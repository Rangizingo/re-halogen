0000000000db2c00 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_>:
; _ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_():
	s_load_b256 s[12:19], s[0:1], null                         // 000000DB2C00: F40C0300 F8000000
	s_mov_b32 s3, 0                                            // 000000DB2C08: BE830080
	v_lshrrev_b32_e32 v143, 5, v0                              // 000000DB2C0C: 331E0085
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000DB2C10: 84828402
	v_and_b32_e32 v142, 15, v0                                 // 000000DB2C14: 371C008F
	v_and_b32_e32 v141, 31, v0                                 // 000000DB2C18: 371A009F
	s_load_b256 s[4:11], s[0:1], 0x20                          // 000000DB2C1C: F40C0100 F8000020
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000DB2C24: 300A0084
	s_waitcnt lgkmcnt(0)                                       // 000000DB2C28: BF89FC07
	s_add_u32 s2, s16, s2                                      // 000000DB2C2C: 80020210
	s_addc_u32 s3, s17, s3                                     // 000000DB2C30: 82030311
	s_load_b128 s[20:23], s[2:3], null                         // 000000DB2C34: F4080501 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000DB2C3C: BF89FC07
	v_lshl_add_u32 v140, v143, 4, s22                          // 000000DB2C40: D646008C 0059098F
	s_add_i32 s2, s23, -1                                      // 000000DB2C48: 8102C117
	s_mul_i32 s0, s20, 0x190000                                // 000000DB2C4C: 9600FF14 00190000
	s_mul_hi_i32 s1, s20, 0x190000                             // 000000DB2C54: 9701FF14 00190000
	s_add_u32 s0, s12, s0                                      // 000000DB2C5C: 8000000C
	v_add_nc_u32_e32 v1, v140, v142                            // 000000DB2C60: 4A031D8C
	s_mul_hi_i32 s3, s21, 0x50000                              // 000000DB2C64: 9703FF15 00050000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000DB2C6C: BF8704B1
	v_min_i32_e32 v1, s2, v1                                   // 000000DB2C70: 22020202
	s_addc_u32 s2, s13, s1                                     // 000000DB2C74: 8202010D
	s_mul_i32 s1, s21, 0x50000                                 // 000000DB2C78: 9601FF15 00050000
	s_add_u32 s1, s0, s1                                       // 000000DB2C80: 80010100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB2C84: BF8700B1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000DB2C88: 3404029F
	s_addc_u32 s2, s2, s3                                      // 000000DB2C8C: 82020302
	s_mov_b32 s0, exec_lo                                      // 000000DB2C90: BE80007E
	.long 0xd73c0001                                           // 000000DB2C94: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DB2C98: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2C9C: BF870091
	.long 0xd7006a01                                           // 000000DB2CA0: D7006A01
	v_cndmask_b32_e32 v1, s18, v1, vcc_lo                      // 000000DB2CA4: 02020212
	v_add_co_ci_u32_e64 v2, null, s19, v2, vcc_lo              // 000000DB2CA8: D5207C02 01AA0413
	global_load_b32 v10, v[1:2], off                           // 000000DB2CB0: DC520000 0A7C0001
	v_lshlrev_b32_e32 v1, 5, v141                              // 000000DB2CB8: 30031A85
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2CBC: BF870091
	v_add_nc_u32_e32 v2, 0x3f0, v1                             // 000000DB2CC0: 4A0402FF 000003F0
	v_lshrrev_b32_e32 v3, 5, v2                                // 000000DB2CC8: 32060485
	v_and_b32_e32 v4, 0x7e0, v2                                // 000000DB2CCC: 360804FF 000007E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB2CD4: BF870112
	v_add_nc_u32_e32 v3, 1, v3                                 // 000000DB2CD8: 4A060681
	v_sub_nc_u32_e32 v4, v4, v1                                // 000000DB2CDC: 4C080304
	v_bfe_u32 v1, v2, 5, 5                                     // 000000DB2CE0: D6100001 02150B02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB2CE8: BF870193
	v_and_b32_e32 v2, 31, v3                                   // 000000DB2CEC: 3604069F
	v_add_nc_u32_e32 v144, 0xfffffc3c, v4                      // 000000DB2CF0: 4B2008FF FFFFFC3C
	v_add_nc_u32_e32 v145, 0xfffffc38, v4                      // 000000DB2CF8: 4B2208FF FFFFFC38
	v_add_nc_u32_e32 v146, 0xfffffc34, v4                      // 000000DB2D00: 4B2408FF FFFFFC34
	v_add_nc_u32_e32 v147, 0xfffffc30, v4                      // 000000DB2D08: 4B2608FF FFFFFC30
	v_lshrrev_b32_e32 v4, 1, v0                                // 000000DB2D10: 32080081
	v_cmpx_lt_u32_e32 0x1ff, v0                                // 000000DB2D14: 7D9200FF 000001FF
	s_xor_b32 s0, exec_lo, s0                                  // 000000DB2D1C: 8D00007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DB2D20: BF870002
	v_and_b32_e32 v3, 8, v4                                    // 000000DB2D24: 36060888
	s_or_saveexec_b32 s0, s0                                   // 000000DB2D28: BE802200
	v_and_b32_e32 v11, 0xf0, v5                                // 000000DB2D2C: 36160AFF 000000F0
	v_lshlrev_b32_e32 v148, 2, v1                              // 000000DB2D34: 31280282
	v_lshlrev_b32_e32 v149, 2, v2                              // 000000DB2D38: 312A0482
	v_lshlrev_b32_e32 v150, 2, v141                            // 000000DB2D3C: 312D1A82
	s_xor_b32 exec_lo, exec_lo, s0                             // 000000DB2D40: 8D7E007E
	s_cbranch_execz 155                                        // 000000DB2D44: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v3, 8, v4           // 000000DB2D48: CA240080 02020888
	v_mov_b32_e32 v5, v143                                     // 000000DB2D50: 7E0A038F
	s_mov_b32 s3, 0                                            // 000000DB2D54: BE830080
	s_movk_i32 s10, 0x1eee                                     // 000000DB2D58: B00A1EEE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2D5C: BF870092
	v_lshlrev_b32_e32 v1, 1, v3                                // 000000DB2D60: 30020681
	v_lshl_add_u32 v4, v11, 1, v1                              // 000000DB2D64: D6460004 0405030B
	v_lshlrev_b32_e32 v1, 5, v5                                // 000000DB2D6C: 30020A85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB2D70: BF870112
	v_lshl_add_u32 v15, v5, 9, v4                              // 000000DB2D74: D646000F 04111305
	.long 0xd73c0006                                           // 000000DB2D7C: D73C0006
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DB2D80: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2D84: BF870091
	.long 0xd7006a01                                           // 000000DB2D88: D7006A01
	v_cndmask_b32_e32 v1, s1, v6, vcc_lo                       // 000000DB2D8C: 02020C01
	v_add_co_ci_u32_e64 v13, null, s2, v7, vcc_lo              // 000000DB2D90: D5207C0D 01AA0E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB2D98: BF870092
	.long 0xd7006a06                                           // 000000DB2D9C: D7006A06
	v_cndmask_b32_e32 v1, v1, v148, vcc_lo                     // 000000DB2DA0: 02032901
	v_add_co_ci_u32_e64 v7, null, 0, v13, vcc_lo               // 000000DB2DA4: D5207C07 01AA1A80
	.long 0xd7006a08                                           // 000000DB2DAC: D7006A08
	v_cndmask_b32_e32 v1, v1, v149, vcc_lo                     // 000000DB2DB0: 02032B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB2DB4: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v13, vcc_lo               // 000000DB2DB8: D5207C09 01AA1A80
	.long 0xd7006a0c                                           // 000000DB2DC0: D7006A0C
	v_cndmask_b32_e32 v1, v1, v150, vcc_lo                     // 000000DB2DC4: 02032D01
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000DB2DC8: D5207C0D 01AA1A80
	s_clause 0x2                                               // 000000DB2DD0: BF850002
	global_load_b32 v7, v[6:7], off                            // 000000DB2DD4: DC520000 077C0006
	global_load_b32 v6, v[8:9], off                            // 000000DB2DDC: DC520000 067C0008
	global_load_b32 v1, v[12:13], off                          // 000000DB2DE4: DC520000 017C000C
	v_cmp_lt_u32_e32 vcc_lo, 7, v5                             // 000000DB2DEC: 7C920A87
	s_or_b32 s3, vcc_lo, s3                                    // 000000DB2DF0: 8C03036A
	s_waitcnt vmcnt(1)                                         // 000000DB2DF4: BF8907F7
	.long 0xd73d000c                                           // 000000DB2DF8: D73D000C
	v_cndmask_b32_e32 v1, v145, v6, vcc_lo                     // 000000DB2DFC: 02020D91
	.long 0xd73d0008                                           // 000000DB2E00: D73D0008
	v_cndmask_b32_e32 v1, v144, v6, vcc_lo                     // 000000DB2E04: 02020D90
	.long 0xd73d000d                                           // 000000DB2E08: D73D000D
	v_cndmask_b32_e32 v1, v146, v6, vcc_lo                     // 000000DB2E0C: 02020D92
	s_waitcnt vmcnt(0)                                         // 000000DB2E10: BF8903F7
	v_bfe_u32 v9, v1, 12, 16                                   // 000000DB2E14: D6100009 02411901
	v_bfe_u32 v14, v1, 8, 16                                   // 000000DB2E1C: D610000E 02411101
	v_bfe_u32 v16, v1, 4, 16                                   // 000000DB2E24: D6100010 02410901
	.long 0xd73d0006                                           // 000000DB2E2C: D73D0006
	v_cndmask_b32_e32 v1, v147, v6, vcc_lo                     // 000000DB2E30: 02020D93
	v_and_b32_e32 v1, 0xffff, v1                               // 000000DB2E34: 360202FF 0000FFFF
	.long 0xd72c0007                                           // 000000DB2E3C: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 000000DB2E40: 020212FF 83DCD12D
	.long 0xd72c0009                                           // 000000DB2E48: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 000000DB2E4C: 02021CFF 83DCD12D
	.long 0xd72c000e                                           // 000000DB2E54: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000DB2E58: 020220FF 83DCD12D
	v_and_b32_e32 v13, 0xffff, v13                             // 000000DB2E60: 361A1AFF 0000FFFF
	v_add_nc_u32_e32 v16, 8, v5                                // 000000DB2E68: 4A200A88
	v_and_b32_e32 v8, 0xffff, v8                               // 000000DB2E6C: 361010FF 0000FFFF
	.long 0xd72c0001                                           // 000000DB2E74: D72C0001
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000DB2E78: 020202FF 83DCD12D
	v_and_b32_e32 v12, 0xffff, v12                             // 000000DB2E80: 361818FF 0000FFFF
	v_and_b32_e32 v6, 0xffff, v6                               // 000000DB2E88: 360C0CFF 0000FFFF
	.long 0xd72c000d                                           // 000000DB2E90: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 000000DB2E94: 02021AFF 83DCD12D
	v_mov_b32_e32 v5, v16                                      // 000000DB2E9C: 7E0A0310
	.long 0xd72c0008                                           // 000000DB2EA0: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000DB2EA4: 020210FF 83DCD12D
	.long 0xd72c000c                                           // 000000DB2EAC: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 000000DB2EB0: 020218FF 83DCD12D
	.long 0xd72c0006                                           // 000000DB2EB8: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000DB2EBC: 02020CFF 83DCD12D
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000DB2EC4: D6220007 03FD0107 00006400
	v_sad_u8 v1, v1, 0, 0x6400                                 // 000000DB2ED0: D6220001 03FD0101 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000DB2EDC: D6220009 03FD0109 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 000000DB2EE8: D622000D 03FD010D 00006400
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000DB2EF4: D622000E 03FD010E 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000DB2F00: D6220008 03FD0108 00006400
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DB2F0C: 360E0EFF 0000FFFF
	v_lshlrev_b32_e32 v1, 16, v1                               // 000000DB2F14: 30020290
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000DB2F18: D622000C 03FD010C 00006400
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000DB2F24: D6220006 03FD0106 00006400
	v_and_b32_e32 v8, 0xffff, v8                               // 000000DB2F30: 361010FF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v13                             // 000000DB2F38: 361A1AFF 0000FFFF
	v_lshl_or_b32 v7, v9, 16, v7                               // 000000DB2F40: D6560007 041D2109
	v_and_or_b32 v1, 0xffff, v14, v1                           // 000000DB2F48: D6570001 04061CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2F54: BF870214
	v_lshl_or_b32 v12, v12, 16, v8                             // 000000DB2F58: D656000C 0421210C
	v_lshl_or_b32 v13, v6, 16, v13                             // 000000DB2F60: D656000D 04352106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2F68: BF870214
	v_pk_fma_f16 v8, v7, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000DB2F6C: CC0E0008 0BFC1507 0000C931
	v_pk_fma_f16 v9, v1, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000DB2F78: CC0E0009 0BFC1501 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB2F84: BF870214
	v_pk_fma_f16 v6, v12, s10, 0xc931 op_sel_hi:[1,0,0]        // 000000DB2F88: CC0E0006 0BFC150C 0000C931
	v_pk_fma_f16 v7, v13, s10, 0xc931 op_sel_hi:[1,0,0]        // 000000DB2F94: CC0E0007 0BFC150D 0000C931
	ds_store_b128 v15, v[6:9]                                  // 000000DB2FA0: DB7C0000 0000060F
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000DB2FA8: 917E037E
	s_cbranch_execnz 65391                                     // 000000DB2FAC: BFA6FF6F <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x16c>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000DB2FB0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000DB2FB4: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000DB2FB8: 8C7E007E
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v1, 1, v3       // 000000DB2FBC: CA220080 02000681
	s_waitcnt vmcnt(0)                                         // 000000DB2FC4: BF8903F7
	v_mad_i64_i32 v[138:139], null, 0x1400, v10, s[14:15]      // 000000DB2FC8: D6FF7C8A 003A14FF 00001400
	.long 0xd4490000                                           // 000000DB2FD4: D4490000
	v_cndmask_b32_e32 v1, 0x1ff, v0, vcc_lo                    // 000000DB2FD8: 020200FF 000001FF
	s_mov_b32 s13, 0                                           // 000000DB2FE0: BE8D0080
	v_mov_b32_e32 v9, v2                                       // 000000DB2FE4: 7E120302
	v_dual_mov_b32 v3, v2 :: v_dual_lshlrev_b32 v152, 5, v142  // 000000DB2FE8: CA220102 03991C85
	v_mov_b32_e32 v4, v2                                       // 000000DB2FF0: 7E080302
	v_mov_b32_e32 v5, v2                                       // 000000DB2FF4: 7E0A0302
	v_mov_b32_e32 v6, v2                                       // 000000DB2FF8: 7E0C0302
	v_mov_b32_e32 v7, v2                                       // 000000DB2FFC: 7E0E0302
	v_mov_b32_e32 v8, v2                                       // 000000DB3000: 7E100302
	v_lshl_add_u32 v151, v11, 1, v1                            // 000000DB3004: D6460097 0405030B
	v_mov_b32_e32 v17, v9                                      // 000000DB300C: 7E220309
	v_mov_b32_e32 v25, v9                                      // 000000DB3010: 7E320309
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB3014: BF870004
	v_dual_mov_b32 v33, v9 :: v_dual_mov_b32 v32, v8           // 000000DB3018: CA100109 21200108
	v_dual_mov_b32 v41, v9 :: v_dual_mov_b32 v40, v8           // 000000DB3020: CA100109 29280108
	v_dual_mov_b32 v49, v9 :: v_dual_mov_b32 v48, v8           // 000000DB3028: CA100109 31300108
	v_dual_mov_b32 v57, v9 :: v_dual_mov_b32 v56, v8           // 000000DB3030: CA100109 39380108
	v_dual_mov_b32 v65, v9 :: v_dual_mov_b32 v64, v8           // 000000DB3038: CA100109 41400108
	v_dual_mov_b32 v73, v9 :: v_dual_mov_b32 v72, v8           // 000000DB3040: CA100109 49480108
	v_dual_mov_b32 v81, v9 :: v_dual_mov_b32 v80, v8           // 000000DB3048: CA100109 51500108
	v_dual_mov_b32 v89, v9 :: v_dual_mov_b32 v88, v8           // 000000DB3050: CA100109 59580108
	v_dual_mov_b32 v97, v9 :: v_dual_mov_b32 v96, v8           // 000000DB3058: CA100109 61600108
	v_dual_mov_b32 v105, v9 :: v_dual_mov_b32 v104, v8         // 000000DB3060: CA100109 69680108
	v_dual_mov_b32 v113, v9 :: v_dual_mov_b32 v112, v8         // 000000DB3068: CA100109 71700108
	v_dual_mov_b32 v121, v9 :: v_dual_mov_b32 v120, v8         // 000000DB3070: CA100109 79780108
	v_dual_mov_b32 v129, v9 :: v_dual_mov_b32 v128, v8         // 000000DB3078: CA100109 81800108
	v_dual_mov_b32 v137, v9 :: v_dual_mov_b32 v136, v8         // 000000DB3080: CA100109 89880108
	v_dual_mov_b32 v16, v8 :: v_dual_mov_b32 v15, v7           // 000000DB3088: CA100108 100E0107
	v_dual_mov_b32 v14, v6 :: v_dual_mov_b32 v13, v5           // 000000DB3090: CA100106 0E0C0105
	v_dual_mov_b32 v12, v4 :: v_dual_mov_b32 v11, v3           // 000000DB3098: CA100104 0C0A0103
	v_mov_b32_e32 v10, v2                                      // 000000DB30A0: 7E140302
	v_dual_mov_b32 v24, v8 :: v_dual_mov_b32 v23, v7           // 000000DB30A4: CA100108 18160107
	v_dual_mov_b32 v22, v6 :: v_dual_mov_b32 v21, v5           // 000000DB30AC: CA100106 16140105
	v_dual_mov_b32 v20, v4 :: v_dual_mov_b32 v19, v3           // 000000DB30B4: CA100104 14120103
	v_dual_mov_b32 v18, v2 :: v_dual_mov_b32 v31, v7           // 000000DB30BC: CA100102 121E0107
	v_dual_mov_b32 v30, v6 :: v_dual_mov_b32 v29, v5           // 000000DB30C4: CA100106 1E1C0105
	v_dual_mov_b32 v28, v4 :: v_dual_mov_b32 v27, v3           // 000000DB30CC: CA100104 1C1A0103
	v_dual_mov_b32 v26, v2 :: v_dual_mov_b32 v39, v7           // 000000DB30D4: CA100102 1A260107
	v_dual_mov_b32 v38, v6 :: v_dual_mov_b32 v37, v5           // 000000DB30DC: CA100106 26240105
	v_dual_mov_b32 v36, v4 :: v_dual_mov_b32 v35, v3           // 000000DB30E4: CA100104 24220103
	v_dual_mov_b32 v34, v2 :: v_dual_mov_b32 v47, v7           // 000000DB30EC: CA100102 222E0107
	v_dual_mov_b32 v46, v6 :: v_dual_mov_b32 v45, v5           // 000000DB30F4: CA100106 2E2C0105
	v_dual_mov_b32 v44, v4 :: v_dual_mov_b32 v43, v3           // 000000DB30FC: CA100104 2C2A0103
	v_dual_mov_b32 v42, v2 :: v_dual_mov_b32 v55, v7           // 000000DB3104: CA100102 2A360107
	v_dual_mov_b32 v54, v6 :: v_dual_mov_b32 v53, v5           // 000000DB310C: CA100106 36340105
	v_dual_mov_b32 v52, v4 :: v_dual_mov_b32 v51, v3           // 000000DB3114: CA100104 34320103
	v_dual_mov_b32 v50, v2 :: v_dual_mov_b32 v63, v7           // 000000DB311C: CA100102 323E0107
	v_dual_mov_b32 v62, v6 :: v_dual_mov_b32 v61, v5           // 000000DB3124: CA100106 3E3C0105
	v_dual_mov_b32 v60, v4 :: v_dual_mov_b32 v59, v3           // 000000DB312C: CA100104 3C3A0103
	v_dual_mov_b32 v58, v2 :: v_dual_mov_b32 v71, v7           // 000000DB3134: CA100102 3A460107
	v_dual_mov_b32 v70, v6 :: v_dual_mov_b32 v69, v5           // 000000DB313C: CA100106 46440105
	v_dual_mov_b32 v68, v4 :: v_dual_mov_b32 v67, v3           // 000000DB3144: CA100104 44420103
	v_dual_mov_b32 v66, v2 :: v_dual_mov_b32 v79, v7           // 000000DB314C: CA100102 424E0107
	v_dual_mov_b32 v78, v6 :: v_dual_mov_b32 v77, v5           // 000000DB3154: CA100106 4E4C0105
	v_dual_mov_b32 v76, v4 :: v_dual_mov_b32 v75, v3           // 000000DB315C: CA100104 4C4A0103
	v_dual_mov_b32 v74, v2 :: v_dual_mov_b32 v87, v7           // 000000DB3164: CA100102 4A560107
	v_dual_mov_b32 v86, v6 :: v_dual_mov_b32 v85, v5           // 000000DB316C: CA100106 56540105
	v_dual_mov_b32 v84, v4 :: v_dual_mov_b32 v83, v3           // 000000DB3174: CA100104 54520103
	v_dual_mov_b32 v82, v2 :: v_dual_mov_b32 v95, v7           // 000000DB317C: CA100102 525E0107
	v_dual_mov_b32 v94, v6 :: v_dual_mov_b32 v93, v5           // 000000DB3184: CA100106 5E5C0105
	v_dual_mov_b32 v92, v4 :: v_dual_mov_b32 v91, v3           // 000000DB318C: CA100104 5C5A0103
	v_dual_mov_b32 v90, v2 :: v_dual_mov_b32 v103, v7          // 000000DB3194: CA100102 5A660107
	v_dual_mov_b32 v102, v6 :: v_dual_mov_b32 v101, v5         // 000000DB319C: CA100106 66640105
	v_dual_mov_b32 v100, v4 :: v_dual_mov_b32 v99, v3          // 000000DB31A4: CA100104 64620103
	v_dual_mov_b32 v98, v2 :: v_dual_mov_b32 v111, v7          // 000000DB31AC: CA100102 626E0107
	v_dual_mov_b32 v110, v6 :: v_dual_mov_b32 v109, v5         // 000000DB31B4: CA100106 6E6C0105
	v_dual_mov_b32 v108, v4 :: v_dual_mov_b32 v107, v3         // 000000DB31BC: CA100104 6C6A0103
	v_dual_mov_b32 v106, v2 :: v_dual_mov_b32 v119, v7         // 000000DB31C4: CA100102 6A760107
	v_dual_mov_b32 v118, v6 :: v_dual_mov_b32 v117, v5         // 000000DB31CC: CA100106 76740105
	v_dual_mov_b32 v116, v4 :: v_dual_mov_b32 v115, v3         // 000000DB31D4: CA100104 74720103
	v_dual_mov_b32 v114, v2 :: v_dual_mov_b32 v127, v7         // 000000DB31DC: CA100102 727E0107
	v_dual_mov_b32 v126, v6 :: v_dual_mov_b32 v125, v5         // 000000DB31E4: CA100106 7E7C0105
	v_dual_mov_b32 v124, v4 :: v_dual_mov_b32 v123, v3         // 000000DB31EC: CA100104 7C7A0103
	v_dual_mov_b32 v122, v2 :: v_dual_mov_b32 v135, v7         // 000000DB31F4: CA100102 7A860107
	v_dual_mov_b32 v134, v6 :: v_dual_mov_b32 v133, v5         // 000000DB31FC: CA100106 86840105
	v_dual_mov_b32 v132, v4 :: v_dual_mov_b32 v131, v3         // 000000DB3204: CA100104 84820103
	v_mov_b32_e32 v130, v2                                     // 000000DB320C: 7F040302
	s_xor_b32 s3, s0, -1                                       // 000000DB3210: 8D03C100
	s_movk_i32 s10, 0x1eee                                     // 000000DB3214: B00A1EEE
	v_cmp_gt_i32_e32 vcc_lo, s23, v140                         // 000000DB3218: 7C891817
	s_branch 4                                                 // 000000DB321C: BFA00004 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x630>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000DB3220: 8C7E0C7E
	s_cmpk_eq_i32 s11, 0xa0                                    // 000000DB3224: B18B00A0
	s_mov_b32 s13, s11                                         // 000000DB3228: BE8D000B
	s_cbranch_scc1 295                                         // 000000DB322C: BFA20127 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0xacc>
	s_and_b32 s14, s13, 1                                      // 000000DB3230: 8B0E810D
	s_add_i32 s11, s13, 1                                      // 000000DB3234: 810B810D
	s_cmpk_lg_i32 s13, 0x9f                                    // 000000DB3238: B20D009F
	s_waitcnt lgkmcnt(0)                                       // 000000DB323C: BF89FC07
	s_cselect_b32 s0, -1, 0                                    // 000000DB3240: 980080C1
	s_barrier                                                  // 000000DB3244: BFBD0000
	s_and_b32 s0, s0, s3                                       // 000000DB3248: 8B000300
	buffer_gl0_inv                                             // 000000DB324C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 000000DB3254: BE8C2000
	s_cbranch_execz 155                                        // 000000DB3258: BFA5009B <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x8c8>
	s_xor_b32 s0, s14, 1                                       // 000000DB325C: 8D00810E
	v_mov_b32_e32 v4, v143                                     // 000000DB3260: 7E08038F
	v_lshl_add_u32 v3, s0, 13, v151                            // 000000DB3264: D6460003 065D1A00
	s_lshl_b32 s15, s11, 9                                     // 000000DB326C: 840F890B
	s_mov_b32 s16, 0                                           // 000000DB3270: BE900080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB3274: BF870112
	v_lshl_add_u32 v1, v4, 5, s15                              // 000000DB3278: D6460001 003D0B04
	v_lshl_add_u32 v155, v4, 9, v3                             // 000000DB3280: D646009B 040D1304
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB3288: BF870092
	.long 0xd73c0005                                           // 000000DB328C: D73C0005
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000DB3290: 02020282
	.long 0xd7000001                                           // 000000DB3294: D7000001
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000DB3298: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB329C: BF870111
	v_add_co_ci_u32_e64 v9, null, s2, v6, s0                   // 000000DB32A0: D5207C09 00020C02
	.long 0xd7000005                                           // 000000DB32A8: D7000005
	v_cndmask_b32_e32 v1, v1, v148, vcc_lo                     // 000000DB32AC: 02032901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB32B0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v9, s0                    // 000000DB32B4: D5207C06 00021280
	.long 0xd7000007                                           // 000000DB32BC: D7000007
	v_cndmask_b32_e32 v1, v1, v149, vcc_lo                     // 000000DB32C0: 02032B01
	v_add_co_ci_u32_e64 v8, null, 0, v9, s0                    // 000000DB32C4: D5207C08 00021280
	.long 0xd7000099                                           // 000000DB32CC: D7000099
	v_cndmask_b32_e32 v1, v1, v150, vcc_lo                     // 000000DB32D0: 02032D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB32D4: BF870001
	v_add_co_ci_u32_e64 v154, null, 0, v9, s0                  // 000000DB32D8: D5207C9A 00021280
	s_clause 0x2                                               // 000000DB32E0: BF850002
	global_load_b32 v6, v[5:6], off                            // 000000DB32E4: DC520000 067C0005
	global_load_b32 v5, v[7:8], off                            // 000000DB32EC: DC520000 057C0007
	global_load_b32 v1, v[153:154], off                        // 000000DB32F4: DC520000 017C0099
	.long 0xd4490000                                           // 000000DB32FC: D4490000
	v_cndmask_b32_e32 v1, 7, v4, vcc_lo                        // 000000DB3300: 02020887
	s_or_b32 s16, s0, s16                                      // 000000DB3304: 8C101000
	s_waitcnt vmcnt(1)                                         // 000000DB3308: BF8907F7
	.long 0xd73d0007                                           // 000000DB330C: D73D0007
	v_cndmask_b32_e32 v1, v144, v5, vcc_lo                     // 000000DB3310: 02020B90
	.long 0xd73d0008                                           // 000000DB3314: D73D0008
	v_cndmask_b32_e32 v1, v145, v5, vcc_lo                     // 000000DB3318: 02020B91
	.long 0xd73d0099                                           // 000000DB331C: D73D0099
	v_cndmask_b32_e32 v1, v146, v5, vcc_lo                     // 000000DB3320: 02020B92
	s_waitcnt vmcnt(0)                                         // 000000DB3324: BF8903F7
	v_bfe_u32 v9, v1, 12, 16                                   // 000000DB3328: D6100009 02411901
	v_bfe_u32 v154, v1, 8, 16                                  // 000000DB3330: D610009A 02411101
	v_bfe_u32 v156, v1, 4, 16                                  // 000000DB3338: D610009C 02410901
	.long 0xd73d0005                                           // 000000DB3340: D73D0005
	v_cndmask_b32_e32 v1, v147, v5, vcc_lo                     // 000000DB3344: 02020B93
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DB3348: 360E0EFF 0000FFFF
	.long 0xd72c0006                                           // 000000DB3350: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 000000DB3354: 020212FF 83DCD12D
	.long 0xd72c0009                                           // 000000DB335C: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 000000DB3360: 020334FF 83DCD12D
	.long 0xd72c009a                                           // 000000DB3368: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 000000DB336C: 020338FF 83DCD12D
	v_and_b32_e32 v153, 0xffff, v153                           // 000000DB3374: 373332FF 0000FFFF
	v_add_nc_u32_e32 v156, 8, v4                               // 000000DB337C: 4B380888
	v_and_b32_e32 v1, 0xffff, v1                               // 000000DB3380: 360202FF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 000000DB3388: 361010FF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 000000DB3390: 360A0AFF 0000FFFF
	.long 0xd72c0007                                           // 000000DB3398: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000DB339C: 02020EFF 83DCD12D
	.long 0xd72c0099                                           // 000000DB33A4: D72C0099
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 000000DB33A8: 020332FF 83DCD12D
	v_mov_b32_e32 v4, v156                                     // 000000DB33B0: 7E08039C
	.long 0xd72c0001                                           // 000000DB33B4: D72C0001
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 000000DB33B8: 020202FF 83DCD12D
	.long 0xd72c0008                                           // 000000DB33C0: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 000000DB33C4: 020210FF 83DCD12D
	.long 0xd72c0005                                           // 000000DB33CC: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000DB33D0: 02020AFF 83DCD12D
	v_sad_u8 v6, v6, 0, 0x6400                                 // 000000DB33D8: D6220006 03FD0106 00006400
	v_sad_u8 v9, v9, 0, 0x6400                                 // 000000DB33E4: D6220009 03FD0109 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000DB33F0: D6220007 03FD0107 00006400
	v_sad_u8 v153, v153, 0, 0x6400                             // 000000DB33FC: D6220099 03FD0199 00006400
	v_sad_u8 v154, v154, 0, 0x6400                             // 000000DB3408: D622009A 03FD019A 00006400
	v_sad_u8 v1, v1, 0, 0x6400                                 // 000000DB3414: D6220001 03FD0101 00006400
	v_and_b32_e32 v6, 0xffff, v6                               // 000000DB3420: 360C0CFF 0000FFFF
	v_sad_u8 v8, v8, 0, 0x6400                                 // 000000DB3428: D6220008 03FD0108 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 000000DB3434: D6220005 03FD0105 00006400
	v_and_b32_e32 v7, 0xffff, v7                               // 000000DB3440: 360E0EFF 0000FFFF
	v_lshlrev_b32_e32 v1, 16, v1                               // 000000DB3448: 30020290
	v_and_b32_e32 v153, 0xffff, v153                           // 000000DB344C: 373332FF 0000FFFF
	v_lshl_or_b32 v6, v9, 16, v6                               // 000000DB3454: D6560006 04192109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB345C: BF870214
	v_lshl_or_b32 v9, v8, 16, v7                               // 000000DB3460: D6560009 041D2108
	v_and_or_b32 v1, 0xffff, v154, v1                          // 000000DB3468: D6570001 040734FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB3474: BF870214
	v_lshl_or_b32 v153, v5, 16, v153                           // 000000DB3478: D6560099 06652105
	v_pk_fma_f16 v7, v6, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000DB3480: CC0E0007 0BFC1506 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB348C: BF870214
	v_pk_fma_f16 v5, v9, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000DB3490: CC0E0005 0BFC1509 0000C931
	v_pk_fma_f16 v8, v1, s10, 0xc931 op_sel_hi:[1,0,0]         // 000000DB349C: CC0E0008 0BFC1501 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB34A8: BF870004
	v_pk_fma_f16 v6, v153, s10, 0xc931 op_sel_hi:[1,0,0]       // 000000DB34AC: CC0E0006 0BFC1599 0000C931
	ds_store_b128 v155, v[5:8]                                 // 000000DB34B8: DB7C0000 0000059B
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000DB34C0: 917E107E
	s_cbranch_execnz 65387                                     // 000000DB34C4: BFA6FF6B <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x674>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000DB34C8: 8C7E0C7E
	s_and_saveexec_b32 s12, vcc_lo                             // 000000DB34CC: BE8C206A
	s_cbranch_execz 65363                                      // 000000DB34D0: BFA5FF53 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x620>
	s_lshl_b32 s0, s13, 5                                      // 000000DB34D4: 8400850D
	v_lshl_or_b32 v1, s14, 13, v152                            // 000000DB34D8: D6560001 06611A0E
	.long 0xd7000003                                           // 000000DB34E0: D7000003
	v_cndmask_b32_e32 v0, v138, v0, vcc_lo                     // 000000DB34E4: 0200018A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB34E8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v139, s0                  // 000000DB34EC: D5207C04 00031680
	ds_load_b128 v[161:164], v1                                // 000000DB34F4: DBFC0000 A1000001
	ds_load_b128 v[165:168], v1 offset:16                      // 000000DB34FC: DBFC0010 A5000001
	ds_load_b128 v[173:176], v1 offset:528                     // 000000DB3504: DBFC0210 AD000001
	ds_load_b128 v[169:172], v1 offset:512                     // 000000DB350C: DBFC0200 A9000001
	s_clause 0x1                                               // 000000DB3514: BF850001
	global_load_b128 v[157:160], v[3:4], off offset:16         // 000000DB3518: DC5E0010 9D7C0003
	global_load_b128 v[153:156], v[3:4], off                   // 000000DB3520: DC5E0000 997C0003
	s_waitcnt vmcnt(0) lgkmcnt(2)                              // 000000DB3528: BF890027
	v_wmma_f32_16x16x16_f16 v[130:137], v[153:160], v[161:168], v[130:137]// 000000DB352C: CC404082 1E0B4399
	ds_load_b128 v[165:168], v1 offset:1040                    // 000000DB3534: DBFC0410 A5000001
	ds_load_b128 v[161:164], v1 offset:1024                    // 000000DB353C: DBFC0400 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3544: BF89FC27
	v_wmma_f32_16x16x16_f16 v[122:129], v[153:160], v[169:176], v[122:129]// 000000DB3548: CC40407A 1DEB5399
	ds_load_b128 v[173:176], v1 offset:1552                    // 000000DB3550: DBFC0610 AD000001
	ds_load_b128 v[169:172], v1 offset:1536                    // 000000DB3558: DBFC0600 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3560: BF89FC27
	v_wmma_f32_16x16x16_f16 v[114:121], v[153:160], v[161:168], v[114:121]// 000000DB3564: CC404072 1DCB4399
	ds_load_b128 v[165:168], v1 offset:2064                    // 000000DB356C: DBFC0810 A5000001
	ds_load_b128 v[161:164], v1 offset:2048                    // 000000DB3574: DBFC0800 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB357C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[106:113], v[153:160], v[169:176], v[106:113]// 000000DB3580: CC40406A 1DAB5399
	ds_load_b128 v[173:176], v1 offset:2576                    // 000000DB3588: DBFC0A10 AD000001
	ds_load_b128 v[169:172], v1 offset:2560                    // 000000DB3590: DBFC0A00 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3598: BF89FC27
	v_wmma_f32_16x16x16_f16 v[98:105], v[153:160], v[161:168], v[98:105]// 000000DB359C: CC404062 1D8B4399
	ds_load_b128 v[165:168], v1 offset:3088                    // 000000DB35A4: DBFC0C10 A5000001
	ds_load_b128 v[161:164], v1 offset:3072                    // 000000DB35AC: DBFC0C00 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB35B4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[90:97], v[153:160], v[169:176], v[90:97]// 000000DB35B8: CC40405A 1D6B5399
	ds_load_b128 v[173:176], v1 offset:3600                    // 000000DB35C0: DBFC0E10 AD000001
	ds_load_b128 v[169:172], v1 offset:3584                    // 000000DB35C8: DBFC0E00 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB35D0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[82:89], v[153:160], v[161:168], v[82:89]// 000000DB35D4: CC404052 1D4B4399
	ds_load_b128 v[165:168], v1 offset:4112                    // 000000DB35DC: DBFC1010 A5000001
	ds_load_b128 v[161:164], v1 offset:4096                    // 000000DB35E4: DBFC1000 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB35EC: BF89FC27
	v_wmma_f32_16x16x16_f16 v[74:81], v[153:160], v[169:176], v[74:81]// 000000DB35F0: CC40404A 1D2B5399
	ds_load_b128 v[173:176], v1 offset:4624                    // 000000DB35F8: DBFC1210 AD000001
	ds_load_b128 v[169:172], v1 offset:4608                    // 000000DB3600: DBFC1200 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3608: BF89FC27
	v_wmma_f32_16x16x16_f16 v[66:73], v[153:160], v[161:168], v[66:73]// 000000DB360C: CC404042 1D0B4399
	ds_load_b128 v[165:168], v1 offset:5136                    // 000000DB3614: DBFC1410 A5000001
	ds_load_b128 v[161:164], v1 offset:5120                    // 000000DB361C: DBFC1400 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3624: BF89FC27
	v_wmma_f32_16x16x16_f16 v[58:65], v[153:160], v[169:176], v[58:65]// 000000DB3628: CC40403A 1CEB5399
	ds_load_b128 v[173:176], v1 offset:5648                    // 000000DB3630: DBFC1610 AD000001
	ds_load_b128 v[169:172], v1 offset:5632                    // 000000DB3638: DBFC1600 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3640: BF89FC27
	v_wmma_f32_16x16x16_f16 v[50:57], v[153:160], v[161:168], v[50:57]// 000000DB3644: CC404032 1CCB4399
	ds_load_b128 v[165:168], v1 offset:6160                    // 000000DB364C: DBFC1810 A5000001
	ds_load_b128 v[161:164], v1 offset:6144                    // 000000DB3654: DBFC1800 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB365C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[42:49], v[153:160], v[169:176], v[42:49]// 000000DB3660: CC40402A 1CAB5399
	ds_load_b128 v[173:176], v1 offset:6672                    // 000000DB3668: DBFC1A10 AD000001
	ds_load_b128 v[169:172], v1 offset:6656                    // 000000DB3670: DBFC1A00 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3678: BF89FC27
	v_wmma_f32_16x16x16_f16 v[34:41], v[153:160], v[161:168], v[34:41]// 000000DB367C: CC404022 1C8B4399
	ds_load_b128 v[165:168], v1 offset:7184                    // 000000DB3684: DBFC1C10 A5000001
	ds_load_b128 v[161:164], v1 offset:7168                    // 000000DB368C: DBFC1C00 A1000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB3694: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[153:160], v[169:176], v[26:33]// 000000DB3698: CC40401A 1C6B5399
	ds_load_b128 v[173:176], v1 offset:7696                    // 000000DB36A0: DBFC1E10 AD000001
	ds_load_b128 v[169:172], v1 offset:7680                    // 000000DB36A8: DBFC1E00 A9000001
	s_waitcnt lgkmcnt(2)                                       // 000000DB36B0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[153:160], v[161:168], v[18:25]// 000000DB36B4: CC404012 1C4B4399
	s_waitcnt lgkmcnt(0)                                       // 000000DB36BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[153:160], v[169:176], v[10:17]// 000000DB36C0: CC40400A 1C2B5399
	s_branch 65237                                             // 000000DB36C8: BFA0FED5 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x620>
	s_and_saveexec_b32 s0, vcc_lo                              // 000000DB36CC: BE80206A
	s_cbranch_execz 7906                                       // 000000DB36D0: BFA51EE2 <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x865c>
	v_dual_add_f32 v2, v130, v122 :: v_dual_and_b32 v1, 1, v0  // 000000DB36D4: C924F582 02000081
	v_and_b32_e32 v147, 2, v0                                  // 000000DB36DC: 37260082
	v_dual_sub_f32 v3, v130, v122 :: v_dual_and_b32 v148, 4, v0// 000000DB36E0: C964F582 03940084
	v_and_b32_e32 v149, 8, v0                                  // 000000DB36E8: 372A0088
	v_lshrrev_b32_e32 v0, 4, v141                              // 000000DB36EC: 32011A84
	v_add_f32_e32 v122, v114, v106                             // 000000DB36F0: 06F4D572
	v_sub_f32_e32 v106, v114, v106                             // 000000DB36F4: 08D4D572
	v_add_f32_e32 v114, v98, v90                               // 000000DB36F8: 06E4B562
	v_sub_f32_e32 v90, v98, v90                                // 000000DB36FC: 08B4B562
	v_add_f32_e32 v98, v82, v74                                // 000000DB3700: 06C49552
	v_sub_f32_e32 v74, v82, v74                                // 000000DB3704: 08949552
	s_mul_i32 s0, s20, 0xa00                                   // 000000DB3708: 9600FF14 00000A00
	s_mul_hi_i32 s1, s20, 0xa00                                // 000000DB3710: 9701FF14 00000A00
	s_add_u32 s4, s4, s0                                       // 000000DB3718: 80040004
	v_add_f32_e32 v82, v66, v58                                // 000000DB371C: 06A47542
	v_sub_f32_e32 v58, v66, v58                                // 000000DB3720: 08747542
	v_add_f32_e32 v66, v50, v42                                // 000000DB3724: 06845532
	v_sub_f32_e32 v42, v50, v42                                // 000000DB3728: 08545532
	v_add_f32_e32 v50, v34, v26                                // 000000DB372C: 06643522
	v_sub_f32_e32 v26, v34, v26                                // 000000DB3730: 08343522
	v_add_f32_e32 v34, v18, v10                                // 000000DB3734: 06441512
	v_sub_f32_e32 v10, v18, v10                                // 000000DB3738: 08141512
	v_add_nc_u32_e32 v6, v140, v0                              // 000000DB373C: 4A0C018C
	v_add_f32_e32 v18, v3, v106                                // 000000DB3740: 0624D503
	v_sub_f32_e32 v3, v3, v106                                 // 000000DB3744: 0806D503
	v_add_f32_e32 v106, v114, v98                              // 000000DB3748: 06D4C572
	v_sub_f32_e32 v98, v114, v98                               // 000000DB374C: 08C4C572
	v_add_f32_e32 v114, v90, v74                               // 000000DB3750: 06E4955A
	v_sub_f32_e32 v74, v90, v74                                // 000000DB3754: 0894955A
	s_addc_u32 s5, s5, s1                                      // 000000DB3758: 82050105
	s_lshl_b32 s0, s21, 7                                      // 000000DB375C: 84008715
	v_add_f32_e32 v0, v2, v122                                 // 000000DB3760: 0600F502
	s_ashr_i32 s1, s0, 31                                      // 000000DB3764: 86019F00
	v_sub_f32_e32 v2, v2, v122                                 // 000000DB3768: 0804F502
	s_lshl_b64 s[2:3], s[0:1], 1                               // 000000DB376C: 84828100
	.long 0xd44a0000                                           // 000000DB3770: D44A0000
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000DB3774: 02020280
	v_add_f32_e32 v141, v3, v74                                // 000000DB3778: 071A9503
	s_add_u32 s4, s4, s2                                       // 000000DB377C: 80040204
	s_mul_i32 s10, s20, 0x500                                  // 000000DB3780: 960AFF14 00000500
	v_add_f32_e32 v151, v2, v98                                // 000000DB3788: 072EC502
	v_sub_f32_e32 v98, v2, v98                                 // 000000DB378C: 08C4C502
	v_mov_b32_dpp v167, v141 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3790: 7F4E02FA FF01618D
	v_cndmask_b32_e64 v141, -v141, v141, s0                    // 000000DB3798: D501008D 20031B8D
	s_addc_u32 s5, s5, s3                                      // 000000DB37A0: 82050305
	s_mul_hi_i32 s1, s20, 0x500                                // 000000DB37A4: 9701FF14 00000500
	s_add_u32 s6, s6, s10                                      // 000000DB37AC: 80060A06
	s_addc_u32 s1, s7, s1                                      // 000000DB37B0: 82010107
	s_add_u32 s10, s6, s2                                      // 000000DB37B4: 800A0206
	s_addc_u32 s11, s1, s3                                     // 000000DB37B8: 820B0301
	v_mov_b32_dpp v171, v98 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB37BC: 7F5602FA FF016162
	v_cndmask_b32_e64 v98, -v98, v98, s0                       // 000000DB37C4: D5010062 2002C562
	.long 0xd44a0001                                           // 000000DB37CC: D44A0001
	v_cndmask_b32_e32 v1, 0, v147, vcc_lo                      // 000000DB37D0: 02032680
	v_dual_add_f32 v141, v141, v167 :: v_dual_add_f32 v122, v50, v34// 000000DB37D4: C9094F8D 8D7A4532
	v_sub_f32_e32 v34, v50, v34                                // 000000DB37DC: 08444532
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB37E0: BF870224
	v_add_f32_e32 v98, v98, v171                               // 000000DB37E4: 06C55762
	v_add_f32_e32 v50, v26, v10                                // 000000DB37E8: 0664151A
	v_mov_b32_dpp v171, v141 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB37EC: 7F5602FA FF01628D
	v_cndmask_b32_e64 v141, -v141, v141, s1                    // 000000DB37F4: D501008D 20071B8D
	v_add_f32_e32 v140, v0, v106                               // 000000DB37FC: 0718D500
	v_sub_f32_e32 v10, v26, v10                                // 000000DB3800: 0814151A
	v_add_f32_e32 v130, v18, v114                              // 000000DB3804: 0704E512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB3808: BF870004
	v_dual_sub_f32 v0, v0, v106 :: v_dual_add_f32 v141, v141, v171// 000000DB380C: C948D500 008D578D
	v_add_f32_e32 v90, v82, v66                                // 000000DB3814: 06B48552
	v_sub_f32_e32 v66, v82, v66                                // 000000DB3818: 08848552
	v_add_f32_e32 v82, v58, v42                                // 000000DB381C: 06A4553A
	v_sub_f32_e32 v42, v58, v42                                // 000000DB3820: 0854553A
	v_mov_b32_dpp v164, v140 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3824: 7F4802FA FF01618C
	v_add_f32_e32 v58, v90, v122                               // 000000DB382C: 0674F55A
	v_cndmask_b32_e64 v140, -v140, v140, s0                    // 000000DB3830: D501008C 2003198C
	v_sub_f32_e32 v1, v90, v122                                // 000000DB3838: 0802F55A
	v_add_f32_e32 v90, v82, v50                                // 000000DB383C: 06B46552
	v_sub_f32_e32 v50, v82, v50                                // 000000DB3840: 08646552
	v_add_f32_e32 v82, v66, v34                                // 000000DB3844: 06A44542
	v_add_f32_e32 v140, v140, v164                             // 000000DB3848: 0719498C
	v_mov_b32_dpp v155, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB384C: 7F3602FA FF016101
	v_cndmask_b32_e64 v156, -v1, v1, s0                        // 000000DB3854: D501009C 20020301
	v_lshlrev_b32_e32 v4, 1, v142                              // 000000DB385C: 30091C81
	v_mov_b32_dpp v153, v82 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3860: 7F3202FA FF016152
	v_cndmask_b32_e64 v82, -v82, v82, s0                       // 000000DB3868: D5010052 2002A552
	v_add_f32_e32 v122, v42, v10                               // 000000DB3870: 06F4152A
	v_sub_f32_e32 v42, v42, v10                                // 000000DB3874: 0854152A
	v_sub_f32_e32 v66, v66, v34                                // 000000DB3878: 08844542
	v_sub_f32_e32 v114, v18, v114                              // 000000DB387C: 08E4E512
	v_dual_add_f32 v82, v82, v153 :: v_dual_add_f32 v153, v156, v155// 000000DB3880: C9093352 5299379C
	s_clause 0xc                                               // 000000DB3888: BF85000C
	global_load_d16_b16 v7, v4, s[4:5]                         // 000000DB388C: DC820000 07040004
	global_load_d16_b16 v5, v4, s[4:5] offset:1280             // 000000DB3894: DC820500 05040004
	global_load_d16_b16 v9, v4, s[4:5] offset:1312             // 000000DB389C: DC820520 09040004
	global_load_d16_b16 v8, v4, s[4:5] offset:32               // 000000DB38A4: DC820020 08040004
	global_load_d16_b16 v139, v4, s[4:5] offset:1344           // 000000DB38AC: DC820540 8B040004
	global_load_d16_b16 v138, v4, s[4:5] offset:64             // 000000DB38B4: DC820040 8A040004
	global_load_d16_b16 v142, v4, s[4:5] offset:96             // 000000DB38BC: DC820060 8E040004
	global_load_d16_b16 v143, v4, s[4:5] offset:128            // 000000DB38C4: DC820080 8F040004
	global_load_d16_b16 v144, v4, s[4:5] offset:160            // 000000DB38CC: DC8200A0 90040004
	global_load_d16_b16 v145, v4, s[4:5] offset:192            // 000000DB38D4: DC8200C0 91040004
	global_load_d16_b16 v146, v4, s[4:5] offset:224            // 000000DB38DC: DC8200E0 92040004
	global_load_d16_b16 v150, v4, s[4:5] offset:1376           // 000000DB38E4: DC820560 96040004
	global_load_d16_b16 v157, v4, s[10:11] offset:32           // 000000DB38EC: DC820020 9D0A0004
	v_mov_b32_dpp v162, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB38F4: 7F4402FA FF01612A
	v_cndmask_b32_e64 v163, -v42, v42, s0                      // 000000DB38FC: D50100A3 2002552A
	v_mov_b32_dpp v160, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3904: 7F4002FA FF016142
	v_cndmask_b32_e64 v161, -v66, v66, s0                      // 000000DB390C: D50100A1 20028542
	v_mov_b32_dpp v154, v122 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3914: 7F3402FA FF01617A
	v_cndmask_b32_e64 v122, -v122, v122, s0                    // 000000DB391C: D501007A 2002F57A
	v_add_f32_e32 v156, v163, v162                             // 000000DB3924: 073945A3
	v_mov_b32_dpp v158, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3928: 7F3C02FA FF016132
	v_cndmask_b32_e64 v159, -v50, v50, s0                      // 000000DB3930: D501009F 20026532
	v_mov_b32_dpp v165, v130 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3938: 7F4A02FA FF016182
	v_cndmask_b32_e64 v130, -v130, v130, s0                    // 000000DB3940: D5010082 20030582
	v_mov_b32_dpp v167, v156 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3948: 7F4E02FA FF01629C
	v_cndmask_b32_e64 v156, -v156, v156, s1                    // 000000DB3950: D501009C 2007399C
	v_mov_b32_dpp v168, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3958: 7F5002FA FF016100
	v_cndmask_b32_e64 v170, -v0, v0, s0                        // 000000DB3960: D50100AA 20020100
	v_add_f32_e32 v155, v161, v160                             // 000000DB3968: 073741A1
	v_mov_b32_dpp v169, v114 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB396C: 7F5202FA FF016172
	v_add_f32_e32 v156, v156, v167                             // 000000DB3974: 07394F9C
	v_mov_b32_dpp v166, v151 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3978: 7F4C02FA FF016197
	v_cndmask_b32_e64 v151, -v151, v151, s0                    // 000000DB3980: D5010097 20032F97
	v_cndmask_b32_e64 v114, -v114, v114, s0                    // 000000DB3988: D5010072 2002E572
	v_add_f32_e32 v122, v122, v154                             // 000000DB3990: 06F5357A
	v_add_f32_e32 v154, v159, v158                             // 000000DB3994: 07353D9F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB3998: BF870004
	v_dual_add_f32 v158, v170, v168 :: v_dual_add_f32 v151, v151, v166// 000000DB399C: C90951AA 9E974D97
	v_mov_b32_dpp v166, v155 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB39A4: 7F4C02FA FF01629B
	v_cndmask_b32_e64 v155, -v155, v155, s1                    // 000000DB39AC: D501009B 2007379B
	v_add_f32_e32 v130, v130, v165                             // 000000DB39B4: 07054B82
	s_add_u32 s2, s8, s2                                       // 000000DB39B8: 80020208
	v_mov_b32_dpp v170, v151 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB39BC: 7F5402FA FF016297
	v_cndmask_b32_e64 v151, -v151, v151, s1                    // 000000DB39C4: D5010097 20072F97
	s_addc_u32 s3, s9, s3                                      // 000000DB39CC: 82030309
	.long 0xd7000200                                           // 000000DB39D0: D7000200
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000DB39D4: 02020802
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB39D8: BF870191
	v_add_co_ci_u32_e64 v1, null, s3, 0, s2                    // 000000DB39DC: D5207C01 00090003
	v_dual_add_f32 v114, v114, v169 :: v_dual_add_f32 v151, v151, v170// 000000DB39E4: C9095372 72975597
	.long 0xd44a0002                                           // 000000DB39EC: D44A0002
	v_cndmask_b32_e32 v1, 0, v148, vcc_lo                      // 000000DB39F0: 02032880
	v_add_f32_e32 v155, v155, v166                             // 000000DB39F4: 07374D9B
	v_mov_b32_dpp v169, v130 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB39F8: 7F5202FA FF016282
	v_cndmask_b32_e64 v130, -v130, v130, s1                    // 000000DB3A00: D5010082 20070582
	v_mov_b32_dpp v168, v140 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3A08: 7F5002FA FF01628C
	v_cndmask_b32_e64 v140, -v140, v140, s1                    // 000000DB3A10: D501008C 2007198C
	.long 0xd44a0003                                           // 000000DB3A18: D44A0003
	v_cndmask_b32_e32 v1, 0, v149, vcc_lo                      // 000000DB3A1C: 02032A80
	s_clause 0x3                                               // 000000DB3A20: BF850003
	global_load_d16_b16 v18, v4, s[4:5] offset:1408            // 000000DB3A24: DC820580 12040004
	global_load_d16_b16 v34, v4, s[4:5] offset:1440            // 000000DB3A2C: DC8205A0 22040004
	global_load_d16_b16 v10, v4, s[4:5] offset:1472            // 000000DB3A34: DC8205C0 0A040004
	global_load_d16_b16 v26, v4, s[4:5] offset:1504            // 000000DB3A3C: DC8205E0 1A040004
	v_add_f32_e32 v130, v130, v169                             // 000000DB3A44: 07055382
	v_mov_b32_dpp v169, v151 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3A48: 7F5202FA FF016497
	v_cndmask_b32_e64 v151, -v151, v151, s2                    // 000000DB3A50: D5010097 200B2F97
	v_add_f32_e32 v140, v140, v168                             // 000000DB3A58: 0719518C
	v_sub_f32_e32 v74, v3, v74                                 // 000000DB3A5C: 08949503
	v_mov_b32_dpp v168, v130 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3A60: 7F5002FA FF016482
	v_cndmask_b32_e64 v130, -v130, v130, s2                    // 000000DB3A68: D5010082 200B0582
	v_add_f32_e32 v151, v151, v169                             // 000000DB3A70: 072F5397
	v_mov_b32_dpp v152, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3A74: 7F3002FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000DB3A7C: D501005A 2002B55A
	v_mov_b32_dpp v172, v74 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3A84: 7F5802FA FF01614A
	v_add_f32_e32 v130, v130, v168                             // 000000DB3A8C: 07055182
	v_mov_b32_dpp v168, v151 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3A90: 7F5002FA FF016897
	v_cndmask_b32_e64 v151, -v151, v151, s3                    // 000000DB3A98: D5010097 200F2F97
	v_cndmask_b32_e64 v173, -v74, v74, s0                      // 000000DB3AA0: D50100AD 2002954A
	v_add_f32_e32 v90, v90, v152                               // 000000DB3AA8: 06B5315A
	v_mov_b32_dpp v162, v82 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3AAC: 7F4402FA FF016252
	v_cndmask_b32_e64 v82, -v82, v82, s1                       // 000000DB3AB4: D5010052 2006A552
	v_add_f32_e32 v151, v151, v168                             // 000000DB3ABC: 072F5197
	v_add_f32_e32 v159, v173, v172                             // 000000DB3AC0: 073F59AD
	v_mov_b32_dpp v170, v141 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3AC4: 7F5402FA FF01648D
	v_cndmask_b32_e64 v141, -v141, v141, s2                    // 000000DB3ACC: D501008D 200B1B8D
	v_mov_b32_dpp v148, v114 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3AD4: 7F2802FA FF016272
	v_mul_f32_e32 v151, 0x3db504f3, v151                       // 000000DB3ADC: 112F2EFF 3DB504F3
	v_mov_b32_dpp v106, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB3AE4: 7ED402FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000DB3AEC: D501003A 2002753A
	v_cndmask_b32_e64 v114, -v114, v114, s1                    // 000000DB3AF4: D5010072 2006E572
	v_add_f32_e32 v82, v82, v162                               // 000000DB3AFC: 06A54552
	v_mov_b32_dpp v162, v159 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B00: 7F4402FA FF01629F
	v_cndmask_b32_e64 v159, -v159, v159, s1                    // 000000DB3B08: D501009F 20073F9F
	v_add_f32_e32 v106, v58, v106                              // 000000DB3B10: 06D4D53A
	s_clause 0x6                                               // 000000DB3B14: BF850006
	global_load_d16_b16 v50, v4, s[10:11] offset:64            // 000000DB3B18: DC820040 320A0004
	global_load_d16_b16 v66, v4, s[10:11] offset:96            // 000000DB3B20: DC820060 420A0004
	global_load_d16_b16 v58, v4, s[10:11] offset:128           // 000000DB3B28: DC820080 3A0A0004
	global_load_d16_b16 v74, v4, s[10:11] offset:160           // 000000DB3B30: DC8200A0 4A0A0004
	global_load_d16_b16 v42, v4, s[10:11] offset:192           // 000000DB3B38: DC8200C0 2A0A0004
	global_load_d16_b16 v147, v4, s[10:11] offset:224          // 000000DB3B40: DC8200E0 930A0004
	global_load_d16_b16 v152, v4, s[10:11]                     // 000000DB3B48: DC820000 980A0004
	v_dual_add_f32 v141, v141, v170 :: v_dual_add_f32 v114, v114, v148// 000000DB3B50: C909558D 8D732972
	v_mov_b32_dpp v164, v153 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B58: 7F4802FA FF016299
	v_mov_b32_dpp v160, v106 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B60: 7F4002FA FF01626A
	v_cndmask_b32_e64 v106, -v106, v106, s1                    // 000000DB3B68: D501006A 2006D56A
	v_cndmask_b32_e64 v153, -v153, v153, s1                    // 000000DB3B70: D5010099 20073399
	v_mov_b32_dpp v163, v122 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B78: 7F4602FA FF01627A
	v_cndmask_b32_e64 v122, -v122, v122, s1                    // 000000DB3B80: D501007A 2006F57A
	v_mov_b32_dpp v161, v90 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B88: 7F4202FA FF01625A
	v_add_f32_e32 v106, v106, v160                             // 000000DB3B90: 06D5416A
	v_mov_b32_dpp v160, v158 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3B94: 7F4002FA FF01629E
	v_cndmask_b32_e64 v158, -v158, v158, s1                    // 000000DB3B9C: D501009E 20073D9E
	v_dual_add_f32 v153, v153, v164 :: v_dual_add_f32 v122, v122, v163// 000000DB3BA4: C9094999 997B477A
	v_cndmask_b32_e64 v90, -v90, v90, s1                       // 000000DB3BAC: D501005A 2006B55A
	v_mov_b32_dpp v167, v140 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3BB4: 7F4E02FA FF01648C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB3BBC: BF870004
	v_add_f32_e32 v148, v158, v160                             // 000000DB3BC0: 0729419E
	v_add_f32_e32 v158, v159, v162                             // 000000DB3BC4: 073D459F
	v_mov_b32_dpp v159, v106 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3BC8: 7F3E02FA FF01646A
	v_cndmask_b32_e64 v106, -v106, v106, s2                    // 000000DB3BD0: D501006A 200AD56A
	v_mov_b32_dpp v163, v153 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3BD8: 7F4602FA FF016499
	v_mov_b32_dpp v171, v148 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3BE0: 7F5602FA FF016494
	v_cndmask_b32_e64 v148, -v148, v148, s2                    // 000000DB3BE8: D5010094 200B2994
	v_cndmask_b32_e64 v153, -v153, v153, s2                    // 000000DB3BF0: D5010099 200B3399
	v_add_f32_e32 v106, v106, v159                             // 000000DB3BF8: 06D53F6A
	v_mov_b32_dpp v159, v114 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3BFC: 7F3E02FA FF016472
	v_cndmask_b32_e64 v114, -v114, v114, s2                    // 000000DB3C04: D5010072 200AE572
	v_add_f32_e32 v148, v148, v171                             // 000000DB3C0C: 07295794
	v_mov_b32_dpp v162, v122 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3C10: 7F4402FA FF01647A
	v_cndmask_b32_e64 v122, -v122, v122, s2                    // 000000DB3C18: D501007A 200AF57A
	v_add_f32_e32 v153, v153, v163                             // 000000DB3C20: 07334799
	v_add_f32_e32 v114, v114, v159                             // 000000DB3C24: 06E53F72
	v_cndmask_b32_e64 v140, -v140, v140, s2                    // 000000DB3C28: D501008C 200B198C
	v_mov_b32_dpp v166, v156 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3C30: 7F4C02FA FF01649C
	v_add_f32_e32 v122, v122, v162                             // 000000DB3C38: 06F5457A
	v_mov_b32_dpp v162, v153 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3C3C: 7F4402FA FF016899
	v_mov_b32_dpp v171, v114 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3C44: 7F5602FA FF016872
	v_cndmask_b32_e64 v114, -v114, v114, s3                    // 000000DB3C4C: D5010072 200EE572
	v_cndmask_b32_e64 v153, -v153, v153, s3                    // 000000DB3C54: D5010099 200F3399
	v_cndmask_b32_e64 v156, -v156, v156, s2                    // 000000DB3C5C: D501009C 200B399C
	v_add_f32_e32 v140, v140, v167                             // 000000DB3C64: 07194F8C
	v_mov_b32_dpp v167, v130 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3C68: 7F4E02FA FF016882
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB3C70: BF870214
	v_dual_add_f32 v114, v114, v171 :: v_dual_add_f32 v153, v153, v162// 000000DB3C74: C9095772 72994599
	v_add_f32_e32 v156, v156, v166                             // 000000DB3C7C: 07394D9C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB3C80: BF870224
	v_mov_b32_dpp v166, v140 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3C84: 7F4C02FA FF01688C
	v_cndmask_b32_e64 v140, -v140, v140, s3                    // 000000DB3C8C: D501008C 200F198C
	v_mul_f32_e32 v114, 0x3db504f3, v114                       // 000000DB3C94: 10E4E4FF 3DB504F3
	v_cndmask_b32_e64 v130, -v130, v130, s3                    // 000000DB3C9C: D5010082 200F0582
	v_mov_b32_dpp v169, v141 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3CA4: 7F5202FA FF01688D
	v_cndmask_b32_e64 v141, -v141, v141, s3                    // 000000DB3CAC: D501008D 200F1B8D
	v_add_f32_e32 v140, v140, v166                             // 000000DB3CB4: 07194D8C
	v_mov_b32_dpp v170, v148 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3CB8: 7F5402FA FF016894
	v_add_f32_e32 v130, v130, v167                             // 000000DB3CC0: 07054F82
	v_cndmask_b32_e64 v148, -v148, v148, s3                    // 000000DB3CC4: D5010094 200F2994
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB3CCC: BF870224
	v_dual_add_f32 v141, v141, v169 :: v_dual_mul_f32 v140, 0x3db504f3, v140// 000000DB3CD0: C907538D 8D8D18FF 3DB504F3
	v_mov_b32_dpp v165, v154 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3CDC: 7F4A02FA FF01629A
	v_mul_f32_e32 v130, 0x3db504f3, v130                       // 000000DB3CE4: 110504FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000DB3CEC: BF8700B3
	v_dual_add_f32 v148, v148, v170 :: v_dual_mul_f32 v141, 0x3db504f3, v141// 000000DB3CF0: C9075594 948D1AFF 3DB504F3
	v_cndmask_b32_e64 v154, -v154, v154, s1                    // 000000DB3CFC: D501009A 2007359A
	.long 0xd7000702                                           // 000000DB3D04: D7000702
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 000000DB3D08: 02020804
	v_add_co_ci_u32_e64 v3, null, s5, 0, s7                    // 000000DB3D0C: D5207C03 001D0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB3D14: BF870243
	v_add_f32_e32 v154, v154, v165                             // 000000DB3D18: 07354B9A
	v_mov_b32_dpp v165, v155 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3D1C: 7F4A02FA FF01649B
	v_cndmask_b32_e64 v155, -v155, v155, s2                    // 000000DB3D24: D501009B 200B379B
	v_mul_f32_e32 v153, 0x3db504f3, v153                       // 000000DB3D2C: 113332FF 3DB504F3
	v_mov_b32_dpp v164, v154 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3D34: 7F4802FA FF01649A
	v_cndmask_b32_e64 v154, -v154, v154, s2                    // 000000DB3D3C: D501009A 200B359A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB3D44: BF870234
	v_add_f32_e32 v155, v155, v165                             // 000000DB3D48: 07374B9B
	v_mov_b32_dpp v165, v156 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3D4C: 7F4A02FA FF01689C
	v_cndmask_b32_e64 v156, -v156, v156, s3                    // 000000DB3D54: D501009C 200F399C
	v_add_f32_e32 v154, v154, v164                             // 000000DB3D5C: 0735499A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB3D60: BF870224
	v_mov_b32_dpp v164, v155 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3D64: 7F4802FA FF01689B
	v_cndmask_b32_e64 v155, -v155, v155, s3                    // 000000DB3D6C: D501009B 200F379B
	v_add_f32_e32 v156, v156, v165                             // 000000DB3D74: 07394B9C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB3D78: BF870224
	v_mov_b32_dpp v163, v154 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3D7C: 7F4602FA FF01689A
	v_cndmask_b32_e64 v154, -v154, v154, s3                    // 000000DB3D84: D501009A 200F359A
	v_add_f32_e32 v155, v155, v164                             // 000000DB3D8C: 0737499B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB3D90: BF870194
	v_mul_f32_e32 v156, 0x3db504f3, v156                       // 000000DB3D94: 113938FF 3DB504F3
	v_add_f32_e32 v154, v154, v163                             // 000000DB3D9C: 0735479A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB3DA0: BF870001
	v_dual_mul_f32 v155, 0x3db504f3, v155 :: v_dual_mul_f32 v154, 0x3db504f3, v154// 000000DB3DA4: C8C736FF 9B9B34FF 3DB504F3
	s_waitcnt vmcnt(23)                                        // 000000DB3DB0: BF895FF7
	v_fma_mix_f32 v7, v7, v140, neg(0) op_sel_hi:[1,0,0]       // 000000DB3DB4: CC200007 8A031907
	v_mul_f32_e32 v140, 0x3db504f3, v148                       // 000000DB3DBC: 111928FF 3DB504F3
	s_waitcnt vmcnt(20)                                        // 000000DB3DC4: BF8953F7
	v_fma_mix_f32 v8, v8, v130, neg(0) op_sel_hi:[1,0,0]       // 000000DB3DC8: CC200008 8A030508
	s_waitcnt vmcnt(17)                                        // 000000DB3DD0: BF8947F7
	v_fma_mix_f32 v130, v142, v141, neg(0) op_sel_hi:[1,0,0]   // 000000DB3DD4: CC200082 8A031B8E
	s_waitcnt vmcnt(15)                                        // 000000DB3DDC: BF893FF7
	v_fma_mix_f32 v114, v144, v114, neg(0) op_sel_hi:[1,0,0]   // 000000DB3DE0: CC200072 8A02E590
	v_add_f32_e32 v90, v90, v161                               // 000000DB3DE8: 06B5435A
	v_mov_b32_dpp v161, v98 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB3DEC: 7F4202FA FF016262
	v_cndmask_b32_e64 v98, -v98, v98, s1                       // 000000DB3DF4: D5010062 2006C562
	v_mul_f32_e32 v142, 0xbfb8aa3b, v130                       // 000000DB3DFC: 111D04FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB3E04: BF870224
	v_mov_b32_dpp v160, v90 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3E08: 7F4002FA FF01645A
	v_cndmask_b32_e64 v90, -v90, v90, s2                       // 000000DB3E10: D501005A 200AB55A
	v_add_f32_e32 v98, v98, v161                               // 000000DB3E18: 06C54362
	v_mov_b32_dpp v161, v82 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3E1C: 7F4202FA FF016452
	v_cndmask_b32_e64 v82, -v82, v82, s2                       // 000000DB3E24: D5010052 200AA552
	v_exp_f32_e32 v142, v142                                   // 000000DB3E2C: 7F1C4B8E
	v_add_f32_e32 v90, v90, v160                               // 000000DB3E30: 06B5415A
	v_mov_b32_dpp v149, v98 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3E34: 7F2A02FA FF016462
	v_cndmask_b32_e64 v98, -v98, v98, s2                       // 000000DB3E3C: D5010062 200AC562
	v_mov_b32_dpp v160, v158 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB3E44: 7F4002FA FF01649E
	v_cndmask_b32_e64 v158, -v158, v158, s2                    // 000000DB3E4C: D501009E 200B3D9E
	v_mov_b32_dpp v159, v90 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3E54: 7F3E02FA FF01685A
	v_cndmask_b32_e64 v90, -v90, v90, s3                       // 000000DB3E5C: D501005A 200EB55A
	v_add_f32_e32 v98, v98, v149                               // 000000DB3E64: 06C52B62
	v_mov_b32_dpp v149, v106 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3E68: 7F2A02FA FF01686A
	v_cndmask_b32_e64 v106, -v106, v106, s3                    // 000000DB3E70: D501006A 200ED56A
	v_add_f32_e32 v82, v82, v161                               // 000000DB3E78: 06A54352
	v_add_f32_e32 v158, v158, v160                             // 000000DB3E7C: 073D419E
	v_add_f32_e32 v90, v90, v159                               // 000000DB3E80: 06B53F5A
	v_mov_b32_dpp v161, v122 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3E84: 7F4202FA FF01687A
	v_add_f32_e32 v106, v106, v149                             // 000000DB3E8C: 06D52B6A
	v_mov_b32_dpp v160, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3E90: 7F4002FA FF016852
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000DB3E98: D5010052 200EA552
	v_mov_b32_dpp v149, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3EA0: 7F2A02FA FF016862
	v_mov_b32_dpp v159, v158 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB3EA8: 7F3E02FA FF01689E
	v_mul_f32_e32 v106, 0x3db504f3, v106                       // 000000DB3EB0: 10D4D4FF 3DB504F3
	v_cndmask_b32_e64 v158, -v158, v158, s3                    // 000000DB3EB8: D501009E 200F3D9E
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000DB3EC0: D5010062 200EC562
	v_mul_f32_e32 v90, 0x3db504f3, v90                         // 000000DB3EC8: 10B4B4FF 3DB504F3
	v_add_f32_e32 v82, v82, v160                               // 000000DB3ED0: 06A54152
	v_fma_mix_f32 v5, v5, v106, neg(0) op_sel_hi:[1,0,0]       // 000000DB3ED4: CC200005 8A02D505
	v_mul_f32_e32 v106, 0xbfb8aa3b, v7                         // 000000DB3EDC: 10D40EFF BFB8AA3B
	v_add_f32_e32 v98, v98, v149                               // 000000DB3EE4: 06C52B62
	v_add_f32_e32 v149, v158, v159                             // 000000DB3EE8: 072B3F9E
	v_fma_mix_f32 v9, v9, v90, neg(0) op_sel_hi:[1,0,0]        // 000000DB3EEC: CC200009 8A02B509
	v_fma_mix_f32 v90, v138, v151, neg(0) op_sel_hi:[1,0,0]    // 000000DB3EF4: CC20005A 8A032F8A
	v_exp_f32_e32 v106, v106                                   // 000000DB3EFC: 7ED44B6A
	v_mul_f32_e32 v138, 0xbfb8aa3b, v8                         // 000000DB3F00: 111410FF BFB8AA3B
	v_mul_f32_e32 v82, 0x3db504f3, v82                         // 000000DB3F08: 10A4A4FF 3DB504F3
	v_mul_f32_e32 v148, 0x3db504f3, v149                       // 000000DB3F10: 11292AFF 3DB504F3
	v_mul_f32_e32 v141, 0xbfb8aa3b, v90                        // 000000DB3F18: 111AB4FF BFB8AA3B
	v_cndmask_b32_e64 v122, -v122, v122, s3                    // 000000DB3F20: D501007A 200EF57A
	v_exp_f32_e32 v138, v138                                   // 000000DB3F28: 7F144B8A
	v_fma_mix_f32 v82, v139, v82, neg(0) op_sel_hi:[1,0,0]     // 000000DB3F2C: CC200052 8A02A58B
	v_fma_mix_f32 v139, v143, v140, neg(0) op_sel_hi:[1,0,0]   // 000000DB3F34: CC20008B 8A03198F
	s_waitcnt vmcnt(13)                                        // 000000DB3F3C: BF8937F7
	v_fma_mix_f32 v140, v146, v148, neg(0) op_sel_hi:[1,0,0]   // 000000DB3F40: CC20008C 8A032992
	v_add_f32_e32 v106, 1.0, v106                              // 000000DB3F48: 06D4D4F2
	v_exp_f32_e32 v141, v141                                   // 000000DB3F4C: 7F1A4B8D
	v_add_f32_e32 v122, v122, v161                             // 000000DB3F50: 06F5437A
	v_mul_f32_e32 v98, 0x3db504f3, v98                         // 000000DB3F54: 10C4C4FF 3DB504F3
	v_mul_f32_e32 v144, 0xbfb8aa3b, v139                       // 000000DB3F5C: 112116FF BFB8AA3B
	v_div_scale_f32 v146, null, v106, v106, v7                 // 000000DB3F64: D6FC7C92 041ED56A
	v_add_f32_e32 v138, 1.0, v138                              // 000000DB3F6C: 071514F2
	v_mul_f32_e32 v122, 0x3db504f3, v122                       // 000000DB3F70: 10F4F4FF 3DB504F3
	v_div_scale_f32 v161, vcc_lo, v7, v106, v7                 // 000000DB3F78: D6FC6AA1 041ED507
	v_fma_mix_f32 v98, v145, v98, neg(0) op_sel_hi:[1,0,0]     // 000000DB3F80: CC200062 8A02C591
	v_rcp_f32_e32 v149, v146                                   // 000000DB3F88: 7F2A5592
	v_div_scale_f32 v151, null, v138, v138, v8                 // 000000DB3F8C: D6FC7C97 0423158A
	v_add_f32_e32 v141, 1.0, v141                              // 000000DB3F94: 071B1AF2
	s_waitcnt vmcnt(12)                                        // 000000DB3F98: BF8933F7
	v_fma_mix_f32 v122, v150, v122, neg(0) op_sel_hi:[1,0,0]   // 000000DB3F9C: CC20007A 8A02F596
	v_exp_f32_e32 v144, v144                                   // 000000DB3FA4: 7F204B90
	v_add_f32_e32 v142, 1.0, v142                              // 000000DB3FA8: 071D1CF2
	v_rcp_f32_e32 v150, v151                                   // 000000DB3FAC: 7F2C5597
	v_div_scale_f32 v158, null, v141, v141, v90                // 000000DB3FB0: D6FC7C9E 056B1B8D
	v_div_scale_f32 v162, s4, v8, v138, v8                     // 000000DB3FB8: D6FC04A2 04231508
	v_mul_f32_e32 v143, 0xbfb8aa3b, v114                       // 000000DB3FC0: 111EE4FF BFB8AA3B
	v_fma_f32 v159, -v146, v149, 1.0                           // 000000DB3FC8: D613009F 23CB2B92
	v_mul_f32_e32 v148, 0xbfb8aa3b, v98                        // 000000DB3FD0: 1128C4FF BFB8AA3B
	v_rcp_f32_e32 v160, v158                                   // 000000DB3FD8: 7F40559E
	v_div_scale_f32 v164, s5, v90, v141, v90                   // 000000DB3FDC: D6FC05A4 056B1B5A
	v_div_scale_f32 v165, null, v142, v142, v130               // 000000DB3FE4: D6FC7CA5 060B1D8E
	v_fmac_f32_e32 v149, v159, v149                            // 000000DB3FEC: 572B2B9F
	v_fma_f32 v159, -v151, v150, 1.0                           // 000000DB3FF0: D613009F 23CB2D97
	v_mul_f32_e32 v145, 0xbfb8aa3b, v140                       // 000000DB3FF8: 112318FF BFB8AA3B
	v_exp_f32_e32 v143, v143                                   // 000000DB4000: 7F1E4B8F
	v_exp_f32_e32 v148, v148                                   // 000000DB4004: 7F284B94
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000DB4008: BF870392
	v_dual_mul_f32 v163, v161, v149 :: v_dual_fmac_f32 v150, v159, v150// 000000DB400C: C8C12BA1 A3972D9F
	v_fma_f32 v159, -v158, v160, 1.0                           // 000000DB4014: D613009F 23CB419E
	v_add_f32_e32 v144, 1.0, v144                              // 000000DB401C: 072120F2
	v_exp_f32_e32 v145, v145                                   // 000000DB4020: 7F224B91
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB4024: BF870003
	v_fma_f32 v166, -v146, v163, v161                          // 000000DB4028: D61300A6 26874792
	v_mul_f32_e32 v168, v162, v150                             // 000000DB4030: 11512DA2
	v_fmac_f32_e32 v160, v159, v160                            // 000000DB4034: 5741419F
	v_div_scale_f32 v159, null, v144, v144, v139               // 000000DB4038: D6FC7C9F 062F2190
	v_add_f32_e32 v143, 1.0, v143                              // 000000DB4040: 071F1EF2
	v_fmac_f32_e32 v163, v166, v149                            // 000000DB4044: 57472BA6
	v_fma_f32 v169, -v151, v168, v162                          // 000000DB4048: D61300A9 268B5197
	v_mul_f32_e32 v170, v164, v160                             // 000000DB4050: 115541A4
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB4054: BF870215
	v_dual_add_f32 v148, 1.0, v148 :: v_dual_add_f32 v145, 1.0, v145// 000000DB4058: C90928F2 949122F2
	v_fma_f32 v146, -v146, v163, v161                          // 000000DB4060: D6130092 26874792
	v_rcp_f32_e32 v161, v165                                   // 000000DB4068: 7F4255A5
	v_fmac_f32_e32 v168, v169, v150                            // 000000DB406C: 57512DA9
	v_fma_f32 v169, -v158, v170, v164                          // 000000DB4070: D61300A9 2693559E
	v_div_scale_f32 v167, s6, v130, v142, v130                 // 000000DB4078: D6FC06A7 060B1D82
	v_div_fmas_f32 v146, v146, v149, v163                      // 000000DB4080: D6370092 068F2B92
	v_rcp_f32_e32 v163, v159                                   // 000000DB4088: 7F46559F
	v_fma_f32 v151, -v151, v168, v162                          // 000000DB408C: D6130097 268B5197
	v_fmac_f32_e32 v170, v169, v160                            // 000000DB4094: 575541A9
	v_div_scale_f32 v166, null, v143, v143, v114               // 000000DB4098: D6FC7CA6 05CB1F8F
	v_div_scale_f32 v171, null, v148, v148, v98                // 000000DB40A0: D6FC7CAB 058B2994
	v_fma_f32 v169, -v165, v161, 1.0                           // 000000DB40A8: D61300A9 23CB43A5
	s_mov_b32 vcc_lo, s4                                       // 000000DB40B0: BEEA0004
	v_fma_f32 v158, -v158, v170, v164                          // 000000DB40B4: D613009E 2693559E
	v_div_fmas_f32 v150, v151, v150, v168                      // 000000DB40BC: D6370096 06A32D97
	s_mov_b32 vcc_lo, s5                                       // 000000DB40C4: BEEA0005
	v_fmac_f32_e32 v161, v169, v161                            // 000000DB40C8: 574343A9
	v_div_scale_f32 v149, null, v145, v145, v140               // 000000DB40CC: D6FC7C95 06332391
	v_rcp_f32_e32 v162, v166                                   // 000000DB40D4: 7F4455A6
	v_rcp_f32_e32 v168, v171                                   // 000000DB40D8: 7F5055AB
	v_fma_f32 v169, -v159, v163, 1.0                           // 000000DB40DC: D61300A9 23CB479F
	v_div_fmas_f32 v158, v158, v160, v170                      // 000000DB40E4: D637009E 06AB419E
	v_mul_f32_e32 v170, v167, v161                             // 000000DB40EC: 115543A7
	v_rcp_f32_e32 v164, v149                                   // 000000DB40F0: 7F485595
	v_div_scale_f32 v151, s4, v139, v144, v139                 // 000000DB40F4: D6FC0497 062F218B
	v_fmac_f32_e32 v163, v169, v163                            // 000000DB40FC: 574747A9
	v_div_fixup_f32 v8, v150, v138, v8                         // 000000DB4100: D6270008 04231596
	v_fma_f32 v169, -v165, v170, v167                          // 000000DB4108: D61300A9 269F55A5
	v_fma_f32 v160, -v166, v162, 1.0                           // 000000DB4110: D61300A0 23CB45A6
	v_fma_f32 v150, -v171, v168, 1.0                           // 000000DB4118: D6130096 23CB51AB
	v_div_scale_f32 v138, s5, v114, v143, v114                 // 000000DB4120: D6FC058A 05CB1F72
	v_div_fixup_f32 v7, v146, v106, v7                         // 000000DB4128: D6270007 041ED592
	v_fmac_f32_e32 v170, v169, v161                            // 000000DB4130: 575543A9
	v_fmac_f32_e32 v162, v160, v162                            // 000000DB4134: 574545A0
	v_fmac_f32_e32 v168, v150, v168                            // 000000DB4138: 57515196
	v_fma_f32 v150, -v149, v164, 1.0                           // 000000DB413C: D6130096 23CB4995
	v_div_fixup_f32 v90, v158, v141, v90                       // 000000DB4144: D627005A 056B1B9E
	v_dual_mul_f32 v8, v9, v8 :: v_dual_mul_f32 v9, v151, v163 // 000000DB414C: C8C61109 08094797
	v_fma_f32 v106, -v165, v170, v167                          // 000000DB4154: D613006A 269F55A5
	v_div_scale_f32 v160, s7, v98, v148, v98                   // 000000DB415C: D6FC07A0 058B2962
	s_mov_b32 vcc_lo, s6                                       // 000000DB4164: BEEA0006
	v_dual_mul_f32 v7, v5, v7 :: v_dual_mul_f32 v82, v82, v90  // 000000DB4168: C8C60F05 0752B552
	v_div_fmas_f32 v5, v106, v161, v170                        // 000000DB4170: D6370005 06AB436A
	v_fma_f32 v90, -v159, v9, v151                             // 000000DB4178: D613005A 265E139F
	v_mul_f32_e32 v106, v138, v162                             // 000000DB4180: 10D5458A
	v_fmac_f32_e32 v164, v150, v164                            // 000000DB4184: 57494996
	v_div_scale_f32 v146, s6, v140, v145, v140                 // 000000DB4188: D6FC0692 0633238C
	v_mul_f32_e32 v141, v160, v168                             // 000000DB4190: 111B51A0
	v_div_fixup_f32 v5, v5, v142, v130                         // 000000DB4194: D6270005 060B1D05
	v_fmac_f32_e32 v9, v90, v163                               // 000000DB419C: 5613475A
	v_fma_f32 v90, -v166, v106, v138                           // 000000DB41A0: D613005A 262AD5A6
	v_mul_f32_e32 v142, v146, v164                             // 000000DB41A8: 111D4992
	v_fma_f32 v130, -v171, v141, v160                          // 000000DB41AC: D6130082 26831BAB
	v_mul_f32_e32 v5, v122, v5                                 // 000000DB41B4: 100A0B7A
	v_fma_f32 v122, -v159, v9, v151                            // 000000DB41B8: D613007A 265E139F
	v_fmac_f32_e32 v106, v90, v162                             // 000000DB41C0: 56D5455A
	v_fma_f32 v90, -v149, v142, v146                           // 000000DB41C4: D613005A 264B1D95
	v_fmac_f32_e32 v141, v130, v168                            // 000000DB41CC: 571B5182
	s_mov_b32 vcc_lo, s4                                       // 000000DB41D0: BEEA0004
	s_waitcnt vmcnt(9)                                         // 000000DB41D4: BF8927F7
	v_fma_mix_f32 v34, v34, v154, neg(0) op_sel_hi:[1,0,0]     // 000000DB41D8: CC200022 8A033522
	v_div_fmas_f32 v9, v122, v163, v9                          // 000000DB41E0: D6370009 0427477A
	v_fma_f32 v122, -v166, v106, v138                          // 000000DB41E8: D613007A 262AD5A6
	v_fmac_f32_e32 v142, v90, v164                             // 000000DB41F0: 571D495A
	v_fma_f32 v90, -v171, v141, v160                           // 000000DB41F4: D613005A 26831BAB
	s_mov_b32 vcc_lo, s5                                       // 000000DB41FC: BEEA0005
	s_waitcnt vmcnt(7)                                         // 000000DB4200: BF891FF7
	v_fma_mix_f32 v26, v26, v156, neg(0) op_sel_hi:[1,0,0]     // 000000DB4204: CC20001A 8A03391A
	v_div_fmas_f32 v106, v122, v162, v106                      // 000000DB420C: D637006A 05AB457A
	v_fma_f32 v122, -v149, v142, v146                          // 000000DB4214: D613007A 264B1D95
	s_mov_b32 vcc_lo, s7                                       // 000000DB421C: BEEA0007
	v_fma_mix_f32 v18, v18, v153, neg(0) op_sel_hi:[1,0,0]     // 000000DB4220: CC200012 8A033312
	v_div_fmas_f32 v90, v90, v168, v141                        // 000000DB4228: D637005A 0637515A
	s_mov_b32 vcc_lo, s6                                       // 000000DB4230: BEEA0006
	v_div_fixup_f32 v106, v106, v143, v114                     // 000000DB4234: D627006A 05CB1F6A
	v_div_fmas_f32 v122, v122, v164, v142                      // 000000DB423C: D637007A 063B497A
	v_div_fixup_f32 v9, v9, v144, v139                         // 000000DB4244: D6270009 062F2109
	v_fma_mix_f32 v10, v10, v155, neg(0) op_sel_hi:[1,0,0]     // 000000DB424C: CC20000A 8A03370A
	v_div_fixup_f32 v90, v90, v148, v98                        // 000000DB4254: D627005A 058B295A
	v_mul_f32_e32 v34, v34, v106                               // 000000DB425C: 1044D522
	v_div_fixup_f32 v114, v122, v145, v140                     // 000000DB4260: D6270072 0633237A
	v_fma_mix_f32 v8, v157, v8, neg(0) op_sel_hi:[1,0,0]       // 000000DB4268: CC200008 8A02119D
	s_waitcnt vmcnt(5)                                         // 000000DB4270: BF8917F7
	v_fma_mix_f32 v66, v66, v5, neg(0) op_sel_hi:[1,0,0]       // 000000DB4274: CC200042 8A020B42
	v_mul_f32_e32 v9, v18, v9                                  // 000000DB427C: 10121312
	s_waitcnt vmcnt(3)                                         // 000000DB4280: BF890FF7
	v_fma_mix_f32 v18, v74, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DB4284: CC200012 8A02454A
	v_mul_f32_e32 v26, v26, v114                               // 000000DB428C: 1034E51A
	v_mul_f32_e32 v10, v10, v90                                // 000000DB4290: 1014B50A
	s_waitcnt vmcnt(0)                                         // 000000DB4294: BF8903F7
	v_fma_mix_f32 v34, v7, v152, v8 op_sel_hi:[0,1,0]          // 000000DB4298: CC200022 14233107
	v_fma_mix_f32 v74, v82, v50, v66 op_sel_hi:[0,1,0]         // 000000DB42A0: CC20004A 150A6552
	v_fma_mix_f32 v90, v9, v58, v18 op_sel_hi:[0,1,0]          // 000000DB42A8: CC20005A 144A7509
	v_fma_mix_f32 v26, v147, v26, neg(0) op_sel_hi:[1,0,0]     // 000000DB42B0: CC20001A 8A023593
	v_fma_mix_f32 v7, v7, v152, -v8 op_sel_hi:[0,1,0]          // 000000DB42B8: CC200007 94233107
	v_fma_mix_f32 v8, v82, v50, -v66 op_sel_hi:[0,1,0]         // 000000DB42C0: CC200008 950A6552
	v_fma_mix_f32 v9, v9, v58, -v18 op_sel_hi:[0,1,0]          // 000000DB42C8: CC200009 944A7509
	v_add_f32_e32 v18, v34, v74                                // 000000DB42D0: 06249522
	v_fma_mix_f32 v98, v10, v42, v26 op_sel_hi:[0,1,0]         // 000000DB42D4: CC200062 146A550A
	v_fma_mix_f32 v10, v10, v42, -v26 op_sel_hi:[0,1,0]        // 000000DB42DC: CC20000A 946A550A
	v_sub_f32_e32 v26, v34, v74                                // 000000DB42E4: 08349522
	v_add_f32_e32 v34, v7, v8                                  // 000000DB42E8: 06441107
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB42EC: BF870004
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v50, v90, v98  // 000000DB42F0: C9481107 0732C55A
	v_sub_f32_e32 v42, v90, v98                                // 000000DB42F8: 0854C55A
	v_add_f32_e32 v58, v9, v10                                 // 000000DB42FC: 06741509
	v_sub_f32_e32 v9, v9, v10                                  // 000000DB4300: 08121509
	.long 0xd7000404                                           // 000000DB4304: D7000404
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 000000DB4308: 0202080A
	v_add_f32_e32 v8, v18, v50                                 // 000000DB430C: 06106512
	v_sub_f32_e32 v10, v18, v50                                // 000000DB4310: 08146512
	v_add_f32_e32 v50, v34, v58                                // 000000DB4314: 06647522
	v_sub_f32_e32 v34, v34, v58                                // 000000DB4318: 08447522
	v_add_f32_e32 v58, v26, v42                                // 000000DB431C: 0674551A
	v_mov_b32_dpp v18, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4320: 7E2402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB4328: D5010008 20021108
	v_sub_f32_e32 v42, v26, v42                                // 000000DB4330: 0854551A
	v_cndmask_b32_e64 v26, -v50, v50, s0                       // 000000DB4334: D501001A 20026532
	v_mov_b32_dpp v82, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB433C: 7EA402FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DB4344: D501000A 2002150A
	v_add_f32_e32 v8, v8, v18                                  // 000000DB434C: 06102508
	v_mov_b32_dpp v18, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4350: 7E2402FA FF016132
	v_mov_b32_dpp v50, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4358: 7E6402FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000DB4360: D501003A 2002753A
	v_mov_b32_dpp v90, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4368: 7EB402FA FF016122
	v_mov_b32_dpp v66, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4370: 7E8402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB4378: D5010008 20061108
	v_add_f32_e32 v18, v26, v18                                // 000000DB4380: 0624251A
	v_add_f32_e32 v50, v58, v50                                // 000000DB4384: 0664653A
	v_add_f32_e32 v26, v7, v9                                  // 000000DB4388: 06341307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB438C: BF870214
	v_dual_sub_f32 v58, v7, v9 :: v_dual_add_f32 v7, v8, v66   // 000000DB4390: C9481307 3A068508
	v_mov_b32_dpp v8, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4398: 7E1002FA FF016212
	v_cndmask_b32_e64 v9, -v18, v18, s1                        // 000000DB43A0: D5010009 20062512
	v_mov_b32_dpp v18, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB43A8: 7E2402FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000DB43B0: D5010032 20066532
	v_mov_b32_dpp v66, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB43B8: 7E8402FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB43C0: D501001A 2002351A
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000DB43C8: D5010022 20024522
	v_mov_b32_dpp v98, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB43D0: 7EC402FA FF01612A
	v_add_f32_e32 v18, v50, v18                                // 000000DB43D8: 06242532
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000DB43DC: D501002A 2002552A
	v_add_f32_e32 v26, v26, v66                                // 000000DB43E4: 0634851A
	v_mov_b32_dpp v106, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB43E8: 7ED402FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000DB43F0: D501003A 2002753A
	v_mov_b32_dpp v66, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB43F8: 7E8402FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB4400: D5010012 200A2512
	v_add_f32_e32 v8, v9, v8                                   // 000000DB4408: 06101109
	v_add_f32_e32 v34, v34, v90                                // 000000DB440C: 0644B522
	v_add_f32_e32 v42, v42, v98                                // 000000DB4410: 0654C52A
	v_add_f32_e32 v58, v58, v106                               // 000000DB4414: 0674D53A
	v_add_f32_e32 v18, v18, v66                                // 000000DB4418: 06248512
	v_add_f32_e32 v66, v10, v82                                // 000000DB441C: 0684A50A
	v_mov_b32_dpp v9, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4420: 7E1202FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 000000DB4428: D5010007 200A0F07
	v_mov_b32_dpp v50, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4430: 7E6402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB4438: D5010008 200A1108
	v_mov_b32_dpp v82, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4440: 7EA402FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000DB4448: D5010042 20068542
	v_mov_b32_dpp v74, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4450: 7E9402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB4458: D501001A 2006351A
	v_mov_b32_dpp v90, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4460: 7EB402FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DB4468: D501002A 2006552A
	v_add_f32_e32 v66, v66, v82                                // 000000DB4470: 0684A542
	v_mov_b32_dpp v82, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4474: 7EA402FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB447C: D5010022 20064522
	v_mov_b32_dpp v98, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4484: 7EC402FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000DB448C: D501003A 2006753A
	v_add_f32_e32 v7, v7, v9                                   // 000000DB4494: 060E1307
	v_add_f32_e32 v9, v8, v50                                  // 000000DB4498: 06126508
	v_add_f32_e32 v50, v26, v74                                // 000000DB449C: 0664951A
	v_add_f32_e32 v34, v34, v82                                // 000000DB44A0: 0644A522
	v_add_f32_e32 v42, v42, v90                                // 000000DB44A4: 0654B52A
	v_add_f32_e32 v58, v58, v98                                // 000000DB44A8: 0674C53A
	v_mov_b32_dpp v82, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB44AC: 7EA402FA FF016442
	v_mov_b32_dpp v74, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB44B4: 7E9402FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000DB44BC: D5010032 200A6532
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000DB44C4: D5010042 200A8542
	v_mov_b32_dpp v90, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB44CC: 7EB402FA FF016422
	v_cndmask_b32_e64 v98, -v34, v34, s2                       // 000000DB44D4: D5010062 200A4522
	v_mov_b32_dpp v106, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB44DC: 7ED402FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DB44E4: D501002A 200A552A
	v_mov_b32_dpp v114, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB44EC: 7EE402FA FF01643A
	v_cndmask_b32_e64 v122, -v58, v58, s2                      // 000000DB44F4: D501007A 200A753A
	v_add_f32_e32 v34, v50, v74                                // 000000DB44FC: 06449532
	v_add_f32_e32 v58, v66, v82                                // 000000DB4500: 0674A542
	v_add_f32_e32 v66, v98, v90                                // 000000DB4504: 0684B562
	v_add_f32_e32 v82, v42, v106                               // 000000DB4508: 06A4D52A
	v_add_f32_e32 v98, v122, v114                              // 000000DB450C: 06C4E57A
	v_add_co_ci_u32_e64 v5, null, s11, 0, s4                   // 000000DB4510: D5207C05 0011000B
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4518: 7E1002FA FF016807
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4520: 7E1402FA FF016809
	v_mov_b32_dpp v26, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4528: 7E3402FA FF016812
	v_mov_b32_dpp v42, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4530: 7E5402FA FF016822
	v_mov_b32_dpp v50, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4538: 7E6402FA FF01683A
	v_mov_b32_dpp v74, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4540: 7E9402FA FF016842
	v_mov_b32_dpp v90, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4548: 7EB402FA FF016852
	v_mov_b32_dpp v106, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4550: 7ED402FA FF016862
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB4558: BE8500FF 3DB504F3
	s_mov_b32 s4, exec_lo                                      // 000000DB4560: BE84007E
	.long 0xd4c4007e                                           // 000000DB4564: D4C4007E
	v_cndmask_b32_e32 v1, s23, v6, vcc_lo                      // 000000DB4568: 02020C17
	s_cbranch_execz 60                                         // 000000DB456C: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x1a60>
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000DB4570: D5010062 200EC562
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB4578: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB4580: D5010009 200E1309
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000DB4588: D5010012 200E2512
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DB4590: D5010022 200E4522
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000DB4598: D501003A 200E753A
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000DB45A0: D5010052 200EA552
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000DB45A8: D5010042 200E8542
	v_dual_add_f32 v98, v98, v106 :: v_dual_add_f32 v7, v7, v8 // 000000DB45B0: C908D562 62061107
	v_add_f32_e32 v8, v9, v10                                  // 000000DB45B8: 06101509
	v_add_f32_e32 v9, v18, v26                                 // 000000DB45BC: 06123512
	v_mad_i64_i32 v[138:139], null, 0x500, v6, v[0:1]          // 000000DB45C0: D6FF7C8A 04020CFF 00000500
	v_add_f32_e32 v10, v34, v42                                // 000000DB45CC: 06145522
	v_add_f32_e32 v50, v58, v50                                // 000000DB45D0: 0664653A
	v_add_f32_e32 v82, v82, v90                                // 000000DB45D4: 06A4B552
	v_add_f32_e32 v66, v66, v74                                // 000000DB45D8: 06849542
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB45DC: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB45E4: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB45EC: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000DB45F4: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v50, s5, 0                             // 000000DB45FC: CC210009 02000B32
	v_fma_mixhi_f16 v9, v66, s5, 0                             // 000000DB4604: CC220009 02000B42
	v_fma_mixlo_f16 v10, v82, s5, 0                            // 000000DB460C: CC21000A 02000B52
	v_fma_mixhi_f16 v10, v98, s5, 0                            // 000000DB4614: CC22000A 02000B62
	s_clause 0x7                                               // 000000DB461C: BF850007
	global_store_b16 v[138:139], v7, off                       // 000000DB4620: DC660000 007C078A
	global_store_d16_hi_b16 v[138:139], v7, off offset:32      // 000000DB4628: DC960020 007C078A
	global_store_b16 v[138:139], v8, off offset:64             // 000000DB4630: DC660040 007C088A
	global_store_d16_hi_b16 v[138:139], v8, off offset:96      // 000000DB4638: DC960060 007C088A
	global_store_b16 v[138:139], v9, off offset:128            // 000000DB4640: DC660080 007C098A
	global_store_d16_hi_b16 v[138:139], v9, off offset:160     // 000000DB4648: DC9600A0 007C098A
	global_store_b16 v[138:139], v10, off offset:192           // 000000DB4650: DC6600C0 007C0A8A
	global_store_d16_hi_b16 v[138:139], v10, off offset:224    // 000000DB4658: DC9600E0 007C0A8A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB4660: 8C7E047E
	s_clause 0xb                                               // 000000DB4664: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB4668: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB4670: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB4678: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB4680: DC820020 097C0002
	global_load_d16_b16 v18, v[2:3], off offset:64             // 000000DB4688: DC820040 127C0002
	global_load_d16_b16 v26, v[2:3], off offset:96             // 000000DB4690: DC820060 1A7C0002
	global_load_d16_b16 v42, v[2:3], off offset:128            // 000000DB4698: DC820080 2A7C0002
	global_load_d16_b16 v50, v[2:3], off offset:160            // 000000DB46A0: DC8200A0 327C0002
	global_load_d16_b16 v58, v[2:3], off offset:192            // 000000DB46A8: DC8200C0 3A7C0002
	global_load_d16_b16 v66, v[2:3], off offset:224            // 000000DB46B0: DC8200E0 427C0002
	global_load_d16_b16 v74, v[2:3], off offset:1344           // 000000DB46B8: DC820540 4A7C0002
	global_load_d16_b16 v82, v[2:3], off offset:1376           // 000000DB46C0: DC820560 527C0002
	v_add_f32_e32 v90, v131, v123                              // 000000DB46C8: 06B4F783
	v_add_f32_e32 v106, v115, v107                             // 000000DB46CC: 06D4D773
	v_sub_f32_e32 v98, v131, v123                              // 000000DB46D0: 08C4F783
	v_sub_f32_e32 v107, v115, v107                             // 000000DB46D4: 08D6D773
	v_add_f32_e32 v114, v99, v91                               // 000000DB46D8: 06E4B763
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB46DC: BF870224
	v_dual_sub_f32 v122, v19, v11 :: v_dual_add_f32 v123, v90, v106// 000000DB46E0: C9481713 7A7AD55A
	v_sub_f32_e32 v90, v90, v106                               // 000000DB46E8: 08B4D55A
	v_add_f32_e32 v106, v98, v107                              // 000000DB46EC: 06D4D762
	v_sub_f32_e32 v91, v99, v91                                // 000000DB46F0: 08B6B763
	v_add_f32_e32 v99, v83, v75                                // 000000DB46F4: 06C69753
	v_sub_f32_e32 v98, v98, v107                               // 000000DB46F8: 08C4D762
	v_sub_f32_e32 v75, v83, v75                                // 000000DB46FC: 08969753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4700: BF8701A3
	v_add_f32_e32 v107, v114, v99                              // 000000DB4704: 06D6C772
	v_sub_f32_e32 v99, v114, v99                               // 000000DB4708: 08C6C772
	v_add_f32_e32 v114, v91, v75                               // 000000DB470C: 06E4975B
	v_sub_f32_e32 v75, v91, v75                                // 000000DB4710: 0896975B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB4714: BF8700A3
	v_add_f32_e32 v138, v90, v99                               // 000000DB4718: 0714C75A
	v_sub_f32_e32 v90, v90, v99                                // 000000DB471C: 08B4C75A
	v_mov_b32_dpp v149, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4720: 7F2A02FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000DB4728: D501005A 2002B55A
	v_add_f32_e32 v83, v67, v59                                // 000000DB4730: 06A67743
	v_sub_f32_e32 v59, v67, v59                                // 000000DB4734: 08767743
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4738: BF870093
	v_dual_add_f32 v67, v51, v43 :: v_dual_add_f32 v90, v90, v149// 000000DB473C: C9085733 435B2B5A
	v_add_f32_e32 v91, v83, v67                                // 000000DB4744: 06B68753
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DB4748: BF8701C2
	v_mov_b32_dpp v149, v90 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB474C: 7F2A02FA FF01625A
	v_cndmask_b32_e64 v90, -v90, v90, s1                       // 000000DB4754: D501005A 2006B55A
	v_sub_f32_e32 v43, v51, v43                                // 000000DB475C: 08565733
	v_add_f32_e32 v51, v35, v27                                // 000000DB4760: 06663723
	v_dual_sub_f32 v35, v35, v27 :: v_dual_add_f32 v90, v90, v149// 000000DB4764: C9483723 235B2B5A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB476C: BF870001
	v_mov_b32_dpp v149, v90 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4770: 7F2A02FA FF01645A
	v_cndmask_b32_e64 v90, -v90, v90, s2                       // 000000DB4778: D501005A 200AB55A
	v_add_f32_e32 v115, v19, v11                               // 000000DB4780: 06E61713
	s_clause 0x3                                               // 000000DB4784: BF850003
	global_load_d16_b16 v19, v[2:3], off offset:1408           // 000000DB4788: DC820580 137C0002
	global_load_d16_b16 v27, v[2:3], off offset:1440           // 000000DB4790: DC8205A0 1B7C0002
	global_load_d16_b16 v11, v[2:3], off offset:1472           // 000000DB4798: DC8205C0 0B7C0002
	global_load_d16_b16 v34, v[2:3], off offset:1504           // 000000DB47A0: DC8205E0 227C0002
	v_add_f32_e32 v90, v90, v149                               // 000000DB47A8: 06B52B5A
	v_add_f32_e32 v130, v51, v115                              // 000000DB47AC: 0704E733
	v_sub_f32_e32 v51, v51, v115                               // 000000DB47B0: 0866E733
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB47B4: BF870003
	v_mov_b32_dpp v149, v90 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB47B8: 7F2A02FA FF01685A
	v_cndmask_b32_e64 v90, -v90, v90, s3                       // 000000DB47C0: D501005A 200EB55A
	v_sub_f32_e32 v67, v83, v67                                // 000000DB47C8: 08868753
	v_add_f32_e32 v83, v59, v43                                // 000000DB47CC: 06A6573B
	v_sub_f32_e32 v43, v59, v43                                // 000000DB47D0: 0856573B
	v_add_f32_e32 v59, v35, v122                               // 000000DB47D4: 0676F523
	v_dual_sub_f32 v35, v35, v122 :: v_dual_add_f32 v90, v90, v149// 000000DB47D8: C948F523 235B2B5A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB47E0: BF870112
	v_add_f32_e32 v122, v83, v59                               // 000000DB47E4: 06F47753
	v_dual_sub_f32 v59, v83, v59 :: v_dual_mul_f32 v90, 0x3db504f3, v90// 000000DB47E8: C9467753 3B5AB4FF 3DB504F3
	v_add_f32_e32 v83, v67, v51                                // 000000DB47F4: 06A66743
	v_sub_f32_e32 v51, v67, v51                                // 000000DB47F8: 08666743
	v_add_f32_e32 v67, v43, v35                                // 000000DB47FC: 0686472B
	v_sub_f32_e32 v35, v43, v35                                // 000000DB4800: 0846472B
	v_add_f32_e32 v43, v106, v114                              // 000000DB4804: 0656E56A
	v_sub_f32_e32 v106, v106, v114                             // 000000DB4808: 08D4E56A
	v_mov_b32_dpp v114, v122 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB480C: 7EE402FA FF01617A
	v_mov_b32_dpp v140, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4814: 7F1802FA FF01613B
	v_cndmask_b32_e64 v59, -v59, v59, s0                       // 000000DB481C: D501003B 2002773B
	v_mov_b32_dpp v144, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4824: 7F2002FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000DB482C: D501002B 2002572B
	v_mov_b32_dpp v148, v106 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4834: 7F2802FA FF01616A
	v_cndmask_b32_e64 v106, -v106, v106, s0                    // 000000DB483C: D501006A 2002D56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4844: BF870113
	v_add_f32_e32 v43, v43, v144                               // 000000DB4848: 0657212B
	v_add_f32_e32 v106, v106, v148                             // 000000DB484C: 06D5296A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4850: BF8701A2
	v_mov_b32_dpp v144, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4854: 7F2002FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000DB485C: D501002B 2006572B
	v_mov_b32_dpp v148, v106 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4864: 7F2802FA FF01626A
	v_cndmask_b32_e64 v106, -v106, v106, s1                    // 000000DB486C: D501006A 2006D56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4874: BF870113
	v_add_f32_e32 v43, v43, v144                               // 000000DB4878: 0657212B
	v_add_f32_e32 v106, v106, v148                             // 000000DB487C: 06D5296A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4880: BF8701A2
	v_mov_b32_dpp v144, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4884: 7F2002FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000DB488C: D501002B 200A572B
	v_mov_b32_dpp v148, v106 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4894: 7F2802FA FF01646A
	v_cndmask_b32_e64 v106, -v106, v106, s2                    // 000000DB489C: D501006A 200AD56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB48A4: BF870113
	v_add_f32_e32 v43, v43, v144                               // 000000DB48A8: 0657212B
	v_add_f32_e32 v106, v106, v148                             // 000000DB48AC: 06D5296A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB48B0: BF8701A2
	v_mov_b32_dpp v144, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB48B4: 7F2002FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000DB48BC: D501002B 200E572B
	v_mov_b32_dpp v148, v106 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB48C4: 7F2802FA FF01686A
	v_cndmask_b32_e64 v106, -v106, v106, s3                    // 000000DB48CC: D501006A 200ED56A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB48D4: BF870113
	v_add_f32_e32 v43, v43, v144                               // 000000DB48D8: 0657212B
	v_dual_add_f32 v106, v106, v148 :: v_dual_add_f32 v115, v91, v130// 000000DB48DC: C909296A 6A73055B
	v_sub_f32_e32 v91, v91, v130                               // 000000DB48E4: 08B7055B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB48E8: BF870192
	v_dual_mul_f32 v43, 0x3db504f3, v43 :: v_dual_mul_f32 v106, 0x3db504f3, v106// 000000DB48EC: C8C656FF 2B6AD4FF 3DB504F3
	v_cndmask_b32_e64 v99, -v115, v115, s0                     // 000000DB48F8: D5010063 2002E773
	s_waitcnt vmcnt(12)                                        // 000000DB4900: BF8933F7
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DB4904: BF870002
	v_fma_mix_f32 v9, v9, v43, neg(0) op_sel_hi:[1,0,0]        // 000000DB4908: CC200009 8A025709
	s_waitcnt vmcnt(8)                                         // 000000DB4910: BF8923F7
	v_fma_mix_f32 v43, v50, v106, neg(0) op_sel_hi:[1,0,0]     // 000000DB4914: CC20002B 8A02D532
	s_waitcnt vmcnt(7)                                         // 000000DB491C: BF891FF7
	v_fma_mix_f32 v50, v58, v90, neg(0) op_sel_hi:[1,0,0]      // 000000DB4920: CC200032 8A02B53A
	v_add_f32_e32 v131, v98, v75                               // 000000DB4928: 07069762
	v_sub_f32_e32 v75, v98, v75                                // 000000DB492C: 08969762
	v_mov_b32_dpp v98, v115 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4930: 7EC402FA FF016173
	v_cndmask_b32_e64 v115, -v122, v122, s0                    // 000000DB4938: D5010073 2002F57A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB4940: BF870223
	v_mov_b32_dpp v150, v75 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4944: 7F2C02FA FF01614B
	v_cndmask_b32_e64 v75, -v75, v75, s0                       // 000000DB494C: D501004B 2002974B
	v_add_f32_e32 v98, v99, v98                                // 000000DB4954: 06C4C563
	v_add_f32_e32 v130, v123, v107                             // 000000DB4958: 0704D77B
	v_add_f32_e32 v99, v115, v114                              // 000000DB495C: 06C6E573
	v_mov_b32_dpp v145, v138 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4960: 7F2202FA FF01618A
	v_add_f32_e32 v75, v75, v150                               // 000000DB4968: 06972D4B
	v_cndmask_b32_e64 v138, -v138, v138, s0                    // 000000DB496C: D501008A 2003158A
	v_mov_b32_dpp v143, v130 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4974: 7F1E02FA FF016182
	v_cndmask_b32_e64 v130, -v130, v130, s0                    // 000000DB497C: D5010082 20030582
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4984: BF8701A4
	v_mov_b32_dpp v150, v75 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4988: 7F2C02FA FF01624B
	v_cndmask_b32_e64 v75, -v75, v75, s1                       // 000000DB4990: D501004B 2006974B
	v_add_f32_e32 v114, v130, v143                             // 000000DB4998: 06E51F82
	v_mov_b32_dpp v130, v99 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB499C: 7F0402FA FF016263
	v_cndmask_b32_e64 v99, -v99, v99, s1                       // 000000DB49A4: D5010063 2006C763
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB49AC: BF870214
	v_add_f32_e32 v75, v75, v150                               // 000000DB49B0: 06972D4B
	v_mov_b32_dpp v143, v114 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB49B4: 7F1E02FA FF016272
	v_cndmask_b32_e64 v114, -v114, v114, s1                    // 000000DB49BC: D5010072 2006E572
	v_add_f32_e32 v59, v59, v140                               // 000000DB49C4: 0677193B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB49C8: BF870224
	v_mov_b32_dpp v150, v75 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB49CC: 7F2C02FA FF01644B
	v_cndmask_b32_e64 v75, -v75, v75, s2                       // 000000DB49D4: D501004B 200A974B
	v_add_f32_e32 v114, v114, v143                             // 000000DB49DC: 06E51F72
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB49E0: BF870224
	v_mov_b32_dpp v140, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB49E4: 7F1802FA FF01623B
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000DB49EC: D501003B 2006773B
	v_add_f32_e32 v75, v75, v150                               // 000000DB49F4: 06972D4B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB49F8: BF8701A4
	v_mov_b32_dpp v143, v114 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB49FC: 7F1E02FA FF016472
	v_cndmask_b32_e64 v114, -v114, v114, s2                    // 000000DB4A04: D5010072 200AE572
	v_mov_b32_dpp v150, v75 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4A0C: 7F2C02FA FF01684B
	v_cndmask_b32_e64 v75, -v75, v75, s3                       // 000000DB4A14: D501004B 200E974B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4A1C: BF870091
	v_dual_add_f32 v114, v114, v143 :: v_dual_add_f32 v75, v75, v150// 000000DB4A20: C9091F72 724B2D4B
	v_mov_b32_dpp v143, v114 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4A28: 7F1E02FA FF016872
	v_cndmask_b32_e64 v114, -v114, v114, s3                    // 000000DB4A30: D5010072 200EE572
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4A38: BF870113
	v_mul_f32_e32 v75, 0x3db504f3, v75                         // 000000DB4A3C: 109696FF 3DB504F3
	v_add_f32_e32 v114, v114, v143                             // 000000DB4A44: 06E51F72
	s_waitcnt vmcnt(6)                                         // 000000DB4A48: BF891BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DB4A4C: BF870252
	v_fma_mix_f32 v58, v66, v75, neg(0) op_sel_hi:[1,0,0]      // 000000DB4A50: CC20003A 8A029742
	v_mul_f32_e32 v66, 0xbfb8aa3b, v9                          // 000000DB4A58: 108412FF BFB8AA3B
	v_mov_b32_dpp v122, v83 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4A60: 7EF402FA FF016153
	v_cndmask_b32_e64 v83, -v83, v83, s0                       // 000000DB4A68: D5010053 2002A753
	v_mul_f32_e32 v114, 0x3db504f3, v114                       // 000000DB4A70: 10E4E4FF 3DB504F3
	v_exp_f32_e32 v66, v66                                     // 000000DB4A78: 7E844B42
	v_sub_f32_e32 v107, v123, v107                             // 000000DB4A7C: 08D6D77B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB4A80: BF870003
	v_dual_add_f32 v83, v83, v122 :: v_dual_add_f32 v122, v138, v145// 000000DB4A84: C908F553 537B238A
	v_mov_b32_dpp v123, v67 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4A8C: 7EF602FA FF016143
	v_cndmask_b32_e64 v67, -v67, v67, s0                       // 000000DB4A94: D5010043 20028743
	v_fma_mix_f32 v8, v8, v114, neg(0) op_sel_hi:[1,0,0]       // 000000DB4A9C: CC200008 8A02E508
	v_mul_f32_e32 v114, 0xbfb8aa3b, v50                        // 000000DB4AA4: 10E464FF BFB8AA3B
	v_mov_b32_dpp v146, v131 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4AAC: 7F2402FA FF016183
	v_cndmask_b32_e64 v131, -v131, v131, s0                    // 000000DB4AB4: D5010083 20030783
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000DB4ABC: BF870005
	v_add_f32_e32 v66, 1.0, v66                                // 000000DB4AC0: 068484F2
	v_mov_b32_dpp v147, v107 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4AC4: 7F2602FA FF01616B
	v_cndmask_b32_e64 v107, -v107, v107, s0                    // 000000DB4ACC: D501006B 2002D76B
	v_mov_b32_dpp v145, v122 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4AD4: 7F2202FA FF01627A
	v_cndmask_b32_e64 v122, -v122, v122, s1                    // 000000DB4ADC: D501007A 2006F57A
	v_exp_f32_e32 v114, v114                                   // 000000DB4AE4: 7EE44B72
	v_mul_f32_e32 v75, 0xbfb8aa3b, v8                          // 000000DB4AE8: 109610FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4AF0: BF870112
	v_dual_add_f32 v107, v107, v147 :: v_dual_add_f32 v122, v122, v145// 000000DB4AF4: C909276B 6B7B237A
	v_exp_f32_e32 v75, v75                                     // 000000DB4AFC: 7E964B4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4B00: BF8701A1
	v_mov_b32_dpp v147, v107 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4B04: 7F2602FA FF01626B
	v_cndmask_b32_e64 v107, -v107, v107, s1                    // 000000DB4B0C: D501006B 2006D76B
	v_mov_b32_dpp v145, v122 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4B14: 7F2202FA FF01647A
	v_cndmask_b32_e64 v122, -v122, v122, s2                    // 000000DB4B1C: D501007A 200AF57A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB4B24: BF870291
	v_dual_add_f32 v107, v107, v147 :: v_dual_add_f32 v122, v122, v145// 000000DB4B28: C909276B 6B7B237A
	v_add_f32_e32 v75, 1.0, v75                                // 000000DB4B30: 069696F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB4B34: BF870222
	v_mov_b32_dpp v147, v107 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4B38: 7F2602FA FF01646B
	v_cndmask_b32_e64 v107, -v107, v107, s2                    // 000000DB4B40: D501006B 200AD76B
	v_mov_b32_dpp v145, v122 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4B48: 7F2202FA FF01687A
	v_cndmask_b32_e64 v122, -v122, v122, s3                    // 000000DB4B50: D501007A 200EF57A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4B58: BF870091
	v_dual_add_f32 v107, v107, v147 :: v_dual_add_f32 v122, v122, v145// 000000DB4B5C: C909276B 6B7B237A
	v_mov_b32_dpp v147, v107 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4B64: 7F2602FA FF01686B
	v_cndmask_b32_e64 v107, -v107, v107, s3                    // 000000DB4B6C: D501006B 200ED76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4B74: BF870091
	v_dual_mul_f32 v122, 0x3db504f3, v122 :: v_dual_add_f32 v107, v107, v147// 000000DB4B78: C8C8F4FF 7A6B276B 3DB504F3
	v_fma_mix_f32 v18, v18, v122, neg(0) op_sel_hi:[1,0,0]     // 000000DB4B84: CC200012 8A02F512
	v_div_scale_f32 v122, s4, v9, v66, v9                      // 000000DB4B8C: D6FC047A 04268509
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4B94: BF870093
	v_mul_f32_e32 v107, 0x3db504f3, v107                       // 000000DB4B98: 10D6D6FF 3DB504F3
	v_fma_mix_f32 v42, v42, v107, neg(0) op_sel_hi:[1,0,0]     // 000000DB4BA0: CC20002A 8A02D72A
	v_mul_f32_e32 v107, 0xbfb8aa3b, v58                        // 000000DB4BA8: 10D674FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4BB0: BF870112
	v_mul_f32_e32 v106, 0xbfb8aa3b, v42                        // 000000DB4BB4: 10D454FF BFB8AA3B
	v_exp_f32_e32 v107, v107                                   // 000000DB4BBC: 7ED64B6B
	v_add_f32_e32 v99, v99, v130                               // 000000DB4BC0: 06C70563
	v_mov_b32_dpp v142, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4BC4: 7F1C02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000DB4BCC: D5010023 20024723
	v_exp_f32_e32 v106, v106                                   // 000000DB4BD4: 7ED44B6A
	v_add_f32_e32 v67, v67, v123                               // 000000DB4BD8: 0686F743
	v_mov_b32_dpp v130, v99 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4BDC: 7F0402FA FF016463
	v_cndmask_b32_e64 v99, -v99, v99, s2                       // 000000DB4BE4: D5010063 200AC763
	v_add_f32_e32 v35, v35, v142                               // 000000DB4BEC: 06471D23
	v_mov_b32_dpp v123, v98 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4BF0: 7EF602FA FF016262
	v_cndmask_b32_e64 v98, -v98, v98, s1                       // 000000DB4BF8: D5010062 2006C562
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB4C00: BF870214
	v_add_f32_e32 v99, v99, v130                               // 000000DB4C04: 06C70563
	v_mov_b32_dpp v142, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4C08: 7F1C02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000DB4C10: D5010023 20064723
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB4C18: BF870004
	v_add_f32_e32 v98, v98, v123                               // 000000DB4C1C: 06C4F762
	v_mov_b32_dpp v139, v91 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4C20: 7F1602FA FF01615B
	v_mov_b32_dpp v130, v99 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4C28: 7F0402FA FF016863
	v_cndmask_b32_e64 v99, -v99, v99, s3                       // 000000DB4C30: D5010063 200EC763
	v_add_f32_e32 v35, v35, v142                               // 000000DB4C38: 06471D23
	v_mov_b32_dpp v123, v98 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4C3C: 7EF602FA FF016462
	v_cndmask_b32_e64 v98, -v98, v98, s2                       // 000000DB4C44: D5010062 200AC562
	v_cndmask_b32_e64 v91, -v91, v91, s0                       // 000000DB4C4C: D501005B 2002B75B
	v_add_f32_e32 v99, v99, v130                               // 000000DB4C54: 06C70563
	v_mov_b32_dpp v142, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4C58: 7F1C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000DB4C60: D5010023 200A4723
	v_add_f32_e32 v98, v98, v123                               // 000000DB4C68: 06C4F762
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB4C6C: BF870194
	v_mul_f32_e32 v99, 0x3db504f3, v99                         // 000000DB4C70: 10C6C6FF 3DB504F3
	v_add_f32_e32 v35, v35, v142                               // 000000DB4C78: 06471D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB4C7C: BF870223
	v_mov_b32_dpp v123, v98 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4C80: 7EF602FA FF016862
	v_cndmask_b32_e64 v98, -v98, v98, s3                       // 000000DB4C88: D5010062 200EC562
	v_fma_mix_f32 v10, v10, v99, neg(0) op_sel_hi:[1,0,0]      // 000000DB4C90: CC20000A 8A02C70A
	v_mul_f32_e32 v99, 0xbfb8aa3b, v43                         // 000000DB4C98: 10C656FF BFB8AA3B
	v_mov_b32_dpp v142, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4CA0: 7F1C02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB4CA8: D5010023 200E4723
	v_add_f32_e32 v98, v98, v123                               // 000000DB4CB0: 06C4F762
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB4CB4: BF870004
	v_exp_f32_e32 v99, v99                                     // 000000DB4CB8: 7EC64B63
	v_add_f32_e32 v115, v131, v146                             // 000000DB4CBC: 06E72583
	v_mov_b32_dpp v131, v83 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4CC0: 7F0602FA FF016253
	v_cndmask_b32_e64 v83, -v83, v83, s1                       // 000000DB4CC8: D5010053 2006A753
	v_add_f32_e32 v35, v35, v142                               // 000000DB4CD0: 06471D23
	v_mul_f32_e32 v98, 0x3db504f3, v98                         // 000000DB4CD4: 10C4C4FF 3DB504F3
	v_mov_b32_dpp v146, v115 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4CDC: 7F2402FA FF016273
	v_cndmask_b32_e64 v115, -v115, v115, s1                    // 000000DB4CE4: D5010073 2006E773
	v_add_f32_e32 v83, v83, v131                               // 000000DB4CEC: 06A70753
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000DB4CF0: 104646FF 3DB504F3
	v_fma_mix_f32 v7, v7, v98, neg(0) op_sel_hi:[1,0,0]        // 000000DB4CF8: CC200007 8A02C507
	v_mul_f32_e32 v98, 0xbfb8aa3b, v18                         // 000000DB4D00: 10C424FF BFB8AA3B
	v_add_f32_e32 v115, v115, v146                             // 000000DB4D08: 06E72573
	v_mov_b32_dpp v131, v83 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4D0C: 7F0602FA FF016453
	v_cndmask_b32_e64 v83, -v83, v83, s2                       // 000000DB4D14: D5010053 200AA753
	s_waitcnt vmcnt(0)                                         // 000000DB4D1C: BF8903F7
	v_fma_mix_f32 v34, v34, v35, neg(0) op_sel_hi:[1,0,0]      // 000000DB4D20: CC200022 8A024722
	v_exp_f32_e32 v98, v98                                     // 000000DB4D28: 7EC44B62
	v_mov_b32_dpp v146, v115 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4D2C: 7F2402FA FF016473
	v_cndmask_b32_e64 v115, -v115, v115, s2                    // 000000DB4D34: D5010073 200AE773
	v_add_f32_e32 v83, v83, v131                               // 000000DB4D3C: 06A70753
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4D40: BF870112
	v_add_f32_e32 v115, v115, v146                             // 000000DB4D44: 06E72573
	v_mov_b32_dpp v131, v83 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4D48: 7F0602FA FF016853
	v_cndmask_b32_e64 v83, -v83, v83, s3                       // 000000DB4D50: D5010053 200EA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4D58: BF8701A3
	v_mov_b32_dpp v146, v115 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4D5C: 7F2402FA FF016873
	v_cndmask_b32_e64 v115, -v115, v115, s3                    // 000000DB4D64: D5010073 200EE773
	v_add_f32_e32 v83, v83, v131                               // 000000DB4D6C: 06A70753
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4D70: BF870112
	v_add_f32_e32 v115, v115, v146                             // 000000DB4D74: 06E72573
	v_mul_f32_e32 v83, 0x3db504f3, v83                         // 000000DB4D78: 10A6A6FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4D80: BF870112
	v_mul_f32_e32 v115, 0x3db504f3, v115                       // 000000DB4D84: 10E6E6FF 3DB504F3
	v_fma_mix_f32 v74, v74, v83, neg(0) op_sel_hi:[1,0,0]      // 000000DB4D8C: CC20004A 8A02A74A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB4D94: BF870122
	v_fma_mix_f32 v26, v26, v115, neg(0) op_sel_hi:[1,0,0]     // 000000DB4D98: CC20001A 8A02E71A
	v_div_scale_f32 v115, null, v66, v66, v9                   // 000000DB4DA0: D6FC7C73 04268542
	v_mul_f32_e32 v90, 0xbfb8aa3b, v26                         // 000000DB4DA8: 10B434FF BFB8AA3B
	v_mov_b32_dpp v141, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB4DB0: 7F1A02FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000DB4DB8: D5010033 20026733
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB4DC0: BF870194
	v_rcp_f32_e32 v142, v115                                   // 000000DB4DC4: 7F1C5573
	v_exp_f32_e32 v90, v90                                     // 000000DB4DC8: 7EB44B5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB4DCC: BF870091
	v_add_f32_e32 v51, v51, v141                               // 000000DB4DD0: 06671B33
	v_mov_b32_dpp v141, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4DD4: 7F1A02FA FF016233
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB4DDC: BF8702A6
	v_fma_f32 v152, -v115, v142, 1.0                           // 000000DB4DE0: D6130098 23CB1D73
	v_add_f32_e32 v91, v91, v139                               // 000000DB4DE8: 06B7175B
	v_add_f32_e32 v83, 1.0, v90                                // 000000DB4DEC: 06A6B4F2
	v_add_f32_e32 v90, 1.0, v106                               // 000000DB4DF0: 06B4D4F2
	v_mov_b32_dpp v138, v67 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4DF4: 7F1402FA FF016243
	v_cndmask_b32_e64 v67, -v67, v67, s1                       // 000000DB4DFC: D5010043 20068743
	v_fmac_f32_e32 v142, v152, v142                            // 000000DB4E04: 571D1D98
	v_mov_b32_dpp v139, v91 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB4E08: 7F1602FA FF01625B
	v_cndmask_b32_e64 v91, -v91, v91, s1                       // 000000DB4E10: D501005B 2006B75B
	v_div_scale_f32 v130, null, v83, v83, v26                  // 000000DB4E18: D6FC7C82 046AA753
	v_add_f32_e32 v67, v67, v138                               // 000000DB4E20: 06871543
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000DB4E24: D5010033 20066733
	v_add_f32_e32 v106, 1.0, v107                              // 000000DB4E2C: 06D4D6F2
	v_div_scale_f32 v107, null, v75, v75, v8                   // 000000DB4E30: D6FC7C6B 0422974B
	v_rcp_f32_e32 v144, v130                                   // 000000DB4E38: 7F205582
	v_mov_b32_dpp v138, v67 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4E3C: 7F1402FA FF016443
	v_cndmask_b32_e64 v67, -v67, v67, s2                       // 000000DB4E44: D5010043 200A8743
	v_div_scale_f32 v131, null, v90, v90, v42                  // 000000DB4E4C: D6FC7C83 04AAB55A
	v_div_scale_f32 v150, s6, v26, v83, v26                    // 000000DB4E54: D6FC0696 046AA71A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB4E5C: BF870193
	v_add_f32_e32 v67, v67, v138                               // 000000DB4E60: 06871543
	v_rcp_f32_e32 v145, v131                                   // 000000DB4E64: 7F225583
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4E68: BF870116
	v_fma_f32 v154, -v130, v144, 1.0                           // 000000DB4E6C: D613009A 23CB2182
	v_mov_b32_dpp v138, v67 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4E74: 7F1402FA FF016843
	v_cndmask_b32_e64 v67, -v67, v67, s3                       // 000000DB4E7C: D5010043 200E8743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB4E84: BF870291
	v_dual_fmac_f32 v144, v154, v144 :: v_dual_add_f32 v67, v67, v138// 000000DB4E88: C809219A 90431543
	v_fma_f32 v155, -v131, v145, 1.0                           // 000000DB4E90: D613009B 23CB2383
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB4E98: BF870112
	v_mul_f32_e32 v67, 0x3db504f3, v67                         // 000000DB4E9C: 108686FF 3DB504F3
	v_fmac_f32_e32 v145, v155, v145                            // 000000DB4EA4: 5723239B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DB4EA8: BF8701C2
	v_fma_mix_f32 v67, v82, v67, neg(0) op_sel_hi:[1,0,0]      // 000000DB4EAC: CC200043 8A028752
	v_add_f32_e32 v82, 1.0, v98                                // 000000DB4EB4: 06A4C4F2
	v_dual_add_f32 v98, 1.0, v99 :: v_dual_add_f32 v99, 1.0, v114// 000000DB4EB8: C908C6F2 6262E4F2
	v_div_scale_f32 v114, vcc_lo, v8, v75, v8                  // 000000DB4EC0: D6FC6A72 04229708
	v_div_scale_f32 v123, null, v82, v82, v18                  // 000000DB4EC8: D6FC7C7B 044AA552
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4ED0: BF8701A3
	v_div_scale_f32 v138, null, v98, v98, v43                  // 000000DB4ED4: D6FC7C8A 04AEC562
	v_div_scale_f32 v148, s5, v18, v82, v18                    // 000000DB4EDC: D6FC0594 044AA512
	v_rcp_f32_e32 v143, v123                                   // 000000DB4EE4: 7F1E557B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB4EE8: BF870312
	v_rcp_f32_e32 v146, v138                                   // 000000DB4EEC: 7F24558A
	v_fma_f32 v153, -v123, v143, 1.0                           // 000000DB4EF0: D6130099 23CB1F7B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB4EF8: BF870125
	v_fma_f32 v156, -v138, v146, 1.0                           // 000000DB4EFC: D613009C 23CB258A
	v_add_f32_e32 v91, v91, v139                               // 000000DB4F04: 06B7175B
	v_dual_fmac_f32 v143, v153, v143 :: v_dual_fmac_f32 v146, v156, v146// 000000DB4F08: C8011F99 8F93259C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB4F10: BF8701A2
	v_mov_b32_dpp v139, v91 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4F14: 7F1602FA FF01645B
	v_cndmask_b32_e64 v91, -v91, v91, s2                       // 000000DB4F1C: D501005B 200AB75B
	v_dual_add_f32 v51, v51, v141 :: v_dual_mul_f32 v154, v148, v143// 000000DB4F24: C9071B33 339B1F94
	v_mul_f32_e32 v153, v122, v142                             // 000000DB4F2C: 11331D7A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB4F30: BF870193
	v_add_f32_e32 v91, v91, v139                               // 000000DB4F34: 06B7175B
	v_mov_b32_dpp v141, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4F38: 7F1A02FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000DB4F40: D5010033 200A6733
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB4F48: BF870214
	v_fma_f32 v156, -v115, v153, v122                          // 000000DB4F4C: D613009C 25EB3373
	v_mov_b32_dpp v139, v91 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4F54: 7F1602FA FF01685B
	v_cndmask_b32_e64 v91, -v91, v91, s3                       // 000000DB4F5C: D501005B 200EB75B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB4F64: BF870214
	v_add_f32_e32 v51, v51, v141                               // 000000DB4F68: 06671B33
	v_fmac_f32_e32 v153, v156, v142                            // 000000DB4F6C: 57331D9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB4F70: BF870223
	v_add_f32_e32 v91, v91, v139                               // 000000DB4F74: 06B7175B
	v_div_scale_f32 v139, null, v99, v99, v50                  // 000000DB4F78: D6FC7C8B 04CAC763
	v_mov_b32_dpp v141, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB4F80: 7F1A02FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000DB4F88: D5010033 200E6733
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB4F90: BF870214
	v_mul_f32_e32 v91, 0x3db504f3, v91                         // 000000DB4F94: 10B6B6FF 3DB504F3
	v_rcp_f32_e32 v147, v139                                   // 000000DB4F9C: 7F26558B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB4FA0: BF870122
	v_add_f32_e32 v51, v51, v141                               // 000000DB4FA4: 06671B33
	v_rcp_f32_e32 v141, v107                                   // 000000DB4FA8: 7F1A556B
	v_fma_mix_f32 v19, v19, v91, neg(0) op_sel_hi:[1,0,0]      // 000000DB4FAC: CC200013 8A02B713
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB4FB4: BF870312
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000DB4FB8: 106666FF 3DB504F3
	v_fma_f32 v157, -v139, v147, 1.0                           // 000000DB4FC0: D613009D 23CB278B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB4FC8: BF870292
	v_fma_mix_f32 v11, v11, v51, neg(0) op_sel_hi:[1,0,0]      // 000000DB4FCC: CC20000B 8A02670B
	v_fma_f32 v151, -v107, v141, 1.0                           // 000000DB4FD4: D6130097 23CB1B6B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB4FDC: BF870133
	v_fmac_f32_e32 v147, v157, v147                            // 000000DB4FE0: 5727279D
	v_fma_f32 v157, -v123, v154, v148                          // 000000DB4FE4: D613009D 2653357B
	v_add_f32_e32 v59, v59, v140                               // 000000DB4FEC: 0677193B
	v_dual_fmac_f32 v141, v151, v141 :: v_dual_fmac_f32 v154, v157, v143// 000000DB4FF0: C8011B97 8D9B1F9D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB4FF8: BF8700A2
	v_mov_b32_dpp v140, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB4FFC: 7F1802FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000DB5004: D501003B 200A773B
	v_dual_mul_f32 v152, v114, v141 :: v_dual_add_f32 v59, v59, v140// 000000DB500C: C8C91B72 983B193B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5014: BF870111
	v_fma_f32 v155, -v107, v152, v114                          // 000000DB5018: D613009B 25CB316B
	v_mov_b32_dpp v140, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5020: 7F1802FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000DB5028: D501003B 200E773B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB5030: BF8701A3
	v_fmac_f32_e32 v152, v155, v141                            // 000000DB5034: 57311B9B
	v_div_scale_f32 v155, s7, v42, v90, v42                    // 000000DB5038: D6FC079B 04AAB52A
	v_add_f32_e32 v59, v59, v140                               // 000000DB5040: 0677193B
	v_div_scale_f32 v140, null, v106, v106, v58                // 000000DB5044: D6FC7C8C 04EAD56A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB504C: BF870003
	v_mul_f32_e32 v157, v155, v145                             // 000000DB5050: 113B239B
	v_fma_f32 v107, -v107, v152, v114                          // 000000DB5054: D613006B 25CB316B
	v_fma_f32 v114, -v115, v153, v122                          // 000000DB505C: D6130072 25EB3373
	v_fma_f32 v115, -v123, v154, v148                          // 000000DB5064: D6130073 2653357B
	v_rcp_f32_e32 v149, v140                                   // 000000DB506C: 7F2A558C
	v_mul_f32_e32 v59, 0x3db504f3, v59                         // 000000DB5070: 107676FF 3DB504F3
	v_div_fmas_f32 v107, v107, v141, v152                      // 000000DB5078: D637006B 06631B6B
	s_mov_b32 vcc_lo, s4                                       // 000000DB5080: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB5084: BE84007E
	v_div_fmas_f32 v114, v114, v142, v153                      // 000000DB5088: D6370072 06671D72
	s_mov_b32 vcc_lo, s5                                       // 000000DB5090: BEEA0005
	v_div_fixup_f32 v8, v107, v75, v8                          // 000000DB5094: D6270008 0422976B
	v_div_fmas_f32 v115, v115, v143, v154                      // 000000DB509C: D6370073 066B1F73
	s_mov_b32 vcc_lo, s6                                       // 000000DB50A4: BEEA0006
	v_fma_f32 v151, -v140, v149, 1.0                           // 000000DB50A8: D6130097 23CB2B8C
	v_div_fixup_f32 v9, v114, v66, v9                          // 000000DB50B0: D6270009 04268572
	v_mul_f32_e32 v7, v7, v8                                   // 000000DB50B8: 100E1107
	v_fma_mix_f32 v27, v27, v59, neg(0) op_sel_hi:[1,0,0]      // 000000DB50BC: CC20001B 8A02771B
	v_div_fixup_f32 v18, v115, v82, v18                        // 000000DB50C4: D6270012 044AA573
	v_fmac_f32_e32 v149, v151, v149                            // 000000DB50CC: 572B2B97
	v_mul_f32_e32 v151, v150, v144                             // 000000DB50D0: 112F2196
	v_mul_f32_e32 v9, v10, v9                                  // 000000DB50D4: 1012130A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB50D8: BF870194
	v_mul_f32_e32 v18, v74, v18                                // 000000DB50DC: 1024254A
	v_fma_f32 v156, -v130, v151, v150                          // 000000DB50E0: D613009C 265B2F82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB50E8: BF8700A1
	v_fmac_f32_e32 v151, v156, v144                            // 000000DB50EC: 572F219C
	v_fma_f32 v156, -v131, v157, v155                          // 000000DB50F0: D613009C 266F3B83
	v_fmac_f32_e32 v157, v156, v145                            // 000000DB50F8: 573B239C
	v_div_scale_f32 v156, s8, v43, v98, v43                    // 000000DB50FC: D6FC089C 04AEC52B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5104: BF870112
	v_fma_f32 v123, -v131, v157, v155                          // 000000DB5108: D613007B 266F3B83
	v_mul_f32_e32 v158, v156, v146                             // 000000DB5110: 113D259C
	global_load_d16_b16 v131, v[4:5], off offset:32            // 000000DB5114: DC820020 837C0004
	v_fma_f32 v159, -v138, v158, v156                          // 000000DB511C: D613009F 26733D8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5124: BF8700A1
	v_fmac_f32_e32 v158, v159, v146                            // 000000DB5128: 573D259F
	v_div_scale_f32 v159, s9, v50, v99, v50                    // 000000DB512C: D6FC099F 04CAC732
	v_mul_f32_e32 v160, v159, v147                             // 000000DB5134: 1141279F
	v_fma_f32 v122, -v130, v151, v150                          // 000000DB5138: D613007A 265B2F82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB5140: BF870194
	v_fma_f32 v130, -v138, v158, v156                          // 000000DB5144: D6130082 26733D8A
	v_fma_f32 v161, -v139, v160, v159                          // 000000DB514C: D61300A1 267F418B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB5154: BF8701B3
	v_div_fmas_f32 v75, v122, v144, v151                       // 000000DB5158: D637004B 065F217A
	s_mov_b32 vcc_lo, s7                                       // 000000DB5160: BEEA0007
	v_div_fmas_f32 v66, v123, v145, v157                       // 000000DB5164: D6370042 0677237B
	v_fmac_f32_e32 v160, v161, v147                            // 000000DB516C: 574127A1
	v_div_scale_f32 v161, s10, v58, v106, v58                  // 000000DB5170: D6FC0AA1 04EAD53A
	v_div_fixup_f32 v8, v75, v83, v26                          // 000000DB5178: D6270008 046AA74B
	s_mov_b32 vcc_lo, s8                                       // 000000DB5180: BEEA0008
	v_div_fixup_f32 v35, v66, v90, v42                         // 000000DB5184: D6270023 04AAB542
	v_fma_f32 v138, -v139, v160, v159                          // 000000DB518C: D613008A 267F418B
	s_clause 0x6                                               // 000000DB5194: BF850006
	global_load_d16_b16 v139, v[4:5], off offset:96            // 000000DB5198: DC820060 8B7C0004
	global_load_d16_b16 v141, v[4:5], off offset:160           // 000000DB51A0: DC8200A0 8D7C0004
	global_load_d16_b16 v142, v[4:5], off offset:224           // 000000DB51A8: DC8200E0 8E7C0004
	global_load_d16_b16 v143, v[4:5], off offset:192           // 000000DB51B0: DC8200C0 8F7C0004
	global_load_d16_b16 v148, v[4:5], off offset:128           // 000000DB51B8: DC820080 947C0004
	global_load_d16_b16 v150, v[4:5], off offset:64            // 000000DB51C0: DC820040 967C0004
	global_load_d16_b16 v152, v[4:5], off                      // 000000DB51C8: DC820000 987C0004
	v_mul_f32_e32 v162, v161, v149                             // 000000DB51D0: 11452BA1
	v_div_fmas_f32 v10, v130, v146, v158                       // 000000DB51D4: D637000A 067B2582
	s_mov_b32 vcc_lo, s9                                       // 000000DB51DC: BEEA0009
	v_mul_f32_e32 v8, v67, v8                                  // 000000DB51E0: 10101143
	v_div_fmas_f32 v67, v138, v147, v160                       // 000000DB51E4: D6370043 0683278A
	v_fma_f32 v163, -v140, v162, v161                          // 000000DB51EC: D61300A3 2687458C
	s_mov_b32 vcc_lo, s10                                      // 000000DB51F4: BEEA000A
	v_div_fixup_f32 v10, v10, v98, v43                         // 000000DB51F8: D627000A 04AEC50A
	v_mul_f32_e32 v19, v19, v35                                // 000000DB5200: 10264713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB5204: BF870193
	v_fmac_f32_e32 v162, v163, v149                            // 000000DB5208: 57452BA3
	v_mul_f32_e32 v10, v27, v10                                // 000000DB520C: 1014151B
	v_div_fixup_f32 v27, v67, v99, v50                         // 000000DB5210: D627001B 04CAC743
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5218: BF870113
	v_fma_f32 v26, -v140, v162, v161                           // 000000DB521C: D613001A 2687458C
	v_mul_f32_e32 v11, v11, v27                                // 000000DB5224: 1016370B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5228: BF870092
	v_div_fmas_f32 v26, v26, v149, v162                        // 000000DB522C: D637001A 068B2B1A
	v_div_fixup_f32 v26, v26, v106, v58                        // 000000DB5234: D627001A 04EAD51A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB523C: BF870001
	v_mul_f32_e32 v26, v34, v26                                // 000000DB5240: 10343522
	s_waitcnt vmcnt(7)                                         // 000000DB5244: BF891FF7
	v_fma_mix_f32 v9, v131, v9, neg(0) op_sel_hi:[1,0,0]       // 000000DB5248: CC200009 8A021383
	s_waitcnt vmcnt(6)                                         // 000000DB5250: BF891BF7
	v_fma_mix_f32 v8, v139, v8, neg(0) op_sel_hi:[1,0,0]       // 000000DB5254: CC200008 8A02118B
	s_waitcnt vmcnt(5)                                         // 000000DB525C: BF8917F7
	v_fma_mix_f32 v10, v141, v10, neg(0) op_sel_hi:[1,0,0]     // 000000DB5260: CC20000A 8A02158D
	s_waitcnt vmcnt(4)                                         // 000000DB5268: BF8913F7
	v_fma_mix_f32 v26, v142, v26, neg(0) op_sel_hi:[1,0,0]     // 000000DB526C: CC20001A 8A02358E
	s_waitcnt vmcnt(1)                                         // 000000DB5274: BF8907F7
	v_fma_mix_f32 v34, v18, v150, v8 op_sel_hi:[0,1,0]         // 000000DB5278: CC200022 14232D12
	s_waitcnt vmcnt(0)                                         // 000000DB5280: BF8903F7
	v_fma_mix_f32 v27, v7, v152, v9 op_sel_hi:[0,1,0]          // 000000DB5284: CC20001B 14273107
	v_fma_mix_f32 v35, v19, v148, v10 op_sel_hi:[0,1,0]        // 000000DB528C: CC200023 142B2913
	v_fma_mix_f32 v42, v11, v143, v26 op_sel_hi:[0,1,0]        // 000000DB5294: CC20002A 146B1F0B
	v_fma_mix_f32 v7, v7, v152, -v9 op_sel_hi:[0,1,0]          // 000000DB529C: CC200007 94273107
	v_fma_mix_f32 v8, v18, v150, -v8 op_sel_hi:[0,1,0]         // 000000DB52A4: CC200008 94232D12
	v_add_f32_e32 v43, v27, v34                                // 000000DB52AC: 0656451B
	v_fma_mix_f32 v10, v19, v148, -v10 op_sel_hi:[0,1,0]       // 000000DB52B0: CC20000A 942B2913
	v_add_f32_e32 v50, v35, v42                                // 000000DB52B8: 06645523
	v_fma_mix_f32 v11, v11, v143, -v26 op_sel_hi:[0,1,0]       // 000000DB52BC: CC20000B 946B1F0B
	v_sub_f32_e32 v18, v27, v34                                // 000000DB52C4: 0824451B
	v_add_f32_e32 v19, v7, v8                                  // 000000DB52C8: 06261107
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB52CC: 080E1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB52D0: BF8701B4
	v_dual_add_f32 v9, v43, v50 :: v_dual_add_f32 v8, v10, v11 // 000000DB52D4: C908652B 0908170A
	v_dual_sub_f32 v27, v35, v42 :: v_dual_sub_f32 v10, v10, v11// 000000DB52DC: C94A5523 1B0A170A
	v_sub_f32_e32 v11, v43, v50                                // 000000DB52E4: 0816652B
	v_mov_b32_dpp v26, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB52E8: 7E3402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB52F0: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB52F8: BF870113
	v_cndmask_b32_e64 v50, -v11, v11, s0                       // 000000DB52FC: D5010032 2002170B
	v_dual_add_f32 v9, v9, v26 :: v_dual_add_f32 v26, v19, v8  // 000000DB5304: C9083509 091A1113
	v_dual_sub_f32 v19, v19, v8 :: v_dual_add_f32 v8, v18, v27 // 000000DB530C: C9481113 13083712
	v_sub_f32_e32 v27, v18, v27                                // 000000DB5314: 08363712
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB5318: BF870003
	v_mov_b32_dpp v34, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB531C: 7E4402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB5324: D5010009 20061309
	v_mov_b32_dpp v35, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB532C: 7E4602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB5334: D501001A 2002351A
	v_mov_b32_dpp v42, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB533C: 7E5402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB5344: D5010008 20021108
	v_add_f32_e32 v9, v9, v34                                  // 000000DB534C: 06124509
	v_mov_b32_dpp v51, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5350: 7E6602FA FF01611B
	v_add_f32_e32 v18, v26, v35                                // 000000DB5358: 0624471A
	v_add_f32_e32 v26, v7, v10                                 // 000000DB535C: 06341507
	v_add_f32_e32 v8, v8, v42                                  // 000000DB5360: 06105508
	v_mov_b32_dpp v34, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5364: 7E4402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DB536C: D5010009 200A1309
	v_mov_b32_dpp v35, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5374: 7E4602FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB537C: D5010012 20062512
	v_mov_b32_dpp v42, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5384: 7E5402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB538C: D5010008 20061108
	v_mov_b32_dpp v43, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5394: 7E5602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB539C: D501001A 2002351A
	v_dual_add_f32 v18, v18, v35 :: v_dual_sub_f32 v35, v7, v10// 000000DB53A4: C90A4712 12221507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB53AC: BF870224
	v_add_f32_e32 v8, v8, v42                                  // 000000DB53B0: 06105508
	v_add_f32_e32 v7, v9, v34                                  // 000000DB53B4: 060E4509
	v_add_f32_e32 v9, v26, v43                                 // 000000DB53B8: 0612571A
	v_mov_b32_dpp v43, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB53BC: 7E5602FA FF01610B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000DB53C4: D501001B 2002371B
	v_mov_b32_dpp v26, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB53CC: 7E3402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB53D4: D5010008 200A1108
	v_mov_b32_dpp v34, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB53DC: 7E4402FA FF016209
	v_cndmask_b32_e64 v42, -v9, v9, s1                         // 000000DB53E4: D501002A 20061309
	v_mov_b32_dpp v58, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB53EC: 7E7402FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000DB53F4: D5010023 20024723
	v_add_f32_e32 v11, v8, v26                                 // 000000DB53FC: 06163508
	v_mov_b32_dpp v10, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5400: 7E1402FA FF016412
	v_add_f32_e32 v26, v42, v34                                // 000000DB5408: 0634452A
	v_add_f32_e32 v34, v50, v43                                // 000000DB540C: 06445732
	v_mov_b32_dpp v50, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5410: 7E6402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB5418: D5010013 20022713
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB5420: D5010012 200A2512
	v_mov_b32_dpp v42, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5428: 7E5402FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000DB5430: D501001A 200A351A
	v_mov_b32_dpp v43, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5438: 7E5602FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB5440: D5010022 20064522
	v_add_f32_e32 v50, v19, v50                                // 000000DB5448: 06646513
	v_add_f32_e32 v9, v18, v10                                 // 000000DB544C: 06121512
	v_dual_add_f32 v19, v26, v42 :: v_dual_add_f32 v26, v27, v51// 000000DB5450: C908551A 131A671B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB5458: BF870214
	v_dual_add_f32 v27, v34, v43 :: v_dual_add_f32 v34, v35, v58// 000000DB545C: C9085722 1B227523
	v_mov_b32_dpp v35, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5464: 7E4602FA FF016232
	v_cndmask_b32_e64 v42, -v50, v50, s1                       // 000000DB546C: D501002A 20066532
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB5474: BF870004
	v_mov_b32_dpp v43, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5478: 7E5602FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB5480: D501001A 2006351A
	v_mov_b32_dpp v50, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5488: 7E6402FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB5490: D5010022 20064522
	v_add_f32_e32 v35, v42, v35                                // 000000DB5498: 0646472A
	v_mov_b32_dpp v42, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB549C: 7E5402FA FF01641B
	v_add_f32_e32 v26, v26, v43                                // 000000DB54A4: 0634571A
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000DB54A8: D501001B 200A371B
	v_add_f32_e32 v34, v34, v50                                // 000000DB54B0: 06446522
	v_mov_b32_dpp v43, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB54B4: 7E5602FA FF016423
	v_cndmask_b32_e64 v50, -v35, v35, s2                       // 000000DB54BC: D5010032 200A4723
	v_mov_b32_dpp v51, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB54C4: 7E6602FA FF01641A
	v_cndmask_b32_e64 v58, -v26, v26, s2                       // 000000DB54CC: D501003A 200A351A
	v_mov_b32_dpp v59, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB54D4: 7E7602FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000DB54DC: D5010022 200A4522
	v_dual_add_f32 v35, v27, v42 :: v_dual_add_f32 v42, v50, v43// 000000DB54E4: C908551B 232A5732
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB54EC: BF870224
	v_add_f32_e32 v50, v58, v51                                // 000000DB54F0: 0664673A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB54F4: 7E1002FA FF016807
	v_add_f32_e32 v58, v34, v59                                // 000000DB54FC: 06747722
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5500: 7E1402FA FF016809
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5508: 7E2402FA FF01680B
	v_mov_b32_dpp v26, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5510: 7E3402FA FF016813
	v_add_nc_u32_e32 v27, 2, v6                                // 000000DB5518: 4A360C82
	v_mov_b32_dpp v34, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB551C: 7E4402FA FF016823
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5524: 7E5602FA FF01682A
	v_mov_b32_dpp v51, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB552C: 7E6602FA FF016832
	v_mov_b32_dpp v59, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5534: 7E7602FA FF01683A
	.long 0xd4c4007e                                           // 000000DB553C: D4C4007E
	v_cndmask_b32_e32 v1, s23, v27, vcc_lo                     // 000000DB5540: 02023617
	s_cbranch_execz 62                                         // 000000DB5544: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x2a40>
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000DB5548: D501003A 200E753A
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB5550: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB5558: D5010009 200E1309
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000DB5560: D5010032 200E6532
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000DB5568: D5010013 200E2713
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DB5570: D501000B 200E170B
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB5578: D5010023 200E4723
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB5580: D501002A 200E552A
	v_dual_add_f32 v58, v58, v59 :: v_dual_add_f32 v7, v7, v8  // 000000DB5588: C908773A 3A061107
	v_add_f32_e32 v8, v9, v10                                  // 000000DB5590: 06101509
	v_dual_add_f32 v50, v50, v51 :: v_dual_add_f32 v9, v11, v18// 000000DB5594: C9086732 3208250B
	v_add_f32_e32 v26, v19, v26                                // 000000DB559C: 06343513
	v_mad_i64_i32 v[18:19], null, 0x500, v27, v[0:1]           // 000000DB55A0: D6FF7C12 040236FF 00000500
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB55AC: BE8500FF 3DB504F3
	v_add_f32_e32 v34, v35, v34                                // 000000DB55B4: 06444523
	v_add_f32_e32 v42, v42, v43                                // 000000DB55B8: 0654572A
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB55BC: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB55C4: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB55CC: CC210008 02000B09
	v_fma_mixhi_f16 v8, v26, s5, 0                             // 000000DB55D4: CC220008 02000B1A
	v_fma_mixlo_f16 v9, v34, s5, 0                             // 000000DB55DC: CC210009 02000B22
	v_fma_mixhi_f16 v9, v42, s5, 0                             // 000000DB55E4: CC220009 02000B2A
	v_fma_mixlo_f16 v10, v50, s5, 0                            // 000000DB55EC: CC21000A 02000B32
	v_fma_mixhi_f16 v10, v58, s5, 0                            // 000000DB55F4: CC22000A 02000B3A
	s_clause 0x7                                               // 000000DB55FC: BF850007
	global_store_b16 v[18:19], v7, off                         // 000000DB5600: DC660000 007C0712
	global_store_d16_hi_b16 v[18:19], v7, off offset:32        // 000000DB5608: DC960020 007C0712
	global_store_b16 v[18:19], v8, off offset:64               // 000000DB5610: DC660040 007C0812
	global_store_d16_hi_b16 v[18:19], v8, off offset:96        // 000000DB5618: DC960060 007C0812
	global_store_b16 v[18:19], v9, off offset:128              // 000000DB5620: DC660080 007C0912
	global_store_d16_hi_b16 v[18:19], v9, off offset:160       // 000000DB5628: DC9600A0 007C0912
	global_store_b16 v[18:19], v10, off offset:192             // 000000DB5630: DC6600C0 007C0A12
	global_store_d16_hi_b16 v[18:19], v10, off offset:224      // 000000DB5638: DC9600E0 007C0A12
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB5640: 8C7E047E
	s_clause 0xb                                               // 000000DB5644: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB5648: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB5650: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB5658: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB5660: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DB5668: DC820040 0B7C0002
	global_load_d16_b16 v18, v[2:3], off offset:96             // 000000DB5670: DC820060 127C0002
	global_load_d16_b16 v27, v[2:3], off offset:128            // 000000DB5678: DC820080 1B7C0002
	global_load_d16_b16 v34, v[2:3], off offset:160            // 000000DB5680: DC8200A0 227C0002
	global_load_d16_b16 v35, v[2:3], off offset:192            // 000000DB5688: DC8200C0 237C0002
	global_load_d16_b16 v42, v[2:3], off offset:224            // 000000DB5690: DC8200E0 2A7C0002
	global_load_d16_b16 v43, v[2:3], off offset:1344           // 000000DB5698: DC820540 2B7C0002
	global_load_d16_b16 v50, v[2:3], off offset:1376           // 000000DB56A0: DC820560 327C0002
	v_add_f32_e32 v67, v100, v92                               // 000000DB56A8: 0686B964
	v_add_f32_e32 v75, v84, v76                                // 000000DB56AC: 06969954
	v_add_f32_e32 v59, v116, v108                              // 000000DB56B0: 0676D974
	v_sub_f32_e32 v58, v132, v124                              // 000000DB56B4: 0874F984
	v_sub_f32_e32 v66, v116, v108                              // 000000DB56B8: 0884D974
	v_add_f32_e32 v51, v132, v124                              // 000000DB56BC: 0666F984
	v_sub_f32_e32 v74, v100, v92                               // 000000DB56C0: 0894B964
	v_sub_f32_e32 v76, v84, v76                                // 000000DB56C4: 08989954
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB56C8: BF870003
	v_add_f32_e32 v84, v51, v59                                // 000000DB56CC: 06A87733
	v_sub_f32_e32 v51, v51, v59                                // 000000DB56D0: 08667733
	v_add_f32_e32 v59, v58, v66                                // 000000DB56D4: 0676853A
	v_sub_f32_e32 v58, v58, v66                                // 000000DB56D8: 0874853A
	v_add_f32_e32 v66, v67, v75                                // 000000DB56DC: 06849743
	v_sub_f32_e32 v67, v67, v75                                // 000000DB56E0: 08869743
	v_add_f32_e32 v75, v74, v76                                // 000000DB56E4: 0696994A
	v_add_f32_e32 v82, v68, v60                                // 000000DB56E8: 06A47944
	v_sub_f32_e32 v60, v68, v60                                // 000000DB56EC: 08787944
	v_add_f32_e32 v68, v52, v44                                // 000000DB56F0: 06885934
	v_add_f32_e32 v92, v51, v67                                // 000000DB56F4: 06B88733
	v_dual_sub_f32 v51, v51, v67 :: v_dual_sub_f32 v44, v52, v44// 000000DB56F8: C94A8733 332C5934
	v_sub_f32_e32 v83, v20, v12                                // 000000DB5700: 08A61914
	v_sub_f32_e32 v74, v74, v76                                // 000000DB5704: 0894994A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB5708: BF870214
	v_mov_b32_dpp v114, v92 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB570C: 7EE402FA FF01615C
	v_mov_b32_dpp v123, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5714: 7EF602FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000DB571C: D5010033 20026733
	v_add_f32_e32 v52, v36, v28                                // 000000DB5724: 06683924
	v_sub_f32_e32 v28, v36, v28                                // 000000DB5728: 08383924
	v_add_f32_e32 v36, v20, v12                                // 000000DB572C: 06481914
	s_clause 0x3                                               // 000000DB5730: BF850003
	global_load_d16_b16 v19, v[2:3], off offset:1408           // 000000DB5734: DC820580 137C0002
	global_load_d16_b16 v20, v[2:3], off offset:1440           // 000000DB573C: DC8205A0 147C0002
	global_load_d16_b16 v12, v[2:3], off offset:1472           // 000000DB5744: DC8205C0 0C7C0002
	global_load_d16_b16 v26, v[2:3], off offset:1504           // 000000DB574C: DC8205E0 1A7C0002
	v_add_f32_e32 v51, v51, v123                               // 000000DB5754: 0666F733
	v_cndmask_b32_e64 v92, -v92, v92, s0                       // 000000DB5758: D501005C 2002B95C
	v_add_f32_e32 v76, v82, v68                                // 000000DB5760: 06988952
	v_sub_f32_e32 v68, v82, v68                                // 000000DB5764: 08888952
	v_add_f32_e32 v82, v60, v44                                // 000000DB5768: 06A4593C
	v_sub_f32_e32 v44, v60, v44                                // 000000DB576C: 0858593C
	v_add_f32_e32 v60, v28, v83                                // 000000DB5770: 0678A71C
	v_sub_f32_e32 v28, v28, v83                                // 000000DB5774: 0838A71C
	v_mov_b32_dpp v123, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5778: 7EF602FA FF016233
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000DB5780: D5010033 20066733
	v_add_f32_e32 v90, v52, v36                                // 000000DB5788: 06B44934
	v_sub_f32_e32 v36, v52, v36                                // 000000DB578C: 08484934
	v_add_f32_e32 v83, v82, v60                                // 000000DB5790: 06A67952
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB5794: BF870194
	v_dual_sub_f32 v60, v82, v60 :: v_dual_add_f32 v51, v51, v123// 000000DB5798: C9487952 3C32F733
	v_dual_add_f32 v91, v58, v74 :: v_dual_add_f32 v82, v68, v36// 000000DB57A0: C908953A 5B524944
	v_sub_f32_e32 v36, v68, v36                                // 000000DB57A8: 08484944
	v_add_f32_e32 v68, v44, v28                                // 000000DB57AC: 0688392C
	v_sub_f32_e32 v28, v44, v28                                // 000000DB57B0: 0838392C
	v_add_f32_e32 v44, v59, v75                                // 000000DB57B4: 0658973B
	v_sub_f32_e32 v59, v59, v75                                // 000000DB57B8: 0876973B
	v_mov_b32_dpp v123, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB57BC: 7EF602FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000DB57C4: D5010033 200A6733
	v_add_f32_e32 v52, v76, v90                                // 000000DB57CC: 0668B54C
	v_cndmask_b32_e64 v75, -v83, v83, s0                       // 000000DB57D0: D501004B 2002A753
	v_mov_b32_dpp v122, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB57D8: 7EF402FA FF01613B
	v_cndmask_b32_e64 v59, -v59, v59, s0                       // 000000DB57E0: D501003B 2002773B
	v_add_f32_e32 v51, v51, v123                               // 000000DB57E8: 0666F733
	v_mov_b32_dpp v67, v52 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB57EC: 7E8602FA FF016134
	v_cndmask_b32_e64 v52, -v52, v52, s0                       // 000000DB57F4: D5010034 20026934
	v_mov_b32_dpp v115, v91 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB57FC: 7EE602FA FF01615B
	v_add_f32_e32 v59, v59, v122                               // 000000DB5804: 0676F53B
	v_mov_b32_dpp v123, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5808: 7EF602FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000DB5810: D5010033 200E6733
	v_cndmask_b32_e64 v91, -v91, v91, s0                       // 000000DB5818: D501005B 2002B75B
	v_mov_b32_dpp v108, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5820: 7ED802FA FF01612C
	v_mov_b32_dpp v122, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5828: 7EF402FA FF01623B
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000DB5830: D501003B 2006773B
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000DB5838: D501002C 2002592C
	v_add_f32_e32 v51, v51, v123                               // 000000DB5840: 0666F733
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5844: BF870113
	v_add_f32_e32 v59, v59, v122                               // 000000DB5848: 0676F53B
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000DB584C: 106666FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5854: BF8700A2
	v_mov_b32_dpp v122, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5858: 7EF402FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000DB5860: D501003B 200A773B
	v_add_f32_e32 v59, v59, v122                               // 000000DB5868: 0676F53B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB586C: BF8700A1
	v_mov_b32_dpp v122, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5870: 7EF402FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000DB5878: D501003B 200E773B
	v_dual_add_f32 v52, v52, v67 :: v_dual_add_f32 v59, v59, v122// 000000DB5880: C9088734 343AF53B
	v_sub_f32_e32 v58, v58, v74                                // 000000DB5888: 0874953A
	v_mov_b32_dpp v74, v83 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB588C: 7E9402FA FF016153
	v_mov_b32_dpp v83, v82 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5894: 7EA602FA FF016152
	v_cndmask_b32_e64 v82, -v82, v82, s0                       // 000000DB589C: D5010052 2002A552
	v_mul_f32_e32 v59, 0x3db504f3, v59                         // 000000DB58A4: 107676FF 3DB504F3
	v_mov_b32_dpp v124, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB58AC: 7EF802FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000DB58B4: D501003A 2002753A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000DB58BC: BF870254
	v_dual_add_f32 v67, v75, v74 :: v_dual_add_f32 v74, v82, v83// 000000DB58C0: C908954B 434AA752
	v_add_f32_e32 v83, v92, v114                               // 000000DB58C8: 06A6E55C
	v_sub_f32_e32 v76, v76, v90                                // 000000DB58CC: 0898B54C
	v_add_f32_e32 v90, v84, v66                                // 000000DB58D0: 06B48554
	v_add_f32_e32 v58, v58, v124                               // 000000DB58D4: 0674F93A
	v_mov_b32_dpp v114, v83 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB58D8: 7EE402FA FF016253
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB58E0: BF870004
	v_mov_b32_dpp v98, v76 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB58E4: 7EC402FA FF01614C
	v_cndmask_b32_e64 v76, -v76, v76, s0                       // 000000DB58EC: D501004C 2002994C
	v_mov_b32_dpp v107, v90 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB58F4: 7ED602FA FF01615A
	v_cndmask_b32_e64 v90, -v90, v90, s0                       // 000000DB58FC: D501005A 2002B55A
	v_mov_b32_dpp v124, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5904: 7EF802FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000DB590C: D501003A 2006753A
	v_add_f32_e32 v75, v76, v98                                // 000000DB5914: 0696C54C
	v_cndmask_b32_e64 v83, -v83, v83, s1                       // 000000DB5918: D5010053 2006A753
	v_add_f32_e32 v76, v90, v107                               // 000000DB5920: 0698D75A
	v_mov_b32_dpp v90, v67 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5924: 7EB402FA FF016243
	v_cndmask_b32_e64 v67, -v67, v67, s1                       // 000000DB592C: D5010043 20068743
	v_add_f32_e32 v58, v58, v124                               // 000000DB5934: 0674F93A
	v_mov_b32_dpp v98, v75 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5938: 7EC402FA FF01624B
	v_cndmask_b32_e64 v75, -v75, v75, s1                       // 000000DB5940: D501004B 2006974B
	v_add_f32_e32 v83, v83, v114                               // 000000DB5948: 06A6E553
	v_add_f32_e32 v67, v67, v90                                // 000000DB594C: 0686B543
	v_mov_b32_dpp v124, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5950: 7EF802FA FF01643A
	v_cndmask_b32_e64 v58, -v58, v58, s2                       // 000000DB5958: D501003A 200A753A
	v_add_f32_e32 v75, v75, v98                                // 000000DB5960: 0696C54B
	v_mov_b32_dpp v114, v83 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5964: 7EE402FA FF016453
	v_mov_b32_dpp v90, v67 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB596C: 7EB402FA FF016443
	v_cndmask_b32_e64 v67, -v67, v67, s2                       // 000000DB5974: D5010043 200A8743
	v_add_f32_e32 v58, v58, v124                               // 000000DB597C: 0674F93A
	v_cndmask_b32_e64 v83, -v83, v83, s2                       // 000000DB5980: D5010053 200AA753
	v_mov_b32_dpp v107, v76 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5988: 7ED602FA FF01624C
	v_cndmask_b32_e64 v76, -v76, v76, s1                       // 000000DB5990: D501004C 2006994C
	v_add_f32_e32 v67, v67, v90                                // 000000DB5998: 0686B543
	v_mov_b32_dpp v124, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB599C: 7EF802FA FF01683A
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000DB59A4: D501003A 200E753A
	v_mov_b32_dpp v98, v75 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB59AC: 7EC402FA FF01644B
	v_cndmask_b32_e64 v75, -v75, v75, s2                       // 000000DB59B4: D501004B 200A974B
	v_mov_b32_dpp v90, v67 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB59BC: 7EB402FA FF016843
	v_cndmask_b32_e64 v67, -v67, v67, s3                       // 000000DB59C4: D5010043 200E8743
	v_dual_add_f32 v58, v58, v124 :: v_dual_add_f32 v83, v83, v114// 000000DB59CC: C908F93A 3A52E553
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB59D4: BF870194
	v_dual_add_f32 v76, v76, v107 :: v_dual_add_f32 v75, v75, v98// 000000DB59D8: C908D74C 4C4AC54B
	v_add_f32_e32 v67, v67, v90                                // 000000DB59E0: 0686B543
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB59E4: BF870003
	v_mul_f32_e32 v58, 0x3db504f3, v58                         // 000000DB59E8: 107474FF 3DB504F3
	v_mov_b32_dpp v100, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB59F0: 7EC802FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000DB59F8: D5010024 20024924
	v_mov_b32_dpp v114, v83 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5A00: 7EE402FA FF016853
	v_cndmask_b32_e64 v83, -v83, v83, s3                       // 000000DB5A08: D5010053 200EA753
	v_mul_f32_e32 v67, 0x3db504f3, v67                         // 000000DB5A10: 108686FF 3DB504F3
	v_mov_b32_dpp v107, v76 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5A18: 7ED602FA FF01644C
	v_cndmask_b32_e64 v76, -v76, v76, s2                       // 000000DB5A20: D501004C 200A994C
	v_mov_b32_dpp v98, v75 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5A28: 7EC402FA FF01684B
	v_cndmask_b32_e64 v75, -v75, v75, s3                       // 000000DB5A30: D501004B 200E974B
	v_add_f32_e32 v83, v83, v114                               // 000000DB5A38: 06A6E553
	v_sub_f32_e32 v66, v84, v66                                // 000000DB5A3C: 08848554
	v_add_f32_e32 v76, v76, v107                               // 000000DB5A40: 0698D74C
	v_mov_b32_dpp v106, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5A44: 7ED402FA FF01611C
	v_add_f32_e32 v75, v75, v98                                // 000000DB5A4C: 0696C54B
	v_mov_b32_dpp v84, v68 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5A50: 7EA802FA FF016144
	v_cndmask_b32_e64 v68, -v68, v68, s0                       // 000000DB5A58: D5010044 20028944
	v_mul_f32_e32 v83, 0x3db504f3, v83                         // 000000DB5A60: 10A6A6FF 3DB504F3
	v_mov_b32_dpp v116, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5A68: 7EE802FA FF016142
	v_cndmask_b32_e64 v66, -v66, v66, s0                       // 000000DB5A70: D5010042 20028542
	v_mov_b32_dpp v107, v76 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5A78: 7ED602FA FF01684C
	v_add_f32_e32 v68, v68, v84                                // 000000DB5A80: 0688A944
	v_cndmask_b32_e64 v76, -v76, v76, s3                       // 000000DB5A84: D501004C 200E994C
	v_mul_f32_e32 v75, 0x3db504f3, v75                         // 000000DB5A8C: 109696FF 3DB504F3
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000DB5A94: D501001C 2002391C
	v_mov_b32_dpp v99, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB5A9C: 7EC602FA FF01613C
	v_mov_b32_dpp v92, v68 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5AA4: 7EB802FA FF016244
	v_cndmask_b32_e64 v68, -v68, v68, s1                       // 000000DB5AAC: D5010044 20068944
	v_add_f32_e32 v76, v76, v107                               // 000000DB5AB4: 0698D74C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000DB5AB8: D501003C 2002793C
	v_mov_b32_dpp v84, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5AC0: 7EA802FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000DB5AC8: D5010034 20066934
	v_add_f32_e32 v68, v68, v92                                // 000000DB5AD0: 0688B944
	v_mul_f32_e32 v76, 0x3db504f3, v76                         // 000000DB5AD4: 109898FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5ADC: BF8700A2
	v_mov_b32_dpp v92, v68 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5AE0: 7EB802FA FF016444
	v_cndmask_b32_e64 v68, -v68, v68, s2                       // 000000DB5AE8: D5010044 200A8944
	v_add_f32_e32 v68, v68, v92                                // 000000DB5AF0: 0688B944
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5AF4: BF8700A1
	v_mov_b32_dpp v92, v68 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5AF8: 7EB802FA FF016844
	v_cndmask_b32_e64 v68, -v68, v68, s3                       // 000000DB5B00: D5010044 200E8944
	v_add_f32_e32 v68, v68, v92                                // 000000DB5B08: 0688B944
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB5B0C: BF870001
	v_mul_f32_e32 v68, 0x3db504f3, v68                         // 000000DB5B10: 108888FF 3DB504F3
	s_waitcnt vmcnt(14)                                        // 000000DB5B18: BF893BF7
	v_fma_mix_f32 v10, v10, v67, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B1C: CC20000A 8A02870A
	s_waitcnt vmcnt(13)                                        // 000000DB5B24: BF8937F7
	v_fma_mix_f32 v8, v8, v76, neg(0) op_sel_hi:[1,0,0]        // 000000DB5B28: CC200008 8A029908
	s_waitcnt vmcnt(11)                                        // 000000DB5B30: BF892FF7
	v_fma_mix_f32 v11, v11, v83, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B34: CC20000B 8A02A70B
	s_waitcnt vmcnt(8)                                         // 000000DB5B3C: BF8923F7
	v_fma_mix_f32 v34, v34, v59, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B40: CC200022 8A027722
	s_waitcnt vmcnt(7)                                         // 000000DB5B48: BF891FF7
	v_fma_mix_f32 v35, v35, v51, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B4C: CC200023 8A026723
	s_waitcnt vmcnt(6)                                         // 000000DB5B54: BF891BF7
	v_fma_mix_f32 v42, v42, v58, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B58: CC20002A 8A02752A
	v_add_f32_e32 v36, v36, v100                               // 000000DB5B60: 0648C924
	v_dual_mul_f32 v51, 0xbfb8aa3b, v8 :: v_dual_add_f32 v60, v60, v99// 000000DB5B64: C8C810FF 333CC73C BFB8AA3B
	v_mul_f32_e32 v59, 0xbfb8aa3b, v34                         // 000000DB5B70: 107644FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB5B78: BF870194
	v_dual_mul_f32 v67, 0xbfb8aa3b, v42 :: v_dual_mul_f32 v76, 0xbfb8aa3b, v35// 000000DB5B7C: C8C654FF 434C46FF BFB8AA3B
	v_exp_f32_e32 v51, v51                                     // 000000DB5B88: 7E664B33
	v_add_f32_e32 v28, v28, v106                               // 000000DB5B8C: 0638D51C
	s_waitcnt vmcnt(4)                                         // 000000DB5B90: BF8913F7
	v_fma_mix_f32 v50, v50, v68, neg(0) op_sel_hi:[1,0,0]      // 000000DB5B94: CC200032 8A028932
	v_exp_f32_e32 v67, v67                                     // 000000DB5B9C: 7E864B43
	v_add_f32_e32 v66, v66, v116                               // 000000DB5BA0: 0684E942
	v_exp_f32_e32 v76, v76                                     // 000000DB5BA4: 7E984B4C
	v_exp_f32_e32 v59, v59                                     // 000000DB5BA8: 7E764B3B
	v_add_f32_e32 v44, v44, v108                               // 000000DB5BAC: 0658D92C
	v_mov_b32_dpp v100, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5BB0: 7EC802FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000DB5BB8: D5010024 20064924
	v_add_f32_e32 v51, 1.0, v51                                // 000000DB5BC0: 066666F2
	v_mov_b32_dpp v106, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5BC4: 7ED402FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000DB5BCC: D501001C 2006391C
	v_add_f32_e32 v67, 1.0, v67                                // 000000DB5BD4: 068686F2
	v_mov_b32_dpp v116, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5BD8: 7EE802FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000DB5BE0: D5010042 20068542
	v_add_f32_e32 v68, 1.0, v76                                // 000000DB5BE8: 068898F2
	v_div_scale_f32 v76, vcc_lo, v8, v51, v8                   // 000000DB5BEC: D6FC6A4C 04226708
	v_add_f32_e32 v82, v91, v115                               // 000000DB5BF4: 06A4E75B
	v_mov_b32_dpp v91, v74 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5BF8: 7EB602FA FF01624A
	v_add_f32_e32 v66, v66, v116                               // 000000DB5C00: 0684E942
	v_cndmask_b32_e64 v74, -v74, v74, s1                       // 000000DB5C04: D501004A 2006954A
	v_add_f32_e32 v59, 1.0, v59                                // 000000DB5C0C: 067676F2
	v_mov_b32_dpp v108, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5C10: 7ED802FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000DB5C18: D501002C 2006592C
	v_mov_b32_dpp v116, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5C20: 7EE802FA FF016442
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000DB5C28: D5010042 200A8542
	v_add_f32_e32 v74, v74, v91                                // 000000DB5C30: 0694B74A
	s_waitcnt vmcnt(3)                                         // 000000DB5C34: BF890FF7
	v_fma_mix_f32 v19, v19, v75, neg(0) op_sel_hi:[1,0,0]      // 000000DB5C38: CC200013 8A029713
	v_add_f32_e32 v44, v44, v108                               // 000000DB5C40: 0658D92C
	v_mov_b32_dpp v115, v82 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5C44: 7EE602FA FF016252
	v_add_f32_e32 v66, v66, v116                               // 000000DB5C4C: 0684E942
	v_mov_b32_dpp v91, v74 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5C50: 7EB602FA FF01644A
	v_cndmask_b32_e64 v74, -v74, v74, s2                       // 000000DB5C58: D501004A 200A954A
	v_mov_b32_dpp v108, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5C60: 7ED802FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000DB5C68: D501002C 200A592C
	v_mov_b32_dpp v116, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5C70: 7EE802FA FF016842
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000DB5C78: D5010042 200E8542
	v_add_f32_e32 v74, v74, v91                                // 000000DB5C80: 0694B74A
	v_cndmask_b32_e64 v82, -v82, v82, s1                       // 000000DB5C84: D5010052 2006A552
	v_add_f32_e32 v44, v44, v108                               // 000000DB5C8C: 0658D92C
	v_add_f32_e32 v36, v36, v100                               // 000000DB5C90: 0648C924
	v_add_f32_e32 v66, v66, v116                               // 000000DB5C94: 0684E942
	v_mov_b32_dpp v91, v74 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5C98: 7EB602FA FF01684A
	v_cndmask_b32_e64 v74, -v74, v74, s3                       // 000000DB5CA0: D501004A 200E954A
	v_mov_b32_dpp v108, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5CA8: 7ED802FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000DB5CB0: D501002C 200E592C
	v_mul_f32_e32 v66, 0x3db504f3, v66                         // 000000DB5CB8: 108484FF 3DB504F3
	v_mov_b32_dpp v100, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5CC0: 7EC802FA FF016424
	v_add_f32_e32 v74, v74, v91                                // 000000DB5CC8: 0694B74A
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000DB5CCC: D5010024 200A4924
	v_add_f32_e32 v44, v44, v108                               // 000000DB5CD4: 0658D92C
	v_fma_mix_f32 v27, v27, v66, neg(0) op_sel_hi:[1,0,0]      // 000000DB5CD8: CC20001B 8A02851B
	v_mov_b32_dpp v99, v60 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB5CE0: 7EC602FA FF01623C
	v_mul_f32_e32 v74, 0x3db504f3, v74                         // 000000DB5CE8: 109494FF 3DB504F3
	v_add_f32_e32 v36, v36, v100                               // 000000DB5CF0: 0648C924
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 000000DB5CF4: 105858FF 3DB504F3
	v_mul_f32_e32 v66, 0xbfb8aa3b, v27                         // 000000DB5CFC: 108436FF BFB8AA3B
	v_cndmask_b32_e64 v60, -v60, v60, s1                       // 000000DB5D04: D501003C 2006793C
	v_fma_mix_f32 v43, v43, v74, neg(0) op_sel_hi:[1,0,0]      // 000000DB5D0C: CC20002B 8A02952B
	v_add_f32_e32 v28, v28, v106                               // 000000DB5D14: 0638D51C
	v_fma_mix_f32 v9, v9, v44, neg(0) op_sel_hi:[1,0,0]        // 000000DB5D18: CC200009 8A025909
	v_exp_f32_e32 v66, v66                                     // 000000DB5D20: 7E844B42
	v_mov_b32_dpp v100, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5D24: 7EC802FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000DB5D2C: D5010024 200E4924
	v_mov_b32_dpp v106, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5D34: 7ED402FA FF01641C
	v_mul_f32_e32 v44, 0xbfb8aa3b, v9                          // 000000DB5D3C: 105812FF BFB8AA3B
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000DB5D44: D501001C 200A391C
	v_div_scale_f32 v74, null, v51, v51, v8                    // 000000DB5D4C: D6FC7C4A 04226733
	v_add_f32_e32 v36, v36, v100                               // 000000DB5D54: 0648C924
	v_mul_f32_e32 v58, 0xbfb8aa3b, v11                         // 000000DB5D58: 107416FF BFB8AA3B
	v_exp_f32_e32 v44, v44                                     // 000000DB5D60: 7E584B2C
	v_add_f32_e32 v66, 1.0, v66                                // 000000DB5D64: 068484F2
	v_add_f32_e32 v28, v28, v106                               // 000000DB5D68: 0638D51C
	v_rcp_f32_e32 v100, v74                                    // 000000DB5D6C: 7EC8554A
	v_exp_f32_e32 v58, v58                                     // 000000DB5D70: 7E744B3A
	v_div_scale_f32 v92, null, v59, v59, v34                   // 000000DB5D74: D6FC7C5C 048A773B
	v_div_scale_f32 v91, null, v66, v66, v27                   // 000000DB5D7C: D6FC7C5B 046E8542
	v_mov_b32_dpp v106, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5D84: 7ED402FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB5D8C: D501001C 200E391C
	v_div_scale_f32 v98, null, v68, v68, v35                   // 000000DB5D94: D6FC7C62 048E8944
	v_add_f32_e32 v44, 1.0, v44                                // 000000DB5D9C: 065858F2
	v_rcp_f32_e32 v114, v91                                    // 000000DB5DA0: 7EE4555B
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000DB5DA4: 104848FF 3DB504F3
	v_add_f32_e32 v28, v28, v106                               // 000000DB5DAC: 0638D51C
	v_fma_f32 v130, -v74, v100, 1.0                            // 000000DB5DB0: D6130082 23CAC94A
	v_add_f32_e32 v58, 1.0, v58                                // 000000DB5DB8: 067474F2
	v_rcp_f32_e32 v116, v98                                    // 000000DB5DBC: 7EE85562
	v_div_scale_f32 v83, s4, v9, v44, v9                       // 000000DB5DC0: D6FC0453 04265909
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000DB5DC8: 103838FF 3DB504F3
	v_fmac_f32_e32 v100, v130, v100                            // 000000DB5DD0: 56C8C982
	v_div_scale_f32 v122, s5, v11, v58, v11                    // 000000DB5DD4: D6FC057A 042E750B
	v_fma_f32 v139, -v91, v114, 1.0                            // 000000DB5DDC: D613008B 23CAE55B
	s_waitcnt vmcnt(1)                                         // 000000DB5DE4: BF8907F7
	v_fma_mix_f32 v12, v12, v36, neg(0) op_sel_hi:[1,0,0]      // 000000DB5DE8: CC20000C 8A02490C
	s_waitcnt vmcnt(0)                                         // 000000DB5DF0: BF8903F7
	v_fma_mix_f32 v26, v26, v28, neg(0) op_sel_hi:[1,0,0]      // 000000DB5DF4: CC20001A 8A02391A
	v_fmac_f32_e32 v114, v139, v114                            // 000000DB5DFC: 56E4E58B
	v_add_f32_e32 v82, v82, v115                               // 000000DB5E00: 06A4E752
	v_fma_f32 v141, -v98, v116, 1.0                            // 000000DB5E04: D613008D 23CAE962
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB5E0C: BF8701A2
	v_mov_b32_dpp v115, v82 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5E10: 7EE602FA FF016452
	v_cndmask_b32_e64 v82, -v82, v82, s2                       // 000000DB5E18: D5010052 200AA552
	v_fmac_f32_e32 v116, v141, v116                            // 000000DB5E20: 56E8E98D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5E24: BF870092
	v_add_f32_e32 v82, v82, v115                               // 000000DB5E28: 06A4E752
	v_mov_b32_dpp v115, v82 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5E2C: 7EE602FA FF016852
	v_cndmask_b32_e64 v82, -v82, v82, s3                       // 000000DB5E34: D5010052 200EA552
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5E3C: BF8700A1
	v_add_f32_e32 v82, v82, v115                               // 000000DB5E40: 06A4E752
	v_rcp_f32_e32 v115, v92                                    // 000000DB5E44: 7EE6555C
	v_mul_f32_e32 v82, 0x3db504f3, v82                         // 000000DB5E48: 10A4A4FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB5E50: BF8702A1
	v_fma_mix_f32 v18, v18, v82, neg(0) op_sel_hi:[1,0,0]      // 000000DB5E54: CC200012 8A02A512
	v_div_scale_f32 v82, null, v44, v44, v9                    // 000000DB5E5C: D6FC7C52 0426592C
	v_fma_f32 v140, -v92, v115, 1.0                            // 000000DB5E64: D613008C 23CAE75C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5E6C: BF870092
	v_rcp_f32_e32 v106, v82                                    // 000000DB5E70: 7ED45552
	v_fmac_f32_e32 v115, v140, v115                            // 000000DB5E74: 56E6E78C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5E78: BF870095
	v_fma_f32 v131, -v82, v106, 1.0                            // 000000DB5E7C: D6130083 23CAD552
	v_dual_fmac_f32 v106, v131, v106 :: v_dual_mul_f32 v131, v76, v100// 000000DB5E84: C806D583 6A82C94C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5E8C: BF870091
	v_fma_f32 v139, -v74, v131, v76                            // 000000DB5E90: D613008B 2533074A
	v_fmac_f32_e32 v131, v139, v100                            // 000000DB5E98: 5706C98B
	v_div_scale_f32 v139, s7, v27, v66, v27                    // 000000DB5E9C: D6FC078B 046E851B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5EA4: BF870092
	v_fma_f32 v74, -v74, v131, v76                             // 000000DB5EA8: D613004A 2533074A
	v_div_fmas_f32 v74, v74, v100, v131                        // 000000DB5EB0: D637004A 060EC94A
	s_mov_b32 vcc_lo, s4                                       // 000000DB5EB8: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB5EBC: BE84007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5EC0: BF8700A1
	v_div_fixup_f32 v8, v74, v51, v8                           // 000000DB5EC4: D6270008 0422674A
	v_add_f32_e32 v60, v60, v99                                // 000000DB5ECC: 0678C73C
	v_mov_b32_dpp v99, v60 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5ED0: 7EC602FA FF01643C
	v_cndmask_b32_e64 v60, -v60, v60, s2                       // 000000DB5ED8: D501003C 200A793C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5EE0: BF870091
	v_add_f32_e32 v60, v60, v99                                // 000000DB5EE4: 0678C73C
	v_mov_b32_dpp v99, v60 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5EE8: 7EC602FA FF01683C
	v_cndmask_b32_e64 v60, -v60, v60, s3                       // 000000DB5EF0: D501003C 200E793C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB5EF8: BF870121
	v_add_f32_e32 v60, v60, v99                                // 000000DB5EFC: 0678C73C
	v_div_scale_f32 v99, null, v67, v67, v42                   // 000000DB5F00: D6FC7C63 04AA8743
	v_mul_f32_e32 v60, 0x3db504f3, v60                         // 000000DB5F08: 107878FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5F10: BF870092
	v_rcp_f32_e32 v123, v99                                    // 000000DB5F14: 7EF65563
	v_fma_mix_f32 v20, v20, v60, neg(0) op_sel_hi:[1,0,0]      // 000000DB5F18: CC200014 8A027914
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5F20: BF870095
	v_fma_f32 v130, -v99, v123, 1.0                            // 000000DB5F24: D6130082 23CAF763
	v_dual_add_f32 v52, v52, v84 :: v_dual_fmac_f32 v123, v130, v123// 000000DB5F2C: C900A934 347AF782
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5F34: BF8700A1
	v_mov_b32_dpp v84, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB5F38: 7EA802FA FF016434
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000DB5F40: D5010034 200A6934
	v_add_f32_e32 v52, v52, v84                                // 000000DB5F48: 0668A934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB5F4C: BF8700A1
	v_mov_b32_dpp v84, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB5F50: 7EA802FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000DB5F58: D5010034 200E6934
	v_add_f32_e32 v52, v52, v84                                // 000000DB5F60: 0668A934
	v_div_scale_f32 v84, null, v58, v58, v11                   // 000000DB5F64: D6FC7C54 042E753A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5F6C: BF870112
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000DB5F70: 106868FF 3DB504F3
	v_rcp_f32_e32 v107, v84                                    // 000000DB5F78: 7ED65554
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5F7C: BF870091
	v_fma_mix_f32 v7, v7, v52, neg(0) op_sel_hi:[1,0,0]        // 000000DB5F80: CC200007 8A026907
	v_dual_mul_f32 v52, 0xbfb8aa3b, v18 :: v_dual_mul_f32 v7, v7, v8// 000000DB5F88: C8C624FF 34061107 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB5F94: BF870311
	v_exp_f32_e32 v52, v52                                     // 000000DB5F98: 7E684B34
	v_fma_f32 v132, -v84, v107, 1.0                            // 000000DB5F9C: D6130084 23CAD754
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB5FA4: BF870291
	v_dual_fmac_f32 v107, v132, v107 :: v_dual_mul_f32 v132, v83, v106// 000000DB5FA8: C806D784 6B84D553
	v_add_f32_e32 v52, 1.0, v52                                // 000000DB5FB0: 066868F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5FB4: BF870112
	v_fma_f32 v140, -v82, v132, v83                            // 000000DB5FB8: D613008C 254F0952
	v_div_scale_f32 v90, null, v52, v52, v18                   // 000000DB5FC0: D6FC7C5A 044A6934
	v_div_scale_f32 v124, s6, v18, v52, v18                    // 000000DB5FC8: D6FC067C 044A6912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB5FD0: BF870193
	v_fmac_f32_e32 v132, v140, v106                            // 000000DB5FD4: 5708D58C
	v_rcp_f32_e32 v108, v90                                    // 000000DB5FD8: 7ED8555A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB5FDC: BF870091
	v_fma_f32 v76, -v82, v132, v83                             // 000000DB5FE0: D613004C 254F0952
	v_div_fmas_f32 v76, v76, v106, v132                        // 000000DB5FE8: D637004C 0612D54C
	s_mov_b32 vcc_lo, s5                                       // 000000DB5FF0: BEEA0005
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB5FF4: BE8500FF 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB5FFC: BF870115
	v_fma_f32 v138, -v90, v108, 1.0                            // 000000DB6000: D613008A 23CAD95A
	v_div_fixup_f32 v9, v76, v44, v9                           // 000000DB6008: D6270009 0426594C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB6010: BF870122
	v_fmac_f32_e32 v108, v138, v108                            // 000000DB6014: 56D8D98A
	v_mul_f32_e32 v138, v122, v107                             // 000000DB6018: 1114D77A
	v_dual_mul_f32 v9, v10, v9 :: v_dual_mul_f32 v130, v124, v108// 000000DB601C: C8C6130A 0982D97C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB6024: BF870112
	v_fma_f32 v141, -v84, v138, v122                           // 000000DB6028: D613008D 25EB1554
	v_fma_f32 v140, -v90, v130, v124                           // 000000DB6030: D613008C 25F3055A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB6038: BF870112
	v_dual_fmac_f32 v138, v141, v107 :: v_dual_mul_f32 v141, v139, v114// 000000DB603C: C806D78D 8A8CE58B
	v_fmac_f32_e32 v130, v140, v108                            // 000000DB6044: 5704D98C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6048: BF870192
	v_fma_f32 v82, -v84, v138, v122                            // 000000DB604C: D6130052 25EB1554
	v_fma_f32 v140, -v91, v141, v139                           // 000000DB6054: D613008C 262F1B5B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB605C: BF870193
	v_fma_f32 v83, -v90, v130, v124                            // 000000DB6060: D6130053 25F3055A
	v_div_fmas_f32 v82, v82, v107, v138                        // 000000DB6068: D6370052 062AD752
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB6070: BF870003
	v_fmac_f32_e32 v141, v140, v114                            // 000000DB6074: 571AE58C
	v_div_scale_f32 v140, s8, v34, v59, v34                    // 000000DB6078: D6FC088C 048A7722
	s_mov_b32 vcc_lo, s6                                       // 000000DB6080: BEEA0006
	v_div_fmas_f32 v51, v83, v108, v130                        // 000000DB6084: D6370033 060AD953
	v_fma_f32 v84, -v91, v141, v139                            // 000000DB608C: D6130054 262F1B5B
	v_mul_f32_e32 v142, v140, v115                             // 000000DB6094: 111CE78C
	global_load_d16_b16 v91, v[4:5], off offset:32             // 000000DB6098: DC820020 5B7C0004
	s_mov_b32 vcc_lo, s7                                       // 000000DB60A0: BEEA0007
	v_div_fixup_f32 v11, v82, v58, v11                         // 000000DB60A4: D627000B 042E7552
	v_div_fmas_f32 v44, v84, v114, v141                        // 000000DB60AC: D637002C 0636E554
	v_fma_f32 v143, -v92, v142, v140                           // 000000DB60B4: D613008F 26331D5C
	s_mov_b32 vcc_lo, s8                                       // 000000DB60BC: BEEA0008
	v_div_fixup_f32 v8, v51, v52, v18                          // 000000DB60C0: D6270008 044A6933
	v_mul_f32_e32 v11, v43, v11                                // 000000DB60C8: 1016172B
	v_div_fixup_f32 v27, v44, v66, v27                         // 000000DB60CC: D627001B 046E852C
	v_fmac_f32_e32 v142, v143, v115                            // 000000DB60D4: 571CE78F
	v_div_scale_f32 v143, s9, v35, v68, v35                    // 000000DB60D8: D6FC098F 048E8923
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB60E0: BF870193
	v_dual_mul_f32 v8, v50, v8 :: v_dual_mul_f32 v19, v19, v27 // 000000DB60E4: C8C61132 08123713
	v_fma_f32 v90, -v92, v142, v140                            // 000000DB60EC: D613005A 26331D5C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB60F4: BF870113
	v_mul_f32_e32 v144, v143, v116                             // 000000DB60F8: 1120E98F
	v_div_fmas_f32 v10, v90, v115, v142                        // 000000DB60FC: D637000A 063AE75A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB6104: BF870122
	v_fma_f32 v145, -v98, v144, v143                           // 000000DB6108: D6130091 263F2162
	s_mov_b32 vcc_lo, s9                                       // 000000DB6110: BEEA0009
	v_div_fixup_f32 v10, v10, v59, v34                         // 000000DB6114: D627000A 048A770A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB611C: BF8701A2
	v_fmac_f32_e32 v144, v145, v116                            // 000000DB6120: 5720E991
	v_div_scale_f32 v145, s10, v42, v67, v42                   // 000000DB6124: D6FC0A91 04AA872A
	v_mul_f32_e32 v10, v20, v10                                // 000000DB612C: 10141514
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB6130: BF870003
	v_fma_f32 v92, -v98, v144, v143                            // 000000DB6134: D613005C 263F2162
	s_clause 0x6                                               // 000000DB613C: BF850006
	global_load_d16_b16 v98, v[4:5], off offset:96             // 000000DB6140: DC820060 627C0004
	global_load_d16_b16 v100, v[4:5], off offset:160           // 000000DB6148: DC8200A0 647C0004
	global_load_d16_b16 v106, v[4:5], off offset:224           // 000000DB6150: DC8200E0 6A7C0004
	global_load_d16_b16 v107, v[4:5], off offset:192           // 000000DB6158: DC8200C0 6B7C0004
	global_load_d16_b16 v122, v[4:5], off offset:128           // 000000DB6160: DC820080 7A7C0004
	global_load_d16_b16 v124, v[4:5], off offset:64            // 000000DB6168: DC820040 7C7C0004
	global_load_d16_b16 v131, v[4:5], off                      // 000000DB6170: DC820000 837C0004
	v_mul_f32_e32 v146, v145, v123                             // 000000DB6178: 1124F791
	v_div_fmas_f32 v43, v92, v116, v144                        // 000000DB617C: D637002B 0642E95C
	s_mov_b32 vcc_lo, s10                                      // 000000DB6184: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB6188: BF870112
	v_fma_f32 v147, -v99, v146, v145                           // 000000DB618C: D6130093 26472563
	v_div_fixup_f32 v20, v43, v68, v35                         // 000000DB6194: D6270014 048E892B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB619C: BF870112
	v_fmac_f32_e32 v146, v147, v123                            // 000000DB61A0: 5724F793
	v_mul_f32_e32 v12, v12, v20                                // 000000DB61A4: 1018290C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB61A8: BF870092
	v_fma_f32 v18, -v99, v146, v145                            // 000000DB61AC: D6130012 26472563
	v_div_fmas_f32 v18, v18, v123, v146                        // 000000DB61B4: D6370012 064AF712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB61BC: BF870091
	v_div_fixup_f32 v18, v18, v67, v42                         // 000000DB61C0: D6270012 04AA8712
	v_mul_f32_e32 v18, v26, v18                                // 000000DB61C8: 1024251A
	s_waitcnt vmcnt(7)                                         // 000000DB61CC: BF891FF7
	v_fma_mix_f32 v9, v91, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB61D0: CC200009 8A02135B
	s_waitcnt vmcnt(6)                                         // 000000DB61D8: BF891BF7
	v_fma_mix_f32 v8, v98, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB61DC: CC200008 8A021162
	s_waitcnt vmcnt(5)                                         // 000000DB61E4: BF8917F7
	v_fma_mix_f32 v10, v100, v10, neg(0) op_sel_hi:[1,0,0]     // 000000DB61E8: CC20000A 8A021564
	s_waitcnt vmcnt(4)                                         // 000000DB61F0: BF8913F7
	v_fma_mix_f32 v18, v106, v18, neg(0) op_sel_hi:[1,0,0]     // 000000DB61F4: CC200012 8A02256A
	s_waitcnt vmcnt(1)                                         // 000000DB61FC: BF8907F7
	v_fma_mix_f32 v26, v11, v124, v8 op_sel_hi:[0,1,0]         // 000000DB6200: CC20001A 1422F90B
	s_waitcnt vmcnt(0)                                         // 000000DB6208: BF8903F7
	v_fma_mix_f32 v20, v7, v131, v9 op_sel_hi:[0,1,0]          // 000000DB620C: CC200014 14270707
	v_fma_mix_f32 v27, v19, v122, v10 op_sel_hi:[0,1,0]        // 000000DB6214: CC20001B 142AF513
	v_fma_mix_f32 v28, v12, v107, v18 op_sel_hi:[0,1,0]        // 000000DB621C: CC20001C 144AD70C
	v_fma_mix_f32 v7, v7, v131, -v9 op_sel_hi:[0,1,0]          // 000000DB6224: CC200007 94270707
	v_fma_mix_f32 v8, v11, v124, -v8 op_sel_hi:[0,1,0]         // 000000DB622C: CC200008 9422F90B
	v_add_f32_e32 v34, v20, v26                                // 000000DB6234: 06443514
	v_fma_mix_f32 v10, v19, v122, -v10 op_sel_hi:[0,1,0]       // 000000DB6238: CC20000A 942AF513
	v_add_f32_e32 v35, v27, v28                                // 000000DB6240: 0646391B
	v_fma_mix_f32 v11, v12, v107, -v18 op_sel_hi:[0,1,0]       // 000000DB6244: CC20000B 944AD70C
	v_sub_f32_e32 v12, v20, v26                                // 000000DB624C: 08183514
	v_add_f32_e32 v18, v7, v8                                  // 000000DB6250: 06241107
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB6254: 080E1107
	v_add_f32_e32 v9, v34, v35                                 // 000000DB6258: 06124722
	v_add_f32_e32 v8, v10, v11                                 // 000000DB625C: 0610170A
	v_sub_f32_e32 v20, v27, v28                                // 000000DB6260: 0828391B
	v_sub_f32_e32 v10, v10, v11                                // 000000DB6264: 0814170A
	v_sub_f32_e32 v11, v34, v35                                // 000000DB6268: 08164722
	v_mov_b32_dpp v19, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB626C: 7E2602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB6274: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB627C: BF870113
	v_cndmask_b32_e64 v35, -v11, v11, s0                       // 000000DB6280: D5010023 2002170B
	v_add_f32_e32 v9, v9, v19                                  // 000000DB6288: 06122709
	v_add_f32_e32 v19, v18, v8                                 // 000000DB628C: 06261112
	v_sub_f32_e32 v18, v18, v8                                 // 000000DB6290: 08241112
	v_add_f32_e32 v8, v12, v20                                 // 000000DB6294: 0610290C
	v_sub_f32_e32 v20, v12, v20                                // 000000DB6298: 0828290C
	v_mov_b32_dpp v26, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB629C: 7E3402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB62A4: D5010009 20061309
	v_mov_b32_dpp v27, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB62AC: 7E3602FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB62B4: D5010013 20022713
	v_mov_b32_dpp v28, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB62BC: 7E3802FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB62C4: D5010008 20021108
	v_add_f32_e32 v9, v9, v26                                  // 000000DB62CC: 06123509
	v_mov_b32_dpp v36, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB62D0: 7E4802FA FF016114
	v_add_f32_e32 v12, v19, v27                                // 000000DB62D8: 06183713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB62DC: BF870214
	v_dual_add_f32 v19, v7, v10 :: v_dual_add_f32 v8, v8, v28  // 000000DB62E0: C9081507 13083908
	v_mov_b32_dpp v26, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB62E8: 7E3402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DB62F0: D5010009 200A1309
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB62F8: BF870004
	v_mov_b32_dpp v27, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB62FC: 7E3602FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB6304: D501000C 2006190C
	v_mov_b32_dpp v28, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB630C: 7E3802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB6314: D5010008 20061108
	v_mov_b32_dpp v34, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB631C: 7E4402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB6324: D5010013 20022713
	v_dual_add_f32 v12, v12, v27 :: v_dual_sub_f32 v27, v7, v10// 000000DB632C: C90A370C 0C1A1507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6334: BF870194
	v_dual_add_f32 v8, v8, v28 :: v_dual_add_f32 v7, v9, v26   // 000000DB6338: C9083908 08063509
	v_add_f32_e32 v9, v19, v34                                 // 000000DB6340: 06124513
	v_mov_b32_dpp v34, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6344: 7E4402FA FF01610B
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000DB634C: D5010014 20022914
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB6354: BF870004
	v_mov_b32_dpp v19, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6358: 7E2602FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB6360: D5010008 200A1108
	v_mov_b32_dpp v26, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6368: 7E3402FA FF016209
	v_cndmask_b32_e64 v28, -v9, v9, s1                         // 000000DB6370: D501001C 20061309
	v_mov_b32_dpp v42, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6378: 7E5402FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000DB6380: D501001B 2002371B
	v_add_f32_e32 v11, v8, v19                                 // 000000DB6388: 06162708
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB638C: 7E1402FA FF01640C
	v_add_f32_e32 v19, v28, v26                                // 000000DB6394: 0626351C
	v_add_f32_e32 v26, v35, v34                                // 000000DB6398: 06344523
	v_mov_b32_dpp v35, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB639C: 7E4602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB63A4: D5010012 20022512
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DB63AC: D501000C 200A190C
	v_mov_b32_dpp v28, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB63B4: 7E3802FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000DB63BC: D5010013 200A2713
	v_mov_b32_dpp v34, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB63C4: 7E4402FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB63CC: D501001A 2006351A
	v_add_f32_e32 v35, v18, v35                                // 000000DB63D4: 06464712
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB63D8: BF870194
	v_dual_add_f32 v9, v12, v10 :: v_dual_add_f32 v18, v19, v28// 000000DB63DC: C908150C 09123913
	v_dual_add_f32 v19, v20, v36 :: v_dual_add_f32 v20, v26, v34// 000000DB63E4: C9084914 1314451A
	v_add_f32_e32 v26, v27, v42                                // 000000DB63EC: 0634551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB63F0: BF870224
	v_mov_b32_dpp v27, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB63F4: 7E3602FA FF016223
	v_cndmask_b32_e64 v28, -v35, v35, s1                       // 000000DB63FC: D501001C 20064723
	v_mov_b32_dpp v34, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6404: 7E4402FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000DB640C: D5010013 20062713
	v_mov_b32_dpp v35, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6414: 7E4602FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB641C: D501001A 2006351A
	v_add_f32_e32 v27, v28, v27                                // 000000DB6424: 0636371C
	v_mov_b32_dpp v28, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6428: 7E3802FA FF016414
	v_add_f32_e32 v19, v19, v34                                // 000000DB6430: 06264513
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000DB6434: D5010014 200A2914
	v_add_f32_e32 v26, v26, v35                                // 000000DB643C: 0634471A
	v_mov_b32_dpp v34, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6440: 7E4402FA FF01641B
	v_cndmask_b32_e64 v35, -v27, v27, s2                       // 000000DB6448: D5010023 200A371B
	v_mov_b32_dpp v36, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6450: 7E4802FA FF016413
	v_cndmask_b32_e64 v42, -v19, v19, s2                       // 000000DB6458: D501002A 200A2713
	v_mov_b32_dpp v43, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6460: 7E5602FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000DB6468: D501001A 200A351A
	v_dual_add_f32 v27, v20, v28 :: v_dual_add_f32 v28, v35, v34// 000000DB6470: C9083914 1B1C4523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB6478: BF870224
	v_add_f32_e32 v35, v42, v36                                // 000000DB647C: 0646492A
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6480: 7E1002FA FF016807
	v_add_f32_e32 v42, v26, v43                                // 000000DB6488: 0654571A
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB648C: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6494: 7E1802FA FF01680B
	v_mov_b32_dpp v19, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB649C: 7E2602FA FF016812
	v_add_nc_u32_e32 v20, 4, v6                                // 000000DB64A4: 4A280C84
	v_mov_b32_dpp v26, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB64A8: 7E3402FA FF01681B
	v_mov_b32_dpp v34, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB64B0: 7E4402FA FF01681C
	v_mov_b32_dpp v36, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB64B8: 7E4802FA FF016823
	v_mov_b32_dpp v43, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB64C0: 7E5602FA FF01682A
	.long 0xd4c4007e                                           // 000000DB64C8: D4C4007E
	v_cndmask_b32_e32 v1, s23, v20, vcc_lo                     // 000000DB64CC: 02022817
	s_cbranch_execz 60                                         // 000000DB64D0: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x39c4>
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB64D4: D501001C 200E391C
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB64DC: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB64E4: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DB64EC: D501000B 200E170B
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000DB64F4: D5010012 200E2512
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000DB64FC: D501001B 200E371B
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB6504: D501002A 200E552A
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB650C: D5010023 200E4723
	v_dual_add_f32 v28, v28, v34 :: v_dual_add_f32 v7, v7, v8  // 000000DB6514: C908451C 1C061107
	v_dual_add_f32 v8, v9, v10 :: v_dual_add_f32 v9, v11, v12  // 000000DB651C: C9081509 0808190B
	v_mad_i64_i32 v[11:12], null, 0x500, v20, v[0:1]           // 000000DB6524: D6FF7C0B 040228FF 00000500
	v_add_f32_e32 v10, v18, v19                                // 000000DB6530: 06142712
	v_add_f32_e32 v26, v27, v26                                // 000000DB6534: 0634351B
	v_dual_add_f32 v42, v42, v43 :: v_dual_add_f32 v35, v35, v36// 000000DB6538: C908572A 2A224923
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB6540: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB6548: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB6550: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000DB6558: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v26, s5, 0                             // 000000DB6560: CC210009 02000B1A
	v_fma_mixhi_f16 v9, v28, s5, 0                             // 000000DB6568: CC220009 02000B1C
	v_fma_mixlo_f16 v10, v35, s5, 0                            // 000000DB6570: CC21000A 02000B23
	v_fma_mixhi_f16 v10, v42, s5, 0                            // 000000DB6578: CC22000A 02000B2A
	s_clause 0x7                                               // 000000DB6580: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000DB6584: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000DB658C: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000DB6594: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000DB659C: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000DB65A4: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000DB65AC: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000DB65B4: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000DB65BC: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB65C4: 8C7E047E
	s_clause 0xb                                               // 000000DB65C8: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB65CC: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB65D4: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB65DC: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB65E4: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DB65EC: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000DB65F4: DC820060 0C7C0002
	global_load_d16_b16 v26, v[2:3], off offset:128            // 000000DB65FC: DC820080 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:160            // 000000DB6604: DC8200A0 1B7C0002
	global_load_d16_b16 v28, v[2:3], off offset:192            // 000000DB660C: DC8200C0 1C7C0002
	global_load_d16_b16 v34, v[2:3], off offset:224            // 000000DB6614: DC8200E0 227C0002
	global_load_d16_b16 v35, v[2:3], off offset:1344           // 000000DB661C: DC820540 237C0002
	global_load_d16_b16 v36, v[2:3], off offset:1376           // 000000DB6624: DC820560 247C0002
	v_add_f32_e32 v66, v53, v45                                // 000000DB662C: 06845B35
	v_sub_f32_e32 v45, v53, v45                                // 000000DB6630: 085A5B35
	v_add_f32_e32 v53, v37, v29                                // 000000DB6634: 066A3B25
	v_sub_f32_e32 v29, v37, v29                                // 000000DB6638: 083A3B25
	v_add_f32_e32 v37, v21, v13                                // 000000DB663C: 064A1B15
	v_add_f32_e32 v51, v101, v93                               // 000000DB6640: 0666BB65
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DB6644: BF870002
	v_add_f32_e32 v68, v53, v37                                // 000000DB6648: 06884B35
	v_add_f32_e32 v58, v85, v77                                // 000000DB664C: 06749B55
	v_add_f32_e32 v44, v117, v109                              // 000000DB6650: 0658DB75
	v_sub_f32_e32 v43, v133, v125                              // 000000DB6654: 0856FB85
	v_sub_f32_e32 v50, v117, v109                              // 000000DB6658: 0864DB75
	v_add_f32_e32 v42, v133, v125                              // 000000DB665C: 0654FB85
	v_sub_f32_e32 v59, v85, v77                                // 000000DB6660: 08769B55
	v_add_f32_e32 v60, v69, v61                                // 000000DB6664: 06787B45
	v_sub_f32_e32 v52, v101, v93                               // 000000DB6668: 0868BB65
	v_sub_f32_e32 v61, v69, v61                                // 000000DB666C: 087A7B45
	v_add_f32_e32 v67, v42, v44                                // 000000DB6670: 0686592A
	v_sub_f32_e32 v42, v42, v44                                // 000000DB6674: 0854592A
	v_add_f32_e32 v44, v43, v50                                // 000000DB6678: 0658652B
	v_sub_f32_e32 v43, v43, v50                                // 000000DB667C: 0856652B
	v_add_f32_e32 v50, v51, v58                                // 000000DB6680: 06647533
	v_dual_sub_f32 v51, v51, v58 :: v_dual_add_f32 v58, v52, v59// 000000DB6684: C9487533 333A7734
	v_sub_f32_e32 v21, v21, v13                                // 000000DB668C: 082A1B15
	s_clause 0x3                                               // 000000DB6690: BF850003
	global_load_d16_b16 v18, v[2:3], off offset:1408           // 000000DB6694: DC820580 127C0002
	global_load_d16_b16 v19, v[2:3], off offset:1440           // 000000DB669C: DC8205A0 137C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000DB66A4: DC8205C0 0D7C0002
	global_load_d16_b16 v20, v[2:3], off offset:1504           // 000000DB66AC: DC8205E0 147C0002
	v_sub_f32_e32 v52, v52, v59                                // 000000DB66B4: 08687734
	v_dual_add_f32 v59, v60, v66 :: v_dual_add_f32 v74, v42, v51// 000000DB66B8: C908853C 3B4A672A
	v_dual_sub_f32 v37, v53, v37 :: v_dual_sub_f32 v42, v42, v51// 000000DB66C0: C94A4B35 252A672A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB66C8: BF870193
	v_add_f32_e32 v69, v43, v52                                // 000000DB66CC: 068A692B
	v_dual_sub_f32 v53, v59, v68 :: v_dual_sub_f32 v60, v60, v66// 000000DB66D0: C94A893B 353C853C
	v_add_f32_e32 v66, v61, v45                                // 000000DB66D8: 06845B3D
	v_sub_f32_e32 v45, v61, v45                                // 000000DB66DC: 085A5B3D
	v_add_f32_e32 v61, v29, v21                                // 000000DB66E0: 067A2B1D
	v_sub_f32_e32 v21, v29, v21                                // 000000DB66E4: 082A2B1D
	v_sub_f32_e32 v43, v43, v52                                // 000000DB66E8: 0856692B
	v_add_f32_e32 v29, v59, v68                                // 000000DB66EC: 063A893B
	v_add_f32_e32 v68, v67, v50                                // 000000DB66F0: 06886543
	v_sub_f32_e32 v50, v67, v50                                // 000000DB66F4: 08646543
	v_mov_b32_dpp v75, v53 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB66F8: 7E9602FA FF016135
	v_cndmask_b32_e64 v53, -v53, v53, s0                       // 000000DB6700: D5010035 20026B35
	v_mov_b32_dpp v51, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6708: 7E6602FA FF01611D
	v_mov_b32_dpp v83, v68 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6710: 7EA602FA FF016144
	v_cndmask_b32_e64 v68, -v68, v68, s0                       // 000000DB6718: D5010044 20028944
	v_add_f32_e32 v59, v66, v61                                // 000000DB6720: 06767B42
	v_sub_f32_e32 v61, v66, v61                                // 000000DB6724: 087A7B42
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000DB6728: D501001D 20023B1D
	v_add_f32_e32 v66, v60, v37                                // 000000DB6730: 06844B3C
	v_mov_b32_dpp v91, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6734: 7EB602FA FF016132
	v_mov_b32_dpp v52, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB673C: 7E6802FA FF01613B
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000DB6744: D5010032 20026532
	v_sub_f32_e32 v37, v60, v37                                // 000000DB674C: 084A4B3C
	v_add_f32_e32 v60, v45, v21                                // 000000DB6750: 06782B2D
	v_sub_f32_e32 v21, v45, v21                                // 000000DB6754: 082A2B2D
	v_add_f32_e32 v45, v44, v58                                // 000000DB6758: 065A752C
	v_sub_f32_e32 v44, v44, v58                                // 000000DB675C: 0858752C
	v_cndmask_b32_e64 v58, -v59, v59, s0                       // 000000DB6760: D501003A 2002773B
	v_add_f32_e32 v29, v29, v51                                // 000000DB6768: 063A671D
	v_mov_b32_dpp v85, v74 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB676C: 7EAA02FA FF01614A
	v_cndmask_b32_e64 v74, -v74, v74, s0                       // 000000DB6774: D501004A 2002954A
	v_mov_b32_dpp v92, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB677C: 7EB802FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000DB6784: D501002C 2002592C
	v_add_f32_e32 v51, v58, v52                                // 000000DB678C: 0666693A
	v_mov_b32_dpp v67, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6790: 7E8602FA FF01613C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000DB6798: D501003C 2002793C
	v_mov_b32_dpp v93, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB67A0: 7EBA02FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000DB67A8: D501002A 2002552A
	v_add_f32_e32 v44, v44, v92                                // 000000DB67B0: 0658B92C
	v_mov_b32_dpp v76, v61 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB67B4: 7E9802FA FF01613D
	v_cndmask_b32_e64 v61, -v61, v61, s0                       // 000000DB67BC: D501003D 20027B3D
	v_add_f32_e32 v58, v60, v67                                // 000000DB67C4: 0674873C
	v_add_f32_e32 v60, v68, v83                                // 000000DB67C8: 0678A744
	v_mov_b32_dpp v59, v66 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB67CC: 7E7602FA FF016142
	v_cndmask_b32_e64 v66, -v66, v66, s0                       // 000000DB67D4: D5010042 20028542
	v_add_f32_e32 v53, v53, v75                                // 000000DB67DC: 066A9735
	v_add_f32_e32 v50, v50, v91                                // 000000DB67E0: 0664B732
	v_add_f32_e32 v42, v42, v93                                // 000000DB67E4: 0654BB2A
	v_mov_b32_dpp v77, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB67E8: 7E9A02FA FF016125
	v_dual_add_f32 v52, v66, v59 :: v_dual_add_f32 v59, v61, v76// 000000DB67F0: C9087742 343A993D
	v_add_f32_e32 v66, v74, v85                                // 000000DB67F8: 0684AB4A
	v_mov_b32_dpp v74, v58 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB67FC: 7E9402FA FF01623A
	v_cndmask_b32_e64 v58, -v58, v58, s1                       // 000000DB6804: D501003A 2006753A
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000DB680C: D5010025 20024B25
	v_mov_b32_dpp v84, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6814: 7EA802FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000DB681C: D501002D 20025B2D
	v_mov_b32_dpp v90, v69 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6824: 7EB402FA FF016145
	v_cndmask_b32_e64 v69, -v69, v69, s0                       // 000000DB682C: D5010045 20028B45
	v_mov_b32_dpp v98, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6834: 7EC402FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000DB683C: D501002B 2002572B
	v_mov_b32_dpp v67, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6844: 7E8602FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000DB684C: D501001D 20063B1D
	v_mov_b32_dpp v83, v60 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6854: 7EA602FA FF01623C
	v_cndmask_b32_e64 v60, -v60, v60, s1                       // 000000DB685C: D501003C 2006793C
	v_mov_b32_dpp v85, v66 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6864: 7EAA02FA FF016242
	v_cndmask_b32_e64 v66, -v66, v66, s1                       // 000000DB686C: D5010042 20068542
	v_mov_b32_dpp v91, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6874: 7EB602FA FF016232
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000DB687C: D5010032 20066532
	v_mov_b32_dpp v93, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6884: 7EBA02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DB688C: D501002A 2006552A
	v_add_f32_e32 v58, v58, v74                                // 000000DB6894: 0674953A
	v_mov_b32_dpp v82, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB6898: 7EA402FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000DB68A0: D5010015 20022B15
	v_dual_add_f32 v37, v37, v77 :: v_dual_add_f32 v60, v60, v83// 000000DB68A8: C9089B25 253CA73C
	v_dual_add_f32 v45, v45, v84 :: v_dual_add_f32 v66, v66, v85// 000000DB68B0: C908A92D 2D42AB42
	v_dual_add_f32 v43, v43, v98 :: v_dual_add_f32 v50, v50, v91// 000000DB68B8: C908C52B 2B32B732
	v_mov_b32_dpp v76, v59 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB68C0: 7E9802FA FF01623B
	v_cndmask_b32_e64 v59, -v59, v59, s1                       // 000000DB68C8: D501003B 2006773B
	v_mov_b32_dpp v92, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB68D0: 7EB802FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000DB68D8: D501002C 2006592C
	v_add_f32_e32 v61, v69, v90                                // 000000DB68E0: 067AB545
	v_mov_b32_dpp v69, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB68E4: 7E8A02FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000DB68EC: D5010034 20066934
	v_add_f32_e32 v21, v21, v82                                // 000000DB68F4: 062AA515
	v_dual_add_f32 v29, v29, v67 :: v_dual_add_f32 v42, v42, v93// 000000DB68F8: C908871D 1D2ABB2A
	v_mov_b32_dpp v75, v53 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6900: 7E9602FA FF016235
	v_cndmask_b32_e64 v53, -v53, v53, s1                       // 000000DB6908: D5010035 20066B35
	v_mov_b32_dpp v84, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6910: 7EA802FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000DB6918: D501002D 20065B2D
	v_add_f32_e32 v52, v52, v69                                // 000000DB6920: 06688B34
	v_mov_b32_dpp v82, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6924: 7EA402FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000DB692C: D5010015 20062B15
	v_add_f32_e32 v44, v44, v92                                // 000000DB6934: 0658B92C
	v_mov_b32_dpp v90, v61 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6938: 7EB402FA FF01623D
	v_cndmask_b32_e64 v61, -v61, v61, s1                       // 000000DB6940: D501003D 20067B3D
	v_mov_b32_dpp v74, v58 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6948: 7E9402FA FF01643A
	v_cndmask_b32_e64 v58, -v58, v58, s2                       // 000000DB6950: D501003A 200A753A
	v_mov_b32_dpp v83, v60 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6958: 7EA602FA FF01643C
	v_cndmask_b32_e64 v60, -v60, v60, s2                       // 000000DB6960: D501003C 200A793C
	v_add_f32_e32 v59, v59, v76                                // 000000DB6968: 0676993B
	v_mov_b32_dpp v85, v66 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB696C: 7EAA02FA FF016442
	v_cndmask_b32_e64 v66, -v66, v66, s2                       // 000000DB6974: D5010042 200A8542
	v_mov_b32_dpp v91, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB697C: 7EB602FA FF016432
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000DB6984: D5010032 200A6532
	v_mov_b32_dpp v93, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB698C: 7EBA02FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DB6994: D501002A 200A552A
	v_mov_b32_dpp v68, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB699C: 7E8802FA FF016233
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000DB69A4: D5010033 20066733
	v_mov_b32_dpp v77, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB69AC: 7E9A02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000DB69B4: D5010025 20064B25
	v_dual_add_f32 v53, v53, v75 :: v_dual_add_f32 v58, v58, v74// 000000DB69BC: C9089735 353A953A
	v_dual_add_f32 v21, v21, v82 :: v_dual_add_f32 v66, v66, v85// 000000DB69C4: C908A515 1542AB42
	v_dual_add_f32 v45, v45, v84 :: v_dual_add_f32 v50, v50, v91// 000000DB69CC: C908A92D 2D32B732
	v_dual_add_f32 v61, v61, v90 :: v_dual_add_f32 v42, v42, v93// 000000DB69D4: C908B53D 3D2ABB2A
	v_mov_b32_dpp v67, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB69DC: 7E8602FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000DB69E4: D501001D 200A3B1D
	v_mov_b32_dpp v69, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB69EC: 7E8A02FA FF016434
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000DB69F4: D5010034 200A6934
	v_mov_b32_dpp v92, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB69FC: 7EB802FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000DB6A04: D501002C 200A592C
	v_add_f32_e32 v60, v60, v83                                // 000000DB6A0C: 0678A73C
	v_mov_b32_dpp v76, v59 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6A10: 7E9802FA FF01643B
	v_cndmask_b32_e64 v59, -v59, v59, s2                       // 000000DB6A18: D501003B 200A773B
	v_mov_b32_dpp v98, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB6A20: 7EC402FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000DB6A28: D501002B 2006572B
	v_dual_add_f32 v51, v51, v68 :: v_dual_add_f32 v52, v52, v69// 000000DB6A30: C9088933 33348B34
	v_dual_add_f32 v37, v37, v77 :: v_dual_add_f32 v44, v44, v92// 000000DB6A38: C9089B25 252CB92C
	v_mov_b32_dpp v75, v53 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6A40: 7E9602FA FF016435
	v_cndmask_b32_e64 v53, -v53, v53, s2                       // 000000DB6A48: D5010035 200A6B35
	v_mov_b32_dpp v82, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6A50: 7EA402FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000DB6A58: D5010015 200A2B15
	v_mov_b32_dpp v74, v58 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6A60: 7E9402FA FF01683A
	v_cndmask_b32_e64 v58, -v58, v58, s3                       // 000000DB6A68: D501003A 200E753A
	v_add_f32_e32 v29, v29, v67                                // 000000DB6A70: 063A871D
	v_mov_b32_dpp v85, v66 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6A74: 7EAA02FA FF016842
	v_cndmask_b32_e64 v66, -v66, v66, s3                       // 000000DB6A7C: D5010042 200E8542
	v_mov_b32_dpp v91, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6A84: 7EB602FA FF016832
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000DB6A8C: D5010032 200E6532
	v_add_f32_e32 v59, v59, v76                                // 000000DB6A94: 0676993B
	v_mov_b32_dpp v93, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6A98: 7EBA02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB6AA0: D501002A 200E552A
	v_mov_b32_dpp v68, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6AA8: 7E8802FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000DB6AB0: D5010033 200A6733
	v_mov_b32_dpp v77, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6AB8: 7E9A02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000DB6AC0: D5010025 200A4B25
	v_mov_b32_dpp v84, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6AC8: 7EA802FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000DB6AD0: D501002D 200A5B2D
	v_mov_b32_dpp v90, v61 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6AD8: 7EB402FA FF01643D
	v_cndmask_b32_e64 v61, -v61, v61, s2                       // 000000DB6AE0: D501003D 200A7B3D
	v_dual_add_f32 v53, v53, v75 :: v_dual_add_f32 v66, v66, v85// 000000DB6AE8: C9089735 3542AB42
	v_dual_add_f32 v21, v21, v82 :: v_dual_add_f32 v42, v42, v93// 000000DB6AF0: C908A515 152ABB2A
	v_mov_b32_dpp v69, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6AF8: 7E8A02FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000DB6B00: D5010034 200E6934
	v_add_f32_e32 v43, v43, v98                                // 000000DB6B08: 0656C52B
	v_mov_b32_dpp v83, v60 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6B0C: 7EA602FA FF01683C
	v_cndmask_b32_e64 v60, -v60, v60, s3                       // 000000DB6B14: D501003C 200E793C
	v_mov_b32_dpp v92, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6B1C: 7EB802FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000DB6B24: D501002C 200E592C
	v_add_f32_e32 v58, v58, v74                                // 000000DB6B2C: 0674953A
	v_mov_b32_dpp v67, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6B30: 7E8602FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000DB6B38: D501001D 200E3B1D
	v_add_f32_e32 v50, v50, v91                                // 000000DB6B40: 0664B732
	v_mov_b32_dpp v76, v59 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6B44: 7E9802FA FF01683B
	v_cndmask_b32_e64 v59, -v59, v59, s3                       // 000000DB6B4C: D501003B 200E773B
	v_dual_add_f32 v51, v51, v68 :: v_dual_add_f32 v60, v60, v83// 000000DB6B54: C9088933 333CA73C
	v_dual_add_f32 v37, v37, v77 :: v_dual_add_f32 v44, v44, v92// 000000DB6B5C: C9089B25 252CB92C
	v_dual_add_f32 v45, v45, v84 :: v_dual_mul_f32 v58, 0x3db504f3, v58// 000000DB6B64: C906A92D 2D3A74FF 3DB504F3
	v_mov_b32_dpp v75, v53 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6B70: 7E9602FA FF016835
	v_cndmask_b32_e64 v53, -v53, v53, s3                       // 000000DB6B78: D5010035 200E6B35
	v_dual_add_f32 v29, v29, v67 :: v_dual_mul_f32 v66, 0x3db504f3, v66// 000000DB6B80: C906871D 1D4284FF 3DB504F3
	v_add_f32_e32 v52, v52, v69                                // 000000DB6B8C: 06688B34
	v_mov_b32_dpp v98, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB6B90: 7EC402FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000DB6B98: D501002B 200A572B
	v_add_f32_e32 v61, v61, v90                                // 000000DB6BA0: 067AB53D
	v_dual_add_f32 v59, v59, v76 :: v_dual_mul_f32 v42, 0x3db504f3, v42// 000000DB6BA4: C906993B 3B2A54FF 3DB504F3
	v_mov_b32_dpp v84, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6BB0: 7EA802FA FF01682D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB6BB8: BF870004
	v_dual_add_f32 v43, v43, v98 :: v_dual_mul_f32 v60, 0x3db504f3, v60// 000000DB6BBC: C906C52B 2B3C78FF 3DB504F3
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000DB6BC8: D501002D 200E5B2D
	v_dual_add_f32 v53, v53, v75 :: v_dual_mul_f32 v44, 0x3db504f3, v44// 000000DB6BD0: C9069735 352C58FF 3DB504F3
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000DB6BDC: 106868FF 3DB504F3
	v_mov_b32_dpp v90, v61 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6BE4: 7EB402FA FF01683D
	v_cndmask_b32_e64 v61, -v61, v61, s3                       // 000000DB6BEC: D501003D 200E7B3D
	v_mov_b32_dpp v77, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6BF4: 7E9A02FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000DB6BFC: D5010025 200E4B25
	v_mov_b32_dpp v68, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6C04: 7E8802FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000DB6C0C: D5010033 200E6733
	v_mov_b32_dpp v98, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6C14: 7EC402FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000DB6C1C: D501002B 200E572B
	v_mul_f32_e32 v50, 0x3db504f3, v50                         // 000000DB6C24: 106464FF 3DB504F3
	v_mov_b32_dpp v82, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB6C2C: 7EA402FA FF016815
	v_add_f32_e32 v51, v51, v68                                // 000000DB6C34: 06668933
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000DB6C38: D5010015 200E2B15
	v_mul_f32_e32 v59, 0x3db504f3, v59                         // 000000DB6C40: 107676FF 3DB504F3
	s_waitcnt vmcnt(13)                                        // 000000DB6C48: BF8937F7
	v_fma_mix_f32 v8, v8, v60, neg(0) op_sel_hi:[1,0,0]        // 000000DB6C4C: CC200008 8A027908
	v_add_f32_e32 v37, v37, v77                                // 000000DB6C54: 064A9B25
	s_waitcnt vmcnt(11)                                        // 000000DB6C58: BF892FF7
	v_fma_mix_f32 v11, v11, v66, neg(0) op_sel_hi:[1,0,0]      // 000000DB6C5C: CC20000B 8A02850B
	v_add_f32_e32 v45, v45, v84                                // 000000DB6C64: 065AA92D
	s_waitcnt vmcnt(9)                                         // 000000DB6C68: BF8927F7
	v_fma_mix_f32 v26, v26, v50, neg(0) op_sel_hi:[1,0,0]      // 000000DB6C6C: CC20001A 8A02651A
	s_waitcnt vmcnt(8)                                         // 000000DB6C74: BF8923F7
	v_fma_mix_f32 v27, v27, v44, neg(0) op_sel_hi:[1,0,0]      // 000000DB6C78: CC20001B 8A02591B
	s_waitcnt vmcnt(7)                                         // 000000DB6C80: BF891FF7
	v_fma_mix_f32 v28, v28, v42, neg(0) op_sel_hi:[1,0,0]      // 000000DB6C84: CC20001C 8A02551C
	v_dual_add_f32 v61, v61, v90 :: v_dual_mul_f32 v44, 0xbfb8aa3b, v11// 000000DB6C8C: C906B53D 3D2C16FF BFB8AA3B
	v_mul_f32_e32 v42, 0xbfb8aa3b, v8                          // 000000DB6C98: 105410FF BFB8AA3B
	s_waitcnt vmcnt(5)                                         // 000000DB6CA0: BF8917F7
	v_fma_mix_f32 v35, v35, v52, neg(0) op_sel_hi:[1,0,0]      // 000000DB6CA4: CC200023 8A026923
	v_mul_f32_e32 v60, 0xbfb8aa3b, v28                         // 000000DB6CAC: 107838FF BFB8AA3B
	s_waitcnt vmcnt(4)                                         // 000000DB6CB4: BF8913F7
	v_fma_mix_f32 v36, v36, v58, neg(0) op_sel_hi:[1,0,0]      // 000000DB6CB8: CC200024 8A027524
	v_exp_f32_e32 v44, v44                                     // 000000DB6CC0: 7E584B2C
	v_add_f32_e32 v43, v43, v98                                // 000000DB6CC4: 0656C52B
	v_exp_f32_e32 v42, v42                                     // 000000DB6CC8: 7E544B2A
	v_exp_f32_e32 v60, v60                                     // 000000DB6CCC: 7E784B3C
	v_mul_f32_e32 v61, 0x3db504f3, v61                         // 000000DB6CD0: 107A7AFF 3DB504F3
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000DB6CD8: 103A3AFF 3DB504F3
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000DB6CE0: 104A4AFF 3DB504F3
	v_mul_f32_e32 v50, 0xbfb8aa3b, v26                         // 000000DB6CE8: 106434FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB6CF0: BF870317
	v_dual_add_f32 v44, 1.0, v44 :: v_dual_mul_f32 v43, 0x3db504f3, v43// 000000DB6CF4: C90658F2 2C2A56FF 3DB504F3
	v_add_f32_e32 v42, 1.0, v42                                // 000000DB6D00: 065454F2
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000DB6D04: BF870005
	v_add_f32_e32 v52, 1.0, v60                                // 000000DB6D08: 066878F2
	v_fma_mix_f32 v12, v12, v61, neg(0) op_sel_hi:[1,0,0]      // 000000DB6D0C: CC20000C 8A027B0C
	v_fma_mix_f32 v7, v7, v29, neg(0) op_sel_hi:[1,0,0]        // 000000DB6D14: CC200007 8A023B07
	v_fma_mix_f32 v29, v34, v43, neg(0) op_sel_hi:[1,0,0]      // 000000DB6D1C: CC20001D 8A025722
	v_div_scale_f32 v58, null, v42, v42, v8                    // 000000DB6D24: D6FC7C3A 0422552A
	v_div_scale_f32 v67, null, v44, v44, v11                   // 000000DB6D2C: D6FC7C43 042E592C
	v_mul_f32_e32 v43, 0xbfb8aa3b, v12                         // 000000DB6D34: 105618FF BFB8AA3B
	v_div_scale_f32 v60, vcc_lo, v8, v42, v8                   // 000000DB6D3C: D6FC6A3C 04225508
	v_div_scale_f32 v92, s5, v11, v44, v11                     // 000000DB6D44: D6FC055C 042E590B
	v_rcp_f32_e32 v77, v58                                     // 000000DB6D4C: 7E9A553A
	v_exp_f32_e32 v50, v50                                     // 000000DB6D50: 7E644B32
	v_mul_f32_e32 v45, 0x3db504f3, v45                         // 000000DB6D54: 105A5AFF 3DB504F3
	v_rcp_f32_e32 v83, v67                                     // 000000DB6D5C: 7EA65543
	v_exp_f32_e32 v43, v43                                     // 000000DB6D60: 7E564B2B
	v_div_scale_f32 v75, null, v52, v52, v28                   // 000000DB6D64: D6FC7C4B 04726934
	s_waitcnt vmcnt(2)                                         // 000000DB6D6C: BF890BF7
	v_fma_mix_f32 v19, v19, v59, neg(0) op_sel_hi:[1,0,0]      // 000000DB6D70: CC200013 8A027713
	s_waitcnt vmcnt(1)                                         // 000000DB6D78: BF8907F7
	v_fma_mix_f32 v13, v13, v37, neg(0) op_sel_hi:[1,0,0]      // 000000DB6D7C: CC20000D 8A024B0D
	v_fma_f32 v99, -v58, v77, 1.0                              // 000000DB6D84: D6130063 23CA9B3A
	v_add_f32_e32 v50, 1.0, v50                                // 000000DB6D8C: 066464F2
	v_fma_mix_f32 v9, v9, v45, neg(0) op_sel_hi:[1,0,0]        // 000000DB6D90: CC200009 8A025B09
	v_add_f32_e32 v21, v21, v82                                // 000000DB6D98: 062AA515
	v_fma_f32 v101, -v67, v83, 1.0                             // 000000DB6D9C: D6130065 23CAA743
	v_rcp_f32_e32 v91, v75                                     // 000000DB6DA4: 7EB6554B
	v_div_scale_f32 v69, null, v50, v50, v26                   // 000000DB6DA8: D6FC7C45 046A6532
	v_mul_f32_e32 v34, 0xbfb8aa3b, v9                          // 000000DB6DB0: 104412FF BFB8AA3B
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000DB6DB8: 102A2AFF 3DB504F3
	v_fmac_f32_e32 v83, v101, v83                              // 000000DB6DC0: 56A6A765
	v_fmac_f32_e32 v77, v99, v77                               // 000000DB6DC4: 569A9B63
	v_add_f32_e32 v43, 1.0, v43                                // 000000DB6DC8: 065656F2
	v_exp_f32_e32 v34, v34                                     // 000000DB6DCC: 7E444B22
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000DB6DD0: 106666FF 3DB504F3
	v_rcp_f32_e32 v85, v69                                     // 000000DB6DD8: 7EAA5545
	v_fma_f32 v109, -v75, v91, 1.0                             // 000000DB6DDC: D613006D 23CAB74B
	s_waitcnt vmcnt(0)                                         // 000000DB6DE4: BF8903F7
	v_fma_mix_f32 v20, v20, v21, neg(0) op_sel_hi:[1,0,0]      // 000000DB6DE8: CC200014 8A022B14
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB6DF0: BF8702A6
	v_add_f32_e32 v34, 1.0, v34                                // 000000DB6DF4: 064444F2
	v_fma_mix_f32 v10, v10, v51, neg(0) op_sel_hi:[1,0,0]      // 000000DB6DF8: CC20000A 8A02670A
	v_fma_f32 v107, -v69, v85, 1.0                             // 000000DB6E00: D613006B 23CAAB45
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB6E08: BF870123
	v_div_scale_f32 v61, null, v34, v34, v9                    // 000000DB6E0C: D6FC7C3D 04264522
	v_div_scale_f32 v66, s4, v9, v34, v9                       // 000000DB6E14: D6FC0442 04264509
	v_rcp_f32_e32 v82, v61                                     // 000000DB6E1C: 7EA4553D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6E20: BF870095
	v_fma_f32 v100, -v61, v82, 1.0                             // 000000DB6E24: D6130064 23CAA53D
	v_fmac_f32_e32 v82, v100, v82                              // 000000DB6E2C: 56A4A564
	v_mul_f32_e32 v100, v60, v77                               // 000000DB6E30: 10C89B3C
	v_div_scale_f32 v68, null, v43, v43, v12                   // 000000DB6E34: D6FC7C44 0432572B
	v_div_scale_f32 v98, s6, v12, v43, v12                     // 000000DB6E3C: D6FC0662 0432570C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB6E44: BF870292
	v_rcp_f32_e32 v84, v68                                     // 000000DB6E48: 7EA85544
	v_fma_f32 v106, -v68, v84, 1.0                             // 000000DB6E4C: D613006A 23CAA944
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6E54: BF870091
	v_dual_mul_f32 v45, 0xbfb8aa3b, v27 :: v_dual_fmac_f32 v84, v106, v84// 000000DB6E58: C8C036FF 2D54A96A BFB8AA3B
	v_exp_f32_e32 v45, v45                                     // 000000DB6E64: 7E5A4B2D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6E68: BF870095
	v_dual_mul_f32 v106, v92, v83 :: v_dual_add_f32 v45, 1.0, v45// 000000DB6E6C: C8C8A75C 6A2C5AF2
	v_div_scale_f32 v74, null, v45, v45, v27                   // 000000DB6E74: D6FC7C4A 046E5B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB6E7C: BF870291
	v_rcp_f32_e32 v90, v74                                     // 000000DB6E80: 7EB4554A
	v_fma_f32 v108, -v74, v90, 1.0                             // 000000DB6E84: D613006C 23CAB54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6E8C: BF870091
	v_dual_mul_f32 v51, 0xbfb8aa3b, v29 :: v_dual_fmac_f32 v90, v108, v90// 000000DB6E90: C8C03AFF 335AB56C BFB8AA3B
	v_exp_f32_e32 v51, v51                                     // 000000DB6E9C: 7E664B33
	v_fmac_f32_e32 v91, v109, v91                              // 000000DB6EA0: 56B6B76D
	v_fma_f32 v109, -v67, v106, v92                            // 000000DB6EA4: D613006D 2572D543
	v_fmac_f32_e32 v85, v107, v85                              // 000000DB6EAC: 56AAAB6B
	v_fma_f32 v107, -v58, v100, v60                            // 000000DB6EB0: D613006B 24F2C93A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB6EB8: BF870003
	v_dual_mul_f32 v101, v66, v82 :: v_dual_fmac_f32 v106, v109, v83// 000000DB6EBC: C8C0A542 656AA76D
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000DB6EC4: BF870105
	v_dual_fmac_f32 v100, v107, v77 :: v_dual_add_f32 v51, 1.0, v51// 000000DB6EC8: C8089B6B 643266F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB6ED0: BF8701A2
	v_fma_f32 v108, -v61, v101, v66                            // 000000DB6ED4: D613006C 250ACB3D
	v_div_scale_f32 v107, s7, v26, v50, v26                    // 000000DB6EDC: D6FC076B 046A651A
	v_fma_f32 v58, -v58, v100, v60                             // 000000DB6EE4: D613003A 24F2C93A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6EEC: BF870194
	v_div_scale_f32 v76, null, v51, v51, v29                   // 000000DB6EF0: D6FC7C4C 04766733
	v_mul_f32_e32 v109, v107, v85                              // 000000DB6EF8: 10DAAB6B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6EFC: BF870193
	v_div_fmas_f32 v58, v58, v77, v100                         // 000000DB6F00: D637003A 05929B3A
	v_rcp_f32_e32 v93, v76                                     // 000000DB6F08: 7EBA554C
	s_mov_b32 vcc_lo, s4                                       // 000000DB6F0C: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB6F10: BE84007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6F14: BF870091
	v_div_fixup_f32 v8, v58, v42, v8                           // 000000DB6F18: D6270008 0422553A
	v_mul_f32_e32 v7, v7, v8                                   // 000000DB6F20: 100E1107
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB6F24: BF870095
	v_fma_f32 v99, -v76, v93, 1.0                              // 000000DB6F28: D6130063 23CABB4C
	v_fmac_f32_e32 v93, v99, v93                               // 000000DB6F30: 56BABB63
	v_mul_f32_e32 v99, v98, v84                                // 000000DB6F34: 10C6A962
	v_fmac_f32_e32 v101, v108, v82                             // 000000DB6F38: 56CAA56C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB6F3C: BF870112
	v_fma_f32 v108, -v68, v99, v98                             // 000000DB6F40: D613006C 258AC744
	v_fma_f32 v60, -v61, v101, v66                             // 000000DB6F48: D613003C 250ACB3D
	v_fma_f32 v61, -v67, v106, v92                             // 000000DB6F50: D613003D 2572D543
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB6F58: BF870223
	v_fmac_f32_e32 v99, v108, v84                              // 000000DB6F5C: 56C6A96C
	v_fma_f32 v108, -v69, v109, v107                           // 000000DB6F60: D613006C 25AEDB45
	v_div_fmas_f32 v60, v60, v82, v101                         // 000000DB6F68: D637003C 0596A53C
	s_mov_b32 vcc_lo, s5                                       // 000000DB6F70: BEEA0005
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6F74: BF870193
	v_fma_f32 v66, -v68, v99, v98                              // 000000DB6F78: D6130042 258AC744
	v_fmac_f32_e32 v109, v108, v85                             // 000000DB6F80: 56DAAB6C
	v_div_scale_f32 v108, s8, v27, v45, v27                    // 000000DB6F84: D6FC086C 046E5B1B
	v_div_fixup_f32 v9, v60, v34, v9                           // 000000DB6F8C: D6270009 0426453C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB6F94: BF870193
	v_fma_f32 v67, -v69, v109, v107                            // 000000DB6F98: D6130043 25AEDB45
	v_mul_f32_e32 v114, v108, v90                              // 000000DB6FA0: 10E4B56C
	global_load_d16_b16 v69, v[4:5], off offset:32             // 000000DB6FA4: DC820020 457C0004
	v_div_fmas_f32 v61, v61, v83, v106                         // 000000DB6FAC: D637003D 05AAA73D
	s_mov_b32 vcc_lo, s6                                       // 000000DB6FB4: BEEA0006
	v_mul_f32_e32 v9, v10, v9                                  // 000000DB6FB8: 1012130A
	v_fma_f32 v115, -v74, v114, v108                           // 000000DB6FBC: D6130073 25B2E54A
	v_div_fmas_f32 v42, v66, v84, v99                          // 000000DB6FC4: D637002A 058EA942
	s_mov_b32 vcc_lo, s7                                       // 000000DB6FCC: BEEA0007
	v_div_fixup_f32 v11, v61, v44, v11                         // 000000DB6FD0: D627000B 042E593D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB6FD8: BF870233
	v_fmac_f32_e32 v114, v115, v90                             // 000000DB6FDC: 56E4B573
	v_div_scale_f32 v115, s9, v28, v52, v28                    // 000000DB6FE0: D6FC0973 0472691C
	v_div_fixup_f32 v8, v42, v43, v12                          // 000000DB6FE8: D6270008 0432572A
	v_mul_f32_e32 v11, v35, v11                                // 000000DB6FF0: 10161723
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB6FF4: BF870214
	v_fma_f32 v68, -v74, v114, v108                            // 000000DB6FF8: D6130044 25B2E54A
	v_mul_f32_e32 v116, v115, v91                              // 000000DB7000: 10E8B773
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7004: BF870114
	v_mul_f32_e32 v8, v36, v8                                  // 000000DB7008: 10101124
	v_fma_f32 v117, -v75, v116, v115                           // 000000DB700C: D6130075 25CEE94B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DB7014: BF8701C1
	v_fmac_f32_e32 v116, v117, v91                             // 000000DB7018: 56E8B775
	v_div_scale_f32 v117, s10, v29, v51, v29                   // 000000DB701C: D6FC0A75 0476671D
	v_div_fmas_f32 v34, v67, v85, v109                         // 000000DB7024: D6370022 05B6AB43
	s_mov_b32 vcc_lo, s8                                       // 000000DB702C: BEEA0008
	v_fma_f32 v74, -v75, v116, v115                            // 000000DB7030: D613004A 25CEE94B
	s_clause 0x6                                               // 000000DB7038: BF850006
	global_load_d16_b16 v75, v[4:5], off offset:96             // 000000DB703C: DC820060 4B7C0004
	global_load_d16_b16 v77, v[4:5], off offset:160            // 000000DB7044: DC8200A0 4D7C0004
	global_load_d16_b16 v82, v[4:5], off offset:224            // 000000DB704C: DC8200E0 527C0004
	global_load_d16_b16 v83, v[4:5], off offset:192            // 000000DB7054: DC8200C0 537C0004
	global_load_d16_b16 v92, v[4:5], off offset:128            // 000000DB705C: DC820080 5C7C0004
	global_load_d16_b16 v98, v[4:5], off offset:64             // 000000DB7064: DC820040 627C0004
	global_load_d16_b16 v100, v[4:5], off                      // 000000DB706C: DC820000 647C0004
	v_mul_f32_e32 v122, v117, v93                              // 000000DB7074: 10F4BB75
	v_div_fmas_f32 v10, v68, v90, v114                         // 000000DB7078: D637000A 05CAB544
	s_mov_b32 vcc_lo, s9                                       // 000000DB7080: BEEA0009
	v_div_fixup_f32 v21, v34, v50, v26                         // 000000DB7084: D6270015 046A6522
	v_div_fmas_f32 v35, v74, v91, v116                         // 000000DB708C: D6370023 05D2B74A
	v_fma_f32 v123, -v76, v122, v117                           // 000000DB7094: D613007B 25D6F54C
	s_mov_b32 vcc_lo, s10                                      // 000000DB709C: BEEA000A
	v_div_fixup_f32 v10, v10, v45, v27                         // 000000DB70A0: D627000A 046E5B0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB70A8: BF870112
	v_fmac_f32_e32 v122, v123, v93                             // 000000DB70AC: 56F4BB7B
	v_mul_f32_e32 v10, v19, v10                                // 000000DB70B0: 10141513
	v_div_fixup_f32 v19, v35, v52, v28                         // 000000DB70B4: D6270013 04726923
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB70BC: BF870113
	v_fma_f32 v12, -v76, v122, v117                            // 000000DB70C0: D613000C 25D6F54C
	v_mul_f32_e32 v13, v13, v19                                // 000000DB70C8: 101A270D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB70CC: BF870092
	v_div_fmas_f32 v12, v12, v93, v122                         // 000000DB70D0: D637000C 05EABB0C
	v_div_fixup_f32 v12, v12, v51, v29                         // 000000DB70D8: D627000C 0476670C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB70E0: BF870001
	v_mul_f32_e32 v12, v20, v12                                // 000000DB70E4: 10181914
	s_waitcnt vmcnt(7)                                         // 000000DB70E8: BF891FF7
	v_fma_mix_f32 v9, v69, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB70EC: CC200009 8A021345
	s_waitcnt vmcnt(6)                                         // 000000DB70F4: BF891BF7
	v_fma_mix_f32 v8, v75, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB70F8: CC200008 8A02114B
	s_waitcnt vmcnt(5)                                         // 000000DB7100: BF8917F7
	v_fma_mix_f32 v10, v77, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB7104: CC20000A 8A02154D
	s_waitcnt vmcnt(4)                                         // 000000DB710C: BF8913F7
	v_fma_mix_f32 v12, v82, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB7110: CC20000C 8A021952
	s_waitcnt vmcnt(1)                                         // 000000DB7118: BF8907F7
	v_fma_mix_f32 v20, v11, v98, v8 op_sel_hi:[0,1,0]          // 000000DB711C: CC200014 1422C50B
	s_waitcnt vmcnt(0)                                         // 000000DB7124: BF8903F7
	v_fma_mix_f32 v19, v7, v100, v9 op_sel_hi:[0,1,0]          // 000000DB7128: CC200013 1426C907
	v_mul_f32_e32 v53, 0x3db504f3, v53                         // 000000DB7130: 106A6AFF 3DB504F3
	v_fma_mix_f32 v26, v13, v83, v12 op_sel_hi:[0,1,0]         // 000000DB7138: CC20001A 1432A70D
	v_fma_mix_f32 v8, v11, v98, -v8 op_sel_hi:[0,1,0]          // 000000DB7140: CC200008 9422C50B
	v_fma_mix_f32 v11, v13, v83, -v12 op_sel_hi:[0,1,0]        // 000000DB7148: CC20000B 9432A70D
	v_sub_f32_e32 v12, v19, v20                                // 000000DB7150: 08182913
	v_fma_mix_f32 v18, v18, v53, neg(0) op_sel_hi:[1,0,0]      // 000000DB7154: CC200012 8A026B12
	v_add_f32_e32 v27, v19, v20                                // 000000DB715C: 06362913
	v_fma_mix_f32 v7, v7, v100, -v9 op_sel_hi:[0,1,0]          // 000000DB7160: CC200007 9426C907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7168: BF870121
	v_dual_mul_f32 v18, v18, v21 :: v_dual_add_f32 v13, v7, v8 // 000000DB716C: C8C82B12 120C1107
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB7174: 080E1107
	v_fma_mix_f32 v21, v18, v92, v10 op_sel_hi:[0,1,0]         // 000000DB7178: CC200015 142AB912
	v_fma_mix_f32 v10, v18, v92, -v10 op_sel_hi:[0,1,0]        // 000000DB7180: CC20000A 942AB912
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7188: BF870112
	v_add_f32_e32 v28, v21, v26                                // 000000DB718C: 06383515
	v_dual_add_f32 v8, v10, v11 :: v_dual_sub_f32 v19, v21, v26// 000000DB7190: C90A170A 08123515
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7198: BF870092
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v9, v27, v28// 000000DB719C: C948170A 0A08391B
	v_mov_b32_dpp v18, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB71A4: 7E2402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB71AC: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB71B4: BF870241
	v_add_f32_e32 v9, v9, v18                                  // 000000DB71B8: 06122509
	v_add_f32_e32 v18, v13, v8                                 // 000000DB71BC: 0624110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v19 // 000000DB71C0: C948110D 0D08270C
	v_sub_f32_e32 v19, v12, v19                                // 000000DB71C8: 0826270C
	v_mov_b32_dpp v20, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB71CC: 7E2802FA FF016209
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000DB71D4: BF8701D4
	v_mov_b32_dpp v21, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB71D8: 7E2A02FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB71E0: D5010012 20022512
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB71E8: D5010009 20061309
	v_mov_b32_dpp v26, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB71F0: 7E3402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB71F8: D5010008 20021108
	v_dual_add_f32 v12, v18, v21 :: v_dual_add_f32 v9, v9, v20 // 000000DB7200: C9082B12 0C082909
	v_add_f32_e32 v18, v7, v10                                 // 000000DB7208: 06241507
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB720C: BF870193
	v_add_f32_e32 v8, v8, v26                                  // 000000DB7210: 06103508
	v_mov_b32_dpp v21, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7214: 7E2A02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB721C: D501000C 2006190C
	v_mov_b32_dpp v20, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7224: 7E2802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DB722C: D5010009 200A1309
	v_mov_b32_dpp v26, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7234: 7E3402FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB723C: D5010008 20061108
	v_dual_add_f32 v12, v12, v21 :: v_dual_sub_f32 v21, v7, v10// 000000DB7244: C90A2B0C 0C141507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB724C: BF870112
	v_dual_add_f32 v7, v9, v20 :: v_dual_add_f32 v8, v8, v26   // 000000DB7250: C9082909 07083508
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7258: 7E1402FA FF01640C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB7260: BF870003
	v_mov_b32_dpp v34, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7264: 7E4402FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000DB726C: D5010015 20022B15
	v_sub_f32_e32 v11, v27, v28                                // 000000DB7274: 0816391B
	v_mov_b32_dpp v27, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7278: 7E3602FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB7280: D5010012 20022512
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DB7288: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB7290: BF870194
	v_cndmask_b32_e64 v28, -v11, v11, s0                       // 000000DB7294: D501001C 2002170B
	v_add_f32_e32 v9, v18, v27                                 // 000000DB729C: 06123712
	v_mov_b32_dpp v18, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB72A0: 7E2402FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB72A8: D5010008 200A1108
	v_mov_b32_dpp v27, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB72B0: 7E3602FA FF01610B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB72B8: BF870224
	v_mov_b32_dpp v20, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB72BC: 7E2802FA FF016209
	v_cndmask_b32_e64 v26, -v9, v9, s1                         // 000000DB72C4: D501001A 20061309
	v_add_f32_e32 v11, v8, v18                                 // 000000DB72CC: 06162508
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB72D0: BF870242
	v_dual_add_f32 v9, v12, v10 :: v_dual_add_f32 v18, v26, v20// 000000DB72D4: C908150C 0912291A
	v_add_f32_e32 v20, v28, v27                                // 000000DB72DC: 0628371C
	v_mov_b32_dpp v28, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB72E0: 7E3802FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB72E8: D501000D 20021B0D
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB72F0: 7E1402FA FF016809
	v_mov_b32_dpp v26, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB72F8: 7E3402FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB7300: D5010012 200A2512
	v_mov_b32_dpp v27, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7308: 7E3602FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000DB7310: D5010014 20062914
	v_add_f32_e32 v28, v13, v28                                // 000000DB7318: 0638390D
	v_mov_b32_dpp v29, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB731C: 7E3A02FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB7324: D5010013 20022713
	v_add_f32_e32 v13, v18, v26                                // 000000DB732C: 061A3512
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7330: 7E1802FA FF01680B
	v_cndmask_b32_e64 v26, -v28, v28, s1                       // 000000DB7338: D501001A 2006391C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB7340: BF8701B4
	v_dual_add_f32 v18, v19, v29 :: v_dual_add_f32 v19, v20, v27// 000000DB7344: C9083B13 12123714
	v_add_f32_e32 v20, v21, v34                                // 000000DB734C: 06284515
	v_mov_b32_dpp v21, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7350: 7E2A02FA FF01621C
	v_mov_b32_dpp v27, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7358: 7E3602FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB7360: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB7368: BF870004
	v_mov_b32_dpp v28, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB736C: 7E3802FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000DB7374: D5010014 20062914
	v_add_f32_e32 v21, v26, v21                                // 000000DB737C: 062A2B1A
	v_mov_b32_dpp v26, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7380: 7E3402FA FF016413
	v_add_f32_e32 v18, v18, v27                                // 000000DB7388: 06243712
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000DB738C: D5010013 200A2713
	v_add_f32_e32 v20, v20, v28                                // 000000DB7394: 06283914
	v_mov_b32_dpp v27, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7398: 7E3602FA FF016415
	v_cndmask_b32_e64 v28, -v21, v21, s2                       // 000000DB73A0: D501001C 200A2B15
	v_mov_b32_dpp v29, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB73A8: 7E3A02FA FF016412
	v_cndmask_b32_e64 v34, -v18, v18, s2                       // 000000DB73B0: D5010022 200A2512
	v_mov_b32_dpp v35, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB73B8: 7E4602FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000DB73C0: D5010014 200A2914
	v_dual_add_f32 v21, v19, v26 :: v_dual_add_f32 v26, v28, v27// 000000DB73C8: C9083513 151A371C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB73D0: BF870224
	v_add_f32_e32 v28, v34, v29                                // 000000DB73D4: 06383B22
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB73D8: 7E1002FA FF016807
	v_add_f32_e32 v34, v20, v35                                // 000000DB73E0: 06444714
	v_mov_b32_dpp v18, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB73E4: 7E2402FA FF01680D
	v_add_nc_u32_e32 v19, 6, v6                                // 000000DB73EC: 4A260C86
	v_mov_b32_dpp v20, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB73F0: 7E2802FA FF016815
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB73F8: 7E3602FA FF01681A
	v_mov_b32_dpp v29, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7400: 7E3A02FA FF01681C
	v_mov_b32_dpp v35, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7408: 7E4602FA FF016822
	.long 0xd4c4007e                                           // 000000DB7410: D4C4007E
	v_cndmask_b32_e32 v1, s23, v19, vcc_lo                     // 000000DB7414: 02022617
	s_cbranch_execz 62                                         // 000000DB7418: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x4914>
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB741C: D501001C 200E391C
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB7424: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB742C: D5010009 200E1309
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000DB7434: D501001A 200E351A
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DB743C: D501000B 200E170B
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DB7444: D5010022 200E4522
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DB744C: D501000D 200E1B0D
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000DB7454: D5010015 200E2B15
	v_dual_add_f32 v28, v28, v29 :: v_dual_add_f32 v7, v7, v8  // 000000DB745C: C9083B1C 1C061107
	v_add_f32_e32 v8, v9, v10                                  // 000000DB7464: 06101509
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v9, v11, v12// 000000DB7468: C908371A 1A08190B
	v_mad_i64_i32 v[11:12], null, 0x500, v19, v[0:1]           // 000000DB7470: D6FF7C0B 040226FF 00000500
	v_dual_add_f32 v34, v34, v35 :: v_dual_add_f32 v13, v13, v18// 000000DB747C: C9084722 220C250D
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB7484: BE8500FF 3DB504F3
	v_add_f32_e32 v20, v21, v20                                // 000000DB748C: 06282915
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB7490: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB7498: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB74A0: CC210008 02000B09
	v_fma_mixhi_f16 v8, v13, s5, 0                             // 000000DB74A8: CC220008 02000B0D
	v_fma_mixlo_f16 v9, v20, s5, 0                             // 000000DB74B0: CC210009 02000B14
	v_fma_mixhi_f16 v9, v26, s5, 0                             // 000000DB74B8: CC220009 02000B1A
	v_fma_mixlo_f16 v10, v28, s5, 0                            // 000000DB74C0: CC21000A 02000B1C
	v_fma_mixhi_f16 v10, v34, s5, 0                            // 000000DB74C8: CC22000A 02000B22
	s_clause 0x7                                               // 000000DB74D0: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000DB74D4: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000DB74DC: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000DB74E4: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000DB74EC: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000DB74F4: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000DB74FC: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000DB7504: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000DB750C: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB7514: 8C7E047E
	s_clause 0xb                                               // 000000DB7518: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB751C: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB7524: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB752C: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB7534: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DB753C: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000DB7544: DC820060 0C7C0002
	global_load_d16_b16 v20, v[2:3], off offset:128            // 000000DB754C: DC820080 147C0002
	global_load_d16_b16 v21, v[2:3], off offset:160            // 000000DB7554: DC8200A0 157C0002
	global_load_d16_b16 v26, v[2:3], off offset:192            // 000000DB755C: DC8200C0 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:224            // 000000DB7564: DC8200E0 1B7C0002
	global_load_d16_b16 v28, v[2:3], off offset:1344           // 000000DB756C: DC820540 1C7C0002
	global_load_d16_b16 v29, v[2:3], off offset:1376           // 000000DB7574: DC820560 1D7C0002
	v_sub_f32_e32 v37, v118, v110                              // 000000DB757C: 084ADD76
	v_add_f32_e32 v42, v102, v94                               // 000000DB7580: 0654BD66
	v_sub_f32_e32 v43, v102, v94                               // 000000DB7584: 0856BD66
	v_add_f32_e32 v44, v86, v78                                // 000000DB7588: 06589D56
	v_sub_f32_e32 v45, v86, v78                                // 000000DB758C: 085A9D56
	v_sub_f32_e32 v35, v134, v126                              // 000000DB7590: 0846FD86
	v_add_f32_e32 v34, v134, v126                              // 000000DB7594: 0644FD86
	v_add_f32_e32 v36, v118, v110                              // 000000DB7598: 0648DD76
	v_add_f32_e32 v53, v38, v30                                // 000000DB759C: 066A3D26
	v_sub_f32_e32 v30, v38, v30                                // 000000DB75A0: 083C3D26
	v_add_f32_e32 v38, v22, v14                                // 000000DB75A4: 064C1D16
	v_sub_f32_e32 v51, v70, v62                                // 000000DB75A8: 08667D46
	v_add_f32_e32 v52, v54, v46                                // 000000DB75AC: 06685D36
	v_sub_f32_e32 v46, v54, v46                                // 000000DB75B0: 085C5D36
	v_sub_f32_e32 v22, v22, v14                                // 000000DB75B4: 082C1D16
	v_add_f32_e32 v58, v53, v38                                // 000000DB75B8: 06744D35
	v_add_f32_e32 v54, v34, v36                                // 000000DB75BC: 066C4922
	v_sub_f32_e32 v34, v34, v36                                // 000000DB75C0: 08444922
	v_add_f32_e32 v36, v35, v37                                // 000000DB75C4: 06484B23
	v_sub_f32_e32 v35, v35, v37                                // 000000DB75C8: 08464B23
	v_add_f32_e32 v37, v42, v44                                // 000000DB75CC: 064A592A
	v_sub_f32_e32 v42, v42, v44                                // 000000DB75D0: 0854592A
	v_add_f32_e32 v44, v43, v45                                // 000000DB75D4: 06585B2B
	v_dual_sub_f32 v43, v43, v45 :: v_dual_add_f32 v50, v70, v62// 000000DB75D8: C9485B2B 2B327D46
	s_clause 0x3                                               // 000000DB75E0: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000DB75E4: DC820580 0E7C0002
	global_load_d16_b16 v18, v[2:3], off offset:1440           // 000000DB75EC: DC8205A0 127C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000DB75F4: DC8205C0 0D7C0002
	global_load_d16_b16 v19, v[2:3], off offset:1504           // 000000DB75FC: DC8205E0 137C0002
	v_add_f32_e32 v59, v35, v43                                // 000000DB7604: 06765723
	v_sub_f32_e32 v35, v35, v43                                // 000000DB7608: 08465723
	v_add_f32_e32 v45, v50, v52                                // 000000DB760C: 065A6932
	v_sub_f32_e32 v50, v50, v52                                // 000000DB7610: 08646932
	v_add_f32_e32 v52, v51, v46                                // 000000DB7614: 06685D33
	v_sub_f32_e32 v46, v51, v46                                // 000000DB7618: 085C5D33
	v_add_f32_e32 v51, v30, v22                                // 000000DB761C: 06662D1E
	v_sub_f32_e32 v22, v30, v22                                // 000000DB7620: 082C2D1E
	v_add_f32_e32 v30, v45, v58                                // 000000DB7624: 063C752D
	v_dual_sub_f32 v45, v45, v58 :: v_dual_add_f32 v58, v54, v37// 000000DB7628: C948752D 2D3A4B36
	v_sub_f32_e32 v37, v54, v37                                // 000000DB7630: 084A4B36
	v_mov_b32_dpp v78, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7634: 7E9C02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000DB763C: D5010023 20024723
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB7644: BF870004
	v_mov_b32_dpp v61, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7648: 7E7A02FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000DB7650: D501002D 20025B2D
	v_mov_b32_dpp v75, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7658: 7E9602FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000DB7660: D5010025 20024B25
	v_mov_b32_dpp v68, v58 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7668: 7E8802FA FF01613A
	v_cndmask_b32_e64 v58, -v58, v58, s0                       // 000000DB7670: D501003A 2002753A
	v_add_f32_e32 v45, v45, v61                                // 000000DB7678: 065A7B2D
	v_add_f32_e32 v35, v35, v78                                // 000000DB767C: 06469D23
	v_add_f32_e32 v37, v37, v75                                // 000000DB7680: 064A9725
	v_dual_sub_f32 v38, v53, v38 :: v_dual_add_f32 v53, v52, v51// 000000DB7684: C9484D35 26346734
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB768C: BF870224
	v_mov_b32_dpp v61, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7690: 7E7A02FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000DB7698: D501002D 20065B2D
	v_mov_b32_dpp v75, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB76A0: 7E9602FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000DB76A8: D5010025 20064B25
	v_dual_sub_f32 v51, v52, v51 :: v_dual_add_f32 v60, v34, v42// 000000DB76B0: C9486734 333C5522
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB76B8: BF870194
	v_dual_add_f32 v45, v45, v61 :: v_dual_add_f32 v52, v50, v38// 000000DB76BC: C9087B2D 2D344D32
	v_add_f32_e32 v37, v37, v75                                // 000000DB76C4: 064A9725
	v_mov_b32_dpp v43, v53 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB76C8: 7E5602FA FF016135
	v_mov_b32_dpp v74, v59 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB76D0: 7E9402FA FF01613B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB76D8: BF870004
	v_mov_b32_dpp v61, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB76DC: 7E7A02FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000DB76E4: D501002D 200A5B2D
	v_sub_f32_e32 v38, v50, v38                                // 000000DB76EC: 084C4D32
	v_add_f32_e32 v50, v46, v22                                // 000000DB76F0: 06642D2E
	v_mov_b32_dpp v75, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB76F4: 7E9602FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000DB76FC: D5010025 200A4B25
	v_dual_add_f32 v45, v45, v61 :: v_dual_sub_f32 v22, v46, v22// 000000DB7704: C90A7B2D 2D162D2E
	v_add_f32_e32 v46, v36, v44                                // 000000DB770C: 065C5924
	v_sub_f32_e32 v36, v36, v44                                // 000000DB7710: 08485924
	v_cndmask_b32_e64 v44, -v53, v53, s0                       // 000000DB7714: D501002C 20026B35
	v_mov_b32_dpp v53, v52 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB771C: 7E6A02FA FF016134
	v_cndmask_b32_e64 v52, -v52, v52, s0                       // 000000DB7724: D5010034 20026934
	v_mov_b32_dpp v61, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB772C: 7E7A02FA FF01682D
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000DB7734: D501002D 200E5B2D
	v_sub_f32_e32 v34, v34, v42                                // 000000DB773C: 08445522
	v_mov_b32_dpp v42, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7740: 7E5402FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000DB7748: D501001E 20023D1E
	v_cndmask_b32_e64 v59, -v59, v59, s0                       // 000000DB7750: D501003B 2002773B
	v_mov_b32_dpp v78, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7758: 7E9C02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000DB7760: D5010023 20064723
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB7768: BF870004
	v_dual_add_f32 v37, v37, v75 :: v_dual_add_f32 v30, v30, v42// 000000DB776C: C9089725 251E551E
	v_add_f32_e32 v42, v44, v43                                // 000000DB7774: 0654572C
	v_dual_add_f32 v43, v52, v53 :: v_dual_add_f32 v52, v59, v74// 000000DB7778: C9086B34 2B34953B
	v_mov_b32_dpp v67, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7780: 7E8602FA FF016116
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000DB7788: D5010016 20022D16
	v_add_f32_e32 v35, v35, v78                                // 000000DB7790: 06469D23
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB7794: BF870004
	v_mov_b32_dpp v59, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7798: 7E7602FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000DB77A0: D501002B 2006572B
	v_add_f32_e32 v45, v45, v61                                // 000000DB77A8: 065A7B2D
	v_mov_b32_dpp v77, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB77AC: 7E9A02FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000DB77B4: D5010022 20024522
	v_add_f32_e32 v22, v22, v67                                // 000000DB77BC: 062C8716
	v_add_f32_e32 v43, v43, v59                                // 000000DB77C0: 0656772B
	v_mov_b32_dpp v54, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB77C4: 7E6C02FA FF016132
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000DB77CC: D5010032 20026532
	v_mov_b32_dpp v62, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB77D4: 7E7C02FA FF016133
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000DB77DC: D5010033 20026733
	v_mov_b32_dpp v59, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB77E4: 7E7602FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000DB77EC: D501002B 200A572B
	v_mov_b32_dpp v78, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB77F4: 7E9C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000DB77FC: D5010023 200A4723
	v_add_f32_e32 v34, v34, v77                                // 000000DB7804: 06449B22
	v_mov_b32_dpp v75, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7808: 7E9602FA FF016825
	v_add_f32_e32 v43, v43, v59                                // 000000DB7810: 0656772B
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000DB7814: D5010025 200E4B25
	v_add_f32_e32 v44, v50, v54                                // 000000DB781C: 06586D32
	v_add_f32_e32 v35, v35, v78                                // 000000DB7820: 06469D23
	v_mov_b32_dpp v77, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7824: 7E9A02FA FF016222
	v_mov_b32_dpp v59, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB782C: 7E7602FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000DB7834: D501002B 200E572B
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB783C: D5010022 20064522
	v_mov_b32_dpp v76, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7844: 7E9802FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000DB784C: D5010024 20024924
	v_mov_b32_dpp v66, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB7854: 7E8402FA FF016126
	v_add_f32_e32 v43, v43, v59                                // 000000DB785C: 0656772B
	v_dual_add_f32 v50, v51, v62 :: v_dual_add_f32 v51, v58, v68// 000000DB7860: C9087D33 3232893A
	v_add_f32_e32 v34, v34, v77                                // 000000DB7868: 06449B22
	v_mov_b32_dpp v70, v60 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB786C: 7E8C02FA FF01613C
	v_cndmask_b32_e64 v60, -v60, v60, s0                       // 000000DB7874: D501003C 2002793C
	v_add_f32_e32 v36, v36, v76                                // 000000DB787C: 06489924
	v_mov_b32_dpp v68, v51 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7880: 7E8802FA FF016233
	v_cndmask_b32_e64 v51, -v51, v51, s1                       // 000000DB7888: D5010033 20066733
	v_mov_b32_dpp v77, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7890: 7E9A02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000DB7898: D5010022 200A4522
	v_add_f32_e32 v53, v60, v70                                // 000000DB78A0: 066A8D3C
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000DB78A4: D5010026 20024D26
	v_add_f32_e32 v51, v51, v68                                // 000000DB78AC: 06668933
	v_mov_b32_dpp v76, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB78B0: 7E9802FA FF016224
	v_add_f32_e32 v34, v34, v77                                // 000000DB78B8: 06449B22
	v_mov_b32_dpp v70, v53 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB78BC: 7E8C02FA FF016235
	v_cndmask_b32_e64 v53, -v53, v53, s1                       // 000000DB78C4: D5010035 20066B35
	v_mov_b32_dpp v68, v51 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB78CC: 7E8802FA FF016433
	v_cndmask_b32_e64 v51, -v51, v51, s2                       // 000000DB78D4: D5010033 200A6733
	v_mov_b32_dpp v77, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB78DC: 7E9A02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DB78E4: D5010022 200E4522
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000DB78EC: D5010024 20064924
	v_add_f32_e32 v53, v53, v70                                // 000000DB78F4: 066A8D35
	v_add_f32_e32 v51, v51, v68                                // 000000DB78F8: 06668933
	v_mov_b32_dpp v69, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB78FC: 7E8A02FA FF01612E
	v_add_f32_e32 v34, v34, v77                                // 000000DB7904: 06449B22
	v_cndmask_b32_e64 v46, -v46, v46, s0                       // 000000DB7908: D501002E 20025D2E
	v_mov_b32_dpp v70, v53 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7910: 7E8C02FA FF016435
	v_mov_b32_dpp v68, v51 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7918: 7E8802FA FF016833
	v_cndmask_b32_e64 v51, -v51, v51, s3                       // 000000DB7920: D5010033 200E6733
	v_mul_f32_e32 v34, 0x3db504f3, v34                         // 000000DB7928: 104444FF 3DB504F3
	v_cndmask_b32_e64 v53, -v53, v53, s2                       // 000000DB7930: D5010035 200A6B35
	v_add_f32_e32 v46, v46, v69                                // 000000DB7938: 065C8B2E
	v_mov_b32_dpp v67, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB793C: 7E8602FA FF016216
	v_dual_add_f32 v51, v51, v68 :: v_dual_add_f32 v38, v38, v66// 000000DB7944: C9088933 33268526
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB794C: BF870234
	v_add_f32_e32 v53, v53, v70                                // 000000DB7950: 066A8D35
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000DB7954: D5010016 20062D16
	v_mov_b32_dpp v54, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB795C: 7E6C02FA FF01621E
	v_mul_f32_e32 v51, 0x3db504f3, v51                         // 000000DB7964: 106666FF 3DB504F3
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000DB796C: D501001E 20063D1E
	v_mov_b32_dpp v70, v53 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7974: 7E8C02FA FF016835
	v_cndmask_b32_e64 v53, -v53, v53, s3                       // 000000DB797C: D5010035 200E6B35
	v_add_f32_e32 v22, v22, v67                                // 000000DB7984: 062C8716
	v_add_f32_e32 v37, v37, v75                                // 000000DB7988: 064A9725
	v_mov_b32_dpp v66, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB798C: 7E8402FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000DB7994: D5010026 20064D26
	v_add_f32_e32 v53, v53, v70                                // 000000DB799C: 066A8D35
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB79A0: BF870234
	v_dual_add_f32 v30, v30, v54 :: v_dual_mul_f32 v37, 0x3db504f3, v37// 000000DB79A4: C9066D1E 1E244AFF 3DB504F3
	v_mov_b32_dpp v69, v46 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB79B0: 7E8A02FA FF01622E
	v_cndmask_b32_e64 v46, -v46, v46, s1                       // 000000DB79B8: D501002E 20065D2E
	v_mul_f32_e32 v53, 0x3db504f3, v53                         // 000000DB79C0: 106A6AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB79C8: BF870004
	v_mov_b32_dpp v54, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB79CC: 7E6C02FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000DB79D4: D501001E 200A3D1E
	v_mov_b32_dpp v78, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB79DC: 7E9C02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB79E4: D5010023 200E4723
	v_add_f32_e32 v46, v46, v69                                // 000000DB79EC: 065C8B2E
	v_mov_b32_dpp v74, v52 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB79F0: 7E9402FA FF016234
	v_cndmask_b32_e64 v52, -v52, v52, s1                       // 000000DB79F8: D5010034 20066934
	v_mov_b32_dpp v67, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7A00: 7E8602FA FF016416
	v_add_f32_e32 v35, v35, v78                                // 000000DB7A08: 06469D23
	v_mov_b32_dpp v69, v46 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7A0C: 7E8A02FA FF01642E
	v_cndmask_b32_e64 v46, -v46, v46, s2                       // 000000DB7A14: D501002E 200A5D2E
	v_add_f32_e32 v52, v52, v74                                // 000000DB7A1C: 06689534
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000DB7A20: D5010016 200A2D16
	v_mul_f32_e32 v43, 0x3db504f3, v43                         // 000000DB7A28: 105656FF 3DB504F3
	v_mov_b32_dpp v58, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7A30: 7E7402FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DB7A38: D501002A 2006552A
	v_mov_b32_dpp v74, v52 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7A40: 7E9402FA FF016434
	v_cndmask_b32_e64 v52, -v52, v52, s2                       // 000000DB7A48: D5010034 200A6934
	v_mul_f32_e32 v35, 0x3db504f3, v35                         // 000000DB7A50: 104646FF 3DB504F3
	v_mov_b32_dpp v62, v50 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7A58: 7E7C02FA FF016232
	v_add_f32_e32 v42, v42, v58                                // 000000DB7A60: 0654752A
	v_cndmask_b32_e64 v50, -v50, v50, s1                       // 000000DB7A64: D5010032 20066532
	v_add_f32_e32 v52, v52, v74                                // 000000DB7A6C: 06689534
	v_mov_b32_dpp v60, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB7A70: 7E7802FA FF01622C
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000DB7A78: D501002C 2006592C
	v_mov_b32_dpp v58, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7A80: 7E7402FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DB7A88: D501002A 200A552A
	v_mov_b32_dpp v74, v52 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7A90: 7E9402FA FF016834
	v_cndmask_b32_e64 v52, -v52, v52, s3                       // 000000DB7A98: D5010034 200E6934
	v_dual_add_f32 v44, v44, v60 :: v_dual_mul_f32 v45, 0x3db504f3, v45// 000000DB7AA0: C906792C 2C2C5AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7AAC: BF870112
	v_add_f32_e32 v52, v52, v74                                // 000000DB7AB0: 06689534
	v_mov_b32_dpp v60, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7AB4: 7E7802FA FF01642C
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000DB7ABC: D501002C 200A592C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB7AC4: BF870003
	v_mul_f32_e32 v52, 0x3db504f3, v52                         // 000000DB7AC8: 106868FF 3DB504F3
	s_waitcnt vmcnt(13)                                        // 000000DB7AD0: BF8937F7
	v_fma_mix_f32 v8, v8, v51, neg(0) op_sel_hi:[1,0,0]        // 000000DB7AD4: CC200008 8A026708
	s_waitcnt vmcnt(11)                                        // 000000DB7ADC: BF892FF7
	v_fma_mix_f32 v11, v11, v53, neg(0) op_sel_hi:[1,0,0]      // 000000DB7AE0: CC20000B 8A026B0B
	s_waitcnt vmcnt(10)                                        // 000000DB7AE8: BF892BF7
	v_fma_mix_f32 v12, v12, v52, neg(0) op_sel_hi:[1,0,0]      // 000000DB7AEC: CC20000C 8A02690C
	s_waitcnt vmcnt(9)                                         // 000000DB7AF4: BF8927F7
	v_fma_mix_f32 v20, v20, v37, neg(0) op_sel_hi:[1,0,0]      // 000000DB7AF8: CC200014 8A024B14
	v_add_f32_e32 v50, v50, v62                                // 000000DB7B00: 06647D32
	s_waitcnt vmcnt(7)                                         // 000000DB7B04: BF891FF7
	v_fma_mix_f32 v26, v26, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DB7B08: CC20001A 8A02451A
	v_add_f32_e32 v36, v36, v76                                // 000000DB7B10: 06489924
	v_mul_f32_e32 v34, 0xbfb8aa3b, v8                          // 000000DB7B14: 104410FF BFB8AA3B
	s_waitcnt vmcnt(5)                                         // 000000DB7B1C: BF8917F7
	v_fma_mix_f32 v28, v28, v43, neg(0) op_sel_hi:[1,0,0]      // 000000DB7B20: CC20001C 8A02571C
	v_fma_mix_f32 v27, v27, v35, neg(0) op_sel_hi:[1,0,0]      // 000000DB7B28: CC20001B 8A02471B
	v_mul_f32_e32 v51, 0xbfb8aa3b, v26                         // 000000DB7B30: 106634FF BFB8AA3B
	v_mov_b32_dpp v76, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7B38: 7E9802FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000DB7B40: D5010024 200A4924
	v_exp_f32_e32 v34, v34                                     // 000000DB7B48: 7E444B22
	v_mul_f32_e32 v35, 0xbfb8aa3b, v12                         // 000000DB7B4C: 104618FF BFB8AA3B
	v_exp_f32_e32 v51, v51                                     // 000000DB7B54: 7E664B33
	v_mov_b32_dpp v62, v50 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7B58: 7E7C02FA FF016432
	v_add_f32_e32 v36, v36, v76                                // 000000DB7B60: 06489924
	v_cndmask_b32_e64 v50, -v50, v50, s2                       // 000000DB7B64: D5010032 200A6532
	v_exp_f32_e32 v35, v35                                     // 000000DB7B6C: 7E464B23
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000DB7B70: BF870322
	v_mov_b32_dpp v76, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7B74: 7E9802FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000DB7B7C: D5010024 200E4924
	v_dual_add_f32 v34, 1.0, v34 :: v_dual_add_f32 v43, 1.0, v51// 000000DB7B84: C90844F2 222A66F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7B8C: BF870112
	v_add_f32_e32 v36, v36, v76                                // 000000DB7B90: 06489924
	v_div_scale_f32 v51, vcc_lo, v8, v34, v8                   // 000000DB7B94: D6FC6A33 04224508
	v_add_f32_e32 v22, v22, v67                                // 000000DB7B9C: 062C8716
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000DB7BA0: BF870005
	v_add_f32_e32 v35, 1.0, v35                                // 000000DB7BA4: 064646F2
	v_div_scale_f32 v61, null, v43, v43, v26                   // 000000DB7BA8: D6FC7C3D 046A572B
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000DB7BB0: 104848FF 3DB504F3
	s_waitcnt vmcnt(3)                                         // 000000DB7BB8: BF890FF7
	v_fma_mix_f32 v14, v14, v45, neg(0) op_sel_hi:[1,0,0]      // 000000DB7BBC: CC20000E 8A025B0E
	v_mov_b32_dpp v67, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7BC4: 7E8602FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000DB7BCC: D5010016 200E2D16
	v_rcp_f32_e32 v75, v61                                     // 000000DB7BD4: 7E96553D
	v_fma_mix_f32 v21, v21, v36, neg(0) op_sel_hi:[1,0,0]      // 000000DB7BD8: CC200015 8A024915
	v_add_f32_e32 v38, v38, v66                                // 000000DB7BE0: 064C8526
	v_mul_f32_e32 v36, 0xbfb8aa3b, v11                         // 000000DB7BE4: 104816FF BFB8AA3B
	v_add_f32_e32 v22, v22, v67                                // 000000DB7BEC: 062C8716
	v_div_scale_f32 v78, s6, v12, v35, v12                     // 000000DB7BF0: D6FC064E 0432470C
	v_mul_f32_e32 v37, 0xbfb8aa3b, v21                         // 000000DB7BF8: 104A2AFF BFB8AA3B
	v_mov_b32_dpp v66, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB7C00: 7E8402FA FF016426
	v_exp_f32_e32 v36, v36                                     // 000000DB7C08: 7E484B24
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000DB7C0C: D5010026 200A4D26
	v_fma_f32 v91, -v61, v75, 1.0                              // 000000DB7C14: D613005B 23CA973D
	v_exp_f32_e32 v37, v37                                     // 000000DB7C1C: 7E4A4B25
	v_add_f32_e32 v30, v30, v54                                // 000000DB7C20: 063C6D1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB7C24: BF870312
	v_dual_add_f32 v50, v50, v62 :: v_dual_fmac_f32 v75, v91, v75// 000000DB7C28: C9007D32 324A975B
	v_add_f32_e32 v36, 1.0, v36                                // 000000DB7C30: 064848F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB7C34: BF8702A2
	v_mov_b32_dpp v62, v50 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7C38: 7E7C02FA FF016832
	v_cndmask_b32_e64 v50, -v50, v50, s3                       // 000000DB7C40: D5010032 200E6532
	v_add_f32_e32 v37, 1.0, v37                                // 000000DB7C48: 064A4AF2
	v_mov_b32_dpp v54, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7C4C: 7E6C02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000DB7C54: D501001E 200E3D1E
	v_div_scale_f32 v76, s5, v11, v36, v11                     // 000000DB7C5C: D6FC054C 042E490B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7C64: BF870122
	v_add_f32_e32 v30, v30, v54                                // 000000DB7C68: 063C6D1E
	v_div_scale_f32 v54, null, v36, v36, v11                   // 000000DB7C6C: D6FC7C36 042E4924
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000DB7C74: 103C3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7C7C: BF870092
	v_rcp_f32_e32 v68, v54                                     // 000000DB7C80: 7E885536
	v_fma_mix_f32 v7, v7, v30, neg(0) op_sel_hi:[1,0,0]        // 000000DB7C84: CC200007 8A023D07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7C8C: BF870095
	v_fma_f32 v84, -v54, v68, 1.0                              // 000000DB7C90: D6130054 23CA8936
	v_fmac_f32_e32 v68, v84, v68                               // 000000DB7C98: 56888954
	v_add_f32_e32 v46, v46, v69                                // 000000DB7C9C: 065C8B2E
	v_add_f32_e32 v38, v38, v66                                // 000000DB7CA0: 064C8526
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB7CA4: BF8700A2
	v_mov_b32_dpp v69, v46 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7CA8: 7E8A02FA FF01682E
	v_cndmask_b32_e64 v46, -v46, v46, s3                       // 000000DB7CB0: D501002E 200E5D2E
	v_add_f32_e32 v46, v46, v69                                // 000000DB7CB8: 065C8B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7CBC: BF870091
	v_mul_f32_e32 v46, 0x3db504f3, v46                         // 000000DB7CC0: 105C5CFF 3DB504F3
	v_fma_mix_f32 v9, v9, v46, neg(0) op_sel_hi:[1,0,0]        // 000000DB7CC8: CC200009 8A025D09
	v_mul_f32_e32 v46, 0xbfb8aa3b, v27                         // 000000DB7CD0: 105C36FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7CD8: BF870112
	v_mul_f32_e32 v30, 0xbfb8aa3b, v9                          // 000000DB7CDC: 103C12FF BFB8AA3B
	v_exp_f32_e32 v46, v46                                     // 000000DB7CE4: 7E5C4B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB7CE8: BF870291
	v_exp_f32_e32 v30, v30                                     // 000000DB7CEC: 7E3C4B1E
	v_add_f32_e32 v30, 1.0, v30                                // 000000DB7CF0: 063C3CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7CF4: BF870121
	v_div_scale_f32 v52, null, v30, v30, v9                    // 000000DB7CF8: D6FC7C34 04263D1E
	v_div_scale_f32 v53, s4, v9, v30, v9                       // 000000DB7D00: D6FC0435 04263D09
	v_rcp_f32_e32 v67, v52                                     // 000000DB7D08: 7E865534
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7D0C: BF870095
	v_fma_f32 v83, -v52, v67, 1.0                              // 000000DB7D10: D6130053 23CA8734
	v_dual_add_f32 v42, v42, v58 :: v_dual_fmac_f32 v67, v83, v67// 000000DB7D18: C900752A 2A428753
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB7D20: BF8701A1
	v_mov_b32_dpp v58, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7D24: 7E7402FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB7D2C: D501002A 200E552A
	v_mul_f32_e32 v84, v53, v67                                // 000000DB7D34: 10A88735
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7D38: BF870122
	v_add_f32_e32 v42, v42, v58                                // 000000DB7D3C: 0654752A
	v_div_scale_f32 v58, null, v35, v35, v12                   // 000000DB7D40: D6FC7C3A 04324723
	v_mul_f32_e32 v42, 0x3db504f3, v42                         // 000000DB7D48: 105454FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7D50: BF870092
	v_rcp_f32_e32 v69, v58                                     // 000000DB7D54: 7E8A553A
	v_fma_mix_f32 v10, v10, v42, neg(0) op_sel_hi:[1,0,0]      // 000000DB7D58: CC20000A 8A02550A
	v_mul_f32_e32 v42, 0xbfb8aa3b, v20                         // 000000DB7D60: 105428FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DB7D68: BF870311
	v_exp_f32_e32 v42, v42                                     // 000000DB7D6C: 7E544B2A
	v_fma_f32 v85, -v58, v69, 1.0                              // 000000DB7D70: D6130055 23CA8B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7D78: BF870091
	v_dual_add_f32 v44, v44, v60 :: v_dual_fmac_f32 v69, v85, v69// 000000DB7D7C: C900792C 2C448B55
	v_mov_b32_dpp v60, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7D84: 7E7802FA FF01682C
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000DB7D8C: D501002C 200E592C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB7D94: BF8701B5
	v_dual_mul_f32 v85, v76, v68 :: v_dual_add_f32 v42, 1.0, v42// 000000DB7D98: C8C8894C 552A54F2
	v_mov_b32_dpp v66, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB7DA0: 7E8402FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000DB7DA8: D5010026 200E4D26
	v_fma_f32 v91, -v54, v85, v76                              // 000000DB7DB0: D613005B 2532AB36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7DB8: BF870114
	v_div_scale_f32 v59, null, v42, v42, v20                   // 000000DB7DBC: D6FC7C3B 0452552A
	v_dual_add_f32 v38, v38, v66 :: v_dual_fmac_f32 v85, v91, v68// 000000DB7DC4: C9008526 2654895B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7DCC: BF870092
	v_rcp_f32_e32 v70, v59                                     // 000000DB7DD0: 7E8C553B
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000DB7DD4: 104C4CFF 3DB504F3
	s_waitcnt vmcnt(1)                                         // 000000DB7DDC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB7DE0: BF870291
	v_fma_mix_f32 v13, v13, v38, neg(0) op_sel_hi:[1,0,0]      // 000000DB7DE4: CC20000D 8A024D0D
	v_fma_f32 v86, -v59, v70, 1.0                              // 000000DB7DEC: D6130056 23CA8D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB7DF4: BF870131
	v_fmac_f32_e32 v70, v86, v70                               // 000000DB7DF8: 568C8D56
	v_add_f32_e32 v44, v44, v60                                // 000000DB7DFC: 0658792C
	v_div_scale_f32 v60, null, v37, v37, v21                   // 000000DB7E00: D6FC7C3C 04564B25
	v_mul_f32_e32 v44, 0x3db504f3, v44                         // 000000DB7E08: 105858FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7E10: BF870092
	v_rcp_f32_e32 v74, v60                                     // 000000DB7E14: 7E94553C
	v_fma_mix_f32 v29, v29, v44, neg(0) op_sel_hi:[1,0,0]      // 000000DB7E18: CC20001D 8A02591D
	v_add_f32_e32 v44, 1.0, v46                                // 000000DB7E20: 06585CF2
	v_div_scale_f32 v46, null, v34, v34, v8                    // 000000DB7E24: D6FC7C2E 04224522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7E2C: BF870115
	v_fma_f32 v90, -v60, v74, 1.0                              // 000000DB7E30: D613005A 23CA953C
	v_rcp_f32_e32 v66, v46                                     // 000000DB7E38: 7E84552E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB7E3C: BF8702A1
	v_fmac_f32_e32 v74, v90, v74                               // 000000DB7E40: 5694955A
	v_fma_f32 v90, -v52, v84, v53                              // 000000DB7E44: D613005A 24D6A934
	v_fma_f32 v82, -v46, v66, 1.0                              // 000000DB7E4C: D6130052 23CA852E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7E54: BF870112
	v_fmac_f32_e32 v84, v90, v67                               // 000000DB7E58: 56A8875A
	v_fmac_f32_e32 v66, v82, v66                               // 000000DB7E5C: 56848552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB7E60: BF870091
	v_mul_f32_e32 v83, v51, v66                                // 000000DB7E64: 10A68533
	v_fma_f32 v86, -v46, v83, v51                              // 000000DB7E68: D6130056 24CEA72E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7E70: BF870121
	v_fmac_f32_e32 v83, v86, v66                               // 000000DB7E74: 56A68556
	v_div_scale_f32 v86, s7, v20, v42, v20                     // 000000DB7E78: D6FC0756 04525514
	v_fma_f32 v46, -v46, v83, v51                              // 000000DB7E80: D613002E 24CEA72E
	v_fma_f32 v51, -v52, v84, v53                              // 000000DB7E88: D6130033 24D6A934
	v_fma_f32 v52, -v54, v85, v76                              // 000000DB7E90: D6130034 2532AB36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB7E98: BF870214
	v_mul_f32_e32 v91, v86, v70                                // 000000DB7E9C: 10B68D56
	v_div_fmas_f32 v46, v46, v66, v83                          // 000000DB7EA0: D637002E 054E852E
	s_mov_b32 vcc_lo, s4                                       // 000000DB7EA8: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB7EAC: BE84007E
	v_div_fmas_f32 v51, v51, v67, v84                          // 000000DB7EB0: D6370033 05528733
	s_mov_b32 vcc_lo, s5                                       // 000000DB7EB8: BEEA0005
	v_div_fixup_f32 v8, v46, v34, v8                           // 000000DB7EBC: D6270008 0422452E
	v_div_fmas_f32 v52, v52, v68, v85                          // 000000DB7EC4: D6370034 05568934
	s_mov_b32 vcc_lo, s6                                       // 000000DB7ECC: BEEA0006
	v_div_fixup_f32 v9, v51, v30, v9                           // 000000DB7ED0: D6270009 04263D33
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB7ED8: BE8500FF 3DB504F3
	v_mul_f32_e32 v7, v7, v8                                   // 000000DB7EE0: 100E1107
	v_div_fixup_f32 v11, v52, v36, v11                         // 000000DB7EE4: D627000B 042E4934
	v_add_f32_e32 v50, v50, v62                                // 000000DB7EEC: 06647D32
	v_div_scale_f32 v62, null, v44, v44, v27                   // 000000DB7EF0: D6FC7C3E 046E592C
	v_mul_f32_e32 v9, v10, v9                                  // 000000DB7EF8: 1012130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB7EFC: BF870193
	v_dual_mul_f32 v11, v28, v11 :: v_dual_mul_f32 v50, 0x3db504f3, v50// 000000DB7F00: C8C6171C 0B3264FF 3DB504F3
	v_rcp_f32_e32 v77, v62                                     // 000000DB7F0C: 7E9A553E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB7F10: BF870291
	v_fma_mix_f32 v18, v18, v50, neg(0) op_sel_hi:[1,0,0]      // 000000DB7F14: CC200012 8A026512
	v_fma_f32 v82, -v62, v77, 1.0                              // 000000DB7F1C: D6130052 23CA9B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB7F24: BF8700A1
	v_fmac_f32_e32 v77, v82, v77                               // 000000DB7F28: 569A9B52
	v_mul_f32_e32 v82, v78, v69                                // 000000DB7F2C: 10A48B4E
	v_fma_f32 v90, -v58, v82, v78                              // 000000DB7F30: D613005A 253AA53A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB7F38: BF870121
	v_fmac_f32_e32 v82, v90, v69                               // 000000DB7F3C: 56A48B5A
	v_fma_f32 v90, -v59, v91, v86                              // 000000DB7F40: D613005A 255AB73B
	v_fma_f32 v53, -v58, v82, v78                              // 000000DB7F48: D6130035 253AA53A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB7F50: BF8701A2
	v_fmac_f32_e32 v91, v90, v70                               // 000000DB7F54: 56B68D5A
	v_div_scale_f32 v90, s8, v21, v37, v21                     // 000000DB7F58: D6FC085A 04564B15
	v_div_fmas_f32 v34, v53, v69, v82                          // 000000DB7F60: D6370022 054A8B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB7F68: BF870193
	v_fma_f32 v54, -v59, v91, v86                              // 000000DB7F6C: D6130036 255AB73B
	v_mul_f32_e32 v92, v90, v74                                // 000000DB7F74: 10B8955A
	global_load_d16_b16 v59, v[4:5], off offset:32             // 000000DB7F78: DC820020 3B7C0004
	s_mov_b32 vcc_lo, s7                                       // 000000DB7F80: BEEA0007
	v_div_fixup_f32 v8, v34, v35, v12                          // 000000DB7F84: D6270008 04324722
	v_div_fmas_f32 v30, v54, v70, v91                          // 000000DB7F8C: D637001E 056E8D36
	v_fma_f32 v93, -v60, v92, v90                              // 000000DB7F94: D613005D 256AB93C
	s_mov_b32 vcc_lo, s8                                       // 000000DB7F9C: BEEA0008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB7FA0: BF870193
	v_mul_f32_e32 v8, v29, v8                                  // 000000DB7FA4: 1010111D
	v_div_fixup_f32 v20, v30, v42, v20                         // 000000DB7FA8: D6270014 0452551E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB7FB0: BF8701A3
	v_fmac_f32_e32 v92, v93, v74                               // 000000DB7FB4: 56B8955D
	v_div_scale_f32 v93, s9, v26, v43, v26                     // 000000DB7FB8: D6FC095D 046A571A
	v_mul_f32_e32 v14, v14, v20                                // 000000DB7FC0: 101C290E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB7FC4: BF870193
	v_fma_f32 v58, -v60, v92, v90                              // 000000DB7FC8: D613003A 256AB93C
	v_mul_f32_e32 v94, v93, v75                                // 000000DB7FD0: 10BC975D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7FD4: BF870112
	v_div_fmas_f32 v10, v58, v74, v92                          // 000000DB7FD8: D637000A 0572953A
	v_fma_f32 v98, -v61, v94, v93                              // 000000DB7FE0: D6130062 2576BD3D
	s_mov_b32 vcc_lo, s9                                       // 000000DB7FE8: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB7FEC: BF870112
	v_div_fixup_f32 v10, v10, v37, v21                         // 000000DB7FF0: D627000A 04564B0A
	v_fmac_f32_e32 v94, v98, v75                               // 000000DB7FF8: 56BC9762
	v_div_scale_f32 v98, s10, v27, v44, v27                    // 000000DB7FFC: D6FC0A62 046E591B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB8004: BF870193
	v_mul_f32_e32 v10, v18, v10                                // 000000DB8008: 10141512
	v_fma_f32 v60, -v61, v94, v93                              // 000000DB800C: D613003C 2576BD3D
	s_clause 0x6                                               // 000000DB8014: BF850006
	global_load_d16_b16 v61, v[4:5], off offset:96             // 000000DB8018: DC820060 3D7C0004
	global_load_d16_b16 v66, v[4:5], off offset:160            // 000000DB8020: DC8200A0 427C0004
	global_load_d16_b16 v67, v[4:5], off offset:224            // 000000DB8028: DC8200E0 437C0004
	global_load_d16_b16 v68, v[4:5], off offset:192            // 000000DB8030: DC8200C0 447C0004
	global_load_d16_b16 v76, v[4:5], off offset:128            // 000000DB8038: DC820080 4C7C0004
	global_load_d16_b16 v78, v[4:5], off offset:64             // 000000DB8040: DC820040 4E7C0004
	global_load_d16_b16 v83, v[4:5], off                       // 000000DB8048: DC820000 537C0004
	v_mul_f32_e32 v99, v98, v77                                // 000000DB8050: 10C69B62
	v_div_fmas_f32 v28, v60, v75, v94                          // 000000DB8054: D637001C 057A973C
	s_mov_b32 vcc_lo, s10                                      // 000000DB805C: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB8060: BF870112
	v_fma_f32 v100, -v62, v99, v98                             // 000000DB8064: D6130064 258AC73E
	v_div_fixup_f32 v18, v28, v43, v26                         // 000000DB806C: D6270012 046A571C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB8074: BF870112
	v_fmac_f32_e32 v99, v100, v77                              // 000000DB8078: 56C69B64
	v_mul_f32_e32 v13, v13, v18                                // 000000DB807C: 101A250D
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 000000DB8080: 102C2CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB8088: BF870123
	v_fma_f32 v12, -v62, v99, v98                              // 000000DB808C: D613000C 258AC73E
	s_waitcnt vmcnt(8)                                         // 000000DB8094: BF8923F7
	v_fma_mix_f32 v19, v19, v22, neg(0) op_sel_hi:[1,0,0]      // 000000DB8098: CC200013 8A022D13
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB80A0: BF870092
	v_div_fmas_f32 v12, v12, v77, v99                          // 000000DB80A4: D637000C 058E9B0C
	v_div_fixup_f32 v12, v12, v44, v27                         // 000000DB80AC: D627000C 046E590C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB80B4: BF870001
	v_mul_f32_e32 v12, v19, v12                                // 000000DB80B8: 10181913
	s_waitcnt vmcnt(7)                                         // 000000DB80BC: BF891FF7
	v_fma_mix_f32 v9, v59, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB80C0: CC200009 8A02133B
	s_waitcnt vmcnt(6)                                         // 000000DB80C8: BF891BF7
	v_fma_mix_f32 v8, v61, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB80CC: CC200008 8A02113D
	s_waitcnt vmcnt(5)                                         // 000000DB80D4: BF8917F7
	v_fma_mix_f32 v10, v66, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB80D8: CC20000A 8A021542
	s_waitcnt vmcnt(4)                                         // 000000DB80E0: BF8913F7
	v_fma_mix_f32 v12, v67, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB80E4: CC20000C 8A021943
	s_waitcnt vmcnt(1)                                         // 000000DB80EC: BF8907F7
	v_fma_mix_f32 v19, v11, v78, v8 op_sel_hi:[0,1,0]          // 000000DB80F0: CC200013 14229D0B
	s_waitcnt vmcnt(0)                                         // 000000DB80F8: BF8903F7
	v_fma_mix_f32 v18, v7, v83, v9 op_sel_hi:[0,1,0]           // 000000DB80FC: CC200012 1426A707
	v_fma_mix_f32 v20, v14, v76, v10 op_sel_hi:[0,1,0]         // 000000DB8104: CC200014 142A990E
	v_fma_mix_f32 v21, v13, v68, v12 op_sel_hi:[0,1,0]         // 000000DB810C: CC200015 1432890D
	v_fma_mix_f32 v7, v7, v83, -v9 op_sel_hi:[0,1,0]           // 000000DB8114: CC200007 9426A707
	v_fma_mix_f32 v8, v11, v78, -v8 op_sel_hi:[0,1,0]          // 000000DB811C: CC200008 94229D0B
	v_add_f32_e32 v22, v18, v19                                // 000000DB8124: 062C2712
	v_fma_mix_f32 v10, v14, v76, -v10 op_sel_hi:[0,1,0]        // 000000DB8128: CC20000A 942A990E
	v_add_f32_e32 v26, v20, v21                                // 000000DB8130: 06342B14
	v_fma_mix_f32 v11, v13, v68, -v12 op_sel_hi:[0,1,0]        // 000000DB8134: CC20000B 9432890D
	v_dual_sub_f32 v12, v18, v19 :: v_dual_add_f32 v13, v7, v8 // 000000DB813C: C9482712 0C0C1107
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB8144: 080E1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB8148: BF870214
	v_add_f32_e32 v9, v22, v26                                 // 000000DB814C: 06123516
	v_add_f32_e32 v8, v10, v11                                 // 000000DB8150: 0610170A
	v_sub_f32_e32 v18, v20, v21                                // 000000DB8154: 08242B14
	v_sub_f32_e32 v10, v10, v11                                // 000000DB8158: 0814170A
	v_sub_f32_e32 v11, v22, v26                                // 000000DB815C: 08163516
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8160: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB8168: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB8170: BF870113
	v_cndmask_b32_e64 v26, -v11, v11, s0                       // 000000DB8174: D501001A 2002170B
	v_add_f32_e32 v9, v9, v14                                  // 000000DB817C: 06121D09
	v_add_f32_e32 v14, v13, v8                                 // 000000DB8180: 061C110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v18 // 000000DB8184: C948110D 0D08250C
	v_sub_f32_e32 v18, v12, v18                                // 000000DB818C: 0824250C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB8190: BF870004
	v_mov_b32_dpp v19, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8194: 7E2602FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB819C: D5010009 20061309
	v_mov_b32_dpp v20, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB81A4: 7E2802FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB81AC: D501000E 20021D0E
	v_mov_b32_dpp v21, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB81B4: 7E2A02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB81BC: D5010008 20021108
	v_add_f32_e32 v9, v9, v19                                  // 000000DB81C4: 06122709
	v_mov_b32_dpp v27, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB81C8: 7E3602FA FF016112
	v_add_f32_e32 v12, v14, v20                                // 000000DB81D0: 0618290E
	v_add_f32_e32 v14, v7, v10                                 // 000000DB81D4: 061C1507
	v_add_f32_e32 v8, v8, v21                                  // 000000DB81D8: 06102B08
	v_mov_b32_dpp v19, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB81DC: 7E2602FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DB81E4: D5010009 200A1309
	v_mov_b32_dpp v20, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB81EC: 7E2802FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB81F4: D501000C 2006190C
	v_mov_b32_dpp v21, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB81FC: 7E2A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB8204: D5010008 20061108
	v_mov_b32_dpp v22, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB820C: 7E2C02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB8214: D501000E 20021D0E
	v_add_f32_e32 v12, v12, v20                                // 000000DB821C: 0618290C
	v_sub_f32_e32 v20, v7, v10                                 // 000000DB8220: 08281507
	v_dual_add_f32 v8, v8, v21 :: v_dual_add_f32 v7, v9, v19   // 000000DB8224: C9082B08 08062709
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB822C: BF870234
	v_add_f32_e32 v9, v14, v22                                 // 000000DB8230: 06122D0E
	v_mov_b32_dpp v22, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8234: 7E2C02FA FF01610B
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DB823C: D5010012 20022512
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8244: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB824C: D5010008 200A1108
	v_mov_b32_dpp v19, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8254: 7E2602FA FF016209
	v_cndmask_b32_e64 v21, -v9, v9, s1                         // 000000DB825C: D5010015 20061309
	v_mov_b32_dpp v28, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8264: 7E3802FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000DB826C: D5010014 20022914
	v_add_f32_e32 v11, v8, v14                                 // 000000DB8274: 06161D08
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8278: 7E1402FA FF01640C
	v_dual_add_f32 v14, v21, v19 :: v_dual_add_f32 v19, v26, v22// 000000DB8280: C9082715 0E122D1A
	v_mov_b32_dpp v26, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8288: 7E3402FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB8290: D501000D 20021B0D
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DB8298: D501000C 200A190C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB82A0: BF870004
	v_mov_b32_dpp v21, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB82A4: 7E2A02FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB82AC: D501000E 200A1D0E
	v_mov_b32_dpp v22, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB82B4: 7E2C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000DB82BC: D5010013 20062713
	v_add_f32_e32 v26, v13, v26                                // 000000DB82C4: 0634350D
	v_add_f32_e32 v9, v12, v10                                 // 000000DB82C8: 0612150C
	v_add_f32_e32 v13, v14, v21                                // 000000DB82CC: 061A2B0E
	v_add_f32_e32 v14, v18, v27                                // 000000DB82D0: 061C3712
	v_dual_add_f32 v18, v19, v22 :: v_dual_add_f32 v19, v20, v28// 000000DB82D4: C9082D13 12123914
	v_mov_b32_dpp v20, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB82DC: 7E2802FA FF01621A
	v_cndmask_b32_e64 v21, -v26, v26, s1                       // 000000DB82E4: D5010015 2006351A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB82EC: BF870004
	v_mov_b32_dpp v22, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB82F0: 7E2C02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB82F8: D501000E 20061D0E
	v_mov_b32_dpp v26, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8300: 7E3402FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000DB8308: D5010013 20062713
	v_add_f32_e32 v20, v21, v20                                // 000000DB8310: 06282915
	v_mov_b32_dpp v21, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8314: 7E2A02FA FF016412
	v_add_f32_e32 v14, v14, v22                                // 000000DB831C: 061C2D0E
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB8320: D5010012 200A2512
	v_add_f32_e32 v19, v19, v26                                // 000000DB8328: 06263513
	v_mov_b32_dpp v22, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB832C: 7E2C02FA FF016414
	v_cndmask_b32_e64 v26, -v20, v20, s2                       // 000000DB8334: D501001A 200A2914
	v_mov_b32_dpp v27, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB833C: 7E3602FA FF01640E
	v_cndmask_b32_e64 v28, -v14, v14, s2                       // 000000DB8344: D501001C 200A1D0E
	v_mov_b32_dpp v29, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB834C: 7E3A02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000DB8354: D5010013 200A2713
	v_add_f32_e32 v20, v18, v21                                // 000000DB835C: 06282B12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB8360: BF870224
	v_dual_add_f32 v21, v26, v22 :: v_dual_add_f32 v26, v28, v27// 000000DB8364: C9082D1A 151A371C
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB836C: 7E1002FA FF016807
	v_add_f32_e32 v28, v19, v29                                // 000000DB8374: 06383B13
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8378: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8380: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8388: 7E1C02FA FF01680D
	v_add_nc_u32_e32 v18, 8, v6                                // 000000DB8390: 4A240C88
	v_mov_b32_dpp v19, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8394: 7E2602FA FF016814
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB839C: 7E2C02FA FF016815
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB83A4: 7E3602FA FF01681A
	v_mov_b32_dpp v29, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB83AC: 7E3A02FA FF01681C
	.long 0xd4c4007e                                           // 000000DB83B4: D4C4007E
	v_cndmask_b32_e32 v1, s23, v18, vcc_lo                     // 000000DB83B8: 02022417
	s_cbranch_execz 60                                         // 000000DB83BC: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x58b0>
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000DB83C0: D501001A 200E351A
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB83C8: D5010007 200E0F07
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000DB83D0: D5010014 200E2914
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB83D8: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DB83E0: D501000B 200E170B
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DB83E8: D501000D 200E1B0D
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB83F0: D501001C 200E391C
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000DB83F8: D5010015 200E2B15
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v7, v7, v8  // 000000DB8400: C908371A 1A061107
	v_dual_add_f32 v19, v20, v19 :: v_dual_add_f32 v8, v9, v10 // 000000DB8408: C9082714 13081509
	v_dual_add_f32 v9, v11, v12 :: v_dual_add_f32 v10, v13, v14// 000000DB8410: C908190B 090A1D0D
	v_mad_i64_i32 v[11:12], null, 0x500, v18, v[0:1]           // 000000DB8418: D6FF7C0B 040224FF 00000500
	v_dual_add_f32 v28, v28, v29 :: v_dual_add_f32 v21, v21, v22// 000000DB8424: C9083B1C 1C142D15
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB842C: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB8434: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB843C: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000DB8444: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v19, s5, 0                             // 000000DB844C: CC210009 02000B13
	v_fma_mixhi_f16 v9, v21, s5, 0                             // 000000DB8454: CC220009 02000B15
	v_fma_mixlo_f16 v10, v26, s5, 0                            // 000000DB845C: CC21000A 02000B1A
	v_fma_mixhi_f16 v10, v28, s5, 0                            // 000000DB8464: CC22000A 02000B1C
	s_clause 0x7                                               // 000000DB846C: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000DB8470: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000DB8478: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000DB8480: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000DB8488: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000DB8490: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000DB8498: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000DB84A0: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000DB84A8: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB84B0: 8C7E047E
	s_clause 0xb                                               // 000000DB84B4: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB84B8: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB84C0: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB84C8: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB84D0: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DB84D8: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000DB84E0: DC820060 0C7C0002
	global_load_d16_b16 v19, v[2:3], off offset:128            // 000000DB84E8: DC820080 137C0002
	global_load_d16_b16 v20, v[2:3], off offset:160            // 000000DB84F0: DC8200A0 147C0002
	global_load_d16_b16 v21, v[2:3], off offset:192            // 000000DB84F8: DC8200C0 157C0002
	global_load_d16_b16 v22, v[2:3], off offset:224            // 000000DB8500: DC8200E0 167C0002
	global_load_d16_b16 v26, v[2:3], off offset:1344           // 000000DB8508: DC820540 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:1376           // 000000DB8510: DC820560 1B7C0002
	v_add_f32_e32 v46, v39, v31                                // 000000DB8518: 065C3F27
	v_sub_f32_e32 v31, v39, v31                                // 000000DB851C: 083E3F27
	v_add_f32_e32 v39, v23, v15                                // 000000DB8520: 064E1F17
	v_sub_f32_e32 v38, v87, v79                                // 000000DB8524: 084C9F57
	v_add_f32_e32 v44, v55, v47                                // 000000DB8528: 06585F37
	v_sub_f32_e32 v45, v55, v47                                // 000000DB852C: 085A5F37
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB8530: BF870004
	v_add_f32_e32 v50, v46, v39                                // 000000DB8534: 06644F2E
	v_sub_f32_e32 v36, v103, v95                               // 000000DB8538: 0848BF67
	v_add_f32_e32 v30, v119, v111                              // 000000DB853C: 063CDF77
	v_sub_f32_e32 v29, v135, v127                              // 000000DB8540: 083AFF87
	v_sub_f32_e32 v34, v119, v111                              // 000000DB8544: 0844DF77
	v_add_f32_e32 v28, v135, v127                              // 000000DB8548: 0638FF87
	v_add_f32_e32 v35, v103, v95                               // 000000DB854C: 0646BF67
	v_add_f32_e32 v37, v87, v79                                // 000000DB8550: 064A9F57
	v_sub_f32_e32 v39, v46, v39                                // 000000DB8554: 084E4F2E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB8558: BF870004
	v_add_f32_e32 v47, v28, v30                                // 000000DB855C: 065E3D1C
	v_sub_f32_e32 v28, v28, v30                                // 000000DB8560: 08383D1C
	v_add_f32_e32 v30, v29, v34                                // 000000DB8564: 063C451D
	v_dual_sub_f32 v29, v29, v34 :: v_dual_add_f32 v34, v35, v37// 000000DB8568: C948451D 1D224B23
	v_sub_f32_e32 v35, v35, v37                                // 000000DB8570: 08464B23
	v_add_f32_e32 v37, v36, v38                                // 000000DB8574: 064A4D24
	v_sub_f32_e32 v36, v36, v38                                // 000000DB8578: 08484D24
	v_add_f32_e32 v42, v71, v63                                // 000000DB857C: 06547F47
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB8580: BF8701A2
	v_dual_add_f32 v52, v28, v35 :: v_dual_add_f32 v51, v29, v36// 000000DB8584: C908471C 3432491D
	v_sub_f32_e32 v29, v29, v36                                // 000000DB858C: 083A491D
	v_dual_sub_f32 v43, v71, v63 :: v_dual_add_f32 v38, v42, v44// 000000DB8590: C9487F47 2B26592A
	v_sub_f32_e32 v42, v42, v44                                // 000000DB8598: 0854592A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB859C: BF870214
	v_mov_b32_dpp v62, v51 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB85A0: 7E7C02FA FF016133
	v_mov_b32_dpp v68, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB85A8: 7E8802FA FF01611D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB85B0: BF870004
	v_add_f32_e32 v44, v43, v45                                // 000000DB85B4: 06585B2B
	v_sub_f32_e32 v23, v23, v15                                // 000000DB85B8: 082E1F17
	v_sub_f32_e32 v43, v43, v45                                // 000000DB85BC: 08565B2B
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000DB85C0: D501001D 20023B1D
	v_cndmask_b32_e64 v51, -v51, v51, s0                       // 000000DB85C8: D5010033 20026733
	s_clause 0x3                                               // 000000DB85D0: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000DB85D4: DC820580 0E7C0002
	global_load_d16_b16 v15, v[2:3], off offset:1440           // 000000DB85DC: DC8205A0 0F7C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000DB85E4: DC8205C0 0D7C0002
	global_load_d16_b16 v18, v[2:3], off offset:1504           // 000000DB85EC: DC8205E0 127C0002
	v_add_f32_e32 v45, v31, v23                                // 000000DB85F4: 065A2F1F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB85F8: BF870001
	v_dual_add_f32 v29, v29, v68 :: v_dual_add_f32 v46, v44, v45// 000000DB85FC: C908891D 1D2E5B2C
	v_dual_sub_f32 v44, v44, v45 :: v_dual_sub_f32 v23, v31, v23// 000000DB8604: C94A5B2C 2C162F1F
	v_add_f32_e32 v31, v38, v50                                // 000000DB860C: 063E6526
	v_sub_f32_e32 v38, v38, v50                                // 000000DB8610: 084C6526
	v_add_f32_e32 v45, v42, v39                                // 000000DB8614: 065A4F2A
	v_dual_sub_f32 v39, v42, v39 :: v_dual_add_f32 v50, v47, v34// 000000DB8618: C9484F2A 2732452F
	v_mov_b32_dpp v54, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8620: 7E6C02FA FF01612C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB8628: BF870004
	v_mov_b32_dpp v53, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB862C: 7E6A02FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000DB8634: D5010026 20024D26
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000DB863C: D501002C 2002592C
	v_sub_f32_e32 v34, v47, v34                                // 000000DB8644: 0844452F
	v_mov_b32_dpp v36, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8648: 7E4802FA FF01612E
	v_mov_b32_dpp v59, v50 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8650: 7E7602FA FF016132
	v_add_f32_e32 v38, v38, v53                                // 000000DB8658: 064C6B26
	v_add_f32_e32 v42, v43, v23                                // 000000DB865C: 06542F2B
	v_sub_f32_e32 v23, v43, v23                                // 000000DB8660: 082E2F2B
	v_add_f32_e32 v43, v30, v37                                // 000000DB8664: 06564B1E
	v_sub_f32_e32 v30, v30, v37                                // 000000DB8668: 083C4B1E
	v_cndmask_b32_e64 v37, -v46, v46, s0                       // 000000DB866C: D5010025 20025D2E
	v_mov_b32_dpp v47, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8674: 7E5E02FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000DB867C: D501002A 2002552A
	v_mov_b32_dpp v60, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8684: 7E7802FA FF01612B
	v_cndmask_b32_e64 v43, -v43, v43, s0                       // 000000DB868C: D501002B 2002572B
	v_sub_f32_e32 v28, v28, v35                                // 000000DB8694: 0838471C
	v_mov_b32_dpp v35, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8698: 7E4602FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000DB86A0: D501001F 20023F1F
	v_mov_b32_dpp v46, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB86A8: 7E5C02FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000DB86B0: D501002D 20025B2D
	v_cndmask_b32_e64 v50, -v50, v50, s0                       // 000000DB86B8: D5010032 20026532
	v_mov_b32_dpp v55, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB86C0: 7E6E02FA FF016127
	v_add_f32_e32 v31, v31, v35                                // 000000DB86C8: 063E471F
	v_add_f32_e32 v35, v37, v36                                // 000000DB86CC: 06464925
	v_dual_add_f32 v37, v42, v47 :: v_dual_add_f32 v42, v44, v54// 000000DB86D0: C9085F2A 252A6D2C
	v_mov_b32_dpp v58, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB86D8: 7E7402FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000DB86E0: D5010017 20022F17
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000DB86E8: D5010027 20024F27
	v_mov_b32_dpp v66, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB86F0: 7E8402FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000DB86F8: D501001E 20023D1E
	v_add_f32_e32 v36, v45, v46                                // 000000DB8700: 06485D2D
	v_add_f32_e32 v23, v23, v58                                // 000000DB8704: 062E7517
	v_mov_b32_dpp v61, v52 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8708: 7E7A02FA FF016134
	v_cndmask_b32_e64 v52, -v52, v52, s0                       // 000000DB8710: D5010034 20026934
	v_dual_add_f32 v44, v50, v59 :: v_dual_add_f32 v45, v51, v62// 000000DB8718: C9087732 2C2C7D33
	v_mov_b32_dpp v63, v34 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB8720: 7E7E02FA FF016122
	v_cndmask_b32_e64 v34, -v34, v34, s0                       // 000000DB8728: D5010022 20024522
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB8730: BF870244
	v_dual_add_f32 v46, v52, v61 :: v_dual_add_f32 v39, v39, v55// 000000DB8734: C9087B34 2E266F27
	v_add_f32_e32 v30, v30, v66                                // 000000DB873C: 063C851E
	v_mov_b32_dpp v62, v45 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8740: 7E7C02FA FF01622D
	v_cndmask_b32_e64 v45, -v45, v45, s1                       // 000000DB8748: D501002D 20065B2D
	v_mov_b32_dpp v61, v46 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8750: 7E7A02FA FF01622E
	v_cndmask_b32_e64 v46, -v46, v46, s1                       // 000000DB8758: D501002E 20065D2E
	v_mov_b32_dpp v47, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8760: 7E5E02FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000DB8768: D501001F 20063F1F
	v_mov_b32_dpp v50, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8770: 7E6402FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000DB8778: D5010023 20064723
	v_add_f32_e32 v34, v34, v63                                // 000000DB8780: 06447F22
	v_mov_b32_dpp v53, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8784: 7E6A02FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000DB878C: D5010026 20064D26
	v_mov_b32_dpp v66, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8794: 7E8402FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000DB879C: D501001E 20063D1E
	v_dual_add_f32 v45, v45, v62 :: v_dual_add_f32 v46, v46, v61// 000000DB87A4: C9087D2D 2D2E7B2E
	v_add_f32_e32 v43, v43, v60                                // 000000DB87AC: 0656792B
	v_mov_b32_dpp v67, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB87B0: 7E8602FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000DB87B8: D501001C 2002391C
	v_mov_b32_dpp v68, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB87C0: 7E8802FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000DB87C8: D501001D 20063B1D
	v_dual_add_f32 v31, v31, v47 :: v_dual_add_f32 v38, v38, v53// 000000DB87D0: C9085F1F 1F266B26
	v_add_f32_e32 v35, v35, v50                                // 000000DB87D8: 06466523
	v_mov_b32_dpp v63, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB87DC: 7E7E02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB87E4: D5010022 20064522
	v_dual_add_f32 v30, v30, v66 :: v_dual_add_f32 v29, v29, v68// 000000DB87EC: C908851E 1E1C891D
	v_mov_b32_dpp v61, v46 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB87F4: 7E7A02FA FF01642E
	v_mov_b32_dpp v62, v45 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB87FC: 7E7C02FA FF01642D
	v_cndmask_b32_e64 v45, -v45, v45, s2                       // 000000DB8804: D501002D 200A5B2D
	v_cndmask_b32_e64 v46, -v46, v46, s2                       // 000000DB880C: D501002E 200A5D2E
	v_mov_b32_dpp v52, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8814: 7E6802FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000DB881C: D5010025 20064B25
	v_add_f32_e32 v28, v28, v67                                // 000000DB8824: 0638871C
	v_mov_b32_dpp v59, v44 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8828: 7E7602FA FF01622C
	v_mov_b32_dpp v60, v43 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8830: 7E7802FA FF01622B
	v_cndmask_b32_e64 v43, -v43, v43, s1                       // 000000DB8838: D501002B 2006572B
	v_cndmask_b32_e64 v44, -v44, v44, s1                       // 000000DB8840: D501002C 2006592C
	v_mov_b32_dpp v47, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8848: 7E5E02FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000DB8850: D501001F 200A3F1F
	v_mov_b32_dpp v50, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8858: 7E6402FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000DB8860: D5010023 200A4723
	v_add_f32_e32 v34, v34, v63                                // 000000DB8868: 06447F22
	v_mov_b32_dpp v53, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB886C: 7E6A02FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000DB8874: D5010026 200A4D26
	v_mov_b32_dpp v66, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB887C: 7E8402FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000DB8884: D501001E 200A3D1E
	v_dual_add_f32 v45, v45, v62 :: v_dual_add_f32 v46, v46, v61// 000000DB888C: C9087D2D 2D2E7B2E
	v_add_f32_e32 v37, v37, v52                                // 000000DB8894: 064A6925
	v_mov_b32_dpp v67, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8898: 7E8602FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000DB88A0: D501001C 2006391C
	v_dual_add_f32 v43, v43, v60 :: v_dual_add_f32 v44, v44, v59// 000000DB88A8: C908792B 2B2C772C
	v_mov_b32_dpp v68, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB88B0: 7E8802FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000DB88B8: D501001D 200A3B1D
	v_dual_add_f32 v31, v31, v47 :: v_dual_add_f32 v38, v38, v53// 000000DB88C0: C9085F1F 1F266B26
	v_add_f32_e32 v35, v35, v50                                // 000000DB88C8: 06466523
	v_mov_b32_dpp v63, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB88CC: 7E7E02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000DB88D4: D5010022 200A4522
	v_dual_add_f32 v30, v30, v66 :: v_dual_add_f32 v29, v29, v68// 000000DB88DC: C908851E 1E1C891D
	v_mov_b32_dpp v61, v46 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB88E4: 7E7A02FA FF01682E
	v_mov_b32_dpp v62, v45 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB88EC: 7E7C02FA FF01682D
	v_cndmask_b32_e64 v45, -v45, v45, s3                       // 000000DB88F4: D501002D 200E5B2D
	v_cndmask_b32_e64 v46, -v46, v46, s3                       // 000000DB88FC: D501002E 200E5D2E
	v_mov_b32_dpp v52, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8904: 7E6802FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000DB890C: D5010025 200A4B25
	v_add_f32_e32 v28, v28, v67                                // 000000DB8914: 0638871C
	v_mov_b32_dpp v59, v44 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8918: 7E7602FA FF01642C
	v_mov_b32_dpp v60, v43 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8920: 7E7802FA FF01642B
	v_cndmask_b32_e64 v43, -v43, v43, s2                       // 000000DB8928: D501002B 200A572B
	v_cndmask_b32_e64 v44, -v44, v44, s2                       // 000000DB8930: D501002C 200A592C
	v_mov_b32_dpp v47, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8938: 7E5E02FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000DB8940: D501001F 200E3F1F
	v_mov_b32_dpp v50, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8948: 7E6402FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB8950: D5010023 200E4723
	v_add_f32_e32 v34, v34, v63                                // 000000DB8958: 06447F22
	v_mov_b32_dpp v53, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB895C: 7E6A02FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000DB8964: D5010026 200E4D26
	v_mov_b32_dpp v66, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB896C: 7E8402FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000DB8974: D501001E 200E3D1E
	v_dual_add_f32 v46, v46, v61 :: v_dual_add_f32 v45, v45, v62// 000000DB897C: C9087B2E 2E2C7D2D
	v_add_f32_e32 v37, v37, v52                                // 000000DB8984: 064A6925
	v_mov_b32_dpp v67, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8988: 7E8602FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000DB8990: D501001C 200A391C
	v_dual_add_f32 v43, v43, v60 :: v_dual_add_f32 v44, v44, v59// 000000DB8998: C908792B 2B2C772C
	v_mov_b32_dpp v68, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB89A0: 7E8802FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000DB89A8: D501001D 200E3B1D
	v_dual_add_f32 v31, v31, v47 :: v_dual_add_f32 v38, v38, v53// 000000DB89B0: C9085F1F 1F266B26
	v_add_f32_e32 v35, v35, v50                                // 000000DB89B8: 06466523
	v_mov_b32_dpp v63, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB89BC: 7E7E02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DB89C4: D5010022 200E4522
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB89CC: BF870004
	v_dual_add_f32 v30, v30, v66 :: v_dual_mul_f32 v31, 0x3db504f3, v31// 000000DB89D0: C906851E 1E1E3EFF 3DB504F3
	v_dual_mul_f32 v45, 0x3db504f3, v45 :: v_dual_mul_f32 v46, 0x3db504f3, v46// 000000DB89DC: C8C65AFF 2D2E5CFF 3DB504F3
	v_mov_b32_dpp v52, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB89E8: 7E6802FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000DB89F0: D5010025 200E4B25
	v_add_f32_e32 v28, v28, v67                                // 000000DB89F8: 0638871C
	v_mov_b32_dpp v59, v44 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB89FC: 7E7602FA FF01682C
	v_mov_b32_dpp v60, v43 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8A04: 7E7802FA FF01682B
	v_cndmask_b32_e64 v43, -v43, v43, s3                       // 000000DB8A0C: D501002B 200E572B
	v_cndmask_b32_e64 v44, -v44, v44, s3                       // 000000DB8A14: D501002C 200E592C
	v_dual_add_f32 v34, v34, v63 :: v_dual_add_f32 v29, v29, v68// 000000DB8A1C: C9087F22 221C891D
	v_dual_mul_f32 v30, 0x3db504f3, v30 :: v_dual_add_f32 v37, v37, v52// 000000DB8A24: C8C83CFF 1E246925 3DB504F3
	v_mov_b32_dpp v67, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8A30: 7E8602FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB8A38: D501001C 200E391C
	v_dual_add_f32 v44, v44, v59 :: v_dual_add_f32 v43, v43, v60// 000000DB8A40: C908772C 2C2A792B
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000DB8A48: 103A3AFF 3DB504F3
	v_mov_b32_dpp v51, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8A50: 7E6602FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000DB8A58: D5010024 20064924
	v_mov_b32_dpp v58, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8A60: 7E7402FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000DB8A68: D5010017 20062F17
	v_dual_add_f32 v28, v28, v67 :: v_dual_mul_f32 v37, 0x3db504f3, v37// 000000DB8A70: C906871C 1C244AFF 3DB504F3
	v_dual_mul_f32 v43, 0x3db504f3, v43 :: v_dual_mul_f32 v44, 0x3db504f3, v44// 000000DB8A7C: C8C656FF 2B2C58FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB8A88: BF870243
	v_dual_add_f32 v36, v36, v51 :: v_dual_add_f32 v23, v23, v58// 000000DB8A8C: C9086724 24167517
	v_mov_b32_dpp v54, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8A94: 7E6C02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DB8A9C: D501002A 2006552A
	v_mov_b32_dpp v55, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB8AA4: 7E6E02FA FF016227
	v_mov_b32_dpp v51, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8AAC: 7E6602FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000DB8AB4: D5010024 200A4924
	v_mov_b32_dpp v58, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8ABC: 7E7402FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000DB8AC4: D5010017 200A2F17
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000DB8ACC: D5010027 20064F27
	v_add_f32_e32 v42, v42, v54                                // 000000DB8AD4: 06546D2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB8AD8: BF870193
	v_dual_add_f32 v36, v36, v51 :: v_dual_add_f32 v23, v23, v58// 000000DB8ADC: C9086724 24167517
	v_add_f32_e32 v39, v39, v55                                // 000000DB8AE4: 064E6F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB8AE8: BF870193
	v_mov_b32_dpp v54, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8AEC: 7E6C02FA FF01642A
	v_mov_b32_dpp v51, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8AF4: 7E6602FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000DB8AFC: D5010024 200E4924
	v_mov_b32_dpp v58, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8B04: 7E7402FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000DB8B0C: D5010017 200E2F17
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DB8B14: D501002A 200A552A
	v_mov_b32_dpp v55, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB8B1C: 7E6E02FA FF016427
	v_add_f32_e32 v36, v36, v51                                // 000000DB8B24: 06486724
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000DB8B28: D5010027 200A4F27
	v_add_f32_e32 v23, v23, v58                                // 000000DB8B30: 062E7517
	v_dual_mul_f32 v35, 0x3db504f3, v35 :: v_dual_add_f32 v42, v42, v54// 000000DB8B34: C8C846FF 232A6D2A 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB8B40: BF870193
	v_dual_mul_f32 v36, 0x3db504f3, v36 :: v_dual_add_f32 v39, v39, v55// 000000DB8B44: C8C848FF 24266F27 3DB504F3
	v_dual_mul_f32 v38, 0x3db504f3, v38 :: v_dual_mul_f32 v23, 0x3db504f3, v23// 000000DB8B50: C8C64CFF 26162EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB8B5C: BF870223
	v_mov_b32_dpp v54, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8B60: 7E6C02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB8B68: D501002A 200E552A
	v_mov_b32_dpp v55, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB8B70: 7E6E02FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000DB8B78: D5010027 200E4F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB8B80: BF870091
	v_dual_add_f32 v42, v42, v54 :: v_dual_add_f32 v39, v39, v55// 000000DB8B84: C9086D2A 2A266F27
	v_mul_f32_e32 v39, 0x3db504f3, v39                         // 000000DB8B8C: 104E4EFF 3DB504F3
	s_waitcnt vmcnt(15)                                        // 000000DB8B94: BF893FF7
	v_fma_mix_f32 v7, v7, v31, neg(0) op_sel_hi:[1,0,0]        // 000000DB8B98: CC200007 8A023F07
	s_waitcnt vmcnt(14)                                        // 000000DB8BA0: BF893BF7
	v_fma_mix_f32 v10, v10, v35, neg(0) op_sel_hi:[1,0,0]      // 000000DB8BA4: CC20000A 8A02470A
	s_waitcnt vmcnt(13)                                        // 000000DB8BAC: BF8937F7
	v_fma_mix_f32 v8, v8, v44, neg(0) op_sel_hi:[1,0,0]        // 000000DB8BB0: CC200008 8A025908
	s_waitcnt vmcnt(12)                                        // 000000DB8BB8: BF8933F7
	v_fma_mix_f32 v9, v9, v43, neg(0) op_sel_hi:[1,0,0]        // 000000DB8BBC: CC200009 8A025709
	s_waitcnt vmcnt(11)                                        // 000000DB8BC4: BF892FF7
	v_fma_mix_f32 v11, v11, v46, neg(0) op_sel_hi:[1,0,0]      // 000000DB8BC8: CC20000B 8A025D0B
	s_waitcnt vmcnt(10)                                        // 000000DB8BD0: BF892BF7
	v_fma_mix_f32 v12, v12, v45, neg(0) op_sel_hi:[1,0,0]      // 000000DB8BD4: CC20000C 8A025B0C
	s_waitcnt vmcnt(8)                                         // 000000DB8BDC: BF8923F7
	v_fma_mix_f32 v20, v20, v30, neg(0) op_sel_hi:[1,0,0]      // 000000DB8BE0: CC200014 8A023D14
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DB8BE8: BF870002
	v_dual_mul_f32 v31, 0xbfb8aa3b, v11 :: v_dual_mul_f32 v30, 0xbfb8aa3b, v12// 000000DB8BEC: C8C616FF 1F1E18FF BFB8AA3B
	s_waitcnt vmcnt(6)                                         // 000000DB8BF8: BF891BF7
	v_fma_mix_f32 v22, v22, v29, neg(0) op_sel_hi:[1,0,0]      // 000000DB8BFC: CC200016 8A023B16
	v_mul_f32_e32 v29, 0xbfb8aa3b, v8                          // 000000DB8C04: 103A10FF BFB8AA3B
	s_waitcnt vmcnt(4)                                         // 000000DB8C0C: BF8913F7
	v_fma_mix_f32 v27, v27, v37, neg(0) op_sel_hi:[1,0,0]      // 000000DB8C10: CC20001B 8A024B1B
	v_exp_f32_e32 v31, v31                                     // 000000DB8C18: 7E3E4B1F
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000DB8C1C: 103838FF 3DB504F3
	v_exp_f32_e32 v30, v30                                     // 000000DB8C24: 7E3C4B1E
	v_exp_f32_e32 v29, v29                                     // 000000DB8C28: 7E3A4B1D
	v_mul_f32_e32 v34, 0x3db504f3, v34                         // 000000DB8C2C: 104444FF 3DB504F3
	v_fma_mix_f32 v26, v26, v36, neg(0) op_sel_hi:[1,0,0]      // 000000DB8C34: CC20001A 8A02491A
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000DB8C3C: BF8702B7
	v_add_f32_e32 v31, 1.0, v31                                // 000000DB8C40: 063E3EF2
	v_fma_mix_f32 v21, v21, v28, neg(0) op_sel_hi:[1,0,0]      // 000000DB8C44: CC200015 8A023915
	v_dual_mul_f32 v28, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v43, 0xbfb8aa3b, v22// 000000DB8C4C: C8C612FF 1C2A2CFF BFB8AA3B
	v_add_f32_e32 v29, 1.0, v29                                // 000000DB8C58: 063A3AF2
	v_fma_mix_f32 v19, v19, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DB8C5C: CC200013 8A024513
	v_mul_f32_e32 v34, 0xbfb8aa3b, v20                         // 000000DB8C64: 104428FF BFB8AA3B
	v_mul_f32_e32 v44, 0xbfb8aa3b, v21                         // 000000DB8C6C: 10582AFF BFB8AA3B
	v_exp_f32_e32 v43, v43                                     // 000000DB8C74: 7E564B2B
	v_exp_f32_e32 v28, v28                                     // 000000DB8C78: 7E384B1C
	v_mul_f32_e32 v35, 0xbfb8aa3b, v19                         // 000000DB8C7C: 104626FF BFB8AA3B
	v_div_scale_f32 v47, null, v31, v31, v11                   // 000000DB8C84: D6FC7C2F 042E3F1F
	v_exp_f32_e32 v44, v44                                     // 000000DB8C8C: 7E584B2C
	v_add_f32_e32 v30, 1.0, v30                                // 000000DB8C90: 063C3CF2
	v_exp_f32_e32 v34, v34                                     // 000000DB8C94: 7E444B22
	v_exp_f32_e32 v35, v35                                     // 000000DB8C98: 7E464B23
	v_rcp_f32_e32 v59, v47                                     // 000000DB8C9C: 7E76552F
	v_div_scale_f32 v66, s5, v11, v31, v11                     // 000000DB8CA0: D6FC0542 042E3F0B
	v_add_f32_e32 v37, 1.0, v43                                // 000000DB8CA8: 064A56F2
	v_div_scale_f32 v43, null, v29, v29, v8                    // 000000DB8CAC: D6FC7C2B 04223B1D
	v_add_f32_e32 v28, 1.0, v28                                // 000000DB8CB4: 063838F2
	v_div_scale_f32 v50, null, v30, v30, v12                   // 000000DB8CB8: D6FC7C32 04323D1E
	v_div_scale_f32 v68, s6, v12, v30, v12                     // 000000DB8CC0: D6FC0644 04323D0C
	v_div_scale_f32 v54, null, v37, v37, v22                   // 000000DB8CC8: D6FC7C36 045A4B25
	v_rcp_f32_e32 v55, v43                                     // 000000DB8CD0: 7E6E552B
	v_add_f32_e32 v35, 1.0, v35                                // 000000DB8CD4: 064646F2
	v_div_scale_f32 v45, null, v28, v28, v9                    // 000000DB8CD8: D6FC7C2D 0426391C
	v_fma_f32 v71, -v47, v59, 1.0                              // 000000DB8CE0: D6130047 23CA772F
	v_add_f32_e32 v36, 1.0, v44                                // 000000DB8CE8: 064858F2
	v_rcp_f32_e32 v60, v50                                     // 000000DB8CEC: 7E785532
	v_div_scale_f32 v51, null, v35, v35, v19                   // 000000DB8CF0: D6FC7C33 044E4723
	v_rcp_f32_e32 v58, v45                                     // 000000DB8CF8: 7E74552D
	v_fmac_f32_e32 v59, v71, v59                               // 000000DB8CFC: 56767747
	v_div_scale_f32 v53, null, v36, v36, v21                   // 000000DB8D00: D6FC7C35 04564924
	v_fma_f32 v69, -v43, v55, 1.0                              // 000000DB8D08: D6130045 23CA6F2B
	v_add_f32_e32 v34, 1.0, v34                                // 000000DB8D10: 064444F2
	v_rcp_f32_e32 v61, v51                                     // 000000DB8D14: 7E7A5533
	v_div_scale_f32 v44, vcc_lo, v8, v29, v8                   // 000000DB8D18: D6FC6A2C 04223B08
	v_rcp_f32_e32 v63, v53                                     // 000000DB8D20: 7E7E5535
	v_fmac_f32_e32 v55, v69, v55                               // 000000DB8D24: 566E6F45
	v_div_scale_f32 v52, null, v34, v34, v20                   // 000000DB8D28: D6FC7C34 04524522
	v_rcp_f32_e32 v67, v54                                     // 000000DB8D30: 7E865536
	v_fma_f32 v70, -v45, v58, 1.0                              // 000000DB8D34: D6130046 23CA752D
	v_div_scale_f32 v46, s4, v9, v28, v9                       // 000000DB8D3C: D6FC042E 04263909
	v_fma_f32 v74, -v50, v60, 1.0                              // 000000DB8D44: D613004A 23CA7932
	v_rcp_f32_e32 v62, v52                                     // 000000DB8D4C: 7E7C5534
	v_fma_f32 v75, -v51, v61, 1.0                              // 000000DB8D50: D613004B 23CA7B33
	v_fmac_f32_e32 v58, v70, v58                               // 000000DB8D58: 56747546
	v_fma_f32 v77, -v53, v63, 1.0                              // 000000DB8D5C: D613004D 23CA7F35
	v_fmac_f32_e32 v60, v74, v60                               // 000000DB8D64: 5678794A
	s_waitcnt vmcnt(0)                                         // 000000DB8D68: BF8903F7
	v_fma_mix_f32 v18, v18, v23, neg(0) op_sel_hi:[1,0,0]      // 000000DB8D6C: CC200012 8A022F12
	v_dual_fmac_f32 v61, v75, v61 :: v_dual_mul_f32 v70, v44, v55// 000000DB8D74: C8067B4B 3D466F2C
	v_mul_f32_e32 v71, v46, v58                                // 000000DB8D7C: 108E752E
	v_fma_f32 v69, -v54, v67, 1.0                              // 000000DB8D80: D6130045 23CA8736
	v_fma_f32 v76, -v52, v62, 1.0                              // 000000DB8D88: D613004C 23CA7D34
	v_fmac_f32_e32 v63, v77, v63                               // 000000DB8D90: 567E7F4D
	v_mul_f32_e32 v74, v66, v59                                // 000000DB8D94: 10947742
	v_fma_f32 v75, -v43, v70, v44                              // 000000DB8D98: D613004B 24B28D2B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB8DA0: BF870004
	v_dual_fmac_f32 v67, v69, v67 :: v_dual_fmac_f32 v62, v76, v62// 000000DB8DA4: C8008745 433E7D4C
	v_mul_f32_e32 v69, v68, v60                                // 000000DB8DAC: 108A7944
	v_fma_f32 v76, -v45, v71, v46                              // 000000DB8DB0: D613004C 24BA8F2D
	v_fma_f32 v77, -v47, v74, v66                              // 000000DB8DB8: D613004D 250A952F
	v_fmac_f32_e32 v70, v75, v55                               // 000000DB8DC0: 568C6F4B
	v_div_scale_f32 v75, s7, v19, v35, v19                     // 000000DB8DC4: D6FC074B 044E4713
	v_fma_mix_f32 v14, v14, v38, neg(0) op_sel_hi:[1,0,0]      // 000000DB8DCC: CC20000E 8A024D0E
	v_fmac_f32_e32 v71, v76, v58                               // 000000DB8DD4: 568E754C
	v_fma_f32 v76, -v50, v69, v68                              // 000000DB8DD8: D613004C 25128B32
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB8DE0: BF870224
	v_dual_fmac_f32 v74, v77, v59 :: v_dual_mul_f32 v77, v75, v61// 000000DB8DE4: C806774D 4A4C7B4B
	v_fma_f32 v43, -v43, v70, v44                              // 000000DB8DEC: D613002B 24B28D2B
	v_fma_f32 v44, -v45, v71, v46                              // 000000DB8DF4: D613002C 24BA8F2D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB8DFC: BF870214
	v_fmac_f32_e32 v69, v76, v60                               // 000000DB8E00: 568A794C
	v_fma_f32 v45, -v47, v74, v66                              // 000000DB8E04: D613002D 250A952F
	v_fma_f32 v76, -v51, v77, v75                              // 000000DB8E0C: D613004C 252E9B33
	v_div_fmas_f32 v43, v43, v55, v70                          // 000000DB8E14: D637002B 051A6F2B
	s_mov_b32 vcc_lo, s4                                       // 000000DB8E1C: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB8E20: BE84007E
	v_div_fmas_f32 v44, v44, v58, v71                          // 000000DB8E24: D637002C 051E752C
	v_fmac_f32_e32 v77, v76, v61                               // 000000DB8E2C: 569A7B4C
	v_div_scale_f32 v76, s8, v20, v34, v20                     // 000000DB8E30: D6FC084C 04524514
	s_mov_b32 vcc_lo, s5                                       // 000000DB8E38: BEEA0005
	v_div_fixup_f32 v8, v43, v29, v8                           // 000000DB8E3C: D6270008 04223B2B
	v_div_fixup_f32 v9, v44, v28, v9                           // 000000DB8E44: D6270009 0426392C
	v_div_fmas_f32 v45, v45, v59, v74                          // 000000DB8E4C: D637002D 052A772D
	v_mul_f32_e32 v78, v76, v62                                // 000000DB8E54: 109C7D4C
	s_mov_b32 vcc_lo, s6                                       // 000000DB8E58: BEEA0006
	v_fma_mix_f32 v13, v13, v39, neg(0) op_sel_hi:[1,0,0]      // 000000DB8E5C: CC20000D 8A024F0D
	v_mul_f32_e32 v9, v10, v9                                  // 000000DB8E64: 1012130A
	v_div_fixup_f32 v11, v45, v31, v11                         // 000000DB8E68: D627000B 042E3F2D
	v_fma_f32 v79, -v52, v78, v76                              // 000000DB8E70: D613004F 25329D34
	v_dual_mul_f32 v42, 0x3db504f3, v42 :: v_dual_mul_f32 v7, v7, v8// 000000DB8E78: C8C654FF 2A061107 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB8E84: BF870232
	v_dual_mul_f32 v11, v26, v11 :: v_dual_fmac_f32 v78, v79, v62// 000000DB8E88: C8C0171A 0B4E7D4F
	v_div_scale_f32 v79, s9, v21, v36, v21                     // 000000DB8E90: D6FC094F 04564915
	v_fma_f32 v46, -v50, v69, v68                              // 000000DB8E98: D613002E 25128B32
	v_fma_mix_f32 v15, v15, v42, neg(0) op_sel_hi:[1,0,0]      // 000000DB8EA0: CC20000F 8A02550F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB8EA8: BF870214
	v_fma_f32 v50, -v52, v78, v76                              // 000000DB8EAC: D6130032 25329D34
	v_mul_f32_e32 v82, v79, v63                                // 000000DB8EB4: 10A47F4F
	v_fma_f32 v47, -v51, v77, v75                              // 000000DB8EB8: D613002F 252E9B33
	global_load_d16_b16 v51, v[4:5], off offset:32             // 000000DB8EC0: DC820020 337C0004
	v_div_fmas_f32 v29, v46, v60, v69                          // 000000DB8EC8: D637001D 0516792E
	s_mov_b32 vcc_lo, s7                                       // 000000DB8ED0: BEEA0007
	v_fma_f32 v83, -v53, v82, v79                              // 000000DB8ED4: D6130053 253EA535
	v_div_fmas_f32 v28, v47, v61, v77                          // 000000DB8EDC: D637001C 05367B2F
	s_mov_b32 vcc_lo, s8                                       // 000000DB8EE4: BEEA0008
	v_div_fixup_f32 v8, v29, v30, v12                          // 000000DB8EE8: D6270008 04323D1D
	v_div_fmas_f32 v10, v50, v62, v78                          // 000000DB8EF0: D637000A 053A7D32
	v_fmac_f32_e32 v82, v83, v63                               // 000000DB8EF8: 56A47F53
	v_div_scale_f32 v83, s10, v22, v37, v22                    // 000000DB8EFC: D6FC0A53 045A4B16
	s_mov_b32 vcc_lo, s9                                       // 000000DB8F04: BEEA0009
	v_div_fixup_f32 v19, v28, v35, v19                         // 000000DB8F08: D6270013 044E471C
	v_div_fixup_f32 v10, v10, v34, v20                         // 000000DB8F10: D627000A 0452450A
	v_fma_f32 v52, -v53, v82, v79                              // 000000DB8F18: D6130034 253EA535
	s_clause 0x6                                               // 000000DB8F20: BF850006
	global_load_d16_b16 v53, v[4:5], off offset:96             // 000000DB8F24: DC820060 357C0004
	global_load_d16_b16 v55, v[4:5], off offset:160            // 000000DB8F2C: DC8200A0 377C0004
	global_load_d16_b16 v58, v[4:5], off offset:224            // 000000DB8F34: DC8200E0 3A7C0004
	global_load_d16_b16 v59, v[4:5], off offset:192            // 000000DB8F3C: DC8200C0 3B7C0004
	global_load_d16_b16 v66, v[4:5], off offset:128            // 000000DB8F44: DC820080 427C0004
	global_load_d16_b16 v68, v[4:5], off offset:64             // 000000DB8F4C: DC820040 447C0004
	global_load_d16_b16 v70, v[4:5], off                       // 000000DB8F54: DC820000 467C0004
	v_mul_f32_e32 v84, v83, v67                                // 000000DB8F5C: 10A88753
	v_mul_f32_e32 v10, v15, v10                                // 000000DB8F60: 1014150F
	v_div_fmas_f32 v26, v52, v63, v82                          // 000000DB8F64: D637001A 054A7F34
	s_mov_b32 vcc_lo, s10                                      // 000000DB8F6C: BEEA000A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB8F70: BF870113
	v_fma_f32 v85, -v54, v84, v83                              // 000000DB8F74: D6130055 254EA936
	v_div_fixup_f32 v15, v26, v36, v21                         // 000000DB8F7C: D627000F 0456491A
	v_mul_f32_e32 v8, v27, v8                                  // 000000DB8F84: 1010111B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB8F88: BF870193
	v_fmac_f32_e32 v84, v85, v67                               // 000000DB8F8C: 56A88755
	v_mul_f32_e32 v13, v13, v15                                // 000000DB8F90: 101A1F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB8F94: BF870092
	v_fma_f32 v12, -v54, v84, v83                              // 000000DB8F98: D613000C 254EA936
	v_div_fmas_f32 v12, v12, v67, v84                          // 000000DB8FA0: D637000C 0552870C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB8FA8: BF870001
	v_div_fixup_f32 v12, v12, v37, v22                         // 000000DB8FAC: D627000C 045A4B0C
	s_waitcnt vmcnt(7)                                         // 000000DB8FB4: BF891FF7
	v_fma_mix_f32 v9, v51, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB8FB8: CC200009 8A021333
	s_waitcnt vmcnt(6)                                         // 000000DB8FC0: BF891BF7
	v_fma_mix_f32 v8, v53, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB8FC4: CC200008 8A021135
	s_waitcnt vmcnt(5)                                         // 000000DB8FCC: BF8917F7
	v_fma_mix_f32 v10, v55, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB8FD0: CC20000A 8A021537
	s_waitcnt vmcnt(0)                                         // 000000DB8FD8: BF8903F7
	v_fma_mix_f32 v15, v7, v70, v9 op_sel_hi:[0,1,0]           // 000000DB8FDC: CC20000F 14268D07
	v_mul_f32_e32 v12, v18, v12                                // 000000DB8FE4: 10181912
	v_fma_mix_f32 v18, v11, v68, v8 op_sel_hi:[0,1,0]          // 000000DB8FE8: CC200012 1422890B
	v_fma_mix_f32 v7, v7, v70, -v9 op_sel_hi:[0,1,0]           // 000000DB8FF0: CC200007 94268D07
	v_fma_mix_f32 v8, v11, v68, -v8 op_sel_hi:[0,1,0]          // 000000DB8FF8: CC200008 9422890B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB9000: BF8700A3
	v_dual_mul_f32 v14, v14, v19 :: v_dual_add_f32 v21, v15, v18// 000000DB9004: C8C8270E 0E14250F
	v_fma_mix_f32 v12, v58, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB900C: CC20000C 8A02193A
	v_fma_mix_f32 v20, v13, v59, v12 op_sel_hi:[0,1,0]         // 000000DB9014: CC200014 1432770D
	v_fma_mix_f32 v11, v13, v59, -v12 op_sel_hi:[0,1,0]        // 000000DB901C: CC20000B 9432770D
	v_add_f32_e32 v13, v7, v8                                  // 000000DB9024: 061A1107
	v_fma_mix_f32 v19, v14, v66, v10 op_sel_hi:[0,1,0]         // 000000DB9028: CC200013 142A850E
	v_fma_mix_f32 v10, v14, v66, -v10 op_sel_hi:[0,1,0]        // 000000DB9030: CC20000A 942A850E
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB9038: 080E1107
	v_sub_f32_e32 v12, v15, v18                                // 000000DB903C: 0818250F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB9040: BF870214
	v_add_f32_e32 v22, v19, v20                                // 000000DB9044: 062C2913
	v_dual_add_f32 v8, v10, v11 :: v_dual_sub_f32 v15, v19, v20// 000000DB9048: C90A170A 080E2913
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9050: BF870092
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v9, v21, v22// 000000DB9054: C948170A 0A082D15
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB905C: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB9064: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB906C: BF870241
	v_add_f32_e32 v9, v9, v14                                  // 000000DB9070: 06121D09
	v_add_f32_e32 v14, v13, v8                                 // 000000DB9074: 061C110D
	v_sub_f32_e32 v11, v21, v22                                // 000000DB9078: 08162D15
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v15 // 000000DB907C: C948110D 0D081F0C
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9084: 7E2402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB908C: D5010009 20061309
	v_sub_f32_e32 v15, v12, v15                                // 000000DB9094: 081E1F0C
	v_mov_b32_dpp v19, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9098: 7E2602FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB90A0: D501000E 20021D0E
	v_mov_b32_dpp v20, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB90A8: 7E2802FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DB90B0: D5010008 20021108
	v_add_f32_e32 v9, v9, v18                                  // 000000DB90B8: 06122509
	v_cndmask_b32_e64 v22, -v11, v11, s0                       // 000000DB90BC: D5010016 2002170B
	v_add_f32_e32 v12, v14, v19                                // 000000DB90C4: 0618270E
	v_add_f32_e32 v14, v7, v10                                 // 000000DB90C8: 061C1507
	v_add_f32_e32 v8, v8, v20                                  // 000000DB90CC: 06102908
	v_mov_b32_dpp v18, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB90D0: 7E2402FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DB90D8: D5010009 200A1309
	v_mov_b32_dpp v19, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB90E0: 7E2602FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DB90E8: D501000C 2006190C
	v_mov_b32_dpp v21, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB90F0: 7E2A02FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DB90F8: D501000E 20021D0E
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9100: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000DB9108: D501000F 20021F0F
	v_dual_add_f32 v12, v12, v19 :: v_dual_sub_f32 v19, v7, v10// 000000DB9110: C90A270C 0C121507
	v_mov_b32_dpp v20, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9118: 7E2802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DB9120: D5010008 20061108
	v_add_f32_e32 v7, v9, v18                                  // 000000DB9128: 060E2509
	v_add_f32_e32 v9, v14, v21                                 // 000000DB912C: 06122B0E
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9130: 7E1402FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DB9138: D501000C 200A190C
	v_add_f32_e32 v8, v8, v20                                  // 000000DB9140: 06102908
	v_mov_b32_dpp v21, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9144: 7E2A02FA FF01610B
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB914C: 7E2402FA FF016209
	v_cndmask_b32_e64 v20, -v9, v9, s1                         // 000000DB9154: D5010014 20061309
	v_add_f32_e32 v9, v12, v10                                 // 000000DB915C: 0612150C
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9160: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DB9168: D5010008 200A1108
	v_mov_b32_dpp v26, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9170: 7E3402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000DB9178: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB9180: BF870003
	v_add_f32_e32 v11, v8, v14                                 // 000000DB9184: 06161D08
	v_add_f32_e32 v14, v20, v18                                // 000000DB9188: 061C2514
	v_add_f32_e32 v18, v22, v21                                // 000000DB918C: 06242B16
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9190: 7E2C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DB9198: D501000D 20021B0D
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB91A0: 7E1002FA FF016807
	v_mov_b32_dpp v20, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB91A8: 7E2802FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DB91B0: D501000E 200A1D0E
	v_mov_b32_dpp v21, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB91B8: 7E2A02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB91C0: D5010012 20062512
	v_add_f32_e32 v22, v13, v22                                // 000000DB91C8: 062C2D0D
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB91CC: 7E1402FA FF016809
	v_dual_add_f32 v13, v14, v20 :: v_dual_add_f32 v14, v15, v23// 000000DB91D4: C908290E 0D0E2F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB91DC: BF870214
	v_add_f32_e32 v15, v18, v21                                // 000000DB91E0: 061E2B12
	v_cndmask_b32_e64 v20, -v22, v22, s1                       // 000000DB91E4: D5010014 20062D16
	v_add_f32_e32 v18, v19, v26                                // 000000DB91EC: 06243513
	v_mov_b32_dpp v19, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB91F0: 7E2602FA FF016216
	v_mov_b32_dpp v21, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB91F8: 7E2A02FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DB9200: D501000E 20061D0E
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9208: 7E1802FA FF01680B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB9210: BF870004
	v_add_f32_e32 v19, v20, v19                                // 000000DB9214: 06262714
	v_mov_b32_dpp v22, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9218: 7E2C02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000DB9220: D5010012 20062512
	v_add_f32_e32 v14, v14, v21                                // 000000DB9228: 061C2B0E
	v_mov_b32_dpp v20, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB922C: 7E2802FA FF01640F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DB9234: D501000F 200A1F0F
	v_mov_b32_dpp v21, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB923C: 7E2A02FA FF016413
	v_add_f32_e32 v18, v18, v22                                // 000000DB9244: 06242D12
	v_cndmask_b32_e64 v22, -v19, v19, s2                       // 000000DB9248: D5010016 200A2713
	v_mov_b32_dpp v23, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9250: 7E2E02FA FF01640E
	v_cndmask_b32_e64 v26, -v14, v14, s2                       // 000000DB9258: D501001A 200A1D0E
	v_add_f32_e32 v19, v15, v20                                // 000000DB9260: 0626290F
	v_mov_b32_dpp v27, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9264: 7E3602FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000DB926C: D5010012 200A2512
	v_add_f32_e32 v20, v22, v21                                // 000000DB9274: 06282B16
	v_add_f32_e32 v22, v26, v23                                // 000000DB9278: 062C2F1A
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB927C: 7E1C02FA FF01680D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DB9284: BF870244
	v_dual_add_f32 v26, v18, v27 :: v_dual_add_nc_u32 v15, 10, v6// 000000DB9288: C9203712 1A0E0C8A
	v_mov_b32_dpp v18, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9290: 7E2402FA FF016813
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9298: 7E2A02FA FF016814
	v_mov_b32_dpp v23, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB92A0: 7E2E02FA FF016816
	v_mov_b32_dpp v27, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB92A8: 7E3602FA FF01681A
	.long 0xd4c4007e                                           // 000000DB92B0: D4C4007E
	v_cndmask_b32_e32 v1, s23, v15, vcc_lo                     // 000000DB92B4: 02021E17
	s_cbranch_execz 62                                         // 000000DB92B8: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x67b4>
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000DB92BC: D5010016 200E2D16
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DB92C4: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DB92CC: D5010009 200E1309
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000DB92D4: D5010014 200E2914
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DB92DC: D501000B 200E170B
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000DB92E4: D501001A 200E351A
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DB92EC: D501000D 200E1B0D
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000DB92F4: D5010013 200E2713
	v_dual_add_f32 v22, v22, v23 :: v_dual_add_f32 v7, v7, v8  // 000000DB92FC: C9082F16 16061107
	v_add_f32_e32 v8, v9, v10                                  // 000000DB9304: 06101509
	v_dual_add_f32 v20, v20, v21 :: v_dual_add_f32 v9, v11, v12// 000000DB9308: C9082B14 1408190B
	v_mad_i64_i32 v[11:12], null, 0x500, v15, v[0:1]           // 000000DB9310: D6FF7C0B 04021EFF 00000500
	v_dual_add_f32 v26, v26, v27 :: v_dual_add_f32 v13, v13, v14// 000000DB931C: C908371A 1A0C1D0D
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB9324: BE8500FF 3DB504F3
	v_add_f32_e32 v18, v19, v18                                // 000000DB932C: 06242513
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DB9330: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DB9338: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DB9340: CC210008 02000B09
	v_fma_mixhi_f16 v8, v13, s5, 0                             // 000000DB9348: CC220008 02000B0D
	v_fma_mixlo_f16 v9, v18, s5, 0                             // 000000DB9350: CC210009 02000B12
	v_fma_mixhi_f16 v9, v20, s5, 0                             // 000000DB9358: CC220009 02000B14
	v_fma_mixlo_f16 v10, v22, s5, 0                            // 000000DB9360: CC21000A 02000B16
	v_fma_mixhi_f16 v10, v26, s5, 0                            // 000000DB9368: CC22000A 02000B1A
	s_clause 0x7                                               // 000000DB9370: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000DB9374: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000DB937C: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000DB9384: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000DB938C: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000DB9394: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000DB939C: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000DB93A4: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000DB93AC: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DB93B4: 8C7E047E
	s_clause 0xb                                               // 000000DB93B8: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DB93BC: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DB93C4: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DB93CC: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DB93D4: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DB93DC: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000DB93E4: DC820060 0C7C0002
	global_load_d16_b16 v18, v[2:3], off offset:128            // 000000DB93EC: DC820080 127C0002
	global_load_d16_b16 v19, v[2:3], off offset:160            // 000000DB93F4: DC8200A0 137C0002
	global_load_d16_b16 v20, v[2:3], off offset:192            // 000000DB93FC: DC8200C0 147C0002
	global_load_d16_b16 v21, v[2:3], off offset:224            // 000000DB9404: DC8200E0 157C0002
	global_load_d16_b16 v22, v[2:3], off offset:1344           // 000000DB940C: DC820540 167C0002
	global_load_d16_b16 v23, v[2:3], off offset:1376           // 000000DB9414: DC820560 177C0002
	v_sub_f32_e32 v31, v104, v96                               // 000000DB941C: 083EC168
	v_sub_f32_e32 v37, v72, v64                                // 000000DB9420: 084A8148
	v_sub_f32_e32 v39, v56, v48                                // 000000DB9424: 084E6138
	v_add_f32_e32 v34, v88, v80                                // 000000DB9428: 0644A158
	v_sub_f32_e32 v35, v88, v80                                // 000000DB942C: 0846A158
	v_sub_f32_e32 v29, v120, v112                              // 000000DB9430: 083AE178
	v_add_f32_e32 v30, v104, v96                               // 000000DB9434: 063CC168
	v_sub_f32_e32 v27, v136, v128                              // 000000DB9438: 08370188
	v_add_f32_e32 v26, v136, v128                              // 000000DB943C: 06350188
	v_add_f32_e32 v28, v120, v112                              // 000000DB9440: 0638E178
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB9444: BF870001
	v_add_f32_e32 v43, v26, v28                                // 000000DB9448: 0656391A
	v_sub_f32_e32 v26, v26, v28                                // 000000DB944C: 0834391A
	v_add_f32_e32 v28, v27, v29                                // 000000DB9450: 06383B1B
	v_sub_f32_e32 v27, v27, v29                                // 000000DB9454: 08363B1B
	v_dual_add_f32 v29, v30, v34 :: v_dual_add_f32 v38, v56, v48// 000000DB9458: C908451E 1D266138
	v_sub_f32_e32 v30, v30, v34                                // 000000DB9460: 083C451E
	v_add_f32_e32 v34, v31, v35                                // 000000DB9464: 0644471F
	v_dual_sub_f32 v31, v31, v35 :: v_dual_add_f32 v36, v72, v64// 000000DB9468: C948471F 1F248148
	v_add_f32_e32 v42, v40, v32                                // 000000DB9470: 06544128
	v_sub_f32_e32 v32, v40, v32                                // 000000DB9474: 08404128
	v_add_f32_e32 v40, v24, v16                                // 000000DB9478: 06502118
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB947C: BF870004
	v_dual_sub_f32 v24, v24, v16 :: v_dual_add_f32 v45, v27, v31// 000000DB9480: C9482118 182C3F1B
	v_add_f32_e32 v35, v36, v38                                // 000000DB9488: 06464D24
	v_sub_f32_e32 v36, v36, v38                                // 000000DB948C: 08484D24
	v_add_f32_e32 v38, v37, v39                                // 000000DB9490: 064C4F25
	v_sub_f32_e32 v37, v37, v39                                // 000000DB9494: 084A4F25
	v_dual_add_f32 v39, v32, v24 :: v_dual_add_f32 v46, v26, v30// 000000DB9498: C9083120 272E3D1A
	v_dual_sub_f32 v24, v32, v24 :: v_dual_sub_f32 v27, v27, v31// 000000DB94A0: C94A3120 181A3F1B
	v_add_f32_e32 v44, v42, v40                                // 000000DB94A8: 0658512A
	v_sub_f32_e32 v40, v42, v40                                // 000000DB94AC: 0850512A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB94B0: BF870004
	v_add_f32_e32 v42, v38, v39                                // 000000DB94B4: 06544F26
	v_sub_f32_e32 v38, v38, v39                                // 000000DB94B8: 084C4F26
	v_mov_b32_dpp v54, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB94BC: 7E6C02FA FF01612E
	v_cndmask_b32_e64 v46, -v46, v46, s0                       // 000000DB94C4: D501002E 20025D2E
	v_add_f32_e32 v39, v36, v40                                // 000000DB94CC: 064E5124
	v_sub_f32_e32 v36, v36, v40                                // 000000DB94D0: 08485124
	v_add_f32_e32 v40, v37, v24                                // 000000DB94D4: 06503125
	v_dual_sub_f32 v24, v37, v24 :: v_dual_add_f32 v37, v28, v34// 000000DB94D8: C9483125 1824451C
	v_sub_f32_e32 v28, v28, v34                                // 000000DB94E0: 0838451C
	v_cndmask_b32_e64 v34, -v42, v42, s0                       // 000000DB94E4: D5010022 2002552A
	v_mov_b32_dpp v48, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB94EC: 7E6002FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000DB94F4: D5010026 20024D26
	v_mov_b32_dpp v53, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB94FC: 7E6A02FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000DB9504: D5010025 20024B25
	v_mov_b32_dpp v58, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB950C: 7E7402FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000DB9514: D501001C 2002391C
	v_mov_b32_dpp v60, v27 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB951C: 7E7802FA FF01611B
	v_cndmask_b32_e64 v27, -v27, v27, s0                       // 000000DB9524: D501001B 2002371B
	v_add_f32_e32 v37, v37, v53                                // 000000DB952C: 064A6B25
	v_mov_b32_dpp v55, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9530: 7E6E02FA FF01612D
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000DB9538: D501002D 20025B2D
	s_clause 0x3                                               // 000000DB9540: BF850003
	global_load_d16_b16 v14, v[2:3], off offset:1408           // 000000DB9544: DC820580 0E7C0002
	global_load_d16_b16 v15, v[2:3], off offset:1440           // 000000DB954C: DC8205A0 0F7C0002
	global_load_d16_b16 v13, v[2:3], off offset:1472           // 000000DB9554: DC8205C0 0D7C0002
	global_load_d16_b16 v16, v[2:3], off offset:1504           // 000000DB955C: DC8205E0 107C0002
	v_add_f32_e32 v27, v27, v60                                // 000000DB9564: 0636791B
	v_mov_b32_dpp v53, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9568: 7E6A02FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000DB9570: D5010025 20064B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB9578: BF8701A3
	v_mov_b32_dpp v60, v27 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB957C: 7E7802FA FF01621B
	v_cndmask_b32_e64 v27, -v27, v27, s1                       // 000000DB9584: D501001B 2006371B
	v_add_f32_e32 v37, v37, v53                                // 000000DB958C: 064A6B25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9590: BF870112
	v_add_f32_e32 v27, v27, v60                                // 000000DB9594: 0636791B
	v_mov_b32_dpp v53, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9598: 7E6A02FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000DB95A0: D5010025 200A4B25
	v_add_f32_e32 v32, v35, v44                                // 000000DB95A8: 06405923
	v_sub_f32_e32 v35, v35, v44                                // 000000DB95AC: 08465923
	v_add_f32_e32 v44, v43, v29                                // 000000DB95B0: 06583B2B
	v_sub_f32_e32 v29, v43, v29                                // 000000DB95B4: 083A3B2B
	v_add_f32_e32 v37, v37, v53                                // 000000DB95B8: 064A6B25
	v_cndmask_b32_e64 v31, -v32, v32, s0                       // 000000DB95BC: D501001F 20024120
	v_mov_b32_dpp v47, v35 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB95C4: 7E5E02FA FF016123
	v_cndmask_b32_e64 v35, -v35, v35, s0                       // 000000DB95CC: D5010023 20024723
	v_mov_b32_dpp v52, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB95D4: 7E6802FA FF01612C
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000DB95DC: D501002C 2002592C
	v_sub_f32_e32 v26, v26, v30                                // 000000DB95E4: 08343D1A
	v_mov_b32_dpp v30, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB95E8: 7E3C02FA FF016120
	v_add_f32_e32 v35, v35, v47                                // 000000DB95F0: 06465F23
	v_mov_b32_dpp v32, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB95F4: 7E4002FA FF01612A
	v_mov_b32_dpp v42, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB95FC: 7E5402FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000DB9604: D5010027 20024F27
	v_add_f32_e32 v30, v31, v30                                // 000000DB960C: 063C3D1F
	v_mov_b32_dpp v47, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9610: 7E5E02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000DB9618: D5010023 20064723
	v_add_f32_e32 v31, v34, v32                                // 000000DB9620: 063E4122
	v_mov_b32_dpp v56, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9624: 7E7002FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000DB962C: D501001D 20023B1D
	v_add_f32_e32 v32, v39, v42                                // 000000DB9634: 06405527
	v_add_f32_e32 v35, v35, v47                                // 000000DB9638: 06465F23
	v_add_f32_e32 v39, v44, v52                                // 000000DB963C: 064E692C
	v_mov_b32_dpp v44, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9640: 7E5802FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000DB9648: D501001F 20063F1F
	v_add_f32_e32 v29, v29, v56                                // 000000DB9650: 063A711D
	v_mov_b32_dpp v47, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9654: 7E5E02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000DB965C: D5010023 200A4723
	v_mov_b32_dpp v53, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9664: 7E6A02FA FF016825
	v_add_f32_e32 v31, v31, v44                                // 000000DB966C: 063E591F
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000DB9670: D5010025 200E4B25
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DB9678: BF870224
	v_dual_add_f32 v38, v38, v48 :: v_dual_add_f32 v35, v35, v47// 000000DB967C: C9086126 26225F23
	v_mov_b32_dpp v56, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9684: 7E7002FA FF01621D
	v_mov_b32_dpp v44, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB968C: 7E5802FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000DB9694: D501001F 200A3F1F
	v_add_f32_e32 v28, v28, v58                                // 000000DB969C: 0638751C
	v_mov_b32_dpp v47, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB96A0: 7E5E02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DB96A8: D5010023 200E4723
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000DB96B0: D501001D 20063B1D
	v_add_f32_e32 v31, v31, v44                                // 000000DB96B8: 063E591F
	v_dual_add_f32 v37, v37, v53 :: v_dual_add_f32 v42, v46, v54// 000000DB96BC: C9086B25 252A6D2E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB96C4: BF870004
	v_add_f32_e32 v35, v35, v47                                // 000000DB96C8: 06465F23
	v_mov_b32_dpp v50, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB96CC: 7E6402FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000DB96D4: D5010024 20024924
	v_mov_b32_dpp v44, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB96DC: 7E5802FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000DB96E4: D501001F 200E3F1F
	v_mov_b32_dpp v52, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB96EC: 7E6802FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000DB96F4: D5010027 20064F27
	v_dual_add_f32 v36, v36, v50 :: v_dual_add_f32 v29, v29, v56// 000000DB96FC: C9086524 241C711D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB9704: BF870234
	v_add_f32_e32 v31, v31, v44                                // 000000DB9708: 063E591F
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000DB970C: 104A4AFF 3DB504F3
	v_mov_b32_dpp v51, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9714: 7E6602FA FF016118
	v_mov_b32_dpp v50, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB971C: 7E6402FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000DB9724: D5010024 20064924
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000DB972C: 103E3EFF 3DB504F3
	v_mov_b32_dpp v43, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9734: 7E5602FA FF016128
	v_cndmask_b32_e64 v40, -v40, v40, s0                       // 000000DB973C: D5010028 20025128
	v_cndmask_b32_e64 v24, -v24, v24, s0                       // 000000DB9744: D5010018 20023118
	v_dual_add_f32 v36, v36, v50 :: v_dual_add_f32 v39, v39, v52// 000000DB974C: C9086524 24266927
	v_mov_b32_dpp v56, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9754: 7E7002FA FF01641D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB975C: BF870214
	v_add_f32_e32 v34, v40, v43                                // 000000DB9760: 06445728
	v_add_f32_e32 v24, v24, v51                                // 000000DB9764: 06306718
	v_mov_b32_dpp v43, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9768: 7E5602FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000DB9770: D501001E 20063D1E
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000DB9778: D501001D 200A3B1D
	v_mov_b32_dpp v59, v26 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9780: 7E7602FA FF01611A
	v_cndmask_b32_e64 v26, -v26, v26, s0                       // 000000DB9788: D501001A 2002351A
	v_add_f32_e32 v40, v45, v55                                // 000000DB9790: 06506F2D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB9794: BF870004
	v_dual_add_f32 v30, v30, v43 :: v_dual_add_f32 v29, v29, v56// 000000DB9798: C908571E 1E1C711D
	v_mov_b32_dpp v52, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB97A0: 7E6802FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000DB97A8: D5010027 200A4F27
	v_add_f32_e32 v26, v26, v59                                // 000000DB97B0: 0634771A
	v_mov_b32_dpp v45, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB97B4: 7E5A02FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000DB97BC: D5010020 20064120
	v_mov_b32_dpp v51, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB97C4: 7E6602FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000DB97CC: D5010018 20063118
	v_mov_b32_dpp v60, v27 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB97D4: 7E7802FA FF01641B
	v_cndmask_b32_e64 v27, -v27, v27, s2                       // 000000DB97DC: D501001B 200A371B
	v_add_f32_e32 v39, v39, v52                                // 000000DB97E4: 064E6927
	v_mov_b32_dpp v56, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB97E8: 7E7002FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000DB97F0: D501001D 200E3B1D
	v_mov_b32_dpp v46, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB97F8: 7E5C02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DB9800: D5010022 20064522
	v_mov_b32_dpp v54, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9808: 7E6C02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DB9810: D501002A 2006552A
	v_dual_add_f32 v32, v32, v45 :: v_dual_add_f32 v27, v27, v60// 000000DB9818: C9085B20 201A791B
	v_dual_add_f32 v24, v24, v51 :: v_dual_add_f32 v29, v29, v56// 000000DB9820: C9086718 181C711D
	v_mov_b32_dpp v52, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9828: 7E6802FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000DB9830: D5010027 200E4F27
	v_mov_b32_dpp v48, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9838: 7E6002FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000DB9840: D5010026 20064D26
	v_mov_b32_dpp v55, v40 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9848: 7E6E02FA FF016228
	v_cndmask_b32_e64 v40, -v40, v40, s1                       // 000000DB9850: D5010028 20065128
	v_dual_add_f32 v34, v34, v46 :: v_dual_add_f32 v39, v39, v52// 000000DB9858: C9085D22 22266927
	v_dual_add_f32 v42, v42, v54 :: v_dual_mul_f32 v29, 0x3db504f3, v29// 000000DB9860: C9066D2A 2A1C3AFF 3DB504F3
	v_mov_b32_dpp v60, v27 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB986C: 7E7802FA FF01681B
	v_cndmask_b32_e64 v27, -v27, v27, s3                       // 000000DB9874: D501001B 200E371B
	v_mov_b32_dpp v58, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB987C: 7E7402FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000DB9884: D501001C 2006391C
	v_mov_b32_dpp v59, v26 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB988C: 7E7602FA FF01621A
	v_cndmask_b32_e64 v26, -v26, v26, s1                       // 000000DB9894: D501001A 2006351A
	v_dual_add_f32 v38, v38, v48 :: v_dual_mul_f32 v39, 0x3db504f3, v39// 000000DB989C: C9066126 26264EFF 3DB504F3
	v_dual_add_f32 v40, v40, v55 :: v_dual_add_f32 v27, v27, v60// 000000DB98A8: C9086F28 281A791B
	v_mov_b32_dpp v43, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB98B0: 7E5602FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000DB98B8: D501001E 200A3D1E
	v_add_f32_e32 v28, v28, v58                                // 000000DB98C0: 0638751C
	v_mov_b32_dpp v54, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB98C4: 7E6C02FA FF01642A
	v_mul_f32_e32 v27, 0x3db504f3, v27                         // 000000DB98CC: 103636FF 3DB504F3
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DB98D4: D501002A 200A552A
	v_mov_b32_dpp v55, v40 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB98DC: 7E6E02FA FF016428
	v_cndmask_b32_e64 v40, -v40, v40, s2                       // 000000DB98E4: D5010028 200A5128
	v_mov_b32_dpp v45, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB98EC: 7E5A02FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000DB98F4: D5010020 200A4120
	v_mov_b32_dpp v51, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB98FC: 7E6602FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000DB9904: D5010018 200A3118
	v_add_f32_e32 v40, v40, v55                                // 000000DB990C: 06506F28
	v_mov_b32_dpp v58, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9910: 7E7402FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000DB9918: D501001C 200A391C
	v_mov_b32_dpp v46, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9920: 7E5C02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000DB9928: D5010022 200A4522
	v_mov_b32_dpp v55, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9930: 7E6E02FA FF016828
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 000000DB9938: D5010028 200E5128
	v_mov_b32_dpp v48, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9940: 7E6002FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000DB9948: D5010026 200A4D26
	v_mov_b32_dpp v50, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB9950: 7E6402FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000DB9958: D5010024 200A4924
	v_add_f32_e32 v40, v40, v55                                // 000000DB9960: 06506F28
	s_delay_alu instid0(VALU_DEP_1)                            // 000000DB9964: BF870001
	v_dual_mul_f32 v35, 0x3db504f3, v35 :: v_dual_mul_f32 v40, 0x3db504f3, v40// 000000DB9968: C8C646FF 232850FF 3DB504F3
	s_waitcnt vmcnt(14)                                        // 000000DB9974: BF893BF7
	v_fma_mix_f32 v10, v10, v31, neg(0) op_sel_hi:[1,0,0]      // 000000DB9978: CC20000A 8A023F0A
	s_waitcnt vmcnt(13)                                        // 000000DB9980: BF8937F7
	v_fma_mix_f32 v8, v8, v39, neg(0) op_sel_hi:[1,0,0]        // 000000DB9984: CC200008 8A024F08
	v_add_f32_e32 v26, v26, v59                                // 000000DB998C: 0634771A
	s_waitcnt vmcnt(12)                                        // 000000DB9990: BF8933F7
	v_fma_mix_f32 v9, v9, v37, neg(0) op_sel_hi:[1,0,0]        // 000000DB9994: CC200009 8A024B09
	s_waitcnt vmcnt(10)                                        // 000000DB999C: BF892BF7
	v_fma_mix_f32 v12, v12, v40, neg(0) op_sel_hi:[1,0,0]      // 000000DB99A0: CC20000C 8A02510C
	s_waitcnt vmcnt(9)                                         // 000000DB99A8: BF8927F7
	v_fma_mix_f32 v18, v18, v29, neg(0) op_sel_hi:[1,0,0]      // 000000DB99AC: CC200012 8A023B12
	v_add_f32_e32 v30, v30, v43                                // 000000DB99B4: 063C571E
	s_waitcnt vmcnt(6)                                         // 000000DB99B8: BF891BF7
	v_fma_mix_f32 v21, v21, v27, neg(0) op_sel_hi:[1,0,0]      // 000000DB99BC: CC200015 8A023715
	v_mul_f32_e32 v27, 0xbfb8aa3b, v8                          // 000000DB99C4: 103610FF BFB8AA3B
	v_mul_f32_e32 v31, 0xbfb8aa3b, v18                         // 000000DB99CC: 103E24FF BFB8AA3B
	v_mov_b32_dpp v59, v26 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DB99D4: 7E7602FA FF01641A
	v_cndmask_b32_e64 v26, -v26, v26, s2                       // 000000DB99DC: D501001A 200A351A
	v_dual_add_f32 v34, v34, v46 :: v_dual_mul_f32 v37, 0xbfb8aa3b, v21// 000000DB99E4: C9065D22 22242AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB99F0: BF8701A4
	v_exp_f32_e32 v31, v31                                     // 000000DB99F4: 7E3E4B1F
	v_add_f32_e32 v42, v42, v54                                // 000000DB99F8: 06546D2A
	v_add_f32_e32 v26, v26, v59                                // 000000DB99FC: 0634771A
	v_mov_b32_dpp v43, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9A00: 7E5602FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000DB9A08: D501001E 200E3D1E
	v_mov_b32_dpp v46, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9A10: 7E5C02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DB9A18: D5010022 200E4522
	v_mov_b32_dpp v59, v26 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9A20: 7E7602FA FF01681A
	v_cndmask_b32_e64 v26, -v26, v26, s3                       // 000000DB9A28: D501001A 200E351A
	v_exp_f32_e32 v27, v27                                     // 000000DB9A30: 7E364B1B
	v_add_f32_e32 v31, 1.0, v31                                // 000000DB9A34: 063E3EF2
	v_mov_b32_dpp v54, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9A38: 7E6C02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DB9A40: D501002A 200E552A
	v_add_f32_e32 v26, v26, v59                                // 000000DB9A48: 0634771A
	v_add_f32_e32 v34, v34, v46                                // 000000DB9A4C: 06445D22
	v_exp_f32_e32 v37, v37                                     // 000000DB9A50: 7E4A4B25
	v_add_f32_e32 v38, v38, v48                                // 000000DB9A54: 064C6126
	v_add_f32_e32 v42, v42, v54                                // 000000DB9A58: 06546D2A
	v_mul_f32_e32 v26, 0x3db504f3, v26                         // 000000DB9A5C: 103434FF 3DB504F3
	v_dual_mul_f32 v34, 0x3db504f3, v34 :: v_dual_add_f32 v27, 1.0, v27// 000000DB9A64: C8C844FF 221A36F2 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB9A70: BF870214
	v_mov_b32_dpp v48, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9A74: 7E6002FA FF016826
	v_mul_f32_e32 v42, 0x3db504f3, v42                         // 000000DB9A7C: 105454FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB9A84: BF870004
	v_fma_mix_f32 v20, v20, v26, neg(0) op_sel_hi:[1,0,0]      // 000000DB9A88: CC200014 8A023514
	v_mul_f32_e32 v26, 0xbfb8aa3b, v9                          // 000000DB9A90: 103412FF BFB8AA3B
	v_add_f32_e32 v36, v36, v50                                // 000000DB9A98: 06486524
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000DB9A9C: D5010026 200E4D26
	v_fma_mix_f32 v11, v11, v42, neg(0) op_sel_hi:[1,0,0]      // 000000DB9AA4: CC20000B 8A02550B
	v_add_f32_e32 v32, v32, v45                                // 000000DB9AAC: 06405B20
	v_exp_f32_e32 v26, v26                                     // 000000DB9AB0: 7E344B1A
	v_mul_f32_e32 v39, 0xbfb8aa3b, v20                         // 000000DB9AB4: 104E28FF BFB8AA3B
	v_mov_b32_dpp v50, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9ABC: 7E6402FA FF016824
	v_mul_f32_e32 v29, 0xbfb8aa3b, v11                         // 000000DB9AC4: 103A16FF BFB8AA3B
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000DB9ACC: D5010024 200E4924
	s_waitcnt vmcnt(4)                                         // 000000DB9AD4: BF8913F7
	v_fma_mix_f32 v23, v23, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DB9AD8: CC200017 8A024517
	v_add_f32_e32 v34, 1.0, v37                                // 000000DB9AE0: 06444AF2
	v_div_scale_f32 v37, null, v27, v27, v8                    // 000000DB9AE4: D6FC7C25 0422371B
	v_exp_f32_e32 v29, v29                                     // 000000DB9AEC: 7E3A4B1D
	v_add_f32_e32 v24, v24, v51                                // 000000DB9AF0: 06306718
	v_add_f32_e32 v26, 1.0, v26                                // 000000DB9AF4: 063434F2
	v_mov_b32_dpp v45, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9AF8: 7E5A02FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000DB9B00: D5010020 200E4120
	v_exp_f32_e32 v39, v39                                     // 000000DB9B08: 7E4E4B27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000DB9B0C: BF870323
	v_div_scale_f32 v40, null, v26, v26, v9                    // 000000DB9B10: D6FC7C28 0426351A
	v_div_scale_f32 v42, s4, v9, v26, v9                       // 000000DB9B18: D6FC042A 04263509
	v_add_f32_e32 v29, 1.0, v29                                // 000000DB9B20: 063A3AF2
	v_mov_b32_dpp v51, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9B24: 7E6602FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000DB9B2C: D5010018 200E3118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000DB9B34: BF8702C1
	v_add_f32_e32 v24, v24, v51                                // 000000DB9B38: 06306718
	v_rcp_f32_e32 v51, v40                                     // 000000DB9B3C: 7E665528
	s_waitcnt vmcnt(3)                                         // 000000DB9B40: BF890FF7
	v_fma_mix_f32 v14, v14, v35, neg(0) op_sel_hi:[1,0,0]      // 000000DB9B44: CC20000E 8A02470E
	v_fma_f32 v62, -v40, v51, 1.0                              // 000000DB9B4C: D613003E 23CA6728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9B54: BF870091
	v_dual_add_f32 v28, v28, v58 :: v_dual_fmac_f32 v51, v62, v51// 000000DB9B58: C900751C 1C32673E
	v_mov_b32_dpp v58, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DB9B60: 7E7402FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000DB9B68: D501001C 200E391C
	v_add_f32_e32 v36, v36, v50                                // 000000DB9B70: 06486524
	v_rcp_f32_e32 v50, v37                                     // 000000DB9B74: 7E645525
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB9B78: BF870122
	v_add_f32_e32 v28, v28, v58                                // 000000DB9B7C: 0638751C
	v_div_scale_f32 v58, s5, v11, v29, v11                     // 000000DB9B80: D6FC053A 042E3B0B
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000DB9B88: 103838FF 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9B90: BF870115
	v_fma_f32 v61, -v37, v50, 1.0                              // 000000DB9B94: D613003D 23CA6525
	v_fma_mix_f32 v19, v19, v28, neg(0) op_sel_hi:[1,0,0]      // 000000DB9B9C: CC200013 8A023913
	v_mul_f32_e32 v28, 0xbfb8aa3b, v12                         // 000000DB9BA4: 103818FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9BAC: BF870113
	v_fmac_f32_e32 v50, v61, v50                               // 000000DB9BB0: 5664653D
	v_exp_f32_e32 v28, v28                                     // 000000DB9BB4: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9BB8: BF870095
	v_add_f32_e32 v28, 1.0, v28                                // 000000DB9BBC: 063838F2
	v_div_scale_f32 v44, null, v28, v28, v12                   // 000000DB9BC0: D6FC7C2C 0432391C
	v_div_scale_f32 v60, s6, v12, v28, v12                     // 000000DB9BC8: D6FC063C 0432390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB9BD0: BF870292
	v_rcp_f32_e32 v53, v44                                     // 000000DB9BD4: 7E6A552C
	v_fma_f32 v64, -v44, v53, 1.0                              // 000000DB9BD8: D6130040 23CA6B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB9BE0: BF8700A1
	v_dual_fmac_f32 v53, v64, v53 :: v_dual_add_f32 v30, v30, v43// 000000DB9BE4: C8086B40 351E571E
	v_div_scale_f32 v43, null, v29, v29, v11                   // 000000DB9BEC: D6FC7C2B 042E3B1D
	v_rcp_f32_e32 v52, v43                                     // 000000DB9BF4: 7E68552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9BF8: BF870095
	v_fma_f32 v63, -v43, v52, 1.0                              // 000000DB9BFC: D613003F 23CA692B
	v_dual_fmac_f32 v52, v63, v52 :: v_dual_mul_f32 v63, v42, v51// 000000DB9C04: C806693F 343E672A
	v_add_f32_e32 v38, v38, v48                                // 000000DB9C0C: 064C6126
	v_div_scale_f32 v48, null, v34, v34, v21                   // 000000DB9C10: D6FC7C30 04564522
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000DB9C18: 104848FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB9C20: BF870194
	v_mul_f32_e32 v64, v58, v52                                // 000000DB9C24: 1080693A
	v_rcp_f32_e32 v59, v48                                     // 000000DB9C28: 7E765530
	s_waitcnt vmcnt(1)                                         // 000000DB9C2C: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB9C30: BF870292
	v_fma_mix_f32 v13, v13, v36, neg(0) op_sel_hi:[1,0,0]      // 000000DB9C34: CC20000D 8A02490D
	v_fma_f32 v61, -v48, v59, 1.0                              // 000000DB9C3C: D613003D 23CA7730
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DB9C44: BF8700A1
	v_fmac_f32_e32 v59, v61, v59                               // 000000DB9C48: 5676773D
	v_dual_mul_f32 v61, v60, v53 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000DB9C4C: C8C66B3C 3D1E3CFF 3DB504F3
	v_fma_mix_f32 v7, v7, v30, neg(0) op_sel_hi:[1,0,0]        // 000000DB9C58: CC200007 8A023D07
	v_mul_f32_e32 v30, 0xbfb8aa3b, v19                         // 000000DB9C60: 103C26FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DB9C68: BF870291
	v_exp_f32_e32 v30, v30                                     // 000000DB9C6C: 7E3C4B1E
	v_add_f32_e32 v30, 1.0, v30                                // 000000DB9C70: 063C3CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9C74: BF870091
	v_div_scale_f32 v46, null, v30, v30, v19                   // 000000DB9C78: D6FC7C2E 044E3D1E
	v_rcp_f32_e32 v55, v46                                     // 000000DB9C80: 7E6E552E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DB9C84: BF870135
	v_fma_f32 v67, -v46, v55, 1.0                              // 000000DB9C88: D6130043 23CA6F2E
	v_add_f32_e32 v32, v32, v45                                // 000000DB9C90: 06405B20
	v_div_scale_f32 v45, null, v31, v31, v18                   // 000000DB9C94: D6FC7C2D 044A3F1F
	v_dual_fmac_f32 v55, v67, v55 :: v_dual_mul_f32 v32, 0x3db504f3, v32// 000000DB9C9C: C8066F43 372040FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DB9CA8: BF870122
	v_rcp_f32_e32 v54, v45                                     // 000000DB9CAC: 7E6C552D
	v_fma_f32 v67, -v40, v63, v42                              // 000000DB9CB0: D6130043 24AA7F28
	v_fma_mix_f32 v22, v22, v32, neg(0) op_sel_hi:[1,0,0]      // 000000DB9CB8: CC200016 8A024116
	v_add_f32_e32 v32, 1.0, v39                                // 000000DB9CC0: 06404EF2
	v_div_scale_f32 v39, vcc_lo, v8, v27, v8                   // 000000DB9CC4: D6FC6A27 04223708
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)// 000000DB9CCC: BF8702C4
	v_fmac_f32_e32 v63, v67, v51                               // 000000DB9CD0: 567E6743
	v_fma_f32 v67, -v44, v61, v60                              // 000000DB9CD4: D6130043 24F27B2C
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000DB9CDC: 104C4CFF 3DB504F3
	v_div_scale_f32 v47, null, v32, v32, v20                   // 000000DB9CE4: D6FC7C2F 04524120
	v_fma_f32 v66, -v45, v54, 1.0                              // 000000DB9CEC: D6130042 23CA6D2D
	v_mul_f32_e32 v62, v39, v50                                // 000000DB9CF4: 107C6527
	v_fmac_f32_e32 v61, v67, v53                               // 000000DB9CF8: 567A6B43
	v_fma_mix_f32 v15, v15, v38, neg(0) op_sel_hi:[1,0,0]      // 000000DB9CFC: CC20000F 8A024D0F
	v_rcp_f32_e32 v56, v47                                     // 000000DB9D04: 7E70552F
	v_fmac_f32_e32 v54, v66, v54                               // 000000DB9D08: 566C6D42
	v_fma_f32 v66, -v37, v62, v39                              // 000000DB9D0C: D6130042 249E7D25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000DB9D14: BF8702A1
	v_fmac_f32_e32 v62, v66, v50                               // 000000DB9D18: 567C6542
	v_div_scale_f32 v66, s7, v18, v31, v18                     // 000000DB9D1C: D6FC0742 044A3F12
	v_fma_f32 v68, -v47, v56, 1.0                              // 000000DB9D24: D6130044 23CA712F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DB9D2C: BF870233
	v_fma_f32 v37, -v37, v62, v39                              // 000000DB9D30: D6130025 249E7D25
	v_fma_f32 v39, -v40, v63, v42                              // 000000DB9D38: D6130027 24AA7F28
	v_fma_f32 v42, -v44, v61, v60                              // 000000DB9D40: D613002A 24F27B2C
	v_fmac_f32_e32 v56, v68, v56                               // 000000DB9D48: 56707144
	v_fma_f32 v68, -v43, v64, v58                              // 000000DB9D4C: D6130044 24EA812B
	v_div_fmas_f32 v37, v37, v50, v62                          // 000000DB9D54: D6370025 04FA6525
	s_mov_b32 vcc_lo, s4                                       // 000000DB9D5C: BEEA0004
	s_mov_b32 s4, exec_lo                                      // 000000DB9D60: BE84007E
	v_div_fmas_f32 v39, v39, v51, v63                          // 000000DB9D64: D6370027 04FE6727
	v_fmac_f32_e32 v64, v68, v52                               // 000000DB9D6C: 56806944
	v_mul_f32_e32 v68, v66, v54                                // 000000DB9D70: 10886D42
	s_mov_b32 vcc_lo, s5                                       // 000000DB9D74: BEEA0005
	v_div_fixup_f32 v8, v37, v27, v8                           // 000000DB9D78: D6270008 04223725
	v_div_fixup_f32 v9, v39, v26, v9                           // 000000DB9D80: D6270009 04263527
	v_fma_f32 v40, -v43, v64, v58                              // 000000DB9D88: D6130028 24EA812B
	v_fma_f32 v67, -v45, v68, v66                              // 000000DB9D90: D6130043 250A892D
	s_mov_b32 s5, 0x3db504f3                                   // 000000DB9D98: BE8500FF 3DB504F3
	v_mul_f32_e32 v7, v7, v8                                   // 000000DB9DA0: 100E1107
	v_mul_f32_e32 v9, v10, v9                                  // 000000DB9DA4: 1012130A
	v_div_fmas_f32 v40, v40, v52, v64                          // 000000DB9DA8: D6370028 05026928
	v_fmac_f32_e32 v68, v67, v54                               // 000000DB9DB0: 56886D43
	v_div_scale_f32 v67, s8, v19, v30, v19                     // 000000DB9DB4: D6FC0843 044E3D13
	s_mov_b32 vcc_lo, s6                                       // 000000DB9DBC: BEEA0006
	v_div_fmas_f32 v27, v42, v53, v61                          // 000000DB9DC0: D637001B 04F66B2A
	v_fma_f32 v43, -v45, v68, v66                              // 000000DB9DC8: D613002B 250A892D
	v_mul_f32_e32 v69, v67, v55                                // 000000DB9DD0: 108A6F43
	global_load_d16_b16 v45, v[4:5], off offset:32             // 000000DB9DD4: DC820020 2D7C0004
	s_mov_b32 vcc_lo, s7                                       // 000000DB9DDC: BEEA0007
	v_div_fixup_f32 v11, v40, v29, v11                         // 000000DB9DE0: D627000B 042E3B28
	v_div_fmas_f32 v26, v43, v54, v68                          // 000000DB9DE8: D637001A 05126D2B
	v_fma_f32 v70, -v46, v69, v67                              // 000000DB9DF0: D6130046 250E8B2E
	s_mov_b32 vcc_lo, s8                                       // 000000DB9DF8: BEEA0008
	v_div_fixup_f32 v8, v27, v28, v12                          // 000000DB9DFC: D6270008 0432391B
	v_mul_f32_e32 v11, v22, v11                                // 000000DB9E04: 10161716
	v_div_fixup_f32 v18, v26, v31, v18                         // 000000DB9E08: D6270012 044A3F1A
	v_fmac_f32_e32 v69, v70, v55                               // 000000DB9E10: 568A6F46
	v_div_scale_f32 v70, s9, v20, v32, v20                     // 000000DB9E14: D6FC0946 04524114
	v_mul_f32_e32 v8, v23, v8                                  // 000000DB9E1C: 10101117
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DB9E20: BF870214
	v_mul_f32_e32 v14, v14, v18                                // 000000DB9E24: 101C250E
	v_fma_f32 v44, -v46, v69, v67                              // 000000DB9E28: D613002C 250E8B2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DB9E30: BF8701A4
	v_mul_f32_e32 v71, v70, v56                                // 000000DB9E34: 108E7146
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000DB9E38: 103030FF 3DB504F3
	v_div_fmas_f32 v10, v44, v55, v69                          // 000000DB9E40: D637000A 05166F2C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DB9E48: BF870003
	v_fma_f32 v72, -v47, v71, v70                              // 000000DB9E4C: D6130048 251A8F2F
	s_mov_b32 vcc_lo, s9                                       // 000000DB9E54: BEEA0009
	s_waitcnt vmcnt(1)                                         // 000000DB9E58: BF8907F7
	v_fma_mix_f32 v16, v16, v24, neg(0) op_sel_hi:[1,0,0]      // 000000DB9E5C: CC200010 8A023110
	v_div_fixup_f32 v10, v10, v30, v19                         // 000000DB9E64: D627000A 044E3D0A
	v_fmac_f32_e32 v71, v72, v56                               // 000000DB9E6C: 568E7148
	v_div_scale_f32 v72, s10, v21, v34, v21                    // 000000DB9E70: D6FC0A48 04564515
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DB9E78: BF870193
	v_mul_f32_e32 v10, v15, v10                                // 000000DB9E7C: 1014150F
	v_fma_f32 v46, -v47, v71, v70                              // 000000DB9E80: D613002E 251A8F2F
	s_clause 0x6                                               // 000000DB9E88: BF850006
	global_load_d16_b16 v47, v[4:5], off offset:96             // 000000DB9E8C: DC820060 2F7C0004
	global_load_d16_b16 v50, v[4:5], off offset:160            // 000000DB9E94: DC8200A0 327C0004
	global_load_d16_b16 v51, v[4:5], off offset:224            // 000000DB9E9C: DC8200E0 337C0004
	global_load_d16_b16 v52, v[4:5], off offset:192            // 000000DB9EA4: DC8200C0 347C0004
	global_load_d16_b16 v58, v[4:5], off offset:128            // 000000DB9EAC: DC820080 3A7C0004
	global_load_d16_b16 v60, v[4:5], off offset:64             // 000000DB9EB4: DC820040 3C7C0004
	global_load_d16_b16 v62, v[4:5], off                       // 000000DB9EBC: DC820000 3E7C0004
	v_mul_f32_e32 v74, v72, v59                                // 000000DB9EC4: 10947748
	v_div_fmas_f32 v22, v46, v56, v71                          // 000000DB9EC8: D6370016 051E712E
	s_mov_b32 vcc_lo, s10                                      // 000000DB9ED0: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9ED4: BF870112
	v_fma_f32 v75, -v48, v74, v72                              // 000000DB9ED8: D613004B 25229530
	v_div_fixup_f32 v15, v22, v32, v20                         // 000000DB9EE0: D627000F 04524116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9EE8: BF870112
	v_fmac_f32_e32 v74, v75, v59                               // 000000DB9EEC: 5694774B
	v_mul_f32_e32 v13, v13, v15                                // 000000DB9EF0: 101A1F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9EF4: BF870092
	v_fma_f32 v12, -v48, v74, v72                              // 000000DB9EF8: D613000C 25229530
	v_div_fmas_f32 v12, v12, v59, v74                          // 000000DB9F00: D637000C 052A770C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DB9F08: BF870091
	v_div_fixup_f32 v12, v12, v34, v21                         // 000000DB9F0C: D627000C 0456450C
	v_mul_f32_e32 v12, v16, v12                                // 000000DB9F14: 10181910
	s_waitcnt vmcnt(7)                                         // 000000DB9F18: BF891FF7
	v_fma_mix_f32 v9, v45, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DB9F1C: CC200009 8A02132D
	s_waitcnt vmcnt(6)                                         // 000000DB9F24: BF891BF7
	v_fma_mix_f32 v8, v47, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DB9F28: CC200008 8A02112F
	s_waitcnt vmcnt(5)                                         // 000000DB9F30: BF8917F7
	v_fma_mix_f32 v10, v50, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DB9F34: CC20000A 8A021532
	s_waitcnt vmcnt(4)                                         // 000000DB9F3C: BF8913F7
	v_fma_mix_f32 v12, v51, v12, neg(0) op_sel_hi:[1,0,0]      // 000000DB9F40: CC20000C 8A021933
	s_waitcnt vmcnt(1)                                         // 000000DB9F48: BF8907F7
	v_fma_mix_f32 v16, v11, v60, v8 op_sel_hi:[0,1,0]          // 000000DB9F4C: CC200010 1422790B
	s_waitcnt vmcnt(0)                                         // 000000DB9F54: BF8903F7
	v_fma_mix_f32 v15, v7, v62, v9 op_sel_hi:[0,1,0]           // 000000DB9F58: CC20000F 14267D07
	v_fma_mix_f32 v18, v14, v58, v10 op_sel_hi:[0,1,0]         // 000000DB9F60: CC200012 142A750E
	v_fma_mix_f32 v19, v13, v52, v12 op_sel_hi:[0,1,0]         // 000000DB9F68: CC200013 1432690D
	v_fma_mix_f32 v7, v7, v62, -v9 op_sel_hi:[0,1,0]           // 000000DB9F70: CC200007 94267D07
	v_fma_mix_f32 v8, v11, v60, -v8 op_sel_hi:[0,1,0]          // 000000DB9F78: CC200008 9422790B
	v_add_f32_e32 v20, v15, v16                                // 000000DB9F80: 0628210F
	v_fma_mix_f32 v10, v14, v58, -v10 op_sel_hi:[0,1,0]        // 000000DB9F84: CC20000A 942A750E
	v_add_f32_e32 v21, v18, v19                                // 000000DB9F8C: 062A2712
	v_fma_mix_f32 v11, v13, v52, -v12 op_sel_hi:[0,1,0]        // 000000DB9F90: CC20000B 9432690D
	v_sub_f32_e32 v12, v15, v16                                // 000000DB9F98: 0818210F
	v_add_f32_e32 v13, v7, v8                                  // 000000DB9F9C: 061A1107
	v_sub_f32_e32 v7, v7, v8                                   // 000000DB9FA0: 080E1107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000DB9FA4: BF8701B4
	v_dual_add_f32 v9, v20, v21 :: v_dual_add_f32 v8, v10, v11 // 000000DB9FA8: C9082B14 0908170A
	v_sub_f32_e32 v15, v18, v19                                // 000000DB9FB0: 081E2712
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v20, v21// 000000DB9FB4: C94A170A 0A0A2B14
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DB9FBC: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DB9FC4: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DB9FCC: BF870113
	v_cndmask_b32_e64 v21, -v11, v11, s0                       // 000000DB9FD0: D5010015 2002170B
	v_add_f32_e32 v9, v9, v14                                  // 000000DB9FD8: 06121D09
	v_add_f32_e32 v14, v13, v8                                 // 000000DB9FDC: 061C110D
	v_dual_sub_f32 v13, v13, v8 :: v_dual_add_f32 v8, v12, v15 // 000000DB9FE0: C948110D 0D081F0C
	v_sub_f32_e32 v15, v12, v15                                // 000000DB9FE8: 081E1F0C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DB9FEC: BF870004
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DB9FF0: 7E2002FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000DB9FF8: D5010009 20061309
	v_mov_b32_dpp v18, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA000: 7E2402FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DBA008: D501000E 20021D0E
	v_mov_b32_dpp v19, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA010: 7E2602FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DBA018: D5010008 20021108
	v_add_f32_e32 v9, v9, v16                                  // 000000DBA020: 06122109
	v_mov_b32_dpp v22, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA024: 7E2C02FA FF01610F
	v_add_f32_e32 v12, v14, v18                                // 000000DBA02C: 0618250E
	v_add_f32_e32 v14, v7, v10                                 // 000000DBA030: 061C1507
	v_add_f32_e32 v8, v8, v19                                  // 000000DBA034: 06102708
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA038: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000DBA040: D5010009 200A1309
	v_mov_b32_dpp v18, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA048: 7E2402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DBA050: D501000C 2006190C
	v_mov_b32_dpp v19, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA058: 7E2602FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000DBA060: D5010008 20061108
	v_mov_b32_dpp v20, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA068: 7E2802FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000DBA070: D501000E 20021D0E
	v_add_f32_e32 v12, v12, v18                                // 000000DBA078: 0618250C
	v_sub_f32_e32 v18, v7, v10                                 // 000000DBA07C: 08241507
	v_dual_add_f32 v8, v8, v19 :: v_dual_add_f32 v7, v9, v16   // 000000DBA080: C9082708 08062109
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DBA088: BF870234
	v_add_f32_e32 v9, v14, v20                                 // 000000DBA08C: 0612290E
	v_mov_b32_dpp v20, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA090: 7E2802FA FF01610B
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000DBA098: D501000F 20021F0F
	v_mov_b32_dpp v14, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA0A0: 7E1C02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000DBA0A8: D5010008 200A1108
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA0B0: 7E2002FA FF016209
	v_cndmask_b32_e64 v19, -v9, v9, s1                         // 000000DBA0B8: D5010013 20061309
	v_mov_b32_dpp v23, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA0C0: 7E2E02FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000DBA0C8: D5010012 20022512
	v_add_f32_e32 v11, v8, v14                                 // 000000DBA0D0: 06161D08
	v_mov_b32_dpp v10, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA0D4: 7E1402FA FF01640C
	v_add_f32_e32 v14, v19, v16                                // 000000DBA0DC: 061C2113
	v_add_f32_e32 v16, v21, v20                                // 000000DBA0E0: 06202915
	v_mov_b32_dpp v21, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA0E4: 7E2A02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DBA0EC: D501000D 20021B0D
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000DBA0F4: D501000C 200A190C
	v_mov_b32_dpp v19, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA0FC: 7E2602FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000DBA104: D501000E 200A1D0E
	v_mov_b32_dpp v20, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA10C: 7E2802FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000DBA114: D5010010 20062110
	v_add_f32_e32 v21, v13, v21                                // 000000DBA11C: 062A2B0D
	v_add_f32_e32 v9, v12, v10                                 // 000000DBA120: 0612150C
	v_dual_add_f32 v13, v14, v19 :: v_dual_add_f32 v14, v15, v22// 000000DBA124: C908270E 0D0E2D0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBA12C: BF870214
	v_dual_add_f32 v15, v16, v20 :: v_dual_add_f32 v16, v18, v23// 000000DBA130: C9082910 0F102F12
	v_mov_b32_dpp v18, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA138: 7E2402FA FF016215
	v_cndmask_b32_e64 v19, -v21, v21, s1                       // 000000DBA140: D5010013 20062B15
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA148: BF870004
	v_mov_b32_dpp v20, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA14C: 7E2802FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000DBA154: D501000E 20061D0E
	v_mov_b32_dpp v21, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA15C: 7E2A02FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000DBA164: D5010010 20062110
	v_add_f32_e32 v18, v19, v18                                // 000000DBA16C: 06242513
	v_mov_b32_dpp v19, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA170: 7E2602FA FF01640F
	v_add_f32_e32 v14, v14, v20                                // 000000DBA178: 061C290E
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000DBA17C: D501000F 200A1F0F
	v_add_f32_e32 v16, v16, v21                                // 000000DBA184: 06202B10
	v_mov_b32_dpp v20, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA188: 7E2802FA FF016412
	v_cndmask_b32_e64 v21, -v18, v18, s2                       // 000000DBA190: D5010015 200A2512
	v_mov_b32_dpp v22, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA198: 7E2C02FA FF01640E
	v_cndmask_b32_e64 v23, -v14, v14, s2                       // 000000DBA1A0: D5010017 200A1D0E
	v_mov_b32_dpp v24, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA1A8: 7E3002FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 000000DBA1B0: D5010010 200A2110
	v_dual_add_f32 v18, v15, v19 :: v_dual_add_f32 v19, v21, v20// 000000DBA1B8: C908270F 12122915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DBA1C0: BF870224
	v_add_f32_e32 v21, v23, v22                                // 000000DBA1C4: 062A2D17
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1C8: 7E1002FA FF016807
	v_add_f32_e32 v23, v16, v24                                // 000000DBA1D0: 062E3110
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1D4: 7E1402FA FF016809
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1DC: 7E1802FA FF01680B
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1E4: 7E1C02FA FF01680D
	v_add_nc_u32_e32 v15, 12, v6                               // 000000DBA1EC: 4A1E0C8C
	v_mov_b32_dpp v16, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1F0: 7E2002FA FF016812
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA1F8: 7E2802FA FF016813
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA200: 7E2C02FA FF016815
	v_mov_b32_dpp v24, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA208: 7E3002FA FF016817
	.long 0xd4c4007e                                           // 000000DBA210: D4C4007E
	v_cndmask_b32_e32 v1, s23, v15, vcc_lo                     // 000000DBA214: 02021E17
	s_cbranch_execz 60                                         // 000000DBA218: BFA5003C <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x770c>
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DBA21C: D5010007 200E0F07
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000DBA224: D5010017 200E2F17
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DBA22C: D5010009 200E1309
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000DBA234: D501000B 200E170B
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000DBA23C: D5010013 200E2713
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DBA244: D501000D 200E1B0D
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000DBA24C: D5010015 200E2B15
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000DBA254: D5010012 200E2512
	v_add_f32_e32 v7, v7, v8                                   // 000000DBA25C: 060E1107
	v_dual_add_f32 v23, v23, v24 :: v_dual_add_f32 v8, v9, v10 // 000000DBA260: C9083117 17081509
	v_add_f32_e32 v9, v11, v12                                 // 000000DBA268: 0612190B
	v_mad_i64_i32 v[11:12], null, 0x500, v15, v[0:1]           // 000000DBA26C: D6FF7C0B 04021EFF 00000500
	v_dual_add_f32 v19, v19, v20 :: v_dual_add_f32 v10, v13, v14// 000000DBA278: C9082913 130A1D0D
	v_dual_add_f32 v21, v21, v22 :: v_dual_add_f32 v16, v18, v16// 000000DBA280: C9082D15 15102112
	v_fma_mixlo_f16 v7, v7, s5, 0                              // 000000DBA288: CC210007 02000B07
	v_fma_mixhi_f16 v7, v8, s5, 0                              // 000000DBA290: CC220007 02000B08
	v_fma_mixlo_f16 v8, v9, s5, 0                              // 000000DBA298: CC210008 02000B09
	v_fma_mixhi_f16 v8, v10, s5, 0                             // 000000DBA2A0: CC220008 02000B0A
	v_fma_mixlo_f16 v9, v16, s5, 0                             // 000000DBA2A8: CC210009 02000B10
	v_fma_mixhi_f16 v9, v19, s5, 0                             // 000000DBA2B0: CC220009 02000B13
	v_fma_mixlo_f16 v10, v21, s5, 0                            // 000000DBA2B8: CC21000A 02000B15
	v_fma_mixhi_f16 v10, v23, s5, 0                            // 000000DBA2C0: CC22000A 02000B17
	s_clause 0x7                                               // 000000DBA2C8: BF850007
	global_store_b16 v[11:12], v7, off                         // 000000DBA2CC: DC660000 007C070B
	global_store_d16_hi_b16 v[11:12], v7, off offset:32        // 000000DBA2D4: DC960020 007C070B
	global_store_b16 v[11:12], v8, off offset:64               // 000000DBA2DC: DC660040 007C080B
	global_store_d16_hi_b16 v[11:12], v8, off offset:96        // 000000DBA2E4: DC960060 007C080B
	global_store_b16 v[11:12], v9, off offset:128              // 000000DBA2EC: DC660080 007C090B
	global_store_d16_hi_b16 v[11:12], v9, off offset:160       // 000000DBA2F4: DC9600A0 007C090B
	global_store_b16 v[11:12], v10, off offset:192             // 000000DBA2FC: DC6600C0 007C0A0B
	global_store_d16_hi_b16 v[11:12], v10, off offset:224      // 000000DBA304: DC9600E0 007C0A0B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000DBA30C: 8C7E047E
	s_clause 0xb                                               // 000000DBA310: BF85000B
	global_load_d16_b16 v7, v[2:3], off offset:1280            // 000000DBA314: DC820500 077C0002
	global_load_d16_b16 v10, v[2:3], off offset:1312           // 000000DBA31C: DC820520 0A7C0002
	global_load_d16_b16 v8, v[2:3], off                        // 000000DBA324: DC820000 087C0002
	global_load_d16_b16 v9, v[2:3], off offset:32              // 000000DBA32C: DC820020 097C0002
	global_load_d16_b16 v11, v[2:3], off offset:64             // 000000DBA334: DC820040 0B7C0002
	global_load_d16_b16 v12, v[2:3], off offset:96             // 000000DBA33C: DC820060 0C7C0002
	global_load_d16_b16 v22, v[2:3], off offset:128            // 000000DBA344: DC820080 167C0002
	global_load_d16_b16 v23, v[2:3], off offset:160            // 000000DBA34C: DC8200A0 177C0002
	global_load_d16_b16 v24, v[2:3], off offset:192            // 000000DBA354: DC8200C0 187C0002
	global_load_d16_b16 v26, v[2:3], off offset:224            // 000000DBA35C: DC8200E0 1A7C0002
	global_load_d16_b16 v27, v[2:3], off offset:1344           // 000000DBA364: DC820540 1B7C0002
	global_load_d16_b16 v28, v[2:3], off offset:1376           // 000000DBA36C: DC820560 1C7C0002
	v_sub_f32_e32 v39, v73, v65                                // 000000DBA374: 084E8349
	v_sub_f32_e32 v42, v57, v49                                // 000000DBA378: 08546339
	v_add_f32_e32 v43, v41, v33                                // 000000DBA37C: 06564329
	v_sub_f32_e32 v33, v41, v33                                // 000000DBA380: 08424329
	v_add_f32_e32 v41, v25, v17                                // 000000DBA384: 06522319
	v_sub_f32_e32 v25, v25, v17                                // 000000DBA388: 08322319
	s_clause 0x3                                               // 000000DBA38C: BF850003
	global_load_d16_b16 v17, v[2:3], off offset:1408           // 000000DBA390: DC820580 117C0002
	global_load_d16_b16 v19, v[2:3], off offset:1440           // 000000DBA398: DC8205A0 137C0002
	global_load_d16_b16 v15, v[2:3], off offset:1472           // 000000DBA3A0: DC8205C0 0F7C0002
	global_load_d16_b16 v20, v[2:3], off offset:1504           // 000000DBA3A8: DC8205E0 147C0002
	s_clause 0x7                                               // 000000DBA3B0: BF850007
	global_load_d16_b16 v13, v[4:5], off                       // 000000DBA3B4: DC820000 0D7C0004
	global_load_d16_b16 v21, v[4:5], off offset:32             // 000000DBA3BC: DC820020 157C0004
	global_load_d16_b16 v14, v[4:5], off offset:64             // 000000DBA3C4: DC820040 0E7C0004
	global_load_d16_b16 v16, v[4:5], off offset:96             // 000000DBA3CC: DC820060 107C0004
	global_load_d16_b16 v2, v[4:5], off offset:128             // 000000DBA3D4: DC820080 027C0004
	global_load_d16_b16 v18, v[4:5], off offset:160            // 000000DBA3DC: DC8200A0 127C0004
	global_load_d16_b16 v3, v[4:5], off offset:192             // 000000DBA3E4: DC8200C0 037C0004
	global_load_d16_b16 v4, v[4:5], off offset:224             // 000000DBA3EC: DC8200E0 047C0004
	v_sub_f32_e32 v32, v121, v113                              // 000000DBA3F4: 0840E379
	v_add_f32_e32 v36, v89, v81                                // 000000DBA3F8: 0648A359
	v_add_f32_e32 v38, v73, v65                                // 000000DBA3FC: 064C8349
	v_add_f32_e32 v40, v57, v49                                // 000000DBA400: 06506339
	v_sub_f32_e32 v30, v137, v129                              // 000000DBA404: 083D0389
	v_add_f32_e32 v29, v137, v129                              // 000000DBA408: 063B0389
	v_add_f32_e32 v34, v105, v97                               // 000000DBA40C: 0644C369
	v_add_f32_e32 v31, v121, v113                              // 000000DBA410: 063EE379
	v_dual_sub_f32 v37, v89, v81 :: v_dual_add_nc_u32 v6, 14, v6// 000000DBA414: C960A359 25060C8E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000DBA41C: BF870002
	v_add_f32_e32 v5, v29, v31                                 // 000000DBA420: 060A3F1D
	v_sub_f32_e32 v29, v29, v31                                // 000000DBA424: 083A3F1D
	v_add_f32_e32 v31, v30, v32                                // 000000DBA428: 063E411E
	v_dual_sub_f32 v35, v105, v97 :: v_dual_sub_f32 v30, v30, v32// 000000DBA42C: C94AC369 231E411E
	v_add_f32_e32 v32, v34, v36                                // 000000DBA434: 06404922
	v_sub_f32_e32 v34, v34, v36                                // 000000DBA438: 08444922
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000DBA43C: BF8700A3
	v_add_f32_e32 v36, v35, v37                                // 000000DBA440: 06484B23
	v_sub_f32_e32 v35, v35, v37                                // 000000DBA444: 08464B23
	v_add_f32_e32 v45, v30, v35                                // 000000DBA448: 065A471E
	v_add_f32_e32 v37, v38, v40                                // 000000DBA44C: 064A5126
	v_sub_f32_e32 v38, v38, v40                                // 000000DBA450: 084C5126
	v_add_f32_e32 v40, v39, v42                                // 000000DBA454: 06505527
	v_add_f32_e32 v44, v43, v41                                // 000000DBA458: 0658532B
	v_dual_sub_f32 v39, v39, v42 :: v_dual_sub_f32 v30, v30, v35// 000000DBA45C: C94A5527 271E471E
	v_add_f32_e32 v42, v33, v25                                // 000000DBA464: 06543321
	v_dual_sub_f32 v41, v43, v41 :: v_dual_add_f32 v46, v29, v34// 000000DBA468: C948532B 292E451D
	v_mov_b32_dpp v54, v45 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA470: 7E6C02FA FF01612D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBA478: BF870214
	v_mov_b32_dpp v58, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA47C: 7E7402FA FF01611E
	v_add_f32_e32 v43, v40, v42                                // 000000DBA484: 06565528
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000DBA488: D501001E 20023D1E
	v_sub_f32_e32 v25, v33, v25                                // 000000DBA490: 08323321
	v_add_f32_e32 v33, v37, v44                                // 000000DBA494: 06425925
	v_sub_f32_e32 v37, v37, v44                                // 000000DBA498: 084A5925
	v_add_f32_e32 v44, v5, v32                                 // 000000DBA49C: 06584105
	v_sub_f32_e32 v5, v5, v32                                  // 000000DBA4A0: 080A4105
	v_cndmask_b32_e64 v35, -v43, v43, s0                       // 000000DBA4A4: D5010023 2002572B
	v_mov_b32_dpp v32, v33 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA4AC: 7E4002FA FF016121
	v_cndmask_b32_e64 v33, -v33, v33, s0                       // 000000DBA4B4: D5010021 20024321
	v_mov_b32_dpp v53, v46 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA4BC: 7E6A02FA FF01612E
	v_cndmask_b32_e64 v46, -v46, v46, s0                       // 000000DBA4C4: D501002E 20025D2E
	v_sub_f32_e32 v29, v29, v34                                // 000000DBA4CC: 083A451D
	v_mov_b32_dpp v34, v43 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA4D0: 7E4402FA FF01612B
	v_add_f32_e32 v32, v33, v32                                // 000000DBA4D8: 06404121
	v_add_f32_e32 v30, v30, v58                                // 000000DBA4DC: 063C751E
	v_cndmask_b32_e64 v45, -v45, v45, s0                       // 000000DBA4E0: D501002D 20025B2D
	v_mov_b32_dpp v51, v44 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA4E8: 7E6602FA FF01612C
	v_add_f32_e32 v33, v35, v34                                // 000000DBA4F0: 06424523
	v_sub_f32_e32 v40, v40, v42                                // 000000DBA4F4: 08505528
	v_add_f32_e32 v42, v38, v41                                // 000000DBA4F8: 06545326
	v_sub_f32_e32 v38, v38, v41                                // 000000DBA4FC: 084C5326
	v_mov_b32_dpp v47, v37 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA500: 7E5E02FA FF016125
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000DBA508: D5010025 20024B25
	v_add_f32_e32 v41, v39, v25                                // 000000DBA510: 06523327
	v_sub_f32_e32 v25, v39, v25                                // 000000DBA514: 08323327
	v_add_f32_e32 v39, v31, v36                                // 000000DBA518: 064E491F
	v_sub_f32_e32 v31, v31, v36                                // 000000DBA51C: 083E491F
	v_mov_b32_dpp v36, v42 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA520: 7E4802FA FF01612A
	v_cndmask_b32_e64 v42, -v42, v42, s0                       // 000000DBA528: D501002A 2002552A
	v_mov_b32_dpp v49, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA530: 7E6202FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000DBA538: D5010026 20024D26
	v_mov_b32_dpp v48, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA540: 7E6002FA FF016128
	v_cndmask_b32_e64 v40, -v40, v40, s0                       // 000000DBA548: D5010028 20025128
	v_add_f32_e32 v34, v42, v36                                // 000000DBA550: 0644492A
	v_add_f32_e32 v36, v37, v47                                // 000000DBA554: 06485F25
	v_mov_b32_dpp v43, v41 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA558: 7E5602FA FF016129
	v_cndmask_b32_e64 v41, -v41, v41, s0                       // 000000DBA560: D5010029 20025329
	v_add_f32_e32 v42, v46, v53                                // 000000DBA568: 06546B2E
	v_add_f32_e32 v38, v38, v49                                // 000000DBA56C: 064C6326
	v_mov_b32_dpp v55, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA570: 7E6E02FA FF016105
	v_mov_b32_dpp v56, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA578: 7E7002FA FF01611F
	v_add_f32_e32 v35, v41, v43                                // 000000DBA580: 06465729
	v_mov_b32_dpp v53, v42 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA584: 7E6A02FA FF01622A
	v_cndmask_b32_e64 v42, -v42, v42, s1                       // 000000DBA58C: D501002A 2006552A
	v_add_f32_e32 v41, v45, v54                                // 000000DBA594: 06526D2D
	v_mov_b32_dpp v45, v34 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA598: 7E5A02FA FF016222
	v_cndmask_b32_e64 v34, -v34, v34, s1                       // 000000DBA5A0: D5010022 20064522
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000DBA5A8: D501001F 20023F1F
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000DBA5B0: D5010005 20020B05
	v_mov_b32_dpp v49, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA5B8: 7E6202FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000DBA5C0: D5010026 20064D26
	v_add_f32_e32 v34, v34, v45                                // 000000DBA5C8: 06445B22
	v_mov_b32_dpp v46, v35 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA5CC: 7E5C02FA FF016223
	v_cndmask_b32_e64 v35, -v35, v35, s1                       // 000000DBA5D4: D5010023 20064723
	v_cndmask_b32_e64 v44, -v44, v44, s0                       // 000000DBA5DC: D501002C 2002592C
	v_dual_add_f32 v37, v40, v48 :: v_dual_add_f32 v38, v38, v49// 000000DBA5E4: C9086128 25266326
	v_mov_b32_dpp v47, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA5EC: 7E5E02FA FF016224
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA5F4: BF870004
	v_add_f32_e32 v35, v35, v46                                // 000000DBA5F8: 06465D23
	v_mov_b32_dpp v43, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA5FC: 7E5602FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000DBA604: D5010020 20064120
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000DBA60C: D5010024 20064924
	v_mov_b32_dpp v58, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA614: 7E7402FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000DBA61C: D501001E 20063D1E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA624: BF870004
	v_dual_add_f32 v31, v31, v56 :: v_dual_add_f32 v32, v32, v43// 000000DBA628: C908711F 1F205720
	v_mov_b32_dpp v50, v25 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA630: 7E6402FA FF016119
	v_cndmask_b32_e64 v25, -v25, v25, s0                       // 000000DBA638: D5010019 20023319
	v_mov_b32_dpp v45, v34 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA640: 7E5A02FA FF016422
	v_cndmask_b32_e64 v34, -v34, v34, s2                       // 000000DBA648: D5010022 200A4522
	v_add_f32_e32 v5, v5, v55                                  // 000000DBA650: 060A6F05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA654: BF870004
	v_dual_add_f32 v40, v44, v51 :: v_dual_add_f32 v25, v25, v50// 000000DBA658: C908672C 28186519
	v_add_f32_e32 v36, v36, v47                                // 000000DBA660: 06485F24
	v_mov_b32_dpp v44, v33 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA664: 7E5802FA FF016221
	v_cndmask_b32_e64 v33, -v33, v33, s1                       // 000000DBA66C: D5010021 20064321
	v_mov_b32_dpp v48, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA674: 7E6002FA FF016225
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000DBA67C: D5010025 20064B25
	v_add_f32_e32 v30, v30, v58                                // 000000DBA684: 063C751E
	v_mov_b32_dpp v56, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA688: 7E7002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000DBA690: D501001F 20063F1F
	v_mov_b32_dpp v49, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA698: 7E6202FA FF016426
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000DBA6A0: D5010026 200A4D26
	v_add_f32_e32 v34, v34, v45                                // 000000DBA6A8: 06445B22
	v_mov_b32_dpp v55, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA6AC: 7E6E02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DBA6B4: D5010005 20060B05
	v_mov_b32_dpp v52, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA6BC: 7E6802FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000DBA6C4: D5010027 20024F27
	v_dual_add_f32 v37, v37, v48 :: v_dual_add_f32 v38, v38, v49// 000000DBA6CC: C9086125 25266326
	v_mov_b32_dpp v47, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA6D4: 7E5E02FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000DBA6DC: D5010024 200A4924
	v_add_f32_e32 v33, v33, v44                                // 000000DBA6E4: 06425921
	v_mov_b32_dpp v58, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA6E8: 7E7402FA FF01641E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000DBA6F0: D501001E 200A3D1E
	v_add_f32_e32 v31, v31, v56                                // 000000DBA6F8: 063E711F
	v_mov_b32_dpp v45, v34 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA6FC: 7E5A02FA FF016822
	v_cndmask_b32_e64 v34, -v34, v34, s3                       // 000000DBA704: D5010022 200E4522
	v_add_f32_e32 v5, v5, v55                                  // 000000DBA70C: 060A6F05
	v_mov_b32_dpp v51, v40 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA710: 7E6602FA FF016228
	v_cndmask_b32_e64 v40, -v40, v40, s1                       // 000000DBA718: D5010028 20065128
	v_dual_add_f32 v39, v39, v52 :: v_dual_add_f32 v36, v36, v47// 000000DBA720: C9086927 27245F24
	v_mov_b32_dpp v44, v33 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA728: 7E5802FA FF016421
	v_cndmask_b32_e64 v33, -v33, v33, s2                       // 000000DBA730: D5010021 200A4321
	v_add_f32_e32 v30, v30, v58                                // 000000DBA738: 063C751E
	v_mov_b32_dpp v56, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA73C: 7E7002FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000DBA744: D501001F 200A3F1F
	v_mov_b32_dpp v49, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA74C: 7E6202FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000DBA754: D5010026 200E4D26
	v_add_f32_e32 v34, v34, v45                                // 000000DBA75C: 06445B22
	v_mov_b32_dpp v55, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA760: 7E6E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DBA768: D5010005 200A0B05
	v_mov_b32_dpp v57, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBA770: 7E7202FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000DBA778: D501001D 20023B1D
	v_add_f32_e32 v40, v40, v51                                // 000000DBA780: 06506728
	v_mov_b32_dpp v52, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA784: 7E6802FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000DBA78C: D5010027 20064F27
	v_add_f32_e32 v42, v42, v53                                // 000000DBA794: 06546B2A
	v_mov_b32_dpp v43, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA798: 7E5602FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000DBA7A0: D5010020 200A4120
	v_dual_add_f32 v33, v33, v44 :: v_dual_add_f32 v38, v38, v49// 000000DBA7A8: C9085921 21266326
	v_dual_add_f32 v31, v31, v56 :: v_dual_mul_f32 v34, 0x3db504f3, v34// 000000DBA7B0: C906711F 1F2244FF 3DB504F3
	v_add_f32_e32 v5, v5, v55                                  // 000000DBA7BC: 060A6F05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA7C0: BF870004
	v_dual_add_f32 v29, v29, v57 :: v_dual_add_f32 v32, v32, v43// 000000DBA7C4: C908731D 1D205720
	v_mov_b32_dpp v50, v25 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA7CC: 7E6402FA FF016219
	v_cndmask_b32_e64 v25, -v25, v25, s1                       // 000000DBA7D4: D5010019 20063319
	v_mov_b32_dpp v53, v42 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA7DC: 7E6A02FA FF01642A
	v_cndmask_b32_e64 v42, -v42, v42, s2                       // 000000DBA7E4: D501002A 200A552A
	v_add_f32_e32 v39, v39, v52                                // 000000DBA7EC: 064E6927
	v_mov_b32_dpp v56, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA7F0: 7E7002FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000DBA7F8: D501001F 200E3F1F
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000DBA800: 104C4CFF 3DB504F3
	v_mov_b32_dpp v55, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA808: 7E6E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000DBA810: D5010005 200E0B05
	v_mov_b32_dpp v54, v41 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA818: 7E6C02FA FF016229
	v_cndmask_b32_e64 v41, -v41, v41, s1                       // 000000DBA820: D5010029 20065329
	v_mov_b32_dpp v57, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBA828: 7E7202FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000DBA830: D501001D 20063B1D
	v_mov_b32_dpp v51, v40 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA838: 7E6602FA FF016428
	v_cndmask_b32_e64 v40, -v40, v40, s2                       // 000000DBA840: D5010028 200A5128
	v_dual_add_f32 v25, v25, v50 :: v_dual_add_f32 v42, v42, v53// 000000DBA848: C9086519 192A6B2A
	v_mov_b32_dpp v52, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA850: 7E6802FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000DBA858: D5010027 200A4F27
	v_mov_b32_dpp v43, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA860: 7E5602FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000DBA868: D5010020 200E4120
	v_add_f32_e32 v5, v5, v55                                  // 000000DBA870: 060A6F05
	v_add_f32_e32 v31, v31, v56                                // 000000DBA874: 063E711F
	v_dual_add_f32 v41, v41, v54 :: v_dual_add_f32 v40, v40, v51// 000000DBA878: C9086D29 29286728
	v_mov_b32_dpp v50, v25 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA880: 7E6402FA FF016419
	v_cndmask_b32_e64 v25, -v25, v25, s2                       // 000000DBA888: D5010019 200A3319
	v_mov_b32_dpp v47, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA890: 7E5E02FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000DBA898: D5010024 200E4924
	v_add_f32_e32 v29, v29, v57                                // 000000DBA8A0: 063A731D
	v_mov_b32_dpp v58, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA8A4: 7E7402FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000DBA8AC: D501001E 200E3D1E
	v_dual_add_f32 v39, v39, v52 :: v_dual_add_f32 v32, v32, v43// 000000DBA8B4: C9086927 27205720
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000DBA8BC: 103E3EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000DBA8C4: 100A0AFF 3DB504F3
	v_mov_b32_dpp v46, v35 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA8CC: 7E5C02FA FF016423
	v_cndmask_b32_e64 v35, -v35, v35, s2                       // 000000DBA8D4: D5010023 200A4723
	v_dual_add_f32 v25, v25, v50 :: v_dual_mul_f32 v32, 0x3db504f3, v32// 000000DBA8DC: C9066519 192040FF 3DB504F3
	v_mov_b32_dpp v51, v40 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA8E8: 7E6602FA FF016828
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 000000DBA8F0: D5010028 200E5128
	v_add_f32_e32 v36, v36, v47                                // 000000DBA8F8: 06485F24
	v_mov_b32_dpp v57, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA8FC: 7E7202FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000DBA904: D501001D 200A3B1D
	v_add_f32_e32 v30, v30, v58                                // 000000DBA90C: 063C751E
	v_mov_b32_dpp v52, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA910: 7E6802FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000DBA918: D5010027 200E4F27
	v_mov_b32_dpp v48, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA920: 7E6002FA FF016425
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000DBA928: D5010025 200A4B25
	v_dual_add_f32 v35, v35, v46 :: v_dual_add_f32 v40, v40, v51// 000000DBA930: C9085D23 23286728
	v_add_f32_e32 v29, v29, v57                                // 000000DBA938: 063A731D
	v_mov_b32_dpp v53, v42 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA93C: 7E6A02FA FF01682A
	v_cndmask_b32_e64 v42, -v42, v42, s3                       // 000000DBA944: D501002A 200E552A
	v_add_f32_e32 v37, v37, v48                                // 000000DBA94C: 064A6125
	v_mul_f32_e32 v40, 0x3db504f3, v40                         // 000000DBA950: 105050FF 3DB504F3
	v_mov_b32_dpp v57, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA958: 7E7202FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000DBA960: D501001D 200E3B1D
	v_add_f32_e32 v42, v42, v53                                // 000000DBA968: 06546B2A
	v_mov_b32_dpp v48, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA96C: 7E6002FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s3                       // 000000DBA974: D5010025 200E4B25
	v_mov_b32_dpp v46, v35 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA97C: 7E5C02FA FF016823
	v_cndmask_b32_e64 v35, -v35, v35, s3                       // 000000DBA984: D5010023 200E4723
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000DBA98C: 103C3CFF 3DB504F3
	v_mov_b32_dpp v54, v41 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBA994: 7E6C02FA FF016429
	v_add_f32_e32 v37, v37, v48                                // 000000DBA99C: 064A6125
	v_cndmask_b32_e64 v41, -v41, v41, s2                       // 000000DBA9A0: D5010029 200A5329
	v_mov_b32_dpp v44, v33 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA9A8: 7E5802FA FF016821
	v_cndmask_b32_e64 v33, -v33, v33, s3                       // 000000DBA9B0: D5010021 200E4321
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000DBA9B8: 104848FF 3DB504F3
	v_mul_f32_e32 v42, 0x3db504f3, v42                         // 000000DBA9C0: 105454FF 3DB504F3
	v_add_f32_e32 v41, v41, v54                                // 000000DBA9C8: 06526D29
	v_mov_b32_dpp v50, v25 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA9CC: 7E6402FA FF016819
	v_add_f32_e32 v33, v33, v44                                // 000000DBA9D4: 06425921
	v_cndmask_b32_e64 v25, -v25, v25, s3                       // 000000DBA9D8: D5010019 200E3319
	s_delay_alu instid0(VALU_DEP_4)                            // 000000DBA9E0: BF870004
	v_mov_b32_dpp v54, v41 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBA9E4: 7E6C02FA FF016829
	v_cndmask_b32_e64 v41, -v41, v41, s3                       // 000000DBA9EC: D5010029 200E5329
	s_waitcnt vmcnt(23)                                        // 000000DBA9F4: BF895FF7
	v_fma_mix_f32 v7, v7, v32, neg(0) op_sel_hi:[1,0,0]        // 000000DBA9F8: CC200007 8A024107
	s_waitcnt vmcnt(21)                                        // 000000DBAA00: BF8957F7
	v_fma_mix_f32 v8, v8, v40, neg(0) op_sel_hi:[1,0,0]        // 000000DBAA04: CC200008 8A025108
	s_waitcnt vmcnt(19)                                        // 000000DBAA0C: BF894FF7
	v_fma_mix_f32 v11, v11, v42, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA10: CC20000B 8A02550B
	s_waitcnt vmcnt(17)                                        // 000000DBAA18: BF8947F7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000DBAA1C: CC200005 8A020B16
	s_waitcnt vmcnt(16)                                        // 000000DBAA24: BF8943F7
	v_fma_mix_f32 v22, v23, v31, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA28: CC200016 8A023F17
	v_add_f32_e32 v39, v39, v52                                // 000000DBAA30: 064E6927
	s_waitcnt vmcnt(11)                                        // 000000DBAA34: BF892FF7
	v_fma_mix_f32 v17, v17, v36, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA38: CC200011 8A024911
	v_fma_mix_f32 v27, v27, v34, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA40: CC20001B 8A02451B
	s_waitcnt vmcnt(9)                                         // 000000DBAA48: BF8927F7
	v_fma_mix_f32 v15, v15, v38, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA4C: CC20000F 8A024D0F
	v_mul_f32_e32 v32, 0xbfb8aa3b, v22                         // 000000DBAA54: 10402CFF BFB8AA3B
	v_mul_f32_e32 v39, 0x3db504f3, v39                         // 000000DBAA5C: 104E4EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DBAA64: BF870122
	v_exp_f32_e32 v32, v32                                     // 000000DBAA68: 7E404B20
	v_add_f32_e32 v29, v29, v57                                // 000000DBAA6C: 063A731D
	v_fma_mix_f32 v9, v9, v39, neg(0) op_sel_hi:[1,0,0]        // 000000DBAA70: CC200009 8A024F09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DBAA78: BF870195
	v_dual_add_f32 v35, v35, v46 :: v_dual_add_f32 v32, 1.0, v32// 000000DBAA7C: C9085D23 232040F2
	v_mul_f32_e32 v29, 0x3db504f3, v29                         // 000000DBAA84: 103A3AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DBAA8C: BF870112
	v_div_scale_f32 v49, null, v32, v32, v22                   // 000000DBAA90: D6FC7C31 045A4120
	v_fma_mix_f32 v23, v24, v29, neg(0) op_sel_hi:[1,0,0]      // 000000DBAA98: CC200017 8A023B18
	v_fma_mix_f32 v24, v26, v30, neg(0) op_sel_hi:[1,0,0]      // 000000DBAAA0: CC200018 8A023D1A
	v_dual_mul_f32 v26, 0xbfb8aa3b, v9 :: v_dual_add_f32 v41, v41, v54// 000000DBAAA8: C8C812FF 1A286D29 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DBAAB4: BF870194
	v_rcp_f32_e32 v58, v49                                     // 000000DBAAB8: 7E745531
	v_mul_f32_e32 v40, 0xbfb8aa3b, v23                         // 000000DBAABC: 10502EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBAAC4: BF870092
	v_exp_f32_e32 v26, v26                                     // 000000DBAAC8: 7E344B1A
	v_exp_f32_e32 v40, v40                                     // 000000DBAACC: 7E504B28
	v_mul_f32_e32 v33, 0x3db504f3, v33                         // 000000DBAAD0: 104242FF 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DBAAD8: BF870317
	v_fma_f32 v68, -v49, v58, 1.0                              // 000000DBAADC: D6130044 23CA7531
	v_add_f32_e32 v26, 1.0, v26                                // 000000DBAAE4: 063434F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DBAAE8: BF870292
	v_fmac_f32_e32 v58, v68, v58                               // 000000DBAAEC: 56747544
	v_add_f32_e32 v34, 1.0, v40                                // 000000DBAAF0: 064450F2
	v_fma_mix_f32 v10, v10, v33, neg(0) op_sel_hi:[1,0,0]      // 000000DBAAF4: CC20000A 8A02430A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DBAAFC: BF870224
	v_div_scale_f32 v42, s4, v9, v26, v9                       // 000000DBAB00: D6FC042A 04263509
	v_mul_f32_e32 v41, 0x3db504f3, v41                         // 000000DBAB08: 105252FF 3DB504F3
	v_div_scale_f32 v51, null, v34, v34, v23                   // 000000DBAB10: D6FC7C33 045E4522
	v_div_scale_f32 v61, s9, v23, v34, v23                     // 000000DBAB18: D6FC093D 045E4517
	s_delay_alu instid0(VALU_DEP_3)                            // 000000DBAB20: BF870003
	v_fma_mix_f32 v12, v12, v41, neg(0) op_sel_hi:[1,0,0]      // 000000DBAB24: CC20000C 8A02530C
	v_add_f32_e32 v25, v25, v50                                // 000000DBAB2C: 06326519
	v_div_scale_f32 v41, null, v26, v26, v9                    // 000000DBAB30: D6FC7C29 0426351A
	v_div_scale_f32 v50, s8, v22, v32, v22                     // 000000DBAB38: D6FC0832 045A4116
	v_rcp_f32_e32 v59, v51                                     // 000000DBAB40: 7E765533
	v_mul_f32_e32 v30, 0xbfb8aa3b, v12                         // 000000DBAB44: 103C18FF BFB8AA3B
	v_mul_f32_e32 v25, 0x3db504f3, v25                         // 000000DBAB4C: 103232FF 3DB504F3
	v_rcp_f32_e32 v54, v41                                     // 000000DBAB54: 7E6C5529
	v_mul_f32_e32 v68, v50, v58                                // 000000DBAB58: 10887532
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DBAB5C: BF870133
	v_exp_f32_e32 v30, v30                                     // 000000DBAB60: 7E3C4B1E
	s_waitcnt vmcnt(8)                                         // 000000DBAB64: BF8923F7
	v_fma_mix_f32 v20, v20, v25, neg(0) op_sel_hi:[1,0,0]      // 000000DBAB68: CC200014 8A023314
	v_fma_f32 v76, -v49, v68, v50                              // 000000DBAB70: D613004C 24CA8931
	v_mul_f32_e32 v33, 0xbfb8aa3b, v5                          // 000000DBAB78: 10420AFF BFB8AA3B
	v_fma_f32 v69, -v51, v59, 1.0                              // 000000DBAB80: D6130045 23CA7733
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBAB88: BF870216
	v_fma_f32 v64, -v41, v54, 1.0                              // 000000DBAB8C: D6130040 23CA6D29
	v_dual_mul_f32 v35, 0x3db504f3, v35 :: v_dual_fmac_f32 v68, v76, v58// 000000DBAB94: C8C046FF 2344754C 3DB504F3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DBABA0: BF8701A5
	v_add_f32_e32 v30, 1.0, v30                                // 000000DBABA4: 063C3CF2
	v_exp_f32_e32 v33, v33                                     // 000000DBABA8: 7E424B21
	v_fmac_f32_e32 v54, v64, v54                               // 000000DBABAC: 566C6D40
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000DBABB0: BF8701C3
	v_fma_mix_f32 v28, v28, v35, neg(0) op_sel_hi:[1,0,0]      // 000000DBABB4: CC20001C 8A02471C
	v_fmac_f32_e32 v59, v69, v59                               // 000000DBABBC: 56767745
	v_div_scale_f32 v45, null, v30, v30, v12                   // 000000DBABC0: D6FC7C2D 04323D1E
	v_div_scale_f32 v46, s6, v12, v30, v12                     // 000000DBABC8: D6FC062E 04323D0C
	v_dual_mul_f32 v64, v42, v54 :: v_dual_mul_f32 v69, v61, v59// 000000DBABD0: C8C66D2A 4044773D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DBABD8: BF870313
	v_rcp_f32_e32 v56, v45                                     // 000000DBABDC: 7E70552D
	v_add_f32_e32 v33, 1.0, v33                                // 000000DBABE0: 064242F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DBABE4: BF870232
	v_fma_f32 v72, -v41, v64, v42                              // 000000DBABE8: D6130048 24AA8129
	v_mul_f32_e32 v29, 0xbfb8aa3b, v8                          // 000000DBABF0: 103A10FF BFB8AA3B
	v_fma_f32 v77, -v51, v69, v61                              // 000000DBABF8: D613004D 24F68B33
	v_div_scale_f32 v47, null, v33, v33, v5                    // 000000DBAC00: D6FC7C2F 04164321
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBAC08: BF870214
	v_fmac_f32_e32 v64, v72, v54                               // 000000DBAC0C: 56806D48
	v_exp_f32_e32 v29, v29                                     // 000000DBAC10: 7E3A4B1D
	v_div_scale_f32 v48, s7, v5, v33, v5                       // 000000DBAC14: D6FC0730 04164305
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000DBAC1C: BF870136
	v_fma_f32 v66, -v45, v56, 1.0                              // 000000DBAC20: D6130042 23CA712D
	v_mul_f32_e32 v37, 0x3db504f3, v37                         // 000000DBAC28: 104A4AFF 3DB504F3
	v_rcp_f32_e32 v57, v47                                     // 000000DBAC30: 7E72552F
	v_dual_fmac_f32 v69, v77, v59 :: v_dual_fmac_f32 v56, v66, v56// 000000DBAC34: C800774D 45387142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DBAC3C: BF8701A2
	v_fma_mix_f32 v19, v19, v37, neg(0) op_sel_hi:[1,0,0]      // 000000DBAC40: CC200013 8A024B13
	v_mul_f32_e32 v39, 0xbfb8aa3b, v24                         // 000000DBAC48: 104E30FF BFB8AA3B
	v_mul_f32_e32 v66, v46, v56                                // 000000DBAC50: 1084712E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DBAC54: BF870312
	v_exp_f32_e32 v39, v39                                     // 000000DBAC58: 7E4E4B27
	v_fma_f32 v67, -v47, v57, 1.0                              // 000000DBAC5C: D6130043 23CA732F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DBAC64: BF870122
	v_fma_f32 v74, -v45, v66, v46                              // 000000DBAC68: D613004A 24BA852D
	v_mul_f32_e32 v31, 0xbfb8aa3b, v11                         // 000000DBAC70: 103E16FF BFB8AA3B
	v_dual_fmac_f32 v57, v67, v57 :: v_dual_fmac_f32 v66, v74, v56// 000000DBAC78: C8007343 3942714A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000DBAC80: BF870312
	v_exp_f32_e32 v31, v31                                     // 000000DBAC84: 7E3E4B1F
	v_add_f32_e32 v35, 1.0, v39                                // 000000DBAC88: 06464EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DBAC8C: BF870112
	v_mul_f32_e32 v67, v48, v57                                // 000000DBAC90: 10867330
	v_div_scale_f32 v52, null, v35, v35, v24                   // 000000DBAC94: D6FC7C34 04624723
	v_div_scale_f32 v62, s10, v24, v35, v24                    // 000000DBAC9C: D6FC0A3E 04624718
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000DBACA4: BF870293
	v_fma_f32 v75, -v47, v67, v48                              // 000000DBACA8: D613004B 24C2872F
	v_add_f32_e32 v31, 1.0, v31                                // 000000DBACB0: 063E3EF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DBACB4: BF870114
	v_rcp_f32_e32 v60, v52                                     // 000000DBACB8: 7E785534
	v_fmac_f32_e32 v67, v75, v57                               // 000000DBACBC: 5686734B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DBACC0: BF870122
	v_div_scale_f32 v43, null, v31, v31, v11                   // 000000DBACC4: D6FC7C2B 042E3F1F
	v_div_scale_f32 v44, s5, v11, v31, v11                     // 000000DBACCC: D6FC052C 042E3F0B
	v_rcp_f32_e32 v55, v43                                     // 000000DBACD4: 7E6E552B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBACD8: BF870096
	v_fma_f32 v70, -v52, v60, 1.0                              // 000000DBACDC: D6130046 23CA7934
	v_fmac_f32_e32 v60, v70, v60                               // 000000DBACE4: 56787946
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBACE8: BF870095
	v_fma_f32 v65, -v43, v55, 1.0                              // 000000DBACEC: D6130041 23CA6F2B
	v_dual_mul_f32 v70, v62, v60 :: v_dual_fmac_f32 v55, v65, v55// 000000DBACF4: C8C0793E 46366F41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000DBACFC: BF870121
	v_fma_f32 v78, -v52, v70, v62                              // 000000DBAD00: D613004E 24FA8D34
	v_add_f32_e32 v29, 1.0, v29                                // 000000DBAD08: 063A3AF2
	v_dual_mul_f32 v65, v44, v55 :: v_dual_fmac_f32 v70, v78, v60// 000000DBAD0C: C8C06F2C 4146794E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DBAD14: BF8701A2
	v_div_scale_f32 v39, null, v29, v29, v8                    // 000000DBAD18: D6FC7C27 04223B1D
	v_div_scale_f32 v40, vcc_lo, v8, v29, v8                   // 000000DBAD20: D6FC6A28 04223B08
	v_fma_f32 v73, -v43, v65, v44                              // 000000DBAD28: D6130049 24B2832B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBAD30: BF870093
	v_rcp_f32_e32 v53, v39                                     // 000000DBAD34: 7E6A5527
	v_fmac_f32_e32 v65, v73, v55                               // 000000DBAD38: 56826F49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBAD3C: BF870095
	v_fma_f32 v63, -v39, v53, 1.0                              // 000000DBAD40: D613003F 23CA6B27
	v_fmac_f32_e32 v53, v63, v53                               // 000000DBAD48: 566A6B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBAD4C: BF870091
	v_mul_f32_e32 v63, v40, v53                                // 000000DBAD50: 107E6B28
	v_fma_f32 v71, -v39, v63, v40                              // 000000DBAD54: D6130047 24A27F27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000DBAD5C: BF870091
	v_fmac_f32_e32 v63, v71, v53                               // 000000DBAD60: 567E6B47
	v_fma_f32 v39, -v39, v63, v40                              // 000000DBAD64: D6130027 24A27F27
	v_fma_f32 v40, -v41, v64, v42                              // 000000DBAD6C: D6130028 24AA8129
	v_fma_f32 v41, -v43, v65, v44                              // 000000DBAD74: D6130029 24B2832B
	v_fma_f32 v42, -v45, v66, v46                              // 000000DBAD7C: D613002A 24BA852D
	v_fma_f32 v43, -v47, v67, v48                              // 000000DBAD84: D613002B 24C2872F
	v_div_fmas_f32 v39, v39, v53, v63                          // 000000DBAD8C: D6370027 04FE6B27
	s_mov_b32 vcc_lo, s4                                       // 000000DBAD94: BEEA0004
	v_fma_f32 v44, -v49, v68, v50                              // 000000DBAD98: D613002C 24CA8931
	v_div_fmas_f32 v40, v40, v54, v64                          // 000000DBADA0: D6370028 05026D28
	s_mov_b32 vcc_lo, s5                                       // 000000DBADA8: BEEA0005
	v_div_fixup_f32 v8, v39, v29, v8                           // 000000DBADAC: D6270008 04223B27
	v_div_fmas_f32 v41, v41, v55, v65                          // 000000DBADB4: D6370029 05066F29
	s_mov_b32 vcc_lo, s6                                       // 000000DBADBC: BEEA0006
	v_div_fixup_f32 v9, v40, v26, v9                           // 000000DBADC0: D6270009 04263528
	v_div_fmas_f32 v29, v42, v56, v66                          // 000000DBADC8: D637001D 050A712A
	s_mov_b32 vcc_lo, s7                                       // 000000DBADD0: BEEA0007
	v_fma_f32 v45, -v51, v69, v61                              // 000000DBADD4: D613002D 24F68B33
	v_div_fmas_f32 v26, v43, v57, v67                          // 000000DBADDC: D637001A 050E732B
	v_mul_f32_e32 v9, v10, v9                                  // 000000DBADE4: 1012130A
	s_mov_b32 vcc_lo, s8                                       // 000000DBADE8: BEEA0008
	v_mul_f32_e32 v7, v7, v8                                   // 000000DBADEC: 100E1107
	v_div_fixup_f32 v8, v29, v30, v12                          // 000000DBADF0: D6270008 04323D1D
	v_fma_f32 v12, -v52, v70, v62                              // 000000DBADF8: D613000C 24FA8D34
	v_div_fmas_f32 v10, v44, v58, v68                          // 000000DBAE00: D637000A 0512752C
	s_mov_b32 vcc_lo, s9                                       // 000000DBAE08: BEEA0009
	s_waitcnt vmcnt(6)                                         // 000000DBAE0C: BF891BF7
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 000000DBAE10: CC200009 8A021315
	v_div_fmas_f32 v21, v45, v59, v69                          // 000000DBAE18: D6370015 0516772D
	s_mov_b32 vcc_lo, s10                                      // 000000DBAE20: BEEA000A
	v_div_fixup_f32 v10, v10, v32, v22                         // 000000DBAE24: D627000A 045A410A
	v_div_fmas_f32 v12, v12, v60, v70                          // 000000DBAE2C: D637000C 051A790C
	v_mul_f32_e32 v8, v28, v8                                  // 000000DBAE34: 1010111C
	v_div_fixup_f32 v11, v41, v31, v11                         // 000000DBAE38: D627000B 042E3F29
	v_cmp_gt_i32_e32 vcc_lo, s23, v6                           // 000000DBAE40: 7C880C17
	v_mul_f32_e32 v10, v19, v10                                // 000000DBAE44: 10141513
	v_div_fixup_f32 v12, v12, v35, v24                         // 000000DBAE48: D627000C 0462470C
	v_div_fixup_f32 v19, v21, v34, v23                         // 000000DBAE50: D6270013 045E4515
	v_mul_f32_e32 v11, v27, v11                                // 000000DBAE58: 1016171B
	s_waitcnt vmcnt(4)                                         // 000000DBAE5C: BF8913F7
	v_fma_mix_f32 v8, v16, v8, neg(0) op_sel_hi:[1,0,0]        // 000000DBAE60: CC200008 8A021110
	s_waitcnt vmcnt(2)                                         // 000000DBAE68: BF890BF7
	v_fma_mix_f32 v10, v18, v10, neg(0) op_sel_hi:[1,0,0]      // 000000DBAE6C: CC20000A 8A021512
	v_mul_f32_e32 v12, v20, v12                                // 000000DBAE74: 10181914
	v_div_fixup_f32 v5, v26, v33, v5                           // 000000DBAE78: D6270005 0416431A
	v_mul_f32_e32 v15, v15, v19                                // 000000DBAE80: 101E270F
	v_fma_mix_f32 v16, v11, v14, v8 op_sel_hi:[0,1,0]          // 000000DBAE84: CC200010 14221D0B
	v_fma_mix_f32 v8, v11, v14, -v8 op_sel_hi:[0,1,0]          // 000000DBAE8C: CC200008 94221D0B
	s_waitcnt vmcnt(0)                                         // 000000DBAE94: BF8903F7
	v_fma_mix_f32 v4, v4, v12, neg(0) op_sel_hi:[1,0,0]        // 000000DBAE98: CC200004 8A021904
	v_mul_f32_e32 v5, v17, v5                                  // 000000DBAEA0: 100A0B11
	v_fma_mix_f32 v12, v7, v13, v9 op_sel_hi:[0,1,0]           // 000000DBAEA4: CC20000C 14261B07
	v_fma_mix_f32 v7, v7, v13, -v9 op_sel_hi:[0,1,0]           // 000000DBAEAC: CC200007 94261B07
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBAEB4: BF870214
	v_fma_mix_f32 v18, v15, v3, v4 op_sel_hi:[0,1,0]           // 000000DBAEB8: CC200012 1412070F
	v_fma_mix_f32 v17, v5, v2, v10 op_sel_hi:[0,1,0]           // 000000DBAEC0: CC200011 142A0505
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000DBAEC8: BF870234
	v_add_f32_e32 v19, v12, v16                                // 000000DBAECC: 0626210C
	v_fma_mix_f32 v2, v5, v2, -v10 op_sel_hi:[0,1,0]           // 000000DBAED0: CC200002 942A0505
	v_fma_mix_f32 v3, v15, v3, -v4 op_sel_hi:[0,1,0]           // 000000DBAED8: CC200003 9412070F
	v_dual_add_f32 v5, v7, v8 :: v_dual_add_f32 v20, v17, v18  // 000000DBAEE0: C9081107 05142511
	v_sub_f32_e32 v7, v7, v8                                   // 000000DBAEE8: 080E1107
	v_sub_f32_e32 v4, v12, v16                                 // 000000DBAEEC: 0808210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000DBAEF0: BF870214
	v_dual_add_f32 v8, v2, v3 :: v_dual_sub_f32 v11, v17, v18  // 000000DBAEF4: C90A0702 080A2511
	v_dual_add_f32 v9, v19, v20 :: v_dual_sub_f32 v2, v2, v3   // 000000DBAEFC: C90A2913 09020702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000DBAF04: BF870112
	v_sub_f32_e32 v12, v5, v8                                  // 000000DBAF08: 08181105
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAF0C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DBAF14: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000DBAF1C: BF870241
	v_add_f32_e32 v3, v9, v10                                  // 000000DBAF20: 06061509
	v_dual_add_f32 v10, v5, v8 :: v_dual_add_f32 v5, v4, v11   // 000000DBAF24: C9081105 0A041704
	v_sub_f32_e32 v11, v4, v11                                 // 000000DBAF2C: 08161704
	v_sub_f32_e32 v9, v19, v20                                 // 000000DBAF30: 08122913
	v_mov_b32_dpp v8, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBAF34: 7E1002FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DBAF3C: D5010003 20060703
	v_mov_b32_dpp v13, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAF44: 7E1A02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000DBAF4C: D501000A 2002150A
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAF54: 7E1C02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000DBAF5C: D5010005 20020B05
	v_add_f32_e32 v3, v3, v8                                   // 000000DBAF64: 06061103
	v_add_f32_e32 v8, v7, v2                                   // 000000DBAF68: 06100507
	v_add_f32_e32 v4, v10, v13                                 // 000000DBAF6C: 06081B0A
	v_mov_b32_dpp v17, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAF70: 7E2202FA FF01610B
	v_add_f32_e32 v5, v5, v14                                  // 000000DBAF78: 060A1D05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBAF7C: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000DBAF84: D5010003 200A0703
	v_mov_b32_dpp v13, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBAF8C: 7E1A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000DBAF94: D5010004 20060904
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAF9C: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000DBAFA4: D5010008 20021108
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBAFAC: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000DBAFB4: D5010005 20060B05
	v_dual_add_f32 v4, v4, v13 :: v_dual_sub_f32 v13, v7, v2   // 000000DBAFBC: C90A1B04 040C0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000DBAFC4: BF870194
	v_dual_add_f32 v2, v3, v10 :: v_dual_add_f32 v3, v8, v15   // 000000DBAFC8: C9081503 02021F08
	v_add_f32_e32 v5, v5, v14                                  // 000000DBAFD0: 060A1D05
	v_mov_b32_dpp v14, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAFD4: 7E1C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000DBAFDC: D5010009 20021309
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000DBAFE4: D501000B 2002170B
	v_mov_b32_dpp v10, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBAFEC: 7E1402FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000DBAFF4: D5010003 20060703
	v_mov_b32_dpp v18, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBAFFC: 7E2402FA FF01610D
	v_add_f32_e32 v9, v9, v14                                  // 000000DBB004: 06121D09
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000DBB008: D501000D 20021B0D
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB010: 7E0E02FA FF016404
	v_add_f32_e32 v10, v3, v10                                 // 000000DBB018: 06141503
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000DBB01C: D5010004 200A0904
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBB024: 7E1E02FA FF016209
	v_cndmask_b32_e64 v16, -v9, v9, s1                         // 000000DBB02C: D5010010 20061309
	v_mov_b32_dpp v9, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000DBB034: 7E1202FA FF01610C
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB03C: 7E1C02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000DBB044: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000DBB04C: D501000C 2002190C
	v_add_f32_e32 v13, v13, v18                                // 000000DBB054: 061A250D
	v_mov_b32_dpp v8, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB058: 7E1002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000DBB060: D5010005 200A0B05
	v_add_f32_e32 v4, v4, v7                                   // 000000DBB068: 06080F04
	v_dual_add_f32 v12, v12, v9 :: v_dual_add_f32 v9, v10, v14 // 000000DBB06C: C908130C 0C081D0A
	v_dual_add_f32 v10, v11, v17 :: v_dual_add_f32 v11, v16, v15// 000000DBB074: C908230B 0A0A1F10
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBB07C: 7E2002FA FF01620D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DBB084: BF870223
	v_mov_b32_dpp v14, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBB088: 7E1C02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000DBB090: D501000C 2006190C
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000DBB098: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000DBB0A0: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000DBB0A8: D501000D 20061B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000DBB0B0: BF8701A4
	v_dual_add_f32 v7, v5, v8 :: v_dual_add_f32 v12, v12, v14  // 000000DBB0B4: C9081105 070C1D0C
	v_mov_b32_dpp v14, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB0BC: 7E1C02FA FF01640B
	v_dual_add_f32 v10, v10, v15 :: v_dual_add_f32 v13, v13, v16// 000000DBB0C4: C9081F0A 0A0C210D
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000DBB0CC: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DBB0D4: BF870224
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB0D8: 7E1E02FA FF01640C
	v_cndmask_b32_e64 v16, -v12, v12, s2                       // 000000DBB0E0: D5010010 200A190C
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB0E8: 7E2202FA FF01640A
	v_cndmask_b32_e64 v18, -v10, v10, s2                       // 000000DBB0F0: D5010012 200A150A
	v_mov_b32_dpp v19, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000DBB0F8: 7E2602FA FF01640D
	v_cndmask_b32_e64 v20, -v13, v13, s2                       // 000000DBB100: D5010014 200A1B0D
	v_dual_add_f32 v12, v11, v14 :: v_dual_add_f32 v13, v16, v15// 000000DBB108: C9081D0B 0C0C1F10
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000DBB110: BF870224
	v_add_f32_e32 v15, v18, v17                                // 000000DBB114: 061E2312
	v_mov_b32_dpp v3, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB118: 7E0602FA FF016802
	v_add_f32_e32 v17, v20, v19                                // 000000DBB120: 06222714
	v_mov_b32_dpp v5, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB124: 7E0A02FA FF016804
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB12C: 7E1002FA FF016807
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB134: 7E1402FA FF016809
	v_mov_b32_dpp v11, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB13C: 7E1602FA FF01680C
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB144: 7E1C02FA FF01680D
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB14C: 7E2002FA FF01680F
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000DBB154: 7E2402FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000DBB15C: 8B7E6A7E
	s_cbranch_execz 62                                         // 000000DBB160: BFA5003E <_ZN7halogen12_GLOBAL__N_111k_ht_moe_guILi4ELi8ELi8EEEvPKjPKDF16_PKNS0_6HtItemEPKiS5_S5_PDF16_+0x865c>
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000DBB164: D5010011 200E2311
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000DBB16C: D5010002 200E0502
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000DBB174: D5010004 200E0904
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000DBB17C: D5010007 200E0F07
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000DBB184: D5010009 200E1309
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000DBB18C: D501000C 200E190C
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000DBB194: D501000F 200E1F0F
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000DBB19C: D501000D 200E1B0D
	v_dual_add_f32 v17, v17, v18 :: v_dual_add_f32 v2, v2, v3  // 000000DBB1A4: C9082511 11020702
	v_add_f32_e32 v3, v4, v5                                   // 000000DBB1AC: 06060B04
	v_add_f32_e32 v7, v7, v8                                   // 000000DBB1B0: 060E1107
	v_mad_i64_i32 v[4:5], null, 0x500, v6, v[0:1]              // 000000DBB1B4: D6FF7C04 04020CFF 00000500
	v_add_f32_e32 v9, v9, v10                                  // 000000DBB1C0: 06121509
	s_mov_b32 s0, 0x3db504f3                                   // 000000DBB1C4: BE8000FF 3DB504F3
	v_add_f32_e32 v11, v12, v11                                // 000000DBB1CC: 0616170C
	v_add_f32_e32 v15, v15, v16                                // 000000DBB1D0: 061E210F
	v_add_f32_e32 v13, v13, v14                                // 000000DBB1D4: 061A1D0D
	v_fma_mixlo_f16 v0, v2, s0, 0                              // 000000DBB1D8: CC210000 02000102
	v_fma_mixhi_f16 v0, v3, s0, 0                              // 000000DBB1E0: CC220000 02000103
	v_fma_mixlo_f16 v1, v7, s0, 0                              // 000000DBB1E8: CC210001 02000107
	v_fma_mixhi_f16 v1, v9, s0, 0                              // 000000DBB1F0: CC220001 02000109
	v_fma_mixlo_f16 v2, v11, s0, 0                             // 000000DBB1F8: CC210002 0200010B
	v_fma_mixhi_f16 v2, v13, s0, 0                             // 000000DBB200: CC220002 0200010D
	v_fma_mixlo_f16 v3, v15, s0, 0                             // 000000DBB208: CC210003 0200010F
	v_fma_mixhi_f16 v3, v17, s0, 0                             // 000000DBB210: CC220003 02000111
	s_clause 0x7                                               // 000000DBB218: BF850007
	global_store_b16 v[4:5], v0, off                           // 000000DBB21C: DC660000 007C0004
	global_store_d16_hi_b16 v[4:5], v0, off offset:32          // 000000DBB224: DC960020 007C0004
	global_store_b16 v[4:5], v1, off offset:64                 // 000000DBB22C: DC660040 007C0104
	global_store_d16_hi_b16 v[4:5], v1, off offset:96          // 000000DBB234: DC960060 007C0104
	global_store_b16 v[4:5], v2, off offset:128                // 000000DBB23C: DC660080 007C0204
	global_store_d16_hi_b16 v[4:5], v2, off offset:160         // 000000DBB244: DC9600A0 007C0204
	global_store_b16 v[4:5], v3, off offset:192                // 000000DBB24C: DC6600C0 007C0304
	global_store_d16_hi_b16 v[4:5], v3, off offset:224         // 000000DBB254: DC9600E0 007C0304
	s_nop 0                                                    // 000000DBB25C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000DBB260: BFB60003
	s_endpgm                                                   // 000000DBB264: BFB00000
		...

