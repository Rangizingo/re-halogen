0000000000810d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000810D00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 000000810D08: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000810D10: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000810D14: 86039F02
	v_mov_b32_e32 v16, 0                                       // 000000810D18: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000810D1C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000810D20: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 000000810D24: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000810D2C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 000000810D30: 38100200
	.long 0x7f183880                                           // 000000810D34: 7F183880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 000000810D38: CA100080 05060080
	s_waitcnt lgkmcnt(0)                                       // 000000810D40: BF89FC07
	s_clause 0x1                                               // 000000810D44: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 000000810D48: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 000000810D50: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000810D58: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 000000810D5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000810D60: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000810D64: 85009F0B
	v_mov_b32_e32 v25, 0                                       // 000000810D68: 7E320280
	s_add_u32 s14, s10, s0                                     // 000000810D6C: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000810D70: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000810D74: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 000000810D7C: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000810D80: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000810D84: 8680810E
	.long 0xd72c000d                                           // 000000810D88: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000810D8C: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000810D90: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000810D98: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 000000810D9C: 0200030A
	.long 0xd72c0013                                           // 000000810DA0: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000810DA4: 0200010E
	.long 0xd72c000e                                           // 000000810DA8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000810DAC: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 000000810DB0: 850E9B14
	s_waitcnt vmcnt(1)                                         // 000000810DB4: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 000000810DB8: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 000000810DC0: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 000000810DC4: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2)                            // 000000810DCC: BF870002
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000810DD0: D6550007 03FE1707 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 000000810DDC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000810DE4: 80020E0A
	v_add3_u32 v3, v3, v18, 0x7fff                             // 000000810DE8: D6550003 03FE2503 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000810DF4: 8203800B
	.long 0x7e183987                                           // 000000810DF8: 7E183987
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000810DFC: 85828502
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v18, 2, v0      // 000000810E00: CA220080 07120082
	.long 0xd4440000                                           // 000000810E08: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000810E0C: 02021E02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000810E10: BF870003
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 000000810E14: D6570003 043206FF FFFF0000
	v_add3_u32 v17, v19, v11, v17                              // 000000810E20: D6550011 04461713
	v_add3_u32 v0, v2, v14, v13                                // 000000810E28: D6550000 04361D02
	ds_store_b32 v18, v3                                       // 000000810E30: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 000000810E38: BF89FC07
	s_barrier                                                  // 000000810E3C: BFBD0000
	buffer_gl0_inv                                             // 000000810E40: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000810E48: BE832000
	s_cbranch_execz 26                                         // 000000810E4C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s1, s4, s16                                      // 000000810E50: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000810E54: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000810E58: 30041E81
	.long 0xd7000103                                           // 000000810E5C: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000810E60: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810E64: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000810E68: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000810E70: 300A1E84
	.long 0xd7000102                                           // 000000810E74: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000810E78: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000810E7C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000810E80: D5207C03 00060880
	.long 0xd7000104                                           // 000000810E88: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000810E8C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000810E90: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000810E94: D5207C05 00062280
	s_clause 0x1                                               // 000000810E9C: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000810EA0: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000810EA8: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000810EB0: BF8907F7
	v_cvt_f32_f16_e32 v25, v2                                  // 000000810EB4: 7E321702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000810EB8: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000810EBC: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000810EC4: CA100080 14140080
	s_and_saveexec_b32 s3, s0                                  // 000000810ECC: BE832000
	s_cbranch_execz 478                                        // 000000810ED0: BFA501DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x94c>
	s_mul_i32 s0, s11, 6                                       // 000000810ED4: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000810ED8: 9681860A
	v_dual_mov_b32 v23, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 000000810EDC: CA22010F 17021E81
	s_add_i32 s18, s1, s0                                      // 000000810EE4: 81120001
	.long 0xd7000001                                           // 000000810EE8: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000810EEC: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810EF0: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000810EF4: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000810EFC: CA220080 0C0A1E85
	.long 0xd7000001                                           // 000000810F04: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000810F08: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810F0C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000810F10: D5207C00 00020080
	v_lshl_or_b32 v22, v15, 4, 0x100                           // 000000810F18: D6560016 03FD090F 00000100
	.long 0xd7000001                                           // 000000810F24: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000810F28: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000810F2C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000810F30: D5207C00 00020005
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v24, v25         // 000000810F38: CA10010C 15180119
	.long 0xd700000d                                           // 000000810F40: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 000000810F44: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000810F48: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000810F4C: D5207C0E 00020080
	v_mov_b32_e32 v20, v12                                     // 000000810F54: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000810F58: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000810F5C: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000810F60: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000810F64: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000810F68: 9611860A
	s_mov_b32 s16, 0                                           // 000000810F6C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000810F70: 8484810A
	s_branch 411                                               // 000000810F74: BFA0019B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x8e4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000810F78: 8C7E0A7E
	v_and_b32_e32 v26, 0xff, v4                                // 000000810F7C: 363408FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000810F84: 8B00007E
	v_add_nc_u32_e32 v22, 0x100, v22                           // 000000810F88: 4A2C2CFF 00000100
	s_or_b32 s16, s0, s16                                      // 000000810F90: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000810F94: BF8700B2
	v_lshlrev_b32_e32 v26, 2, v26                              // 000000810F98: 30343482
	ds_load_b32 v42, v26                                       // 000000810F9C: D8D80000 2A00001A
	v_lshrrev_b32_e32 v26, 6, v4                               // 000000810FA4: 32340886
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000810FA8: 363434FF 000003FC
	ds_load_b32 v43, v26                                       // 000000810FB0: D8D80000 2B00001A
	v_lshrrev_b32_e32 v26, 14, v4                              // 000000810FB8: 3234088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000810FBC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000810FC0: BF870112
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000810FC4: 363434FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000810FCC: 360808FF 000003FC
	ds_load_b32 v44, v26                                       // 000000810FD4: D8D80000 2C00001A
	ds_load_b32 v45, v4                                        // 000000810FDC: D8D80000 2D000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000810FE4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000810FEC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000810FF0: 30080882
	ds_load_b32 v46, v4                                        // 000000810FF4: D8D80000 2E000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000810FFC: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000811000: 360808FF 000003FC
	ds_load_b32 v47, v4                                        // 000000811008: D8D80000 2F000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000811010: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000811014: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000811018: 360808FF 000003FC
	ds_load_b32 v48, v4                                        // 000000811020: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000811028: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000081102C: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000811034: D8D80000 31000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000081103C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000811044: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000811048: 30080882
	ds_load_b32 v50, v4                                        // 00000081104C: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000811054: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000811058: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000811060: D8D80000 33000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000811068: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081106C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000811070: 360808FF 000003FC
	ds_load_b32 v52, v4                                        // 000000811078: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000811080: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000811084: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 00000081108C: D8D80000 35000004
	v_and_b32_e32 v4, 0xff, v7                                 // 000000811094: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000081109C: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008110A0: 30080882
	ds_load_b32 v54, v4                                        // 0000008110A4: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000008110AC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008110B0: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000008110B8: D8D80000 37000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000008110C0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008110C4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008110C8: 360808FF 000003FC
	ds_load_b32 v56, v4                                        // 0000008110D0: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000008110D8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008110DC: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000008110E4: D8D80000 39000004
	.long 0xd73c0004                                           // 0000008110EC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000008110F0: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 0000008110F4: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008110FC: BF870092
	.long 0xd7000026                                           // 000000811100: D7000026
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000811104: 02020806
	v_add_co_ci_u32_e64 v39, null, s7, v5, s0                  // 000000811108: D5207C27 00020A07
	s_clause 0x3                                               // 000000811110: BF850003
	global_load_b128 v[4:7], v[38:39], off                     // 000000811114: DC5E0000 047C0026
	global_load_b128 v[26:29], v[38:39], off offset:16         // 00000081111C: DC5E0010 1A7C0026
	global_load_b128 v[30:33], v[38:39], off offset:32         // 000000811124: DC5E0020 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:48         // 00000081112C: DC5E0030 227C0026
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000811134: BF890CF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000811138: CC1A4004 1A025504
	s_waitcnt lgkmcnt(14)                                      // 000000811140: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811144: BF8700A1
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000811148: CC1A4004 1C125705
	s_waitcnt lgkmcnt(13)                                      // 000000811150: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000811154: CC1A4004 1C125906
	s_waitcnt lgkmcnt(12)                                      // 00000081115C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811160: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000811164: CC1A4004 1C125B07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000081116C: BF8908B7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000811170: CC1A4004 1C125D1A
	s_waitcnt lgkmcnt(10)                                      // 000000811178: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081117C: BF8700A1
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000811180: CC1A4004 1C125F1B
	s_waitcnt lgkmcnt(9)                                       // 000000811188: BF89FC97
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000081118C: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(8)                                       // 000000811194: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811198: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000081119C: CC1A4004 1C12631D
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008111A4: BF890477
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008111A8: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(6)                                       // 0000008111B0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008111B4: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008111B8: CC1A4004 1C12671F
	s_waitcnt lgkmcnt(5)                                       // 0000008111C0: BF89FC57
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008111C4: CC1A4004 1C126920
	s_waitcnt lgkmcnt(4)                                       // 0000008111CC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008111D0: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008111D4: CC1A4004 1C126B21
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008111DC: BF890037
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008111E0: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000008111E8: D7000022
	v_cndmask_b32_e32 v0, v38, v4, vcc_lo                      // 0000008111EC: 02000926
	s_waitcnt lgkmcnt(2)                                       // 0000008111F0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008111F4: BF8701C2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008111F8: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s5, v39, s0                 // 000000811200: D5207C23 00024E05
	.long 0xd7000028                                           // 000000811208: D7000028
	v_cndmask_b32_e32 v0, v38, v14, vcc_lo                     // 00000081120C: 02001D26
	s_waitcnt lgkmcnt(1)                                       // 000000811210: BF89FC17
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000811214: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v41, null, s15, v39, s0                // 00000081121C: D5207C29 00024E0F
	s_waitcnt lgkmcnt(0)                                       // 000000811224: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811228: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000081122C: CC1A4004 1C127325
	v_fmac_f32_e32 v21, v25, v4                                // 000000811234: 562A0919
	s_clause 0x3                                               // 000000811238: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 00000081123C: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000811244: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000081124C: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000811254: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 00000081125C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000811260: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811268: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000081126C: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000811274: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081127C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000811280: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 000000811288: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000081128C: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811294: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000811298: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008112A0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008112A8: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008112AC: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 0000008112B4: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008112B8: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008112C0: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008112C4: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008112CC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008112D4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008112D8: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008112E0: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008112E4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008112EC: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008112F0: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008112F8: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811300: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000811304: CC1A4004 1C127325
	v_fmac_f32_e32 v20, v25, v4                                // 00000081130C: 56280919
	s_clause 0x3                                               // 000000811310: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000811314: DC5E0000 047C0028
	global_load_b128 v[26:29], v[40:41], off offset:16         // 00000081131C: DC5E0010 1A7C0028
	global_load_b128 v[30:33], v[40:41], off offset:32         // 000000811324: DC5E0020 1E7C0028
	global_load_b128 v[34:37], v[40:41], off offset:48         // 00000081132C: DC5E0030 227C0028
	s_waitcnt vmcnt(3)                                         // 000000811334: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000811338: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811340: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000811344: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 00000081134C: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811354: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000811358: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 000000811360: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000811364: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081136C: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000811370: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000811378: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811380: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000811384: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 00000081138C: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000811390: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811398: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000081139C: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008113A4: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008113AC: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008113B0: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008113B8: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008113BC: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000008113C4: D7000022
	v_cndmask_b32_e32 v0, v38, v17, vcc_lo                     // 0000008113C8: 02002326
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008113CC: BF870122
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008113D0: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s18, v39, s0                // 0000008113D8: D5207C23 00024E12
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008113E0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008113E8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008113EC: CC1A4004 1C127325
	v_fmac_f32_e32 v19, v25, v4                                // 0000008113F4: 56260919
	s_clause 0x3                                               // 0000008113F8: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 0000008113FC: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 000000811404: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 00000081140C: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 000000811414: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 00000081141C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000811420: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811428: BF870091
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 00000081142C: CC1A4004 1C125705
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000811434: CC1A4004 1C125906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081143C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000811440: CC1A4004 1C125B07
	s_waitcnt vmcnt(2)                                         // 000000811448: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 00000081144C: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811454: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 000000811458: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000811460: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811468: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 00000081146C: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 000000811474: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000811478: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811480: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000811484: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 00000081148C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811494: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000811498: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008114A0: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008114A4: CC1A4004 1C126D22
	.long 0xd7000022                                           // 0000008114AC: D7000022
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 0000008114B0: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008114B4: BF8701B2
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008114B8: CC1A4004 1C126F23
	v_add_co_ci_u32_e64 v35, null, s15, v41, s0                // 0000008114C0: D5207C23 0002520F
	.long 0xd700000d                                           // 0000008114C8: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 0000008114CC: 0201410D
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008114D0: CC1A4004 1C127124
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000008114D8: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008114E0: BF870092
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008114E4: CC1A4004 1C127325
	v_fmac_f32_e32 v18, v25, v4                                // 0000008114EC: 56240919
	s_clause 0x3                                               // 0000008114F0: BF850003
	global_load_b128 v[4:7], v[34:35], off                     // 0000008114F4: DC5E0000 047C0022
	global_load_b128 v[26:29], v[34:35], off offset:16         // 0000008114FC: DC5E0010 1A7C0022
	global_load_b128 v[30:33], v[34:35], off offset:32         // 000000811504: DC5E0020 1E7C0022
	global_load_b128 v[34:37], v[34:35], off offset:48         // 00000081150C: DC5E0030 227C0022
	s_waitcnt vmcnt(3)                                         // 000000811514: BF890FF7
	v_dot2_f32_bf16 v4, v4, v42, 0                             // 000000811518: CC1A4004 1A025504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000811520: BF870121
	v_dot2_f32_bf16 v4, v5, v43, v4                            // 000000811524: CC1A4004 1C125705
	v_mov_b32_e32 v5, v1                                       // 00000081152C: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v44, v4                            // 000000811530: CC1A4004 1C125906
	v_mov_b32_e32 v6, v2                                       // 000000811538: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000081153C: BF870132
	v_dot2_f32_bf16 v4, v7, v45, v4                            // 000000811540: CC1A4004 1C125B07
	v_mov_b32_e32 v7, v3                                       // 000000811548: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 00000081154C: BF890BF7
	v_dot2_f32_bf16 v4, v26, v46, v4                           // 000000811550: CC1A4004 1C125D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811558: BF870091
	v_dot2_f32_bf16 v4, v27, v47, v4                           // 00000081155C: CC1A4004 1C125F1B
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000811564: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081156C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000811570: CC1A4004 1C12631D
	s_waitcnt vmcnt(1)                                         // 000000811578: BF8907F7
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000081157C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811584: BF870091
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000811588: CC1A4004 1C12671F
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000811590: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000811598: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000081159C: CC1A4004 1C126B21
	s_waitcnt vmcnt(0)                                         // 0000008115A4: BF8903F7
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008115A8: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008115B0: BF870091
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008115B4: CC1A4004 1C126F23
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008115BC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008115C4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008115C8: CC1A4004 1C127325
	v_fmac_f32_e32 v16, v25, v4                                // 0000008115D0: 56200919
	v_mov_b32_e32 v4, v0                                       // 0000008115D4: 7E080300
	v_mov_b32_e32 v25, v24                                     // 0000008115D8: 7E320318
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008115DC: 917E107E
	s_cbranch_execz 25                                         // 0000008115E0: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x948>
	s_waitcnt vmcnt(0)                                         // 0000008115E4: BF8903F7
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v23, 16, v23    // 0000008115E8: CA200104 00162E90
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000008115F0: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000008115F8: 7E060307
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008115FC: BF870003
	.long 0xd4430000                                           // 000000811600: D4430000
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000811604: 02022E02
	s_mov_b32 s10, exec_lo                                     // 000000811608: BE8A007E
	.long 0xd4c4007e                                           // 00000081160C: D4C4007E
	v_cndmask_b32_e32 v1, s2, v23, vcc_lo                      // 000000811610: 02022E02
	s_cbranch_execz 65112                                      // 000000811614: BFA5FE58 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x278>
	.long 0xd7000100                                           // 000000811618: D7000100
	v_cndmask_b32_e32 v1, v10, v22, vcc_lo                     // 00000081161C: 02022D0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000811620: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000811624: D5207C01 00062280
	global_load_d16_b16 v24, v[13:14], off                     // 00000081162C: DC820000 187C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000811634: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 00000081163C: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 000000811640: 7E301718
	s_branch 65100                                             // 000000811644: BFA0FE4C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x278>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000811648: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000081164C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000811650: 8C7E037E
	.long 0xd71f0000                                           // 000000811654: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000811658: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000081165C: 3A020088
	s_waitcnt vmcnt(0)                                         // 000000811660: BF8903F7
	v_xor_b32_e32 v6, 4, v0                                    // 000000811664: 3A0C0084
	v_xor_b32_e32 v13, 2, v0                                   // 000000811668: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000081166C: BF870093
	.long 0xd44c0000                                           // 000000811670: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000811674: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000811678: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811680: BF870114
	.long 0xd44c0000                                           // 000000811684: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 000000811688: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000081168C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000811690: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 000000811694: D5010006 00020D00
	.long 0xd44c0000                                           // 00000081169C: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 0000008116A0: 02021AA0
	ds_bpermute_b32 v2, v1, v21                                // 0000008116A4: DACC0000 02001501
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 0000008116AC: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 0000008116B4: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000008116B8: 06040515
	ds_bpermute_b32 v3, v1, v20                                // 0000008116BC: DACC0000 03001401
	ds_bpermute_b32 v4, v1, v19                                // 0000008116C4: DACC0000 04001301
	ds_bpermute_b32 v5, v1, v18                                // 0000008116CC: DACC0000 05001201
	ds_bpermute_b32 v1, v1, v16                                // 0000008116D4: DACC0000 01001001
	s_waitcnt lgkmcnt(3)                                       // 0000008116DC: BF89FC37
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000008116E0: C9220714 03060C82
	ds_bpermute_b32 v7, v6, v2                                 // 0000008116E8: DACC0000 07000206
	s_waitcnt lgkmcnt(2)                                       // 0000008116F0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_add_f32 v5, v18, v5   // 0000008116F4: C9080913 04040B12
	s_waitcnt lgkmcnt(1)                                       // 0000008116FC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000811700: 06020310
	ds_bpermute_b32 v10, v6, v3                                // 000000811704: DACC0000 0A000306
	ds_bpermute_b32 v11, v6, v4                                // 00000081170C: DACC0000 0B000406
	ds_bpermute_b32 v12, v6, v5                                // 000000811714: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 00000081171C: BF89FC37
	v_dual_add_f32 v2, v2, v7 :: v_dual_lshlrev_b32 v13, 2, v13// 000000811720: C9220F02 020C1A82
	ds_bpermute_b32 v6, v6, v1                                 // 000000811728: DACC0000 06000106
	s_waitcnt lgkmcnt(0)                                       // 000000811730: BF89FC07
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v1, v1, v6    // 000000811734: C9081704 04000D01
	ds_bpermute_b32 v6, v13, v2                                // 00000081173C: DACC0000 0600020D
	v_add_f32_e32 v5, v5, v12                                  // 000000811744: 060A1905
	ds_bpermute_b32 v12, v13, v1                               // 000000811748: DACC0000 0C00010D
	v_add_f32_e32 v3, v3, v10                                  // 000000811750: 06061503
	ds_bpermute_b32 v10, v13, v4                               // 000000811754: DACC0000 0A00040D
	ds_bpermute_b32 v7, v13, v3                                // 00000081175C: DACC0000 0700030D
	s_waitcnt lgkmcnt(3)                                       // 000000811764: BF89FC37
	v_add_f32_e32 v2, v2, v6                                   // 000000811768: 06040D02
	ds_bpermute_b32 v11, v13, v5                               // 00000081176C: DACC0000 0B00050D
	v_xor_b32_e32 v13, 1, v0                                   // 000000811774: 3A1A0081
	s_waitcnt lgkmcnt(2)                                       // 000000811778: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 00000081177C: 06081504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811780: BF870092
	.long 0xd44c0000                                           // 000000811784: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 000000811788: 02021AA0
	v_cndmask_b32_e64 v0, v0, v13, s0                          // 00000081178C: D5010000 00021B00
	.long 0xd44a0000                                           // 000000811794: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000811798: 02021E80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000081179C: BF870002
	v_lshlrev_b32_e32 v13, 2, v0                               // 0000008117A0: 301A0082
	s_waitcnt lgkmcnt(1)                                       // 0000008117A4: BF89FC17
	v_dual_add_f32 v0, v1, v12 :: v_dual_add_f32 v3, v3, v7    // 0000008117A8: C9081901 00020F03
	s_and_b32 s0, s0, vcc_lo                                   // 0000008117B0: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000008117B4: BF89FC07
	v_add_f32_e32 v5, v5, v11                                  // 0000008117B8: 060A1705
	ds_bpermute_b32 v6, v13, v2                                // 0000008117BC: DACC0000 0600020D
	ds_bpermute_b32 v10, v13, v4                               // 0000008117C4: DACC0000 0A00040D
	ds_bpermute_b32 v7, v13, v3                                // 0000008117CC: DACC0000 0700030D
	ds_bpermute_b32 v1, v13, v0                                // 0000008117D4: DACC0000 0100000D
	ds_bpermute_b32 v11, v13, v5                               // 0000008117DC: DACC0000 0B00050D
	s_and_saveexec_b32 s1, s0                                  // 0000008117E4: BE812000
	s_cbranch_execz 252                                        // 0000008117E8: BFA500FC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xedc>
	s_waitcnt lgkmcnt(2)                                       // 0000008117EC: BF89FC27
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 0000008117F0: C9080D02 02020F03
	s_waitcnt lgkmcnt(0)                                       // 0000008117F8: BF89FC07
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 0000008117FC: C9081504 04041705
	.long 0x7f183880                                           // 000000811804: 7F183880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000811808: BF870223
	v_bfe_u32 v6, v2, 16, 1                                    // 00000081180C: D6100006 02052102
	v_bfe_u32 v7, v3, 16, 1                                    // 000000811814: D6100007 02052103
	v_bfe_u32 v10, v4, 16, 1                                   // 00000081181C: D610000A 02052104
	v_bfe_u32 v11, v5, 16, 1                                   // 000000811824: D610000B 02052105
	.long 0x7f22398c                                           // 00000081182C: 7F22398C
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000811830: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 00000081183C: D6550003 03FE0F03 00007FFF
	v_add3_u32 v4, v4, v10, 0x7fff                             // 000000811848: D6550004 03FE1504 00007FFF
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000811854: D6550005 03FE1705 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000811860: BF870214
	v_dual_add_f32 v0, v0, v1 :: v_dual_and_b32 v1, 0xffff0000, v2// 000000811864: C9240300 000004FF FFFF0000
	v_and_b32_e32 v2, 0xffff0000, v3                           // 000000811870: 360406FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000811878: BF870214
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000081187C: 360608FF FFFF0000
	v_and_b32_e32 v4, 0xffff0000, v5                           // 000000811884: 36080AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000081188C: BF870134
	v_bfe_u32 v5, v0, 16, 1                                    // 000000811890: D6100005 02052100
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000811898: 100202FF BFB8AA3B
	s_lshl_b64 s[4:5], s[12:13], 1                             // 0000008118A0: 8484810C
	v_add3_u32 v0, v0, v5, 0x7fff                              // 0000008118A4: D6550000 03FE0B00 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008118B0: BF870092
	v_exp_f32_e32 v5, v1                                       // 0000008118B4: 7E0A4B01
	v_and_b32_e32 v6, 0xffff0000, v0                           // 0000008118B8: 360C00FF FFFF0000
	.long 0xd73c0000                                           // 0000008118C0: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000008118C4: 02021081
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008118C8: BF870095
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_mul_f32 v2, 0xbfb8aa3b, v2// 0000008118CC: C9060AF2 050204FF BFB8AA3B
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000008118D8: D6FC6A13 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008118E0: BF870292
	v_exp_f32_e32 v2, v2                                       // 0000008118E4: 7E044B02
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000008118E8: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008118F4: BF870111
	v_div_scale_f32 v20, s0, 1.0, v2, 1.0                      // 0000008118F8: D6FC0014 03CA04F2
	v_exp_f32_e32 v3, v3                                       // 000000811900: 7E064B03
	v_div_scale_f32 v9, null, v2, v2, 1.0                      // 000000811904: D6FC7C09 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000081190C: BF870311
	v_rcp_f32_e32 v14, v9                                      // 000000811910: 7E1C5509
	v_dual_add_f32 v7, 1.0, v3 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 000000811914: C90606F2 070408FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811920: BF870111
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 000000811924: D6FC7C0A 03CA0F07
	v_exp_f32_e32 v4, v4                                       // 00000081192C: 7E084B04
	v_div_scale_f32 v21, s1, 1.0, v7, 1.0                      // 000000811930: D6FC0115 03CA0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000811938: BF870292
	v_rcp_f32_e32 v15, v10                                     // 00000081193C: 7E1E550A
	v_fma_f32 v22, -v10, v15, 1.0                              // 000000811940: D6130016 23CA1F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811948: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_fmac_f32 v15, v22, v15// 00000081194C: C8C00CFF 060E1F16 BFB8AA3B
	v_exp_f32_e32 v3, v6                                       // 000000811958: 7E064B06
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 00000081195C: D6FC7C06 03CA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000811964: BF870311
	v_rcp_f32_e32 v13, v6                                      // 000000811968: 7E1A5506
	v_add_f32_e32 v18, 1.0, v3                                 // 00000081196C: 062406F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811970: BF870095
	v_fma_f32 v3, -v6, v13, 1.0                                // 000000811974: D6130003 23CA1B06
	v_dual_fmac_f32 v13, v3, v13 :: v_dual_add_f32 v8, 1.0, v4 // 00000081197C: C8081B03 0D0808F2
	v_fma_f32 v4, -v9, v14, 1.0                                // 000000811984: D6130004 23CA1D09
	.long 0xd7000303                                           // 00000081198C: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000811990: 02020008
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000811994: BF870093
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 000000811998: D6FC7C0B 03CA1108
	v_rcp_f32_e32 v16, v11                                     // 0000008119A0: 7E20550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008119A4: BF870095
	v_fma_f32 v23, -v11, v16, 1.0                              // 0000008119A8: D6130017 23CA210B
	v_fmac_f32_e32 v16, v23, v16                               // 0000008119B0: 56202117
	v_mul_f32_e32 v23, v19, v13                                // 0000008119B4: 102E1B13
	v_div_scale_f32 v24, s2, 1.0, v8, 1.0                      // 0000008119B8: D6FC0218 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008119C0: BF8701B2
	v_fma_f32 v29, -v6, v23, v19                               // 0000008119C4: D613001D 244E2F06
	v_fmac_f32_e32 v14, v4, v14                                // 0000008119CC: 561C1D04
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 0000008119D0: D5207C04 000E0209
	v_fmac_f32_e32 v23, v29, v13                               // 0000008119D8: 562E1B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008119DC: BF8701A3
	v_mul_f32_e32 v25, v20, v14                                // 0000008119E0: 10321D14
	v_div_scale_f32 v22, null, v18, v18, 1.0                   // 0000008119E4: D6FC7C16 03CA2512
	v_fma_f32 v1, -v6, v23, v19                                // 0000008119EC: D6130001 244E2F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008119F4: BF870193
	v_fma_f32 v30, -v9, v25, v20                               // 0000008119F8: D613001E 24523309
	v_rcp_f32_e32 v28, v22                                     // 000000811A00: 7E385516
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811A04: BF870112
	v_div_fmas_f32 v1, v1, v13, v23                            // 000000811A08: D6370001 045E1B01
	v_dual_fmac_f32 v25, v30, v14 :: v_dual_mul_f32 v26, v21, v15// 000000811A10: C8061D1E 191A1F15
	v_mul_f32_e32 v27, v24, v16                                // 000000811A18: 10362118
	s_mov_b32 vcc_lo, s0                                       // 000000811A1C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000811A20: BF870193
	v_div_fixup_f32 v1, v1, v5, 1.0                            // 000000811A24: D6270001 03CA0B01
	v_fma_f32 v6, -v9, v25, v20                                // 000000811A2C: D6130006 24523309
	v_fma_f32 v31, -v10, v26, v21                              // 000000811A34: D613001F 2456350A
	v_fma_f32 v32, -v11, v27, v24                              // 000000811A3C: D6130020 2462370B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000811A44: BF870235
	v_fma_f32 v0, -v22, v28, 1.0                               // 000000811A48: D6130000 23CA3916
	.long 0x7e223981                                           // 000000811A50: 7E223981
	v_div_fmas_f32 v6, v6, v14, v25                            // 000000811A54: D6370006 04661D06
	v_dual_fmac_f32 v26, v31, v15 :: v_dual_fmac_f32 v27, v32, v16// 000000811A5C: C8001F1F 1A1A2120
	s_mov_b32 vcc_lo, s1                                       // 000000811A64: BEEA0001
	v_fmac_f32_e32 v28, v0, v28                                // 000000811A68: 56383900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000811A6C: BF870193
	v_div_fixup_f32 v2, v6, v2, 1.0                            // 000000811A70: D6270002 03CA0506
	v_fma_f32 v9, -v10, v26, v21                               // 000000811A78: D6130009 2456350A
	v_fma_f32 v10, -v11, v27, v24                              // 000000811A80: D613000A 2462370B
	v_div_scale_f32 v0, s3, 1.0, v18, 1.0                      // 000000811A88: D6FC0300 03CA24F2
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000811A90: 8480820C
	.long 0x7e183982                                           // 000000811A94: 7E183982
	v_div_fmas_f32 v9, v9, v15, v26                            // 000000811A98: D6370009 046A1F09
	s_mov_b32 vcc_lo, s2                                       // 000000811AA0: BEEA0002
	v_div_fmas_f32 v6, v10, v16, v27                           // 000000811AA4: D6370006 046E210A
	s_mov_b32 vcc_lo, s3                                       // 000000811AAC: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000811AB0: BF8701A2
	v_div_fixup_f32 v9, v9, v7, 1.0                            // 000000811AB4: D6270009 03CA0F09
	.long 0x7f0e398c                                           // 000000811ABC: 7F0E398C
	v_div_fixup_f32 v10, v6, v8, 1.0                           // 000000811AC0: D627000A 03CA1106
	v_and_b32_e32 v6, 1, v12                                   // 000000811AC8: 360C1881
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000811ACC: BF870224
	.long 0x7e0e3989                                           // 000000811AD0: 7E0E3989
	v_mul_f32_e32 v11, v0, v28                                 // 000000811AD4: 10163900
	.long 0x7e18398a                                           // 000000811AD8: 7E18398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811ADC: BF870114
	v_add3_u32 v14, v2, v6, 0x7fff                             // 000000811AE0: D655000E 03FE0D02 00007FFF
	v_and_b32_e32 v2, 1, v12                                   // 000000811AEC: 36041881
	v_and_b32_e32 v12, 1, v7                                   // 000000811AF0: 36180E81
	v_fma_f32 v5, -v22, v11, v0                                // 000000811AF4: D6130005 24021716
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000811AFC: BF870193
	v_add3_u32 v16, v10, v2, 0x7fff                            // 000000811B00: D6550010 03FE050A 00007FFF
	v_add3_u32 v12, v9, v12, 0x7fff                            // 000000811B0C: D655000C 03FE1909 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000811B18: BF870123
	v_fmac_f32_e32 v11, v5, v28                                // 000000811B1C: 56163905
	v_and_b32_e32 v5, 1, v17                                   // 000000811B20: 360A2281
	v_fma_f32 v0, -v22, v11, v0                                // 000000811B24: D6130000 24021716
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000811B2C: BF870112
	v_add3_u32 v13, v1, v5, 0x7fff                             // 000000811B30: D655000D 03FE0B01 00007FFF
	v_div_fmas_f32 v0, v0, v28, v11                            // 000000811B3C: D6370000 042E3900
	.long 0xd7006a05                                           // 000000811B44: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000811B48: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000811B4C: BF870191
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000811B50: D5207C06 01AA0805
	v_div_fixup_f32 v11, v0, v18, 1.0                          // 000000811B58: D627000B 03CA2500
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 000000811B60: D6FE7C00 040D0C0C
	.long 0xd7006a07                                           // 000000811B68: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000811B6C: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000811B70: BF870211
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 000000811B74: D5207C08 01AA0801
	v_bfe_u32 v15, v11, 16, 1                                  // 000000811B7C: D610000F 0205210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000811B84: BF870223
	.long 0xd7006a09                                           // 000000811B88: D7006A09
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 000000811B8C: 02000107
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000811B90: D6FE7C01 04050C0D
	v_add_co_ci_u32_e64 v10, null, s1, v8, vcc_lo              // 000000811B98: D5207C0A 01AA1001
	s_delay_alu instid0(VALU_DEP_4)                            // 000000811BA0: BF870004
	v_add3_u32 v2, v11, v15, 0x7fff                            // 000000811BA4: D6550002 03FE1F0B 00007FFF
	s_clause 0x4                                               // 000000811BB0: BF850004
	global_store_d16_hi_b16 v[3:4], v13, off                   // 000000811BB4: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v14, off                   // 000000811BBC: DC960000 007C0E05
	global_store_d16_hi_b16 v[7:8], v12, off                   // 000000811BC4: DC960000 007C0C07
	global_store_d16_hi_b16 v[0:1], v16, off                   // 000000811BCC: DC960000 007C1000
	global_store_d16_hi_b16 v[9:10], v2, off                   // 000000811BD4: DC960000 007C0209
	s_endpgm                                                   // 000000811BDC: BFB00000
		...

