00000000008e2b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008E2B00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008E2B08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008E2B0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008E2B10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000008E2B14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 0000008E2B18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 0000008E2B1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000008E2B24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 0000008E2B28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008E2B2C: 30020282
	.long 0x7f0a3880                                           // 0000008E2B30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000008E2B34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 0000008E2B38: BF89FC07
	s_clause 0x1                                               // 0000008E2B3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000008E2B40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000008E2B48: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000008E2B50: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000008E2B54: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000008E2B58: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000008E2B5C: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000008E2B60: 85109B10
	v_or_b32_e32 v1, s20, v28                                  // 0000008E2B64: 38023814
	s_add_u32 s16, s10, s16                                    // 0000008E2B68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000008E2B6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E2B70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000008E2B74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008E2B78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000008E2B7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008E2B80: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000008E2B84: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000008E2B88: 81111611
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000008E2B8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 0000008E2B90: 86118111
	v_cndmask_b32_e64 v2, 0, s21, vcc_lo                       // 0000008E2B94: D5010002 01A82A80
	.long 0xd72c0007                                           // 0000008E2B9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 0000008E2BA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000008E2BA4: B3900201
	.long 0xd72c0009                                           // 0000008E2BA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000008E2BAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[2:3]              // 0000008E2BB0: D6FE7C18 000A0212
	s_cselect_b32 s2, -1, 0                                    // 0000008E2BB8: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000008E2BBC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 0000008E2BC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 0000008E2BC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008E2BC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 0000008E2BCC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 0000008E2BD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000008E2BD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008E2BD8: BF870151
	.long 0xd4410003                                           // 0000008E2BDC: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008E2BE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 0000008E2BE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 0000008E2BE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 0000008E2BF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000008E2BF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000008E2BFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 0000008E2C08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 0000008E2C0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E2C10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000008E2C14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 0000008E2C20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008E2C24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 0000008E2C28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 0000008E2C30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 0000008E2C3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 0000008E2C44: BF89FC07
	s_barrier                                                  // 0000008E2C48: BFBD0000
	buffer_gl0_inv                                             // 0000008E2C4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000008E2C54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000008E2C58: CA100080 09080080
	s_and_saveexec_b32 s17, s3                                 // 0000008E2C60: BE912003
	s_cbranch_execz 11                                         // 0000008E2C64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 0000008E2C68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2C6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2C70: 3408069F
	.long 0xd7006a03                                           // 0000008E2C74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2C78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2C7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2C84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2C8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 0000008E2C90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008E2C94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 0000008E2C98: 4A063EA0
	s_mov_b32 s3, exec_lo                                      // 0000008E2C9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E2CA0: BF870001
	.long 0xd4c1007e                                           // 0000008E2CA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2CA8: 02024103
	s_cbranch_execz 11                                         // 0000008E2CAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2CB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2CB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2CB8: 3408069F
	.long 0xd7006a03                                           // 0000008E2CBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2CC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2CC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2CCC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2CD4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 0000008E2CD8: 7E121703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2CDC: 8C7E037E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 0000008E2CE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 0000008E2CE8: 7E160280
	s_mov_b32 s3, exec_lo                                      // 0000008E2CEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E2CF0: BF870002
	.long 0xd4c1007e                                           // 0000008E2CF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2CF8: 02024103
	s_cbranch_execz 11                                         // 0000008E2CFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2D00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2D04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2D08: 3408069F
	.long 0xd7006a03                                           // 0000008E2D0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2D10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2D14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2D1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2D24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 0000008E2D28: 7E141703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2D2C: 8C7E037E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 0000008E2D30: 4A063EFF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000008E2D38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E2D3C: BF870001
	.long 0xd4c1007e                                           // 0000008E2D40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2D44: 02024103
	s_cbranch_execz 11                                         // 0000008E2D48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2D4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2D50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2D54: 3408069F
	.long 0xd7006a03                                           // 0000008E2D58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2D5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2D60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2D68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2D70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 0000008E2D74: 7E161703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2D78: 8C7E037E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 0000008E2D7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000008E2D88: 7E1A0280
	s_mov_b32 s3, exec_lo                                      // 0000008E2D8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E2D90: BF870002
	.long 0xd4c1007e                                           // 0000008E2D94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2D98: 02024103
	s_cbranch_execz 11                                         // 0000008E2D9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2DA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2DA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2DA8: 3408069F
	.long 0xd7006a03                                           // 0000008E2DAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2DB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2DB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2DBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2DC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 0000008E2DC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2DCC: 8C7E037E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 0000008E2DD0: 4A063EFF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000008E2DD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E2DDC: BF870001
	.long 0xd4c1007e                                           // 0000008E2DE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2DE4: 02024103
	s_cbranch_execz 11                                         // 0000008E2DE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2DEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2DF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2DF4: 3408069F
	.long 0xd7006a03                                           // 0000008E2DF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2DFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2E00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2E08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2E10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 0000008E2E14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2E18: 8C7E037E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 0000008E2E1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000008E2E28: 7E1E0280
	s_mov_b32 s3, exec_lo                                      // 0000008E2E2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E2E30: BF870002
	.long 0xd4c1007e                                           // 0000008E2E34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2E38: 02024103
	s_cbranch_execz 11                                         // 0000008E2E3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2E40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2E44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2E48: 3408069F
	.long 0xd7006a03                                           // 0000008E2E4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2E50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2E54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2E5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2E64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 0000008E2E68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2E6C: 8C7E037E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 0000008E2E70: 4A063EFF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000008E2E78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E2E7C: BF870001
	.long 0xd4c1007e                                           // 0000008E2E80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000008E2E84: 02024103
	s_cbranch_execz 11                                         // 0000008E2E88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000008E2E8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2E90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008E2E94: 3408069F
	.long 0xd7006a03                                           // 0000008E2E98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000008E2E9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000008E2EA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000008E2EA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008E2EB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 0000008E2EB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008E2EB8: 8C7E037E
	s_branch 9                                                 // 0000008E2EBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 0000008E2EC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E2EC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000008E2EC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000008E2ECC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000008E2ED0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000008E2ED4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000008E2ED8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000008E2EDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000008E2EE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 0000008E2EE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000008E2EE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000008E2EEC: 85039F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 0000008E2EF0: CA100080 141A0080
	s_add_u32 s14, s10, s3                                     // 0000008E2EF8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 0000008E2EFC: 820F800B
	.long 0xd4410003                                           // 0000008E2F00: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008E2F04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008E2F08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 0000008E2F0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 0000008E2F14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 0000008E2F1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000008E2F20: 02001F01
	.long 0xd72c0002                                           // 0000008E2F24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000008E2F28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 0000008E2F2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008E2F34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E2F3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 0000008E2F40: D6550024 04063502
	s_and_saveexec_b32 s4, s3                                  // 0000008E2F48: BE842003
	s_cbranch_execz 22                                         // 0000008E2F4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000008E2F50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000008E2F54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E2F58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008E2F5C: 3404029F
	.long 0xd7006a01                                           // 0000008E2F60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000008E2F64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008E2F68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000008E2F70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 0000008E2F74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000008E2F7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000008E2F80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E2F84: BF870091
	.long 0xd7006a01                                           // 0000008E2F88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008E2F8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000008E2F90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000008E2F98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008E2FA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000008E2FA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008E2FA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000008E2FAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000008E2FB4: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 0000008E2FBC: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 0000008E2FC4: 7E4A0280
	s_and_saveexec_b32 s14, s3                                 // 0000008E2FC8: BE8E2003
	s_cbranch_execz 666                                        // 0000008E2FCC: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xf38>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000008E2FD0: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000008E2FD8: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 0000008E2FE0: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E2FE8: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 0000008E2FEC: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 0000008E2FF4: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000008E2FFC: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 0000008E3004: 7E5C031B
	s_mul_i32 s3, s11, 6                                       // 0000008E3008: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000008E300C: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008E3010: 8484820A
	s_add_i32 s15, s15, s3                                     // 0000008E3014: 810F030F
	s_mul_i32 s17, s10, 6                                      // 0000008E3018: 9611860A
	s_mov_b32 s16, 0                                           // 0000008E301C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008E3020: 848A810A
	s_branch 608                                               // 0000008E3024: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xea8>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008E3028: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s2                         // 0000008E302C: D501002F 000A111B
	v_cndmask_b32_e64 v4, v11, v12, s2                         // 0000008E3034: D5010004 000A190B
	v_cndmask_b32_e64 v3, v10, v11, s2                         // 0000008E303C: D5010003 000A170A
	v_cndmask_b32_e64 v2, v9, v10, s2                          // 0000008E3044: D5010002 000A1509
	v_cndmask_b32_e64 v1, v8, v9, s2                           // 0000008E304C: D5010001 000A1308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000008E3054: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 0000008E3060: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 0000008E3064: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s2                         // 0000008E3068: D5010007 000A1F0E
	v_cndmask_b32_e64 v6, v13, v14, s2                         // 0000008E3070: D5010006 000A1D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008E3078: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008E307C: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E3084: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s2                         // 0000008E308C: D5010005 000A1B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000008E3094: 3436349F
	ds_load_b32 v9, v9                                         // 0000008E3098: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 0000008E30A0: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 0000008E30A8: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 0000008E30B0: 32162896
	s_and_b32 s3, exec_lo, s3                                  // 0000008E30B4: 8B03037E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 0000008E30B8: 4A5858FF 00000200
	s_or_b32 s16, s3, s16                                      // 0000008E30C0: 8C101003
	v_add_nc_u32_e32 v45, 64, v45                              // 0000008E30C4: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E30C8: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 0000008E30D0: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 0000008E30D8: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E30E0: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008E30E4: 30161682
	ds_load_b32 v61, v11                                       // 0000008E30E8: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 0000008E30F0: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E30F4: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 0000008E30FC: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 0000008E3104: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3108: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E310C: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 0000008E3114: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 0000008E311C: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E3120: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 0000008E3128: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 0000008E3130: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3138: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008E313C: 30161682
	ds_load_b32 v65, v11                                       // 0000008E3140: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 0000008E3148: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E314C: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 0000008E3154: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 0000008E315C: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3160: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E3164: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 0000008E316C: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 0000008E3174: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E3178: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 0000008E3180: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 0000008E3188: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3190: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008E3194: 30161682
	ds_load_b32 v69, v11                                       // 0000008E3198: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 0000008E31A0: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E31A4: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 0000008E31AC: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 0000008E31B4: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E31B8: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E31BC: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 0000008E31C4: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 0000008E31CC: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008E31D0: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 0000008E31D8: D8D80000 4800000B
	.long 0xd73c000b                                           // 0000008E31E0: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008E31E4: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008E31E8: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E31F4: BF870092
	.long 0xd7006a38                                           // 0000008E31F8: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000008E31FC: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 0000008E3200: D5207C39 01AA1807
	s_clause 0x3                                               // 0000008E3208: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000008E320C: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000008E3214: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008E321C: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000008E3224: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008E322C: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E3230: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 0000008E3238: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E323C: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E3240: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 0000008E3248: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E324C: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 0000008E3254: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3258: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E325C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008E3264: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E3268: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 0000008E3270: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3274: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3278: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 0000008E3280: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3284: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 0000008E328C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3290: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E3294: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008E329C: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E32A0: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 0000008E32A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E32AC: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E32B0: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 0000008E32B8: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E32BC: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 0000008E32C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E32C8: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E32CC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008E32D4: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E32D8: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000008E32E0: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 0000008E32E4: 02001538
	s_waitcnt lgkmcnt(2)                                       // 0000008E32E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008E32EC: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E32F0: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 0000008E32F8: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 0000008E3300: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000008E3304: 02000938
	s_waitcnt lgkmcnt(1)                                       // 0000008E3308: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E330C: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 0000008E3314: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 0000008E331C: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 0000008E3320: 02002338
	s_waitcnt lgkmcnt(0)                                       // 0000008E3324: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E3328: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E332C: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 0000008E3334: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 0000008E333C: 564A172F
	s_clause 0x3                                               // 0000008E3340: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000008E3344: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008E334C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000008E3354: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000008E335C: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000008E3364: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E3368: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3370: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E3374: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E337C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3384: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E3388: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3390: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E3394: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E339C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E33A0: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E33A8: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E33B0: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E33B4: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E33BC: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E33C0: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E33C8: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E33CC: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E33D4: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E33DC: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E33E0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E33E8: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E33EC: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E33F4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E33F8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E3400: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3408: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E340C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 0000008E3414: 5656172F
	s_clause 0x3                                               // 0000008E3418: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000008E341C: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000008E3424: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000008E342C: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000008E3434: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 0000008E343C: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 0000008E3440: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3444: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 0000008E3448: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 0000008E3450: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E3454: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E345C: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3464: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E3468: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E3470: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3478: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E347C: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E3480: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3488: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3490: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3494: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E349C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E34A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E34A8: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E34AC: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E34B4: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E34BC: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E34C0: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E34C8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E34D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E34D4: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E34D8: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E34E0: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E34E8: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E34EC: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E34F4: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E34FC: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 0000008E3500: 5654172F
	s_clause 0x3                                               // 0000008E3504: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000008E3508: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000008E3510: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008E3518: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000008E3520: DC5E0030 347C0038
	.long 0xd7006a38                                           // 0000008E3528: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000008E352C: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3530: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 0000008E3534: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 0000008E353C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E3540: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E3548: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3550: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E3554: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E355C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3564: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3568: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E356C: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3574: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E357C: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3580: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E3588: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E3590: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3594: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E3598: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E35A0: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E35A8: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E35AC: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E35B4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E35BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E35C0: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E35C4: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E35CC: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E35D4: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E35D8: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E35E0: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E35E8: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000008E35EC: 5652172F
	s_clause 0x3                                               // 0000008E35F0: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000008E35F4: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000008E35FC: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000008E3604: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000008E360C: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 0000008E3614: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E3618: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3620: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E3624: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E362C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3634: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E3638: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3640: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E3644: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E364C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3650: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3658: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3660: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E3664: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E366C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E3670: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3678: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E367C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E3684: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E368C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E3690: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E3698: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E369C: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E36A4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E36A8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E36B0: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E36B8: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E36BC: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000008E36C4: 5650172F
	s_clause 0x3                                               // 0000008E36C8: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000008E36CC: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000008E36D4: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008E36DC: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000008E36E4: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000008E36EC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E36F0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E36F8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E36FC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E3704: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E370C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E3710: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3718: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E371C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3724: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3728: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3730: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3738: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E373C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E3744: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E3748: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3750: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E3754: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E375C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3764: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E3768: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E3770: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E3774: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000008E377C: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 0000008E3780: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E3784: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E3788: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 0000008E3790: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E3798: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E37A0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E37A4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000008E37AC: 564E172F
	s_clause 0x3                                               // 0000008E37B0: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000008E37B4: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008E37BC: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000008E37C4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000008E37CC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000008E37D4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000008E37D8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E37E0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000008E37E4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000008E37EC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E37F4: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000008E37F8: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000008E3800: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000008E3804: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E380C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000008E3810: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000008E3818: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3820: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000008E3824: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000008E382C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000008E3830: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3838: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000008E383C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000008E3844: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E384C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000008E3850: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000008E3858: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000008E385C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000008E3864: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000008E3868: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E386C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000008E3870: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 0000008E3878: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000008E3880: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3888: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000008E388C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 0000008E3894: 564C172F
	s_clause 0x3                                               // 0000008E3898: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000008E389C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000008E38A4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000008E38AC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000008E38B4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000008E38BC: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 0000008E38C0: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E38C8: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 0000008E38CC: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 0000008E38D4: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E38DC: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 0000008E38E0: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 0000008E38E8: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 0000008E38EC: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 0000008E38F4: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E38F8: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 0000008E38FC: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 0000008E3904: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 0000008E3908: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 0000008E3910: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008E3914: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 0000008E3918: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 0000008E3920: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000008E3924: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 0000008E3928: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3930: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 0000008E3934: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 0000008E393C: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3944: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 0000008E3948: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 0000008E3950: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 0000008E3954: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E395C: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 0000008E3960: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 0000008E3968: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3970: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 0000008E3974: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 0000008E397C: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000008E3984: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000008E398C: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000008E3994: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000008E399C: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008E39A0: 917E107E
	s_cbranch_execz 35                                         // 0000008E39A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xf34>
	s_waitcnt vmcnt(0)                                         // 0000008E39A8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008E39AC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008E39B4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008E39BC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E39C0: BF870003
	.long 0xd4460003                                           // 0000008E39C4: D4460003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008E39C8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000008E39CC: BE92007E
	.long 0xd4c1007e                                           // 0000008E39D0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008E39D4: 0202411F
	s_cbranch_execz 64915                                      // 0000008E39D8: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000008E39DC: 3404589F
	.long 0xd7006a01                                           // 0000008E39E0: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 0000008E39E4: 02025919
	v_mov_b32_e32 v46, v27                                     // 0000008E39E8: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E39EC: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008E39F0: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000008E39F8: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000008E39FC: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 0000008E3A04: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v45                              // 0000008E3A08: 34045A9F
	.long 0xd7006a01                                           // 0000008E3A0C: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 0000008E3A10: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008E3A14: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008E3A18: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008E3A20: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008E3A28: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 0000008E3A2C: 7E5C1701
	s_branch 64893                                             // 0000008E3A30: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008E3A34: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3A38: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008E3A3C: 8C7E0E7E
	.long 0xd71f0001                                           // 0000008E3A40: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008E3A44: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008E3A48: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008E3A4C: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 0000008E3A50: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 0000008E3A54: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008E3A58: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008E3A5C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008E3A60: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008E3A64: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008E3A68: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008E3A6C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000008E3A70: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000008E3A78: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000008E3A7C: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 0000008E3A80: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 0000008E3A88: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 0000008E3A90: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008E3A98: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 0000008E3A9C: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 0000008E3AA4: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 0000008E3AAC: DACC0000 08002702
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000008E3AB4: 7C9824A0
	ds_bpermute_b32 v2, v2, v34                                // 0000008E3AB8: DACC0000 02002202
	s_waitcnt lgkmcnt(6)                                       // 0000008E3AC0: BF89FC67
	v_dual_cndmask_b32 v18, v1, v18 :: v_dual_add_f32 v5, v42, v5// 0000008E3AC4: CA482501 12040B2A
	s_waitcnt lgkmcnt(5)                                       // 0000008E3ACC: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008E3AD0: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000008E3AD8: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 0000008E3ADC: 06121326
	ds_bpermute_b32 v13, v10, v5                               // 0000008E3AE0: DACC0000 0D00050A
	s_waitcnt lgkmcnt(4)                                       // 0000008E3AE8: BF89FC47
	v_add_f32_e32 v4, v43, v4                                  // 0000008E3AEC: 0608092B
	ds_bpermute_b32 v11, v10, v3                               // 0000008E3AF0: DACC0000 0B00030A
	ds_bpermute_b32 v17, v10, v9                               // 0000008E3AF8: DACC0000 1100090A
	s_waitcnt lgkmcnt(5)                                       // 0000008E3B00: BF89FC57
	v_add_f32_e32 v6, v41, v6                                  // 0000008E3B04: 060C0D29
	s_waitcnt lgkmcnt(4)                                       // 0000008E3B08: BF89FC47
	v_add_f32_e32 v8, v39, v8                                  // 0000008E3B0C: 06101127
	ds_bpermute_b32 v15, v10, v7                               // 0000008E3B10: DACC0000 0F00070A
	s_waitcnt lgkmcnt(3)                                       // 0000008E3B18: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v13   // 0000008E3B1C: C9080522 02041B05
	ds_bpermute_b32 v12, v10, v4                               // 0000008E3B24: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 0000008E3B2C: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_lshlrev_b32 v18, 2, v18// 0000008E3B30: C9221703 03122482
	ds_bpermute_b32 v14, v10, v6                               // 0000008E3B38: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 0000008E3B40: BF89FC37
	v_add_f32_e32 v9, v9, v17                                  // 0000008E3B44: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 0000008E3B48: DACC0000 1000080A
	s_waitcnt lgkmcnt(3)                                       // 0000008E3B50: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 0000008E3B54: 060E1F07
	ds_bpermute_b32 v10, v10, v2                               // 0000008E3B58: DACC0000 0A00020A
	s_waitcnt lgkmcnt(3)                                       // 0000008E3B60: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 0000008E3B64: 06081904
	ds_bpermute_b32 v12, v18, v5                               // 0000008E3B68: DACC0000 0C000512
	s_waitcnt lgkmcnt(2)                                       // 0000008E3B70: BF89FC27
	v_add_f32_e32 v8, v8, v16                                  // 0000008E3B74: 06102108
	s_waitcnt lgkmcnt(0)                                       // 0000008E3B78: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000008E3B7C: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 0000008E3B80: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 0000008E3B88: 060C1D06
	ds_bpermute_b32 v14, v18, v7                               // 0000008E3B8C: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 0000008E3B94: BF89FC17
	v_add_f32_e32 v9, v9, v16                                  // 0000008E3B98: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 0000008E3B9C: DACC0000 0D000612
	s_waitcnt lgkmcnt(1)                                       // 0000008E3BA4: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 0000008E3BA8: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 0000008E3BAC: DACC0000 0F000812
	s_waitcnt lgkmcnt(0)                                       // 0000008E3BB4: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 0000008E3BB8: 06101F08
	v_add_f32_e32 v2, v2, v10                                  // 0000008E3BBC: 06041502
	ds_bpermute_b32 v10, v18, v3                               // 0000008E3BC0: DACC0000 0A000312
	ds_bpermute_b32 v17, v18, v2                               // 0000008E3BC8: DACC0000 11000212
	s_waitcnt lgkmcnt(1)                                       // 0000008E3BD0: BF89FC17
	v_add_f32_e32 v3, v3, v10                                  // 0000008E3BD4: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 0000008E3BD8: DACC0000 0B000412
	v_xor_b32_e32 v18, 2, v1                                   // 0000008E3BE0: 3A240282
	s_waitcnt lgkmcnt(1)                                       // 0000008E3BE4: BF89FC17
	v_add_f32_e32 v10, v2, v17                                 // 0000008E3BE8: 06142302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008E3BEC: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000008E3BF0: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000008E3BF4: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000008E3BF8: 30242482
	s_waitcnt lgkmcnt(0)                                       // 0000008E3BFC: BF89FC07
	v_add_f32_e32 v4, v4, v11                                  // 0000008E3C00: 06081704
	ds_bpermute_b32 v2, v18, v3                                // 0000008E3C04: DACC0000 02000312
	v_add_f32_e32 v6, v6, v13                                  // 0000008E3C0C: 060C1B06
	ds_bpermute_b32 v12, v18, v5                               // 0000008E3C10: DACC0000 0C000512
	ds_bpermute_b32 v14, v18, v7                               // 0000008E3C18: DACC0000 0E000712
	ds_bpermute_b32 v11, v18, v4                               // 0000008E3C20: DACC0000 0B000412
	ds_bpermute_b32 v15, v18, v8                               // 0000008E3C28: DACC0000 0F000812
	ds_bpermute_b32 v13, v18, v6                               // 0000008E3C30: DACC0000 0D000612
	ds_bpermute_b32 v16, v18, v9                               // 0000008E3C38: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v10                              // 0000008E3C40: DACC0000 11000A12
	v_xor_b32_e32 v18, 1, v1                                   // 0000008E3C48: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008E3C4C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000008E3C50: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 0000008E3C54: 02022501
	s_waitcnt lgkmcnt(7)                                       // 0000008E3C58: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 0000008E3C5C: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 0000008E3C64: BF89FC47
	v_add_f32_e32 v2, v4, v11                                  // 0000008E3C68: 06041704
	s_waitcnt lgkmcnt(2)                                       // 0000008E3C6C: BF89FC27
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 0000008E3C70: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 0000008E3C78: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 0000008E3C7C: BF89FC17
	v_dual_add_f32 v11, v8, v15 :: v_dual_add_f32 v12, v9, v16 // 0000008E3C80: C9081F08 0B0C2109
	s_waitcnt lgkmcnt(0)                                       // 0000008E3C88: BF89FC07
	v_add_f32_e32 v13, v10, v17                                // 0000008E3C8C: 061A230A
	ds_bpermute_b32 v6, v18, v1                                // 0000008E3C90: DACC0000 06000112
	ds_bpermute_b32 v7, v18, v2                                // 0000008E3C98: DACC0000 07000212
	ds_bpermute_b32 v9, v18, v4                                // 0000008E3CA0: DACC0000 09000412
	ds_bpermute_b32 v10, v18, v5                               // 0000008E3CA8: DACC0000 0A000512
	ds_bpermute_b32 v8, v18, v3                                // 0000008E3CB0: DACC0000 08000312
	ds_bpermute_b32 v14, v18, v11                              // 0000008E3CB8: DACC0000 0E000B12
	ds_bpermute_b32 v15, v18, v12                              // 0000008E3CC0: DACC0000 0F000C12
	ds_bpermute_b32 v16, v18, v13                              // 0000008E3CC8: DACC0000 10000D12
	v_cmpx_eq_u32_e32 0, v30                                   // 0000008E3CD0: 7D943C80
	s_cbranch_execz 17                                         // 0000008E3CD4: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 0000008E3CD8: BF89FC27
	v_dual_add_f32 v11, v11, v14 :: v_dual_lshlrev_b32 v18, 5, v29// 0000008E3CDC: C9221D0B 0B123A85
	s_waitcnt lgkmcnt(0)                                       // 0000008E3CE4: BF89FC07
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v15// 0000008E3CE8: C908210D 0D0C1F0C
	v_dual_add_f32 v17, v5, v10 :: v_dual_add_f32 v16, v4, v9  // 0000008E3CF0: C9081505 11101304
	v_dual_add_f32 v15, v2, v7 :: v_dual_add_f32 v14, v1, v6   // 0000008E3CF8: C9080F02 0F0E0D01
	v_lshl_or_b32 v1, v28, 6, v18                              // 0000008E3D00: D6560001 04490D1C
	v_add_f32_e32 v10, v3, v8                                  // 0000008E3D08: 06141103
	ds_store_b128 v1, v[14:17] offset:1024                     // 0000008E3D0C: DB7C0400 00000E01
	ds_store_b128 v1, v[10:13] offset:1040                     // 0000008E3D14: DB7C0410 00000A01
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008E3D1C: 8C7E027E
	v_lshrrev_b32_e32 v3, 3, v0                                // 0000008E3D20: 32060083
	v_mov_b32_e32 v2, s21                                      // 0000008E3D24: 7E040215
	.long 0xd44c0002                                           // 0000008E3D28: D44C0002
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 0000008E3D2C: 020200A0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008E3D30: BF890007
	s_barrier                                                  // 0000008E3D34: BFBD0000
	v_or_b32_e32 v1, s20, v3                                   // 0000008E3D38: 38020614
	buffer_gl0_inv                                             // 0000008E3D3C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008E3D44: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008E3D48: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008E3D4C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008E3D50: BE832002
	s_cbranch_execz 80                                         // 0000008E3D54: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1398>
	v_dual_mov_b32 v10, s8 :: v_dual_and_b32 v5, 7, v0         // 0000008E3D58: CA240008 0A040087
	v_ashrrev_i32_e32 v4, 31, v2                               // 0000008E3D60: 3408049F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008E3D64: F4040080 F8000040
	s_lshr_b32 s0, s13, 31                                     // 0000008E3D6C: 85009F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008E3D70: BF8704B2
	v_lshlrev_b32_e32 v0, 2, v5                                // 0000008E3D74: 30000A82
	s_add_u32 s0, s12, s0                                      // 0000008E3D78: 8000000C
	s_addc_u32 s1, s13, 0                                      // 0000008E3D7C: 8201800D
	s_ashr_i64 s[0:1], s[0:1], 1                               // 0000008E3D80: 86808100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008E3D84: BF870121
	v_lshl_or_b32 v0, v3, 6, v0                                // 0000008E3D88: D6560000 04010D03
	v_lshrrev_b32_e32 v3, 23, v4                               // 0000008E3D90: 32060897
	v_add_nc_u32_e32 v0, 0x400, v0                             // 0000008E3D94: 4A0000FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3D9C: BF870092
	.long 0xd7006a03                                           // 0000008E3DA0: D7006A03
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000008E3DA4: 02020701
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000008E3DA8: D5207C08 01AA0480
	ds_load_2addr_b32 v[6:7], v0 offset1:8                     // 0000008E3DB0: D8DC0800 06000000
	v_and_b32_e32 v9, 0xfffffe00, v3                           // 0000008E3DB8: 361206FF FFFFFE00
	v_mad_u64_u32 v[3:4], null, s0, v5, 0                      // 0000008E3DC0: D6FE7C03 02020A00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008E3DC8: BF870092
	.long 0xd7016a00                                           // 0000008E3DCC: D7016A00
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000008E3DD0: 02021301
	v_sub_co_ci_u32_e64 v1, null, v2, v8, vcc_lo               // 0000008E3DD4: D5217C01 01AA1102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008E3DDC: BF870223
	v_mad_u64_u32 v[4:5], null, s1, v5, v[4:5]                 // 0000008E3DE0: D6FE7C04 04120A01
	v_mov_b32_e32 v5, s9                                       // 0000008E3DE8: 7E0A0209
	.long 0xd700000b                                           // 0000008E3DEC: D700000B
	v_cndmask_b32_e32 v1, 0xffffff00, v0, vcc_lo               // 0000008E3DF0: 020200FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008E3DF8: BF870004
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[0:1]                     // 0000008E3DFC: 7CA800FF 00000100
	v_add_co_ci_u32_e64 v12, null, -1, v1, s0                  // 0000008E3E04: D5207C0C 000202C1
	.long 0xd73c0002                                           // 0000008E3E0C: D73C0002
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000008E3E10: 02020681
	s_waitcnt lgkmcnt(0)                                       // 0000008E3E14: BF89FC07
	v_dual_cndmask_b32 v5, s3, v5 :: v_dual_cndmask_b32 v0, v11, v0// 0000008E3E18: CA520A03 0500010B
	v_add_f32_e32 v4, 0, v6                                    // 0000008E3E20: 06080C80
	v_dual_cndmask_b32 v6, s2, v10 :: v_dual_cndmask_b32 v1, v12, v1// 0000008E3E24: CA521402 0600030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008E3E2C: BF870112
	v_add_f32_e32 v4, v4, v7                                   // 0000008E3E30: 06080F04
	.long 0xd7006a02                                           // 0000008E3E34: D7006A02
	v_cndmask_b32_e32 v1, v6, v2, vcc_lo                       // 0000008E3E38: 02020506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008E3E3C: BF870211
	v_add_co_ci_u32_e64 v3, null, v5, v3, vcc_lo               // 0000008E3E40: D5207C03 01AA0705
	.long 0xd73c0000                                           // 0000008E3E48: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008E3E4C: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008E3E50: BF870223
	.long 0xd7006a02                                           // 0000008E3E54: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 0000008E3E58: 02021302
	v_bfe_u32 v5, v4, 16, 1                                    // 0000008E3E5C: D6100005 02052104
	v_add_co_ci_u32_e64 v3, null, v3, v8, vcc_lo               // 0000008E3E64: D5207C03 01AA1103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008E3E6C: BF870193
	.long 0xd7006a00                                           // 0000008E3E70: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008E3E74: 02020102
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000008E3E78: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008E3E84: BF870003
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 0000008E3E88: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008E3E90: DC960000 007C0400
	s_endpgm                                                   // 0000008E3E98: BFB00000
		...

