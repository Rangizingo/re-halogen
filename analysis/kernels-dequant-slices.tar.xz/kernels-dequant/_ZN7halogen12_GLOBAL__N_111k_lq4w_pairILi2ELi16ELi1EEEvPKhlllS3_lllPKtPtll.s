0000000000289100 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll>:
; _ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll():
	s_load_b512 s[4:19], s[0:1], null                          // 000000289100: F4100100 F8000000
	v_and_b32_e32 v51, 15, v0                                  // 000000289108: 3666008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000028910C: 32020084
	s_mov_b32 s3, 0                                            // 000000289110: BE830080
	s_load_b256 s[20:27], s[0:1], 0x40                         // 000000289114: F40C0500 F8000040
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000028911C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000289120: BF870009
	v_dual_mov_b32 v41, s1 :: v_dual_lshlrev_b32 v2, 2, v51    // 000000289124: CA220001 29026682
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000028912C: 30060282
	v_and_b32_e32 v4, 14, v1                                   // 000000289130: 3608028E
	v_and_b32_e32 v1, 1, v1                                    // 000000289134: 36020281
	v_lshlrev_b32_e32 v13, 2, v0                               // 000000289138: 301A0082
	.long 0x7f183880                                           // 00000028913C: 7F183880
	s_waitcnt lgkmcnt(0)                                       // 000000289140: BF89FC07
	s_clause 0x1                                               // 000000289144: BF850001
	global_load_b32 v8, v2, s[4:5]                             // 000000289148: DC520000 08040002
	global_load_b32 v2, v2, s[12:13]                           // 000000289150: DC520000 020C0002
	s_clause 0x1                                               // 000000289158: BF850001
	global_load_b32 v9, v3, s[4:5]                             // 00000028915C: DC520000 09040003
	global_load_b32 v3, v3, s[12:13]                           // 000000289164: DC520000 030C0003
	v_or3_b32 v40, s0, v4, v1                                  // 00000028916C: D6580028 04060800
	s_ashr_i32 s2, s25, 31                                     // 000000289174: 86029F19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000289178: BF8704A1
	.long 0xd4540000                                           // 00000028917C: D4540000
	v_cndmask_b32_e32 v1, s26, v40, vcc_lo                     // 000000289180: 0202501A
	s_lshr_b32 s2, s2, 27                                      // 000000289184: 85029B02
	s_add_u32 s2, s24, s2                                      // 000000289188: 80020218
	s_addc_u32 s3, s25, 0                                      // 00000028918C: 82038019
	v_cndmask_b32_e64 v1, 0, v40, s0                           // 000000289190: D5010001 00025080
	v_cndmask_b32_e64 v0, 0, s1, s0                            // 000000289198: D5010000 00000280
	s_lshr_b64 s[28:29], s[2:3], 5                             // 0000002891A0: 859C8502
	s_add_u32 s3, s4, s8                                       // 0000002891A4: 80030804
	.long 0xd4440002                                           // 0000002891A8: D4440002
	v_cndmask_b32_e32 v1, s28, v51, vcc_lo                     // 0000002891AC: 0202661C
	.long 0xd72c000a                                           // 0000002891B0: D72C000A
	v_cndmask_b32_e32 v0, v1, v11, vcc_lo                      // 0000002891B4: 02001701
	v_mad_u64_u32 v[6:7], null, v1, s10, 0                     // 0000002891B8: D6FE7C06 02001501
	.long 0xd72c000e                                           // 0000002891C0: D72C000E
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                      // 0000002891C4: 02001500
	.long 0xd72c000b                                           // 0000002891C8: D72C000B
	v_cndmask_b32_e32 v0, v1, v19, vcc_lo                      // 0000002891CC: 02002701
	v_mad_u64_u32 v[4:5], null, v1, s18, 0                     // 0000002891D0: D6FE7C04 02002501
	.long 0xd72c0010                                           // 0000002891D8: D72C0010
	v_cndmask_b32_e32 v0, v0, v18, vcc_lo                      // 0000002891DC: 02002500
	s_addc_u32 s11, s5, s9                                     // 0000002891E0: 820B0905
	s_add_u32 s19, s12, s16                                    // 0000002891E4: 8013100C
	s_addc_u32 s29, s13, s17                                   // 0000002891E8: 821D110D
	s_cmpk_lt_i32 s28, 0x81                                    // 0000002891EC: B39C0081
	v_add3_u32 v7, v7, v10, v14                                // 0000002891F0: D6550007 043A1507
	.long 0xd700030a                                           // 0000002891F8: D700030A
	v_cndmask_b32_e32 v1, s3, v6, vcc_lo                       // 0000002891FC: 02020C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000289200: BF8701A3
	v_add3_u32 v5, v5, v11, v16                                // 000000289204: D6550005 04421705
	s_cselect_b32 s1, -1, 0                                    // 00000028920C: 980180C1
	v_add_co_ci_u32_e64 v11, null, s11, v7, s3                 // 000000289210: D5207C0B 000E0E0B
	s_cmpk_gt_i32 s28, 0x80                                    // 000000289218: B29C0080
	s_cselect_b32 s10, -1, 0                                   // 00000028921C: 980A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000289220: BF870009
	s_and_b32 vcc_lo, exec_lo, s10                             // 000000289224: 8B6A0A7E
	s_waitcnt vmcnt(3)                                         // 000000289228: BF890FF7
	v_bfe_u32 v15, v8, 16, 1                                   // 00000028922C: D610000F 02052108
	s_waitcnt vmcnt(1)                                         // 000000289234: BF8907F7
	v_bfe_u32 v17, v9, 16, 1                                   // 000000289238: D6100011 02052109
	s_waitcnt vmcnt(0)                                         // 000000289240: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 000000289244: D6100012 02052103
	v_add3_u32 v8, v8, v15, 0x7fff                             // 00000028924C: D6550008 03FE1F08 00007FFF
	v_bfe_u32 v15, v2, 16, 1                                   // 000000289258: D610000F 02052102
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000289260: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000028926C: BF870214
	v_add3_u32 v3, v3, v18, 0x7fff                             // 000000289270: D6550003 03FE2503 00007FFF
	.long 0x7e183988                                           // 00000028927C: 7E183988
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000289280: BF8701A4
	v_add3_u32 v2, v2, v15, 0x7fff                             // 000000289284: D6550002 03FE1F02 00007FFF
	.long 0xd7000308                                           // 000000289290: D7000308
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 000000289294: 02020813
	v_and_or_b32 v14, 0xffff0000, v9, v12                      // 000000289298: D657000E 043212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002892A4: BF870123
	.long 0x7e183982                                           // 0000002892A8: 7E183982
	v_add_co_ci_u32_e64 v9, null, s29, v5, s3                  // 0000002892AC: D5207C09 000E0A1D
	v_and_or_b32 v2, 0xffff0000, v3, v12                       // 0000002892B4: D6570002 043206FF FFFF0000
	ds_store_2addr_stride64_b32 v13, v14, v2 offset1:4         // 0000002892C0: D83C0400 00020E0D
	s_waitcnt lgkmcnt(0)                                       // 0000002892C8: BF89FC07
	s_barrier                                                  // 0000002892CC: BFBD0000
	buffer_gl0_inv                                             // 0000002892D0: E0AC0000 00000000
	s_cbranch_vccnz 215                                        // 0000002892D8: BFA400D7 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x538>
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v53, 0             // 0000002892DC: CA100080 24340080
	v_mov_b32_e32 v52, 0                                       // 0000002892E4: 7E680280
	s_and_saveexec_b32 s3, s2                                  // 0000002892E8: BE832002
	s_cbranch_execz 18                                         // 0000002892EC: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x238>
	v_lshlrev_b32_e32 v12, 1, v51                              // 0000002892F0: 30186681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002892F4: BF870091
	.long 0xd7006a02                                           // 0000002892F8: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 0000002892FC: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 000000289300: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289308: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000028930C: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289310: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 000000289314: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 00000028931C: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 000000289324: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 00000028932C: BF8903F7
	v_cvt_f32_f16_e32 v53, v2                                  // 000000289330: 7E6A1702
	v_cvt_f32_f16_e32 v52, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000289334: 7E681782
	s_or_b32 exec_lo, exec_lo, s3                              // 000000289338: 8C7E037E
	v_or_b32_e32 v2, 16, v51                                   // 00000028933C: 38046690
	v_mov_b32_e32 v37, 0                                       // 000000289340: 7E4A0280
	s_mov_b32 s2, exec_lo                                      // 000000289344: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000289348: BF870002
	.long 0xd4c4007e                                           // 00000028934C: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000289350: 0202041C
	s_cbranch_execz 18                                         // 000000289354: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x2a0>
	v_lshlrev_b32_e32 v12, 1, v2                               // 000000289358: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028935C: BF870091
	.long 0xd7006a02                                           // 000000289360: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000289364: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 000000289368: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289370: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 000000289374: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289378: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 00000028937C: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 000000289384: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 00000028938C: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 000000289394: BF8903F7
	v_cvt_f32_f16_e32 v36, v2                                  // 000000289398: 7E481702
	v_cvt_f32_f16_e32 v37, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000028939C: 7E4A1782
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002893A0: 8C7E027E
	v_or_b32_e32 v2, 32, v51                                   // 0000002893A4: 380466A0
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v38, 0             // 0000002893A8: CA100080 3B260080
	v_mov_b32_e32 v39, 0                                       // 0000002893B0: 7E4E0280
	s_mov_b32 s2, exec_lo                                      // 0000002893B4: BE82007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002893B8: BF870003
	.long 0xd4c4007e                                           // 0000002893BC: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000002893C0: 0202041C
	s_cbranch_execz 18                                         // 0000002893C4: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x310>
	v_lshlrev_b32_e32 v12, 1, v2                               // 0000002893C8: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002893CC: BF870091
	.long 0xd7006a02                                           // 0000002893D0: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 0000002893D4: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 0000002893D8: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 0000002893E0: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000002893E4: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002893E8: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 0000002893EC: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 0000002893F4: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 0000002893FC: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 000000289404: BF8903F7
	v_cvt_f32_f16_e32 v39, v2                                  // 000000289408: 7E4E1702
	v_cvt_f32_f16_e32 v38, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000028940C: 7E4C1782
	s_or_b32 exec_lo, exec_lo, s2                              // 000000289410: 8C7E027E
	v_or_b32_e32 v2, 48, v51                                   // 000000289414: 380466B0
	v_mov_b32_e32 v60, 0                                       // 000000289418: 7E780280
	s_mov_b32 s2, exec_lo                                      // 00000028941C: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000289420: BF870002
	.long 0xd4c4007e                                           // 000000289424: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000289428: 0202041C
	s_cbranch_execz 18                                         // 00000028942C: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x378>
	v_lshlrev_b32_e32 v12, 1, v2                               // 000000289430: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000289434: BF870091
	.long 0xd7006a02                                           // 000000289438: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 00000028943C: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 000000289440: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289448: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000028944C: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289450: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 000000289454: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 00000028945C: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 000000289464: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 00000028946C: BF8903F7
	v_cvt_f32_f16_e32 v59, v2                                  // 000000289470: 7E761702
	v_cvt_f32_f16_e32 v60, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000289474: 7E781782
	s_or_b32 exec_lo, exec_lo, s2                              // 000000289478: 8C7E027E
	v_or_b32_e32 v2, 64, v51                                   // 00000028947C: 380466C0
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 000000289480: CA100080 403E0080
	v_mov_b32_e32 v61, 0                                       // 000000289488: 7E7A0280
	s_mov_b32 s2, exec_lo                                      // 00000028948C: BE82007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000289490: BF870003
	.long 0xd4c4007e                                           // 000000289494: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000289498: 0202041C
	s_cbranch_execz 18                                         // 00000028949C: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x3e8>
	v_lshlrev_b32_e32 v12, 1, v2                               // 0000002894A0: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002894A4: BF870091
	.long 0xd7006a02                                           // 0000002894A8: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 0000002894AC: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 0000002894B0: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 0000002894B8: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 0000002894BC: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002894C0: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 0000002894C4: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 0000002894CC: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 0000002894D4: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 0000002894DC: BF8903F7
	v_cvt_f32_f16_e32 v63, v2                                  // 0000002894E0: 7E7E1702
	v_cvt_f32_f16_e32 v61, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000002894E4: 7E7A1782
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002894E8: 8C7E027E
	v_or_b32_e32 v2, 0x50, v51                                 // 0000002894EC: 380466FF 00000050
	v_mov_b32_e32 v68, 0                                       // 0000002894F4: 7E880280
	s_mov_b32 s2, exec_lo                                      // 0000002894F8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002894FC: BF870002
	.long 0xd4c4007e                                           // 000000289500: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000289504: 0202041C
	s_cbranch_execz 18                                         // 000000289508: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x454>
	v_lshlrev_b32_e32 v12, 1, v2                               // 00000028950C: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000289510: BF870091
	.long 0xd7006a02                                           // 000000289514: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000289518: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 00000028951C: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289524: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 000000289528: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 00000028952C: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 000000289530: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 000000289538: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 000000289540: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 000000289548: BF8903F7
	v_cvt_f32_f16_e32 v64, v2                                  // 00000028954C: 7E801702
	v_cvt_f32_f16_e32 v68, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000289550: 7E881782
	s_or_b32 exec_lo, exec_lo, s2                              // 000000289554: 8C7E027E
	v_or_b32_e32 v2, 0x60, v51                                 // 000000289558: 380466FF 00000060
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v71, 0             // 000000289560: CA100080 36460080
	v_mov_b32_e32 v70, 0                                       // 000000289568: 7E8C0280
	s_mov_b32 s2, exec_lo                                      // 00000028956C: BE82007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000289570: BF870003
	.long 0xd4c4007e                                           // 000000289574: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000289578: 0202041C
	s_cbranch_execz 18                                         // 00000028957C: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x4c8>
	v_lshlrev_b32_e32 v12, 1, v2                               // 000000289580: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000289584: BF870091
	.long 0xd7006a02                                           // 000000289588: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 00000028958C: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 000000289590: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289598: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000028959C: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002895A0: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 0000002895A4: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 0000002895AC: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 0000002895B4: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 0000002895BC: BF8903F7
	v_cvt_f32_f16_e32 v71, v2                                  // 0000002895C0: 7E8E1702
	v_cvt_f32_f16_e32 v70, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000002895C4: 7E8C1782
	s_or_b32 exec_lo, exec_lo, s2                              // 0000002895C8: 8C7E027E
	v_or_b32_e32 v2, 0x70, v51                                 // 0000002895CC: 380466FF 00000070
	v_mov_b32_e32 v55, 0                                       // 0000002895D4: 7E6E0280
	s_mov_b32 s2, exec_lo                                      // 0000002895D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002895DC: BF870002
	.long 0xd4c4007e                                           // 0000002895E0: D4C4007E
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 0000002895E4: 0202041C
	s_cbranch_execz 18                                         // 0000002895E8: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x534>
	v_lshlrev_b32_e32 v12, 1, v2                               // 0000002895EC: 30180481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002895F0: BF870091
	.long 0xd7006a02                                           // 0000002895F4: D7006A02
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 0000002895F8: 0202190A
	v_add_co_ci_u32_e64 v3, null, 0, v11, vcc_lo               // 0000002895FC: D5207C03 01AA1680
	.long 0xd7006a0c                                           // 000000289604: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 000000289608: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 00000028960C: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 000000289610: D5207C0D 01AA1280
	global_load_d16_b16 v2, v[2:3], off                        // 000000289618: DC820000 027C0002
	global_load_d16_hi_b16 v2, v[12:13], off                   // 000000289620: DC8E0000 027C000C
	s_waitcnt vmcnt(0)                                         // 000000289628: BF8903F7
	v_cvt_f32_f16_e32 v55, v2                                  // 00000028962C: 7E6E1702
	v_cvt_f32_f16_e32 v54, v130/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000289630: 7E6C1782
	s_or_b32 exec_lo, exec_lo, s2                              // 000000289634: 8C7E027E
	s_add_u32 s2, s4, s6                                       // 000000289638: 80020604
	s_addc_u32 s3, s5, s7                                      // 00000028963C: 82030705
	s_lshr_b32 s6, s25, 31                                     // 000000289640: 85069F19
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v75, 0             // 000000289644: CA100080 104A0080
	s_add_u32 s6, s24, s6                                      // 00000028964C: 80060618
	s_addc_u32 s7, s25, 0                                      // 000000289650: 82078019
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v17, 0             // 000000289654: CA100080 3A100080
	s_ashr_i64 s[6:7], s[6:7], 1                               // 00000028965C: 86868106
	s_add_u32 s14, s12, s14                                    // 000000289660: 800E0E0C
	s_addc_u32 s15, s13, s15                                   // 000000289664: 820F0F0D
	v_mad_u64_u32 v[42:43], null, v1, s6, s[2:3]               // 000000289668: D6FE7C2A 00080D01
	.long 0xd72c0002                                           // 000000289670: D72C0002
	v_cndmask_b32_e32 v0, v1, v7, vcc_lo                       // 000000289674: 02000F01
	.long 0xd72c0000                                           // 000000289678: D72C0000
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 00000028967C: 02000D00
	v_mad_u64_u32 v[44:45], null, v1, s6, s[14:15]             // 000000289680: D6FE7C2C 00380D01
	.long 0xd4440002                                           // 000000289688: D4440002
	v_cndmask_b32_e32 v1, s28, v51, vcc_lo                     // 00000028968C: 0202661C
	v_cndmask_b32_e64 v56, 0, 1, s10                           // 000000289690: D5010038 00290280
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v19, 0             // 000000289698: CA100080 4C120080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v1, 0              // 0000002896A0: CA100080 12000080
	v_add3_u32 v43, v0, v43, v2                                // 0000002896A8: D655002B 040A5700
	v_add3_u32 v57, v0, v45, v2                                // 0000002896B0: D6550039 040A5B00
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v3, 0               // 0000002896B8: CA100080 00020080
	v_mov_b32_e32 v2, 0                                        // 0000002896C0: 7E040280
	s_and_saveexec_b32 s3, s2                                  // 0000002896C4: BE832002
	s_cbranch_execz 37                                         // 0000002896C8: BFA50025 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x660>
	v_dual_mov_b32 v75, 0 :: v_dual_lshlrev_b32 v2, 4, v51     // 0000002896CC: CA220080 4B026684
	v_mov_b32_e32 v76, 0                                       // 0000002896D4: 7E980280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002896D8: BF870092
	.long 0xd7006a00                                           // 0000002896DC: D7006A00
	v_cndmask_b32_e32 v1, v42, v2, vcc_lo                      // 0000002896E0: 0202052A
	v_add_co_ci_u32_e64 v1, null, 0, v43, vcc_lo               // 0000002896E4: D5207C01 01AA5680
	.long 0xd7006a0c                                           // 0000002896EC: D7006A0C
	v_cndmask_b32_e32 v1, v44, v2, vcc_lo                      // 0000002896F0: 0202052C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002896F4: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v57, vcc_lo              // 0000002896F8: D5207C0D 01AA7280
	global_load_b128 v[0:3], v[0:1], off                       // 000000289700: DC5E0000 007C0000
	global_load_b128 v[16:19], v[12:13], off                   // 000000289708: DC5E0000 107C000C
	s_and_not1_b32 vcc_lo, exec_lo, s10                        // 000000289710: 916A0A7E
	s_cbranch_vccnz 18                                         // 000000289714: BFA40012 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x660>
	v_lshlrev_b32_e32 v12, 1, v51                              // 000000289718: 30186681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028971C: BF870091
	.long 0xd7006a0a                                           // 000000289720: D7006A0A
	v_cndmask_b32_e32 v1, v10, v12, vcc_lo                     // 000000289724: 0202190A
	v_add_co_ci_u32_e64 v11, null, 0, v11, vcc_lo              // 000000289728: D5207C0B 01AA1680
	.long 0xd7006a0c                                           // 000000289730: D7006A0C
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 000000289734: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289738: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v9, vcc_lo               // 00000028973C: D5207C0D 01AA1280
	global_load_d16_b16 v8, v[10:11], off                      // 000000289744: DC820000 087C000A
	global_load_d16_hi_b16 v8, v[12:13], off                   // 00000028974C: DC8E0000 087C000C
	s_waitcnt vmcnt(0)                                         // 000000289754: BF8903F7
	v_cvt_f32_f16_e32 v76, v8                                  // 000000289758: 7E981708
	v_cvt_f32_f16_e32 v75, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000028975C: 7E961788
	s_or_b32 exec_lo, exec_lo, s3                              // 000000289760: 8C7E037E
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v66, 0             // 000000289764: CA100080 41420080
	v_mov_b32_e32 v67, 0                                       // 00000028976C: 7E860280
	s_and_saveexec_b32 s3, s2                                  // 000000289770: BE832002
	s_cbranch_execz 532                                        // 000000289774: BFA50214 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xec8>
	.long 0xd7006a06                                           // 000000289778: D7006A06
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 00000028977C: 02020C08
	v_dual_mov_b32 v69, v51 :: v_dual_lshlrev_b32 v8, 1, v51   // 000000289780: CA220133 45086681
	v_add_co_ci_u32_e64 v7, null, s9, v7, vcc_lo               // 000000289788: D5207C07 01AA0E09
	.long 0xd7006a04                                           // 000000289790: D7006A04
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 000000289794: 02020810
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000289798: BF870211
	v_add_co_ci_u32_e64 v5, null, s17, v5, vcc_lo              // 00000028979C: D5207C05 01AA0A11
	.long 0xd7006a06                                           // 0000002897A4: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 0000002897A8: 02021106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002897AC: BF870211
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000002897B0: D5207C07 01AA0E80
	.long 0xd7006a04                                           // 0000002897B8: D7006A04
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                       // 0000002897BC: 02021104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002897C0: BF870211
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002897C4: D5207C05 01AA0A80
	.long 0xd7006a06                                           // 0000002897CC: D7006A06
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000002897D0: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002897D4: BF870211
	v_add_co_ci_u32_e64 v7, null, s5, v7, vcc_lo               // 0000002897D8: D5207C07 01AA0E05
	.long 0xd7006a04                                           // 0000002897E0: D7006A04
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000002897E4: 0202080C
	v_dual_mov_b32 v46, 0 :: v_dual_lshlrev_b32 v45, 5, v51    // 0000002897E8: CA220080 2E2C6685
	v_add_co_ci_u32_e64 v5, null, s13, v5, vcc_lo              // 0000002897F0: D5207C05 01AA0A0D
	.long 0xd7006a2f                                           // 0000002897F8: D7006A2F
	v_cndmask_b32_e32 v0, v6, v160, vcc_lo                     // 0000002897FC: 02014106
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289800: BF870001
	v_add_co_ci_u32_e64 v48, null, 0, v7, vcc_lo               // 000000289804: D5207C30 01AA0E80
	.long 0xd7006a31                                           // 00000028980C: D7006A31
	v_cndmask_b32_e32 v0, v4, v160, vcc_lo                     // 000000289810: 02014104
	v_lshl_or_b32 v62, v51, 4, 0x100                           // 000000289814: D656003E 03FD0933 00000100
	v_add_co_ci_u32_e64 v50, null, 0, v5, vcc_lo               // 000000289820: D5207C32 01AA0A80
	v_mov_b32_e32 v65, v46                                     // 000000289828: 7E82032E
	v_mov_b32_e32 v58, v46                                     // 00000028982C: 7E74032E
	v_mov_b32_e32 v67, v46                                     // 000000289830: 7E86032E
	v_mov_b32_e32 v66, v46                                     // 000000289834: 7E84032E
	s_mov_b32 s6, 0                                            // 000000289838: BE860080
	s_lshl_b64 s[4:5], s[24:25], 1                             // 00000028983C: 84848118
	s_branch 405                                               // 000000289840: BFA00195 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xd98>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000289844: 8C7E077E
	.long 0xd73c0008                                           // 000000289848: D73C0008
	v_cndmask_b32_e32 v1, 1, v45, vcc_lo                       // 00000028984C: 02025A81
	v_and_b32_e32 v99, 0xff, v0                                // 000000289850: 36C600FF 000000FF
	v_and_b32_e32 v100, 0xff, v16                              // 000000289858: 36C820FF 000000FF
	v_lshrrev_b32_e32 v101, 6, v0                              // 000000289860: 32CA0086
	v_dual_mov_b32 v71, v77 :: v_dual_and_b32 v106, 0xff, v17  // 000000289864: CA24014D 476A22FF 000000FF
	.long 0xd7006a08                                           // 000000289870: D7006A08
	v_cndmask_b32_e32 v1, s20, v8, vcc_lo                      // 000000289874: 02021014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000289878: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s21, v9, vcc_lo              // 00000028987C: D5207C09 01AA1215
	v_dual_mov_b32 v63, v79 :: v_dual_and_b32 v112, 0xff, v2   // 000000289884: CA24014F 3F7004FF 000000FF
	.long 0xd7006a0a                                           // 000000289890: D7006A0A
	v_cndmask_b32_e32 v0, v8, v4, vcc_lo                       // 000000289894: 02000908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000289898: BF870001
	v_add_co_ci_u32_e64 v11, null, s5, v9, vcc_lo              // 00000028989C: D5207C0B 01AA1205
	v_lshrrev_b32_e32 v114, 6, v2                              // 0000002898A4: 32E40486
	s_clause 0x7                                               // 0000002898A8: BF850007
	global_load_b128 v[91:94], v[8:9], off                     // 0000002898AC: DC5E0000 5B7C0008
	global_load_b128 v[95:98], v[10:11], off                   // 0000002898B4: DC5E0000 5F7C000A
	global_load_b128 v[32:35], v[8:9], off offset:16           // 0000002898BC: DC5E0010 207C0008
	global_load_b128 v[28:31], v[10:11], off offset:16         // 0000002898C4: DC5E0010 1C7C000A
	global_load_b128 v[24:27], v[8:9], off offset:32           // 0000002898CC: DC5E0020 187C0008
	global_load_b128 v[20:23], v[10:11], off offset:32         // 0000002898D4: DC5E0020 147C000A
	global_load_b128 v[12:15], v[8:9], off offset:48           // 0000002898DC: DC5E0030 0C7C0008
	global_load_b128 v[8:11], v[10:11], off offset:48          // 0000002898E4: DC5E0030 087C000A
	v_lshrrev_b32_e32 v116, 14, v2                             // 0000002898EC: 32E8048E
	v_lshrrev_b32_e32 v118, 22, v2                             // 0000002898F0: 32EC0496
	s_waitcnt vmcnt(9)                                         // 0000002898F4: BF8927F7
	v_dual_mov_b32 v2, v38 :: v_dual_lshlrev_b32 v77, 2, v99   // 0000002898F8: CA220126 024CC682
	v_lshrrev_b32_e32 v102, 6, v16                             // 000000289900: 32CC2086
	v_dual_mov_b32 v64, v78 :: v_dual_and_b32 v119, 0xff, v3   // 000000289904: CA24014E 407606FF 000000FF
	v_lshrrev_b32_e32 v120, 6, v3                              // 000000289910: 32F00686
	v_lshrrev_b32_e32 v121, 14, v3                             // 000000289914: 32F2068E
	v_lshrrev_b32_e32 v122, 22, v3                             // 000000289918: 32F40696
	v_dual_mov_b32 v3, v39 :: v_dual_lshlrev_b32 v78, 2, v100  // 00000028991C: CA220127 034EC882
	v_lshrrev_b32_e32 v103, 14, v0                             // 000000289924: 32CE008E
	v_and_b32_e32 v79, 0x3fc, v101                             // 000000289928: 369ECAFF 000003FC
	ds_load_b32 v77, v77                                       // 000000289930: D8D80000 4D00004D
	ds_load_b32 v78, v78 offset:1024                           // 000000289938: D8D80400 4E00004E
	v_lshrrev_b32_e32 v104, 14, v16                            // 000000289940: 32D0208E
	v_dual_mov_b32 v59, v80 :: v_dual_add_nc_u32 v62, 0x100, v62// 000000289944: CA200150 3B3E7CFF 00000100
	v_and_b32_e32 v80, 0x3fc, v102                             // 000000289950: 36A0CCFF 000003FC
	v_lshrrev_b32_e32 v105, 22, v0                             // 000000289958: 32D20096
	v_dual_mov_b32 v39, v81 :: v_dual_mov_b32 v60, v87         // 00000028995C: CA100151 273C0157
	v_and_b32_e32 v81, 0x3fc, v103                             // 000000289964: 36A2CEFF 000003FC
	ds_load_b32 v79, v79                                       // 00000028996C: D8D80000 4F00004F
	ds_load_b32 v80, v80 offset:1024                           // 000000289974: D8D80400 50000050
	v_lshrrev_b32_e32 v16, 22, v16                             // 00000028997C: 32202096
	v_cndmask_b32_e64 v75, v75, v52, s1                        // 000000289980: D501004B 0006694B
	v_dual_mov_b32 v0, v36 :: v_dual_and_b32 v113, 0xff, v18   // 000000289988: CA240124 007024FF 000000FF
	v_dual_mov_b32 v36, v82 :: v_dual_and_b32 v123, 0xff, v19  // 000000289994: CA240152 247A26FF 000000FF
	v_and_b32_e32 v82, 0x3fc, v104                             // 0000002899A0: 36A4D0FF 000003FC
	v_cndmask_b32_e64 v74, v76, v53, s1                        // 0000002899A8: D501004A 00066B4C
	v_dual_mov_b32 v53, v83 :: v_dual_and_b32 v76, 0xff, v1    // 0000002899B0: CA240153 354C02FF 000000FF
	v_dual_mov_b32 v68, v85 :: v_dual_and_b32 v83, 0x3fc, v105 // 0000002899BC: CA240155 4452D2FF 000003FC
	ds_load_b32 v81, v81                                       // 0000002899C8: D8D80000 51000051
	ds_load_b32 v82, v82 offset:1024                           // 0000002899D0: D8D80400 52000052
	v_and_b32_e32 v16, 0x3fc, v16                              // 0000002899D8: 362020FF 000003FC
	v_lshrrev_b32_e32 v107, 6, v1                              // 0000002899E0: 32D60286
	v_lshrrev_b32_e32 v109, 14, v1                             // 0000002899E4: 32DA028E
	v_lshrrev_b32_e32 v111, 22, v1                             // 0000002899E8: 32DE0296
	v_dual_mov_b32 v1, v37 :: v_dual_lshlrev_b32 v76, 2, v76   // 0000002899EC: CA220125 014C9882
	ds_load_b32 v83, v83                                       // 0000002899F4: D8D80000 53000053
	ds_load_b32 v16, v16 offset:1024                           // 0000002899FC: D8D80400 10000010
	v_lshrrev_b32_e32 v108, 6, v17                             // 000000289A04: 32D82286
	v_dual_mov_b32 v70, v84 :: v_dual_add_nc_u32 v45, 0x200, v45// 000000289A08: CA200154 462C5AFF 00000200
	v_dual_mov_b32 v37, v89 :: v_dual_lshlrev_b32 v84, 2, v106 // 000000289A14: CA220159 2554D482
	v_dual_mov_b32 v52, v90 :: v_dual_and_b32 v85, 0x3fc, v107 // 000000289A1C: CA24015A 3454D6FF 000003FC
	v_lshlrev_b32_e32 v90, 2, v112                             // 000000289A28: 30B4E082
	ds_load_b32 v76, v76                                       // 000000289A2C: D8D80000 4C00004C
	ds_load_b32 v84, v84 offset:1024                           // 000000289A34: D8D80400 54000054
	v_lshrrev_b32_e32 v110, 14, v17                            // 000000289A3C: 32DC228E
	v_dual_mov_b32 v61, v86 :: v_dual_mov_b32 v38, v88         // 000000289A40: CA100156 3D260158
	v_and_b32_e32 v86, 0x3fc, v108                             // 000000289A48: 36ACD8FF 000003FC
	v_and_b32_e32 v87, 0x3fc, v109                             // 000000289A50: 36AEDAFF 000003FC
	v_lshrrev_b32_e32 v17, 22, v17                             // 000000289A58: 32222296
	v_and_b32_e32 v88, 0x3fc, v110                             // 000000289A5C: 36B0DCFF 000003FC
	v_and_b32_e32 v89, 0x3fc, v111                             // 000000289A64: 36B2DEFF 000003FC
	v_lshrrev_b32_e32 v115, 6, v18                             // 000000289A6C: 32E62486
	v_lshlrev_b32_e32 v99, 2, v113                             // 000000289A70: 30C6E282
	v_and_b32_e32 v17, 0x3fc, v17                              // 000000289A74: 362222FF 000003FC
	v_and_b32_e32 v100, 0x3fc, v114                            // 000000289A7C: 36C8E4FF 000003FC
	v_lshrrev_b32_e32 v117, 14, v18                            // 000000289A84: 32EA248E
	v_and_b32_e32 v101, 0x3fc, v115                            // 000000289A88: 36CAE6FF 000003FC
	v_and_b32_e32 v102, 0x3fc, v116                            // 000000289A90: 36CCE8FF 000003FC
	v_lshrrev_b32_e32 v18, 22, v18                             // 000000289A98: 32242496
	v_and_b32_e32 v104, 0x3fc, v118                            // 000000289A9C: 36D0ECFF 000003FC
	v_and_b32_e32 v103, 0x3fc, v117                            // 000000289AA4: 36CEEAFF 000003FC
	v_lshlrev_b32_e32 v105, 2, v119                            // 000000289AAC: 30D2EE82
	v_lshlrev_b32_e32 v106, 2, v123                            // 000000289AB0: 30D4F682
	v_and_b32_e32 v18, 0x3fc, v18                              // 000000289AB4: 362424FF 000003FC
	v_lshrrev_b32_e32 v124, 6, v19                             // 000000289ABC: 32F82686
	v_lshrrev_b32_e32 v125, 14, v19                            // 000000289AC0: 32FA268E
	v_and_b32_e32 v107, 0x3fc, v120                            // 000000289AC4: 36D6F0FF 000003FC
	v_and_b32_e32 v109, 0x3fc, v121                            // 000000289ACC: 36DAF2FF 000003FC
	v_lshrrev_b32_e32 v19, 22, v19                             // 000000289AD4: 32262696
	v_and_b32_e32 v108, 0x3fc, v124                            // 000000289AD8: 36D8F8FF 000003FC
	v_and_b32_e32 v110, 0x3fc, v125                            // 000000289AE0: 36DCFAFF 000003FC
	v_and_b32_e32 v111, 0x3fc, v122                            // 000000289AE8: 36DEF4FF 000003FC
	.long 0xd7006a2f                                           // 000000289AF0: D7006A2F
	v_cndmask_b32_e32 v0, v47, v160, vcc_lo                    // 000000289AF4: 0201412F
	v_and_b32_e32 v19, 0x3fc, v19                              // 000000289AF8: 362626FF 000003FC
	v_add_co_ci_u32_e64 v48, null, 0, v48, vcc_lo              // 000000289B00: D5207C30 01AA6080
	.long 0xd7006a31                                           // 000000289B08: D7006A31
	v_cndmask_b32_e32 v0, v49, v160, vcc_lo                    // 000000289B0C: 02014131
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000289B10: BF8704A1
	v_add_co_ci_u32_e64 v50, null, 0, v50, vcc_lo              // 000000289B14: D5207C32 01AA6480
	s_and_b32 s2, exec_lo, s2                                  // 000000289B1C: 8B02027E
	s_or_b32 s6, s2, s6                                        // 000000289B20: 8C060602
	s_waitcnt vmcnt(7) lgkmcnt(9)                              // 000000289B24: BF891C97
	v_dot2_f32_bf16 v112, v91, v77, 0                          // 000000289B28: CC1A4070 1A029B5B
	s_waitcnt lgkmcnt(8)                                       // 000000289B30: BF89FC87
	v_dot2_f32_bf16 v91, v91, v78, 0                           // 000000289B34: CC1A405B 1A029D5B
	s_waitcnt vmcnt(6)                                         // 000000289B3C: BF891BF7
	v_dot2_f32_bf16 v77, v95, v77, 0                           // 000000289B40: CC1A404D 1A029B5F
	v_dot2_f32_bf16 v78, v95, v78, 0                           // 000000289B48: CC1A404E 1A029D5F
	s_waitcnt lgkmcnt(7)                                       // 000000289B50: BF89FC77
	v_dot2_f32_bf16 v95, v92, v79, v112                        // 000000289B54: CC1A405F 1DC29F5C
	s_waitcnt lgkmcnt(6)                                       // 000000289B5C: BF89FC67
	v_dot2_f32_bf16 v91, v92, v80, v91                         // 000000289B60: CC1A405B 1D6EA15C
	v_dot2_f32_bf16 v77, v96, v79, v77                         // 000000289B68: CC1A404D 1D369F60
	v_dot2_f32_bf16 v78, v96, v80, v78                         // 000000289B70: CC1A404E 1D3AA160
	ds_load_b32 v79, v85                                       // 000000289B78: D8D80000 4F000055
	ds_load_b32 v80, v86 offset:1024                           // 000000289B80: D8D80400 50000056
	s_waitcnt lgkmcnt(7)                                       // 000000289B88: BF89FC77
	v_dot2_f32_bf16 v85, v93, v81, v95                         // 000000289B8C: CC1A4055 1D7EA35D
	s_waitcnt lgkmcnt(6)                                       // 000000289B94: BF89FC67
	v_dot2_f32_bf16 v86, v93, v82, v91                         // 000000289B98: CC1A4056 1D6EA55D
	v_dot2_f32_bf16 v77, v97, v81, v77                         // 000000289BA0: CC1A404D 1D36A361
	v_dot2_f32_bf16 v78, v97, v82, v78                         // 000000289BA8: CC1A404E 1D3AA561
	ds_load_b32 v81, v87                                       // 000000289BB0: D8D80000 51000057
	ds_load_b32 v82, v88 offset:1024                           // 000000289BB8: D8D80400 52000058
	s_waitcnt lgkmcnt(7)                                       // 000000289BC0: BF89FC77
	v_dot2_f32_bf16 v85, v94, v83, v85                         // 000000289BC4: CC1A4055 1D56A75E
	s_waitcnt lgkmcnt(6)                                       // 000000289BCC: BF89FC67
	v_dot2_f32_bf16 v86, v94, v16, v86                         // 000000289BD0: CC1A4056 1D5A215E
	v_dot2_f32_bf16 v77, v98, v83, v77                         // 000000289BD8: CC1A404D 1D36A762
	v_dot2_f32_bf16 v16, v98, v16, v78                         // 000000289BE0: CC1A4010 1D3A2162
	ds_load_b32 v78, v89                                       // 000000289BE8: D8D80000 4E000059
	ds_load_b32 v17, v17 offset:1024                           // 000000289BF0: D8D80400 11000011
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000289BF8: BF891477
	v_dot2_f32_bf16 v83, v32, v76, v85                         // 000000289BFC: CC1A4053 1D569920
	s_waitcnt lgkmcnt(6)                                       // 000000289C04: BF89FC67
	v_dot2_f32_bf16 v32, v32, v84, v86                         // 000000289C08: CC1A4020 1D5AA920
	s_waitcnt vmcnt(4)                                         // 000000289C10: BF8913F7
	v_dot2_f32_bf16 v76, v28, v76, v77                         // 000000289C14: CC1A404C 1D36991C
	v_dot2_f32_bf16 v16, v28, v84, v16                         // 000000289C1C: CC1A4010 1C42A91C
	ds_load_b32 v28, v90                                       // 000000289C24: D8D80000 1C00005A
	ds_load_b32 v77, v99 offset:1024                           // 000000289C2C: D8D80400 4D000063
	s_waitcnt lgkmcnt(7)                                       // 000000289C34: BF89FC77
	v_dot2_f32_bf16 v83, v33, v79, v83                         // 000000289C38: CC1A4053 1D4E9F21
	s_waitcnt lgkmcnt(6)                                       // 000000289C40: BF89FC67
	v_dot2_f32_bf16 v32, v33, v80, v32                         // 000000289C44: CC1A4020 1C82A121
	v_dot2_f32_bf16 v33, v29, v79, v76                         // 000000289C4C: CC1A4021 1D329F1D
	v_dot2_f32_bf16 v16, v29, v80, v16                         // 000000289C54: CC1A4010 1C42A11D
	ds_load_b32 v29, v100                                      // 000000289C5C: D8D80000 1D000064
	ds_load_b32 v76, v101 offset:1024                          // 000000289C64: D8D80400 4C000065
	s_waitcnt lgkmcnt(7)                                       // 000000289C6C: BF89FC77
	v_dot2_f32_bf16 v79, v34, v81, v83                         // 000000289C70: CC1A404F 1D4EA322
	s_waitcnt lgkmcnt(6)                                       // 000000289C78: BF89FC67
	v_dot2_f32_bf16 v32, v34, v82, v32                         // 000000289C7C: CC1A4020 1C82A522
	v_dot2_f32_bf16 v33, v30, v81, v33                         // 000000289C84: CC1A4021 1C86A31E
	v_dot2_f32_bf16 v16, v30, v82, v16                         // 000000289C8C: CC1A4010 1C42A51E
	ds_load_b32 v30, v102                                      // 000000289C94: D8D80000 1E000066
	ds_load_b32 v34, v103 offset:1024                          // 000000289C9C: D8D80400 22000067
	s_waitcnt lgkmcnt(7)                                       // 000000289CA4: BF89FC77
	v_dot2_f32_bf16 v79, v35, v78, v79                         // 000000289CA8: CC1A404F 1D3E9D23
	s_waitcnt lgkmcnt(6)                                       // 000000289CB0: BF89FC67
	v_dot2_f32_bf16 v32, v35, v17, v32                         // 000000289CB4: CC1A4020 1C822323
	v_dot2_f32_bf16 v33, v31, v78, v33                         // 000000289CBC: CC1A4021 1C869D1F
	v_dot2_f32_bf16 v16, v31, v17, v16                         // 000000289CC4: CC1A4010 1C42231F
	ds_load_b32 v17, v104                                      // 000000289CCC: D8D80000 11000068
	ds_load_b32 v18, v18 offset:1024                           // 000000289CD4: D8D80400 12000012
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000289CDC: BF890C77
	v_dot2_f32_bf16 v31, v24, v28, v79                         // 000000289CE0: CC1A401F 1D3E3918
	s_waitcnt lgkmcnt(6)                                       // 000000289CE8: BF89FC67
	v_dot2_f32_bf16 v24, v24, v77, v32                         // 000000289CEC: CC1A4018 1C829B18
	s_waitcnt vmcnt(2)                                         // 000000289CF4: BF890BF7
	v_dot2_f32_bf16 v28, v20, v28, v33                         // 000000289CF8: CC1A401C 1C863914
	v_dot2_f32_bf16 v16, v20, v77, v16                         // 000000289D00: CC1A4010 1C429B14
	ds_load_b32 v20, v105                                      // 000000289D08: D8D80000 14000069
	ds_load_b32 v32, v106 offset:1024                          // 000000289D10: D8D80400 2000006A
	s_waitcnt lgkmcnt(7)                                       // 000000289D18: BF89FC77
	v_dot2_f32_bf16 v31, v25, v29, v31                         // 000000289D1C: CC1A401F 1C7E3B19
	s_waitcnt lgkmcnt(6)                                       // 000000289D24: BF89FC67
	v_dot2_f32_bf16 v24, v25, v76, v24                         // 000000289D28: CC1A4018 1C629919
	v_dot2_f32_bf16 v25, v21, v29, v28                         // 000000289D30: CC1A4019 1C723B15
	v_dot2_f32_bf16 v16, v21, v76, v16                         // 000000289D38: CC1A4010 1C429915
	ds_load_b32 v21, v107                                      // 000000289D40: D8D80000 1500006B
	ds_load_b32 v28, v108 offset:1024                          // 000000289D48: D8D80400 1C00006C
	ds_load_b32 v29, v109                                      // 000000289D50: D8D80000 1D00006D
	ds_load_b32 v33, v110 offset:1024                          // 000000289D58: D8D80400 2100006E
	s_waitcnt lgkmcnt(9)                                       // 000000289D60: BF89FC97
	v_dot2_f32_bf16 v31, v26, v30, v31                         // 000000289D64: CC1A401F 1C7E3D1A
	s_waitcnt lgkmcnt(8)                                       // 000000289D6C: BF89FC87
	v_dot2_f32_bf16 v24, v26, v34, v24                         // 000000289D70: CC1A4018 1C62451A
	v_dot2_f32_bf16 v25, v22, v30, v25                         // 000000289D78: CC1A4019 1C663D16
	v_dot2_f32_bf16 v16, v22, v34, v16                         // 000000289D80: CC1A4010 1C424516
	ds_load_b32 v22, v111                                      // 000000289D88: D8D80000 1600006F
	ds_load_b32 v26, v19 offset:1024                           // 000000289D90: D8D80400 1A000013
	s_waitcnt lgkmcnt(9)                                       // 000000289D98: BF89FC97
	v_dot2_f32_bf16 v30, v27, v17, v31                         // 000000289D9C: CC1A401E 1C7E231B
	s_waitcnt lgkmcnt(8)                                       // 000000289DA4: BF89FC87
	v_dot2_f32_bf16 v24, v27, v18, v24                         // 000000289DA8: CC1A4018 1C62251B
	v_dot2_f32_bf16 v17, v23, v17, v25                         // 000000289DB0: CC1A4011 1C662317
	v_dot2_f32_bf16 v16, v23, v18, v16                         // 000000289DB8: CC1A4010 1C422517
	v_mov_b32_e32 v19, v7                                      // 000000289DC0: 7E260307
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000289DC4: BF890477
	v_dot2_f32_bf16 v7, v12, v20, v30                          // 000000289DC8: CC1A4007 1C7A290C
	s_waitcnt lgkmcnt(6)                                       // 000000289DD0: BF89FC67
	v_dot2_f32_bf16 v12, v12, v32, v24                         // 000000289DD4: CC1A400C 1C62410C
	s_waitcnt vmcnt(0)                                         // 000000289DDC: BF8903F7
	v_dot2_f32_bf16 v17, v8, v20, v17                          // 000000289DE0: CC1A4011 1C462908
	v_dot2_f32_bf16 v8, v8, v32, v16                           // 000000289DE8: CC1A4008 1C424108
	v_mov_b32_e32 v18, v6                                      // 000000289DF0: 7E240306
	v_mov_b32_e32 v16, v4                                      // 000000289DF4: 7E200304
	s_waitcnt lgkmcnt(5)                                       // 000000289DF8: BF89FC57
	v_dot2_f32_bf16 v6, v13, v21, v7                           // 000000289DFC: CC1A4006 1C1E2B0D
	s_waitcnt lgkmcnt(4)                                       // 000000289E04: BF89FC47
	v_dot2_f32_bf16 v7, v13, v28, v12                          // 000000289E08: CC1A4007 1C32390D
	v_dot2_f32_bf16 v12, v9, v21, v17                          // 000000289E10: CC1A400C 1C462B09
	v_dot2_f32_bf16 v8, v9, v28, v8                            // 000000289E18: CC1A4008 1C223909
	v_mov_b32_e32 v17, v5                                      // 000000289E20: 7E220305
	s_waitcnt lgkmcnt(3)                                       // 000000289E24: BF89FC37
	v_dot2_f32_bf16 v5, v14, v29, v6                           // 000000289E28: CC1A4005 1C1A3B0E
	s_waitcnt lgkmcnt(2)                                       // 000000289E30: BF89FC27
	v_dot2_f32_bf16 v6, v14, v33, v7                           // 000000289E34: CC1A4006 1C1E430E
	v_dot2_f32_bf16 v7, v10, v29, v12                          // 000000289E3C: CC1A4007 1C323B0A
	v_dot2_f32_bf16 v8, v10, v33, v8                           // 000000289E44: CC1A4008 1C22430A
	v_mov_b32_e32 v76, v73                                     // 000000289E4C: 7E980349
	s_waitcnt lgkmcnt(1)                                       // 000000289E50: BF89FC17
	v_dot2_f32_bf16 v4, v15, v22, v5                           // 000000289E54: CC1A4004 1C162D0F
	s_waitcnt lgkmcnt(0)                                       // 000000289E5C: BF89FC07
	v_dot2_f32_bf16 v5, v15, v26, v6                           // 000000289E60: CC1A4005 1C1A350F
	v_dot2_f32_bf16 v6, v11, v22, v7                           // 000000289E68: CC1A4006 1C1E2D0B
	v_dot2_f32_bf16 v7, v11, v26, v8                           // 000000289E70: CC1A4007 1C22350B
	v_fmac_f32_e32 v67, v74, v4                                // 000000289E78: 5686094A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000289E7C: BF870193
	v_dual_fmac_f32 v65, v75, v5 :: v_dual_fmac_f32 v66, v74, v6// 000000289E80: C8000B4B 41420D4A
	v_dual_fmac_f32 v58, v75, v7 :: v_dual_mov_b32 v75, v72    // 000000289E88: C8100F4B 3A4A0148
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000289E90: 917E067E
	s_cbranch_execz 75                                         // 000000289E94: BFA5004B <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xec4>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000289E98: 916A017E
	s_cbranch_vccnz 15                                         // 000000289E9C: BFA4000F <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xddc>
	v_dual_mov_b32 v77, v55 :: v_dual_mov_b32 v84, v54         // 000000289EA0: CA100137 4D540136
	v_dual_mov_b32 v78, v71 :: v_dual_mov_b32 v79, v64         // 000000289EA8: CA100147 4E4E0140
	v_dual_mov_b32 v80, v63 :: v_dual_mov_b32 v83, v36         // 000000289EB0: CA10013F 50520124
	v_dual_mov_b32 v81, v59 :: v_dual_mov_b32 v86, v68         // 000000289EB8: CA10013B 51560144
	v_dual_mov_b32 v82, v39 :: v_dual_mov_b32 v85, v70         // 000000289EC0: CA100127 52540146
	v_dual_mov_b32 v87, v61 :: v_dual_mov_b32 v88, v60         // 000000289EC8: CA10013D 5758013C
	v_dual_mov_b32 v89, v38 :: v_dual_mov_b32 v90, v37         // 000000289ED0: CA100126 595A0125
	s_branch 14                                                // 000000289ED8: BFA0000E <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0xe14>
	v_dual_mov_b32 v77, v71 :: v_dual_mov_b32 v78, v64         // 000000289EDC: CA100147 4D4E0140
	v_dual_mov_b32 v79, v63 :: v_dual_mov_b32 v82, v36         // 000000289EE4: CA10013F 4F520124
	v_dual_mov_b32 v80, v59 :: v_dual_mov_b32 v83, v53         // 000000289EEC: CA10013B 50520135
	v_dual_mov_b32 v81, v39 :: v_dual_mov_b32 v84, v70         // 000000289EF4: CA100127 51540146
	v_dual_mov_b32 v85, v68 :: v_dual_mov_b32 v86, v61         // 000000289EFC: CA100144 5556013D
	v_dual_mov_b32 v87, v60 :: v_dual_mov_b32 v88, v38         // 000000289F04: CA10013C 57580126
	v_dual_mov_b32 v89, v37 :: v_dual_mov_b32 v90, v52         // 000000289F0C: CA100125 595A0134
	v_dual_mov_b32 v72, v75 :: v_dual_add_nc_u32 v69, 16, v69  // 000000289F14: CA20014B 48448A90
	s_waitcnt vmcnt(0)                                         // 000000289F1C: BF8903F7
	v_dual_mov_b32 v73, v76 :: v_dual_mov_b32 v6, v18          // 000000289F20: CA10014C 49060112
	v_dual_mov_b32 v4, v16 :: v_dual_mov_b32 v5, v17           // 000000289F28: CA100110 04040111
	s_delay_alu instid0(VALU_DEP_3)                            // 000000289F30: BF870003
	.long 0xd4430002                                           // 000000289F34: D4430002
	v_cndmask_b32_e32 v1, s28, v69, vcc_lo                     // 000000289F38: 02028A1C
	v_dual_mov_b32 v7, v19 :: v_dual_mov_b32 v36, v0           // 000000289F3C: CA100113 07240100
	v_dual_mov_b32 v37, v1 :: v_dual_mov_b32 v38, v2           // 000000289F44: CA100101 25260102
	v_mov_b32_e32 v39, v3                                      // 000000289F4C: 7E4E0303
	s_mov_b32 s7, exec_lo                                      // 000000289F50: BE87007E
	.long 0xd4c4007e                                           // 000000289F54: D4C4007E
	v_cndmask_b32_e32 v1, s28, v69, vcc_lo                     // 000000289F58: 02028A1C
	s_cbranch_execz 65081                                      // 000000289F5C: BFA5FE39 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x744>
	.long 0xd7006a04                                           // 000000289F60: D7006A04
	v_cndmask_b32_e32 v1, v42, v62, vcc_lo                     // 000000289F64: 02027D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000289F68: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v43, vcc_lo               // 000000289F6C: D5207C05 01AA5680
	.long 0xd7006a06                                           // 000000289F74: D7006A06
	v_cndmask_b32_e32 v1, v44, v62, vcc_lo                     // 000000289F78: 02027D2C
	v_add_co_ci_u32_e64 v7, null, 0, v57, vcc_lo               // 000000289F7C: D5207C07 01AA7280
	global_load_b128 v[36:39], v[4:5], off                     // 000000289F84: DC5E0000 247C0004
	global_load_b128 v[4:7], v[6:7], off                       // 000000289F8C: DC5E0000 047C0006
	v_cmp_ne_u32_e32 vcc_lo, 1, v56                            // 000000289F94: 7C9A7081
	v_dual_mov_b32 v73, v76 :: v_dual_mov_b32 v72, v75         // 000000289F98: CA10014C 4948014B
	s_cbranch_vccnz 65064                                      // 000000289FA0: BFA4FE28 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x744>
	global_load_d16_b16 v8, v[47:48], off                      // 000000289FA4: DC820000 087C002F
	global_load_d16_hi_b16 v8, v[49:50], off                   // 000000289FAC: DC8E0000 087C0031
	s_waitcnt vmcnt(0)                                         // 000000289FB4: BF8903F7
	v_cvt_f32_f16_e32 v73, v8                                  // 000000289FB8: 7E921708
	v_cvt_f32_f16_e32 v72, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000289FBC: 7E901788
	s_branch 65056                                             // 000000289FC0: BFA0FE20 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x744>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000289FC4: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000289FC8: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000289FCC: 8C7E037E
	s_waitcnt vmcnt(1)                                         // 000000289FD0: BF8907F7
	.long 0xd71f0000                                           // 000000289FD4: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000289FD8: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000289FDC: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 000000289FE0: 3A0A0084
	v_xor_b32_e32 v9, 2, v0                                    // 000000289FE4: 3A120082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000289FE8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000289FEC: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000289FF0: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000289FF4: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000289FF8: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000289FFC: 30020282
	ds_bpermute_b32 v4, v1, v66                                // 00000028A000: DACC0000 04004201
	s_waitcnt lgkmcnt(0)                                       // 00000028A008: BF89FC07
	v_add_f32_e32 v4, v66, v4                                  // 00000028A00C: 06080942
	ds_bpermute_b32 v2, v1, v67                                // 00000028A010: DACC0000 02004301
	ds_bpermute_b32 v3, v1, v65                                // 00000028A018: DACC0000 03004101
	ds_bpermute_b32 v1, v1, v58                                // 00000028A020: DACC0000 01003A01
	s_waitcnt lgkmcnt(2)                                       // 00000028A028: BF89FC27
	v_dual_add_f32 v2, v67, v2 :: v_dual_cndmask_b32 v5, v0, v5// 00000028A02C: C9120543 02040B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000028A034: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000028A038: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000028A03C: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000028A040: 02121300
	ds_bpermute_b32 v6, v5, v2                                 // 00000028A044: DACC0000 06000205
	ds_bpermute_b32 v8, v5, v4                                 // 00000028A04C: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 00000028A054: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v9, 2, v9  // 00000028A058: C9220D02 02081282
	s_waitcnt lgkmcnt(0)                                       // 00000028A060: BF89FC07
	v_add_f32_e32 v6, v4, v8                                   // 00000028A064: 060C1104
	v_xor_b32_e32 v4, 1, v0                                    // 00000028A068: 3A080081
	ds_bpermute_b32 v8, v9, v6                                 // 00000028A06C: DACC0000 08000609
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000028A074: 7C9808A0
	v_dual_add_f32 v3, v65, v3 :: v_dual_cndmask_b32 v0, v0, v4// 00000028A078: C9120741 03000900
	v_add_f32_e32 v1, v58, v1                                  // 00000028A080: 0602033A
	ds_bpermute_b32 v7, v5, v3                                 // 00000028A084: DACC0000 07000305
	v_cmp_eq_u32_e32 vcc_lo, 0, v51                            // 00000028A08C: 7C946680
	v_lshlrev_b32_e32 v10, 2, v0                               // 00000028A090: 30140082
	ds_bpermute_b32 v5, v5, v1                                 // 00000028A094: DACC0000 05000105
	s_and_b32 s0, vcc_lo, s0                                   // 00000028A09C: 8B00006A
	s_waitcnt lgkmcnt(1)                                       // 00000028A0A0: BF89FC17
	v_add_f32_e32 v3, v3, v7                                   // 00000028A0A4: 06060F03
	s_waitcnt lgkmcnt(0)                                       // 00000028A0A8: BF89FC07
	v_add_f32_e32 v7, v1, v5                                   // 00000028A0AC: 060E0B01
	ds_bpermute_b32 v1, v9, v2                                 // 00000028A0B0: DACC0000 01000209
	s_waitcnt lgkmcnt(0)                                       // 00000028A0B8: BF89FC07
	v_add_f32_e32 v4, v2, v1                                   // 00000028A0BC: 06080302
	ds_bpermute_b32 v5, v9, v3                                 // 00000028A0C0: DACC0000 05000309
	ds_bpermute_b32 v9, v9, v7                                 // 00000028A0C8: DACC0000 09000709
	s_waitcnt lgkmcnt(1)                                       // 00000028A0D0: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 00000028A0D4: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 00000028A0D8: BF89FC07
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v0, v7, v9     // 00000028A0DC: C9081106 05001307
	ds_bpermute_b32 v6, v10, v4                                // 00000028A0E4: DACC0000 0600040A
	ds_bpermute_b32 v2, v10, v1                                // 00000028A0EC: DACC0000 0200010A
	ds_bpermute_b32 v7, v10, v5                                // 00000028A0F4: DACC0000 0700050A
	ds_bpermute_b32 v3, v10, v0                                // 00000028A0FC: DACC0000 0300000A
	s_and_saveexec_b32 s1, s0                                  // 00000028A104: BE812000
	s_cbranch_execz 135                                        // 00000028A108: BFA50087 <_ZN7halogen12_GLOBAL__N_111k_lq4w_pairILi2ELi16ELi1EEEvPKhlllS3_lllPKtPtll+0x1228>
	s_waitcnt lgkmcnt(1)                                       // 00000028A10C: BF89FC17
	v_dual_add_f32 v5, v5, v7 :: v_dual_add_f32 v4, v4, v6     // 00000028A110: C9080F05 05040D04
	.long 0x7f0c3880                                           // 00000028A118: 7F0C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028A11C: BF870192
	.long 0x7e0c3985                                           // 00000028A120: 7E0C3985
	.long 0x7e0e3984                                           // 00000028A124: 7E0E3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028A128: BF870193
	.long 0x7f0e3986                                           // 00000028A12C: 7F0E3986
	v_and_b32_e32 v8, 1, v6                                    // 00000028A130: 36100C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000028A134: BF870112
	v_and_b32_e32 v7, 1, v7                                    // 00000028A138: 360E0E81
	v_add3_u32 v5, v5, v8, 0x7fff                              // 00000028A13C: D6550005 03FE1105 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A148: BF870092
	v_add3_u32 v4, v4, v7, 0x7fff                              // 00000028A14C: D6550004 03FE0F04 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000028A158: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A160: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v4                           // 00000028A164: 101008FF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 00000028A16C: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A170: BF870095
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000028A174: C92410F2 08040AFF FFFF0000
	v_mul_f32_e32 v7, 0xbfb8aa3b, v5                           // 00000028A180: 100E0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000028A188: BF870291
	v_exp_f32_e32 v7, v7                                       // 00000028A18C: 7E0E4B07
	v_add_f32_e32 v7, 1.0, v7                                  // 00000028A190: 060E0EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000028A194: BF870113
	v_div_scale_f32 v10, null, v8, v8, v4                      // 00000028A198: D6FC7C0A 04121108
	v_div_scale_f32 v9, null, v7, v7, v5                       // 00000028A1A0: D6FC7C09 04160F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000028A1A8: BF870122
	v_rcp_f32_e32 v12, v10                                     // 00000028A1AC: 7E18550A
	v_div_scale_f32 v15, vcc_lo, v5, v7, v5                    // 00000028A1B0: D6FC6A0F 04160F05
	v_rcp_f32_e32 v11, v9                                      // 00000028A1B8: 7E165509
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000028A1BC: BF870296
	v_fma_f32 v14, -v10, v12, 1.0                              // 00000028A1C0: D613000E 23CA190A
	v_fma_f32 v13, -v9, v11, 1.0                               // 00000028A1C8: D613000D 23CA1709
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000028A1D0: BF8701A2
	v_fmac_f32_e32 v12, v14, v12                               // 00000028A1D4: 5618190E
	.long 0x7f1c3986                                           // 00000028A1D8: 7F1C3986
	v_fmac_f32_e32 v11, v13, v11                               // 00000028A1DC: 5616170D
	v_div_scale_f32 v13, s0, v4, v8, v4                        // 00000028A1E0: D6FC000D 04121104
	s_waitcnt lgkmcnt(0)                                       // 00000028A1E8: BF89FC07
	v_dual_add_f32 v1, v1, v2 :: v_dual_add_f32 v0, v0, v3     // 00000028A1EC: C9080501 01000700
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000028A1F4: BF870112
	v_dual_mul_f32 v2, v15, v11 :: v_dual_mul_f32 v3, v13, v12 // 00000028A1F8: C8C6170F 0202190D
	.long 0x7e1c3981                                           // 00000028A200: 7E1C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000028A204: BF8701A3
	.long 0x7e0c3980                                           // 00000028A208: 7E0C3980
	s_waitcnt vmcnt(0)                                         // 00000028A20C: BF8903F7
	v_fma_f32 v16, -v9, v2, v15                                // 00000028A210: D6130010 243E0509
	v_fma_f32 v17, -v10, v3, v13                               // 00000028A218: D6130011 2436070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A220: BF870091
	v_dual_fmac_f32 v3, v17, v12 :: v_dual_and_b32 v14, 1, v14 // 00000028A224: C8241911 030E1C81
	v_add3_u32 v1, v1, v14, 0x7fff                             // 00000028A22C: D6550001 03FE1D01 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028A238: BF870194
	v_fmac_f32_e32 v2, v16, v11                                // 00000028A23C: 56041710
	v_fma_f32 v10, -v10, v3, v13                               // 00000028A240: D613000A 2436070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028A248: BF870193
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000028A24C: 360202FF FFFF0000
	v_fma_f32 v9, -v9, v2, v15                                 // 00000028A254: D6130009 243E0509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000028A25C: BF870141
	v_div_fmas_f32 v2, v9, v11, v2                             // 00000028A260: D6370002 040A1709
	s_mov_b32 vcc_lo, s0                                       // 00000028A268: BEEA0000
	s_lshl_b64 s[0:1], s[26:27], 1                             // 00000028A26C: 8480811A
	v_div_fmas_f32 v3, v10, v12, v3                            // 00000028A270: D6370003 040E190A
	v_div_fixup_f32 v2, v2, v7, v5                             // 00000028A278: D6270002 04160F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A280: BF870092
	v_div_fixup_f32 v3, v3, v8, v4                             // 00000028A284: D6270003 04121103
	v_dual_mul_f32 v5, v3, v1 :: v_dual_and_b32 v16, 1, v6     // 00000028A28C: C8E40303 05100C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A294: BF870091
	v_add3_u32 v0, v0, v16, 0x7fff                             // 00000028A298: D6550000 03FE2100 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 00000028A2A4: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000028A2AC: BF870141
	v_mul_f32_e32 v4, v2, v0                                   // 00000028A2B0: 10080102
	.long 0x7f043986                                           // 00000028A2B4: 7F043986
	.long 0x7e043985                                           // 00000028A2B8: 7E043985
	.long 0xd73c0000                                           // 00000028A2BC: D73C0000
	v_cndmask_b32_e32 v1, 1, v40, vcc_lo                       // 00000028A2C0: 02025081
	v_and_b32_e32 v7, 1, v2                                    // 00000028A2C4: 360E0481
	.long 0x7e0c3984                                           // 00000028A2C8: 7E0C3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000028A2CC: BF870093
	.long 0xd7006a00                                           // 00000028A2D0: D7006A00
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000028A2D4: 02020016
	v_add_co_ci_u32_e64 v1, null, s23, v1, vcc_lo              // 00000028A2D8: D5207C01 01AA0217
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000028A2E0: BF870193
	v_and_b32_e32 v6, 1, v6                                    // 00000028A2E4: 360C0C81
	.long 0xd7006a02                                           // 00000028A2E8: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000028A2EC: 02000100
	v_add3_u32 v5, v5, v7, 0x7fff                              // 00000028A2F0: D6550005 03FE0F05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000028A2FC: BF870214
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000028A300: D5207C03 01AA0201
	v_add3_u32 v4, v4, v6, 0x7fff                              // 00000028A308: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 00000028A314: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 00000028A318: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000028A320: DC960000 007C0402
	s_nop 0                                                    // 00000028A328: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000028A32C: BFB60003
	s_endpgm                                                   // 00000028A330: BFB00000
		...

