0000000000841b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000841B00: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000841B08: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000841B10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000841B14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000841B18: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000841B1C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000841B20: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000841B28: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 000000841B2C: 321E0085
	v_dual_mov_b32 v21, 0 :: v_dual_and_b32 v16, 31, v0        // 000000841B30: CA240080 1510009F
	.long 0x7f263880                                           // 000000841B38: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 000000841B3C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000841B44: BF89FC07
	s_clause 0x1                                               // 000000841B48: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 000000841B4C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000841B54: DC520000 0D040002
	.long 0xd4510014                                           // 000000841B5C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000841B60: 02001802
	s_and_b32 s20, s20, exec_lo                                // 000000841B64: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 000000841B68: 98188003
	s_cselect_b32 s25, s2, 0                                   // 000000841B6C: 98198002
	s_add_u32 s14, s4, s14                                     // 000000841B70: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000841B74: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 000000841B78: 85149F0B
	v_mov_b32_e32 v1, s14                                      // 000000841B7C: 7E02020E
	s_add_u32 s20, s10, s20                                    // 000000841B80: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000841B84: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 000000841B88: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 000000841B8C: 86948114
	s_lshr_b32 s22, s22, 27                                    // 000000841B90: 85169B16
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s15             // 000000841B94: CA100080 0702000F
	s_add_u32 s22, s10, s22                                    // 000000841B9C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 000000841BA0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 000000841BA4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 000000841BA8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000841BAC: BF870499
	s_add_i32 s23, s22, 7                                      // 000000841BB0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 000000841BB4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000841BB8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 000000841BBC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 000000841BC0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000841BC4: BF8704B9
	s_ashr_i32 s14, s23, 3                                     // 000000841BC8: 860E8317
	s_add_u32 s4, s4, s16                                      // 000000841BCC: 80041004
	s_addc_u32 s5, s5, s17                                     // 000000841BD0: 82051105
	v_dual_mov_b32 v3, s4 :: v_dual_mov_b32 v4, s5             // 000000841BD4: CA100004 03040005
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 000000841BDC: D6FE7C09 04042819
	.long 0xd72c0012                                           // 000000841BE4: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 000000841BE8: 02021E0E
	s_mul_i32 s4, s24, s20                                     // 000000841BEC: 96041418
	s_waitcnt vmcnt(1)                                         // 000000841BF0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 000000841BF4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 000000841BFC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000841C00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000841C08: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 000000841C0C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000841C18: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000841C24: BF870002
	.long 0x7e263982                                           // 000000841C28: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 000000841C2C: 4A041404
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 000000841C30: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 000000841C38: 4A06240E
	v_add_nc_u32_e32 v10, v18, v16                             // 000000841C3C: 4A142112
	s_mul_i32 s25, s25, s21                                    // 000000841C40: 96191519
	s_mul_i32 s4, s18, s24                                     // 000000841C44: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000841C48: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s22, v3                                 // 000000841C54: 22240616
	v_add_nc_u32_e32 v19, s25, v2                              // 000000841C58: 4A260419
	v_add_nc_u32_e32 v3, s19, v12                              // 000000841C5C: 4A061813
	ds_store_b32 v14, v1                                       // 000000841C60: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000841C68: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 000000841C6C: 4A280604
	s_waitcnt lgkmcnt(0)                                       // 000000841C70: BF89FC07
	s_barrier                                                  // 000000841C74: BFBD0000
	buffer_gl0_inv                                             // 000000841C78: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 000000841C80: BE85206A
	s_cbranch_execz 21                                         // 000000841C84: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000841C88: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000841C8C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000841C90: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000841C94: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000841C98: 3408069F
	.long 0xd7000401                                           // 000000841C9C: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000841CA0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841CA4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 000000841CA8: D5207C02 00120514
	.long 0xd7000403                                           // 000000841CB0: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000841CB4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 000000841CB8: D5207C04 00120913
	s_clause 0x1                                               // 000000841CC0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000841CC4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000841CCC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000841CD4: BF8907F7
	v_cvt_f32_f16_e32 v21, v1                                  // 000000841CD8: 7E2A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000841CDC: 8C7E057E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000841CE0: CA100080 17180080
	v_mov_b32_e32 v22, 0                                       // 000000841CE8: 7E2C0280
	s_and_saveexec_b32 s5, vcc_lo                              // 000000841CEC: BE85206A
	s_cbranch_execz 401                                        // 000000841CF0: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x838>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000841CF4: CA200080 160014A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000841CFC: CA220080 170C1485
	v_mov_b32_e32 v27, v21                                     // 000000841D04: 7E360315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000841D08: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 000000841D0C: CA220080 18180284
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000841D14: CA220080 111A0281
	s_mul_i32 s4, s11, 6                                       // 000000841D1C: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000841D20: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000841D24: 848E820A
	s_add_i32 s16, s16, s4                                     // 000000841D28: 81100410
	s_mul_i32 s18, s10, 6                                      // 000000841D2C: 9612860A
	s_mov_b32 s17, 0                                           // 000000841D30: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000841D34: 848A810A
	s_branch 351                                               // 000000841D38: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x7b8>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000841D3C: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 000000841D40: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 000000841D48: 8B046A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000841D4C: 4A3232FF 00000200
	s_or_b32 s17, s4, s17                                      // 000000841D54: 8C111104
	v_add_nc_u32_e32 v26, 64, v26                              // 000000841D58: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000841D5C: 301A1A82
	ds_load_b32 v42, v13                                       // 000000841D60: D8D80000 2A00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000841D68: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000841D6C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000841D70: 361A1AFF 000003FC
	ds_load_b32 v43, v13                                       // 000000841D78: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000841D80: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000841D84: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000841D88: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000841D90: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841D94: 360A0AFF 000003FC
	ds_load_b32 v44, v13                                       // 000000841D9C: D8D80000 2C00000D
	ds_load_b32 v45, v5                                        // 000000841DA4: D8D80000 2D000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000841DAC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000841DB4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000841DB8: 300A0A82
	ds_load_b32 v46, v5                                        // 000000841DBC: D8D80000 2E000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000841DC4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000841DC8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841DCC: 360A0AFF 000003FC
	ds_load_b32 v47, v5                                        // 000000841DD4: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000841DDC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841DE0: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 000000841DE8: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000841DF0: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000841DF4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841DF8: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 000000841E00: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000841E08: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000841E10: 300A0A82
	ds_load_b32 v50, v5                                        // 000000841E14: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000841E1C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000841E20: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841E24: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000841E2C: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000841E34: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841E38: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000841E40: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000841E48: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000841E4C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841E50: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000841E58: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000841E60: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000841E68: 300A0A82
	ds_load_b32 v54, v5                                        // 000000841E6C: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000841E74: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000841E78: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841E7C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000841E84: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000841E8C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841E90: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000841E98: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000841EA0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000841EA4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000841EA8: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000841EB0: D8D80000 39000005
	.long 0xd73c0005                                           // 000000841EB8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000841EBC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000841EC0: 4A1818FF 00000400
	.long 0xd7006a28                                           // 000000841EC8: D7006A28
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000841ECC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000841ED0: BF870001
	v_add_co_ci_u32_e64 v41, null, s7, v6, vcc_lo              // 000000841ED4: D5207C29 01AA0C07
	s_clause 0x3                                               // 000000841EDC: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000841EE0: DC5E0000 057C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000841EE8: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000841EF0: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000841EF8: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000841F00: BF890CF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000841F04: CC1A4005 1A025505
	s_waitcnt lgkmcnt(14)                                      // 000000841F0C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F10: BF8700A1
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000841F14: CC1A4005 1C165706
	s_waitcnt lgkmcnt(13)                                      // 000000841F1C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000841F20: CC1A4005 1C165907
	s_waitcnt lgkmcnt(12)                                      // 000000841F28: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F2C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000841F30: CC1A4005 1C165B08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000841F38: BF8908B7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000841F3C: CC1A4005 1C165D1C
	s_waitcnt lgkmcnt(10)                                      // 000000841F44: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F48: BF8700A1
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000841F4C: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(9)                                       // 000000841F54: BF89FC97
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000841F58: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(8)                                       // 000000841F60: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F64: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000841F68: CC1A4005 1C16631F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000841F70: BF890477
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000841F74: CC1A4005 1C166520
	s_waitcnt lgkmcnt(6)                                       // 000000841F7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F80: BF8700A1
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000841F84: CC1A4005 1C166721
	s_waitcnt lgkmcnt(5)                                       // 000000841F8C: BF89FC57
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000841F90: CC1A4005 1C166922
	s_waitcnt lgkmcnt(4)                                       // 000000841F98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000841F9C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000841FA0: CC1A4005 1C166B23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000841FA8: BF890037
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000841FAC: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000841FB4: D7006A24
	v_cndmask_b32_e32 v0, v40, v10, vcc_lo                     // 000000841FB8: 02001528
	s_waitcnt lgkmcnt(2)                                       // 000000841FBC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000841FC0: BF870132
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000841FC4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s11, v41, vcc_lo            // 000000841FCC: D5207C25 01AA520B
	s_waitcnt lgkmcnt(1)                                       // 000000841FD4: BF89FC17
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000841FD8: CC1A4005 1C167126
	s_waitcnt lgkmcnt(0)                                       // 000000841FE0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000841FE4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000841FE8: CC1A4005 1C167327
	v_fmac_f32_e32 v22, v21, v5                                // 000000841FF0: 562C0B15
	s_clause 0x3                                               // 000000841FF4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000841FF8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000842000: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000842008: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000842010: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000842018: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 00000084201C: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842024: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000842028: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000842030: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842038: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 00000084203C: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000842044: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000842048: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842050: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000842054: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 00000084205C: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842064: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000842068: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000842070: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000842074: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084207C: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000842080: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000842088: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842090: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000842094: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 00000084209C: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 0000008420A0: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 0000008420A8: D7006A24
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 0000008420AC: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008420B0: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 0000008420B4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s15, v41, vcc_lo            // 0000008420BC: D5207C25 01AA520F
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008420C4: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008420CC: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008420D0: CC1A4005 1C167327
	v_fmac_f32_e32 v24, v21, v5                                // 0000008420D8: 56300B15
	s_clause 0x3                                               // 0000008420DC: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 0000008420E0: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000008420E8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000008420F0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000008420F8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000842100: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000842104: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084210C: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000842110: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000842118: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842120: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000842124: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 00000084212C: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000842130: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842138: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 00000084213C: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000842144: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084214C: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000842150: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000842158: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 00000084215C: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842164: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000842168: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000842170: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842178: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 00000084217C: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000842184: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000842188: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000842190: D7006A24
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 000000842194: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000842198: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 00000084219C: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s16, v41, vcc_lo            // 0000008421A4: D5207C25 01AA5210
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 0000008421AC: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008421B4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 0000008421B8: CC1A4005 1C167327
	v_fmac_f32_e32 v23, v21, v5                                // 0000008421C0: 562E0B15
	s_clause 0x3                                               // 0000008421C4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 0000008421C8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000008421D0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000008421D8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000008421E0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000008421E8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 0000008421EC: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008421F4: BF870121
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 0000008421F8: CC1A4005 1C165706
	v_mov_b32_e32 v6, v2                                       // 000000842200: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000842204: CC1A4005 1C165907
	v_mov_b32_e32 v7, v3                                       // 00000084220C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000842210: BF870132
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000842214: CC1A4005 1C165B08
	v_mov_b32_e32 v8, v4                                       // 00000084221C: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000842220: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000842224: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084222C: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000842230: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000842238: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842240: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000842244: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 00000084224C: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000842250: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842258: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 00000084225C: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000842264: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084226C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000842270: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000842278: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 00000084227C: CC1A4005 1C166D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842284: BF870091
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000842288: CC1A4005 1C166F25
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000842290: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842298: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 00000084229C: CC1A4005 1C167327
	v_fmac_f32_e32 v17, v21, v5                                // 0000008422A4: 56220B15
	v_mov_b32_e32 v5, v1                                       // 0000008422A8: 7E0A0301
	v_mov_b32_e32 v21, v27                                     // 0000008422AC: 7E2A031B
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000008422B0: 917E117E
	s_cbranch_execz 31                                         // 0000008422B4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x834>
	s_waitcnt vmcnt(0)                                         // 0000008422B8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 0000008422BC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000008422C4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000008422CC: 7E080308
	s_mov_b32 s19, exec_lo                                     // 0000008422D0: BE93007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008422D4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000008422D8: 7C8C250A
	.long 0xd4c1007e                                           // 0000008422DC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000008422E0: 0202250A
	s_cbranch_execz 65173                                      // 0000008422E4: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	v_ashrrev_i32_e32 v2, 31, v26                              // 0000008422E8: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 0000008422EC: 3408329F
	.long 0xd7000401                                           // 0000008422F0: D7000401
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000008422F4: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008422F8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008422FC: D5207C02 00120514
	.long 0xd7000403                                           // 000000842304: D7000403
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000842308: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 00000084230C: D5207C04 00120913
	s_clause 0x1                                               // 000000842314: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000842318: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000842320: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000842328: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 00000084232C: 7E36170D
	s_branch 65154                                             // 000000842330: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000842334: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842338: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000084233C: 8C7E057E
	.long 0xd71f0001                                           // 000000842340: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000842344: 020100C1
	s_mov_b32 s4, exec_lo                                      // 000000842348: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000084234C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000842350: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 000000842354: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000842358: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000084235C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000842360: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000842364: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000842368: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000084236C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000842370: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 000000842374: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 00000084237C: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 000000842380: 060A0B17
	ds_bpermute_b32 v3, v2, v22                                // 000000842384: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v24                                // 00000084238C: DACC0000 04001802
	ds_bpermute_b32 v2, v2, v17                                // 000000842394: DACC0000 02001102
	s_waitcnt lgkmcnt(2)                                       // 00000084239C: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000008423A0: C9120716 03060D01
	s_waitcnt lgkmcnt(0)                                       // 0000008423A8: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000008423AC: 06040511
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000008423B0: 7C9814A0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008423B4: BF870003
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008423B8: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000008423BC: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000008423C0: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000008423C8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000008423CC: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 0000008423D0: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 0000008423D8: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008423DC: C9220F03 030A1482
	v_add_f32_e32 v4, v24, v4                                  // 0000008423E4: 06080918
	ds_bpermute_b32 v8, v6, v4                                 // 0000008423E8: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000008423F0: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000008423F8: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000008423FC: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 000000842400: DACC0000 0600030A
	s_waitcnt lgkmcnt(0)                                       // 000000842408: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000084240C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 000000842414: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 00000084241C: BF89FC07
	v_add_f32_e32 v5, v5, v8                                   // 000000842420: 060A1105
	ds_bpermute_b32 v7, v10, v4                                // 000000842424: DACC0000 0700040A
	ds_bpermute_b32 v9, v10, v2                                // 00000084242C: DACC0000 0900020A
	v_xor_b32_e32 v10, 2, v1                                   // 000000842434: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000842438: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000084243C: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000842440: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000842444: 30141482
	s_waitcnt lgkmcnt(0)                                       // 000000842448: BF89FC07
	v_add_f32_e32 v6, v2, v9                                   // 00000084244C: 060C1302
	ds_bpermute_b32 v2, v10, v3                                // 000000842450: DACC0000 0200030A
	v_add_f32_e32 v4, v4, v7                                   // 000000842458: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000084245C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 000000842464: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000084246C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 000000842474: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842478: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000084247C: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000842480: 02021501
	s_waitcnt lgkmcnt(3)                                       // 000000842484: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000842488: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000842490: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 000000842494: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000842498: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000084249C: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000008424A4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000008424AC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000008424B4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000008424BC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008424C4: 7D942080
	s_cbranch_execz 9                                          // 0000008424C8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt lgkmcnt(1)                                       // 0000008424CC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 0000008424D0: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 0000008424D8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 0000008424DC: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000008424E4: 30021E84
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000008424E8: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008424F0: 8C7E047E
	.long 0xd4510004                                           // 0000008424F4: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008424F8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 0000008424FC: 7C980084
	s_waitcnt lgkmcnt(0)                                       // 000000842500: BF89FC07
	s_barrier                                                  // 000000842504: BFBD0000
	buffer_gl0_inv                                             // 000000842508: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 000000842510: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000842514: BF870009
	s_and_saveexec_b32 s5, s4                                  // 000000842518: BE852004
	s_cbranch_execz 85                                         // 00000084251C: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb74>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000842520: 4A0E1CFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 000000842528: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 000000842530: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 000000842538: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 000000842540: D8DC1410 05000007
	s_waitcnt lgkmcnt(0)                                       // 000000842548: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 00000084254C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000842550: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 000000842554: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:24 offset1:28         // 000000842558: D8DC1C18 01000007
	v_add_f32_e32 v3, v8, v3                                   // 000000842560: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000842564: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842568: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000084256C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000842570: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000842574: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842578: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000084257C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000842580: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842584: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000842588: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000842590: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084259C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000008425A0: 360202FF FFFF0000
	v_mul_f32_e32 v1, s0, v1                                   // 0000008425A8: 10020200
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000008425AC: 84808202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008425B0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000008425B4: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000008425BC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008425C0: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 0000008425C4: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 0000008425C8: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 0000008425D0: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000008425D8: BF870292
	v_rcp_f32_e32 v6, v5                                       // 0000008425DC: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 0000008425E0: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008425E8: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000008425EC: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000008425F0: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 0000008425F8: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008425FC: BF870091
	v_fma_f32 v3, -v5, v8, v7                                  // 000000842600: D6130003 241E1105
	v_fmac_f32_e32 v8, v3, v6                                  // 000000842608: 56100D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084260C: BF870114
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000842610: D6FE7C02 040A000D
	v_fma_f32 v0, -v5, v8, v7                                  // 000000842618: D6130000 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000842620: BF870191
	v_div_fmas_f32 v3, v0, v6, v8                              // 000000842624: D6370003 04220D00
	.long 0xd73c0000                                           // 00000084262C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000842630: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000842634: BF870112
	v_div_fixup_f32 v2, v3, v4, 1.0                            // 000000842638: D6270002 03CA0903
	.long 0xd7006a00                                           // 000000842640: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000842644: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000842648: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000084264C: D5207C01 01AA0209
	v_add_f32_e32 v2, v2, v2                                   // 000000842654: 06040502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000842658: BF870093
	.long 0xd7006a00                                           // 00000084265C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000842660: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000842664: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 00000084266C: DC6A0000 007C0200
	s_endpgm                                                   // 000000842674: BFB00000
		...

