0000000000427900 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 000000427900: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 000000427904: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000042790C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 000000427914: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 000000427918: BF108004
	s_cbranch_scc1 244                                         // 00000042791C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 000000427920: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 000000427928: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000042792C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 000000427930: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000427934: BF030602
	s_cbranch_scc0 233                                         // 000000427938: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000042793C: 32020085
	s_sub_i32 s6, s2, s6                                       // 000000427940: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000427944: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 000000427948: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 000000427950: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000427954: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 000000427958: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000042795C: BE86206A
	s_cbranch_execz 222                                        // 000000427960: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 000000427964: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000427968: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 000000427970: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 000000427974: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000042797C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000427984: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 000000427988: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000042798C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 000000427990: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000427994: BF870121
	.long 0xd72c0002                                           // 000000427998: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000042799C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000004279A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000004279B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004279B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000004279BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004279C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004279C8: BF870091
	.long 0xd73c0002                                           // 0000004279CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004279D0: 02020481
	.long 0xd7006a04                                           // 0000004279D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004279D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004279DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004279E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000004279E8: BF89FC07
	.long 0xd7006a02                                           // 0000004279EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004279F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004279F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000004279FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 000000427A04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 000000427A0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 000000427A14: BF8907F7
	.long 0x7e043904                                           // 000000427A18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 000000427A1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 000000427A24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000427A28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000427A30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 000000427A34: 301C0490
	s_waitcnt vmcnt(0)                                         // 000000427A38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000427A3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000427A44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000427A48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000427A50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000427A54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 000000427A58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 000000427A60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 000000427A68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 000000427A70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 000000427A78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000427A7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 000000427A80: 361A0088
	.long 0xd73c0001                                           // 000000427A84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000427A88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 000000427A8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 000000427A90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000427A94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000427A98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000427A9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000427AA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000427AAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000427AB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 000000427AB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 000000427ABC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 000000427AC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 000000427ACC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 000000427AD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000427AD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000427AE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000427AE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000427AEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000427AF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000427AFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000427B00: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000427B08: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000427B0C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000427B10: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000427B14: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000427B1C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000427B24: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000427B2C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000427B34: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000427B3C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000427B44: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000427B48: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000427B50: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000427B58: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 000000427B5C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000427B60: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000427B68: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 000000427B6C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000427B70: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000427B78: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000427B80: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000427B84: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000427B88: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000427B90: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000427B98: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 000000427BA0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 000000427BA4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 000000427BA8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000427BAC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000427BB4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 000000427BBC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 000000427BC0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000427BC4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000427BCC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 000000427BD4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000427BD8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000427BE0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000427BE8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000427BF0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000427BF8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000427C00: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000427C08: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 000000427C0C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000427C10: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000427C14: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000427C18: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000427C20: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000427C24: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000427C2C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000427C30: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000427C34: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000427C38: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000427C40: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000427C4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000427C54: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 000000427C5C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000427C68: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000427C74: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000427C80: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000427C84: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000427C88: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 000000427C8C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000427C94: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 000000427C9C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 000000427CA0: 060A1B05
	.long 0xd7006a01                                           // 000000427CA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 000000427CA8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000427CAC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 000000427CB4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 000000427CBC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 000000427CC4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 000000427CCC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 000000427CD4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 000000427CDC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427CE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000427CE4: 8B6A037E
	s_cbranch_vccnz 2                                          // 000000427CE8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 000000427CEC: BFB00000
	s_cbranch_execz 65534                                      // 000000427CF0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 000000427CF4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000427CF8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000427D00: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000427D08: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000427D10: F4000180 F800010C
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000427D18: 32160085
	v_and_b32_e32 v12, 31, v0                                  // 000000427D1C: 3618009F
	s_mov_b32 s34, 0                                           // 000000427D20: BEA20080
	s_mov_b32 s33, exec_lo                                     // 000000427D24: BEA1007E
	s_waitcnt lgkmcnt(0)                                       // 000000427D28: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000427D2C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000427D30: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000427D34: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000427D38: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427D3C: BF870009
	s_and_b32 s4, s7, s4                                       // 000000427D40: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000427D44: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000427D48: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000427D50: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000427D54: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000427D58: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427D5C: BF870009
	s_and_b32 s4, s7, s5                                       // 000000427D60: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000427D64: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000427D68: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000427D6C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000427D70: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000427D74: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000427D78: BF8704D9
	s_and_b32 s3, s3, s6                                       // 000000427D7C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000427D80: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000427D84: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000427D88: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000427D8C: 98030483
	s_mulk_i32 s3, 0x48                                        // 000000427D90: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427D94: BF870009
	s_add_u32 s4, s0, s3                                       // 000000427D98: 80040300
	s_addc_u32 s5, s1, 0                                       // 000000427D9C: 82058001
	s_clause 0x3                                               // 000000427DA0: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 000000427DA4: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 000000427DAC: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 000000427DB4: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 000000427DBC: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 000000427DC4: BF89FC07
	s_abs_i32 s3, s21                                          // 000000427DC8: BE831515
	s_sub_i32 s2, s2, s23                                      // 000000427DCC: 81821702
	s_cvt_f32_u32 s6, s3                                       // 000000427DD0: BE866503
	s_sub_i32 s7, 0, s3                                        // 000000427DD4: 81870380
	s_abs_i32 s8, s2                                           // 000000427DD8: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000427DDC: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 000000427DE0: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 000000427DE4: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 000000427DE8: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000427DF0: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 000000427DF4: BE866706
	s_mul_i32 s7, s7, s6                                       // 000000427DF8: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000427DFC: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 000000427E00: 96870706
	s_add_i32 s6, s6, s7                                       // 000000427E04: 81060706
	s_xor_b32 s7, s2, s21                                      // 000000427E08: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 000000427E0C: 96860608
	s_ashr_i32 s7, s7, 31                                      // 000000427E10: 86079F07
	s_mul_i32 s9, s6, s3                                       // 000000427E14: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427E18: BF870009
	s_sub_i32 s8, s8, s9                                       // 000000427E1C: 81880908
	s_add_i32 s9, s6, 1                                        // 000000427E20: 81098106
	s_sub_i32 s10, s8, s3                                      // 000000427E24: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 000000427E28: BF090308
	s_cselect_b32 s6, s9, s6                                   // 000000427E2C: 98060609
	s_cselect_b32 s8, s10, s8                                  // 000000427E30: 9808080A
	s_add_i32 s9, s6, 1                                        // 000000427E34: 81098106
	s_cmp_ge_u32 s8, s3                                        // 000000427E38: BF090308
	s_cselect_b32 s3, s9, s6                                   // 000000427E3C: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 000000427E40: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 000000427E48: 8D030703
	s_ashr_i32 s27, s19, 31                                    // 000000427E4C: 861B9F13
	s_sub_i32 s26, s3, s7                                      // 000000427E50: 819A0703
	s_lshr_b32 s4, s27, 25                                     // 000000427E54: 8504991B
	s_mul_i32 s3, s26, s21                                     // 000000427E58: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000427E5C: BF8704D9
	s_sub_i32 s23, s2, s3                                      // 000000427E60: 81970302
	s_add_i32 s2, s19, s4                                      // 000000427E64: 81020413
	s_mul_i32 s29, s22, s23                                    // 000000427E68: 961D1716
	s_ashr_i32 s2, s2, 7                                       // 000000427E6C: 86028702
	s_add_i32 s3, s29, s22                                     // 000000427E70: 8103161D
	s_min_i32 s2, s2, s3                                       // 000000427E74: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000427E78: BF870499
	s_sub_i32 s7, s2, s29                                      // 000000427E7C: 81871D02
	s_lshl_b32 s22, s7, 1                                      // 000000427E80: 84168107
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000427E84: BF870009
	.long 0xd4c4007e                                           // 000000427E88: D4C4007E
	v_cndmask_b32_e32 v1, s22, v11, vcc_lo                     // 000000427E8C: 02021616
	s_cbranch_execz 290                                        // 000000427E90: BFA50122 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s35, s7                                          // 000000427E94: BEA31507
	v_lshlrev_b32_e32 v7, 3, v12                               // 000000427E98: 300E1883
	s_cvt_f32_u32 s2, s35                                      // 000000427E9C: BE826523
	v_lshlrev_b32_e32 v8, 7, v11                               // 000000427EA0: 30101687
	v_and_b32_e32 v3, 2, v0                                    // 000000427EA4: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 000000427EA8: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 000000427EAC: 7E025602
	s_sub_i32 s2, 0, s35                                       // 000000427EB0: 81822380
	s_ashr_i32 s38, s7, 31                                     // 000000427EB4: 86269F07
	.long 0xd44a0003                                           // 000000427EB8: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000427EBC: 02020680
	s_mul_i32 s40, s38, 0x1400                                 // 000000427EC0: 9628FF26 00001400
	.long 0xd44a0005                                           // 000000427EC8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000427ECC: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 000000427ED0: 84068707
	s_add_i32 s36, s18, -1                                     // 000000427ED4: 8124C112
	s_mov_b32 s37, s19                                         // 000000427ED8: BEA50013
	s_lshl_b32 s39, s7, 8                                      // 000000427EDC: 84278807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 000000427EE0: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s41, 0x76543210                                  // 000000427EEC: BEA900FF 76543210
	s_mov_b32 s42, 0x3db504f3                                  // 000000427EF4: BEAA00FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v12                           // 000000427EFC: 7C981890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000427F00: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 000000427F04: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 000000427F08: 36020084
	.long 0xd72c0006                                           // 000000427F0C: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000427F10: 02020802
	.long 0xd44a0002                                           // 000000427F14: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000427F18: 02020480
	v_lshl_or_b32 v2, v11, 8, v7                               // 000000427F1C: D6560002 041D110B
	v_lshl_add_u32 v7, s29, 7, v8                              // 000000427F24: D6460007 04210E1D
	.long 0xd44a0004                                           // 000000427F2C: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000427F30: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000427F34: BF870223
	v_subrev_nc_u32_e32 v2, s40, v2                            // 000000427F38: 4E040428
	.long 0xd72d0006                                           // 000000427F3C: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000427F40: 02020D04
	v_lshl_or_b32 v1, v12, 2, v7                               // 000000427F44: D6560001 041D050C
	s_sub_i32 s40, 0, s6                                       // 000000427F4C: 81A80680
	s_delay_alu instid0(VALU_DEP_2)                            // 000000427F50: BF870002
	v_dual_mov_b32 v4, v11 :: v_dual_add_nc_u32 v3, v4, v6     // 000000427F54: CA20010B 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000427F5C: BF870091
	.long 0xd72d0005                                           // 000000427F60: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 000000427F64: 02020704
	.long 0xd72c0006                                           // 000000427F68: D72C0006
	v_cndmask_b32_e32 v0, v5, v35, vcc_lo                      // 000000427F6C: 02004705
	v_add_nc_u32_e32 v7, 1, v5                                 // 000000427F70: 4A0E0A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000427F74: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 000000427F78: 4C0C0D04
	v_subrev_nc_u32_e32 v8, s35, v6                            // 000000427F7C: 4E100C23
	.long 0xd44b0006                                           // 000000427F80: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 000000427F84: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000427F88: BF870191
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 000000427F8C: D5010005 001A0F05
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 000000427F94: D5010006 001A1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000427F9C: BF870112
	v_add_nc_u32_e32 v7, 1, v5                                 // 000000427FA0: 4A0E0A81
	.long 0xd44b0006                                           // 000000427FA4: D44B0006
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 000000427FA8: 02020C23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000427FAC: BF870091
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 000000427FB0: D5010005 001A0F05
	v_xor_b32_e32 v9, s38, v5                                  // 000000427FB8: 3A120A26
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000427FBC: BF870121
	v_subrev_nc_u32_e32 v10, s38, v9                           // 000000427FC0: 4E141226
	.long 0xd72c0009                                           // 000000427FC4: D72C0009
	v_cndmask_b32_e32 v1, 0x1400, v9, vcc_lo                   // 000000427FC8: 020212FF 00001400
	v_min_i32_e32 v7, s36, v10                                 // 000000427FD0: 220E1424
	v_mad_u64_u32 v[5:6], null, s40, v10, v[1:2]               // 000000427FD4: D6FE7C05 04061428
	.long 0xd72c000a                                           // 000000427FDC: D72C000A
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 000000427FE0: 02021427
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000427FE4: BF870193
	v_mad_i64_i32 v[7:8], null, v7, s37, 0                     // 000000427FE8: D6FF7C07 02004B07
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000427FF0: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000427FF4: BF870193
	v_sub_nc_u32_e32 v9, v9, v10                               // 000000427FF8: 4C121509
	.long 0xd73c0007                                           // 000000427FFC: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000428000: 02020E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000428004: BF870193
	.long 0xd73c0005                                           // 000000428008: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000042800C: 02020A81
	v_add_nc_u32_e32 v9, v2, v9                                // 000000428010: 4A121302
	v_add_nc_u32_e32 v2, 0x800, v2                             // 000000428014: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042801C: BF870094
	.long 0xd700060d                                           // 000000428020: D700060D
	v_cndmask_b32_e32 v1, s16, v7, vcc_lo                      // 000000428024: 02020E10
	v_add_co_ci_u32_e64 v14, null, s17, v8, s6                 // 000000428028: D5207C0E 001A1011
	s_waitcnt lgkmcnt(0)                                       // 000000428030: BF89FC07
	.long 0xd7000607                                           // 000000428034: D7000607
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000428038: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042803C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s11, v6, s6                  // 000000428040: D5207C08 001A0C0B
	.long 0xd7000605                                           // 000000428048: D7000605
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 00000042804C: 02020B0D
	v_add_co_ci_u32_e64 v6, null, v14, v6, s6                  // 000000428050: D5207C06 001A0D0E
	global_load_b64 v[5:6], v[5:6], off                        // 000000428058: DC560000 057C0005
	global_load_b64 v[7:8], v[7:8], off                        // 000000428060: DC560000 077C0007
	s_waitcnt vmcnt(1)                                         // 000000428068: BF8907F7
	.long 0x7e1a3905                                           // 00000042806C: 7E1A3905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000428070: 360A0AFF FFFF0000
	.long 0x7e1c3906                                           // 000000428078: 7E1C3906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042807C: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000428080: 301A1A90
	s_waitcnt vmcnt(0)                                         // 000000428084: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000428088: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000428090: BF870113
	v_lshlrev_b32_e32 v14, 16, v14                             // 000000428094: 301C1C90
	v_fma_mix_f32 v16, v7, v13, v5 op_sel_hi:[1,0,0]           // 000000428098: CC200010 0C161B07
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000004280A0: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v7, v13, -v5 op_sel_hi:[1,0,0]           // 0000004280A8: CC200005 8C161B07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004280B0: BF870092
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000004280B4: CC200806 8A020D08
	v_fma_mix_f32 v15, v8, v14, v6 op_sel_hi:[1,0,0]           // 0000004280BC: CC20000F 0C1A1D08
	v_fma_mix_f32 v6, v8, v14, -v6 op_sel_hi:[1,0,0]           // 0000004280C4: CC200006 8C1A1D08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004280CC: BF870112
	v_dual_add_f32 v7, v16, v15 :: v_dual_add_nc_u32 v4, 8, v4 // 0000004280D0: C9201F10 07040888
	v_dual_add_f32 v8, v6, v5 :: v_dual_sub_f32 v5, v5, v6     // 0000004280D8: C90A0B06 08040D05
	v_sub_f32_e32 v13, v16, v15                                // 0000004280E0: 081A1F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004280E4: BF870213
	.long 0xd4430006                                           // 0000004280E8: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 0000004280EC: 02020816
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004280F0: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 0000004280F8: D5010007 200A0F07
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000428100: 7E2002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000428108: D5010005 200A0B05
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000428110: 4A0202FF 00000400
	v_mov_b32_dpp v15, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000428118: 7E1E02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000428120: D501000D 200A1B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000428128: BF8701C4
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v16    // 00000042812C: C9080D07 06042105
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000428134: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000042813C: D5010008 200A1108
	s_or_b32 s34, s6, s34                                      // 000000428144: 8C222206
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000428148: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000428150: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000428158: BF8701B3
	v_dual_add_f32 v7, v8, v14 :: v_dual_add_f32 v8, v13, v15  // 00000042815C: C9081D08 07081F0D
	v_mov_b32_dpp v13, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000428164: 7E1A02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000042816C: D5010006 200E0D06
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000428174: 7E1E02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 00000042817C: D5010008 200E1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000428184: BF870233
	v_add_f32_e32 v6, v6, v13                                  // 000000428188: 060C1B06
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000042818C: 7E1C02FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000428194: D5010007 200E0F07
	v_add_f32_e32 v8, v8, v15                                  // 00000042819C: 06101F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004281A0: BF870224
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004281A4: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000004281AC: D5010006 20120D06
	v_add_f32_e32 v7, v7, v14                                  // 0000004281B4: 060E1D07
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004281B8: BF870224
	v_mov_b32_dpp v15, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004281BC: 7E1E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000004281C4: D5010008 20121108
	v_add_f32_e32 v6, v6, v13                                  // 0000004281CC: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004281D0: BF870224
	v_mov_b32_dpp v14, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004281D4: 7E1C02FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 0000004281DC: D5010007 20120F07
	v_add_f32_e32 v8, v8, v15                                  // 0000004281E4: 06101F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004281E8: BF870234
	v_mov_b32_dpp v13, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004281EC: 7E1A02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 0000004281F4: D5010006 20160D06
	v_add_f32_e32 v5, v5, v16                                  // 0000004281FC: 060A2105
	v_mov_b32_dpp v15, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000428200: 7E1E02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000428208: D5010008 20161108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000428210: BF870214
	v_add_f32_e32 v6, v6, v13                                  // 000000428214: 060C1B06
	v_mov_b32_dpp v16, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000428218: 7E2002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000428220: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000428228: BF870091
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v5, v5, v16   // 00000042822C: C9081F08 08042105
	v_mov_b32_e32 v15, v8                                      // 000000428234: 7E1E0308
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000428238: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000428240: BF870223
	v_mov_b32_dpp v16, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000428244: 7E2002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000042824C: D5010005 20160B05
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 000000428254: D65C000F 03FC530F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000428260: BF870091
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v8, v8, v15   // 000000428264: C9082105 05081F08
	v_dual_add_f32 v7, v7, v14 :: v_dual_mov_b32 v16, v5       // 00000042826C: C9101D07 07100105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000428274: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000042827C: BF870222
	v_mov_b32_dpp v14, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000428280: 7E1C02FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 000000428288: D5010007 20160F07
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 000000428290: D65C0010 03FC5310 FEDCBA98
	v_mov_b32_e32 v13, v6                                      // 00000042829C: 7E1A0306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004282A0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004282A8: BF870193
	v_add_f32_e32 v10, v5, v16                                 // 0000004282AC: 06142105
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 0000004282B0: D65C000D 03FC530D FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004282BC: BF870091
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v6, v6, v13   // 0000004282C0: C9081D07 07061B06
	v_mov_b32_e32 v14, v7                                      // 0000004282C8: 7E1C0307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000004282CC: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004282D4: BF870193
	v_fma_mixlo_f16 v5, v6, s42, 0                             // 0000004282D8: CC210005 02005506
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 0000004282E0: D65C000E 03FC530E FEDCBA98
	v_fma_mixhi_f16 v6, v10, s42, 0                            // 0000004282EC: CC220006 0200550A
	v_fma_mixlo_f16 v6, v8, s42, 0                             // 0000004282F4: CC210006 02005508
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004282FC: BF870093
	v_add_f32_e32 v7, v7, v14                                  // 000000428300: 060E1D07
	v_fma_mixhi_f16 v5, v7, s42, 0                             // 000000428304: CC220005 02005507
	ds_store_b64 v9, v[5:6]                                    // 00000042830C: D9340000 00000509
	s_and_not1_b32 exec_lo, exec_lo, s34                       // 000000428314: 917E227E
	s_cbranch_execnz 65296                                     // 000000428318: BFA6FF10 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x65c>
	s_or_b32 exec_lo, exec_lo, s33                             // 00000042831C: 8C7E217E
	s_bfe_i32 s6, s7, 0x1001c                                  // 000000428320: 9386FF07 0001001C
	s_lshr_b32 s5, s27, 28                                     // 000000428328: 85059C1B
	s_lshr_b64 s[2:3], s[6:7], 29                              // 00000042832C: 85829D06
	s_lshl_b32 s4, s7, 3                                       // 000000428330: 84048307
	s_add_i32 s2, s2, 7                                        // 000000428334: 81028702
	s_lshl_b32 s3, s29, 3                                      // 000000428338: 8403831D
	s_ashr_i32 s2, s2, 3                                       // 00000042833C: 86028302
	v_dual_mov_b32 v14, 0 :: v_dual_lshlrev_b32 v13, 2, v12    // 000000428340: CA220080 0E0C1882
	.long 0xd72c0001                                           // 000000428348: D72C0001
	v_cndmask_b32_e32 v1, s2, v11, vcc_lo                      // 00000042834C: 02021602
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000428350: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000428358: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 000000428360: CA100080 16180080
	s_delay_alu instid0(VALU_DEP_4)                            // 000000428368: BF870004
	v_dual_mov_b32 v31, 0 :: v_dual_add_nc_u32 v2, s2, v1      // 00000042836C: CA200080 1F020202
	s_add_i32 s2, s19, s5                                      // 000000428374: 81020513
	s_ashr_i32 s5, s3, 31                                      // 000000428378: 86059F03
	s_ashr_i32 s2, s2, 4                                       // 00000042837C: 86028402
	v_mov_b32_e32 v35, 0                                       // 000000428380: 7E460280
	v_min_i32_e32 v16, s4, v2                                  // 000000428384: 22200404
	s_mul_i32 s4, s26, s2                                      // 000000428388: 9604021A
	s_mul_hi_i32 s6, s26, s2                                   // 00000042838C: 9706021A
	s_add_u32 s2, s4, s3                                       // 000000428390: 80020304
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000428394: 3404029F
	v_cmp_lt_i32_e32 vcc_lo, v1, v16                           // 000000428398: 7C822101
	s_addc_u32 s3, s6, s5                                      // 00000042839C: 82030506
	s_waitcnt lgkmcnt(0)                                       // 0000004283A0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000004283A4: BC7C0000
	s_lshl_b64 s[4:5], s[2:3], 10                              // 0000004283A8: 84848A02
	s_barrier                                                  // 0000004283AC: BFBD0000
	buffer_gl0_inv                                             // 0000004283B0: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004283B8: BE83206A
	s_cbranch_execz 31                                         // 0000004283BC: BFA5001F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xb3c>
	.long 0xd73c0003                                           // 0000004283C0: D73C0003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000004283C4: 0202028A
	s_add_u32 s2, s8, s4                                       // 0000004283C8: 80020408
	s_addc_u32 s6, s9, s5                                      // 0000004283CC: 82060509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004283D0: BF870091
	.long 0xd7000203                                           // 0000004283D4: D7000203
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000004283D8: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s2                   // 0000004283DC: D5207C04 000A0806
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004283E4: BF870092
	.long 0xd7000203                                           // 0000004283E8: D7000203
	v_cndmask_b32_e32 v1, v3, v13, vcc_lo                      // 0000004283EC: 02021B03
	v_add_co_ci_u32_e64 v4, null, 0, v4, s2                    // 0000004283F0: D5207C04 000A0880
	s_clause 0x7                                               // 0000004283F8: BF850007
	global_load_b32 v18, v[3:4], off                           // 0000004283FC: DC520000 127C0003
	global_load_b32 v19, v[3:4], off offset:128                // 000000428404: DC520080 137C0003
	global_load_b32 v20, v[3:4], off offset:256                // 00000042840C: DC520100 147C0003
	global_load_b32 v21, v[3:4], off offset:384                // 000000428414: DC520180 157C0003
	global_load_b32 v22, v[3:4], off offset:512                // 00000042841C: DC520200 167C0003
	global_load_b32 v25, v[3:4], off offset:640                // 000000428424: DC520280 197C0003
	global_load_b32 v31, v[3:4], off offset:768                // 00000042842C: DC520300 1F7C0003
	global_load_b32 v35, v[3:4], off offset:896                // 000000428434: DC520380 237C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 00000042843C: 8C7E037E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v37, 0             // 000000428440: CA100080 26240080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v33, 0             // 000000428448: CA100080 24200080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v23, 0             // 000000428450: CA100080 22160080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v29, 0             // 000000428458: CA100080 201C0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 000000428460: CA100080 1E1A0080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v17, 0             // 000000428468: CA100080 18100080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v15, 0             // 000000428470: CA100080 1A0E0080
	v_mov_b32_e32 v28, 0                                       // 000000428478: 7E380280
	s_ashr_i32 s27, s26, 31                                    // 00000042847C: 861B9F1A
	s_and_saveexec_b32 s3, vcc_lo                              // 000000428480: BE83206A
	s_cbranch_execz 1024                                       // 000000428484: BFA50400 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1b88>
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v4, 5, v12     // 000000428488: CA220080 0F041885
	v_mad_u32_u24 v7, 0x420, v11, v13                          // 000000428490: D60B0007 043616FF 00000420
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v9, 16, v0         // 00000042849C: CA240080 1A080090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004284A4: BF870243
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v5, 0x3f0, v4   // 0000004284A8: CA200080 1C0408FF 000003F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v12                            // 0000004284B4: 7C9A1880
	.long 0xd73c0002                                           // 0000004284B8: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000004284BC: 0202028A
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v40, 1, v1      // 0000004284C0: CA200080 11280281
	v_lshrrev_b32_e32 v8, 5, v5                                // 0000004284C8: 32100A85
	v_lshl_or_b32 v41, v1, 5, v9                               // 0000004284CC: D6560029 04250B01
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 0000004284D4: CA240080 18040AFF 000007E0
	v_mul_u32_u24_e32 v6, 0x420, v11                           // 0000004284E0: 160C16FF 00000420
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004284E8: BF870224
	v_subrev_nc_u32_e32 v8, 32, v8                             // 0000004284EC: 4E1010A0
	v_add_nc_u32_e32 v42, 0x2800, v7                           // 0000004284F0: 4A540EFF 00002800
	v_sub_nc_u32_e32 v4, v5, v4                                // 0000004284F8: 4C080905
	v_sub_nc_u32_e32 v39, 0, v16                               // 0000004284FC: 4C4E2080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v38, 0             // 000000428500: CA100080 1D260080
	v_cndmask_b32_e32 v1, 31, v8, vcc_lo                       // 000000428508: 0202109F
	.long 0xd7006a02                                           // 00000042850C: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000428510: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000428514: BF870191
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 000000428518: D5207C03 01AA0605
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v7, 1, v1       // 000000428520: CA200080 1E060281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000428528: BF870093
	.long 0xd7006a02                                           // 00000042852C: D7006A02
	v_cndmask_b32_e32 v1, v2, v13, vcc_lo                      // 000000428530: 02021B02
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000428534: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042853C: BF870193
	v_dual_mov_b32 v32, 0 :: v_dual_and_b32 v5, 31, v7         // 000000428540: CA240080 20040E9F
	.long 0xd7006a02                                           // 000000428548: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000042854C: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000428550: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 000000428554: D5207C03 01AA0609
	v_dual_mov_b32 v34, 0 :: v_dual_add_nc_u32 v43, 0xfffffc30, v4// 00000042855C: CA200080 222A08FF FFFFFC30
	v_lshl_add_u32 v1, v1, 2, v6                               // 000000428568: D6460001 04190501
	v_lshl_add_u32 v4, v5, 2, v6                               // 000000428570: D6460004 04190505
	.long 0xd7006a09                                           // 000000428578: D7006A09
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 00000042857C: 020204FF 00000400
	v_add_co_ci_u32_e64 v10, null, 0, v3, vcc_lo               // 000000428584: D5207C0A 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042858C: BF870214
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v44, 0x2800, v1 // 000000428590: CA200080 1B2C02FF 00002800
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v45, 0x2800, v4 // 00000042859C: CA200080 242C08FF 00002800
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v14, 0             // 0000004285A8: CA100080 170E0080
	v_mov_b32_e32 v33, 0                                       // 0000004285B0: 7E420280
	v_mov_b32_e32 v37, 0                                       // 0000004285B4: 7E4A0280
	s_mov_b32 s4, 0                                            // 0000004285B8: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000004285BC: B0051EEE
	s_branch 910                                               // 0000004285C0: BFA0038E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1afc>
	s_or_b32 exec_lo, exec_lo, s2                              // 0000004285C4: 8C7E027E
	ds_load_2addr_b32 v[46:47], v45 offset1:32                 // 0000004285C8: D8DC2000 2E00002D
	ds_load_2addr_b32 v[56:57], v42 offset1:32                 // 0000004285D0: D8DC2000 3800002A
	ds_load_2addr_b32 v[50:51], v44 offset1:32                 // 0000004285D8: D8DC2000 3200002C
	ds_load_b128 v[1:4], v41                                   // 0000004285E0: DBFC0000 01000029
	ds_load_b128 v[5:8], v41 offset:5120                       // 0000004285E8: DBFC1400 05000029
	ds_load_2addr_b32 v[52:53], v44 offset0:64 offset1:96      // 0000004285F0: D8DC6040 3400002C
	ds_load_2addr_b32 v[54:55], v45 offset0:64 offset1:96      // 0000004285F8: D8DC6040 3600002D
	v_add_nc_u32_e32 v40, 1, v40                               // 000000428600: 4A505081
	.long 0xd7000209                                           // 000000428604: D7000209
	v_cndmask_b32_e32 v1, 0x400, v9, vcc_lo                    // 000000428608: 020212FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000428610: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s2                  // 000000428614: D5207C0A 000A1480
	v_add_nc_u32_e32 v41, 32, v41                              // 00000042861C: 4A5252A0
	s_waitcnt lgkmcnt(6)                                       // 000000428620: BF89FC67
	v_mov_b32_e32 v49, v46                                     // 000000428624: 7E62032E
	s_waitcnt lgkmcnt(5)                                       // 000000428628: BF89FC57
	v_bfe_u32 v46, v56, 12, 16                                 // 00000042862C: D610002E 02411938
	v_bfe_u32 v58, v56, 8, 16                                  // 000000428634: D610003A 02411138
	v_bfe_u32 v59, v56, 4, 16                                  // 00000042863C: D610003B 02410938
	v_and_b32_e32 v56, 0xffff, v56                             // 000000428644: 367070FF 0000FFFF
	s_waitcnt lgkmcnt(4)                                       // 00000042864C: BF89FC47
	.long 0xd73d0031                                           // 000000428650: D73D0031
	v_cndmask_b32_e32 v1, v43, v49, vcc_lo                     // 000000428654: 0202632B
	v_mov_b32_e32 v48, v51                                     // 000000428658: 7E600333
	v_bfe_u32 v60, v57, 8, 16                                  // 00000042865C: D610003C 02411139
	v_bfe_u32 v51, v57, 12, 16                                 // 000000428664: D6100033 02411939
	v_bfe_u32 v61, v57, 4, 16                                  // 00000042866C: D610003D 02410939
	v_and_b32_e32 v57, 0xffff, v57                             // 000000428674: 367272FF 0000FFFF
	.long 0xd72c0032                                           // 00000042867C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000428680: 02025CFF 83DCD12D
	.long 0xd73d002e                                           // 000000428688: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 00000042868C: 02025F2B
	.long 0xd72c0030                                           // 000000428690: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000428694: 020278FF 83DCD12D
	v_bfe_u32 v60, v49, 12, 16                                 // 00000042869C: D610003C 02411931
	.long 0xd72c002f                                           // 0000004286A4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004286A8: 020266FF 83DCD12D
	.long 0xd72c0033                                           // 0000004286B0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000004286B4: 02027AFF 83DCD12D
	v_bfe_u32 v61, v49, 8, 16                                  // 0000004286BC: D610003D 02411131
	.long 0xd72c003a                                           // 0000004286C4: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000004286C8: 020274FF 83DCD12D
	.long 0xd72c003c                                           // 0000004286D0: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000004286D4: 020278FF 83DCD12D
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004286DC: D6220032 03FD0132 00006400
	.long 0xd72c0038                                           // 0000004286E8: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000004286EC: 020270FF 83DCD12D
	.long 0xd72c003d                                           // 0000004286F4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000004286F8: 02027AFF 83DCD12D
	.long 0xd72c003b                                           // 000000428700: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000428704: 020276FF 83DCD12D
	v_bfe_u32 v63, v46, 12, 16                                 // 00000042870C: D610003F 0241192E
	v_and_b32_e32 v50, 0xffff, v50                             // 000000428714: 366464FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000042871C: D622003A 03FD013A 00006400
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000428728: D622003C 03FD013C 00006400
	v_bfe_u32 v64, v46, 8, 16                                  // 000000428734: D6100040 0241112E
	v_sad_u8 v56, v56, 0, 0x6400                               // 00000042873C: D6220038 03FD0138 00006400
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000428748: D622003D 03FD013D 00006400
	v_lshl_or_b32 v50, v58, 16, v50                            // 000000428754: D6560032 04C9213A
	v_and_b32_e32 v60, 0xffff, v60                             // 00000042875C: 367878FF 0000FFFF
	v_bfe_u32 v65, v46, 4, 16                                  // 000000428764: D6100041 0241092E
	.long 0xd72c003f                                           // 00000042876C: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000428770: 02027EFF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000428778: D622003B 03FD013B 00006400
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428784: CC0E0032 0BFC0B32 0000C931
	v_lshl_or_b32 v60, v61, 16, v60                            // 000000428790: D656003C 04F1213D
	v_lshlrev_b32_e32 v56, 16, v56                             // 000000428798: 30707090
	.long 0xd72c0040                                           // 00000042879C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000004287A0: 020280FF 83DCD12D
	.long 0xd72c003d                                           // 0000004287A8: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000004287AC: 020282FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000004287B4: D622002F 03FD012F 00006400
	v_pk_fma_f16 v58, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004287C0: CC0E003A 0BFC0B3C 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 0000004287CC: 365C5CFF 0000FFFF
	v_and_or_b32 v56, 0xffff, v59, v56                         // 0000004287D4: D6570038 04E276FF 0000FFFF
	v_sad_u8 v59, v63, 0, 0x6400                               // 0000004287E0: D622003B 03FD013F 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 0000004287EC: 365E5EFF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 0000004287F4: BF89FC37
	v_dot2acc_f32_f16 v15, v58, v1                             // 0000004287F8: 041E033A
	.long 0xd72c002e                                           // 0000004287FC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000428800: 02025CFF 83DCD12D
	v_sad_u8 v60, v64, 0, 0x6400                               // 000000428808: D622003C 03FD0140 00006400
	v_and_b32_e32 v59, 0xffff, v59                             // 000000428814: 367676FF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 00000042881C: D622003D 03FD013D 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000428828: D6220030 03FD0130 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000428834: BF89FC27
	v_dot2acc_f32_f16 v17, v58, v5                             // 000000428838: 04220B3A
	v_bfe_u32 v62, v49, 4, 16                                  // 00000042883C: D610003E 02410931
	v_lshl_or_b32 v59, v60, 16, v59                            // 000000428844: D656003B 04ED213C
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000042884C: D622002E 03FD012E 00006400
	v_lshl_or_b32 v60, v48, 16, v47                            // 000000428858: D656003C 04BD2130
	v_sad_u8 v48, v51, 0, 0x6400                               // 000000428860: D6220030 03FD0133 00006400
	s_waitcnt lgkmcnt(0)                                       // 00000042886C: BF89FC07
	v_mov_b32_e32 v51, v54                                     // 000000428870: 7E660336
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428874: CC0E003A 0BFC0B3B 0000C931
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000428880: 305C5C90
	.long 0xd72c003e                                           // 000000428884: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 000000428888: 02027CFF 83DCD12D
	.long 0xd72c0039                                           // 000000428890: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000428894: 020272FF 83DCD12D
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000042889C: CC0E0038 0BFC0B38 0000C931
	v_dot2acc_f32_f16 v28, v58, v5                             // 0000004288A8: 04380B3A
	v_and_or_b32 v46, 0xffff, v61, v46                         // 0000004288AC: D657002E 04BA7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000004288B8: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004288C4: BF870002
	v_pk_fma_f16 v59, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004288C8: CC0E003B 0BFC0B2E 0000C931
	v_and_b32_e32 v49, 0xffff, v49                             // 0000004288D4: 366262FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000004288DC: D6220039 03FD0139 00006400
	ds_load_2addr_b32 v[46:47], v42 offset0:64 offset1:96      // 0000004288E8: D8DC6040 2E00002A
	v_dual_dot2acc_f32_f16 v27, v58, v1 :: v_dual_dot2acc_f32_f16 v28, v59, v6// 0000004288F0: CB18033A 1B1C0D3B
	.long 0xd72c0031                                           // 0000004288F8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000004288FC: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000428904: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000428908: BF870191
	v_and_or_b32 v54, 0xffff, v48, v57                         // 00000042890C: D6570036 04E660FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000428918: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000428924: BF870112
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428928: CC0E0036 0BFC0B36 0000C931
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000428934: 30626290
	s_waitcnt lgkmcnt(0)                                       // 000000428938: BF89FC07
	v_bfe_u32 v57, v46, 4, 16                                  // 00000042893C: D6100039 0241092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000428944: BF870112
	v_and_or_b32 v49, 0xffff, v62, v49                         // 000000428948: D6570031 04C67CFF 0000FFFF
	.long 0xd72c0039                                           // 000000428954: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000428958: 020272FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000428960: BF870092
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428964: CC0E0031 0BFC0B31 0000C931
	v_dot2acc_f32_f16 v15, v49, v2                             // 000000428970: 041E0531
	v_dot2acc_f32_f16 v17, v49, v6                             // 000000428974: 04220D31
	.long 0xd73d0030                                           // 000000428978: D73D0030
	v_cndmask_b32_e32 v1, v43, v51, vcc_lo                     // 00000042897C: 0202672B
	v_bfe_u32 v52, v46, 12, 16                                 // 000000428980: D6100034 0241192E
	v_pk_fma_f16 v49, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428988: CC0E0031 0BFC0B3C 0000C931
	v_dot2acc_f32_f16 v15, v50, v3                             // 000000428994: 041E0732
	v_dot2acc_f32_f16 v17, v50, v7                             // 000000428998: 04220F32
	v_bfe_u32 v50, v48, 12, 16                                 // 00000042899C: D6100032 02411930
	v_and_b32_e32 v51, 0xffff, v48                             // 0000004289A4: 366660FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004289AC: BF870224
	v_dual_dot2acc_f32_f16 v15, v56, v4 :: v_dual_dot2acc_f32_f16 v28, v49, v7// 0000004289B0: CB180938 0F1C0F31
	.long 0xd72c0034                                           // 0000004289B8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004289BC: 020268FF 83DCD12D
	.long 0xd72c0032                                           // 0000004289C4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004289C8: 020264FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004289D0: BF870214
	.long 0xd72c0033                                           // 0000004289D4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000004289D8: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v28, v54, v8                             // 0000004289E0: 04381136
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004289E4: BF870214
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000004289E8: D6220034 03FD0134 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004289F4: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000428A00: BF870114
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000428A04: D6220033 03FD0133 00006400
	v_dual_dot2acc_f32_f16 v17, v56, v8 :: v_dual_and_b32 v50, 0xffff, v50// 000000428A10: CB241138 113264FF 0000FFFF
	v_bfe_u32 v56, v46, 8, 16                                  // 000000428A1C: D6100038 0241112E
	v_and_b32_e32 v46, 0xffff, v46                             // 000000428A24: 365C5CFF 0000FFFF
	v_dot2acc_f32_f16 v27, v59, v2                             // 000000428A2C: 0436053B
	v_lshlrev_b32_e32 v51, 16, v51                             // 000000428A30: 30666690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000428A34: BF870214
	.long 0xd72c003a                                           // 000000428A38: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000428A3C: 020270FF 83DCD12D
	.long 0xd72c002e                                           // 000000428A44: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000428A48: 02025CFF 83DCD12D
	v_mov_b32_e32 v56, v53                                     // 000000428A50: 7E700335
	v_sad_u8 v53, v57, 0, 0x6400                               // 000000428A54: D6220035 03FD0139 00006400
	v_bfe_u32 v57, v47, 4, 16                                  // 000000428A60: D6100039 0241092F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000428A68: BF870004
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000428A6C: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v27, v49, v3                             // 000000428A78: 04360731
	v_bfe_u32 v49, v48, 8, 16                                  // 000000428A7C: D6100031 02411130
	v_bfe_u32 v48, v48, 4, 16                                  // 000000428A84: D6100030 02410930
	.long 0xd72c0039                                           // 000000428A8C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000428A90: 020272FF 83DCD12D
	v_lshlrev_b32_e32 v46, 16, v46                             // 000000428A98: 305C5C90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000428A9C: BF870214
	.long 0xd72c0031                                           // 000000428AA0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000428AA4: 020262FF 83DCD12D
	.long 0xd72c0030                                           // 000000428AAC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000428AB0: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000428AB8: BF870223
	v_and_or_b32 v46, 0xffff, v53, v46                         // 000000428ABC: D657002E 04BA6AFF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000428AC8: D6220039 03FD0139 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000428AD4: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000428AE0: BF870114
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000428AE4: D6220030 03FD0130 00006400
	v_lshl_or_b32 v50, v49, 16, v50                            // 000000428AF0: D6560032 04C92131
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000428AF8: BF870232
	v_and_or_b32 v51, 0xffff, v48, v51                         // 000000428AFC: D6570033 04CE60FF 0000FFFF
	.long 0xd73d0030                                           // 000000428B08: D73D0030
	v_cndmask_b32_e32 v1, v43, v55, vcc_lo                     // 000000428B0C: 02026F2B
	v_pk_fma_f16 v56, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428B10: CC0E0038 0BFC0B2E 0000C931
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428B1C: CC0E0032 0BFC0B32 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000428B28: BF870214
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428B2C: CC0E0033 0BFC0B33 0000C931
	v_bfe_u32 v55, v48, 12, 16                                 // 000000428B38: D6100037 02411930
	v_bfe_u32 v53, v48, 8, 16                                  // 000000428B40: D6100035 02411130
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000428B48: BF870234
	v_dual_dot2acc_f32_f16 v24, v50, v5 :: v_dual_and_b32 v49, 0xffff, v52// 000000428B4C: CB240B32 183068FF 0000FFFF
	v_sad_u8 v52, v58, 0, 0x6400                               // 000000428B58: D6220034 03FD013A 00006400
	v_dot2acc_f32_f16 v26, v50, v1                             // 000000428B64: 04340332
	.long 0xd72c002e                                           // 000000428B68: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000428B6C: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000428B74: BF870004
	v_dot2acc_f32_f16 v24, v51, v6                             // 000000428B78: 04300D33
	v_bfe_u32 v53, v47, 8, 16                                  // 000000428B7C: D6100035 0241112F
	v_lshl_or_b32 v49, v52, 16, v49                            // 000000428B84: D6560031 04C52134
	.long 0xd72c0034                                           // 000000428B8C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000428B90: 02026EFF 83DCD12D
	v_dot2acc_f32_f16 v26, v51, v2                             // 000000428B98: 04340533
	v_and_b32_e32 v58, 0xffff, v47                             // 000000428B9C: 36745EFF 0000FFFF
	.long 0xd72c0035                                           // 000000428BA4: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000428BA8: 02026AFF 83DCD12D
	v_pk_fma_f16 v55, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428BB0: CC0E0037 0BFC0B31 0000C931
	v_and_b32_e32 v49, 0xffff, v48                             // 000000428BBC: 366260FF 0000FFFF
	v_bfe_u32 v48, v48, 4, 16                                  // 000000428BC4: D6100030 02410930
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000428BCC: D622002E 03FD012E 00006400
	v_sad_u8 v50, v52, 0, 0x6400                               // 000000428BD8: D6220032 03FD0134 00006400
	v_bfe_u32 v52, v47, 12, 16                                 // 000000428BE4: D6100034 0241192F
	v_dot2acc_f32_f16 v26, v55, v3                             // 000000428BEC: 04340737
	.long 0xd72c0031                                           // 000000428BF0: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000428BF4: 020262FF 83DCD12D
	.long 0xd72c0030                                           // 000000428BFC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000428C00: 020260FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 000000428C08: 366464FF 0000FFFF
	.long 0xd72c0034                                           // 000000428C10: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000428C14: 020268FF 83DCD12D
	.long 0xd72c003a                                           // 000000428C1C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000428C20: 020274FF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000428C28: D6220035 03FD0135 00006400
	v_dot2acc_f32_f16 v26, v56, v4                             // 000000428C34: 04340938
	v_lshl_or_b32 v59, v46, 16, v50                            // 000000428C38: D656003B 04C9212E
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000428C40: D6220031 03FD0131 00006400
	ds_load_2addr_b32 v[46:47], v45 offset0:128 offset1:160    // 000000428C4C: D8DCA080 2E00002D
	v_dot2acc_f32_f16 v27, v54, v4                             // 000000428C54: 04360936
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000428C58: D6220034 03FD0134 00006400
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000428C64: D6220030 03FD0130 00006400
	v_lshlrev_b32_e32 v60, 16, v49                             // 000000428C70: 30786290
	ds_load_2addr_b32 v[49:50], v44 offset0:128 offset1:160    // 000000428C74: D8DCA080 3100002C
	v_sad_u8 v51, v58, 0, 0x6400                               // 000000428C7C: D6220033 03FD013A 00006400
	v_pk_fma_f16 v58, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428C88: CC0E003A 0BFC0B3B 0000C931
	v_and_b32_e32 v52, 0xffff, v52                             // 000000428C94: 366868FF 0000FFFF
	v_and_or_b32 v48, 0xffff, v48, v60                         // 000000428C9C: D6570030 04F260FF 0000FFFF
	v_dot2acc_f32_f16 v24, v55, v7                             // 000000428CA8: 04300F37
	v_lshlrev_b32_e32 v59, 16, v51                             // 000000428CAC: 30766690
	v_dot2acc_f32_f16 v29, v58, v1                             // 000000428CB0: 043A033A
	v_lshl_or_b32 v52, v53, 16, v52                            // 000000428CB4: D6560034 04D12135
	v_pk_fma_f16 v53, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428CBC: CC0E0035 0BFC0B30 0000C931
	v_dot2acc_f32_f16 v30, v58, v5                             // 000000428CC8: 043C0B3A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000428CCC: BF870003
	v_pk_fma_f16 v60, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428CD0: CC0E003C 0BFC0B34 0000C931
	ds_load_2addr_b32 v[51:52], v42 offset0:128 offset1:160    // 000000428CDC: D8DCA080 3300002A
	s_waitcnt lgkmcnt(2)                                       // 000000428CE4: BF89FC27
	v_mov_b32_e32 v48, v46                                     // 000000428CE8: 7E60032E
	v_and_or_b32 v46, 0xffff, v57, v59                         // 000000428CEC: D657002E 04EE72FF 0000FFFF
	v_dual_dot2acc_f32_f16 v29, v53, v2 :: v_dual_dot2acc_f32_f16 v24, v56, v8// 000000428CF8: CB180535 1D181138
	v_dot2acc_f32_f16 v30, v53, v6                             // 000000428D00: 043C0D35
	s_waitcnt lgkmcnt(1)                                       // 000000428D04: BF89FC17
	.long 0xd73d0030                                           // 000000428D08: D73D0030
	v_cndmask_b32_e32 v1, v43, v48, vcc_lo                     // 000000428D0C: 0202612B
	v_pk_fma_f16 v49, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428D10: CC0E0031 0BFC0B2E 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000428D1C: BF870122
	v_dual_dot2acc_f32_f16 v29, v60, v3 :: v_dual_and_b32 v54, 0xffff, v48// 000000428D20: CB24073C 1D3660FF 0000FFFF
	v_bfe_u32 v46, v48, 12, 16                                 // 000000428D2C: D610002E 02411930
	v_dot2acc_f32_f16 v29, v49, v4                             // 000000428D34: 043A0931
	v_bfe_u32 v55, v48, 8, 16                                  // 000000428D38: D6100037 02411130
	v_bfe_u32 v48, v48, 4, 16                                  // 000000428D40: D6100030 02410930
	.long 0xd72c0036                                           // 000000428D48: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000428D4C: 02026CFF 83DCD12D
	.long 0xd72c002e                                           // 000000428D54: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000428D58: 02025CFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000428D60: BF89FC07
	v_bfe_u32 v53, v51, 12, 16                                 // 000000428D64: D6100035 02411933
	v_bfe_u32 v56, v51, 8, 16                                  // 000000428D6C: D6100038 02411133
	v_bfe_u32 v57, v51, 4, 16                                  // 000000428D74: D6100039 02410933
	v_and_b32_e32 v51, 0xffff, v51                             // 000000428D7C: 366666FF 0000FFFF
	.long 0xd72c0037                                           // 000000428D84: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000428D88: 02026EFF 83DCD12D
	.long 0xd72c0030                                           // 000000428D90: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000428D94: 020260FF 83DCD12D
	.long 0xd72c0035                                           // 000000428D9C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000428DA0: 02026AFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000428DA8: D622002E 03FD012E 00006400
	.long 0xd72c0033                                           // 000000428DB4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000428DB8: 020266FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000428DC0: D6220036 03FD0136 00006400
	.long 0xd72c0038                                           // 000000428DCC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000428DD0: 020270FF 83DCD12D
	.long 0xd72c0039                                           // 000000428DD8: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000428DDC: 020272FF 83DCD12D
	v_and_b32_e32 v46, 0xffff, v46                             // 000000428DE4: 365C5CFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000428DEC: D6220037 03FD0137 00006400
	v_sad_u8 v58, v48, 0, 0x6400                               // 000000428DF8: D622003A 03FD0130 00006400
	v_lshlrev_b32_e32 v54, 16, v54                             // 000000428E04: 306C6C90
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000428E08: D6220033 03FD0133 00006400
	v_mov_b32_e32 v48, v50                                     // 000000428E14: 7E600332
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000428E18: D6220035 03FD0135 00006400
	v_lshl_or_b32 v55, v55, 16, v46                            // 000000428E24: D6560037 04B92137
	v_and_or_b32 v50, 0xffff, v58, v54                         // 000000428E2C: D6570032 04DA74FF 0000FFFF
	v_lshlrev_b32_e32 v51, 16, v51                             // 000000428E38: 30666690
	.long 0xd73d002e                                           // 000000428E3C: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 000000428E40: 02025F2B
	v_and_b32_e32 v53, 0xffff, v53                             // 000000428E44: 366A6AFF 0000FFFF
	v_sad_u8 v54, v56, 0, 0x6400                               // 000000428E4C: D6220036 03FD0138 00006400
	v_pk_fma_f16 v47, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428E58: CC0E002F 0BFC0B37 0000C931
	v_pk_fma_f16 v48, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428E64: CC0E0030 0BFC0B32 0000C931
	v_sad_u8 v50, v57, 0, 0x6400                               // 000000428E70: D6220032 03FD0139 00006400
	v_dot2acc_f32_f16 v30, v60, v7                             // 000000428E7C: 043C0F3C
	v_lshl_or_b32 v53, v54, 16, v53                            // 000000428E80: D6560035 04D52136
	v_bfe_u32 v54, v46, 12, 16                                 // 000000428E88: D6100036 0241192E
	v_dot2acc_f32_f16 v23, v47, v1                             // 000000428E90: 042E032F
	v_and_or_b32 v50, 0xffff, v50, v51                         // 000000428E94: D6570032 04CE64FF 0000FFFF
	v_dot2acc_f32_f16 v30, v49, v8                             // 000000428EA0: 043C1131
	v_bfe_u32 v49, v46, 8, 16                                  // 000000428EA4: D6100031 0241112E
	.long 0xd72c0033                                           // 000000428EAC: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000428EB0: 02026CFF 83DCD12D
	v_dot2acc_f32_f16 v23, v48, v2                             // 000000428EB8: 042E0530
	v_pk_fma_f16 v54, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428EBC: CC0E0036 0BFC0B32 0000C931
	v_and_b32_e32 v50, 0xffff, v46                             // 000000428EC8: 36645CFF 0000FFFF
	v_dot2acc_f32_f16 v32, v47, v5                             // 000000428ED0: 04400B2F
	.long 0xd72c0031                                           // 000000428ED4: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000428ED8: 020262FF 83DCD12D
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428EE0: CC0E0035 0BFC0B35 0000C931
	v_bfe_u32 v55, v52, 12, 16                                 // 000000428EEC: D6100037 02411934
	v_sad_u8 v47, v51, 0, 0x6400                               // 000000428EF4: D622002F 03FD0133 00006400
	.long 0xd72c0032                                           // 000000428F00: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000428F04: 020264FF 83DCD12D
	v_bfe_u32 v51, v46, 4, 16                                  // 000000428F0C: D6100033 0241092E
	v_bfe_u32 v56, v52, 8, 16                                  // 000000428F14: D6100038 02411134
	v_dot2acc_f32_f16 v23, v53, v3                             // 000000428F1C: 042E0735
	v_and_b32_e32 v57, 0xffff, v47                             // 000000428F20: 36725EFF 0000FFFF
	ds_load_2addr_b32 v[46:47], v45 offset0:192 offset1:224    // 000000428F28: D8DCE0C0 2E00002D
	.long 0xd72c0033                                           // 000000428F30: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000428F34: 020266FF 83DCD12D
	v_sad_u8 v58, v49, 0, 0x6400                               // 000000428F3C: D622003A 03FD0131 00006400
	v_sad_u8 v59, v50, 0, 0x6400                               // 000000428F48: D622003B 03FD0132 00006400
	ds_load_2addr_b32 v[49:50], v44 offset0:192 offset1:224    // 000000428F54: D8DCE0C0 3100002C
	.long 0xd72c0037                                           // 000000428F5C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000428F60: 02026EFF 83DCD12D
	.long 0xd72c0038                                           // 000000428F68: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000428F6C: 020270FF 83DCD12D
	v_lshl_or_b32 v57, v58, 16, v57                            // 000000428F74: D6560039 04E5213A
	v_dual_dot2acc_f32_f16 v23, v54, v4 :: v_dual_lshlrev_b32 v58, 16, v59// 000000428F7C: CB220936 173A7690
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000428F84: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000428F90: BF870233
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428F94: CC0E0039 0BFC0B39 0000C931
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000428FA0: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v32, v48, v6                             // 000000428FAC: 04400D30
	v_and_or_b32 v51, 0xffff, v51, v58                         // 000000428FB0: D6570033 04EA66FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000428FBC: BF870214
	v_dot2acc_f32_f16 v33, v57, v1                             // 000000428FC0: 04420339
	v_and_b32_e32 v55, 0xffff, v55                             // 000000428FC4: 366E6EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000428FCC: BF870004
	v_dot2acc_f32_f16 v32, v53, v7                             // 000000428FD0: 04400F35
	s_waitcnt lgkmcnt(1)                                       // 000000428FD4: BF89FC17
	v_mov_b32_e32 v48, v46                                     // 000000428FD8: 7E60032E
	v_sad_u8 v46, v56, 0, 0x6400                               // 000000428FDC: D622002E 03FD0138 00006400
	v_pk_fma_f16 v56, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000428FE8: CC0E0038 0BFC0B33 0000C931
	v_and_b32_e32 v60, 0xffff, v52                             // 000000428FF4: 367868FF 0000FFFF
	v_bfe_u32 v52, v52, 4, 16                                  // 000000428FFC: D6100034 02410934
	s_waitcnt lgkmcnt(0)                                       // 000000429004: BF89FC07
	.long 0xd73d0030                                           // 000000429008: D73D0030
	v_cndmask_b32_e32 v1, v43, v48, vcc_lo                     // 00000042900C: 0202612B
	v_lshl_or_b32 v46, v46, 16, v55                            // 000000429010: D656002E 04DD212E
	v_dot2acc_f32_f16 v33, v56, v2                             // 000000429018: 04420538
	.long 0xd72c003b                                           // 00000042901C: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000429020: 020278FF 83DCD12D
	.long 0xd72c0034                                           // 000000429028: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 00000042902C: 020268FF 83DCD12D
	v_bfe_u32 v53, v48, 12, 16                                 // 000000429034: D6100035 02411930
	v_bfe_u32 v55, v48, 8, 16                                  // 00000042903C: D6100037 02411130
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000429044: CC0E002E 0BFC0B2E 0000C931
	v_sad_u8 v58, v59, 0, 0x6400                               // 000000429050: D622003A 03FD013B 00006400
	v_sad_u8 v59, v52, 0, 0x6400                               // 00000042905C: D622003B 03FD0134 00006400
	ds_load_2addr_b32 v[51:52], v42 offset0:192 offset1:224    // 000000429068: D8DCE0C0 3300002A
	.long 0xd72c0035                                           // 000000429070: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000429074: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v33, v46, v3                             // 00000042907C: 0442072E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429080: BF870092
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000429084: D6220035 03FD0135 00006400
	v_dual_dot2acc_f32_f16 v32, v54, v8 :: v_dual_and_b32 v53, 0xffff, v53// 000000429090: CB241136 20346AFF 0000FFFF
	.long 0xd72c0036                                           // 00000042909C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000004290A0: 02026EFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 0000004290A8: BF89FC07
	v_bfe_u32 v55, v51, 12, 16                                 // 0000004290AC: D6100037 02411933
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004290B4: BF870112
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000004290B8: D6220036 03FD0136 00006400
	.long 0xd72c0037                                           // 0000004290C4: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000004290C8: 02026EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004290D0: BF870112
	v_lshl_or_b32 v53, v54, 16, v53                            // 0000004290D4: D6560035 04D52136
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004290DC: D6220037 03FD0137 00006400
	v_dot2acc_f32_f16 v34, v57, v5                             // 0000004290E8: 04440B39
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004290EC: BF870233
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004290F0: CC0E0035 0BFC0B35 0000C931
	v_lshlrev_b32_e32 v58, 16, v58                             // 0000004290FC: 30747490
	v_bfe_u32 v57, v51, 8, 16                                  // 000000429100: D6100039 02411133
	v_dual_dot2acc_f32_f16 v34, v56, v6 :: v_dual_and_b32 v55, 0xffff, v55// 000000429108: CB240D38 22366EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000429114: BF870234
	v_dual_dot2acc_f32_f16 v37, v53, v5 :: v_dual_and_b32 v56, 0xffff, v51// 000000429118: CB240B35 253866FF 0000FFFF
	v_bfe_u32 v51, v51, 4, 16                                  // 000000429124: D6100033 02410933
	v_and_or_b32 v49, 0xffff, v59, v58                         // 00000042912C: D6570031 04EA76FF 0000FFFF
	v_dot2acc_f32_f16 v34, v46, v7                             // 000000429138: 04440F2E
	v_and_b32_e32 v46, 0xffff, v48                             // 00000042913C: 365C60FF 0000FFFF
	v_bfe_u32 v48, v48, 4, 16                                  // 000000429144: D6100030 02410930
	.long 0xd72c0036                                           // 00000042914C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000429150: 020270FF 83DCD12D
	.long 0xd72c0038                                           // 000000429158: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000042915C: 020272FF 83DCD12D
	.long 0xd72c0033                                           // 000000429164: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000429168: 020266FF 83DCD12D
	.long 0xd72c002e                                           // 000000429170: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000429174: 02025CFF 83DCD12D
	.long 0xd72c0030                                           // 00000042917C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000429180: 020260FF 83DCD12D
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000429188: CC0E0031 0BFC0B31 0000C931
	v_dot2acc_f32_f16 v36, v53, v1                             // 000000429194: 04480335
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000429198: D6220036 03FD0136 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000004291A4: D6220033 03FD0133 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000004291B0: D622002E 03FD012E 00006400
	v_sad_u8 v57, v48, 0, 0x6400                               // 0000004291BC: D6220039 03FD0130 00006400
	v_mov_b32_e32 v48, v50                                     // 0000004291C8: 7E600332
	v_sad_u8 v50, v56, 0, 0x6400                               // 0000004291CC: D6220032 03FD0138 00006400
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000004291D8: 306C6C90
	v_dual_dot2acc_f32_f16 v33, v49, v4 :: v_dual_lshlrev_b32 v46, 16, v46// 0000004291DC: CB220931 212E5C90
	v_dot2acc_f32_f16 v34, v49, v8                             // 0000004291E4: 04441131
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004291E8: BF870002
	v_and_or_b32 v56, 0xffff, v57, v46                         // 0000004291EC: D6570038 04BA72FF 0000FFFF
	.long 0xd73d002e                                           // 0000004291F8: D73D002E
	v_cndmask_b32_e32 v1, v43, v47, vcc_lo                     // 0000004291FC: 02025F2B
	v_lshl_or_b32 v47, v50, 16, v55                            // 000000429200: D656002F 04DD2132
	v_and_or_b32 v48, 0xffff, v51, v54                         // 000000429208: D6570030 04DA66FF 0000FFFF
	v_bfe_u32 v55, v52, 12, 16                                 // 000000429214: D6100037 02411934
	v_pk_fma_f16 v49, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000042921C: CC0E0031 0BFC0B38 0000C931
	v_bfe_u32 v56, v52, 8, 16                                  // 000000429228: D6100038 02411134
	v_bfe_u32 v50, v46, 12, 16                                 // 000000429230: D6100032 0241192E
	v_and_b32_e32 v51, 0xffff, v46                             // 000000429238: 36665CFF 0000FFFF
	v_bfe_u32 v54, v46, 8, 16                                  // 000000429240: D6100036 0241112E
	v_bfe_u32 v46, v46, 4, 16                                  // 000000429248: D610002E 0241092E
	.long 0xd72c0037                                           // 000000429250: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000429254: 02026EFF 83DCD12D
	.long 0xd72c0032                                           // 00000042925C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000429260: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 000000429268: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 00000042926C: 020266FF 83DCD12D
	.long 0xd72c0036                                           // 000000429274: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000429278: 02026CFF 83DCD12D
	.long 0xd72c002e                                           // 000000429280: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000429284: 02025CFF 83DCD12D
	v_bfe_u32 v57, v52, 4, 16                                  // 00000042928C: D6100039 02410934
	v_and_b32_e32 v52, 0xffff, v52                             // 000000429294: 366868FF 0000FFFF
	.long 0xd72c0038                                           // 00000042929C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000004292A0: 020270FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000004292A8: D6220037 03FD0137 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000004292B4: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000004292C0: D6220033 03FD0133 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000004292CC: D6220036 03FD0136 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000004292D8: D622002E 03FD012E 00006400
	.long 0xd72c0034                                           // 0000004292E4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000004292E8: 020268FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 0000004292F0: 366464FF 0000FFFF
	v_lshlrev_b32_e32 v51, 16, v51                             // 0000004292F8: 30666690
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004292FC: CC0E002F 0BFC0B2F 0000C931
	v_dot2acc_f32_f16 v36, v49, v2                             // 000000429308: 04480531
	v_dot2acc_f32_f16 v37, v49, v6                             // 00000042930C: 044A0D31
	v_lshl_or_b32 v50, v54, 16, v50                            // 000000429310: D6560032 04C92136
	v_and_or_b32 v46, 0xffff, v46, v51                         // 000000429318: D657002E 04CE5CFF 0000FFFF
	.long 0xd72c0033                                           // 000000429324: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 000000429328: 020272FF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v55                             // 000000429330: 366C6EFF 0000FFFF
	v_sad_u8 v55, v56, 0, 0x6400                               // 000000429338: D6220037 03FD0138 00006400
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000429344: CC0E0032 0BFC0B32 0000C931
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000429350: D6220034 03FD0134 00006400
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000042935C: CC0E002E 0BFC0B2E 0000C931
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000429368: CC0E0030 0BFC0B30 0000C931
	v_lshl_or_b32 v53, v55, 16, v54                            // 000000429374: D6560035 04D92137
	v_dot2acc_f32_f16 v38, v50, v1                             // 00000042937C: 044C0332
	v_dot2acc_f32_f16 v14, v50, v5                             // 000000429380: 041C0B32
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000429384: D6220033 03FD0133 00006400
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000429390: 30686890
	v_pk_fma_f16 v1, v53, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000429394: CC0E0001 0BFC0B35 0000C931
	v_dot2acc_f32_f16 v38, v46, v2                             // 0000004293A0: 044C052E
	v_dot2acc_f32_f16 v14, v46, v6                             // 0000004293A4: 041C0D2E
	v_dot2acc_f32_f16 v36, v47, v3                             // 0000004293A8: 0448072F
	v_and_or_b32 v5, 0xffff, v51, v52                          // 0000004293AC: D6570005 04D266FF 0000FFFF
	v_dot2acc_f32_f16 v37, v47, v7                             // 0000004293B8: 044A0F2F
	v_dot2acc_f32_f16 v38, v1, v3                              // 0000004293BC: 044C0701
	v_dual_dot2acc_f32_f16 v14, v1, v7 :: v_dual_add_nc_u32 v1, v39, v40// 0000004293C0: CB200F01 0E005127
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004293C8: BF870234
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000004293CC: CC0E0002 0BFC0B05 0000C931
	v_dot2acc_f32_f16 v36, v48, v4                             // 0000004293D8: 04480930
	v_dot2acc_f32_f16 v37, v48, v8                             // 0000004293DC: 044A1130
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 0000004293E0: 7C940281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004293E4: BF8704B4
	v_dot2acc_f32_f16 v38, v2, v4                              // 0000004293E8: 044C0902
	v_dot2acc_f32_f16 v14, v2, v8                              // 0000004293EC: 041C1102
	s_or_b32 s4, vcc_lo, s4                                    // 0000004293F0: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000004293F4: 917E047E
	s_cbranch_execz 34                                         // 0000004293F8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1b84>
	s_mov_b32 s2, exec_lo                                      // 0000004293FC: BE82007E
	s_waitcnt vmcnt(6)                                         // 000000429400: BF891BF7
	ds_store_2addr_b32 v42, v18, v19 offset1:32                // 000000429404: D8382000 0013122A
	s_waitcnt vmcnt(4)                                         // 00000042940C: BF8913F7
	ds_store_2addr_b32 v42, v20, v21 offset0:64 offset1:96     // 000000429410: D8386040 0015142A
	s_waitcnt vmcnt(2)                                         // 000000429418: BF890BF7
	ds_store_2addr_b32 v42, v22, v25 offset0:128 offset1:160   // 00000042941C: D838A080 0019162A
	s_waitcnt vmcnt(0)                                         // 000000429424: BF8903F7
	ds_store_2addr_b32 v42, v31, v35 offset0:192 offset1:224   // 000000429428: D838E0C0 00231F2A
	.long 0xd4c1007e                                           // 000000429430: D4C1007E
	v_cndmask_b32_e32 v1, v40, v16, vcc_lo                     // 000000429434: 02022128
	s_cbranch_execz 64610                                      // 000000429438: BFA5FC62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xcc4>
	s_clause 0x7                                               // 00000042943C: BF850007
	global_load_b32 v18, v[9:10], off                          // 000000429440: DC520000 127C0009
	global_load_b32 v19, v[9:10], off offset:128               // 000000429448: DC520080 137C0009
	global_load_b32 v20, v[9:10], off offset:256               // 000000429450: DC520100 147C0009
	global_load_b32 v21, v[9:10], off offset:384               // 000000429458: DC520180 157C0009
	global_load_b32 v22, v[9:10], off offset:512               // 000000429460: DC520200 167C0009
	global_load_b32 v25, v[9:10], off offset:640               // 000000429468: DC520280 197C0009
	global_load_b32 v31, v[9:10], off offset:768               // 000000429470: DC520300 1F7C0009
	global_load_b32 v35, v[9:10], off offset:896               // 000000429478: DC520380 237C0009
	s_branch 64592                                             // 000000429480: BFA0FC50 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xcc4>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000429484: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000429488: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 00000042948C: 8C7E037E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v2, v17           // 000000429490: CA10010F 01020111
	v_dual_mov_b32 v3, v27 :: v_dual_mov_b32 v6, v28           // 000000429498: CA10011B 0306011C
	v_dual_mov_b32 v4, v26 :: v_dual_mov_b32 v5, v24           // 0000004294A0: CA10011A 04040118
	v_dual_mov_b32 v8, v29 :: v_dual_mov_b32 v9, v30           // 0000004294A8: CA10011D 0808011E
	v_dual_mov_b32 v7, v23 :: v_dual_mov_b32 v10, v32          // 0000004294B0: CA100117 070A0120
	s_waitcnt vmcnt(6)                                         // 0000004294B8: BF891BF7
	v_dual_mov_b32 v16, v33 :: v_dual_mov_b32 v19, v36         // 0000004294BC: CA100121 10120124
	v_mov_b32_e32 v18, v34                                     // 0000004294C4: 7E240322
	s_waitcnt vmcnt(4)                                         // 0000004294C8: BF8913F7
	v_dual_mov_b32 v20, v37 :: v_dual_mov_b32 v21, v38         // 0000004294CC: CA100125 14140126
	s_waitcnt vmcnt(3)                                         // 0000004294D4: BF890FF7
	v_mov_b32_e32 v22, v14                                     // 0000004294D8: 7E2C030E
	s_mov_b32 s2, 0x76543210                                   // 0000004294DC: BE8200FF 76543210
	s_waitcnt vmcnt(0)                                         // 0000004294E4: BF8903F7
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000004294E8: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000004294F4: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 000000429500: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 00000042950C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 000000429518: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 000000429524: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 000000429530: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 00000042953C: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 000000429548: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 000000429554: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 000000429560: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 00000042956C: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 000000429578: D65C0013 03FC0513 FEDCBA98
	v_permlanex16_b32 v20, v20, s2, 0xfedcba98                 // 000000429584: D65C0014 03FC0514 FEDCBA98
	v_permlanex16_b32 v21, v21, s2, 0xfedcba98                 // 000000429590: D65C0015 03FC0515 FEDCBA98
	v_permlanex16_b32 v22, v22, s2, 0xfedcba98                 // 00000042959C: D65C0016 03FC0516 FEDCBA98
	.long 0xd44c0002                                           // 0000004295A8: D44C0002
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 0000004295AC: 02021890
	s_barrier                                                  // 0000004295B0: BFBD0000
	buffer_gl0_inv                                             // 0000004295B4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 0000004295BC: BE832002
	s_cbranch_execz 34                                         // 0000004295C0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d4c>
	v_dual_add_f32 v12, v14, v22 :: v_dual_add_f32 v19, v36, v19// 0000004295C4: C9082D0E 0C122724
	v_dual_add_f32 v14, v38, v21 :: v_dual_add_f32 v3, v27, v3 // 0000004295CC: C9082B26 0E02071B
	v_dual_add_f32 v18, v34, v18 :: v_dual_add_f32 v1, v15, v1 // 0000004295D4: C9082522 1200030F
	v_lshl_or_b32 v13, v11, 10, v13                            // 0000004295DC: D656000D 0435150B
	v_add_f32_e32 v6, v28, v6                                  // 0000004295E4: 060C0D1C
	v_add_f32_e32 v2, v17, v2                                  // 0000004295E8: 06040511
	v_add_f32_e32 v8, v29, v8                                  // 0000004295EC: 0610111D
	v_add_f32_e32 v4, v26, v4                                  // 0000004295F0: 0608091A
	v_dual_add_f32 v20, v37, v20 :: v_dual_add_f32 v9, v30, v9 // 0000004295F4: C9082925 1408131E
	v_dual_add_f32 v16, v33, v16 :: v_dual_add_f32 v5, v24, v5 // 0000004295FC: C9082121 10040B18
	v_dual_add_f32 v10, v32, v10 :: v_dual_add_f32 v7, v23, v7 // 000000429604: C9081520 0A060F17
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 00000042960C: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 000000429614: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 00000042961C: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 000000429624: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v16 offset0:64 offset1:80      // 00000042962C: D8385040 0010070D
	ds_store_2addr_b32 v13, v10, v18 offset0:192 offset1:208   // 000000429634: D838D0C0 00120A0D
	ds_store_2addr_b32 v13, v19, v14 offset0:96 offset1:112    // 00000042963C: D8387060 000E130D
	ds_store_2addr_b32 v13, v20, v12 offset0:224 offset1:240   // 000000429644: D838F0E0 000C140D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000042964C: 8C7E037E
	.long 0xd44c0003                                           // 000000429650: D44C0003
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000429654: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000042965C: BF89FC07
	s_barrier                                                  // 000000429660: BFBD0000
	buffer_gl0_inv                                             // 000000429664: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000042966C: BE842003
	s_cbranch_execnz 7                                         // 000000429670: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d90>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000429674: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 000000429678: BF048215
	s_mov_b32 s4, -1                                           // 00000042967C: BE8400C1
	s_cbranch_scc0 33                                          // 000000429680: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e08>
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000429684: 8B6A047E
	s_cbranch_vccz 63896                                       // 000000429688: BFA3F998 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 209                                               // 00000042968C: BFA000D1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20d4>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000429690: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000429694: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 00000042969C: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 0000004296A4: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 0000004296AC: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 0000004296B0: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004296B4: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 0000004296B8: 06020501
	s_waitcnt lgkmcnt(1)                                       // 0000004296BC: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000004296C0: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 0000004296C4: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 0000004296CC: 06060903
	s_waitcnt lgkmcnt(1)                                       // 0000004296D0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004296D4: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000004296D8: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000004296DC: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000004296E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004296E4: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000004296E8: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000004296EC: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000004296F0: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 0000004296F8: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000004296FC: BF048215
	s_mov_b32 s4, -1                                           // 000000429700: BE8400C1
	s_cbranch_scc1 65503                                       // 000000429704: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d84>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 000000429708: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 000000429710: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 000000429714: BF89FC07
	s_barrier                                                  // 000000429718: BFBD0000
	buffer_gl0_inv                                             // 00000042971C: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 000000429724: 80010804
	s_addc_u32 s4, s5, s9                                      // 000000429728: 82040905
	s_and_saveexec_b32 s0, s3                                  // 00000042972C: BE802003
	s_cbranch_execz 41                                         // 000000429730: BFA50029 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ed8>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000429734: 32020087
	s_ashr_i32 s5, s20, 31                                     // 000000429738: 86059F14
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000042973C: 30080082
	s_lshl_b32 s8, s26, 7                                      // 000000429740: 8408871A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000429744: BF870009
	s_ashr_i32 s9, s8, 31                                      // 000000429748: 86099F08
	v_lshl_or_b32 v1, s23, 1, v1                               // 00000042974C: D6560001 04050217
	ds_load_b32 v4, v4 offset:8192                             // 000000429754: D8D82000 04000004
	s_lshl_b64 s[8:9], s[8:9], 2                               // 00000042975C: 84888208
	.long 0xd72c0003                                           // 000000429760: D72C0003
	v_cndmask_b32_e32 v0, v1, v5, vcc_lo                       // 000000429764: 02000B01
	v_mad_u64_u32 v[1:2], null, v1, s20, 0                     // 000000429768: D6FE7C01 02002901
	s_ashr_i32 s5, s23, 31                                     // 000000429770: 86059F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000429774: BF870499
	s_mul_i32 s5, s5, s20                                      // 000000429778: 96051405
	v_add3_u32 v2, v2, v3, s5                                  // 00000042977C: D6550002 00160702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000429784: 360600FF 0000007F
	s_add_u32 s5, s1, s8                                       // 00000042978C: 80050801
	s_addc_u32 s8, s4, s9                                      // 000000429790: 82080904
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000429794: BF870112
	.long 0xd73c0001                                           // 000000429798: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000042979C: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000004297A0: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004297A4: BF870092
	.long 0xd7006a01                                           // 0000004297A8: D7006A01
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 0000004297AC: 02020205
	v_add_co_ci_u32_e64 v2, null, s8, v2, vcc_lo               // 0000004297B0: D5207C02 01AA0408
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004297B8: BF870092
	.long 0xd7006a01                                           // 0000004297BC: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000004297C0: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000004297C4: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 0000004297CC: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 0000004297D0: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004297D8: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000004297DC: 861D9F1C
	.long 0xd44a0000                                           // 0000004297E0: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004297E4: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000004297E8: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000004297EC: BC7C0000
	buffer_gl1_inv                                             // 0000004297F0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004297F8: E0AC0000 00000000
	s_add_u32 s5, s6, s8                                       // 000000429800: 80050806
	s_addc_u32 s6, s7, s9                                      // 000000429804: 82060907
	s_barrier                                                  // 000000429808: BFBD0000
	buffer_gl0_inv                                             // 00000042980C: E0AC0000 00000000
	s_and_saveexec_b32 s7, s0                                  // 000000429814: BE872000
	s_cbranch_execz 29                                         // 000000429818: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f90>
	s_mov_b32 s9, exec_lo                                      // 00000042981C: BE89007E
	s_mov_b32 s8, exec_lo                                      // 000000429820: BE88007E
	.long 0xd71f0001                                           // 000000429824: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 000000429828: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042982C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000429830: 7D940280
	s_cbranch_execz 9                                          // 000000429834: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f5c>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 000000429838: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000042983C: BF8704B9
	s_add_u32 s10, s5, s10                                     // 000000429840: 800A0A05
	s_addc_u32 s11, s6, s11                                    // 000000429844: 820B0B06
	s_bcnt1_i32_b32 s9, s9                                     // 000000429848: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 00000042984C: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 000000429854: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 00000042985C: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 000000429860: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 000000429864: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429868: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 00000042986C: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 000000429874: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000429878: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 00000042987C: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000429880: D5010001 01A90280
	ds_store_b32 v2, v1 offset:18688                           // 000000429888: D8344900 00000102
	s_or_b32 exec_lo, exec_lo, s7                              // 000000429890: 8C7E077E
	v_mov_b32_e32 v1, 0                                        // 000000429894: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000429898: BF89FC07
	s_barrier                                                  // 00000042989C: BFBD0000
	buffer_gl0_inv                                             // 0000004298A0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:18688                            // 0000004298A8: D8D84900 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004298B0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004298B4: 7C940280
	s_cbranch_vccnz 69                                         // 0000004298B8: BFA40045 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20d0>
	buffer_gl1_inv                                             // 0000004298BC: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004298C4: E0AC0000 00000000
	s_and_saveexec_b32 s7, s3                                  // 0000004298CC: BE872003
	s_cbranch_execz 51                                         // 0000004298D0: BFA50033 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20a0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 0000004298D4: 360400FF 0000007F
	s_lshl_b32 s8, s26, 7                                      // 0000004298DC: 8408871A
	s_ashr_i32 s3, s20, 31                                     // 0000004298E0: 86039F14
	s_ashr_i32 s9, s8, 31                                      // 0000004298E4: 86099F08
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004298E8: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 0000004298EC: CA220080 02020482
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000004298F4: 84888208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004298F8: BF8700A9
	s_add_u32 s1, s1, s8                                       // 0000004298FC: 80010801
	s_addc_u32 s4, s4, s9                                      // 000000429900: 82040904
	.long 0xd7000103                                           // 000000429904: D7000103
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000429908: 02020601
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042990C: BF870001
	v_add_co_ci_u32_e64 v4, null, s4, 0, s1                    // 000000429910: D5207C04 00050004
	s_mov_b32 s1, s20                                          // 000000429918: BE810014
	s_nop 0                                                    // 00000042991C: BF800000
	s_nop 0                                                    // 000000429920: BF800000
	s_nop 0                                                    // 000000429924: BF800000
	s_nop 0                                                    // 000000429928: BF800000
	s_nop 0                                                    // 00000042992C: BF800000
	s_nop 0                                                    // 000000429930: BF800000
	s_nop 0                                                    // 000000429934: BF800000
	s_nop 0                                                    // 000000429938: BF800000
	s_nop 0                                                    // 00000042993C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000429940: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s1, 0                      // 000000429944: D6FE7C05 02000301
	s_add_i32 s21, s21, -1                                     // 00000042994C: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 000000429950: BF068015
	v_mad_u64_u32 v[6:7], null, v1, s3, v[6:7]                 // 000000429954: D6FE7C06 04180701
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000042995C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429960: BF870092
	.long 0xd73c0005                                           // 000000429964: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000429968: 02020A82
	.long 0xd7006a05                                           // 00000042996C: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000429970: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429974: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000429978: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000429980: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000429988: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 00000042998C: 06040B02
	s_cbranch_scc0 65515                                       // 000000429990: BFA1FFEB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2040>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000429994: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000429998: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s7                              // 0000004299A0: 8C7E077E
	s_and_saveexec_b32 s1, s0                                  // 0000004299A4: BE812000
	s_cbranch_execz 6                                          // 0000004299A8: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20c4>
	s_lshl_b64 s[8:9], s[26:27], 2                             // 0000004299AC: 8488821A
	v_mov_b32_e32 v1, 0                                        // 0000004299B0: 7E020280
	s_add_u32 s4, s5, s8                                       // 0000004299B4: 80040805
	s_addc_u32 s5, s6, s9                                      // 0000004299B8: 82050906
	global_store_b32 v1, v1, s[4:5]                            // 0000004299BC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004299C4: 8C7E017E
	s_cbranch_execz 63688                                      // 0000004299C8: BFA5F8C8 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 0000004299CC: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20d4>
	s_branch 63686                                             // 0000004299D0: BFA0F8C6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v11                          // 0000004299D4: 7C881612
	.long 0xd44c0000                                           // 0000004299D8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000004299DC: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 0000004299E0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000004299E4: BC7C0000
	s_barrier                                                  // 0000004299E8: BFBD0000
	buffer_gl0_inv                                             // 0000004299EC: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000004299F4: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004299F8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000004299FC: BE812000
	s_cbranch_execz 63674                                      // 000000429A00: BFA5F8BA <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000429A04: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429A08: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000429A0C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 000000429A10: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429A18: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000429A1C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000429A24: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000429A2C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000429A34: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000429A3C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000429A44: 36140081
	s_waitcnt lgkmcnt(3)                                       // 000000429A48: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 000000429A4C: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000429A54: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000429A58: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000429A60: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000429A64: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000429A6C: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000429A70: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 000000429A78: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 000000429A7C: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 000000429A84: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000429A88: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 000000429A8C: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 000000429A94: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 000000429A98: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 000000429AA0: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000429AA8: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 000000429AAC: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 000000429AB4: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 000000429AB8: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000429ABC: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000429AC0: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000429AC4: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429AC8: 7E1402FA FF016109
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429AD0: 7E1E02FA FF01610E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429AD8: 7E2202FA FF016108
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429AE0: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000429AE8: D5010009 21AA1309
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000429AF0: D501000E 21AA1D0E
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000429AF8: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 000000429B00: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429B04: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000429B0C: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000429B14: D5010008 21AA1108
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429B1C: 7E2402FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000429B24: D5010004 21AA0904
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429B2C: 7E2602FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000429B34: D5010003 21AA0703
	v_add_f32_e32 v6, v7, v6                                   // 000000429B3C: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 000000429B40: 060E1509
	v_add_f32_e32 v9, v14, v15                                 // 000000429B44: 06121F0E
	v_add_f32_e32 v5, v5, v16                                  // 000000429B48: 060A2105
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000429B4C: 7E2802FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000429B54: D5010002 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000429B5C: 7C941880
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429B60: 7E1C02FA FF016209
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429B68: 7E1402FA FF016206
	.long 0xd44a0000                                           // 000000429B70: D44A0000
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 000000429B74: 02021A80
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429B78: 7E1802FA FF016207
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000429B80: D5010009 21AA1309
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000429B88: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000429B90: D5010007 21AA0F07
	v_add_f32_e32 v8, v8, v17                                  // 000000429B98: 06102308
	v_mov_b32_dpp v15, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429B9C: 7E1E02FA FF016205
	v_add_f32_e32 v9, v9, v14                                  // 000000429BA4: 06121D09
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000429BA8: D5010005 21AA0B05
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v4, v4, v18   // 000000429BB0: C9081907 07042504
	v_add_f32_e32 v3, v3, v19                                  // 000000429BB8: 06062703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000429BBC: BF870004
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429BC0: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000429BC8: D5010009 20021309
	v_add_f32_e32 v6, v6, v10                                  // 000000429BD0: 060C1506
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429BD4: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000429BDC: D5010007 20020F07
	v_add_f32_e32 v15, v5, v15                                 // 000000429BE4: 061E1F05
	v_add_f32_e32 v21, v9, v13                                 // 000000429BE8: 062A1B09
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429BEC: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000429BF4: D5010006 20020D06
	v_add_f32_e32 v2, v2, v20                                  // 000000429BFC: 06042902
	v_mov_b32_dpp v16, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429C00: 7E2002FA FF016208
	v_add_f32_e32 v14, v7, v12                                 // 000000429C08: 061C1907
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429C0C: 7E1802FA FF016203
	v_add_f32_e32 v5, v6, v10                                  // 000000429C14: 060A1506
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429C18: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000429C20: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 000000429C28: D5010006 21AA1108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000429C30: D5010003 21AA0703
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000429C38: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000429C40: D5010002 21AA0502
	v_add_f32_e32 v4, v4, v10                                  // 000000429C48: 06081504
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429C4C: 7E0E02FA FF01640F
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 000000429C54: D5010009 20021F0F
	v_add_f32_e32 v6, v6, v16                                  // 000000429C5C: 060C2106
	v_add_f32_e32 v3, v3, v12                                  // 000000429C60: 06061903
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429C64: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000429C6C: D5010004 20020904
	v_dual_add_f32 v2, v2, v13 :: v_dual_add_f32 v19, v9, v7   // 000000429C74: C9081B02 02120F09
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429C7C: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000429C84: D5010006 20020D06
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429C8C: 7E1A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000429C94: D5010003 20020703
	v_add_f32_e32 v15, v4, v12                                 // 000000429C9C: 061E1904
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000429CA0: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000429CA8: D5010002 20020502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000429CB0: BF870234
	v_dual_add_f32 v17, v6, v10 :: v_dual_add_f32 v12, v3, v13 // 000000429CB4: C9081506 110C1B03
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CBC: 7E1002FA FF016805
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CC4: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v2, v16                                  // 000000429CCC: 06122102
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CD0: 7E2C02FA FF016815
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CD8: 7E2802FA FF016813
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CE0: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CE8: 7E2002FA FF01680F
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CF0: 7E1A02FA FF01680C
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000429CF8: 7E1402FA FF016809
	s_and_b32 exec_lo, exec_lo, s2                             // 000000429D00: 8B7E027E
	s_cbranch_execz 63481                                      // 000000429D04: BFA5F7F9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 000000429D08: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 000000429D10: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 000000429D14: BF118018
	s_cselect_b32 s1, -1, 0                                    // 000000429D18: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000429D1C: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000429D20: 3408069F
	.long 0xd44a0000                                           // 000000429D24: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000429D28: 02020080
	s_lshr_b32 s2, s20, 31                                     // 000000429D2C: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000429D30: BF870009
	s_add_i32 s2, s20, s2                                      // 000000429D34: 81020214
	.long 0xd73c0001                                           // 000000429D38: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000429D3C: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 000000429D40: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v11, 0                    // 000000429D48: D6FF7C04 02021614
	s_ashr_i32 s2, s2, 1                                       // 000000429D50: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 000000429D54: BF108018
	v_add_f32_e32 v0, v0, v8                                   // 000000429D58: 06001100
	.long 0xd7006a06                                           // 000000429D5C: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000429D60: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000429D64: BF870191
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 000000429D68: D5207C07 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000429D70: 100000FF 3DB504F3
	.long 0xd73c0004                                           // 000000429D78: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000429D7C: 02020881
	global_load_d16_b16 v24, v[6:7], off                       // 000000429D80: DC820000 187C0006
	s_waitcnt vmcnt(0)                                         // 000000429D88: BF8903F7
	v_fma_mix_f32 v26, v24, v0, neg(0) op_sel_hi:[1,0,0]       // 000000429D8C: CC20001A 8A020118
	v_mad_i64_i32 v[24:25], null, s2, v11, 0                   // 000000429D94: D6FF7C18 02021602
	.long 0xd7006a00                                           // 000000429D9C: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000429DA0: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000429DA4: BF870211
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 000000429DA8: D5207C08 01AA0A0F
	v_bfe_u32 v27, v26, 16, 1                                  // 000000429DB0: D610001B 0205211A
	v_ashrrev_i32_e32 v11, 31, v3                              // 000000429DB8: 3416069F
	.long 0xd73c0004                                           // 000000429DBC: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000429DC0: 02023081
	s_delay_alu instid0(VALU_DEP_3)                            // 000000429DC4: BF870003
	v_add3_u32 v24, v26, v27, 0x7fff                           // 000000429DC8: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 569                                         // 000000429DD4: BFA20239 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dbc>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000429DD8: BF870123
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000429DDC: 32321697
	v_mov_b32_e32 v29, s14                                     // 000000429DE0: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 000000429DE4: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429DE8: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000429DEC: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 000000429DF4: 4C363503
	v_mov_b32_e32 v26, s15                                     // 000000429DF8: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000429DFC: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000429E00: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 000000429E04: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 000000429E0C: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 000000429E14: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000429E1C: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 000000429E20: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 000000429E24: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 000000429E28: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000429E2C: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 000000429E30: 3438369F
	.long 0xd73c0019                                           // 000000429E34: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000429E38: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429E3C: BF870093
	.long 0xd7006a1d                                           // 000000429E40: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 000000429E44: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 000000429E48: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000429E50: BF870194
	.long 0xd73c001b                                           // 000000429E54: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 000000429E58: 02023681
	.long 0xd7006a19                                           // 000000429E5C: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 000000429E60: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000429E64: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 000000429E68: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 000000429E70: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000429E74: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429E78: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 000000429E7C: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000429E84: DC960000 007C1819
	s_cbranch_execnz 7                                         // 000000429E8C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x25ac>
	.long 0xd7006a19                                           // 000000429E90: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000429E94: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429E98: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 000000429E9C: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000429EA4: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 000000429EAC: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000429EB4: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000429EBC: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429EC0: BF870091
	v_add_f32_e32 v14, v14, v23                                // 000000429EC4: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000429EC8: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000429ED0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000429ED4: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 000000429ED8: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 000000429EE0: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 000000429EE8: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429EF0: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 000000429EF4: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 495                                        // 000000429F00: BFA401EF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dc0>
	v_or_b32_e32 v24, 16, v3                                   // 000000429F04: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000429F08: 32321697
	v_mov_b32_e32 v27, s15                                     // 000000429F0C: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 000000429F10: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429F14: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 000000429F18: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000429F1C: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429F24: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 000000429F28: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 000000429F2C: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 000000429F34: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 000000429F3C: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000429F40: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000429F44: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 000000429F48: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 000000429F4C: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 000000429F50: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000429F54: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000429F58: 3436349F
	.long 0xd7006a1c                                           // 000000429F5C: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 000000429F60: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000429F64: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 000000429F68: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000429F70: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000429F74: BF870114
	.long 0xd73c001a                                           // 000000429F78: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000429F7C: 02023481
	.long 0xd73c0018                                           // 000000429F80: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000429F84: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429F88: BF870091
	.long 0xd7006a18                                           // 000000429F8C: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 000000429F90: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 000000429F94: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000429F9C: BF870092
	.long 0xd7006a18                                           // 000000429FA0: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000429FA4: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 000000429FA8: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 000000429FB0: DC960000 007C1718
	s_cbranch_execnz 7                                         // 000000429FB8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x26d8>
	.long 0xd7006a18                                           // 000000429FBC: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000429FC0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000429FC4: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 000000429FC8: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 000000429FD0: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 000000429FD8: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000429FE0: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000429FE8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000429FEC: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 000000429FF0: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000429FF4: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000429FF8: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A000: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A004: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 00000042A008: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 00000042A010: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A018: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 00000042A01C: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 422                                        // 00000042A028: BFA401A6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dc4>
	v_or_b32_e32 v22, 32, v3                                   // 00000042A02C: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 00000042A030: 322E1697
	v_mov_b32_e32 v25, s15                                     // 00000042A034: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 00000042A038: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A03C: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 00000042A040: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 00000042A044: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A04C: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 00000042A050: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 00000042A054: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 00000042A05C: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 00000042A064: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 00000042A068: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A06C: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 00000042A070: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 00000042A074: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 00000042A078: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A07C: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 00000042A080: 3432309F
	.long 0xd7006a1a                                           // 00000042A084: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 00000042A088: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042A08C: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 00000042A090: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000042A098: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042A09C: BF870114
	.long 0xd73c0018                                           // 00000042A0A0: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 00000042A0A4: 02023081
	.long 0xd73c0016                                           // 00000042A0A8: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000042A0AC: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A0B0: BF870091
	.long 0xd7006a16                                           // 00000042A0B4: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 00000042A0B8: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 00000042A0BC: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A0C4: BF870092
	.long 0xd7006a16                                           // 00000042A0C8: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 00000042A0CC: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 00000042A0D0: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 00000042A0D8: DC960000 007C1516
	s_cbranch_execnz 7                                         // 00000042A0E0: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2800>
	.long 0xd7006a16                                           // 00000042A0E4: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A0E8: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A0EC: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 00000042A0F0: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 00000042A0F8: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 00000042A100: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 00000042A108: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042A110: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A114: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 00000042A118: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042A11C: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 00000042A120: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A128: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A12C: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 00000042A130: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 00000042A138: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A140: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000042A144: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 349                                        // 00000042A150: BFA4015D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dc8>
	v_or_b32_e32 v20, 48, v3                                   // 00000042A154: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 00000042A158: 322A1697
	v_mov_b32_e32 v23, s15                                     // 00000042A15C: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 00000042A160: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A164: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 00000042A168: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000042A16C: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A174: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 00000042A178: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000042A17C: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 00000042A184: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 00000042A18C: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 00000042A190: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A194: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 00000042A198: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 00000042A19C: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 00000042A1A0: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A1A4: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000042A1A8: 342E2C9F
	.long 0xd7006a18                                           // 00000042A1AC: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 00000042A1B0: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042A1B4: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 00000042A1B8: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000042A1C0: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042A1C4: BF870114
	.long 0xd73c0016                                           // 00000042A1C8: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000042A1CC: 02022C81
	.long 0xd73c0014                                           // 00000042A1D0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000042A1D4: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A1D8: BF870091
	.long 0xd7006a14                                           // 00000042A1DC: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 00000042A1E0: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 00000042A1E4: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A1EC: BF870092
	.long 0xd7006a14                                           // 00000042A1F0: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000042A1F4: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 00000042A1F8: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 00000042A200: DC960000 007C1314
	s_cbranch_execnz 7                                         // 00000042A208: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2928>
	.long 0xd7006a14                                           // 00000042A20C: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A210: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A214: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 00000042A218: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 00000042A220: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 00000042A228: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 00000042A230: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042A238: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A23C: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 00000042A240: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042A244: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000042A248: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A250: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A254: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 00000042A258: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 00000042A260: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A268: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000042A26C: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 276                                        // 00000042A278: BFA40114 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dcc>
	v_or_b32_e32 v18, 64, v3                                   // 00000042A27C: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 00000042A280: 32261697
	v_mov_b32_e32 v21, s15                                     // 00000042A284: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 00000042A288: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A28C: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 00000042A290: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 00000042A294: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A29C: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 00000042A2A0: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 00000042A2A4: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 00000042A2AC: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 00000042A2B4: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 00000042A2B8: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A2BC: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 00000042A2C0: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 00000042A2C4: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 00000042A2C8: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A2CC: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000042A2D0: 342A289F
	.long 0xd7006a16                                           // 00000042A2D4: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 00000042A2D8: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042A2DC: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 00000042A2E0: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000042A2E8: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042A2EC: BF870114
	.long 0xd73c0014                                           // 00000042A2F0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000042A2F4: 02022881
	.long 0xd73c0012                                           // 00000042A2F8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000042A2FC: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A300: BF870091
	.long 0xd7006a12                                           // 00000042A304: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 00000042A308: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 00000042A30C: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A314: BF870092
	.long 0xd7006a12                                           // 00000042A318: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 00000042A31C: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 00000042A320: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 00000042A328: DC960000 007C1112
	s_cbranch_execnz 7                                         // 00000042A330: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a50>
	.long 0xd7006a12                                           // 00000042A334: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A338: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A33C: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 00000042A340: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 00000042A348: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 00000042A350: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 00000042A358: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042A360: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A364: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 00000042A368: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042A36C: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000042A370: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A378: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A37C: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 00000042A380: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 00000042A388: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A390: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000042A394: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 203                                        // 00000042A3A0: BFA400CB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dd0>
	v_or_b32_e32 v16, 0x50, v3                                 // 00000042A3A4: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 00000042A3AC: 32221697
	v_mov_b32_e32 v19, s15                                     // 00000042A3B0: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 00000042A3B4: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A3B8: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 00000042A3BC: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 00000042A3C0: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A3C8: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 00000042A3CC: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 00000042A3D0: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 00000042A3D8: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 00000042A3E0: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 00000042A3E4: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A3E8: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 00000042A3EC: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 00000042A3F0: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 00000042A3F4: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A3F8: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000042A3FC: 3426249F
	.long 0xd7006a14                                           // 00000042A400: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 00000042A404: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042A408: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 00000042A40C: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000042A414: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042A418: BF870114
	.long 0xd73c0012                                           // 00000042A41C: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000042A420: 02022481
	.long 0xd73c0010                                           // 00000042A424: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000042A428: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A42C: BF870091
	.long 0xd7006a10                                           // 00000042A430: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 00000042A434: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 00000042A438: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A440: BF870092
	.long 0xd7006a10                                           // 00000042A444: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 00000042A448: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 00000042A44C: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000042A454: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 00000042A45C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b7c>
	.long 0xd7006a10                                           // 00000042A460: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A464: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A468: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 00000042A46C: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 00000042A474: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 00000042A47C: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 00000042A484: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042A48C: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A490: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 00000042A494: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042A498: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 00000042A49C: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A4A4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A4A8: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 00000042A4AC: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 00000042A4B4: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A4BC: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000042A4C0: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 129                                        // 00000042A4CC: BFA40081 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dd4>
	v_or_b32_e32 v13, 0x60, v3                                 // 00000042A4D0: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 00000042A4D8: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A4DC: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 00000042A4E0: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 00000042A4E8: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000042A4F0: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 00000042A4F4: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 00000042A4F8: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 00000042A4FC: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 00000042A500: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 00000042A508: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A510: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 00000042A514: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 00000042A518: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 00000042A51C: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A520: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 00000042A524: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 00000042A528: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 00000042A52C: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A530: BF870193
	.long 0xd73c000f                                           // 00000042A534: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 00000042A538: 02021E81
	.long 0xd7006a0d                                           // 00000042A53C: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 00000042A540: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000042A544: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 00000042A548: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 00000042A550: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 00000042A554: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A558: BF870093
	.long 0xd7006a0d                                           // 00000042A55C: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 00000042A560: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 00000042A564: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A56C: BF870092
	.long 0xd7006a0f                                           // 00000042A570: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 00000042A574: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 00000042A578: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 00000042A580: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 00000042A588: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ca8>
	.long 0xd7006a0f                                           // 00000042A58C: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A590: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A594: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 00000042A598: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 00000042A5A0: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 00000042A5A8: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 00000042A5B0: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 00000042A5B8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000042A5BC: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 00000042A5C0: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000042A5C4: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 00000042A5C8: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000042A5D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A5D4: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 00000042A5D8: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 00000042A5E0: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A5E8: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000042A5EC: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 55                                         // 00000042A5F8: BFA40037 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dd8>
	v_or_b32_e32 v3, 0x70, v3                                  // 00000042A5FC: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 00000042A604: 320E1697
	v_mov_b32_e32 v10, s15                                     // 00000042A608: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A60C: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 00000042A610: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 00000042A618: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 00000042A620: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000042A624: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 00000042A628: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 00000042A62C: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000042A630: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 00000042A634: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 00000042A63C: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 00000042A644: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000042A648: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000042A64C: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 00000042A650: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 00000042A654: 02061818
	.long 0xd73c0009                                           // 00000042A658: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000042A65C: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A660: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000042A664: 3418169F
	.long 0xd7006a07                                           // 00000042A668: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 00000042A66C: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000042A670: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 00000042A674: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 00000042A67C: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000042A680: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A684: BF870093
	.long 0xd7006a07                                           // 00000042A688: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 00000042A68C: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 00000042A690: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000042A698: BF870092
	.long 0xd7006a03                                           // 00000042A69C: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 00000042A6A0: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 00000042A6A4: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 00000042A6AC: DC960000 007C0603
	s_cbranch_execnz 62861                                     // 00000042A6B4: BFA6F58D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 00000042A6B8: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2dd8>
	s_branch 65012                                             // 00000042A6BC: BFA0FDF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2590>
	s_branch 65086                                             // 00000042A6C0: BFA0FE3E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x26bc>
	s_branch 65159                                             // 00000042A6C4: BFA0FE87 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x27e4>
	s_branch 65232                                             // 00000042A6C8: BFA0FED0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x290c>
	s_branch 65305                                             // 00000042A6CC: BFA0FF19 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a34>
	s_branch 65379                                             // 00000042A6D0: BFA0FF63 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b60>
	s_branch 65453                                             // 00000042A6D4: BFA0FFAD <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi2ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2c8c>
	.long 0xd7006a00                                           // 00000042A6D8: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000042A6DC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000042A6E0: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 00000042A6E4: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 00000042A6EC: DC9600E0 007C0600
	s_endpgm                                                   // 00000042A6F4: BFB00000
		...

