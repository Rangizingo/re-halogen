00000000009ed900 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b512 s[4:19], s[0:1], null                          // 0000009ED900: F4100100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 0000009ED908: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009ED910: BF8704A9
	s_lshr_b32 s20, s3, 31                                     // 0000009ED914: 85149F03
	s_ashr_i32 s3, s3, 3                                       // 0000009ED918: 86038303
	s_add_i32 s20, s3, s20                                     // 0000009ED91C: 81141403
	s_mov_b32 s3, exec_lo                                      // 0000009ED920: BE83007E
	s_ashr_i32 s21, s20, 31                                    // 0000009ED924: 86159F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009ED928: BF870009
	s_lshl_b64 s[22:23], s[20:21], 2                           // 0000009ED92C: 84968214
	s_waitcnt lgkmcnt(0)                                       // 0000009ED930: BF89FC07
	s_add_u32 s8, s8, s22                                      // 0000009ED934: 80081608
	s_addc_u32 s9, s9, s23                                     // 0000009ED938: 82091709
	s_load_b32 s8, s[8:9], null                                // 0000009ED93C: F4000204 F8000000
	v_cmpx_gt_u32_e32 0x50, v0                                 // 0000009ED944: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 0000009ED94C: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x80>
	s_mul_i32 s9, s20, 0x500                                   // 0000009ED950: 9609FF14 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 0000009ED958: 300A0084
	s_mul_hi_i32 s21, s20, 0x500                               // 0000009ED95C: 9715FF14 00000500
	s_add_u32 s6, s6, s9                                       // 0000009ED964: 80060906
	s_addc_u32 s7, s7, s21                                     // 0000009ED968: 82071507
	global_load_b128 v[1:4], v5, s[6:7]                        // 0000009ED96C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 0000009ED974: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 0000009ED978: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009ED980: 8C7E037E
	v_lshrrev_b32_e32 v9, 5, v0                                // 0000009ED984: 32120085
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v10, 31, v0        // 0000009ED988: CA240080 0D0A009F
	s_mul_i32 s9, s20, 0xffffffec                              // 0000009ED990: 9609FF14 FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 0000009ED998: BF89FC07
	s_mul_i32 s21, s8, 0x96000                                 // 0000009ED99C: 9615FF08 00096000
	v_mul_u32_u24_e32 v42, 5, v9                               // 0000009ED9A4: 16541285
	s_add_i32 s9, s9, s2                                       // 0000009ED9A8: 81090209
	s_mul_hi_i32 s7, s8, 0x96000                               // 0000009ED9AC: 9707FF08 00096000
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 0000009ED9B4: CA100080 0E0E0080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000009ED9BC: BF870142
	v_min_u32_e32 v1, 35, v42                                  // 0000009ED9C0: 260254A3
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 0000009ED9C4: CA100080 10100080
	s_add_u32 s3, s4, s21                                      // 0000009ED9CC: 80031504
	s_mul_i32 s22, s9, 0x7800                                  // 0000009ED9D0: 9616FF09 00007800
	v_dual_mov_b32 v19, 0 :: v_dual_add_nc_u32 v12, 5, v1      // 0000009ED9D8: CA200080 130C0285
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v11, 2, v10    // 0000009ED9E0: CA220080 120A1482
	s_addc_u32 s6, s5, s7                                      // 0000009ED9E8: 82060705
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009ED9EC: BF870002
	v_cmp_lt_u32_e32 vcc_lo, v42, v12                          // 0000009ED9F0: 7C92192A
	s_mul_hi_i32 s25, s9, 0x7800                               // 0000009ED9F4: 9719FF09 00007800
	s_add_u32 s23, s3, s22                                     // 0000009ED9FC: 80171603
	s_addc_u32 s24, s6, s25                                    // 0000009EDA00: 82181906
	s_barrier                                                  // 0000009EDA04: BFBD0000
	buffer_gl0_inv                                             // 0000009EDA08: E0AC0000 00000000
	s_and_saveexec_b32 s6, vcc_lo                              // 0000009EDA10: BE86206A
	s_cbranch_execz 25                                         // 0000009EDA14: BFA50019 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x17c>
	v_mul_u32_u24_e32 v1, 0xf00, v9                            // 0000009EDA18: 160212FF 00000F00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EDA20: BF870091
	.long 0xd7000301                                           // 0000009EDA24: D7000301
	v_cndmask_b32_e32 v1, s23, v1, vcc_lo                      // 0000009EDA28: 02020217
	v_add_co_ci_u32_e64 v2, null, s24, 0, s3                   // 0000009EDA2C: D5207C02 000D0018
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EDA34: BF870092
	.long 0xd7000301                                           // 0000009EDA38: D7000301
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000009EDA3C: 02021701
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 0000009EDA40: D5207C02 000E0480
	s_clause 0x5                                               // 0000009EDA48: BF850005
	global_load_b32 v14, v[1:2], off                           // 0000009EDA4C: DC520000 0E7C0001
	global_load_b32 v15, v[1:2], off offset:128                // 0000009EDA54: DC520080 0F7C0001
	global_load_b32 v16, v[1:2], off offset:256                // 0000009EDA5C: DC520100 107C0001
	global_load_b32 v17, v[1:2], off offset:384                // 0000009EDA64: DC520180 117C0001
	global_load_b32 v18, v[1:2], off offset:512                // 0000009EDA6C: DC520200 127C0001
	global_load_b32 v19, v[1:2], off offset:640                // 0000009EDA74: DC520280 137C0001
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009EDA7C: 8C7E067E
	v_dual_mov_b32 v22, v13 :: v_dual_add_nc_u32 v1, 1, v42    // 0000009EDA80: CA20010D 16005481
	v_mov_b32_e32 v21, v13                                     // 0000009EDA88: 7E2A030D
	v_mov_b32_e32 v23, v13                                     // 0000009EDA8C: 7E2E030D
	v_mov_b32_e32 v24, v13                                     // 0000009EDA90: 7E30030D
	v_mov_b32_e32 v25, v13                                     // 0000009EDA94: 7E32030D
	s_mov_b32 s6, exec_lo                                      // 0000009EDA98: BE86007E
	.long 0xd4c9007e                                           // 0000009EDA9C: D4C9007E
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000009EDAA0: 02021901
	s_cbranch_execz 25                                         // 0000009EDAA4: BFA50019 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x20c>
	v_mul_u32_u24_e32 v1, 0x300, v1                            // 0000009EDAA8: 160202FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EDAB0: BF870091
	.long 0xd7000301                                           // 0000009EDAB4: D7000301
	v_cndmask_b32_e32 v1, s23, v1, vcc_lo                      // 0000009EDAB8: 02020217
	v_add_co_ci_u32_e64 v2, null, s24, 0, s3                   // 0000009EDABC: D5207C02 000D0018
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EDAC4: BF870092
	.long 0xd7000301                                           // 0000009EDAC8: D7000301
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000009EDACC: 02021701
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 0000009EDAD0: D5207C02 000E0480
	s_clause 0x5                                               // 0000009EDAD8: BF850005
	global_load_b32 v13, v[1:2], off                           // 0000009EDADC: DC520000 0D7C0001
	global_load_b32 v21, v[1:2], off offset:128                // 0000009EDAE4: DC520080 157C0001
	global_load_b32 v22, v[1:2], off offset:256                // 0000009EDAEC: DC520100 167C0001
	global_load_b32 v23, v[1:2], off offset:384                // 0000009EDAF4: DC520180 177C0001
	global_load_b32 v24, v[1:2], off offset:512                // 0000009EDAFC: DC520200 187C0001
	global_load_b32 v25, v[1:2], off offset:640                // 0000009EDB04: DC520280 197C0001
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009EDB0C: 8C7E067E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v27, 0             // 0000009EDB10: CA100080 201A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v29, 0             // 0000009EDB18: CA100080 1A1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v31, 0             // 0000009EDB20: CA100080 1C1E0080
	v_mov_b32_e32 v30, 0                                       // 0000009EDB28: 7E3C0280
	v_mov_b32_e32 v20, 0                                       // 0000009EDB2C: 7E280280
	s_and_saveexec_b32 s6, vcc_lo                              // 0000009EDB30: BE86206A
	s_cbranch_execz 1959                                       // 0000009EDB34: BFA507A7 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x20d4>
	v_lshl_or_b32 v3, v10, 3, 4                                // 0000009EDB38: D6560003 0211070A
	v_mad_u32_u24 v8, v10, 24, 0x2f0                           // 0000009EDB40: D60B0008 03FD310A 000002F0
	v_mad_u32_u24 v27, 0x320, v9, v11                          // 0000009EDB4C: D60B001B 042E12FF 00000320
	s_add_u32 s26, s21, s22                                    // 0000009EDB58: 801A1615
	s_addc_u32 s27, s7, s25                                    // 0000009EDB5C: 821B1907
	v_mad_u32_u24 v4, v3, 3, 0x2f0                             // 0000009EDB60: D60B0004 03FD0703 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v3                             // 0000009EDB6C: 7C920685
	v_lshrrev_b32_e32 v29, 5, v8                               // 0000009EDB70: 323A1085
	v_mul_i32_i24_e32 v3, -3, v3                               // 0000009EDB74: 120606C3
	v_add_nc_u32_e32 v36, 0x400, v27                           // 0000009EDB78: 4A4836FF 00000400
	v_lshrrev_b32_e32 v1, 5, v4                                // 0000009EDB80: 32020885
	v_and_b32_e32 v4, 0x7e0, v4                                // 0000009EDB84: 360808FF 000007E0
	v_subrev_nc_u32_e32 v29, 24, v29                           // 0000009EDB8C: 4E3A3A98
	v_mul_i32_i24_e32 v26, 0xffffffe8, v10                     // 0000009EDB90: 123414FF FFFFFFE8
	v_and_b32_e32 v8, 0x7e0, v8                                // 0000009EDB98: 361010FF 000007E0
	v_subrev_nc_u32_e32 v28, 24, v1                            // 0000009EDBA0: 4E380298
	v_mad_u64_u32 v[1:2], null, 0x300, v42, s[26:27]           // 0000009EDBA4: D6FE7C01 006A54FF 00000300
	v_add3_u32 v34, v3, v4, 0xfffffd34                         // 0000009EDBB0: D6550022 03FE0903 FFFFFD34
	v_mul_u32_u24_e32 v7, 0x320, v9                            // 0000009EDBBC: 160E12FF 00000320
	.long 0xd7000305                                           // 0000009EDBC4: D7000305
	v_cndmask_b32_e32 v1, s23, v11, vcc_lo                     // 0000009EDBC8: 02021617
	v_cndmask_b32_e32 v28, 23, v28, vcc_lo                     // 0000009EDBCC: 02383897
	v_cmp_ne_u32_e32 vcc_lo, 0, v10                            // 0000009EDBD0: 7C9A1480
	v_mov_b32_e32 v20, 0                                       // 0000009EDBD4: 7E280280
	v_add_co_ci_u32_e64 v6, null, s24, 0, s3                   // 0000009EDBD8: D5207C06 000D0018
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009EDBE0: BF8701B4
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v30, 1, v28     // 0000009EDBE4: CA200080 1B1E3881
	v_subrev_nc_u32_e32 v31, 23, v28                           // 0000009EDBEC: 4E3E3897
	v_dual_cndmask_b32 v29, 23, v29 :: v_dual_mov_b32 v32, 0   // 0000009EDBF0: CA503A97 1D200080
	v_cmp_gt_u32_e32 vcc_lo, 24, v30                           // 0000009EDBF8: 7C983C98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EDBFC: BF870212
	v_lshl_add_u32 v4, v29, 2, v7                              // 0000009EDC00: D6460004 041D051D
	v_cndmask_b32_e32 v3, v31, v30, vcc_lo                     // 0000009EDC08: 02063D1F
	v_cmp_gt_i32_e32 vcc_lo, 23, v29                           // 0000009EDC0C: 7C883A97
	v_mov_b32_e32 v31, 0                                       // 0000009EDC10: 7E3E0280
	v_add3_u32 v33, v26, v8, 0xfffffd34                        // 0000009EDC14: D6550021 03FE111A FFFFFD34
	v_lshl_add_u32 v26, v28, 2, v7                             // 0000009EDC20: D646001A 041D051C
	v_lshl_add_u32 v3, v3, 2, v7                               // 0000009EDC28: D6460003 041D0503
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 0000009EDC30: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a01                                           // 0000009EDC3C: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 0000009EDC40: 02021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EDC44: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000009EDC48: D5207C02 01AA0480
	v_dual_mov_b32 v30, 0 :: v_dual_and_b32 v7, 16, v0         // 0000009EDC50: CA240080 1E060090
	.long 0xd7006a01                                           // 0000009EDC58: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000009EDC5C: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EDC60: BF870221
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000009EDC64: D5207C02 01AA0405
	v_add_nc_u32_e32 v28, v4, v8                               // 0000009EDC6C: 4A381104
	v_lshl_or_b32 v35, v42, 5, v7                              // 0000009EDC70: D6560023 041D0B2A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EDC78: BF870094
	.long 0xd7006a07                                           // 0000009EDC7C: D7006A07
	v_cndmask_b32_e32 v1, 0x600, v1, vcc_lo                    // 0000009EDC80: 020202FF 00000600
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000009EDC88: D5207C08 01AA0480
	v_add_nc_u32_e32 v37, 0x400, v4                            // 0000009EDC90: 4A4A08FF 00000400
	v_add_nc_u32_e32 v38, 0x400, v28                           // 0000009EDC98: 4A4C38FF 00000400
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v39, 0x400, v26 // 0000009EDCA0: CA200080 1A2634FF 00000400
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v40, 0x400, v3  // 0000009EDCAC: CA200080 1D2806FF 00000400
	v_mov_b32_e32 v28, 0                                       // 0000009EDCB8: 7E380280
	s_mov_b32 s4, 0                                            // 0000009EDCBC: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000009EDCC0: B0051EEE
	s_branch 903                                               // 0000009EDCC4: BFA00387 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11e4>
	s_or_b32 exec_lo, exec_lo, s21                             // 0000009EDCC8: 8C7E157E
	ds_load_2addr_b32 v[42:43], v38 offset0:64 offset1:88      // 0000009EDCCC: D8DC5840 2A000026
	ds_load_2addr_b32 v[44:45], v40 offset0:64 offset1:88      // 0000009EDCD4: D8DC5840 2C000028
	ds_load_2addr_b32 v[48:49], v37 offset0:64 offset1:88      // 0000009EDCDC: D8DC5840 30000025
	ds_load_2addr_b32 v[51:52], v39 offset0:64 offset1:88      // 0000009EDCE4: D8DC5840 33000027
	ds_load_b128 v[1:4], v35 offset:32                         // 0000009EDCEC: DBFC0020 01000023
	ds_load_2addr_b32 v[53:54], v37 offset0:112 offset1:136    // 0000009EDCF4: D8DC8870 35000025
	s_waitcnt lgkmcnt(4)                                       // 0000009EDCFC: BF89FC47
	v_dual_mov_b32 v47, v42 :: v_dual_mov_b32 v50, v44         // 0000009EDD00: CA10012A 2F32012C
	s_waitcnt lgkmcnt(3)                                       // 0000009EDD08: BF89FC37
	v_mov_b32_e32 v44, v49                                     // 0000009EDD0C: 7E580331
	s_waitcnt lgkmcnt(2)                                       // 0000009EDD10: BF89FC27
	v_mov_b32_e32 v46, v52                                     // 0000009EDD14: 7E5C0334
	.long 0xd73d0039                                           // 0000009EDD18: D73D0039
	v_cndmask_b32_e32 v1, v33, v47, vcc_lo                     // 0000009EDD1C: 02025F21
	.long 0xd73d0031                                           // 0000009EDD20: D73D0031
	v_cndmask_b32_e32 v1, v34, v50, vcc_lo                     // 0000009EDD24: 02026522
	.long 0xd73d002a                                           // 0000009EDD28: D73D002A
	v_cndmask_b32_e32 v1, v33, v43, vcc_lo                     // 0000009EDD2C: 02025721
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EDD30: BF870004
	.long 0xd73d002b                                           // 0000009EDD34: D73D002B
	v_cndmask_b32_e32 v1, v34, v45, vcc_lo                     // 0000009EDD38: 02025B22
	ds_load_2addr_b32 v[47:48], v38 offset0:112 offset1:136    // 0000009EDD3C: D8DC8870 2F000026
	ds_load_2addr_b32 v[55:56], v40 offset0:112 offset1:136    // 0000009EDD44: D8DC8870 37000028
	v_bfe_u32 v44, v57, 9, 16                                  // 0000009EDD4C: D610002C 02411339
	v_bfe_u32 v45, v57, 6, 16                                  // 0000009EDD54: D610002D 02410D39
	v_and_b32_e32 v50, 0xffff, v57                             // 0000009EDD5C: 366472FF 0000FFFF
	v_bfe_u32 v46, v57, 3, 16                                  // 0000009EDD64: D610002E 02410739
	v_bfe_u32 v51, v49, 9, 16                                  // 0000009EDD6C: D6100033 02411331
	.long 0xd72c002c                                           // 0000009EDD74: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EDD78: 020258FF 83DCD12D
	.long 0xd72c002d                                           // 0000009EDD80: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EDD84: 02025AFF 83DCD12D
	.long 0xd72c0032                                           // 0000009EDD8C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EDD90: 020264FF 83DCD12D
	v_bfe_u32 v58, v42, 9, 16                                  // 0000009EDD98: D610003A 0241132A
	.long 0xd72c002e                                           // 0000009EDDA0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EDDA4: 02025CFF 83DCD12D
	v_bfe_u32 v59, v42, 6, 16                                  // 0000009EDDAC: D610003B 02410D2A
	.long 0xd72c0033                                           // 0000009EDDB4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EDDB8: 020266FF 83DCD12D
	v_bfe_u32 v52, v49, 6, 16                                  // 0000009EDDC0: D6100034 02410D31
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EDDC8: D622002C 03FD012C 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EDDD4: D622002D 03FD012D 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EDDE0: D6220032 03FD0132 00006400
	.long 0xd72c003a                                           // 0000009EDDEC: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EDDF0: 020274FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EDDF8: D622002E 03FD012E 00006400
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009EDE04: 365858FF 0000FFFF
	v_bfe_u32 v57, v49, 3, 16                                  // 0000009EDE0C: D6100039 02410731
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000009EDE14: 30646490
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009EDE18: 366262FF 0000FFFF
	.long 0xd72c003b                                           // 0000009EDE20: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009EDE24: 020276FF 83DCD12D
	v_lshl_or_b32 v44, v45, 16, v44                            // 0000009EDE2C: D656002C 04B1212D
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009EDE34: D6220033 03FD0133 00006400
	v_and_or_b32 v46, 0xffff, v46, v50                         // 0000009EDE40: D657002E 04CA5CFF 0000FFFF
	v_sad_u8 v50, v58, 0, 0x6400                               // 0000009EDE4C: D6220032 03FD013A 00006400
	.long 0xd72c0031                                           // 0000009EDE58: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EDE5C: 020262FF 83DCD12D
	v_pk_fma_f16 v44, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EDE64: CC0E002C 0BFC0B2C 0000C931
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009EDE70: 366666FF 0000FFFF
	.long 0xd72c0034                                           // 0000009EDE78: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EDE7C: 020268FF 83DCD12D
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009EDE84: 366464FF 0000FFFF
	.long 0xd72c0039                                           // 0000009EDE8C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EDE90: 020272FF 83DCD12D
	s_waitcnt lgkmcnt(3)                                       // 0000009EDE98: BF89FC37
	v_dot2acc_f32_f16 v20, v44, v1                             // 0000009EDE9C: 0428032C
	v_sad_u8 v44, v59, 0, 0x6400                               // 0000009EDEA0: D622002C 03FD013B 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009EDEAC: D6220031 03FD0131 00006400
	v_bfe_u32 v60, v42, 3, 16                                  // 0000009EDEB8: D610003C 0241072A
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EDEC0: CC0E002E 0BFC0B2E 0000C931
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009EDECC: D6220034 03FD0134 00006400
	v_lshl_or_b32 v50, v44, 16, v50                            // 0000009EDED8: D6560032 04C9212C
	v_sad_u8 v45, v57, 0, 0x6400                               // 0000009EDEE0: D622002D 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EDEEC: BF870224
	v_dual_dot2acc_f32_f16 v20, v46, v2 :: v_dual_lshlrev_b32 v49, 16, v49// 0000009EDEF0: CB22052E 14306290
	v_bfe_u32 v61, v43, 9, 16                                  // 0000009EDEF8: D610003D 0241132B
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EDF00: CC0E0032 0BFC0B32 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009EDF0C: 365454FF 0000FFFF
	v_bfe_u32 v62, v43, 6, 16                                  // 0000009EDF14: D610003E 02410D2B
	v_bfe_u32 v63, v43, 3, 16                                  // 0000009EDF1C: D610003F 0241072B
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EDF24: 365656FF 0000FFFF
	v_lshl_or_b32 v51, v52, 16, v51                            // 0000009EDF2C: D6560033 04CD2134
	v_and_or_b32 v45, 0xffff, v45, v49                         // 0000009EDF34: D657002D 04C65AFF 0000FFFF
	v_dot2acc_f32_f16 v31, v50, v1                             // 0000009EDF40: 043E0332
	.long 0xd72c002a                                           // 0000009EDF44: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EDF48: 020254FF 83DCD12D
	.long 0xd72c003d                                           // 0000009EDF50: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009EDF54: 02027AFF 83DCD12D
	.long 0xd72c003c                                           // 0000009EDF5C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009EDF60: 020278FF 83DCD12D
	v_pk_fma_f16 v49, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EDF68: CC0E0031 0BFC0B33 0000C931
	v_pk_fma_f16 v51, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EDF74: CC0E0033 0BFC0B2D 0000C931
	.long 0xd72c002d                                           // 0000009EDF80: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EDF84: 020256FF 83DCD12D
	.long 0xd72c003e                                           // 0000009EDF8C: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009EDF90: 02027CFF 83DCD12D
	ds_load_2addr_b32 v[43:44], v39 offset0:112 offset1:136    // 0000009EDF98: D8DC8870 2B000027
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009EDFA0: D622002A 03FD012A 00006400
	v_sad_u8 v46, v61, 0, 0x6400                               // 0000009EDFAC: D622002E 03FD013D 00006400
	.long 0xd72c003a                                           // 0000009EDFB8: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009EDFBC: 02027EFF 83DCD12D
	v_dot2acc_f32_f16 v20, v49, v3                             // 0000009EDFC4: 04280731
	v_sad_u8 v49, v60, 0, 0x6400                               // 0000009EDFC8: D6220031 03FD013C 00006400
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000009EDFD4: 30545490
	v_sad_u8 v59, v45, 0, 0x6400                               // 0000009EDFD8: D622003B 03FD012D 00006400
	s_waitcnt lgkmcnt(2)                                       // 0000009EDFE4: BF89FC27
	v_dual_mov_b32 v52, v47 :: v_dual_and_b32 v57, 0xffff, v46 // 0000009EDFE8: CA24012F 34385CFF 0000FFFF
	v_sad_u8 v47, v62, 0, 0x6400                               // 0000009EDFF4: D622002F 03FD013E 00006400
	v_and_or_b32 v42, 0xffff, v49, v42                         // 0000009EE000: D657002A 04AA62FF 0000FFFF
	v_lshlrev_b32_e32 v49, 16, v59                             // 0000009EE00C: 30627690
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EE010: BF870004
	.long 0xd73d002d                                           // 0000009EE014: D73D002D
	v_cndmask_b32_e32 v1, v33, v52, vcc_lo                     // 0000009EE018: 02026921
	v_dot2acc_f32_f16 v20, v51, v4                             // 0000009EE01C: 04280933
	v_lshl_or_b32 v46, v47, 16, v57                            // 0000009EE020: D656002E 04E5212F
	v_sad_u8 v47, v58, 0, 0x6400                               // 0000009EE028: D622002F 03FD013A 00006400
	v_pk_fma_f16 v52, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE034: CC0E0034 0BFC0B2A 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009EE040: BF89FC17
	v_mov_b32_e32 v42, v55                                     // 0000009EE044: 7E540337
	v_bfe_u32 v53, v45, 9, 16                                  // 0000009EE048: D6100035 0241132D
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE050: CC0E002E 0BFC0B2E 0000C931
	v_and_or_b32 v47, 0xffff, v47, v49                         // 0000009EE05C: D657002F 04C65EFF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v45                             // 0000009EE068: 36625AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009EE070: BF89FC07
	.long 0xd73d002a                                           // 0000009EE074: D73D002A
	v_cndmask_b32_e32 v1, v34, v42, vcc_lo                     // 0000009EE078: 02025522
	.long 0xd72c002b                                           // 0000009EE07C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009EE080: 02026AFF 83DCD12D
	v_bfe_u32 v53, v45, 6, 16                                  // 0000009EE088: D6100035 02410D2D
	v_bfe_u32 v45, v45, 3, 16                                  // 0000009EE090: D610002D 0241072D
	.long 0xd72c0031                                           // 0000009EE098: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EE09C: 020262FF 83DCD12D
	v_dot2acc_f32_f16 v31, v52, v2                             // 0000009EE0A4: 043E0534
	v_bfe_u32 v55, v42, 9, 16                                  // 0000009EE0A8: D6100037 0241132A
	.long 0xd72c0035                                           // 0000009EE0B0: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009EE0B4: 02026AFF 83DCD12D
	.long 0xd72c002d                                           // 0000009EE0BC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EE0C0: 02025AFF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EE0C8: D622002B 03FD012B 00006400
	v_bfe_u32 v57, v42, 6, 16                                  // 0000009EE0D4: D6100039 02410D2A
	.long 0xd72c0037                                           // 0000009EE0DC: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009EE0E0: 02026EFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009EE0E8: D6220031 03FD0131 00006400
	v_and_b32_e32 v58, 0xffff, v42                             // 0000009EE0F4: 367454FF 0000FFFF
	v_bfe_u32 v42, v42, 3, 16                                  // 0000009EE0FC: D610002A 0241072A
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009EE104: D6220035 03FD0135 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EE110: D622002D 03FD012D 00006400
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000009EE11C: 30626290
	.long 0xd72c0039                                           // 0000009EE120: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EE124: 020272FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009EE12C: D6220037 03FD0137 00006400
	.long 0xd72c002a                                           // 0000009EE138: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE13C: 020254FF 83DCD12D
	.long 0xd72c003a                                           // 0000009EE144: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EE148: 020274FF 83DCD12D
	v_and_or_b32 v45, 0xffff, v45, v49                         // 0000009EE150: D657002D 04C65AFF 0000FFFF
	v_dot2acc_f32_f16 v31, v46, v3                             // 0000009EE15C: 043E072E
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE160: CC0E002F 0BFC0B2F 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009EE16C: BF870233
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE170: CC0E002D 0BFC0B2D 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EE17C: 365656FF 0000FFFF
	v_sad_u8 v50, v58, 0, 0x6400                               // 0000009EE184: D6220032 03FD013A 00006400
	v_dot2acc_f32_f16 v31, v47, v4                             // 0000009EE190: 043E092F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EE194: BF870223
	v_lshl_or_b32 v43, v53, 16, v43                            // 0000009EE198: D656002B 04AD2135
	v_sad_u8 v53, v57, 0, 0x6400                               // 0000009EE1A0: D6220035 03FD0139 00006400
	v_dual_mov_b32 v57, v44 :: v_dual_lshlrev_b32 v50, 16, v50 // 0000009EE1AC: CA22012C 39326490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EE1B4: BF870093
	v_pk_fma_f16 v43, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE1B8: CC0E002B 0BFC0B2B 0000C931
	v_dual_dot2acc_f32_f16 v30, v43, v1 :: v_dual_and_b32 v49, 0xffff, v55// 0000009EE1C4: CB24032B 1E306EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009EE1D0: BF870231
	v_lshl_or_b32 v53, v53, 16, v49                            // 0000009EE1D4: D6560035 04C52135
	v_mov_b32_e32 v49, v54                                     // 0000009EE1DC: 7E620336
	v_sad_u8 v54, v42, 0, 0x6400                               // 0000009EE1E0: D6220036 03FD012A 00006400
	v_dot2acc_f32_f16 v30, v45, v2                             // 0000009EE1EC: 043C052D
	.long 0xd73d002c                                           // 0000009EE1F0: D73D002C
	v_cndmask_b32_e32 v1, v34, v56, vcc_lo                     // 0000009EE1F4: 02027122
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009EE1F8: BF870234
	.long 0xd73d002a                                           // 0000009EE1FC: D73D002A
	v_cndmask_b32_e32 v1, v33, v48, vcc_lo                     // 0000009EE200: 02026121
	v_pk_fma_f16 v43, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE204: CC0E002B 0BFC0B35 0000C931
	v_and_or_b32 v48, 0xffff, v54, v50                         // 0000009EE210: D6570030 04CA6CFF 0000FFFF
	v_bfe_u32 v47, v44, 9, 16                                  // 0000009EE21C: D610002F 0241132C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EE224: BF870214
	v_bfe_u32 v46, v42, 9, 16                                  // 0000009EE228: D610002E 0241132A
	v_dot2acc_f32_f16 v30, v43, v3                             // 0000009EE230: 043C072B
	v_bfe_u32 v45, v42, 6, 16                                  // 0000009EE234: D610002D 02410D2A
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE23C: CC0E0030 0BFC0B30 0000C931
	v_bfe_u32 v49, v44, 6, 16                                  // 0000009EE248: D6100031 02410D2C
	.long 0xd72c002b                                           // 0000009EE250: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EE254: 02025CFF 83DCD12D
	v_bfe_u32 v46, v42, 3, 16                                  // 0000009EE25C: D610002E 0241072A
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009EE264: 365454FF 0000FFFF
	.long 0xd72c0032                                           // 0000009EE26C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EE270: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v30, v48, v4                             // 0000009EE278: 043C0930
	v_bfe_u32 v52, v44, 3, 16                                  // 0000009EE27C: D6100034 0241072C
	.long 0xd72c0035                                           // 0000009EE284: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EE288: 02025CFF 83DCD12D
	.long 0xd72c0033                                           // 0000009EE290: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE294: 020254FF 83DCD12D
	v_sad_u8 v48, v43, 0, 0x6400                               // 0000009EE29C: D6220030 03FD012B 00006400
	ds_load_2addr_b32 v[42:43], v38 offset0:160 offset1:184    // 0000009EE2A8: D8DCB8A0 2A000026
	ds_load_2addr_b32 v[45:46], v37 offset0:160 offset1:184    // 0000009EE2B0: D8DCB8A0 2D000025
	v_sad_u8 v55, v50, 0, 0x6400                               // 0000009EE2B8: D6220037 03FD0132 00006400
	.long 0xd72c0038                                           // 0000009EE2C4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EE2C8: 02025EFF 83DCD12D
	v_and_b32_e32 v54, 0xffff, v48                             // 0000009EE2D0: 366C60FF 0000FFFF
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009EE2D8: D6220035 03FD0135 00006400
	v_sad_u8 v50, v51, 0, 0x6400                               // 0000009EE2E4: D6220032 03FD0133 00006400
	ds_load_2addr_b32 v[47:48], v40 offset0:160 offset1:184    // 0000009EE2F0: D8DCB8A0 2F000028
	.long 0xd72c0031                                           // 0000009EE2F8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EE2FC: 020262FF 83DCD12D
	v_lshl_or_b32 v54, v55, 16, v54                            // 0000009EE304: D6560036 04D92137
	.long 0xd72c0034                                           // 0000009EE30C: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EE310: 020268FF 83DCD12D
	v_lshlrev_b32_e32 v57, 16, v50                             // 0000009EE318: 30726490
	ds_load_2addr_b32 v[50:51], v39 offset0:160 offset1:184    // 0000009EE31C: D8DCB8A0 32000027
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EE324: D6220038 03FD0138 00006400
	v_and_or_b32 v53, 0xffff, v53, v57                         // 0000009EE330: D6570035 04E66AFF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009EE33C: D6220031 03FD0131 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009EE348: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009EE354: BF8700A3
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE358: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009EE364: 365858FF 0000FFFF
	.long 0xd72c002c                                           // 0000009EE36C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EE370: 020258FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009EE378: BF8700A1
	v_sad_u8 v55, v44, 0, 0x6400                               // 0000009EE37C: D6220037 03FD012C 00006400
	s_waitcnt lgkmcnt(3)                                       // 0000009EE388: BF89FC37
	v_dual_mov_b32 v44, v42 :: v_dual_lshlrev_b32 v55, 16, v55 // 0000009EE38C: CA22012A 2C366E90
	s_waitcnt lgkmcnt(2)                                       // 0000009EE394: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009EE398: BF8700A1
	.long 0xd73d002c                                           // 0000009EE39C: D73D002C
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000009EE3A0: 02025921
	v_pk_fma_f16 v45, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE3A4: CC0E002D 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v29, v45, v1                             // 0000009EE3B0: 043A032D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EE3B4: BF870091
	v_dual_dot2acc_f32_f16 v29, v53, v2 :: v_dual_and_b32 v42, 0xffff, v56// 0000009EE3B8: CB240535 1D2A70FF 0000FFFF
	v_lshl_or_b32 v42, v49, 16, v42                            // 0000009EE3C4: D656002A 04A92131
	s_waitcnt lgkmcnt(1)                                       // 0000009EE3CC: BF89FC17
	v_mov_b32_e32 v49, v47                                     // 0000009EE3D0: 7E62032F
	v_and_or_b32 v47, 0xffff, v52, v55                         // 0000009EE3D4: D657002F 04DE68FF 0000FFFF
	v_bfe_u32 v52, v44, 9, 16                                  // 0000009EE3E0: D6100034 0241132C
	v_pk_fma_f16 v54, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE3E8: CC0E0036 0BFC0B2A 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009EE3F4: BF89FC07
	.long 0xd73d0031                                           // 0000009EE3F8: D73D0031
	v_cndmask_b32_e32 v1, v34, v49, vcc_lo                     // 0000009EE3FC: 02026322
	v_and_b32_e32 v42, 0xffff, v44                             // 0000009EE400: 365458FF 0000FFFF
	v_pk_fma_f16 v55, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE408: CC0E0037 0BFC0B2F 0000C931
	.long 0xd72c002f                                           // 0000009EE414: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EE418: 020268FF 83DCD12D
	v_bfe_u32 v50, v44, 6, 16                                  // 0000009EE420: D6100032 02410D2C
	v_bfe_u32 v44, v44, 3, 16                                  // 0000009EE428: D610002C 0241072C
	.long 0xd72c002a                                           // 0000009EE430: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE434: 020254FF 83DCD12D
	v_bfe_u32 v52, v49, 9, 16                                  // 0000009EE43C: D6100034 02411331
	v_and_b32_e32 v56, 0xffff, v49                             // 0000009EE444: 367062FF 0000FFFF
	.long 0xd72c002d                                           // 0000009EE44C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EE450: 020264FF 83DCD12D
	.long 0xd72c002c                                           // 0000009EE458: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EE45C: 020258FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EE464: D622002F 03FD012F 00006400
	.long 0xd72c0032                                           // 0000009EE470: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EE474: 020268FF 83DCD12D
	v_bfe_u32 v52, v49, 6, 16                                  // 0000009EE47C: D6100034 02410D31
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009EE484: D622002A 03FD012A 00006400
	v_bfe_u32 v49, v49, 3, 16                                  // 0000009EE490: D6100031 02410731
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009EE498: 365E5EFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EE4A0: D622002D 03FD012D 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EE4AC: D622002C 03FD012C 00006400
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000009EE4B8: 30545490
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EE4BC: D6220032 03FD0132 00006400
	.long 0xd72c0034                                           // 0000009EE4C8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EE4CC: 020268FF 83DCD12D
	v_lshl_or_b32 v45, v45, 16, v47                            // 0000009EE4D4: D656002D 04BD212D
	.long 0xd72c0038                                           // 0000009EE4DC: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009EE4E0: 020270FF 83DCD12D
	v_and_or_b32 v42, 0xffff, v44, v42                         // 0000009EE4E8: D657002A 04AA58FF 0000FFFF
	v_dual_mov_b32 v44, v46 :: v_dual_and_b32 v47, 0xffff, v50 // 0000009EE4F4: CA24012E 2C2E64FF 0000FFFF
	.long 0xd72c0031                                           // 0000009EE500: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EE504: 020262FF 83DCD12D
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE50C: CC0E002D 0BFC0B2D 0000C931
	v_sad_u8 v46, v52, 0, 0x6400                               // 0000009EE518: D622002E 03FD0134 00006400
	v_pk_fma_f16 v52, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE524: CC0E0034 0BFC0B2A 0000C931
	.long 0xd73d002a                                           // 0000009EE530: D73D002A
	v_cndmask_b32_e32 v1, v33, v43, vcc_lo                     // 0000009EE534: 02025721
	v_sad_u8 v50, v56, 0, 0x6400                               // 0000009EE538: D6220032 03FD0138 00006400
	v_dot2acc_f32_f16 v28, v45, v1                             // 0000009EE544: 0438032D
	v_lshl_or_b32 v43, v46, 16, v47                            // 0000009EE548: D656002B 04BD212E
	v_sad_u8 v44, v49, 0, 0x6400                               // 0000009EE550: D622002C 03FD0131 00006400
	v_dot2acc_f32_f16 v29, v54, v3                             // 0000009EE55C: 043A0736
	v_bfe_u32 v45, v42, 9, 16                                  // 0000009EE560: D610002D 0241132A
	v_lshlrev_b32_e32 v46, 16, v50                             // 0000009EE568: 305C6490
	v_pk_fma_f16 v47, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE56C: CC0E002F 0BFC0B2B 0000C931
	v_mov_b32_e32 v49, v51                                     // 0000009EE578: 7E620333
	v_dot2acc_f32_f16 v29, v55, v4                             // 0000009EE57C: 043A0937
	.long 0xd72c002d                                           // 0000009EE580: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EE584: 02025AFF 83DCD12D
	v_and_or_b32 v43, 0xffff, v44, v46                         // 0000009EE58C: D657002B 04BA58FF 0000FFFF
	v_bfe_u32 v46, v42, 6, 16                                  // 0000009EE598: D610002E 02410D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EE5A0: BF870211
	.long 0xd72c002e                                           // 0000009EE5A4: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EE5A8: 02025CFF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EE5B0: D622002D 03FD012D 00006400
	v_dot2acc_f32_f16 v28, v52, v2                             // 0000009EE5BC: 04380534
	v_pk_fma_f16 v52, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE5C0: CC0E0034 0BFC0B2B 0000C931
	.long 0xd73d002b                                           // 0000009EE5CC: D73D002B
	v_cndmask_b32_e32 v1, v34, v48, vcc_lo                     // 0000009EE5D0: 02026122
	v_bfe_u32 v44, v42, 3, 16                                  // 0000009EE5D4: D610002C 0241072A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EE5DC: BF870004
	v_dual_dot2acc_f32_f16 v28, v47, v3 :: v_dual_and_b32 v51, 0xffff, v45// 0000009EE5E0: CB24072F 1C325AFF 0000FFFF
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009EE5EC: 365454FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EE5F4: D622002E 03FD012E 00006400
	v_bfe_u32 v47, v43, 9, 16                                  // 0000009EE600: D610002F 0241132B
	v_and_b32_e32 v50, 0xffff, v43                             // 0000009EE608: 366456FF 0000FFFF
	.long 0xd72c0038                                           // 0000009EE610: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EE614: 020258FF 83DCD12D
	v_bfe_u32 v49, v43, 6, 16                                  // 0000009EE61C: D6100031 02410D2B
	.long 0xd72c0036                                           // 0000009EE624: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE628: 020254FF 83DCD12D
	.long 0xd72c0039                                           // 0000009EE630: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EE634: 02025EFF 83DCD12D
	ds_load_2addr_b32 v[44:45], v40 offset0:208 offset1:232    // 0000009EE63C: D8DCE8D0 2C000028
	ds_load_2addr_b32 v[47:48], v37 offset0:208 offset1:232    // 0000009EE644: D8DCE8D0 2F000025
	v_bfe_u32 v53, v43, 3, 16                                  // 0000009EE64C: D6100035 0241072B
	ds_load_2addr_b32 v[42:43], v38 offset0:208 offset1:232    // 0000009EE654: D8DCE8D0 2A000026
	v_lshl_or_b32 v46, v46, 16, v51                            // 0000009EE65C: D656002E 04CD212E
	.long 0xd72c003a                                           // 0000009EE664: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EE668: 020264FF 83DCD12D
	ds_load_2addr_b32 v[50:51], v39 offset0:208 offset1:232    // 0000009EE670: D8DCE8D0 32000027
	.long 0xd72c0031                                           // 0000009EE678: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EE67C: 020262FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009EE684: D6220036 03FD0136 00006400
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009EE690: D6220039 03FD0139 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EE69C: D6220038 03FD0138 00006400
	.long 0xd72c0035                                           // 0000009EE6A8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009EE6AC: 02026AFF 83DCD12D
	v_pk_fma_f16 v59, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE6B4: CC0E003B 0BFC0B2E 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000009EE6C0: 306C6C90
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009EE6C4: 367272FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009EE6CC: D6220031 03FD0131 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009EE6D8: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v27, v59, v1                             // 0000009EE6E4: 0436033B
	v_and_or_b32 v54, 0xffff, v56, v54                         // 0000009EE6E8: D6570036 04DA70FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009EE6F4: BF8701B4
	v_lshl_or_b32 v56, v49, 16, v57                            // 0000009EE6F8: D6560038 04E52131
	s_waitcnt lgkmcnt(3)                                       // 0000009EE700: BF89FC37
	v_mov_b32_e32 v49, v44                                     // 0000009EE704: 7E62032C
	v_pk_fma_f16 v44, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE708: CC0E002C 0BFC0B36 0000C931
	v_dot2acc_f32_f16 v28, v52, v4                             // 0000009EE714: 04380934
	s_waitcnt lgkmcnt(0)                                       // 0000009EE718: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009EE71C: BF870253
	.long 0xd73d0031                                           // 0000009EE720: D73D0031
	v_cndmask_b32_e32 v1, v34, v49, vcc_lo                     // 0000009EE724: 02026322
	v_mov_b32_e32 v46, v42                                     // 0000009EE728: 7E5C032A
	v_sad_u8 v42, v53, 0, 0x6400                               // 0000009EE72C: D622002A 03FD0135 00006400
	v_lshlrev_b32_e32 v53, 16, v58                             // 0000009EE738: 306A7490
	v_dot2acc_f32_f16 v27, v44, v2                             // 0000009EE73C: 0436052C
	.long 0xd73d002e                                           // 0000009EE740: D73D002E
	v_cndmask_b32_e32 v1, v33, v46, vcc_lo                     // 0000009EE744: 02025D21
	v_bfe_u32 v44, v49, 9, 16                                  // 0000009EE748: D610002C 02411331
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EE750: BF870004
	v_and_or_b32 v42, 0xffff, v42, v53                         // 0000009EE754: D657002A 04D654FF 0000FFFF
	v_pk_fma_f16 v47, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE760: CC0E002F 0BFC0B38 0000C931
	v_bfe_u32 v56, v49, 6, 16                                  // 0000009EE76C: D6100038 02410D31
	v_bfe_u32 v57, v49, 3, 16                                  // 0000009EE774: D6100039 02410731
	v_bfe_u32 v50, v46, 9, 16                                  // 0000009EE77C: D6100032 0241132E
	v_pk_fma_f16 v53, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE784: CC0E0035 0BFC0B2A 0000C931
	v_and_b32_e32 v42, 0xffff, v46                             // 0000009EE790: 36545CFF 0000FFFF
	v_bfe_u32 v54, v46, 6, 16                                  // 0000009EE798: D6100036 02410D2E
	v_bfe_u32 v46, v46, 3, 16                                  // 0000009EE7A0: D610002E 0241072E
	.long 0xd72c0032                                           // 0000009EE7A8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EE7AC: 020264FF 83DCD12D
	.long 0xd72c002c                                           // 0000009EE7B4: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EE7B8: 020258FF 83DCD12D
	.long 0xd72c002a                                           // 0000009EE7C0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE7C4: 020254FF 83DCD12D
	.long 0xd72c0036                                           // 0000009EE7CC: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EE7D0: 02026CFF 83DCD12D
	.long 0xd72c002e                                           // 0000009EE7D8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EE7DC: 02025CFF 83DCD12D
	.long 0xd72c0038                                           // 0000009EE7E4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009EE7E8: 020270FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009EE7F0: 366262FF 0000FFFF
	v_dot2acc_f32_f16 v27, v47, v3                             // 0000009EE7F8: 0436072F
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EE7FC: D6220032 03FD0132 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EE808: D622002C 03FD012C 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009EE814: D622002A 03FD012A 00006400
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009EE820: D6220036 03FD0136 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EE82C: D622002E 03FD012E 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009EE838: 366464FF 0000FFFF
	v_and_b32_e32 v58, 0xffff, v44                             // 0000009EE840: 367458FF 0000FFFF
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000009EE848: 30545490
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EE84C: D6220038 03FD0138 00006400
	v_mov_b32_e32 v44, v48                                     // 0000009EE858: 7E580330
	v_lshl_or_b32 v48, v54, 16, v50                            // 0000009EE85C: D6560030 04C92136
	.long 0xd72c0031                                           // 0000009EE864: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EE868: 020262FF 83DCD12D
	v_and_or_b32 v46, 0xffff, v46, v42                         // 0000009EE870: D657002E 04AA5CFF 0000FFFF
	v_lshl_or_b32 v50, v56, 16, v58                            // 0000009EE87C: D6560032 04E92138
	.long 0xd73d002a                                           // 0000009EE884: D73D002A
	v_cndmask_b32_e32 v1, v33, v43, vcc_lo                     // 0000009EE888: 02025721
	.long 0xd72c0036                                           // 0000009EE88C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EE890: 020272FF 83DCD12D
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE898: CC0E0030 0BFC0B30 0000C931
	v_pk_fma_f16 v56, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE8A4: CC0E0038 0BFC0B2E 0000C931
	v_mov_b32_e32 v46, v51                                     // 0000009EE8B0: 7E5C0333
	v_pk_fma_f16 v50, v50, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE8B4: CC0E0032 0BFC0B32 0000C931
	v_bfe_u32 v51, v42, 9, 16                                  // 0000009EE8C0: D6100033 0241132A
	v_and_b32_e32 v57, 0xffff, v42                             // 0000009EE8C8: 367254FF 0000FFFF
	v_dot2acc_f32_f16 v27, v53, v4                             // 0000009EE8D0: 04360935
	.long 0xd73d002b                                           // 0000009EE8D4: D73D002B
	v_cndmask_b32_e32 v1, v34, v45, vcc_lo                     // 0000009EE8D8: 02025B22
	v_sad_u8 v44, v49, 0, 0x6400                               // 0000009EE8DC: D622002C 03FD0131 00006400
	.long 0xd72c002d                                           // 0000009EE8E8: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EE8EC: 020266FF 83DCD12D
	.long 0xd72c0031                                           // 0000009EE8F4: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EE8F8: 020272FF 83DCD12D
	v_bfe_u32 v46, v42, 6, 16                                  // 0000009EE900: D610002E 02410D2A
	v_bfe_u32 v42, v42, 3, 16                                  // 0000009EE908: D610002A 0241072A
	v_bfe_u32 v51, v43, 9, 16                                  // 0000009EE910: D6100033 0241132B
	v_bfe_u32 v57, v43, 6, 16                                  // 0000009EE918: D6100039 02410D2B
	v_bfe_u32 v58, v43, 3, 16                                  // 0000009EE920: D610003A 0241072B
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EE928: 365656FF 0000FFFF
	.long 0xd72c002e                                           // 0000009EE930: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EE934: 02025CFF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EE93C: D622002D 03FD012D 00006400
	.long 0xd72c002a                                           // 0000009EE948: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 0000009EE94C: 020254FF 83DCD12D
	.long 0xd72c0033                                           // 0000009EE954: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EE958: 020266FF 83DCD12D
	.long 0xd72c002b                                           // 0000009EE960: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EE964: 020256FF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009EE96C: D6220031 03FD0131 00006400
	.long 0xd72c0039                                           // 0000009EE978: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EE97C: 020272FF 83DCD12D
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009EE984: D6220036 03FD0136 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EE990: D622002E 03FD012E 00006400
	v_lshlrev_b32_e32 v44, 16, v44                             // 0000009EE99C: 30585890
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009EE9A0: D622002A 03FD012A 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009EE9AC: D6220033 03FD0133 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EE9B8: D622002B 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EE9C4: BF870091
	v_dual_dot2acc_f32_f16 v26, v48, v1 :: v_dual_lshlrev_b32 v43, 16, v43// 0000009EE9C8: CB220330 1A2A5690
	v_dual_dot2acc_f32_f16 v26, v56, v2 :: v_dual_and_b32 v45, 0xffff, v45// 0000009EE9D0: CB240538 1A2C5AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EE9DC: BF8701A1
	v_lshl_or_b32 v45, v46, 16, v45                            // 0000009EE9E0: D656002D 04B5212E
	.long 0xd72c002e                                           // 0000009EE9E8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EE9EC: 020274FF 83DCD12D
	v_dot2acc_f32_f16 v26, v50, v3                             // 0000009EE9F4: 04340732
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EE9F8: BF870193
	v_pk_fma_f16 v45, v45, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EE9FC: CC0E002D 0BFC0B2D 0000C931
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EEA08: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009EEA14: BF870232
	v_dot2acc_f32_f16 v32, v45, v1                             // 0000009EEA18: 0440032D
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000009EEA1C: 30626290
	v_and_or_b32 v1, 0xffff, v54, v44                          // 0000009EEA20: D6570001 04B26CFF 0000FFFF
	v_and_or_b32 v43, 0xffff, v46, v43                         // 0000009EEA2C: D657002B 04AE5CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009EEA38: BF870243
	v_and_or_b32 v42, 0xffff, v42, v49                         // 0000009EEA3C: D657002A 04C654FF 0000FFFF
	v_and_b32_e32 v49, 0xffff, v51                             // 0000009EEA48: 366266FF 0000FFFF
	v_sad_u8 v51, v57, 0, 0x6400                               // 0000009EEA50: D6220033 03FD0139 00006400
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000009EEA5C: CC0E0001 0BFC0B01 0000C931
	v_pk_fma_f16 v42, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEA68: CC0E002A 0BFC0B2A 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EEA74: BF870193
	v_lshl_or_b32 v48, v51, 16, v49                            // 0000009EEA78: D6560030 04C52133
	v_dot2acc_f32_f16 v26, v1, v4                              // 0000009EEA80: 04340901
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EEA84: BF870223
	v_dot2acc_f32_f16 v32, v42, v2                             // 0000009EEA88: 0440052A
	v_pk_fma_f16 v2, v43, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000009EEA8C: CC0E0002 0BFC0B2B 0000C931
	v_pk_fma_f16 v44, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEA98: CC0E002C 0BFC0B30 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EEAA4: BF870091
	v_dot2acc_f32_f16 v32, v44, v3                             // 0000009EEAA8: 0440072C
	v_dot2acc_f32_f16 v32, v2, v4                              // 0000009EEAAC: 04400902
	s_or_b32 exec_lo, exec_lo, s7                              // 0000009EEAB0: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000009EEAB4: BF8704D9
	s_and_b32 s3, exec_lo, vcc_lo                              // 0000009EEAB8: 8B036A7E
	.long 0xd7006a07                                           // 0000009EEABC: D7006A07
	v_cndmask_b32_e32 v1, 0x600, v7, vcc_lo                    // 0000009EEAC0: 02020EFF 00000600
	v_dual_mov_b32 v42, v41 :: v_dual_add_nc_u32 v35, 64, v35  // 0000009EEAC8: CA200129 2A2246C0
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000009EEAD0: D5207C08 01AA1080
	s_or_b32 s4, s3, s4                                        // 0000009EEAD8: 8C040403
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000009EEADC: 917E047E
	s_cbranch_execz 955                                        // 0000009EEAE0: BFA503BB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x20d0>
	v_add_nc_u32_e32 v41, 2, v42                               // 0000009EEAE4: 4A525482
	s_mov_b32 s7, exec_lo                                      // 0000009EEAE8: BE87007E
	s_waitcnt vmcnt(4)                                         // 0000009EEAEC: BF8913F7
	ds_store_2addr_b32 v36, v14, v15 offset0:64 offset1:96     // 0000009EEAF0: D8386040 000F0E24
	s_waitcnt vmcnt(2)                                         // 0000009EEAF8: BF890BF7
	ds_store_2addr_b32 v36, v16, v17 offset0:128 offset1:160   // 0000009EEAFC: D838A080 00111024
	s_waitcnt vmcnt(0)                                         // 0000009EEB04: BF8903F7
	ds_store_2addr_b32 v36, v18, v19 offset0:192 offset1:224   // 0000009EEB08: D838E0C0 00131224
	v_cmp_ge_u32_e32 vcc_lo, v41, v12                          // 0000009EEB10: 7C9C1929
	.long 0xd4c9007e                                           // 0000009EEB14: D4C9007E
	v_cndmask_b32_e32 v1, v41, v12, vcc_lo                     // 0000009EEB18: 02021929
	s_cbranch_execz 13                                         // 0000009EEB1C: BFA5000D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1254>
	s_clause 0x5                                               // 0000009EEB20: BF850005
	global_load_b32 v14, v[7:8], off                           // 0000009EEB24: DC520000 0E7C0007
	global_load_b32 v15, v[7:8], off offset:128                // 0000009EEB2C: DC520080 0F7C0007
	global_load_b32 v16, v[7:8], off offset:256                // 0000009EEB34: DC520100 107C0007
	global_load_b32 v17, v[7:8], off offset:384                // 0000009EEB3C: DC520180 117C0007
	global_load_b32 v18, v[7:8], off offset:512                // 0000009EEB44: DC520200 127C0007
	global_load_b32 v19, v[7:8], off offset:640                // 0000009EEB4C: DC520280 137C0007
	s_or_b32 exec_lo, exec_lo, s7                              // 0000009EEB54: 8C7E077E
	ds_load_2addr_b32 v[43:44], v38 offset0:64 offset1:88      // 0000009EEB58: D8DC5840 2B000026
	ds_load_2addr_b32 v[45:46], v40 offset0:64 offset1:88      // 0000009EEB60: D8DC5840 2D000028
	ds_load_2addr_b32 v[49:50], v37 offset0:64 offset1:88      // 0000009EEB68: D8DC5840 31000025
	ds_load_2addr_b32 v[52:53], v39 offset0:64 offset1:88      // 0000009EEB70: D8DC5840 34000027
	ds_load_b128 v[1:4], v35                                   // 0000009EEB78: DBFC0000 01000023
	ds_load_2addr_b32 v[54:55], v37 offset0:112 offset1:136    // 0000009EEB80: D8DC8870 36000025
	s_mov_b32 s7, exec_lo                                      // 0000009EEB88: BE87007E
	s_waitcnt lgkmcnt(4)                                       // 0000009EEB8C: BF89FC47
	v_dual_mov_b32 v48, v43 :: v_dual_mov_b32 v51, v45         // 0000009EEB90: CA10012B 3032012D
	s_waitcnt lgkmcnt(3)                                       // 0000009EEB98: BF89FC37
	v_mov_b32_e32 v45, v50                                     // 0000009EEB9C: 7E5A0332
	s_waitcnt lgkmcnt(2)                                       // 0000009EEBA0: BF89FC27
	v_mov_b32_e32 v47, v53                                     // 0000009EEBA4: 7E5E0335
	.long 0xd73d003a                                           // 0000009EEBA8: D73D003A
	v_cndmask_b32_e32 v1, v33, v48, vcc_lo                     // 0000009EEBAC: 02026121
	.long 0xd73d0032                                           // 0000009EEBB0: D73D0032
	v_cndmask_b32_e32 v1, v34, v51, vcc_lo                     // 0000009EEBB4: 02026722
	.long 0xd73d002b                                           // 0000009EEBB8: D73D002B
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000009EEBBC: 02025921
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EEBC0: BF870004
	.long 0xd73d002c                                           // 0000009EEBC4: D73D002C
	v_cndmask_b32_e32 v1, v34, v46, vcc_lo                     // 0000009EEBC8: 02025D22
	ds_load_2addr_b32 v[48:49], v38 offset0:112 offset1:136    // 0000009EEBCC: D8DC8870 30000026
	ds_load_2addr_b32 v[56:57], v40 offset0:112 offset1:136    // 0000009EEBD4: D8DC8870 38000028
	v_bfe_u32 v45, v58, 9, 16                                  // 0000009EEBDC: D610002D 0241133A
	v_bfe_u32 v46, v58, 6, 16                                  // 0000009EEBE4: D610002E 02410D3A
	v_bfe_u32 v47, v58, 3, 16                                  // 0000009EEBEC: D610002F 0241073A
	v_bfe_u32 v62, v44, 9, 16                                  // 0000009EEBF4: D610003E 0241132C
	v_bfe_u32 v63, v44, 6, 16                                  // 0000009EEBFC: D610003F 02410D2C
	v_bfe_u32 v64, v44, 3, 16                                  // 0000009EEC04: D6100040 0241072C
	v_and_b32_e32 v65, 0xffff, v44                             // 0000009EEC0C: 368258FF 0000FFFF
	.long 0xd72c002c                                           // 0000009EEC14: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EEC18: 02025AFF 83DCD12D
	.long 0xd72c002d                                           // 0000009EEC20: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EEC24: 02025CFF 83DCD12D
	.long 0xd72c002e                                           // 0000009EEC2C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EEC30: 02025EFF 83DCD12D
	v_bfe_u32 v52, v50, 9, 16                                  // 0000009EEC38: D6100034 02411332
	v_bfe_u32 v53, v50, 6, 16                                  // 0000009EEC40: D6100035 02410D32
	v_bfe_u32 v59, v43, 9, 16                                  // 0000009EEC48: D610003B 0241132B
	v_bfe_u32 v60, v43, 6, 16                                  // 0000009EEC50: D610003C 02410D2B
	v_bfe_u32 v61, v43, 3, 16                                  // 0000009EEC58: D610003D 0241072B
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EEC60: D622002C 03FD012C 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EEC6C: D622002D 03FD012D 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EEC78: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EEC84: BF870093
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009EEC88: 365858FF 0000FFFF
	v_lshl_or_b32 v44, v45, 16, v44                            // 0000009EEC90: D656002C 04B1212D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009EEC98: BF870001
	v_pk_fma_f16 v44, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEC9C: CC0E002C 0BFC0B2C 0000C931
	v_and_b32_e32 v51, 0xffff, v58                             // 0000009EECA8: 366674FF 0000FFFF
	v_bfe_u32 v58, v50, 3, 16                                  // 0000009EECB0: D610003A 02410732
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009EECB8: 366464FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 0000009EECC0: BF89FC37
	v_dot2acc_f32_f16 v20, v44, v1                             // 0000009EECC4: 0428032C
	.long 0xd72c002f                                           // 0000009EECC8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EECCC: 020266FF 83DCD12D
	.long 0xd72c0033                                           // 0000009EECD4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EECD8: 020268FF 83DCD12D
	.long 0xd72c0034                                           // 0000009EECE0: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009EECE4: 02026AFF 83DCD12D
	.long 0xd72c0032                                           // 0000009EECEC: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EECF0: 020264FF 83DCD12D
	.long 0xd72c0035                                           // 0000009EECF8: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EECFC: 020274FF 83DCD12D
	.long 0xd72c003a                                           // 0000009EED04: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009EED08: 020276FF 83DCD12D
	.long 0xd72c003b                                           // 0000009EED10: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009EED14: 020278FF 83DCD12D
	.long 0xd72c003c                                           // 0000009EED1C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009EED20: 02027AFF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EED28: D622002F 03FD012F 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009EED34: D6220033 03FD0133 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009EED40: D6220034 03FD0134 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EED4C: D6220032 03FD0132 00006400
	v_sad_u8 v45, v53, 0, 0x6400                               // 0000009EED58: D622002D 03FD0135 00006400
	v_lshlrev_b32_e32 v47, 16, v47                             // 0000009EED64: 305E5E90
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009EED68: 366666FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 0000009EED70: BF89FC17
	v_dual_mov_b32 v53, v48 :: v_dual_lshlrev_b32 v50, 16, v50 // 0000009EED74: CA220130 35326490
	.long 0xd72c003d                                           // 0000009EED7C: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009EED80: 02027CFF 83DCD12D
	v_and_or_b32 v46, 0xffff, v46, v47                         // 0000009EED88: D657002E 04BE5CFF 0000FFFF
	v_lshl_or_b32 v51, v52, 16, v51                            // 0000009EED94: D6560033 04CD2134
	v_sad_u8 v47, v58, 0, 0x6400                               // 0000009EED9C: D622002F 03FD013A 00006400
	v_and_or_b32 v44, 0xffff, v45, v50                         // 0000009EEDA8: D657002C 04CA5AFF 0000FFFF
	v_sad_u8 v52, v59, 0, 0x6400                               // 0000009EEDB4: D6220034 03FD013B 00006400
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEDC0: CC0E002E 0BFC0B2E 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EEDCC: 365656FF 0000FFFF
	v_pk_fma_f16 v45, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEDD4: CC0E002D 0BFC0B33 0000C931
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009EEDE0: 365E5EFF 0000FFFF
	v_pk_fma_f16 v51, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEDE8: CC0E0033 0BFC0B2C 0000C931
	v_dot2acc_f32_f16 v20, v46, v2                             // 0000009EEDF4: 0428052E
	.long 0xd72c002b                                           // 0000009EEDF8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EEDFC: 020256FF 83DCD12D
	v_sad_u8 v46, v60, 0, 0x6400                               // 0000009EEE04: D622002E 03FD013C 00006400
	v_lshl_or_b32 v47, v52, 16, v47                            // 0000009EEE10: D656002F 04BD2134
	v_sad_u8 v50, v61, 0, 0x6400                               // 0000009EEE18: D6220032 03FD013D 00006400
	v_dot2acc_f32_f16 v20, v45, v3                             // 0000009EEE24: 0428072D
	ds_load_2addr_b32 v[44:45], v39 offset0:112 offset1:136    // 0000009EEE28: D8DC8870 2C000027
	.long 0xd72c003e                                           // 0000009EEE30: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 0000009EEE34: 02027EFF 83DCD12D
	v_pk_fma_f16 v59, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEE3C: CC0E003B 0BFC0B2F 0000C931
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EEE48: D622002B 03FD012B 00006400
	v_and_b32_e32 v48, 0xffff, v50                             // 0000009EEE54: 366064FF 0000FFFF
	.long 0xd72c003a                                           // 0000009EEE5C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009EEE60: 020282FF 83DCD12D
	.long 0xd72c0034                                           // 0000009EEE68: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 0000009EEE6C: 020280FF 83DCD12D
	v_dot2acc_f32_f16 v31, v59, v1                             // 0000009EEE74: 043E033B
	v_lshlrev_b32_e32 v43, 16, v43                             // 0000009EEE78: 30565690
	v_sad_u8 v50, v62, 0, 0x6400                               // 0000009EEE7C: D6220032 03FD013E 00006400
	v_dot2acc_f32_f16 v20, v51, v4                             // 0000009EEE88: 04280933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009EEE8C: BF8701B3
	v_and_or_b32 v43, 0xffff, v46, v43                         // 0000009EEE90: D657002B 04AE5CFF 0000FFFF
	.long 0xd73d002e                                           // 0000009EEE9C: D73D002E
	v_cndmask_b32_e32 v1, v33, v53, vcc_lo                     // 0000009EEEA0: 02026B21
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009EEEA4: D622003A 03FD013A 00006400
	v_pk_fma_f16 v47, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEEB0: CC0E002F 0BFC0B2B 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009EEEBC: BF89FC17
	v_mov_b32_e32 v43, v56                                     // 0000009EEEC0: 7E560338
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EEEC4: BF870004
	v_bfe_u32 v53, v46, 9, 16                                  // 0000009EEEC8: D6100035 0241132E
	v_lshl_or_b32 v48, v50, 16, v48                            // 0000009EEED0: D6560030 04C12132
	v_sad_u8 v50, v52, 0, 0x6400                               // 0000009EEED8: D6220032 03FD0134 00006400
	v_lshlrev_b32_e32 v52, 16, v58                             // 0000009EEEE4: 30687490
	s_waitcnt lgkmcnt(0)                                       // 0000009EEEE8: BF89FC07
	.long 0xd73d002b                                           // 0000009EEEEC: D73D002B
	v_cndmask_b32_e32 v1, v34, v43, vcc_lo                     // 0000009EEEF0: 02025722
	.long 0xd72c002c                                           // 0000009EEEF4: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 0000009EEEF8: 02026AFF 83DCD12D
	v_pk_fma_f16 v48, v48, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EEF00: CC0E0030 0BFC0B30 0000C931
	v_dot2acc_f32_f16 v31, v47, v2                             // 0000009EEF0C: 043E052F
	v_and_b32_e32 v54, 0xffff, v46                             // 0000009EEF10: 366C5CFF 0000FFFF
	v_and_or_b32 v52, 0xffff, v50, v52                         // 0000009EEF18: D6570034 04D264FF 0000FFFF
	v_bfe_u32 v50, v46, 6, 16                                  // 0000009EEF24: D6100032 02410D2E
	v_bfe_u32 v56, v43, 6, 16                                  // 0000009EEF2C: D6100038 02410D2B
	v_dot2acc_f32_f16 v31, v48, v3                             // 0000009EEF34: 043E0730
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EEF38: D622002C 03FD012C 00006400
	.long 0xd72c0035                                           // 0000009EEF44: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EEF48: 02026CFF 83DCD12D
	v_bfe_u32 v54, v43, 9, 16                                  // 0000009EEF50: D6100036 0241132B
	.long 0xd72c0032                                           // 0000009EEF58: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EEF5C: 020264FF 83DCD12D
	v_bfe_u32 v58, v43, 3, 16                                  // 0000009EEF64: D610003A 0241072B
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009EEF6C: 365858FF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EEF74: 365656FF 0000FFFF
	.long 0xd72c0038                                           // 0000009EEF7C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009EEF80: 020270FF 83DCD12D
	v_bfe_u32 v46, v46, 3, 16                                  // 0000009EEF88: D610002E 0241072E
	.long 0xd72c0036                                           // 0000009EEF90: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EEF94: 02026CFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009EEF9C: D6220035 03FD0135 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EEFA8: D6220032 03FD0132 00006400
	.long 0xd72c002b                                           // 0000009EEFB4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EEFB8: 020256FF 83DCD12D
	.long 0xd72c002e                                           // 0000009EEFC0: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EEFC4: 02025CFF 83DCD12D
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EEFCC: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009EEFD8: BF870244
	v_lshl_or_b32 v44, v50, 16, v44                            // 0000009EEFDC: D656002C 04B12132
	v_mov_b32_e32 v50, v55                                     // 0000009EEFE4: 7E640337
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009EEFE8: D6220036 03FD0136 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EEFF4: D622002B 03FD012B 00006400
	v_pk_fma_f16 v44, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF000: CC0E002C 0BFC0B2C 0000C931
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EF00C: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EF018: BF870194
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009EF01C: 366C6CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v30, v44, v1 :: v_dual_lshlrev_b32 v55, 16, v43// 0000009EF024: CB22032C 1E365690
	.long 0xd73d002b                                           // 0000009EF02C: D73D002B
	v_cndmask_b32_e32 v1, v33, v49, vcc_lo                     // 0000009EF030: 02026321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009EF034: BF870113
	v_lshl_or_b32 v54, v56, 16, v54                            // 0000009EF038: D6560036 04D92138
	v_bfe_u32 v49, v43, 9, 16                                  // 0000009EF040: D6100031 0241132B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009EF048: BF870132
	v_pk_fma_f16 v44, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF04C: CC0E002C 0BFC0B36 0000C931
	v_lshlrev_b32_e32 v53, 16, v53                             // 0000009EF058: 306A6A90
	v_bfe_u32 v48, v43, 6, 16                                  // 0000009EF05C: D6100030 02410D2B
	v_and_or_b32 v46, 0xffff, v46, v53                         // 0000009EF064: D657002E 04D65CFF 0000FFFF
	.long 0xd72c0035                                           // 0000009EF070: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EF074: 020274FF 83DCD12D
	v_mov_b32_e32 v58, v45                                     // 0000009EF07C: 7E74032D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EF080: BF870193
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF084: CC0E002E 0BFC0B2E 0000C931
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009EF090: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EF09C: BF8701A2
	v_dot2acc_f32_f16 v30, v46, v2                             // 0000009EF0A0: 043C052E
	v_pk_fma_f16 v46, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF0A4: CC0E002E 0BFC0B34 0000C931
	v_and_or_b32 v47, 0xffff, v53, v55                         // 0000009EF0B0: D657002F 04DE6AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009EF0BC: BF870002
	v_dual_dot2acc_f32_f16 v30, v44, v3 :: v_dual_dot2acc_f32_f16 v31, v46, v4// 0000009EF0C0: CB18072C 1E1E092E
	.long 0xd73d002d                                           // 0000009EF0C8: D73D002D
	v_cndmask_b32_e32 v1, v34, v57, vcc_lo                     // 0000009EF0CC: 02027322
	.long 0xd72c002c                                           // 0000009EF0D0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EF0D4: 020262FF 83DCD12D
	v_bfe_u32 v49, v43, 3, 16                                  // 0000009EF0DC: D6100031 0241072B
	.long 0xd72c002e                                           // 0000009EF0E4: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009EF0E8: 020260FF 83DCD12D
	v_pk_fma_f16 v47, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF0F0: CC0E002F 0BFC0B2F 0000C931
	v_bfe_u32 v48, v45, 9, 16                                  // 0000009EF0FC: D6100030 0241132D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EF104: BF870004
	.long 0xd72c0038                                           // 0000009EF108: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009EF10C: 020262FF 83DCD12D
	v_bfe_u32 v50, v45, 6, 16                                  // 0000009EF114: D6100032 02410D2D
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EF11C: D622002C 03FD012C 00006400
	v_dot2acc_f32_f16 v30, v47, v4                             // 0000009EF128: 043C092F
	.long 0xd72c0037                                           // 0000009EF12C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009EF130: 020260FF 83DCD12D
	ds_load_2addr_b32 v[48:49], v40 offset0:160 offset1:184    // 0000009EF138: D8DCB8A0 30000028
	.long 0xd72c0032                                           // 0000009EF140: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EF144: 020264FF 83DCD12D
	v_and_b32_e32 v47, 0xffff, v43                             // 0000009EF14C: 365E56FF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v44                             // 0000009EF154: 366858FF 0000FFFF
	ds_load_2addr_b32 v[43:44], v38 offset0:160 offset1:184    // 0000009EF15C: D8DCB8A0 2B000026
	v_bfe_u32 v51, v45, 3, 16                                  // 0000009EF164: D6100033 0241072D
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009EF16C: 365A5AFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009EF174: D6220037 03FD0137 00006400
	v_sad_u8 v53, v46, 0, 0x6400                               // 0000009EF180: D6220035 03FD012E 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EF18C: D6220032 03FD0132 00006400
	.long 0xd72c0039                                           // 0000009EF198: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EF19C: 020266FF 83DCD12D
	.long 0xd72c002d                                           // 0000009EF1A4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EF1A8: 02025AFF 83DCD12D
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009EF1B0: 366E6EFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EF1B8: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF1C4: BF870212
	v_lshl_or_b32 v55, v50, 16, v55                            // 0000009EF1C8: D6560037 04DD2132
	v_sad_u8 v58, v45, 0, 0x6400                               // 0000009EF1D0: D622003A 03FD012D 00006400
	s_waitcnt lgkmcnt(1)                                       // 0000009EF1DC: BF89FC17
	v_mov_b32_e32 v50, v48                                     // 0000009EF1E0: 7E640330
	.long 0xd72c0036                                           // 0000009EF1E4: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EF1E8: 02025EFF 83DCD12D
	ds_load_2addr_b32 v[46:47], v37 offset0:160 offset1:184    // 0000009EF1F0: D8DCB8A0 2E000025
	v_pk_fma_f16 v48, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF1F8: CC0E0030 0BFC0B37 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009EF204: BF89FC17
	v_mov_b32_e32 v45, v43                                     // 0000009EF208: 7E5A032B
	v_lshl_or_b32 v53, v53, 16, v52                            // 0000009EF20C: D6560035 04D12135
	ds_load_2addr_b32 v[51:52], v39 offset0:160 offset1:184    // 0000009EF214: D8DCB8A0 33000027
	v_sad_u8 v43, v57, 0, 0x6400                               // 0000009EF21C: D622002B 03FD0139 00006400
	v_lshlrev_b32_e32 v57, 16, v58                             // 0000009EF228: 30727490
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009EF22C: D6220036 03FD0136 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EF238: BF870092
	v_and_or_b32 v43, 0xffff, v43, v57                         // 0000009EF23C: D657002B 04E656FF 0000FFFF
	v_pk_fma_f16 v55, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF248: CC0E0037 0BFC0B2B 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009EF254: BF89FC17
	.long 0xd73d002d                                           // 0000009EF258: D73D002D
	v_cndmask_b32_e32 v1, v33, v45, vcc_lo                     // 0000009EF25C: 02025B21
	v_pk_fma_f16 v46, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF260: CC0E002E 0BFC0B35 0000C931
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000009EF26C: 306C6C90
	s_waitcnt lgkmcnt(0)                                       // 0000009EF270: BF89FC07
	.long 0xd73d0032                                           // 0000009EF274: D73D0032
	v_cndmask_b32_e32 v1, v34, v50, vcc_lo                     // 0000009EF278: 02026522
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EF27C: BF870004
	v_and_b32_e32 v43, 0xffff, v45                             // 0000009EF280: 36565AFF 0000FFFF
	v_dot2acc_f32_f16 v29, v46, v1                             // 0000009EF288: 043A032E
	v_and_or_b32 v54, 0xffff, v56, v54                         // 0000009EF28C: D6570036 04DA70FF 0000FFFF
	v_bfe_u32 v51, v45, 6, 16                                  // 0000009EF298: D6100033 02410D2D
	v_and_b32_e32 v56, 0xffff, v50                             // 0000009EF2A0: 367064FF 0000FFFF
	.long 0xd72c002b                                           // 0000009EF2A8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EF2AC: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009EF2B4: BF870244
	v_pk_fma_f16 v53, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF2B8: CC0E0035 0BFC0B36 0000C931
	v_bfe_u32 v54, v45, 9, 16                                  // 0000009EF2C4: D6100036 0241132D
	v_bfe_u32 v45, v45, 3, 16                                  // 0000009EF2CC: D610002D 0241072D
	.long 0xd72c0033                                           // 0000009EF2D4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EF2D8: 020266FF 83DCD12D
	v_dot2acc_f32_f16 v29, v53, v2                             // 0000009EF2E0: 043A0535
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF2E4: BF870214
	.long 0xd72c002e                                           // 0000009EF2E8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EF2EC: 02026CFF 83DCD12D
	.long 0xd72c002d                                           // 0000009EF2F4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EF2F8: 02025AFF 83DCD12D
	v_bfe_u32 v54, v50, 9, 16                                  // 0000009EF300: D6100036 02411332
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EF308: D622002B 03FD012B 00006400
	v_dot2acc_f32_f16 v29, v48, v3                             // 0000009EF314: 043A0730
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009EF318: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EF324: BF870004
	.long 0xd72c0035                                           // 0000009EF328: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EF32C: 02026CFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EF334: D622002E 03FD012E 00006400
	v_bfe_u32 v54, v50, 6, 16                                  // 0000009EF340: D6100036 02410D32
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EF348: D622002D 03FD012D 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 0000009EF354: 30565690
	v_bfe_u32 v50, v50, 3, 16                                  // 0000009EF358: D6100032 02410732
	v_and_b32_e32 v46, 0xffff, v46                             // 0000009EF360: 365C5CFF 0000FFFF
	.long 0xd72c0036                                           // 0000009EF368: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EF36C: 02026CFF 83DCD12D
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009EF374: D6220035 03FD0135 00006400
	v_and_or_b32 v43, 0xffff, v45, v43                         // 0000009EF380: D657002B 04AE5AFF 0000FFFF
	v_mov_b32_e32 v45, v47                                     // 0000009EF38C: 7E5A032F
	.long 0xd72c0038                                           // 0000009EF390: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009EF394: 020270FF 83DCD12D
	v_lshl_or_b32 v46, v51, 16, v46                            // 0000009EF39C: D656002E 04B92133
	.long 0xd72c0032                                           // 0000009EF3A4: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EF3A8: 020264FF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v53                             // 0000009EF3B0: 36666AFF 0000FFFF
	v_sad_u8 v47, v54, 0, 0x6400                               // 0000009EF3B8: D622002F 03FD0136 00006400
	v_pk_fma_f16 v54, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF3C4: CC0E0036 0BFC0B2B 0000C931
	.long 0xd73d002b                                           // 0000009EF3D0: D73D002B
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000009EF3D4: 02025921
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF3D8: CC0E002E 0BFC0B2E 0000C931
	v_sad_u8 v53, v56, 0, 0x6400                               // 0000009EF3E4: D6220035 03FD0138 00006400
	v_lshl_or_b32 v44, v47, 16, v51                            // 0000009EF3F0: D656002C 04CD212F
	v_sad_u8 v45, v50, 0, 0x6400                               // 0000009EF3F8: D622002D 03FD0132 00006400
	v_mov_b32_e32 v50, v52                                     // 0000009EF404: 7E640334
	v_dot2acc_f32_f16 v28, v46, v1                             // 0000009EF408: 0438032E
	v_lshlrev_b32_e32 v47, 16, v53                             // 0000009EF40C: 305E6A90
	v_bfe_u32 v46, v43, 9, 16                                  // 0000009EF410: D610002E 0241132B
	v_pk_fma_f16 v48, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF418: CC0E0030 0BFC0B2C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF424: BF870214
	v_dot2acc_f32_f16 v28, v54, v2                             // 0000009EF428: 04380536
	v_and_or_b32 v44, 0xffff, v45, v47                         // 0000009EF42C: D657002C 04BE5AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EF438: BF870224
	.long 0xd72c002e                                           // 0000009EF43C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 0000009EF440: 02025CFF 83DCD12D
	v_bfe_u32 v47, v43, 6, 16                                  // 0000009EF448: D610002F 02410D2B
	v_dot2acc_f32_f16 v28, v48, v3                             // 0000009EF450: 04380730
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EF454: BF870224
	v_pk_fma_f16 v53, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF458: CC0E0035 0BFC0B2C 0000C931
	.long 0xd73d002c                                           // 0000009EF464: D73D002C
	v_cndmask_b32_e32 v1, v34, v49, vcc_lo                     // 0000009EF468: 02026322
	.long 0xd72c002f                                           // 0000009EF46C: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EF470: 02025EFF 83DCD12D
	v_bfe_u32 v45, v43, 3, 16                                  // 0000009EF478: D610002D 0241072B
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009EF480: 365656FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EF488: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v29, v55, v4                             // 0000009EF494: 043A0937
	v_bfe_u32 v48, v44, 9, 16                                  // 0000009EF498: D6100030 0241132C
	v_bfe_u32 v50, v44, 6, 16                                  // 0000009EF4A0: D6100032 02410D2C
	v_bfe_u32 v54, v44, 3, 16                                  // 0000009EF4A8: D6100036 0241072C
	v_and_b32_e32 v51, 0xffff, v44                             // 0000009EF4B0: 366658FF 0000FFFF
	v_and_b32_e32 v52, 0xffff, v46                             // 0000009EF4B8: 36685CFF 0000FFFF
	.long 0xd72c0037                                           // 0000009EF4C0: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EF4C4: 020256FF 83DCD12D
	ds_load_2addr_b32 v[43:44], v38 offset0:208 offset1:232    // 0000009EF4CC: D8DCE8D0 2B000026
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EF4D4: D622002F 03FD012F 00006400
	.long 0xd72c0038                                           // 0000009EF4E0: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EF4E4: 02025AFF 83DCD12D
	.long 0xd72c0039                                           // 0000009EF4EC: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009EF4F0: 020260FF 83DCD12D
	ds_load_2addr_b32 v[45:46], v40 offset0:208 offset1:232    // 0000009EF4F8: D8DCE8D0 2D000028
	ds_load_2addr_b32 v[48:49], v37 offset0:208 offset1:232    // 0000009EF500: D8DCE8D0 30000025
	.long 0xd72c003a                                           // 0000009EF508: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EF50C: 020266FF 83DCD12D
	v_lshl_or_b32 v47, v47, 16, v52                            // 0000009EF514: D656002F 04D1212F
	ds_load_2addr_b32 v[51:52], v39 offset0:208 offset1:232    // 0000009EF51C: D8DCE8D0 33000027
	.long 0xd72c0032                                           // 0000009EF524: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EF528: 020264FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009EF530: D6220037 03FD0137 00006400
	.long 0xd72c0036                                           // 0000009EF53C: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 0000009EF540: 02026CFF 83DCD12D
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009EF548: D6220039 03FD0139 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EF554: D6220038 03FD0138 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009EF560: D622003A 03FD013A 00006400
	v_dual_dot2acc_f32_f16 v28, v53, v4 :: v_dual_lshlrev_b32 v55, 16, v55// 0000009EF56C: CB220935 1C366E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009EF574: BF870234
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009EF578: 367272FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EF580: D6220032 03FD0132 00006400
	v_pk_fma_f16 v59, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF58C: CC0E003B 0BFC0B2F 0000C931
	v_and_or_b32 v55, 0xffff, v56, v55                         // 0000009EF598: D6570037 04DE70FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 0000009EF5A4: BF89FC37
	v_mov_b32_e32 v47, v43                                     // 0000009EF5A8: 7E5E032B
	v_sad_u8 v43, v54, 0, 0x6400                               // 0000009EF5AC: D622002B 03FD0136 00006400
	v_lshl_or_b32 v56, v50, 16, v57                            // 0000009EF5B8: D6560038 04E52132
	s_waitcnt lgkmcnt(2)                                       // 0000009EF5C0: BF89FC27
	v_mov_b32_e32 v50, v45                                     // 0000009EF5C4: 7E64032D
	v_lshlrev_b32_e32 v54, 16, v58                             // 0000009EF5C8: 306C7490
	s_waitcnt lgkmcnt(1)                                       // 0000009EF5CC: BF89FC17
	.long 0xd73d002f                                           // 0000009EF5D0: D73D002F
	v_cndmask_b32_e32 v1, v33, v47, vcc_lo                     // 0000009EF5D4: 02025F21
	v_pk_fma_f16 v45, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF5D8: CC0E002D 0BFC0B37 0000C931
	v_pk_fma_f16 v48, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF5E4: CC0E0030 0BFC0B38 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009EF5F0: BF89FC07
	.long 0xd73d0032                                           // 0000009EF5F4: D73D0032
	v_cndmask_b32_e32 v1, v34, v50, vcc_lo                     // 0000009EF5F8: 02026522
	v_and_or_b32 v43, 0xffff, v43, v54                         // 0000009EF5FC: D657002B 04DA56FF 0000FFFF
	v_dot2acc_f32_f16 v27, v59, v1                             // 0000009EF608: 0436033B
	v_bfe_u32 v51, v47, 9, 16                                  // 0000009EF60C: D6100033 0241132F
	v_bfe_u32 v55, v47, 6, 16                                  // 0000009EF614: D6100037 02410D2F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF61C: BF870214
	v_pk_fma_f16 v54, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF620: CC0E0036 0BFC0B2B 0000C931
	v_dot2acc_f32_f16 v27, v45, v2                             // 0000009EF62C: 0436052D
	v_and_b32_e32 v43, 0xffff, v47                             // 0000009EF630: 36565EFF 0000FFFF
	v_bfe_u32 v45, v50, 9, 16                                  // 0000009EF638: D610002D 02411332
	v_bfe_u32 v47, v47, 3, 16                                  // 0000009EF640: D610002F 0241072F
	.long 0xd72c0033                                           // 0000009EF648: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 0000009EF64C: 020266FF 83DCD12D
	v_bfe_u32 v56, v50, 6, 16                                  // 0000009EF654: D6100038 02410D32
	.long 0xd72c002b                                           // 0000009EF65C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EF660: 020256FF 83DCD12D
	.long 0xd72c002d                                           // 0000009EF668: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009EF66C: 02025AFF 83DCD12D
	.long 0xd72c002f                                           // 0000009EF674: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EF678: 02025EFF 83DCD12D
	.long 0xd72c0037                                           // 0000009EF680: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 0000009EF684: 02026EFF 83DCD12D
	.long 0xd72c0038                                           // 0000009EF68C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009EF690: 020270FF 83DCD12D
	v_bfe_u32 v57, v50, 3, 16                                  // 0000009EF698: D6100039 02410732
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009EF6A0: D6220033 03FD0133 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009EF6AC: 366464FF 0000FFFF
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EF6B4: D622002B 03FD012B 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009EF6C0: D622002D 03FD012D 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EF6CC: D622002F 03FD012F 00006400
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009EF6D8: 366666FF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009EF6E0: D6220037 03FD0137 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 0000009EF6EC: 30565690
	v_dual_mov_b32 v45, v49 :: v_dual_and_b32 v58, 0xffff, v45 // 0000009EF6F0: CA240131 2D3A5AFF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009EF6FC: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF708: BF870214
	v_lshl_or_b32 v49, v55, 16, v51                            // 0000009EF70C: D6560031 04CD2137
	v_and_or_b32 v47, 0xffff, v47, v43                         // 0000009EF714: D657002F 04AE5EFF 0000FFFF
	.long 0xd72c0032                                           // 0000009EF720: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000009EF724: 020264FF 83DCD12D
	.long 0xd73d002b                                           // 0000009EF72C: D73D002B
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000009EF730: 02025921
	v_lshl_or_b32 v51, v56, 16, v58                            // 0000009EF734: D6560033 04E92138
	.long 0xd72c0037                                           // 0000009EF73C: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EF740: 020272FF 83DCD12D
	v_pk_fma_f16 v56, v47, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF748: CC0E0038 0BFC0B2F 0000C931
	v_mov_b32_e32 v47, v52                                     // 0000009EF754: 7E5E0334
	v_pk_fma_f16 v49, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF758: CC0E0031 0BFC0B31 0000C931
	v_bfe_u32 v52, v43, 9, 16                                  // 0000009EF764: D6100034 0241132B
	v_and_b32_e32 v57, 0xffff, v43                             // 0000009EF76C: 367256FF 0000FFFF
	v_pk_fma_f16 v51, v51, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF774: CC0E0033 0BFC0B33 0000C931
	.long 0xd73d002c                                           // 0000009EF780: D73D002C
	v_cndmask_b32_e32 v1, v34, v46, vcc_lo                     // 0000009EF784: 02025D22
	v_bfe_u32 v47, v43, 6, 16                                  // 0000009EF788: D610002F 02410D2B
	.long 0xd72c002e                                           // 0000009EF790: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EF794: 020268FF 83DCD12D
	v_sad_u8 v45, v50, 0, 0x6400                               // 0000009EF79C: D622002D 03FD0132 00006400
	v_bfe_u32 v43, v43, 3, 16                                  // 0000009EF7A8: D610002B 0241072B
	.long 0xd72c0032                                           // 0000009EF7B0: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EF7B4: 020272FF 83DCD12D
	v_bfe_u32 v52, v44, 9, 16                                  // 0000009EF7BC: D6100034 0241132C
	.long 0xd72c002f                                           // 0000009EF7C4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 0000009EF7C8: 02025EFF 83DCD12D
	v_bfe_u32 v57, v44, 6, 16                                  // 0000009EF7D0: D6100039 02410D2C
	.long 0xd72c002b                                           // 0000009EF7D8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 0000009EF7DC: 020256FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009EF7E4: D622002E 03FD012E 00006400
	v_bfe_u32 v58, v44, 3, 16                                  // 0000009EF7F0: D610003A 0241072C
	.long 0xd72c0034                                           // 0000009EF7F8: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009EF7FC: 020268FF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009EF804: 365858FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009EF80C: D6220032 03FD0132 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 0000009EF818: 365C5CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EF820: D622002F 03FD012F 00006400
	.long 0xd72c0039                                           // 0000009EF82C: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009EF830: 020272FF 83DCD12D
	.long 0xd72c002c                                           // 0000009EF838: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009EF83C: 020258FF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009EF844: D622002B 03FD012B 00006400
	v_lshlrev_b32_e32 v50, 16, v50                             // 0000009EF850: 30646490
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009EF854: D6220034 03FD0134 00006400
	v_lshl_or_b32 v46, v47, 16, v46                            // 0000009EF860: D656002E 04B9212F
	.long 0xd72c002f                                           // 0000009EF868: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 0000009EF86C: 020274FF 83DCD12D
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009EF874: D6220037 03FD0137 00006400
	v_and_or_b32 v43, 0xffff, v43, v50                         // 0000009EF880: D657002B 04CA56FF 0000FFFF
	v_dual_dot2acc_f32_f16 v27, v48, v3 :: v_dual_and_b32 v50, 0xffff, v52// 0000009EF88C: CB240730 1B3268FF 0000FFFF
	v_sad_u8 v52, v57, 0, 0x6400                               // 0000009EF898: D6220034 03FD0139 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009EF8A4: D622002C 03FD012C 00006400
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF8B0: CC0E002E 0BFC0B2E 0000C931
	v_lshlrev_b32_e32 v45, 16, v45                             // 0000009EF8BC: 305A5A90
	v_dot2acc_f32_f16 v26, v49, v1                             // 0000009EF8C0: 04340331
	v_pk_fma_f16 v43, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF8C4: CC0E002B 0BFC0B2B 0000C931
	v_lshl_or_b32 v49, v52, 16, v50                            // 0000009EF8D0: D6560031 04C92134
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009EF8D8: D622002F 03FD012F 00006400
	v_lshlrev_b32_e32 v44, 16, v44                             // 0000009EF8E4: 30585890
	v_dot2acc_f32_f16 v32, v46, v1                             // 0000009EF8E8: 0440032E
	v_and_or_b32 v1, 0xffff, v55, v45                          // 0000009EF8EC: D6570001 04B66EFF 0000FFFF
	v_dot2acc_f32_f16 v26, v56, v2                             // 0000009EF8F8: 04340538
	v_pk_fma_f16 v45, v49, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009EF8FC: CC0E002D 0BFC0B31 0000C931
	v_and_or_b32 v44, 0xffff, v47, v44                         // 0000009EF908: D657002C 04B25EFF 0000FFFF
	v_dot2acc_f32_f16 v32, v43, v2                             // 0000009EF914: 0440052B
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000009EF918: CC0E0001 0BFC0B01 0000C931
	v_dual_dot2acc_f32_f16 v26, v51, v3 :: v_dual_dot2acc_f32_f16 v27, v54, v4// 0000009EF924: CB180733 1A1A0936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EF92C: BF870214
	v_pk_fma_f16 v2, v44, s5, 0xc931 op_sel_hi:[1,0,0]         // 0000009EF930: CC0E0002 0BFC0B2C 0000C931
	v_dual_dot2acc_f32_f16 v32, v45, v3 :: v_dual_add_nc_u32 v3, 1, v42// 0000009EF93C: CB20072D 20025481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009EF944: BF870113
	v_dot2acc_f32_f16 v26, v1, v4                              // 0000009EF948: 04340901
	v_dot2acc_f32_f16 v32, v2, v4                              // 0000009EF94C: 04400902
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009EF950: BF870003
	.long 0xd4c9007e                                           // 0000009EF954: D4C9007E
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000009EF958: 02021903
	s_cbranch_execz 64596                                      // 0000009EF95C: BFA5FC54 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11b0>
	v_add_nc_u32_e32 v1, 3, v42                                // 0000009EF960: 4A025483
	s_mov_b32 s21, exec_lo                                     // 0000009EF964: BE95007E
	ds_store_2addr_b32 v36, v13, v21 offset0:64 offset1:96     // 0000009EF968: D8386040 00150D24
	ds_store_2addr_b32 v36, v22, v23 offset0:128 offset1:160   // 0000009EF970: D838A080 00171624
	ds_store_2addr_b32 v36, v24, v25 offset0:192 offset1:224   // 0000009EF978: D838E0C0 00191824
	.long 0xd4c9007e                                           // 0000009EF980: D4C9007E
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000009EF984: 02021901
	s_cbranch_execz 63695                                      // 0000009EF988: BFA5F8CF <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x3c8>
	v_mad_u64_u32 v[1:2], null, 0x300, v1, v[5:6]              // 0000009EF98C: D6FE7C01 041602FF 00000300
	s_clause 0x5                                               // 0000009EF998: BF850005
	global_load_b32 v13, v[1:2], off                           // 0000009EF99C: DC520000 0D7C0001
	global_load_b32 v21, v[1:2], off offset:128                // 0000009EF9A4: DC520080 157C0001
	global_load_b32 v22, v[1:2], off offset:256                // 0000009EF9AC: DC520100 167C0001
	global_load_b32 v23, v[1:2], off offset:384                // 0000009EF9B4: DC520180 177C0001
	global_load_b32 v24, v[1:2], off offset:512                // 0000009EF9BC: DC520200 187C0001
	global_load_b32 v25, v[1:2], off offset:640                // 0000009EF9C4: DC520280 197C0001
	s_branch 63678                                             // 0000009EF9CC: BFA0F8BE <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x3c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009EF9D0: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009EF9D4: BF870009
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009EF9D8: 8C7E067E
	s_load_b128 s[4:7], s[0:1], 0x40                           // 0000009EF9DC: F4080100 F8000040
	v_dual_mov_b32 v1, v20 :: v_dual_mov_b32 v2, v31           // 0000009EF9E4: CA100114 0102011F
	v_dual_mov_b32 v3, v30 :: v_dual_mov_b32 v4, v28           // 0000009EF9EC: CA10011E 0304011C
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v6, v26           // 0000009EF9F4: CA10011D 0706011A
	v_dual_mov_b32 v5, v27 :: v_dual_mov_b32 v8, v32           // 0000009EF9FC: CA10011B 05080120
	s_mov_b32 s0, 0x76543210                                   // 0000009EFA04: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v10                           // 0000009EFA0C: 7C981490
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009EFA10: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009EFA1C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009EFA28: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009EFA34: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009EFA40: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009EFA4C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009EFA58: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009EFA64: D65C0008 03FC0108 FEDCBA98
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000009EFA70: BF890007
	s_barrier                                                  // 0000009EFA74: BFBD0000
	buffer_gl0_inv                                             // 0000009EFA78: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009EFA80: BE80206A
	s_cbranch_execz 18                                         // 0000009EFA84: BFA50012 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x21d0>
	v_dual_add_f32 v1, v20, v1 :: v_dual_add_f32 v2, v31, v2   // 0000009EFA88: C9080314 0102051F
	v_lshl_or_b32 v10, v9, 9, v11                              // 0000009EFA90: D656000A 042D1309
	v_dual_add_f32 v8, v32, v8 :: v_dual_add_f32 v3, v30, v3   // 0000009EFA98: C9081120 0802071E
	v_dual_add_f32 v7, v29, v7 :: v_dual_add_f32 v4, v28, v4   // 0000009EFAA0: C9080F1D 0704091C
	v_dual_add_f32 v5, v27, v5 :: v_dual_add_f32 v6, v26, v6   // 0000009EFAA8: C9080B1B 05060D1A
	ds_store_2addr_b32 v10, v1, v2 offset1:16                  // 0000009EFAB0: D8381000 0002010A
	ds_store_2addr_b32 v10, v3, v7 offset0:32 offset1:48       // 0000009EFAB8: D8383020 0007030A
	ds_store_2addr_b32 v10, v4, v5 offset0:64 offset1:80       // 0000009EFAC0: D8385040 0005040A
	ds_store_2addr_b32 v10, v6, v8 offset0:96 offset1:112      // 0000009EFAC8: D8387060 0008060A
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009EFAD0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009EFAD4: BF870009
	s_mov_b32 s21, exec_lo                                     // 0000009EFAD8: BE95007E
	s_waitcnt lgkmcnt(0)                                       // 0000009EFADC: BF89FC07
	s_barrier                                                  // 0000009EFAE0: BFBD0000
	buffer_gl0_inv                                             // 0000009EFAE4: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v9                                    // 0000009EFAEC: 7D941280
	s_cbranch_execz 513                                        // 0000009EFAF0: BFA50201 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x29f8>
	v_and_b32_e32 v1, 15, v0                                   // 0000009EFAF4: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009EFAF8: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000009EFAFC: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 0000009EFB00: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 0000009EFB08: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 0000009EFB10: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 0000009EFB14: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 0000009EFB1C: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 0000009EFB24: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 0000009EFB2C: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000009EFB34: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 0000009EFB38: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 0000009EFB3C: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 0000009EFB44: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 0000009EFB4C: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 0000009EFB54: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 0000009EFB5C: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 0000009EFB64: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 0000009EFB6C: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 0000009EFB74: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 0000009EFB7C: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 0000009EFB84: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 0000009EFB8C: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 0000009EFB94: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 0000009EFB9C: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 0000009EFBA4: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 0000009EFBAC: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 0000009EFBB4: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 0000009EFBBC: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 0000009EFBC4: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 0000009EFBCC: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 0000009EFBD4: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 0000009EFBDC: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 0000009EFBE4: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 0000009EFBE8: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 0000009EFBEC: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 0000009EFBF0: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 0000009EFBF8: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 0000009EFC00: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 0000009EFC08: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 0000009EFC10: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 0000009EFC14: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 0000009EFC1C: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 0000009EFC20: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 0000009EFC28: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 0000009EFC2C: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 0000009EFC34: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 0000009EFC38: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 0000009EFC3C: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 0000009EFC40: 06102908
	v_add_f32_e32 v12, v11, v13                                // 0000009EFC44: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 0000009EFC48: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 0000009EFC50: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 0000009EFC54: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 0000009EFC58: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 0000009EFC60: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 0000009EFC68: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009EFC6C: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 0000009EFC70: 06103108
	s_waitcnt lgkmcnt(4)                                       // 0000009EFC74: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 0000009EFC78: 06265909
	s_waitcnt lgkmcnt(2)                                       // 0000009EFC7C: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 0000009EFC80: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 0000009EFC84: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 0000009EFC8C: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 0000009EFC90: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 0000009EFC94: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 0000009EFC98: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 0000009EFC9C: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 0000009EFCA4: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 0000009EFCAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009EFCB0: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 0000009EFCB4: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 0000009EFCB8: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 0000009EFCC0: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 0000009EFCC8: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 0000009EFCCC: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 0000009EFCD0: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 0000009EFCD8: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 0000009EFCDC: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 0000009EFCE4: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 0000009EFCE8: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009EFCF0: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 0000009EFCF4: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 0000009EFCF8: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 0000009EFD00: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 0000009EFD04: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 0000009EFD0C: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 0000009EFD10: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 0000009EFD18: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009EFD1C: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 0000009EFD20: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 0000009EFD28: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000009EFD2C: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009EFD34: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 0000009EFD38: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 0000009EFD40: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 0000009EFD44: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 0000009EFD48: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009EFD4C: 08040702
	v_add_f32_e32 v16, v16, v48                                // 0000009EFD50: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EFD54: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 0000009EFD58: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 0000009EFD5C: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009EFD60: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 0000009EFD64: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 0000009EFD68: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 0000009EFD6C: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009EFD70: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 0000009EFD74: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 0000009EFD7C: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 0000009EFD80: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EFD84: BF870213
	.long 0xd44a0000                                           // 0000009EFD88: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009EFD8C: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 0000009EFD90: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EFD94: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 0000009EFD98: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 0000009EFD9C: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 0000009EFDA0: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 0000009EFDA8: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EFDAC: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 0000009EFDB0: 06105308
	.long 0xd44a0001                                           // 0000009EFDB4: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000009EFDB8: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009EFDBC: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 0000009EFDC0: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 0000009EFDC4: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 0000009EFDC8: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 0000009EFDCC: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EFDD0: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 0000009EFDD4: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 0000009EFDDC: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 0000009EFDE0: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 0000009EFDE4: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 0000009EFDE8: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFDEC: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009EFDF4: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009EFDFC: BF870113
	.long 0xd44a0003                                           // 0000009EFE00: D44A0003
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000009EFE04: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 0000009EFE08: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 0000009EFE10: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EFE18: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFE1C: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009EFE24: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 0000009EFE2C: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EFE30: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFE34: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009EFE3C: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 0000009EFE44: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009EFE4C: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFE50: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 0000009EFE58: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009EFE5C: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFE60: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009EFE68: D5010004 200E0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFE70: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009EFE78: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009EFE80: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 0000009EFE84: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 0000009EFE88: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFE90: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009EFE98: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 0000009EFEA0: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFEA4: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009EFEAC: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 0000009EFEB0: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009EFEB4: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFEBC: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009EFEC4: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009EFECC: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFED0: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 0000009EFED8: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 0000009EFEE0: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 0000009EFEE4: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 0000009EFEE8: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 0000009EFEEC: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFEF0: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 0000009EFEF8: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EFF00: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFF04: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009EFF0C: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFF14: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009EFF1C: D501000B 200E170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009EFF24: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009EFF2C: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 0000009EFF34: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFF38: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009EFF40: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 0000009EFF48: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFF4C: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009EFF54: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009EFF5C: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009EFF64: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 0000009EFF6C: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFF70: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009EFF78: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EFF80: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 0000009EFF84: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFF8C: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009EFF94: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EFF9C: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 0000009EFFA0: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFFA4: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009EFFAC: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009EFFB4: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 0000009EFFBC: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 0000009EFFC4: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFFCC: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009EFFD4: BF870214
	v_add_f32_e32 v10, v10, v12                                // 0000009EFFD8: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 0000009EFFDC: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009EFFE0: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFFE4: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s3                         // 0000009EFFEC: D501000F 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009EFFF4: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009EFFFC: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009F0004: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009F000C: D501000A 200E150A
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000009F0014: D501000C 200E190C
	v_add_f32_e32 v14, v9, v11                                 // 0000009F001C: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 0000009F0020: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F0024: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 0000009F002C: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 0000009F0030: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F0034: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F003C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F0044: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F004C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009F0054: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009F005C: 8B7E6A7E
	s_cbranch_execz 165                                        // 0000009F0060: BFA500A5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x29f8>
	v_and_b32_e32 v26, 8, v0                                   // 0000009F0064: 36340088
	s_mul_i32 s0, s8, 0x1400                                   // 0000009F0068: 9600FF08 00001400
	s_mul_hi_i32 s1, s8, 0x1400                                // 0000009F0070: 9701FF08 00001400
	s_add_u32 s3, s10, s0                                      // 0000009F0078: 8003000A
	s_addc_u32 s8, s11, s1                                     // 0000009F007C: 8208010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v26                            // 0000009F0080: 7C943480
	s_lshl_b32 s0, s9, 7                                       // 0000009F0084: 84008709
	.long 0x7f243880                                           // 0000009F0088: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 0000009F008C: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009F0090: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000009F0094: 84808100
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009F0098: D5010006 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000009F00A0: 30020281
	s_add_u32 s10, s3, s0                                      // 0000009F00A4: 800A0003
	s_addc_u32 s11, s8, s1                                     // 0000009F00A8: 820B0108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009F00AC: D5010003 21AA0703
	v_add_f32_e32 v4, v6, v4                                   // 0000009F00B4: 06080906
	s_clause 0x7                                               // 0000009F00B8: BF850007
	global_load_d16_b16 v18, v1, s[10:11] offset:32            // 0000009F00BC: DC820020 120A0001
	global_load_d16_b16 v19, v1, s[10:11]                      // 0000009F00C4: DC820000 130A0001
	global_load_d16_b16 v20, v1, s[10:11] offset:64            // 0000009F00CC: DC820040 140A0001
	global_load_d16_b16 v21, v1, s[10:11] offset:96            // 0000009F00D4: DC820060 150A0001
	global_load_d16_b16 v22, v1, s[10:11] offset:128           // 0000009F00DC: DC820080 160A0001
	global_load_d16_b16 v23, v1, s[10:11] offset:160           // 0000009F00E4: DC8200A0 170A0001
	global_load_d16_b16 v24, v1, s[10:11] offset:192           // 0000009F00EC: DC8200C0 180A0001
	global_load_d16_b16 v25, v1, s[10:11] offset:224           // 0000009F00F4: DC8200E0 190A0001
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 0000009F00FC: D5010006 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009F0104: D5010005 21AA0B05
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 0000009F010C: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009F0114: D501000E 21AA1D0E
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009F011C: D5010010 21AA2311
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v4// 0000009F0124: C9060503 020208FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009F0130: BF8701B4
	v_dual_add_f32 v4, v6, v8 :: v_dual_add_f32 v7, v7, v11    // 0000009F0134: C9081106 04061707
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009F013C: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v14, v10   // 0000009F0144: C9081305 0506150E
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009F014C: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009F0158: BF8701B2
	v_dual_add_f32 v8, v15, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000009F015C: C906190F 08040AFF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 0000009F0168: BF8917F7
	.long 0x7f283992                                           // 0000009F016C: 7F283992
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009F0170: 101212FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 0000009F0178: BF8913F7
	.long 0x7f2a3992                                           // 0000009F017C: 7F2A3992
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000009F0180: C8C604FF 02060EFF 3DB504F3
	.long 0x7f263992                                           // 0000009F018C: 7F263992
	s_waitcnt vmcnt(3)                                         // 0000009F0190: BF890FF7
	.long 0x7f2c3992                                           // 0000009F0194: 7F2C3992
	s_mul_i32 s8, s20, 0x1400                                  // 0000009F0198: 9608FF14 00001400
	s_mul_hi_i32 s3, s20, 0x1400                               // 0000009F01A0: 9703FF14 00001400
	s_add_u32 s8, s12, s8                                      // 0000009F01A8: 8008080C
	s_addc_u32 s3, s13, s3                                     // 0000009F01AC: 8203030D
	s_add_u32 s0, s8, s0                                       // 0000009F01B0: 80000008
	s_addc_u32 s1, s3, s1                                      // 0000009F01B4: 82010103
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009F01B8: CC200003 8A020712
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 0000009F01C0: CC200002 8A020513
	v_fma_mix_f32 v4, v20, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009F01C8: CC200004 8A020914
	v_fma_mix_f32 v5, v21, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009F01D0: CC200005 8A020B15
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009F01D8: BF870004
	.long 0x7e243983                                           // 0000009F01DC: 7E243983
	s_waitcnt vmcnt(2)                                         // 0000009F01E0: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000009F01E4: CC200007 8A020F17
	.long 0x7e283984                                           // 0000009F01EC: 7E283984
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000009F01F0: 100C0CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000009F01F8: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009F01FC: CC200009 8A021319
	v_and_b32_e32 v10, 1, v18                                  // 0000009F0204: 36142481
	.long 0x7e243985                                           // 0000009F0208: 7E243985
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000009F020C: 101010FF 3DB504F3
	v_and_b32_e32 v13, 1, v20                                  // 0000009F0214: 361A2881
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009F0218: CC200006 8A020D16
	.long 0x7e263982                                           // 0000009F0220: 7E263982
	v_and_b32_e32 v11, 1, v18                                  // 0000009F0224: 36162481
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009F0228: CC200008 8A021118
	.long 0x7e243987                                           // 0000009F0230: 7E243987
	.long 0x7e2a3986                                           // 0000009F0234: 7E2A3986
	v_and_b32_e32 v12, 1, v19                                  // 0000009F0238: 36182681
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000009F023C: D6550003 03FE1503 00007FFF
	.long 0x7e2c3988                                           // 0000009F0248: 7E2C3988
	v_and_b32_e32 v15, 1, v18                                  // 0000009F024C: 361E2481
	.long 0x7e243989                                           // 0000009F0250: 7E243989
	v_and_b32_e32 v14, 1, v21                                  // 0000009F0254: 361C2A81
	v_add3_u32 v2, v2, v12, 0x7fff                             // 0000009F0258: D6550002 03FE1902 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 0000009F0264: 36202C81
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000009F0268: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 0000009F0274: 36142481
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000009F0278: D6550005 03FE1705 00007FFF
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000009F0284: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000009F0290: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000009F029C: D6550007 03FE1F07 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000009F02A8: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000009F02B4: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009F02B8: DC960000 00000201
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:32           // 0000009F02C0: DC960020 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:64           // 0000009F02C8: DC960040 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:96           // 0000009F02D0: DC960060 00000501
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:128          // 0000009F02D8: DC960080 00000601
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 0000009F02E0: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 0000009F02E8: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v9, s[0:1] offset:224          // 0000009F02F0: DC9600E0 00000901
	s_or_b32 exec_lo, exec_lo, s21                             // 0000009F02F8: 8C7E157E
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 0000009F02FC: 9700FF02 51EB851F
	s_waitcnt_vscnt null, 0x0                                  // 0000009F0304: BC7C0000
	buffer_gl1_inv                                             // 0000009F0308: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009F0310: E0AC0000 00000000
	s_lshr_b32 s1, s0, 31                                      // 0000009F0318: 85019F00
	s_ashr_i32 s0, s0, 6                                       // 0000009F031C: 86008600
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009F0320: BF870009
	s_add_i32 s8, s0, s1                                       // 0000009F0324: 81080100
	.long 0xd44a0000                                           // 0000009F0328: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009F032C: 02020080
	s_mul_i32 s1, s8, 20                                       // 0000009F0330: 96019408
	s_barrier                                                  // 0000009F0334: BFBD0000
	s_add_i32 s2, s9, s1                                       // 0000009F0338: 81020109
	buffer_gl0_inv                                             // 0000009F033C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009F0344: BE812000
	s_cbranch_execz 29                                         // 0000009F0348: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2ac0>
	s_mov_b32 s11, exec_lo                                     // 0000009F034C: BE8B007E
	s_mov_b32 s10, exec_lo                                     // 0000009F0350: BE8A007E
	.long 0xd71f0001                                           // 0000009F0354: D71F0001
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                    // 0000009F0358: 0201000B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F035C: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000009F0360: 7D940280
	s_cbranch_execz 11                                         // 0000009F0364: BFA5000B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2a94>
	s_ashr_i32 s3, s2, 31                                      // 0000009F0368: 86039F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009F036C: BF870499
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000009F0370: 84948202
	s_add_u32 s20, s6, s20                                     // 0000009F0374: 80141406
	s_addc_u32 s21, s7, s21                                    // 0000009F0378: 82151507
	s_bcnt1_i32_b32 s3, s11                                    // 0000009F037C: BE83180B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009F0380: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s3              // 0000009F0384: CA100080 02020003
	global_atomic_add_u32 v2, v2, v3, s[20:21] glc             // 0000009F038C: DCD64000 02140302
	s_or_b32 exec_lo, exec_lo, s10                             // 0000009F0394: 8C7E0A7E
	s_waitcnt vmcnt(0)                                         // 0000009F0398: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 0000009F039C: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F03A0: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 0000009F03A4: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 9, v1                             // 0000009F03AC: 7C940289
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000009F03B0: D5010001 01A90280
	ds_store_b32 v2, v1 offset:7680                            // 0000009F03B8: D8341E00 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009F03C0: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000009F03C4: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000009F03C8: BF89FC07
	s_barrier                                                  // 0000009F03CC: BFBD0000
	buffer_gl0_inv                                             // 0000009F03D0: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:7680                             // 0000009F03D8: D8D81E00 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009F03E0: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009F03E4: 7C940280
	s_cbranch_vccnz 287                                        // 0000009F03E8: BFA4011F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f68>
	s_mov_b32 s1, exec_lo                                      // 0000009F03EC: BE81007E
	buffer_gl1_inv                                             // 0000009F03F0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009F03F8: E0AC0000 00000000
	v_cmpx_gt_u32_e32 64, v0                                   // 0000009F0400: 7D9800C0
	s_cbranch_execz 269                                        // 0000009F0404: BFA5010D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f3c>
	v_lshlrev_b32_e32 v0, 1, v0                                // 0000009F0408: 30000081
	s_mul_i32 s10, s8, 10                                      // 0000009F040C: 960A8A08
	v_mov_b32_e32 v6, 0                                        // 0000009F0410: 7E0C0280
	s_ashr_i32 s11, s10, 31                                    // 0000009F0414: 860B9F0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F0418: BF870092
	v_lshl_or_b32 v0, s9, 7, v0                                // 0000009F041C: D6560000 04010E09
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000009F0424: 3402009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009F0428: BF870121
	.long 0xd73c0002                                           // 0000009F042C: D73C0002
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009F0430: 02020081
	v_mad_i64_i32 v[0:1], null, 0xa00, s8, v[0:1]              // 0000009F0434: D6FF7C00 040010FF 00000A00
	.long 0xd7006a02                                           // 0000009F0440: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000009F0444: 0202040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009F0448: BF870191
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000009F044C: D5207C03 01AA060D
	.long 0xd73c0000                                           // 0000009F0454: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009F0458: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009F045C: BF8704A2
	v_mad_i64_i32 v[2:3], null, 0x1400, s10, v[2:3]            // 0000009F0460: D6FF7C02 040814FF 00001400
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000009F046C: 848A820A
	s_add_u32 s10, s14, s10                                    // 0000009F0470: 800A0A0E
	s_addc_u32 s11, s15, s11                                   // 0000009F0474: 820B0B0F
	s_ashr_i32 s9, s8, 31                                      // 0000009F0478: 86099F08
	global_load_b32 v7, v6, s[10:11]                           // 0000009F047C: DC520000 070A0006
	global_load_b32 v4, v[2:3], off glc                        // 0000009F0484: DC524000 047C0002
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000009F048C: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009F0490: BF870009
	s_add_u32 s8, s18, s8                                      // 0000009F0494: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000009F0498: 82090913
	s_waitcnt vmcnt(0)                                         // 0000009F049C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v4                               // 0000009F04A0: 30100890
	v_and_b32_e32 v9, 0xffff0000, v4                           // 0000009F04A4: 361208FF FFFF0000
	.long 0xd7006a04                                           // 0000009F04AC: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000009F04B0: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F04B8: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F04BC: D5207C05 01AA0680
	v_mul_f32_e32 v8, v7, v8                                   // 0000009F04C4: 10101107
	v_mul_f32_e32 v7, v7, v9                                   // 0000009F04C8: 100E1307
	global_load_b32 v9, v6, s[10:11] offset:4                  // 0000009F04CC: DC520004 090A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009F04D4: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F04DC: BF8903F7
	v_dual_add_f32 v7, 0, v7 :: v_dual_lshlrev_b32 v10, 16, v4 // 0000009F04E0: C9220E80 070A0890
	v_mul_f32_e32 v10, v9, v10                                 // 0000009F04E8: 10141509
	v_and_b32_e32 v11, 0xffff0000, v4                          // 0000009F04EC: 361608FF FFFF0000
	.long 0xd7006a04                                           // 0000009F04F4: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000009F04F8: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0500: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0504: D5207C05 01AA0680
	v_mul_f32_e32 v9, v9, v11                                  // 0000009F050C: 10121709
	global_load_b32 v11, v6, s[10:11] offset:8                 // 0000009F0510: DC520008 0B0A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009F0518: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F0520: BF8903F7
	v_dual_add_f32 v7, v7, v9 :: v_dual_lshlrev_b32 v12, 16, v4// 0000009F0524: C9221307 070C0890
	v_and_b32_e32 v13, 0xffff0000, v4                          // 0000009F052C: 361A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009F0534: D7006A04
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000009F0538: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0540: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0544: D5207C05 01AA0680
	v_mul_f32_e32 v12, v11, v12                                // 0000009F054C: 1018190B
	v_mul_f32_e32 v11, v11, v13                                // 0000009F0550: 10161B0B
	global_load_b32 v13, v6, s[10:11] offset:12                // 0000009F0554: DC52000C 0D0A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009F055C: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F0564: BF8903F7
	v_dual_add_f32 v7, v7, v11 :: v_dual_lshlrev_b32 v14, 16, v4// 0000009F0568: C9221707 070E0890
	v_and_b32_e32 v15, 0xffff0000, v4                          // 0000009F0570: 361E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009F0578: D7006A04
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 0000009F057C: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0584: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0588: D5207C05 01AA0680
	v_mul_f32_e32 v14, v13, v14                                // 0000009F0590: 101C1D0D
	v_mul_f32_e32 v13, v13, v15                                // 0000009F0594: 101A1F0D
	global_load_b32 v15, v6, s[10:11] offset:16                // 0000009F0598: DC520010 0F0A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009F05A0: DC524000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F05A8: BF8903F7
	v_dual_add_f32 v7, v7, v13 :: v_dual_lshlrev_b32 v16, 16, v4// 0000009F05AC: C9221B07 07100890
	v_and_b32_e32 v17, 0xffff0000, v4                          // 0000009F05B4: 362208FF FFFF0000
	.long 0xd7006a04                                           // 0000009F05BC: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000009F05C0: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F05C8: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F05CC: D5207C05 01AA0680
	v_mul_f32_e32 v16, v15, v16                                // 0000009F05D4: 1020210F
	v_mul_f32_e32 v15, v15, v17                                // 0000009F05D8: 101E230F
	global_load_b32 v17, v6, s[10:11] offset:20                // 0000009F05DC: DC520014 110A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009F05E4: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F05EC: BF8903F7
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v18, 16, v4// 0000009F05F0: C9221F07 07120890
	v_and_b32_e32 v19, 0xffff0000, v4                          // 0000009F05F8: 362608FF FFFF0000
	.long 0xd7006a04                                           // 0000009F0600: D7006A04
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000009F0604: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F060C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0610: D5207C05 01AA0680
	v_mul_f32_e32 v18, v17, v18                                // 0000009F0618: 10242511
	v_mul_f32_e32 v17, v17, v19                                // 0000009F061C: 10222711
	global_load_b32 v19, v6, s[10:11] offset:24                // 0000009F0620: DC520018 130A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009F0628: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F0630: BF8903F7
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 16, v4// 0000009F0634: C9222307 07140890
	v_and_b32_e32 v21, 0xffff0000, v4                          // 0000009F063C: 362A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009F0644: D7006A04
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 0000009F0648: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0650: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0654: D5207C05 01AA0680
	v_mul_f32_e32 v20, v19, v20                                // 0000009F065C: 10282913
	v_mul_f32_e32 v19, v19, v21                                // 0000009F0660: 10262B13
	global_load_b32 v21, v6, s[10:11] offset:28                // 0000009F0664: DC52001C 150A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009F066C: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009F0674: BF8903F7
	v_dual_add_f32 v7, v7, v19 :: v_dual_lshlrev_b32 v22, 16, v4// 0000009F0678: C9222707 07160890
	v_and_b32_e32 v23, 0xffff0000, v4                          // 0000009F0680: 362E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009F0688: D7006A04
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 0000009F068C: 020204FF 0000A000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0694: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009F0698: D5207C05 01AA0680
	v_mul_f32_e32 v22, v21, v22                                // 0000009F06A0: 102C2D15
	v_mul_f32_e32 v21, v21, v23                                // 0000009F06A4: 102A2F15
	global_load_b32 v23, v6, s[10:11] offset:32                // 0000009F06A8: DC520020 170A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009F06B0: DC524000 047C0004
	.long 0xd7006a02                                           // 0000009F06B8: D7006A02
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000009F06BC: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F06C4: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000009F06C8: D5207C03 01AA0680
	v_add_f32_e32 v7, v7, v21                                  // 0000009F06D0: 060E2B07
	s_waitcnt vmcnt(0)                                         // 0000009F06D4: BF8903F7
	v_lshlrev_b32_e32 v5, 16, v4                               // 0000009F06D8: 300A0890
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009F06DC: 360808FF FFFF0000
	v_mul_f32_e32 v5, v23, v5                                  // 0000009F06E4: 100A0B17
	v_mul_f32_e32 v4, v23, v4                                  // 0000009F06E8: 10080917
	global_load_b32 v23, v6, s[10:11] offset:36                // 0000009F06EC: DC520024 170A0006
	global_load_b32 v2, v[2:3], off offset:1024 glc            // 0000009F06F4: DC524400 027C0002
	v_add_f32_e32 v4, v7, v4                                   // 0000009F06FC: 06080907
	s_waitcnt vmcnt(0)                                         // 0000009F0700: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v2                              // 0000009F0704: 30300490
	v_and_b32_e32 v25, 0xffff0000, v2                          // 0000009F0708: 363204FF FFFF0000
	.long 0xd7006a02                                           // 0000009F0710: D7006A02
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000009F0714: 02020010
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009F0718: BF870001
	v_add_co_ci_u32_e64 v3, null, s17, v1, vcc_lo              // 0000009F071C: D5207C03 01AA0211
	v_mul_f32_e32 v24, v23, v24                                // 0000009F0724: 10303117
	v_mul_f32_e32 v23, v23, v25                                // 0000009F0728: 102E3317
	v_add_f32_e32 v4, v4, v23                                  // 0000009F072C: 06082F04
	global_load_b32 v2, v[2:3], off                            // 0000009F0730: DC520000 027C0002
	global_load_b32 v3, v6, s[8:9]                             // 0000009F0738: DC520000 03080006
	v_add_f32_e32 v6, 0, v8                                    // 0000009F0740: 060C1080
	.long 0xd7006a00                                           // 0000009F0744: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000009F0748: 02020004
	v_bfe_u32 v7, v4, 16, 1                                    // 0000009F074C: D6100007 02052104
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000009F0754: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009F075C: BF870194
	v_add_f32_e32 v6, v6, v10                                  // 0000009F0760: 060C1506
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000009F0764: D6550004 03FE0F04 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009F0770: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000009F0774: 060C1906
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009F0778: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F0780: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 0000009F0784: 060C1D06
	v_add_f32_e32 v6, v6, v16                                  // 0000009F0788: 060C2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F078C: BF870091
	v_add_f32_e32 v6, v6, v18                                  // 0000009F0790: 060C2506
	v_add_f32_e32 v6, v6, v20                                  // 0000009F0794: 060C2906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F0798: BF870091
	v_add_f32_e32 v6, v6, v22                                  // 0000009F079C: 060C2D06
	v_add_f32_e32 v5, v6, v5                                   // 0000009F07A0: 060A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F07A4: BF870091
	v_add_f32_e32 v5, v5, v24                                  // 0000009F07A8: 060A3105
	v_bfe_u32 v6, v5, 16, 1                                    // 0000009F07AC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F07B4: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000009F07B8: D6550005 03FE0D05 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000009F07C4: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000009F07CC: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v2                               // 0000009F07D0: 300C0490
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000009F07D4: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000009F07DC: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009F07E0: BF870112
	v_fmac_f32_e32 v5, v3, v6                                  // 0000009F07E4: 560A0D03
	v_fmac_f32_e32 v4, v3, v2                                  // 0000009F07E8: 56080503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009F07EC: BF870112
	v_bfe_u32 v2, v5, 16, 1                                    // 0000009F07F0: D6100002 02052105
	v_bfe_u32 v3, v4, 16, 1                                    // 0000009F07F8: D6100003 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009F0800: BF8701A2
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000009F0804: D6550002 03FE0505 00007FFF
	.long 0x7f0a3880                                           // 0000009F0810: 7F0A3880
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000009F0814: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009F0820: BF870093
	.long 0x7e0a3982                                           // 0000009F0824: 7E0A3982
	v_and_or_b32 v2, 0xffff0000, v3, v5                        // 0000009F0828: D6570002 041606FF FFFF0000
	global_store_b32 v[0:1], v2, off                           // 0000009F0834: DC6A0000 007C0200
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009F083C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000009F0840: BE812000
	s_cbranch_execz 8                                          // 0000009F0844: BFA50008 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi3ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f68>
	s_ashr_i32 s3, s2, 31                                      // 0000009F0848: 86039F02
	v_mov_b32_e32 v0, 0                                        // 0000009F084C: 7E000280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000009F0850: 84808202
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009F0854: BF870009
	s_add_u32 s0, s6, s0                                       // 0000009F0858: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000009F085C: 82010107
	global_store_b32 v0, v0, s[0:1]                            // 0000009F0860: DC6A0000 00000000
	s_endpgm                                                   // 0000009F0868: BFB00000
		...

