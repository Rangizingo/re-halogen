000000000041be00 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 00000041BE00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 00000041BE04: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000041BE0C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 00000041BE14: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 00000041BE18: BF108004
	s_cbranch_scc1 244                                         // 00000041BE1C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 00000041BE20: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 00000041BE28: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000041BE2C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 00000041BE30: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000041BE34: BF030602
	s_cbranch_scc0 233                                         // 00000041BE38: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000041BE3C: 32020085
	s_sub_i32 s6, s2, s6                                       // 00000041BE40: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000041BE44: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 00000041BE48: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 00000041BE50: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000041BE54: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 00000041BE58: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000041BE5C: BE86206A
	s_cbranch_execz 222                                        // 00000041BE60: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 00000041BE64: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 00000041BE68: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 00000041BE70: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 00000041BE74: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000041BE7C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041BE84: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000041BE88: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000041BE8C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 00000041BE90: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041BE94: BF870121
	.long 0xd72c0002                                           // 00000041BE98: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000041BE9C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 00000041BEA4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 00000041BEB0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BEB8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 00000041BEBC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000041BEC4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041BEC8: BF870091
	.long 0xd73c0002                                           // 00000041BECC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000041BED0: 02020481
	.long 0xd7006a04                                           // 00000041BED4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000041BED8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000041BEDC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000041BEE0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 00000041BEE8: BF89FC07
	.long 0xd7006a02                                           // 00000041BEEC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000041BEF0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000041BEF4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 00000041BEFC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 00000041BF04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000041BF0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 00000041BF14: BF8907F7
	.long 0x7e043904                                           // 00000041BF18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000041BF1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 00000041BF24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000041BF28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041BF30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 00000041BF34: 301C0490
	s_waitcnt vmcnt(0)                                         // 00000041BF38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041BF3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000041BF44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041BF48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000041BF50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041BF54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 00000041BF58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 00000041BF60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 00000041BF68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 00000041BF70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 00000041BF78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000041BF7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 00000041BF80: 361A0088
	.long 0xd73c0001                                           // 00000041BF84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000041BF88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000041BF8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 00000041BF90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000041BF94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041BF98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041BF9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041BFA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041BFAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000041BFB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 00000041BFB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 00000041BFBC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 00000041BFC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 00000041BFCC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000041BFD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041BFD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041BFE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000041BFE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041BFEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000041BFF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000041BFFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 00000041C000: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 00000041C008: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041C00C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 00000041C010: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C014: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041C01C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C024: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041C02C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C034: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041C03C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 00000041C044: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C048: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041C050: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000041C058: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000041C05C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C060: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 00000041C068: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000041C06C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C070: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C078: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000041C080: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000041C084: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041C088: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041C090: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041C098: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 00000041C0A0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 00000041C0A4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 00000041C0A8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C0AC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041C0B4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000041C0BC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 00000041C0C0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C0C4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C0CC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 00000041C0D4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041C0D8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C0E0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041C0E8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041C0F0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C0F8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041C100: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000041C108: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000041C10C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 00000041C110: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C114: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 00000041C118: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 00000041C120: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041C124: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C12C: BF870214
	v_mov_b32_e32 v13, v5                                      // 00000041C130: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 00000041C134: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 00000041C138: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 00000041C140: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041C14C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000041C154: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000041C15C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 00000041C168: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 00000041C174: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 00000041C180: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000041C184: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000041C188: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000041C18C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 00000041C194: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000041C19C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 00000041C1A0: 060A1B05
	.long 0xd7006a01                                           // 00000041C1A4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000041C1A8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000041C1AC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 00000041C1B4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 00000041C1BC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 00000041C1C4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 00000041C1CC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 00000041C1D4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 00000041C1DC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C1E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000041C1E4: 8B6A037E
	s_cbranch_vccnz 2                                          // 00000041C1E8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 00000041C1EC: BFB00000
	s_cbranch_execz 65534                                      // 00000041C1F0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 00000041C1F4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000041C1F8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 00000041C200: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 00000041C208: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 00000041C210: F4000180 F800010C
	v_lshrrev_b32_e32 v7, 5, v0                                // 00000041C218: 320E0085
	v_and_b32_e32 v8, 31, v0                                   // 00000041C21C: 3610009F
	s_mov_b32 s33, 0                                           // 00000041C220: BEA10080
	s_waitcnt lgkmcnt(0)                                       // 00000041C224: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000041C228: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000041C22C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000041C230: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000041C234: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C238: BF870009
	s_and_b32 s4, s7, s4                                       // 00000041C23C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000041C240: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000041C244: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000041C24C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000041C250: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000041C254: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C258: BF870009
	s_and_b32 s4, s7, s5                                       // 00000041C25C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000041C260: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000041C264: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000041C268: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000041C26C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000041C270: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000041C274: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000041C278: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000041C27C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000041C280: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000041C284: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000041C288: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000041C28C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C290: BF870009
	s_add_u32 s4, s0, s3                                       // 00000041C294: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000041C298: 82058001
	s_clause 0x3                                               // 00000041C29C: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 00000041C2A0: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 00000041C2A8: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 00000041C2B0: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 00000041C2B8: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 00000041C2C0: BF89FC07
	s_abs_i32 s3, s21                                          // 00000041C2C4: BE831515
	s_sub_i32 s2, s2, s23                                      // 00000041C2C8: 81821702
	s_cvt_f32_u32 s6, s3                                       // 00000041C2CC: BE866503
	s_sub_i32 s7, 0, s3                                        // 00000041C2D0: 81870380
	s_abs_i32 s8, s2                                           // 00000041C2D4: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000041C2D8: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 00000041C2DC: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 00000041C2E0: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 00000041C2E4: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000041C2EC: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 00000041C2F0: BE866706
	s_mul_i32 s7, s7, s6                                       // 00000041C2F4: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000041C2F8: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 00000041C2FC: 96870706
	s_add_i32 s6, s6, s7                                       // 00000041C300: 81060706
	s_xor_b32 s7, s2, s21                                      // 00000041C304: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 00000041C308: 96860608
	s_ashr_i32 s7, s7, 31                                      // 00000041C30C: 86079F07
	s_mul_i32 s9, s6, s3                                       // 00000041C310: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C314: BF870009
	s_sub_i32 s8, s8, s9                                       // 00000041C318: 81880908
	s_add_i32 s9, s6, 1                                        // 00000041C31C: 81098106
	s_sub_i32 s10, s8, s3                                      // 00000041C320: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 00000041C324: BF090308
	s_cselect_b32 s6, s9, s6                                   // 00000041C328: 98060609
	s_cselect_b32 s8, s10, s8                                  // 00000041C32C: 9808080A
	s_add_i32 s9, s6, 1                                        // 00000041C330: 81098106
	s_cmp_ge_u32 s8, s3                                        // 00000041C334: BF090308
	s_cselect_b32 s3, s9, s6                                   // 00000041C338: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 00000041C33C: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 00000041C344: 8D030703
	s_ashr_i32 s27, s19, 31                                    // 00000041C348: 861B9F13
	s_sub_i32 s26, s3, s7                                      // 00000041C34C: 819A0703
	s_lshr_b32 s4, s27, 25                                     // 00000041C350: 8504991B
	s_mul_i32 s3, s26, s21                                     // 00000041C354: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041C358: BF870009
	s_sub_i32 s23, s2, s3                                      // 00000041C35C: 81970302
	s_add_i32 s2, s19, s4                                      // 00000041C360: 81020413
	s_mul_i32 s29, s22, s23                                    // 00000041C364: 961D1716
	s_ashr_i32 s2, s2, 7                                       // 00000041C368: 86028702
	s_add_i32 s3, s29, s22                                     // 00000041C36C: 8103161D
	s_mov_b32 s22, exec_lo                                     // 00000041C370: BE96007E
	s_min_i32 s2, s2, s3                                       // 00000041C374: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000041C378: BF870499
	s_sub_i32 s7, s2, s29                                      // 00000041C37C: 81871D02
	.long 0xd4c4007e                                           // 00000041C380: D4C4007E
	v_cndmask_b32_e32 v1, s7, v7, vcc_lo                       // 00000041C384: 02020E07
	s_cbranch_execz 289                                        // 00000041C388: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa10>
	s_abs_i32 s34, s7                                          // 00000041C38C: BEA21507
	v_lshlrev_b32_e32 v9, 3, v8                                // 00000041C390: 30121083
	s_cvt_f32_u32 s2, s34                                      // 00000041C394: BE826522
	v_lshlrev_b32_e32 v10, 7, v7                               // 00000041C398: 30140E87
	v_and_b32_e32 v3, 2, v0                                    // 00000041C39C: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 00000041C3A0: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 00000041C3A4: 7E025602
	s_sub_i32 s2, 0, s34                                       // 00000041C3A8: 81822280
	s_ashr_i32 s37, s7, 31                                     // 00000041C3AC: 86259F07
	.long 0xd44a0003                                           // 00000041C3B0: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000041C3B4: 02020680
	s_mul_i32 s39, s37, 0x1400                                 // 00000041C3B8: 9627FF25 00001400
	.long 0xd44a0005                                           // 00000041C3C0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000041C3C4: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 00000041C3C8: 84068707
	s_add_i32 s35, s18, -1                                     // 00000041C3CC: 8123C112
	s_mov_b32 s36, s19                                         // 00000041C3D0: BEA40013
	s_lshl_b32 s38, s7, 8                                      // 00000041C3D4: 84268807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 00000041C3D8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s40, 0x76543210                                  // 00000041C3E4: BEA800FF 76543210
	s_mov_b32 s41, 0x3db504f3                                  // 00000041C3EC: BEA900FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 00000041C3F4: 7C981090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041C3F8: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 00000041C3FC: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 00000041C400: 36020084
	.long 0xd72c0006                                           // 00000041C404: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 00000041C408: 02020802
	.long 0xd44a0002                                           // 00000041C40C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000041C410: 02020480
	v_lshl_or_b32 v2, v7, 8, v9                                // 00000041C414: D6560002 04251107
	v_lshl_add_u32 v9, s29, 7, v10                             // 00000041C41C: D6460009 04290E1D
	.long 0xd44a0004                                           // 00000041C424: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000041C428: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041C42C: BF870223
	v_subrev_nc_u32_e32 v2, s39, v2                            // 00000041C430: 4E040427
	.long 0xd72d0006                                           // 00000041C434: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000041C438: 02020D04
	v_lshl_or_b32 v1, v8, 2, v9                                // 00000041C43C: D6560001 04250508
	s_sub_i32 s39, 0, s6                                       // 00000041C444: 81A70680
	s_delay_alu instid0(VALU_DEP_2)                            // 00000041C448: BF870002
	v_dual_mov_b32 v4, v7 :: v_dual_add_nc_u32 v3, v4, v6      // 00000041C44C: CA200107 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C454: BF870091
	.long 0xd72d0005                                           // 00000041C458: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 00000041C45C: 02020704
	.long 0xd72c0006                                           // 00000041C460: D72C0006
	v_cndmask_b32_e32 v0, v5, v34, vcc_lo                      // 00000041C464: 02004505
	v_add_nc_u32_e32 v9, 1, v5                                 // 00000041C468: 4A120A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C46C: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 00000041C470: 4C0C0D04
	v_subrev_nc_u32_e32 v10, s34, v6                           // 00000041C474: 4E140C22
	.long 0xd44b0006                                           // 00000041C478: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 00000041C47C: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041C480: BF870191
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 00000041C484: D5010005 001A1305
	v_cndmask_b32_e64 v6, v6, v10, s6                          // 00000041C48C: D5010006 001A1506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041C494: BF870112
	v_add_nc_u32_e32 v9, 1, v5                                 // 00000041C498: 4A120A81
	.long 0xd44b0006                                           // 00000041C49C: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 00000041C4A0: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C4A4: BF870091
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 00000041C4A8: D5010005 001A1305
	v_xor_b32_e32 v11, s37, v5                                 // 00000041C4B0: 3A160A25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041C4B4: BF870121
	v_subrev_nc_u32_e32 v12, s37, v11                          // 00000041C4B8: 4E181625
	.long 0xd72c000b                                           // 00000041C4BC: D72C000B
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 00000041C4C0: 020216FF 00001400
	v_min_i32_e32 v9, s35, v12                                 // 00000041C4C8: 22121823
	v_mad_u64_u32 v[5:6], null, s39, v12, v[1:2]               // 00000041C4CC: D6FE7C05 04061827
	.long 0xd72c000c                                           // 00000041C4D4: D72C000C
	v_cndmask_b32_e32 v1, s38, v12, vcc_lo                     // 00000041C4D8: 02021826
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041C4DC: BF870193
	v_mad_i64_i32 v[9:10], null, v9, s36, 0                    // 00000041C4E0: D6FF7C09 02004909
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000041C4E8: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041C4EC: BF870193
	v_sub_nc_u32_e32 v11, v11, v12                             // 00000041C4F0: 4C16190B
	.long 0xd73c0009                                           // 00000041C4F4: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000041C4F8: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041C4FC: BF870193
	.long 0xd73c0005                                           // 00000041C500: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000041C504: 02020A81
	v_add_nc_u32_e32 v11, v2, v11                              // 00000041C508: 4A161702
	v_add_nc_u32_e32 v2, 0x800, v2                             // 00000041C50C: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C514: BF870094
	.long 0xd700060d                                           // 00000041C518: D700060D
	v_cndmask_b32_e32 v1, s16, v9, vcc_lo                      // 00000041C51C: 02021210
	v_add_co_ci_u32_e64 v14, null, s17, v10, s6                // 00000041C520: D5207C0E 001A1411
	s_waitcnt lgkmcnt(0)                                       // 00000041C528: BF89FC07
	.long 0xd7000609                                           // 00000041C52C: D7000609
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000041C530: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041C534: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s11, v6, s6                 // 00000041C538: D5207C0A 001A0C0B
	.long 0xd7000605                                           // 00000041C540: D7000605
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 00000041C544: 02020B0D
	v_add_co_ci_u32_e64 v6, null, v14, v6, s6                  // 00000041C548: D5207C06 001A0D0E
	global_load_b64 v[5:6], v[5:6], off                        // 00000041C550: DC560000 057C0005
	global_load_b64 v[9:10], v[9:10], off                      // 00000041C558: DC560000 097C0009
	s_waitcnt vmcnt(1)                                         // 00000041C560: BF8907F7
	.long 0x7e1a3905                                           // 00000041C564: 7E1A3905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000041C568: 360A0AFF FFFF0000
	.long 0x7e1c3906                                           // 00000041C570: 7E1C3906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041C574: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 00000041C578: 301A1A90
	s_waitcnt vmcnt(0)                                         // 00000041C57C: BF8903F7
	v_fma_mix_f32 v5, v9, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041C580: CC200805 8A020B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041C588: BF870113
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000041C58C: 301C1C90
	v_fma_mix_f32 v16, v9, v13, v5 op_sel_hi:[1,0,0]           // 00000041C590: CC200010 0C161B09
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000041C598: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v9, v13, -v5 op_sel_hi:[1,0,0]           // 00000041C5A0: CC200005 8C161B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C5A8: BF870092
	v_fma_mix_f32 v6, v10, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041C5AC: CC200806 8A020D0A
	v_fma_mix_f32 v15, v10, v14, v6 op_sel_hi:[1,0,0]          // 00000041C5B4: CC20000F 0C1A1D0A
	v_fma_mix_f32 v6, v10, v14, -v6 op_sel_hi:[1,0,0]          // 00000041C5BC: CC200006 8C1A1D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041C5C4: BF870112
	v_dual_add_f32 v9, v16, v15 :: v_dual_add_nc_u32 v4, 8, v4 // 00000041C5C8: C9201F10 09040888
	v_dual_add_f32 v10, v6, v5 :: v_dual_sub_f32 v5, v5, v6    // 00000041C5D0: C90A0B06 0A040D05
	v_sub_f32_e32 v13, v16, v15                                // 00000041C5D8: 081A1F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C5DC: BF870213
	.long 0xd4430006                                           // 00000041C5E0: D4430006
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 00000041C5E4: 02020807
	v_mov_b32_dpp v6, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041C5E8: 7E0C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 00000041C5F0: D5010009 200A1309
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041C5F8: 7E2002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000041C600: D5010005 200A0B05
	v_mov_b32_dpp v15, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041C608: 7E1E02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 00000041C610: D501000D 200A1B0D
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_nc_u32 v1, 0x400, v1// 00000041C618: C9200D09 060002FF 00000400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000041C624: BF8701C4
	v_add_f32_e32 v5, v5, v16                                  // 00000041C628: 060A2105
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041C62C: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 00000041C634: D501000A 200A150A
	s_or_b32 s33, s6, s33                                      // 00000041C63C: 8C212106
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C640: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000041C648: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C650: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 00000041C654: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C658: 7E2002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000041C660: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C668: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 00000041C66C: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C670: 7E2002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000041C678: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041C680: BF870241
	v_add_f32_e32 v5, v5, v16                                  // 00000041C684: 060A2105
	v_dual_add_f32 v9, v10, v14 :: v_dual_add_f32 v10, v13, v15// 00000041C688: C9081D0A 090A1F0D
	v_mov_b32_dpp v13, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C690: 7E1A02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000041C698: D5010006 200E0D06
	v_mov_b32_e32 v16, v5                                      // 00000041C6A0: 7E200305
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041C6A4: BF870004
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C6A8: 7E1C02FA FF016209
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041C6B0: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 00000041C6B8: D501000A 200E150A
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 00000041C6C0: D5010009 200E1309
	v_add_f32_e32 v6, v6, v13                                  // 00000041C6C8: 060C1B06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041C6CC: D5010005 21AA0B05
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 00000041C6D4: D65C0010 03FC5110 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C6E0: BF870214
	v_dual_add_f32 v10, v10, v15 :: v_dual_add_f32 v9, v9, v14 // 00000041C6E4: C9081F0A 0A081D09
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C6EC: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 00000041C6F4: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C6FC: BF870214
	v_add_f32_e32 v12, v5, v16                                 // 00000041C700: 06182105
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C704: 7E1E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 00000041C70C: D501000A 2012150A
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041C714: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 00000041C71C: D5010009 20121309
	v_add_f32_e32 v6, v6, v13                                  // 00000041C724: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041C728: BF870114
	v_add_f32_e32 v10, v10, v15                                // 00000041C72C: 06141F0A
	v_mov_b32_dpp v13, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C730: 7E1A02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 00000041C738: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041C740: BF8701A3
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C744: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 00000041C74C: D501000A 2016150A
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v6, v6, v13   // 00000041C754: C9081D09 09061B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041C75C: BF870112
	v_add_f32_e32 v10, v10, v15                                // 00000041C760: 06141F0A
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041C764: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 00000041C76C: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041C774: BF870123
	v_mov_b32_e32 v15, v10                                     // 00000041C778: 7E1E030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041C77C: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 00000041C784: D65C000F 03FC510F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C790: BF870091
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v15 // 00000041C794: C9081D09 090A1F0A
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v14, v9           // 00000041C79C: CA100106 0D0E0109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000041C7A4: D5010009 21AA1309
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000041C7AC: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041C7B4: BF870213
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 00000041C7B8: D65C000D 03FC510D FEDCBA98
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000041C7C4: D65C000E 03FC510E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C7D0: BF870091
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v9, v9, v14   // 00000041C7D4: C9081B06 06081D09
	v_fma_mixlo_f16 v5, v6, s41, 0                             // 00000041C7DC: CC210005 02005306
	s_delay_alu instid0(VALU_DEP_2)                            // 00000041C7E4: BF870002
	v_fma_mixhi_f16 v5, v9, s41, 0                             // 00000041C7E8: CC220005 02005309
	v_fma_mixhi_f16 v6, v12, s41, 0                            // 00000041C7F0: CC220006 0200530C
	v_fma_mixlo_f16 v6, v10, s41, 0                            // 00000041C7F8: CC210006 0200530A
	ds_store_b64 v11, v[5:6]                                   // 00000041C800: D9340000 0000050B
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 00000041C808: 917E217E
	s_cbranch_execnz 65297                                     // 00000041C80C: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x654>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000041C810: 8C7E167E
	s_bfe_i32 s6, s7, 0x1001c                                  // 00000041C814: 9386FF07 0001001C
	s_lshr_b32 s5, s27, 28                                     // 00000041C81C: 85059C1B
	s_lshr_b64 s[2:3], s[6:7], 29                              // 00000041C820: 85829D06
	s_lshl_b32 s4, s7, 3                                       // 00000041C824: 84048307
	s_add_i32 s2, s2, 7                                        // 00000041C828: 81028702
	s_lshl_b32 s3, s29, 3                                      // 00000041C82C: 8403831D
	s_ashr_i32 s2, s2, 3                                       // 00000041C830: 86028302
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v9, 2, v8      // 00000041C834: CA220080 0C081082
	.long 0xd72c0001                                           // 00000041C83C: D72C0001
	v_cndmask_b32_e32 v1, s2, v7, vcc_lo                       // 00000041C840: 02020E02
	v_mov_b32_e32 v15, 0                                       // 00000041C844: 7E1E0280
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v14, 0             // 00000041C848: CA100080 0B0E0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v16, 0             // 00000041C850: CA100080 0D100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 00000041C858: CA100080 12120080
	v_add_nc_u32_e32 v2, s2, v1                                // 00000041C860: 4A040202
	s_add_i32 s2, s19, s5                                      // 00000041C864: 81020513
	s_ashr_i32 s5, s3, 31                                      // 00000041C868: 86059F03
	s_ashr_i32 s2, s2, 4                                       // 00000041C86C: 86028402
	v_mov_b32_e32 v20, 0                                       // 00000041C870: 7E280280
	v_min_i32_e32 v10, s4, v2                                  // 00000041C874: 22140404
	s_mul_i32 s4, s26, s2                                      // 00000041C878: 9604021A
	s_mul_hi_i32 s6, s26, s2                                   // 00000041C87C: 9706021A
	s_add_u32 s2, s4, s3                                       // 00000041C880: 80020304
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000041C884: 3404029F
	v_cmp_lt_i32_e32 vcc_lo, v1, v10                           // 00000041C888: 7C821501
	s_addc_u32 s3, s6, s5                                      // 00000041C88C: 82030506
	s_waitcnt lgkmcnt(0)                                       // 00000041C890: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000041C894: BC7C0000
	s_lshl_b64 s[4:5], s[2:3], 10                              // 00000041C898: 84848A02
	s_barrier                                                  // 00000041C89C: BFBD0000
	buffer_gl0_inv                                             // 00000041C8A0: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 00000041C8A8: BE83206A
	s_cbranch_execz 31                                         // 00000041C8AC: BFA5001F <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xb2c>
	.long 0xd73c0003                                           // 00000041C8B0: D73C0003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000041C8B4: 0202028A
	s_add_u32 s2, s8, s4                                       // 00000041C8B8: 80020408
	s_addc_u32 s6, s9, s5                                      // 00000041C8BC: 82060509
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C8C0: BF870091
	.long 0xd7000203                                           // 00000041C8C4: D7000203
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000041C8C8: 02020602
	v_add_co_ci_u32_e64 v4, null, s6, v4, s2                   // 00000041C8CC: D5207C04 000A0806
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C8D4: BF870092
	.long 0xd7000203                                           // 00000041C8D8: D7000203
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000041C8DC: 02021303
	v_add_co_ci_u32_e64 v4, null, 0, v4, s2                    // 00000041C8E0: D5207C04 000A0880
	s_clause 0x7                                               // 00000041C8E8: BF850007
	global_load_b32 v11, v[3:4], off                           // 00000041C8EC: DC520000 0B7C0003
	global_load_b32 v13, v[3:4], off offset:128                // 00000041C8F4: DC520080 0D7C0003
	global_load_b32 v14, v[3:4], off offset:256                // 00000041C8FC: DC520100 0E7C0003
	global_load_b32 v15, v[3:4], off offset:384                // 00000041C904: DC520180 0F7C0003
	global_load_b32 v16, v[3:4], off offset:512                // 00000041C90C: DC520200 107C0003
	global_load_b32 v18, v[3:4], off offset:640                // 00000041C914: DC520280 127C0003
	global_load_b32 v19, v[3:4], off offset:768                // 00000041C91C: DC520300 137C0003
	global_load_b32 v20, v[3:4], off offset:896                // 00000041C924: DC520380 147C0003
	s_or_b32 exec_lo, exec_lo, s3                              // 00000041C92C: 8C7E037E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000041C930: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000041C938: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 00000041C940: CA100080 1A140080
	v_mov_b32_e32 v17, 0                                       // 00000041C948: 7E220280
	s_ashr_i32 s27, s26, 31                                    // 00000041C94C: 861B9F1A
	s_and_saveexec_b32 s3, vcc_lo                              // 00000041C950: BE83206A
	s_cbranch_execz 981                                        // 00000041C954: BFA503D5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1aac>
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v4, 5, v8      // 00000041C958: CA220080 11041085
	v_and_b32_e32 v22, 16, v0                                  // 00000041C960: 362C0090
	v_cmp_ne_u32_e32 vcc_lo, 0, v8                             // 00000041C964: 7C9A1080
	.long 0xd73c0002                                           // 00000041C968: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000041C96C: 0202028A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041C970: BF870244
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v5, 0x3f0, v4   // 00000041C974: CA200080 1A0408FF 000003F0
	v_mad_u32_u24 v12, 0x420, v7, v9                           // 00000041C980: D60B000C 04260EFF 00000420
	v_mul_u32_u24_e32 v6, 0x420, v7                            // 00000041C98C: 160C0EFF 00000420
	v_sub_nc_u32_e32 v27, 0, v10                               // 00000041C994: 4C361480
	v_lshrrev_b32_e32 v21, 5, v5                               // 00000041C998: 322A0A85
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 00000041C99C: CA240080 18040AFF 000007E0
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v30, 0x1400, v12// 00000041C9A8: CA200080 191E18FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041C9B4: BF870243
	v_subrev_nc_u32_e32 v23, 32, v21                           // 00000041C9B8: 4E2E2AA0
	v_dual_mov_b32 v21, 0 :: v_dual_add_nc_u32 v28, 1, v1      // 00000041C9BC: CA200080 151C0281
	v_lshl_or_b32 v29, v1, 5, v22                              // 00000041C9C4: D656001D 04590B01
	v_sub_nc_u32_e32 v4, v5, v4                                // 00000041C9CC: 4C080905
	v_cndmask_b32_e32 v1, 31, v23, vcc_lo                      // 00000041C9D0: 02022E9F
	.long 0xd7006a02                                           // 00000041C9D4: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000041C9D8: 02020404
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041C9DC: BF870191
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000041C9E0: D5207C03 01AA0605
	v_dual_mov_b32 v23, 0 :: v_dual_add_nc_u32 v12, 1, v1      // 00000041C9E8: CA200080 170C0281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041C9F0: BF870093
	.long 0xd7006a02                                           // 00000041C9F4: D7006A02
	v_cndmask_b32_e32 v1, v2, v9, vcc_lo                       // 00000041C9F8: 02021302
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000041C9FC: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CA04: BF870193
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v5, 31, v12        // 00000041CA08: CA240080 1604189F
	.long 0xd7006a02                                           // 00000041CA10: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000041CA14: 02020408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000041CA18: BF8700D1
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000041CA1C: D5207C03 01AA0609
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v31, 0xfffffc30, v4// 00000041CA24: CA200080 0C1E08FF FFFFFC30
	v_lshl_add_u32 v1, v1, 2, v6                               // 00000041CA30: D6460001 04190501
	v_lshl_add_u32 v4, v5, 2, v6                               // 00000041CA38: D6460004 04190505
	.long 0xd7006a05                                           // 00000041CA40: D7006A05
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 00000041CA44: 020204FF 00000400
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 00000041CA4C: D5207C06 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041CA54: BF870214
	v_add_nc_u32_e32 v32, 0x1400, v1                           // 00000041CA58: 4A4002FF 00001400
	v_add_nc_u32_e32 v33, 0x1400, v4                           // 00000041CA60: 4A4208FF 00001400
	s_mov_b32 s4, 0                                            // 00000041CA68: BE840080
	s_movk_i32 s5, 0x1eee                                      // 00000041CA6C: B0051EEE
	s_branch 875                                               // 00000041CA70: BFA0036B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1a20>
	s_or_b32 exec_lo, exec_lo, s2                              // 00000041CA74: 8C7E027E
	ds_load_2addr_b32 v[34:35], v33 offset1:32                 // 00000041CA78: D8DC2000 22000021
	ds_load_2addr_b32 v[40:41], v30 offset1:32                 // 00000041CA80: D8DC2000 2800001E
	ds_load_2addr_b32 v[38:39], v32 offset1:32                 // 00000041CA88: D8DC2000 26000020
	ds_load_b128 v[1:4], v29                                   // 00000041CA90: DBFC0000 0100001D
	v_add_nc_u32_e32 v28, 1, v28                               // 00000041CA98: 4A383881
	.long 0xd7000205                                           // 00000041CA9C: D7000205
	v_cndmask_b32_e32 v1, 0x400, v5, vcc_lo                    // 00000041CAA0: 02020AFF 00000400
	v_add_nc_u32_e32 v29, 32, v29                              // 00000041CAA8: 4A3A3AA0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 00000041CAAC: D5207C06 000A0C80
	s_waitcnt lgkmcnt(3)                                       // 00000041CAB4: BF89FC37
	v_mov_b32_e32 v37, v34                                     // 00000041CAB8: 7E4A0322
	s_waitcnt lgkmcnt(2)                                       // 00000041CABC: BF89FC27
	v_bfe_u32 v34, v40, 12, 16                                 // 00000041CAC0: D6100022 02411928
	v_bfe_u32 v42, v40, 8, 16                                  // 00000041CAC8: D610002A 02411128
	v_bfe_u32 v43, v40, 4, 16                                  // 00000041CAD0: D610002B 02410928
	v_and_b32_e32 v40, 0xffff, v40                             // 00000041CAD8: 365050FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000041CAE0: BF89FC17
	v_mov_b32_e32 v36, v39                                     // 00000041CAE4: 7E480327
	.long 0xd73d0025                                           // 00000041CAE8: D73D0025
	v_cndmask_b32_e32 v1, v31, v37, vcc_lo                     // 00000041CAEC: 02024B1F
	v_bfe_u32 v39, v41, 12, 16                                 // 00000041CAF0: D6100027 02411929
	v_bfe_u32 v44, v41, 8, 16                                  // 00000041CAF8: D610002C 02411129
	v_bfe_u32 v45, v41, 4, 16                                  // 00000041CB00: D610002D 02410929
	v_and_b32_e32 v41, 0xffff, v41                             // 00000041CB08: 365252FF 0000FFFF
	.long 0xd72c0026                                           // 00000041CB10: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041CB14: 020244FF 83DCD12D
	.long 0xd73d0022                                           // 00000041CB1C: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 00000041CB20: 0202471F
	v_bfe_u32 v35, v37, 12, 16                                 // 00000041CB24: D6100023 02411925
	.long 0xd72c0024                                           // 00000041CB2C: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041CB30: 02024EFF 83DCD12D
	v_bfe_u32 v39, v37, 8, 16                                  // 00000041CB38: D6100027 02411125
	.long 0xd72c0028                                           // 00000041CB40: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000041CB44: 020250FF 83DCD12D
	.long 0xd72c002b                                           // 00000041CB4C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041CB50: 020256FF 83DCD12D
	.long 0xd72c0023                                           // 00000041CB58: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000041CB5C: 020246FF 83DCD12D
	v_bfe_u32 v47, v34, 12, 16                                 // 00000041CB64: D610002F 02411922
	.long 0xd72c0027                                           // 00000041CB6C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041CB70: 02024EFF 83DCD12D
	v_bfe_u32 v48, v34, 8, 16                                  // 00000041CB78: D6100030 02411122
	v_bfe_u32 v49, v34, 4, 16                                  // 00000041CB80: D6100031 02410922
	.long 0xd72c002c                                           // 00000041CB88: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041CB8C: 020258FF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 00000041CB94: D6220028 03FD0128 00006400
	.long 0xd72c002f                                           // 00000041CBA0: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000041CBA4: 02025EFF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000041CBAC: D6220023 03FD0123 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000041CBB8: D622002B 03FD012B 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000041CBC4: D6220027 03FD0127 00006400
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000041CBD0: 30505090
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000041CBD4: D6220024 03FD0124 00006400
	v_and_b32_e32 v35, 0xffff, v35                             // 00000041CBE0: 364646FF 0000FFFF
	v_bfe_u32 v46, v37, 4, 16                                  // 00000041CBE8: D610002E 02410925
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041CBF0: D622002C 03FD012C 00006400
	v_and_or_b32 v43, 0xffff, v43, v40                         // 00000041CBFC: D657002B 04A256FF 0000FFFF
	v_sad_u8 v40, v47, 0, 0x6400                               // 00000041CC08: D6220028 03FD012F 00006400
	v_lshl_or_b32 v35, v39, 16, v35                            // 00000041CC14: D6560023 048D2127
	v_and_b32_e32 v36, 0xffff, v36                             // 00000041CC1C: 364848FF 0000FFFF
	.long 0xd72c002a                                           // 00000041CC24: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000041CC28: 020254FF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000041CC30: D6220026 03FD0126 00006400
	.long 0xd72c002e                                           // 00000041CC3C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000041CC40: 02025CFF 83DCD12D
	v_pk_fma_f16 v47, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CC48: CC0E002F 0BFC0B23 0000C931
	v_and_b32_e32 v34, 0xffff, v34                             // 00000041CC54: 364444FF 0000FFFF
	v_lshl_or_b32 v44, v44, 16, v36                            // 00000041CC5C: D656002C 0491212C
	.long 0xd72c0031                                           // 00000041CC64: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000041CC68: 020262FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000041CC70: BF89FC07
	v_dual_dot2acc_f32_f16 v17, v47, v1 :: v_dual_and_b32 v38, 0xffff, v38// 00000041CC74: CB24032F 11264CFF 0000FFFF
	.long 0xd72c0022                                           // 00000041CC80: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041CC84: 020244FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000041CC8C: D622002A 03FD012A 00006400
	.long 0xd72c0030                                           // 00000041CC98: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000041CC9C: 020260FF 83DCD12D
	.long 0xd72c0029                                           // 00000041CCA4: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000041CCA8: 020252FF 83DCD12D
	.long 0xd72c002d                                           // 00000041CCB0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041CCB4: 02025AFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000041CCBC: D6220031 03FD0131 00006400
	v_lshl_or_b32 v38, v42, 16, v38                            // 00000041CCC8: D6560026 0499212A
	v_sad_u8 v42, v46, 0, 0x6400                               // 00000041CCD0: D622002A 03FD012E 00006400
	v_sad_u8 v39, v34, 0, 0x6400                               // 00000041CCDC: D6220027 03FD0122 00006400
	ds_load_2addr_b32 v[34:35], v33 offset0:64 offset1:96      // 00000041CCE8: D8DC6040 22000021
	v_and_b32_e32 v37, 0xffff, v37                             // 00000041CCF0: 364A4AFF 0000FFFF
	v_sad_u8 v46, v48, 0, 0x6400                               // 00000041CCF8: D622002E 03FD0130 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000041CD04: D6220029 03FD0129 00006400
	v_lshlrev_b32_e32 v39, 16, v39                             // 00000041CD10: 304E4E90
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041CD14: D622002D 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CD20: BF870193
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000041CD24: 30525290
	v_and_or_b32 v39, 0xffff, v49, v39                         // 00000041CD28: D6570027 049E62FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041CD34: BF870112
	v_and_or_b32 v41, 0xffff, v45, v41                         // 00000041CD38: D6570029 04A65AFF 0000FFFF
	v_pk_fma_f16 v47, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CD44: CC0E002F 0BFC0B27 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 00000041CD50: 365050FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000041CD58: BF870003
	v_pk_fma_f16 v41, v41, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CD5C: CC0E0029 0BFC0B29 0000C931
	s_waitcnt lgkmcnt(0)                                       // 00000041CD68: BF89FC07
	v_mov_b32_e32 v36, v34                                     // 00000041CD6C: 7E480322
	.long 0xd72c0025                                           // 00000041CD70: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000041CD74: 02024AFF 83DCD12D
	v_lshl_or_b32 v40, v46, 16, v40                            // 00000041CD7C: D6560028 04A1212E
	v_pk_fma_f16 v34, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CD84: CC0E0022 0BFC0B2C 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000041CD90: BF870142
	v_pk_fma_f16 v46, v40, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CD94: CC0E002E 0BFC0B28 0000C931
	ds_load_2addr_b32 v[39:40], v30 offset0:64 offset1:96      // 00000041CDA0: D8DC6040 2700001E
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000041CDA8: D6220025 03FD0125 00006400
	v_dot2acc_f32_f16 v21, v46, v1                             // 00000041CDB4: 042A032E
	v_lshlrev_b32_e32 v37, 16, v37                             // 00000041CDB8: 304A4A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041CDBC: BF870112
	v_dot2acc_f32_f16 v21, v47, v2                             // 00000041CDC0: 042A052F
	v_and_or_b32 v37, 0xffff, v42, v37                         // 00000041CDC4: D6570025 049654FF 0000FFFF
	v_pk_fma_f16 v42, v38, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CDD0: CC0E002A 0BFC0B26 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CDDC: BF870193
	v_dot2acc_f32_f16 v21, v34, v3                             // 00000041CDE0: 042A0722
	v_pk_fma_f16 v48, v37, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CDE4: CC0E0030 0BFC0B25 0000C931
	ds_load_2addr_b32 v[37:38], v32 offset0:64 offset1:96      // 00000041CDF0: D8DC6040 25000020
	s_waitcnt lgkmcnt(1)                                       // 00000041CDF8: BF89FC17
	v_bfe_u32 v44, v39, 4, 16                                  // 00000041CDFC: D610002C 02410927
	v_dot2acc_f32_f16 v17, v48, v2                             // 00000041CE04: 04220530
	v_bfe_u32 v47, v40, 4, 16                                  // 00000041CE08: D610002F 02410928
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CE10: BF870193
	.long 0xd72c002c                                           // 00000041CE14: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041CE18: 020258FF 83DCD12D
	v_dot2acc_f32_f16 v17, v42, v3                             // 00000041CE20: 0422072A
	s_waitcnt lgkmcnt(0)                                       // 00000041CE24: BF89FC07
	.long 0xd73d0024                                           // 00000041CE28: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 00000041CE2C: 0202491F
	v_pk_fma_f16 v37, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CE30: CC0E0025 0BFC0B2B 0000C931
	v_bfe_u32 v43, v39, 8, 16                                  // 00000041CE3C: D610002B 02411127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041CE44: BF8701A3
	v_bfe_u32 v34, v36, 12, 16                                 // 00000041CE48: D6100022 02411924
	v_bfe_u32 v42, v36, 8, 16                                  // 00000041CE50: D610002A 02411124
	.long 0xd72c002b                                           // 00000041CE58: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041CE5C: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CE64: BF870193
	.long 0xd72c0022                                           // 00000041CE68: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041CE6C: 020244FF 83DCD12D
	.long 0xd72c002a                                           // 00000041CE74: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000041CE78: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041CE80: BF870112
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000041CE84: D6220022 03FD0122 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000041CE90: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041CE9C: BF8701B2
	v_dual_dot2acc_f32_f16 v21, v41, v4 :: v_dual_and_b32 v34, 0xffff, v34// 00000041CEA0: CB240929 152244FF 0000FFFF
	v_bfe_u32 v41, v39, 12, 16                                 // 00000041CEAC: D6100029 02411927
	v_and_b32_e32 v39, 0xffff, v39                             // 00000041CEB4: 364E4EFF 0000FFFF
	v_lshl_or_b32 v42, v42, 16, v34                            // 00000041CEBC: D656002A 0489212A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CEC4: BF870193
	.long 0xd72c0029                                           // 00000041CEC8: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000041CECC: 020252FF 83DCD12D
	.long 0xd72c0027                                           // 00000041CED4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041CED8: 02024EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041CEE0: BF870112
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000041CEE4: D6220029 03FD0129 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000041CEF0: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v17, v37, v4                             // 00000041CEFC: 04220925
	v_and_b32_e32 v37, 0xffff, v36                             // 00000041CF00: 364A48FF 0000FFFF
	v_bfe_u32 v36, v36, 4, 16                                  // 00000041CF08: D6100024 02410924
	v_and_b32_e32 v41, 0xffff, v41                             // 00000041CF10: 365252FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CF18: BF870193
	.long 0xd72c0025                                           // 00000041CF1C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000041CF20: 02024AFF 83DCD12D
	.long 0xd72c0024                                           // 00000041CF28: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000041CF2C: 020248FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041CF34: BF870112
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000041CF38: D6220025 03FD0125 00006400
	v_sad_u8 v45, v36, 0, 0x6400                               // 00000041CF44: D622002D 03FD0124 00006400
	v_mov_b32_e32 v36, v38                                     // 00000041CF50: 7E480326
	v_sad_u8 v38, v43, 0, 0x6400                               // 00000041CF54: D6220026 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041CF60: BF870194
	v_lshlrev_b32_e32 v37, 16, v37                             // 00000041CF64: 304A4A90
	.long 0xd73d0022                                           // 00000041CF68: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 00000041CF6C: 0202471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041CF70: BF870223
	v_lshl_or_b32 v35, v38, 16, v41                            // 00000041CF74: D6560023 04A52126
	v_sad_u8 v36, v44, 0, 0x6400                               // 00000041CF7C: D6220024 03FD012C 00006400
	v_and_or_b32 v37, 0xffff, v45, v37                         // 00000041CF88: D6570025 04965AFF 0000FFFF
	v_lshlrev_b32_e32 v38, 16, v39                             // 00000041CF94: 304C4E90
	v_pk_fma_f16 v39, v42, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CF98: CC0E0027 0BFC0B2A 0000C931
	v_bfe_u32 v41, v34, 12, 16                                 // 00000041CFA4: D6100029 02411922
	v_pk_fma_f16 v42, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CFAC: CC0E002A 0BFC0B23 0000C931
	v_pk_fma_f16 v37, v37, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CFB8: CC0E0025 0BFC0B25 0000C931
	v_and_or_b32 v35, 0xffff, v36, v38                         // 00000041CFC4: D6570023 049A48FF 0000FFFF
	v_dot2acc_f32_f16 v26, v39, v1                             // 00000041CFD0: 04340327
	v_bfe_u32 v36, v34, 8, 16                                  // 00000041CFD4: D6100024 02411122
	.long 0xd72c0026                                           // 00000041CFDC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000041CFE0: 020252FF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v34                             // 00000041CFE8: 364E44FF 0000FFFF
	v_pk_fma_f16 v41, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041CFF0: CC0E0029 0BFC0B23 0000C931
	v_dot2acc_f32_f16 v26, v37, v2                             // 00000041CFFC: 04340525
	v_bfe_u32 v37, v34, 4, 16                                  // 00000041D000: D6100025 02410922
	ds_load_2addr_b32 v[34:35], v33 offset0:128 offset1:160    // 00000041D008: D8DCA080 22000021
	.long 0xd72c0024                                           // 00000041D010: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000041D014: 020248FF 83DCD12D
	.long 0xd72c0027                                           // 00000041D01C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D020: 02024EFF 83DCD12D
	v_sad_u8 v43, v38, 0, 0x6400                               // 00000041D028: D622002B 03FD0126 00006400
	.long 0xd72c002e                                           // 00000041D034: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000041D038: 02024AFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v32 offset0:128 offset1:160    // 00000041D040: D8DCA080 25000020
	v_bfe_u32 v44, v40, 12, 16                                 // 00000041D048: D610002C 02411928
	v_bfe_u32 v45, v40, 8, 16                                  // 00000041D050: D610002D 02411128
	v_and_b32_e32 v43, 0xffff, v43                             // 00000041D058: 365656FF 0000FFFF
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000041D060: D6220024 03FD0124 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000041D06C: D6220027 03FD0127 00006400
	.long 0xd72c002c                                           // 00000041D078: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041D07C: 020258FF 83DCD12D
	.long 0xd72c002d                                           // 00000041D084: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041D088: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v26, v42, v3                             // 00000041D090: 0434072A
	v_lshl_or_b32 v36, v36, 16, v43                            // 00000041D094: D6560024 04AD2124
	v_sad_u8 v43, v46, 0, 0x6400                               // 00000041D09C: D622002B 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041D0A8: BF870193
	v_dual_dot2acc_f32_f16 v26, v41, v4 :: v_dual_lshlrev_b32 v39, 16, v39// 00000041D0AC: CB220929 1A264E90
	v_pk_fma_f16 v46, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D0B4: CC0E002E 0BFC0B24 0000C931
	s_waitcnt lgkmcnt(1)                                       // 00000041D0C0: BF89FC17
	v_mov_b32_e32 v36, v34                                     // 00000041D0C4: 7E480322
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041D0C8: D622002C 03FD012C 00006400
	v_and_or_b32 v43, 0xffff, v43, v39                         // 00000041D0D4: D657002B 049E56FF 0000FFFF
	v_dual_dot2acc_f32_f16 v25, v46, v1 :: v_dual_and_b32 v40, 0xffff, v40// 00000041D0E0: CB24032E 192850FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000041D0EC: BF89FC07
	.long 0xd73d0024                                           // 00000041D0F0: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 00000041D0F4: 0202491F
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041D0F8: D622002D 03FD012D 00006400
	v_pk_fma_f16 v37, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D104: CC0E0025 0BFC0B2B 0000C931
	v_and_b32_e32 v44, 0xffff, v44                             // 00000041D110: 365858FF 0000FFFF
	.long 0xd72c0028                                           // 00000041D118: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000041D11C: 020250FF 83DCD12D
	.long 0xd72c0022                                           // 00000041D124: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000041D128: 02025EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041D130: BF870214
	v_dot2acc_f32_f16 v25, v37, v2                             // 00000041D134: 04320525
	v_lshl_or_b32 v43, v45, 16, v44                            // 00000041D138: D656002B 04B1212D
	v_bfe_u32 v45, v36, 12, 16                                 // 00000041D140: D610002D 02411924
	v_sad_u8 v47, v40, 0, 0x6400                               // 00000041D148: D622002F 03FD0128 00006400
	ds_load_2addr_b32 v[39:40], v30 offset0:128 offset1:160    // 00000041D154: D8DCA080 2700001E
	v_pk_fma_f16 v42, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D15C: CC0E002A 0BFC0B2B 0000C931
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000041D168: D6220022 03FD0122 00006400
	.long 0xd72c0025                                           // 00000041D174: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041D178: 02025AFF 83DCD12D
	v_bfe_u32 v43, v36, 8, 16                                  // 00000041D180: D610002B 02411124
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041D188: BF8701A4
	v_dot2acc_f32_f16 v25, v42, v3                             // 00000041D18C: 0432072A
	v_lshlrev_b32_e32 v44, 16, v47                             // 00000041D190: 30585E90
	.long 0xd72c002a                                           // 00000041D194: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041D198: 020256FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000041D1A0: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041D1AC: BF870113
	v_and_or_b32 v34, 0xffff, v34, v44                         // 00000041D1B0: D6570022 04B244FF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v37                             // 00000041D1BC: 364A4AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 00000041D1C4: BF870002
	v_pk_fma_f16 v41, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D1C8: CC0E0029 0BFC0B22 0000C931
	v_bfe_u32 v34, v36, 4, 16                                  // 00000041D1D4: D6100022 02410924
	v_and_b32_e32 v36, 0xffff, v36                             // 00000041D1DC: 364848FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 00000041D1E4: BF89FC07
	v_bfe_u32 v43, v39, 12, 16                                 // 00000041D1E8: D610002B 02411927
	v_and_b32_e32 v45, 0xffff, v39                             // 00000041D1F0: 365A4EFF 0000FFFF
	v_bfe_u32 v44, v39, 8, 16                                  // 00000041D1F8: D610002C 02411127
	.long 0xd72c0022                                           // 00000041D200: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041D204: 020244FF 83DCD12D
	.long 0xd72c0024                                           // 00000041D20C: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000041D210: 020248FF 83DCD12D
	.long 0xd72c002b                                           // 00000041D218: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041D21C: 020256FF 83DCD12D
	.long 0xd72c002d                                           // 00000041D224: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041D228: 02025AFF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000041D230: D622002A 03FD012A 00006400
	v_bfe_u32 v39, v39, 4, 16                                  // 00000041D23C: D6100027 02410927
	v_dot2acc_f32_f16 v25, v41, v4                             // 00000041D244: 04320929
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000041D248: D6220024 03FD0124 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041D254: BF870004
	v_lshl_or_b32 v37, v42, 16, v37                            // 00000041D258: D6560025 0495212A
	.long 0xd72c002a                                           // 00000041D260: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041D264: 020258FF 83DCD12D
	.long 0xd72c0027                                           // 00000041D26C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D270: 02024EFF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000041D278: D622002B 03FD012B 00006400
	v_sad_u8 v44, v34, 0, 0x6400                               // 00000041D284: D622002C 03FD0122 00006400
	v_lshlrev_b32_e32 v46, 16, v36                             // 00000041D290: 305C4890
	v_sad_u8 v34, v45, 0, 0x6400                               // 00000041D294: D6220022 03FD012D 00006400
	v_mov_b32_e32 v36, v38                                     // 00000041D2A0: 7E480326
	v_and_b32_e32 v38, 0xffff, v43                             // 00000041D2A4: 364C56FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000041D2AC: D622002A 03FD012A 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000041D2B8: D6220027 03FD0127 00006400
	v_lshlrev_b32_e32 v43, 16, v34                             // 00000041D2C4: 30564490
	.long 0xd73d0022                                           // 00000041D2C8: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 00000041D2CC: 0202471F
	v_pk_fma_f16 v36, v37, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D2D0: CC0E0024 0BFC0B25 0000C931
	v_lshl_or_b32 v37, v42, 16, v38                            // 00000041D2DC: D6560025 0499212A
	v_and_or_b32 v35, 0xffff, v44, v46                         // 00000041D2E4: D6570023 04BA58FF 0000FFFF
	v_and_or_b32 v38, 0xffff, v39, v43                         // 00000041D2F0: D6570026 04AE4EFF 0000FFFF
	v_bfe_u32 v43, v40, 8, 16                                  // 00000041D2FC: D610002B 02411128
	v_bfe_u32 v39, v34, 12, 16                                 // 00000041D304: D6100027 02411922
	v_dot2acc_f32_f16 v24, v36, v1                             // 00000041D30C: 04300324
	v_pk_fma_f16 v41, v37, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D310: CC0E0029 0BFC0B25 0000C931
	v_bfe_u32 v37, v34, 8, 16                                  // 00000041D31C: D6100025 02411122
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D324: CC0E0023 0BFC0B23 0000C931
	.long 0xd72c0024                                           // 00000041D330: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D334: 02024EFF 83DCD12D
	v_pk_fma_f16 v42, v38, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D33C: CC0E002A 0BFC0B26 0000C931
	v_bfe_u32 v38, v34, 4, 16                                  // 00000041D348: D6100026 02410922
	v_and_b32_e32 v34, 0xffff, v34                             // 00000041D350: 364444FF 0000FFFF
	.long 0xd72c0025                                           // 00000041D358: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000041D35C: 02024AFF 83DCD12D
	v_dot2acc_f32_f16 v24, v35, v2                             // 00000041D364: 04300523
	v_bfe_u32 v39, v40, 12, 16                                 // 00000041D368: D6100027 02411928
	v_bfe_u32 v44, v40, 4, 16                                  // 00000041D370: D610002C 02410928
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000041D378: D6220024 03FD0124 00006400
	.long 0xd72c002d                                           // 00000041D384: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041D388: 020244FF 83DCD12D
	ds_load_2addr_b32 v[34:35], v33 offset0:192 offset1:224    // 00000041D390: D8DCE0C0 22000021
	v_and_b32_e32 v40, 0xffff, v40                             // 00000041D398: 365050FF 0000FFFF
	v_sad_u8 v46, v37, 0, 0x6400                               // 00000041D3A0: D622002E 03FD0125 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 00000041D3AC: 364848FF 0000FFFF
	.long 0xd72c002f                                           // 00000041D3B4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000041D3B8: 02024CFF 83DCD12D
	ds_load_2addr_b32 v[37:38], v32 offset0:192 offset1:224    // 00000041D3C0: D8DCE0C0 25000020
	.long 0xd72c0028                                           // 00000041D3C8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000041D3CC: 020250FF 83DCD12D
	.long 0xd72c0027                                           // 00000041D3D4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D3D8: 02024EFF 83DCD12D
	v_lshl_or_b32 v46, v46, 16, v36                            // 00000041D3E0: D656002E 0491212E
	v_sad_u8 v36, v45, 0, 0x6400                               // 00000041D3E8: D6220024 03FD012D 00006400
	.long 0xd72c002b                                           // 00000041D3F4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041D3F8: 020256FF 83DCD12D
	.long 0xd72c002c                                           // 00000041D400: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041D404: 020258FF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000041D40C: D622002F 03FD012F 00006400
	v_pk_fma_f16 v46, v46, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D418: CC0E002E 0BFC0B2E 0000C931
	v_lshlrev_b32_e32 v48, 16, v36                             // 00000041D424: 30604890
	v_sad_u8 v36, v40, 0, 0x6400                               // 00000041D428: D6220024 03FD0128 00006400
	v_sad_u8 v45, v39, 0, 0x6400                               // 00000041D434: D622002D 03FD0127 00006400
	ds_load_2addr_b32 v[39:40], v30 offset0:192 offset1:224    // 00000041D440: D8DCE0C0 2700001E
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000041D448: D622002B 03FD012B 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041D454: D622002C 03FD012C 00006400
	s_waitcnt lgkmcnt(2)                                       // 00000041D460: BF89FC27
	v_dual_mov_b32 v36, v34 :: v_dual_lshlrev_b32 v49, 16, v36 // 00000041D464: CA220122 24304890
	v_and_b32_e32 v45, 0xffff, v45                             // 00000041D46C: 365A5AFF 0000FFFF
	v_and_or_b32 v34, 0xffff, v47, v48                         // 00000041D474: D6570022 04C25EFF 0000FFFF
	v_dot2acc_f32_f16 v23, v46, v1                             // 00000041D480: 042E032E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041D484: BF870004
	v_and_or_b32 v44, 0xffff, v44, v49                         // 00000041D488: D657002C 04C658FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000041D494: BF89FC17
	.long 0xd73d0024                                           // 00000041D498: D73D0024
	v_cndmask_b32_e32 v1, v31, v36, vcc_lo                     // 00000041D49C: 0202491F
	v_lshl_or_b32 v43, v43, 16, v45                            // 00000041D4A0: D656002B 04B5212B
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D4A8: CC0E0022 0BFC0B22 0000C931
	v_dot2acc_f32_f16 v24, v41, v3                             // 00000041D4B4: 04300729
	v_pk_fma_f16 v41, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D4B8: CC0E0029 0BFC0B2C 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000041D4C4: BF870254
	v_pk_fma_f16 v37, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D4C8: CC0E0025 0BFC0B2B 0000C931
	v_bfe_u32 v43, v36, 12, 16                                 // 00000041D4D4: D610002B 02411924
	v_dual_dot2acc_f32_f16 v23, v34, v2 :: v_dual_and_b32 v34, 0xffff, v36// 00000041D4DC: CB240522 172248FF 0000FFFF
	v_bfe_u32 v44, v36, 8, 16                                  // 00000041D4E8: D610002C 02411124
	v_bfe_u32 v36, v36, 4, 16                                  // 00000041D4F0: D6100024 02410924
	.long 0xd72c002b                                           // 00000041D4F8: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000041D4FC: 020256FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000041D504: BF89FC07
	v_bfe_u32 v45, v39, 12, 16                                 // 00000041D508: D610002D 02411927
	.long 0xd72c0022                                           // 00000041D510: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041D514: 020244FF 83DCD12D
	.long 0xd72c002c                                           // 00000041D51C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041D520: 020258FF 83DCD12D
	.long 0xd72c0024                                           // 00000041D528: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000041D52C: 020248FF 83DCD12D
	v_bfe_u32 v46, v39, 8, 16                                  // 00000041D534: D610002E 02411127
	.long 0xd72c002d                                           // 00000041D53C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041D540: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v23, v37, v3                             // 00000041D548: 042E0725
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000041D54C: D622002B 03FD012B 00006400
	v_bfe_u32 v47, v39, 4, 16                                  // 00000041D558: D610002F 02410927
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000041D560: D6220022 03FD0122 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041D56C: D622002C 03FD012C 00006400
	v_sad_u8 v48, v36, 0, 0x6400                               // 00000041D578: D6220030 03FD0124 00006400
	v_dual_mov_b32 v36, v38 :: v_dual_and_b32 v43, 0xffff, v43 // 00000041D584: CA240126 242A56FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000041D590: BF870234
	v_dual_dot2acc_f32_f16 v23, v41, v4 :: v_dual_lshlrev_b32 v34, 16, v34// 00000041D594: CB220929 17224490
	.long 0xd72c002e                                           // 00000041D59C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000041D5A0: 02025CFF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041D5A8: D622002D 03FD012D 00006400
	v_lshl_or_b32 v43, v44, 16, v43                            // 00000041D5B4: D656002B 04AD212C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041D5BC: BF870004
	v_and_or_b32 v44, 0xffff, v48, v34                         // 00000041D5C0: D657002C 048A60FF 0000FFFF
	.long 0xd73d0022                                           // 00000041D5CC: D73D0022
	v_cndmask_b32_e32 v1, v31, v35, vcc_lo                     // 00000041D5D0: 0202471F
	v_dual_dot2acc_f32_f16 v24, v42, v4 :: v_dual_and_b32 v39, 0xffff, v39// 00000041D5D4: CB24092A 18264EFF 0000FFFF
	v_and_b32_e32 v45, 0xffff, v45                             // 00000041D5E0: 365A5AFF 0000FFFF
	v_sad_u8 v38, v46, 0, 0x6400                               // 00000041D5E8: D6220026 03FD012E 00006400
	.long 0xd72c002e                                           // 00000041D5F4: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000041D5F8: 02025EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041D600: BF870004
	.long 0xd72c0024                                           // 00000041D604: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D608: 02024EFF 83DCD12D
	v_bfe_u32 v39, v34, 12, 16                                 // 00000041D610: D6100027 02411922
	v_pk_fma_f16 v37, v43, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D618: CC0E0025 0BFC0B2B 0000C931
	v_lshl_or_b32 v35, v38, 16, v45                            // 00000041D624: D6560023 04B52126
	v_pk_fma_f16 v38, v44, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D62C: CC0E0026 0BFC0B2C 0000C931
	v_and_b32_e32 v44, 0xffff, v34                             // 00000041D638: 365844FF 0000FFFF
	.long 0xd72c0027                                           // 00000041D640: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000041D644: 02024EFF 83DCD12D
	v_bfe_u32 v45, v34, 8, 16                                  // 00000041D64C: D610002D 02411122
	v_bfe_u32 v34, v34, 4, 16                                  // 00000041D654: D6100022 02410922
	v_sad_u8 v43, v46, 0, 0x6400                               // 00000041D65C: D622002B 03FD012E 00006400
	.long 0xd72c002c                                           // 00000041D668: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000041D66C: 020258FF 83DCD12D
	v_bfe_u32 v46, v40, 12, 16                                 // 00000041D674: D610002E 02411928
	.long 0xd72c002d                                           // 00000041D67C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000041D680: 02025AFF 83DCD12D
	.long 0xd72c0022                                           // 00000041D688: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000041D68C: 020244FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000041D694: D6220027 03FD0127 00006400
	v_bfe_u32 v47, v40, 8, 16                                  // 00000041D6A0: D610002F 02411128
	.long 0xd72c002e                                           // 00000041D6A8: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000041D6AC: 02025CFF 83DCD12D
	v_bfe_u32 v48, v40, 4, 16                                  // 00000041D6B4: D6100030 02410928
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041D6BC: D622002C 03FD012C 00006400
	v_and_b32_e32 v40, 0xffff, v40                             // 00000041D6C8: 365050FF 0000FFFF
	v_and_b32_e32 v39, 0xffff, v39                             // 00000041D6D0: 364E4EFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000041D6D8: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 00000041D6E4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000041D6E8: 02025EFF 83DCD12D
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000041D6F0: D6220022 03FD0122 00006400
	v_lshlrev_b32_e32 v44, 16, v44                             // 00000041D6FC: 30585890
	.long 0xd72c0028                                           // 00000041D700: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000041D704: 020250FF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000041D70C: D622002E 03FD012E 00006400
	v_lshl_or_b32 v39, v45, 16, v39                            // 00000041D718: D6560027 049D212D
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000041D720: D6220024 03FD0124 00006400
	v_and_or_b32 v34, 0xffff, v34, v44                         // 00000041D72C: D6570022 04B244FF 0000FFFF
	.long 0xd72c002c                                           // 00000041D738: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000041D73C: 020260FF 83DCD12D
	v_and_b32_e32 v45, 0xffff, v46                             // 00000041D744: 365A5CFF 0000FFFF
	v_sad_u8 v46, v47, 0, 0x6400                               // 00000041D74C: D622002E 03FD012F 00006400
	v_pk_fma_f16 v39, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D758: CC0E0027 0BFC0B27 0000C931
	v_dot2acc_f32_f16 v22, v37, v1                             // 00000041D764: 042C0325
	v_sad_u8 v37, v40, 0, 0x6400                               // 00000041D768: D6220025 03FD0128 00006400
	v_lshlrev_b32_e32 v36, 16, v36                             // 00000041D774: 30484890
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D778: CC0E0022 0BFC0B22 0000C931
	v_lshl_or_b32 v40, v46, 16, v45                            // 00000041D784: D6560028 04B5212E
	v_dot2acc_f32_f16 v12, v39, v1                             // 00000041D78C: 04180327
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000041D790: D622002C 03FD012C 00006400
	v_lshlrev_b32_e32 v37, 16, v37                             // 00000041D79C: 304A4A90
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D7A0: CC0E0023 0BFC0B23 0000C931
	v_and_or_b32 v1, 0xffff, v43, v36                          // 00000041D7AC: D6570001 049256FF 0000FFFF
	v_dot2acc_f32_f16 v22, v38, v2                             // 00000041D7B8: 042C0526
	v_pk_fma_f16 v36, v40, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000041D7BC: CC0E0024 0BFC0B28 0000C931
	v_dot2acc_f32_f16 v12, v34, v2                             // 00000041D7C8: 04180522
	v_and_or_b32 v37, 0xffff, v44, v37                         // 00000041D7CC: D6570025 049658FF 0000FFFF
	v_pk_fma_f16 v1, v1, s5, 0xc931 op_sel_hi:[1,0,0]          // 00000041D7D8: CC0E0001 0BFC0B01 0000C931
	v_dot2acc_f32_f16 v22, v35, v3                             // 00000041D7E4: 042C0723
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000041D7E8: BF870214
	v_dual_dot2acc_f32_f16 v12, v36, v3 :: v_dual_add_nc_u32 v3, v27, v28// 00000041D7EC: CB200724 0C02391B
	v_pk_fma_f16 v2, v37, s5, 0xc931 op_sel_hi:[1,0,0]         // 00000041D7F4: CC0E0002 0BFC0B25 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041D800: BF870193
	v_dot2acc_f32_f16 v22, v1, v4                              // 00000041D804: 042C0901
	v_cmp_eq_u32_e32 vcc_lo, 1, v3                             // 00000041D808: 7C940681
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000041D80C: BF8704A3
	v_dot2acc_f32_f16 v12, v2, v4                              // 00000041D810: 04180902
	s_or_b32 s4, vcc_lo, s4                                    // 00000041D814: 8C04046A
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000041D818: 917E047E
	s_cbranch_execz 34                                         // 00000041D81C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1aa8>
	s_mov_b32 s2, exec_lo                                      // 00000041D820: BE82007E
	s_waitcnt vmcnt(6)                                         // 00000041D824: BF891BF7
	ds_store_2addr_b32 v30, v11, v13 offset1:32                // 00000041D828: D8382000 000D0B1E
	s_waitcnt vmcnt(4)                                         // 00000041D830: BF8913F7
	ds_store_2addr_b32 v30, v14, v15 offset0:64 offset1:96     // 00000041D834: D8386040 000F0E1E
	s_waitcnt vmcnt(2)                                         // 00000041D83C: BF890BF7
	ds_store_2addr_b32 v30, v16, v18 offset0:128 offset1:160   // 00000041D840: D838A080 0012101E
	s_waitcnt vmcnt(0)                                         // 00000041D848: BF8903F7
	ds_store_2addr_b32 v30, v19, v20 offset0:192 offset1:224   // 00000041D84C: D838E0C0 0014131E
	.long 0xd4c1007e                                           // 00000041D854: D4C1007E
	v_cndmask_b32_e32 v1, v28, v10, vcc_lo                     // 00000041D858: 0202151C
	s_cbranch_execz 64645                                      // 00000041D85C: BFA5FC85 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc74>
	s_clause 0x7                                               // 00000041D860: BF850007
	global_load_b32 v11, v[5:6], off                           // 00000041D864: DC520000 0B7C0005
	global_load_b32 v13, v[5:6], off offset:128                // 00000041D86C: DC520080 0D7C0005
	global_load_b32 v14, v[5:6], off offset:256                // 00000041D874: DC520100 0E7C0005
	global_load_b32 v15, v[5:6], off offset:384                // 00000041D87C: DC520180 0F7C0005
	global_load_b32 v16, v[5:6], off offset:512                // 00000041D884: DC520200 107C0005
	global_load_b32 v18, v[5:6], off offset:640                // 00000041D88C: DC520280 127C0005
	global_load_b32 v19, v[5:6], off offset:768                // 00000041D894: DC520300 137C0005
	global_load_b32 v20, v[5:6], off offset:896                // 00000041D89C: DC520380 147C0005
	s_branch 64627                                             // 00000041D8A4: BFA0FC73 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000041D8A8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041D8AC: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 00000041D8B0: 8C7E037E
	v_dual_mov_b32 v1, v17 :: v_dual_mov_b32 v4, v24           // 00000041D8B4: CA100111 01040118
	v_dual_mov_b32 v2, v21 :: v_dual_mov_b32 v3, v26           // 00000041D8BC: CA100115 0202011A
	v_dual_mov_b32 v10, v25 :: v_dual_mov_b32 v5, v23          // 00000041D8C4: CA100119 0A040117
	s_waitcnt vmcnt(7)                                         // 00000041D8CC: BF891FF7
	v_dual_mov_b32 v6, v22 :: v_dual_mov_b32 v11, v12          // 00000041D8D0: CA100116 060A010C
	s_mov_b32 s2, 0x76543210                                   // 00000041D8D8: BE8200FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000041D8E0: BF8903F7
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 00000041D8E4: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 00000041D8F0: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 00000041D8FC: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 00000041D908: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 00000041D914: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 00000041D920: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 00000041D92C: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 00000041D938: D65C000B 03FC050B FEDCBA98
	.long 0xd44c0002                                           // 00000041D944: D44C0002
	v_cndmask_b32_e32 v1, 16, v8, vcc_lo                       // 00000041D948: 02021090
	s_barrier                                                  // 00000041D94C: BFBD0000
	buffer_gl0_inv                                             // 00000041D950: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 00000041D958: BE832002
	s_cbranch_execz 18                                         // 00000041D95C: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ba8>
	v_dual_add_f32 v8, v12, v11 :: v_dual_add_f32 v1, v17, v1  // 00000041D960: C908170C 08000311
	v_dual_add_f32 v2, v21, v2 :: v_dual_add_f32 v3, v26, v3   // 00000041D968: C9080515 0202071A
	v_lshl_or_b32 v9, v7, 9, v9                                // 00000041D970: D6560009 04251307
	v_dual_add_f32 v10, v25, v10 :: v_dual_add_f32 v5, v23, v5 // 00000041D978: C9081519 0A040B17
	v_add_f32_e32 v4, v24, v4                                  // 00000041D980: 06080918
	v_add_f32_e32 v6, v22, v6                                  // 00000041D984: 060C0D16
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 00000041D988: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 00000041D990: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 00000041D998: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 00000041D9A0: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s3                              // 00000041D9A8: 8C7E037E
	.long 0xd44c0003                                           // 00000041D9AC: D44C0003
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000041D9B0: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000041D9B8: BF89FC07
	s_barrier                                                  // 00000041D9BC: BFBD0000
	buffer_gl0_inv                                             // 00000041D9C0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000041D9C8: BE842003
	s_cbranch_execnz 7                                         // 00000041D9CC: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1bec>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000041D9D0: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 00000041D9D4: BF048215
	s_mov_b32 s4, -1                                           // 00000041D9D8: BE8400C1
	s_cbranch_scc0 33                                          // 00000041D9DC: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1c64>
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000041D9E0: 8B6A047E
	s_cbranch_vccz 64001                                       // 00000041D9E4: BFA3FA01 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 164                                               // 00000041D9E8: BFA000A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e7c>
	v_lshlrev_b32_e32 v8, 2, v0                                // 00000041D9EC: 30100082
	ds_load_2addr_stride64_b32 v[1:2], v8 offset1:2            // 00000041D9F0: D8E00200 01000008
	ds_load_2addr_stride64_b32 v[3:4], v8 offset0:4 offset1:6  // 00000041D9F8: D8E00604 03000008
	s_waitcnt lgkmcnt(1)                                       // 00000041DA00: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 00000041DA04: 06020280
	ds_load_2addr_stride64_b32 v[5:6], v8 offset0:8 offset1:10 // 00000041DA08: D8E00A08 05000008
	v_add_f32_e32 v1, v1, v2                                   // 00000041DA10: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000041DA14: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000041DA18: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 00000041DA1C: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v8 offset0:12 offset1:14// 00000041DA20: D8E00E0C 01000008
	v_add_f32_e32 v3, v3, v4                                   // 00000041DA28: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000041DA2C: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 00000041DA30: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041DA34: BF8700A1
	v_add_f32_e32 v3, v3, v6                                   // 00000041DA38: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000041DA3C: BF89FC07
	v_add_f32_e32 v1, v3, v1                                   // 00000041DA40: 06020303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041DA44: BF870001
	v_add_f32_e32 v1, v1, v2                                   // 00000041DA48: 06020501
	ds_store_b32 v8, v1 offset:4096                            // 00000041DA4C: D8341000 00000108
	s_or_b32 exec_lo, exec_lo, s4                              // 00000041DA54: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 00000041DA58: BF048215
	s_mov_b32 s4, -1                                           // 00000041DA5C: BE8400C1
	s_cbranch_scc1 65503                                       // 00000041DA60: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1be0>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 00000041DA64: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 00000041DA6C: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 00000041DA70: BF89FC07
	s_barrier                                                  // 00000041DA74: BFBD0000
	buffer_gl0_inv                                             // 00000041DA78: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 00000041DA80: 80010804
	s_addc_u32 s4, s5, s9                                      // 00000041DA84: 82040905
	s_and_saveexec_b32 s0, s3                                  // 00000041DA88: BE802003
	s_cbranch_execz 17                                         // 00000041DA8C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1cd4>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000041DA90: 30020082
	s_mul_hi_i32 s9, s23, s20                                  // 00000041DA94: 97091417
	s_mul_i32 s8, s23, s20                                     // 00000041DA98: 96081417
	s_lshl_b32 s10, s26, 7                                     // 00000041DA9C: 840A871A
	s_lshl_b64 s[8:9], s[8:9], 2                               // 00000041DAA0: 84888208
	ds_load_b32 v2, v1 offset:4096                             // 00000041DAA4: D8D81000 02000001
	s_ashr_i32 s11, s10, 31                                    // 00000041DAAC: 860B9F0A
	s_add_u32 s5, s1, s8                                       // 00000041DAB0: 80050801
	s_addc_u32 s16, s4, s9                                     // 00000041DAB4: 82100904
	s_lshl_b64 s[8:9], s[10:11], 2                             // 00000041DAB8: 8488820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041DABC: BF870009
	s_add_u32 s8, s5, s8                                       // 00000041DAC0: 80080805
	s_addc_u32 s9, s16, s9                                     // 00000041DAC4: 82090910
	s_waitcnt lgkmcnt(0)                                       // 00000041DAC8: BF89FC07
	global_store_b32 v1, v2, s[8:9]                            // 00000041DACC: DC6A0000 00080201
	s_or_b32 exec_lo, exec_lo, s0                              // 00000041DAD4: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 00000041DAD8: 861D9F1C
	.long 0xd44a0000                                           // 00000041DADC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000041DAE0: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 00000041DAE4: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 00000041DAE8: BC7C0000
	buffer_gl1_inv                                             // 00000041DAEC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000041DAF4: E0AC0000 00000000
	s_add_u32 s6, s6, s8                                       // 00000041DAFC: 80060806
	s_addc_u32 s7, s7, s9                                      // 00000041DB00: 82070907
	s_barrier                                                  // 00000041DB04: BFBD0000
	buffer_gl0_inv                                             // 00000041DB08: E0AC0000 00000000
	s_and_saveexec_b32 s5, s0                                  // 00000041DB10: BE852000
	s_cbranch_execz 29                                         // 00000041DB14: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d8c>
	s_mov_b32 s9, exec_lo                                      // 00000041DB18: BE89007E
	s_mov_b32 s8, exec_lo                                      // 00000041DB1C: BE88007E
	.long 0xd71f0001                                           // 00000041DB20: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 00000041DB24: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041DB28: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000041DB2C: 7D940280
	s_cbranch_execz 9                                          // 00000041DB30: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1d58>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 00000041DB34: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000041DB38: BF8704B9
	s_add_u32 s10, s6, s10                                     // 00000041DB3C: 800A0A06
	s_addc_u32 s11, s7, s11                                    // 00000041DB40: 820B0B07
	s_bcnt1_i32_b32 s9, s9                                     // 00000041DB44: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 00000041DB48: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000041DB50: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 00000041DB58: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 00000041DB5C: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 00000041DB60: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041DB64: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 00000041DB68: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 00000041DB70: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000041DB74: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 00000041DB78: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000041DB7C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:13568                           // 00000041DB84: D8343500 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000041DB8C: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000041DB90: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000041DB94: BF89FC07
	s_barrier                                                  // 00000041DB98: BFBD0000
	buffer_gl0_inv                                             // 00000041DB9C: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:13568                            // 00000041DBA4: D8D83500 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000041DBAC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000041DBB0: 7C940280
	s_cbranch_vccnz 48                                         // 00000041DBB4: BFA40030 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e78>
	buffer_gl1_inv                                             // 00000041DBB8: E0B00000 00000000
	buffer_gl0_inv                                             // 00000041DBC0: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 00000041DBC8: BE882003
	s_cbranch_execz 30                                         // 00000041DBCC: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e48>
	s_lshl_b32 s10, s26, 7                                     // 00000041DBD0: 840A871A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 00000041DBD4: CA220080 04020082
	s_ashr_i32 s11, s10, 31                                    // 00000041DBDC: 860B9F0A
	s_ashr_i32 s5, s20, 31                                     // 00000041DBE0: 86059F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 00000041DBE4: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000041DBE8: BF8700B9
	s_add_u32 s1, s1, s10                                      // 00000041DBEC: 80010A01
	s_addc_u32 s3, s4, s11                                     // 00000041DBF0: 82030B04
	.long 0xd7000101                                           // 00000041DBF4: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 00000041DBF8: 02020601
	v_add_co_ci_u32_e64 v2, null, s3, 0, s1                    // 00000041DBFC: D5207C02 00050003
	s_mov_b32 s4, s20                                          // 00000041DC04: BE840014
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000041DC08: BF870009
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000041DC0C: 84848204
	global_load_b32 v5, v[1:2], off glc                        // 00000041DC10: DC524000 057C0001
	.long 0xd7006a01                                           // 00000041DC18: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000041DC1C: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000041DC20: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000041DC24: D5207C02 01AA0405
	s_add_i32 s21, s21, -1                                     // 00000041DC2C: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 00000041DC30: BF068015
	s_waitcnt vmcnt(0)                                         // 00000041DC34: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 00000041DC38: 06080B04
	s_cbranch_scc0 65524                                       // 00000041DC3C: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e10>
	ds_store_b32 v3, v4 offset:4096                            // 00000041DC40: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 00000041DC48: 8C7E087E
	s_and_saveexec_b32 s1, s0                                  // 00000041DC4C: BE812000
	s_cbranch_execz 6                                          // 00000041DC50: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e6c>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 00000041DC54: 8484821A
	v_mov_b32_e32 v1, 0                                        // 00000041DC58: 7E020280
	s_add_u32 s4, s6, s4                                       // 00000041DC5C: 80040406
	s_addc_u32 s5, s7, s5                                      // 00000041DC60: 82050507
	global_store_b32 v1, v1, s[4:5]                            // 00000041DC64: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000041DC6C: 8C7E017E
	s_cbranch_execz 63838                                      // 00000041DC70: BFA5F95E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 00000041DC74: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e7c>
	s_branch 63836                                             // 00000041DC78: BFA0F95C <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_eq_u32_e32 vcc_lo, 0, v7                             // 00000041DC7C: 7C940E80
	s_cmp_gt_i32 s18, 0                                        // 00000041DC80: BF028012
	s_waitcnt lgkmcnt(0)                                       // 00000041DC84: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000041DC88: BC7C0000
	s_cselect_b32 s0, -1, 0                                    // 00000041DC8C: 980080C1
	s_barrier                                                  // 00000041DC90: BFBD0000
	s_and_b32 s0, vcc_lo, s0                                   // 00000041DC94: 8B00006A
	buffer_gl0_inv                                             // 00000041DC98: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000041DCA0: BE812000
	s_cbranch_execz 63825                                      // 00000041DCA4: BFA5F951 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 00000041DCA8: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041DCAC: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000041DCB0: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 00000041DCB4: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000041DCBC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000041DCC4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000041DCCC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000041DCD4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000041DCDC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000041DCE0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000041DCE4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000041DCE8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000041DCF0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000041DCF4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000041DCFC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000041DD00: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000041DD08: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000041DD0C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000041DD14: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000041DD1C: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041DD20: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000041DD24: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000041DD2C: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000041DD34: 7C941480
	.long 0xd44a0000                                           // 00000041DD38: D44A0000
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 00000041DD3C: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000041DD40: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000041DD48: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000041DD4C: 08101D09
	.long 0xd44a0001                                           // 00000041DD50: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000041DD54: 02021880
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041DD58: BF870004
	v_add_f32_e32 v9, v13, v4                                  // 00000041DD5C: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000041DD60: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000041DD68: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000041DD6C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000041DD70: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DD74: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000041DD7C: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DD84: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000041DD8C: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DD94: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000041DD9C: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DDA4: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000041DDAC: D5010008 21AA1108
	v_add_f32_e32 v6, v7, v6                                   // 00000041DDB4: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 00000041DDB8: 060E1509
	v_add_f32_e32 v5, v5, v15                                  // 00000041DDBC: 060A1F05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DDC0: 7E1C02FA FF01610D
	v_add_f32_e32 v8, v8, v16                                  // 00000041DDC8: 06102108
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DDCC: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000041DDD4: D5010006 20020D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DDDC: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 00000041DDE4: D5010007 20020F07
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000041DDEC: D501000D 21AA1B0D
	v_mov_b32_dpp v22, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DDF4: 7E2C02FA FF016104
	v_add_f32_e32 v6, v6, v10                                  // 00000041DDFC: 060C1506
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000041DE00: D5010004 21AA0904
	v_add_f32_e32 v7, v7, v11                                  // 00000041DE08: 060E1707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041DE0C: BF8701A3
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DE10: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000041DE18: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DE20: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000041DE28: D5010007 20060F07
	v_add_f32_e32 v9, v13, v14                                 // 00000041DE30: 06121D0D
	v_add_f32_e32 v4, v4, v22                                  // 00000041DE34: 06082D04
	v_add_f32_e32 v20, v6, v10                                 // 00000041DE38: 06281506
	v_cndmask_b32_e64 v6, -v8, v8, s0                          // 00000041DE3C: D5010006 20021108
	v_add_f32_e32 v10, v7, v11                                 // 00000041DE44: 06141707
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DE48: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 00000041DE50: D5010009 20021309
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DE58: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000041DE60: D5010005 20020B05
	v_mov_b32_dpp v19, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DE68: 7E2602FA FF01680A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041DE70: BF870004
	v_add_f32_e32 v9, v9, v13                                  // 00000041DE74: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DE78: 7E1A02FA FF016208
	v_mov_b32_dpp v8, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DE80: 7E1002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000041DE88: D5010003 21AA0703
	v_add_f32_e32 v5, v5, v14                                  // 00000041DE90: 060A1D05
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DE94: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000041DE9C: D5010009 20061309
	v_add_f32_e32 v6, v6, v13                                  // 00000041DEA4: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041DEA8: BF870224
	v_mov_b32_dpp v7, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DEAC: 7E0E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 00000041DEB4: D5010005 20060B05
	v_add_f32_e32 v17, v9, v12                                 // 00000041DEBC: 06221909
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041DEC0: 7E1202FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000041DEC8: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v8                                   // 00000041DED0: 06061103
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DED4: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000041DEDC: D5010004 20020904
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DEE4: 7E2A02FA FF016814
	v_add_f32_e32 v2, v2, v9                                   // 00000041DEEC: 06041302
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DEF0: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000041DEF8: D5010003 20020703
	v_add_f32_e32 v4, v4, v8                                   // 00000041DF00: 06081104
	v_mov_b32_dpp v8, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DF04: 7E1002FA FF016406
	v_mov_b32_dpp v11, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000041DF0C: 7E1602FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000041DF14: D5010002 20020502
	v_add_f32_e32 v3, v3, v9                                   // 00000041DF1C: 06061303
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DF20: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000041DF28: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000041DF30: D5010006 20060D06
	v_add_f32_e32 v2, v2, v11                                  // 00000041DF38: 06041702
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DF3C: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000041DF44: D5010003 20060703
	v_add_f32_e32 v11, v4, v9                                  // 00000041DF4C: 06161304
	v_add_f32_e32 v15, v5, v7                                  // 00000041DF50: 061E0F05
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000041DF54: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000041DF5C: D5010002 20060502
	v_add_f32_e32 v13, v6, v8                                  // 00000041DF64: 061A1106
	v_add_f32_e32 v8, v3, v12                                  // 00000041DF68: 06101903
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF6C: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF74: 7E2002FA FF01680F
	v_add_f32_e32 v6, v2, v14                                  // 00000041DF7C: 060C1D02
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF80: 7E1C02FA FF01680D
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF88: 7E1802FA FF01680B
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF90: 7E1202FA FF016808
	s_delay_alu instid0(VALU_DEP_4)                            // 00000041DF98: BF870004
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000041DF9C: 7E0E02FA FF016806
	s_and_b32 exec_lo, exec_lo, s2                             // 00000041DFA4: 8B7E027E
	s_cbranch_execz 63632                                      // 00000041DFA8: BFA5F890 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 00000041DFAC: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 00000041DFB4: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 00000041DFB8: BF118018
	s_mov_b32 s2, 0                                            // 00000041DFBC: BE820080
	s_cselect_b32 s1, -1, 0                                    // 00000041DFC0: 980180C1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000041DFC4: 3408069F
	.long 0xd44a0000                                           // 00000041DFC8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000041DFCC: 02020080
	s_cmp_eq_u64 s[24:25], 0                                   // 00000041DFD0: BF108018
	.long 0xd73c0001                                           // 00000041DFD4: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000041DFD8: 02020681
	v_cndmask_b32_e64 v0, -v20, v20, s0                        // 00000041DFDC: D5010000 20022914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041DFE4: BF870191
	v_add_f32_e32 v0, v0, v21                                  // 00000041DFE8: 06002B00
	.long 0xd7006a04                                           // 00000041DFEC: D7006A04
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 00000041DFF0: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041DFF4: BF870191
	v_add_co_ci_u32_e64 v5, null, s13, v2, vcc_lo              // 00000041DFF8: D5207C05 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 00000041E000: 100000FF 3DB504F3
	global_load_d16_b16 v22, v[4:5], off                       // 00000041E008: DC820000 167C0004
	s_waitcnt vmcnt(0)                                         // 00000041E010: BF8903F7
	v_fma_mix_f32 v20, v22, v0, neg(0) op_sel_hi:[1,0,0]       // 00000041E014: CC200014 8A020116
	v_ashrrev_i32_e32 v0, 31, v3                               // 00000041E01C: 3400069F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E020: BF870092
	v_bfe_u32 v21, v20, 16, 1                                  // 00000041E024: D6100015 02052114
	v_add3_u32 v20, v20, v21, 0x7fff                           // 00000041E02C: D6550014 03FE2B14 00007FFF
	s_cbranch_scc1 537                                         // 00000041E038: BFA20219 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2aa0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041E03C: BF870123
	v_lshrrev_b32_e32 v21, 23, v0                              // 00000041E040: 322A0097
	v_dual_mov_b32 v26, s14 :: v_dual_mov_b32 v23, s15         // 00000041E044: CA10000E 1A16000F
	v_add_nc_u32_e32 v21, v3, v21                              // 00000041E04C: 4A2A2B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041E050: BF870121
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000041E054: 362C2AFF FFFFFE00
	v_ashrrev_i32_e32 v21, 9, v21                              // 00000041E05C: 342A2A89
	v_sub_nc_u32_e32 v22, v3, v22                              // 00000041E060: 4C2C2D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000041E064: BF870221
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000041E068: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 00000041E070: 4A302CFF FFFFFF00
	v_dual_cndmask_b32 v26, s24, v26 :: v_dual_lshlrev_b32 v21, 8, v21// 00000041E078: CA623418 1A142A88
	v_cndmask_b32_e32 v25, s25, v23, vcc_lo                    // 00000041E080: 02322E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E084: BF870193
	v_cndmask_b32_e32 v23, v24, v22, vcc_lo                    // 00000041E088: 022E2D18
	v_ashrrev_i32_e32 v22, 31, v21                             // 00000041E08C: 342C2A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E090: BF870112
	v_ashrrev_i32_e32 v24, 31, v23                             // 00000041E094: 34302E9F
	.long 0xd73c0015                                           // 00000041E098: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 00000041E09C: 02022A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E0A0: BF870112
	.long 0xd73c0017                                           // 00000041E0A4: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 00000041E0A8: 02022E81
	.long 0xd7006a15                                           // 00000041E0AC: D7006A15
	v_cndmask_b32_e32 v1, v26, v21, vcc_lo                     // 00000041E0B0: 02022B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E0B4: BF870111
	v_add_co_ci_u32_e64 v22, null, v25, v22, vcc_lo            // 00000041E0B8: D5207C16 01AA2D19
	.long 0xd7006a15                                           // 00000041E0C0: D7006A15
	v_cndmask_b32_e32 v1, v21, v23, vcc_lo                     // 00000041E0C4: 02022F15
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E0C8: BF870001
	v_add_co_ci_u32_e64 v22, null, v22, v24, vcc_lo            // 00000041E0CC: D5207C16 01AA3116
	global_store_d16_hi_b16 v[21:22], v20, off                 // 00000041E0D4: DC960000 007C1415
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000041E0DC: 916A027E
	s_cbranch_vccnz 7                                          // 00000041E0E0: BFA40007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2300>
	.long 0xd7006a15                                           // 00000041E0E4: D7006A15
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E0E8: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E0EC: BF870001
	v_add_co_ci_u32_e64 v22, null, s15, v2, vcc_lo             // 00000041E0F0: D5207C16 01AA040F
	global_store_d16_hi_b16 v[21:22], v20, off                 // 00000041E0F8: DC960000 007C1415
	global_load_d16_b16 v20, v[4:5], off offset:32             // 00000041E100: DC820020 147C0004
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 00000041E108: D501000A 2002150A
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000041E110: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E114: BF870091
	v_add_f32_e32 v10, v10, v19                                // 00000041E118: 0614270A
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 00000041E11C: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E124: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041E128: BF870121
	v_fma_mix_f32 v19, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 00000041E12C: CC200013 8A021514
	v_cndmask_b32_e64 v10, 0, 1, s1                            // 00000041E134: D501000A 00050280
	v_bfe_u32 v20, v19, 16, 1                                  // 00000041E13C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E144: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 00000041E148: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 467                                        // 00000041E154: BFA401D3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2aa4>
	v_or_b32_e32 v20, 16, v3                                   // 00000041E158: 38280690
	v_lshrrev_b32_e32 v21, 23, v0                              // 00000041E15C: 322A0097
	v_mov_b32_e32 v25, s14                                     // 00000041E160: 7E32020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E164: BF870092
	v_add_nc_u32_e32 v21, v20, v21                             // 00000041E168: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 00000041E16C: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E174: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 00000041E178: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 00000041E17C: 7C882CFF 00000100
	v_add_nc_u32_e32 v23, 0xffffff00, v22                      // 00000041E184: 4A2E2CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E18C: BF8701B1
	v_dual_cndmask_b32 v25, s24, v25 :: v_dual_cndmask_b32 v22, v23, v22// 00000041E190: CA523218 19162D17
	v_ashrrev_i32_e32 v20, 9, v21                              // 00000041E198: 34282A89
	v_mov_b32_e32 v21, s15                                     // 00000041E19C: 7E2A020F
	v_ashrrev_i32_e32 v23, 31, v22                             // 00000041E1A0: 342E2C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E1A4: BF870193
	v_lshlrev_b32_e32 v20, 8, v20                              // 00000041E1A8: 30282888
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 00000041E1AC: 02302A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E1B0: BF870193
	.long 0xd73c0016                                           // 00000041E1B4: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 00000041E1B8: 02022C81
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000041E1BC: 342A289F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E1C0: BF870091
	.long 0xd73c0014                                           // 00000041E1C4: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041E1C8: 02022881
	.long 0xd7006a14                                           // 00000041E1CC: D7006A14
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000041E1D0: 02022919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E1D4: BF870111
	v_add_co_ci_u32_e64 v21, null, v24, v21, vcc_lo            // 00000041E1D8: D5207C15 01AA2B18
	.long 0xd7006a14                                           // 00000041E1E0: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 00000041E1E4: 02022D14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E1E8: BF870001
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 00000041E1EC: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 00000041E1F4: DC960000 007C1314
	s_cbranch_execnz 7                                         // 00000041E1FC: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x241c>
	.long 0xd7006a14                                           // 00000041E200: D7006A14
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E204: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E208: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v2, vcc_lo             // 00000041E20C: D5207C15 01AA040F
	global_store_d16_hi_b16 v[20:21], v19, off offset:32       // 00000041E214: DC960020 007C1314
	global_load_d16_b16 v19, v[4:5], off offset:64             // 00000041E21C: DC820040 137C0004
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 00000041E224: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E22C: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E230: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 00000041E234: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E238: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 00000041E23C: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E244: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E248: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 00000041E24C: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 00000041E254: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E25C: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 00000041E260: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 398                                        // 00000041E26C: BFA4018E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2aa8>
	v_or_b32_e32 v18, 32, v3                                   // 00000041E270: 382406A0
	v_lshrrev_b32_e32 v19, 23, v0                              // 00000041E274: 32260097
	v_mov_b32_e32 v23, s14                                     // 00000041E278: 7E2E020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E27C: BF870092
	v_add_nc_u32_e32 v19, v18, v19                             // 00000041E280: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 00000041E284: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E28C: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 00000041E290: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 00000041E294: 7C8828FF 00000100
	v_add_nc_u32_e32 v21, 0xffffff00, v20                      // 00000041E29C: 4A2A28FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E2A4: BF8701B1
	v_dual_cndmask_b32 v23, s24, v23 :: v_dual_cndmask_b32 v20, v21, v20// 00000041E2A8: CA522E18 17142915
	v_ashrrev_i32_e32 v18, 9, v19                              // 00000041E2B0: 34242689
	v_mov_b32_e32 v19, s15                                     // 00000041E2B4: 7E26020F
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000041E2B8: 342A289F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E2BC: BF870193
	v_lshlrev_b32_e32 v18, 8, v18                              // 00000041E2C0: 30242488
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 00000041E2C4: 022C2619
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E2C8: BF870193
	.long 0xd73c0014                                           // 00000041E2CC: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 00000041E2D0: 02022881
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000041E2D4: 3426249F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E2D8: BF870091
	.long 0xd73c0012                                           // 00000041E2DC: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000041E2E0: 02022481
	.long 0xd7006a12                                           // 00000041E2E4: D7006A12
	v_cndmask_b32_e32 v1, v23, v18, vcc_lo                     // 00000041E2E8: 02022517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E2EC: BF870111
	v_add_co_ci_u32_e64 v19, null, v22, v19, vcc_lo            // 00000041E2F0: D5207C13 01AA2716
	.long 0xd7006a12                                           // 00000041E2F8: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 00000041E2FC: 02022912
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E300: BF870001
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 00000041E304: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 00000041E30C: DC960000 007C1112
	s_cbranch_execnz 7                                         // 00000041E314: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2534>
	.long 0xd7006a12                                           // 00000041E318: D7006A12
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E31C: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E320: BF870001
	v_add_co_ci_u32_e64 v19, null, s15, v2, vcc_lo             // 00000041E324: D5207C13 01AA040F
	global_store_d16_hi_b16 v[18:19], v17, off offset:64       // 00000041E32C: DC960040 007C1112
	global_load_d16_b16 v17, v[4:5], off offset:96             // 00000041E334: DC820060 117C0004
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 00000041E33C: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E344: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E348: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 00000041E34C: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E350: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 00000041E354: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E35C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E360: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 00000041E364: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 00000041E36C: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E374: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000041E378: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 329                                        // 00000041E384: BFA40149 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2aac>
	v_or_b32_e32 v16, 48, v3                                   // 00000041E388: 382006B0
	v_lshrrev_b32_e32 v17, 23, v0                              // 00000041E38C: 32220097
	v_mov_b32_e32 v21, s14                                     // 00000041E390: 7E2A020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E394: BF870092
	v_add_nc_u32_e32 v17, v16, v17                             // 00000041E398: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 00000041E39C: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E3A4: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 00000041E3A8: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 00000041E3AC: 7C8824FF 00000100
	v_add_nc_u32_e32 v19, 0xffffff00, v18                      // 00000041E3B4: 4A2624FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E3BC: BF8701B1
	v_dual_cndmask_b32 v21, s24, v21 :: v_dual_cndmask_b32 v18, v19, v18// 00000041E3C0: CA522A18 15122513
	v_ashrrev_i32_e32 v16, 9, v17                              // 00000041E3C8: 34202289
	v_mov_b32_e32 v17, s15                                     // 00000041E3CC: 7E22020F
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000041E3D0: 3426249F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E3D4: BF870193
	v_lshlrev_b32_e32 v16, 8, v16                              // 00000041E3D8: 30202088
	v_cndmask_b32_e32 v20, s25, v17, vcc_lo                    // 00000041E3DC: 02282219
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E3E0: BF870193
	.long 0xd73c0012                                           // 00000041E3E4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000041E3E8: 02022481
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000041E3EC: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E3F0: BF870091
	.long 0xd73c0010                                           // 00000041E3F4: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000041E3F8: 02022081
	.long 0xd7006a10                                           // 00000041E3FC: D7006A10
	v_cndmask_b32_e32 v1, v21, v16, vcc_lo                     // 00000041E400: 02022115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E404: BF870111
	v_add_co_ci_u32_e64 v17, null, v20, v17, vcc_lo            // 00000041E408: D5207C11 01AA2314
	.long 0xd7006a10                                           // 00000041E410: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 00000041E414: 02022510
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E418: BF870001
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 00000041E41C: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 00000041E424: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 00000041E42C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x264c>
	.long 0xd7006a10                                           // 00000041E430: D7006A10
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E434: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E438: BF870001
	v_add_co_ci_u32_e64 v17, null, s15, v2, vcc_lo             // 00000041E43C: D5207C11 01AA040F
	global_store_d16_hi_b16 v[16:17], v15, off offset:96       // 00000041E444: DC960060 007C0F10
	global_load_d16_b16 v15, v[4:5], off offset:128            // 00000041E44C: DC820080 0F7C0004
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 00000041E454: D501000D 20021B0D
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E45C: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E460: BF8700A2
	v_add_f32_e32 v13, v13, v14                                // 00000041E464: 061A1D0D
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E468: 8B6A6A7E
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 00000041E46C: 101A1AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E474: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E478: BF870091
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 00000041E47C: CC20000D 8A021B0F
	v_bfe_u32 v14, v13, 16, 1                                  // 00000041E484: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E48C: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 00000041E490: D655000D 03FE1D0D 00007FFF
	s_cbranch_vccnz 260                                        // 00000041E49C: BFA40104 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ab0>
	v_or_b32_e32 v14, 64, v3                                   // 00000041E4A0: 381C06C0
	v_lshrrev_b32_e32 v15, 23, v0                              // 00000041E4A4: 321E0097
	v_mov_b32_e32 v19, s14                                     // 00000041E4A8: 7E26020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E4AC: BF870092
	v_add_nc_u32_e32 v15, v14, v15                             // 00000041E4B0: 4A1E1F0E
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 00000041E4B4: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E4BC: BF870091
	v_sub_nc_u32_e32 v16, v14, v16                             // 00000041E4C0: 4C20210E
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v16                        // 00000041E4C4: 7C8820FF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v16                      // 00000041E4CC: 4A2220FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E4D4: BF8701B1
	v_dual_cndmask_b32 v19, s24, v19 :: v_dual_cndmask_b32 v16, v17, v16// 00000041E4D8: CA522618 13102111
	v_ashrrev_i32_e32 v14, 9, v15                              // 00000041E4E0: 341C1E89
	v_mov_b32_e32 v15, s15                                     // 00000041E4E4: 7E1E020F
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000041E4E8: 3422209F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E4EC: BF870193
	v_lshlrev_b32_e32 v14, 8, v14                              // 00000041E4F0: 301C1C88
	v_cndmask_b32_e32 v18, s25, v15, vcc_lo                    // 00000041E4F4: 02241E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E4F8: BF870193
	.long 0xd73c0010                                           // 00000041E4FC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000041E500: 02022081
	v_ashrrev_i32_e32 v15, 31, v14                             // 00000041E504: 341E1C9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E508: BF870091
	.long 0xd73c000e                                           // 00000041E50C: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000041E510: 02021C81
	.long 0xd7006a0e                                           // 00000041E514: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 00000041E518: 02021D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E51C: BF870111
	v_add_co_ci_u32_e64 v15, null, v18, v15, vcc_lo            // 00000041E520: D5207C0F 01AA1F12
	.long 0xd7006a0e                                           // 00000041E528: D7006A0E
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 00000041E52C: 0202210E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E530: BF870001
	v_add_co_ci_u32_e64 v15, null, v15, v17, vcc_lo            // 00000041E534: D5207C0F 01AA230F
	global_store_d16_hi_b16 v[14:15], v13, off                 // 00000041E53C: DC960000 007C0D0E
	s_cbranch_execnz 7                                         // 00000041E544: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2764>
	.long 0xd7006a0e                                           // 00000041E548: D7006A0E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E54C: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E550: BF870001
	v_add_co_ci_u32_e64 v15, null, s15, v2, vcc_lo             // 00000041E554: D5207C0F 01AA040F
	global_store_d16_hi_b16 v[14:15], v13, off offset:128      // 00000041E55C: DC960080 007C0D0E
	global_load_d16_b16 v13, v[4:5], off offset:160            // 00000041E564: DC8200A0 0D7C0004
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 00000041E56C: D501000B 2002170B
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E574: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E578: BF8700A2
	v_add_f32_e32 v11, v11, v12                                // 00000041E57C: 0616190B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E580: 8B6A6A7E
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 00000041E584: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E58C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E590: BF870091
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel_hi:[1,0,0]      // 00000041E594: CC20000B 8A02170D
	v_bfe_u32 v12, v11, 16, 1                                  // 00000041E59C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E5A4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 00000041E5A8: D655000B 03FE190B 00007FFF
	s_cbranch_vccnz 191                                        // 00000041E5B4: BFA400BF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ab4>
	v_or_b32_e32 v12, 0x50, v3                                 // 00000041E5B8: 381806FF 00000050
	v_lshrrev_b32_e32 v13, 23, v0                              // 00000041E5C0: 321A0097
	v_mov_b32_e32 v17, s14                                     // 00000041E5C4: 7E22020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E5C8: BF870092
	v_add_nc_u32_e32 v13, v12, v13                             // 00000041E5CC: 4A1A1B0C
	v_and_b32_e32 v14, 0xfffffe00, v13                         // 00000041E5D0: 361C1AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E5D8: BF870091
	v_sub_nc_u32_e32 v14, v12, v14                             // 00000041E5DC: 4C1C1D0C
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v14                        // 00000041E5E0: 7C881CFF 00000100
	v_add_nc_u32_e32 v15, 0xffffff00, v14                      // 00000041E5E8: 4A1E1CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E5F0: BF8701B1
	v_dual_cndmask_b32 v17, s24, v17 :: v_dual_cndmask_b32 v14, v15, v14// 00000041E5F4: CA522218 110E1D0F
	v_ashrrev_i32_e32 v12, 9, v13                              // 00000041E5FC: 34181A89
	v_mov_b32_e32 v13, s15                                     // 00000041E600: 7E1A020F
	v_ashrrev_i32_e32 v15, 31, v14                             // 00000041E604: 341E1C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E608: BF870193
	v_lshlrev_b32_e32 v12, 8, v12                              // 00000041E60C: 30181888
	v_cndmask_b32_e32 v16, s25, v13, vcc_lo                    // 00000041E610: 02201A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E614: BF870193
	.long 0xd73c000e                                           // 00000041E618: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000041E61C: 02021C81
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000041E620: 341A189F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E624: BF870091
	.long 0xd73c000c                                           // 00000041E628: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000041E62C: 02021881
	.long 0xd7006a0c                                           // 00000041E630: D7006A0C
	v_cndmask_b32_e32 v1, v17, v12, vcc_lo                     // 00000041E634: 02021911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E638: BF870111
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 00000041E63C: D5207C0D 01AA1B10
	.long 0xd7006a0c                                           // 00000041E644: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000041E648: 02021D0C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E64C: BF870001
	v_add_co_ci_u32_e64 v13, null, v13, v15, vcc_lo            // 00000041E650: D5207C0D 01AA1F0D
	global_store_d16_hi_b16 v[12:13], v11, off                 // 00000041E658: DC960000 007C0B0C
	s_cbranch_execnz 7                                         // 00000041E660: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2880>
	.long 0xd7006a0c                                           // 00000041E664: D7006A0C
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E668: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E66C: BF870001
	v_add_co_ci_u32_e64 v13, null, s15, v2, vcc_lo             // 00000041E670: D5207C0D 01AA040F
	global_store_d16_hi_b16 v[12:13], v11, off offset:160      // 00000041E678: DC9600A0 007C0B0C
	global_load_d16_b16 v11, v[4:5], off offset:192            // 00000041E680: DC8200C0 0B7C0004
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 00000041E688: D5010008 20021108
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E690: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E694: BF8700A2
	v_add_f32_e32 v8, v8, v9                                   // 00000041E698: 06101308
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E69C: 8B6A6A7E
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000041E6A0: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E6A8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E6AC: BF870091
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 00000041E6B0: CC200008 8A02110B
	v_bfe_u32 v9, v8, 16, 1                                    // 00000041E6B8: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E6C0: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000041E6C4: D6550008 03FE1308 00007FFF
	s_cbranch_vccnz 121                                        // 00000041E6D0: BFA40079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ab8>
	v_or_b32_e32 v9, 0x60, v3                                  // 00000041E6D4: 381206FF 00000060
	v_lshrrev_b32_e32 v11, 23, v0                              // 00000041E6DC: 32160097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E6E0: BF870091
	v_add_nc_u32_e32 v11, v9, v11                              // 00000041E6E4: 4A161709
	v_and_b32_e32 v12, 0xfffffe00, v11                         // 00000041E6E8: 361816FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E6F0: BF8701B1
	v_sub_nc_u32_e32 v9, v9, v12                               // 00000041E6F4: 4C121909
	v_mov_b32_e32 v12, s15                                     // 00000041E6F8: 7E18020F
	v_ashrrev_i32_e32 v11, 9, v11                              // 00000041E6FC: 34161689
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v9                         // 00000041E700: 7C8812FF 00000100
	v_add_nc_u32_e32 v13, 0xffffff00, v9                       // 00000041E708: 4A1A12FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041E710: BF8701A3
	v_lshlrev_b32_e32 v11, 8, v11                              // 00000041E714: 30161688
	v_cndmask_b32_e32 v15, s25, v12, vcc_lo                    // 00000041E718: 021E1819
	v_cndmask_b32_e32 v13, v13, v9, vcc_lo                     // 00000041E71C: 021A130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041E720: BF8701A3
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000041E724: 3418169F
	v_mov_b32_e32 v9, s14                                      // 00000041E728: 7E12020E
	v_ashrrev_i32_e32 v14, 31, v13                             // 00000041E72C: 341C1A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E730: BF870193
	.long 0xd73c000b                                           // 00000041E734: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000041E738: 02021681
	v_cndmask_b32_e32 v9, s24, v9, vcc_lo                      // 00000041E73C: 02121218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E740: BF870113
	.long 0xd73c000d                                           // 00000041E744: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 00000041E748: 02021A81
	.long 0xd7006a09                                           // 00000041E74C: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000041E750: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E754: BF870111
	v_add_co_ci_u32_e64 v12, null, v15, v12, vcc_lo            // 00000041E758: D5207C0C 01AA190F
	.long 0xd7006a0b                                           // 00000041E760: D7006A0B
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 00000041E764: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E768: BF870001
	v_add_co_ci_u32_e64 v12, null, v12, v14, vcc_lo            // 00000041E76C: D5207C0C 01AA1D0C
	global_store_d16_hi_b16 v[11:12], v8, off                  // 00000041E774: DC960000 007C080B
	s_cbranch_execnz 7                                         // 00000041E77C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x299c>
	.long 0xd7006a0b                                           // 00000041E780: D7006A0B
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E784: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E788: BF870001
	v_add_co_ci_u32_e64 v12, null, s15, v2, vcc_lo             // 00000041E78C: D5207C0C 01AA040F
	global_store_d16_hi_b16 v[11:12], v8, off offset:192       // 00000041E794: DC9600C0 007C080B
	global_load_d16_b16 v4, v[4:5], off offset:224             // 00000041E79C: DC8200E0 047C0004
	v_cndmask_b32_e64 v5, -v6, v6, s0                          // 00000041E7A4: D5010005 20020D06
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041E7AC: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041E7B0: BF8700A2
	v_add_f32_e32 v5, v5, v7                                   // 00000041E7B4: 060A0F05
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041E7B8: 8B6A6A7E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 00000041E7BC: 100A0AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000041E7C4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E7C8: BF870091
	v_fma_mix_f32 v4, v4, v5, neg(0) op_sel_hi:[1,0,0]         // 00000041E7CC: CC200004 8A020B04
	v_bfe_u32 v5, v4, 16, 1                                    // 00000041E7D4: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E7DC: BF870001
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000041E7E0: D6550004 03FE0B04 00007FFF
	s_cbranch_vccnz 51                                         // 00000041E7EC: BFA40033 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2abc>
	v_or_b32_e32 v3, 0x70, v3                                  // 00000041E7F0: 380606FF 00000070
	v_lshrrev_b32_e32 v0, 23, v0                               // 00000041E7F8: 32000097
	v_mov_b32_e32 v6, s15                                      // 00000041E7FC: 7E0C020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E800: BF870092
	v_add_nc_u32_e32 v0, v3, v0                                // 00000041E804: 4A000103
	v_and_b32_e32 v5, 0xfffffe00, v0                           // 00000041E808: 360A00FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E810: BF870091
	v_sub_nc_u32_e32 v3, v3, v5                                // 00000041E814: 4C060B03
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 00000041E818: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 00000041E820: 4A0E06FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000041E828: BF8701B1
	v_cndmask_b32_e32 v7, v7, v3, vcc_lo                       // 00000041E82C: 020E0707
	v_mov_b32_e32 v3, s14                                      // 00000041E830: 7E06020E
	v_ashrrev_i32_e32 v0, 9, v0                                // 00000041E834: 34000089
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000041E838: 34100E9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041E83C: BF870193
	v_cndmask_b32_e32 v3, s24, v3, vcc_lo                      // 00000041E840: 02060618
	v_dual_cndmask_b32 v0, s25, v6 :: v_dual_lshlrev_b32 v5, 8, v0// 00000041E844: CA620C19 00040088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E84C: BF870113
	.long 0xd73c0007                                           // 00000041E850: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000041E854: 02020E81
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000041E858: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041E85C: BF870091
	.long 0xd73c0005                                           // 00000041E860: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000041E864: 02020A81
	.long 0xd7006a03                                           // 00000041E868: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000041E86C: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041E870: BF870111
	v_add_co_ci_u32_e64 v0, null, v0, v6, vcc_lo               // 00000041E874: D5207C00 01AA0D00
	.long 0xd7006a05                                           // 00000041E87C: D7006A05
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000041E880: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E884: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v8, vcc_lo               // 00000041E888: D5207C06 01AA1100
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000041E890: DC960000 007C0405
	s_cbranch_execnz 63060                                     // 00000041E898: BFA6F654 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 00000041E89C: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2abc>
	s_branch 65040                                             // 00000041E8A0: BFA0FE10 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x22e4>
	s_branch 65110                                             // 00000041E8A4: BFA0FE56 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2400>
	s_branch 65179                                             // 00000041E8A8: BFA0FE9B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2518>
	s_branch 65248                                             // 00000041E8AC: BFA0FEE0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2630>
	s_branch 65317                                             // 00000041E8B0: BFA0FF25 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2748>
	s_branch 65387                                             // 00000041E8B4: BFA0FF6B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2864>
	s_branch 65457                                             // 00000041E8B8: BFA0FFB1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb0ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2980>
	.long 0xd7006a00                                           // 00000041E8BC: D7006A00
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000041E8C0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041E8C4: BF870001
	v_add_co_ci_u32_e64 v1, null, s15, v2, vcc_lo              // 00000041E8C8: D5207C01 01AA040F
	global_store_d16_hi_b16 v[0:1], v4, off offset:224         // 00000041E8D0: DC9600E0 007C0400
	s_endpgm                                                   // 00000041E8D8: BFB00000
		...

