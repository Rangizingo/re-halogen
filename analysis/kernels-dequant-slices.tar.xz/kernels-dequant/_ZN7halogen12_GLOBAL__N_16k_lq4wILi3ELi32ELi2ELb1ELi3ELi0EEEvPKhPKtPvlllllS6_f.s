000000000083cf00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000083CF00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 00000083CF08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000083CF10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 00000083CF14: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000083CF18: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 00000083CF1C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083CF20: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 00000083CF24: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000083CF2C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 00000083CF30: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 00000083CF34: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000083CF3C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 00000083CF40: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 00000083CF44: BF89FC07
	s_clause 0x1                                               // 00000083CF48: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000083CF4C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 00000083CF54: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 00000083CF5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000083CF60: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000083CF64: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 00000083CF68: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000083CF6C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000083CF70: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 00000083CF74: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000083CF78: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 00000083CF7C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 00000083CF80: CA640680 0310009F
	s_add_u32 s22, s10, s22                                    // 00000083CF88: 8016160A
	s_addc_u32 s23, s11, 0                                     // 00000083CF8C: 8217800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 00000083CF90: D5010004 01A82A80
	s_lshr_b64 s[22:23], s[22:23], 5                           // 00000083CF98: 85968516
	.long 0xd72c0008                                           // 00000083CF9C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 00000083CFA0: 02020613
	s_add_i32 s23, s22, 1                                      // 00000083CFA4: 81178116
	.long 0xd72c000d                                           // 00000083CFA8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 00000083CFAC: 02001F03
	s_lshr_b32 s19, s23, 31                                    // 00000083CFB0: 85139F17
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 00000083CFB4: D6FE7C09 00081D03
	s_add_i32 s23, s23, s19                                    // 00000083CFBC: 81171317
	.long 0xd72c0015                                           // 00000083CFC0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 00000083CFC4: 02001D04
	s_ashr_i32 s15, s23, 1                                     // 00000083CFC8: 860F8117
	s_add_u32 s2, s4, s16                                      // 00000083CFCC: 80021004
	.long 0xd72c0013                                           // 00000083CFD0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 00000083CFD4: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 00000083CFD8: 82031105
	.long 0xd72c0016                                           // 00000083CFDC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 00000083CFE0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000083CFE4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083CFEC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 00000083CFF0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 00000083CFF8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 00000083CFFC: 4A262113
	s_waitcnt vmcnt(1)                                         // 00000083D000: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 00000083D004: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 00000083D00C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 00000083D010: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083D018: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 00000083D01C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 00000083D028: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000083D030: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 00000083D03C: 7E060280
	v_min_i32_e32 v20, s22, v4                                 // 00000083D040: 22280816
	.long 0x7e0e3985                                           // 00000083D044: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 00000083D048: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 00000083D050: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083D058: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 00000083D05C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000083D068: 7C822913
	ds_store_b32 v5, v6                                        // 00000083D06C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 00000083D074: BF89FC07
	s_barrier                                                  // 00000083D078: BFBD0000
	buffer_gl0_inv                                             // 00000083D07C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 00000083D084: BE83206A
	s_cbranch_execz 21                                         // 00000083D088: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000083D08C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 00000083D090: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083D094: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000083D098: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000083D09C: 3408069F
	.long 0xd7000201                                           // 00000083D0A0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000083D0A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083D0A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 00000083D0AC: D5207C02 000A0515
	.long 0xd7000203                                           // 00000083D0B4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000083D0B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 00000083D0BC: D5207C04 000A090A
	s_clause 0x1                                               // 00000083D0C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 00000083D0C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000083D0D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000083D0D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 00000083D0DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083D0E0: 8C7E037E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000083D0E4: CA100080 17160080
	s_and_saveexec_b32 s3, vcc_lo                              // 00000083D0EC: BE83206A
	s_cbranch_execz 314                                        // 00000083D0F0: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x6dc>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 00000083D0F4: CA200080 160426A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 00000083D0FC: CA220080 170C2685
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000083D104: 8484820A
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083D108: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 00000083D10C: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 00000083D114: CA220112 1A180A81
	s_mov_b32 s14, 0                                           // 00000083D11C: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000083D120: 848A810A
	s_branch 269                                               // 00000083D124: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x65c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000083D128: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000083D12C: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 00000083D130: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 00000083D134: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 00000083D138: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 00000083D140: 329C0486
	.long 0xd73c001b                                           // 00000083D144: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000083D148: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 00000083D14C: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 00000083D154: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 00000083D15C: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 00000083D164: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 00000083D168: 329E048E
	.long 0xd700023f                                           // 00000083D16C: D700023F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 00000083D170: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083D174: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s2                 // 00000083D178: D5207C40 000A3807
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000083D180: 301A1A82
	.long 0xd7000243                                           // 00000083D184: D7000243
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 00000083D188: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083D18C: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s2                // 00000083D190: D5207C44 000A800B
	.long 0xd7000247                                           // 00000083D198: D7000247
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 00000083D19C: 0200093F
	v_add_co_ci_u32_e64 v72, null, s5, v64, s2                 // 00000083D1A0: D5207C48 000A8005
	s_clause 0xb                                               // 00000083D1A8: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 00000083D1AC: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 00000083D1B4: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 00000083D1BC: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 00000083D1C4: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 00000083D1CC: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 00000083D1D4: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 00000083D1DC: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 00000083D1E4: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 00000083D1EC: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 00000083D1F4: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 00000083D1FC: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 00000083D204: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 00000083D20C: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 00000083D214: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 00000083D21C: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 00000083D224: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 00000083D228: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 00000083D230: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 00000083D234: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 00000083D23C: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000083D244: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 00000083D24C: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 00000083D254: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 00000083D25C: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 00000083D264: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 00000083D26C: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 00000083D274: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 00000083D27C: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 00000083D280: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 00000083D284: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 00000083D288: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 00000083D290: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 00000083D294: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 00000083D29C: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000083D2A0: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000083D2A8: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 00000083D2B0: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083D2B4: BF870009
	s_or_b32 s14, s2, s14                                      // 00000083D2B8: 8C0E0E02
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 00000083D2BC: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 00000083D2C0: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 00000083D2C8: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 00000083D2CC: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 00000083D2D4: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 00000083D2D8: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 00000083D2E0: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 00000083D2E4: 32080896
	s_waitcnt lgkmcnt(6)                                       // 00000083D2E8: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 00000083D2EC: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 00000083D2F4: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 00000083D2FC: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 00000083D304: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 00000083D308: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000083D310: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 00000083D314: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 00000083D31C: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 00000083D324: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 00000083D32C: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 00000083D334: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 00000083D33C: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 00000083D340: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 00000083D348: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 00000083D350: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 00000083D358: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 00000083D360: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 00000083D368: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 00000083D36C: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 00000083D374: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 00000083D378: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 00000083D380: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 00000083D384: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 00000083D38C: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 00000083D390: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 00000083D398: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 00000083D39C: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 00000083D3A4: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 00000083D3AC: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 00000083D3B4: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000083D3BC: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 00000083D3C4: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 00000083D3C8: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 00000083D3D0: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 00000083D3D8: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 00000083D3E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D3E4: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 00000083D3E8: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 00000083D3F0: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083D3F8: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 00000083D3FC: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 00000083D404: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 00000083D40C: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 00000083D414: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 00000083D41C: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 00000083D424: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 00000083D42C: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 00000083D430: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 00000083D438: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 00000083D43C: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 00000083D444: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 00000083D448: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 00000083D450: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 00000083D454: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 00000083D45C: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D464: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 00000083D468: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 00000083D470: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D478: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 00000083D47C: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 00000083D484: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 00000083D48C: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D490: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 00000083D494: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 00000083D49C: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083D4A4: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 00000083D4A8: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 00000083D4B0: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 00000083D4B4: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 00000083D4BC: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 00000083D4C0: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 00000083D4C8: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 00000083D4CC: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 00000083D4D4: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 00000083D4D8: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 00000083D4E0: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083D4E8: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 00000083D4EC: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 00000083D4F4: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 00000083D4F8: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 00000083D4FC: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 00000083D504: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 00000083D50C: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 00000083D514: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 00000083D51C: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 00000083D520: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 00000083D528: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 00000083D530: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D538: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 00000083D53C: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 00000083D544: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083D548: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 00000083D54C: 56221112
	v_mov_b32_e32 v18, v26                                     // 00000083D550: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 00000083D554: 917E0E7E
	s_cbranch_execz 31                                         // 00000083D558: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x6d8>
	s_waitcnt vmcnt(0)                                         // 00000083D55C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 00000083D560: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 00000083D568: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 00000083D570: 7E0E0303
	s_mov_b32 s15, exec_lo                                     // 00000083D574: BE8F007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000083D578: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 00000083D57C: 7C8C2913
	.long 0xd4c1007e                                           // 00000083D580: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000083D584: 02022913
	s_cbranch_execz 65255                                      // 00000083D588: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	v_ashrrev_i32_e32 v6, 31, v25                              // 00000083D58C: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 00000083D590: 3410309F
	.long 0xd7000205                                           // 00000083D594: D7000205
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 00000083D598: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083D59C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 00000083D5A0: D5207C06 000A0D15
	.long 0xd7000207                                           // 00000083D5A8: D7000207
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 00000083D5AC: 02023109
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 00000083D5B0: D5207C08 000A110A
	s_clause 0x1                                               // 00000083D5B8: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 00000083D5BC: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 00000083D5C4: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 00000083D5CC: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 00000083D5D0: 7E34170D
	s_branch 65236                                             // 00000083D5D4: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000083D5D8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000083D5DC: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000083D5E0: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 00000083D5E4: BF8903F7
	.long 0xd71f0001                                           // 00000083D5E8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000083D5EC: 020100C1
	s_mov_b32 s2, exec_lo                                      // 00000083D5F0: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000083D5F4: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 00000083D5F8: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 00000083D5FC: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000083D600: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000083D604: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000083D608: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000083D60C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 00000083D610: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083D614: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000083D618: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000083D61C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000083D620: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 00000083D624: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 00000083D62C: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 00000083D630: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 00000083D634: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 00000083D63C: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 00000083D644: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000083D64C: 02101101
	s_waitcnt lgkmcnt(2)                                       // 00000083D650: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 00000083D654: 06080917
	s_waitcnt lgkmcnt(0)                                       // 00000083D658: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000083D65C: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 00000083D660: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 00000083D668: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000083D66C: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 00000083D670: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 00000083D678: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 00000083D67C: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 00000083D680: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 00000083D688: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000083D68C: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 00000083D690: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 00000083D694: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 00000083D69C: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 00000083D6A4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000083D6A8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083D6AC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000083D6B0: 02101101
	s_waitcnt lgkmcnt(1)                                       // 00000083D6B4: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 00000083D6B8: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 00000083D6C0: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000083D6C4: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 00000083D6C8: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 00000083D6D0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 00000083D6D8: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 00000083D6E0: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000083D6E4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000083D6E8: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000083D6EC: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000083D6F0: 30100282
	s_waitcnt lgkmcnt(1)                                       // 00000083D6F4: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 00000083D6F8: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 00000083D6FC: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 00000083D700: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 00000083D708: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 00000083D710: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 00000083D718: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 00000083D720: 7D942080
	s_cbranch_execz 15                                         // 00000083D724: BFA5000F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x864>
	.long 0xd72c0007                                           // 00000083D728: D72C0007
	v_cndmask_b32_e32 v0, v14, v152, vcc_lo                    // 00000083D72C: 0201310E
	s_waitcnt lgkmcnt(0)                                       // 00000083D730: BF89FC07
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 00000083D734: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D73C: BF870092
	v_mad_u32_u24 v7, v15, 12, v7                              // 00000083D740: D60B0007 041D190F
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 00000083D748: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 00000083D754: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 00000083D75C: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s2                              // 00000083D764: 8C7E027E
	.long 0xd7050001                                           // 00000083D768: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000083D76C: 020200FF 000000AB
	.long 0x7f063880                                           // 00000083D774: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 00000083D778: BF89FC07
	s_barrier                                                  // 00000083D77C: BFBD0000
	buffer_gl0_inv                                             // 00000083D780: E0AC0000 00000000
	.long 0xd7390003                                           // 00000083D788: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 00000083D78C: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D790: BF870091
	.long 0xd7000201                                           // 00000083D794: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 00000083D798: 02020614
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 00000083D79C: D5207C02 00090015
	.long 0xd44c0002                                           // 00000083D7A4: D44C0002
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 00000083D7A8: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000083D7AC: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000083D7B0: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 00000083D7B4: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 00000083D7B8: BE832002
	s_cbranch_execz 81                                         // 00000083D7BC: BFA50051 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xa04>
	.long 0xd7054000                                           // 00000083D7C0: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 00000083D7C4: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 00000083D7C8: 16060698
	s_load_b32 s0, s[0:1], 0x48                                // 00000083D7CC: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D7D4: BF870092
	.long 0xd7041000                                           // 00000083D7D8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000083D7DC: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000083D7E0: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D7E8: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000083D7EC: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000083D7F4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:3                     // 00000083D7FC: D8DC0300 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000083D804: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 00000083D808: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D80C: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 00000083D810: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 00000083D814: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D81C: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000083D820: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000083D82C: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D834: BF870091
	v_mul_f32_e32 v3, s0, v3                                   // 00000083D838: 10060600
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000083D83C: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000083D844: BF870291
	v_exp_f32_e32 v3, v3                                       // 00000083D848: 7E064B03
	v_add_f32_e32 v6, 1.0, v3                                  // 00000083D84C: 060C06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000083D850: BF870121
	v_div_scale_f32 v7, null, v6, v6, 1.0                      // 00000083D854: D6FC7C07 03CA0D06
	v_div_scale_f32 v9, vcc_lo, 1.0, v6, 1.0                   // 00000083D85C: D6FC6A09 03CA0CF2
	v_rcp_f32_e32 v8, v7                                       // 00000083D864: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D868: BF870095
	v_fma_f32 v3, -v7, v8, 1.0                                 // 00000083D86C: D6130003 23CA1107
	v_fmac_f32_e32 v8, v3, v8                                  // 00000083D874: 56101103
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000083D878: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083D880: BF870092
	v_mul_f32_e32 v10, v9, v8                                  // 00000083D884: 10141109
	v_fma_f32 v5, -v7, v10, v9                                 // 00000083D888: D6130005 24261507
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000083D890: BF870211
	v_fmac_f32_e32 v10, v5, v8                                 // 00000083D894: 56141105
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000083D898: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083D8A0: BF870112
	v_fma_f32 v0, -v7, v10, v9                                 // 00000083D8A4: D6130000 24261507
	.long 0xd73c0003                                           // 00000083D8AC: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000083D8B0: 02020682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083D8B4: BF8701A2
	v_div_fmas_f32 v5, v0, v8, v10                             // 00000083D8B8: D6370005 042A1100
	.long 0xd73c0000                                           // 00000083D8C0: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000083D8C4: 02020282
	.long 0xd7006a03                                           // 00000083D8C8: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000083D8CC: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000083D8D0: BF8701A3
	v_div_fixup_f32 v2, v5, v6, 1.0                            // 00000083D8D4: D6270002 03CA0D05
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000083D8DC: D5207C04 01AA0809
	.long 0xd7006a00                                           // 00000083D8E4: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000083D8E8: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000083D8EC: BF870193
	v_add_f32_e32 v2, v2, v2                                   // 00000083D8F0: 06040502
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000083D8F4: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 00000083D8FC: DC6A0000 007C0200
	s_endpgm                                                   // 00000083D904: BFB00000
		...

