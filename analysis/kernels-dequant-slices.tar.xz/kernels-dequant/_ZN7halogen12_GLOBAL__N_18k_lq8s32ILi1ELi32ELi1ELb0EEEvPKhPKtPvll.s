0000000000581000 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000581000: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000581004: F40C0100 F8000000
	s_load_b64 s[0:1], s[0:1], 0x20                            // 00000058100C: F4040000 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000581014: 32020085
	s_mov_b32 s3, 0                                            // 000000581018: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000058101C: CA240080 100E009F
	s_lshl_b64 s[12:13], s[2:3], 3                             // 000000581024: 848C8302
	.long 0x7e283880                                           // 000000581028: 7E283880
	v_or_b32_e32 v9, s12, v1                                   // 00000058102C: 3812020C
	v_dual_mov_b32 v10, s13 :: v_dual_mov_b32 v3, 0            // 000000581030: CA10000D 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 000000581038: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 00000058103C: BF89FC07
	s_ashr_i32 s2, s11, 31                                     // 000000581040: 86029F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000581044: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[0:1], v[9:10]                   // 000000581048: 7CA81200
	s_lshr_b32 s0, s2, 28                                      // 00000058104C: 85009C02
	s_add_u32 s0, s10, s0                                      // 000000581050: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000581054: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000581058: BF870009
	s_ashr_i64 s[2:3], s[0:1], 4                               // 00000058105C: 86828400
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000581060: 02021280
	s_add_u32 s0, s10, s2                                      // 000000581064: 8000020A
	v_cndmask_b32_e64 v2, 0, s13, vcc_lo                       // 000000581068: D5010002 01A81A80
	s_addc_u32 s1, s11, s3                                     // 000000581070: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000581074: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000581078: 82018001
	s_and_b32 s0, s0, -16                                      // 00000058107C: 8B00D000
	.long 0xd72c0004                                           // 000000581080: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000581084: 02000301
	.long 0xd72c0007                                           // 000000581088: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000058108C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 000000581090: D6FE7C05 02000101
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000581098: CA100080 01020080
	.long 0xd4440000                                           // 0000005810A0: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000005810A4: 02021E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005810A8: BF870213
	v_add3_u32 v6, v6, v4, v7                                  // 0000005810AC: D6550006 041E0906
	.long 0xd7000111                                           // 0000005810B4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000005810B8: 02020A04
	v_mov_b32_e32 v4, 0                                        // 0000005810BC: 7E080280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005810C0: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000005810C4: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000005810CC: BE832000
	s_cbranch_execz 21                                         // 0000005810D0: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x128>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000005810D4: 30021E84
	.long 0xd7000103                                           // 0000005810D8: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000005810DC: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 0000005810E0: 360E009E
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000005810E4: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005810EC: BF870094
	.long 0xd7000101                                           // 0000005810F0: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000005810F4: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000005810F8: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000581100: BF870094
	.long 0xd7000107                                           // 000000581104: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000581108: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 00000058110C: D5207C08 00060880
	s_clause 0x1                                               // 000000581114: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000581118: DC5E0000 017C0001
	global_load_d16_b16 v20, v[7:8], off                       // 000000581120: DC820000 147C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 000000581128: 8C7E037E
	s_and_saveexec_b32 s3, s0                                  // 00000058112C: BE832000
	s_cbranch_execz 298                                        // 000000581130: BFA5012A <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x5dc>
	v_and_or_b32 v0, v0, 30, 32                                // 000000581134: D6570000 02813D00
	.long 0xd7000005                                           // 00000058113C: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000581140: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000581144: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 000000581148: D5207C06 00020C0B
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v19, v15           // 000000581150: CA100080 0C12010F
	.long 0xd7000000                                           // 000000581158: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000058115C: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000581160: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 000000581164: D5207C05 00020C80
	v_mov_b32_e32 v16, v12                                     // 00000058116C: 7E20030C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000581170: BF870093
	.long 0xd700000d                                           // 000000581174: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000581178: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 00000058117C: D5207C0E 00020A05
	s_mov_b32 s4, 0                                            // 000000581184: BE840080
	s_branch 246                                               // 000000581188: BFA000F6 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x564>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000058118C: 8C7E057E
	.long 0xd73c0016                                           // 000000581190: D73C0016
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000581194: 02021681
	v_bfe_i32 v11, v1, 0, 8                                    // 000000581198: D611000B 02210101
	v_bfe_i32 v30, v1, 8, 8                                    // 0000005811A0: D611001E 02211101
	v_bfe_i32 v31, v1, 16, 8                                   // 0000005811A8: D611001F 02212101
	.long 0x7f283880                                           // 0000005811B0: 7F283880
	v_ashrrev_i32_e32 v1, 24, v1                               // 0000005811B4: 34020298
	.long 0xd700011a                                           // 0000005811B8: D700011A
	v_cndmask_b32_e32 v1, s6, v22, vcc_lo                      // 0000005811BC: 02022C06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005811C0: BF870001
	v_add_co_ci_u32_e64 v27, null, s7, v23, s1                 // 0000005811C4: D5207C1B 00062E07
	v_cvt_f32_i32_e32 v11, v11                                 // 0000005811CC: 7E160B0B
	v_bfe_i32 v32, v2, 0, 8                                    // 0000005811D0: D6110020 02210102
	v_cvt_f32_i32_e32 v30, v30                                 // 0000005811D8: 7E3C0B1E
	s_clause 0x1                                               // 0000005811DC: BF850001
	global_load_b128 v[22:25], v[26:27], off                   // 0000005811E0: DC5E0000 167C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 0000005811E8: DC5E0010 1A7C001A
	v_cvt_f32_i32_e32 v31, v31                                 // 0000005811F0: 7E3E0B1F
	v_fma_mix_f32 v11, v20, v11, neg(0) op_sel_hi:[1,0,0]      // 0000005811F4: CC20000B 8A021714
	v_bfe_i32 v33, v2, 8, 8                                    // 0000005811FC: D6110021 02211102
	v_bfe_i32 v34, v2, 16, 8                                   // 000000581204: D6110022 02212102
	v_ashrrev_i32_e32 v2, 24, v2                               // 00000058120C: 34040498
	v_bfe_i32 v35, v3, 0, 8                                    // 000000581210: D6110023 02210103
	v_bfe_i32 v36, v3, 8, 8                                    // 000000581218: D6110024 02211103
	v_bfe_i32 v37, v3, 16, 8                                   // 000000581220: D6110025 02212103
	v_ashrrev_i32_e32 v3, 24, v3                               // 000000581228: 34060698
	v_bfe_i32 v38, v4, 0, 8                                    // 00000058122C: D6110026 02210104
	v_bfe_i32 v39, v4, 8, 8                                    // 000000581234: D6110027 02211104
	v_bfe_i32 v40, v4, 16, 8                                   // 00000058123C: D6110028 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000581244: 34080898
	v_cvt_f32_i32_e32 v1, v1                                   // 000000581248: 7E020B01
	v_cvt_f32_i32_e32 v32, v32                                 // 00000058124C: 7E400B20
	v_fma_mix_f32 v30, v20, v30, neg(0) op_sel_hi:[1,0,0]      // 000000581250: CC20001E 8A023D14
	v_fma_mix_f32 v31, v20, v31, neg(0) op_sel_hi:[1,0,0]      // 000000581258: CC20001F 8A023F14
	v_bfe_u32 v44, v11, 16, 1                                  // 000000581260: D610002C 0205210B
	v_cvt_f32_i32_e32 v33, v33                                 // 000000581268: 7E420B21
	v_cvt_f32_i32_e32 v34, v34                                 // 00000058126C: 7E440B22
	v_cvt_f32_i32_e32 v2, v2                                   // 000000581270: 7E040B02
	v_cvt_f32_i32_e32 v35, v35                                 // 000000581274: 7E460B23
	v_cvt_f32_i32_e32 v36, v36                                 // 000000581278: 7E480B24
	v_cvt_f32_i32_e32 v37, v37                                 // 00000058127C: 7E4A0B25
	v_cvt_f32_i32_e32 v3, v3                                   // 000000581280: 7E060B03
	v_cvt_f32_i32_e32 v38, v38                                 // 000000581284: 7E4C0B26
	v_cvt_f32_i32_e32 v39, v39                                 // 000000581288: 7E4E0B27
	v_cvt_f32_i32_e32 v40, v40                                 // 00000058128C: 7E500B28
	v_cvt_f32_i32_e32 v4, v4                                   // 000000581290: 7E080B04
	v_fma_mix_f32 v1, v20, v1, neg(0) op_sel_hi:[1,0,0]        // 000000581294: CC200001 8A020314
	v_fma_mix_f32 v32, v20, v32, neg(0) op_sel_hi:[1,0,0]      // 00000058129C: CC200020 8A024114
	v_bfe_u32 v45, v30, 16, 1                                  // 0000005812A4: D610002D 0205211E
	v_bfe_u32 v46, v31, 16, 1                                  // 0000005812AC: D610002E 0205211F
	v_add3_u32 v11, v11, v44, 0x7fff                           // 0000005812B4: D655000B 03FE590B 00007FFF
	v_fma_mix_f32 v33, v20, v33, neg(0) op_sel_hi:[1,0,0]      // 0000005812C0: CC200021 8A024314
	v_fma_mix_f32 v34, v20, v34, neg(0) op_sel_hi:[1,0,0]      // 0000005812C8: CC200022 8A024514
	v_fma_mix_f32 v2, v20, v2, neg(0) op_sel_hi:[1,0,0]        // 0000005812D0: CC200002 8A020514
	v_fma_mix_f32 v35, v20, v35, neg(0) op_sel_hi:[1,0,0]      // 0000005812D8: CC200023 8A024714
	v_fma_mix_f32 v36, v20, v36, neg(0) op_sel_hi:[1,0,0]      // 0000005812E0: CC200024 8A024914
	v_fma_mix_f32 v37, v20, v37, neg(0) op_sel_hi:[1,0,0]      // 0000005812E8: CC200025 8A024B14
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 0000005812F0: CC200003 8A020714
	v_fma_mix_f32 v38, v20, v38, neg(0) op_sel_hi:[1,0,0]      // 0000005812F8: CC200026 8A024D14
	v_fma_mix_f32 v39, v20, v39, neg(0) op_sel_hi:[1,0,0]      // 000000581300: CC200027 8A024F14
	v_fma_mix_f32 v40, v20, v40, neg(0) op_sel_hi:[1,0,0]      // 000000581308: CC200028 8A025114
	v_fma_mix_f32 v4, v20, v4, neg(0) op_sel_hi:[1,0,0]        // 000000581310: CC200004 8A020914
	v_bfe_u32 v47, v1, 16, 1                                   // 000000581318: D610002F 02052101
	v_bfe_u32 v48, v32, 16, 1                                  // 000000581320: D6100030 02052120
	v_add3_u32 v31, v31, v46, 0x7fff                           // 000000581328: D655001F 03FE5D1F 00007FFF
	v_add3_u32 v30, v30, v45, 0x7fff                           // 000000581334: D655001E 03FE5B1E 00007FFF
	.long 0x7e28398b                                           // 000000581340: 7E28398B
	.long 0x7f523994                                           // 000000581344: 7F523994
	v_bfe_u32 v49, v33, 16, 1                                  // 000000581348: D6100031 02052121
	v_bfe_u32 v50, v34, 16, 1                                  // 000000581350: D6100032 02052122
	v_add3_u32 v1, v1, v47, 0x7fff                             // 000000581358: D6550001 03FE5F01 00007FFF
	.long 0x7e52399f                                           // 000000581364: 7E52399F
	v_add3_u32 v31, v32, v48, 0x7fff                           // 000000581368: D655001F 03FE6120 00007FFF
	v_and_or_b32 v30, 0xffff0000, v30, v20                     // 000000581374: D657001E 04523CFF FFFF0000
	v_bfe_u32 v51, v2, 16, 1                                   // 000000581380: D6100033 02052102
	v_bfe_u32 v52, v35, 16, 1                                  // 000000581388: D6100034 02052123
	v_add3_u32 v32, v33, v49, 0x7fff                           // 000000581390: D6550020 03FE6321 00007FFF
	v_add3_u32 v33, v34, v50, 0x7fff                           // 00000058139C: D6550021 03FE6522 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v41                       // 0000005813A8: D6570001 04A602FF FFFF0000
	.long 0x7e28399f                                           // 0000005813B4: 7E28399F
	.long 0x7f543994                                           // 0000005813B8: 7F543994
	v_bfe_u32 v53, v36, 16, 1                                  // 0000005813BC: D6100035 02052124
	v_bfe_u32 v54, v37, 16, 1                                  // 0000005813C4: D6100036 02052125
	v_add3_u32 v2, v2, v51, 0x7fff                             // 0000005813CC: D6550002 03FE6702 00007FFF
	.long 0x7e5439a1                                           // 0000005813D8: 7E5439A1
	v_and_or_b32 v31, 0xffff0000, v32, v20                     // 0000005813DC: D657001F 045240FF FFFF0000
	v_bfe_u32 v55, v3, 16, 1                                   // 0000005813E8: D6100037 02052103
	v_bfe_u32 v56, v38, 16, 1                                  // 0000005813F0: D6100038 02052126
	.long 0x7f563994                                           // 0000005813F8: 7F563994
	v_and_or_b32 v2, 0xffff0000, v2, v42                       // 0000005813FC: D6570002 04AA04FF FFFF0000
	v_bfe_u32 v44, v39, 16, 1                                  // 000000581408: D610002C 02052127
	v_bfe_u32 v57, v40, 16, 1                                  // 000000581410: D6100039 02052128
	v_add3_u32 v3, v3, v55, 0x7fff                             // 000000581418: D6550003 03FE6F03 00007FFF
	v_bfe_u32 v11, v4, 16, 1                                   // 000000581424: D610000B 02052104
	s_and_b32 s1, exec_lo, s0                                  // 00000058142C: 8B01007E
	.long 0xd700000d                                           // 000000581430: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000581434: 0201410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000581438: BF870191
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000058143C: D5207C0E 00021C80
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000581444: D6550004 03FE1704 00007FFF
	v_mov_b32_e32 v11, v21                                     // 000000581450: 7E160315
	s_or_b32 s4, s1, s4                                        // 000000581454: 8C040401
	s_waitcnt vmcnt(1)                                         // 000000581458: BF8907F7
	v_dot2_f32_bf16 v22, v22, v30, 0                           // 00000058145C: CC1A4016 1A023D16
	v_add3_u32 v30, v35, v52, 0x7fff                           // 000000581464: D655001E 03FE6923 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000581470: BF870232
	v_dot2_f32_bf16 v1, v23, v1, v22                           // 000000581474: CC1A4001 1C5A0317
	v_add3_u32 v22, v36, v53, 0x7fff                           // 00000058147C: D6550016 03FE6B24 00007FFF
	v_add3_u32 v23, v37, v54, 0x7fff                           // 000000581488: D6550017 03FE6D25 00007FFF
	.long 0x7e28399e                                           // 000000581494: 7E28399E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000581498: BF870224
	v_dot2_f32_bf16 v1, v24, v31, v1                           // 00000058149C: CC1A4001 1C063F18
	v_add3_u32 v24, v38, v56, 0x7fff                           // 0000005814A4: D6550018 03FE7126 00007FFF
	.long 0x7e563997                                           // 0000005814B0: 7E563997
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005814B4: BF870004
	v_and_or_b32 v22, 0xffff0000, v22, v20                     // 0000005814B8: D6570016 04522CFF FFFF0000
	v_add3_u32 v23, v40, v57, 0x7fff                           // 0000005814C4: D6550017 03FE7328 00007FFF
	v_dot2_f32_bf16 v1, v25, v2, v1                            // 0000005814D0: CC1A4001 1C060519
	v_add3_u32 v2, v39, v44, 0x7fff                            // 0000005814D8: D6550002 03FE5927 00007FFF
	v_and_or_b32 v3, 0xffff0000, v3, v43                       // 0000005814E4: D6570003 04AE06FF FFFF0000
	.long 0x7e283998                                           // 0000005814F0: 7E283998
	s_waitcnt vmcnt(0)                                         // 0000005814F4: BF8903F7
	v_dot2_f32_bf16 v1, v26, v22, v1                           // 0000005814F8: CC1A4001 1C062D1A
	.long 0x7f2c3994                                           // 000000581500: 7F2C3994
	.long 0x7e2c3997                                           // 000000581504: 7E2C3997
	v_and_or_b32 v2, 0xffff0000, v2, v20                       // 000000581508: D6570002 045204FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000581514: BF870194
	v_dot2_f32_bf16 v1, v27, v3, v1                            // 000000581518: CC1A4001 1C06071B
	v_and_or_b32 v3, 0xffff0000, v4, v22                       // 000000581520: D6570003 045A08FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 00000058152C: 7E080308
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000581530: BF870123
	v_dot2_f32_bf16 v1, v28, v2, v1                            // 000000581534: CC1A4001 1C06051C
	v_mov_b32_e32 v2, v6                                       // 00000058153C: 7E040306
	v_dot2_f32_bf16 v20, v29, v3, v1                           // 000000581540: CC1A4014 1C06071D
	v_mov_b32_e32 v3, v7                                       // 000000581548: 7E060307
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058154C: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_add_f32 v16, v16, v20      // 000000581550: CA080105 01102910
	.long 0x7e283900                                           // 000000581558: 7E283900
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000058155C: 917E047E
	s_cbranch_execz 29                                         // 000000581560: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x5d8>
	v_add_nc_u32_e32 v19, 32, v19                              // 000000581564: 4A2626A0
	v_add_nc_u32_e32 v21, 0x200, v11                           // 000000581568: 4A2A16FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000581570: BF8704A2
	.long 0xd4430000                                           // 000000581574: D4430000
	v_cndmask_b32_e32 v1, s2, v19, vcc_lo                      // 000000581578: 02022602
	s_and_saveexec_b32 s1, s0                                  // 00000058157C: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 000000581580: 8D01017E
	v_add_nc_u32_e32 v21, 0x200, v11                           // 000000581584: 4A2A16FF 00000200
	s_or_saveexec_b32 s5, s1                                   // 00000058158C: BE852201
	s_waitcnt vmcnt(0)                                         // 000000581590: BF8903F7
	.long 0x7e003914                                           // 000000581594: 7E003914
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 000000581598: CA100101 05060102
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v8, v4             // 0000005815A0: CA100103 07080104
	s_xor_b32 exec_lo, exec_lo, s5                             // 0000005815A8: 8D7E057E
	s_cbranch_execz 65271                                      // 0000005815AC: BFA5FEF7 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x18c>
	.long 0xd7000105                                           // 0000005815B0: D7000105
	v_cndmask_b32_e32 v1, v17, v21, vcc_lo                     // 0000005815B4: 02022B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005815B8: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 0000005815BC: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 0000005815C4: DC5E0000 057C0005
	global_load_d16_b16 v0, v[13:14], off                      // 0000005815CC: DC820000 007C000D
	s_branch 65261                                             // 0000005815D4: BFA0FEED <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x18c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005815D8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005815DC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005815E0: 8C7E037E
	.long 0xd71f0000                                           // 0000005815E4: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005815E8: 020100C1
	s_waitcnt vmcnt(1)                                         // 0000005815EC: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 0000005815F0: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 0000005815F4: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 0000005815F8: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005815FC: BF870093
	.long 0xd44c0000                                           // 000000581600: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000581604: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000581608: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000581610: BF870114
	.long 0xd44c0000                                           // 000000581614: D44C0000
	v_cndmask_b32_e32 v1, 32, v2, vcc_lo                       // 000000581618: 020204A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000058161C: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000581620: BF8700D2
	v_cndmask_b32_e64 v2, v0, v2, s0                           // 000000581624: D5010002 00020500
	.long 0xd44c0000                                           // 00000058162C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000581630: 020206A0
	ds_bpermute_b32 v1, v1, v16                                // 000000581634: DACC0000 01001001
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000058163C: 30040482
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000581640: D5010003 00020700
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000581648: 30060682
	s_waitcnt lgkmcnt(0)                                       // 00000058164C: BF89FC07
	v_add_f32_e32 v1, v16, v1                                  // 000000581650: 06020310
	ds_bpermute_b32 v2, v2, v1                                 // 000000581654: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 00000058165C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000581660: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 000000581664: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 00000058166C: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000581670: BF870091
	.long 0xd44c0000                                           // 000000581674: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000581678: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000058167C: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000581684: BF8700D1
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000581688: 30060682
	s_waitcnt lgkmcnt(0)                                       // 00000058168C: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000581690: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 000000581694: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 00000058169C: 3A060081
	.long 0xd44c0000                                           // 0000005816A0: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000005816A4: 020206A0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005816A8: BF870001
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000005816AC: D5010003 00020700
	.long 0xd44a0000                                           // 0000005816B4: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000005816B8: 02021E80
	s_and_b32 s0, s0, vcc_lo                                   // 0000005816BC: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000005816C0: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 0000005816C4: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 0000005816CC: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 0000005816D4: BE812000
	s_cbranch_execz 17                                         // 0000005816D8: BFA50011 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x720>
	s_waitcnt lgkmcnt(0)                                       // 0000005816DC: BF89FC07
	v_add_f32_e32 v2, v0, v1                                   // 0000005816E0: 06040300
	.long 0xd73c0000                                           // 0000005816E4: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000005816E8: 02021281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005816EC: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 0000005816F0: D6100003 02052102
	.long 0xd7006a00                                           // 0000005816F8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000005816FC: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000581700: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000581704: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000058170C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000581718: DC960000 007C0200
	s_endpgm                                                   // 000000581720: BFB00000
		...

