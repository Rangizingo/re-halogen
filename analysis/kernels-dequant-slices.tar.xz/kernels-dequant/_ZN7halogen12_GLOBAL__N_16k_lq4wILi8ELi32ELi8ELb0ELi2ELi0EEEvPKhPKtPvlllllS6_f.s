0000000000827900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000827900: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000827908: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000827910: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000827914: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000827918: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082791C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000827920: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000827928: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000082792C: 321E0085
	v_dual_mov_b32 v31, 0 :: v_dual_and_b32 v16, 31, v0        // 000000827930: CA240080 1F10009F
	.long 0x7f263880                                           // 000000827938: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000082793C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000827944: BF89FC07
	s_clause 0x1                                               // 000000827948: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000082794C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000827954: DC520000 0D040002
	.long 0xd4510000                                           // 00000082795C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000827960: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000827964: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000827968: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000082796C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000827970: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000827974: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000827978: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000082797C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000827984: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000827988: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000082798C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000827990: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000827994: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000827998: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000082799C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000008279A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 0000008279A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000008279A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008279AC: BF870499
	s_add_i32 s21, s20, 7                                      // 0000008279B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 0000008279B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008279B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 0000008279BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 0000008279C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008279C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 0000008279C8: 86158315
	s_add_u32 s0, s4, s16                                      // 0000008279CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000008279D0: 82011105
	.long 0xd72c0012                                           // 0000008279D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 0000008279D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 0000008279DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 0000008279E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 0000008279E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 0000008279EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 0000008279F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008279F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008279FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000827A00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000827A08: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 000000827A0C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000827A18: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000827A24: BF870002
	.long 0x7e263982                                           // 000000827A28: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 000000827A2C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000827A30: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000827A38: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 000000827A3C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000827A40: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000827A44: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000827A48: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000827A54: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000827A58: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 000000827A5C: 4A061813
	ds_store_b32 v14, v1                                       // 000000827A60: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000827A68: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 000000827A6C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000827A70: BF89FC07
	s_barrier                                                  // 000000827A74: BFBD0000
	buffer_gl0_inv                                             // 000000827A78: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000827A80: BE81206A
	s_cbranch_execz 21                                         // 000000827A84: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000827A88: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000827A8C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000827A90: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000827A94: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000827A98: 3408069F
	.long 0xd7000001                                           // 000000827A9C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000827AA0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827AA4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000827AA8: D5207C02 00020514
	.long 0xd7000003                                           // 000000827AB0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000827AB4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000827AB8: D5207C04 00020913
	s_clause 0x1                                               // 000000827AC0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000827AC4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000827ACC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000827AD4: BF8907F7
	v_cvt_f32_f16_e32 v31, v1                                  // 000000827AD8: 7E3E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000827ADC: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000827AE0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000827AE8: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 000000827AF0: CA100080 1A1A0080
	v_mov_b32_e32 v21, 0                                       // 000000827AF8: 7E2A0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000827AFC: BE81206A
	s_cbranch_execz 639                                        // 000000827B00: BFA5027F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xc00>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000827B04: CA200080 1A0014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000827B0C: CA220080 150C1485
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 000000827B14: CA100080 19160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000827B1C: BF870003
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v28, 4, v1     // 000000827B20: CA220080 1B1C0284
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v29, 1, v1     // 000000827B28: CA220080 181C0281
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v30, v31           // 000000827B30: CA100080 171E011F
	v_mov_b32_e32 v17, 0                                       // 000000827B38: 7E220280
	s_mul_i32 s0, s11, 6                                       // 000000827B3C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000827B40: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000827B44: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000827B48: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000827B4C: 9610860A
	s_mov_b32 s15, 0                                           // 000000827B50: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000827B54: 848A810A
	s_branch 585                                               // 000000827B58: BFA00249 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb80>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000827B5C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000827B60: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000827B68: 8B006A7E
	v_add_nc_u32_e32 v29, 64, v29                              // 000000827B6C: 4A3A3AC0
	s_or_b32 s15, s0, s15                                      // 000000827B70: 8C0F0F00
	v_add_nc_u32_e32 v28, 0x200, v28                           // 000000827B74: 4A3838FF 00000200
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000827B7C: 301A1A82
	ds_load_b32 v48, v13                                       // 000000827B80: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000827B88: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000827B8C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000827B90: 361A1AFF 000003FC
	ds_load_b32 v49, v13                                       // 000000827B98: D8D80000 3100000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000827BA0: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000827BA4: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000827BA8: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000827BB0: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827BB4: 360A0AFF 000003FC
	ds_load_b32 v50, v13                                       // 000000827BBC: D8D80000 3200000D
	ds_load_b32 v51, v5                                        // 000000827BC4: D8D80000 33000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000827BCC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000827BD4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000827BD8: 300A0A82
	ds_load_b32 v52, v5                                        // 000000827BDC: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000827BE4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827BE8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827BEC: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000827BF4: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000827BFC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C00: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000827C08: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000827C10: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827C14: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C18: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000827C20: D8D80000 37000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000827C28: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000827C30: 300A0A82
	ds_load_b32 v56, v5                                        // 000000827C34: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000827C3C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827C40: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C44: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000827C4C: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000827C54: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C58: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000827C60: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000827C68: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827C6C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C70: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000827C78: D8D80000 3B000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000827C80: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000827C88: 300A0A82
	ds_load_b32 v60, v5                                        // 000000827C8C: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000827C94: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827C98: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827C9C: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 000000827CA4: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000827CAC: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827CB0: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 000000827CB8: D8D80000 3E000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000827CC0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000827CC4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000827CC8: 360A0AFF 000003FC
	ds_load_b32 v63, v5                                        // 000000827CD0: D8D80000 3F000005
	.long 0xd73c0005                                           // 000000827CD8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000827CDC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000827CE0: 4A1818FF 00000400
	.long 0xd7006a2c                                           // 000000827CE8: D7006A2C
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000827CEC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000827CF0: BF870001
	v_add_co_ci_u32_e64 v45, null, s7, v6, vcc_lo              // 000000827CF4: D5207C2D 01AA0C07
	s_clause 0x3                                               // 000000827CFC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000827D00: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 000000827D08: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 000000827D10: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 000000827D18: DC5E0030 287C002C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000827D20: BF890CF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000827D24: CC1A4005 1A026105
	s_waitcnt lgkmcnt(14)                                      // 000000827D2C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827D30: BF8700A1
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000827D34: CC1A4005 1C166306
	s_waitcnt lgkmcnt(13)                                      // 000000827D3C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000827D40: CC1A4005 1C166507
	s_waitcnt lgkmcnt(12)                                      // 000000827D48: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827D4C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000827D50: CC1A4005 1C166708
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000827D58: BF8908B7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000827D5C: CC1A4005 1C166920
	s_waitcnt lgkmcnt(10)                                      // 000000827D64: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827D68: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000827D6C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(9)                                       // 000000827D74: BF89FC97
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000827D78: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(8)                                       // 000000827D80: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827D84: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000827D88: CC1A4005 1C166F23
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000827D90: BF890477
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000827D94: CC1A4005 1C167124
	s_waitcnt lgkmcnt(6)                                       // 000000827D9C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827DA0: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000827DA4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(5)                                       // 000000827DAC: BF89FC57
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000827DB0: CC1A4005 1C167526
	s_waitcnt lgkmcnt(4)                                       // 000000827DB8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827DBC: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000827DC0: CC1A4005 1C167727
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000827DC8: BF890037
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000827DCC: CC1A4005 1C167928
	.long 0xd7006a28                                           // 000000827DD4: D7006A28
	v_cndmask_b32_e32 v0, v44, v10, vcc_lo                     // 000000827DD8: 0200152C
	s_waitcnt lgkmcnt(2)                                       // 000000827DDC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000827DE0: BF8701C2
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000827DE4: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s11, v45, vcc_lo            // 000000827DEC: D5207C29 01AA5A0B
	.long 0xd7006a2e                                           // 000000827DF4: D7006A2E
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000827DF8: 0200092C
	s_waitcnt lgkmcnt(1)                                       // 000000827DFC: BF89FC17
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000827E00: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v47, null, s5, v45, vcc_lo             // 000000827E08: D5207C2F 01AA5A05
	.long 0xd7006a2c                                           // 000000827E10: D7006A2C
	v_cndmask_b32_e32 v0, v44, v16, vcc_lo                     // 000000827E14: 0200212C
	s_waitcnt lgkmcnt(0)                                       // 000000827E18: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000827E1C: BF870123
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000827E20: CC1A4005 1C167F2B
	v_add_co_ci_u32_e64 v45, null, s14, v45, vcc_lo            // 000000827E28: D5207C2D 01AA5A0E
	v_fmac_f32_e32 v21, v31, v5                                // 000000827E30: 562A0B1F
	s_clause 0x3                                               // 000000827E34: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000827E38: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 000000827E40: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 000000827E48: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 000000827E50: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 000000827E58: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000827E5C: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827E64: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000827E68: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000827E70: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827E78: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000827E7C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000827E84: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000827E88: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827E90: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000827E94: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000827E9C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827EA4: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000827EA8: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000827EB0: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000827EB4: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827EBC: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000827EC0: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000827EC8: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000827ED0: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000827ED4: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000827EDC: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000827EE0: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827EE8: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000827EEC: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000827EF4: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827EFC: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000827F00: CC1A4005 1C167F2B
	v_fmac_f32_e32 v27, v31, v5                                // 000000827F08: 56360B1F
	s_clause 0x3                                               // 000000827F0C: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 000000827F10: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 000000827F18: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 000000827F20: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 000000827F28: DC5E0030 287C002E
	.long 0xd7006a2e                                           // 000000827F30: D7006A2E
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 000000827F34: 0200092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000827F38: BF8700B1
	v_add_co_ci_u32_e64 v47, null, s5, v47, vcc_lo             // 000000827F3C: D5207C2F 01AA5E05
	s_waitcnt vmcnt(3)                                         // 000000827F44: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000827F48: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000827F50: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827F58: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000827F5C: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000827F64: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000827F6C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827F70: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000827F74: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000827F7C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827F84: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000827F88: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000827F90: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000827F98: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827F9C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000827FA0: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000827FA8: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827FB0: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000827FB4: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000827FBC: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000827FC4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827FC8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000827FCC: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000827FD4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000827FDC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000827FE0: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000827FE8: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000827FF0: BF870001
	v_fmac_f32_e32 v26, v31, v5                                // 000000827FF4: 56340B1F
	s_clause 0x3                                               // 000000827FF8: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 000000827FFC: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 000000828004: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 00000082800C: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 000000828014: DC5E0030 287C002C
	.long 0xd7006a2c                                           // 00000082801C: D7006A2C
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 000000828020: 0200092C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000828024: BF8700B1
	v_add_co_ci_u32_e64 v45, null, s5, v45, vcc_lo             // 000000828028: D5207C2D 01AA5A05
	s_waitcnt vmcnt(3)                                         // 000000828030: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 000000828034: CC1A4005 1A026105
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 00000082803C: CC1A4005 1C166306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828044: BF870091
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000828048: CC1A4005 1C166507
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000828050: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000828058: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082805C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000828060: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000828068: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828070: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000828074: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082807C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000828084: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828088: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082808C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000828094: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082809C: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008280A0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008280A8: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 0000008280B0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008280B4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008280B8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008280C0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008280C8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008280CC: CC1A4005 1C167D2A
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 0000008280D4: CC1A4005 1C167F2B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008280DC: BF870001
	v_fmac_f32_e32 v25, v31, v5                                // 0000008280E0: 56320B1F
	s_clause 0x3                                               // 0000008280E4: BF850003
	global_load_b128 v[5:8], v[46:47], off                     // 0000008280E8: DC5E0000 057C002E
	global_load_b128 v[32:35], v[46:47], off offset:16         // 0000008280F0: DC5E0010 207C002E
	global_load_b128 v[36:39], v[46:47], off offset:32         // 0000008280F8: DC5E0020 247C002E
	global_load_b128 v[40:43], v[46:47], off offset:48         // 000000828100: DC5E0030 287C002E
	s_waitcnt vmcnt(3)                                         // 000000828108: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 00000082810C: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828114: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 000000828118: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 000000828120: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828128: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 00000082812C: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 000000828134: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000828138: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828140: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000828144: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082814C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828154: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000828158: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000828160: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000828164: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082816C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000828170: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000828178: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828180: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000828184: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082818C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000828190: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828198: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082819C: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008281A4: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008281AC: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 0000008281B0: CC1A4005 1C167F2B
	v_fmac_f32_e32 v24, v31, v5                                // 0000008281B8: 56300B1F
	s_clause 0x3                                               // 0000008281BC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 0000008281C0: DC5E0000 057C002C
	global_load_b128 v[32:35], v[44:45], off offset:16         // 0000008281C8: DC5E0010 207C002C
	global_load_b128 v[36:39], v[44:45], off offset:32         // 0000008281D0: DC5E0020 247C002C
	global_load_b128 v[40:43], v[44:45], off offset:48         // 0000008281D8: DC5E0030 287C002C
	s_waitcnt vmcnt(3)                                         // 0000008281E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 0000008281E4: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008281EC: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 0000008281F0: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 0000008281F8: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828200: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 000000828204: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 00000082820C: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000828210: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828218: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082821C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000828224: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082822C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000828230: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000828238: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000082823C: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828244: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000828248: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000828250: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828258: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000082825C: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000828264: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000828268: CC1A4005 1C167928
	.long 0xd7006a28                                           // 000000828270: D7006A28
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 000000828274: 0200092E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000828278: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000082827C: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v47, vcc_lo             // 000000828284: D5207C29 01AA5E05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000082828C: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828294: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000828298: CC1A4005 1C167F2B
	v_fmac_f32_e32 v23, v31, v5                                // 0000008282A0: 562E0B1F
	s_clause 0x3                                               // 0000008282A4: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 0000008282A8: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 0000008282B0: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 0000008282B8: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 0000008282C0: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 0000008282C8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 0000008282CC: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008282D4: BF870091
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 0000008282D8: CC1A4005 1C166306
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 0000008282E0: CC1A4005 1C166507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008282E8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 0000008282EC: CC1A4005 1C166708
	s_waitcnt vmcnt(2)                                         // 0000008282F4: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008282F8: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828300: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000828304: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082830C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828314: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000828318: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000828320: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000828324: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082832C: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000828330: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000828338: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828340: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000828344: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 00000082834C: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000828350: CC1A4005 1C167928
	.long 0xd7006a28                                           // 000000828358: D7006A28
	v_cndmask_b32_e32 v0, v44, v4, vcc_lo                      // 00000082835C: 0200092C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000828360: BF870122
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000828364: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v41, null, s5, v45, vcc_lo             // 00000082836C: D5207C29 01AA5A05
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000828374: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082837C: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000828380: CC1A4005 1C167F2B
	v_fmac_f32_e32 v22, v31, v5                                // 000000828388: 562C0B1F
	s_clause 0x3                                               // 00000082838C: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000828390: DC5E0000 057C0028
	global_load_b128 v[32:35], v[40:41], off offset:16         // 000000828398: DC5E0010 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:32         // 0000008283A0: DC5E0020 247C0028
	global_load_b128 v[40:43], v[40:41], off offset:48         // 0000008283A8: DC5E0030 287C0028
	s_waitcnt vmcnt(3)                                         // 0000008283B0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v48, 0                             // 0000008283B4: CC1A4005 1A026105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008283BC: BF870121
	v_dot2_f32_bf16 v5, v6, v49, v5                            // 0000008283C0: CC1A4005 1C166306
	v_mov_b32_e32 v6, v2                                       // 0000008283C8: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v50, v5                            // 0000008283CC: CC1A4005 1C166507
	v_mov_b32_e32 v7, v3                                       // 0000008283D4: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008283D8: BF870132
	v_dot2_f32_bf16 v5, v8, v51, v5                            // 0000008283DC: CC1A4005 1C166708
	v_mov_b32_e32 v8, v4                                       // 0000008283E4: 7E100304
	s_waitcnt vmcnt(2)                                         // 0000008283E8: BF890BF7
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008283EC: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008283F4: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008283F8: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000828400: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828408: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082840C: CC1A4005 1C166F23
	s_waitcnt vmcnt(1)                                         // 000000828414: BF8907F7
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000828418: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828420: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000828424: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082842C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828434: BF8700A1
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000828438: CC1A4005 1C167727
	s_waitcnt vmcnt(0)                                         // 000000828440: BF8903F7
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000828444: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082844C: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000828450: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000828458: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828460: BF870091
	v_dot2_f32_bf16 v5, v43, v63, v5                           // 000000828464: CC1A4005 1C167F2B
	v_fmac_f32_e32 v17, v31, v5                                // 00000082846C: 56220B1F
	v_mov_b32_e32 v5, v1                                       // 000000828470: 7E0A0301
	v_mov_b32_e32 v31, v30                                     // 000000828474: 7E3E031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000828478: 917E0F7E
	s_cbranch_execz 31                                         // 00000082847C: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xbfc>
	s_waitcnt vmcnt(0)                                         // 000000828480: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000828484: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000082848C: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000828494: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000828498: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000082849C: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000008284A0: 7C8C250A
	.long 0xd4c1007e                                           // 0000008284A4: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000008284A8: 0202250A
	s_cbranch_execz 64939                                      // 0000008284AC: BFA5FDAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x25c>
	v_ashrrev_i32_e32 v2, 31, v29                              // 0000008284B0: 34043A9F
	v_ashrrev_i32_e32 v4, 31, v28                              // 0000008284B4: 3408389F
	.long 0xd7000001                                           // 0000008284B8: D7000001
	v_cndmask_b32_e32 v1, v11, v29, vcc_lo                     // 0000008284BC: 02023B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008284C0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000008284C4: D5207C02 00020514
	.long 0xd7000003                                           // 0000008284CC: D7000003
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 0000008284D0: 02023909
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000008284D4: D5207C04 00020913
	s_clause 0x1                                               // 0000008284DC: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000008284E0: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008284E8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008284F0: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 0000008284F4: 7E3C170D
	s_branch 64920                                             // 0000008284F8: BFA0FD98 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x25c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008284FC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000828500: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000828504: 8C7E017E
	.long 0xd71f0001                                           // 000000828508: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000082850C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000828510: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000828514: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000828518: 3A140288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000082851C: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000828520: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000828524: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000828528: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000082852C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000828530: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000828534: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000082853C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000828540: 06060715
	s_waitcnt vmcnt(0)                                         // 000000828544: BF8903F7
	ds_bpermute_b32 v5, v2, v26                                // 000000828548: DACC0000 05001A02
	ds_bpermute_b32 v7, v2, v24                                // 000000828550: DACC0000 07001802
	ds_bpermute_b32 v9, v2, v22                                // 000000828558: DACC0000 09001602
	ds_bpermute_b32 v4, v2, v27                                // 000000828560: DACC0000 04001B02
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000828568: 02141501
	ds_bpermute_b32 v6, v2, v25                                // 00000082856C: DACC0000 06001902
	ds_bpermute_b32 v8, v2, v23                                // 000000828574: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 00000082857C: DACC0000 02001102
	v_xor_b32_e32 v21, 4, v1                                   // 000000828584: 3A2A0284
	s_delay_alu instid0(VALU_DEP_1)                            // 000000828588: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000082858C: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 000000828590: 022A2B01
	s_waitcnt lgkmcnt(6)                                       // 000000828594: BF89FC67
	v_add_f32_e32 v5, v26, v5                                  // 000000828598: 060A0B1A
	s_waitcnt lgkmcnt(5)                                       // 00000082859C: BF89FC57
	v_dual_add_f32 v7, v24, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000008285A0: C9220F18 070A1482
	s_waitcnt lgkmcnt(3)                                       // 0000008285A8: BF89FC37
	v_dual_add_f32 v9, v22, v9 :: v_dual_add_f32 v4, v27, v4   // 0000008285AC: C9081316 0904091B
	s_waitcnt lgkmcnt(2)                                       // 0000008285B4: BF89FC27
	v_dual_add_f32 v6, v25, v6 :: v_dual_lshlrev_b32 v21, 2, v21// 0000008285B8: C9220D19 06142A82
	ds_bpermute_b32 v11, v10, v3                               // 0000008285C0: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 0000008285C8: DACC0000 0D00050A
	s_waitcnt lgkmcnt(3)                                       // 0000008285D0: BF89FC37
	v_add_f32_e32 v8, v23, v8                                  // 0000008285D4: 06101117
	s_waitcnt lgkmcnt(2)                                       // 0000008285D8: BF89FC27
	v_add_f32_e32 v2, v17, v2                                  // 0000008285DC: 06040511
	ds_bpermute_b32 v12, v10, v4                               // 0000008285E0: DACC0000 0C00040A
	ds_bpermute_b32 v17, v10, v6                               // 0000008285E8: DACC0000 1100060A
	ds_bpermute_b32 v18, v10, v7                               // 0000008285F0: DACC0000 1200070A
	ds_bpermute_b32 v20, v10, v9                               // 0000008285F8: DACC0000 1400090A
	s_waitcnt lgkmcnt(5)                                       // 000000828600: BF89FC57
	v_add_f32_e32 v3, v3, v11                                  // 000000828604: 06061703
	s_waitcnt lgkmcnt(4)                                       // 000000828608: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 00000082860C: 060A1B05
	ds_bpermute_b32 v19, v10, v8                               // 000000828610: DACC0000 1300080A
	ds_bpermute_b32 v10, v10, v2                               // 000000828618: DACC0000 0A00020A
	s_waitcnt lgkmcnt(5)                                       // 000000828620: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 000000828624: 06081904
	s_waitcnt lgkmcnt(3)                                       // 000000828628: BF89FC37
	v_dual_add_f32 v6, v6, v17 :: v_dual_add_f32 v7, v7, v18   // 00000082862C: C9082306 06062507
	s_waitcnt lgkmcnt(2)                                       // 000000828634: BF89FC27
	v_add_f32_e32 v9, v9, v20                                  // 000000828638: 06122909
	ds_bpermute_b32 v12, v21, v5                               // 00000082863C: DACC0000 0C000515
	ds_bpermute_b32 v11, v21, v4                               // 000000828644: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v6                               // 00000082864C: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 000000828654: DACC0000 11000715
	s_waitcnt lgkmcnt(5)                                       // 00000082865C: BF89FC57
	v_add_f32_e32 v8, v8, v19                                  // 000000828660: 06102708
	s_waitcnt lgkmcnt(4)                                       // 000000828664: BF89FC47
	v_add_f32_e32 v2, v2, v10                                  // 000000828668: 06041502
	ds_bpermute_b32 v10, v21, v3                               // 00000082866C: DACC0000 0A000315
	ds_bpermute_b32 v19, v21, v9                               // 000000828674: DACC0000 13000915
	ds_bpermute_b32 v18, v21, v8                               // 00000082867C: DACC0000 12000815
	ds_bpermute_b32 v20, v21, v2                               // 000000828684: DACC0000 14000215
	v_xor_b32_e32 v21, 2, v1                                   // 00000082868C: 3A2A0282
	s_waitcnt lgkmcnt(5)                                       // 000000828690: BF89FC57
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 000000828694: C9081905 05061B06
	v_add_f32_e32 v4, v4, v11                                  // 00000082869C: 06081704
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008286A0: BF870143
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 0000008286A4: 7C982AA0
	v_cndmask_b32_e32 v21, v1, v21, vcc_lo                     // 0000008286A8: 022A2B01
	s_waitcnt lgkmcnt(4)                                       // 0000008286AC: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 0000008286B0: 060E2307
	v_lshlrev_b32_e32 v21, 2, v21                              // 0000008286B4: 302A2A82
	s_waitcnt lgkmcnt(3)                                       // 0000008286B8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 0000008286BC: 06061503
	s_waitcnt lgkmcnt(1)                                       // 0000008286C0: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 0000008286C4: 06102508
	ds_bpermute_b32 v10, v21, v4                               // 0000008286C8: DACC0000 0A000415
	v_add_f32_e32 v9, v9, v19                                  // 0000008286D0: 06122709
	ds_bpermute_b32 v12, v21, v5                               // 0000008286D4: DACC0000 0C000515
	ds_bpermute_b32 v13, v21, v6                               // 0000008286DC: DACC0000 0D000615
	ds_bpermute_b32 v17, v21, v7                               // 0000008286E4: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v8                               // 0000008286EC: DACC0000 12000815
	ds_bpermute_b32 v19, v21, v9                               // 0000008286F4: DACC0000 13000915
	s_waitcnt lgkmcnt(6)                                       // 0000008286FC: BF89FC67
	v_add_f32_e32 v11, v2, v20                                 // 000000828700: 06162902
	ds_bpermute_b32 v2, v21, v3                                // 000000828704: DACC0000 02000315
	ds_bpermute_b32 v20, v21, v11                              // 00000082870C: DACC0000 14000B15
	v_xor_b32_e32 v21, 1, v1                                   // 000000828714: 3A2A0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000828718: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v21                           // 00000082871C: 7C982AA0
	v_cndmask_b32_e32 v1, v1, v21, vcc_lo                      // 000000828720: 02022B01
	v_lshlrev_b32_e32 v21, 2, v1                               // 000000828724: 302A0282
	s_waitcnt lgkmcnt(1)                                       // 000000828728: BF89FC17
	v_add_f32_e32 v1, v3, v2                                   // 00000082872C: 06020503
	v_add_f32_e32 v2, v4, v10                                  // 000000828730: 06041504
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000828734: C9081905 04041B06
	v_add_f32_e32 v3, v7, v17                                  // 00000082873C: 06062307
	v_dual_add_f32 v7, v8, v18 :: v_dual_add_f32 v10, v9, v19  // 000000828740: C9082508 070A2709
	s_waitcnt lgkmcnt(0)                                       // 000000828748: BF89FC07
	v_add_f32_e32 v12, v11, v20                                // 00000082874C: 0618290B
	ds_bpermute_b32 v6, v21, v1                                // 000000828750: DACC0000 06000115
	ds_bpermute_b32 v8, v21, v2                                // 000000828758: DACC0000 08000215
	ds_bpermute_b32 v11, v21, v4                               // 000000828760: DACC0000 0B000415
	ds_bpermute_b32 v13, v21, v5                               // 000000828768: DACC0000 0D000515
	ds_bpermute_b32 v9, v21, v3                                // 000000828770: DACC0000 09000315
	ds_bpermute_b32 v17, v21, v7                               // 000000828778: DACC0000 11000715
	ds_bpermute_b32 v18, v21, v10                              // 000000828780: DACC0000 12000A15
	ds_bpermute_b32 v19, v21, v12                              // 000000828788: DACC0000 13000C15
	v_cmpx_eq_u32_e32 0, v16                                   // 000000828790: 7D942080
	s_cbranch_execz 14                                         // 000000828794: BFA5000E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xed0>
	s_waitcnt lgkmcnt(0)                                       // 000000828798: BF89FC07
	v_dual_add_f32 v19, v12, v19 :: v_dual_add_f32 v18, v10, v18// 00000082879C: C908270C 1312250A
	v_dual_add_f32 v17, v7, v17 :: v_dual_add_f32 v12, v4, v11 // 0000008287A4: C9082307 110C1704
	v_add_f32_e32 v13, v5, v13                                 // 0000008287AC: 061A1B05
	v_dual_add_f32 v11, v2, v8 :: v_dual_add_f32 v10, v1, v6   // 0000008287B0: C9081102 0B0A0D01
	v_dual_add_f32 v16, v3, v9 :: v_dual_lshlrev_b32 v1, 5, v15// 0000008287B8: C9221303 10001E85
	ds_store_b128 v1, v[10:13] offset:1024                     // 0000008287C0: DB7C0400 00000A01
	ds_store_b128 v1, v[16:19] offset:1040                     // 0000008287C8: DB7C0410 00001001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000008287D0: 8C7E007E
	.long 0xd4510000                                           // 0000008287D4: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008287D8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 0000008287DC: 7C980088
	s_waitcnt lgkmcnt(0)                                       // 0000008287E0: BF89FC07
	s_barrier                                                  // 0000008287E4: BFBD0000
	buffer_gl0_inv                                             // 0000008287E8: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000008287F0: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008287F4: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000008287F8: BE812000
	s_cbranch_execz 88                                         // 0000008287FC: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1060>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000828800: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000828808: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 00000082880C: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000828814: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 00000082881C: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000828824: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000828828: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000082882C: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000828830: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:48 offset1:56         // 000000828834: D8DC3830 01000007
	s_waitcnt lgkmcnt(2)                                       // 00000082883C: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000828840: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000828844: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000828848: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082884C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000828850: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000828854: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000828858: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082885C: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000828860: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000828864: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828868: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 00000082886C: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 000000828874: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828880: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000828884: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 00000082888C: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000828894: BF870291
	v_exp_f32_e32 v1, v1                                       // 000000828898: 7E024B01
	v_add_f32_e32 v4, 1.0, v1                                  // 00000082889C: 060802F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008288A0: BF870121
	v_div_scale_f32 v3, null, v4, v4, 1.0                      // 0000008288A4: D6FC7C03 03CA0904
	v_div_scale_f32 v6, vcc_lo, 1.0, v4, 1.0                   // 0000008288AC: D6FC6A06 03CA08F2
	v_rcp_f32_e32 v5, v3                                       // 0000008288B4: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008288B8: BF870095
	v_fma_f32 v1, -v3, v5, 1.0                                 // 0000008288BC: D6130001 23CA0B03
	v_fmac_f32_e32 v5, v1, v5                                  // 0000008288C4: 560A0B01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000008288C8: D6FE7C01 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008288D0: BF870092
	v_mul_f32_e32 v7, v6, v5                                   // 0000008288D4: 100E0B06
	v_fma_f32 v8, -v3, v7, v6                                  // 0000008288D8: D6130008 241A0F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008288E0: BF870091
	v_fmac_f32_e32 v7, v8, v5                                  // 0000008288E4: 560E0B08
	v_fma_f32 v6, -v3, v7, v6                                  // 0000008288E8: D6130006 241A0F03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000008288F0: D6FE7C02 040A000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008288F8: BF870092
	v_div_fmas_f32 v0, v6, v5, v7                              // 0000008288FC: D6370000 041E0B06
	v_div_fixup_f32 v3, v0, v4, 1.0                            // 000000828904: D6270003 03CA0900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082890C: BF870113
	.long 0xd73c0000                                           // 000000828910: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000828914: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000828918: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000828920: BF870092
	.long 0xd7006a00                                           // 000000828924: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000828928: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000082892C: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000828934: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000828938: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000828944: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000828948: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000082894C: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000828950: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000828958: DC960000 007C0200
	s_endpgm                                                   // 000000828960: BFB00000
		...

