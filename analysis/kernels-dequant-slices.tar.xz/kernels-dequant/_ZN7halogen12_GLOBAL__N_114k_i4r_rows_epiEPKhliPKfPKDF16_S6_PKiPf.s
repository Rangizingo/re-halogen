0000000000234300 <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_epiEPKhliPKfPKDF16_S6_PKiPf>:
; _ZN7halogen12_GLOBAL__N_114k_i4r_rows_epiEPKhliPKfPKDF16_S6_PKiPf():
	s_clause 0x2                                               // 000000234300: BF850002
	s_load_b32 s20, s[0:1], 0x10                               // 000000234304: F4000500 F8000010
	s_load_b256 s[8:15], s[0:1], 0x18                          // 00000023430C: F40C0200 F8000018
	s_load_b64 s[16:17], s[0:1], 0x38                          // 000000234314: F4040400 F8000038
	s_waitcnt lgkmcnt(0)                                       // 00000023431C: BF89FC07
	s_ashr_i32 s21, s20, 31                                    // 000000234320: 86159F14
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000234324: BF870499
	s_lshr_b32 s3, s21, 26                                     // 000000234328: 85039A15
	s_add_i32 s3, s20, s3                                      // 00000023432C: 81030314
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000234330: BF870499
	s_ashr_i32 s22, s3, 6                                      // 000000234334: 86168603
	s_cvt_f32_u32 s3, s22                                      // 000000234338: BE836516
	s_sub_i32 s4, 0, s22                                       // 00000023433C: 81841680
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000234340: BF87029A
	v_rcp_iflag_f32_e32 v1, s3                                 // 000000234344: 7E025603
	v_readfirstlane_b32 s3, v1                                 // 000000234348: 7E060501
	s_mul_f32 s3, s3, 0x4f7ffffe                               // 00000023434C: A203FF03 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000234354: BF87059B
	s_cvt_u32_f32 s3, s3                                       // 000000234358: BE836703
	s_mul_i32 s4, s4, s3                                       // 00000023435C: 96040304
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000234360: BF870499
	s_mul_hi_u32 s4, s3, s4                                    // 000000234364: 96840403
	s_add_i32 s3, s3, s4                                       // 000000234368: 81030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023436C: BF870499
	s_mul_hi_u32 s3, s2, s3                                    // 000000234370: 96830302
	s_mul_i32 s4, s3, s22                                      // 000000234374: 96041603
	s_add_i32 s5, s3, 1                                        // 000000234378: 81058103
	s_sub_i32 s4, s2, s4                                       // 00000023437C: 81840402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000234380: BF870009
	s_sub_i32 s6, s4, s22                                      // 000000234384: 81861604
	s_cmp_ge_u32 s4, s22                                       // 000000234388: BF091604
	s_cselect_b32 s3, s5, s3                                   // 00000023438C: 98030305
	s_cselect_b32 s4, s6, s4                                   // 000000234390: 98040406
	s_add_i32 s5, s3, 1                                        // 000000234394: 81058103
	s_cmp_ge_u32 s4, s22                                       // 000000234398: BF091604
	s_cselect_b32 s18, s5, s3                                  // 00000023439C: 98120305
	s_mov_b32 s3, exec_lo                                      // 0000002343A0: BE83007E
	v_cmpx_lt_u32_e32 0x9f, v0                                 // 0000002343A4: 7D9200FF 0000009F
	s_xor_b32 s3, exec_lo, s3                                  // 0000002343AC: 8D03037E
	s_ashr_i32 s19, s18, 31                                    // 0000002343B0: 86139F12
	s_or_saveexec_b32 s23, s3                                  // 0000002343B4: BE972203
	v_dual_mov_b32 v21, s19 :: v_dual_mov_b32 v20, s18         // 0000002343B8: CA100013 15140012
	s_xor_b32 exec_lo, exec_lo, s23                            // 0000002343C0: 8D7E177E
	s_cbranch_execz 608                                        // 0000002343C4: BFA50260 <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_epiEPKhliPKfPKDF16_S6_PKiPf+0xa48>
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000002343C8: 30020082
	v_and_b32_e32 v15, 31, v0                                  // 0000002343CC: 361E009F
	s_mul_i32 s4, s18, 0x1400                                  // 0000002343D0: 9604FF12 00001400
	s_ashr_i32 s19, s18, 31                                    // 0000002343D8: 86139F12
	s_mul_hi_i32 s3, s18, 0x1400                               // 0000002343DC: 9703FF12 00001400
	v_and_b32_e32 v9, 0x380, v1                                // 0000002343E4: 361202FF 00000380
	s_add_u32 s4, s8, s4                                       // 0000002343EC: 80040408
	s_addc_u32 s3, s9, s3                                      // 0000002343F0: 82030309
	v_lshlrev_b32_e32 v2, 4, v15                               // 0000002343F4: 30041E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002343F8: BF870092
	v_lshlrev_b32_e32 v1, 2, v9                                // 0000002343FC: 30021282
	.long 0xd7000401                                           // 000000234400: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000234404: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234408: BF870111
	v_add_co_ci_u32_e64 v3, null, s3, 0, s4                    // 00000023440C: D5207C03 00110003
	.long 0xd7006a05                                           // 000000234414: D7006A05
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000234418: 02020501
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023441C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v3, vcc_lo                // 000000234420: D5207C06 01AA0680
	s_clause 0x1                                               // 000000234428: BF850001
	global_load_b128 v[1:4], v[5:6], off                       // 00000023442C: DC5E0000 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:2560           // 000000234434: DC5E0A00 057C0005
	v_and_b32_e32 v18, 2, v0                                   // 00000023443C: 36240082
	s_waitcnt vmcnt(1)                                         // 000000234440: BF8907F7
	v_dual_add_f32 v21, v1, v2 :: v_dual_and_b32 v20, 8, v0    // 000000234444: C9240501 15140088
	v_dual_sub_f32 v1, v1, v2 :: v_dual_add_f32 v2, v3, v4     // 00000023444C: C9480501 01020903
	s_waitcnt vmcnt(0)                                         // 000000234454: BF8903F7
	v_dual_sub_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v6     // 000000234458: C9480903 03040D05
	v_dual_sub_f32 v5, v5, v6 :: v_dual_add_f32 v6, v7, v8     // 000000234460: C9480D05 05061107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000234468: BF870232
	v_dual_add_f32 v22, v1, v3 :: v_dual_lshlrev_b32 v9, 1, v9 // 00000023446C: C9220701 16081281
	v_and_b32_e32 v19, 4, v0                                   // 000000234474: 36260084
	v_sub_f32_e32 v1, v1, v3                                   // 000000234478: 08020701
	v_add_f32_e32 v3, v4, v6                                   // 00000023447C: 06060D04
	v_dual_sub_f32 v4, v4, v6 :: v_dual_and_b32 v17, 1, v0     // 000000234480: C9640D04 04100081
	.long 0xd44a0004                                           // 000000234488: D44A0004
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 00000023448C: 02022480
	.long 0xd44a0005                                           // 000000234490: D44A0005
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000234494: 02022680
	.long 0xd44a0006                                           // 000000234498: D44A0006
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 00000023449C: 02022880
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002344A0: BF870004
	v_mov_b32_dpp v26, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002344A4: 7E3402FA FF016104
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v21, v2    // 0000002344AC: C9481107 07080515
	v_lshl_or_b32 v16, v15, 3, v9                              // 0000002344B4: D6560010 0425070F
	s_clause 0x2                                               // 0000002344BC: BF850002
	global_load_b64 v[9:10], v16, s[10:11]                     // 0000002344C0: DC560000 090A0010
	global_load_b64 v[11:12], v16, s[10:11] offset:1280        // 0000002344C8: DC560500 0B0A0010
	global_load_b64 v[13:14], v16, s[12:13]                    // 0000002344D0: DC560000 0D0C0010
	v_sub_f32_e32 v2, v21, v2                                  // 0000002344D8: 08040515
	.long 0xd44a0003                                           // 0000002344DC: D44A0003
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000002344E0: 02022280
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002344E4: 7E0C02FA FF016108
	.long 0xd44c0007                                           // 0000002344EC: D44C0007
	v_cndmask_b32_e32 v1, 16, v15, vcc_lo                      // 0000002344F0: 02021E90
	s_mov_b32 s11, 0x76543210                                  // 0000002344F4: BE8B00FF 76543210
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000002344FC: D5010004 200E0904
	v_cndmask_b32_e64 v21, -v22, v22, s3                       // 000000234504: D5010015 200E2D16
	s_delay_alu instid0(VALU_DEP_2)                            // 00000023450C: BF870002
	v_dual_add_f32 v4, v4, v26 :: v_dual_add_f32 v17, v5, v7   // 000000234510: C9083504 04100F05
	v_sub_f32_e32 v5, v5, v7                                   // 000000234518: 080A0F05
	v_cndmask_b32_e64 v7, -v8, v8, s3                          // 00000023451C: D5010007 200E1108
	v_mov_b32_dpp v8, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234524: 7E1002FA FF016116
	v_mov_b32_dpp v22, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000023452C: 7E2C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000234534: D5010002 200E0502
	s_delay_alu instid0(VALU_DEP_4)                            // 00000023453C: BF870004
	v_add_f32_e32 v6, v7, v6                                   // 000000234540: 060C0D07
	v_mov_b32_dpp v23, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234544: 7E2E02FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 00000023454C: D5010001 200E0301
	v_add_f32_e32 v8, v21, v8                                  // 000000234554: 06101115
	v_mov_b32_dpp v24, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234558: 7E3002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000234560: D5010003 200E0703
	v_mov_b32_dpp v21, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234568: 7E2A02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000234570: D5010004 20120904
	v_dual_add_f32 v1, v1, v23 :: v_dual_add_f32 v2, v2, v22   // 000000234578: C9082F01 01022D02
	v_mov_b32_dpp v25, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234580: 7E3202FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000234588: D5010011 200E2311
	v_mov_b32_dpp v23, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234590: 7E2E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 000000234598: D5010006 20120D06
	v_add_f32_e32 v3, v3, v24                                  // 0000002345A0: 06063103
	v_mov_b32_dpp v24, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000002345A4: 7E3002FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 0000002345AC: D5010008 20121108
	v_add_f32_e32 v4, v4, v21                                  // 0000002345B4: 06082B04
	v_add_f32_e32 v6, v6, v23                                  // 0000002345B8: 060C2F06
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000002345BC: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000002345C4: D5010003 20120703
	v_add_f32_e32 v8, v8, v24                                  // 0000002345CC: 06103108
	v_mov_b32_dpp v27, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000002345D0: 7E3602FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000002345D8: D5010005 200E0B05
	v_mov_b32_dpp v19, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000002345E0: 7E2602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 0000002345E8: D5010004 20160904
	v_add_f32_e32 v17, v17, v25                                // 0000002345F0: 06223311
	v_mov_b32_dpp v25, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000002345F4: 7E3202FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000002345FC: D5010002 20120502
	v_add_f32_e32 v5, v5, v27                                  // 000000234604: 060A3705
	v_mov_b32_dpp v23, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234608: 7E2E02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 000000234610: D5010008 20161108
	v_add_f32_e32 v4, v4, v19                                  // 000000234618: 06082704
	v_add_f32_e32 v2, v2, v25                                  // 00000023461C: 06043302
	v_mov_b32_dpp v18, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234620: 7E2402FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s4                       // 000000234628: D5010011 20122311
	v_mov_b32_dpp v22, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234630: 7E2C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000234638: D5010005 20120B05
	v_mov_b32_dpp v24, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234640: 7E3002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000234648: D5010002 20160502
	v_add_f32_e32 v3, v3, v7                                   // 000000234650: 06060F03
	v_dual_add_f32 v7, v17, v18 :: v_dual_add_f32 v8, v8, v23  // 000000234654: C9082511 07082F08
	v_mov_b32_dpp v19, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000023465C: 7E2602FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000234664: BF870004
	v_add_f32_e32 v2, v2, v24                                  // 000000234668: 06043102
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 00000023466C: D5010004 201A0904
	v_add_f32_e32 v5, v5, v22                                  // 000000234674: 060A2D05
	v_mov_b32_dpp v22, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234678: 7E2C02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000234680: D5010006 20160D06
	v_mov_b32_dpp v17, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234688: 7E2202FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000234690: D5010003 20160703
	v_mov_b32_dpp v18, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234698: 7E2402FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 0000002346A0: D5010007 20160F07
	v_add_f32_e32 v6, v6, v22                                  // 0000002346A8: 060C2D06
	v_mov_b32_dpp v22, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002346AC: 7E2C02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s6                          // 0000002346B4: D5010008 201A1108
	v_mov_b32_dpp v23, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002346BC: 7E2E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000002346C4: D5010002 201A0502
	v_add_f32_e32 v4, v4, v19                                  // 0000002346CC: 06082704
	v_mov_b32_dpp v21, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000002346D0: 7E2A02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000002346D8: D5010005 20160B05
	v_mov_b32_dpp v26, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000002346E0: 7E3402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 0000002346E8: D5010001 20120301
	v_dual_add_f32 v3, v3, v17 :: v_dual_add_f32 v8, v8, v22   // 0000002346F0: C9082303 03082D08
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v2, v2, v23   // 0000002346F8: C9082507 07022F02
	v_add_f32_e32 v5, v5, v21                                  // 000000234700: 060A2B05
	v_mov_b32_dpp v21, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234704: 7E2A02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s6                          // 00000023470C: D5010006 201A0D06
	v_add_f32_e32 v1, v1, v26                                  // 000000234714: 06023501
	v_mov_b32_dpp v17, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234718: 7E2202FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000234720: D5010003 201A0703
	v_mov_b32_e32 v19, v2                                      // 000000234728: 7E260302
	v_add_f32_e32 v6, v6, v21                                  // 00000023472C: 060C2B06
	v_mov_b32_dpp v18, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234730: 7E2402FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s6                          // 000000234738: D5010007 201A0F07
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000234740: D5010002 201E0502
	v_permlanex16_b32 v19, v19, s11, 0xfedcba98                // 000000234748: D65C0013 03FC1713 FEDCBA98
	v_add_f32_e32 v3, v3, v17                                  // 000000234754: 06062303
	v_mov_b32_e32 v17, v6                                      // 000000234758: 7E220306
	v_mov_b32_dpp v25, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000023475C: 7E3202FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000234764: D5010001 20160301
	v_cndmask_b32_e64 v6, -v6, v6, s7                          // 00000023476C: D5010006 201E0D06
	v_add_f32_e32 v2, v2, v19                                  // 000000234774: 06042702
	v_permlanex16_b32 v17, v17, s11, 0xfedcba98                // 000000234778: D65C0011 03FC1711 FEDCBA98
	v_dual_add_f32 v7, v7, v18 :: v_dual_mov_b32 v18, v8       // 000000234784: C9102507 07120108
	v_cndmask_b32_e64 v8, -v8, v8, s7                          // 00000023478C: D5010008 201E1108
	v_mov_b32_dpp v20, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234794: 7E2802FA FF016805
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000023479C: BF870244
	v_add_f32_e32 v6, v6, v17                                  // 0000002347A0: 060C2306
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000002347A4: D5010005 201A0B05
	v_permlanex16_b32 v18, v18, s11, 0xfedcba98                // 0000002347AC: D65C0012 03FC1712 FEDCBA98
	v_dual_add_f32 v1, v1, v25 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 0000002347B8: C9063301 010204FF 3DB504F3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000002347C4: 100C0CFF 3DB504F3
	v_cndmask_b32_e64 v15, -v3, v3, s7                         // 0000002347CC: D501000F 201E0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002347D4: BF870214
	v_add_f32_e32 v8, v8, v18                                  // 0000002347D8: 06102508
	v_mov_b32_dpp v24, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000002347DC: 7E3002FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s6                          // 0000002347E4: D5010001 201A0301
	v_permlanex16_b32 v3, v3, s11, 0xfedcba98                  // 0000002347EC: D65C0003 03FC1703 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002347F8: BF870194
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000002347FC: 101010FF 3DB504F3
	v_add_f32_e32 v1, v1, v24                                  // 000000234804: 06023101
	s_waitcnt vmcnt(2)                                         // 000000234808: BF890BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023480C: BF870112
	v_fma_mix_f32 v8, v9, v8, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234810: CC200808 8A021109
	v_mov_b32_e32 v21, v1                                      // 000000234818: 7E2A0301
	v_cndmask_b32_e64 v1, -v1, v1, s7                          // 00000023481C: D5010001 201E0301
	v_fma_mix_f32 v2, v10, v2, neg(0) op_sel_hi:[1,0,0]        // 000000234824: CC200002 8A02050A
	v_dual_add_f32 v5, v5, v20 :: v_dual_mov_b32 v20, v4       // 00000023482C: C9102905 05140104
	s_delay_alu instid0(VALU_DEP_4)                            // 000000234834: BF870004
	v_permlanex16_b32 v21, v21, s11, 0xfedcba98                // 000000234838: D65C0015 03FC1715 FEDCBA98
	v_fma_mix_f32 v6, v9, v6, neg(0) op_sel_hi:[1,0,0]         // 000000234844: CC200006 8A020D09
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 00000023484C: D5010004 201E0904
	v_mul_f32_e32 v18, 0xbfb8aa3b, v2                          // 000000234854: 102404FF BFB8AA3B
	v_permlanex16_b32 v20, v20, s11, 0xfedcba98                // 00000023485C: D65C0014 03FC1714 FEDCBA98
	v_add_f32_e32 v1, v1, v21                                  // 000000234868: 06022B01
	v_mul_f32_e32 v9, 0xbfb8aa3b, v6                           // 00000023486C: 10120CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234874: BF870114
	v_exp_f32_e32 v18, v18                                     // 000000234878: 7E244B12
	v_dual_add_f32 v4, v4, v20 :: v_dual_mul_f32 v1, 0x3db504f3, v1// 00000023487C: C9062904 040002FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000234888: BF870122
	v_exp_f32_e32 v9, v9                                       // 00000023488C: 7E124B09
	v_mov_b32_e32 v17, v7                                      // 000000234890: 7E220307
	v_dual_add_f32 v3, v15, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000234894: C906070F 030408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_2)// 0000002348A0: BF870333
	v_fma_mix_f32 v1, v10, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000002348A4: CC200801 8A02030A
	v_mul_f32_e32 v10, 0xbfb8aa3b, v8                          // 0000002348AC: 101410FF BFB8AA3B
	v_cndmask_b32_e64 v7, -v7, v7, s7                          // 0000002348B4: D5010007 201E0F07
	v_add_f32_e32 v18, 1.0, v18                                // 0000002348BC: 062424F2
	v_permlanex16_b32 v17, v17, s11, 0xfedcba98                // 0000002348C0: D65C0011 03FC1711 FEDCBA98
	s_waitcnt vmcnt(1)                                         // 0000002348CC: BF8907F7
	v_fma_mix_f32 v4, v12, v4, neg(0) op_sel_hi:[1,0,0]        // 0000002348D0: CC200004 8A02090C
	v_exp_f32_e32 v10, v10                                     // 0000002348D8: 7E144B0A
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 0000002348DC: 100606FF 3DB504F3
	v_div_scale_f32 v24, null, v18, v18, v2                    // 0000002348E4: D6FC7C18 040A2512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002348EC: BF870112
	v_fma_mix_f32 v3, v11, v3, neg(0) op_sel_hi:[1,0,0]        // 0000002348F0: CC200003 8A02070B
	v_rcp_f32_e32 v27, v24                                     // 0000002348F8: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002348FC: BF870096
	v_add_f32_e32 v10, 1.0, v10                                // 000000234900: 061414F2
	v_div_scale_f32 v23, null, v10, v10, v8                    // 000000234904: D6FC7C17 0422150A
	v_div_scale_f32 v20, s8, v8, v10, v8                       // 00000023490C: D6FC0814 04221508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000234914: BF870195
	v_fma_f32 v31, -v24, v27, 1.0                              // 000000234918: D613001F 23CA3718
	v_rcp_f32_e32 v26, v23                                     // 000000234920: 7E345517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000234924: BF870291
	v_fmac_f32_e32 v27, v31, v27                               // 000000234928: 5636371F
	v_fma_f32 v30, -v23, v26, 1.0                              // 00000023492C: D613001E 23CA3517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234934: BF870091
	v_dual_mul_f32 v19, 0xbfb8aa3b, v1 :: v_dual_fmac_f32 v26, v30, v26// 000000234938: C8C002FF 131A351E BFB8AA3B
	v_exp_f32_e32 v19, v19                                     // 000000234944: 7E264B13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234948: BF870091
	v_dual_add_f32 v9, 1.0, v9 :: v_dual_mul_f32 v30, v20, v26 // 00000023494C: C90612F2 091E3514
	v_div_scale_f32 v22, null, v9, v9, v6                      // 000000234954: D6FC7C16 041A1309
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000023495C: BF870292
	v_fma_f32 v35, -v23, v30, v20                              // 000000234960: D6130023 24523D17
	v_add_f32_e32 v19, 1.0, v19                                // 000000234968: 062626F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023496C: BF870113
	v_rcp_f32_e32 v15, v22                                     // 000000234970: 7E1E5516
	v_fmac_f32_e32 v30, v35, v26                               // 000000234974: 563C3523
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000234978: BF8701A2
	v_div_scale_f32 v25, null, v19, v19, v1                    // 00000023497C: D6FC7C19 04062713
	v_div_scale_f32 v33, s10, v1, v19, v1                      // 000000234984: D6FC0A21 04062701
	v_fma_f32 v20, -v23, v30, v20                              // 00000023498C: D6130014 24523D17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000234994: BF870313
	v_rcp_f32_e32 v28, v25                                     // 000000234998: 7E385519
	v_fma_f32 v29, -v22, v15, 1.0                              // 00000023499C: D613001D 23CA1F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002349A4: BF870291
	v_fmac_f32_e32 v15, v29, v15                               // 0000002349A8: 561E1F1D
	v_fma_f32 v32, -v25, v28, 1.0                              // 0000002349AC: D6130020 23CA3919
	v_mov_b32_e32 v21, v5                                      // 0000002349B4: 7E2A0305
	v_cndmask_b32_e64 v5, -v5, v5, s7                          // 0000002349B8: D5010005 201E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002349C0: BF870193
	v_fmac_f32_e32 v28, v32, v28                               // 0000002349C4: 56383920
	v_permlanex16_b32 v21, v21, s11, 0xfedcba98                // 0000002349C8: D65C0015 03FC1715 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002349D4: BF870112
	v_mul_f32_e32 v32, v33, v28                                // 0000002349D8: 10403921
	v_add_f32_e32 v5, v5, v21                                  // 0000002349DC: 060A2B05
	v_div_scale_f32 v21, s9, v2, v18, v2                       // 0000002349E0: D6FC0915 040A2502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002349E8: BF870233
	v_fma_f32 v37, -v25, v32, v33                              // 0000002349EC: D6130025 24864119
	v_add_f32_e32 v7, v7, v17                                  // 0000002349F4: 060E2307
	v_div_scale_f32 v17, vcc_lo, v6, v9, v6                    // 0000002349F8: D6FC6A11 041A1306
	v_mul_f32_e32 v31, v21, v27                                // 000000234A00: 103E3715
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234A04: BF870214
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_fmac_f32 v32, v37, v28// 000000234A08: C8C00AFF 05203925 3DB504F3
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000234A14: 100E0EFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234A1C: BF870214
	v_mul_f32_e32 v29, v17, v15                                // 000000234A20: 103A1F11
	v_fma_f32 v36, -v24, v31, v21                              // 000000234A24: D6130024 24563F18
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234A2C: BF870214
	v_fma_mix_f32 v5, v12, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234A30: CC200805 8A020B0C
	v_fma_mix_f32 v7, v11, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234A38: CC200807 8A020F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234A40: BF870214
	v_fma_f32 v34, -v22, v29, v17                              // 000000234A44: D6130022 24463B16
	v_fmac_f32_e32 v31, v36, v27                               // 000000234A4C: 563E3724
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234A50: BF870112
	v_fmac_f32_e32 v29, v34, v15                               // 000000234A54: 563A1F22
	v_fma_f32 v21, -v24, v31, v21                              // 000000234A58: D6130015 24563F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000234A60: BF870122
	v_fma_f32 v17, -v22, v29, v17                              // 000000234A64: D6130011 24463B16
	v_fma_f32 v22, -v25, v32, v33                              // 000000234A6C: D6130016 24864119
	v_div_fmas_f32 v15, v17, v15, v29                          // 000000234A74: D637000F 04761F11
	s_mov_b32 vcc_lo, s8                                       // 000000234A7C: BEEA0008
	v_div_fmas_f32 v17, v20, v26, v30                          // 000000234A80: D6370011 047A3514
	s_mov_b32 vcc_lo, s9                                       // 000000234A88: BEEA0009
	s_delay_alu instid0(VALU_DEP_2)                            // 000000234A8C: BF870002
	v_div_fixup_f32 v6, v15, v9, v6                            // 000000234A90: D6270006 041A130F
	v_div_fmas_f32 v20, v21, v27, v31                          // 000000234A98: D6370014 047E3715
	s_mov_b32 vcc_lo, s10                                      // 000000234AA0: BEEA000A
	v_div_fixup_f32 v8, v17, v10, v8                           // 000000234AA4: D6270008 04221511
	v_div_fmas_f32 v21, v22, v28, v32                          // 000000234AAC: D6370015 04823916
	v_mul_f32_e32 v3, v3, v6                                   // 000000234AB4: 10060D03
	v_div_fixup_f32 v2, v20, v18, v2                           // 000000234AB8: D6270002 040A2514
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234AC0: BF870214
	v_mul_f32_e32 v7, v7, v8                                   // 000000234AC4: 100E1107
	v_div_fixup_f32 v1, v21, v19, v1                           // 000000234AC8: D6270001 04062715
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000234AD0: BF870153
	v_dual_mov_b32 v21, s19 :: v_dual_mul_f32 v2, v4, v2       // 000000234AD4: CA060013 15020504
	v_mov_b32_e32 v20, s18                                     // 000000234ADC: 7E280212
	s_waitcnt vmcnt(0)                                         // 000000234AE0: BF8903F7
	v_fma_mix_f32 v4, v13, v7, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234AE4: CC200804 8A020F0D
	v_mul_f32_e32 v1, v5, v1                                   // 000000234AEC: 10020305
	v_fma_mix_f32 v5, v3, v13, v4 op_sel_hi:[0,1,0]            // 000000234AF0: CC200005 14121B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000234AF8: BF870122
	v_fma_mix_f32 v1, v14, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000234AFC: CC200801 8A02030E
	v_fma_mix_f32 v3, v3, v13, -v4 op_sel_hi:[0,1,0]           // 000000234B04: CC200003 94121B03
	v_fma_mix_f32 v6, v2, v14, v1 op_sel_hi:[0,1,0]            // 000000234B0C: CC200006 14061D02
	v_fma_mix_f32 v1, v2, v14, -v1 op_sel_hi:[0,1,0]           // 000000234B14: CC200001 94061D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234B1C: BF870112
	v_add_f32_e32 v2, v5, v6                                   // 000000234B20: 06040D05
	v_dual_add_f32 v4, v3, v1 :: v_dual_sub_f32 v5, v5, v6     // 000000234B24: C90A0303 04040D05
	v_sub_f32_e32 v1, v3, v1                                   // 000000234B2C: 08020303
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000234B30: BF870223
	v_mov_b32_dpp v3, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234B34: 7E0602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000234B3C: D5010002 200E0502
	v_mov_b32_dpp v6, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234B44: 7E0C02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000234B4C: D5010004 200E0904
	v_mov_b32_dpp v7, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234B54: 7E0E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000234B5C: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234B64: BF870113
	v_dual_add_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v6     // 000000234B68: C9080702 02020D04
	v_add_f32_e32 v4, v5, v7                                   // 000000234B70: 06080F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000234B74: BF870222
	v_mov_b32_dpp v5, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234B78: 7E0A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000234B80: D5010002 20120502
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234B88: 7E0C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000234B90: D5010003 20120703
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234B98: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000234BA0: D5010004 20120904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234BA8: BF870113
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v6     // 000000234BAC: C9080B02 02020D03
	v_add_f32_e32 v4, v4, v7                                   // 000000234BB4: 06080F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000234BB8: BF870222
	v_mov_b32_dpp v5, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234BBC: 7E0A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000234BC4: D5010002 20160502
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234BCC: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000234BD4: D5010003 20160703
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234BDC: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000234BE4: D5010004 20160904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234BEC: BF870113
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v6     // 000000234BF0: C9080B02 02020D03
	v_add_f32_e32 v4, v4, v7                                   // 000000234BF8: 06080F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000234BFC: BF870222
	v_mov_b32_dpp v5, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234C00: 7E0A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 000000234C08: D5010002 201A0502
	v_mov_b32_dpp v6, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234C10: 7E0C02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000234C18: D5010003 201A0703
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234C20: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 000000234C28: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000234C30: BF870113
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v6     // 000000234C34: C9080B02 02020D03
	v_add_f32_e32 v4, v4, v7                                   // 000000234C3C: 06080F04
	v_mov_b32_dpp v8, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000234C40: 7E1002FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000234C48: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000234C50: BF870214
	v_dual_mov_b32 v5, v2 :: v_dual_mov_b32 v6, v3             // 000000234C54: CA100102 05060103
	v_mov_b32_e32 v7, v4                                       // 000000234C5C: 7E0E0304
	v_cndmask_b32_e64 v4, -v4, v4, s7                          // 000000234C60: D5010004 201E0904
	v_cndmask_b32_e64 v2, -v2, v2, s7                          // 000000234C68: D5010002 201E0502
	v_cndmask_b32_e64 v3, -v3, v3, s7                          // 000000234C70: D5010003 201E0703
	v_permlanex16_b32 v5, v5, s11, 0xfedcba98                  // 000000234C78: D65C0005 03FC1705 FEDCBA98
	v_permlanex16_b32 v7, v7, s11, 0xfedcba98                  // 000000234C84: D65C0007 03FC1707 FEDCBA98
	v_add_f32_e32 v1, v1, v8                                   // 000000234C90: 06021101
	v_permlanex16_b32 v6, v6, s11, 0xfedcba98                  // 000000234C94: D65C0006 03FC1706 FEDCBA98
	s_mov_b32 s3, 0x3db504f3                                   // 000000234CA0: BE8300FF 3DB504F3
	v_add_f32_e32 v2, v2, v5                                   // 000000234CA8: 06040B02
	v_add_f32_e32 v4, v4, v7                                   // 000000234CAC: 06080F04
	v_mov_b32_dpp v8, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000234CB0: 7E1002FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s4                          // 000000234CB8: D5010001 20120301
	v_add_f32_e32 v3, v3, v6                                   // 000000234CC0: 06060D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234CC4: BF870092
	v_add_f32_e32 v1, v1, v8                                   // 000000234CC8: 06021101
	v_mov_b32_dpp v8, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000234CCC: 7E1002FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s5                          // 000000234CD4: D5010001 20160301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234CDC: BF870091
	v_add_f32_e32 v1, v1, v8                                   // 000000234CE0: 06021101
	v_mov_b32_dpp v8, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000234CE4: 7E1002FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s6                          // 000000234CEC: D5010001 201A0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234CF4: BF870091
	v_add_f32_e32 v1, v1, v8                                   // 000000234CF8: 06021101
	v_mov_b32_e32 v8, v1                                       // 000000234CFC: 7E100301
	v_cndmask_b32_e64 v1, -v1, v1, s7                          // 000000234D00: D5010001 201E0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000234D08: BF870092
	v_permlanex16_b32 v8, v8, s11, 0xfedcba98                  // 000000234D0C: D65C0008 03FC1708 FEDCBA98
	v_add_f32_e32 v5, v1, v8                                   // 000000234D18: 060A1101
	v_fma_mixlo_f16 v1, v2, s3, 0                              // 000000234D1C: CC210001 02000702
	v_fma_mixhi_f16 v1, v3, s3, 0                              // 000000234D24: CC220001 02000703
	v_fma_mixlo_f16 v2, v4, s3, 0                              // 000000234D2C: CC210002 02000704
	s_delay_alu instid0(VALU_DEP_4)                            // 000000234D34: BF870004
	v_fma_mixhi_f16 v2, v5, s3, 0                              // 000000234D38: CC220002 02000705
	ds_store_b64 v16, v[1:2]                                   // 000000234D40: D9340000 00000110
	s_or_b32 exec_lo, exec_lo, s23                             // 000000234D48: 8C7E177E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000234D4C: BF870001
	.long 0xd73c0001                                           // 000000234D50: D73C0001
	v_cndmask_b32_e32 v1, 2, v20, vcc_lo                       // 000000234D54: 02022882
	s_waitcnt lgkmcnt(0)                                       // 000000234D58: BF89FC07
	s_barrier                                                  // 000000234D5C: BFBD0000
	buffer_gl0_inv                                             // 000000234D60: E0AC0000 00000000
	s_mul_i32 s3, s18, s22                                     // 000000234D68: 96031612
	v_bfe_u32 v3, v0, 2, 3                                     // 000000234D6C: D6100003 020D0500
	.long 0xd7006a01                                           // 000000234D74: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000234D78: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000234D7C: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 000000234D80: D5207C02 01AA040F
	s_sub_i32 s4, s2, s3                                       // 000000234D88: 81840302
	s_load_b128 s[0:3], s[0:1], null                           // 000000234D8C: F4080000 F8000000
	s_lshl_b32 s4, s4, 6                                       // 000000234D94: 84048604
	global_load_b32 v1, v[1:2], off                            // 000000234D98: DC520000 017C0001
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000234DA0: 32040082
	v_dual_mov_b32 v31, 0 :: v_dual_and_b32 v26, 3, v0         // 000000234DA4: CA240080 1F1A0083
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v27, 0             // 000000234DAC: CA100080 1C1A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000234DB4: BF870193
	v_and_b32_e32 v2, 56, v2                                   // 000000234DB8: 360404B8
	v_lshlrev_b32_e32 v29, 6, v26                              // 000000234DBC: 303A3486
	ds_load_b128 v[42:45], v29                                 // 000000234DC0: DBFC0000 2A00001D
	ds_load_b128 v[46:49], v29 offset:16                       // 000000234DC8: DBFC0010 2E00001D
	v_or3_b32 v22, s4, v2, v3                                  // 000000234DD0: D6580016 040E0404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000234DD8: BF8700A1
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000234DDC: 342E2C9F
	s_waitcnt vmcnt(0)                                         // 000000234DE0: BF8903F7
	v_mad_i64_i32 v[12:13], null, v1, s20, v[22:23]            // 000000234DE4: D6FF7C0C 04582901
	s_waitcnt lgkmcnt(0)                                       // 000000234DEC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000234DF0: BF8704B1
	v_mad_u64_u32 v[1:2], null, 0x140, v12, s[0:1]             // 000000234DF4: D6FE7C01 000218FF 00000140
	s_add_u32 s0, s0, s2                                       // 000000234E00: 80000200
	s_addc_u32 s1, s1, s3                                      // 000000234E04: 82010301
	v_mad_u64_u32 v[70:71], null, v12, 10, s[0:1]              // 000000234E08: D6FE7C46 0001150C
	s_mov_b32 s0, exec_lo                                      // 000000234E10: BE80007E
	v_mad_u64_u32 v[2:3], null, 0x140, v13, v[2:3]             // 000000234E14: D6FE7C02 040A1AFF 00000140
	v_mad_u64_u32 v[71:72], null, v13, 10, v[71:72]            // 000000234E20: D6FE7C47 051D150D
	ds_load_b128 v[16:19], v29 offset:32                       // 000000234E28: DBFC0020 1000001D
	ds_load_b128 v[12:15], v29 offset:48                       // 000000234E30: DBFC0030 0C00001D
	ds_load_b128 v[50:53], v29 offset:256                      // 000000234E38: DBFC0100 3200001D
	ds_load_b128 v[54:57], v29 offset:272                      // 000000234E40: DBFC0110 3600001D
	ds_load_b128 v[58:61], v29 offset:512                      // 000000234E48: DBFC0200 3A00001D
	ds_load_b128 v[62:65], v29 offset:528                      // 000000234E50: DBFC0210 3E00001D
	ds_load_b128 v[66:69], v29 offset:768                      // 000000234E58: DBFC0300 4200001D
	v_lshlrev_b32_e32 v0, 4, v26                               // 000000234E60: 30003484
	s_clause 0x1                                               // 000000234E64: BF850001
	global_load_d16_b16 v33, v[70:71], off offset:8            // 000000234E68: DC820008 217C0046
	global_load_b64 v[24:25], v[70:71], off                    // 000000234E70: DC560000 187C0046
	.long 0xd7006a00                                           // 000000234E78: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000234E7C: 02020101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000234E80: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v2, vcc_lo                // 000000234E84: D5207C01 01AA0480
	s_clause 0x4                                               // 000000234E8C: BF850004
	global_load_b128 v[34:37], v[0:1], off                     // 000000234E90: DC5E0000 227C0000
	global_load_b128 v[38:41], v[0:1], off offset:64           // 000000234E98: DC5E0040 267C0000
	global_load_b128 v[8:11], v[0:1], off offset:128           // 000000234EA0: DC5E0080 087C0000
	global_load_b128 v[4:7], v[0:1], off offset:192            // 000000234EA8: DC5E00C0 047C0000
	global_load_b128 v[0:3], v[0:1], off offset:256            // 000000234EB0: DC5E0100 007C0000
	v_mov_b32_e32 v32, 0                                       // 000000234EB8: 7E400280
	v_mov_b32_e32 v30, 0                                       // 000000234EBC: 7E3C0280
	s_waitcnt vmcnt(4)                                         // 000000234EC0: BF8913F7
	v_and_b32_e32 v70, 0xf0f0f0f, v34                          // 000000234EC4: 368C44FF 0F0F0F0F
	v_lshrrev_b32_e32 v34, 4, v34                              // 000000234ECC: 32444484
	v_and_b32_e32 v76, 0xf0f0f0f, v36                          // 000000234ED0: 369848FF 0F0F0F0F
	v_lshrrev_b32_e32 v77, 4, v36                              // 000000234ED8: 329A4884
	v_and_b32_e32 v78, 0xf0f0f0f, v37                          // 000000234EDC: 369C4AFF 0F0F0F0F
	v_lshrrev_b32_e32 v79, 4, v37                              // 000000234EE4: 329E4A84
	s_waitcnt vmcnt(3)                                         // 000000234EE8: BF890FF7
	v_lshrrev_b32_e32 v36, 4, v38                              // 000000234EEC: 32484C84
	s_waitcnt vmcnt(2)                                         // 000000234EF0: BF890BF7
	v_and_b32_e32 v37, 0xf0f0f0f, v8                           // 000000234EF4: 364A10FF 0F0F0F0F
	v_lshrrev_b32_e32 v8, 4, v8                                // 000000234EFC: 32101084
	v_and_b32_e32 v34, 0xf0f0f0f, v34                          // 000000234F00: 364444FF 0F0F0F0F
	v_and_b32_e32 v74, 0xf0f0f0f, v35                          // 000000234F08: 369446FF 0F0F0F0F
	v_lshrrev_b32_e32 v75, 4, v35                              // 000000234F10: 32964684
	v_and_b32_e32 v35, 0xf0f0f0f, v38                          // 000000234F14: 36464CFF 0F0F0F0F
	v_and_b32_e32 v82, 0xf0f0f0f, v40                          // 000000234F1C: 36A450FF 0F0F0F0F
	v_lshrrev_b32_e32 v83, 4, v40                              // 000000234F24: 32A65084
	v_and_b32_e32 v36, 0xf0f0f0f, v36                          // 000000234F28: 364848FF 0F0F0F0F
	v_and_b32_e32 v8, 0xf0f0f0f, v8                            // 000000234F30: 361010FF 0F0F0F0F
	v_perm_b32 v40, v34, v70, 0xc040c00                        // 000000234F38: D6440028 03FE8D22 0C040C00
	v_and_b32_e32 v84, 0xf0f0f0f, v41                          // 000000234F44: 36A852FF 0F0F0F0F
	v_lshrrev_b32_e32 v85, 4, v41                              // 000000234F4C: 32AA5284
	v_perm_b32 v41, v34, v70, 0xc050c01                        // 000000234F50: D6440029 03FE8D22 0C050C01
	v_perm_b32 v71, v34, v70, 0xc060c02                        // 000000234F5C: D6440047 03FE8D22 0C060C02
	v_perm_b32 v70, v34, v70, 0xc070c03                        // 000000234F68: D6440046 03FE8D22 0C070C03
	v_perm_b32 v34, v36, v35, 0xc040c00                        // 000000234F74: D6440022 03FE4724 0C040C00
	v_perm_b32 v72, v36, v35, 0xc050c01                        // 000000234F80: D6440048 03FE4724 0C050C01
	v_perm_b32 v73, v36, v35, 0xc060c02                        // 000000234F8C: D6440049 03FE4724 0C060C02
	v_perm_b32 v86, v36, v35, 0xc070c03                        // 000000234F98: D6440056 03FE4724 0C070C03
	v_or_b32_e32 v35, 0x64006400, v40                          // 000000234FA4: 384650FF 64006400
	v_perm_b32 v40, v8, v37, 0xc040c00                         // 000000234FAC: D6440028 03FE4B08 0C040C00
	v_perm_b32 v87, v8, v37, 0xc050c01                         // 000000234FB8: D6440057 03FE4B08 0C050C01
	v_perm_b32 v88, v8, v37, 0xc060c02                         // 000000234FC4: D6440058 03FE4B08 0C060C02
	v_perm_b32 v8, v8, v37, 0xc070c03                          // 000000234FD0: D6440008 03FE4B08 0C070C03
	s_waitcnt vmcnt(1)                                         // 000000234FDC: BF8907F7
	v_and_b32_e32 v38, 0xf0f0f0f, v4                           // 000000234FE0: 364C08FF 0F0F0F0F
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000234FE8: 32080884
	v_or_b32_e32 v36, 0x64006400, v41                          // 000000234FEC: 384852FF 64006400
	.long 0xcc0f4023                                           // 000000234FF4: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 000000234FF8: 120246FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000235000: 381010FF 64006400
	v_lshrrev_b32_e32 v81, 4, v39                              // 000000235008: 32A24E84
	v_and_b32_e32 v4, 0xf0f0f0f, v4                            // 00000023500C: 360808FF 0F0F0F0F
	v_or_b32_e32 v34, 0x64006400, v34                          // 000000235014: 384444FF 64006400
	v_or_b32_e32 v37, 0x64006400, v71                          // 00000023501C: 384A8EFF 64006400
	.long 0xcc0f4008                                           // 000000235024: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000235028: 120210FF 0000E408
	v_and_b32_e32 v80, 0xf0f0f0f, v39                          // 000000235030: 36A04EFF 0F0F0F0F
	s_waitcnt vmcnt(0)                                         // 000000235038: BF8903F7
	v_lshrrev_b32_e32 v39, 4, v0                               // 00000023503C: 324E0084
	.long 0xcc0f4024                                           // 000000235040: CC0F4024
	v_mul_i32_i24_e32 v1, 0xe408, v36                          // 000000235044: 120248FF 0000E408
	v_dot2acc_f32_f16 v28, v35, v42                            // 00000023504C: 04385523
	v_perm_b32 v41, v4, v38, 0xc040c00                         // 000000235050: D6440029 03FE4D04 0C040C00
	.long 0xcc0f4022                                           // 00000023505C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 000000235060: 120244FF 0000E408
	v_and_b32_e32 v90, 0xf0f0f0f, v39                          // 000000235068: 36B44EFF 0F0F0F0F
	v_or_b32_e32 v39, 0x64006400, v72                          // 000000235070: 384E90FF 64006400
	v_perm_b32 v42, v4, v38, 0xc050c01                         // 000000235078: D644002A 03FE4D04 0C050C01
	.long 0xcc0f4047                                           // 000000235084: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v37                          // 000000235088: 12024AFF 0000E408
	v_dot2acc_f32_f16 v28, v36, v43                            // 000000235090: 04385724
	v_perm_b32 v89, v4, v38, 0xc060c02                         // 000000235094: D6440059 03FE4D04 0C060C02
	v_perm_b32 v4, v4, v38, 0xc070c03                          // 0000002350A0: D6440004 03FE4D04 0C070C03
	v_or_b32_e32 v38, 0x64006400, v70                          // 0000002350AC: 384C8CFF 64006400
	v_or_b32_e32 v40, 0x64006400, v40                          // 0000002350B4: 385050FF 64006400
	v_or_b32_e32 v41, 0x64006400, v41                          // 0000002350BC: 385252FF 64006400
	s_waitcnt lgkmcnt(4)                                       // 0000002350C4: BF89FC47
	v_dot2acc_f32_f16 v30, v34, v50                            // 0000002350C8: 043C6522
	v_or_b32_e32 v50, 0x64006400, v73                          // 0000002350CC: 386492FF 64006400
	.long 0xcc0f4027                                           // 0000002350D4: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 0000002350D8: 12024EFF 0000E408
	v_dot2acc_f32_f16 v28, v71, v44                            // 0000002350E0: 04385947
	v_or_b32_e32 v43, 0x64006400, v87                          // 0000002350E4: 3856AEFF 64006400
	v_or_b32_e32 v42, 0x64006400, v42                          // 0000002350EC: 385454FF 64006400
	.long 0xcc0f4026                                           // 0000002350F4: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 0000002350F8: 12024CFF 0000E408
	.long 0xcc0f4028                                           // 000000235100: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000235104: 120250FF 0000E408
	.long 0xcc0f4029                                           // 00000023510C: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000235110: 120252FF 0000E408
	v_and_b32_e32 v0, 0xf0f0f0f, v0                            // 000000235118: 360000FF 0F0F0F0F
	.long 0xcc0f4032                                           // 000000235120: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000235124: 120264FF 0000E408
	v_and_b32_e32 v87, 0xf0f0f0f, v7                           // 00000023512C: 36AE0EFF 0F0F0F0F
	v_dot2acc_f32_f16 v30, v39, v51                            // 000000235134: 043C6727
	.long 0xcc0f4046                                           // 000000235138: CC0F4046
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 00000023513C: 120256FF 0000E408
	.long 0xcc0f4047                                           // 000000235144: CC0F4047
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000235148: 120254FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 000000235150: BF89FC27
	v_dot2acc_f32_f16 v31, v40, v58                            // 000000235154: 043E7528
	s_waitcnt lgkmcnt(0)                                       // 000000235158: BF89FC07
	v_dot2acc_f32_f16 v32, v41, v66                            // 00000023515C: 04408529
	v_or_b32_e32 v66, 0x64006400, v89                          // 000000235160: 3884B2FF 64006400
	v_and_b32_e32 v89, 0xf0f0f0f, v1                           // 000000235168: 36B202FF 0F0F0F0F
	v_dot2acc_f32_f16 v28, v38, v45                            // 000000235170: 04385B26
	ds_load_b128 v[38:41], v29 offset:1024                     // 000000235174: DBFC0400 2600001D
	ds_load_b128 v[42:45], v29 offset:1040                     // 00000023517C: DBFC0410 2A00001D
	v_perm_b32 v51, v90, v0, 0xc040c00                         // 000000235184: D6440033 03FE015A 0C040C00
	v_dot2acc_f32_f16 v30, v50, v52                            // 000000235190: 043C6932
	v_or_b32_e32 v52, 0x64006400, v88                          // 000000235194: 3868B0FF 64006400
	v_dot2acc_f32_f16 v31, v70, v59                            // 00000023519C: 043E7746
	v_perm_b32 v58, v90, v0, 0xc050c01                         // 0000002351A0: D644003A 03FE015A 0C050C01
	v_or_b32_e32 v51, 0x64006400, v51                          // 0000002351AC: 386666FF 64006400
	v_dot2acc_f32_f16 v32, v71, v67                            // 0000002351B4: 04408747
	.long 0xcc0f4034                                           // 0000002351B8: CC0F4034
	v_mul_i32_i24_e32 v1, 0xe408, v52                          // 0000002351BC: 120268FF 0000E408
	v_perm_b32 v59, v90, v0, 0xc060c02                         // 0000002351C4: D644003B 03FE015A 0C060C02
	v_or_b32_e32 v4, 0x64006400, v4                            // 0000002351D0: 380808FF 64006400
	v_or_b32_e32 v58, 0x64006400, v58                          // 0000002351D8: 387474FF 64006400
	.long 0xcc0f4033                                           // 0000002351E0: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 0000002351E4: 120266FF 0000E408
	.long 0xcc0f4042                                           // 0000002351EC: CC0F4042
	v_mul_i32_i24_e32 v1, 0xe408, v66                          // 0000002351F0: 120284FF 0000E408
	v_dot2acc_f32_f16 v31, v52, v60                            // 0000002351F8: 043E7934
	v_or_b32_e32 v50, 0x64006400, v86                          // 0000002351FC: 3864ACFF 64006400
	.long 0xcc0f4004                                           // 000000235204: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000235208: 120208FF 0000E408
	.long 0xcc0f4056                                           // 000000235210: CC0F4056
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000235214: 120274FF 0000E408
	v_perm_b32 v0, v90, v0, 0xc070c03                          // 00000023521C: D6440000 03FE015A 0C070C03
	s_waitcnt lgkmcnt(1)                                       // 000000235228: BF89FC17
	v_dot2acc_f32_f16 v27, v51, v38                            // 00000023522C: 04364D33
	v_or_b32_e32 v38, 0x64006400, v59                          // 000000235230: 384C76FF 64006400
	v_dot2acc_f32_f16 v31, v8, v61                             // 000000235238: 043E7B08
	v_and_b32_e32 v8, 0xf0f0f0f, v9                            // 00000023523C: 361012FF 0F0F0F0F
	v_lshrrev_b32_e32 v9, 4, v9                                // 000000235244: 32121284
	v_dot2acc_f32_f16 v32, v66, v68                            // 000000235248: 04408942
	v_dot2acc_f32_f16 v27, v86, v39                            // 00000023524C: 04364F56
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000235250: 380000FF 64006400
	v_lshrrev_b32_e32 v86, 4, v6                               // 000000235258: 32AC0C84
	v_and_b32_e32 v9, 0xf0f0f0f, v9                            // 00000023525C: 361212FF 0F0F0F0F
	v_dot2acc_f32_f16 v32, v4, v69                             // 000000235264: 04408B04
	.long 0xcc0f4004                                           // 000000235268: CC0F4004
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 00000023526C: 12024CFF 0000E408
	ds_load_b128 v[58:61], v29 offset:544                      // 000000235274: DBFC0220 3A00001D
	ds_load_b128 v[66:69], v29 offset:560                      // 00000023527C: DBFC0230 4200001D
	.long 0xcc0f4000                                           // 000000235284: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000235288: 120200FF 0000E408
	v_lshrrev_b32_e32 v90, 4, v1                               // 000000235290: 32B40284
	.long 0xcc0f4032                                           // 000000235294: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 000000235298: 120264FF 0000E408
	v_dual_dot2acc_f32_f16 v27, v4, v40 :: v_dual_and_b32 v4, 0xf0f0f0f, v75// 0000002352A0: CB245104 1B0496FF 0F0F0F0F
	v_and_b32_e32 v40, 0xf0f0f0f, v5                           // 0000002352AC: 36500AFF 0F0F0F0F
	v_lshrrev_b32_e32 v75, 4, v5                               // 0000002352B4: 32960A84
	v_and_b32_e32 v39, 0xf0f0f0f, v11                          // 0000002352B8: 364E16FF 0F0F0F0F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002352C0: BF870004
	v_dot2acc_f32_f16 v27, v0, v41                             // 0000002352C4: 04365300
	v_perm_b32 v5, v4, v74, 0xc040c00                          // 0000002352C8: D6440005 03FE9504 0C040C00
	v_perm_b32 v0, v4, v74, 0xc050c01                          // 0000002352D4: D6440000 03FE9504 0C050C01
	v_and_b32_e32 v41, 0xf0f0f0f, v6                           // 0000002352E0: 36520CFF 0F0F0F0F
	v_perm_b32 v6, v4, v74, 0xc060c02                          // 0000002352E8: D6440006 03FE9504 0C060C02
	v_perm_b32 v1, v4, v74, 0xc070c03                          // 0000002352F4: D6440001 03FE9504 0C070C03
	v_or_b32_e32 v5, 0x64006400, v5                            // 000000235300: 380A0AFF 64006400
	v_or_b32_e32 v0, 0x64006400, v0                            // 000000235308: 380000FF 64006400
	v_lshrrev_b32_e32 v74, 4, v2                               // 000000235310: 32940484
	v_or_b32_e32 v4, 0x64006400, v6                            // 000000235314: 38080CFF 64006400
	v_or_b32_e32 v1, 0x64006400, v1                            // 00000023531C: 380202FF 64006400
	.long 0xcc0f4005                                           // 000000235324: CC0F4005
	v_mul_i32_i24_e32 v1, 0xe408, v5                           // 000000235328: 12020AFF 0000E408
	.long 0xcc0f4000                                           // 000000235330: CC0F4000
	v_mul_i32_i24_e32 v1, 0xe408, v0                           // 000000235334: 120200FF 0000E408
	v_lshrrev_b32_e32 v11, 4, v11                              // 00000023533C: 32161684
	v_lshrrev_b32_e32 v88, 4, v7                               // 000000235340: 32B00E84
	.long 0xcc0f4001                                           // 000000235344: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v1                           // 000000235348: 120202FF 0000E408
	v_dot2acc_f32_f16 v28, v5, v46                             // 000000235350: 04385D05
	v_and_b32_e32 v46, 0xf0f0f0f, v2                           // 000000235354: 365C04FF 0F0F0F0F
	.long 0xcc0f4002                                           // 00000023535C: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v4                           // 000000235360: 120208FF 0000E408
	v_and_b32_e32 v11, 0xf0f0f0f, v11                          // 000000235368: 361616FF 0F0F0F0F
	ds_load_b128 v[34:37], v29 offset:784                      // 000000235370: DBFC0310 2200001D
	v_dot2acc_f32_f16 v28, v0, v47                             // 000000235378: 04385F00
	v_and_b32_e32 v0, 0xf0f0f0f, v81                           // 00000023537C: 3600A2FF 0F0F0F0F
	v_and_b32_e32 v75, 0xf0f0f0f, v75                          // 000000235384: 369696FF 0F0F0F0F
	v_and_b32_e32 v38, 0xf0f0f0f, v10                          // 00000023538C: 364C14FF 0F0F0F0F
	v_lshrrev_b32_e32 v10, 4, v10                              // 000000235394: 32141484
	v_dot2acc_f32_f16 v28, v2, v48                             // 000000235398: 04386102
	v_perm_b32 v48, v0, v80, 0xc040c00                         // 00000023539C: D6440030 03FEA100 0C040C00
	v_perm_b32 v91, v0, v80, 0xc050c01                         // 0000002353A8: D644005B 03FEA100 0C050C01
	v_perm_b32 v92, v0, v80, 0xc060c02                         // 0000002353B4: D644005C 03FEA100 0C060C02
	v_perm_b32 v80, v0, v80, 0xc070c03                         // 0000002353C0: D6440050 03FEA100 0C070C03
	v_dot2acc_f32_f16 v28, v1, v49                             // 0000002353CC: 04386301
	v_or_b32_e32 v48, 0x64006400, v48                          // 0000002353D0: 386060FF 64006400
	v_and_b32_e32 v49, 0xf0f0f0f, v77                          // 0000002353D8: 36629AFF 0F0F0F0F
	v_and_b32_e32 v77, 0xf0f0f0f, v79                          // 0000002353E0: 369A9EFF 0F0F0F0F
	v_dual_dot2acc_f32_f16 v30, v50, v53 :: v_dual_and_b32 v79, 0xf0f0f0f, v83// 0000002353E8: CB246B32 1E4EA6FF 0F0F0F0F
	v_and_b32_e32 v83, 0xf0f0f0f, v85                          // 0000002353F4: 36A6AAFF 0F0F0F0F
	v_or_b32_e32 v85, 0x64006400, v91                          // 0000002353FC: 38AAB6FF 64006400
	.long 0xcc0f4030                                           // 000000235404: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000235408: 120260FF 0000E408
	v_or_b32_e32 v91, 0x64006400, v92                          // 000000235410: 38B6B8FF 64006400
	v_or_b32_e32 v80, 0x64006400, v80                          // 000000235418: 38A0A0FF 64006400
	v_and_b32_e32 v10, 0xf0f0f0f, v10                          // 000000235420: 361414FF 0F0F0F0F
	.long 0xcc0f4055                                           // 000000235428: CC0F4055
	v_mul_i32_i24_e32 v1, 0xe408, v85                          // 00000023542C: 1202AAFF 0000E408
	v_dot2acc_f32_f16 v30, v48, v54                            // 000000235434: 043C6D30
	v_and_b32_e32 v48, 0xf0f0f0f, v86                          // 000000235438: 3660ACFF 0F0F0F0F
	.long 0xcc0f4056                                           // 000000235440: CC0F4056
	v_mul_i32_i24_e32 v1, 0xe408, v91                          // 000000235444: 1202B6FF 0000E408
	v_and_b32_e32 v54, 0xf0f0f0f, v88                          // 00000023544C: 366CB0FF 0F0F0F0F
	.long 0xcc0f4050                                           // 000000235454: CC0F4050
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000235458: 1202A0FF 0000E408
	v_dot2acc_f32_f16 v30, v85, v55                            // 000000235460: 043C6F55
	v_perm_b32 v85, v49, v76, 0xc040c00                        // 000000235464: D6440055 03FE9931 0C040C00
	v_perm_b32 v88, v9, v8, 0xc050c01                          // 000000235470: D6440058 03FE1109 0C050C01
	v_and_b32_e32 v55, 0xf0f0f0f, v90                          // 00000023547C: 366EB4FF 0F0F0F0F
	v_perm_b32 v90, v77, v78, 0xc060c02                        // 000000235484: D644005A 03FE9D4D 0C060C02
	v_dot2acc_f32_f16 v30, v86, v56                            // 000000235490: 043C7156
	v_perm_b32 v56, v49, v76, 0xc050c01                        // 000000235494: D6440038 03FE9931 0C050C01
	v_perm_b32 v86, v49, v76, 0xc060c02                        // 0000002354A0: D6440056 03FE9931 0C060C02
	v_perm_b32 v49, v49, v76, 0xc070c03                        // 0000002354AC: D6440031 03FE9931 0C070C03
	v_perm_b32 v76, v9, v8, 0xc040c00                          // 0000002354B8: D644004C 03FE1109 0C040C00
	v_dot2acc_f32_f16 v30, v80, v57                            // 0000002354C4: 043C7350
	v_perm_b32 v57, v77, v78, 0xc040c00                        // 0000002354C8: D6440039 03FE9D4D 0C040C00
	v_perm_b32 v80, v77, v78, 0xc050c01                        // 0000002354D4: D6440050 03FE9D4D 0C050C01
	v_perm_b32 v77, v77, v78, 0xc070c03                        // 0000002354E0: D644004D 03FE9D4D 0C070C03
	v_or_b32_e32 v76, 0x64006400, v76                          // 0000002354EC: 389898FF 64006400
	v_perm_b32 v78, v9, v8, 0xc060c02                          // 0000002354F4: D644004E 03FE1109 0C060C02
	v_or_b32_e32 v88, 0x64006400, v88                          // 000000235500: 38B0B0FF 64006400
	v_perm_b32 v8, v9, v8, 0xc070c03                           // 000000235508: D6440008 03FE1109 0C070C03
	v_perm_b32 v91, v79, v82, 0xc040c00                        // 000000235514: D644005B 03FEA54F 0C040C00
	.long 0xcc0f404c                                           // 000000235520: CC0F404C
	v_mul_i32_i24_e32 v1, 0xe408, v76                          // 000000235524: 120298FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v78                           // 00000023552C: 38129CFF 64006400
	.long 0xcc0f404e                                           // 000000235534: CC0F404E
	v_mul_i32_i24_e32 v1, 0xe408, v88                          // 000000235538: 1202B0FF 0000E408
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000235540: 381010FF 64006400
	v_perm_b32 v88, v75, v40, 0xc060c02                        // 000000235548: D6440058 03FE514B 0C060C02
	v_dot2acc_f32_f16 v31, v76, v62                            // 000000235554: 043E7D4C
	.long 0xcc0f4009                                           // 000000235558: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 00000023555C: 120212FF 0000E408
	v_perm_b32 v62, v79, v82, 0xc050c01                        // 000000235564: D644003E 03FEA54F 0C050C01
	.long 0xcc0f4008                                           // 000000235570: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000235574: 120210FF 0000E408
	v_perm_b32 v76, v79, v82, 0xc060c02                        // 00000023557C: D644004C 03FEA54F 0C060C02
	v_dot2acc_f32_f16 v31, v78, v63                            // 000000235588: 043E7F4E
	v_perm_b32 v63, v79, v82, 0xc070c03                        // 00000023558C: D644003F 03FEA54F 0C070C03
	v_perm_b32 v78, v83, v84, 0xc040c00                        // 000000235598: D644004E 03FEA953 0C040C00
	v_perm_b32 v79, v83, v84, 0xc050c01                        // 0000002355A4: D644004F 03FEA953 0C050C01
	v_perm_b32 v82, v83, v84, 0xc070c03                        // 0000002355B0: D6440052 03FEA953 0C070C03
	v_dot2acc_f32_f16 v31, v9, v64                             // 0000002355BC: 043E8109
	v_perm_b32 v9, v75, v40, 0xc040c00                         // 0000002355C0: D6440009 03FE514B 0C040C00
	v_perm_b32 v64, v83, v84, 0xc060c02                        // 0000002355CC: D6440040 03FEA953 0C060C02
	v_perm_b32 v83, v10, v38, 0xc050c01                        // 0000002355D8: D6440053 03FE4D0A 0C050C01
	v_perm_b32 v84, v10, v38, 0xc060c02                        // 0000002355E4: D6440054 03FE4D0A 0C060C02
	v_dot2acc_f32_f16 v31, v8, v65                             // 0000002355F0: 043E8308
	v_perm_b32 v65, v75, v40, 0xc050c01                        // 0000002355F4: D6440041 03FE514B 0C050C01
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000235600: 381212FF 64006400
	v_perm_b32 v8, v10, v38, 0xc040c00                         // 000000235608: D6440008 03FE4D0A 0C040C00
	v_perm_b32 v38, v10, v38, 0xc070c03                        // 000000235614: D6440026 03FE4D0A 0C070C03
	v_perm_b32 v10, v75, v40, 0xc070c03                        // 000000235620: D644000A 03FE514B 0C070C03
	v_or_b32_e32 v65, 0x64006400, v65                          // 00000023562C: 388282FF 64006400
	.long 0xcc0f4009                                           // 000000235634: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000235638: 120212FF 0000E408
	v_or_b32_e32 v40, 0x64006400, v88                          // 000000235640: 3850B0FF 64006400
	ds_load_b128 v[50:53], v29 offset:288                      // 000000235648: DBFC0120 3200001D
	ds_load_b128 v[70:73], v29 offset:304                      // 000000235650: DBFC0130 4600001D
	v_or_b32_e32 v8, 0x64006400, v8                            // 000000235658: 381010FF 64006400
	.long 0xcc0f4041                                           // 000000235660: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 000000235664: 120282FF 0000E408
	s_waitcnt lgkmcnt(2)                                       // 00000023566C: BF89FC27
	v_dot2acc_f32_f16 v32, v9, v34                             // 000000235670: 04404509
	v_or_b32_e32 v9, 0x64006400, v10                           // 000000235674: 381214FF 64006400
	.long 0xcc0f400a                                           // 00000023567C: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000235680: 120250FF 0000E408
	v_or_b32_e32 v34, 0x64006400, v85                          // 000000235688: 3844AAFF 64006400
	.long 0xcc0f4008                                           // 000000235690: CC0F4008
	v_mul_i32_i24_e32 v1, 0xe408, v8                           // 000000235694: 120210FF 0000E408
	v_dot2acc_f32_f16 v32, v65, v35                            // 00000023569C: 04404741
	v_or_b32_e32 v35, 0x64006400, v62                          // 0000002356A0: 38467CFF 64006400
	.long 0xcc0f4009                                           // 0000002356A8: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 0000002356AC: 120212FF 0000E408
	v_lshrrev_b32_e32 v81, 4, v3                               // 0000002356B4: 32A20684
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002356B8: BF870004
	v_dual_dot2acc_f32_f16 v31, v8, v58 :: v_dual_dot2acc_f32_f16 v32, v10, v36// 0000002356BC: CB187508 1F20490A
	v_perm_b32 v10, v55, v89, 0xc040c00                        // 0000002356C4: D644000A 03FEB337 0C040C00
	.long 0xcc0f4023                                           // 0000002356D0: CC0F4023
	v_mul_i32_i24_e32 v1, 0xe408, v35                          // 0000002356D4: 120246FF 0000E408
	v_or_b32_e32 v58, 0x64006400, v64                          // 0000002356DC: 387480FF 64006400
	v_or_b32_e32 v64, 0x64006400, v84                          // 0000002356E4: 3880A8FF 64006400
	v_dot2acc_f32_f16 v32, v9, v37                             // 0000002356EC: 04404B09
	v_or_b32_e32 v10, 0x64006400, v10                          // 0000002356F0: 381414FF 64006400
	v_perm_b32 v9, v55, v89, 0xc050c01                         // 0000002356F8: D6440009 03FEB337 0C050C01
	v_perm_b32 v75, v11, v39, 0xc040c00                        // 000000235704: D644004B 03FE4F0B 0C040C00
	v_or_b32_e32 v38, 0x64006400, v38                          // 000000235710: 384C4CFF 64006400
	.long 0xcc0f4040                                           // 000000235718: CC0F4040
	v_mul_i32_i24_e32 v1, 0xe408, v64                          // 00000023571C: 120280FF 0000E408
	.long 0xcc0f400a                                           // 000000235724: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 000000235728: 120214FF 0000E408
	v_or_b32_e32 v9, 0x64006400, v9                            // 000000235730: 381212FF 64006400
	v_and_b32_e32 v47, 0xf0f0f0f, v3                           // 000000235738: 365E06FF 0F0F0F0F
	v_and_b32_e32 v81, 0xf0f0f0f, v81                          // 000000235740: 36A2A2FF 0F0F0F0F
	v_perm_b32 v88, v11, v39, 0xc050c01                        // 000000235748: D6440058 03FE4F0B 0C050C01
	v_dot2acc_f32_f16 v27, v10, v42                            // 000000235754: 0436550A
	.long 0xcc0f400a                                           // 000000235758: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 00000023575C: 120244FF 0000E408
	v_or_b32_e32 v34, 0x64006400, v91                          // 000000235764: 3844B6FF 64006400
	.long 0xcc0f4009                                           // 00000023576C: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000235770: 120212FF 0000E408
	v_perm_b32 v40, v11, v39, 0xc060c02                        // 000000235778: D6440028 03FE4F0B 0C060C02
	v_perm_b32 v39, v11, v39, 0xc070c03                        // 000000235784: D6440027 03FE4F0B 0C070C03
	v_perm_b32 v11, v55, v89, 0xc060c02                        // 000000235790: D644000B 03FEB337 0C060C02
	.long 0xcc0f4022                                           // 00000023579C: CC0F4022
	v_mul_i32_i24_e32 v1, 0xe408, v34                          // 0000002357A0: 120244FF 0000E408
	v_dot2acc_f32_f16 v27, v9, v43                             // 0000002357A8: 04365709
	v_or_b32_e32 v9, 0x64006400, v56                           // 0000002357AC: 381270FF 64006400
	v_or_b32_e32 v75, 0x64006400, v75                          // 0000002357B4: 389696FF 64006400
	.long 0xcc0f4026                                           // 0000002357BC: CC0F4026
	v_mul_i32_i24_e32 v1, 0xe408, v38                          // 0000002357C0: 12024CFF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 0000002357C8: BF89FC17
	v_dot2acc_f32_f16 v30, v34, v50                            // 0000002357CC: 043C6522
	v_perm_b32 v43, v81, v47, 0xc050c01                        // 0000002357D0: D644002B 03FE5F51 0C050C01
	v_dot2acc_f32_f16 v28, v10, v16                            // 0000002357DC: 0438210A
	v_or_b32_e32 v10, 0x64006400, v86                          // 0000002357E0: 3814ACFF 64006400
	v_or_b32_e32 v11, 0x64006400, v11                          // 0000002357E8: 381616FF 64006400
	v_dot2acc_f32_f16 v30, v35, v51                            // 0000002357F0: 043C6723
	v_or_b32_e32 v51, 0x64006400, v63                          // 0000002357F4: 38667EFF 64006400
	v_or_b32_e32 v63, 0x64006400, v83                          // 0000002357FC: 387EA6FF 64006400
	.long 0xcc0f4009                                           // 000000235804: CC0F4009
	v_mul_i32_i24_e32 v1, 0xe408, v9                           // 000000235808: 120212FF 0000E408
	v_or_b32_e32 v50, 0x64006400, v76                          // 000000235810: 386498FF 64006400
	v_or_b32_e32 v76, 0x64006400, v88                          // 000000235818: 3898B0FF 64006400
	.long 0xcc0f404b                                           // 000000235820: CC0F404B
	v_mul_i32_i24_e32 v1, 0xe408, v75                          // 000000235824: 120296FF 0000E408
	.long 0xcc0f403f                                           // 00000023582C: CC0F403F
	v_mul_i32_i24_e32 v1, 0xe408, v63                          // 000000235830: 12027EFF 0000E408
	.long 0xcc0f400a                                           // 000000235838: CC0F400A
	v_mul_i32_i24_e32 v1, 0xe408, v10                          // 00000023583C: 120214FF 0000E408
	.long 0xcc0f400b                                           // 000000235844: CC0F400B
	v_mul_i32_i24_e32 v1, 0xe408, v11                          // 000000235848: 120216FF 0000E408
	v_dot2acc_f32_f16 v28, v9, v17                             // 000000235850: 04382309
	v_or_b32_e32 v43, 0x64006400, v43                          // 000000235854: 385656FF 64006400
	v_dot2acc_f32_f16 v31, v63, v59                            // 00000023585C: 043E773F
	.long 0xcc0f404c                                           // 000000235860: CC0F404C
	v_mul_i32_i24_e32 v1, 0xe408, v76                          // 000000235864: 120298FF 0000E408
	ds_load_b128 v[0:3], v29 offset:800                        // 00000023586C: DBFC0320 0000001D
	ds_load_b128 v[4:7], v29 offset:816                        // 000000235874: DBFC0330 0400001D
	v_perm_b32 v55, v55, v89, 0xc070c03                        // 00000023587C: D6440037 03FEB337 0C070C03
	v_dot2acc_f32_f16 v27, v11, v44                            // 000000235888: 0436590B
	v_dual_dot2acc_f32_f16 v31, v64, v60 :: v_dual_dot2acc_f32_f16 v28, v10, v18// 00000023588C: CB187940 1F1C250A
	ds_load_b128 v[8:11], v29 offset:1056                      // 000000235894: DBFC0420 0800001D
	ds_load_b128 v[34:37], v29 offset:1072                     // 00000023589C: DBFC0430 2200001D
	.long 0xcc0f402b                                           // 0000002358A4: CC0F402B
	v_mul_i32_i24_e32 v1, 0xe408, v43                          // 0000002358A8: 120256FF 0000E408
	v_dual_dot2acc_f32_f16 v31, v38, v61 :: v_dual_and_b32 v74, 0xf0f0f0f, v74// 0000002358B0: CB247B26 1F4A94FF 0F0F0F0F
	v_perm_b32 v94, v54, v87, 0xc050c01                        // 0000002358BC: D644005E 03FEAF36 0C050C01
	v_perm_b32 v95, v54, v87, 0xc060c02                        // 0000002358C8: D644005F 03FEAF36 0C060C02
	v_or_b32_e32 v18, 0x64006400, v49                          // 0000002358D4: 382462FF 64006400
	v_or_b32_e32 v55, 0x64006400, v55                          // 0000002358DC: 386E6EFF 64006400
	v_dot2acc_f32_f16 v31, v75, v66                            // 0000002358E4: 043E854B
	v_perm_b32 v85, v74, v46, 0xc050c01                        // 0000002358E8: D6440055 03FE5D4A 0C050C01
	v_perm_b32 v42, v74, v46, 0xc060c02                        // 0000002358F4: D644002A 03FE5D4A 0C060C02
	v_perm_b32 v16, v81, v47, 0xc060c02                        // 000000235900: D6440010 03FE5F51 0C060C02
	v_perm_b32 v17, v81, v47, 0xc070c03                        // 00000023590C: D6440011 03FE5F51 0C070C03
	v_dot2acc_f32_f16 v31, v76, v67                            // 000000235918: 043E874C
	v_perm_b32 v65, v48, v41, 0xc040c00                        // 00000023591C: D6440041 03FE5330 0C040C00
	v_perm_b32 v92, v48, v41, 0xc050c01                        // 000000235928: D644005C 03FE5330 0C050C01
	v_perm_b32 v93, v48, v41, 0xc060c02                        // 000000235934: D644005D 03FE5330 0C060C02
	v_perm_b32 v41, v48, v41, 0xc070c03                        // 000000235940: D6440029 03FE5330 0C070C03
	v_perm_b32 v48, v54, v87, 0xc040c00                        // 00000023594C: D6440030 03FEAF36 0C040C00
	v_perm_b32 v54, v54, v87, 0xc070c03                        // 000000235958: D6440036 03FEAF36 0C070C03
	v_perm_b32 v87, v74, v46, 0xc040c00                        // 000000235964: D6440057 03FE5D4A 0C040C00
	v_or_b32_e32 v65, 0x64006400, v65                          // 000000235970: 388282FF 64006400
	v_perm_b32 v46, v74, v46, 0xc070c03                        // 000000235978: D644002E 03FE5D4A 0C070C03
	v_perm_b32 v74, v81, v47, 0xc040c00                        // 000000235984: D644004A 03FE5F51 0C040C00
	v_or_b32_e32 v29, 0x64006400, v57                          // 000000235990: 383A72FF 64006400
	v_or_b32_e32 v49, 0x64006400, v77                          // 000000235998: 38629AFF 64006400
	v_or_b32_e32 v77, 0x64006400, v92                          // 0000002359A0: 389AB8FF 64006400
	v_or_b32_e32 v81, 0x64006400, v87                          // 0000002359A8: 38A2AEFF 64006400
	.long 0xcc0f4012                                           // 0000002359B0: CC0F4012
	v_mul_i32_i24_e32 v1, 0xe408, v18                          // 0000002359B4: 120224FF 0000E408
	.long 0xcc0f4032                                           // 0000002359BC: CC0F4032
	v_mul_i32_i24_e32 v1, 0xe408, v50                          // 0000002359C0: 120264FF 0000E408
	.long 0xcc0f4041                                           // 0000002359C8: CC0F4041
	v_mul_i32_i24_e32 v1, 0xe408, v65                          // 0000002359CC: 120282FF 0000E408
	.long 0xcc0f4037                                           // 0000002359D4: CC0F4037
	v_mul_i32_i24_e32 v1, 0xe408, v55                          // 0000002359D8: 12026EFF 0000E408
	v_or_b32_e32 v44, 0x64006400, v80                          // 0000002359E0: 3858A0FF 64006400
	v_or_b32_e32 v56, 0x64006400, v78                          // 0000002359E8: 38709CFF 64006400
	v_or_b32_e32 v62, 0x64006400, v82                          // 0000002359F0: 387CA4FF 64006400
	v_or_b32_e32 v78, 0x64006400, v93                          // 0000002359F8: 389CBAFF 64006400
	v_or_b32_e32 v82, 0x64006400, v85                          // 000000235A00: 38A4AAFF 64006400
	.long 0xcc0f401d                                           // 000000235A08: CC0F401D
	v_mul_i32_i24_e32 v1, 0xe408, v29                          // 000000235A0C: 12023AFF 0000E408
	.long 0xcc0f4033                                           // 000000235A14: CC0F4033
	v_mul_i32_i24_e32 v1, 0xe408, v51                          // 000000235A18: 120266FF 0000E408
	.long 0xcc0f404d                                           // 000000235A20: CC0F404D
	v_mul_i32_i24_e32 v1, 0xe408, v77                          // 000000235A24: 12029AFF 0000E408
	.long 0xcc0f4051                                           // 000000235A2C: CC0F4051
	v_mul_i32_i24_e32 v1, 0xe408, v81                          // 000000235A30: 1202A2FF 0000E408
	s_waitcnt lgkmcnt(3)                                       // 000000235A38: BF89FC37
	v_dual_dot2acc_f32_f16 v27, v55, v45 :: v_dual_dot2acc_f32_f16 v32, v65, v0// 000000235A3C: CB185B37 1B200141
	v_dot2acc_f32_f16 v30, v50, v52                            // 000000235A44: 043C6932
	v_dot2acc_f32_f16 v28, v18, v19                            // 000000235A48: 04382712
	v_or_b32_e32 v47, 0x64006400, v90                          // 000000235A4C: 385EB4FF 64006400
	v_or_b32_e32 v57, 0x64006400, v79                          // 000000235A54: 38729EFF 64006400
	v_or_b32_e32 v41, 0x64006400, v41                          // 000000235A5C: 385252FF 64006400
	v_or_b32_e32 v42, 0x64006400, v42                          // 000000235A64: 385454FF 64006400
	.long 0xcc0f402c                                           // 000000235A6C: CC0F402C
	v_mul_i32_i24_e32 v1, 0xe408, v44                          // 000000235A70: 120258FF 0000E408
	.long 0xcc0f4038                                           // 000000235A78: CC0F4038
	v_mul_i32_i24_e32 v1, 0xe408, v56                          // 000000235A7C: 120270FF 0000E408
	.long 0xcc0f404e                                           // 000000235A84: CC0F404E
	v_mul_i32_i24_e32 v1, 0xe408, v78                          // 000000235A88: 12029CFF 0000E408
	.long 0xcc0f4052                                           // 000000235A90: CC0F4052
	v_mul_i32_i24_e32 v1, 0xe408, v82                          // 000000235A94: 1202A4FF 0000E408
	s_waitcnt lgkmcnt(1)                                       // 000000235A9C: BF89FC17
	v_dot2acc_f32_f16 v27, v81, v8                             // 000000235AA0: 04361151
	v_dot2acc_f32_f16 v32, v77, v1                             // 000000235AA4: 0440034D
	v_dot2acc_f32_f16 v30, v51, v53                            // 000000235AA8: 043C6B33
	v_dot2acc_f32_f16 v28, v29, v12                            // 000000235AAC: 0438191D
	v_or_b32_e32 v48, 0x64006400, v48                          // 000000235AB0: 386060FF 64006400
	v_or_b32_e32 v46, 0x64006400, v46                          // 000000235AB8: 385C5CFF 64006400
	.long 0xcc0f402f                                           // 000000235AC0: CC0F402F
	v_mul_i32_i24_e32 v1, 0xe408, v47                          // 000000235AC4: 12025EFF 0000E408
	.long 0xcc0f4039                                           // 000000235ACC: CC0F4039
	v_mul_i32_i24_e32 v1, 0xe408, v57                          // 000000235AD0: 120272FF 0000E408
	.long 0xcc0f4029                                           // 000000235AD8: CC0F4029
	v_mul_i32_i24_e32 v1, 0xe408, v41                          // 000000235ADC: 120252FF 0000E408
	.long 0xcc0f402a                                           // 000000235AE4: CC0F402A
	v_mul_i32_i24_e32 v1, 0xe408, v42                          // 000000235AE8: 120254FF 0000E408
	v_dot2acc_f32_f16 v27, v82, v9                             // 000000235AF0: 04361352
	v_dot2acc_f32_f16 v32, v78, v2                             // 000000235AF4: 0440054E
	v_dot2acc_f32_f16 v30, v56, v70                            // 000000235AF8: 043C8D38
	v_dot2acc_f32_f16 v28, v44, v13                            // 000000235AFC: 04381B2C
	v_or_b32_e32 v40, 0x64006400, v40                          // 000000235B00: 385050FF 64006400
	v_or_b32_e32 v79, 0x64006400, v94                          // 000000235B08: 389EBCFF 64006400
	v_or_b32_e32 v74, 0x64006400, v74                          // 000000235B10: 389494FF 64006400
	.long 0xcc0f4031                                           // 000000235B18: CC0F4031
	v_mul_i32_i24_e32 v1, 0xe408, v49                          // 000000235B1C: 120262FF 0000E408
	.long 0xcc0f403a                                           // 000000235B24: CC0F403A
	v_mul_i32_i24_e32 v1, 0xe408, v58                          // 000000235B28: 120274FF 0000E408
	.long 0xcc0f4030                                           // 000000235B30: CC0F4030
	v_mul_i32_i24_e32 v1, 0xe408, v48                          // 000000235B34: 120260FF 0000E408
	.long 0xcc0f402e                                           // 000000235B3C: CC0F402E
	v_mul_i32_i24_e32 v1, 0xe408, v46                          // 000000235B40: 12025CFF 0000E408
	v_dual_dot2acc_f32_f16 v27, v42, v10 :: v_dual_dot2acc_f32_f16 v32, v41, v3// 000000235B48: CB18152A 1B200729
	v_dot2acc_f32_f16 v30, v57, v71                            // 000000235B50: 043C8F39
	v_dot2acc_f32_f16 v28, v47, v14                            // 000000235B54: 04381D2F
	v_or_b32_e32 v39, 0x64006400, v39                          // 000000235B58: 384E4EFF 64006400
	v_or_b32_e32 v80, 0x64006400, v95                          // 000000235B60: 38A0BEFF 64006400
	.long 0xcc0f403e                                           // 000000235B68: CC0F403E
	v_mul_i32_i24_e32 v1, 0xe408, v62                          // 000000235B6C: 12027CFF 0000E408
	.long 0xcc0f4028                                           // 000000235B74: CC0F4028
	v_mul_i32_i24_e32 v1, 0xe408, v40                          // 000000235B78: 120250FF 0000E408
	.long 0xcc0f404f                                           // 000000235B80: CC0F404F
	v_mul_i32_i24_e32 v1, 0xe408, v79                          // 000000235B84: 12029EFF 0000E408
	.long 0xcc0f404a                                           // 000000235B8C: CC0F404A
	v_mul_i32_i24_e32 v1, 0xe408, v74                          // 000000235B90: 120294FF 0000E408
	v_dual_dot2acc_f32_f16 v27, v46, v11 :: v_dual_dot2acc_f32_f16 v32, v48, v4// 000000235B98: CB18172E 1B200930
	v_dot2acc_f32_f16 v30, v58, v72                            // 000000235BA0: 043C913A
	v_dot2acc_f32_f16 v28, v49, v15                            // 000000235BA4: 04381F31
	v_or_b32_e32 v54, 0x64006400, v54                          // 000000235BA8: 386C6CFF 64006400
	v_or_b32_e32 v16, 0x64006400, v16                          // 000000235BB0: 382020FF 64006400
	.long 0xcc0f4027                                           // 000000235BB8: CC0F4027
	v_mul_i32_i24_e32 v1, 0xe408, v39                          // 000000235BBC: 12024EFF 0000E408
	.long 0xcc0f4050                                           // 000000235BC4: CC0F4050
	v_mul_i32_i24_e32 v1, 0xe408, v80                          // 000000235BC8: 1202A0FF 0000E408
	s_waitcnt lgkmcnt(0)                                       // 000000235BD0: BF89FC07
	v_dual_dot2acc_f32_f16 v27, v74, v34 :: v_dual_dot2acc_f32_f16 v32, v79, v5// 000000235BD4: CB18454A 1B200B4F
	v_dual_dot2acc_f32_f16 v31, v40, v68 :: v_dual_dot2acc_f32_f16 v30, v62, v73// 000000235BDC: CB188928 1F1E933E
	v_fma_mix_f32 v0, v24, v28, 0 op_sel_hi:[1,0,0]            // 000000235BE4: CC200000 0A023918
	v_or_b32_e32 v17, 0x64006400, v17                          // 000000235BEC: 382222FF 64006400
	.long 0xcc0f4036                                           // 000000235BF4: CC0F4036
	v_mul_i32_i24_e32 v1, 0xe408, v54                          // 000000235BF8: 12026CFF 0000E408
	.long 0xcc0f4001                                           // 000000235C00: CC0F4001
	v_mul_i32_i24_e32 v1, 0xe408, v16                          // 000000235C04: 120220FF 0000E408
	v_dual_dot2acc_f32_f16 v27, v43, v35 :: v_dual_dot2acc_f32_f16 v32, v80, v6// 000000235C0C: CB18472B 1B200D50
	v_dot2acc_f32_f16 v31, v39, v69                            // 000000235C14: 043E8B27
	v_fma_mix_f32 v0, v24, v30, v0 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000235C18: CC200800 0C023D18
	.long 0xcc0f4002                                           // 000000235C20: CC0F4002
	v_mul_i32_i24_e32 v1, 0xe408, v17                          // 000000235C24: 120222FF 0000E408
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000235C2C: BF870194
	v_dual_dot2acc_f32_f16 v27, v1, v36 :: v_dual_dot2acc_f32_f16 v32, v54, v7// 000000235C30: CB184901 1B200F36
	v_fma_mix_f32 v0, v25, v31, v0 op_sel_hi:[1,0,0]           // 000000235C38: CC200000 0C023F19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000235C40: BF870112
	v_dot2acc_f32_f16 v27, v2, v37                             // 000000235C44: 04364B02
	v_fma_mix_f32 v0, v25, v32, v0 op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000235C48: CC200800 0C024119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000235C50: BF870091
	v_fma_mix_f32 v0, v33, v27, v0 op_sel_hi:[1,0,0]           // 000000235C54: CC200000 0C023721
	v_mov_b32_dpp v1, v0 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000235C5C: 7E0202FA FF016100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000235C64: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 000000235C68: 06000300
	v_mov_b32_dpp v1, v0 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000235C6C: 7E0202FA FF016200
	v_cmpx_eq_u32_e32 0, v26                                   // 000000235C74: 7D943480
	s_cbranch_execz 26                                         // 000000235C78: BFA5001A <_ZN7halogen12_GLOBAL__N_114k_i4r_rows_epiEPKhliPKfPKDF16_S6_PKiPf+0x19e4>
	.long 0xd72c0004                                           // 000000235C7C: D72C0004
	v_cndmask_b32_e32 v0, v21, v20, vcc_lo                     // 000000235C80: 02002915
	.long 0xd72c0005                                           // 000000235C84: D72C0005
	v_cndmask_b32_e32 v0, v20, v21, vcc_lo                     // 000000235C88: 02002B14
	v_mad_u64_u32 v[2:3], null, v20, s20, 0                    // 000000235C8C: D6FE7C02 02002914
	v_add_f32_e32 v6, v0, v1                                   // 000000235C94: 060C0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000235C98: BF870122
	v_add3_u32 v3, v3, v5, v4                                  // 000000235C9C: D6550003 04120B03
	.long 0xd73c0004                                           // 000000235CA4: D73C0004
	v_cndmask_b32_e32 v1, 2, v22, vcc_lo                       // 000000235CA8: 02022C82
	.long 0xd73c0002                                           // 000000235CAC: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000235CB0: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000235CB4: BF870091
	.long 0xd7006a02                                           // 000000235CB8: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000235CBC: 02020410
	v_add_co_ci_u32_e64 v3, null, s17, v3, vcc_lo              // 000000235CC0: D5207C03 01AA0611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000235CC8: BF870092
	.long 0xd7006a00                                           // 000000235CCC: D7006A00
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000235CD0: 02020902
	v_add_co_ci_u32_e64 v1, null, v3, v5, vcc_lo               // 000000235CD4: D5207C01 01AA0B03
	global_store_b32 v[0:1], v6, off                           // 000000235CDC: DC6A0000 007C0600
	s_endpgm                                                   // 000000235CE4: BFB00000
		...

