00000000007c8400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007C8400: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007C8408: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C840C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 0000007C8410: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 0000007C8414: 362E009F
	.long 0x7f0a3880                                           // 0000007C8418: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 0000007C841C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 0000007C8420: BF89FC07
	.long 0xd4510004                                           // 0000007C8424: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007C8428: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000007C842C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000007C8430: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000007C8434: 98078002
	s_add_u32 s4, s8, s20                                      // 0000007C8438: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000007C843C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000007C8440: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007C8444: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000007C8448: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C844C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000007C8450: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C8454: 30020282
	s_add_u32 s20, s14, s20                                    // 0000007C8458: 8014140E
	s_clause 0x1                                               // 0000007C845C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007C8460: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007C8468: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000007C8470: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000007C8474: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007C8478: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000007C847C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000007C8480: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000007C8484: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000007C8488: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007C848C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000007C8490: 85049D18
	v_mad_u64_u32 v[17:18], null, s22, s7, v[1:2]              // 0000007C8494: D6FE7C11 04040E16
	s_add_i32 s21, s21, s4                                     // 0000007C849C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000007C84A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000007C84A4: B3940801
	.long 0xd72c0001                                           // 0000007C84A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v22, vcc_lo                      // 0000007C84AC: 02022C04
	s_mul_i32 s21, s22, s6                                     // 0000007C84B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007C84B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000007C84B8: 4A0E0204
	v_add_nc_u32_e32 v24, v1, v23                              // 0000007C84BC: 4A302F01
	s_cselect_b32 s4, -1, 0                                    // 0000007C84C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000007C84C4: B2940800
	v_min_i32_e32 v25, s20, v7                                 // 0000007C84C8: 22320E14
	s_cselect_b32 s20, -1, 0                                   // 0000007C84CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C84D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000007C84D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000007C84D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007C84DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007C84E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000007C84E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007C84F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v18                               // 0000007C84FC: 4A062405
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C8500: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000007C8504: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000007C8510: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C8514: 02023318
	.long 0x7e0a3982                                           // 0000007C8518: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C851C: BF870114
	v_add_nc_u32_e32 v26, s21, v3                              // 0000007C8520: 4A340615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007C8524: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 0000007C8530: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 0000007C8538: BF89FC07
	s_barrier                                                  // 0000007C853C: BFBD0000
	buffer_gl0_inv                                             // 0000007C8540: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007C8548: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007C854C: CA100080 02000080
	s_and_saveexec_b32 s21, s5                                 // 0000007C8554: BE952005
	s_cbranch_execz 11                                         // 0000007C8558: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007C855C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8560: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007C8564: 3408029F
	.long 0xd7006a03                                           // 0000007C8568: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007C856C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007C8570: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007C8578: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007C8580: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007C8584: 7E021701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000007C8588: 8C7E157E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007C858C: 4A0630A0
	s_mov_b32 s5, exec_lo                                      // 0000007C8590: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C8594: BF870001
	.long 0xd4c1007e                                           // 0000007C8598: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007C859C: 02023303
	s_cbranch_execz 11                                         // 0000007C85A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007C85A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C85A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007C85AC: 3406049F
	.long 0xd7006a02                                           // 0000007C85B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007C85B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007C85B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007C85C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007C85C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007C85CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C85D0: 8C7E057E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007C85D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007C85DC: 7E060280
	s_mov_b32 s5, exec_lo                                      // 0000007C85E0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C85E4: BF870002
	.long 0xd4c1007e                                           // 0000007C85E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007C85EC: 02023305
	s_cbranch_execz 11                                         // 0000007C85F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007C85F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C85F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007C85FC: 340C069F
	.long 0xd7006a05                                           // 0000007C8600: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007C8604: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007C8608: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007C8610: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007C8618: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007C861C: 7E061703
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C8620: 8C7E057E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007C8624: 4A0A30FF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000007C862C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C8630: BF870001
	.long 0xd4c1007e                                           // 0000007C8634: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007C8638: 02023305
	s_cbranch_execz 11                                         // 0000007C863C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007C8640: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8644: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007C8648: 340A089F
	.long 0xd7006a04                                           // 0000007C864C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007C8650: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007C8654: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007C865C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007C8664: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007C8668: 7E081704
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C866C: 8C7E057E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007C8670: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007C867C: 7E0A0280
	s_mov_b32 s5, exec_lo                                      // 0000007C8680: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C8684: BF870002
	.long 0xd4c1007e                                           // 0000007C8688: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007C868C: 02023307
	s_cbranch_execz 11                                         // 0000007C8690: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007C8694: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8698: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007C869C: 34100A9F
	.long 0xd7006a07                                           // 0000007C86A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007C86A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007C86A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007C86B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007C86B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007C86BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C86C0: 8C7E057E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007C86C4: 4A0E30FF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000007C86CC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C86D0: BF870001
	.long 0xd4c1007e                                           // 0000007C86D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007C86D8: 02023307
	s_cbranch_execz 11                                         // 0000007C86DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007C86E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C86E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007C86E8: 340E0C9F
	.long 0xd7006a06                                           // 0000007C86EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007C86F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007C86F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007C86FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007C8704: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007C8708: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C870C: 8C7E057E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 0000007C8710: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007C871C: 7E0E0280
	s_mov_b32 s5, exec_lo                                      // 0000007C8720: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C8724: BF870002
	.long 0xd4c1007e                                           // 0000007C8728: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007C872C: 02023309
	s_cbranch_execz 11                                         // 0000007C8730: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000007C8734: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8738: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000007C873C: 34140E9F
	.long 0xd7006a09                                           // 0000007C8740: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007C8744: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 0000007C8748: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 0000007C8750: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000007C8758: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007C875C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C8760: 8C7E057E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 0000007C8764: 4A1230FF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000007C876C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C8770: BF870001
	.long 0xd4c1007e                                           // 0000007C8774: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007C8778: 02023309
	s_cbranch_execz 11                                         // 0000007C877C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000007C8780: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8784: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000007C8788: 3412109F
	.long 0xd7006a08                                           // 0000007C878C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007C8790: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 0000007C8794: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 0000007C879C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000007C87A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007C87A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C87AC: 8C7E057E
	s_branch 9                                                 // 0000007C87B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000007C87B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C87B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007C87BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007C87C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007C87C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007C87C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007C87CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007C87D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007C87D4: 7E100301
	s_add_u32 s8, s8, s18                                      // 0000007C87D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000007C87DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000007C87E0: 85059F0F
	v_dual_mov_b32 v9, s7 :: v_dual_mov_b32 v20, 0             // 0000007C87E4: CA100007 09140080
	s_add_u32 s18, s14, s5                                     // 0000007C87EC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000007C87F0: 8213800F
	.long 0xd4410005                                           // 0000007C87F4: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C87F8: 02023318
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007C87FC: 86928112
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v14, 0             // 0000007C8800: CA100080 0D0E0080
	v_mad_u64_u32 v[18:19], null, v9, s18, s[8:9]              // 0000007C8808: D6FE7C12 00202509
	.long 0xd72c0009                                           // 0000007C8810: D72C0009
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000007C8814: 02002607
	.long 0xd72c000a                                           // 0000007C8818: D72C000A
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000007C881C: 02002406
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v16, 0             // 0000007C8820: CA100080 1B100080
	v_cndmask_b32_e64 v28, 0, 1, s20                           // 0000007C8828: D501001C 00510280
	v_mov_b32_e32 v15, 0                                       // 0000007C8830: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007C8834: BF870004
	v_add3_u32 v29, v10, v19, v9                               // 0000007C8838: D655001D 0426270A
	s_and_saveexec_b32 s6, s5                                  // 0000007C8840: BE862005
	s_cbranch_execz 22                                         // 0000007C8844: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v24     // 0000007C8848: CA220080 14083084
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8850: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007C8854: 3414129F
	.long 0xd7006a09                                           // 0000007C8858: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007C885C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007C8860: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000007C8868: 916A147E
	global_load_b128 v[13:16], v[9:10], off                    // 0000007C886C: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 0000007C8874: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 1, v24                               // 0000007C8878: 30123081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C887C: BF870091
	.long 0xd7006a09                                           // 0000007C8880: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 0000007C8884: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v26, vcc_lo              // 0000007C8888: D5207C0A 01AA3480
	global_load_d16_b16 v9, v[9:10], off                       // 0000007C8890: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 0000007C8898: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 0000007C889C: 7E281709
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007C88A0: 8C7E067E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000007C88A4: CA100080 1F200080
	v_mov_b32_e32 v30, 0                                       // 0000007C88AC: 7E3C0280
	s_and_saveexec_b32 s18, s5                                 // 0000007C88B0: BE922005
	s_cbranch_execz 429                                        // 0000007C88B4: BFA501AD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xb6c>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v9, 32, v24     // 0000007C88B8: CA200080 1E0830A0
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v19, 5, v24    // 0000007C88C0: CA220080 20123085
	v_mov_b32_e32 v27, 0                                       // 0000007C88C8: 7E360280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C88CC: BF870003
	v_lshlrev_b32_e32 v33, 4, v9                               // 0000007C88D0: 30421284
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v34, 1, v9     // 0000007C88D4: CA220080 1F221281
	v_mov_b32_e32 v35, v20                                     // 0000007C88DC: 7E460314
	s_mul_i32 s5, s15, 6                                       // 0000007C88E0: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000007C88E4: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000007C88E8: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000007C88EC: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000007C88F0: 9615860E
	s_mov_b32 s20, 0                                           // 0000007C88F4: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007C88F8: 8488810E
	s_branch 375                                               // 0000007C88FC: BFA00177 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007C8900: 8C7E0E7E
	v_cndmask_b32_e64 v50, v20, v1, s4                         // 0000007C8904: D5010032 00120314
	v_cndmask_b32_e64 v36, v1, v2, s4                          // 0000007C890C: D5010024 00120501
	v_and_b32_e32 v1, 0xff, v13                                // 0000007C8914: 36021AFF 000000FF
	v_cndmask_b32_e64 v42, v7, v8, s4                          // 0000007C891C: D501002A 00121107
	v_cndmask_b32_e64 v41, v6, v7, s4                          // 0000007C8924: D5010029 00120F06
	v_cndmask_b32_e64 v40, v5, v6, s4                          // 0000007C892C: D5010028 00120D05
	v_cndmask_b32_e64 v39, v4, v5, s4                          // 0000007C8934: D5010027 00120B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C893C: 30020282
	v_cndmask_b32_e64 v38, v3, v4, s4                          // 0000007C8940: D5010026 00120903
	v_cndmask_b32_e64 v37, v2, v3, s4                          // 0000007C8948: D5010025 00120702
	v_mov_b32_e32 v43, v8                                      // 0000007C8950: 7E560308
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007C8954: 3428269F
	ds_load_b32 v51, v1                                        // 0000007C8958: D8D80000 33000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 0000007C8960: 32021A86
	v_add_nc_u32_e32 v33, 0x200, v33                           // 0000007C8964: 4A4242FF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 0000007C896C: 8B05057E
	v_add_nc_u32_e32 v34, 64, v34                              // 0000007C8970: 4A4444C0
	s_or_b32 s20, s5, s20                                      // 0000007C8974: 8C141405
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8978: 360202FF 000003FC
	ds_load_b32 v52, v1                                        // 0000007C8980: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 0000007C8988: 32021A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C898C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8990: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 0000007C8998: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 0000007C89A0: 32021A96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C89A4: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 0000007C89AC: D8D80000 36000001
	v_and_b32_e32 v1, 0xff, v14                                // 0000007C89B4: 36021CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C89BC: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C89C0: 30020282
	ds_load_b32 v55, v1                                        // 0000007C89C4: D8D80000 37000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 0000007C89CC: 32021C86
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C89D0: 360202FF 000003FC
	ds_load_b32 v56, v1                                        // 0000007C89D8: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 0000007C89E0: 32021C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C89E4: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C89E8: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 0000007C89F0: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 0000007C89F8: 32021C96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C89FC: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 0000007C8A04: D8D80000 3A000001
	v_and_b32_e32 v1, 0xff, v15                                // 0000007C8A0C: 36021EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C8A14: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C8A18: 30020282
	ds_load_b32 v59, v1                                        // 0000007C8A1C: D8D80000 3B000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 0000007C8A24: 32021E86
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8A28: 360202FF 000003FC
	ds_load_b32 v60, v1                                        // 0000007C8A30: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 0000007C8A38: 32021E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C8A3C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8A40: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 0000007C8A48: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 0000007C8A50: 32021E96
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8A54: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 0000007C8A5C: D8D80000 3E000001
	v_and_b32_e32 v1, 0xff, v16                                // 0000007C8A64: 360220FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C8A6C: BF8700B1
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C8A70: 30020282
	ds_load_b32 v63, v1                                        // 0000007C8A74: D8D80000 3F000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 0000007C8A7C: 32022086
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8A80: 360202FF 000003FC
	ds_load_b32 v64, v1                                        // 0000007C8A88: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 0000007C8A90: 3202208E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C8A94: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8A98: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 0000007C8AA0: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 0000007C8AA8: 32022096
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C8AAC: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 0000007C8AB4: D8D80000 42000001
	.long 0xd73c0001                                           // 0000007C8ABC: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007C8AC0: 02022681
	v_dual_mov_b32 v20, v35 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000007C8AC4: CA200123 141226FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8AD0: BF870092
	.long 0xd7006a30                                           // 0000007C8AD4: D7006A30
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000007C8AD8: 0202020A
	v_add_co_ci_u32_e64 v49, null, s11, v2, vcc_lo             // 0000007C8ADC: D5207C31 01AA040B
	s_clause 0x3                                               // 0000007C8AE4: BF850003
	global_load_b128 v[1:4], v[48:49], off                     // 0000007C8AE8: DC5E0000 017C0030
	global_load_b128 v[5:8], v[48:49], off offset:16           // 0000007C8AF0: DC5E0010 057C0030
	global_load_b128 v[13:16], v[48:49], off offset:32         // 0000007C8AF8: DC5E0020 0D7C0030
	global_load_b128 v[44:47], v[48:49], off offset:48         // 0000007C8B00: DC5E0030 2C7C0030
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007C8B08: BF890CF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000007C8B0C: CC1A4001 1A026701
	s_waitcnt lgkmcnt(14)                                      // 0000007C8B14: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8B18: BF8700A1
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000007C8B1C: CC1A4001 1C066902
	s_waitcnt lgkmcnt(13)                                      // 0000007C8B24: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000007C8B28: CC1A4001 1C066B03
	s_waitcnt lgkmcnt(12)                                      // 0000007C8B30: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8B34: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000007C8B38: CC1A4001 1C066D04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007C8B40: BF8908B7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000007C8B44: CC1A4001 1C066F05
	s_waitcnt lgkmcnt(10)                                      // 0000007C8B4C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8B50: BF8700A1
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000007C8B54: CC1A4001 1C067106
	s_waitcnt lgkmcnt(9)                                       // 0000007C8B5C: BF89FC97
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000007C8B60: CC1A4001 1C067307
	s_waitcnt lgkmcnt(8)                                       // 0000007C8B68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8B6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000007C8B70: CC1A4001 1C067508
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007C8B78: BF890477
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000007C8B7C: CC1A4001 1C06770D
	s_waitcnt lgkmcnt(6)                                       // 0000007C8B84: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8B88: BF8700A1
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000007C8B8C: CC1A4001 1C06790E
	s_waitcnt lgkmcnt(5)                                       // 0000007C8B94: BF89FC57
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000007C8B98: CC1A4001 1C067B0F
	s_waitcnt lgkmcnt(4)                                       // 0000007C8BA0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8BA4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000007C8BA8: CC1A4001 1C067D10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007C8BB0: BF890037
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000007C8BB4: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000007C8BBC: D7006A2C
	v_cndmask_b32_e32 v0, v48, v8, vcc_lo                      // 0000007C8BC0: 02001130
	s_waitcnt lgkmcnt(2)                                       // 0000007C8BC4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007C8BC8: BF870132
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007C8BCC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s9, v49, vcc_lo             // 0000007C8BD4: D5207C2D 01AA6209
	s_waitcnt lgkmcnt(1)                                       // 0000007C8BDC: BF89FC17
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007C8BE0: CC1A4001 1C06832E
	s_waitcnt lgkmcnt(0)                                       // 0000007C8BE8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8BEC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007C8BF0: CC1A4001 1C06852F
	v_fmac_f32_e32 v30, v50, v1                                // 0000007C8BF8: 563C0332
	s_clause 0x3                                               // 0000007C8BFC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000007C8C00: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000007C8C08: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000007C8C10: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000007C8C18: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000007C8C20: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000007C8C24: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8C2C: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000007C8C30: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000007C8C38: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8C40: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000007C8C44: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000007C8C4C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000007C8C50: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8C58: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000007C8C5C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000007C8C64: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8C6C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000007C8C70: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000007C8C78: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000007C8C7C: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8C84: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000007C8C88: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000007C8C90: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8C98: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000007C8C9C: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 0000007C8CA4: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000007C8CA8: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000007C8CB0: D7006A2C
	v_cndmask_b32_e32 v0, v48, v6, vcc_lo                      // 0000007C8CB4: 02000D30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C8CB8: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007C8CBC: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s7, v49, vcc_lo             // 0000007C8CC4: D5207C2D 01AA6207
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007C8CCC: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8CD4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007C8CD8: CC1A4001 1C06852F
	v_fmac_f32_e32 v32, v50, v1                                // 0000007C8CE0: 56400332
	s_clause 0x3                                               // 0000007C8CE4: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000007C8CE8: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000007C8CF0: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000007C8CF8: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000007C8D00: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000007C8D08: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000007C8D0C: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8D14: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000007C8D18: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000007C8D20: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8D28: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000007C8D2C: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000007C8D34: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000007C8D38: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8D40: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000007C8D44: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000007C8D4C: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8D54: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000007C8D58: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000007C8D60: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000007C8D64: CC1A4001 1C06770D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8D6C: BF870091
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000007C8D70: CC1A4001 1C06790E
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000007C8D78: CC1A4001 1C067B0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8D80: BF8700A1
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000007C8D84: CC1A4001 1C067D10
	s_waitcnt vmcnt(0)                                         // 0000007C8D8C: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000007C8D90: CC1A4001 1C067F2C
	.long 0xd7006a2c                                           // 0000007C8D98: D7006A2C
	v_cndmask_b32_e32 v0, v48, v21, vcc_lo                     // 0000007C8D9C: 02002B30
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C8DA0: BF870122
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007C8DA4: CC1A4001 1C06812D
	v_add_co_ci_u32_e64 v45, null, s19, v49, vcc_lo            // 0000007C8DAC: D5207C2D 01AA6213
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007C8DB4: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8DBC: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007C8DC0: CC1A4001 1C06852F
	v_fmac_f32_e32 v31, v50, v1                                // 0000007C8DC8: 563E0332
	s_clause 0x3                                               // 0000007C8DCC: BF850003
	global_load_b128 v[1:4], v[44:45], off                     // 0000007C8DD0: DC5E0000 017C002C
	global_load_b128 v[5:8], v[44:45], off offset:16           // 0000007C8DD8: DC5E0010 057C002C
	global_load_b128 v[13:16], v[44:45], off offset:32         // 0000007C8DE0: DC5E0020 0D7C002C
	global_load_b128 v[44:47], v[44:45], off offset:48         // 0000007C8DE8: DC5E0030 2C7C002C
	s_waitcnt vmcnt(3)                                         // 0000007C8DF0: BF890FF7
	v_dot2_f32_bf16 v1, v1, v51, 0                             // 0000007C8DF4: CC1A4001 1A026701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8DFC: BF870091
	v_dot2_f32_bf16 v1, v2, v52, v1                            // 0000007C8E00: CC1A4001 1C066902
	v_dot2_f32_bf16 v1, v3, v53, v1                            // 0000007C8E08: CC1A4001 1C066B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8E10: BF8700A1
	v_dot2_f32_bf16 v1, v4, v54, v1                            // 0000007C8E14: CC1A4001 1C066D04
	s_waitcnt vmcnt(2)                                         // 0000007C8E1C: BF890BF7
	v_dot2_f32_bf16 v1, v5, v55, v1                            // 0000007C8E20: CC1A4001 1C066F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8E28: BF870091
	v_dot2_f32_bf16 v1, v6, v56, v1                            // 0000007C8E2C: CC1A4001 1C067106
	v_dot2_f32_bf16 v1, v7, v57, v1                            // 0000007C8E34: CC1A4001 1C067307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C8E3C: BF8700A1
	v_dot2_f32_bf16 v1, v8, v58, v1                            // 0000007C8E40: CC1A4001 1C067508
	s_waitcnt vmcnt(1)                                         // 0000007C8E48: BF8907F7
	v_dot2_f32_bf16 v1, v13, v59, v1                           // 0000007C8E4C: CC1A4001 1C06770D
	v_mov_b32_e32 v13, v9                                      // 0000007C8E54: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C8E58: BF870122
	v_dot2_f32_bf16 v1, v14, v60, v1                           // 0000007C8E5C: CC1A4001 1C06790E
	v_mov_b32_e32 v14, v10                                     // 0000007C8E64: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v61, v1                           // 0000007C8E68: CC1A4001 1C067B0F
	v_mov_b32_e32 v15, v11                                     // 0000007C8E70: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007C8E74: BF870132
	v_dot2_f32_bf16 v1, v16, v62, v1                           // 0000007C8E78: CC1A4001 1C067D10
	v_mov_b32_e32 v16, v12                                     // 0000007C8E80: 7E20030C
	s_waitcnt vmcnt(0)                                         // 0000007C8E84: BF8903F7
	v_dot2_f32_bf16 v1, v44, v63, v1                           // 0000007C8E88: CC1A4001 1C067F2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8E90: BF870091
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007C8E94: CC1A4001 1C06812D
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007C8E9C: CC1A4001 1C06832E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C8EA4: BF870091
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007C8EA8: CC1A4001 1C06852F
	v_fmac_f32_e32 v27, v50, v1                                // 0000007C8EB0: 56360332
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 0000007C8EB4: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 0000007C8EBC: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 0000007C8EC4: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 0000007C8ECC: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000007C8ED4: 917E147E
	s_cbranch_execz 35                                         // 0000007C8ED8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xb68>
	s_waitcnt vmcnt(0)                                         // 0000007C8EDC: BF8903F7
	v_dual_mov_b32 v9, v13 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007C8EE0: CA20010D 091830A0
	v_dual_mov_b32 v10, v14 :: v_dual_mov_b32 v11, v15         // 0000007C8EE8: CA10010E 0A0A010F
	v_mov_b32_e32 v12, v16                                     // 0000007C8EF0: 7E180310
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C8EF4: BF870003
	.long 0xd4460005                                           // 0000007C8EF8: D4460005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C8EFC: 02023318
	s_mov_b32 s14, exec_lo                                     // 0000007C8F00: BE8E007E
	.long 0xd4c1007e                                           // 0000007C8F04: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C8F08: 02023318
	s_cbranch_execz 65148                                      // 0000007C8F0C: BFA5FE7C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v10, 31, v33                             // 0000007C8F10: 3414429F
	.long 0xd7006a09                                           // 0000007C8F14: D7006A09
	v_cndmask_b32_e32 v1, v18, v33, vcc_lo                     // 0000007C8F18: 02024312
	v_mov_b32_e32 v35, v20                                     // 0000007C8F1C: 7E460314
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C8F20: BF870003
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007C8F24: D5207C0A 01AA151D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007C8F2C: 7C9A3881
	global_load_b128 v[9:12], v[9:10], off                     // 0000007C8F30: DC5E0000 097C0009
	s_cbranch_vccnz 65137                                      // 0000007C8F38: BFA4FE71 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	v_ashrrev_i32_e32 v36, 31, v34                             // 0000007C8F3C: 3448449F
	.long 0xd7006a23                                           // 0000007C8F40: D7006A23
	v_cndmask_b32_e32 v1, v17, v34, vcc_lo                     // 0000007C8F44: 02024511
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C8F48: BF870001
	v_add_co_ci_u32_e64 v36, null, v26, v36, vcc_lo            // 0000007C8F4C: D5207C24 01AA491A
	global_load_d16_b16 v35, v[35:36], off                     // 0000007C8F54: DC820000 237C0023
	s_waitcnt vmcnt(0)                                         // 0000007C8F5C: BF8903F7
	v_cvt_f32_f16_e32 v35, v35                                 // 0000007C8F60: 7E461723
	s_branch 65126                                             // 0000007C8F64: BFA0FE66 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x500>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000007C8F68: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C8F6C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007C8F70: 8C7E127E
	.long 0xd71f0001                                           // 0000007C8F74: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C8F78: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007C8F7C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007C8F80: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 0000007C8F84: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 0000007C8F88: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C8F8C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007C8F90: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007C8F94: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007C8F98: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C8F9C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007C8FA0: 30040482
	ds_bpermute_b32 v5, v2, v31                                // 0000007C8FA4: DACC0000 05001F02
	s_waitcnt lgkmcnt(0)                                       // 0000007C8FAC: BF89FC07
	v_add_f32_e32 v5, v31, v5                                  // 0000007C8FB0: 060A0B1F
	ds_bpermute_b32 v3, v2, v30                                // 0000007C8FB4: DACC0000 03001E02
	ds_bpermute_b32 v4, v2, v32                                // 0000007C8FBC: DACC0000 04002002
	ds_bpermute_b32 v2, v2, v27                                // 0000007C8FC4: DACC0000 02001B02
	s_waitcnt lgkmcnt(2)                                       // 0000007C8FCC: BF89FC27
	v_dual_add_f32 v3, v30, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000007C8FD0: C912071E 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007C8FD8: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C8FDC: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000007C8FE0: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007C8FE4: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000007C8FE8: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000007C8FF0: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007C8FF4: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 0000007C8FFC: DACC0000 07000306
	v_add_f32_e32 v2, v27, v2                                  // 0000007C9004: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 0000007C9008: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v32, v4    // 0000007C900C: C9080F03 03040920
	ds_bpermute_b32 v8, v6, v4                                 // 0000007C9014: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000007C901C: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000007C9024: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000007C9028: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000007C902C: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000007C9034: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000007C903C: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 0000007C9040: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000007C9048: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 0000007C9050: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000007C9054: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 0000007C9058: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 0000007C9060: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C9064: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007C9068: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007C906C: 02141501
	s_waitcnt lgkmcnt(1)                                       // 0000007C9070: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007C9074: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 0000007C907C: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 0000007C9084: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000007C9088: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 0000007C908C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000007C9094: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000007C909C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000007C90A4: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C90A8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007C90AC: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000007C90B0: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000007C90B4: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000007C90B8: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000007C90C0: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000007C90C4: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000007C90C8: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000007C90CC: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000007C90D4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000007C90DC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000007C90E4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000007C90EC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007C90F4: 7D942E80
	s_cbranch_execz 9                                          // 0000007C90F8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xd20>
	s_waitcnt lgkmcnt(1)                                       // 0000007C90FC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 0000007C9100: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 0000007C9108: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 0000007C910C: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v22                               // 0000007C9114: 30022C84
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000007C9118: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C9120: 8C7E047E
	.long 0xd4510004                                           // 0000007C9124: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007C9128: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 0000007C912C: 7C980084
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007C9130: BF890007
	s_barrier                                                  // 0000007C9134: BFBD0000
	buffer_gl0_inv                                             // 0000007C9138: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007C9140: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C9144: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007C9148: BE852004
	s_cbranch_execz 89                                         // 0000007C914C: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xeb4>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 0000007C9150: 4A0E2AFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C9158: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 0000007C9160: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 0000007C9168: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 0000007C9170: D8DC1410 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007C9178: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007C917C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C9180: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007C9184: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:24 offset1:28         // 0000007C9188: D8DC1C18 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007C9190: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007C9194: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C9198: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007C919C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007C91A0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007C91A4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C91A8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007C91AC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007C91B0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C91B4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007C91B8: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007C91C0: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C91CC: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C91D0: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007C91D8: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007C91DC: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C91E0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007C91E4: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007C91EC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C91F0: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007C91F4: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007C91F8: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007C9200: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C9208: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007C920C: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007C9210: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C9218: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007C921C: 560C0D01
	v_mad_u64_u32 v[1:2], null, s16, v0, 0                     // 0000007C9220: D6FE7C01 02020010
	v_mul_f32_e32 v8, v7, v6                                   // 0000007C9228: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C922C: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007C9230: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007C9238: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C923C: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007C9240: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s17, v0, v[2:3]                // 0000007C9248: D6FE7C02 040A0011
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007C9250: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C9258: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007C925C: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007C9264: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007C9268: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C926C: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007C9270: D6100002 02052103
	.long 0xd7006a00                                           // 0000007C9278: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007C927C: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C9280: BF870191
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007C9284: D5207C01 01AA020D
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007C928C: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C9298: BF870093
	.long 0xd7006a00                                           // 0000007C929C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007C92A0: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007C92A4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007C92AC: DC960000 007C0200
	s_endpgm                                                   // 0000007C92B4: BFB00000
		...

