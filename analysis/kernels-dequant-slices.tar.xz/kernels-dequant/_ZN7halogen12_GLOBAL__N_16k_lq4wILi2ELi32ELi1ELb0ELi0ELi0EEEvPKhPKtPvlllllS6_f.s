0000000000552500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000552500: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000552508: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000055250C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000552510: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000552514: BF8701A9
	v_dual_mov_b32 v10, s1 :: v_dual_and_b32 v1, 15, v0        // 000000552518: CA240001 0A00008F
	.long 0x7f103880                                           // 000000552520: 7F103880
	v_and_b32_e32 v2, 60, v2                                   // 000000552524: 360404BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000552528: BF870003
	v_dual_mov_b32 v18, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 00000055252C: CA220080 12000282
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v16, 31, v0         // 000000552534: CA240080 0310009F
	v_mov_b32_e32 v17, 0                                       // 00000055253C: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000552540: BF89FC07
	s_clause 0x1                                               // 000000552544: BF850001
	global_load_b32 v4, v1, s[4:5]                             // 000000552548: DC520000 04040001
	global_load_b32 v7, v2, s[4:5]                             // 000000552550: DC520000 07040002
	v_lshrrev_b32_e32 v2, 5, v0                                // 000000552558: 32040085
	s_add_u32 s2, s4, s14                                      // 00000055255C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000552560: 82030F05
	v_mov_b32_e32 v1, 0                                        // 000000552564: 7E020280
	s_delay_alu instid0(VALU_DEP_2)                            // 000000552568: BF870002
	v_or_b32_e32 v9, s0, v2                                    // 00000055256C: 38120400
	s_lshr_b32 s0, s11, 31                                     // 000000552570: 85009F0B
	v_mov_b32_e32 v2, 0                                        // 000000552574: 7E040280
	s_add_u32 s14, s10, s0                                     // 000000552578: 800E000A
	s_addc_u32 s15, s11, 0                                     // 00000055257C: 820F800B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000552580: 7CA8120C
	s_ashr_i32 s20, s11, 31                                    // 000000552584: 86149F0B
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 000000552588: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 00000055258C: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000552594: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000552598: 850E9B14
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055259C: BF870001
	.long 0xd72c0014                                           // 0000005525A0: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000005525A4: 0200010E
	.long 0xd72c000e                                           // 0000005525A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000005525AC: 02021C12
	s_waitcnt vmcnt(1)                                         // 0000005525B0: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000005525B4: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000005525BC: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000005525C0: D6100013 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005525C8: BF870112
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000005525CC: D6550004 03FE1904 00007FFF
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000005525D8: D6550007 03FE2707 00007FFF
	v_lshlrev_b32_e32 v19, 2, v0                               // 0000005525E4: 30260082
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005525E8: BF870003
	.long 0x7e103984                                           // 0000005525EC: 7E103984
	v_mov_b32_e32 v4, 0                                        // 0000005525F0: 7E080280
	.long 0xd72c000d                                           // 0000005525F4: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000005525F8: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000005525FC: D6FE7C05 02021612
	.long 0xd72c000f                                           // 000000552604: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 000000552608: 0200030B
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 00000055260C: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 000000552614: 80020E0A
	s_addc_u32 s3, s11, 0                                      // 000000552618: 8203800B
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 00000055261C: D6570007 04220EFF FFFF0000
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000552628: 85828502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055262C: BF870009
	.long 0xd4440000                                           // 000000552630: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 000000552634: 02022002
	v_add3_u32 v6, v6, v14, v13                                // 000000552638: D6550006 04361D06
	v_add3_u32 v0, v20, v12, v15                               // 000000552640: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 000000552648: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 000000552650: BF89FC07
	s_barrier                                                  // 000000552654: BFBD0000
	buffer_gl0_inv                                             // 000000552658: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000552660: BE832000
	s_cbranch_execz 26                                         // 000000552664: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1d0>
	s_add_u32 s1, s4, s16                                      // 000000552668: 80011004
	s_addc_u32 s14, s5, s17                                    // 00000055266C: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 000000552670: 30022081
	.long 0xd7000102                                           // 000000552674: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000552678: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000055267C: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 000000552680: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 000000552688: 30082084
	.long 0xd7000101                                           // 00000055268C: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000552690: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000552694: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 000000552698: D5207C02 00060680
	.long 0xd7000103                                           // 0000005526A0: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000005526A4: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005526A8: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 0000005526AC: D5207C04 00060080
	s_clause 0x1                                               // 0000005526B4: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000005526B8: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000005526C0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000005526C8: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000005526CC: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005526D0: 8C7E037E
	v_mov_b32_e32 v19, 0                                       // 0000005526D4: 7E260280
	s_and_saveexec_b32 s3, s0                                  // 0000005526D8: BE832000
	s_cbranch_execz 281                                        // 0000005526DC: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x644>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000005526E0: CA220112 16062081
	.long 0xd7000005                                           // 0000005526E8: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000005526EC: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005526F0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 0000005526F4: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000005526FC: CA220080 0D0C2085
	.long 0xd7000005                                           // 000000552704: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000552708: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000055270C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000552710: D5207C06 00020C80
	v_lshl_or_b32 v20, v16, 4, 0x200                           // 000000552718: D6560014 03FD0910 00000200
	.long 0xd7000005                                           // 000000552724: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000552728: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000055272C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 000000552730: D5207C06 00020C05
	v_mov_b32_e32 v21, v16                                     // 000000552738: 7E2A0310
	.long 0xd700000e                                           // 00000055273C: D700000E
	v_cndmask_b32_e32 v0, v5, v192, vcc_lo                     // 000000552740: 02018105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000552744: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 000000552748: D5207C0F 00020C80
	v_mov_b32_e32 v19, v13                                     // 000000552750: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 000000552754: 7E22030D
	s_mov_b32 s14, 0                                           // 000000552758: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000055275C: 8484810A
	s_branch 222                                               // 000000552760: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x5dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000552764: 8C7E0A7E
	.long 0xd73c0017                                           // 000000552768: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000055276C: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 000000552770: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 000000552778: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 00000055277C: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000552780: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 000000552784: 367404FF 000000FF
	.long 0xd700012f                                           // 00000055278C: D700012F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000552790: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000552794: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s1                 // 000000552798: D5207C30 00063007
	v_lshlrev_b32_e32 v55, 2, v55                              // 0000005527A0: 306E6E82
	.long 0xd7000133                                           // 0000005527A4: D7000133
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 0000005527A8: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005527AC: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s1                 // 0000005527B0: D5207C34 00066005
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000005527B8: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 0000005527C0: D8D80000 37000037
	s_clause 0x7                                               // 0000005527C8: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 0000005527CC: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000005527D4: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 0000005527DC: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 0000005527E4: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 0000005527EC: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000005527F4: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000005527FC: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 000000552804: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 00000055280C: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 000000552814: 32760486
	ds_load_b32 v56, v56                                       // 000000552818: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 000000552820: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000552824: 32040496
	ds_load_b32 v57, v57                                       // 000000552828: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000552830: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 000000552838: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 00000055283C: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 000000552844: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 00000055284C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000552854: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 00000055285C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 000000552864: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 00000055286C: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 000000552874: D8D80000 02000002
	s_and_b32 s1, exec_lo, s0                                  // 00000055287C: 8B01007E
	.long 0xd700000e                                           // 000000552880: D700000E
	v_cndmask_b32_e32 v0, v14, v192, vcc_lo                    // 000000552884: 0201810E
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000552888: 4A1818FF 00000400
	v_add_nc_u32_e32 v20, 0x200, v20                           // 000000552890: 4A2828FF 00000200
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 000000552898: D5207C0F 00021E80
	s_or_b32 s14, s1, s14                                      // 0000005528A0: 8C0E0E01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000005528A4: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 0000005528A8: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 0000005528B0: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 0000005528B4: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 0000005528BC: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000005528C4: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 0000005528C8: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005528D0: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 0000005528D4: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000005528DC: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 0000005528E0: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000005528E4: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000005528E8: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 0000005528EC: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 0000005528F4: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 0000005528FC: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 000000552904: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 000000552908: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 00000055290C: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 000000552910: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 000000552918: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 000000552920: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 000000552924: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 00000055292C: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 000000552934: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 000000552938: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 000000552940: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 000000552944: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 00000055294C: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 000000552954: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 00000055295C: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 000000552964: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 000000552968: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 000000552970: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000552978: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 00000055297C: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 000000552984: 30323282
	s_waitcnt lgkmcnt(4)                                       // 000000552988: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 00000055298C: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 000000552994: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 00000055299C: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 0000005529A4: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005529AC: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000005529B4: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 0000005529B8: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 0000005529C0: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 0000005529C8: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000005529D0: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000005529D8: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000005529E0: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000005529E8: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000005529F0: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 0000005529F4: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 0000005529FC: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 000000552A00: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 000000552A08: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552A0C: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 000000552A10: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 000000552A18: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 000000552A20: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552A24: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 000000552A28: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 000000552A30: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 000000552A38: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552A3C: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 000000552A40: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 000000552A48: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000552A50: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000552A54: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 000000552A58: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 000000552A60: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 000000552A64: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000552A6C: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 000000552A74: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 000000552A78: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000552A80: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 000000552A84: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 000000552A8C: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 000000552A90: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000552A98: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 000000552A9C: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 000000552AA4: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 000000552AA8: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000552AB0: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 000000552AB4: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000552ABC: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 000000552AC4: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 000000552AC8: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 000000552ACC: 56222F12
	v_mov_b32_e32 v18, v22                                     // 000000552AD0: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000552AD4: 917E0E7E
	s_cbranch_execz 25                                         // 000000552AD8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x640>
	s_waitcnt vmcnt(0)                                         // 000000552ADC: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 32, v21    // 000000552AE0: CA200102 06142AA0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000552AE8: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000552AF0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 000000552AF4: BF870003
	.long 0xd4430000                                           // 000000552AF8: D4430000
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000552AFC: 02022A02
	s_mov_b32 s10, exec_lo                                     // 000000552B00: BE8A007E
	.long 0xd4c4007e                                           // 000000552B04: D4C4007E
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 000000552B08: 02022A02
	s_cbranch_execz 65301                                      // 000000552B0C: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	.long 0xd7000105                                           // 000000552B10: D7000105
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 000000552B14: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000552B18: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 000000552B1C: D5207C06 00060080
	global_load_d16_b16 v22, v[14:15], off                     // 000000552B24: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 000000552B2C: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 000000552B34: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 000000552B38: 7E2C1716
	s_branch 65289                                             // 000000552B3C: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x264>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000552B40: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000552B44: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000552B48: 8C7E037E
	.long 0xd71f0000                                           // 000000552B4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000552B50: 020100C1
	s_waitcnt vmcnt(0)                                         // 000000552B54: BF8903F7
	v_xor_b32_e32 v1, 16, v0                                   // 000000552B58: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 000000552B5C: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 000000552B60: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000552B64: BF870093
	.long 0xd44c0000                                           // 000000552B68: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000552B6C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000552B70: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000552B78: BF870114
	.long 0xd44c0000                                           // 000000552B7C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000552B80: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000552B84: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000552B88: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000552B8C: D5010003 00020700
	.long 0xd44c0000                                           // 000000552B94: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000552B98: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 000000552B9C: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000552BA4: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 000000552BAC: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 000000552BB0: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000552BB8: 30060682
	ds_bpermute_b32 v1, v1, v17                                // 000000552BBC: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 000000552BC4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 000000552BCC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 000000552BD0: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 000000552BD8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 000000552BE0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000552BE4: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000552BE8: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000552BF0: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 000000552BF8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000552BFC: BF870091
	.long 0xd44c0000                                           // 000000552C00: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000552C04: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000552C08: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 000000552C10: BF89FC07
	v_dual_add_f32 v2, v2, v3 :: v_dual_add_f32 v1, v1, v4     // 000000552C14: C9080702 02000901
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000552C1C: BF8700C2
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000552C20: 300A0A82
	ds_bpermute_b32 v3, v5, v2                                 // 000000552C24: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 000000552C2C: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 000000552C34: 3A0A0081
	.long 0xd44c0000                                           // 000000552C38: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000552C3C: 02020AA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000552C40: BF870121
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 000000552C44: D5010000 00020B00
	.long 0xd44a0000                                           // 000000552C4C: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000552C50: 02022080
	v_lshlrev_b32_e32 v5, 2, v0                                // 000000552C54: 300A0082
	s_and_b32 s0, s0, vcc_lo                                   // 000000552C58: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 000000552C5C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 000000552C60: 06040702
	s_waitcnt lgkmcnt(0)                                       // 000000552C64: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 000000552C68: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 000000552C6C: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 000000552C74: DACC0000 01000005
	s_and_saveexec_b32 s1, s0                                  // 000000552C7C: BE812000
	s_cbranch_execz 35                                         // 000000552C80: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x810>
	s_waitcnt lgkmcnt(1)                                       // 000000552C84: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 000000552C88: 06040702
	.long 0x7f063880                                           // 000000552C8C: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000552C90: BF89FC07
	v_add_f32_e32 v4, v0, v1                                   // 000000552C94: 06080300
	.long 0xd73c0000                                           // 000000552C98: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000552C9C: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000552CA0: 8480810C
	.long 0x7e0a3982                                           // 000000552CA4: 7E0A3982
	.long 0x7f0a3983                                           // 000000552CA8: 7F0A3983
	.long 0x7e063984                                           // 000000552CAC: 7E063984
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000552CB0: BF870194
	.long 0xd7006a00                                           // 000000552CB4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000552CB8: 02020008
	v_and_b32_e32 v5, 1, v5                                    // 000000552CBC: 360A0A81
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000552CC0: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000552CC8: BF870194
	v_and_b32_e32 v6, 1, v3                                    // 000000552CCC: 360C0681
	v_add3_u32 v5, v2, v5, 0x7fff                              // 000000552CD0: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 000000552CDC: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000552CE0: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000552CE4: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000552CE8: D5207C03 01AA0201
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000552CF0: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 000000552CFC: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000552D00: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000552D08: DC960000 007C0402
	s_endpgm                                                   // 000000552D10: BFB00000
		...

