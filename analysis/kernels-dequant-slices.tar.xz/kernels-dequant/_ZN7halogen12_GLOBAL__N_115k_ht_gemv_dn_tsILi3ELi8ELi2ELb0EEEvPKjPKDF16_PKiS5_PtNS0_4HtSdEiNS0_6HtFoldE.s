0000000000952000 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE():
	s_clause 0x1                                               // 000000952000: BF850001
	s_load_b32 s3, s[0:1], 0x80                                // 000000952004: F40000C0 F8000080
	s_load_b512 s[12:27], s[0:1], null                         // 00000095200C: F4100300 F8000000
	v_and_b32_e32 v12, 31, v0                                  // 000000952014: 3618009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 000000952018: 32160085
	s_mov_b32 s4, -1                                           // 00000095201C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 000000952020: BF89FC07
	s_cmp_lt_i32 s2, s3                                        // 000000952024: BF040302
	s_cbranch_scc1 2422                                        // 000000952028: BFA20976 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2604>
	s_load_b64 s[8:9], s[0:1], 0x74                            // 00000095202C: F4040200 F8000074
	s_sub_i32 s3, s2, s3                                       // 000000952034: 81830302
	s_clause 0x2                                               // 000000952038: BF850002
	s_load_b128 s[28:31], s[0:1], 0x68                         // 00000095203C: F4080700 F8000068
	s_load_b64 s[34:35], s[0:1], 0x60                          // 000000952044: F4040880 F8000060
	s_load_b256 s[36:43], s[0:1], 0x40                         // 00000095204C: F40C0900 F8000040
	s_mov_b32 s47, 0                                           // 000000952054: BEAF0080
	s_mov_b32 s46, exec_lo                                     // 000000952058: BEAE007E
	s_waitcnt lgkmcnt(0)                                       // 00000095205C: BF89FC07
	s_abs_i32 s4, s9                                           // 000000952060: BE841509
	s_ashr_i32 s7, s9, 31                                      // 000000952064: 86079F09
	s_cvt_f32_u32 s5, s4                                       // 000000952068: BE856504
	s_sub_i32 s6, 0, s4                                        // 00000095206C: 81860480
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000952070: BF87029A
	v_rcp_iflag_f32_e32 v1, s5                                 // 000000952074: 7E025605
	v_readfirstlane_b32 s5, v1                                 // 000000952078: 7E0A0501
	s_mul_f32 s5, s5, 0x4f7ffffe                               // 00000095207C: A205FF05 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000952084: BF87059B
	s_cvt_u32_f32 s5, s5                                       // 000000952088: BE856705
	s_mul_i32 s6, s6, s5                                       // 00000095208C: 96060506
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000952090: BF870499
	s_mul_hi_u32 s6, s5, s6                                    // 000000952094: 96860605
	s_add_i32 s5, s5, s6                                       // 000000952098: 81050605
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000095209C: BF870499
	s_mul_hi_u32 s5, s3, s5                                    // 0000009520A0: 96850503
	s_mul_i32 s6, s5, s4                                       // 0000009520A4: 96060405
	s_add_i32 s10, s5, 1                                       // 0000009520A8: 810A8105
	s_sub_i32 s6, s3, s6                                       // 0000009520AC: 81860603
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009520B0: BF870009
	s_sub_i32 s11, s6, s4                                      // 0000009520B4: 818B0406
	s_cmp_ge_u32 s6, s4                                        // 0000009520B8: BF090406
	s_cselect_b32 s5, s10, s5                                  // 0000009520BC: 9805050A
	s_cselect_b32 s6, s11, s6                                  // 0000009520C0: 9806060B
	s_add_i32 s10, s5, 1                                       // 0000009520C4: 810A8105
	s_cmp_ge_u32 s6, s4                                        // 0000009520C8: BF090406
	s_cselect_b32 s4, s10, s5                                  // 0000009520CC: 9804050A
	s_ashr_i32 s11, s30, 31                                    // 0000009520D0: 860B9F1E
	s_xor_b32 s4, s4, s7                                       // 0000009520D4: 8D040704
	s_lshr_b32 s1, s11, 25                                     // 0000009520D8: 8501990B
	s_sub_i32 s10, s4, s7                                      // 0000009520DC: 818A0704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009520E0: BF870499
	s_mul_i32 s0, s10, s9                                      // 0000009520E4: 9600090A
	s_sub_i32 s31, s3, s0                                      // 0000009520E8: 819F0003
	s_add_i32 s0, s30, s1                                      // 0000009520EC: 8100011E
	s_mul_i32 s33, s31, s8                                     // 0000009520F0: 9621081F
	s_ashr_i32 s0, s0, 7                                       // 0000009520F4: 86008700
	s_add_i32 s1, s33, s8                                      // 0000009520F8: 81010821
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009520FC: BF870499
	s_min_i32 s0, s0, s1                                       // 000000952100: 89000100
	s_sub_i32 s45, s0, s33                                     // 000000952104: 81AD2100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000952108: BF870499
	s_lshl_b32 s44, s45, 1                                     // 00000095210C: 842C812D
	.long 0xd4c4007e                                           // 000000952110: D4C4007E
	v_cndmask_b32_e32 v1, s44, v11, vcc_lo                     // 000000952114: 0202162C
	s_cbranch_execz 505                                        // 000000952118: BFA501F9 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x900>
	s_add_i32 s48, s28, -1                                     // 00000095211C: 8130C11C
	s_cmp_lg_u64 s[38:39], 0                                   // 000000952120: BF118026
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 000000952124: CA24010B 08000081
	s_cselect_b32 s49, -1, 0                                   // 00000095212C: 983180C1
	s_abs_i32 s50, s45                                         // 000000952130: BEB2152D
	v_and_b32_e32 v2, 2, v0                                    // 000000952134: 36040082
	s_cvt_f32_u32 s0, s50                                      // 000000952138: BE806532
	v_lshlrev_b32_e32 v6, 3, v12                               // 00000095213C: 300C1883
	v_lshlrev_b32_e32 v7, 7, v11                               // 000000952140: 300E1687
	v_and_b32_e32 v3, 4, v0                                    // 000000952144: 36060084
	v_rcp_iflag_f32_e32 v4, s0                                 // 000000952148: 7E085600
	v_and_b32_e32 v5, 8, v0                                    // 00000095214C: 360A0088
	.long 0xd44a0001                                           // 000000952150: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000952154: 02020280
	.long 0xd44a0003                                           // 000000952158: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000095215C: 02020480
	v_lshl_or_b32 v1, v11, 8, v6                               // 000000952160: D6560001 0419110B
	v_lshl_add_u32 v2, s33, 7, v7                              // 000000952168: D6460002 041D0E21
	s_ashr_i32 s52, s45, 31                                    // 000000952170: 86349F2D
	s_sub_i32 s54, 0, s50                                      // 000000952174: 81B63280
	s_mul_i32 s8, s52, 0x1400                                  // 000000952178: 9608FF34 00001400
	.long 0xd44c0000                                           // 000000952180: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000952184: 02021890
	v_readfirstlane_b32 s5, v4                                 // 000000952188: 7E0A0504
	.long 0xd44a0004                                           // 00000095218C: D44A0004
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000952190: 02020680
	v_subrev_nc_u32_e32 v9, s8, v1                             // 000000952194: 4E120208
	v_lshl_or_b32 v1, v12, 2, v2                               // 000000952198: D6560001 0409050C
	s_lshl_b32 s6, s45, 7                                      // 0000009521A0: 8406872D
	s_mul_f32 s7, s5, 0x4f7ffffe                               // 0000009521A4: A207FF05 4F7FFFFE
	.long 0xd44a0005                                           // 0000009521AC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000009521B0: 02020A80
	s_mov_b32 s51, 0x76543210                                  // 0000009521B4: BEB300FF 76543210
	s_lshl_b32 s53, s45, 8                                     // 0000009521BC: 8435882D
	s_cvt_u32_f32 s7, s7                                       // 0000009521C0: BE876707
	s_mov_b32 s56, 0x3db504f3                                  // 0000009521C4: BEB800FF 3DB504F3
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009521CC: BF87049A
	s_mul_i32 s54, s54, s7                                     // 0000009521D0: 96360736
	s_mul_hi_u32 s8, s7, s54                                   // 0000009521D4: 96883607
	s_sub_i32 s54, 0, s6                                       // 0000009521D8: 81B60680
	s_add_i32 s55, s7, s8                                      // 0000009521DC: 81370807
	s_branch 166                                               // 0000009521E0: BFA000A6 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x47c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009521E4: BF870091
	.long 0xd7006a02                                           // 0000009521E8: D7006A02
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 0000009521EC: 02020418
	v_add_co_ci_u32_e64 v3, null, s25, v3, vcc_lo              // 0000009521F0: D5207C03 01AA0619
	v_add_nc_u32_e32 v1, 0x400, v1                             // 0000009521F8: 4A0202FF 00000400
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000952200: 4A101088
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000952204: DC820006 027C0002
	v_cmp_le_i32_e32 vcc_lo, s44, v8                           // 00000095220C: 7C86102C
	s_or_b32 s47, vcc_lo, s47                                  // 000000952210: 8C2F2F6A
	s_waitcnt vmcnt(0)                                         // 000000952214: BF8903F7
	v_fma_mix_f32 v5, v16, v2, v14 op_sel_hi:[0,1,0]           // 000000952218: CC200005 143A0510
	v_sub_f32_e32 v4, v17, v15                                 // 000000952220: 08081F11
	v_fma_mix_f32 v2, -v16, v2, v14 op_sel_hi:[0,1,0]          // 000000952224: CC200002 343A0510
	v_add_f32_e32 v3, v17, v15                                 // 00000095222C: 06061F11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000952230: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000952234: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000952238: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000095223C: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000952240: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000952244: BF870193
	v_mov_b32_dpp v15, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000952248: 7E1E02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000952250: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000952258: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000952260: BF870234
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000952264: 7E1C02FA FF016103
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000095226C: D5010002 20060502
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000952274: D5010003 20060703
	v_add_f32_e32 v4, v6, v4                                   // 00000095227C: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000952280: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000952288: D5010007 20060F07
	.long 0xd72c0006                                           // 000000952290: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v13, vcc_lo                  // 000000952294: 02021AFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000095229C: BF870242
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v5, v7, v5    // 0000009522A0: C9081F02 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009522A8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009522B0: D5010004 200E0904
	v_add_f32_e32 v3, v3, v14                                  // 0000009522B8: 06061D03
	v_mov_b32_dpp v15, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009522BC: 7E1E02FA FF016202
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009522C4: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 0000009522CC: D5010005 200E0B05
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 0000009522D4: D5010002 200E0502
	v_add_f32_e32 v4, v4, v7                                   // 0000009522DC: 06080F04
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009522E0: 7E1C02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 0000009522E8: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009522F0: BF870234
	v_dual_add_f32 v5, v5, v13 :: v_dual_add_f32 v2, v2, v15   // 0000009522F4: C9081B05 05021F02
	.long 0xd72c0007                                           // 0000009522FC: D72C0007
	v_cndmask_b32_e32 v1, s53, v10, vcc_lo                     // 000000952300: 02021435
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000952304: 7E1402FA FF016404
	v_add_f32_e32 v3, v3, v14                                  // 00000095230C: 06061D03
	s_delay_alu instid0(VALU_DEP_4)                            // 000000952310: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000952314: 7E1A02FA FF016405
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 00000095231C: D5010004 20120904
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000952324: D5010005 20120B05
	v_mov_b32_dpp v15, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000095232C: 7E1E02FA FF016402
	v_mov_b32_dpp v14, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000952334: 7E1C02FA FF016403
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000095233C: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000952344: D5010003 20120703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 00000095234C: C9081504 04041B05
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000952354: 4C0C0F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000952358: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 00000095235C: C9081F02 02021D03
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000952364: 7E1402FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 00000095236C: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000952370: 7E1A02FA FF016805
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000952378: D5010004 20160904
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000952380: D5010005 20160B05
	v_mov_b32_dpp v14, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000952388: 7E1C02FA FF016803
	v_mov_b32_dpp v15, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000952390: 7E1E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000952398: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000009523A0: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v13   // 0000009523A8: C9081504 04041B05
	v_add_nc_u32_e32 v6, v9, v6                                // 0000009523B0: 4A0C0D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009523B4: BF870193
	v_dual_add_f32 v2, v2, v15 :: v_dual_add_f32 v3, v3, v14   // 0000009523B8: C9081F02 02021D03
	v_dual_mov_b32 v10, v4 :: v_dual_mov_b32 v13, v5           // 0000009523C0: CA100104 0A0C0105
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 0000009523C8: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009523D0: BF870003
	v_mov_b32_e32 v15, v2                                      // 0000009523D4: 7E1E0302
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 0000009523D8: D5010004 20020904
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 0000009523E0: D5010002 20020502
	v_permlanex16_b32 v13, v13, s51, 0xfedcba98                // 0000009523E8: D65C000D 03FC670D FEDCBA98
	v_mov_b32_e32 v14, v3                                      // 0000009523F4: 7E1C0303
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009523F8: D5010003 20020703
	v_permlanex16_b32 v10, v10, s51, 0xfedcba98                // 000000952400: D65C000A 03FC670A FEDCBA98
	v_permlanex16_b32 v15, v15, s51, 0xfedcba98                // 00000095240C: D65C000F 03FC670F FEDCBA98
	v_add_f32_e32 v5, v5, v13                                  // 000000952418: 060A1B05
	v_permlanex16_b32 v14, v14, s51, 0xfedcba98                // 00000095241C: D65C000E 03FC670E FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000952428: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 00000095242C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v15                                  // 000000952438: 060E1F02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095243C: BF870214
	v_fma_mixhi_f16 v2, v5, s56, 0                             // 000000952440: CC220002 02007105
	v_add_f32_e32 v10, v3, v14                                 // 000000952448: 06141D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095244C: BF870214
	v_fma_mixlo_f16 v2, v4, s56, 0                             // 000000952450: CC210002 02007104
	v_fma_mixhi_f16 v3, v7, s56, 0                             // 000000952458: CC220003 02007107
	s_delay_alu instid0(VALU_DEP_3)                            // 000000952460: BF870003
	v_fma_mixlo_f16 v3, v10, s56, 0                            // 000000952464: CC210003 0200710A
	ds_store_b64 v6, v[2:3]                                    // 00000095246C: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s47                       // 000000952474: 917E2F7E
	s_cbranch_execz 289                                        // 000000952478: BFA50121 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x900>
	.long 0xd72d0002                                           // 00000095247C: D72D0002
	v_cndmask_b32_e32 v0, v8, v55, vcc_lo                      // 000000952480: 02006F08
	s_mov_b32 s6, -1                                           // 000000952484: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952488: BF870091
	.long 0xd72c0003                                           // 00000095248C: D72C0003
	v_cndmask_b32_e32 v0, v2, v50, vcc_lo                      // 000000952490: 02006502
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000952494: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000952498: BF870121
	v_subrev_nc_u32_e32 v5, s50, v3                            // 00000095249C: 4E0A0632
	v_cmp_le_u32_e32 vcc_lo, s50, v3                           // 0000009524A0: 7C960632
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 0000009524A4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009524AC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009524B0: 02040902
	v_cmp_le_u32_e32 vcc_lo, s50, v3                           // 0000009524B4: 7C960632
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009524B8: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 0000009524BC: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 0000009524C0: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s49                        // 0000009524C4: 916A317E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009524C8: BF870091
	v_xor_b32_e32 v13, s52, v2                                 // 0000009524CC: 3A1A0434
	v_subrev_nc_u32_e32 v10, s52, v13                          // 0000009524D0: 4E141A34
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009524D4: BF8700A1
	v_mad_u64_u32 v[6:7], null, s54, v10, v[1:2]               // 0000009524D8: D6FE7C06 04061436
	v_min_i32_e32 v2, s48, v10                                 // 0000009524E0: 22041430
	v_mad_i64_i32 v[4:5], null, v2, s30, 0                     // 0000009524E4: D6FF7C04 02003D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009524EC: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000009524F0: 340E0C9F
	.long 0xd73c0002                                           // 0000009524F4: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000009524F8: 02020C81
	s_cbranch_vccnz 212                                        // 0000009524FC: BFA400D4 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x850>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952500: BF870093
	.long 0xd7006a06                                           // 000000952504: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000952508: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000095250C: D5207C07 01AA0F05
	.long 0x7f3c3880                                           // 000000952514: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952518: BF870112
	.long 0xd73c0006                                           // 00000095251C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000952520: 02020C81
	.long 0x7f42399e                                           // 000000952524: 7F42399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952528: BF870092
	.long 0xd7006a0e                                           // 00000095252C: D7006A0E
	v_cndmask_b32_e32 v1, s36, v6, vcc_lo                      // 000000952530: 02020C24
	v_add_co_ci_u32_e64 v15, null, s37, v7, vcc_lo             // 000000952534: D5207C0F 01AA0E25
	.long 0xd7006a06                                           // 00000095253C: D7006A06
	v_cndmask_b32_e32 v1, s38, v6, vcc_lo                      // 000000952540: 02020C26
	s_delay_alu instid0(VALU_DEP_1)                            // 000000952544: BF870001
	v_add_co_ci_u32_e64 v7, null, s39, v7, vcc_lo              // 000000952548: D5207C07 01AA0E27
	global_load_b64 v[14:15], v[14:15], off                    // 000000952550: DC560000 0E7C000E
	.long 0xd7006a10                                           // 000000952558: D7006A10
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 00000095255C: 02020418
	global_load_b64 v[6:7], v[6:7], off                        // 000000952560: DC560000 067C0006
	v_add_co_ci_u32_e64 v17, null, s25, v3, vcc_lo             // 000000952568: D5207C11 01AA0619
	s_clause 0x1                                               // 000000952570: BF850001
	global_load_b32 v18, v[16:17], off                         // 000000952574: DC520000 127C0010
	global_load_d16_b16 v16, v[16:17], off offset:4            // 00000095257C: DC820004 107C0010
	s_waitcnt vmcnt(3)                                         // 000000952584: BF890FF7
	.long 0x7e22390e                                           // 000000952588: 7E22390E
	s_waitcnt vmcnt(2)                                         // 00000095258C: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000952590: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000952598: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000095259C: BF870093
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000009525A0: 30222290
	v_mul_f32_e32 v21, 0xbfb8aa3b, v17                         // 0000009525A4: 102A22FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000009525AC: BF870291
	v_exp_f32_e32 v21, v21                                     // 0000009525B0: 7E2A4B15
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_and_b32 v14, 0xffff0000, v14// 0000009525B4: C9242AF2 150E1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009525C0: BF870111
	v_mul_f32_e32 v20, 0xbfb8aa3b, v14                         // 0000009525C4: 10281CFF BFB8AA3B
	v_div_scale_f32 v25, null, v21, v21, v17                   // 0000009525CC: D6FC7C19 04462B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009525D4: BF8701B2
	v_exp_f32_e32 v20, v20                                     // 0000009525D8: 7E284B14
	v_lshlrev_b32_e32 v19, 16, v15                             // 0000009525DC: 30261E90
	v_div_scale_f32 v38, s7, v17, v21, v17                     // 0000009525E0: D6FC0726 04462B11
	v_rcp_f32_e32 v29, v25                                     // 0000009525E8: 7E3A5519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009525EC: BF870196
	v_add_f32_e32 v20, 1.0, v20                                // 0000009525F0: 062828F2
	v_mul_f32_e32 v22, 0xbfb8aa3b, v19                         // 0000009525F4: 102C26FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009525FC: BF870195
	v_fma_f32 v37, -v25, v29, 1.0                              // 000000952600: D6130025 23CA3B19
	v_div_scale_f32 v24, null, v20, v20, v14                   // 000000952608: D6FC7C18 043A2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000952610: BF8701B3
	v_exp_f32_e32 v22, v22                                     // 000000952614: 7E2C4B16
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000952618: 361E1EFF FFFF0000
	v_div_scale_f32 v34, vcc_lo, v14, v20, v14                 // 000000952620: D6FC6A22 043A290E
	v_rcp_f32_e32 v27, v24                                     // 000000952628: 7E365518
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 00000095262C: BF870106
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v23, 0xbfb8aa3b, v15// 000000952630: C9062CF2 16161EFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000095263C: BF870115
	v_fma_f32 v35, -v24, v27, 1.0                              // 000000952640: D6130023 23CA3718
	v_div_scale_f32 v26, null, v22, v22, v19                   // 000000952648: D6FC7C1A 044E2D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000952650: BF8701A3
	v_exp_f32_e32 v23, v23                                     // 000000952654: 7E2E4B17
	v_div_scale_f32 v36, s6, v19, v22, v19                     // 000000952658: D6FC0624 044E2D13
	v_fmac_f32_e32 v27, v35, v27                               // 000000952660: 56363723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000952664: BF870313
	v_rcp_f32_e32 v31, v26                                     // 000000952668: 7E3E551A
	v_add_f32_e32 v23, 1.0, v23                                // 00000095266C: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952670: BF870115
	v_fma_f32 v39, -v26, v31, 1.0                              // 000000952674: D6130027 23CA3F1A
	v_div_scale_f32 v28, null, v23, v23, v15                   // 00000095267C: D6FC7C1C 043E2F17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000952684: BF8701A2
	v_fmac_f32_e32 v31, v39, v31                               // 000000952688: 563E3F27
	v_mul_f32_e32 v39, v34, v27                                // 00000095268C: 104E3722
	v_rcp_f32_e32 v32, v28                                     // 000000952690: 7E40551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952694: BF870091
	v_fma_f32 v42, -v24, v39, v34                              // 000000952698: D613002A 248A4F18
	v_fmac_f32_e32 v39, v42, v27                               // 0000009526A0: 564E372A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009526A4: BF870115
	v_fma_f32 v35, -v28, v32, 1.0                              // 0000009526A8: D6130023 23CA411C
	v_fma_f32 v24, -v24, v39, v34                              // 0000009526B0: D6130018 248A4F18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009526B8: BF870112
	v_fmac_f32_e32 v32, v35, v32                               // 0000009526BC: 56404123
	v_div_fmas_f32 v24, v24, v27, v39                          // 0000009526C0: D6370018 049E3718
	s_mov_b32 vcc_lo, s7                                       // 0000009526C8: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009526CC: BF8701B1
	v_div_fixup_f32 v14, v24, v20, v14                         // 0000009526D0: D627000E 043A2918
	v_fmac_f32_e32 v29, v37, v29                               // 0000009526D8: 563A3B25
	v_div_scale_f32 v37, s8, v15, v23, v15                     // 0000009526DC: D6FC0825 043E2F0F
	v_mul_f32_e32 v14, v14, v40                                // 0000009526E4: 101C510E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009526E8: BF870193
	v_mul_f32_e32 v35, v38, v29                                // 0000009526EC: 10463B26
	v_mul_f32_e32 v43, v37, v32                                // 0000009526F0: 10564125
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009526F4: BF870193
	.long 0x7e3c398e                                           // 0000009526F8: 7E3C398E
	v_fma_f32 v44, -v25, v35, v38                              // 0000009526FC: D613002C 249A4719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952704: BF870113
	v_fma_f32 v42, -v28, v43, v37                              // 000000952708: D613002A 2496571C
	v_fmac_f32_e32 v35, v44, v29                               // 000000952710: 56463B2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952714: BF870112
	v_fmac_f32_e32 v43, v42, v32                               // 000000952718: 5656412A
	v_fma_f32 v25, -v25, v35, v38                              // 00000095271C: D6130019 249A4719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952724: BF870112
	v_fma_f32 v24, -v28, v43, v37                              // 000000952728: D6130018 2496571C
	v_div_fmas_f32 v25, v25, v29, v35                          // 000000952730: D6370019 048E3B19
	s_mov_b32 vcc_lo, s6                                       // 000000952738: BEEA0006
	s_mov_b32 s6, 0                                            // 00000095273C: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000952740: BF870121
	v_div_fixup_f32 v17, v25, v21, v17                         // 000000952744: D6270011 04462B19
	v_lshlrev_b32_e32 v21, 16, v7                              // 00000095274C: 302A0E90
	v_dual_mul_f32 v6, v17, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 000000952750: C8E40D11 06060EFF FFFF0000
	v_mul_f32_e32 v41, v36, v31                                // 00000095275C: 10523F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952760: BF870112
	.long 0x7e423986                                           // 000000952764: 7E423986
	v_fma_f32 v45, -v26, v41, v36                              // 000000952768: D613002D 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952770: BF870091
	v_fmac_f32_e32 v41, v45, v31                               // 000000952774: 56523F2D
	v_fma_f32 v26, -v26, v41, v36                              // 000000952778: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000952780: BF870131
	v_div_fmas_f32 v20, v26, v31, v41                          // 000000952784: D6370014 04A63F1A
	s_mov_b32 vcc_lo, s8                                       // 00000095278C: BEEA0008
	v_div_fmas_f32 v17, v24, v32, v43                          // 000000952790: D6370011 04AE4118
	v_div_fixup_f32 v19, v20, v22, v19                         // 000000952798: D6270013 044E2D14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009527A0: BF8701A2
	v_div_fixup_f32 v15, v17, v23, v15                         // 0000009527A4: D627000F 043E2F11
	v_and_b32_e32 v17, 1, v30                                  // 0000009527AC: 36223C81
	v_mul_f32_e32 v19, v19, v21                                // 0000009527B0: 10262B13
	v_and_b32_e32 v21, 1, v33                                  // 0000009527B4: 362A4281
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009527B8: BF870214
	v_mul_f32_e32 v7, v15, v7                                  // 0000009527BC: 100E0F0F
	v_add3_u32 v14, v14, v17, 0x7fff                           // 0000009527C0: D655000E 03FE230E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009527CC: BF870214
	v_bfe_u32 v20, v19, 16, 1                                  // 0000009527D0: D6100014 02052113
	v_add3_u32 v6, v6, v21, 0x7fff                             // 0000009527D8: D6550006 03FE2B06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009527E4: BF870214
	v_bfe_u32 v17, v7, 16, 1                                   // 0000009527E8: D6100011 02052107
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000009527F0: 361C1CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009527F8: BF870214
	v_add3_u32 v15, v19, v20, 0x7fff                           // 0000009527FC: D655000F 03FE2913 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000952808: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000952810: BF870194
	v_add3_u32 v7, v7, v17, 0x7fff                             // 000000952814: D6550007 03FE2307 00007FFF
	v_and_b32_e32 v19, 0xffff0000, v15                         // 000000952820: 36261EFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000952828: BF8907F7
	v_fma_mix_f32 v15, v18, v14, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000095282C: CC20080F 8A021D12
	v_fma_mix_f32 v17, v18, v6, neg(0) op_sel_hi:[1,0,0]       // 000000952834: CC200011 8A020D12
	s_waitcnt vmcnt(0)                                         // 00000095283C: BF8903F7
	v_fma_mix_f32 v14, v16, v19, neg(0) op_sel_hi:[1,0,0]      // 000000952840: CC20000E 8A022710
	v_and_b32_e32 v16, 0xffff0000, v7                          // 000000952848: 36200EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000952850: 916A067E
	s_cbranch_vccnz 65123                                      // 000000952854: BFA4FE63 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1e4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952858: BF870093
	.long 0xd73c0004                                           // 00000095285C: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000952860: 02020881
	.long 0xd7006a04                                           // 000000952864: D7006A04
	v_cndmask_b32_e32 v1, s36, v4, vcc_lo                      // 000000952868: 02020824
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000095286C: BF870111
	v_add_co_ci_u32_e64 v5, null, s37, v5, vcc_lo              // 000000952870: D5207C05 01AA0A25
	.long 0xd7006a04                                           // 000000952878: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000095287C: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000952880: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000952884: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000095288C: D7006A06
	v_cndmask_b32_e32 v1, s24, v2, vcc_lo                      // 000000952890: 02020418
	v_add_co_ci_u32_e64 v7, null, s25, v3, vcc_lo              // 000000952894: D5207C07 01AA0619
	global_load_b64 v[4:5], v[4:5], off                        // 00000095289C: DC560000 047C0004
	s_clause 0x1                                               // 0000009528A4: BF850001
	global_load_b32 v16, v[6:7], off                           // 0000009528A8: DC520000 107C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 0000009528B0: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 0000009528B8: BF890BF7
	.long 0x7e0e3904                                           // 0000009528BC: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009528C0: 360808FF FFFF0000
	v_lshlrev_b32_e32 v14, 16, v5                              // 0000009528C8: 301C0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009528CC: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000009528D0: 300E0E90
	s_waitcnt vmcnt(1)                                         // 0000009528D4: BF8907F7
	v_fma_mix_f32 v15, v16, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 0000009528D8: CC20080F 8A020910
	s_waitcnt vmcnt(0)                                         // 0000009528E0: BF8903F7
	v_fma_mix_f32 v14, v6, v14, neg(0) op_sel_hi:[1,0,0]       // 0000009528E4: CC20000E 8A021D06
	v_fma_mix_f32 v17, v16, v7, neg(0) op_sel_hi:[1,0,0]       // 0000009528EC: CC200011 8A020F10
	v_and_b32_e32 v16, 0xffff0000, v5                          // 0000009528F4: 36200AFF FFFF0000
	s_branch 65081                                             // 0000009528FC: BFA0FE39 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1e4>
	s_or_b32 exec_lo, exec_lo, s46                             // 000000952900: 8C7E2E7E
	s_bfe_i32 s44, s45, 0x1001c                                // 000000952904: 93ACFF2D 0001001C
	s_lshr_b32 s3, s11, 28                                     // 00000095290C: 85039C0B
	s_lshr_b64 s[0:1], s[44:45], 29                            // 000000952910: 85809D2C
	s_add_i32 s3, s30, s3                                      // 000000952914: 8103031E
	s_add_i32 s0, s0, 7                                        // 000000952918: 81008700
	s_lshl_b32 s1, s45, 3                                      // 00000095291C: 8401832D
	s_ashr_i32 s0, s0, 3                                       // 000000952920: 86008300
	s_lshl_b32 s4, s33, 3                                      // 000000952924: 84048321
	.long 0xd72c0001                                           // 000000952928: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 00000095292C: 02021600
	v_lshlrev_b32_e32 v13, 2, v12                              // 000000952930: 301A1882
	s_waitcnt lgkmcnt(0)                                       // 000000952934: BF89FC07
	s_barrier                                                  // 000000952938: BFBD0000
	buffer_gl0_inv                                             // 00000095293C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000952944: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 000000952948: 86008403
	s_ashr_i32 s3, s4, 31                                      // 00000095294C: 86039F04
	s_mul_hi_i32 s5, s10, s0                                   // 000000952950: 9705000A
	s_mul_i32 s0, s10, s0                                      // 000000952954: 9600000A
	v_min_i32_e32 v14, s1, v2                                  // 000000952958: 221C0401
	s_add_u32 s0, s0, s4                                       // 00000095295C: 80000400
	s_addc_u32 s1, s5, s3                                      // 000000952960: 82010305
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952964: BF870099
	s_lshl_b64 s[4:5], s[0:1], 10                              // 000000952968: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 00000095296C: 7C821D01
	s_add_u32 s1, s22, s4                                      // 000000952970: 80010416
	s_addc_u32 s3, s23, s5                                     // 000000952974: 82030517
	s_and_saveexec_b32 s4, vcc_lo                              // 000000952978: BE84206A
	s_cbranch_execz 93                                         // 00000095297C: BFA5005D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xaf4>
	.long 0xd7010002                                           // 000000952980: D7010002
	v_cndmask_b32_e32 v0, v12, v129, vcc_lo                    // 000000952984: 0201030C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000952988: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000095298C: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000952994: 3404029F
	.long 0xd44c0000                                           // 000000952998: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000095299C: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009529A0: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000009529A4: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 0000009529B0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009529B8: BF870114
	.long 0xd73c0005                                           // 0000009529BC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000009529C0: 0202028A
	.long 0xd73c0002                                           // 0000009529C4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000009529C8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009529CC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 0000009529D0: 30080E98
	v_bfe_i32 v8, v7, 7, 1                                     // 0000009529D4: D6110008 02050F07
	.long 0xd7000009                                           // 0000009529DC: D7000009
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000009529E0: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009529E4: BF870211
	v_add_co_ci_u32_e64 v10, null, s3, v6, s0                  // 0000009529E8: D5207C0A 00020C03
	v_ashrrev_i32_e32 v4, 22, v4                               // 0000009529F0: 34080896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009529F4: BF870093
	.long 0xd7000005                                           // 0000009529F8: D7000005
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 0000009529FC: 02020509
	v_add_co_ci_u32_e64 v6, null, v10, v3, s0                  // 000000952A00: D5207C06 0002070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000952A08: BF870093
	.long 0xd7000007                                           // 000000952A0C: D7000007
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 000000952A10: 02020909
	v_add_co_ci_u32_e64 v8, null, v10, v8, s0                  // 000000952A14: D5207C08 0002110A
	.long 0xd7000009                                           // 000000952A1C: D7000009
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000952A20: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000952A24: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v10, s0                  // 000000952A28: D5207C0A 00021480
	s_clause 0x17                                              // 000000952A30: BF850017
	global_load_b32 v4, v[5:6], off                            // 000000952A34: DC520000 047C0005
	global_load_b32 v2, v[5:6], off offset:128                 // 000000952A3C: DC520080 027C0005
	global_load_b32 v65, v[5:6], off offset:256                // 000000952A44: DC520100 417C0005
	global_load_b32 v62, v[5:6], off offset:384                // 000000952A4C: DC520180 3E7C0005
	global_load_b32 v59, v[5:6], off offset:512                // 000000952A54: DC520200 3B7C0005
	global_load_b32 v56, v[5:6], off offset:640                // 000000952A5C: DC520280 387C0005
	global_load_b32 v53, v[5:6], off offset:768                // 000000952A64: DC520300 357C0005
	global_load_b32 v35, v[5:6], off offset:896                // 000000952A6C: DC520380 237C0005
	global_load_b32 v6, v[7:8], off                            // 000000952A74: DC520000 067C0007
	global_load_b32 v3, v[7:8], off offset:128                 // 000000952A7C: DC520080 037C0007
	global_load_b32 v66, v[7:8], off offset:256                // 000000952A84: DC520100 427C0007
	global_load_b32 v63, v[7:8], off offset:384                // 000000952A8C: DC520180 3F7C0007
	global_load_b32 v60, v[7:8], off offset:512                // 000000952A94: DC520200 3C7C0007
	global_load_b32 v57, v[7:8], off offset:640                // 000000952A9C: DC520280 397C0007
	global_load_b32 v55, v[7:8], off offset:768                // 000000952AA4: DC520300 377C0007
	global_load_b32 v36, v[7:8], off offset:896                // 000000952AAC: DC520380 247C0007
	global_load_b32 v5, v[9:10], off                           // 000000952AB4: DC520000 057C0009
	global_load_b32 v67, v[9:10], off offset:128               // 000000952ABC: DC520080 437C0009
	global_load_b32 v64, v[9:10], off offset:256               // 000000952AC4: DC520100 407C0009
	global_load_b32 v61, v[9:10], off offset:384               // 000000952ACC: DC520180 3D7C0009
	global_load_b32 v58, v[9:10], off offset:512               // 000000952AD4: DC520200 3A7C0009
	global_load_b32 v54, v[9:10], off offset:640               // 000000952ADC: DC520280 367C0009
	global_load_b32 v52, v[9:10], off offset:768               // 000000952AE4: DC520300 347C0009
	global_load_b32 v34, v[9:10], off offset:896               // 000000952AEC: DC520380 227C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000952AF4: 8C7E047E
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v18, 0             // 000000952AF8: CA100080 0F120080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 000000952B00: CA100080 11140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000952B08: CA100080 15160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000952B10: CA100080 18180080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 000000952B18: CA100080 10120080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 000000952B20: CA100080 1A160080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 000000952B28: CA100080 1C1C0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v30, 0             // 000000952B30: CA100080 1B1E0080
	s_ashr_i32 s11, s10, 31                                    // 000000952B38: 860B9F0A
	s_and_saveexec_b32 s0, vcc_lo                              // 000000952B3C: BE80206A
	s_cbranch_execz 1008                                       // 000000952B40: BFA503F0 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1b04>
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v7, -1, v0      // 000000952B44: CA200080 120600C1
	v_dual_mov_b32 v15, 0 :: v_dual_lshlrev_b32 v32, 2, v12    // 000000952B4C: CA220080 0F201882
	v_dual_mov_b32 v20, 0 :: v_dual_and_b32 v31, 16, v0        // 000000952B54: CA240080 141E0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000952B5C: BF8701B3
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v7, 31, v7         // 000000952B60: CA240080 18060E9F
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v22, 0             // 000000952B68: CA100080 11160080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v16, 0             // 000000952B70: CA100080 15100080
	v_dual_mov_b32 v26, 0 :: v_dual_lshlrev_b32 v33, 2, v7     // 000000952B78: CA220080 1A200E82
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v28, 0             // 000000952B80: CA100080 191C0080
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v30, 0             // 000000952B88: CA100080 131E0080
	v_mov_b32_e32 v23, 0                                       // 000000952B90: 7E2E0280
	v_mov_b32_e32 v29, 0                                       // 000000952B94: 7E3A0280
	v_mov_b32_e32 v27, 0                                       // 000000952B98: 7E360280
	s_mov_b32 s4, 0                                            // 000000952B9C: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000952BA0: B0051EEE
	s_branch 924                                               // 000000952BA4: BFA0039C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1a18>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000952BA8: 8C7E067E
	s_waitcnt vmcnt(15)                                        // 000000952BAC: BF893FF7
	v_alignbit_b32 v4, v4, v6, 16                              // 000000952BB0: D6160004 02420D04
	s_waitcnt vmcnt(7)                                         // 000000952BB8: BF891FF7
	v_bfe_u32 v68, v5, 12, 16                                  // 000000952BBC: D6100044 02411905
	v_bfe_u32 v69, v5, 8, 16                                   // 000000952BC4: D6100045 02411105
	v_bfe_u32 v70, v5, 4, 16                                   // 000000952BCC: D6100046 02410905
	v_lshl_or_b32 v1, v1, 5, v31                               // 000000952BD4: D6560001 047D0B01
	v_and_b32_e32 v7, 0xffff, v4                               // 000000952BDC: 360E08FF 0000FFFF
	v_bfe_u32 v74, v4, 4, 16                                   // 000000952BE4: D610004A 02410904
	.long 0xd72c0044                                           // 000000952BEC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000952BF0: 020288FF 83DCD12D
	.long 0xd72c0045                                           // 000000952BF8: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000952BFC: 02028AFF 83DCD12D
	v_bfe_u32 v6, v4, 12, 16                                   // 000000952C04: D6100006 02411904
	.long 0xd72c004c                                           // 000000952C0C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000952C10: 02020EFF 83DCD12D
	.long 0xd72c004a                                           // 000000952C18: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000952C1C: 020294FF 83DCD12D
	v_alignbit_b32 v72, v2, v3, 16                             // 000000952C24: D6160048 02420702
	.long 0xd72c0046                                           // 000000952C2C: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000952C30: 02028CFF 83DCD12D
	.long 0xd72c0049                                           // 000000952C38: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 000000952C3C: 02020CFF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000952C44: D6220044 03FD0144 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000952C50: D6220045 03FD0145 00006400
	s_waitcnt vmcnt(6)                                         // 000000952C5C: BF891BF7
	v_bfe_u32 v77, v67, 4, 16                                  // 000000952C60: D610004D 02410943
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000952C68: D622004C 03FD014C 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000952C74: D622004A 03FD014A 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000952C80: 368888FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000952C88: D6220046 03FD0146 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000952C94: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000952CA0: 30989890
	v_alignbit_b32 v65, v65, v66, 16                           // 000000952CA4: D6160041 02428541
	v_lshl_or_b32 v68, v69, 16, v68                            // 000000952CAC: D6560044 05112145
	v_alignbit_b32 v62, v62, v63, 16                           // 000000952CB4: D616003E 02427F3E
	v_alignbit_b32 v59, v59, v60, 16                           // 000000952CBC: D616003B 0242793B
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000952CC4: D657004A 053294FF 0000FFFF
	v_bfe_u32 v76, v67, 8, 16                                  // 000000952CD0: D610004C 02411143
	v_pk_fma_f16 v68, v68, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952CD8: CC0E0044 0BFC0B44 0000C931
	v_alignbit_b32 v56, v56, v57, 16                           // 000000952CE4: D6160038 02427338
	v_alignbit_b32 v53, v53, v55, 16                           // 000000952CEC: D6160035 02426F35
	v_pk_fma_f16 v69, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952CF4: CC0E0045 0BFC0B4A 0000C931
	v_and_b32_e32 v71, 0xffff, v5                              // 000000952D00: 368E0AFF 0000FFFF
	v_bfe_u32 v5, v4, 8, 16                                    // 000000952D08: D6100005 02411104
	v_bfe_u32 v74, v72, 12, 16                                 // 000000952D10: D610004A 02411948
	.long 0xd72c004c                                           // 000000952D18: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000952D1C: 020298FF 83DCD12D
	v_bfe_u32 v55, v53, 12, 16                                 // 000000952D24: D6100037 02411935
	v_alignbit_b32 v35, v35, v36, 16                           // 000000952D2C: D6160023 02424923
	.long 0xd72c004b                                           // 000000952D34: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 000000952D38: 02020AFF 83DCD12D
	ds_load_b128 v[5:8], v1                                    // 000000952D40: DBFC0000 05000001
	ds_load_b128 v[1:4], v1 offset:5120                        // 000000952D48: DBFC1400 01000001
	v_and_b32_e32 v73, 0xffff, v73                             // 000000952D50: 369292FF 0000FFFF
	.long 0xd72c004a                                           // 000000952D58: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000952D5C: 020294FF 83DCD12D
	.long 0xd72c0037                                           // 000000952D64: D72C0037
	v_cndmask_b32_e32 v1, 0x83dcd12d, v55, vcc_lo              // 000000952D68: 02026EFF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000952D70: D622004C 03FD014C 00006400
	v_cmp_eq_u32_e32 vcc_lo, v9, v14                           // 000000952D7C: 7C941D09
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000952D80: D622004B 03FD014B 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000952D8C: D622004A 03FD014A 00006400
	v_sad_u8 v55, v55, 0, 0x6400                               // 000000952D98: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 000000952DA4: BF870003
	v_lshl_or_b32 v73, v75, 16, v73                            // 000000952DA8: D6560049 0525214B
	v_bfe_u32 v75, v72, 8, 16                                  // 000000952DB0: D610004B 02411148
	s_or_b32 s4, vcc_lo, s4                                    // 000000952DB8: 8C04046A
	v_and_b32_e32 v74, 0xffff, v74                             // 000000952DBC: 369494FF 0000FFFF
	v_and_b32_e32 v55, 0xffff, v55                             // 000000952DC4: 366E6EFF 0000FFFF
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952DCC: CC0E0049 0BFC0B49 0000C931
	.long 0xd72c004b                                           // 000000952DD8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000952DDC: 020296FF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 000000952DE4: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000952DE8: BF870242
	v_dot2acc_f32_f16 v30, v73, v5                             // 000000952DEC: 043C0B49
	s_waitcnt lgkmcnt(0)                                       // 000000952DF0: BF89FC07
	v_dot2acc_f32_f16 v27, v73, v1                             // 000000952DF4: 04360349
	v_bfe_u32 v73, v67, 12, 16                                 // 000000952DF8: D6100049 02411943
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000952E00: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v30, v69, v6                             // 000000952E0C: 043C0D45
	.long 0xd72c0047                                           // 000000952E10: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000952E14: 02028EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000952E1C: BF870254
	.long 0xd72c0049                                           // 000000952E20: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000952E24: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v27, v69, v2                             // 000000952E2C: 04360545
	v_lshl_or_b32 v74, v75, 16, v74                            // 000000952E30: D656004A 0529214B
	v_dot2acc_f32_f16 v30, v68, v7                             // 000000952E38: 043C0F44
	.long 0xd72c004b                                           // 000000952E3C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000952E40: 02029AFF 83DCD12D
	v_dot2acc_f32_f16 v27, v68, v3                             // 000000952E48: 04360744
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000952E4C: D6220047 03FD0147 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000952E58: D6220049 03FD0149 00006400
	v_bfe_u32 v68, v65, 4, 16                                  // 000000952E64: D6100044 02410941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000952E6C: BF870113
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000952E70: 308E8E90
	.long 0xd72c0044                                           // 000000952E74: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000952E78: 020288FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000952E80: BF8701B2
	v_and_or_b32 v70, 0xffff, v70, v71                         // 000000952E84: D6570046 051E8CFF 0000FFFF
	v_and_b32_e32 v71, 0xffff, v72                             // 000000952E90: 368E90FF 0000FFFF
	v_bfe_u32 v72, v72, 4, 16                                  // 000000952E98: D6100048 02410948
	v_pk_fma_f16 v70, v70, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952EA0: CC0E0046 0BFC0B46 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000952EAC: BF870193
	.long 0xd72c0047                                           // 000000952EB0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000952EB4: 02028EFF 83DCD12D
	.long 0xd72c0048                                           // 000000952EBC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000952EC0: 020290FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000952EC8: BF870003
	v_dot2acc_f32_f16 v27, v70, v4                             // 000000952ECC: 04360946
	v_dot2acc_f32_f16 v30, v70, v8                             // 000000952ED0: 043C1146
	s_waitcnt vmcnt(5)                                         // 000000952ED4: BF8917F7
	v_bfe_u32 v70, v64, 8, 16                                  // 000000952ED8: D6100046 02411140
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000952EE0: D6220047 03FD0147 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000952EEC: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000952EF8: BF870193
	.long 0xd72c0046                                           // 000000952EFC: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000952F00: 02028CFF 83DCD12D
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000952F08: 308E8E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000952F0C: BF870241
	v_and_or_b32 v69, 0xffff, v72, v71                         // 000000952F10: D6570045 051E90FF 0000FFFF
	v_pk_fma_f16 v71, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952F1C: CC0E0047 0BFC0B4A 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000952F28: 368686FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000952F30: D6220046 03FD0146 00006400
	v_pk_fma_f16 v69, v69, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952F3C: CC0E0045 0BFC0B45 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000952F48: BF870214
	v_dot2acc_f32_f16 v28, v71, v1                             // 000000952F4C: 04380347
	.long 0xd72c0043                                           // 000000952F50: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000952F54: 020286FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000952F5C: BF870122
	v_dual_dot2acc_f32_f16 v29, v71, v5 :: v_dual_dot2acc_f32_f16 v28, v69, v2// 000000952F60: CB180B47 1D1C0545
	v_and_b32_e32 v73, 0xffff, v73                             // 000000952F68: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v29, v69, v6                             // 000000952F70: 043A0D45
	v_bfe_u32 v69, v64, 12, 16                                 // 000000952F74: D6100045 02411940
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000952F7C: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000952F88: BF870224
	v_lshl_or_b32 v72, v76, 16, v73                            // 000000952F8C: D6560048 0525214C
	v_sad_u8 v73, v75, 0, 0x6400                               // 000000952F94: D6220049 03FD014B 00006400
	.long 0xd72c0045                                           // 000000952FA0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000952FA4: 02028AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000952FAC: BF870133
	v_pk_fma_f16 v71, v72, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000952FB0: CC0E0047 0BFC0B48 0000C931
	s_waitcnt vmcnt(4)                                         // 000000952FBC: BF8913F7
	v_bfe_u32 v72, v61, 4, 16                                  // 000000952FC0: D6100048 0241093D
	v_dot2acc_f32_f16 v28, v71, v3                             // 000000952FC8: 04380747
	v_lshlrev_b32_e32 v67, 16, v67                             // 000000952FCC: 30868690
	v_dot2acc_f32_f16 v29, v71, v7                             // 000000952FD0: 043A0F47
	v_and_b32_e32 v71, 0xffff, v64                             // 000000952FD4: 368E80FF 0000FFFF
	v_bfe_u32 v64, v64, 4, 16                                  // 000000952FDC: D6100040 02410940
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000952FE4: D6220045 03FD0145 00006400
	v_and_or_b32 v67, 0xffff, v73, v67                         // 000000952FF0: D6570043 050E92FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000952FFC: BF870214
	.long 0xd72c0047                                           // 000000953000: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000953004: 02028EFF 83DCD12D
	.long 0xd72c0040                                           // 00000095300C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000953010: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000953018: BF870214
	v_and_b32_e32 v69, 0xffff, v69                             // 00000095301C: 368A8AFF 0000FFFF
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953024: CC0E0042 0BFC0B43 0000C931
	v_bfe_u32 v67, v65, 12, 16                                 // 000000953030: D6100043 02411941
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953038: BF870193
	v_lshl_or_b32 v63, v70, 16, v69                            // 00000095303C: D656003F 05152146
	v_dot2acc_f32_f16 v29, v66, v8                             // 000000953044: 043A1142
	s_delay_alu instid0(VALU_DEP_3)                            // 000000953048: BF870003
	.long 0xd72c0043                                           // 00000095304C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000953050: 020286FF 83DCD12D
	v_dot2acc_f32_f16 v28, v66, v4                             // 000000953058: 04380942
	v_bfe_u32 v66, v65, 8, 16                                  // 00000095305C: D6100042 02411141
	v_and_b32_e32 v65, 0xffff, v65                             // 000000953064: 368282FF 0000FFFF
	v_sad_u8 v64, v64, 0, 0x6400                               // 00000095306C: D6220040 03FD0140 00006400
	v_bfe_u32 v69, v62, 8, 16                                  // 000000953078: D6100045 0241113E
	v_bfe_u32 v70, v61, 12, 16                                 // 000000953080: D6100046 0241193D
	.long 0xd72c0042                                           // 000000953088: D72C0042
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000095308C: 020284FF 83DCD12D
	.long 0xd72c0041                                           // 000000953094: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000953098: 020282FF 83DCD12D
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009530A0: D6220043 03FD0143 00006400
	.long 0xd72c0045                                           // 0000009530AC: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 0000009530B0: 02028AFF 83DCD12D
	.long 0xd72c0046                                           // 0000009530B8: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 0000009530BC: 02028CFF 83DCD12D
	v_pk_fma_f16 v63, v63, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009530C4: CC0E003F 0BFC0B3F 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009530D0: BF870254
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009530D4: 368686FF 0000FFFF
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009530DC: D6220042 03FD0142 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009530E8: D6220041 03FD0141 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 0000009530F4: D6220045 03FD0145 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000953100: D6220046 03FD0146 00006400
	v_lshl_or_b32 v66, v66, 16, v67                            // 00000095310C: D6560042 050D2142
	v_sad_u8 v67, v68, 0, 0x6400                               // 000000953114: D6220043 03FD0144 00006400
	v_sad_u8 v68, v71, 0, 0x6400                               // 000000953120: D6220044 03FD0147 00006400
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000095312C: 30828290
	v_bfe_u32 v71, v61, 8, 16                                  // 000000953130: D6100047 0241113D
	v_pk_fma_f16 v66, v66, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953138: CC0E0042 0BFC0B42 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 000000953144: 367A7AFF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 00000095314C: 30888890
	v_and_or_b32 v65, 0xffff, v67, v65                         // 000000953150: D6570041 050686FF 0000FFFF
	v_bfe_u32 v67, v62, 12, 16                                 // 00000095315C: D6100043 0241193E
	v_dot2acc_f32_f16 v23, v66, v5                             // 000000953164: 042E0B42
	v_dot2acc_f32_f16 v19, v66, v1                             // 000000953168: 04260342
	v_and_or_b32 v64, 0xffff, v64, v68                         // 00000095316C: D6570040 051280FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v62                             // 000000953178: 36887CFF 0000FFFF
	.long 0xd72c0043                                           // 000000953180: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000953184: 020286FF 83DCD12D
	v_bfe_u32 v62, v62, 4, 16                                  // 00000095318C: D610003E 0241093E
	.long 0xd72c0047                                           // 000000953194: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000953198: 02028EFF 83DCD12D
	.long 0xd72c003d                                           // 0000009531A0: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009531A4: 02027AFF 83DCD12D
	.long 0xd72c0044                                           // 0000009531AC: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 0000009531B0: 020288FF 83DCD12D
	v_pk_fma_f16 v65, v65, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009531B8: CC0E0041 0BFC0B41 0000C931
	.long 0xd72c003e                                           // 0000009531C4: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009531C8: 02027CFF 83DCD12D
	v_pk_fma_f16 v64, v64, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009531D0: CC0E0040 0BFC0B40 0000C931
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009531DC: D6220043 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009531E8: BF870234
	v_dot2acc_f32_f16 v23, v65, v6                             // 0000009531EC: 042E0D41
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009531F0: D622003D 03FD013D 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 0000009531FC: D6220044 03FD0144 00006400
	v_and_b32_e32 v67, 0xffff, v67                             // 000000953208: 368686FF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 000000953210: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095321C: BF870214
	v_lshlrev_b32_e32 v61, 16, v61                             // 000000953220: 307A7A90
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000953224: 30888890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000953228: BF870234
	v_lshl_or_b32 v67, v69, 16, v67                            // 00000095322C: D6560043 050D2145
	v_and_b32_e32 v69, 0xffff, v70                             // 000000953234: 368A8CFF 0000FFFF
	v_sad_u8 v70, v71, 0, 0x6400                               // 00000095323C: D6220046 03FD0147 00006400
	v_and_or_b32 v62, 0xffff, v62, v68                         // 000000953248: D657003E 05127CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000953254: BF870224
	v_pk_fma_f16 v66, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953258: CC0E0042 0BFC0B43 0000C931
	.long 0xd72c0044                                           // 000000953264: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000953268: 020290FF 83DCD12D
	v_lshl_or_b32 v67, v70, 16, v69                            // 000000953270: D6560043 05152146
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000953278: BF870214
	v_pk_fma_f16 v62, v62, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000095327C: CC0E003E 0BFC0B3E 0000C931
	v_dot2acc_f32_f16 v26, v66, v5                             // 000000953288: 04340B42
	v_dot2acc_f32_f16 v25, v66, v1                             // 00000095328C: 04320342
	s_waitcnt vmcnt(2)                                         // 000000953290: BF890BF7
	v_bfe_u32 v66, v54, 4, 16                                  // 000000953294: D6100042 02410936
	v_sad_u8 v68, v68, 0, 0x6400                               // 00000095329C: D6220044 03FD0144 00006400
	v_dot2acc_f32_f16 v26, v62, v6                             // 0000009532A8: 04340D3E
	v_dual_dot2acc_f32_f16 v25, v62, v2 :: v_dual_and_b32 v62, 0xffff, v59// 0000009532AC: CB24053E 193E76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009532B8: BF870113
	v_and_or_b32 v61, 0xffff, v68, v61                         // 0000009532BC: D657003D 04F688FF 0000FFFF
	.long 0xd72c003e                                           // 0000009532C8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009532CC: 02027CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009532D4: BF8701A2
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009532D8: CC0E003C 0BFC0B3D 0000C931
	v_bfe_u32 v61, v59, 12, 16                                 // 0000009532E4: D610003D 0241193B
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009532EC: D622003E 03FD013E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009532F8: BF870112
	.long 0xd72c003d                                           // 0000009532FC: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000953300: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v62, 16, v62                             // 000000953308: 307C7C90
	v_dot2acc_f32_f16 v19, v65, v2                             // 00000095330C: 04260541
	v_pk_fma_f16 v65, v67, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953310: CC0E0041 0BFC0B43 0000C931
	v_mov_b32_e32 v67, v50                                     // 00000095331C: 7E860332
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000953320: D622003D 03FD013D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000095332C: BF8701B3
	v_dot2acc_f32_f16 v26, v65, v7                             // 000000953330: 04340F41
	v_dot2acc_f32_f16 v25, v65, v3                             // 000000953334: 04320741
	v_bfe_u32 v65, v58, 4, 16                                  // 000000953338: D6100041 0241093A
	v_dot2acc_f32_f16 v26, v60, v8                             // 000000953340: 0434113C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000953344: BF8701C3
	v_dot2acc_f32_f16 v25, v60, v4                             // 000000953348: 0432093C
	v_bfe_u32 v60, v59, 8, 16                                  // 00000095334C: D610003C 0241113B
	v_bfe_u32 v59, v59, 4, 16                                  // 000000953354: D610003B 0241093B
	.long 0xd72c0041                                           // 00000095335C: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 000000953360: 020282FF 83DCD12D
	.long 0xd72c003c                                           // 000000953368: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 00000095336C: 020278FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953374: BF870193
	.long 0xd72c003b                                           // 000000953378: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000095337C: 020276FF 83DCD12D
	v_sad_u8 v65, v65, 0, 0x6400                               // 000000953384: D6220041 03FD0141 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953390: BF870193
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000953394: D622003C 03FD013C 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009533A0: D622003B 03FD013B 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009533AC: BF870121
	v_and_or_b32 v59, 0xffff, v59, v62                         // 0000009533B0: D657003B 04FA76FF 0000FFFF
	v_dual_dot2acc_f32_f16 v23, v63, v7 :: v_dual_and_b32 v62, 0xffff, v56// 0000009533BC: CB240F3F 173E70FF 0000FFFF
	v_pk_fma_f16 v59, v59, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009533C8: CC0E003B 0BFC0B3B 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009533D4: BF870192
	.long 0xd72c003e                                           // 0000009533D8: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v62, vcc_lo              // 0000009533DC: 02027CFF 83DCD12D
	v_dot2acc_f32_f16 v23, v64, v8                             // 0000009533E4: 042E1140
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009533E8: BF870132
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009533EC: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v19, v63, v3                             // 0000009533F8: 0426073F
	v_bfe_u32 v63, v58, 12, 16                                 // 0000009533FC: D610003F 0241193A
	v_dual_dot2acc_f32_f16 v19, v64, v4 :: v_dual_lshlrev_b32 v62, 16, v62// 000000953404: CB220940 133E7C90
	v_bfe_u32 v64, v58, 8, 16                                  // 00000095340C: D6100040 0241113A
	v_and_b32_e32 v58, 0xffff, v58                             // 000000953414: 367474FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000095341C: BF870194
	.long 0xd72c003f                                           // 000000953420: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000953424: 02027EFF 83DCD12D
	.long 0xd72c0040                                           // 00000095342C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000953430: 020280FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953438: BF870193
	.long 0xd72c003a                                           // 00000095343C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000953440: 020274FF 83DCD12D
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000953448: D622003F 03FD013F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953454: BF870193
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000953458: D6220040 03FD0140 00006400
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000953464: D622003A 03FD013A 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000953470: BF870091
	v_lshlrev_b32_e32 v58, 16, v58                             // 000000953474: 30747490
	v_and_or_b32 v58, 0xffff, v65, v58                         // 000000953478: D657003A 04EA82FF 0000FFFF
	v_bfe_u32 v65, v54, 8, 16                                  // 000000953484: D6100041 02411136
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000095348C: BF870232
	v_pk_fma_f16 v58, v58, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953490: CC0E003A 0BFC0B3A 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 00000095349C: 367A7AFF 0000FFFF
	v_and_b32_e32 v63, 0xffff, v63                             // 0000009534A4: 367E7EFF 0000FFFF
	.long 0xd72c0041                                           // 0000009534AC: D72C0041
	v_cndmask_b32_e32 v1, 0x83dcd12d, v65, vcc_lo              // 0000009534B0: 020282FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009534B8: BF870193
	v_lshl_or_b32 v60, v60, 16, v61                            // 0000009534BC: D656003C 04F5213C
	v_lshl_or_b32 v57, v64, 16, v63                            // 0000009534C4: D6560039 04FD2140
	v_bfe_u32 v61, v56, 12, 16                                 // 0000009534CC: D610003D 02411938
	v_bfe_u32 v63, v56, 8, 16                                  // 0000009534D4: D610003F 02411138
	v_bfe_u32 v56, v56, 4, 16                                  // 0000009534DC: D6100038 02410938
	v_bfe_u32 v64, v54, 12, 16                                 // 0000009534E4: D6100040 02411936
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009534EC: 366C6CFF 0000FFFF
	.long 0xd72c003d                                           // 0000009534F4: D72C003D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 0000009534F8: 02027AFF 83DCD12D
	.long 0xd72c003f                                           // 000000953500: D72C003F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v63, vcc_lo              // 000000953504: 02027EFF 83DCD12D
	.long 0xd72c0038                                           // 00000095350C: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 000000953510: 020270FF 83DCD12D
	v_pk_fma_f16 v60, v60, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953518: CC0E003C 0BFC0B3C 0000C931
	.long 0xd72c0036                                           // 000000953524: D72C0036
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000953528: 02026CFF 83DCD12D
	v_pk_fma_f16 v57, v57, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953530: CC0E0039 0BFC0B39 0000C931
	.long 0xd72c0040                                           // 00000095353C: D72C0040
	v_cndmask_b32_e32 v1, 0x83dcd12d, v64, vcc_lo              // 000000953540: 020280FF 83DCD12D
	v_sad_u8 v61, v61, 0, 0x6400                               // 000000953548: D622003D 03FD013D 00006400
	v_sad_u8 v63, v63, 0, 0x6400                               // 000000953554: D622003F 03FD013F 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 000000953560: D6220038 03FD0138 00006400
	v_dot2acc_f32_f16 v16, v60, v5                             // 00000095356C: 04200B3C
	v_sad_u8 v54, v54, 0, 0x6400                               // 000000953570: D6220036 03FD0136 00006400
	v_dot2acc_f32_f16 v24, v60, v1                             // 00000095357C: 0430033C
	v_sad_u8 v64, v64, 0, 0x6400                               // 000000953580: D6220040 03FD0140 00006400
	v_and_or_b32 v56, 0xffff, v56, v62                         // 00000095358C: D6570038 04FA70FF 0000FFFF
	.long 0xd72c003e                                           // 000000953598: D72C003E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v66, vcc_lo              // 00000095359C: 020284FF 83DCD12D
	v_lshlrev_b32_e32 v54, 16, v54                             // 0000009535A4: 306C6C90
	v_dot2acc_f32_f16 v16, v59, v6                             // 0000009535A8: 04200D3B
	v_dot2acc_f32_f16 v24, v59, v2                             // 0000009535AC: 0430053B
	v_pk_fma_f16 v56, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009535B0: CC0E0038 0BFC0B38 0000C931
	v_mov_b32_e32 v66, v49                                     // 0000009535BC: 7E840331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009535C0: BF8701B4
	v_dot2acc_f32_f16 v16, v57, v7                             // 0000009535C4: 04200F39
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009535C8: D622003E 03FD013E 00006400
	v_dot2acc_f32_f16 v24, v57, v3                             // 0000009535D4: 04300739
	v_dot2acc_f32_f16 v16, v58, v8                             // 0000009535D8: 0420113A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009535DC: BF870193
	v_and_or_b32 v54, 0xffff, v62, v54                         // 0000009535E0: D6570036 04DA7CFF 0000FFFF
	v_dot2acc_f32_f16 v24, v58, v4                             // 0000009535EC: 0430093A
	s_waitcnt vmcnt(1)                                         // 0000009535F0: BF8907F7
	v_bfe_u32 v58, v52, 12, 16                                 // 0000009535F4: D610003A 02411934
	v_mov_b32_e32 v62, v40                                     // 0000009535FC: 7E7C0328
	v_pk_fma_f16 v54, v54, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953600: CC0E0036 0BFC0B36 0000C931
	v_and_b32_e32 v61, 0xffff, v61                             // 00000095360C: 367A7AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953614: BF870114
	.long 0xd72c003a                                           // 000000953618: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000095361C: 020274FF 83DCD12D
	v_lshl_or_b32 v61, v63, 16, v61                            // 000000953624: D656003D 04F5213F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000095362C: BF870112
	v_sad_u8 v58, v58, 0, 0x6400                               // 000000953630: D622003A 03FD013A 00006400
	v_pk_fma_f16 v60, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000095363C: CC0E003C 0BFC0B3D 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953648: BF870112
	v_and_b32_e32 v58, 0xffff, v58                             // 00000095364C: 367474FF 0000FFFF
	v_dot2acc_f32_f16 v22, v60, v5                             // 000000953654: 042C0B3C
	v_dot2acc_f32_f16 v21, v60, v1                             // 000000953658: 042A033C
	v_bfe_u32 v60, v52, 4, 16                                  // 00000095365C: D610003C 02410934
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953664: BF870193
	v_dot2acc_f32_f16 v22, v56, v6                             // 000000953668: 042C0D38
	v_dot2acc_f32_f16 v21, v56, v2                             // 00000095366C: 042A0538
	v_bfe_u32 v56, v53, 8, 16                                  // 000000953670: D6100038 02411135
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953678: BF870114
	.long 0xd72c003c                                           // 00000095367C: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 000000953680: 020278FF 83DCD12D
	.long 0xd72c0038                                           // 000000953688: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 00000095368C: 020270FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953694: BF870112
	v_sad_u8 v60, v60, 0, 0x6400                               // 000000953698: D622003C 03FD013C 00006400
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009536A4: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009536B0: BF870121
	v_lshl_or_b32 v55, v56, 16, v55                            // 0000009536B4: D6560037 04DD2138
	v_bfe_u32 v56, v35, 12, 16                                 // 0000009536BC: D6100038 02411923
	v_pk_fma_f16 v55, v55, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009536C4: CC0E0037 0BFC0B37 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009536D0: BF870112
	.long 0xd72c0038                                           // 0000009536D4: D72C0038
	v_cndmask_b32_e32 v1, 0x83dcd12d, v56, vcc_lo              // 0000009536D8: 020270FF 83DCD12D
	v_dot2acc_f32_f16 v18, v55, v1                             // 0000009536E0: 04240337
	v_and_b32_e32 v57, 0xffff, v53                             // 0000009536E4: 36726AFF 0000FFFF
	v_bfe_u32 v53, v53, 4, 16                                  // 0000009536EC: D6100035 02410935
	v_dot2acc_f32_f16 v20, v55, v5                             // 0000009536F4: 04280B37
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009536F8: D6220038 03FD0138 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000953704: BF870214
	.long 0xd72c0039                                           // 000000953708: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 00000095370C: 020272FF 83DCD12D
	.long 0xd72c0035                                           // 000000953714: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000953718: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953720: BF870193
	v_and_b32_e32 v56, 0xffff, v56                             // 000000953724: 367070FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000095372C: D6220039 03FD0139 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953738: BF870113
	v_sad_u8 v53, v53, 0, 0x6400                               // 00000095373C: D6220035 03FD0135 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000953748: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000095374C: BF870091
	v_and_or_b32 v53, 0xffff, v53, v57                         // 000000953750: D6570035 04E66AFF 0000FFFF
	v_pk_fma_f16 v53, v53, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000095375C: CC0E0035 0BFC0B35 0000C931
	v_and_b32_e32 v63, 0xffff, v64                             // 000000953768: 367E80FF 0000FFFF
	v_sad_u8 v64, v65, 0, 0x6400                               // 000000953770: D6220040 03FD0141 00006400
	v_mov_b32_e32 v65, v41                                     // 00000095377C: 7E820329
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000953780: BF870224
	v_dot2acc_f32_f16 v20, v53, v6                             // 000000953784: 04280D35
	v_dot2acc_f32_f16 v18, v53, v2                             // 000000953788: 04240535
	v_lshl_or_b32 v61, v64, 16, v63                            // 00000095378C: D656003D 04FD2140
	v_mov_b32_e32 v63, v48                                     // 000000953794: 7E7E0330
	v_mov_b32_e32 v53, v37                                     // 000000953798: 7E6A0325
	v_mov_b32_e32 v64, v49                                     // 00000095379C: 7E800331
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000009537A0: BF870134
	v_pk_fma_f16 v59, v61, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000009537A4: CC0E003B 0BFC0B3D 0000C931
	s_waitcnt vmcnt(0)                                         // 0000009537B0: BF8903F7
	v_bfe_u32 v61, v34, 4, 16                                  // 0000009537B4: D610003D 02410922
	v_dot2acc_f32_f16 v22, v59, v7                             // 0000009537BC: 042C0F3B
	v_dot2acc_f32_f16 v21, v59, v3                             // 0000009537C0: 042A073B
	v_bfe_u32 v59, v52, 8, 16                                  // 0000009537C4: D610003B 02411134
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009537CC: 366868FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009537D4: BF870214
	v_dot2acc_f32_f16 v22, v54, v8                             // 0000009537D8: 042C1136
	v_dot2acc_f32_f16 v21, v54, v4                             // 0000009537DC: 042A0936
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009537E0: BF870214
	.long 0xd72c003b                                           // 0000009537E4: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 0000009537E8: 020276FF 83DCD12D
	.long 0xd72c0034                                           // 0000009537F0: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 0000009537F4: 020268FF 83DCD12D
	v_mov_b32_e32 v54, v46                                     // 0000009537FC: 7E6C032E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000953800: BF870193
	v_sad_u8 v59, v59, 0, 0x6400                               // 000000953804: D622003B 03FD013B 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000953810: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000095381C: BF870112
	v_lshl_or_b32 v36, v59, 16, v58                            // 000000953820: D6560024 04E9213B
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000953828: 30686890
	v_bfe_u32 v58, v35, 8, 16                                  // 00000095382C: D610003A 02411123
	v_bfe_u32 v59, v34, 12, 16                                 // 000000953834: D610003B 02411922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095383C: BF870214
	v_pk_fma_f16 v36, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953840: CC0E0024 0BFC0B24 0000C931
	v_and_or_b32 v52, 0xffff, v60, v52                         // 00000095384C: D6570034 04D278FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000953858: BF870004
	.long 0xd72c003a                                           // 00000095385C: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 000000953860: 020274FF 83DCD12D
	v_bfe_u32 v60, v34, 8, 16                                  // 000000953868: D610003C 02411122
	.long 0xd72c003b                                           // 000000953870: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 000000953874: 020276FF 83DCD12D
	v_dot2acc_f32_f16 v18, v36, v3                             // 00000095387C: 04240724
	v_pk_fma_f16 v52, v52, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953880: CC0E0034 0BFC0B34 0000C931
	v_and_b32_e32 v57, 0xffff, v35                             // 00000095388C: 367246FF 0000FFFF
	v_bfe_u32 v35, v35, 4, 16                                  // 000000953894: D6100023 02410923
	v_and_b32_e32 v34, 0xffff, v34                             // 00000095389C: 364444FF 0000FFFF
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009538A4: D622003A 03FD013A 00006400
	v_dot2acc_f32_f16 v18, v52, v4                             // 0000009538B0: 04240934
	.long 0xd72c0039                                           // 0000009538B4: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v57, vcc_lo              // 0000009538B8: 020272FF 83DCD12D
	.long 0xd72c0023                                           // 0000009538C0: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000009538C4: 020246FF 83DCD12D
	.long 0xd72c003c                                           // 0000009538CC: D72C003C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v60, vcc_lo              // 0000009538D0: 020278FF 83DCD12D
	.long 0xd72c0022                                           // 0000009538D8: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000009538DC: 020244FF 83DCD12D
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009538E4: D622003B 03FD013B 00006400
	v_lshl_or_b32 v56, v58, 16, v56                            // 0000009538F0: D6560038 04E1213A
	v_dot2acc_f32_f16 v20, v36, v7                             // 0000009538F8: 04280F24
	v_mov_b32_e32 v36, v43                                     // 0000009538FC: 7E48032B
	v_sad_u8 v57, v57, 0, 0x6400                               // 000000953900: D6220039 03FD0139 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000095390C: D6220023 03FD0123 00006400
	v_pk_fma_f16 v55, v56, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953918: CC0E0037 0BFC0B38 0000C931
	v_and_b32_e32 v58, 0xffff, v59                             // 000000953924: 367476FF 0000FFFF
	v_sad_u8 v59, v60, 0, 0x6400                               // 00000095392C: D622003B 03FD013C 00006400
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000953938: 30727290
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000095393C: D6220022 03FD0122 00006400
	v_dot2acc_f32_f16 v17, v55, v5                             // 000000953948: 04220B37
	v_dot2acc_f32_f16 v15, v55, v1                             // 00000095394C: 041E0337
	v_lshl_or_b32 v56, v59, 16, v58                            // 000000953950: D6560038 04E9213B
	v_and_or_b32 v35, 0xffff, v35, v57                         // 000000953958: D6570023 04E646FF 0000FFFF
	.long 0xd72c0039                                           // 000000953964: D72C0039
	v_cndmask_b32_e32 v1, 0x83dcd12d, v61, vcc_lo              // 000000953968: 02027AFF 83DCD12D
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000953970: 30444490
	v_dot2acc_f32_f16 v20, v52, v8                             // 000000953974: 04281134
	v_pk_fma_f16 v1, v56, s5, 0xc931 op_sel_hi:[1,0,0]         // 000000953978: CC0E0001 0BFC0B38 0000C931
	v_pk_fma_f16 v35, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000953984: CC0E0023 0BFC0B23 0000C931
	v_mov_b32_e32 v56, v38                                     // 000000953990: 7E700326
	v_mov_b32_e32 v58, v47                                     // 000000953994: 7E74032F
	v_mov_b32_e32 v60, v47                                     // 000000953998: 7E78032F
	v_sad_u8 v57, v57, 0, 0x6400                               // 00000095399C: D6220039 03FD0139 00006400
	v_dot2acc_f32_f16 v17, v35, v6                             // 0000009539A8: 04220D23
	v_dot2acc_f32_f16 v15, v35, v2                             // 0000009539AC: 041E0523
	v_mov_b32_e32 v59, v39                                     // 0000009539B0: 7E760327
	v_dual_mov_b32 v61, v48 :: v_dual_mov_b32 v6, v51          // 0000009539B4: CA100130 3D060133
	v_and_or_b32 v5, 0xffff, v57, v34                          // 0000009539BC: D6570005 048A72FF 0000FFFF
	v_dot2acc_f32_f16 v17, v1, v7                              // 0000009539C8: 04220F01
	v_dot2acc_f32_f16 v15, v1, v3                              // 0000009539CC: 041E0701
	v_mov_b32_e32 v57, v46                                     // 0000009539D0: 7E72032E
	v_dual_mov_b32 v3, v50 :: v_dual_mov_b32 v34, v43          // 0000009539D4: CA100132 0322012B
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000009539DC: CC0E0002 0BFC0B05 0000C931
	v_mov_b32_e32 v5, v51                                      // 0000009539E8: 7E0A0333
	v_mov_b32_e32 v55, v45                                     // 0000009539EC: 7E6E032D
	v_dual_mov_b32 v52, v45 :: v_dual_mov_b32 v35, v10         // 0000009539F0: CA10012D 3422010A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009539F8: BF870004
	v_dot2acc_f32_f16 v17, v2, v8                              // 0000009539FC: 04221102
	v_dual_dot2acc_f32_f16 v15, v2, v4 :: v_dual_mov_b32 v2, v44// 000000953A00: CB100902 0F02012C
	v_dual_mov_b32 v4, v42 :: v_dual_mov_b32 v1, v9            // 000000953A08: CA10012A 04000109
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000953A10: 917E047E
	s_cbranch_execz 58                                         // 000000953A14: BFA5003A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1b00>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000953A18: BF8700A1
	v_add_nc_u32_e32 v9, 1, v1                                 // 000000953A1C: 4A120281
	s_mov_b32 s6, exec_lo                                      // 000000953A20: BE86007E
	.long 0xd4c1007e                                           // 000000953A24: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 000000953A28: 02021D09
	s_cbranch_execz 64606                                      // 000000953A2C: BFA5FC5E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xba8>
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000953A30: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000953A34: BF870091
	.long 0xd73c0007                                           // 000000953A38: D73C0007
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 000000953A3C: 0202128A
	.long 0xd7006a0a                                           // 000000953A40: D7006A0A
	v_cndmask_b32_e32 v1, s1, v7, vcc_lo                       // 000000953A44: 02020E01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953A48: BF870111
	v_add_co_ci_u32_e64 v37, null, s3, v8, vcc_lo              // 000000953A4C: D5207C25 01AA1003
	.long 0xd7006a07                                           // 000000953A54: D7006A07
	v_cndmask_b32_e32 v1, v10, v33, vcc_lo                     // 000000953A58: 0202430A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000953A5C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v37, vcc_lo               // 000000953A60: D5207C08 01AA4A80
	.long 0xd7006a44                                           // 000000953A68: D7006A44
	v_cndmask_b32_e32 v1, v10, v32, vcc_lo                     // 000000953A6C: 0202410A
	v_add_co_ci_u32_e64 v69, null, 0, v37, vcc_lo              // 000000953A70: D5207C45 01AA4A80
	s_clause 0xf                                               // 000000953A78: BF85000F
	global_load_b32 v42, v[7:8], off                           // 000000953A7C: DC520000 2A7C0007
	global_load_b32 v44, v[7:8], off offset:128                // 000000953A84: DC520080 2C7C0007
	global_load_b32 v41, v[7:8], off offset:256                // 000000953A8C: DC520100 297C0007
	global_load_b32 v40, v[7:8], off offset:384                // 000000953A94: DC520180 287C0007
	global_load_b32 v39, v[7:8], off offset:512                // 000000953A9C: DC520200 277C0007
	global_load_b32 v38, v[7:8], off offset:640                // 000000953AA4: DC520280 267C0007
	global_load_b32 v37, v[7:8], off offset:768                // 000000953AAC: DC520300 257C0007
	global_load_b32 v10, v[7:8], off offset:896                // 000000953AB4: DC520380 0A7C0007
	global_load_b32 v51, v[68:69], off                         // 000000953ABC: DC520000 337C0044
	global_load_b32 v50, v[68:69], off offset:128              // 000000953AC4: DC520080 327C0044
	global_load_b32 v49, v[68:69], off offset:256              // 000000953ACC: DC520100 317C0044
	global_load_b32 v48, v[68:69], off offset:384              // 000000953AD4: DC520180 307C0044
	global_load_b32 v47, v[68:69], off offset:512              // 000000953ADC: DC520200 2F7C0044
	global_load_b32 v46, v[68:69], off offset:640              // 000000953AE4: DC520280 2E7C0044
	global_load_b32 v45, v[68:69], off offset:768              // 000000953AEC: DC520300 2D7C0044
	global_load_b32 v43, v[68:69], off offset:896              // 000000953AF4: DC520380 2B7C0044
	s_branch 64554                                             // 000000953AFC: BFA0FC2A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0xba8>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000953B00: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000953B04: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000953B08: 8C7E007E
	s_waitcnt vmcnt(22)                                        // 000000953B0C: BF895BF7
	v_dual_mov_b32 v1, v30 :: v_dual_mov_b32 v2, v27           // 000000953B10: CA10011E 0102011B
	s_waitcnt vmcnt(14)                                        // 000000953B18: BF893BF7
	v_dual_mov_b32 v3, v29 :: v_dual_mov_b32 v6, v28           // 000000953B1C: CA10011D 0306011C
	v_dual_mov_b32 v4, v23 :: v_dual_mov_b32 v9, v25           // 000000953B24: CA100117 04080119
	s_waitcnt vmcnt(7)                                         // 000000953B2C: BF891FF7
	v_dual_mov_b32 v5, v19 :: v_dual_mov_b32 v8, v26           // 000000953B30: CA100113 0508011A
	v_dual_mov_b32 v7, v16 :: v_dual_mov_b32 v14, v22          // 000000953B38: CA100110 070E0116
	v_dual_mov_b32 v10, v24 :: v_dual_mov_b32 v31, v21         // 000000953B40: CA100118 0A1E0115
	v_dual_mov_b32 v32, v20 :: v_dual_mov_b32 v33, v18         // 000000953B48: CA100114 20200112
	s_waitcnt vmcnt(0)                                         // 000000953B50: BF8903F7
	v_dual_mov_b32 v34, v17 :: v_dual_mov_b32 v35, v15         // 000000953B54: CA100111 2222010F
	s_mov_b32 s0, 0x76543210                                   // 000000953B5C: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000953B64: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000953B68: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000953B74: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000953B80: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000953B8C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000953B98: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000953BA4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000953BB0: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000953BBC: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000953BC8: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000953BD4: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000953BE0: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000953BEC: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000953BF8: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000953C04: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000953C10: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v35, v35, s0, 0xfedcba98                 // 000000953C1C: D65C0023 03FC0123 FEDCBA98
	.long 0xd44c0000                                           // 000000953C28: D44C0000
	v_cndmask_b32_e32 v1, 16, v12, vcc_lo                      // 000000953C2C: 02021890
	s_barrier                                                  // 000000953C30: BFBD0000
	buffer_gl0_inv                                             // 000000953C34: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000953C3C: BE812000
	s_cbranch_execz 34                                         // 000000953C40: BFA50022 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1ccc>
	v_dual_add_f32 v8, v26, v8 :: v_dual_add_f32 v3, v29, v3   // 000000953C44: C908111A 0802071D
	v_dual_add_f32 v6, v28, v6 :: v_dual_add_f32 v1, v30, v1   // 000000953C4C: C9080D1C 0600031E
	v_lshl_or_b32 v13, v11, 10, v13                            // 000000953C54: D656000D 0435150B
	v_dual_add_f32 v2, v27, v2 :: v_dual_add_f32 v7, v16, v7   // 000000953C5C: C908051B 02060F10
	v_add_f32_e32 v4, v23, v4                                  // 000000953C64: 06080917
	v_dual_add_f32 v10, v24, v10 :: v_dual_add_f32 v9, v25, v9 // 000000953C68: C9081518 0A081319
	v_add_f32_e32 v5, v19, v5                                  // 000000953C70: 060A0B13
	v_dual_add_f32 v21, v21, v31 :: v_dual_add_f32 v14, v22, v14// 000000953C74: C9083F15 150E1D16
	v_dual_add_f32 v15, v15, v35 :: v_dual_add_f32 v18, v18, v33// 000000953C7C: C908470F 0F124312
	v_dual_add_f32 v17, v17, v34 :: v_dual_add_f32 v20, v20, v32// 000000953C84: C9084511 11144114
	ds_store_2addr_b32 v13, v1, v3 offset1:16                  // 000000953C8C: D8381000 0003010D
	ds_store_2addr_b32 v13, v2, v6 offset0:128 offset1:144     // 000000953C94: D8389080 0006020D
	ds_store_2addr_b32 v13, v4, v8 offset0:32 offset1:48       // 000000953C9C: D8383020 0008040D
	ds_store_2addr_b32 v13, v5, v9 offset0:160 offset1:176     // 000000953CA4: D838B0A0 0009050D
	ds_store_2addr_b32 v13, v7, v14 offset0:64 offset1:80      // 000000953CAC: D8385040 000E070D
	ds_store_2addr_b32 v13, v10, v21 offset0:192 offset1:208   // 000000953CB4: D838D0C0 00150A0D
	ds_store_2addr_b32 v13, v20, v17 offset0:96 offset1:112    // 000000953CBC: D8387060 0011140D
	ds_store_2addr_b32 v13, v18, v15 offset0:224 offset1:240   // 000000953CC4: D838F0E0 000F120D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000953CCC: 8C7E017E
	.long 0xd44c0001                                           // 000000953CD0: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000953CD4: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000953CDC: BF89FC07
	s_barrier                                                  // 000000953CE0: BFBD0000
	buffer_gl0_inv                                             // 000000953CE4: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000953CEC: BE832001
	s_cbranch_execnz 7                                         // 000000953CF0: BFA60007 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1d10>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000953CF4: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000953CF8: BF048209
	s_mov_b32 s3, -1                                           // 000000953CFC: BE8300C1
	s_cbranch_scc0 33                                          // 000000953D00: BFA10021 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1d88>
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000953D04: 8B6A037E
	s_cbranch_vccnz 194                                        // 000000953D08: BFA400C2 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2014>
	s_branch 572                                               // 000000953D0C: BFA0023C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2600>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000953D10: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000953D14: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000953D1C: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000953D24: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000953D2C: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000953D30: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000953D34: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000953D38: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000953D3C: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000953D40: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000953D44: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000953D4C: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000953D50: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000953D54: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000953D58: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000953D5C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000953D60: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000953D64: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000953D68: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000953D6C: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000953D70: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s3                              // 000000953D78: 8C7E037E
	s_cmp_lt_i32 s9, 2                                         // 000000953D7C: BF048209
	s_mov_b32 s3, -1                                           // 000000953D80: BE8300C1
	s_cbranch_scc1 65503                                       // 000000953D84: BFA2FFDF <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1d04>
	s_waitcnt lgkmcnt(0)                                       // 000000953D88: BF89FC07
	s_barrier                                                  // 000000953D8C: BFBD0000
	buffer_gl0_inv                                             // 000000953D90: E0AC0000 00000000
	s_and_saveexec_b32 s3, s1                                  // 000000953D98: BE832001
	s_cbranch_execz 41                                         // 000000953D9C: BFA50029 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1e44>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000953DA0: 32020087
	s_ashr_i32 s4, s29, 31                                     // 000000953DA4: 86049F1D
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000953DA8: 30080082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000953DAC: BF8704D2
	v_lshl_or_b32 v1, s31, 1, v1                               // 000000953DB0: D6560001 0405021F
	ds_load_b32 v4, v4 offset:8192                             // 000000953DB8: D8D82000 04000004
	.long 0xd72c0003                                           // 000000953DC0: D72C0003
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000953DC4: 02000901
	v_mad_u64_u32 v[1:2], null, v1, s29, 0                     // 000000953DC8: D6FE7C01 02003B01
	s_ashr_i32 s4, s31, 31                                     // 000000953DD0: 86049F1F
	s_mul_i32 s4, s4, s29                                      // 000000953DD4: 96041D04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000953DD8: BF870149
	v_add3_u32 v2, v2, v3, s4                                  // 000000953DDC: D6550002 00120702
	s_lshl_b32 s4, s10, 7                                      // 000000953DE4: 8404870A
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000953DE8: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000953DF0: 86059F04
	.long 0xd73c0001                                           // 000000953DF4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000953DF8: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000953DFC: 84848204
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000953E00: BF870132
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000953E04: 30060682
	s_add_u32 s4, s42, s4                                      // 000000953E08: 8004042A
	s_addc_u32 s5, s43, s5                                     // 000000953E0C: 8205052B
	.long 0xd7006a01                                           // 000000953E10: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000953E14: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000953E18: BF870111
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000953E1C: D5207C02 01AA0405
	.long 0xd7006a01                                           // 000000953E24: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000953E28: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 000000953E2C: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000953E30: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000953E38: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000953E3C: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s3                              // 000000953E44: 8C7E037E
	.long 0xd44a0003                                           // 000000953E48: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000953E4C: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000953E50: BC7C0000
	buffer_gl1_inv                                             // 000000953E54: E0B00000 00000000
	buffer_gl0_inv                                             // 000000953E5C: E0AC0000 00000000
	s_barrier                                                  // 000000953E64: BFBD0000
	buffer_gl0_inv                                             // 000000953E68: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000953E70: BE842003
	s_cbranch_execz 29                                         // 000000953E74: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1eec>
	s_mov_b32 s6, exec_lo                                      // 000000953E78: BE86007E
	s_mov_b32 s5, exec_lo                                      // 000000953E7C: BE85007E
	.long 0xd71f0001                                           // 000000953E80: D71F0001
	v_cndmask_b32_e32 v0, s6, v128, vcc_lo                     // 000000953E84: 02010006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000953E88: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000953E8C: 7D940280
	s_cbranch_execz 9                                          // 000000953E90: BFA50009 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1eb8>
	s_lshl_b64 s[22:23], s[10:11], 2                           // 000000953E94: 8496820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000953E98: BF8704B9
	s_add_u32 s22, s34, s22                                    // 000000953E9C: 80161622
	s_addc_u32 s23, s35, s23                                   // 000000953EA0: 82171723
	s_bcnt1_i32_b32 s6, s6                                     // 000000953EA4: BE861806
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s6              // 000000953EA8: CA100080 02020006
	global_atomic_add_u32 v2, v2, v3, s[22:23] glc             // 000000953EB0: DCD64000 02160302
	s_or_b32 exec_lo, exec_lo, s5                              // 000000953EB8: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 000000953EBC: BF8903F7
	v_readfirstlane_b32 s5, v2                                 // 000000953EC0: 7E0A0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000953EC4: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s5, v1       // 000000953EC8: CA200080 02000205
	s_add_i32 s5, s9, -1                                       // 000000953ED0: 8105C109
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000953ED4: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s5, v1                            // 000000953ED8: 7C940205
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000953EDC: D5010001 01A90280
	ds_store_b32 v2, v1 offset:17920                           // 000000953EE4: D8344600 00000102
	s_or_b32 exec_lo, exec_lo, s4                              // 000000953EEC: 8C7E047E
	v_mov_b32_e32 v1, 0                                        // 000000953EF0: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000953EF4: BF89FC07
	s_barrier                                                  // 000000953EF8: BFBD0000
	buffer_gl0_inv                                             // 000000953EFC: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:17920                            // 000000953F04: D8D84600 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000953F0C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000953F10: 7C940280
	s_cbranch_vccnz 62                                         // 000000953F14: BFA4003E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2010>
	buffer_gl1_inv                                             // 000000953F18: E0B00000 00000000
	buffer_gl0_inv                                             // 000000953F20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000953F28: BE842001
	s_cbranch_execz 44                                         // 000000953F2C: BFA5002C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1fe0>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000953F30: 360400FF 0000007F
	s_lshl_b32 s6, s10, 7                                      // 000000953F38: 8406870A
	s_ashr_i32 s1, s29, 31                                     // 000000953F3C: 86019F1D
	s_ashr_i32 s7, s6, 31                                      // 000000953F40: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000953F44: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000953F48: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000953F50: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000953F54: BF8700A9
	s_add_u32 s5, s42, s6                                      // 000000953F58: 8005062A
	s_addc_u32 s6, s43, s7                                     // 000000953F5C: 8206072B
	.long 0xd7000503                                           // 000000953F60: D7000503
	v_cndmask_b32_e32 v1, s5, v3, vcc_lo                       // 000000953F64: 02020605
	s_delay_alu instid0(VALU_DEP_1)                            // 000000953F68: BF870001
	v_add_co_ci_u32_e64 v4, null, s6, 0, s5                    // 000000953F6C: D5207C04 00150006
	s_mov_b32 s5, s29                                          // 000000953F74: BE85001D
	s_nop 0                                                    // 000000953F78: BF800000
	s_nop 0                                                    // 000000953F7C: BF800000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000953F80: BF8704A9
	v_mad_u64_u32 v[5:6], null, v1, s5, 0                      // 000000953F84: D6FE7C05 02000B01
	s_add_i32 s9, s9, -1                                       // 000000953F8C: 8109C109
	s_cmp_eq_u32 s9, 0                                         // 000000953F90: BF068009
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 000000953F94: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 000000953F9C: 4A020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000953FA0: BF870092
	.long 0xd73c0005                                           // 000000953FA4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000953FA8: 02020A82
	.long 0xd7006a05                                           // 000000953FAC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000953FB0: 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000953FB4: BF870001
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 000000953FB8: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 000000953FC0: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000953FC8: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000953FCC: 06040B02
	s_cbranch_scc0 65515                                       // 000000953FD0: BFA1FFEB <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x1f80>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000953FD4: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000953FD8: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000953FE0: 8C7E047E
	s_and_saveexec_b32 s1, s3                                  // 000000953FE4: BE812003
	s_cbranch_execz 6                                          // 000000953FE8: BFA50006 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2004>
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000953FEC: 8484820A
	v_mov_b32_e32 v1, 0                                        // 000000953FF0: 7E020280
	s_add_u32 s4, s34, s4                                      // 000000953FF4: 80040422
	s_addc_u32 s5, s35, s5                                     // 000000953FF8: 82050523
	global_store_b32 v1, v1, s[4:5]                            // 000000953FFC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000954004: 8C7E017E
	s_cbranch_execnz 2                                         // 000000954008: BFA60002 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2014>
	s_branch 380                                               // 00000095400C: BFA0017C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2600>
	s_branch 379                                               // 000000954010: BFA0017B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2600>
	v_cmp_gt_i32_e32 vcc_lo, s28, v11                          // 000000954014: 7C88161C
	.long 0xd44c0001                                           // 000000954018: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000095401C: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 000000954020: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000954024: BC7C0000
	s_barrier                                                  // 000000954028: BFBD0000
	buffer_gl0_inv                                             // 00000095402C: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000954034: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000954038: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000095403C: BE832001
	s_cbranch_execz 366                                        // 000000954040: BFA5016E <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x25fc>
	v_and_b32_e32 v1, 15, v0                                   // 000000954044: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000954048: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000095404C: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 000000954050: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000954058: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000095405C: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000954064: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000095406C: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000954074: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000095407C: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000954084: 36140081
	v_and_b32_e32 v13, 2, v0                                   // 000000954088: 361A0082
	s_waitcnt lgkmcnt(3)                                       // 00000095408C: BF89FC37
	v_dual_add_f32 v15, v2, v3 :: v_dual_and_b32 v14, 4, v0    // 000000954090: C9240702 0F0E0084
	s_waitcnt lgkmcnt(2)                                       // 000000954098: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000095409C: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000009540A4: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000009540A8: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000009540B0: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000009540B4: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v15, v3    // 0000009540BC: C9481308 0808070F
	v_sub_f32_e32 v3, v15, v3                                  // 0000009540C4: 0806070F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009540C8: BF870243
	v_dual_add_f32 v15, v2, v4 :: v_dual_add_f32 v16, v5, v7   // 0000009540CC: C9080902 0F100F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000009540D4: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000009540DC: 7C941480
	.long 0xd44a0001                                           // 0000009540E0: D44A0001
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009540E4: 02021C80
	v_add_f32_e32 v7, v9, v16                                  // 0000009540E8: 060E2109
	v_add_f32_e32 v4, v6, v8                                   // 0000009540EC: 06081106
	v_sub_f32_e32 v6, v6, v8                                   // 0000009540F0: 080C1106
	v_sub_f32_e32 v8, v9, v16                                  // 0000009540F4: 08102109
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009540F8: BF870003
	v_add_f32_e32 v9, v15, v4                                  // 0000009540FC: 0612090F
	v_sub_f32_e32 v4, v15, v4                                  // 000000954100: 0808090F
	v_add_f32_e32 v15, v3, v5                                  // 000000954104: 061E0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000954108: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000095410C: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000954110: 08040D02
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954114: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000095411C: D5010009 21AA1309
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954124: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000095412C: D5010007 21AA0F07
	v_mov_b32_dpp v16, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954134: 7E2002FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000095413C: D501000F 21AA1F0F
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954144: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000095414C: D5010005 21AA0B05
	v_mov_b32_dpp v18, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954154: 7E2402FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000095415C: D5010008 21AA1108
	v_mov_b32_dpp v19, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000954164: 7E2602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000095416C: D5010004 21AA0904
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 000000954174: D5010015 21AA0703
	v_mov_b32_dpp v22, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000095417C: 7E2C02FA FF016102
	v_cndmask_b32_e64 v23, -v2, v2, vcc_lo                     // 000000954184: D5010017 21AA0502
	s_delay_alu instid0(VALU_DEP_4)                            // 00000095418C: BF870004
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v19   // 000000954190: C9081509 02082704
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 000000954198: 7C941A80
	v_mov_b32_dpp v20, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000095419C: 7E2802FA FF016103
	v_add_f32_e32 v3, v7, v6                                   // 0000009541A4: 06060D07
	v_dual_add_f32 v5, v5, v17 :: v_dual_add_f32 v6, v15, v16  // 0000009541A8: C9082305 0506210F
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009541B0: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000009541B8: D5010002 21AA0502
	v_mov_b32_dpp v16, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009541C0: 7E2002FA FF016209
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009541C8: BF870004
	v_mov_b32_dpp v13, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009541CC: 7E1A02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009541D4: D5010005 21AA0B05
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009541DC: 7E1402FA FF016206
	v_add_f32_e32 v2, v2, v7                                   // 0000009541E4: 06040F02
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009541E8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009541F0: D5010003 21AA0703
	v_add_f32_e32 v8, v8, v18                                  // 0000009541F8: 06102508
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009541FC: D5010006 21AA0D06
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000954204: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000095420C: 7E0402FA FF016402
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v13    // 000000954214: C9080903 03041B05
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000095421C: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000954224: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095422C: BF870214
	v_add_f32_e32 v7, v7, v2                                   // 000000954230: 060E0507
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000954234: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000095423C: D5010003 20060703
	v_add_f32_e32 v6, v6, v10                                  // 000000954244: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000954248: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000954250: D5010004 20060904
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000954258: D5010009 21AA1309
	v_add_f32_e32 v15, v23, v22                                // 000000954260: 061E2D17
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v3, v3, v5    // 000000954264: C9081D08 08020B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000095426C: BF870223
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v9, v9, v16   // 000000954270: C9081504 04082109
	v_add_f32_e32 v10, v21, v20                                // 000000954278: 06142915
	v_mov_b32_dpp v17, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000095427C: 7E2202FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000954284: D501000F 21AA1F0F
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000095428C: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000954294: D5010006 20060D06
	v_mov_b32_dpp v14, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000095429C: 7E1C02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000009542A4: D501000A 21AA150A
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009542AC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009542B4: 7E0A02FA FF016807
	v_add_f32_e32 v6, v6, v13                                  // 0000009542BC: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009542C0: BF870244
	v_add_f32_e32 v10, v10, v14                                // 0000009542C4: 06141D0A
	v_add_f32_e32 v14, v15, v17                                // 0000009542C8: 061C230F
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009542CC: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000009542D4: D5010009 20061309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009542DC: 7E2202FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009542E4: D501000A 2006150A
	v_mov_b32_dpp v19, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009542EC: 7E2602FA FF01640E
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 0000009542F4: D501000E 20061D0E
	v_add_f32_e32 v18, v9, v15                                 // 0000009542FC: 06241F09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954300: 7E1202FA FF016804
	v_add_f32_e32 v17, v10, v17                                // 000000954308: 0622230A
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000095430C: 7E1A02FA FF016408
	v_cndmask_b32_e64 v16, -v8, v8, s1                         // 000000954314: D5010010 20061108
	v_add_f32_e32 v19, v14, v19                                // 00000095431C: 0626270E
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954320: 7E1002FA FF016806
	v_mov_b32_dpp v14, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954328: 7E1C02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000954330: BF8701B4
	v_add_f32_e32 v16, v16, v13                                // 000000954334: 06201B10
	v_mov_b32_dpp v13, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954338: 7E1A02FA FF016812
	v_mov_b32_dpp v15, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954340: 7E1E02FA FF016813
	v_mov_b32_dpp v10, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000954348: 7E1402FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 000000954350: 8B7E007E
	s_cbranch_execz 169                                        // 000000954354: BFA500A9 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x25fc>
	v_lshl_or_b32 v20, s10, 7, v1                              // 000000954358: D6560014 04050E0A
	v_and_b32_e32 v1, 8, v0                                    // 000000954360: 36020088
	.long 0x7f303880                                           // 000000954364: 7F303880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000954368: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000095436C: 342A289F
	.long 0x7f363998                                           // 000000954370: 7F363998
	.long 0x7f323998                                           // 000000954374: 7F323998
	.long 0x7f343998                                           // 000000954378: 7F343998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000095437C: BF870094
	.long 0xd73c0014                                           // 000000954380: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000954384: 02022881
	.long 0xd7006a16                                           // 000000954388: D7006A16
	v_cndmask_b32_e32 v1, s26, v20, vcc_lo                     // 00000095438C: 0202281A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000954390: BF870001
	v_add_co_ci_u32_e64 v23, null, s27, v21, vcc_lo            // 000000954394: D5207C17 01AA2A1B
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000095439C: 7C940280
	s_clause 0x7                                               // 0000009543A0: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 0000009543A4: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 0000009543AC: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:64           // 0000009543B4: DC820040 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:96           // 0000009543BC: DC820060 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:128          // 0000009543C4: DC820080 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:160          // 0000009543CC: DC8200A0 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:192          // 0000009543D4: DC8200C0 1E7C0016
	global_load_d16_b16 v31, v[22:23], off offset:224          // 0000009543DC: DC8200E0 1F7C0016
	v_mad_i64_i32 v[22:23], null, s29, v11, 0                  // 0000009543E4: D6FF7C16 0202161D
	v_cndmask_b32_e64 v1, -v7, v7, vcc_lo                      // 0000009543EC: D5010001 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009543F4: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000009543FC: D5010004 21AA0904
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000954404: D5010010 21AA2110
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 00000095440C: D5010011 21AA2311
	v_add_f32_e32 v1, v1, v5                                   // 000000954414: 06020B01
	v_cndmask_b32_e64 v5, -v6, v6, vcc_lo                      // 000000954418: D5010005 21AA0D06
	.long 0xd73c0016                                           // 000000954420: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000954424: 02022C81
	v_cndmask_b32_e64 v6, -v18, v18, vcc_lo                    // 000000954428: D5010006 21AA2512
	v_cndmask_b32_e64 v18, -v19, v19, vcc_lo                   // 000000954430: D5010012 21AA2713
	v_dual_add_f32 v3, v3, v2 :: v_dual_add_f32 v4, v4, v9     // 000000954438: C9080503 03041304
	v_add_f32_e32 v9, v17, v14                                 // 000000954440: 06121D11
	.long 0xd7006a13                                           // 000000954444: D7006A13
	v_cndmask_b32_e32 v1, s40, v22, vcc_lo                     // 000000954448: 02022C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000095444C: BF8701D1
	v_add_co_ci_u32_e64 v22, null, s41, v23, vcc_lo            // 000000954450: D5207C16 01AA2E29
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v5, v5, v8    // 000000954458: C9081B06 06041105
	v_dual_add_f32 v8, v16, v10 :: v_dual_mul_f32 v23, 0x3db504f3, v1// 000000954460: C9061510 081602FF 3DB504F3
	v_add_f32_e32 v10, v18, v15                                // 00000095446C: 06141F12
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000954470: C8C608FF 040206FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000095447C: 101010FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000954484: C8C60CFF 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000954490: BF8700C4
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000954494: 101414FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 00000095449C: BF891FF7
	.long 0x7f0e3998                                           // 0000009544A0: 7F0E3998
	.long 0xd7006a01                                           // 0000009544A4: D7006A01
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000009544A8: 02022913
	v_add_co_ci_u32_e64 v2, null, v22, v21, vcc_lo             // 0000009544AC: D5207C02 01AA2B16
	v_fma_mix_f32 v13, v24, v23, neg(0) op_sel_hi:[1,0,0]      // 0000009544B4: CC20000D 8A022F18
	s_waitcnt vmcnt(6)                                         // 0000009544BC: BF891BF7
	v_fma_mix_f32 v3, v25, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009544C0: CC200003 8A020719
	s_waitcnt vmcnt(5)                                         // 0000009544C8: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009544CC: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 0000009544D4: BF8913F7
	v_fma_mix_f32 v4, v27, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009544D8: CC200004 8A02091B
	s_waitcnt vmcnt(3)                                         // 0000009544E0: BF890FF7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009544E4: CC200008 8A02111C
	.long 0x7e30398d                                           // 0000009544EC: 7E30398D
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009544F0: 101212FF 3DB504F3
	s_waitcnt vmcnt(2)                                         // 0000009544F8: BF890BF7
	v_fma_mix_f32 v6, v29, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009544FC: CC200006 8A020D1D
	s_waitcnt vmcnt(0)                                         // 000000954504: BF8903F7
	v_fma_mix_f32 v10, v31, v10, neg(0) op_sel_hi:[1,0,0]      // 000000954508: CC20000A 8A02151F
	.long 0x7e0e3983                                           // 000000954510: 7E0E3983
	v_and_b32_e32 v14, 1, v24                                  // 000000954514: 361C3081
	.long 0x7e303984                                           // 000000954518: 7E303984
	v_fma_mix_f32 v9, v30, v9, neg(0) op_sel_hi:[1,0,0]        // 00000095451C: CC200009 8A02131E
	.long 0x7e323985                                           // 000000954524: 7E323985
	.long 0x7e343988                                           // 000000954528: 7E343988
	v_and_b32_e32 v7, 1, v7                                    // 00000095452C: 360E0E81
	v_and_b32_e32 v15, 1, v24                                  // 000000954530: 361E3081
	.long 0x7e303986                                           // 000000954534: 7E303986
	.long 0x7e363989                                           // 000000954538: 7E363989
	v_and_b32_e32 v16, 1, v25                                  // 00000095453C: 36203281
	v_and_b32_e32 v17, 1, v26                                  // 000000954540: 36223481
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000954544: D6550003 03FE0F03 00007FFF
	v_and_b32_e32 v18, 1, v24                                  // 000000954550: 36243081
	.long 0x7e30398a                                           // 000000954554: 7E30398A
	v_and_b32_e32 v19, 1, v27                                  // 000000954558: 36263681
	v_add3_u32 v13, v13, v14, 0x7fff                           // 00000095455C: D655000D 03FE1D0D 00007FFF
	v_add3_u32 v5, v5, v16, 0x7fff                             // 000000954568: D6550005 03FE2105 00007FFF
	v_add3_u32 v4, v4, v15, 0x7fff                             // 000000954574: D6550004 03FE1F04 00007FFF
	v_and_b32_e32 v7, 1, v24                                   // 000000954580: 360E3081
	v_add3_u32 v8, v8, v17, 0x7fff                             // 000000954584: D6550008 03FE2308 00007FFF
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000954590: D6550009 03FE2709 00007FFF
	v_add3_u32 v6, v6, v18, 0x7fff                             // 00000095459C: D6550006 03FE2506 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009545A8: BF870004
	v_add3_u32 v7, v10, v7, 0x7fff                             // 0000009545AC: D6550007 03FE0F0A 00007FFF
	s_clause 0x7                                               // 0000009545B8: BF850007
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000009545BC: DC960000 007C0301
	global_store_d16_hi_b16 v[1:2], v13, off offset:32         // 0000009545C4: DC960020 007C0D01
	global_store_d16_hi_b16 v[1:2], v5, off offset:64          // 0000009545CC: DC960040 007C0501
	global_store_d16_hi_b16 v[1:2], v4, off offset:96          // 0000009545D4: DC960060 007C0401
	global_store_d16_hi_b16 v[1:2], v8, off offset:128         // 0000009545DC: DC960080 007C0801
	global_store_d16_hi_b16 v[1:2], v6, off offset:160         // 0000009545E4: DC9600A0 007C0601
	global_store_d16_hi_b16 v[1:2], v9, off offset:192         // 0000009545EC: DC9600C0 007C0901
	global_store_d16_hi_b16 v[1:2], v7, off offset:224         // 0000009545F4: DC9600E0 007C0701
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009545FC: 8C7E037E
	s_mov_b32 s4, 0                                            // 000000954600: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000954604: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000954608: 8B6A047E
	s_cbranch_vccz 1735                                        // 00000095460C: BFA306C7 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x412c>
	s_mul_hi_i32 s0, s2, 0x66666667                            // 000000954610: 9700FF02 66666667
	v_mov_b32_e32 v8, 0                                        // 000000954618: 7E100280
	s_lshr_b32 s1, s0, 31                                      // 00000095461C: 85019F00
	s_ashr_i32 s0, s0, 3                                       // 000000954620: 86008300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000954624: BF870499
	s_add_i32 s4, s0, s1                                       // 000000954628: 81040100
	s_ashr_i32 s5, s4, 31                                      // 00000095462C: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000954630: BF870499
	s_lshl_b64 s[0:1], s[4:5], 2                               // 000000954634: 84808204
	s_add_u32 s0, s16, s0                                      // 000000954638: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000095463C: 82010111
	global_load_b32 v1, v8, s[0:1]                             // 000000954640: DC520000 01000008
	s_mov_b32 s0, exec_lo                                      // 000000954648: BE80007E
	s_waitcnt vmcnt(0)                                         // 00000095464C: BF8903F7
	v_readfirstlane_b32 s3, v1                                 // 000000954650: 7E060501
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000954654: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 00000095465C: BFA5000C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2690>
	s_mul_i32 s1, s4, 0x500                                    // 000000954660: 9601FF04 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000954668: 300A0084
	s_mul_hi_i32 s5, s4, 0x500                                 // 00000095466C: 9705FF04 00000500
	s_add_u32 s6, s14, s1                                      // 000000954674: 8006010E
	s_addc_u32 s7, s15, s5                                     // 000000954678: 8207050F
	global_load_b128 v[1:4], v5, s[6:7]                        // 00000095467C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 000000954684: BF8903F7
	ds_store_b128 v5, v[1:4] offset:10240                      // 000000954688: DB7C2800 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000954690: 8C7E007E
	v_mul_u32_u24_e32 v1, 5, v11                               // 000000954694: 16021685
	s_mul_i32 s5, s4, 0xffffffec                               // 000000954698: 9605FF04 FFFFFFEC
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v7, 2, v12     // 0000009546A0: CA220080 0A061882
	v_mov_b32_e32 v13, 0                                       // 0000009546A8: 7E1A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009546AC: BF870003
	v_min_u32_e32 v2, 35, v1                                   // 0000009546B0: 260402A3
	v_mov_b32_e32 v15, 0                                       // 0000009546B4: 7E1E0280
	v_mov_b32_e32 v17, 0                                       // 0000009546B8: 7E220280
	s_add_i32 s5, s5, s2                                       // 0000009546BC: 81050205
	s_mul_hi_i32 s6, s3, 0x96000                               // 0000009546C0: 9706FF03 00096000
	v_dual_mov_b32 v16, 0 :: v_dual_add_nc_u32 v9, 5, v2       // 0000009546C8: CA200080 10080485
	s_mul_i32 s7, s3, 0x96000                                  // 0000009546D0: 9607FF03 00096000
	s_mul_hi_i32 s2, s5, 0x7800                                // 0000009546D8: 9702FF05 00007800
	s_mul_i32 s8, s5, 0x7800                                   // 0000009546E0: 9608FF05 00007800
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009546E8: BF870001
	v_cmp_lt_u32_e32 vcc_lo, v1, v9                            // 0000009546EC: 7C921301
	s_waitcnt lgkmcnt(0)                                       // 0000009546F0: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000009546F4: BC7C0000
	s_barrier                                                  // 0000009546F8: BFBD0000
	buffer_gl0_inv                                             // 0000009546FC: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000954704: BE81206A
	s_cbranch_execz 29                                         // 000000954708: BFA5001D <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x2780>
	v_mul_u32_u24_e32 v3, 0xf00, v11                           // 00000095470C: 160616FF 00000F00
	s_add_u32 s0, s12, s7                                      // 000000954714: 8000070C
	s_addc_u32 s9, s13, s6                                     // 000000954718: 8209060D
	s_add_u32 s0, s0, s8                                       // 00000095471C: 80000800
	s_addc_u32 s9, s9, s2                                      // 000000954720: 82090209
	.long 0xd7000003                                           // 000000954724: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000954728: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000095472C: BF870111
	v_add_co_ci_u32_e64 v4, null, s9, 0, s0                    // 000000954730: D5207C04 00010009
	.long 0xd7000003                                           // 000000954738: D7000003
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000095473C: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000954740: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000954744: D5207C04 00020880
	s_clause 0x5                                               // 00000095474C: BF850005
	global_load_b32 v8, v[3:4], off                            // 000000954750: DC520000 087C0003
	global_load_b32 v10, v[3:4], off offset:128                // 000000954758: DC520080 0A7C0003
	global_load_b32 v13, v[3:4], off offset:256                // 000000954760: DC520100 0D7C0003
	global_load_b32 v15, v[3:4], off offset:384                // 000000954768: DC520180 0F7C0003
	global_load_b32 v16, v[3:4], off offset:512                // 000000954770: DC520200 107C0003
	global_load_b32 v17, v[3:4], off offset:640                // 000000954778: DC520280 117C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000954780: 8C7E017E
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v19, 0             // 000000954784: CA100080 18120080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v21, 0             // 00000095478C: CA100080 12140080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v23, 0             // 000000954794: CA100080 14160080
	v_mov_b32_e32 v22, 0                                       // 00000095479C: 7E2C0280
	v_mov_b32_e32 v14, 0                                       // 0000009547A0: 7E1C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000009547A4: BE81206A
	s_cbranch_execz 1049                                       // 0000009547A8: BFA50419 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3810>
	v_lshl_or_b32 v5, v12, 3, 4                                // 0000009547AC: D6560005 0211070C
	v_mad_u32_u24 v6, v12, 24, 0x2f0                           // 0000009547B4: D60B0006 03FD310C 000002F0
	v_cmp_ne_u32_e32 vcc_lo, 0, v12                            // 0000009547C0: 7C9A1880
	s_movk_i32 s0, 0x320                                       // 0000009547C4: B0000320
	s_add_u32 s8, s7, s8                                       // 0000009547C8: 80080807
	v_mad_u32_u24 v18, v5, 3, 0x2f0                            // 0000009547CC: D60B0012 03FD0705 000002F0
	v_lshrrev_b32_e32 v3, 5, v6                                // 0000009547D8: 32060C85
	v_mul_i32_i24_e32 v23, -3, v5                              // 0000009547DC: 122E0AC3
	v_mul_i32_i24_e32 v19, 0xffffffe8, v12                     // 0000009547E0: 122618FF FFFFFFE8
	s_addc_u32 s9, s6, s2                                      // 0000009547E8: 82090206
	v_lshrrev_b32_e32 v20, 5, v18                              // 0000009547EC: 32282485
	v_subrev_nc_u32_e32 v22, 24, v3                            // 0000009547F0: 4E2C0698
	v_mad_u32_u24 v21, v11, s0, 0x2800                         // 0000009547F4: D60B0015 03FC010B 00002800
	v_and_b32_e32 v6, 0x7e0, v6                                // 000000954800: 360C0CFF 000007E0
	v_mad_u64_u32 v[3:4], null, 0x300, v1, s[8:9]              // 000000954808: D6FE7C03 002202FF 00000300
	v_subrev_nc_u32_e32 v20, 24, v20                           // 000000954814: 4E282898
	v_cndmask_b32_e32 v22, 23, v22, vcc_lo                     // 000000954818: 022C2C97
	v_cmp_lt_u32_e32 vcc_lo, 5, v5                             // 00000095481C: 7C920A85
	v_mov_b32_e32 v14, 0                                       // 000000954820: 7E1C0280
	v_add3_u32 v25, v19, v6, 0xfffffd34                        // 000000954824: D6550019 03FE0D13 FFFFFD34
	v_and_b32_e32 v18, 0x7e0, v18                              // 000000954830: 362424FF 000007E0
	v_sub_nc_u32_e32 v28, 0, v2                                // 000000954838: 4C380480
	v_cndmask_b32_e32 v5, 23, v20, vcc_lo                      // 00000095483C: 020A2897
	v_cmp_gt_i32_e32 vcc_lo, 23, v22                           // 000000954840: 7C882C97
	v_add_nc_u32_e32 v29, 1, v1                                // 000000954844: 4A3A0281
	s_mov_b32 s2, 0                                            // 000000954848: BE820080
	s_movk_i32 s6, 0x1eee                                      // 00000095484C: B0061EEE
	v_add_nc_u32_e32 v26, 1, v5                                // 000000954850: 4A340A81
	v_cndmask_b32_e64 v24, 0xffffffe9, 1, vcc_lo               // 000000954854: D5010018 01A902FF FFFFFFE9
	v_subrev_nc_u32_e32 v27, 23, v5                            // 000000954860: 4E360A97
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000954864: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 24, v26                           // 000000954868: 7C983498
	v_add_nc_u32_e32 v20, v21, v7                              // 00000095486C: 4A280F15
	v_add_nc_u32_e32 v6, v24, v22                              // 000000954870: 4A0C2D18
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000954874: BF8700A4
	v_dual_mov_b32 v24, 0 :: v_dual_cndmask_b32 v19, v27, v26  // 000000954878: CA120080 1812351B
	.long 0xd7006a03                                           // 000000954880: D7006A03
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000954884: 02020F03
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000954888: D5207C04 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954890: BF870193
	v_lshl_add_u32 v19, v19, 2, v21                            // 000000954894: D6460013 04550513
	.long 0xd7006a03                                           // 00000095489C: D7006A03
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000009548A0: 0202060C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009548A4: BF870191
	v_add_co_ci_u32_e64 v4, null, s13, v4, vcc_lo              // 0000009548A8: D5207C04 01AA080D
	v_dual_mov_b32 v19, 0 :: v_dual_add_nc_u32 v34, 0x400, v19 // 0000009548B0: CA200080 132226FF 00000400
	v_add3_u32 v26, v23, v18, 0xfffffd34                       // 0000009548BC: D655001A 03FE2517 FFFFFD34
	v_lshl_add_u32 v18, v22, 2, v21                            // 0000009548C8: D6460012 04550516
	v_lshl_add_u32 v22, v5, 2, v21                             // 0000009548D0: D6460016 04550505
	v_and_b32_e32 v5, 16, v0                                   // 0000009548D8: 360A0090
	v_lshl_add_u32 v23, v6, 2, v21                             // 0000009548DC: D6460017 04550506
	v_add_nc_u32_e32 v30, 0x400, v20                           // 0000009548E4: 4A3C28FF 00000400
	v_dual_mov_b32 v20, 0 :: v_dual_add_nc_u32 v31, 0x400, v18 // 0000009548EC: CA200080 141E24FF 00000400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009548F8: BF8700A4
	v_lshl_or_b32 v27, v1, 5, v5                               // 0000009548FC: D656001B 04150B01
	.long 0xd7006a05                                           // 000000954904: D7006A05
	v_cndmask_b32_e32 v1, 0x300, v3, vcc_lo                    // 000000954908: 020206FF 00000300
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 000000954910: D5207C06 01AA0880
	v_add_nc_u32_e32 v32, 0x400, v23                           // 000000954918: 4A402EFF 00000400
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v33, 0x400, v22 // 000000954920: CA200080 12202CFF 00000400
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000095492C: CA100080 17160080
	v_mov_b32_e32 v21, 0                                       // 000000954934: 7E2A0280
	s_branch 921                                               // 000000954938: BFA00399 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x37a0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000095493C: 8C7E007E
	ds_load_2addr_b32 v[35:36], v32 offset0:64 offset1:88      // 000000954940: D8DC5840 23000020
	ds_load_2addr_b32 v[37:38], v34 offset0:64 offset1:88      // 000000954948: D8DC5840 25000022
	ds_load_2addr_b32 v[41:42], v31 offset0:64 offset1:88      // 000000954950: D8DC5840 2900001F
	ds_load_2addr_b32 v[44:45], v33 offset0:64 offset1:88      // 000000954958: D8DC5840 2C000021
	ds_load_b128 v[1:4], v27 offset:10240                      // 000000954960: DBFC2800 0100001B
	v_add_nc_u32_e32 v29, 1, v29                               // 000000954968: 4A3A3A81
	.long 0xd7000005                                           // 00000095496C: D7000005
	v_cndmask_b32_e32 v1, 0x300, v5, vcc_lo                    // 000000954970: 02020AFF 00000300
	v_add_nc_u32_e32 v27, 32, v27                              // 000000954978: 4A3636A0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000095497C: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 000000954984: BF89FC37
	v_dual_mov_b32 v40, v35 :: v_dual_mov_b32 v43, v37         // 000000954988: CA100123 282A0125
	s_waitcnt lgkmcnt(2)                                       // 000000954990: BF89FC27
	v_mov_b32_e32 v37, v42                                     // 000000954994: 7E4A032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000954998: BF8701B2
	.long 0xd73d002f                                           // 00000095499C: D73D002F
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 0000009549A0: 02025119
	s_waitcnt lgkmcnt(1)                                       // 0000009549A4: BF89FC17
	.long 0xd73d002a                                           // 0000009549A8: D73D002A
	v_cndmask_b32_e32 v1, v26, v43, vcc_lo                     // 0000009549AC: 0202571A
	.long 0xd73d0023                                           // 0000009549B0: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 0000009549B4: 02024919
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009549B8: BF8701A2
	v_bfe_u32 v44, v42, 9, 16                                  // 0000009549BC: D610002C 0241132A
	v_bfe_u32 v48, v42, 3, 16                                  // 0000009549C4: D6100030 0241072A
	v_bfe_u32 v49, v35, 9, 16                                  // 0000009549CC: D6100031 02411323
	v_bfe_u32 v50, v35, 6, 16                                  // 0000009549D4: D6100032 02410D23
	v_bfe_u32 v51, v35, 3, 16                                  // 0000009549DC: D6100033 02410723
	.long 0xd72c002c                                           // 0000009549E4: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009549E8: 020258FF 83DCD12D
	.long 0xd72c0030                                           // 0000009549F0: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 0000009549F4: 020260FF 83DCD12D
	.long 0xd72c0031                                           // 0000009549FC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000954A00: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 000000954A08: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000954A0C: 020264FF 83DCD12D
	.long 0xd72c0033                                           // 000000954A14: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000954A18: 020266FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000954A20: D622002C 03FD012C 00006400
	v_mov_b32_e32 v39, v45                                     // 000000954A2C: 7E4E032D
	ds_load_2addr_b32 v[40:41], v31 offset0:112 offset1:136    // 000000954A30: D8DC8870 2800001F
	ds_load_2addr_b32 v[45:46], v32 offset0:112 offset1:136    // 000000954A38: D8DC8870 2D000020
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000954A40: D6220030 03FD0130 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000954A4C: D6220031 03FD0131 00006400
	v_and_b32_e32 v44, 0xffff, v44                             // 000000954A58: 365858FF 0000FFFF
	.long 0xd73d0024                                           // 000000954A60: D73D0024
	v_cndmask_b32_e32 v1, v26, v38, vcc_lo                     // 000000954A64: 02024D1A
	v_bfe_u32 v37, v47, 9, 16                                  // 000000954A68: D6100025 0241132F
	v_bfe_u32 v38, v47, 6, 16                                  // 000000954A70: D6100026 02410D2F
	v_bfe_u32 v39, v47, 3, 16                                  // 000000954A78: D6100027 0241072F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954A80: BF870193
	.long 0xd72c0025                                           // 000000954A84: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000954A88: 02024AFF 83DCD12D
	.long 0xd72c0026                                           // 000000954A90: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000954A94: 02024CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000954A9C: BF8701C3
	.long 0xd72c0027                                           // 000000954AA0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000954AA4: 02024EFF 83DCD12D
	v_bfe_u32 v52, v36, 9, 16                                  // 000000954AAC: D6100034 02411324
	v_bfe_u32 v53, v36, 6, 16                                  // 000000954AB4: D6100035 02410D24
	v_bfe_u32 v54, v36, 3, 16                                  // 000000954ABC: D6100036 02410724
	.long 0xd72c0034                                           // 000000954AC4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000954AC8: 020268FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000954AD0: D6220025 03FD0125 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000954ADC: D6220026 03FD0126 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000954AE8: D6220027 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000954AF4: BF870093
	v_and_b32_e32 v37, 0xffff, v37                             // 000000954AF8: 364A4AFF 0000FFFF
	v_lshl_or_b32 v37, v38, 16, v37                            // 000000954B00: D6560025 04952126
	v_sad_u8 v38, v50, 0, 0x6400                               // 000000954B08: D6220026 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000954B14: BF870002
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954B18: CC0E0025 0BFC0D25 0000C931
	v_and_b32_e32 v43, 0xffff, v47                             // 000000954B24: 36565EFF 0000FFFF
	v_bfe_u32 v47, v42, 6, 16                                  // 000000954B2C: D610002F 02410D2A
	v_and_b32_e32 v42, 0xffff, v42                             // 000000954B34: 365454FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 000000954B3C: BF89FC27
	v_dot2acc_f32_f16 v14, v37, v1                             // 000000954B40: 041C0325
	.long 0xd72c002b                                           // 000000954B44: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000954B48: 020256FF 83DCD12D
	.long 0xd72c002f                                           // 000000954B50: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000954B54: 02025EFF 83DCD12D
	.long 0xd72c002a                                           // 000000954B5C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000954B60: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954B68: BF870193
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000954B6C: D622002B 03FD012B 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000954B78: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954B84: BF870193
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000954B88: D622002A 03FD012A 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000954B94: 30565690
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954B98: BF870193
	v_lshl_or_b32 v44, v47, 16, v44                            // 000000954B9C: D656002C 04B1212F
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000954BA4: 30545490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954BA8: BF870193
	v_and_or_b32 v39, 0xffff, v39, v43                         // 000000954BAC: D6570027 04AE4EFF 0000FFFF
	v_pk_fma_f16 v47, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954BB8: CC0E002F 0BFC0D2C 0000C931
	v_sad_u8 v43, v51, 0, 0x6400                               // 000000954BC4: D622002B 03FD0133 00006400
	.long 0xd72c0033                                           // 000000954BD0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000954BD4: 02026CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000954BDC: BF870094
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954BE0: CC0E0027 0BFC0D27 0000C931
	v_dual_dot2acc_f32_f16 v14, v39, v2 :: v_dual_and_b32 v35, 0xffff, v35// 000000954BEC: CB240527 0E2246FF 0000FFFF
	v_sad_u8 v39, v52, 0, 0x6400                               // 000000954BF8: D6220027 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954C04: BF870192
	.long 0xd72c0023                                           // 000000954C08: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000954C0C: 020246FF 83DCD12D
	v_dot2acc_f32_f16 v14, v47, v3                             // 000000954C14: 041C072F
	s_waitcnt lgkmcnt(0)                                       // 000000954C18: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000954C1C: BF8701C3
	v_dual_mov_b32 v39, v45 :: v_dual_and_b32 v50, 0xffff, v39 // 000000954C20: CA24012D 27324EFF 0000FFFF
	v_and_or_b32 v42, 0xffff, v48, v42                         // 000000954C2C: D657002A 04AA60FF 0000FFFF
	v_mov_b32_e32 v47, v41                                     // 000000954C38: 7E5E0329
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000954C3C: D6220023 03FD0123 00006400
	v_pk_fma_f16 v48, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954C48: CC0E0030 0BFC0D2A 0000C931
	v_and_b32_e32 v37, 0xffff, v49                             // 000000954C54: 364A62FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000954C5C: BF870223
	v_lshlrev_b32_e32 v35, 16, v35                             // 000000954C60: 30464690
	.long 0xd72c002a                                           // 000000954C64: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000954C68: 02026AFF 83DCD12D
	v_dot2acc_f32_f16 v14, v48, v4                             // 000000954C70: 041C0930
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000954C74: BF870214
	v_lshl_or_b32 v37, v38, 16, v37                            // 000000954C78: D6560025 04952126
	v_and_or_b32 v49, 0xffff, v43, v35                         // 000000954C80: D6570031 048E56FF 0000FFFF
	ds_load_2addr_b32 v[43:44], v33 offset0:112 offset1:136    // 000000954C8C: D8DC8870 2B000021
	v_pk_fma_f16 v45, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954C94: CC0E002D 0BFC0D25 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 000000954CA0: 364848FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000954CA8: D622002A 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954CB4: BF870193
	v_dot2acc_f32_f16 v23, v45, v1                             // 000000954CB8: 042E032D
	.long 0xd72c0026                                           // 000000954CBC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000954CC0: 020248FF 83DCD12D
	ds_load_2addr_b32 v[35:36], v34 offset0:112 offset1:136    // 000000954CC8: D8DC8870 23000022
	v_sad_u8 v52, v38, 0, 0x6400                               // 000000954CD0: D6220034 03FD0126 00006400
	.long 0xd73d0025                                           // 000000954CDC: D73D0025
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000954CE0: 02024F19
	v_pk_fma_f16 v38, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954CE4: CC0E0026 0BFC0D31 0000C931
	v_sad_u8 v40, v51, 0, 0x6400                               // 000000954CF0: D6220028 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000954CFC: BF870132
	v_dot2acc_f32_f16 v23, v38, v2                             // 000000954D00: 042E0526
	v_lshl_or_b32 v39, v42, 16, v50                            // 000000954D04: D6560027 04C9212A
	v_bfe_u32 v45, v37, 9, 16                                  // 000000954D0C: D610002D 02411325
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954D14: CC0E0027 0BFC0D27 0000C931
	v_lshlrev_b32_e32 v42, 16, v52                             // 000000954D20: 30546890
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954D24: BF870193
	.long 0xd72c002d                                           // 000000954D28: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000954D2C: 02025AFF 83DCD12D
	v_dot2acc_f32_f16 v23, v39, v3                             // 000000954D34: 042E0727
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000954D38: BF8701C3
	v_and_or_b32 v40, 0xffff, v40, v42                         // 000000954D3C: D6570028 04AA50FF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 000000954D48: BF89FC07
	v_mov_b32_e32 v42, v35                                     // 000000954D4C: 7E540323
	v_bfe_u32 v35, v37, 6, 16                                  // 000000954D50: D6100023 02410D25
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954D58: CC0E0028 0BFC0D28 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000954D64: BF870193
	.long 0xd73d0026                                           // 000000954D68: D73D0026
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 000000954D6C: 0202551A
	.long 0xd72c0023                                           // 000000954D70: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000954D74: 020246FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v37                             // 000000954D7C: 36544AFF 0000FFFF
	v_sad_u8 v39, v45, 0, 0x6400                               // 000000954D84: D6220027 03FD012D 00006400
	v_dot2acc_f32_f16 v23, v40, v4                             // 000000954D90: 042E0928
	v_bfe_u32 v37, v37, 3, 16                                  // 000000954D94: D6100025 02410725
	v_bfe_u32 v40, v38, 9, 16                                  // 000000954D9C: D6100028 02411326
	.long 0xd72c002a                                           // 000000954DA4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000954DA8: 020254FF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v39                             // 000000954DB0: 364E4EFF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000954DB8: D6220023 03FD0123 00006400
	.long 0xd72c0025                                           // 000000954DC4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000954DC8: 02024AFF 83DCD12D
	.long 0xd72c0028                                           // 000000954DD0: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000954DD4: 020250FF 83DCD12D
	v_bfe_u32 v43, v38, 6, 16                                  // 000000954DDC: D610002B 02410D26
	v_bfe_u32 v45, v38, 3, 16                                  // 000000954DE4: D610002D 02410726
	v_lshl_or_b32 v35, v35, 16, v39                            // 000000954DEC: D6560023 049D2123
	v_sad_u8 v39, v42, 0, 0x6400                               // 000000954DF4: D6220027 03FD012A 00006400
	v_and_b32_e32 v38, 0xffff, v38                             // 000000954E00: 364C4CFF 0000FFFF
	.long 0xd72c002a                                           // 000000954E08: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000954E0C: 020256FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000954E14: D6220025 03FD0125 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000954E20: D6220028 03FD0128 00006400
	v_lshlrev_b32_e32 v41, 16, v39                             // 000000954E2C: 30524E90
	.long 0xd72c002d                                           // 000000954E30: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000954E34: 02025AFF 83DCD12D
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954E3C: CC0E0023 0BFC0D23 0000C931
	.long 0xd72c002b                                           // 000000954E48: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000954E4C: 02024CFF 83DCD12D
	v_and_b32_e32 v40, 0xffff, v40                             // 000000954E54: 365050FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000954E5C: D622002A 03FD012A 00006400
	v_and_or_b32 v37, 0xffff, v37, v41                         // 000000954E68: D6570025 04A64AFF 0000FFFF
	v_dot2acc_f32_f16 v22, v35, v1                             // 000000954E74: 042C0323
	.long 0xd73d0026                                           // 000000954E78: D73D0026
	v_cndmask_b32_e32 v1, v25, v46, vcc_lo                     // 000000954E7C: 02025D19
	v_sad_u8 v41, v45, 0, 0x6400                               // 000000954E80: D6220029 03FD012D 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000954E8C: BF870004
	v_pk_fma_f16 v45, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954E90: CC0E002D 0BFC0D25 0000C931
	v_mov_b32_e32 v37, v44                                     // 000000954E9C: 7E4A032C
	v_lshl_or_b32 v40, v42, 16, v40                            // 000000954EA0: D6560028 04A1212A
	v_sad_u8 v39, v43, 0, 0x6400                               // 000000954EA8: D6220027 03FD012B 00006400
	v_bfe_u32 v42, v38, 9, 16                                  // 000000954EB4: D610002A 02411326
	v_dot2acc_f32_f16 v22, v45, v2                             // 000000954EBC: 042C052D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000954EC0: BF870224
	v_pk_fma_f16 v46, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954EC4: CC0E002E 0BFC0D28 0000C931
	v_and_b32_e32 v35, 0xffff, v38                             // 000000954ED0: 36464CFF 0000FFFF
	.long 0xd72c002a                                           // 000000954ED8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000954EDC: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000954EE4: BF8700A3
	v_dot2acc_f32_f16 v22, v46, v3                             // 000000954EE8: 042C072E
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000954EEC: 304E4E90
	v_and_or_b32 v47, 0xffff, v41, v39                         // 000000954EF0: D657002F 049E52FF 0000FFFF
	v_bfe_u32 v41, v38, 6, 16                                  // 000000954EFC: D6100029 02410D26
	.long 0xd73d0027                                           // 000000954F04: D73D0027
	v_cndmask_b32_e32 v1, v26, v36, vcc_lo                     // 000000954F08: 0202491A
	v_bfe_u32 v36, v38, 3, 16                                  // 000000954F0C: D6100024 02410726
	v_sad_u8 v38, v42, 0, 0x6400                               // 000000954F14: D6220026 03FD012A 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000954F20: BF870224
	.long 0xd72c0025                                           // 000000954F24: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000954F28: 020252FF 83DCD12D
	.long 0xd72c0029                                           // 000000954F30: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000954F34: 020246FF 83DCD12D
	.long 0xd72c002c                                           // 000000954F3C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000954F40: 020248FF 83DCD12D
	ds_load_2addr_b32 v[35:36], v32 offset0:160 offset1:184    // 000000954F48: D8DCB8A0 23000020
	v_and_b32_e32 v38, 0xffff, v38                             // 000000954F50: 364C4CFF 0000FFFF
	v_bfe_u32 v40, v39, 9, 16                                  // 000000954F58: D6100028 02411327
	v_bfe_u32 v42, v39, 6, 16                                  // 000000954F60: D610002A 02410D27
	v_bfe_u32 v43, v39, 3, 16                                  // 000000954F68: D610002B 02410727
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000954F70: D6220025 03FD0125 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000954F7C: D6220029 03FD0129 00006400
	.long 0xd72c0028                                           // 000000954F88: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000954F8C: 020250FF 83DCD12D
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000954F94: D622002C 03FD012C 00006400
	.long 0xd72c002a                                           // 000000954FA0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000954FA4: 020254FF 83DCD12D
	v_lshl_or_b32 v37, v37, 16, v38                            // 000000954FAC: D6560025 04992125
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000954FB4: 30525290
	.long 0xd72c0033                                           // 000000954FB8: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000954FBC: 020256FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000954FC4: BF870003
	v_pk_fma_f16 v50, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000954FC8: CC0E0032 0BFC0D25 0000C931
	v_and_b32_e32 v48, 0xffff, v39                             // 000000954FD4: 36604EFF 0000FFFF
	ds_load_2addr_b32 v[38:39], v31 offset0:160 offset1:184    // 000000954FDC: D8DCB8A0 2600001F
	v_sad_u8 v49, v40, 0, 0x6400                               // 000000954FE4: D6220031 03FD0128 00006400
	v_and_or_b32 v37, 0xffff, v44, v41                         // 000000954FF0: D6570025 04A658FF 0000FFFF
	v_dot2acc_f32_f16 v21, v50, v1                             // 000000954FFC: 042A0332
	.long 0xd72c0030                                           // 000000955000: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000955004: 020260FF 83DCD12D
	ds_load_2addr_b32 v[40:41], v34 offset0:160 offset1:184    // 00000095500C: D8DCB8A0 28000022
	v_and_b32_e32 v49, 0xffff, v49                             // 000000955014: 366262FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000095501C: D622002A 03FD012A 00006400
	ds_load_2addr_b32 v[43:44], v33 offset0:160 offset1:184    // 000000955028: D8DCB8A0 2B000021
	v_pk_fma_f16 v52, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955030: CC0E0034 0BFC0D25 0000C931
	s_waitcnt lgkmcnt(3)                                       // 00000095503C: BF89FC37
	v_mov_b32_e32 v37, v35                                     // 000000955040: 7E4A0323
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000955044: D6220030 03FD0130 00006400
	v_lshl_or_b32 v35, v42, 16, v49                            // 000000955050: D6560023 04C5212A
	v_sad_u8 v42, v51, 0, 0x6400                               // 000000955058: D622002A 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000955064: BF870193
	v_dual_dot2acc_f32_f16 v21, v52, v2 :: v_dual_lshlrev_b32 v48, 16, v48// 000000955068: CB220534 15306090
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955070: CC0E0023 0BFC0D23 0000C931
	s_waitcnt lgkmcnt(2)                                       // 00000095507C: BF89FC27
	.long 0xd73d0025                                           // 000000955080: D73D0025
	v_cndmask_b32_e32 v1, v25, v37, vcc_lo                     // 000000955084: 02024B19
	v_pk_fma_f16 v38, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955088: CC0E0026 0BFC0D2F 0000C931
	v_and_or_b32 v42, 0xffff, v42, v48                         // 000000955094: D657002A 04C254FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009550A0: BF870113
	v_bfe_u32 v45, v37, 9, 16                                  // 0000009550A4: D610002D 02411325
	v_pk_fma_f16 v46, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009550AC: CC0E002E 0BFC0D2A 0000C931
	s_waitcnt lgkmcnt(1)                                       // 0000009550B8: BF89FC17
	v_mov_b32_e32 v42, v40                                     // 0000009550BC: 7E540328
	v_bfe_u32 v40, v37, 6, 16                                  // 0000009550C0: D6100028 02410D25
	v_dot2acc_f32_f16 v22, v38, v4                             // 0000009550C8: 042C0926
	v_bfe_u32 v38, v37, 3, 16                                  // 0000009550CC: D6100026 02410725
	v_and_b32_e32 v37, 0xffff, v37                             // 0000009550D4: 364A4AFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009550DC: BF89FC07
	.long 0xd73d002a                                           // 0000009550E0: D73D002A
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 0000009550E4: 0202551A
	v_dot2acc_f32_f16 v21, v35, v3                             // 0000009550E8: 042A0723
	.long 0xd72c0023                                           // 0000009550EC: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009550F0: 02025AFF 83DCD12D
	.long 0xd72c0028                                           // 0000009550F8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 0000009550FC: 020250FF 83DCD12D
	.long 0xd72c0025                                           // 000000955104: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000955108: 02024AFF 83DCD12D
	.long 0xd72c0026                                           // 000000955110: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000955114: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v21, v46, v4                             // 00000095511C: 042A092E
	v_bfe_u32 v43, v42, 9, 16                                  // 000000955120: D610002B 0241132A
	v_and_b32_e32 v46, 0xffff, v42                             // 000000955128: 365C54FF 0000FFFF
	v_bfe_u32 v45, v42, 6, 16                                  // 000000955130: D610002D 02410D2A
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000955138: D6220023 03FD0123 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000955144: D6220028 03FD0128 00006400
	.long 0xd72c002b                                           // 000000955150: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000955154: 020256FF 83DCD12D
	v_bfe_u32 v42, v42, 3, 16                                  // 00000095515C: D610002A 0241072A
	.long 0xd72c002e                                           // 000000955164: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000955168: 02025CFF 83DCD12D
	v_and_b32_e32 v35, 0xffff, v35                             // 000000955170: 364646FF 0000FFFF
	.long 0xd72c002d                                           // 000000955178: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000095517C: 02025AFF 83DCD12D
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000955184: D6220026 03FD0126 00006400
	.long 0xd72c002a                                           // 000000955190: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000955194: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000095519C: BF870244
	v_lshl_or_b32 v40, v40, 16, v35                            // 0000009551A0: D6560028 048D2128
	v_sad_u8 v35, v37, 0, 0x6400                               // 0000009551A8: D6220023 03FD0125 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009551B4: D622002B 03FD012B 00006400
	v_mov_b32_e32 v37, v39                                     // 0000009551C0: 7E4A0327
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009551C4: CC0E0028 0BFC0D28 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009551D0: BF870254
	v_lshlrev_b32_e32 v47, 16, v35                             // 0000009551D4: 305E4690
	v_sad_u8 v35, v46, 0, 0x6400                               // 0000009551D8: D6220023 03FD012E 00006400
	v_and_b32_e32 v39, 0xffff, v43                             // 0000009551E4: 364E56FF 0000FFFF
	v_sad_u8 v43, v45, 0, 0x6400                               // 0000009551EC: D622002B 03FD012D 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009551F8: D622002A 03FD012A 00006400
	v_dual_dot2acc_f32_f16 v20, v40, v1 :: v_dual_lshlrev_b32 v45, 16, v35// 000000955204: CB220328 142C4690
	.long 0xd73d0023                                           // 00000095520C: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 000000955210: 02024919
	v_and_or_b32 v36, 0xffff, v38, v47                         // 000000955214: D6570024 04BE4CFF 0000FFFF
	v_lshl_or_b32 v37, v43, 16, v39                            // 000000955220: D6560025 049D212B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000955228: BF870004
	v_and_or_b32 v38, 0xffff, v42, v45                         // 00000095522C: D6570026 04B654FF 0000FFFF
	v_mov_b32_e32 v42, v44                                     // 000000955238: 7E54032C
	v_bfe_u32 v39, v35, 9, 16                                  // 00000095523C: D6100027 02411323
	v_pk_fma_f16 v45, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955244: CC0E002D 0BFC0D24 0000C931
	v_pk_fma_f16 v46, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955250: CC0E002E 0BFC0D25 0000C931
	v_pk_fma_f16 v47, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000095525C: CC0E002F 0BFC0D26 0000C931
	.long 0xd73d0024                                           // 000000955268: D73D0024
	v_cndmask_b32_e32 v1, v26, v41, vcc_lo                     // 00000095526C: 0202531A
	.long 0xd72c0025                                           // 000000955270: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000955274: 02024EFF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v35                             // 00000095527C: 364C46FF 0000FFFF
	v_bfe_u32 v39, v35, 6, 16                                  // 000000955284: D6100027 02410D23
	v_bfe_u32 v35, v35, 3, 16                                  // 00000095528C: D6100023 02410723
	v_dot2acc_f32_f16 v20, v45, v2                             // 000000955294: 0428052D
	v_bfe_u32 v40, v36, 9, 16                                  // 000000955298: D6100028 02411324
	.long 0xd72c0026                                           // 0000009552A0: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000009552A4: 02024CFF 83DCD12D
	v_bfe_u32 v42, v36, 6, 16                                  // 0000009552AC: D610002A 02410D24
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009552B4: D6220025 03FD0125 00006400
	.long 0xd72c0029                                           // 0000009552C0: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 0000009552C4: 020246FF 83DCD12D
	v_bfe_u32 v48, v36, 3, 16                                  // 0000009552CC: D6100030 02410724
	v_and_b32_e32 v43, 0xffff, v36                             // 0000009552D4: 365648FF 0000FFFF
	ds_load_2addr_b32 v[35:36], v32 offset0:208 offset1:232    // 0000009552DC: D8DCE8D0 23000020
	v_and_b32_e32 v49, 0xffff, v37                             // 0000009552E4: 36624AFF 0000FFFF
	v_sad_u8 v37, v38, 0, 0x6400                               // 0000009552EC: D6220025 03FD0126 00006400
	.long 0xd72c0027                                           // 0000009552F8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000009552FC: 02024EFF 83DCD12D
	.long 0xd72c002c                                           // 000000955304: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000955308: 020250FF 83DCD12D
	v_sad_u8 v50, v41, 0, 0x6400                               // 000000955310: D6220032 03FD0129 00006400
	.long 0xd72c0035                                           // 00000095531C: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000955320: 020256FF 83DCD12D
	v_lshlrev_b32_e32 v51, 16, v37                             // 000000955328: 30664A90
	ds_load_2addr_b32 v[37:38], v34 offset0:208 offset1:232    // 00000095532C: D8DCE8D0 25000022
	ds_load_2addr_b32 v[40:41], v31 offset0:208 offset1:232    // 000000955334: D8DCE8D0 2800001F
	.long 0xd72c0030                                           // 00000095533C: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000955340: 020260FF 83DCD12D
	.long 0xd72c002a                                           // 000000955348: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000095534C: 020254FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000955354: D6220027 03FD0127 00006400
	v_sad_u8 v52, v44, 0, 0x6400                               // 000000955360: D6220034 03FD012C 00006400
	ds_load_2addr_b32 v[43:44], v33 offset0:208 offset1:232    // 00000095536C: D8DCE8D0 2B000021
	v_dot2acc_f32_f16 v20, v46, v3                             // 000000955374: 0428072E
	v_lshl_or_b32 v39, v39, 16, v49                            // 000000955378: D6560027 04C52127
	v_and_or_b32 v49, 0xffff, v50, v51                         // 000000955380: D6570031 04CE64FF 0000FFFF
	v_sad_u8 v51, v53, 0, 0x6400                               // 00000095538C: D6220033 03FD0135 00006400
	v_and_b32_e32 v50, 0xffff, v52                             // 000000955398: 366468FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 0000009553A0: D622002A 03FD012A 00006400
	v_pk_fma_f16 v45, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009553AC: CC0E002D 0BFC0D27 0000C931
	s_waitcnt lgkmcnt(3)                                       // 0000009553B8: BF89FC37
	v_mov_b32_e32 v39, v35                                     // 0000009553BC: 7E4E0323
	v_sad_u8 v35, v48, 0, 0x6400                               // 0000009553C0: D6220023 03FD0130 00006400
	v_lshlrev_b32_e32 v48, 16, v51                             // 0000009553CC: 30606690
	v_lshl_or_b32 v50, v42, 16, v50                            // 0000009553D0: D6560032 04C9212A
	v_pk_fma_f16 v49, v49, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009553D8: CC0E0031 0BFC0D31 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000009553E4: BF89FC27
	v_mov_b32_e32 v42, v37                                     // 0000009553E8: 7E540325
	s_waitcnt lgkmcnt(1)                                       // 0000009553EC: BF89FC17
	.long 0xd73d0027                                           // 0000009553F0: D73D0027
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 0000009553F4: 02024F19
	v_and_or_b32 v35, 0xffff, v35, v48                         // 0000009553F8: D6570023 04C246FF 0000FFFF
	v_pk_fma_f16 v37, v50, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955404: CC0E0025 0BFC0D32 0000C931
	v_dot2acc_f32_f16 v20, v47, v4                             // 000000955410: 0428092F
	s_waitcnt lgkmcnt(0)                                       // 000000955414: BF89FC07
	.long 0xd73d002a                                           // 000000955418: D73D002A
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 00000095541C: 0202551A
	v_bfe_u32 v40, v39, 9, 16                                  // 000000955420: D6100028 02411327
	v_pk_fma_f16 v43, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955428: CC0E002B 0BFC0D23 0000C931
	v_and_b32_e32 v35, 0xffff, v39                             // 000000955434: 36464EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000095543C: BF8701A3
	.long 0xd72c0028                                           // 000000955440: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000955444: 020250FF 83DCD12D
	v_bfe_u32 v46, v42, 6, 16                                  // 00000095544C: D610002E 02410D2A
	.long 0xd72c0023                                           // 000000955454: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000955458: 020246FF 83DCD12D
	v_bfe_u32 v48, v42, 3, 16                                  // 000000955460: D6100030 0241072A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000955468: BF870003
	.long 0xd72c002e                                           // 00000095546C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000955470: 02025CFF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000955478: D6220028 03FD0128 00006400
	v_dot2acc_f32_f16 v19, v45, v1                             // 000000955484: 0426032D
	v_bfe_u32 v45, v39, 6, 16                                  // 000000955488: D610002D 02410D27
	v_bfe_u32 v39, v39, 3, 16                                  // 000000955490: D6100027 02410727
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000955498: D6220023 03FD0123 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009554A4: BF870214
	v_dual_dot2acc_f32_f16 v19, v49, v2 :: v_dual_and_b32 v40, 0xffff, v40// 0000009554A8: CB240531 132850FF 0000FFFF
	.long 0xd72c002d                                           // 0000009554B4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 0000009554B8: 02025AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009554C0: BF870214
	.long 0xd72c0027                                           // 0000009554C4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000009554C8: 02024EFF 83DCD12D
	v_lshlrev_b32_e32 v35, 16, v35                             // 0000009554D0: 30464690
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009554D4: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v19, v37, v3                             // 0000009554E0: 04260725
	v_bfe_u32 v37, v42, 9, 16                                  // 0000009554E4: D6100025 0241132A
	v_and_b32_e32 v42, 0xffff, v42                             // 0000009554EC: 365454FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009554F4: D622002D 03FD012D 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000955500: D6220027 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000095550C: BF870214
	.long 0xd72c0025                                           // 000000955510: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000955514: 02024AFF 83DCD12D
	.long 0xd72c002a                                           // 00000095551C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000955520: 020254FF 83DCD12D
	v_dot2acc_f32_f16 v19, v43, v4                             // 000000955528: 0426092B
	v_lshl_or_b32 v40, v45, 16, v40                            // 00000095552C: D6560028 04A1212D
	v_and_or_b32 v39, 0xffff, v39, v35                         // 000000955534: D6570027 048E4EFF 0000FFFF
	.long 0xd72c002d                                           // 000000955540: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000955544: 020260FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000095554C: D6220025 03FD0125 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000955558: BF870114
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000095555C: CC0E0028 0BFC0D28 0000C931
	v_and_b32_e32 v49, 0xffff, v37                             // 000000955568: 36624AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000955570: BF8701A2
	v_dual_mov_b32 v37, v41 :: v_dual_dot2acc_f32_f16 v18, v40, v1// 000000955574: CA180129 25120328
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000095557C: D622002D 03FD012D 00006400
	v_lshl_or_b32 v41, v46, 16, v49                            // 000000955588: D6560029 04C5212E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000955590: BF870233
	.long 0xd73d0023                                           // 000000955594: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 000000955598: 02024919
	v_pk_fma_f16 v46, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000095559C: CC0E002E 0BFC0D27 0000C931
	v_mov_b32_e32 v39, v44                                     // 0000009555A8: 7E4E032C
	v_pk_fma_f16 v41, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009555AC: CC0E0029 0BFC0D29 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009555B8: BF870194
	v_bfe_u32 v44, v35, 9, 16                                  // 0000009555BC: D610002C 02411323
	.long 0xd73d0024                                           // 0000009555C4: D73D0024
	v_cndmask_b32_e32 v1, v26, v38, vcc_lo                     // 0000009555C8: 02024D1A
	v_bfe_u32 v39, v35, 6, 16                                  // 0000009555CC: D6100027 02410D23
	v_and_b32_e32 v48, 0xffff, v35                             // 0000009555D4: 366046FF 0000FFFF
	v_sad_u8 v37, v42, 0, 0x6400                               // 0000009555DC: D6220025 03FD012A 00006400
	.long 0xd72c0026                                           // 0000009555E8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000009555EC: 020258FF 83DCD12D
	v_bfe_u32 v35, v35, 3, 16                                  // 0000009555F4: D6100023 02410723
	.long 0xd72c0027                                           // 0000009555FC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000955600: 02024EFF 83DCD12D
	.long 0xd72c002a                                           // 000000955608: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000095560C: 020260FF 83DCD12D
	v_bfe_u32 v44, v36, 9, 16                                  // 000000955614: D610002C 02411324
	v_bfe_u32 v48, v36, 6, 16                                  // 00000095561C: D6100030 02410D24
	v_bfe_u32 v49, v36, 3, 16                                  // 000000955624: D6100031 02410724
	v_and_b32_e32 v36, 0xffff, v36                             // 00000095562C: 364848FF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000955634: D6220026 03FD0126 00006400
	.long 0xd72c0023                                           // 000000955640: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000955644: 020246FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000095564C: D6220027 03FD0127 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000955658: D622002A 03FD012A 00006400
	.long 0xd72c0024                                           // 000000955664: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000955668: 020248FF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v38                             // 000000955670: 364C4CFF 0000FFFF
	.long 0xd72c002c                                           // 000000955678: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000095567C: 020258FF 83DCD12D
	.long 0xd72c0030                                           // 000000955684: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000955688: 020260FF 83DCD12D
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000955690: 30545490
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000955694: D6220023 03FD0123 00006400
	v_lshl_or_b32 v38, v39, 16, v38                            // 0000009556A0: D6560026 04992127
	.long 0xd72c0027                                           // 0000009556A8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 0000009556AC: 020262FF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009556B4: D6220024 03FD0124 00006400
	v_dot2acc_f32_f16 v18, v46, v2                             // 0000009556C0: 0424052E
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009556C4: D622002C 03FD012C 00006400
	v_and_or_b32 v35, 0xffff, v35, v42                         // 0000009556D0: D6570023 04AA46FF 0000FFFF
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000009556DC: CC0E0026 0BFC0D26 0000C931
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000009556E8: 30484890
	v_dot2acc_f32_f16 v18, v41, v3                             // 0000009556EC: 04240729
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009556F0: D6220027 03FD0127 00006400
	v_and_b32_e32 v42, 0xffff, v44                             // 0000009556FC: 365458FF 0000FFFF
	v_sad_u8 v44, v48, 0, 0x6400                               // 000000955704: D622002C 03FD0130 00006400
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000955710: CC0E0023 0BFC0D23 0000C931
	v_dot2acc_f32_f16 v24, v38, v1                             // 00000095571C: 04300326
	v_and_or_b32 v36, 0xffff, v39, v36                         // 000000955720: D6570024 04924EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000095572C: BF870194
	v_lshl_or_b32 v40, v44, 16, v42                            // 000000955730: D6560028 04A9212C
	v_dot2acc_f32_f16 v24, v35, v2                             // 000000955738: 04300523
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000095573C: BF8700A3
	v_pk_fma_f16 v2, v36, s6, 0xc931 op_sel_hi:[1,0,0]         // 000000955740: CC0E0002 0BFC0D24 0000C931
	v_lshlrev_b32_e32 v37, 16, v37                             // 00000095574C: 304A4A90
	v_and_or_b32 v1, 0xffff, v45, v37                          // 000000955750: D6570001 04965AFF 0000FFFF
	v_pk_fma_f16 v37, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000095575C: CC0E0025 0BFC0D28 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000955768: BF870112
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000095576C: CC0E0001 0BFC0D01 0000C931
	v_dual_dot2acc_f32_f16 v24, v37, v3 :: v_dual_add_nc_u32 v3, v28, v29// 000000955778: CB200725 18023B1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000955780: BF870112
	v_dot2acc_f32_f16 v18, v1, v4                              // 000000955784: 04240901
	v_dot2acc_f32_f16 v24, v2, v4                              // 000000955788: 04300902
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000095578C: BF8704A3
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 000000955790: 7C940686
	s_or_b32 s2, vcc_lo, s2                                    // 000000955794: 8C02026A
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000955798: 917E027E
	s_cbranch_execz 27                                         // 00000095579C: BFA5001B <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x380c>
	s_mov_b32 s0, exec_lo                                      // 0000009557A0: BE80007E
	s_waitcnt vmcnt(4)                                         // 0000009557A4: BF8913F7
	ds_store_2addr_b32 v30, v8, v10 offset0:64 offset1:96      // 0000009557A8: D8386040 000A081E
	s_waitcnt vmcnt(2)                                         // 0000009557B0: BF890BF7
	ds_store_2addr_b32 v30, v13, v15 offset0:128 offset1:160   // 0000009557B4: D838A080 000F0D1E
	s_waitcnt vmcnt(0)                                         // 0000009557BC: BF8903F7
	ds_store_2addr_b32 v30, v16, v17 offset0:192 offset1:224   // 0000009557C0: D838E0C0 0011101E
	.long 0xd4c9007e                                           // 0000009557C8: D4C9007E
	v_cndmask_b32_e32 v1, v29, v9, vcc_lo                      // 0000009557CC: 0202131D
	s_cbranch_execz 64602                                      // 0000009557D0: BFA5FC5A <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x293c>
	s_clause 0x5                                               // 0000009557D4: BF850005
	global_load_b32 v8, v[5:6], off                            // 0000009557D8: DC520000 087C0005
	global_load_b32 v10, v[5:6], off offset:128                // 0000009557E0: DC520080 0A7C0005
	global_load_b32 v13, v[5:6], off offset:256                // 0000009557E8: DC520100 0D7C0005
	global_load_b32 v15, v[5:6], off offset:384                // 0000009557F0: DC520180 0F7C0005
	global_load_b32 v16, v[5:6], off offset:512                // 0000009557F8: DC520200 107C0005
	global_load_b32 v17, v[5:6], off offset:640                // 000000955800: DC520280 117C0005
	s_branch 64588                                             // 000000955808: BFA0FC4C <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x293c>
	s_or_b32 exec_lo, exec_lo, s2                              // 00000095580C: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000955810: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000955814: 8C7E017E
	v_dual_mov_b32 v1, v14 :: v_dual_mov_b32 v2, v23           // 000000955818: CA10010E 01020117
	v_dual_mov_b32 v3, v22 :: v_dual_mov_b32 v4, v21           // 000000955820: CA100116 03040115
	v_dual_mov_b32 v5, v20 :: v_dual_mov_b32 v6, v19           // 000000955828: CA100114 05060113
	s_waitcnt vmcnt(5)                                         // 000000955830: BF8917F7
	v_dual_mov_b32 v8, v18 :: v_dual_mov_b32 v9, v24           // 000000955834: CA100112 08080118
	s_mov_b32 s0, 0x76543210                                   // 00000095583C: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v12                           // 000000955844: 7C981890
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000955848: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000955854: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000955860: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000095586C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000955878: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000955884: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000955890: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000095589C: D65C0009 03FC0109 FEDCBA98
	s_waitcnt vmcnt(0)                                         // 0000009558A8: BF8903F7
	s_barrier                                                  // 0000009558AC: BFBD0000
	buffer_gl0_inv                                             // 0000009558B0: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009558B8: BE80206A
	s_cbranch_execz 21                                         // 0000009558BC: BFA50015 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x3914>
	v_lshl_or_b32 v7, v11, 9, v7                               // 0000009558C0: D6560007 041D130B
	v_dual_add_f32 v9, v24, v9 :: v_dual_add_f32 v2, v23, v2   // 0000009558C8: C9081318 09020517
	v_dual_add_f32 v1, v14, v1 :: v_dual_add_f32 v4, v21, v4   // 0000009558D0: C908030E 01040915
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009558D8: BF870003
	v_dual_add_f32 v8, v18, v8 :: v_dual_add_nc_u32 v7, 0x2800, v7// 0000009558DC: C9201112 08060EFF 00002800
	v_dual_add_f32 v3, v22, v3 :: v_dual_add_f32 v6, v19, v6   // 0000009558E8: C9080716 03060D13
	v_add_f32_e32 v5, v20, v5                                  // 0000009558F0: 060A0B14
	ds_store_2addr_b32 v7, v1, v2 offset1:16                   // 0000009558F4: D8381000 00020107
	ds_store_2addr_b32 v7, v3, v4 offset0:32 offset1:48        // 0000009558FC: D8383020 00040307
	ds_store_2addr_b32 v7, v5, v6 offset0:64 offset1:80        // 000000955904: D8385040 00060507
	ds_store_2addr_b32 v7, v8, v9 offset0:96 offset1:112       // 00000095590C: D8387060 00090807
	s_or_b32 exec_lo, exec_lo, s0                              // 000000955914: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 000000955918: BF89FC07
	s_barrier                                                  // 00000095591C: BFBD0000
	buffer_gl0_inv                                             // 000000955920: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000955928: BE81007E
	v_cmpx_eq_u32_e32 0, v11                                   // 00000095592C: 7D941680
	s_cbranch_execz 510                                        // 000000955930: BFA501FE <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x412c>
	v_and_b32_e32 v1, 15, v0                                   // 000000955934: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000955938: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000095593C: 30040282
	v_add_nc_u32_e32 v48, 0x2800, v2                           // 000000955940: 4A6004FF 00002800
	v_add_nc_u32_e32 v52, 0x2c00, v2                           // 000000955948: 4A6804FF 00002C00
	v_add_nc_u32_e32 v56, 0x3000, v2                           // 000000955950: 4A7004FF 00003000
	v_add_nc_u32_e32 v57, 0x3400, v2                           // 000000955958: 4A7204FF 00003400
	ds_load_2addr_b32 v[2:3], v48 offset1:16                   // 000000955960: D8DC1000 02000030
	ds_load_2addr_b32 v[4:5], v48 offset0:128 offset1:144      // 000000955968: D8DC9080 04000030
	ds_load_2addr_b32 v[6:7], v52 offset1:16                   // 000000955970: D8DC1000 06000034
	ds_load_2addr_b32 v[8:9], v52 offset0:128 offset1:144      // 000000955978: D8DC9080 08000034
	ds_load_2addr_b32 v[10:11], v56 offset1:16                 // 000000955980: D8DC1000 0A000038
	ds_load_2addr_b32 v[12:13], v56 offset0:128 offset1:144    // 000000955988: D8DC9080 0C000038
	ds_load_2addr_b32 v[14:15], v57 offset1:16                 // 000000955990: D8DC1000 0E000039
	ds_load_2addr_b32 v[16:17], v57 offset0:128 offset1:144    // 000000955998: D8DC9080 10000039
	ds_load_2addr_b32 v[18:19], v48 offset0:32 offset1:48      // 0000009559A0: D8DC3020 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:160 offset1:176    // 0000009559A8: D8DCB0A0 14000030
	ds_load_2addr_b32 v[22:23], v52 offset0:32 offset1:48      // 0000009559B0: D8DC3020 16000034
	ds_load_2addr_b32 v[24:25], v52 offset0:160 offset1:176    // 0000009559B8: D8DCB0A0 18000034
	ds_load_2addr_b32 v[26:27], v56 offset0:32 offset1:48      // 0000009559C0: D8DC3020 1A000038
	ds_load_2addr_b32 v[28:29], v56 offset0:160 offset1:176    // 0000009559C8: D8DCB0A0 1C000038
	ds_load_2addr_b32 v[30:31], v57 offset0:32 offset1:48      // 0000009559D0: D8DC3020 1E000039
	ds_load_2addr_b32 v[32:33], v48 offset0:64 offset1:80      // 0000009559D8: D8DC5040 20000030
	ds_load_2addr_b32 v[34:35], v57 offset0:160 offset1:176    // 0000009559E0: D8DCB0A0 22000039
	ds_load_2addr_b32 v[36:37], v48 offset0:192 offset1:208    // 0000009559E8: D8DCD0C0 24000030
	ds_load_2addr_b32 v[38:39], v52 offset0:64 offset1:80      // 0000009559F0: D8DC5040 26000034
	ds_load_2addr_b32 v[40:41], v52 offset0:192 offset1:208    // 0000009559F8: D8DCD0C0 28000034
	ds_load_2addr_b32 v[42:43], v48 offset0:96 offset1:112     // 000000955A00: D8DC7060 2A000030
	ds_load_2addr_b32 v[44:45], v56 offset0:64 offset1:80      // 000000955A08: D8DC5040 2C000038
	ds_load_2addr_b32 v[46:47], v56 offset0:192 offset1:208    // 000000955A10: D8DCD0C0 2E000038
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 000000955A18: D8DCF0E0 30000030
	ds_load_2addr_b32 v[50:51], v52 offset0:96 offset1:112     // 000000955A20: D8DC7060 32000034
	ds_load_2addr_b32 v[52:53], v52 offset0:224 offset1:240    // 000000955A28: D8DCF0E0 34000034
	ds_load_2addr_b32 v[54:55], v56 offset0:96 offset1:112     // 000000955A30: D8DC7060 36000038
	s_waitcnt lgkmcnt(26)                                      // 000000955A38: BF89FDA7
	v_dual_add_f32 v59, 0, v3 :: v_dual_add_f32 v58, 0, v2     // 000000955A3C: C9080680 3B3A0480
	s_waitcnt lgkmcnt(18)                                      // 000000955A44: BF89FD27
	v_add_f32_e32 v19, 0, v19                                  // 000000955A48: 06262680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000955A4C: BF870092
	v_dual_add_f32 v5, v59, v5 :: v_dual_add_f32 v4, v58, v4   // 000000955A50: C9080B3B 0504093A
	v_dual_add_f32 v5, v5, v7 :: v_dual_add_f32 v18, 0, v18    // 000000955A58: C9080F05 05122480
	ds_load_2addr_b32 v[2:3], v56 offset0:224 offset1:240      // 000000955A60: D8DCF0E0 02000038
	s_waitcnt lgkmcnt(7)                                       // 000000955A68: BF89FC77
	v_add_f32_e32 v7, 0, v42                                   // 000000955A6C: 060E5480
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v5, v5, v9     // 000000955A70: C9080D04 04041305
	v_add_f32_e32 v18, v18, v20                                // 000000955A78: 06242912
	v_add_f32_e32 v20, 0, v32                                  // 000000955A7C: 06284080
	s_waitcnt lgkmcnt(4)                                       // 000000955A80: BF89FC47
	v_add_f32_e32 v7, v7, v48                                  // 000000955A84: 060E6107
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v32, 0, v33   // 000000955A88: C9081705 05204280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000955A90: BF870113
	v_dual_add_f32 v9, v20, v36 :: v_dual_add_f32 v6, v18, v22 // 000000955A94: C9084914 09062D12
	v_dual_add_f32 v18, 0, v43 :: v_dual_add_f32 v5, v5, v13   // 000000955A9C: C9085680 12041B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000955AA4: BF8701C2
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v9, v9, v38    // 000000955AA8: C9081104 04084D09
	v_add_f32_e32 v8, v19, v21                                 // 000000955AB0: 06102B13
	s_waitcnt lgkmcnt(3)                                       // 000000955AB4: BF89FC37
	v_add_f32_e32 v11, v7, v50                                 // 000000955AB8: 06166507
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v4, v4, v10   // 000000955ABC: C9081F05 05041504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000955AC4: BF870113
	v_dual_add_f32 v13, v9, v40 :: v_dual_add_f32 v8, v8, v23  // 000000955AC8: C9085109 0D082F08
	v_dual_add_f32 v6, v6, v24 :: v_dual_add_f32 v15, v5, v17  // 000000955AD0: C9083106 060E2305
	s_delay_alu instid0(VALU_DEP_2)                            // 000000955AD8: BF870002
	v_dual_add_f32 v10, v32, v37 :: v_dual_add_f32 v13, v13, v44// 000000955ADC: C9084B20 0A0C590D
	s_waitcnt lgkmcnt(2)                                       // 000000955AE4: BF89FC27
	v_add_f32_e32 v19, v11, v52                                // 000000955AE8: 0626690B
	v_add_f32_e32 v4, v4, v12                                  // 000000955AEC: 06081904
	v_add_f32_e32 v12, v8, v25                                 // 000000955AF0: 06183308
	v_add_f32_e32 v8, v18, v49                                 // 000000955AF4: 06106312
	v_add_f32_e32 v6, v6, v26                                  // 000000955AF8: 060C3506
	s_waitcnt lgkmcnt(1)                                       // 000000955AFC: BF89FC17
	v_add_f32_e32 v19, v19, v54                                // 000000955B00: 06266D13
	v_add_f32_e32 v13, v13, v46                                // 000000955B04: 061A5D0D
	v_add_f32_e32 v17, v8, v51                                 // 000000955B08: 06226708
	ds_load_2addr_b32 v[8:9], v57 offset0:192 offset1:208      // 000000955B0C: D8DCD0C0 08000039
	v_add_f32_e32 v10, v10, v39                                // 000000955B14: 06144F0A
	v_dual_add_f32 v6, v6, v28 :: v_dual_add_f32 v17, v17, v53 // 000000955B18: C9083906 06106B11
	v_add_f32_e32 v4, v4, v14                                  // 000000955B20: 06081D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000955B24: BF8700C3
	v_add_f32_e32 v18, v10, v41                                // 000000955B28: 0624530A
	ds_load_2addr_b32 v[10:11], v57 offset0:224 offset1:240    // 000000955B2C: D8DCF0E0 0A000039
	v_dual_add_f32 v17, v17, v55 :: v_dual_add_f32 v6, v6, v30 // 000000955B34: C9086F11 11063D06
	s_waitcnt lgkmcnt(2)                                       // 000000955B3C: BF89FC27
	v_dual_add_f32 v18, v18, v45 :: v_dual_add_f32 v3, v17, v3 // 000000955B40: C9085B12 12020711
	s_delay_alu instid0(VALU_DEP_1)                            // 000000955B48: BF870001
	v_add_f32_e32 v18, v18, v47                                // 000000955B4C: 06245F12
	v_add_f32_e32 v14, v4, v16                                 // 000000955B50: 061C2104
	ds_load_2addr_b32 v[4:5], v57 offset0:64 offset1:80        // 000000955B54: D8DC5040 04000039
	v_add_f32_e32 v16, v6, v34                                 // 000000955B5C: 06204506
	ds_load_2addr_b32 v[6:7], v57 offset0:96 offset1:112       // 000000955B60: D8DC7060 06000039
	s_waitcnt lgkmcnt(1)                                       // 000000955B68: BF89FC17
	v_dual_add_f32 v5, v18, v5 :: v_dual_add_f32 v2, v19, v2   // 000000955B6C: C9080B12 05020513
	s_waitcnt lgkmcnt(0)                                       // 000000955B74: BF89FC07
	v_add_f32_e32 v3, v3, v7                                   // 000000955B78: 06060F03
	v_add_f32_e32 v7, v14, v15                                 // 000000955B7C: 060E1F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000955B80: BF870193
	v_dual_add_f32 v12, v12, v27 :: v_dual_add_f32 v5, v5, v9  // 000000955B84: C908370C 0C041305
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v11    // 000000955B8C: C9080D02 02021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000955B94: BF870091
	v_add_f32_e32 v2, v2, v10                                  // 000000955B98: 06041502
	v_dual_add_f32 v12, v12, v29 :: v_dual_add_f32 v11, v2, v3 // 000000955B9C: C9083B0C 0C0A0702
	v_add_f32_e32 v4, v13, v4                                  // 000000955BA4: 0608090D
	v_sub_f32_e32 v2, v2, v3                                   // 000000955BA8: 08040702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000955BAC: BF870122
	v_add_f32_e32 v4, v4, v8                                   // 000000955BB0: 06081104
	v_sub_f32_e32 v8, v14, v15                                 // 000000955BB4: 08101F0E
	v_add_f32_e32 v10, v4, v5                                  // 000000955BB8: 06140B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000955BBC: BF870121
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v10, v11   // 000000955BC0: C9480B04 0404170A
	v_add_f32_e32 v12, v12, v31                                // 000000955BC8: 06183F0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_add_f32 v13, v4, v2 // 000000955BCC: C948170A 0A0C0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000955BD4: 08040504
	v_and_b32_e32 v14, 1, v0                                   // 000000955BD8: 361C0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000955BDC: BF8701A4
	v_add_f32_e32 v6, v12, v35                                 // 000000955BE0: 060C470C
	v_and_b32_e32 v4, 2, v0                                    // 000000955BE4: 36080082
	.long 0xd44a0000                                           // 000000955BE8: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000955BEC: 02021C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000955BF0: BF870193
	v_add_f32_e32 v9, v16, v6                                  // 000000955BF4: 06120D10
	.long 0xd44a0001                                           // 000000955BF8: D44A0001
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000955BFC: 02020880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000955C00: BF870122
	v_add_f32_e32 v3, v7, v9                                   // 000000955C04: 06061307
	v_sub_f32_e32 v7, v7, v9                                   // 000000955C08: 080E1307
	v_add_f32_e32 v9, v3, v5                                   // 000000955C0C: 06120B03
	v_sub_f32_e32 v5, v3, v5                                   // 000000955C10: 080A0B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000955C14: BF870223
	v_add_f32_e32 v4, v7, v10                                  // 000000955C18: 06081507
	v_dual_sub_f32 v7, v7, v10 :: v_dual_and_b32 v10, 4, v0    // 000000955C1C: C9641507 070A0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955C24: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000955C2C: D5010009 20021309
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000955C34: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000955C3C: BF870194
	.long 0xd44a0002                                           // 000000955C40: D44A0002
	v_cndmask_b32_e32 v1, 0, v10, vcc_lo                       // 000000955C44: 02021480
	v_add_f32_e32 v3, v9, v11                                  // 000000955C48: 06061709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000955C4C: BF8700A1
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955C50: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000955C58: D5010003 20060703
	v_dual_sub_f32 v6, v16, v6 :: v_dual_add_f32 v3, v3, v11   // 000000955C60: C9480D10 06021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000955C68: BF8700A1
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955C6C: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000955C74: D5010003 200A0703
	v_add_f32_e32 v3, v3, v10                                  // 000000955C7C: 06061503
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000955C80: BF870124
	v_add_f32_e32 v12, v8, v6                                  // 000000955C84: 06180D08
	v_sub_f32_e32 v8, v8, v6                                   // 000000955C88: 08100D08
	v_add_f32_e32 v6, v12, v13                                 // 000000955C8C: 060C1B0C
	v_sub_f32_e32 v9, v12, v13                                 // 000000955C90: 08121B0C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000955C94: BF870003
	v_add_f32_e32 v13, v8, v2                                  // 000000955C98: 061A0508
	v_sub_f32_e32 v8, v8, v2                                   // 000000955C9C: 08100508
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955CA0: 7E0402FA FF016803
	v_mov_b32_dpp v14, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955CA8: 7E1C02FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000955CB0: D5010006 20020D06
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955CB8: 7E1602FA FF01610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000955CC0: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 000000955CC4: 060C1D06
	v_mov_b32_dpp v12, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955CC8: 7E1802FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000955CD0: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000955CD8: BF8701C1
	v_add_f32_e32 v6, v6, v12                                  // 000000955CDC: 060C1906
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000955CE0: D501000C 20021B0D
	v_mov_b32_dpp v13, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955CE8: 7E1A02FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000955CF0: D5010004 20020904
	v_add_f32_e32 v11, v12, v11                                // 000000955CF8: 0616170C
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955CFC: 7E1802FA FF016406
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000955D04: BF870223
	v_add_f32_e32 v4, v4, v13                                  // 000000955D08: 06081B04
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000955D0C: D5010006 200A0D06
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955D14: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000955D1C: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000955D24: BF870134
	v_mov_b32_dpp v14, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955D28: 7E1C02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000955D30: D5010004 20060904
	v_add_f32_e32 v6, v6, v12                                  // 000000955D38: 060C1906
	v_dual_add_f32 v10, v11, v13 :: v_dual_add_f32 v11, v4, v14// 000000955D3C: C9081B0B 0A0A1D04
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955D44: 7E1C02FA FF016105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000955D4C: BF870193
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955D50: 7E0802FA FF016806
	v_mov_b32_dpp v12, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955D58: 7E1802FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000955D60: D501000A 200A150A
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955D68: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000955D70: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000955D78: BF870003
	v_add_f32_e32 v5, v10, v12                                 // 000000955D7C: 060A190A
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955D80: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000955D88: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000955D90: 06181D0F
	v_mov_b32_dpp v14, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955D94: 7E1C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000955D9C: D5010007 20020F07
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000955DA4: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000955DAC: D5010008 20021108
	v_add_f32_e32 v9, v9, v10                                  // 000000955DB4: 06121509
	v_mov_b32_dpp v10, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955DB8: 7E1402FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000955DC0: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000955DC8: BF870214
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v8, v8, v15   // 000000955DCC: C9081D07 07081F08
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955DD4: 7E1C02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000955DDC: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000955DE4: BF870214
	v_add_f32_e32 v10, v12, v10                                // 000000955DE8: 0614150C
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955DEC: 7E1802FA FF016207
	v_mov_b32_dpp v15, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000955DF4: 7E1E02FA FF016208
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000955DFC: D5010010 20060F07
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000955E04: D5010008 20061108
	v_add_f32_e32 v9, v9, v14                                  // 000000955E0C: 06121D09
	v_add_f32_e32 v7, v11, v13                                 // 000000955E10: 060E1B0B
	v_mov_b32_dpp v11, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955E14: 7E1602FA FF01640A
	v_add_f32_e32 v12, v16, v12                                // 000000955E1C: 06181910
	v_add_f32_e32 v8, v8, v15                                  // 000000955E20: 06101F08
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955E24: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000955E2C: D5010009 200A1309
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000955E34: D501000A 200A150A
	v_mov_b32_dpp v15, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955E3C: 7E1E02FA FF01640C
	v_mov_b32_dpp v17, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000955E44: 7E2202FA FF016408
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000955E4C: D501000C 200A190C
	v_cndmask_b32_e64 v18, -v8, v8, s2                         // 000000955E54: D5010012 200A1108
	v_add_f32_e32 v14, v10, v11                                // 000000955E5C: 061C170A
	v_add_f32_e32 v16, v9, v13                                 // 000000955E60: 06201B09
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E64: 7E1002FA FF016807
	v_add_f32_e32 v15, v12, v15                                // 000000955E6C: 061E1F0C
	v_add_f32_e32 v17, v18, v17                                // 000000955E70: 06222312
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E74: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E7C: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E84: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E8C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000955E94: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000955E9C: 8B7E6A7E
	s_cbranch_execz 162                                        // 000000955EA0: BFA500A2 <_ZN7halogen12_GLOBAL__N_115k_ht_gemv_dn_tsILi3ELi8ELi2ELb0EEEvPKjPKDF16_PKiS5_PtNS0_4HtSdEiNS0_6HtFoldE+0x412c>
	v_and_b32_e32 v0, 8, v0                                    // 000000955EA4: 36000088
	s_mul_i32 s0, s3, 0x1400                                   // 000000955EA8: 9600FF03 00001400
	s_mul_hi_i32 s1, s3, 0x1400                                // 000000955EB0: 9701FF03 00001400
	s_add_u32 s2, s18, s0                                      // 000000955EB8: 80020012
	s_addc_u32 s3, s19, s1                                     // 000000955EBC: 82030113
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000955EC0: 7C940080
	s_lshl_b32 s0, s5, 7                                       // 000000955EC4: 84008705
	.long 0x7f243880                                           // 000000955EC8: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000955ECC: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000955ED0: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000955ED4: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000955ED8: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000955EE0: 30020281
	s_add_u32 s2, s2, s0                                       // 000000955EE4: 80020002
	s_addc_u32 s3, s3, s1                                      // 000000955EE8: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000955EEC: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 000000955EF4: 06000900
	s_clause 0x7                                               // 000000955EF8: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000955EFC: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000955F04: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000955F0C: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000955F14: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000955F1C: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000955F24: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000955F2C: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000955F34: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000955F3C: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000955F44: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000955F4C: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000955F54: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 000000955F5C: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000955F60: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 000000955F68: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000955F70: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000955F78: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 000000955F80: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 000000955F84: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000955F88: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000955F94: BF8913F7
	.long 0x7f2a3992                                           // 000000955F98: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000955F9C: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000955FA4: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000955FB0: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 000000955FB8: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 000000955FBC: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000955FC0: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 000000955FCC: 7F283992
	.long 0x7f0c3992                                           // 000000955FD0: 7F0C3992
	s_mul_i32 s3, s4, 0x1400                                   // 000000955FD4: 9603FF04 00001400
	s_mul_hi_i32 s2, s4, 0x1400                                // 000000955FDC: 9702FF04 00001400
	s_add_u32 s3, s20, s3                                      // 000000955FE4: 80030314
	s_addc_u32 s2, s21, s2                                     // 000000955FE8: 82020215
	s_add_u32 s0, s3, s0                                       // 000000955FEC: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000955FF0: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 000000955FF4: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000955FFC: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000956004: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 00000095600C: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000956014: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000956018: CC200005 8A020B16
	.long 0x7e243980                                           // 000000956020: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000956024: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000956028: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000956030: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000956034: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 00000095603C: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000956040: CC200009 8A021319
	.long 0x7e0c3982                                           // 000000956048: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 00000095604C: 36142481
	.long 0x7e243984                                           // 000000956050: 7E243984
	.long 0x7e263983                                           // 000000956054: 7E263983
	.long 0x7e283985                                           // 000000956058: 7E283985
	.long 0x7e2a3988                                           // 00000095605C: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 000000956060: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 000000956064: 36162481
	.long 0x7e243987                                           // 000000956068: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 00000095606C: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 000000956070: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 000000956074: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000956078: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 000000956084: 361C2481
	.long 0x7e243989                                           // 000000956088: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 00000095608C: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000956098: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000009560A4: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000009560B0: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 0000009560BC: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 0000009560C0: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 0000009560CC: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009560D8: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 0000009560DC: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 0000009560E8: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009560EC: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 0000009560F4: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 0000009560FC: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000956104: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 00000095610C: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000956114: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 00000095611C: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000956124: DC9600E0 00000601
	s_endpgm                                                   // 00000095612C: BFB00000
		...

