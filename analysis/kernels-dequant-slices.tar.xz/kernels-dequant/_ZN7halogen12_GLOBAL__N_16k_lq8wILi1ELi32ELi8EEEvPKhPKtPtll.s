00000000002dee00 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002DEE00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000002DEE04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002DEE0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000002DEE14: BE830080
	v_lshrrev_b32_e32 v13, 5, v0                               // 0000002DEE18: 321A0085
	v_dual_mov_b32 v3, 0 :: v_dual_and_b32 v14, 31, v0         // 0000002DEE1C: CA240080 030E009F
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v22, 0             // 0000002DEE24: CA100080 0F160080
	s_waitcnt lgkmcnt(0)                                       // 0000002DEE2C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 0000002DEE30: 86009F0B
	.long 0xd451000e                                           // 0000002DEE34: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000002DEE38: 02001802
	s_lshr_b32 s0, s0, 28                                      // 0000002DEE3C: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 0000002DEE40: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 0000002DEE48: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000002DEE4C: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002DEE50: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000002DEE54: 86808400
	s_add_u32 s15, s0, s10                                     // 0000002DEE58: 800F0A00
	s_addc_u32 s1, s1, s11                                     // 0000002DEE5C: 82010B01
	s_and_b32 s14, s14, exec_lo                                // 0000002DEE60: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 0000002DEE64: 980E8002
	s_add_i32 s16, s0, 7                                       // 0000002DEE68: 81108700
	v_mad_u64_u32 v[9:10], null, s14, s15, v[1:2]              // 0000002DEE6C: D6FE7C09 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 0000002DEE74: 86119F10
	s_mul_i32 s14, s14, s1                                     // 0000002DEE78: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 0000002DEE7C: 85119D11
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000002DEE80: CA100080 01020080
	s_add_i32 s16, s16, s17                                    // 0000002DEE88: 81101110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002DEE8C: BF8700C9
	s_ashr_i32 s4, s16, 3                                      // 0000002DEE90: 86048310
	v_add_nc_u32_e32 v10, s14, v10                             // 0000002DEE94: 4A14140E
	.long 0xd72c0004                                           // 0000002DEE98: D72C0004
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000002DEE9C: 02021A04
	.long 0xd7006a12                                           // 0000002DEEA0: D7006A12
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000002DEEA4: 02001509
	v_add_co_ci_u32_e64 v19, null, s11, v10, vcc_lo            // 0000002DEEA8: D5207C13 01AA140B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DEEB0: BF8701B3
	v_add_nc_u32_e32 v5, s4, v4                                // 0000002DEEB4: 4A0A0804
	v_add_nc_u32_e32 v16, v4, v14                              // 0000002DEEB8: 4A201D04
	v_mov_b32_e32 v4, 0                                        // 0000002DEEBC: 7E080280
	v_min_i32_e32 v17, s0, v5                                  // 0000002DEEC0: 22220A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DEEC4: BF870113
	v_lshlrev_b32_e32 v11, 4, v16                              // 0000002DEEC8: 30162084
	v_cmp_lt_i32_e32 vcc_lo, v16, v17                          // 0000002DEECC: 7C822310
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002DEED0: BE81206A
	s_cbranch_execz 19                                         // 0000002DEED4: BFA50013 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x124>
	v_lshlrev_b32_e32 v1, 4, v16                               // 0000002DEED8: 30022084
	v_and_b32_e32 v3, -4, v16                                  // 0000002DEEDC: 360620C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DEEE0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002DEEE4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002DEEE8: 3408069F
	.long 0xd7000001                                           // 0000002DEEEC: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000002DEEF0: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DEEF4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 0000002DEEF8: D5207C02 0002050A
	.long 0xd7000005                                           // 0000002DEF00: D7000005
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000002DEF04: 02020712
	v_add_co_ci_u32_e64 v6, null, v19, v4, s0                  // 0000002DEF08: D5207C06 00020913
	s_clause 0x1                                               // 0000002DEF10: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000002DEF14: DC5E0000 017C0001
	global_load_b32 v22, v[5:6], off                           // 0000002DEF1C: DC520000 167C0005
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002DEF24: 8C7E017E
	s_and_saveexec_b32 s1, vcc_lo                              // 0000002DEF28: BE81206A
	s_cbranch_execz 254                                        // 0000002DEF2C: BFA500FE <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x528>
	v_dual_mov_b32 v15, 0 :: v_dual_add_nc_u32 v20, 0x200, v11 // 0000002DEF30: CA200080 0F1416FF 00000200
	s_waitcnt vmcnt(0)                                         // 0000002DEF3C: BF8903F7
	v_mov_b32_e32 v21, v22                                     // 0000002DEF40: 7E2A0316
	s_mov_b32 s4, 0                                            // 0000002DEF44: BE840080
	s_branch 216                                               // 0000002DEF48: BFA000D8 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x4ac>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000002DEF4C: 8C7E057E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002DEF50: 3418169F
	v_cvt_f32_ubyte1_e32 v32, v1                               // 0000002DEF54: 7E402501
	v_cvt_f32_ubyte2_e32 v33, v1                               // 0000002DEF58: 7E422701
	v_cvt_f32_ubyte0_e32 v34, v2                               // 0000002DEF5C: 7E442302
	v_cvt_f32_ubyte1_e32 v35, v2                               // 0000002DEF60: 7E462502
	.long 0xd73c0017                                           // 0000002DEF64: D73C0017
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002DEF68: 02021681
	v_cvt_f32_ubyte0_e32 v12, v1                               // 0000002DEF6C: 7E182301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000002DEF70: 7E022901
	v_cvt_f32_ubyte2_e32 v36, v2                               // 0000002DEF74: 7E482702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000002DEF78: 7E042902
	v_cvt_f32_ubyte0_e32 v37, v3                               // 0000002DEF7C: 7E4A2303
	.long 0xd700001b                                           // 0000002DEF80: D700001B
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000002DEF84: 02022E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DEF88: BF870001
	v_add_co_ci_u32_e64 v28, null, s7, v24, s0                 // 0000002DEF8C: D5207C1C 00023007
	v_cvt_f32_ubyte1_e32 v38, v3                               // 0000002DEF94: 7E4C2503
	v_cvt_f32_ubyte2_e32 v39, v3                               // 0000002DEF98: 7E4E2703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000002DEF9C: 7E062903
	s_clause 0x1                                               // 0000002DEFA0: BF850001
	global_load_b128 v[23:26], v[27:28], off                   // 0000002DEFA4: DC5E0000 177C001B
	global_load_b128 v[27:30], v[27:28], off offset:16         // 0000002DEFAC: DC5E0010 1B7C001B
	v_cvt_f32_ubyte0_e32 v40, v4                               // 0000002DEFB4: 7E502304
	v_cvt_f32_ubyte1_e32 v41, v4                               // 0000002DEFB8: 7E522504
	v_cvt_f32_ubyte2_e32 v42, v4                               // 0000002DEFBC: 7E542704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002DEFC0: 7E082904
	v_fma_mix_f32 v12, v12, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFC4: CC20600C 145A2D0C
	v_fma_mix_f32 v32, v32, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFCC: CC206020 145A2D20
	v_fma_mix_f32 v33, v33, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFD4: CC206021 145A2D21
	v_fma_mix_f32 v1, v1, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFDC: CC206001 145A2D01
	v_fma_mix_f32 v34, v34, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFE4: CC206022 145A2D22
	v_fma_mix_f32 v35, v35, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFEC: CC206023 145A2D23
	v_fma_mix_f32 v36, v36, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFF4: CC206024 145A2D24
	v_fma_mix_f32 v2, v2, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DEFFC: CC206002 145A2D02
	v_fma_mix_f32 v37, v37, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF004: CC206025 145A2D25
	v_fma_mix_f32 v38, v38, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF00C: CC206026 145A2D26
	v_fma_mix_f32 v39, v39, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF014: CC206027 145A2D27
	v_fma_mix_f32 v3, v3, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF01C: CC206003 145A2D03
	v_fma_mix_f32 v40, v40, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF024: CC206028 145A2D28
	v_fma_mix_f32 v41, v41, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF02C: CC206029 145A2D29
	v_fma_mix_f32 v42, v42, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF034: CC20602A 145A2D2A
	v_fma_mix_f32 v4, v4, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002DF03C: CC206004 145A2D04
	v_bfe_u32 v22, v12, 16, 1                                  // 0000002DF044: D6100016 0205210C
	v_bfe_u32 v46, v32, 16, 1                                  // 0000002DF04C: D610002E 02052120
	v_bfe_u32 v47, v33, 16, 1                                  // 0000002DF054: D610002F 02052121
	.long 0x7f3e3880                                           // 0000002DF05C: 7F3E3880
	v_bfe_u32 v48, v1, 16, 1                                   // 0000002DF060: D6100030 02052101
	v_add3_u32 v12, v12, v22, 0x7fff                           // 0000002DF068: D655000C 03FE2D0C 00007FFF
	v_bfe_u32 v49, v34, 16, 1                                  // 0000002DF074: D6100031 02052122
	v_add3_u32 v33, v33, v47, 0x7fff                           // 0000002DF07C: D6550021 03FE5F21 00007FFF
	v_add3_u32 v32, v32, v46, 0x7fff                           // 0000002DF088: D6550020 03FE5D20 00007FFF
	.long 0x7f56399f                                           // 0000002DF094: 7F56399F
	.long 0x7e3e398c                                           // 0000002DF098: 7E3E398C
	v_bfe_u32 v50, v35, 16, 1                                  // 0000002DF09C: D6100032 02052123
	v_bfe_u32 v51, v36, 16, 1                                  // 0000002DF0A4: D6100033 02052124
	v_add3_u32 v1, v1, v48, 0x7fff                             // 0000002DF0AC: D6550001 03FE6101 00007FFF
	.long 0x7e5639a1                                           // 0000002DF0B8: 7E5639A1
	v_add3_u32 v33, v34, v49, 0x7fff                           // 0000002DF0BC: D6550021 03FE6322 00007FFF
	v_and_or_b32 v32, 0xffff0000, v32, v31                     // 0000002DF0C8: D6570020 047E40FF FFFF0000
	v_bfe_u32 v52, v2, 16, 1                                   // 0000002DF0D4: D6100034 02052102
	v_bfe_u32 v53, v37, 16, 1                                  // 0000002DF0DC: D6100035 02052125
	v_add3_u32 v34, v35, v50, 0x7fff                           // 0000002DF0E4: D6550022 03FE6523 00007FFF
	v_add3_u32 v35, v36, v51, 0x7fff                           // 0000002DF0F0: D6550023 03FE6724 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v43                       // 0000002DF0FC: D6570001 04AE02FF FFFF0000
	.long 0x7e3e39a1                                           // 0000002DF108: 7E3E39A1
	.long 0x7f58399f                                           // 0000002DF10C: 7F58399F
	v_bfe_u32 v54, v38, 16, 1                                  // 0000002DF110: D6100036 02052126
	v_bfe_u32 v55, v39, 16, 1                                  // 0000002DF118: D6100037 02052127
	v_add3_u32 v2, v2, v52, 0x7fff                             // 0000002DF120: D6550002 03FE6902 00007FFF
	.long 0x7e5839a3                                           // 0000002DF12C: 7E5839A3
	v_and_or_b32 v33, 0xffff0000, v34, v31                     // 0000002DF130: D6570021 047E44FF FFFF0000
	v_bfe_u32 v56, v3, 16, 1                                   // 0000002DF13C: D6100038 02052103
	v_bfe_u32 v57, v40, 16, 1                                  // 0000002DF144: D6100039 02052128
	.long 0x7f5a399f                                           // 0000002DF14C: 7F5A399F
	v_and_or_b32 v2, 0xffff0000, v2, v44                       // 0000002DF150: D6570002 04B204FF FFFF0000
	v_bfe_u32 v22, v41, 16, 1                                  // 0000002DF15C: D6100016 02052129
	v_bfe_u32 v58, v42, 16, 1                                  // 0000002DF164: D610003A 0205212A
	v_add3_u32 v3, v3, v56, 0x7fff                             // 0000002DF16C: D6550003 03FE7103 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 0000002DF178: D610000C 02052104
	v_add_nc_u32_e32 v20, 0x200, v20                           // 0000002DF180: 4A2828FF 00000200
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000002DF188: 8B006A7E
	v_add_nc_u32_e32 v11, 0x200, v11                           // 0000002DF18C: 4A1616FF 00000200
	s_or_b32 s4, s0, s4                                        // 0000002DF194: 8C040400
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000002DF198: D6550004 03FE1904 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000002DF1A4: BF8907F7
	v_dot2_f32_bf16 v23, v23, v32, 0                           // 0000002DF1A8: CC1A4017 1A024117
	v_add3_u32 v32, v37, v53, 0x7fff                           // 0000002DF1B0: D6550020 03FE6B25 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000002DF1BC: BF870232
	v_dot2_f32_bf16 v1, v24, v1, v23                           // 0000002DF1C0: CC1A4001 1C5E0318
	v_add3_u32 v23, v38, v54, 0x7fff                           // 0000002DF1C8: D6550017 03FE6D26 00007FFF
	v_add3_u32 v24, v39, v55, 0x7fff                           // 0000002DF1D4: D6550018 03FE6F27 00007FFF
	.long 0x7e3e39a0                                           // 0000002DF1E0: 7E3E39A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DF1E4: BF870224
	v_dot2_f32_bf16 v1, v25, v33, v1                           // 0000002DF1E8: CC1A4001 1C064319
	v_add3_u32 v25, v40, v57, 0x7fff                           // 0000002DF1F0: D6550019 03FE7328 00007FFF
	.long 0x7e5a3998                                           // 0000002DF1FC: 7E5A3998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DF200: BF870214
	v_and_or_b32 v23, 0xffff0000, v23, v31                     // 0000002DF204: D6570017 047E2EFF FFFF0000
	v_dot2_f32_bf16 v1, v26, v2, v1                            // 0000002DF210: CC1A4001 1C06051A
	v_add3_u32 v2, v41, v22, 0x7fff                            // 0000002DF218: D6550002 03FE2D29 00007FFF
	v_add3_u32 v22, v42, v58, 0x7fff                           // 0000002DF224: D6550016 03FE752A 00007FFF
	v_and_or_b32 v3, 0xffff0000, v3, v45                       // 0000002DF230: D6570003 04B606FF FFFF0000
	.long 0x7e3e3999                                           // 0000002DF23C: 7E3E3999
	s_waitcnt vmcnt(0)                                         // 0000002DF240: BF8903F7
	v_dot2_f32_bf16 v1, v27, v23, v1                           // 0000002DF244: CC1A4001 1C062F1B
	.long 0x7f2e399f                                           // 0000002DF24C: 7F2E399F
	.long 0x7e2e3996                                           // 0000002DF250: 7E2E3996
	v_mov_b32_e32 v22, v21                                     // 0000002DF254: 7E2C0315
	v_and_or_b32 v2, 0xffff0000, v2, v31                       // 0000002DF258: D6570002 047E04FF FFFF0000
	v_dot2_f32_bf16 v1, v28, v3, v1                            // 0000002DF264: CC1A4001 1C06071C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002DF26C: BF8701A4
	v_and_or_b32 v3, 0xffff0000, v4, v23                       // 0000002DF270: D6570003 045E08FF FFFF0000
	v_mov_b32_e32 v4, v8                                       // 0000002DF27C: 7E080308
	v_dot2_f32_bf16 v1, v29, v2, v1                            // 0000002DF280: CC1A4001 1C06051D
	v_mov_b32_e32 v2, v6                                       // 0000002DF288: 7E040306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DF28C: BF8701B2
	v_dot2_f32_bf16 v8, v30, v3, v1                            // 0000002DF290: CC1A4008 1C06071E
	v_mov_b32_e32 v3, v7                                       // 0000002DF298: 7E060307
	v_mov_b32_e32 v1, v5                                       // 0000002DF29C: 7E020305
	v_add_f32_e32 v15, v15, v8                                 // 0000002DF2A0: 061E110F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000002DF2A4: 917E047E
	s_cbranch_execz 30                                         // 0000002DF2A8: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x524>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000002DF2AC: BF8701C2
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v16, 32, v16    // 0000002DF2B0: CA200101 051020A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000002DF2B8: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000002DF2C0: 7E100304
	s_mov_b32 s5, exec_lo                                      // 0000002DF2C4: BE85007E
	v_cmp_ge_i32_e32 vcc_lo, v16, v17                          // 0000002DF2C8: 7C8C2310
	.long 0xd4c1007e                                           // 0000002DF2CC: D4C1007E
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 0000002DF2D0: 02022310
	s_cbranch_execz 65309                                      // 0000002DF2D4: BFA5FF1D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x14c>
	v_and_b32_e32 v7, -4, v16                                  // 0000002DF2D8: 360E20C4
	v_ashrrev_i32_e32 v6, 31, v20                              // 0000002DF2DC: 340C289F
	.long 0xd7000005                                           // 0000002DF2E0: D7000005
	v_cndmask_b32_e32 v1, v9, v20, vcc_lo                      // 0000002DF2E4: 02022909
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DF2E8: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 0000002DF2EC: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 0000002DF2F0: D5207C06 00020D0A
	.long 0xd7000017                                           // 0000002DF2F8: D7000017
	v_cndmask_b32_e32 v1, v18, v7, vcc_lo                      // 0000002DF2FC: 02020F12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DF300: BF870001
	v_add_co_ci_u32_e64 v24, null, v19, v8, s0                 // 0000002DF304: D5207C18 00021113
	s_clause 0x1                                               // 0000002DF30C: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 0000002DF310: DC5E0000 057C0005
	global_load_b32 v21, v[23:24], off                         // 0000002DF318: DC520000 157C0017
	s_branch 65290                                             // 0000002DF320: BFA0FF0A <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x14c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002DF324: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002DF328: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000002DF32C: 8C7E017E
	s_waitcnt vmcnt(1)                                         // 0000002DF330: BF8907F7
	.long 0xd71f0001                                           // 0000002DF334: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DF338: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002DF33C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000002DF340: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000002DF344: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000002DF348: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DF34C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002DF350: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002DF354: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000002DF358: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000002DF35C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DF360: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002DF364: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000002DF368: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002DF36C: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000002DF370: 02080901
	ds_bpermute_b32 v2, v2, v15                                // 0000002DF374: DACC0000 02000F02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DF37C: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000002DF380: BF89FC07
	v_add_f32_e32 v2, v15, v2                                  // 0000002DF384: 0604050F
	ds_bpermute_b32 v3, v3, v2                                 // 0000002DF388: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000002DF390: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000002DF394: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000002DF398: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000002DF3A0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DF3A4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DF3A8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000002DF3AC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DF3B0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000002DF3B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000002DF3B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000002DF3BC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000002DF3C4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002DF3C8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DF3CC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000002DF3D0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000002DF3D4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000002DF3DC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000002DF3E0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v14                                   // 0000002DF3E8: 7D941C80
	s_cbranch_execz 5                                          // 0000002DF3EC: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x604>
	s_waitcnt lgkmcnt(0)                                       // 0000002DF3F0: BF89FC07
	v_dual_add_f32 v1, v1, v2 :: v_dual_lshlrev_b32 v2, 2, v13 // 0000002DF3F4: C9220501 01021A82
	ds_store_b32 v2, v1                                        // 0000002DF3FC: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000002DF404: 8C7E007E
	.long 0xd4510000                                           // 0000002DF408: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000002DF40C: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002DF410: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000002DF414: BF890007
	s_barrier                                                  // 0000002DF418: BFBD0000
	buffer_gl0_inv                                             // 0000002DF41C: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000002DF424: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DF428: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002DF42C: BE812000
	s_cbranch_execz 30                                         // 0000002DF430: BFA5001E <_ZN7halogen12_GLOBAL__N_16k_lq8wILi1ELi32ELi8EEEvPKhPKtPtll+0x6ac>
	v_mov_b32_e32 v8, 0                                        // 0000002DF434: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000002DF438: 84808102
	ds_load_b128 v[0:3], v8                                    // 0000002DF43C: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 0000002DF444: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 0000002DF44C: 80000008
	s_addc_u32 s1, s9, s1                                      // 0000002DF450: 82010109
	s_waitcnt lgkmcnt(1)                                       // 0000002DF454: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 0000002DF458: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DF45C: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 0000002DF460: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 0000002DF464: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DF468: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 0000002DF46C: 06000700
	s_waitcnt lgkmcnt(0)                                       // 0000002DF470: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 0000002DF474: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DF478: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 0000002DF47C: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 0000002DF480: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DF484: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 0000002DF488: 06000F00
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002DF48C: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DF494: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000002DF498: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000002DF49C: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v8, v0, s[0:1]                     // 0000002DF4A4: DC960000 00000008
	s_endpgm                                                   // 0000002DF4AC: BFB00000
		...

