0000000000342f00 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000342F00: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000342F08: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000342F0C: 32020084
	s_lshl_b64 s[12:13], s[2:3], 4                             // 000000342F10: 848C8402
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000342F14: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 000000342F1C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 15, v0         // 000000342F20: CA240080 0610008F
	v_or_b32_e32 v8, s12, v1                                   // 000000342F28: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000342F2C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000342F34: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000342F3C: BF8704D3
	.long 0xd73c0001                                           // 000000342F40: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000342F44: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v44, 0             // 000000342F48: CA100080 0F2C0080
	v_mov_b32_e32 v18, 0                                       // 000000342F50: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 000000342F54: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000342F58: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 000000342F5C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000342F60: BF870009
	s_add_u32 s0, s10, s0                                      // 000000342F64: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000342F68: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 000000342F6C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000342F70: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000342F74: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000342F78: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 000000342F7C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000342F80: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000342F84: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000342F88: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 000000342F8C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000342F90: 86908200
	s_add_u32 s0, s10, s13                                     // 000000342F94: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000342F98: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 000000342F9C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000342FA0: 86808400
	s_add_u32 s13, s16, s14                                    // 000000342FA4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 000000342FA8: 82120F11
	s_add_u32 s0, s13, s0                                      // 000000342FAC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 000000342FB0: 82010112
	s_add_u32 s0, s0, 15                                       // 000000342FB4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000342FB8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 000000342FBC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 000000342FC0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000342FC4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 000000342FC8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000342FCC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 000000342FD0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 000000342FD4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000342FD8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000342FDC: BF870149
	.long 0xd72c0003                                           // 000000342FE0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000342FE4: 02000301
	.long 0xd72c0002                                           // 000000342FE8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000342FEC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 000000342FF0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 000000342FF8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 000000342FFC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 000000343000: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000343008: BE842000
	s_cbranch_execz 35                                         // 00000034300C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000343010: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000343014: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000343018: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034301C: BF870093
	.long 0xd7000101                                           // 000000343020: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000343024: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 000000343028: D5207C02 00062680
	.long 0xd7000103                                           // 000000343030: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000343034: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000343038: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000034303C: D5207C04 0006260F
	v_and_b32_e32 v0, 28, v0                                   // 000000343044: 3600009C
	.long 0xd7000106                                           // 000000343048: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000034304C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343050: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000343054: D5207C07 00060811
	.long 0xd700010b                                           // 00000034305C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000343060: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000343064: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034306C: BF870094
	.long 0xd700010d                                           // 000000343070: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000343074: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000343078: D5207C0E 00060E80
	s_clause 0x2                                               // 000000343080: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000343084: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000034308C: DC560000 0F7C000B
	global_load_b32 v44, v[13:14], off                         // 000000343094: DC520000 2C7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000034309C: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000003430A0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000003430A8: CA100080 16160080
	s_and_saveexec_b32 s13, s0                                 // 0000003430B0: BE8D2000
	s_cbranch_execz 954                                        // 0000003430B4: BFA503BA <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x10a0>
	.long 0xd7000018                                           // 0000003430B8: D7000018
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000003430BC: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003430C0: BF8701A1
	v_add_co_ci_u32_e64 v25, null, s15, v19, s0                // 0000003430C4: D5207C19 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 0000003430CC: CA220080 0C0A2285
	.long 0xd700001a                                           // 0000003430D4: D700001A
	v_cndmask_b32_e32 v0, v24, v16, vcc_lo                     // 0000003430D8: 02002118
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003430DC: BF870001
	v_add_co_ci_u32_e64 v27, null, s17, v25, s0                // 0000003430E0: D5207C1B 00023211
	v_lshl_or_b32 v28, v17, 4, 0x100                           // 0000003430E8: D656001C 03FD0911 00000100
	v_lshl_or_b32 v29, v17, 3, 0x80                            // 0000003430F4: D656001D 03FD0711 00000080
	v_lshl_or_b32 v30, v17, 1, 32                              // 000000343100: D656001E 02810311
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v31, v17         // 000000343108: CA10010C 121E0111
	v_mov_b32_e32 v20, v12                                     // 000000343110: 7E28030C
	v_mov_b32_e32 v21, v12                                     // 000000343114: 7E2A030C
	v_mov_b32_e32 v22, v12                                     // 000000343118: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 00000034311C: 7E2E030C
	s_waitcnt vmcnt(0)                                         // 000000343120: BF8903F7
	v_mov_b32_e32 v32, v44                                     // 000000343124: 7E40032C
	s_mul_i32 s0, s11, 6                                       // 000000343128: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 00000034312C: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000343130: 8484820A
	s_add_i32 s14, s1, s0                                      // 000000343134: 810E0001
	s_mul_i32 s16, s10, 6                                      // 000000343138: 9610860A
	s_mov_b32 s15, 0                                           // 00000034313C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000343140: 848A810A
	s_branch 879                                               // 000000343144: BFA0036F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x1004>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000343148: 8C7E117E
	v_lshlrev_b32_e32 v33, 4, v15                              // 00000034314C: 30421E84
	v_lshlrev_b32_e32 v35, 2, v15                              // 000000343150: 30461E82
	v_lshrrev_b32_e32 v34, 4, v4                               // 000000343154: 32440884
	v_lshrrev_b32_e32 v36, 2, v15                              // 000000343158: 32481E82
	.long 0x7f5a3880                                           // 00000034315C: 7F5A3880
	v_and_b32_e32 v33, 48, v33                                 // 000000343160: 364242B0
	v_and_b32_e32 v35, 48, v35                                 // 000000343164: 364646B0
	v_lshrrev_b32_e32 v38, 6, v15                              // 000000343168: 324C1E86
	v_and_b32_e32 v36, 48, v36                                 // 00000034316C: 364848B0
	v_lshrrev_b32_e32 v37, 20, v4                              // 000000343170: 324A0894
	v_and_or_b32 v33, v4, 15, v33                              // 000000343174: D6570021 04851F04
	v_and_or_b32 v34, v34, 15, v35                             // 00000034317C: D6570022 048D1F22
	v_and_b32_e32 v38, 48, v38                                 // 000000343184: 364C4CB0
	v_lshrrev_b32_e32 v40, 18, v15                             // 000000343188: 32501E92
	v_lshrrev_b32_e32 v41, 22, v15                             // 00000034318C: 32521E96
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000343190: 7E422321
	v_lshrrev_b32_e32 v43, 6, v16                              // 000000343194: 32562086
	v_and_or_b32 v37, v37, 15, v38                             // 000000343198: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 0000003431A0: 365050B0
	v_and_b32_e32 v41, 48, v41                                 // 0000003431A4: 365252B0
	v_fma_mix_f32 v33, v33, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003431A8: CC206021 14B25921
	v_lshrrev_b32_e32 v42, 20, v6                              // 0000003431B0: 32540C94
	v_and_b32_e32 v43, 48, v43                                 // 0000003431B4: 365656B0
	v_lshrrev_b32_e32 v47, 18, v16                             // 0000003431B8: 325E2092
	v_lshrrev_b32_e32 v48, 22, v16                             // 0000003431BC: 32602096
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003431C0: D6100023 02052121
	s_and_b32 s0, exec_lo, s0                                  // 0000003431C8: 8B00007E
	v_and_or_b32 v42, v42, 15, v43                             // 0000003431CC: D657002A 04AD1F2A
	v_and_b32_e32 v47, 48, v47                                 // 0000003431D4: 365E5EB0
	v_and_b32_e32 v48, 48, v48                                 // 0000003431D8: 366060B0
	v_add3_u32 v33, v33, v35, 0x7fff                           // 0000003431DC: D6550021 03FE4721 00007FFF
	v_and_b32_e32 v35, 48, v15                                 // 0000003431E8: 36461EB0
	s_or_b32 s15, s0, s15                                      // 0000003431EC: 8C0F0F00
	v_add_nc_u32_e32 v28, 0x100, v28                           // 0000003431F0: 4A3838FF 00000100
	v_add_nc_u32_e32 v29, 0x80, v29                            // 0000003431F8: 4A3A3AFF 00000080
	.long 0x7e5a39a1                                           // 000000343200: 7E5A39A1
	v_cvt_f32_ubyte0_e32 v33, v34                              // 000000343204: 7E422322
	v_add_nc_u32_e32 v30, 32, v30                              // 000000343208: 4A3C3CA0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034320C: BF870092
	v_fma_mix_f32 v33, v33, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343210: CC206021 14B25921
	v_bfe_u32 v34, v33, 16, 1                                  // 000000343218: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343220: BF870121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000343224: D6550021 03FE4521 00007FFF
	v_lshrrev_b32_e32 v34, 8, v4                               // 000000343230: 32440888
	v_and_or_b32 v33, 0xffff0000, v33, v45                     // 000000343234: D6570021 04B642FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343240: BF870122
	v_and_or_b32 v34, v34, 15, v35                             // 000000343244: D6570022 048D1F22
	v_lshrrev_b32_e32 v35, 12, v4                              // 00000034324C: 3246088C
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000343250: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343254: BF870112
	v_and_or_b32 v35, v35, 15, v36                             // 000000343258: D6570023 04911F23
	v_fma_mix_f32 v34, v34, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343260: CC206022 14B25922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343268: BF870091
	v_bfe_u32 v36, v34, 16, 1                                  // 00000034326C: D6100024 02052122
	v_add3_u32 v34, v34, v36, 0x7fff                           // 000000343274: D6550022 03FE4922 00007FFF
	v_lshrrev_b32_e32 v36, 8, v15                              // 000000343280: 32481E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000343284: BF8701A2
	.long 0x7e5a39a2                                           // 000000343288: 7E5A39A2
	v_cvt_f32_ubyte0_e32 v34, v35                              // 00000034328C: 7E442323
	v_and_b32_e32 v36, 48, v36                                 // 000000343290: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343294: BF870092
	v_fma_mix_f32 v34, v34, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343298: CC206022 14B25922
	v_bfe_u32 v35, v34, 16, 1                                  // 0000003432A0: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003432A8: BF870121
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000003432AC: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 4, v15                              // 0000003432B8: 32461E84
	v_and_or_b32 v34, 0xffff0000, v34, v45                     // 0000003432BC: D6570022 04B644FF FFFF0000
	.long 0x7e5a3984                                           // 0000003432C8: 7E5A3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003432CC: BF870093
	v_and_b32_e32 v35, 48, v35                                 // 0000003432D0: 364646B0
	v_and_or_b32 v35, v45, 15, v35                             // 0000003432D4: D6570023 048D1F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003432DC: BF870091
	v_cvt_f32_ubyte0_e32 v35, v35                              // 0000003432E0: 7E462323
	v_fma_mix_f32 v35, v35, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003432E4: CC206023 14B25923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003432EC: BF870091
	v_bfe_u32 v38, v35, 16, 1                                  // 0000003432F0: D6100026 02052123
	v_add3_u32 v35, v35, v38, 0x7fff                           // 0000003432F8: D6550023 03FE4D23 00007FFF
	v_lshrrev_b32_e32 v38, 12, v15                             // 000000343304: 324C1E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343308: BF8700A2
	.long 0x7e5a39a3                                           // 00000034330C: 7E5A39A3
	v_cvt_f32_ubyte0_e32 v35, v37                              // 000000343310: 7E462325
	v_fma_mix_f32 v35, v35, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343314: CC206023 14B25923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034331C: BF870091
	v_bfe_u32 v37, v35, 16, 1                                  // 000000343320: D6100025 02052123
	v_add3_u32 v35, v35, v37, 0x7fff                           // 000000343328: D6550023 03FE4B23 00007FFF
	v_lshrrev_b32_e32 v37, 24, v4                              // 000000343334: 324A0898
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000343338: 3208089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034333C: BF870193
	v_and_or_b32 v35, 0xffff0000, v35, v45                     // 000000343340: D6570023 04B646FF FFFF0000
	v_and_or_b32 v36, v37, 15, v36                             // 00000034334C: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v15                             // 000000343354: 324A1E8A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343358: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034335C: 7E482324
	v_and_or_b32 v4, v37, 48, v4                               // 000000343360: D6570004 04116125
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343368: BF870112
	v_fma_mix_f32 v36, v36, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034336C: CC206024 14B25924
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000343374: 7E082304
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343378: BF870112
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034337C: D6100025 02052124
	v_fma_mix_f32 v4, v4, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343384: CC206004 14B25904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034338C: BF870122
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000343390: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v5                               // 00000034339C: 324A0A84
	.long 0x7e5a39a4                                           // 0000003433A0: 7E5A39A4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003433A4: BF870094
	v_bfe_u32 v36, v4, 16, 1                                   // 0000003433A8: D6100024 02052104
	v_add3_u32 v4, v4, v36, 0x7fff                             // 0000003433B0: D6550004 03FE4904 00007FFF
	v_and_b32_e32 v36, 48, v38                                 // 0000003433BC: 36484CB0
	v_lshrrev_b32_e32 v38, 14, v15                             // 0000003433C0: 324C1E8E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003433C4: BF870193
	v_and_or_b32 v4, 0xffff0000, v4, v45                       // 0000003433C8: D6570004 04B608FF FFFF0000
	v_and_or_b32 v36, v5, 15, v36                              // 0000003433D4: D6570024 04911F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003433DC: BF8701A3
	v_and_b32_e32 v38, 48, v38                                 // 0000003433E0: 364C4CB0
	.long 0x7e5a398f                                           // 0000003433E4: 7E5A398F
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000003433E8: 7E482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003433EC: BF870193
	v_and_or_b32 v37, v37, 15, v38                             // 0000003433F0: D6570025 04991F25
	v_and_b32_e32 v39, 48, v45                                 // 0000003433F8: 364E5AB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003433FC: BF870193
	v_fma_mix_f32 v36, v36, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343400: CC206024 14B25924
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000343408: 7E4A2325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034340C: BF870112
	v_bfe_u32 v38, v36, 16, 1                                  // 000000343410: D6100026 02052124
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343418: CC206025 14B25925
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343420: BF870112
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000343424: D6550024 03FE4D24 00007FFF
	v_bfe_u32 v38, v37, 16, 1                                  // 000000343430: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000343438: BF8701A2
	.long 0x7e4839a4                                           // 00000034343C: 7E4839A4
	.long 0x7f4839ad                                           // 000000343440: 7F4839AD
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000343444: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 20, v15                             // 000000343450: 324C1E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000343454: BF8701A2
	v_and_or_b32 v36, 0xffff0000, v37, v36                     // 000000343458: D6570024 04924AFF FFFF0000
	v_lshrrev_b32_e32 v37, 8, v5                               // 000000343464: 324A0A88
	v_and_b32_e32 v38, 48, v38                                 // 000000343468: 364C4CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034346C: BF870122
	v_and_or_b32 v37, v37, 15, v39                             // 000000343470: D6570025 049D1F25
	v_lshrrev_b32_e32 v39, 12, v5                              // 000000343478: 324E0A8C
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034347C: 7E4A2325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343480: BF870112
	v_and_or_b32 v39, v39, 15, v40                             // 000000343484: D6570027 04A11F27
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034348C: CC206025 14B25925
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343494: BF870091
	v_bfe_u32 v40, v37, 16, 1                                  // 000000343498: D6100028 02052125
	v_add3_u32 v37, v37, v40, 0x7fff                           // 0000003434A0: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 20, v5                              // 0000003434AC: 32500A94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003434B0: BF8701A2
	.long 0x7e5a39a5                                           // 0000003434B4: 7E5A39A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 0000003434B8: 7E4A2327
	v_and_or_b32 v40, v40, 15, v41                             // 0000003434BC: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003434C4: BF870092
	v_fma_mix_f32 v37, v37, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003434C8: CC206025 14B25925
	v_bfe_u32 v39, v37, 16, 1                                  // 0000003434D0: D6100027 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003434D8: BF8701B1
	v_add3_u32 v37, v37, v39, 0x7fff                           // 0000003434DC: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v15                             // 0000003434E8: 324E1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 0000003434EC: 321E1E9A
	v_and_or_b32 v37, 0xffff0000, v37, v45                     // 0000003434F0: D6570025 04B64AFF FFFF0000
	.long 0x7e5a3985                                           // 0000003434FC: 7E5A3985
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343500: BF870114
	v_and_b32_e32 v39, 48, v39                                 // 000000343504: 364E4EB0
	v_and_or_b32 v38, v45, 15, v38                             // 000000343508: D6570026 04991F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343510: BF870091
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000343514: 7E4C2326
	v_fma_mix_f32 v38, v38, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343518: CC206026 14B25926
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343520: BF870091
	v_bfe_u32 v41, v38, 16, 1                                  // 000000343524: D6100029 02052126
	v_add3_u32 v38, v38, v41, 0x7fff                           // 00000034352C: D6550026 03FE5326 00007FFF
	v_lshrrev_b32_e32 v41, 2, v16                              // 000000343538: 32522082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034353C: BF8701A2
	.long 0x7e5a39a6                                           // 000000343540: 7E5A39A6
	v_cvt_f32_ubyte0_e32 v38, v40                              // 000000343544: 7E4C2328
	v_and_b32_e32 v41, 48, v41                                 // 000000343548: 365252B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034354C: BF870092
	v_fma_mix_f32 v38, v38, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343550: CC206026 14B25926
	v_bfe_u32 v40, v38, 16, 1                                  // 000000343558: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000343560: BF8701B1
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000343564: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 24, v5                              // 000000343570: 32500A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000343574: 320A0A9C
	v_and_or_b32 v38, 0xffff0000, v38, v45                     // 000000343578: D6570026 04B64CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000343584: BF870193
	v_and_or_b32 v39, v40, 15, v39                             // 000000343588: D6570027 049D1F28
	v_and_or_b32 v5, v15, 48, v5                               // 000000343590: D6570005 0415610F
	v_lshlrev_b32_e32 v40, 2, v16                              // 000000343598: 30502082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034359C: BF870193
	v_cvt_f32_ubyte0_e32 v15, v39                              // 0000003435A0: 7E1E2327
	v_cvt_f32_ubyte0_e32 v5, v5                                // 0000003435A4: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003435A8: BF870193
	v_and_b32_e32 v40, 48, v40                                 // 0000003435AC: 365050B0
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003435B0: CC20600F 14B2590F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003435B8: BF870113
	v_fma_mix_f32 v5, v5, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003435BC: CC206005 14B25905
	v_bfe_u32 v39, v15, 16, 1                                  // 0000003435C4: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003435CC: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 0000003435D0: D655000F 03FE4F0F 00007FFF
	v_lshrrev_b32_e32 v39, 4, v6                               // 0000003435DC: 324E0C84
	.long 0x7e5a398f                                           // 0000003435E0: 7E5A398F
	v_bfe_u32 v15, v5, 16, 1                                   // 0000003435E4: D610000F 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003435EC: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 0000003435F0: D6570027 04A11F27
	v_add3_u32 v5, v5, v15, 0x7fff                             // 0000003435F8: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000343604: 301E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343608: BF870112
	v_and_or_b32 v5, 0xffff0000, v5, v45                       // 00000034360C: D6570005 04B60AFF FFFF0000
	v_and_b32_e32 v15, 48, v15                                 // 000000343618: 361E1EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034361C: BF870091
	v_and_or_b32 v15, v6, 15, v15                              // 000000343620: D657000F 043D1F06
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000343628: 7E1E230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034362C: BF870091
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343630: CC20600F 14B2590F
	v_bfe_u32 v40, v15, 16, 1                                  // 000000343638: D6100028 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343640: BF870121
	v_add3_u32 v15, v15, v40, 0x7fff                           // 000000343644: D655000F 03FE510F 00007FFF
	v_and_b32_e32 v40, 48, v16                                 // 000000343650: 365020B0
	.long 0x7e5a398f                                           // 000000343654: 7E5A398F
	v_cvt_f32_ubyte0_e32 v15, v39                              // 000000343658: 7E1E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034365C: BF870091
	v_fma_mix_f32 v15, v15, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343660: CC20600F 14B2590F
	v_bfe_u32 v39, v15, 16, 1                                  // 000000343668: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343670: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000343674: D655000F 03FE4F0F 00007FFF
	v_lshrrev_b32_e32 v39, 8, v6                               // 000000343680: 324E0C88
	v_and_or_b32 v15, 0xffff0000, v15, v45                     // 000000343684: D657000F 04B61EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343690: BF870122
	v_and_or_b32 v39, v39, 15, v40                             // 000000343694: D6570027 04A11F27
	v_lshrrev_b32_e32 v40, 12, v6                              // 00000034369C: 32500C8C
	v_cvt_f32_ubyte0_e32 v39, v39                              // 0000003436A0: 7E4E2327
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003436A4: BF870112
	v_and_or_b32 v40, v40, 15, v41                             // 0000003436A8: D6570028 04A51F28
	v_fma_mix_f32 v39, v39, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003436B0: CC206027 14B25927
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003436B8: BF870091
	v_bfe_u32 v41, v39, 16, 1                                  // 0000003436BC: D6100029 02052127
	v_add3_u32 v39, v39, v41, 0x7fff                           // 0000003436C4: D6550027 03FE5327 00007FFF
	v_lshrrev_b32_e32 v41, 8, v16                              // 0000003436D0: 32522088
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003436D4: BF8701A2
	.long 0x7e5a39a7                                           // 0000003436D8: 7E5A39A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 0000003436DC: 7E4E2328
	v_and_b32_e32 v41, 48, v41                                 // 0000003436E0: 365252B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003436E4: BF870092
	v_fma_mix_f32 v39, v39, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003436E8: CC206027 14B25927
	v_bfe_u32 v40, v39, 16, 1                                  // 0000003436F0: D6100028 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003436F8: BF870121
	v_add3_u32 v39, v39, v40, 0x7fff                           // 0000003436FC: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 4, v16                              // 000000343708: 32502084
	v_and_or_b32 v39, 0xffff0000, v39, v45                     // 00000034370C: D6570027 04B64EFF FFFF0000
	.long 0x7e5a3986                                           // 000000343718: 7E5A3986
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034371C: BF870093
	v_and_b32_e32 v40, 48, v40                                 // 000000343720: 365050B0
	v_and_or_b32 v40, v45, 15, v40                             // 000000343724: D6570028 04A11F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034372C: BF870091
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000343730: 7E502328
	v_fma_mix_f32 v40, v40, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343734: CC206028 14B25928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034373C: BF870091
	v_bfe_u32 v43, v40, 16, 1                                  // 000000343740: D610002B 02052128
	v_add3_u32 v40, v40, v43, 0x7fff                           // 000000343748: D6550028 03FE5728 00007FFF
	v_lshrrev_b32_e32 v43, 12, v16                             // 000000343754: 3256208C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343758: BF8700A2
	.long 0x7e5a39a8                                           // 00000034375C: 7E5A39A8
	v_cvt_f32_ubyte0_e32 v40, v42                              // 000000343760: 7E50232A
	v_fma_mix_f32 v40, v40, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343764: CC206028 14B25928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034376C: BF870091
	v_bfe_u32 v42, v40, 16, 1                                  // 000000343770: D610002A 02052128
	v_add3_u32 v40, v40, v42, 0x7fff                           // 000000343778: D6550028 03FE5528 00007FFF
	v_lshrrev_b32_e32 v42, 24, v6                              // 000000343784: 32540C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000343788: 320C0C9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034378C: BF870193
	v_and_or_b32 v40, 0xffff0000, v40, v45                     // 000000343790: D6570028 04B650FF FFFF0000
	v_and_or_b32 v41, v42, 15, v41                             // 00000034379C: D6570029 04A51F2A
	v_lshrrev_b32_e32 v42, 10, v16                             // 0000003437A4: 3254208A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003437A8: BF870112
	v_cvt_f32_ubyte0_e32 v41, v41                              // 0000003437AC: 7E522329
	v_and_or_b32 v6, v42, 48, v6                               // 0000003437B0: D6570006 0419612A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003437B8: BF870112
	v_fma_mix_f32 v41, v41, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003437BC: CC206029 14B25929
	v_cvt_f32_ubyte0_e32 v6, v6                                // 0000003437C4: 7E0C2306
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003437C8: BF870112
	v_bfe_u32 v42, v41, 16, 1                                  // 0000003437CC: D610002A 02052129
	v_fma_mix_f32 v6, v6, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003437D4: CC206006 14B25906
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003437DC: BF870122
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000003437E0: D6550029 03FE5529 00007FFF
	v_lshrrev_b32_e32 v42, 4, v7                               // 0000003437EC: 32540E84
	.long 0x7e5a39a9                                           // 0000003437F0: 7E5A39A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003437F4: BF870094
	v_bfe_u32 v41, v6, 16, 1                                   // 0000003437F8: D6100029 02052106
	v_add3_u32 v6, v6, v41, 0x7fff                             // 000000343800: D6550006 03FE5306 00007FFF
	v_and_b32_e32 v41, 15, v7                                  // 00000034380C: 36520E8F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343810: BF870112
	v_and_or_b32 v6, 0xffff0000, v6, v45                       // 000000343814: D6570006 04B60CFF FFFF0000
	v_and_or_b32 v41, v43, 48, v41                             // 000000343820: D6570029 04A5612B
	v_lshrrev_b32_e32 v43, 14, v16                             // 000000343828: 3256208E
	.long 0x7e5a3990                                           // 00000034382C: 7E5A3990
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000343830: BF870193
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000343834: 7E522329
	v_and_b32_e32 v43, 48, v43                                 // 000000343838: 365656B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034383C: BF870193
	v_and_b32_e32 v46, 48, v45                                 // 000000343840: 365C5AB0
	v_fma_mix_f32 v41, v41, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343844: CC206029 14B25929
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034384C: BF870113
	v_and_or_b32 v42, v42, 15, v43                             // 000000343850: D657002A 04AD1F2A
	v_bfe_u32 v43, v41, 16, 1                                  // 000000343858: D610002B 02052129
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343860: BF870112
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000343864: 7E54232A
	v_add3_u32 v41, v41, v43, 0x7fff                           // 000000343868: D6550029 03FE5729 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343874: BF870112
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343878: CC20602A 14B2592A
	.long 0x7e5239a9                                           // 000000343880: 7E5239A9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343884: BF870122
	v_bfe_u32 v43, v42, 16, 1                                  // 000000343888: D610002B 0205212A
	.long 0x7f5239ad                                           // 000000343890: 7F5239AD
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000343894: D655002A 03FE572A 00007FFF
	v_lshrrev_b32_e32 v43, 20, v16                             // 0000003438A0: 32562094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003438A4: BF8701A2
	v_and_or_b32 v41, 0xffff0000, v42, v41                     // 0000003438A8: D6570029 04A654FF FFFF0000
	v_lshrrev_b32_e32 v42, 8, v7                               // 0000003438B4: 32540E88
	v_and_b32_e32 v43, 48, v43                                 // 0000003438B8: 365656B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003438BC: BF870122
	v_and_or_b32 v42, v42, 15, v46                             // 0000003438C0: D657002A 04B91F2A
	v_lshrrev_b32_e32 v46, 12, v7                              // 0000003438C8: 325C0E8C
	v_cvt_f32_ubyte0_e32 v42, v42                              // 0000003438CC: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003438D0: BF870112
	v_and_or_b32 v46, v46, 15, v47                             // 0000003438D4: D657002E 04BD1F2E
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003438DC: CC20602A 14B2592A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003438E4: BF870091
	v_bfe_u32 v47, v42, 16, 1                                  // 0000003438E8: D610002F 0205212A
	v_add3_u32 v42, v42, v47, 0x7fff                           // 0000003438F0: D655002A 03FE5F2A 00007FFF
	v_lshrrev_b32_e32 v47, 20, v7                              // 0000003438FC: 325E0E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000343900: BF8701A2
	.long 0x7e5a39aa                                           // 000000343904: 7E5A39AA
	v_cvt_f32_ubyte0_e32 v42, v46                              // 000000343908: 7E54232E
	v_and_or_b32 v47, v47, 15, v48                             // 00000034390C: D657002F 04C11F2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343914: BF870092
	v_fma_mix_f32 v42, v42, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343918: CC20602A 14B2592A
	v_bfe_u32 v46, v42, 16, 1                                  // 000000343920: D610002E 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000343928: BF8701B1
	v_add3_u32 v42, v42, v46, 0x7fff                           // 00000034392C: D655002A 03FE5D2A 00007FFF
	v_lshrrev_b32_e32 v46, 24, v16                             // 000000343938: 325C2098
	v_lshrrev_b32_e32 v16, 26, v16                             // 00000034393C: 3220209A
	v_and_or_b32 v42, 0xffff0000, v42, v45                     // 000000343940: D657002A 04B654FF FFFF0000
	.long 0x7e5a3987                                           // 00000034394C: 7E5A3987
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343950: BF870114
	v_and_b32_e32 v46, 48, v46                                 // 000000343954: 365C5CB0
	v_and_or_b32 v43, v45, 15, v43                             // 000000343958: D657002B 04AD1F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343960: BF870091
	v_cvt_f32_ubyte0_e32 v43, v43                              // 000000343964: 7E56232B
	v_fma_mix_f32 v43, v43, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343968: CC20602B 14B2592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343970: BF870091
	v_bfe_u32 v48, v43, 16, 1                                  // 000000343974: D6100030 0205212B
	v_add3_u32 v43, v43, v48, 0x7fff                           // 00000034397C: D655002B 03FE612B 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343988: BF8700A1
	.long 0x7e5a39ab                                           // 00000034398C: 7E5A39AB
	v_cvt_f32_ubyte0_e32 v43, v47                              // 000000343990: 7E56232F
	v_fma_mix_f32 v43, v43, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000343994: CC20602B 14B2592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034399C: BF870091
	v_bfe_u32 v47, v43, 16, 1                                  // 0000003439A0: D610002F 0205212B
	v_add3_u32 v43, v43, v47, 0x7fff                           // 0000003439A8: D655002B 03FE5F2B 00007FFF
	v_lshrrev_b32_e32 v47, 24, v7                              // 0000003439B4: 325E0E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 0000003439B8: 320E0E9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003439BC: BF870193
	v_and_or_b32 v43, 0xffff0000, v43, v45                     // 0000003439C0: D657002B 04B656FF FFFF0000
	v_and_or_b32 v46, v47, 15, v46                             // 0000003439CC: D657002E 04B91F2F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003439D4: BF870113
	v_and_or_b32 v7, v16, 48, v7                               // 0000003439D8: D6570007 041D6110
	v_cvt_f32_ubyte0_e32 v16, v46                              // 0000003439E0: 7E20232E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003439E4: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 0000003439E8: 7E0E2307
	v_fma_mix_f32 v16, v16, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003439EC: CC206010 14B25910
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003439F4: BF870112
	v_fma_mix_f32 v7, v7, v44, v44 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003439F8: CC206007 14B25907
	v_bfe_u32 v46, v16, 16, 1                                  // 000000343A00: D610002E 02052110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343A08: BF870091
	v_add3_u32 v16, v16, v46, 0x7fff                           // 000000343A0C: D6550010 03FE5D10 00007FFF
	.long 0x7e5a3990                                           // 000000343A18: 7E5A3990
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343A1C: BF870094
	v_bfe_u32 v16, v7, 16, 1                                   // 000000343A20: D6100010 02052107
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000343A28: D6550007 03FE2107 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000343A34: BF870131
	v_and_or_b32 v7, 0xffff0000, v7, v45                       // 000000343A38: D6570007 04B60EFF FFFF0000
	.long 0xd73c002c                                           // 000000343A44: D73C002C
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000343A48: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000343A4C: 4A1616FF 00000200
	.long 0xd700003c                                           // 000000343A54: D700003C
	v_cndmask_b32_e32 v1, s6, v44, vcc_lo                      // 000000343A58: 02025806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000343A5C: BF870001
	v_add_co_ci_u32_e64 v61, null, s7, v45, s0                 // 000000343A60: D5207C3D 00025A07
	s_clause 0x3                                               // 000000343A68: BF850003
	global_load_b128 v[44:47], v[60:61], off                   // 000000343A6C: DC5E0000 2C7C003C
	global_load_b128 v[48:51], v[60:61], off offset:16         // 000000343A74: DC5E0010 307C003C
	global_load_b128 v[52:55], v[60:61], off offset:32         // 000000343A7C: DC5E0020 347C003C
	global_load_b128 v[56:59], v[60:61], off offset:48         // 000000343A84: DC5E0030 387C003C
	s_waitcnt vmcnt(3)                                         // 000000343A8C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000343A90: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343A98: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000343A9C: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000343AA4: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343AAC: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000343AB0: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000343AB8: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000343ABC: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343AC4: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000343AC8: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000343AD0: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343AD8: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000343ADC: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000343AE4: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000343AE8: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343AF0: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000343AF4: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000343AFC: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343B04: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000343B08: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000343B10: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 000000343B14: CC1A4010 1C425338
	.long 0xd7000038                                           // 000000343B1C: D7000038
	v_cndmask_b32_e32 v0, v60, v10, vcc_lo                     // 000000343B20: 0200153C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000343B24: BF8701B2
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000343B28: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s11, v61, s0                // 000000343B30: D5207C39 00027A0B
	.long 0xd700003e                                           // 000000343B38: D700003E
	v_cndmask_b32_e32 v0, v60, v4, vcc_lo                      // 000000343B3C: 0200093C
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000343B40: CC1A4010 1C42573A
	v_add_co_ci_u32_e64 v63, null, s5, v61, s0                 // 000000343B48: D5207C3F 00027A05
	s_delay_alu instid0(VALU_DEP_2)                            // 000000343B50: BF870002
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000343B54: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000343B5C: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000343B60: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000343B68: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000343B70: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000343B78: DC5E0030 387C0038
	v_add_f32_e32 v23, v23, v16                                // 000000343B80: 062E2117
	s_waitcnt vmcnt(3)                                         // 000000343B84: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000343B88: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343B90: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000343B94: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000343B9C: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343BA4: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000343BA8: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000343BB0: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000343BB4: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343BBC: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000343BC0: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000343BC8: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343BD0: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000343BD4: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000343BDC: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000343BE0: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343BE8: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000343BEC: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000343BF4: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343BFC: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000343C00: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000343C08: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 000000343C0C: CC1A4010 1C425338
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343C14: BF870091
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000343C18: CC1A4010 1C425539
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000343C20: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000343C28: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000343C2C: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000343C34: BF850003
	global_load_b128 v[44:47], v[62:63], off                   // 000000343C38: DC5E0000 2C7C003E
	global_load_b128 v[48:51], v[62:63], off offset:16         // 000000343C40: DC5E0010 307C003E
	global_load_b128 v[52:55], v[62:63], off offset:32         // 000000343C48: DC5E0020 347C003E
	global_load_b128 v[56:59], v[62:63], off offset:48         // 000000343C50: DC5E0030 387C003E
	v_add_f32_e32 v22, v22, v16                                // 000000343C58: 062C2116
	s_waitcnt vmcnt(3)                                         // 000000343C5C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000343C60: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343C68: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000343C6C: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000343C74: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343C7C: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000343C80: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000343C88: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000343C8C: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343C94: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000343C98: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000343CA0: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343CA8: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000343CAC: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000343CB4: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000343CB8: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343CC0: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000343CC4: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000343CCC: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343CD4: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000343CD8: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000343CE0: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 000000343CE4: CC1A4010 1C425338
	.long 0xd7000038                                           // 000000343CEC: D7000038
	v_cndmask_b32_e32 v0, v60, v16, vcc_lo                     // 000000343CF0: 0200213C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343CF4: BF870122
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000343CF8: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s14, v61, s0                // 000000343D00: D5207C39 00027A0E
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000343D08: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000343D10: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000343D14: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000343D1C: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000343D20: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000343D28: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000343D30: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000343D38: DC5E0030 387C0038
	v_add_f32_e32 v21, v21, v16                                // 000000343D40: 062A2115
	s_waitcnt vmcnt(3)                                         // 000000343D44: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000343D48: CC1A4010 1A02432C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343D50: BF870091
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000343D54: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000343D5C: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343D64: BF8700A1
	v_dot2_f32_bf16 v16, v47, v4, v16                          // 000000343D68: CC1A4010 1C42092F
	s_waitcnt vmcnt(2)                                         // 000000343D70: BF890BF7
	v_dot2_f32_bf16 v16, v48, v36, v16                         // 000000343D74: CC1A4010 1C424930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343D7C: BF870091
	v_dot2_f32_bf16 v16, v49, v37, v16                         // 000000343D80: CC1A4010 1C424B31
	v_dot2_f32_bf16 v16, v50, v38, v16                         // 000000343D88: CC1A4010 1C424D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343D90: BF8700A1
	v_dot2_f32_bf16 v16, v51, v5, v16                          // 000000343D94: CC1A4010 1C420B33
	s_waitcnt vmcnt(1)                                         // 000000343D9C: BF8907F7
	v_dot2_f32_bf16 v16, v52, v15, v16                         // 000000343DA0: CC1A4010 1C421F34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343DA8: BF870091
	v_dot2_f32_bf16 v16, v53, v39, v16                         // 000000343DAC: CC1A4010 1C424F35
	v_dot2_f32_bf16 v16, v54, v40, v16                         // 000000343DB4: CC1A4010 1C425136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343DBC: BF8700A1
	v_dot2_f32_bf16 v16, v55, v6, v16                          // 000000343DC0: CC1A4010 1C420D37
	s_waitcnt vmcnt(0)                                         // 000000343DC8: BF8903F7
	v_dot2_f32_bf16 v16, v56, v41, v16                         // 000000343DCC: CC1A4010 1C425338
	.long 0xd7000038                                           // 000000343DD4: D7000038
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 000000343DD8: 0200093E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000343DDC: BF870122
	v_dot2_f32_bf16 v16, v57, v42, v16                         // 000000343DE0: CC1A4010 1C425539
	v_add_co_ci_u32_e64 v57, null, s5, v63, s0                 // 000000343DE8: D5207C39 00027E05
	v_dot2_f32_bf16 v16, v58, v43, v16                         // 000000343DF0: CC1A4010 1C42573A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000343DF8: BF870001
	v_dot2_f32_bf16 v16, v59, v7, v16                          // 000000343DFC: CC1A4010 1C420F3B
	s_clause 0x3                                               // 000000343E04: BF850003
	global_load_b128 v[44:47], v[56:57], off                   // 000000343E08: DC5E0000 2C7C0038
	global_load_b128 v[48:51], v[56:57], off offset:16         // 000000343E10: DC5E0010 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:32         // 000000343E18: DC5E0020 347C0038
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000343E20: DC5E0030 387C0038
	v_add_f32_e32 v20, v20, v16                                // 000000343E28: 06282114
	s_waitcnt vmcnt(3)                                         // 000000343E2C: BF890FF7
	v_dot2_f32_bf16 v16, v44, v33, 0                           // 000000343E30: CC1A4010 1A02432C
	v_mov_b32_e32 v44, v32                                     // 000000343E38: 7E580320
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343E3C: BF870092
	v_dot2_f32_bf16 v16, v45, v34, v16                         // 000000343E40: CC1A4010 1C42452D
	v_dot2_f32_bf16 v16, v46, v35, v16                         // 000000343E48: CC1A4010 1C42472E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000343E50: BF870131
	v_dot2_f32_bf16 v4, v47, v4, v16                           // 000000343E54: CC1A4004 1C42092F
	v_mov_b32_e32 v16, v14                                     // 000000343E5C: 7E20030E
	s_waitcnt vmcnt(2)                                         // 000000343E60: BF890BF7
	v_dot2_f32_bf16 v4, v48, v36, v4                           // 000000343E64: CC1A4004 1C124930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343E6C: BF870091
	v_dot2_f32_bf16 v4, v49, v37, v4                           // 000000343E70: CC1A4004 1C124B31
	v_dot2_f32_bf16 v4, v50, v38, v4                           // 000000343E78: CC1A4004 1C124D32
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000343E80: BF870131
	v_dot2_f32_bf16 v4, v51, v5, v4                            // 000000343E84: CC1A4004 1C120B33
	v_mov_b32_e32 v5, v1                                       // 000000343E8C: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 000000343E90: BF8907F7
	v_dot2_f32_bf16 v4, v52, v15, v4                           // 000000343E94: CC1A4004 1C121F34
	v_mov_b32_e32 v15, v13                                     // 000000343E9C: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343EA0: BF870092
	v_dot2_f32_bf16 v4, v53, v39, v4                           // 000000343EA4: CC1A4004 1C124F35
	v_dot2_f32_bf16 v4, v54, v40, v4                           // 000000343EAC: CC1A4004 1C125136
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000343EB4: BF870131
	v_dot2_f32_bf16 v4, v55, v6, v4                            // 000000343EB8: CC1A4004 1C120D37
	v_mov_b32_e32 v6, v2                                       // 000000343EC0: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 000000343EC4: BF8903F7
	v_dot2_f32_bf16 v4, v56, v41, v4                           // 000000343EC8: CC1A4004 1C125338
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343ED0: BF870091
	v_dot2_f32_bf16 v4, v57, v42, v4                           // 000000343ED4: CC1A4004 1C125539
	v_dot2_f32_bf16 v4, v58, v43, v4                           // 000000343EDC: CC1A4004 1C12573A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343EE4: BF870091
	v_dot2_f32_bf16 v4, v59, v7, v4                            // 000000343EE8: CC1A4004 1C120F3B
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 000000343EF0: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 000000343EF8: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000343EFC: 917E0F7E
	s_cbranch_execz 38                                         // 000000343F00: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x109c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000343F04: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v31, 16, v31    // 000000343F08: CA200104 001E3E90
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 000000343F10: CA100105 01020106
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v14, v16           // 000000343F18: CA100107 030E0110
	.long 0xd4430000                                           // 000000343F20: D4430000
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000343F24: 02023E0C
	v_mov_b32_e32 v13, v15                                     // 000000343F28: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 000000343F2C: BE91007E
	.long 0xd4c4007e                                           // 000000343F30: D4C4007E
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 000000343F34: 02023E0C
	s_cbranch_execz 64643                                      // 000000343F38: BFA5FC83 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x248>
	v_and_b32_e32 v2, 0x7ffffffc, v30                          // 000000343F3C: 36043CFF 7FFFFFFC
	.long 0xd7000100                                           // 000000343F44: D7000100
	v_cndmask_b32_e32 v1, v10, v28, vcc_lo                     // 000000343F48: 0202390A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343F4C: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000343F50: D5207C01 00062680
	.long 0xd700010d                                           // 000000343F58: D700010D
	v_cndmask_b32_e32 v1, v24, v29, vcc_lo                     // 000000343F5C: 02023B18
	v_add_co_ci_u32_e64 v14, null, 0, v25, s1                  // 000000343F60: D5207C0E 00063280
	.long 0xd7000120                                           // 000000343F68: D7000120
	v_cndmask_b32_e32 v1, v26, v2, vcc_lo                      // 000000343F6C: 0202051A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000343F70: BF870001
	v_add_co_ci_u32_e64 v33, null, 0, v27, s1                  // 000000343F74: D5207C21 00063680
	s_clause 0x2                                               // 000000343F7C: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 000000343F80: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 000000343F88: DC560000 0D7C000D
	global_load_b32 v32, v[32:33], off                         // 000000343F90: DC520000 207C0020
	s_branch 64619                                             // 000000343F98: BFA0FC6B <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000343F9C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000343FA0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 000000343FA4: 8C7E0D7E
	.long 0xd71f0000                                           // 000000343FA8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000343FAC: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000343FB0: 3A020088
	s_waitcnt vmcnt(2)                                         // 000000343FB4: BF890BF7
	v_xor_b32_e32 v6, 4, v0                                    // 000000343FB8: 3A0C0084
	v_xor_b32_e32 v13, 2, v0                                   // 000000343FBC: 3A1A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000343FC0: BF870093
	.long 0xd44c0000                                           // 000000343FC4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000343FC8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000343FCC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000343FD4: BF870114
	.long 0xd44c0000                                           // 000000343FD8: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 000000343FDC: 02020CA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000343FE0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000343FE4: BF870002
	v_cndmask_b32_e64 v6, v0, v6, s0                           // 000000343FE8: D5010006 00020D00
	.long 0xd44c0000                                           // 000000343FF0: D44C0000
	v_cndmask_b32_e32 v1, 32, v13, vcc_lo                      // 000000343FF4: 02021AA0
	ds_bpermute_b32 v2, v1, v23                                // 000000343FF8: DACC0000 02001701
	v_cndmask_b32_e64 v13, v0, v13, s0                         // 000000344000: D501000D 00021B00
	s_waitcnt lgkmcnt(0)                                       // 000000344008: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 00000034400C: 06040517
	ds_bpermute_b32 v4, v1, v21                                // 000000344010: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 000000344018: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 000000344020: DACC0000 05001401
	ds_bpermute_b32 v1, v1, v18                                // 000000344028: DACC0000 01001201
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000344030: 300C0C82
	s_waitcnt lgkmcnt(2)                                       // 000000344034: BF89FC27
	v_dual_add_f32 v4, v21, v4 :: v_dual_add_f32 v3, v22, v3   // 000000344038: C9080915 04020716
	s_waitcnt lgkmcnt(1)                                       // 000000344040: BF89FC17
	v_add_f32_e32 v5, v20, v5                                  // 000000344044: 060A0B14
	ds_bpermute_b32 v7, v6, v2                                 // 000000344048: DACC0000 07000206
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000344050: 301A1A82
	ds_bpermute_b32 v11, v6, v4                                // 000000344054: DACC0000 0B000406
	s_waitcnt lgkmcnt(2)                                       // 00000034405C: BF89FC27
	v_add_f32_e32 v1, v18, v1                                  // 000000344060: 06020312
	ds_bpermute_b32 v10, v6, v3                                // 000000344064: DACC0000 0A000306
	ds_bpermute_b32 v12, v6, v5                                // 00000034406C: DACC0000 0C000506
	s_waitcnt lgkmcnt(3)                                       // 000000344074: BF89FC37
	v_add_f32_e32 v2, v2, v7                                   // 000000344078: 06040F02
	s_waitcnt lgkmcnt(2)                                       // 00000034407C: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 000000344080: 06081704
	ds_bpermute_b32 v6, v6, v1                                 // 000000344084: DACC0000 06000106
	s_waitcnt lgkmcnt(2)                                       // 00000034408C: BF89FC27
	v_add_f32_e32 v3, v3, v10                                  // 000000344090: 06061503
	ds_bpermute_b32 v11, v13, v4                               // 000000344094: DACC0000 0B00040D
	s_waitcnt lgkmcnt(1)                                       // 00000034409C: BF89FC17
	v_add_f32_e32 v10, v1, v6                                  // 0000003440A0: 06140D01
	v_xor_b32_e32 v6, 1, v0                                    // 0000003440A4: 3A0C0081
	ds_bpermute_b32 v1, v13, v2                                // 0000003440A8: DACC0000 0100020D
	v_add_f32_e32 v5, v5, v12                                  // 0000003440B0: 060A1905
	.long 0xd44c0000                                           // 0000003440B4: D44C0000
	v_cndmask_b32_e32 v1, 32, v6, vcc_lo                       // 0000003440B8: 02020CA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003440BC: BF870121
	v_cndmask_b32_e64 v0, v0, v6, s0                           // 0000003440C0: D5010000 00020D00
	.long 0xd44a0000                                           // 0000003440C8: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000003440CC: 02022280
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000003440D0: 301C0082
	ds_bpermute_b32 v7, v13, v3                                // 0000003440D4: DACC0000 0700030D
	s_and_b32 s0, s0, vcc_lo                                   // 0000003440DC: 8B006A00
	s_waitcnt lgkmcnt(1)                                       // 0000003440E0: BF89FC17
	v_add_f32_e32 v6, v2, v1                                   // 0000003440E4: 060C0302
	ds_bpermute_b32 v12, v13, v5                               // 0000003440E8: DACC0000 0C00050D
	v_add_f32_e32 v0, v4, v11                                  // 0000003440F0: 06001704
	s_waitcnt lgkmcnt(1)                                       // 0000003440F4: BF89FC17
	v_add_f32_e32 v7, v3, v7                                   // 0000003440F8: 060E0F03
	ds_bpermute_b32 v13, v13, v10                              // 0000003440FC: DACC0000 0D000A0D
	ds_bpermute_b32 v11, v14, v7                               // 000000344104: DACC0000 0B00070E
	s_waitcnt lgkmcnt(2)                                       // 00000034410C: BF89FC27
	v_add_f32_e32 v1, v5, v12                                  // 000000344110: 06021905
	ds_bpermute_b32 v2, v14, v0                                // 000000344114: DACC0000 0200000E
	ds_bpermute_b32 v3, v14, v1                                // 00000034411C: DACC0000 0300010E
	s_waitcnt lgkmcnt(3)                                       // 000000344124: BF89FC37
	v_add_f32_e32 v4, v10, v13                                 // 000000344128: 06081B0A
	ds_bpermute_b32 v10, v14, v6                               // 00000034412C: DACC0000 0A00060E
	ds_bpermute_b32 v5, v14, v4                                // 000000344134: DACC0000 0500040E
	s_and_saveexec_b32 s1, s0                                  // 00000034413C: BE812000
	s_cbranch_execz 72                                         // 000000344140: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi5ELi16ELi1EEEvPKhPKtPtll+0x1364>
	s_waitcnt lgkmcnt(1)                                       // 000000344144: BF89FC17
	v_dual_add_f32 v11, v7, v11 :: v_dual_add_f32 v10, v6, v10 // 000000344148: C9081707 0B0A1506
	.long 0x7f183880                                           // 000000344150: 7F183880
	.long 0xd73c0006                                           // 000000344154: D73C0006
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000344158: 02021081
	s_waitcnt lgkmcnt(0)                                       // 00000034415C: BF89FC07
	v_dual_add_f32 v14, v4, v5 :: v_dual_add_f32 v3, v1, v3    // 000000344160: C9080B04 0E020701
	.long 0x7e1a398a                                           // 000000344168: 7E1A398A
	.long 0x7f1a398c                                           // 00000034416C: 7F1A398C
	.long 0x7e18398b                                           // 000000344170: 7E18398B
	.long 0xd7006a04                                           // 000000344174: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000344178: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034417C: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v9, 1, v13     // 000000344180: C9240500 02081A81
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 000000344188: D5207C05 01AA0E09
	.long 0x7f00398c                                           // 000000344190: 7F00398C
	.long 0x7e003982                                           // 000000344194: 7E003982
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000344198: 84808102
	v_and_b32_e32 v8, 1, v12                                   // 00000034419C: 36101881
	.long 0x7e183983                                           // 0000003441A0: 7E183983
	.long 0xd7006a06                                           // 0000003441A4: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000003441A8: 02000104
	v_and_b32_e32 v13, 1, v0                                   // 0000003441AC: 361A0081
	v_mad_u64_u32 v[0:1], null, s2, 6, v[4:5]                  // 0000003441B0: D6FE7C00 04110C02
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 0000003441B8: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000003441C0: 84808202
	v_add3_u32 v11, v11, v8, 0x7fff                            // 0000003441C4: D655000B 03FE110B 00007FFF
	.long 0xd7006a08                                           // 0000003441D0: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000003441D4: 02000104
	v_and_b32_e32 v12, 1, v12                                  // 0000003441D8: 36181881
	v_add3_u32 v10, v10, v9, 0x7fff                            // 0000003441DC: D655000A 03FE130A 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000003441E8: BF8907F7
	v_bfe_u32 v15, v14, 16, 1                                  // 0000003441EC: D610000F 0205210E
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 0000003441F4: D5207C09 01AA0A01
	v_add3_u32 v13, v2, v13, 0x7fff                            // 0000003441FC: D655000D 03FE1B02 00007FFF
	v_mad_u64_u32 v[1:2], null, s3, 6, v[1:2]                  // 000000344208: D6FE7C01 04050C03
	.long 0xd7006a02                                           // 000000344210: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000344214: 02000108
	v_add3_u32 v12, v3, v12, 0x7fff                            // 000000344218: D655000C 03FE1903 00007FFF
	v_add3_u32 v14, v14, v15, 0x7fff                           // 000000344224: D655000E 03FE1F0E 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 000000344230: D5207C03 01AA1201
	s_clause 0x4                                               // 000000344238: BF850004
	global_store_d16_hi_b16 v[4:5], v10, off                   // 00000034423C: DC960000 007C0A04
	global_store_d16_hi_b16 v[6:7], v11, off                   // 000000344244: DC960000 007C0B06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 00000034424C: DC960000 007C0D08
	global_store_d16_hi_b16 v[0:1], v12, off                   // 000000344254: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v14, off                   // 00000034425C: DC960000 007C0E02
	s_endpgm                                                   // 000000344264: BFB00000
		...

