000000000043eb00 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 00000043EB00: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 00000043EB04: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000043EB0C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 00000043EB14: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 00000043EB18: BF108004
	s_cbranch_scc1 246                                         // 00000043EB1C: BFA200F6 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f8>
	s_load_b32 s6, s[0:1], 0x138                               // 00000043EB20: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 00000043EB28: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000043EB2C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 00000043EB30: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000043EB34: BF030602
	s_cbranch_scc0 233                                         // 00000043EB38: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000043EB3C: 32020085
	s_sub_i32 s6, s2, s6                                       // 00000043EB40: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000043EB44: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 00000043EB48: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 00000043EB50: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000043EB54: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 00000043EB58: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000043EB5C: BE86206A
	s_cbranch_execz 222                                        // 00000043EB60: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 00000043EB64: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 00000043EB68: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 00000043EB70: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 00000043EB74: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000043EB7C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000043EB84: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000043EB88: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000043EB8C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 00000043EB90: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000043EB94: BF870121
	.long 0xd72c0002                                           // 00000043EB98: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000043EB9C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 00000043EBA4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 00000043EBB0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043EBB8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 00000043EBBC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000043EBC4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043EBC8: BF870091
	.long 0xd73c0002                                           // 00000043EBCC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 00000043EBD0: 02020481
	.long 0xd7006a04                                           // 00000043EBD4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000043EBD8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000043EBDC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000043EBE0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 00000043EBE8: BF89FC07
	.long 0xd7006a02                                           // 00000043EBEC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 00000043EBF0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 00000043EBF4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 00000043EBFC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 00000043EC04: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000043EC0C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 00000043EC14: BF8907F7
	.long 0x7e043904                                           // 00000043EC18: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000043EC1C: 360608FF FFFF0000
	.long 0x7e083905                                           // 00000043EC24: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000043EC28: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043EC30: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 00000043EC34: 301C0490
	s_waitcnt vmcnt(0)                                         // 00000043EC38: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043EC3C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000043EC44: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043EC48: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000043EC50: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043EC54: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 00000043EC58: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 00000043EC60: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 00000043EC68: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 00000043EC70: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 00000043EC78: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000043EC7C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 00000043EC80: 361A0088
	.long 0xd73c0001                                           // 00000043EC84: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000043EC88: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000043EC8C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 00000043EC90: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000043EC94: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043EC98: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043EC9C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043ECA4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043ECAC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000043ECB4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 00000043ECB8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 00000043ECBC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 00000043ECC8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 00000043ECCC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 00000043ECD0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043ECD8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000043ECE0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043ECE8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043ECEC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000043ECF4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000043ECFC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 00000043ED00: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 00000043ED08: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043ED0C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 00000043ED10: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043ED14: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043ED1C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043ED24: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043ED2C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043ED34: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000043ED3C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 00000043ED44: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043ED48: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000043ED50: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000043ED58: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 00000043ED5C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043ED60: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 00000043ED68: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 00000043ED6C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043ED70: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043ED78: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000043ED80: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000043ED84: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043ED88: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043ED90: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000043ED98: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 00000043EDA0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 00000043EDA4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 00000043EDA8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043EDAC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000043EDB4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 00000043EDBC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 00000043EDC0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043EDC4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043EDCC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 00000043EDD4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043EDD8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043EDE0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043EDE8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000043EDF0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043EDF8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000043EE00: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 00000043EE08: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 00000043EE0C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 00000043EE10: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043EE14: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 00000043EE18: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 00000043EE20: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043EE24: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043EE2C: BF870214
	v_mov_b32_e32 v13, v5                                      // 00000043EE30: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 00000043EE34: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 00000043EE38: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 00000043EE40: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043EE4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000043EE54: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 00000043EE5C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 00000043EE68: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 00000043EE74: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 00000043EE80: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000043EE84: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000043EE88: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000043EE8C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 00000043EE94: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 00000043EE9C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 00000043EEA0: 060A1B05
	.long 0xd7006a01                                           // 00000043EEA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 00000043EEA8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000043EEAC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 00000043EEB4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 00000043EEBC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 00000043EEC4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 00000043EECC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 00000043EED4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 00000043EEDC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043EEE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000043EEE4: 8B6A037E
	s_cbranch_vccnz 4                                          // 00000043EEE8: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3fc>
	s_nop 0                                                    // 00000043EEEC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000043EEF0: BFB60003
	s_endpgm                                                   // 00000043EEF4: BFB00000
	s_cbranch_execz 65532                                      // 00000043EEF8: BFA5FFFC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 00000043EEFC: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000043EF00: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 00000043EF08: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 00000043EF10: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 00000043EF18: F4000180 F800010C
	v_lshrrev_b32_e32 v35, 5, v0                               // 00000043EF20: 32460085
	v_and_b32_e32 v36, 31, v0                                  // 00000043EF24: 3648009F
	s_mov_b32 s29, 0                                           // 00000043EF28: BE9D0080
	s_mov_b32 s27, exec_lo                                     // 00000043EF2C: BE9B007E
	s_waitcnt lgkmcnt(0)                                       // 00000043EF30: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000043EF34: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000043EF38: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000043EF3C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000043EF40: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043EF44: BF870009
	s_and_b32 s4, s7, s4                                       // 00000043EF48: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000043EF4C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000043EF50: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000043EF58: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000043EF5C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000043EF60: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043EF64: BF870009
	s_and_b32 s4, s7, s5                                       // 00000043EF68: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000043EF6C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000043EF70: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000043EF74: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000043EF78: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000043EF7C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000043EF80: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000043EF84: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000043EF88: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000043EF8C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000043EF90: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000043EF94: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000043EF98: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043EF9C: BF870009
	s_add_u32 s4, s0, s3                                       // 00000043EFA0: 80040300
	s_addc_u32 s5, s1, 0                                       // 00000043EFA4: 82058001
	s_clause 0x3                                               // 00000043EFA8: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 00000043EFAC: F4000702 F8000038
	s_load_b64 s[34:35], s[4:5], 0x40                          // 00000043EFB4: F4040882 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 00000043EFBC: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 00000043EFC4: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 00000043EFCC: BF89FC07
	s_abs_i32 s3, s21                                          // 00000043EFD0: BE831515
	s_sub_i32 s2, s2, s23                                      // 00000043EFD4: 81821702
	s_cvt_f32_u32 s6, s3                                       // 00000043EFD8: BE866503
	s_sub_i32 s7, 0, s3                                        // 00000043EFDC: 81870380
	s_abs_i32 s8, s2                                           // 00000043EFE0: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000043EFE4: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 00000043EFE8: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 00000043EFEC: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 00000043EFF0: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000043EFF8: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 00000043EFFC: BE866706
	s_mul_i32 s7, s7, s6                                       // 00000043F000: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000043F004: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 00000043F008: 96870706
	s_add_i32 s6, s6, s7                                       // 00000043F00C: 81060706
	s_xor_b32 s7, s2, s21                                      // 00000043F010: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 00000043F014: 96860608
	s_ashr_i32 s7, s7, 31                                      // 00000043F018: 86079F07
	s_mul_i32 s9, s6, s3                                       // 00000043F01C: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043F020: BF870009
	s_sub_i32 s8, s8, s9                                       // 00000043F024: 81880908
	s_add_i32 s9, s6, 1                                        // 00000043F028: 81098106
	s_sub_i32 s10, s8, s3                                      // 00000043F02C: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 00000043F030: BF090308
	s_cselect_b32 s6, s9, s6                                   // 00000043F034: 98060609
	s_cselect_b32 s8, s10, s8                                  // 00000043F038: 9808080A
	s_add_i32 s9, s6, 1                                        // 00000043F03C: 81098106
	s_cmp_ge_u32 s8, s3                                        // 00000043F040: BF090308
	s_cselect_b32 s3, s9, s6                                   // 00000043F044: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 00000043F048: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 00000043F050: 8D030703
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043F054: BF870009
	s_sub_i32 s26, s3, s7                                      // 00000043F058: 819A0703
	s_ashr_i32 s7, s19, 31                                     // 00000043F05C: 86079F13
	s_mul_i32 s3, s26, s21                                     // 00000043F060: 9603151A
	s_lshr_b32 s4, s7, 25                                      // 00000043F064: 85049907
	s_sub_i32 s30, s2, s3                                      // 00000043F068: 819E0302
	s_add_i32 s2, s19, s4                                      // 00000043F06C: 81020413
	s_mul_i32 s23, s22, s30                                    // 00000043F070: 96171E16
	s_ashr_i32 s2, s2, 7                                       // 00000043F074: 86028702
	s_add_i32 s3, s23, s22                                     // 00000043F078: 81031617
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000043F07C: BF870499
	s_min_i32 s2, s2, s3                                       // 00000043F080: 89020302
	s_sub_i32 s2, s2, s23                                      // 00000043F084: 81821702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000043F088: BF870499
	s_lshl_b32 s22, s2, 3                                      // 00000043F08C: 84168302
	.long 0xd4c4007e                                           // 00000043F090: D4C4007E
	v_cndmask_b32_e32 v1, s22, v35, vcc_lo                     // 00000043F094: 02024616
	s_cbranch_execz 288                                        // 00000043F098: BFA50120 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa1c>
	s_abs_i32 s31, s2                                          // 00000043F09C: BE9F1502
	v_lshlrev_b32_e32 v7, 3, v36                               // 00000043F0A0: 300E4883
	s_cvt_f32_u32 s3, s31                                      // 00000043F0A4: BE83651F
	v_lshlrev_b32_e32 v8, 7, v35                               // 00000043F0A8: 30104687
	v_and_b32_e32 v3, 2, v0                                    // 00000043F0AC: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 00000043F0B0: 360A0088
	v_rcp_iflag_f32_e32 v1, s3                                 // 00000043F0B4: 7E025603
	s_sub_i32 s3, 0, s31                                       // 00000043F0B8: 81831F80
	s_ashr_i32 s37, s2, 31                                     // 00000043F0BC: 86259F02
	s_lshl_b32 s38, s2, 8                                      // 00000043F0C0: 84268802
	s_lshl_b32 s6, s2, 7                                       // 00000043F0C4: 84068702
	s_mul_i32 s39, s37, 0x1400                                 // 00000043F0C8: 9627FF25 00001400
	.long 0xd44a0005                                           // 00000043F0D0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000043F0D4: 02020A80
	s_add_i32 s33, s18, -1                                     // 00000043F0D8: 8121C112
	s_mov_b32 s36, s19                                         // 00000043F0DC: BEA40013
	s_mov_b32 s40, 0x76543210                                  // 00000043F0E0: BEA800FF 76543210
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 00000043F0E8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s41, 0x3db504f3                                  // 00000043F0F4: BEA900FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v36                           // 00000043F0FC: 7C984890
	s_delay_alu instid0(VALU_DEP_2)                            // 00000043F100: BF870002
	v_cvt_u32_f32_e32 v4, v1                                   // 00000043F104: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 00000043F108: 36020084
	.long 0xd44a0002                                           // 00000043F10C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000043F110: 02020480
	v_lshl_or_b32 v2, v35, 8, v7                               // 00000043F114: D6560002 041D1123
	v_lshl_add_u32 v7, s23, 7, v8                              // 00000043F11C: D6460007 04210E17
	.long 0xd72c0006                                           // 00000043F124: D72C0006
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 00000043F128: 02020803
	.long 0xd44a0003                                           // 00000043F12C: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000043F130: 02020680
	.long 0xd44a0004                                           // 00000043F134: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000043F138: 02020280
	v_subrev_nc_u32_e32 v2, s39, v2                            // 00000043F13C: 4E040427
	v_lshl_or_b32 v1, v36, 2, v7                               // 00000043F140: D6560001 041D0524
	s_sub_i32 s39, 0, s6                                       // 00000043F148: 81A70680
	.long 0xd72d0006                                           // 00000043F14C: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000043F150: 02020D04
	s_delay_alu instid0(VALU_DEP_1)                            // 00000043F154: BF870001
	v_dual_mov_b32 v4, v35 :: v_dual_add_nc_u32 v3, v4, v6     // 00000043F158: CA200123 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F160: BF870091
	.long 0xd72d0005                                           // 00000043F164: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 00000043F168: 02020704
	.long 0xd72c0006                                           // 00000043F16C: D72C0006
	v_cndmask_b32_e32 v0, v5, v31, vcc_lo                      // 00000043F170: 02003F05
	v_add_nc_u32_e32 v7, 1, v5                                 // 00000043F174: 4A0E0A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F178: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 00000043F17C: 4C0C0D04
	v_subrev_nc_u32_e32 v8, s31, v6                            // 00000043F180: 4E100C1F
	.long 0xd44b0006                                           // 00000043F184: D44B0006
	v_cndmask_b32_e32 v1, s31, v6, vcc_lo                      // 00000043F188: 02020C1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F18C: BF870191
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 00000043F190: D5010005 001A0F05
	v_cndmask_b32_e64 v6, v6, v8, s6                           // 00000043F198: D5010006 001A1106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000043F1A0: BF870112
	v_add_nc_u32_e32 v7, 1, v5                                 // 00000043F1A4: 4A0E0A81
	.long 0xd44b0006                                           // 00000043F1A8: D44B0006
	v_cndmask_b32_e32 v1, s31, v6, vcc_lo                      // 00000043F1AC: 02020C1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F1B0: BF870091
	v_cndmask_b32_e64 v5, v5, v7, s6                           // 00000043F1B4: D5010005 001A0F05
	v_xor_b32_e32 v9, s37, v5                                  // 00000043F1BC: 3A120A25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000043F1C0: BF870121
	v_subrev_nc_u32_e32 v10, s37, v9                           // 00000043F1C4: 4E141225
	.long 0xd72c0009                                           // 00000043F1C8: D72C0009
	v_cndmask_b32_e32 v1, 0x1400, v9, vcc_lo                   // 00000043F1CC: 020212FF 00001400
	v_min_i32_e32 v7, s33, v10                                 // 00000043F1D4: 220E1421
	v_mad_u64_u32 v[5:6], null, s39, v10, v[1:2]               // 00000043F1D8: D6FE7C05 04061427
	.long 0xd72c000a                                           // 00000043F1E0: D72C000A
	v_cndmask_b32_e32 v1, s38, v10, vcc_lo                     // 00000043F1E4: 02021426
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F1E8: BF870193
	v_mad_i64_i32 v[7:8], null, v7, s36, 0                     // 00000043F1EC: D6FF7C07 02004907
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000043F1F4: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F1F8: BF870193
	v_sub_nc_u32_e32 v9, v9, v10                               // 00000043F1FC: 4C121509
	.long 0xd73c0007                                           // 00000043F200: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000043F204: 02020E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F208: BF870193
	.long 0xd73c0005                                           // 00000043F20C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000043F210: 02020A81
	v_add_nc_u32_e32 v9, v2, v9                                // 00000043F214: 4A121302
	v_add_nc_u32_e32 v2, 0x800, v2                             // 00000043F218: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F220: BF870094
	.long 0xd700060b                                           // 00000043F224: D700060B
	v_cndmask_b32_e32 v1, s16, v7, vcc_lo                      // 00000043F228: 02020E10
	v_add_co_ci_u32_e64 v12, null, s17, v8, s6                 // 00000043F22C: D5207C0C 001A1011
	s_waitcnt lgkmcnt(0)                                       // 00000043F234: BF89FC07
	.long 0xd7000607                                           // 00000043F238: D7000607
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000043F23C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000043F240: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s11, v6, s6                  // 00000043F244: D5207C08 001A0C0B
	.long 0xd7000605                                           // 00000043F24C: D7000605
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 00000043F250: 02020B0B
	v_add_co_ci_u32_e64 v6, null, v12, v6, s6                  // 00000043F254: D5207C06 001A0D0C
	global_load_b64 v[5:6], v[5:6], off                        // 00000043F25C: DC560000 057C0005
	global_load_b64 v[7:8], v[7:8], off                        // 00000043F264: DC560000 077C0007
	s_waitcnt vmcnt(1)                                         // 00000043F26C: BF8907F7
	.long 0x7e163905                                           // 00000043F270: 7E163905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000043F274: 360A0AFF FFFF0000
	.long 0x7e183906                                           // 00000043F27C: 7E183906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000043F280: BF8701A3
	v_lshlrev_b32_e32 v11, 16, v11                             // 00000043F284: 30161690
	s_waitcnt vmcnt(0)                                         // 00000043F288: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043F28C: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000043F294: BF8701C1
	v_fma_mix_f32 v14, v7, v11, v5 op_sel_hi:[1,0,0]           // 00000043F298: CC20000E 0C161707
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000043F2A0: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v7, v11, -v5 op_sel_hi:[1,0,0]           // 00000043F2A8: CC200005 8C161707
	v_lshlrev_b32_e32 v12, 16, v12                             // 00000043F2B0: 30181890
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000043F2B4: CC200806 8A020D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000043F2BC: BF870121
	v_fma_mix_f32 v13, v8, v12, v6 op_sel_hi:[1,0,0]           // 00000043F2C0: CC20000D 0C1A1908
	v_fma_mix_f32 v6, v8, v12, -v6 op_sel_hi:[1,0,0]           // 00000043F2C8: CC200006 8C1A1908
	v_dual_add_f32 v7, v14, v13 :: v_dual_add_nc_u32 v4, 8, v4 // 00000043F2D0: C9201B0E 07040888
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043F2D8: BF870232
	v_add_f32_e32 v8, v6, v5                                   // 00000043F2DC: 06100B06
	v_sub_f32_e32 v11, v14, v13                                // 00000043F2E0: 08161B0E
	v_sub_f32_e32 v5, v5, v6                                   // 00000043F2E4: 080A0D05
	.long 0xd4430006                                           // 00000043F2E8: D4430006
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 00000043F2EC: 02020816
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043F2F0: 7E0C02FA FF016107
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043F2F8: 7E1802FA FF016108
	v_mov_b32_dpp v13, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043F300: 7E1A02FA FF01610B
	v_cndmask_b32_e64 v7, -v7, v7, s2                          // 00000043F308: D5010007 200A0F07
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 00000043F310: D5010008 200A1108
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 00000043F318: D501000B 200A170B
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000043F320: 4A0202FF 00000400
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000043F328: 7E1C02FA FF016105
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043F330: BF870214
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v7, v8, v12    // 00000043F334: C9080D07 06061908
	v_add_f32_e32 v8, v11, v13                                 // 00000043F33C: 06101B0B
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 00000043F340: D5010005 200A0B05
	s_or_b32 s29, s6, s29                                      // 00000043F348: 8C1D1D06
	s_delay_alu instid0(VALU_DEP_3)                            // 00000043F34C: BF870003
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043F350: 7E1602FA FF016206
	v_mov_b32_dpp v12, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043F358: 7E1802FA FF016207
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043F360: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 00000043F368: D5010008 200E1108
	v_add_f32_e32 v5, v5, v14                                  // 00000043F370: 060A1D05
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 00000043F374: D5010007 200E0F07
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 00000043F37C: D5010006 200E0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043F384: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 00000043F388: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000043F38C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000043F394: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043F39C: BF870214
	v_add_f32_e32 v6, v6, v11                                  // 00000043F3A0: 060C1706
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043F3A4: 7E1A02FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s4                          // 00000043F3AC: D5010008 20121108
	v_add_f32_e32 v7, v7, v12                                  // 00000043F3B4: 060E1907
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043F3B8: BF870224
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043F3BC: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 00000043F3C4: D5010006 20120D06
	v_add_f32_e32 v8, v8, v13                                  // 00000043F3CC: 06101B08
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043F3D0: BF870224
	v_mov_b32_dpp v12, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043F3D4: 7E1802FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s4                          // 00000043F3DC: D5010007 20120F07
	v_add_f32_e32 v6, v6, v11                                  // 00000043F3E4: 060C1706
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043F3E8: BF870234
	v_mov_b32_dpp v13, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043F3EC: 7E1A02FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, s5                          // 00000043F3F4: D5010008 20161108
	v_add_f32_e32 v5, v5, v14                                  // 00000043F3FC: 060A1D05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043F400: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 00000043F408: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043F410: BF870214
	v_add_f32_e32 v8, v8, v13                                  // 00000043F414: 06101B08
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000043F418: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000043F420: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000043F428: BF8701A3
	v_dual_add_f32 v6, v6, v11 :: v_dual_mov_b32 v13, v8       // 00000043F42C: C9101706 060C0108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000043F434: D5010008 21AA1108
	v_add_f32_e32 v5, v5, v14                                  // 00000043F43C: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000043F440: BF870113
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 00000043F444: D65C000D 03FC510D FEDCBA98
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043F450: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000043F458: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F460: BF870091
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v5, v5, v14   // 00000043F464: C9081B08 08041D05
	v_dual_add_f32 v7, v7, v12 :: v_dual_mov_b32 v14, v5       // 00000043F46C: C9101907 070E0105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043F474: BF870231
	v_mov_b32_dpp v12, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000043F478: 7E1802FA FF016807
	v_cndmask_b32_e64 v7, -v7, v7, s5                          // 00000043F480: D5010007 20160F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000043F488: D5010005 21AA0B05
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 00000043F490: D65C000E 03FC510E FEDCBA98
	v_mov_b32_e32 v11, v6                                      // 00000043F49C: 7E160306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000043F4A0: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F4A8: BF870193
	v_add_f32_e32 v10, v5, v14                                 // 00000043F4AC: 06141D05
	v_permlanex16_b32 v11, v11, s40, 0xfedcba98                // 00000043F4B0: D65C000B 03FC510B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F4BC: BF870091
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 00000043F4C0: C9081907 07061706
	v_mov_b32_e32 v12, v7                                      // 00000043F4C8: 7E180307
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000043F4CC: D5010007 21AA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000043F4D4: BF870193
	v_fma_mixlo_f16 v5, v6, s41, 0                             // 00000043F4D8: CC210005 02005306
	v_permlanex16_b32 v12, v12, s40, 0xfedcba98                // 00000043F4E0: D65C000C 03FC510C FEDCBA98
	v_fma_mixhi_f16 v6, v10, s41, 0                            // 00000043F4EC: CC220006 0200530A
	v_fma_mixlo_f16 v6, v8, s41, 0                             // 00000043F4F4: CC210006 02005308
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F4FC: BF870093
	v_add_f32_e32 v7, v7, v12                                  // 00000043F500: 060E1907
	v_fma_mixhi_f16 v5, v7, s41, 0                             // 00000043F504: CC220005 02005307
	ds_store_b64 v9, v[5:6]                                    // 00000043F50C: D9340000 00000509
	s_and_not1_b32 exec_lo, exec_lo, s29                       // 00000043F514: 917E1D7E
	s_cbranch_execnz 65297                                     // 00000043F518: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x660>
	s_or_b32 exec_lo, exec_lo, s27                             // 00000043F51C: 8C7E1B7E
	s_ashr_i32 s2, s22, 31                                     // 00000043F520: 86029F16
	s_lshr_b32 s3, s7, 28                                      // 00000043F524: 85039C07
	s_lshr_b32 s2, s2, 29                                      // 00000043F528: 85029D02
	s_add_i32 s3, s19, s3                                      // 00000043F52C: 81030313
	s_add_i32 s2, s2, s22                                      // 00000043F530: 81021602
	s_waitcnt lgkmcnt(0)                                       // 00000043F534: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000043F538: BC7C0000
	s_add_i32 s2, s2, 7                                        // 00000043F53C: 81028702
	s_barrier                                                  // 00000043F540: BFBD0000
	s_ashr_i32 s2, s2, 3                                       // 00000043F544: 86028302
	buffer_gl0_inv                                             // 00000043F548: E0AC0000 00000000
	.long 0xd72c0001                                           // 00000043F550: D72C0001
	v_cndmask_b32_e32 v1, s2, v35, vcc_lo                      // 00000043F554: 02024602
	s_delay_alu instid0(VALU_DEP_1)                            // 00000043F558: BF870001
	v_add_nc_u32_e32 v2, s2, v1                                // 00000043F55C: 4A040202
	s_ashr_i32 s2, s3, 4                                       // 00000043F560: 86028403
	s_lshl_b32 s3, s23, 3                                      // 00000043F564: 84038317
	s_mul_hi_i32 s4, s26, s2                                   // 00000043F568: 9704021A
	s_mul_i32 s2, s26, s2                                      // 00000043F56C: 9602021A
	v_min_i32_e32 v101, s22, v2                                // 00000043F570: 22CA0416
	s_ashr_i32 s5, s3, 31                                      // 00000043F574: 86059F03
	s_add_u32 s2, s2, s3                                       // 00000043F578: 80020302
	s_addc_u32 s3, s4, s5                                      // 00000043F57C: 82030504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000043F580: BF870009
	s_lshl_b64 s[4:5], s[2:3], 10                              // 00000043F584: 84848A02
	v_cmp_lt_i32_e32 vcc_lo, v1, v101                          // 00000043F588: 7C82CB01
	s_add_u32 s3, s8, s4                                       // 00000043F58C: 80030408
	s_addc_u32 s4, s9, s5                                      // 00000043F590: 82040509
	s_and_saveexec_b32 s5, vcc_lo                              // 00000043F594: BE85206A
	s_cbranch_execz 94                                         // 00000043F598: BFA5005E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc14>
	.long 0xd7010202                                           // 00000043F59C: D7010202
	v_cndmask_b32_e32 v0, v36, v129, vcc_lo                    // 00000043F5A0: 02010324
	v_lshlrev_b32_e32 v8, 2, v36                               // 00000043F5A4: 30104882
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000043F5A8: BF870122
	v_cndmask_b32_e64 v3, v2, 31, s2                           // 00000043F5AC: D5010003 00093F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000043F5B4: 3404029F
	.long 0xd44c0002                                           // 00000043F5B8: D44C0002
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000043F5BC: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F5C0: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s2                          // 00000043F5C4: D5010005 000902FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000043F5D0: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000043F5D8: BF870114
	.long 0xd73c0005                                           // 00000043F5DC: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000043F5E0: 0202028A
	.long 0xd73c0002                                           // 00000043F5E4: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000043F5E8: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043F5EC: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000043F5F0: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 00000043F5F4: D6110007 02050F07
	.long 0xd7000209                                           // 00000043F5FC: D7000209
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 00000043F600: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043F604: BF870211
	v_add_co_ci_u32_e64 v10, null, s4, v6, s2                  // 00000043F608: D5207C0A 000A0C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 00000043F610: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F614: BF870093
	.long 0xd7000204                                           // 00000043F618: D7000204
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 00000043F61C: 02020509
	v_add_co_ci_u32_e64 v5, null, v10, v3, s2                  // 00000043F620: D5207C05 000A070A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000043F628: BF870093
	.long 0xd7000206                                           // 00000043F62C: D7000206
	v_cndmask_b32_e32 v1, v9, v6, vcc_lo                       // 00000043F630: 02020D09
	v_add_co_ci_u32_e64 v7, null, v10, v7, s2                  // 00000043F634: D5207C07 000A0F0A
	.long 0xd7000208                                           // 00000043F63C: D7000208
	v_cndmask_b32_e32 v1, v9, v8, vcc_lo                       // 00000043F640: 02021109
	s_delay_alu instid0(VALU_DEP_1)                            // 00000043F644: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v10, s2                   // 00000043F648: D5207C09 000A1480
	s_clause 0x17                                              // 00000043F650: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000043F654: DC520000 027C0004
	global_load_b32 v139, v[4:5], off offset:128               // 00000043F65C: DC520080 8B7C0004
	global_load_b32 v136, v[4:5], off offset:256               // 00000043F664: DC520100 887C0004
	global_load_b32 v133, v[4:5], off offset:384               // 00000043F66C: DC520180 857C0004
	global_load_b32 v130, v[4:5], off offset:512               // 00000043F674: DC520200 827C0004
	global_load_b32 v127, v[4:5], off offset:640               // 00000043F67C: DC520280 7F7C0004
	global_load_b32 v124, v[4:5], off offset:768               // 00000043F684: DC520300 7C7C0004
	global_load_b32 v116, v[4:5], off offset:896               // 00000043F68C: DC520380 747C0004
	global_load_b32 v3, v[6:7], off                            // 00000043F694: DC520000 037C0006
	global_load_b32 v140, v[6:7], off offset:128               // 00000043F69C: DC520080 8C7C0006
	global_load_b32 v137, v[6:7], off offset:256               // 00000043F6A4: DC520100 897C0006
	global_load_b32 v134, v[6:7], off offset:384               // 00000043F6AC: DC520180 867C0006
	global_load_b32 v131, v[6:7], off offset:512               // 00000043F6B4: DC520200 837C0006
	global_load_b32 v128, v[6:7], off offset:640               // 00000043F6BC: DC520280 807C0006
	global_load_b32 v125, v[6:7], off offset:768               // 00000043F6C4: DC520300 7D7C0006
	global_load_b32 v122, v[6:7], off offset:896               // 00000043F6CC: DC520380 7A7C0006
	global_load_b32 v4, v[8:9], off                            // 00000043F6D4: DC520000 047C0008
	global_load_b32 v138, v[8:9], off offset:128               // 00000043F6DC: DC520080 8A7C0008
	global_load_b32 v135, v[8:9], off offset:256               // 00000043F6E4: DC520100 877C0008
	global_load_b32 v132, v[8:9], off offset:384               // 00000043F6EC: DC520180 847C0008
	global_load_b32 v129, v[8:9], off offset:512               // 00000043F6F4: DC520200 817C0008
	global_load_b32 v126, v[8:9], off offset:640               // 00000043F6FC: DC520280 7E7C0008
	global_load_b32 v123, v[8:9], off offset:768               // 00000043F704: DC520300 7B7C0008
	global_load_b32 v105, v[8:9], off offset:896               // 00000043F70C: DC520380 697C0008
	s_or_b32 exec_lo, exec_lo, s5                              // 00000043F714: 8C7E057E
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 00000043F718: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 00000043F720: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 00000043F728: CA100080 292A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v44, 0             // 00000043F730: CA100080 2B2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 00000043F738: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 00000043F740: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 00000043F748: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 00000043F750: CA100080 33340080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 00000043F758: CA100080 35360080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 00000043F760: CA100080 37380080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0             // 00000043F768: CA100080 393A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 00000043F770: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 00000043F778: CA100080 3D3E0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v64, 0             // 00000043F780: CA100080 3F400080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v66, 0             // 00000043F788: CA100080 41420080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v68, 0             // 00000043F790: CA100080 43440080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v70, 0             // 00000043F798: CA100080 45460080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 00000043F7A0: CA100080 47480080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v74, 0             // 00000043F7A8: CA100080 494A0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v76, 0             // 00000043F7B0: CA100080 4B4C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 00000043F7B8: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0             // 00000043F7C0: CA100080 4F500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v82, 0             // 00000043F7C8: CA100080 51520080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v84, 0             // 00000043F7D0: CA100080 53540080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v95, 0             // 00000043F7D8: CA100080 565E0080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v97, 0             // 00000043F7E0: CA100080 58600080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v99, 0             // 00000043F7E8: CA100080 5C620080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v85, 0             // 00000043F7F0: CA100080 5E540080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v87, 0             // 00000043F7F8: CA100080 62560080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v90, 0             // 00000043F800: CA100080 595A0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v96, 0             // 00000043F808: CA100080 5D600080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v100, 0            // 00000043F810: CA100080 5B640080
	s_ashr_i32 s27, s26, 31                                    // 00000043F818: 861B9F1A
	s_and_saveexec_b32 s2, vcc_lo                              // 00000043F81C: BE82206A
	s_cbranch_execz 1253                                       // 00000043F820: BFA504E5 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20b8>
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v5, -1, v0      // 00000043F824: CA200080 260400C1
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v102, 16, v0       // 00000043F82C: CA240080 25660090
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v103, 2, v36   // 00000043F834: CA220080 28664882
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000043F83C: BF8701B3
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v5, 31, v5         // 00000043F840: CA240080 2A040A9F
	v_mov_b32_e32 v39, 0                                       // 00000043F848: 7E4E0280
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v44, 0             // 00000043F84C: CA100080 292C0080
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v104, 2, v5    // 00000043F854: CA220080 2B680A82
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v45, 0             // 00000043F85C: CA100080 2E2C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 00000043F864: CA100080 302E0080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v49, 0             // 00000043F86C: CA100080 32300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 00000043F874: CA100080 34320080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 00000043F87C: CA100080 36340080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v55, 0             // 00000043F884: CA100080 38360080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v57, 0             // 00000043F88C: CA100080 3A380080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v59, 0             // 00000043F894: CA100080 3C3A0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0             // 00000043F89C: CA100080 3E3C0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 00000043F8A4: CA100080 403E0080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 00000043F8AC: CA100080 42400080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v67, 0             // 00000043F8B4: CA100080 44420080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v69, 0             // 00000043F8BC: CA100080 46440080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v71, 0             // 00000043F8C4: CA100080 48460080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0             // 00000043F8CC: CA100080 4A480080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v75, 0             // 00000043F8D4: CA100080 4C4A0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v77, 0             // 00000043F8DC: CA100080 4E4C0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v79, 0             // 00000043F8E4: CA100080 504E0080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v81, 0             // 00000043F8EC: CA100080 52500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0             // 00000043F8F4: CA100080 54520080
	v_mov_b32_e32 v86, 0                                       // 00000043F8FC: 7EAC0280
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v95, 0             // 00000043F900: CA100080 585E0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v97, 0             // 00000043F908: CA100080 5C600080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v99, 0             // 00000043F910: CA100080 5E620080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v85, 0             // 00000043F918: CA100080 62540080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v90, 0             // 00000043F920: CA100080 575A0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v96, 0             // 00000043F928: CA100080 59600080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v100, 0            // 00000043F930: CA100080 5D640080
	v_mov_b32_e32 v91, 0                                       // 00000043F938: 7EB60280
	s_mov_b32 s5, 0                                            // 00000043F93C: BE850080
	s_movk_i32 s6, 0x1eee                                      // 00000043F940: B0061EEE
	s_branch 1121                                              // 00000043F944: BFA00461 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1fcc>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000043F948: 8C7E077E
	s_waitcnt vmcnt(15)                                        // 00000043F94C: BF893FF7
	v_alignbit_b32 v9, v2, v3, 16                              // 00000043F950: D6160009 02420702
	v_lshl_or_b32 v29, v1, 5, v102                             // 00000043F958: D656001D 05990B01
	s_waitcnt vmcnt(7)                                         // 00000043F960: BF891FF7
	v_bfe_u32 v10, v4, 12, 16                                  // 00000043F964: D610000A 02411904
	v_bfe_u32 v13, v4, 8, 16                                   // 00000043F96C: D610000D 02411104
	v_bfe_u32 v14, v4, 4, 16                                   // 00000043F974: D610000E 02410904
	v_bfe_u32 v1, v9, 12, 16                                   // 00000043F97C: D6100001 02411909
	v_bfe_u32 v2, v9, 8, 16                                    // 00000043F984: D6100002 02411109
	ds_load_b128 v[25:28], v29 offset:5120                     // 00000043F98C: DBFC1400 1900001D
	ds_load_b128 v[21:24], v29 offset:10240                    // 00000043F994: DBFC2800 1500001D
	v_bfe_u32 v30, v9, 4, 16                                   // 00000043F99C: D610001E 02410909
	ds_load_b128 v[17:20], v29                                 // 00000043F9A4: DBFC0000 1100001D
	.long 0xd72c000b                                           // 00000043F9AC: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v1, vcc_lo               // 00000043F9B0: 020202FF 83DCD12D
	.long 0xd72c0010                                           // 00000043F9B8: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v2, vcc_lo               // 00000043F9BC: 020204FF 83DCD12D
	.long 0xd72c008d                                           // 00000043F9C4: D72C008D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v10, vcc_lo              // 00000043F9C8: 020214FF 83DCD12D
	.long 0xd72c001e                                           // 00000043F9D0: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000043F9D4: 02023CFF 83DCD12D
	.long 0xd72c000d                                           // 00000043F9DC: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 00000043F9E0: 02021AFF 83DCD12D
	v_alignbit_b32 v139, v139, v140, 16                        // 00000043F9E8: D616008B 0243198B
	s_waitcnt vmcnt(6)                                         // 00000043F9F0: BF891BF7
	v_bfe_u32 v147, v138, 12, 16                               // 00000043F9F4: D6100093 0241198A
	v_bfe_u32 v148, v138, 8, 16                                // 00000043F9FC: D6100094 0241118A
	v_sad_u8 v32, v11, 0, 0x6400                               // 00000043FA04: D6220020 03FD010B 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 00000043FA10: D6220010 03FD0110 00006400
	v_bfe_u32 v140, v139, 12, 16                               // 00000043FA1C: D610008C 0241198B
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000043FA24: D622001E 03FD011E 00006400
	v_sad_u8 v144, v13, 0, 0x6400                              // 00000043FA30: D6220090 03FD010D 00006400
	v_and_b32_e32 v32, 0xffff, v32                             // 00000043FA3C: 364040FF 0000FFFF
	v_bfe_u32 v146, v139, 8, 16                                // 00000043FA44: D6100092 0241118B
	.long 0xd72c008c                                           // 00000043FA4C: D72C008C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v140, vcc_lo             // 00000043FA50: 020318FF 83DCD12D
	v_bfe_u32 v149, v138, 4, 16                                // 00000043FA58: D6100095 0241098A
	.long 0xd72c0093                                           // 00000043FA60: D72C0093
	v_cndmask_b32_e32 v1, 0x83dcd12d, v147, vcc_lo             // 00000043FA64: 020326FF 83DCD12D
	v_lshl_or_b32 v32, v16, 16, v32                            // 00000043FA6C: D6560020 04812110
	.long 0xd72c0092                                           // 00000043FA74: D72C0092
	v_cndmask_b32_e32 v1, 0x83dcd12d, v146, vcc_lo             // 00000043FA78: 020324FF 83DCD12D
	.long 0xd72c0094                                           // 00000043FA80: D72C0094
	v_cndmask_b32_e32 v1, 0x83dcd12d, v148, vcc_lo             // 00000043FA84: 020328FF 83DCD12D
	v_alignbit_b32 v136, v136, v137, 16                        // 00000043FA8C: D6160088 02431388
	v_alignbit_b32 v133, v133, v134, 16                        // 00000043FA94: D6160085 02430D85
	v_pk_fma_f16 v145, v32, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000043FA9C: CC0E0091 0BFC0D20 0000C931
	v_and_b32_e32 v15, 0xffff, v4                              // 00000043FAA8: 361E08FF 0000FFFF
	ds_load_b128 v[1:4], v29 offset:15360                      // 00000043FAB0: DBFC3C00 0100001D
	ds_load_b128 v[5:8], v29 offset:20480                      // 00000043FAB8: DBFC5000 0500001D
	v_sad_u8 v140, v140, 0, 0x6400                             // 00000043FAC0: D622008C 03FD018C 00006400
	v_sad_u8 v146, v146, 0, 0x6400                             // 00000043FACC: D6220092 03FD0192 00006400
	s_waitcnt lgkmcnt(3)                                       // 00000043FAD8: BF89FC37
	v_dot2acc_f32_f16 v91, v145, v21                           // 00000043FADC: 04B62B91
	v_and_b32_e32 v12, 0xffff, v9                              // 00000043FAE0: 361812FF 0000FFFF
	.long 0xd72c008e                                           // 00000043FAE8: D72C008E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000043FAEC: 02021EFF 83DCD12D
	v_sad_u8 v15, v141, 0, 0x6400                              // 00000043FAF4: D622000F 03FD018D 00006400
	.long 0xd72c008d                                           // 00000043FB00: D72C008D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 00000043FB04: 02021CFF 83DCD12D
	v_sad_u8 v147, v147, 0, 0x6400                             // 00000043FB0C: D6220093 03FD0193 00006400
	.long 0xd72c001f                                           // 00000043FB18: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 00000043FB1C: 020218FF 83DCD12D
	ds_load_b128 v[9:12], v29 offset:25600                     // 00000043FB24: DBFC6400 0900001D
	v_bfe_u32 v137, v136, 12, 16                               // 00000043FB2C: D6100089 02411988
	v_bfe_u32 v134, v133, 12, 16                               // 00000043FB34: D6100086 02411985
	v_sad_u8 v142, v142, 0, 0x6400                             // 00000043FB3C: D622008E 03FD018E 00006400
	v_alignbit_b32 v130, v130, v131, 16                        // 00000043FB48: D6160082 02430782
	v_sad_u8 v32, v141, 0, 0x6400                              // 00000043FB50: D6220020 03FD018D 00006400
	.long 0xd72c0089                                           // 00000043FB5C: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 00000043FB60: 020312FF 83DCD12D
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000043FB68: D622001F 03FD011F 00006400
	v_lshlrev_b32_e32 v141, 16, v142                           // 00000043FB74: 311B1C90
	.long 0xd72c0086                                           // 00000043FB78: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 00000043FB7C: 02030CFF 83DCD12D
	v_bfe_u32 v131, v130, 12, 16                               // 00000043FB84: D6100083 02411982
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043FB8C: BF870234
	v_dual_dot2acc_f32_f16 v96, v145, v25 :: v_dual_lshlrev_b32 v31, 16, v31// 00000043FB90: CB223391 601E3E90
	v_alignbit_b32 v127, v127, v128, 16                        // 00000043FB98: D616007F 0243017F
	v_sad_u8 v137, v137, 0, 0x6400                             // 00000043FBA0: D6220089 03FD0189 00006400
	.long 0xd72c0083                                           // 00000043FBAC: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 00000043FBB0: 020306FF 83DCD12D
	v_alignbit_b32 v124, v124, v125, 16                        // 00000043FBB8: D616007C 0242FB7C
	v_and_or_b32 v30, 0xffff, v30, v31                         // 00000043FBC0: D657001E 047E3CFF 0000FFFF
	v_sad_u8 v134, v134, 0, 0x6400                             // 00000043FBCC: D6220086 03FD0186 00006400
	v_bfe_u32 v128, v127, 12, 16                               // 00000043FBD8: D6100080 0241197F
	v_alignbit_b32 v116, v116, v122, 16                        // 00000043FBE0: D6160074 0242F574
	v_bfe_u32 v125, v124, 12, 16                               // 00000043FBE8: D610007D 0241197C
	v_pk_fma_f16 v142, v30, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000043FBF0: CC0E008E 0BFC0D1E 0000C931
	v_and_b32_e32 v143, 0xffff, v15                            // 00000043FBFC: 371E1EFF 0000FFFF
	ds_load_b128 v[13:16], v29 offset:35840                    // 00000043FC04: DBFC8C00 0D00001D
	s_waitcnt lgkmcnt(4)                                       // 00000043FC0C: BF89FC47
	v_dot2acc_f32_f16 v100, v145, v17                          // 00000043FC10: 04C82391
	s_waitcnt lgkmcnt(2)                                       // 00000043FC14: BF89FC27
	v_dual_dot2acc_f32_f16 v93, v145, v5 :: v_dual_dot2acc_f32_f16 v96, v142, v26// 00000043FC18: CB180B91 5D60358E
	v_dot2acc_f32_f16 v91, v142, v22                           // 00000043FC20: 04B62D8E
	v_sad_u8 v131, v131, 0, 0x6400                             // 00000043FC24: D6220083 03FD0183 00006400
	v_dot2acc_f32_f16 v100, v142, v18                          // 00000043FC30: 04C8258E
	v_lshl_or_b32 v31, v144, 16, v143                          // 00000043FC34: D656001F 063D2190
	.long 0xd72c0080                                           // 00000043FC3C: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 00000043FC40: 020300FF 83DCD12D
	.long 0xd72c007d                                           // 00000043FC48: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000043FC4C: 0202FAFF 83DCD12D
	v_bfe_u32 v122, v116, 12, 16                               // 00000043FC54: D610007A 02411974
	v_cmp_eq_u32_e32 vcc_lo, v33, v101                         // 00000043FC5C: 7C94CB21
	v_pk_fma_f16 v143, v31, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000043FC60: CC0E008F 0BFC0D1F 0000C931
	v_dot2acc_f32_f16 v90, v145, v1                            // 00000043FC6C: 04B40391
	s_waitcnt lgkmcnt(1)                                       // 00000043FC70: BF89FC17
	v_dot2acc_f32_f16 v89, v145, v9                            // 00000043FC74: 04B21391
	.long 0xd72c007a                                           // 00000043FC78: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 00000043FC7C: 0202F4FF 83DCD12D
	v_sad_u8 v128, v128, 0, 0x6400                             // 00000043FC84: D6220080 03FD0180 00006400
	v_dot2acc_f32_f16 v100, v143, v19                          // 00000043FC90: 04C8278F
	v_and_or_b32 v30, 0xffff, v32, v141                        // 00000043FC94: D657001E 063640FF 0000FFFF
	v_dot2acc_f32_f16 v91, v143, v23                           // 00000043FCA0: 04B62F8F
	v_dot2acc_f32_f16 v96, v143, v27                           // 00000043FCA4: 04C0378F
	v_sad_u8 v125, v125, 0, 0x6400                             // 00000043FCA8: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v93, v142, v6                            // 00000043FCB4: 04BA0D8E
	v_pk_fma_f16 v141, v30, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000043FCB8: CC0E008D 0BFC0D1E 0000C931
	v_dot2acc_f32_f16 v90, v142, v2                            // 00000043FCC4: 04B4058E
	ds_load_b128 v[29:32], v29 offset:30720                    // 00000043FCC8: DBFC7800 1D00001D
	v_dot2acc_f32_f16 v89, v142, v10                           // 00000043FCD0: 04B2158E
	v_dual_dot2acc_f32_f16 v93, v143, v7 :: v_dual_dot2acc_f32_f16 v100, v141, v20// 00000043FCD4: CB180F8F 5D64298D
	v_dot2acc_f32_f16 v96, v141, v28                           // 00000043FCDC: 04C0398D
	v_dual_dot2acc_f32_f16 v90, v143, v3 :: v_dual_dot2acc_f32_f16 v91, v141, v24// 00000043FCE0: CB18078F 5A5A318D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000043FCE8: BF8701A3
	v_dual_dot2acc_f32_f16 v93, v141, v8 :: v_dual_and_b32 v144, 0xffff, v139// 00000043FCEC: CB24118D 5D9116FF 0000FFFF
	v_bfe_u32 v139, v139, 4, 16                                // 00000043FCF8: D610008B 0241098B
	v_dual_dot2acc_f32_f16 v89, v143, v11 :: v_dual_dot2acc_f32_f16 v90, v141, v4// 00000043FD00: CB18178F 595A098D
	v_and_b32_e32 v138, 0xffff, v138                           // 00000043FD08: 371514FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043FD10: BF870214
	.long 0xd72c0090                                           // 00000043FD14: D72C0090
	v_cndmask_b32_e32 v1, 0x83dcd12d, v144, vcc_lo             // 00000043FD18: 020320FF 83DCD12D
	.long 0xd72c008b                                           // 00000043FD20: D72C008B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v139, vcc_lo             // 00000043FD24: 020316FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043FD2C: BF870004
	v_dot2acc_f32_f16 v89, v141, v12                           // 00000043FD30: 04B2198D
	v_and_b32_e32 v140, 0xffff, v140                           // 00000043FD34: 371918FF 0000FFFF
	.long 0xd72c008a                                           // 00000043FD3C: D72C008A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 00000043FD40: 020314FF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 00000043FD48: D622007A 03FD017A 00006400
	s_or_b32 s5, vcc_lo, s5                                    // 00000043FD54: 8C05056A
	s_waitcnt lgkmcnt(0)                                       // 00000043FD58: BF89FC07
	v_dot2acc_f32_f16 v87, v145, v29                           // 00000043FD5C: 04AE3B91
	v_sad_u8 v144, v144, 0, 0x6400                             // 00000043FD60: D6220090 03FD0190 00006400
	v_sad_u8 v139, v139, 0, 0x6400                             // 00000043FD6C: D622008B 03FD018B 00006400
	v_lshl_or_b32 v140, v146, 16, v140                         // 00000043FD78: D656008C 06312192
	v_dot2acc_f32_f16 v85, v145, v13                           // 00000043FD80: 04AA1B91
	v_sad_u8 v138, v138, 0, 0x6400                             // 00000043FD84: D622008A 03FD018A 00006400
	v_lshlrev_b32_e32 v144, 16, v144                           // 00000043FD90: 31212090
	v_and_b32_e32 v134, 0xffff, v134                           // 00000043FD94: 370D0CFF 0000FFFF
	v_pk_fma_f16 v140, v140, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000043FD9C: CC0E008C 0BFC0D8C 0000C931
	v_and_b32_e32 v146, 0xffff, v147                           // 00000043FDA8: 372526FF 0000FFFF
	v_sad_u8 v147, v148, 0, 0x6400                             // 00000043FDB0: D6220093 03FD0194 00006400
	v_and_or_b32 v139, 0xffff, v139, v144                      // 00000043FDBC: D657008B 064316FF 0000FFFF
	.long 0xd72c0090                                           // 00000043FDC8: D72C0090
	v_cndmask_b32_e32 v1, 0x83dcd12d, v149, vcc_lo             // 00000043FDCC: 02032AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v87, v142, v30 :: v_dual_dot2acc_f32_f16 v98, v140, v25// 00000043FDD4: CB183D8E 5762338C
	v_lshlrev_b32_e32 v138, 16, v138                           // 00000043FDDC: 31151490
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043FDE0: BF870004
	v_pk_fma_f16 v139, v139, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000043FDE4: CC0E008B 0BFC0D8B 0000C931
	v_dot2acc_f32_f16 v99, v140, v17                           // 00000043FDF0: 04C6238C
	v_lshl_or_b32 v145, v147, 16, v146                         // 00000043FDF4: D6560091 06492193
	v_dot2acc_f32_f16 v87, v143, v31                           // 00000043FDFC: 04AE3F8F
	v_sad_u8 v144, v144, 0, 0x6400                             // 00000043FE00: D6220090 03FD0190 00006400
	v_dual_dot2acc_f32_f16 v85, v142, v14 :: v_dual_dot2acc_f32_f16 v94, v140, v5// 00000043FE0C: CB181D8E 555E0B8C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043FE14: BF870214
	v_pk_fma_f16 v142, v145, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000043FE18: CC0E008E 0BFC0D91 0000C931
	v_dual_dot2acc_f32_f16 v87, v141, v32 :: v_dual_dot2acc_f32_f16 v98, v139, v26// 00000043FE24: CB18418D 5762358B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000043FE2C: BF870234
	v_and_or_b32 v138, 0xffff, v144, v138                      // 00000043FE30: D657008A 062B20FF 0000FFFF
	v_dot2acc_f32_f16 v99, v139, v18                           // 00000043FE3C: 04C6258B
	v_dual_dot2acc_f32_f16 v85, v143, v15 :: v_dual_dot2acc_f32_f16 v92, v140, v9// 00000043FE40: CB181F8F 555C138C
	v_dot2acc_f32_f16 v98, v142, v27                           // 00000043FE48: 04C4378E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000043FE4C: BF870254
	v_pk_fma_f16 v138, v138, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000043FE50: CC0E008A 0BFC0D8A 0000C931
	v_dot2acc_f32_f16 v97, v140, v21                           // 00000043FE5C: 04C22B8C
	v_bfe_u32 v143, v136, 8, 16                                // 00000043FE60: D610008F 02411188
	v_dual_dot2acc_f32_f16 v99, v142, v19 :: v_dual_dot2acc_f32_f16 v94, v139, v6// 00000043FE68: CB18278E 635E0D8B
	v_dual_dot2acc_f32_f16 v85, v141, v16 :: v_dual_dot2acc_f32_f16 v92, v139, v10// 00000043FE70: CB18218D 555C158B
	v_dual_dot2acc_f32_f16 v98, v138, v28 :: v_dual_dot2acc_f32_f16 v97, v139, v22// 00000043FE78: CB18398A 62602D8B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043FE80: BF870214
	.long 0xd72c008f                                           // 00000043FE84: D72C008F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v143, vcc_lo             // 00000043FE88: 02031EFF 83DCD12D
	v_dual_dot2acc_f32_f16 v99, v138, v20 :: v_dual_dot2acc_f32_f16 v88, v140, v29// 00000043FE90: CB18298A 63583B8C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000043FE98: BF870214
	v_dot2acc_f32_f16 v92, v142, v11                           // 00000043FE9C: 04B8178E
	v_dual_dot2acc_f32_f16 v97, v142, v23 :: v_dual_dot2acc_f32_f16 v86, v140, v13// 00000043FEA0: CB182F8E 61561B8C
	v_dual_dot2acc_f32_f16 v95, v140, v1 :: v_dual_dot2acc_f32_f16 v94, v142, v7// 00000043FEA8: CB18038C 5F5E0F8E
	v_sad_u8 v143, v143, 0, 0x6400                             // 00000043FEB0: D622008F 03FD018F 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000043FEBC: BF870223
	v_dual_dot2acc_f32_f16 v97, v138, v24 :: v_dual_dot2acc_f32_f16 v88, v139, v30// 00000043FEC0: CB18318A 61583D8B
	v_and_b32_e32 v137, 0xffff, v137                           // 00000043FEC8: 371312FF 0000FFFF
	v_dual_dot2acc_f32_f16 v95, v139, v2 :: v_dual_dot2acc_f32_f16 v94, v138, v8// 00000043FED0: CB18058B 5F5E118A
	s_waitcnt vmcnt(5)                                         // 00000043FED8: BF8917F7
	v_bfe_u32 v144, v135, 12, 16                               // 00000043FEDC: D6100090 02411987
	v_dot2acc_f32_f16 v88, v142, v31                           // 00000043FEE4: 04B03F8E
	v_lshl_or_b32 v137, v143, 16, v137                         // 00000043FEE8: D6560089 0625218F
	v_dot2acc_f32_f16 v86, v139, v14                           // 00000043FEF0: 04AC1D8B
	v_bfe_u32 v145, v135, 8, 16                                // 00000043FEF4: D6100091 02411187
	.long 0xd72c0090                                           // 00000043FEFC: D72C0090
	v_cndmask_b32_e32 v1, 0x83dcd12d, v144, vcc_lo             // 00000043FF00: 020320FF 83DCD12D
	v_dot2acc_f32_f16 v92, v138, v12                           // 00000043FF08: 04B8198A
	v_pk_fma_f16 v137, v137, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000043FF0C: CC0E0089 0BFC0D89 0000C931
	v_dot2acc_f32_f16 v95, v142, v3                            // 00000043FF18: 04BE078E
	v_dot2acc_f32_f16 v86, v142, v15                           // 00000043FF1C: 04AC1F8E
	v_bfe_u32 v146, v135, 4, 16                                // 00000043FF20: D6100092 02410987
	s_delay_alu instid0(VALU_DEP_4)                            // 00000043FF28: BF870004
	v_dual_dot2acc_f32_f16 v84, v137, v17 :: v_dual_and_b32 v135, 0xffff, v135// 00000043FF2C: CB242389 54870EFF 0000FFFF
	v_and_b32_e32 v141, 0xffff, v136                           // 00000043FF38: 371B10FF 0000FFFF
	v_bfe_u32 v136, v136, 4, 16                                // 00000043FF40: D6100088 02410988
	v_dot2acc_f32_f16 v95, v138, v4                            // 00000043FF48: 04BE098A
	.long 0xd72c0091                                           // 00000043FF4C: D72C0091
	v_cndmask_b32_e32 v1, 0x83dcd12d, v145, vcc_lo             // 00000043FF50: 020322FF 83DCD12D
	v_sad_u8 v144, v144, 0, 0x6400                             // 00000043FF58: D6220090 03FD0190 00006400
	.long 0xd72c008d                                           // 00000043FF64: D72C008D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v141, vcc_lo             // 00000043FF68: 02031AFF 83DCD12D
	.long 0xd72c0088                                           // 00000043FF70: D72C0088
	v_cndmask_b32_e32 v1, 0x83dcd12d, v136, vcc_lo             // 00000043FF74: 020310FF 83DCD12D
	.long 0xd72c0087                                           // 00000043FF7C: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 00000043FF80: 02030EFF 83DCD12D
	.long 0xd72c008c                                           // 00000043FF88: D72C008C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v146, vcc_lo             // 00000043FF8C: 020324FF 83DCD12D
	v_dual_dot2acc_f32_f16 v83, v137, v25 :: v_dual_dot2acc_f32_f16 v86, v138, v16// 00000043FF94: CB183389 5356218A
	v_sad_u8 v143, v145, 0, 0x6400                             // 00000043FF9C: D622008F 03FD0191 00006400
	v_dot2acc_f32_f16 v88, v138, v32                           // 00000043FFA8: 04B0418A
	v_sad_u8 v141, v141, 0, 0x6400                             // 00000043FFAC: D622008D 03FD018D 00006400
	v_sad_u8 v136, v136, 0, 0x6400                             // 00000043FFB8: D6220088 03FD0188 00006400
	v_sad_u8 v135, v135, 0, 0x6400                             // 00000043FFC4: D6220087 03FD0187 00006400
	v_sad_u8 v140, v140, 0, 0x6400                             // 00000043FFD0: D622008C 03FD018C 00006400
	v_dot2acc_f32_f16 v81, v137, v1                            // 00000043FFDC: 04A20389
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000043FFE0: 311B1A90
	v_and_b32_e32 v138, 0xffff, v133                           // 00000043FFE4: 37150AFF 0000FFFF
	v_lshlrev_b32_e32 v135, 16, v135                           // 00000043FFEC: 310F0E90
	v_dot2acc_f32_f16 v77, v137, v13                           // 00000043FFF0: 049A1B89
	s_waitcnt vmcnt(4)                                         // 00000043FFF4: BF8913F7
	v_bfe_u32 v142, v132, 8, 16                                // 00000043FFF8: D610008E 02411184
	v_and_or_b32 v136, 0xffff, v136, v141                      // 000000440000: D6570088 063710FF 0000FFFF
	.long 0xd72c008a                                           // 00000044000C: D72C008A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 000000440010: 020314FF 83DCD12D
	v_and_or_b32 v135, 0xffff, v140, v135                      // 000000440018: D6570087 061F18FF 0000FFFF
	v_bfe_u32 v140, v133, 8, 16                                // 000000440024: D610008C 02411185
	v_bfe_u32 v133, v133, 4, 16                                // 00000044002C: D6100085 02410985
	v_pk_fma_f16 v136, v136, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440034: CC0E0088 0BFC0D88 0000C931
	v_dot2acc_f32_f16 v82, v137, v21                           // 000000440040: 04A42B89
	v_pk_fma_f16 v135, v135, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440044: CC0E0087 0BFC0D87 0000C931
	v_dot2acc_f32_f16 v80, v137, v5                            // 000000440050: 04A00B89
	.long 0xd72c008c                                           // 000000440054: D72C008C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v140, vcc_lo             // 000000440058: 020318FF 83DCD12D
	v_dual_dot2acc_f32_f16 v84, v136, v18 :: v_dual_and_b32 v141, 0xffff, v144// 000000440060: CB242588 548D20FF 0000FFFF
	v_dot2acc_f32_f16 v83, v136, v26                           // 00000044006C: 04A63588
	v_dot2acc_f32_f16 v81, v136, v2                            // 000000440070: 04A20588
	.long 0xd72c0085                                           // 000000440074: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 000000440078: 02030AFF 83DCD12D
	v_dot2acc_f32_f16 v78, v137, v29                           // 000000440080: 049C3B89
	v_lshl_or_b32 v141, v143, 16, v141                         // 000000440084: D656008D 0635218F
	v_sad_u8 v140, v140, 0, 0x6400                             // 00000044008C: D622008C 03FD018C 00006400
	v_bfe_u32 v143, v132, 4, 16                                // 000000440098: D610008F 02410984
	.long 0xd72c008e                                           // 0000004400A0: D72C008E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v142, vcc_lo             // 0000004400A4: 02031CFF 83DCD12D
	v_dot2acc_f32_f16 v77, v136, v14                           // 0000004400AC: 049A1D88
	v_pk_fma_f16 v139, v141, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004400B0: CC0E008B 0BFC0D8D 0000C931
	v_dot2acc_f32_f16 v82, v136, v22                           // 0000004400BC: 04A42D88
	v_bfe_u32 v141, v132, 12, 16                               // 0000004400C0: D610008D 02411984
	v_and_b32_e32 v132, 0xffff, v132                           // 0000004400C8: 370908FF 0000FFFF
	v_lshl_or_b32 v134, v140, 16, v134                         // 0000004400D0: D6560086 0619218C
	v_dot2acc_f32_f16 v83, v139, v27                           // 0000004400D8: 04A6378B
	v_dual_dot2acc_f32_f16 v79, v137, v9 :: v_dual_dot2acc_f32_f16 v82, v139, v23// 0000004400DC: CB181389 4F522F8B
	v_dot2acc_f32_f16 v84, v139, v19                           // 0000004400E4: 04A8278B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004400E8: BF870193
	v_dual_dot2acc_f32_f16 v80, v136, v6 :: v_dual_dot2acc_f32_f16 v83, v135, v28// 0000004400EC: CB180D88 50523987
	v_dual_dot2acc_f32_f16 v79, v136, v10 :: v_dual_dot2acc_f32_f16 v82, v135, v24// 0000004400F4: CB181588 4F523187
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004400FC: BF870193
	v_dot2acc_f32_f16 v84, v135, v20                           // 000000440100: 04A82987
	v_dot2acc_f32_f16 v80, v139, v7                            // 000000440104: 04A00F8B
	.long 0xd72c008d                                           // 000000440108: D72C008D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v141, vcc_lo             // 00000044010C: 02031AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000440114: BF870004
	v_dot2acc_f32_f16 v79, v139, v11                           // 000000440118: 049E178B
	v_dot2acc_f32_f16 v81, v139, v3                            // 00000044011C: 04A2078B
	v_sad_u8 v138, v138, 0, 0x6400                             // 000000440120: D622008A 03FD018A 00006400
	v_dot2acc_f32_f16 v80, v135, v8                            // 00000044012C: 04A01187
	v_sad_u8 v133, v133, 0, 0x6400                             // 000000440130: D6220085 03FD0185 00006400
	v_dot2acc_f32_f16 v79, v135, v12                           // 00000044013C: 049E1987
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000440140: BF870244
	v_dual_dot2acc_f32_f16 v77, v139, v15 :: v_dual_lshlrev_b32 v138, 16, v138// 000000440144: CB221F8B 4D8B1490
	.long 0xd72c0084                                           // 00000044014C: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 000000440150: 020308FF 83DCD12D
	v_dual_dot2acc_f32_f16 v81, v135, v4 :: v_dual_dot2acc_f32_f16 v78, v136, v30// 000000440158: CB180987 514E3D88
	v_sad_u8 v141, v141, 0, 0x6400                             // 000000440160: D622008D 03FD018D 00006400
	v_and_or_b32 v133, 0xffff, v133, v138                      // 00000044016C: D6570085 062B0AFF 0000FFFF
	v_pk_fma_f16 v134, v134, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440178: CC0E0086 0BFC0D86 0000C931
	.long 0xd72c0089                                           // 000000440184: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v143, vcc_lo             // 000000440188: 02031EFF 83DCD12D
	v_dot2acc_f32_f16 v78, v139, v31                           // 000000440190: 049C3F8B
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000440194: D6220084 03FD0184 00006400
	v_sad_u8 v140, v142, 0, 0x6400                             // 0000004401A0: D622008C 03FD018E 00006400
	v_pk_fma_f16 v133, v133, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004401AC: CC0E0085 0BFC0D85 0000C931
	v_dot2acc_f32_f16 v75, v134, v25                           // 0000004401B8: 04963386
	v_and_b32_e32 v138, 0xffff, v141                           // 0000004401BC: 37151AFF 0000FFFF
	v_dual_dot2acc_f32_f16 v73, v134, v1 :: v_dual_lshlrev_b32 v132, 16, v132// 0000004401C4: CB220386 49850890
	v_sad_u8 v137, v137, 0, 0x6400                             // 0000004401CC: D6220089 03FD0189 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004401D8: BF870214
	v_dot2acc_f32_f16 v75, v133, v26                           // 0000004401DC: 04963585
	v_lshl_or_b32 v138, v140, 16, v138                         // 0000004401E0: D656008A 0629218C
	v_dual_dot2acc_f32_f16 v76, v134, v17 :: v_dual_dot2acc_f32_f16 v77, v135, v16// 0000004401E8: CB182386 4C4C2187
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004401F0: BF870224
	v_and_or_b32 v132, 0xffff, v137, v132                      // 0000004401F4: D6570084 061312FF 0000FFFF
	v_dual_dot2acc_f32_f16 v74, v134, v21 :: v_dual_dot2acc_f32_f16 v73, v133, v2// 000000440200: CB182B86 4A480585
	v_pk_fma_f16 v136, v138, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440208: CC0E0088 0BFC0D8A 0000C931
	v_bfe_u32 v137, v130, 8, 16                                // 000000440214: D6100089 02411182
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044021C: BF870214
	v_pk_fma_f16 v132, v132, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440220: CC0E0084 0BFC0D84 0000C931
	v_dual_dot2acc_f32_f16 v74, v133, v22 :: v_dual_dot2acc_f32_f16 v69, v134, v13// 00000044022C: CB182D85 4A441B86
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000440234: BF8701B4
	v_dual_dot2acc_f32_f16 v75, v136, v27 :: v_dual_dot2acc_f32_f16 v76, v133, v18// 000000440238: CB183788 4B4C2585
	v_dual_dot2acc_f32_f16 v71, v134, v9 :: v_dual_dot2acc_f32_f16 v78, v135, v32// 000000440240: CB181386 474E4187
	v_dot2acc_f32_f16 v73, v136, v3                            // 000000440248: 04920788
	v_dot2acc_f32_f16 v75, v132, v28                           // 00000044024C: 04963984
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440250: BF870214
	v_dual_dot2acc_f32_f16 v76, v136, v19 :: v_dual_and_b32 v135, 0xffff, v130// 000000440254: CB242788 4C8704FF 0000FFFF
	v_dual_dot2acc_f32_f16 v71, v133, v10 :: v_dual_dot2acc_f32_f16 v72, v134, v5// 000000440260: CB181585 47480B86
	v_dot2acc_f32_f16 v74, v136, v23                           // 000000440268: 04942F88
	s_delay_alu instid0(VALU_DEP_3)                            // 00000044026C: BF870003
	v_dot2acc_f32_f16 v76, v132, v20                           // 000000440270: 04982984
	v_dual_dot2acc_f32_f16 v70, v134, v29 :: v_dual_dot2acc_f32_f16 v73, v132, v4// 000000440274: CB183B86 46480984
	v_bfe_u32 v130, v130, 4, 16                                // 00000044027C: D6100082 02410982
	.long 0xd72c0087                                           // 000000440284: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 000000440288: 02030EFF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 000000440290: BF890FF7
	v_bfe_u32 v134, v129, 12, 16                               // 000000440294: D6100086 02411981
	.long 0xd72c0089                                           // 00000044029C: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 0000004402A0: 020312FF 83DCD12D
	v_dual_dot2acc_f32_f16 v71, v136, v11 :: v_dual_dot2acc_f32_f16 v72, v133, v6// 0000004402A8: CB181788 47480D85
	v_dot2acc_f32_f16 v74, v132, v24                           // 0000004402B0: 04943184
	v_bfe_u32 v138, v129, 8, 16                                // 0000004402B4: D610008A 02411181
	.long 0xd72c0082                                           // 0000004402BC: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000004402C0: 020304FF 83DCD12D
	v_bfe_u32 v139, v129, 4, 16                                // 0000004402C8: D610008B 02410981
	.long 0xd72c0086                                           // 0000004402D0: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 0000004402D4: 02030CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v70, v133, v30 :: v_dual_and_b32 v129, 0xffff, v129// 0000004402DC: CB243D85 468102FF 0000FFFF
	v_and_b32_e32 v131, 0xffff, v131                           // 0000004402E8: 370706FF 0000FFFF
	v_dot2acc_f32_f16 v71, v132, v12                           // 0000004402F0: 048E1984
	v_dual_dot2acc_f32_f16 v72, v136, v7 :: v_dual_dot2acc_f32_f16 v69, v133, v14// 0000004402F4: CB180F88 48441D85
	v_sad_u8 v135, v135, 0, 0x6400                             // 0000004402FC: D6220087 03FD0187 00006400
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000440308: D6220089 03FD0189 00006400
	.long 0xd72c0081                                           // 000000440314: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000440318: 020302FF 83DCD12D
	.long 0xd72c008a                                           // 000000440320: D72C008A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 000000440324: 020314FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044032C: BF870004
	v_dual_dot2acc_f32_f16 v72, v132, v8 :: v_dual_lshlrev_b32 v135, 16, v135// 000000440330: CB221184 48870E90
	v_sad_u8 v130, v130, 0, 0x6400                             // 000000440338: D6220082 03FD0182 00006400
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000440344: D6220086 03FD0186 00006400
	v_lshl_or_b32 v131, v137, 16, v131                         // 000000440350: D6560083 060D2189
	.long 0xd72c0085                                           // 000000440358: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v139, vcc_lo             // 00000044035C: 020316FF 83DCD12D
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000440364: D6220081 03FD0181 00006400
	v_dot2acc_f32_f16 v70, v136, v31                           // 000000440370: 048C3F88
	v_and_or_b32 v130, 0xffff, v130, v135                      // 000000440374: D6570082 061F04FF 0000FFFF
	v_dual_dot2acc_f32_f16 v69, v136, v15 :: v_dual_and_b32 v134, 0xffff, v134// 000000440380: CB241F88 45870CFF 0000FFFF
	v_sad_u8 v135, v138, 0, 0x6400                             // 00000044038C: D6220087 03FD018A 00006400
	v_pk_fma_f16 v131, v131, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440398: CC0E0083 0BFC0D83 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004403A4: BF870234
	v_pk_fma_f16 v130, v130, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004403A8: CC0E0082 0BFC0D82 0000C931
	v_sad_u8 v133, v133, 0, 0x6400                             // 0000004403B4: D6220085 03FD0185 00006400
	v_dual_dot2acc_f32_f16 v70, v132, v32 :: v_dual_lshlrev_b32 v129, 16, v129// 0000004403C0: CB224184 46810290
	v_dot2acc_f32_f16 v67, v131, v25                           // 0000004403C8: 04863383
	v_lshl_or_b32 v134, v135, 16, v134                         // 0000004403CC: D6560086 06192187
	v_dot2acc_f32_f16 v68, v131, v17                           // 0000004403D4: 04882383
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004403D8: BF870004
	v_and_or_b32 v129, 0xffff, v133, v129                      // 0000004403DC: D6570081 06070AFF 0000FFFF
	v_dot2acc_f32_f16 v69, v132, v16                           // 0000004403E8: 048A2184
	v_dot2acc_f32_f16 v67, v130, v26                           // 0000004403EC: 04863582
	v_pk_fma_f16 v133, v134, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004403F0: CC0E0085 0BFC0D86 0000C931
	v_dot2acc_f32_f16 v68, v130, v18                           // 0000004403FC: 04882582
	v_pk_fma_f16 v129, v129, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440400: CC0E0081 0BFC0D81 0000C931
	v_dot2acc_f32_f16 v65, v131, v1                            // 00000044040C: 04820383
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440410: BF870214
	v_dual_dot2acc_f32_f16 v66, v131, v21 :: v_dual_dot2acc_f32_f16 v67, v133, v27// 000000440414: CB182B83 42423785
	v_dot2acc_f32_f16 v68, v133, v19                           // 00000044041C: 04882785
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000440420: BF870223
	v_dual_dot2acc_f32_f16 v64, v131, v5 :: v_dual_dot2acc_f32_f16 v65, v130, v2// 000000440424: CB180B83 40400582
	v_bfe_u32 v134, v127, 8, 16                                // 00000044042C: D6100086 0241117F
	v_dual_dot2acc_f32_f16 v66, v130, v22 :: v_dual_dot2acc_f32_f16 v63, v131, v9// 000000440434: CB182D82 423E1383
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044043C: BF870214
	v_dot2acc_f32_f16 v68, v129, v20                           // 000000440440: 04882981
	v_dual_dot2acc_f32_f16 v67, v129, v28 :: v_dual_dot2acc_f32_f16 v64, v130, v6// 000000440444: CB183981 43400D82
	v_dot2acc_f32_f16 v65, v133, v3                            // 00000044044C: 04820785
	.long 0xd72c0086                                           // 000000440450: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 000000440454: 02030CFF 83DCD12D
	v_dual_dot2acc_f32_f16 v66, v133, v23 :: v_dual_dot2acc_f32_f16 v63, v130, v10// 00000044045C: CB182F85 423E1582
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440464: BF870214
	v_dual_dot2acc_f32_f16 v64, v133, v7 :: v_dual_dot2acc_f32_f16 v61, v131, v13// 000000440468: CB180F85 403C1B83
	v_dual_dot2acc_f32_f16 v65, v129, v4 :: v_dual_and_b32 v132, 0xffff, v127// 000000440470: CB240981 4184FEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044047C: BF870223
	v_dot2acc_f32_f16 v66, v129, v24                           // 000000440480: 04843181
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000440484: D6220086 03FD0186 00006400
	v_dual_dot2acc_f32_f16 v61, v130, v14 :: v_dual_and_b32 v128, 0xffff, v128// 000000440490: CB241D82 3D8100FF 0000FFFF
	v_bfe_u32 v127, v127, 4, 16                                // 00000044049C: D610007F 0241097F
	.long 0xd72c0084                                           // 0000004404A4: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 0000004404A8: 020308FF 83DCD12D
	s_waitcnt vmcnt(2)                                         // 0000004404B0: BF890BF7
	v_bfe_u32 v135, v126, 12, 16                               // 0000004404B4: D6100087 0241197E
	v_dot2acc_f32_f16 v61, v133, v15                           // 0000004404BC: 047A1F85
	v_lshl_or_b32 v128, v134, 16, v128                         // 0000004404C0: D6560080 06012186
	.long 0xd72c007f                                           // 0000004404C8: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000004404CC: 0202FEFF 83DCD12D
	v_dot2acc_f32_f16 v63, v133, v11                           // 0000004404D4: 047E1785
	v_bfe_u32 v136, v126, 8, 16                                // 0000004404D8: D6100088 0241117E
	v_bfe_u32 v137, v126, 4, 16                                // 0000004404E0: D6100089 0241097E
	.long 0xd72c0087                                           // 0000004404E8: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 0000004404EC: 02030EFF 83DCD12D
	v_sad_u8 v132, v132, 0, 0x6400                             // 0000004404F4: D6220084 03FD0184 00006400
	v_and_b32_e32 v126, 0xffff, v126                           // 000000440500: 36FCFCFF 0000FFFF
	v_pk_fma_f16 v128, v128, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440508: CC0E0080 0BFC0D80 0000C931
	v_dot2acc_f32_f16 v64, v129, v8                            // 000000440514: 04801181
	v_sad_u8 v127, v127, 0, 0x6400                             // 000000440518: D622007F 03FD017F 00006400
	.long 0xd72c0088                                           // 000000440524: D72C0088
	v_cndmask_b32_e32 v1, 0x83dcd12d, v136, vcc_lo             // 000000440528: 020310FF 83DCD12D
	.long 0xd72c007e                                           // 000000440530: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000440534: 0202FCFF 83DCD12D
	v_dual_dot2acc_f32_f16 v59, v128, v25 :: v_dual_lshlrev_b32 v132, 16, v132// 00000044053C: CB223380 3B850890
	v_sad_u8 v135, v135, 0, 0x6400                             // 000000440544: D6220087 03FD0187 00006400
	v_dual_dot2acc_f32_f16 v62, v131, v29 :: v_dual_dot2acc_f32_f16 v63, v129, v12// 000000440550: CB183B83 3E3E1981
	v_dot2acc_f32_f16 v61, v129, v16                           // 000000440558: 047A2181
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044055C: BF870004
	v_and_or_b32 v127, 0xffff, v127, v132                      // 000000440560: D657007F 0612FEFF 0000FFFF
	.long 0xd72c0084                                           // 00000044056C: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 000000440570: 020312FF 83DCD12D
	v_and_b32_e32 v134, 0xffff, v135                           // 000000440578: 370D0EFF 0000FFFF
	v_sad_u8 v135, v136, 0, 0x6400                             // 000000440580: D6220087 03FD0188 00006400
	v_sad_u8 v126, v126, 0, 0x6400                             // 00000044058C: D622007E 03FD017E 00006400
	v_pk_fma_f16 v127, v127, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440598: CC0E007F 0BFC0D7F 0000C931
	v_dual_dot2acc_f32_f16 v62, v130, v30 :: v_dual_dot2acc_f32_f16 v55, v128, v9// 0000004405A4: CB183D82 3E361380
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004405AC: BF870244
	v_lshl_or_b32 v131, v135, 16, v134                         // 0000004405B0: D6560083 06192187
	v_sad_u8 v132, v132, 0, 0x6400                             // 0000004405B8: D6220084 03FD0184 00006400
	v_dual_dot2acc_f32_f16 v57, v128, v1 :: v_dual_lshlrev_b32 v126, 16, v126// 0000004405C4: CB220380 397EFC90
	v_dot2acc_f32_f16 v59, v127, v26                           // 0000004405CC: 0476357F
	v_pk_fma_f16 v130, v131, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004405D0: CC0E0082 0BFC0D83 0000C931
	v_dot2acc_f32_f16 v60, v128, v17                           // 0000004405DC: 04782380
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004405E0: BF870224
	v_and_or_b32 v126, 0xffff, v132, v126                      // 0000004405E4: D657007E 05FB08FF 0000FFFF
	v_dual_dot2acc_f32_f16 v62, v133, v31 :: v_dual_dot2acc_f32_f16 v57, v127, v2// 0000004405F0: CB183F85 3E38057F
	v_dot2acc_f32_f16 v59, v130, v27                           // 0000004405F8: 04763782
	v_bfe_u32 v131, v124, 8, 16                                // 0000004405FC: D6100083 0241117C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000440604: BF8701B4
	v_pk_fma_f16 v126, v126, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440608: CC0E007E 0BFC0D7E 0000C931
	v_dot2acc_f32_f16 v60, v127, v18                           // 000000440614: 0478257F
	v_dual_dot2acc_f32_f16 v62, v129, v32 :: v_dual_dot2acc_f32_f16 v57, v130, v3// 000000440618: CB184181 3E380782
	v_dual_dot2acc_f32_f16 v56, v128, v5 :: v_dual_dot2acc_f32_f16 v59, v126, v28// 000000440620: CB180B80 383A397E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000440628: BF870193
	v_dual_dot2acc_f32_f16 v60, v130, v19 :: v_dual_dot2acc_f32_f16 v55, v127, v10// 00000044062C: CB182782 3C36157F
	v_dual_dot2acc_f32_f16 v58, v128, v21 :: v_dual_dot2acc_f32_f16 v57, v126, v4// 000000440634: CB182B80 3A38097E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044063C: BF8701A3
	v_dual_dot2acc_f32_f16 v56, v127, v6 :: v_dual_and_b32 v129, 0xffff, v124// 000000440640: CB240D7F 3880F8FF 0000FFFF
	.long 0xd72c0083                                           // 00000044064C: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000440650: 020306FF 83DCD12D
	v_dual_dot2acc_f32_f16 v55, v130, v11 :: v_dual_dot2acc_f32_f16 v58, v127, v22// 000000440658: CB181782 373A2D7F
	v_bfe_u32 v124, v124, 4, 16                                // 000000440660: D610007C 0241097C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000440668: BF870004
	.long 0xd72c0081                                           // 00000044066C: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000440670: 020302FF 83DCD12D
	s_waitcnt vmcnt(1)                                         // 000000440678: BF8907F7
	v_bfe_u32 v132, v123, 12, 16                               // 00000044067C: D6100084 0241197B
	v_dot2acc_f32_f16 v55, v126, v12                           // 000000440684: 046E197E
	v_dual_dot2acc_f32_f16 v58, v130, v23 :: v_dual_and_b32 v125, 0xffff, v125// 000000440688: CB242F82 3A7CFAFF 0000FFFF
	v_sad_u8 v131, v131, 0, 0x6400                             // 000000440694: D6220083 03FD0183 00006400
	v_bfe_u32 v133, v123, 8, 16                                // 0000004406A0: D6100085 0241117B
	.long 0xd72c007c                                           // 0000004406A8: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 0000004406AC: 0202F8FF 83DCD12D
	.long 0xd72c0084                                           // 0000004406B4: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 0000004406B8: 020308FF 83DCD12D
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000004406C0: D6220081 03FD0181 00006400
	v_lshl_or_b32 v125, v131, 16, v125                         // 0000004406CC: D656007D 05F52183
	v_dot2acc_f32_f16 v60, v126, v20                           // 0000004406D4: 0478297E
	v_bfe_u32 v134, v123, 4, 16                                // 0000004406D8: D6100086 0241097B
	v_and_b32_e32 v123, 0xffff, v123                           // 0000004406E0: 36F6F6FF 0000FFFF
	.long 0xd72c0085                                           // 0000004406E8: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 0000004406EC: 02030AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v56, v130, v7 :: v_dual_lshlrev_b32 v129, 16, v129// 0000004406F4: CB220F82 38810290
	v_dual_dot2acc_f32_f16 v58, v126, v24 :: v_dual_dot2acc_f32_f16 v53, v128, v13// 0000004406FC: CB18317E 3A341B80
	v_sad_u8 v124, v124, 0, 0x6400                             // 000000440704: D622007C 03FD017C 00006400
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000440710: D6220084 03FD0184 00006400
	v_dot2acc_f32_f16 v54, v128, v29                           // 00000044071C: 046C3B80
	v_pk_fma_f16 v125, v125, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440720: CC0E007D 0BFC0D7D 0000C931
	.long 0xd72c007b                                           // 00000044072C: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000440730: 0202F6FF 83DCD12D
	v_and_or_b32 v124, 0xffff, v124, v129                      // 000000440738: D657007C 0606F8FF 0000FFFF
	v_and_b32_e32 v131, 0xffff, v132                           // 000000440744: 370708FF 0000FFFF
	v_sad_u8 v132, v133, 0, 0x6400                             // 00000044074C: D6220084 03FD0185 00006400
	v_dual_dot2acc_f32_f16 v52, v125, v17 :: v_dual_dot2acc_f32_f16 v53, v127, v14// 000000440758: CB18237D 34341D7F
	v_dot2acc_f32_f16 v54, v127, v30                           // 000000440760: 046C3D7F
	.long 0xd72c0081                                           // 000000440764: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 000000440768: 02030CFF 83DCD12D
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000440770: D622007B 03FD017B 00006400
	v_pk_fma_f16 v124, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000044077C: CC0E007C 0BFC0D7C 0000C931
	v_lshl_or_b32 v128, v132, 16, v131                         // 000000440788: D6560080 060D2184
	v_dot2acc_f32_f16 v53, v130, v15                           // 000000440790: 046A1F82
	v_dual_dot2acc_f32_f16 v54, v130, v31 :: v_dual_dot2acc_f32_f16 v51, v125, v25// 000000440794: CB183F82 3632337D
	v_dot2acc_f32_f16 v50, v125, v21                           // 00000044079C: 04642B7D
	v_dual_dot2acc_f32_f16 v56, v126, v8 :: v_dual_lshlrev_b32 v123, 16, v123// 0000004407A0: CB22117E 387AF690
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000004407A8: D6220081 03FD0181 00006400
	v_pk_fma_f16 v127, v128, s6, 0xc931 op_sel_hi:[1,0,0]      // 0000004407B4: CC0E007F 0BFC0D80 0000C931
	v_dot2acc_f32_f16 v51, v124, v26                           // 0000004407C0: 0466357C
	v_dual_dot2acc_f32_f16 v50, v124, v22 :: v_dual_dot2acc_f32_f16 v47, v125, v9// 0000004407C4: CB182D7C 322E137D
	v_bfe_u32 v128, v116, 8, 16                                // 0000004407CC: D6100080 02411174
	v_and_or_b32 v123, 0xffff, v129, v123                      // 0000004407D4: D657007B 05EF02FF 0000FFFF
	v_and_b32_e32 v122, 0xffff, v122                           // 0000004407E0: 36F4F4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004407E8: BF870214
	v_dual_dot2acc_f32_f16 v50, v127, v23 :: v_dual_dot2acc_f32_f16 v47, v124, v10// 0000004407EC: CB182F7F 322E157C
	.long 0xd72c0080                                           // 0000004407F4: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 0000004407F8: 020300FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000440800: BF870004
	v_pk_fma_f16 v123, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440804: CC0E007B 0BFC0D7B 0000C931
	v_dot2acc_f32_f16 v46, v125, v29                           // 000000440810: 045C3B7D
	v_dual_dot2acc_f32_f16 v52, v124, v18 :: v_dual_dot2acc_f32_f16 v53, v126, v16// 000000440814: CB18257C 3434217E
	v_dual_dot2acc_f32_f16 v47, v127, v11 :: v_dual_dot2acc_f32_f16 v54, v126, v32// 00000044081C: CB18177F 2F36417E
	v_dot2acc_f32_f16 v51, v127, v27                           // 000000440824: 0466377F
	v_sad_u8 v128, v128, 0, 0x6400                             // 000000440828: D6220080 03FD0180 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440834: BF870214
	v_dual_dot2acc_f32_f16 v52, v127, v19 :: v_dual_dot2acc_f32_f16 v49, v125, v1// 000000440838: CB18277F 3430037D
	v_dual_dot2acc_f32_f16 v47, v123, v12 :: v_dual_dot2acc_f32_f16 v48, v125, v5// 000000440840: CB18197B 2F300B7D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440848: BF870214
	v_dot2acc_f32_f16 v51, v123, v28                           // 00000044084C: 0466397B
	v_lshl_or_b32 v122, v128, 16, v122                         // 000000440850: D656007A 05E92180
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000440858: BF870214
	v_dual_dot2acc_f32_f16 v52, v123, v20 :: v_dual_dot2acc_f32_f16 v49, v124, v2// 00000044085C: CB18297B 3430057C
	v_dot2acc_f32_f16 v48, v124, v6                            // 000000440864: 04600D7C
	s_waitcnt vmcnt(0)                                         // 000000440868: BF8903F7
	v_bfe_u32 v129, v105, 12, 16                               // 00000044086C: D6100081 02411969
	v_pk_fma_f16 v122, v122, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440874: CC0E007A 0BFC0D7A 0000C931
	v_and_b32_e32 v126, 0xffff, v116                           // 000000440880: 36FCE8FF 0000FFFF
	v_bfe_u32 v116, v116, 4, 16                                // 000000440888: D6100074 02410974
	v_dot2acc_f32_f16 v49, v127, v3                            // 000000440890: 0462077F
	v_dual_dot2acc_f32_f16 v48, v127, v7 :: v_dual_dot2acc_f32_f16 v45, v125, v13// 000000440894: CB180F7F 302C1B7D
	v_dot2acc_f32_f16 v43, v122, v25                           // 00000044089C: 0456337A
	.long 0xd72c007e                                           // 0000004408A0: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004408A4: 0202FCFF 83DCD12D
	.long 0xd72c0074                                           // 0000004408AC: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 0000004408B0: 0202E8FF 83DCD12D
	v_dot2acc_f32_f16 v50, v123, v24                           // 0000004408B8: 0464317B
	v_bfe_u32 v130, v105, 8, 16                                // 0000004408BC: D6100082 02411169
	v_bfe_u32 v131, v105, 4, 16                                // 0000004408C4: D6100083 02410969
	.long 0xd72c0081                                           // 0000004408CC: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 0000004408D0: 020302FF 83DCD12D
	v_dual_dot2acc_f32_f16 v48, v123, v8 :: v_dual_and_b32 v105, 0xffff, v105// 0000004408D8: CB24117B 3068D2FF 0000FFFF
	v_dot2acc_f32_f16 v45, v124, v14                           // 0000004408E4: 045A1D7C
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000004408E8: D622007E 03FD017E 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 0000004408F4: D6220074 03FD0174 00006400
	.long 0xd72c0082                                           // 000000440900: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000440904: 020304FF 83DCD12D
	.long 0xd72c0069                                           // 00000044090C: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 000000440910: 0202D2FF 83DCD12D
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000440918: D6220081 03FD0181 00006400
	v_dual_dot2acc_f32_f16 v45, v127, v15 :: v_dual_lshlrev_b32 v126, 16, v126// 000000440924: CB221F7F 2D7EFC90
	.long 0xd72c007d                                           // 00000044092C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000440930: 020306FF 83DCD12D
	v_dual_dot2acc_f32_f16 v49, v123, v4 :: v_dual_dot2acc_f32_f16 v46, v124, v30// 000000440938: CB18097B 312E3D7C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000440940: BF870243
	v_and_or_b32 v116, 0xffff, v116, v126                      // 000000440944: D6570074 05FAE8FF 0000FFFF
	v_sad_u8 v128, v130, 0, 0x6400                             // 000000440950: D6220080 03FD0182 00006400
	v_sad_u8 v105, v105, 0, 0x6400                             // 00000044095C: D6220069 03FD0169 00006400
	v_dual_dot2acc_f32_f16 v42, v122, v21 :: v_dual_dot2acc_f32_f16 v45, v123, v16// 000000440968: CB182B7A 2A2C217B
	v_pk_fma_f16 v116, v116, s6, 0xc931 op_sel_hi:[1,0,0]      // 000000440970: CC0E0074 0BFC0D74 0000C931
	v_and_b32_e32 v126, 0xffff, v129                           // 00000044097C: 36FD02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000440984: BF870224
	v_dual_dot2acc_f32_f16 v46, v127, v31 :: v_dual_lshlrev_b32 v105, 16, v105// 000000440988: CB223F7F 2E68D290
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000440990: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v43, v116, v26                           // 00000044099C: 04563574
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004409A0: BF870244
	v_lshl_or_b32 v124, v128, 16, v126                         // 0000004409A4: D656007C 05F92180
	v_dot2acc_f32_f16 v44, v122, v17                           // 0000004409AC: 0458237A
	v_dual_dot2acc_f32_f16 v42, v116, v22 :: v_dual_dot2acc_f32_f16 v41, v122, v1// 0000004409B0: CB182D74 2A28037A
	v_and_or_b32 v21, 0xffff, v125, v105                       // 0000004409B8: D6570015 05A6FAFF 0000FFFF
	v_pk_fma_f16 v17, v124, s6, 0xc931 op_sel_hi:[1,0,0]       // 0000004409C4: CC0E0011 0BFC0D7C 0000C931
	v_dual_dot2acc_f32_f16 v39, v122, v9 :: v_dual_dot2acc_f32_f16 v46, v123, v32// 0000004409D0: CB18137A 272E417B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004409D8: BF870194
	v_dual_dot2acc_f32_f16 v41, v116, v2 :: v_dual_dot2acc_f32_f16 v40, v122, v5// 0000004409DC: CB180574 29280B7A
	v_dual_dot2acc_f32_f16 v43, v17, v27 :: v_dual_dot2acc_f32_f16 v44, v116, v18// 0000004409E4: CB183711 2B2C2574
	v_pk_fma_f16 v18, v21, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004409EC: CC0E0012 0BFC0D15 0000C931
	v_dual_dot2acc_f32_f16 v42, v17, v23 :: v_dual_dot2acc_f32_f16 v37, v122, v13// 0000004409F8: CB182F11 2A241B7A
	v_dual_dot2acc_f32_f16 v39, v116, v10 :: v_dual_dot2acc_f32_f16 v38, v122, v29// 000000440A00: CB181574 27263B7A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000440A08: BF870193
	v_dual_dot2acc_f32_f16 v43, v18, v28 :: v_dual_dot2acc_f32_f16 v44, v17, v19// 000000440A0C: CB183912 2B2C2711
	v_dual_dot2acc_f32_f16 v42, v18, v24 :: v_dual_dot2acc_f32_f16 v37, v116, v14// 000000440A14: CB183112 2A241D74
	v_dual_dot2acc_f32_f16 v41, v17, v3 :: v_dual_dot2acc_f32_f16 v40, v116, v6// 000000440A1C: CB180711 29280D74
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000440A24: BF870113
	v_dual_dot2acc_f32_f16 v44, v18, v20 :: v_dual_dot2acc_f32_f16 v39, v17, v11// 000000440A28: CB182912 2C261711
	v_dual_dot2acc_f32_f16 v38, v116, v30 :: v_dual_dot2acc_f32_f16 v41, v18, v4// 000000440A30: CB183D74 26280912
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000440A38: BF870194
	v_dot2acc_f32_f16 v37, v17, v15                            // 000000440A3C: 044A1F11
	v_dual_dot2acc_f32_f16 v40, v17, v7 :: v_dual_dot2acc_f32_f16 v39, v18, v12// 000000440A40: CB180F11 28261912
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000440A48: BF8701A3
	v_dot2acc_f32_f16 v38, v17, v31                            // 000000440A4C: 044C3F11
	v_dual_mov_b32 v2, v111 :: v_dual_mov_b32 v133, v109       // 000000440A50: CA10016F 0284016D
	v_dual_dot2acc_f32_f16 v40, v18, v8 :: v_dual_mov_b32 v3, v121// 000000440A58: CB101112 28020179
	v_dot2acc_f32_f16 v37, v18, v16                            // 000000440A60: 044A2112
	s_delay_alu instid0(VALU_DEP_4)                            // 000000440A64: BF870004
	v_dual_dot2acc_f32_f16 v38, v18, v32 :: v_dual_mov_b32 v139, v113// 000000440A68: CB104112 268A0171
	v_dual_mov_b32 v4, v121 :: v_dual_mov_b32 v137, v119       // 000000440A70: CA100179 04880177
	v_dual_mov_b32 v140, v120 :: v_dual_mov_b32 v135, v119     // 000000440A78: CA100178 8C860177
	v_dual_mov_b32 v138, v120 :: v_dual_mov_b32 v131, v117     // 000000440A80: CA100178 8A820175
	v_dual_mov_b32 v136, v110 :: v_dual_mov_b32 v129, v117     // 000000440A88: CA10016E 88800175
	v_dual_mov_b32 v134, v118 :: v_dual_mov_b32 v127, v107     // 000000440A90: CA100176 867E016B
	v_dual_mov_b32 v132, v118 :: v_dual_mov_b32 v105, v112     // 000000440A98: CA100176 84680170
	v_dual_mov_b32 v130, v108 :: v_dual_mov_b32 v125, v114     // 000000440AA0: CA10016C 827C0172
	v_dual_mov_b32 v128, v115 :: v_dual_mov_b32 v123, v114     // 000000440AA8: CA100173 807A0172
	v_dual_mov_b32 v126, v115 :: v_dual_mov_b32 v1, v33        // 000000440AB0: CA100173 7E000121
	v_mov_b32_e32 v124, v106                                   // 000000440AB8: 7EF8036A
	v_mov_b32_e32 v116, v34                                    // 000000440ABC: 7EE80322
	v_mov_b32_e32 v122, v112                                   // 000000440AC0: 7EF40370
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000440AC4: 917E057E
	s_cbranch_execz 58                                         // 000000440AC8: BFA5003A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x20b4>
	v_add_nc_u32_e32 v33, 1, v1                                // 000000440ACC: 4A420281
	s_mov_b32 s7, exec_lo                                      // 000000440AD0: BE87007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000440AD4: BF870001
	.long 0xd4c1007e                                           // 000000440AD8: D4C1007E
	v_cndmask_b32_e32 v1, v33, v101, vcc_lo                    // 000000440ADC: 0202CB21
	s_cbranch_execz 64409                                      // 000000440AE0: BFA5FB99 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe48>
	v_ashrrev_i32_e32 v34, 31, v33                             // 000000440AE4: 3444429F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000440AE8: BF870091
	.long 0xd73c0005                                           // 000000440AEC: D73C0005
	v_cndmask_b32_e32 v1, 10, v33, vcc_lo                      // 000000440AF0: 0202428A
	.long 0xd7006a07                                           // 000000440AF4: D7006A07
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000440AF8: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000440AFC: BF870111
	v_add_co_ci_u32_e64 v8, null, s4, v6, vcc_lo               // 000000440B00: D5207C08 01AA0C04
	.long 0xd7006a05                                           // 000000440B08: D7006A05
	v_cndmask_b32_e32 v1, v7, v104, vcc_lo                     // 000000440B0C: 0202D107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000440B10: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v8, vcc_lo                // 000000440B14: D5207C06 01AA1080
	.long 0xd7006a07                                           // 000000440B1C: D7006A07
	v_cndmask_b32_e32 v1, v7, v103, vcc_lo                     // 000000440B20: 0202CF07
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000440B24: D5207C08 01AA1080
	s_clause 0xf                                               // 000000440B2C: BF85000F
	global_load_b32 v111, v[5:6], off                          // 000000440B30: DC520000 6F7C0005
	global_load_b32 v113, v[5:6], off offset:128               // 000000440B38: DC520080 717C0005
	global_load_b32 v110, v[5:6], off offset:256               // 000000440B40: DC520100 6E7C0005
	global_load_b32 v109, v[5:6], off offset:384               // 000000440B48: DC520180 6D7C0005
	global_load_b32 v108, v[5:6], off offset:512               // 000000440B50: DC520200 6C7C0005
	global_load_b32 v107, v[5:6], off offset:640               // 000000440B58: DC520280 6B7C0005
	global_load_b32 v106, v[5:6], off offset:768               // 000000440B60: DC520300 6A7C0005
	global_load_b32 v34, v[5:6], off offset:896                // 000000440B68: DC520380 227C0005
	global_load_b32 v121, v[7:8], off                          // 000000440B70: DC520000 797C0007
	global_load_b32 v120, v[7:8], off offset:128               // 000000440B78: DC520080 787C0007
	global_load_b32 v119, v[7:8], off offset:256               // 000000440B80: DC520100 777C0007
	global_load_b32 v118, v[7:8], off offset:384               // 000000440B88: DC520180 767C0007
	global_load_b32 v117, v[7:8], off offset:512               // 000000440B90: DC520200 757C0007
	global_load_b32 v115, v[7:8], off offset:640               // 000000440B98: DC520280 737C0007
	global_load_b32 v114, v[7:8], off offset:768               // 000000440BA0: DC520300 727C0007
	global_load_b32 v112, v[7:8], off offset:896               // 000000440BA8: DC520380 707C0007
	s_branch 64357                                             // 000000440BB0: BFA0FB65 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe48>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000440BB4: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000440BB8: BF870009
	s_or_b32 exec_lo, exec_lo, s2                              // 000000440BBC: 8C7E027E
	s_waitcnt vmcnt(7)                                         // 000000440BC0: BF891FF7
	v_dual_mov_b32 v1, v100 :: v_dual_mov_b32 v4, v90          // 000000440BC4: CA100164 0104015A
	v_dual_mov_b32 v2, v96 :: v_dual_mov_b32 v3, v91           // 000000440BCC: CA100160 0202015B
	v_dual_mov_b32 v5, v93 :: v_dual_mov_b32 v10, v98          // 000000440BD4: CA10015D 050A0162
	v_dual_mov_b32 v6, v89 :: v_dual_mov_b32 v7, v87           // 000000440BDC: CA100159 06060157
	v_dual_mov_b32 v8, v85 :: v_dual_mov_b32 v9, v99           // 000000440BE4: CA100155 08080163
	v_dual_mov_b32 v11, v97 :: v_dual_mov_b32 v12, v95         // 000000440BEC: CA100161 0B0C015F
	v_dual_mov_b32 v13, v94 :: v_dual_mov_b32 v14, v92         // 000000440BF4: CA10015E 0D0E015C
	v_dual_mov_b32 v15, v88 :: v_dual_mov_b32 v16, v86         // 000000440BFC: CA100158 0F100156
	v_dual_mov_b32 v17, v84 :: v_dual_mov_b32 v18, v83         // 000000440C04: CA100154 11120153
	v_dual_mov_b32 v19, v82 :: v_dual_mov_b32 v20, v81         // 000000440C0C: CA100152 13140151
	v_dual_mov_b32 v21, v80 :: v_dual_mov_b32 v22, v79         // 000000440C14: CA100150 1516014F
	v_dual_mov_b32 v23, v78 :: v_dual_mov_b32 v24, v77         // 000000440C1C: CA10014E 1718014D
	v_dual_mov_b32 v25, v76 :: v_dual_mov_b32 v26, v75         // 000000440C24: CA10014C 191A014B
	v_dual_mov_b32 v27, v74 :: v_dual_mov_b32 v28, v73         // 000000440C2C: CA10014A 1B1C0149
	v_dual_mov_b32 v29, v72 :: v_dual_mov_b32 v30, v71         // 000000440C34: CA100148 1D1E0147
	v_dual_mov_b32 v31, v70 :: v_dual_mov_b32 v32, v69         // 000000440C3C: CA100146 1F200145
	v_dual_mov_b32 v33, v68 :: v_dual_mov_b32 v34, v67         // 000000440C44: CA100144 21220143
	v_dual_mov_b32 v101, v66 :: v_dual_mov_b32 v102, v65       // 000000440C4C: CA100142 65660141
	v_dual_mov_b32 v103, v64 :: v_dual_mov_b32 v104, v63       // 000000440C54: CA100140 6768013F
	s_waitcnt vmcnt(0)                                         // 000000440C5C: BF8903F7
	v_dual_mov_b32 v105, v62 :: v_dual_mov_b32 v106, v61       // 000000440C60: CA10013E 696A013D
	v_dual_mov_b32 v107, v60 :: v_dual_mov_b32 v108, v59       // 000000440C68: CA10013C 6B6C013B
	v_dual_mov_b32 v109, v58 :: v_dual_mov_b32 v110, v57       // 000000440C70: CA10013A 6D6E0139
	v_dual_mov_b32 v111, v56 :: v_dual_mov_b32 v112, v55       // 000000440C78: CA100138 6F700137
	v_dual_mov_b32 v113, v54 :: v_dual_mov_b32 v114, v53       // 000000440C80: CA100136 71720135
	v_dual_mov_b32 v115, v52 :: v_dual_mov_b32 v116, v51       // 000000440C88: CA100134 73740133
	v_dual_mov_b32 v117, v50 :: v_dual_mov_b32 v118, v49       // 000000440C90: CA100132 75760131
	v_dual_mov_b32 v119, v48 :: v_dual_mov_b32 v120, v47       // 000000440C98: CA100130 7778012F
	v_dual_mov_b32 v121, v46 :: v_dual_mov_b32 v122, v45       // 000000440CA0: CA10012E 797A012D
	v_dual_mov_b32 v123, v44 :: v_dual_mov_b32 v124, v43       // 000000440CA8: CA10012C 7B7C012B
	v_dual_mov_b32 v125, v42 :: v_dual_mov_b32 v126, v41       // 000000440CB0: CA10012A 7D7E0129
	v_dual_mov_b32 v127, v40 :: v_dual_mov_b32 v128, v39       // 000000440CB8: CA100128 7F800127
	v_dual_mov_b32 v129, v38 :: v_dual_mov_b32 v130, v37       // 000000440CC0: CA100126 81820125
	s_mov_b32 s2, 0x76543210                                   // 000000440CC8: BE8200FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000440CD0: BF870009
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 000000440CD4: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 000000440CE0: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 000000440CEC: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 000000440CF8: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 000000440D04: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 000000440D10: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v7, v7, s2, 0xfedcba98                   // 000000440D1C: D65C0007 03FC0507 FEDCBA98
	v_permlanex16_b32 v8, v8, s2, 0xfedcba98                   // 000000440D28: D65C0008 03FC0508 FEDCBA98
	v_permlanex16_b32 v9, v9, s2, 0xfedcba98                   // 000000440D34: D65C0009 03FC0509 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 000000440D40: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 000000440D4C: D65C000B 03FC050B FEDCBA98
	v_permlanex16_b32 v12, v12, s2, 0xfedcba98                 // 000000440D58: D65C000C 03FC050C FEDCBA98
	v_permlanex16_b32 v13, v13, s2, 0xfedcba98                 // 000000440D64: D65C000D 03FC050D FEDCBA98
	v_permlanex16_b32 v14, v14, s2, 0xfedcba98                 // 000000440D70: D65C000E 03FC050E FEDCBA98
	v_permlanex16_b32 v15, v15, s2, 0xfedcba98                 // 000000440D7C: D65C000F 03FC050F FEDCBA98
	v_permlanex16_b32 v16, v16, s2, 0xfedcba98                 // 000000440D88: D65C0010 03FC0510 FEDCBA98
	v_permlanex16_b32 v17, v17, s2, 0xfedcba98                 // 000000440D94: D65C0011 03FC0511 FEDCBA98
	v_permlanex16_b32 v18, v18, s2, 0xfedcba98                 // 000000440DA0: D65C0012 03FC0512 FEDCBA98
	v_permlanex16_b32 v19, v19, s2, 0xfedcba98                 // 000000440DAC: D65C0013 03FC0513 FEDCBA98
	v_permlanex16_b32 v20, v20, s2, 0xfedcba98                 // 000000440DB8: D65C0014 03FC0514 FEDCBA98
	v_permlanex16_b32 v21, v21, s2, 0xfedcba98                 // 000000440DC4: D65C0015 03FC0515 FEDCBA98
	v_permlanex16_b32 v22, v22, s2, 0xfedcba98                 // 000000440DD0: D65C0016 03FC0516 FEDCBA98
	v_permlanex16_b32 v23, v23, s2, 0xfedcba98                 // 000000440DDC: D65C0017 03FC0517 FEDCBA98
	v_permlanex16_b32 v24, v24, s2, 0xfedcba98                 // 000000440DE8: D65C0018 03FC0518 FEDCBA98
	v_permlanex16_b32 v25, v25, s2, 0xfedcba98                 // 000000440DF4: D65C0019 03FC0519 FEDCBA98
	v_permlanex16_b32 v26, v26, s2, 0xfedcba98                 // 000000440E00: D65C001A 03FC051A FEDCBA98
	v_permlanex16_b32 v27, v27, s2, 0xfedcba98                 // 000000440E0C: D65C001B 03FC051B FEDCBA98
	v_permlanex16_b32 v28, v28, s2, 0xfedcba98                 // 000000440E18: D65C001C 03FC051C FEDCBA98
	v_permlanex16_b32 v29, v29, s2, 0xfedcba98                 // 000000440E24: D65C001D 03FC051D FEDCBA98
	v_permlanex16_b32 v30, v30, s2, 0xfedcba98                 // 000000440E30: D65C001E 03FC051E FEDCBA98
	v_permlanex16_b32 v31, v31, s2, 0xfedcba98                 // 000000440E3C: D65C001F 03FC051F FEDCBA98
	v_permlanex16_b32 v32, v32, s2, 0xfedcba98                 // 000000440E48: D65C0020 03FC0520 FEDCBA98
	v_permlanex16_b32 v33, v33, s2, 0xfedcba98                 // 000000440E54: D65C0021 03FC0521 FEDCBA98
	v_permlanex16_b32 v34, v34, s2, 0xfedcba98                 // 000000440E60: D65C0022 03FC0522 FEDCBA98
	v_permlanex16_b32 v101, v101, s2, 0xfedcba98               // 000000440E6C: D65C0065 03FC0565 FEDCBA98
	v_permlanex16_b32 v102, v102, s2, 0xfedcba98               // 000000440E78: D65C0066 03FC0566 FEDCBA98
	v_permlanex16_b32 v103, v103, s2, 0xfedcba98               // 000000440E84: D65C0067 03FC0567 FEDCBA98
	v_permlanex16_b32 v104, v104, s2, 0xfedcba98               // 000000440E90: D65C0068 03FC0568 FEDCBA98
	v_permlanex16_b32 v105, v105, s2, 0xfedcba98               // 000000440E9C: D65C0069 03FC0569 FEDCBA98
	v_permlanex16_b32 v106, v106, s2, 0xfedcba98               // 000000440EA8: D65C006A 03FC056A FEDCBA98
	v_permlanex16_b32 v107, v107, s2, 0xfedcba98               // 000000440EB4: D65C006B 03FC056B FEDCBA98
	v_permlanex16_b32 v108, v108, s2, 0xfedcba98               // 000000440EC0: D65C006C 03FC056C FEDCBA98
	v_permlanex16_b32 v109, v109, s2, 0xfedcba98               // 000000440ECC: D65C006D 03FC056D FEDCBA98
	v_permlanex16_b32 v110, v110, s2, 0xfedcba98               // 000000440ED8: D65C006E 03FC056E FEDCBA98
	v_permlanex16_b32 v111, v111, s2, 0xfedcba98               // 000000440EE4: D65C006F 03FC056F FEDCBA98
	v_permlanex16_b32 v112, v112, s2, 0xfedcba98               // 000000440EF0: D65C0070 03FC0570 FEDCBA98
	v_permlanex16_b32 v113, v113, s2, 0xfedcba98               // 000000440EFC: D65C0071 03FC0571 FEDCBA98
	v_permlanex16_b32 v114, v114, s2, 0xfedcba98               // 000000440F08: D65C0072 03FC0572 FEDCBA98
	v_permlanex16_b32 v115, v115, s2, 0xfedcba98               // 000000440F14: D65C0073 03FC0573 FEDCBA98
	v_permlanex16_b32 v116, v116, s2, 0xfedcba98               // 000000440F20: D65C0074 03FC0574 FEDCBA98
	v_permlanex16_b32 v117, v117, s2, 0xfedcba98               // 000000440F2C: D65C0075 03FC0575 FEDCBA98
	v_permlanex16_b32 v118, v118, s2, 0xfedcba98               // 000000440F38: D65C0076 03FC0576 FEDCBA98
	v_permlanex16_b32 v119, v119, s2, 0xfedcba98               // 000000440F44: D65C0077 03FC0577 FEDCBA98
	v_permlanex16_b32 v120, v120, s2, 0xfedcba98               // 000000440F50: D65C0078 03FC0578 FEDCBA98
	v_permlanex16_b32 v121, v121, s2, 0xfedcba98               // 000000440F5C: D65C0079 03FC0579 FEDCBA98
	v_permlanex16_b32 v122, v122, s2, 0xfedcba98               // 000000440F68: D65C007A 03FC057A FEDCBA98
	v_permlanex16_b32 v123, v123, s2, 0xfedcba98               // 000000440F74: D65C007B 03FC057B FEDCBA98
	v_permlanex16_b32 v124, v124, s2, 0xfedcba98               // 000000440F80: D65C007C 03FC057C FEDCBA98
	v_permlanex16_b32 v125, v125, s2, 0xfedcba98               // 000000440F8C: D65C007D 03FC057D FEDCBA98
	v_permlanex16_b32 v126, v126, s2, 0xfedcba98               // 000000440F98: D65C007E 03FC057E FEDCBA98
	v_permlanex16_b32 v127, v127, s2, 0xfedcba98               // 000000440FA4: D65C007F 03FC057F FEDCBA98
	v_permlanex16_b32 v128, v128, s2, 0xfedcba98               // 000000440FB0: D65C0080 03FC0580 FEDCBA98
	v_permlanex16_b32 v129, v129, s2, 0xfedcba98               // 000000440FBC: D65C0081 03FC0581 FEDCBA98
	v_permlanex16_b32 v130, v130, s2, 0xfedcba98               // 000000440FC8: D65C0082 03FC0582 FEDCBA98
	.long 0xd44c0002                                           // 000000440FD4: D44C0002
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 000000440FD8: 02024890
	s_barrier                                                  // 000000440FDC: BFBD0000
	buffer_gl0_inv                                             // 000000440FE0: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 000000440FE8: BE832002
	s_cbranch_execz 138                                        // 000000440FEC: BFA5008A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2718>
	v_dual_add_f32 v7, v87, v7 :: v_dual_lshlrev_b32 v36, 2, v36// 000000440FF0: C9220F57 07244882
	v_dual_add_f32 v10, v98, v10 :: v_dual_add_f32 v9, v99, v9 // 000000440FF8: C9081562 0A081363
	v_dual_add_f32 v8, v85, v8 :: v_dual_add_f32 v1, v100, v1  // 000000441000: C9081155 08000364
	s_delay_alu instid0(VALU_DEP_3)                            // 000000441008: BF870003
	v_lshl_or_b32 v36, v35, 12, v36                            // 00000044100C: D6560024 04911923
	v_add_f32_e32 v2, v96, v2                                  // 000000441014: 06040560
	v_dual_add_f32 v34, v67, v34 :: v_dual_add_f32 v33, v68, v33// 000000441018: C9084543 22204344
	v_dual_add_f32 v12, v95, v12 :: v_dual_add_f32 v11, v97, v11// 000000441020: C908195F 0C0A1761
	v_dual_add_f32 v6, v89, v6 :: v_dual_add_f32 v3, v91, v3   // 000000441028: C9080D59 0602075B
	v_add_nc_u32_e32 v67, 0x400, v36                           // 000000441030: 4A8648FF 00000400
	v_dual_add_f32 v5, v93, v5 :: v_dual_add_f32 v4, v90, v4   // 000000441038: C9080B5D 0504095A
	v_dual_add_f32 v14, v92, v14 :: v_dual_add_f32 v13, v94, v13// 000000441040: C9081D5C 0E0C1B5E
	ds_store_2addr_b32 v36, v1, v9 offset1:16                  // 000000441048: D8381000 00090124
	v_add_nc_u32_e32 v1, 0x800, v36                            // 000000441050: 4A0248FF 00000800
	v_dual_add_f32 v16, v86, v16 :: v_dual_add_f32 v15, v88, v15// 000000441058: C9082156 100E1F58
	ds_store_2addr_b32 v36, v2, v10 offset0:128 offset1:144    // 000000441060: D8389080 000A0224
	v_dual_add_f32 v37, v37, v130 :: v_dual_add_nc_u32 v2, 0xc00, v36// 000000441068: C9210525 250248FF 00000C00
	v_dual_add_f32 v38, v38, v129 :: v_dual_add_f32 v39, v39, v128// 000000441074: C9090326 26270127
	v_dual_add_f32 v40, v40, v127 :: v_dual_add_f32 v41, v41, v126// 00000044107C: C908FF28 2828FD29
	v_dual_add_f32 v42, v42, v125 :: v_dual_add_f32 v43, v43, v124// 000000441084: C908FB2A 2A2AF92B
	v_dual_add_f32 v44, v44, v123 :: v_dual_add_f32 v45, v45, v122// 00000044108C: C908F72C 2C2CF52D
	v_dual_add_f32 v46, v46, v121 :: v_dual_add_f32 v47, v47, v120// 000000441094: C908F32E 2E2EF12F
	v_dual_add_f32 v48, v48, v119 :: v_dual_add_f32 v49, v49, v118// 00000044109C: C908EF30 3030ED31
	v_dual_add_f32 v50, v50, v117 :: v_dual_add_f32 v51, v51, v116// 0000004410A4: C908EB32 3232E933
	v_dual_add_f32 v52, v52, v115 :: v_dual_add_f32 v53, v53, v114// 0000004410AC: C908E734 3434E535
	v_dual_add_f32 v54, v54, v113 :: v_dual_add_f32 v55, v55, v112// 0000004410B4: C908E336 3636E137
	v_dual_add_f32 v56, v56, v111 :: v_dual_add_f32 v57, v57, v110// 0000004410BC: C908DF38 3838DD39
	v_dual_add_f32 v58, v58, v109 :: v_dual_add_f32 v59, v59, v108// 0000004410C4: C908DB3A 3A3AD93B
	v_dual_add_f32 v60, v60, v107 :: v_dual_add_f32 v61, v61, v106// 0000004410CC: C908D73C 3C3CD53D
	v_dual_add_f32 v62, v62, v105 :: v_dual_add_f32 v63, v63, v104// 0000004410D4: C908D33E 3E3ED13F
	v_dual_add_f32 v64, v64, v103 :: v_dual_add_f32 v65, v65, v102// 0000004410DC: C908CF40 4040CD41
	v_add_f32_e32 v66, v66, v101                               // 0000004410E4: 0684CB42
	v_dual_add_f32 v32, v69, v32 :: v_dual_add_f32 v31, v70, v31// 0000004410E8: C9084145 201E3F46
	v_dual_add_f32 v30, v71, v30 :: v_dual_add_f32 v29, v72, v29// 0000004410F0: C9083D47 1E1C3B48
	v_dual_add_f32 v28, v73, v28 :: v_dual_add_f32 v27, v74, v27// 0000004410F8: C9083949 1C1A374A
	v_dual_add_f32 v26, v75, v26 :: v_dual_add_f32 v25, v76, v25// 000000441100: C908354B 1A18334C
	v_dual_add_f32 v24, v77, v24 :: v_dual_add_f32 v23, v78, v23// 000000441108: C908314D 18162F4E
	v_dual_add_f32 v22, v79, v22 :: v_dual_add_f32 v21, v80, v21// 000000441110: C9082D4F 16142B50
	v_dual_add_f32 v20, v81, v20 :: v_dual_add_f32 v19, v82, v19// 000000441118: C9082951 14122752
	v_dual_add_f32 v18, v83, v18 :: v_dual_add_f32 v17, v84, v17// 000000441120: C9082553 12102354
	ds_store_2addr_b32 v67, v3, v11 offset1:16                 // 000000441128: D8381000 000B0343
	ds_store_2addr_b32 v67, v4, v12 offset0:128 offset1:144    // 000000441130: D8389080 000C0443
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000441138: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 000000441140: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000441148: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 000000441150: D8389080 00100802
	ds_store_2addr_b32 v36, v17, v25 offset0:32 offset1:48     // 000000441158: D8383020 00191124
	ds_store_2addr_b32 v36, v18, v26 offset0:160 offset1:176   // 000000441160: D838B0A0 001A1224
	ds_store_2addr_b32 v67, v19, v27 offset0:32 offset1:48     // 000000441168: D8383020 001B1343
	ds_store_2addr_b32 v67, v20, v28 offset0:160 offset1:176   // 000000441170: D838B0A0 001C1443
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000441178: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 000000441180: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000441188: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 000000441190: D838B0A0 00201802
	ds_store_2addr_b32 v36, v33, v60 offset0:64 offset1:80     // 000000441198: D8385040 003C2124
	ds_store_2addr_b32 v36, v34, v59 offset0:192 offset1:208   // 0000004411A0: D838D0C0 003B2224
	ds_store_2addr_b32 v67, v66, v58 offset0:64 offset1:80     // 0000004411A8: D8385040 003A4243
	ds_store_2addr_b32 v67, v65, v57 offset0:192 offset1:208   // 0000004411B0: D838D0C0 00394143
	ds_store_2addr_b32 v1, v64, v56 offset0:64 offset1:80      // 0000004411B8: D8385040 00384001
	ds_store_2addr_b32 v1, v63, v55 offset0:192 offset1:208    // 0000004411C0: D838D0C0 00373F01
	ds_store_2addr_b32 v2, v62, v54 offset0:64 offset1:80      // 0000004411C8: D8385040 00363E02
	ds_store_2addr_b32 v2, v61, v53 offset0:192 offset1:208    // 0000004411D0: D838D0C0 00353D02
	ds_store_2addr_b32 v36, v52, v44 offset0:96 offset1:112    // 0000004411D8: D8387060 002C3424
	ds_store_2addr_b32 v36, v51, v43 offset0:224 offset1:240   // 0000004411E0: D838F0E0 002B3324
	ds_store_2addr_b32 v67, v50, v42 offset0:96 offset1:112    // 0000004411E8: D8387060 002A3243
	ds_store_2addr_b32 v67, v49, v41 offset0:224 offset1:240   // 0000004411F0: D838F0E0 00293143
	ds_store_2addr_b32 v1, v48, v40 offset0:96 offset1:112     // 0000004411F8: D8387060 00283001
	ds_store_2addr_b32 v1, v47, v39 offset0:224 offset1:240    // 000000441200: D838F0E0 00272F01
	ds_store_2addr_b32 v2, v46, v38 offset0:96 offset1:112     // 000000441208: D8387060 00262E02
	ds_store_2addr_b32 v2, v45, v37 offset0:224 offset1:240    // 000000441210: D838F0E0 00252D02
	s_or_b32 exec_lo, exec_lo, s3                              // 000000441218: 8C7E037E
	v_mov_b32_e32 v1, v0                                       // 00000044121C: 7E020300
	s_mov_b32 s3, 0                                            // 000000441220: BE830080
	s_waitcnt lgkmcnt(0)                                       // 000000441224: BF89FC07
	s_barrier                                                  // 000000441228: BFBD0000
	buffer_gl0_inv                                             // 00000044122C: E0AC0000 00000000
	s_nop 0                                                    // 000000441234: BF800000
	s_nop 0                                                    // 000000441238: BF800000
	s_nop 0                                                    // 00000044123C: BF800000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000441240: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000441244: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 00000044124C: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000441254: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 00000044125C: D8E05040 06000008
	s_or_b32 s3, vcc_lo, s3                                    // 000000441264: 8C03036A
	s_waitcnt lgkmcnt(2)                                       // 000000441268: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000044126C: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000441270: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000441274: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000441278: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000441280: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000441284: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000441288: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000044128C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441290: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000441294: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000441298: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000044129C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004412A0: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 0000004412A4: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 0000004412A8: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 0000004412B0: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 0000004412B8: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000004412C0: 917E037E
	s_cbranch_execnz 65502                                     // 0000004412C4: BFA6FFDE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2740>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004412C8: 8C7E037E
	s_cmp_lt_i32 s21, 2                                        // 0000004412CC: BF048215
	s_mov_b32 s3, -1                                           // 0000004412D0: BE8300C1
	s_cbranch_scc1 212                                         // 0000004412D4: BFA200D4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b28>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 0000004412D8: F4080100 F80001A8
	s_lshl_b64 s[10:11], s[34:35], 2                           // 0000004412E0: 848A8222
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 0000004412E4: CA240100 040000FF 0000007F
	s_waitcnt lgkmcnt(0)                                       // 0000004412F0: BF89FC07
	s_barrier                                                  // 0000004412F4: BFBD0000
	buffer_gl0_inv                                             // 0000004412F8: E0AC0000 00000000
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000441300: 30040282
	s_add_u32 s3, s4, s10                                      // 000000441304: 80030A04
	s_addc_u32 s8, s5, s11                                     // 000000441308: 82080B05
	s_lshl_b32 s0, s26, 7                                      // 00000044130C: 8400871A
	s_ashr_i32 s31, s30, 31                                    // 000000441310: 861F9F1E
	s_ashr_i32 s1, s0, 31                                      // 000000441314: 86019F00
	s_ashr_i32 s9, s20, 31                                     // 000000441318: 86099F14
	s_lshl_b64 s[16:17], s[0:1], 2                             // 00000044131C: 84908200
	s_lshl_b64 s[22:23], s[30:31], 3                           // 000000441320: 8496831E
	s_add_u32 s0, s3, s16                                      // 000000441324: 80001003
	s_addc_u32 s1, s8, s17                                     // 000000441328: 82011108
	.long 0xd7000002                                           // 00000044132C: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000441330: 02020400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441334: BF870001
	v_add_co_ci_u32_e64 v3, null, s1, 0, s0                    // 000000441338: D5207C03 00010001
	s_mov_b32 s8, s20                                          // 000000441340: BE880014
	s_mov_b32 s1, 0                                            // 000000441344: BE810080
	s_nop 0                                                    // 000000441348: BF800000
	s_nop 0                                                    // 00000044134C: BF800000
	s_nop 0                                                    // 000000441350: BF800000
	s_nop 0                                                    // 000000441354: BF800000
	s_nop 0                                                    // 000000441358: BF800000
	s_nop 0                                                    // 00000044135C: BF800000
	s_nop 0                                                    // 000000441360: BF800000
	s_nop 0                                                    // 000000441364: BF800000
	s_nop 0                                                    // 000000441368: BF800000
	s_nop 0                                                    // 00000044136C: BF800000
	s_nop 0                                                    // 000000441370: BF800000
	s_nop 0                                                    // 000000441374: BF800000
	s_nop 0                                                    // 000000441378: BF800000
	s_nop 0                                                    // 00000044137C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000441380: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000441384: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044138C: BF870092
	.long 0xd7000005                                           // 000000441390: D7000005
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 000000441394: 02020A16
	v_add_co_ci_u32_e64 v6, null, s23, 0, s0                   // 000000441398: D5207C06 00010017
	s_or_b32 s1, vcc_lo, s1                                    // 0000004413A0: 8C01016A
	.long 0xd72c0009                                           // 0000004413A4: D72C0009
	v_cndmask_b32_e32 v0, v5, v9, vcc_lo                       // 0000004413A8: 02001305
	.long 0xd72c0008                                           // 0000004413AC: D72C0008
	v_cndmask_b32_e32 v0, v6, v8, vcc_lo                       // 0000004413B0: 02001106
	v_mad_u64_u32 v[5:6], null, v5, s8, 0                      // 0000004413B4: D6FE7C05 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004413BC: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 0000004413C0: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 0000004413C8: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 0000004413D0: 300E0882
	.long 0xd73c0005                                           // 0000004413D4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004413D8: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004413DC: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 0000004413E0: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 0000004413E4: D8D88000 07000007
	.long 0xd7000005                                           // 0000004413EC: D7000005
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 0000004413F0: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s0                   // 0000004413F4: D5207C06 00020D03
	s_waitcnt lgkmcnt(0)                                       // 0000004413FC: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 000000441400: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000441408: 917E017E
	s_cbranch_execnz 65500                                     // 00000044140C: BFA6FFDC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2880>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000441410: 8C7E017E
	s_ashr_i32 s29, s28, 31                                    // 000000441414: 861D9F1C
	.long 0xd44a0000                                           // 000000441418: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000044141C: 02020080
	s_lshl_b64 s[22:23], s[28:29], 2                           // 000000441420: 8496821C
	s_waitcnt_vscnt null, 0x0                                  // 000000441424: BC7C0000
	buffer_gl1_inv                                             // 000000441428: E0B00000 00000000
	buffer_gl0_inv                                             // 000000441430: E0AC0000 00000000
	s_add_u32 s3, s6, s22                                      // 000000441438: 80031606
	s_addc_u32 s19, s7, s23                                    // 00000044143C: 82131707
	s_barrier                                                  // 000000441440: BFBD0000
	buffer_gl0_inv                                             // 000000441444: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000044144C: BE812000
	s_cbranch_execz 29                                         // 000000441450: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x29c8>
	s_mov_b32 s7, exec_lo                                      // 000000441454: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000441458: BE86007E
	.long 0xd71f0002                                           // 00000044145C: D71F0002
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000441460: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441464: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 000000441468: 7D940480
	s_cbranch_execz 9                                          // 00000044146C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2994>
	s_lshl_b64 s[22:23], s[26:27], 2                           // 000000441470: 8496821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000441474: BF8704B9
	s_add_u32 s22, s3, s22                                     // 000000441478: 80161603
	s_addc_u32 s23, s19, s23                                   // 00000044147C: 82171713
	s_bcnt1_i32_b32 s7, s7                                     // 000000441480: BE871807
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s7              // 000000441484: CA100080 03040007
	global_atomic_add_u32 v3, v3, v4, s[22:23] glc             // 00000044148C: DCD64000 03160403
	s_or_b32 exec_lo, exec_lo, s6                              // 000000441494: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000441498: BF8903F7
	v_readfirstlane_b32 s6, v3                                 // 00000044149C: 7E0C0503
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004414A0: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s6, v2       // 0000004414A4: CA200080 03020406
	s_add_i32 s6, s21, -1                                      // 0000004414AC: 8106C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000004414B0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v2                            // 0000004414B4: 7C940406
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 0000004414B8: D5010002 01A90280
	ds_store_b32 v3, v2 offset:40960                           // 0000004414C0: D834A000 00000203
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004414C8: 8C7E017E
	v_mov_b32_e32 v2, 0                                        // 0000004414CC: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 0000004414D0: BF89FC07
	s_barrier                                                  // 0000004414D4: BFBD0000
	buffer_gl0_inv                                             // 0000004414D8: E0AC0000 00000000
	s_mov_b32 s22, 0                                           // 0000004414E0: BE960080
	ds_load_b32 v2, v2 offset:40960                            // 0000004414E4: D8D8A000 02000002
	s_waitcnt lgkmcnt(0)                                       // 0000004414EC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 0000004414F0: 7C940480
	s_cbranch_vccnz 915                                        // 0000004414F4: BFA40393 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3844>
	v_lshrrev_b32_e32 v2, 7, v0                                // 0000004414F8: 32040087
	s_add_u32 s1, s16, s10                                     // 0000004414FC: 80010A10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000441500: 30020282
	s_addc_u32 s6, s17, s11                                    // 000000441504: 82060B11
	v_mov_b32_e32 v5, v0                                       // 000000441508: 7E0A0300
	v_mad_i64_i32 v[2:3], null, v2, s8, 0                      // 00000044150C: D6FF7C02 02001102
	buffer_gl1_inv                                             // 000000441514: E0B00000 00000000
	buffer_gl0_inv                                             // 00000044151C: E0AC0000 00000000
	.long 0xd73c0002                                           // 000000441524: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000441528: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044152C: BF870091
	.long 0xd7006a02                                           // 000000441530: D7006A02
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000441534: 02020401
	v_add_co_ci_u32_e64 v3, null, s6, v3, vcc_lo               // 000000441538: D5207C03 01AA0606
	s_lshl_b64 s[6:7], s[8:9], 5                               // 000000441540: 84868508
	.long 0xd7006a01                                           // 000000441544: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 000000441548: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044154C: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 000000441550: D5207C02 01AA0680
	.long 0xd7006a01                                           // 000000441558: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000044155C: 02020204
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441560: BF870001
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000441564: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[8:9], 3                               // 00000044156C: 84848308
	s_nop 0                                                    // 000000441570: BF800000
	s_nop 0                                                    // 000000441574: BF800000
	s_nop 0                                                    // 000000441578: BF800000
	s_nop 0                                                    // 00000044157C: BF800000
	v_mov_b32_e32 v4, v2                                       // 000000441580: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 000000441584: CA100080 06020101
	s_mov_b32 s1, s21                                          // 00000044158C: BE810015
	global_load_b32 v7, v[3:4], off glc                        // 000000441590: DC524000 077C0003
	.long 0xd7006a03                                           // 000000441598: D7006A03
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 00000044159C: 02000D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000004415A0: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s7, v4, vcc_lo               // 0000004415A4: D5207C04 01AA0807
	s_add_i32 s1, s1, -1                                       // 0000004415AC: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000004415B0: BF068001
	s_waitcnt vmcnt(0)                                         // 0000004415B4: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000004415B8: 060C0F06
	s_cbranch_scc0 65524                                       // 0000004415BC: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a90>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 0000004415C0: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 0000004415C8: 7C920AFF 000002FF
	.long 0xd7000101                                           // 0000004415D0: D7000101
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000004415D4: 02000901
	v_lshlrev_b32_e32 v3, 2, v5                                // 0000004415D8: 30060A82
	v_add_co_ci_u32_e64 v2, null, s5, v2, s1                   // 0000004415DC: D5207C02 00060405
	v_mov_b32_e32 v5, v4                                       // 0000004415E4: 7E0A0304
	s_or_b32 s22, vcc_lo, s22                                  // 0000004415E8: 8C16166A
	ds_store_b32 v3, v6 offset:32768                           // 0000004415EC: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000004415F4: 917E167E
	s_cbranch_execnz 65505                                     // 0000004415F8: BFA6FFE1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a80>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000004415FC: 8C7E167E
	s_and_saveexec_b32 s1, s0                                  // 000000441600: BE812000
	s_cbranch_execz 6                                          // 000000441604: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b20>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 000000441608: 8484821A
	v_mov_b32_e32 v1, 0                                        // 00000044160C: 7E020280
	s_add_u32 s4, s3, s4                                       // 000000441610: 80040403
	s_addc_u32 s5, s19, s5                                     // 000000441614: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000441618: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000441620: 8C7E017E
	s_mov_b32 s3, -1                                           // 000000441624: BE8300C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000441628: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000044162C: 8B6A037E
	s_cbranch_vccz 63022                                       // 000000441630: BFA3F62E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_gt_i32_e32 vcc_lo, s18, v35                          // 000000441634: 7C884612
	.long 0xd44c0000                                           // 000000441638: D44C0000
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000044163C: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000441644: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000441648: BC7C0000
	s_barrier                                                  // 00000044164C: BFBD0000
	buffer_gl0_inv                                             // 000000441650: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000441658: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044165C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000441660: BE812000
	s_cbranch_execz 63009                                      // 000000441664: BFA5F621 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 000000441668: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044166C: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000441670: 30040282
	v_lshl_or_b32 v2, v35, 9, v2                               // 000000441674: D6560002 04091323
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044167C: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 000000441680: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000441688: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000441690: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000441698: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004416A0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004416A8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004416AC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004416B0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004416B4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004416BC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000004416C0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000004416C8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004416CC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004416D4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004416D8: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000004416E0: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 0000004416E8: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004416EC: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 0000004416F0: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 0000004416F8: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000441700: 7C941480
	.long 0xd44a0000                                           // 000000441704: D44A0000
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000441708: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000044170C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000441714: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000441718: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000044171C: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000441720: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000441724: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000044172C: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000441730: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000441734: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441738: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000441740: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441748: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000441750: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441758: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000441760: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441768: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000441770: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441778: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000441780: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441788: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000441790: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000441798: 7E2402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004417A0: D5010003 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004417A8: 7E2602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 0000004417B0: D5010002 21AA0502
	v_dual_add_f32 v6, v7, v6 :: v_dual_add_f32 v5, v5, v15    // 0000004417B8: C9080D07 06041F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004417C0: 7C941680
	v_dual_add_f32 v7, v9, v10 :: v_dual_add_f32 v8, v8, v16   // 0000004417C4: C9081509 07082108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004417CC: BF870233
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004417D0: 7E1402FA FF016206
	v_add_f32_e32 v4, v4, v17                                  // 0000004417D8: 06082304
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004417DC: D5010006 21AA0D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004417E4: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000004417EC: D5010007 21AA0F07
	v_add_f32_e32 v2, v2, v19                                  // 0000004417F4: 06042702
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004417F8: BF870092
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000004417FC: C9081506 06061707
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441804: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000044180C: D5010006 20020D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000441814: BF8700D3
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441818: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000441820: D5010007 20020F07
	v_add_f32_e32 v9, v13, v14                                 // 000000441828: 06121D0D
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044182C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000441834: D5010005 21AA0B05
	v_dual_add_f32 v15, v5, v14 :: v_dual_add_f32 v14, v7, v11 // 00000044183C: C9081D05 0F0E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441844: BF8701A4
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000441848: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000441850: D5010009 21AA1309
	v_mov_b32_dpp v7, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441858: 7E0E02FA FF01640F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441860: BF870194
	v_mov_b32_dpp v23, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000441864: 7E2E02FA FF01680E
	v_add_f32_e32 v9, v9, v13                                  // 00000044186C: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000441870: 7E1A02FA FF016208
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441878: BF8700A2
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044187C: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000441884: D5010009 20021309
	v_add_f32_e32 v21, v9, v12                                 // 00000044188C: 062A1909
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000441890: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000441898: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v18                                  // 0000004418A0: 06062503
	v_cndmask_b32_e64 v9, -v15, v15, s0                        // 0000004418A4: D5010009 20021F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004418AC: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 0000004418B0: 06041902
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004418B4: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004418BC: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004418C4: BF870114
	v_add_f32_e32 v19, v9, v7                                  // 0000004418C8: 06260F09
	v_add_f32_e32 v3, v3, v11                                  // 0000004418CC: 06061703
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004418D0: BF870112
	v_mov_b32_dpp v20, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004418D4: 7E2802FA FF016813
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004418DC: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000004418E4: D5010003 20020703
	v_add_f32_e32 v5, v6, v10                                  // 0000004418EC: 060A1506
	v_cndmask_b32_e64 v6, -v8, v8, vcc_lo                      // 0000004418F0: D5010006 21AA1108
	v_mov_b32_dpp v10, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004418F8: 7E1402FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000441900: D5010004 21AA0904
	v_add_f32_e32 v12, v3, v12                                 // 000000441908: 06181903
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044190C: 7E1002FA FF016805
	v_add_f32_e32 v6, v6, v13                                  // 000000441914: 060C1B06
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441918: 7E1A02FA FF016402
	v_add_f32_e32 v4, v4, v10                                  // 000000441920: 06081504
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000441924: D5010002 20020502
	v_mov_b32_dpp v22, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044192C: 7E2C02FA FF016815
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441934: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 00000044193C: D5010006 20020D06
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000441944: 7E1602FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000044194C: D5010004 20020904
	v_add_f32_e32 v9, v2, v13                                  // 000000441954: 06121B02
	v_mov_b32_dpp v13, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000441958: 7E1A02FA FF01680C
	v_add_f32_e32 v17, v6, v10                                 // 000000441960: 06221506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000441964: BF870214
	v_add_f32_e32 v15, v4, v11                                 // 000000441968: 061E1704
	v_mov_b32_dpp v10, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044196C: 7E1402FA FF016809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441974: BF870193
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000441978: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000441980: 7E2002FA FF01680F
	s_and_b32 exec_lo, exec_lo, s2                             // 000000441988: 8B7E027E
	s_cbranch_execz 62807                                      // 00000044198C: BFA5F557 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 000000441990: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 000000441998: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 00000044199C: BF118018
	s_cselect_b32 s1, -1, 0                                    // 0000004419A0: 980180C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004419A4: BF870112
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000004419A8: 3408069F
	.long 0xd44a0000                                           // 0000004419AC: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004419B0: 02020080
	s_lshr_b32 s2, s20, 31                                     // 0000004419B4: 85029F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004419B8: BF870009
	s_add_i32 s2, s20, s2                                      // 0000004419BC: 81020214
	.long 0xd73c0001                                           // 0000004419C0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000004419C4: 02020681
	v_cndmask_b32_e64 v0, -v5, v5, s0                          // 0000004419C8: D5010000 20020B05
	v_mad_i64_i32 v[4:5], null, s20, v35, 0                    // 0000004419D0: D6FF7C04 02024614
	s_ashr_i32 s2, s2, 1                                       // 0000004419D8: 86028102
	s_cmp_eq_u64 s[24:25], 0                                   // 0000004419DC: BF108018
	v_mad_i64_i32 v[24:25], null, s2, v35, 0                   // 0000004419E0: D6FF7C18 02024602
	.long 0xd7006a06                                           // 0000004419E8: D7006A06
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000004419EC: 0202020C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004419F0: BF870001
	v_add_co_ci_u32_e64 v7, null, s13, v2, vcc_lo              // 0000004419F4: D5207C07 01AA040D
	v_add_f32_e32 v0, v0, v8                                   // 0000004419FC: 06001100
	.long 0xd73c0004                                           // 000000441A00: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000441A04: 02020881
	global_load_d16_b16 v11, v[6:7], off                       // 000000441A08: DC820000 0B7C0006
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000441A10: 100000FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000441A18: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441A1C: BF8700A1
	v_fma_mix_f32 v26, v11, v0, neg(0) op_sel_hi:[1,0,0]       // 000000441A20: CC20001A 8A02010B
	.long 0xd7006a00                                           // 000000441A28: D7006A00
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000441A2C: 0202080E
	v_add_co_ci_u32_e64 v8, null, s15, v5, vcc_lo              // 000000441A30: D5207C08 01AA0A0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000441A38: BF8701B3
	v_bfe_u32 v27, v26, 16, 1                                  // 000000441A3C: D610001B 0205211A
	.long 0xd73c0004                                           // 000000441A44: D73C0004
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000441A48: 02023081
	v_ashrrev_i32_e32 v11, 31, v3                              // 000000441A4C: 3416069F
	v_add3_u32 v24, v26, v27, 0x7fff                           // 000000441A50: D6550018 03FE371A 00007FFF
	s_cbranch_scc1 570                                         // 000000441A5C: BFA2023A <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3848>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000441A60: BF870122
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000441A64: 32321697
	v_mov_b32_e32 v29, s14                                     // 000000441A68: 7E3A020E
	v_add_nc_u32_e32 v25, v3, v25                              // 000000441A6C: 4A323303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441A70: BF870091
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000441A74: 363432FF FFFFFE00
	v_sub_nc_u32_e32 v27, v3, v26                              // 000000441A7C: 4C363503
	v_mov_b32_e32 v26, s15                                     // 000000441A80: 7E34020F
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000441A84: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441A88: BF8701A3
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v27                        // 000000441A8C: 7C8836FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v27                      // 000000441A94: 4A3836FF FFFFFF00
	v_dual_cndmask_b32 v30, s25, v26 :: v_dual_lshlrev_b32 v25, 8, v25// 000000441A9C: CA623419 1E183288
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441AA4: BF870112
	v_cndmask_b32_e32 v27, v28, v27, vcc_lo                    // 000000441AA8: 0236371C
	v_ashrrev_i32_e32 v26, 31, v25                             // 000000441AAC: 3434329F
	v_cndmask_b32_e32 v29, s24, v29, vcc_lo                    // 000000441AB0: 023A3A18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441AB4: BF870193
	v_ashrrev_i32_e32 v28, 31, v27                             // 000000441AB8: 3438369F
	.long 0xd73c0019                                           // 000000441ABC: D73C0019
	v_cndmask_b32_e32 v1, 1, v25, vcc_lo                       // 000000441AC0: 02023281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441AC4: BF870093
	.long 0xd7006a1d                                           // 000000441AC8: D7006A1D
	v_cndmask_b32_e32 v1, v29, v4, vcc_lo                      // 000000441ACC: 0202091D
	v_add_co_ci_u32_e64 v30, null, v30, v5, vcc_lo             // 000000441AD0: D5207C1E 01AA0B1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441AD8: BF870194
	.long 0xd73c001b                                           // 000000441ADC: D73C001B
	v_cndmask_b32_e32 v1, 1, v27, vcc_lo                       // 000000441AE0: 02023681
	.long 0xd7006a19                                           // 000000441AE4: D7006A19
	v_cndmask_b32_e32 v1, v29, v25, vcc_lo                     // 000000441AE8: 0202331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441AEC: BF870111
	v_add_co_ci_u32_e64 v26, null, v30, v26, vcc_lo            // 000000441AF0: D5207C1A 01AA351E
	.long 0xd7006a19                                           // 000000441AF8: D7006A19
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000441AFC: 02023719
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441B00: BF870001
	v_add_co_ci_u32_e64 v26, null, v26, v28, vcc_lo            // 000000441B04: D5207C1A 01AA391A
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000441B0C: DC960000 007C1819
	s_cbranch_execnz 7                                         // 000000441B14: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3034>
	.long 0xd7006a19                                           // 000000441B18: D7006A19
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000441B1C: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441B20: BF870001
	v_add_co_ci_u32_e64 v26, null, v8, v2, vcc_lo              // 000000441B24: D5207C1A 01AA0508
	global_store_d16_hi_b16 v[25:26], v24, off                 // 000000441B2C: DC960000 007C1819
	global_load_d16_b16 v24, v[6:7], off offset:32             // 000000441B34: DC820020 187C0006
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000441B3C: D501000E 20021D0E
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000441B44: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441B48: BF870091
	v_add_f32_e32 v14, v14, v23                                // 000000441B4C: 061C2F0E
	v_mul_f32_e32 v14, 0x3db504f3, v14                         // 000000441B50: 101C1CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000441B58: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000441B5C: BF870121
	v_fma_mix_f32 v23, v24, v14, neg(0) op_sel_hi:[1,0,0]      // 000000441B60: CC200017 8A021D18
	v_cndmask_b32_e64 v14, 0, 1, s1                            // 000000441B68: D501000E 00050280
	v_bfe_u32 v24, v23, 16, 1                                  // 000000441B70: D6100018 02052117
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441B78: BF870001
	v_add3_u32 v23, v23, v24, 0x7fff                           // 000000441B7C: D6550017 03FE3117 00007FFF
	s_cbranch_vccnz 496                                        // 000000441B88: BFA401F0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x384c>
	v_or_b32_e32 v24, 16, v3                                   // 000000441B8C: 38300690
	v_lshrrev_b32_e32 v25, 23, v11                             // 000000441B90: 32321697
	v_mov_b32_e32 v27, s15                                     // 000000441B94: 7E36020F
	v_mov_b32_e32 v29, s14                                     // 000000441B98: 7E3A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441B9C: BF870093
	v_add_nc_u32_e32 v25, v24, v25                             // 000000441BA0: 4A323318
	v_and_b32_e32 v26, 0xfffffe00, v25                         // 000000441BA4: 363432FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441BAC: BF870091
	v_sub_nc_u32_e32 v26, v24, v26                             // 000000441BB0: 4C343518
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v26                        // 000000441BB4: 7C8834FF 00000100
	v_add_nc_u32_e32 v28, 0xffffff00, v26                      // 000000441BBC: 4A3834FF FFFFFF00
	v_cndmask_b32_e32 v30, s25, v27, vcc_lo                    // 000000441BC4: 023C3619
	v_ashrrev_i32_e32 v25, 9, v25                              // 000000441BC8: 34323289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441BCC: BF8701A3
	v_cndmask_b32_e32 v26, v28, v26, vcc_lo                    // 000000441BD0: 0234351C
	v_cndmask_b32_e32 v28, s24, v29, vcc_lo                    // 000000441BD4: 02383A18
	v_lshlrev_b32_e32 v24, 8, v25                              // 000000441BD8: 30303288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441BDC: BF870193
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000441BE0: 3436349F
	.long 0xd7006a1c                                           // 000000441BE4: D7006A1C
	v_cndmask_b32_e32 v1, v28, v4, vcc_lo                      // 000000441BE8: 0202091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000441BEC: BF870211
	v_add_co_ci_u32_e64 v29, null, v30, v5, vcc_lo             // 000000441BF0: D5207C1D 01AA0B1E
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000441BF8: 3432309F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441BFC: BF870114
	.long 0xd73c001a                                           // 000000441C00: D73C001A
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000441C04: 02023481
	.long 0xd73c0018                                           // 000000441C08: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000441C0C: 02023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441C10: BF870091
	.long 0xd7006a18                                           // 000000441C14: D7006A18
	v_cndmask_b32_e32 v1, v28, v24, vcc_lo                     // 000000441C18: 0202311C
	v_add_co_ci_u32_e64 v25, null, v29, v25, vcc_lo            // 000000441C1C: D5207C19 01AA331D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441C24: BF870092
	.long 0xd7006a18                                           // 000000441C28: D7006A18
	v_cndmask_b32_e32 v1, v24, v26, vcc_lo                     // 000000441C2C: 02023518
	v_add_co_ci_u32_e64 v25, null, v25, v27, vcc_lo            // 000000441C30: D5207C19 01AA3719
	global_store_d16_hi_b16 v[24:25], v23, off                 // 000000441C38: DC960000 007C1718
	s_cbranch_execnz 7                                         // 000000441C40: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3160>
	.long 0xd7006a18                                           // 000000441C44: D7006A18
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000441C48: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441C4C: BF870001
	v_add_co_ci_u32_e64 v25, null, v8, v2, vcc_lo              // 000000441C50: D5207C19 01AA0508
	global_store_d16_hi_b16 v[24:25], v23, off offset:32       // 000000441C58: DC960020 007C1718
	global_load_d16_b16 v23, v[6:7], off offset:64             // 000000441C60: DC820040 177C0006
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000441C68: D5010015 20022B15
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000441C70: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441C74: BF8700A2
	v_add_f32_e32 v21, v21, v22                                // 000000441C78: 062A2D15
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000441C7C: 8B6A6A7E
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000441C80: 102A2AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000441C88: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441C8C: BF870091
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 000000441C90: CC200015 8A022B17
	v_bfe_u32 v22, v21, 16, 1                                  // 000000441C98: D6100016 02052115
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441CA0: BF870001
	v_add3_u32 v21, v21, v22, 0x7fff                           // 000000441CA4: D6550015 03FE2D15 00007FFF
	s_cbranch_vccnz 423                                        // 000000441CB0: BFA401A7 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3850>
	v_or_b32_e32 v22, 32, v3                                   // 000000441CB4: 382C06A0
	v_lshrrev_b32_e32 v23, 23, v11                             // 000000441CB8: 322E1697
	v_mov_b32_e32 v25, s15                                     // 000000441CBC: 7E32020F
	v_mov_b32_e32 v27, s14                                     // 000000441CC0: 7E36020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441CC4: BF870093
	v_add_nc_u32_e32 v23, v22, v23                             // 000000441CC8: 4A2E2F16
	v_and_b32_e32 v24, 0xfffffe00, v23                         // 000000441CCC: 36302EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441CD4: BF870091
	v_sub_nc_u32_e32 v24, v22, v24                             // 000000441CD8: 4C303116
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v24                        // 000000441CDC: 7C8830FF 00000100
	v_add_nc_u32_e32 v26, 0xffffff00, v24                      // 000000441CE4: 4A3430FF FFFFFF00
	v_cndmask_b32_e32 v28, s25, v25, vcc_lo                    // 000000441CEC: 02383219
	v_ashrrev_i32_e32 v23, 9, v23                              // 000000441CF0: 342E2E89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441CF4: BF8701A3
	v_cndmask_b32_e32 v24, v26, v24, vcc_lo                    // 000000441CF8: 0230311A
	v_cndmask_b32_e32 v26, s24, v27, vcc_lo                    // 000000441CFC: 02343618
	v_lshlrev_b32_e32 v22, 8, v23                              // 000000441D00: 302C2E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441D04: BF870193
	v_ashrrev_i32_e32 v25, 31, v24                             // 000000441D08: 3432309F
	.long 0xd7006a1a                                           // 000000441D0C: D7006A1A
	v_cndmask_b32_e32 v1, v26, v4, vcc_lo                      // 000000441D10: 0202091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000441D14: BF870211
	v_add_co_ci_u32_e64 v27, null, v28, v5, vcc_lo             // 000000441D18: D5207C1B 01AA0B1C
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000441D20: 342E2C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441D24: BF870114
	.long 0xd73c0018                                           // 000000441D28: D73C0018
	v_cndmask_b32_e32 v1, 1, v24, vcc_lo                       // 000000441D2C: 02023081
	.long 0xd73c0016                                           // 000000441D30: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000441D34: 02022C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441D38: BF870091
	.long 0xd7006a16                                           // 000000441D3C: D7006A16
	v_cndmask_b32_e32 v1, v26, v22, vcc_lo                     // 000000441D40: 02022D1A
	v_add_co_ci_u32_e64 v23, null, v27, v23, vcc_lo            // 000000441D44: D5207C17 01AA2F1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441D4C: BF870092
	.long 0xd7006a16                                           // 000000441D50: D7006A16
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 000000441D54: 02023116
	v_add_co_ci_u32_e64 v23, null, v23, v25, vcc_lo            // 000000441D58: D5207C17 01AA3317
	global_store_d16_hi_b16 v[22:23], v21, off                 // 000000441D60: DC960000 007C1516
	s_cbranch_execnz 7                                         // 000000441D68: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3288>
	.long 0xd7006a16                                           // 000000441D6C: D7006A16
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000441D70: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441D74: BF870001
	v_add_co_ci_u32_e64 v23, null, v8, v2, vcc_lo              // 000000441D78: D5207C17 01AA0508
	global_store_d16_hi_b16 v[22:23], v21, off offset:64       // 000000441D80: DC960040 007C1516
	global_load_d16_b16 v21, v[6:7], off offset:96             // 000000441D88: DC820060 157C0006
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000441D90: D5010013 20022713
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000441D98: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441D9C: BF8700A2
	v_add_f32_e32 v19, v19, v20                                // 000000441DA0: 06262913
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000441DA4: 8B6A6A7E
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000441DA8: 102626FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000441DB0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441DB4: BF870091
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel_hi:[1,0,0]      // 000000441DB8: CC200013 8A022715
	v_bfe_u32 v20, v19, 16, 1                                  // 000000441DC0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441DC8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000441DCC: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 350                                        // 000000441DD8: BFA4015E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3854>
	v_or_b32_e32 v20, 48, v3                                   // 000000441DDC: 382806B0
	v_lshrrev_b32_e32 v21, 23, v11                             // 000000441DE0: 322A1697
	v_mov_b32_e32 v23, s15                                     // 000000441DE4: 7E2E020F
	v_mov_b32_e32 v25, s14                                     // 000000441DE8: 7E32020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441DEC: BF870093
	v_add_nc_u32_e32 v21, v20, v21                             // 000000441DF0: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 000000441DF4: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441DFC: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 000000441E00: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 000000441E04: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 000000441E0C: 4A302CFF FFFFFF00
	v_cndmask_b32_e32 v26, s25, v23, vcc_lo                    // 000000441E14: 02342E19
	v_ashrrev_i32_e32 v21, 9, v21                              // 000000441E18: 342A2A89
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441E1C: BF8701A3
	v_cndmask_b32_e32 v22, v24, v22, vcc_lo                    // 000000441E20: 022C2D18
	v_cndmask_b32_e32 v24, s24, v25, vcc_lo                    // 000000441E24: 02303218
	v_lshlrev_b32_e32 v20, 8, v21                              // 000000441E28: 30282A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441E2C: BF870193
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000441E30: 342E2C9F
	.long 0xd7006a18                                           // 000000441E34: D7006A18
	v_cndmask_b32_e32 v1, v24, v4, vcc_lo                      // 000000441E38: 02020918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000441E3C: BF870211
	v_add_co_ci_u32_e64 v25, null, v26, v5, vcc_lo             // 000000441E40: D5207C19 01AA0B1A
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000441E48: 342A289F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441E4C: BF870114
	.long 0xd73c0016                                           // 000000441E50: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000441E54: 02022C81
	.long 0xd73c0014                                           // 000000441E58: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000441E5C: 02022881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441E60: BF870091
	.long 0xd7006a14                                           // 000000441E64: D7006A14
	v_cndmask_b32_e32 v1, v24, v20, vcc_lo                     // 000000441E68: 02022918
	v_add_co_ci_u32_e64 v21, null, v25, v21, vcc_lo            // 000000441E6C: D5207C15 01AA2B19
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441E74: BF870092
	.long 0xd7006a14                                           // 000000441E78: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 000000441E7C: 02022D14
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 000000441E80: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 000000441E88: DC960000 007C1314
	s_cbranch_execnz 7                                         // 000000441E90: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x33b0>
	.long 0xd7006a14                                           // 000000441E94: D7006A14
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000441E98: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441E9C: BF870001
	v_add_co_ci_u32_e64 v21, null, v8, v2, vcc_lo              // 000000441EA0: D5207C15 01AA0508
	global_store_d16_hi_b16 v[20:21], v19, off offset:96       // 000000441EA8: DC960060 007C1314
	global_load_d16_b16 v19, v[6:7], off offset:128            // 000000441EB0: DC820080 137C0006
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000441EB8: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000441EC0: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441EC4: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 000000441EC8: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000441ECC: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000441ED0: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000441ED8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441EDC: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 000000441EE0: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 000000441EE8: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441EF0: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000441EF4: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 277                                        // 000000441F00: BFA40115 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3858>
	v_or_b32_e32 v18, 64, v3                                   // 000000441F04: 382406C0
	v_lshrrev_b32_e32 v19, 23, v11                             // 000000441F08: 32261697
	v_mov_b32_e32 v21, s15                                     // 000000441F0C: 7E2A020F
	v_mov_b32_e32 v23, s14                                     // 000000441F10: 7E2E020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441F14: BF870093
	v_add_nc_u32_e32 v19, v18, v19                             // 000000441F18: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 000000441F1C: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441F24: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 000000441F28: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 000000441F2C: 7C8828FF 00000100
	v_add_nc_u32_e32 v22, 0xffffff00, v20                      // 000000441F34: 4A2C28FF FFFFFF00
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 000000441F3C: 02302A19
	v_ashrrev_i32_e32 v19, 9, v19                              // 000000441F40: 34262689
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000441F44: BF8701A3
	v_cndmask_b32_e32 v20, v22, v20, vcc_lo                    // 000000441F48: 02282916
	v_cndmask_b32_e32 v22, s24, v23, vcc_lo                    // 000000441F4C: 022C2E18
	v_lshlrev_b32_e32 v18, 8, v19                              // 000000441F50: 30242688
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000441F54: BF870193
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000441F58: 342A289F
	.long 0xd7006a16                                           // 000000441F5C: D7006A16
	v_cndmask_b32_e32 v1, v22, v4, vcc_lo                      // 000000441F60: 02020916
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000441F64: BF870211
	v_add_co_ci_u32_e64 v23, null, v24, v5, vcc_lo             // 000000441F68: D5207C17 01AA0B18
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000441F70: 3426249F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000441F74: BF870114
	.long 0xd73c0014                                           // 000000441F78: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000441F7C: 02022881
	.long 0xd73c0012                                           // 000000441F80: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000441F84: 02022481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441F88: BF870091
	.long 0xd7006a12                                           // 000000441F8C: D7006A12
	v_cndmask_b32_e32 v1, v22, v18, vcc_lo                     // 000000441F90: 02022516
	v_add_co_ci_u32_e64 v19, null, v23, v19, vcc_lo            // 000000441F94: D5207C13 01AA2717
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000441F9C: BF870092
	.long 0xd7006a12                                           // 000000441FA0: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 000000441FA4: 02022912
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 000000441FA8: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 000000441FB0: DC960000 007C1112
	s_cbranch_execnz 7                                         // 000000441FB8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x34d8>
	.long 0xd7006a12                                           // 000000441FBC: D7006A12
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000441FC0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000441FC4: BF870001
	v_add_co_ci_u32_e64 v19, null, v8, v2, vcc_lo              // 000000441FC8: D5207C13 01AA0508
	global_store_d16_hi_b16 v[18:19], v17, off offset:128      // 000000441FD0: DC960080 007C1112
	global_load_d16_b16 v17, v[6:7], off offset:160            // 000000441FD8: DC8200A0 117C0006
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000441FE0: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000441FE8: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000441FEC: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 000000441FF0: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000441FF4: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000441FF8: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000442000: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442004: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 000000442008: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 000000442010: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000442018: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 00000044201C: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 204                                        // 000000442028: BFA400CC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x385c>
	v_or_b32_e32 v16, 0x50, v3                                 // 00000044202C: 382006FF 00000050
	v_lshrrev_b32_e32 v17, 23, v11                             // 000000442034: 32221697
	v_mov_b32_e32 v19, s15                                     // 000000442038: 7E26020F
	v_mov_b32_e32 v21, s14                                     // 00000044203C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442040: BF870093
	v_add_nc_u32_e32 v17, v16, v17                             // 000000442044: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 000000442048: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442050: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 000000442054: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 000000442058: 7C8824FF 00000100
	v_add_nc_u32_e32 v20, 0xffffff00, v18                      // 000000442060: 4A2824FF FFFFFF00
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 000000442068: 022C2619
	v_ashrrev_i32_e32 v17, 9, v17                              // 00000044206C: 34222289
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000442070: BF8701A3
	v_cndmask_b32_e32 v18, v20, v18, vcc_lo                    // 000000442074: 02242514
	v_cndmask_b32_e32 v20, s24, v21, vcc_lo                    // 000000442078: 02282A18
	v_lshlrev_b32_e32 v16, 8, v17                              // 00000044207C: 30202288
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000442080: BF870193
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000442084: 3426249F
	.long 0xd7006a14                                           // 000000442088: D7006A14
	v_cndmask_b32_e32 v1, v20, v4, vcc_lo                      // 00000044208C: 02020914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000442090: BF870211
	v_add_co_ci_u32_e64 v21, null, v22, v5, vcc_lo             // 000000442094: D5207C15 01AA0B16
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000044209C: 3422209F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004420A0: BF870114
	.long 0xd73c0012                                           // 0000004420A4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004420A8: 02022481
	.long 0xd73c0010                                           // 0000004420AC: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000004420B0: 02022081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004420B4: BF870091
	.long 0xd7006a10                                           // 0000004420B8: D7006A10
	v_cndmask_b32_e32 v1, v20, v16, vcc_lo                     // 0000004420BC: 02022114
	v_add_co_ci_u32_e64 v17, null, v21, v17, vcc_lo            // 0000004420C0: D5207C11 01AA2315
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004420C8: BF870092
	.long 0xd7006a10                                           // 0000004420CC: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000004420D0: 02022510
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 0000004420D4: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 0000004420DC: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 0000004420E4: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3604>
	.long 0xd7006a10                                           // 0000004420E8: D7006A10
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000004420EC: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004420F0: BF870001
	v_add_co_ci_u32_e64 v17, null, v8, v2, vcc_lo              // 0000004420F4: D5207C11 01AA0508
	global_store_d16_hi_b16 v[16:17], v15, off offset:160      // 0000004420FC: DC9600A0 007C0F10
	global_load_d16_b16 v15, v[6:7], off offset:192            // 000000442104: DC8200C0 0F7C0006
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 00000044210C: D501000C 2002190C
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000442114: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000442118: BF8700A2
	v_add_f32_e32 v12, v12, v13                                // 00000044211C: 06181B0C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000442120: 8B6A6A7E
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000442124: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 00000044212C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442130: BF870091
	v_fma_mix_f32 v12, v15, v12, neg(0) op_sel_hi:[1,0,0]      // 000000442134: CC20000C 8A02190F
	v_bfe_u32 v13, v12, 16, 1                                  // 00000044213C: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000442144: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 000000442148: D655000C 03FE1B0C 00007FFF
	s_cbranch_vccnz 130                                        // 000000442154: BFA40082 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3860>
	v_or_b32_e32 v13, 0x60, v3                                 // 000000442158: 381A06FF 00000060
	v_lshrrev_b32_e32 v15, 23, v11                             // 000000442160: 321E1697
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442164: BF870091
	v_dual_mov_b32 v18, s14 :: v_dual_add_nc_u32 v15, v13, v15 // 000000442168: CA20000E 120E1F0D
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 000000442170: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000442178: BF8701B1
	v_sub_nc_u32_e32 v13, v13, v16                             // 00000044217C: 4C1A210D
	v_mov_b32_e32 v16, s15                                     // 000000442180: 7E20020F
	v_ashrrev_i32_e32 v15, 9, v15                              // 000000442184: 341E1E89
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v13                        // 000000442188: 7C881AFF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v13                      // 000000442190: 4A221AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000442198: BF8701A3
	v_lshlrev_b32_e32 v15, 8, v15                              // 00000044219C: 301E1E88
	v_cndmask_b32_e32 v19, s25, v16, vcc_lo                    // 0000004421A0: 02262019
	v_cndmask_b32_e32 v17, v17, v13, vcc_lo                    // 0000004421A4: 02221B11
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004421A8: BF8701A3
	v_ashrrev_i32_e32 v16, 31, v15                             // 0000004421AC: 34201E9F
	v_cndmask_b32_e32 v13, s24, v18, vcc_lo                    // 0000004421B0: 021A2418
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000004421B4: 3424229F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004421B8: BF870193
	.long 0xd73c000f                                           // 0000004421BC: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000004421C0: 02021E81
	.long 0xd7006a0d                                           // 0000004421C4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v4, vcc_lo                      // 0000004421C8: 0202090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004421CC: BF870211
	v_add_co_ci_u32_e64 v19, null, v19, v5, vcc_lo             // 0000004421D0: D5207C13 01AA0B13
	.long 0xd73c0011                                           // 0000004421D8: D73C0011
	v_cndmask_b32_e32 v1, 1, v17, vcc_lo                       // 0000004421DC: 02022281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004421E0: BF870093
	.long 0xd7006a0d                                           // 0000004421E4: D7006A0D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 0000004421E8: 02021F0D
	v_add_co_ci_u32_e64 v16, null, v19, v16, vcc_lo            // 0000004421EC: D5207C10 01AA2113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004421F4: BF870092
	.long 0xd7006a0f                                           // 0000004421F8: D7006A0F
	v_cndmask_b32_e32 v1, v13, v17, vcc_lo                     // 0000004421FC: 0202230D
	v_add_co_ci_u32_e64 v16, null, v16, v18, vcc_lo            // 000000442200: D5207C10 01AA2510
	global_store_d16_hi_b16 v[15:16], v12, off                 // 000000442208: DC960000 007C0C0F
	s_cbranch_execnz 7                                         // 000000442210: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3730>
	.long 0xd7006a0f                                           // 000000442214: D7006A0F
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000442218: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044221C: BF870001
	v_add_co_ci_u32_e64 v16, null, v8, v2, vcc_lo              // 000000442220: D5207C10 01AA0508
	global_store_d16_hi_b16 v[15:16], v12, off offset:192      // 000000442228: DC9600C0 007C0C0F
	global_load_d16_b16 v6, v[6:7], off offset:224             // 000000442230: DC8200E0 067C0006
	v_cndmask_b32_e64 v7, -v9, v9, s0                          // 000000442238: D5010007 20021309
	v_cmp_ne_u32_e32 vcc_lo, 1, v14                            // 000000442240: 7C9A1C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000442244: BF8700A2
	v_add_f32_e32 v7, v7, v10                                  // 000000442248: 060E1507
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000044224C: 8B6A6A7E
	v_mul_f32_e32 v7, 0x3db504f3, v7                           // 000000442250: 100E0EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000442258: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044225C: BF870091
	v_fma_mix_f32 v6, v6, v7, neg(0) op_sel_hi:[1,0,0]         // 000000442260: CC200006 8A020F06
	v_bfe_u32 v7, v6, 16, 1                                    // 000000442268: D6100007 02052106
	s_delay_alu instid0(VALU_DEP_1)                            // 000000442270: BF870001
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000442274: D6550006 03FE0F06 00007FFF
	s_cbranch_vccnz 56                                         // 000000442280: BFA40038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3864>
	v_or_b32_e32 v3, 0x70, v3                                  // 000000442284: 380606FF 00000070
	v_lshrrev_b32_e32 v7, 23, v11                              // 00000044228C: 320E1697
	v_mov_b32_e32 v10, s15                                     // 000000442290: 7E14020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442294: BF870092
	v_dual_mov_b32 v12, s14 :: v_dual_add_nc_u32 v7, v3, v7    // 000000442298: CA20000E 0C060F03
	v_and_b32_e32 v9, 0xfffffe00, v7                           // 0000004422A0: 36120EFF FFFFFE00
	v_ashrrev_i32_e32 v7, 9, v7                                // 0000004422A8: 340E0E89
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004422AC: BF870112
	v_sub_nc_u32_e32 v3, v3, v9                                // 0000004422B0: 4C061303
	v_lshlrev_b32_e32 v9, 8, v7                                // 0000004422B4: 30120E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004422B8: BF870232
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 0000004422BC: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 0000004422C4: 4A0E06FF FFFFFF00
	v_cndmask_b32_e32 v13, s25, v10, vcc_lo                    // 0000004422CC: 021A1419
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000004422D0: 3414129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004422D4: BF8701A3
	v_cndmask_b32_e32 v11, v7, v3, vcc_lo                      // 0000004422D8: 02160707
	v_cndmask_b32_e32 v3, s24, v12, vcc_lo                     // 0000004422DC: 02061818
	.long 0xd73c0009                                           // 0000004422E0: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000004422E4: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004422E8: BF870193
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000004422EC: 3418169F
	.long 0xd7006a07                                           // 0000004422F0: D7006A07
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 0000004422F4: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004422F8: BF870191
	v_add_co_ci_u32_e64 v5, null, v13, v5, vcc_lo              // 0000004422FC: D5207C05 01AA0B0D
	.long 0xd73c0003                                           // 000000442304: D73C0003
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000442308: 02021681
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044230C: BF870093
	.long 0xd7006a07                                           // 000000442310: D7006A07
	v_cndmask_b32_e32 v1, v7, v9, vcc_lo                       // 000000442314: 02021307
	v_add_co_ci_u32_e64 v5, null, v5, v10, vcc_lo              // 000000442318: D5207C05 01AA1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000442320: BF870092
	.long 0xd7006a03                                           // 000000442324: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 000000442328: 02020707
	v_add_co_ci_u32_e64 v4, null, v5, v4, vcc_lo               // 00000044232C: D5207C04 01AA0905
	global_store_d16_hi_b16 v[3:4], v6, off                    // 000000442334: DC960000 007C0603
	s_cbranch_execnz 62187                                     // 00000044233C: BFA6F2EB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 8                                                 // 000000442340: BFA00008 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3864>
	s_branch 62185                                             // 000000442344: BFA0F2E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 65011                                             // 000000442348: BFA0FDF3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3018>
	s_branch 65085                                             // 00000044234C: BFA0FE3D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3144>
	s_branch 65158                                             // 000000442350: BFA0FE86 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x326c>
	s_branch 65231                                             // 000000442354: BFA0FECF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3394>
	s_branch 65304                                             // 000000442358: BFA0FF18 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x34bc>
	s_branch 65378                                             // 00000044235C: BFA0FF62 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x35e8>
	s_branch 65452                                             // 000000442360: BFA0FFAC <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi8ELb1ELb0ELb0ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3714>
	.long 0xd7006a00                                           // 000000442364: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000442368: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044236C: BF870001
	v_add_co_ci_u32_e64 v1, null, v8, v2, vcc_lo               // 000000442370: D5207C01 01AA0508
	global_store_d16_hi_b16 v[0:1], v6, off offset:224         // 000000442378: DC9600E0 007C0600
	s_nop 0                                                    // 000000442380: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000442384: BFB60003
	s_endpgm                                                   // 000000442388: BFB00000
		...

