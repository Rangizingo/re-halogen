0000000000860b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000860B00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000860B08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000860B10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000860B14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000860B18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000860B1C: CA220080 10000282
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000860B24: 84828302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000860B28: BF870482
	v_dual_mov_b32 v9, s3 :: v_dual_and_b32 v2, 60, v2         // 000000860B2C: CA240003 090204BC
	.long 0x7f183880                                           // 000000860B34: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 000000860B38: 361E009F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v6, 0              // 000000860B3C: CA100080 1B060080
	s_waitcnt lgkmcnt(0)                                       // 000000860B44: BF89FC07
	s_clause 0x1                                               // 000000860B48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000860B4C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000860B54: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000860B5C: 32020085
	s_add_u32 s14, s4, s14                                     // 000000860B60: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000860B64: 820F0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000860B68: BF8704A1
	v_or_b32_e32 v8, s2, v1                                    // 000000860B6C: 38100202
	s_lshr_b32 s2, s11, 31                                     // 000000860B70: 85029F0B
	s_add_u32 s20, s10, s2                                     // 000000860B74: 8014020A
	s_addc_u32 s21, s11, 0                                     // 000000860B78: 8215800B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000860B7C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000860B80: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 000000860B84: 7E0A0280
	s_ashr_i32 s22, s11, 31                                    // 000000860B88: 86169F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000860B8C: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 000000860B90: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 000000860B98: 86828114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000860B9C: BF870002
	.long 0xd72c000d                                           // 000000860BA0: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000860BA4: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000860BA8: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000860BB0: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 000000860BB4: 0200070A
	.long 0xd72c0013                                           // 000000860BB8: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 000000860BBC: 0200050E
	s_lshr_b32 s19, s22, 27                                    // 000000860BC0: 85139B16
	s_waitcnt vmcnt(1)                                         // 000000860BC4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000860BC8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000860BD0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 000000860BD4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 000000860BDC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000860BE0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 000000860BEC: D6FE7C0A 0038050A
	s_add_u32 s14, s10, s19                                    // 000000860BF4: 800E130A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000860BF8: D6550007 03FE2507 00007FFF
	s_addc_u32 s15, s11, 0                                     // 000000860C04: 820F800B
	.long 0x7e183983                                           // 000000860C08: 7E183983
	.long 0xd72c0003                                           // 000000860C0C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000860C10: 02021C12
	s_lshr_b64 s[14:15], s[14:15], 5                           // 000000860C14: 858E850E
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000860C18: 301C0082
	.long 0xd4440002                                           // 000000860C1C: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 000000860C20: 02021E0E
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 000000860C24: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 000000860C30: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 000000860C34: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 000000860C3C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 000000860C44: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 000000860C4C: BF89FC07
	s_barrier                                                  // 000000860C50: BFBD0000
	buffer_gl0_inv                                             // 000000860C54: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 000000860C5C: BE8F2002
	s_cbranch_execz 26                                         // 000000860C60: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s3, s4, s16                                      // 000000860C64: 80031004
	s_addc_u32 s18, s5, s17                                    // 000000860C68: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000860C6C: 30041E81
	.long 0xd7000303                                           // 000000860C70: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 000000860C74: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860C78: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 000000860C7C: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000860C84: 300A1E84
	.long 0xd7000302                                           // 000000860C88: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000860C8C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000860C90: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 000000860C94: D5207C03 000E0880
	.long 0xd7000304                                           // 000000860C9C: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000860CA0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000860CA4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 000000860CA8: D5207C05 000E2280
	s_clause 0x1                                               // 000000860CB0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000860CB4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000860CBC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000860CC4: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 000000860CC8: 7E361702
	s_or_b32 exec_lo, exec_lo, s15                             // 000000860CCC: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000860CD0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000860CD8: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000860CE0: CA100080 16160080
	s_and_saveexec_b32 s15, s2                                 // 000000860CE8: BE8F2002
	s_cbranch_execz 597                                        // 000000860CEC: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb44>
	s_mul_i32 s2, s11, 6                                       // 000000860CF0: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 000000860CF4: 9683860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 000000860CF8: CA22010F 19021E81
	s_add_i32 s20, s3, s2                                      // 000000860D00: 81140203
	.long 0xd7000201                                           // 000000860D04: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000860D08: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860D0C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 000000860D10: D5207C00 000A0011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000860D18: CA220080 0C0A1E85
	.long 0xd7000201                                           // 000000860D20: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000860D24: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860D28: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 000000860D2C: D5207C00 000A0080
	v_lshl_or_b32 v24, v15, 4, 0x200                           // 000000860D34: D6560018 03FD090F 00000200
	.long 0xd7000201                                           // 000000860D40: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000860D44: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000860D48: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 000000860D4C: D5207C00 000A0005
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 000000860D54: CA10010C 171A011B
	.long 0xd700020d                                           // 000000860D5C: D700020D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000860D60: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000860D64: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 000000860D68: D5207C0E 000A0080
	v_mov_b32_e32 v22, v12                                     // 000000860D70: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000860D74: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000860D78: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000860D7C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000860D80: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000860D84: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 000000860D88: 8492820A
	s_mul_i32 s17, s10, 6                                      // 000000860D8C: 9611860A
	s_mov_b32 s16, 0                                           // 000000860D90: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000860D94: 8484810A
	s_branch 528                                               // 000000860D98: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000860D9C: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 000000860DA0: 363808FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 000000860DA8: 8B02027E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 000000860DAC: 4A3030FF 00000200
	s_or_b32 s16, s2, s16                                      // 000000860DB4: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860DB8: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 000000860DBC: 30383882
	ds_load_b32 v44, v28                                       // 000000860DC0: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 000000860DC8: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000860DCC: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 000000860DD4: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 000000860DDC: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000860DE0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000860DE4: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000860DE8: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860DF0: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 000000860DF8: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 000000860E00: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000860E08: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860E10: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000860E14: 30080882
	ds_load_b32 v48, v4                                        // 000000860E18: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000860E20: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860E24: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000860E2C: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000860E34: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860E38: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860E3C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000860E44: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000860E4C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860E50: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000860E58: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000860E60: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860E68: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000860E6C: 30080882
	ds_load_b32 v52, v4                                        // 000000860E70: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000860E78: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860E7C: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000860E84: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000860E8C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860E90: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860E94: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 000000860E9C: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000860EA4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860EA8: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 000000860EB0: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 000000860EB8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860EC0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000860EC4: 30080882
	ds_load_b32 v56, v4                                        // 000000860EC8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 000000860ED0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860ED4: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 000000860EDC: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 000000860EE4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000860EE8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860EEC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 000000860EF4: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 000000860EFC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000860F00: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 000000860F08: D8D80000 3B000004
	.long 0xd73c0004                                           // 000000860F10: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000860F14: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000860F18: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000860F20: BF870092
	.long 0xd7000228                                           // 000000860F24: D7000228
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000860F28: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s2                  // 000000860F2C: D5207C29 000A0A07
	s_clause 0x3                                               // 000000860F34: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000860F38: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000860F40: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000860F48: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000860F50: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000860F58: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000860F5C: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 000000860F64: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860F68: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000860F6C: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 000000860F74: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000860F78: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 000000860F80: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860F84: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000860F88: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000860F90: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000860F94: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 000000860F9C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860FA0: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000860FA4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 000000860FAC: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000860FB0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 000000860FB8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860FBC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000860FC0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000860FC8: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000860FCC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 000000860FD4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860FD8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000860FDC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 000000860FE4: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000860FE8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 000000860FF0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000860FF4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000860FF8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000861000: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000861004: CC1A4004 1C127124
	.long 0xd7000224                                           // 00000086100C: D7000224
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000861010: 02000928
	s_waitcnt lgkmcnt(2)                                       // 000000861014: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000861018: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000086101C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s2                 // 000000861024: D5207C25 000A5205
	.long 0xd700022a                                           // 00000086102C: D700022A
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 000000861030: 02002528
	s_waitcnt lgkmcnt(1)                                       // 000000861034: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000861038: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s19, v41, s2                // 000000861040: D5207C2B 000A5213
	.long 0xd7000228                                           // 000000861048: D7000228
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 00000086104C: 02002328
	s_waitcnt lgkmcnt(0)                                       // 000000861050: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000861054: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000861058: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s20, v41, s2                // 000000861060: D5207C29 000A5214
	v_fmac_f32_e32 v23, v27, v4                                // 000000861068: 562E091B
	s_clause 0x3                                               // 00000086106C: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000861070: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000861078: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000861080: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000861088: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000861090: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861094: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086109C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000008610A0: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000008610A8: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008610B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000008610B4: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000008610BC: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008610C0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008610C8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008610CC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008610D4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008610DC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008610E0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008610E8: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008610EC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008610F4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008610F8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000861100: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861108: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000086110C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000861114: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000861118: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861120: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000861124: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000086112C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861134: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000861138: CC1A4004 1C127727
	v_fmac_f32_e32 v22, v27, v4                                // 000000861140: 562C091B
	s_clause 0x3                                               // 000000861144: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000861148: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000861150: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000861158: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000861160: DC5E0030 247C002A
	.long 0xd700022a                                           // 000000861168: D700022A
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 00000086116C: 0200252A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000861170: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s19, v43, s2                // 000000861174: D5207C2B 000A5613
	s_waitcnt vmcnt(3)                                         // 00000086117C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861180: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000861188: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861190: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000861194: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 00000086119C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000008611A4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008611A8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000008611AC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000008611B4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008611BC: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000008611C0: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008611C8: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008611D0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008611D4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008611D8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008611E0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008611E8: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008611EC: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008611F4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008611FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861200: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000861204: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000086120C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861214: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000861218: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000861220: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 000000861228: BF870001
	v_fmac_f32_e32 v21, v27, v4                                // 00000086122C: 562A091B
	s_clause 0x3                                               // 000000861230: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000861234: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 00000086123C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000861244: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 00000086124C: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 000000861254: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861258: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861260: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000861264: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 00000086126C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861274: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000861278: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000861280: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000861284: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086128C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000861290: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000861298: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008612A0: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000008612A4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000008612AC: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000008612B0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008612B8: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000008612BC: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000008612C4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008612CC: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008612D0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008612D8: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008612DC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008612E4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008612E8: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008612F0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008612F8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008612FC: CC1A4004 1C127727
	v_fmac_f32_e32 v20, v27, v4                                // 000000861304: 5628091B
	s_clause 0x3                                               // 000000861308: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 00000086130C: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000861314: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 00000086131C: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000861324: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 00000086132C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861330: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861338: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000086133C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000861344: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086134C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000861350: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000861358: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000086135C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861364: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000861368: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000861370: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861378: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000086137C: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000861384: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000861388: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861390: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000861394: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000086139C: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008613A4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000008613A8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000008613B0: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008613B4: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000008613BC: D7000224
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000008613C0: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008613C4: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008613C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v41, s2                // 0000008613D0: D5207C25 000A5213
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008613D8: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008613E0: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008613E4: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 0000008613EC: 5626091B
	s_clause 0x3                                               // 0000008613F0: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000008613F4: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000008613FC: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000861404: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 00000086140C: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000861414: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861418: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861420: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000861424: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 00000086142C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861434: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000861438: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000861440: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000861444: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086144C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000861450: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000861458: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861460: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000861464: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 00000086146C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000861470: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861478: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000086147C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000861484: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000086148C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000861490: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000861498: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000086149C: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000008614A4: D7000224
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000008614A8: 0200252A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008614AC: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008614B0: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v43, s2                // 0000008614B8: D5207C25 000A5613
	.long 0xd700020d                                           // 0000008614C0: D700020D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 0000008614C4: 0201810D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008614C8: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 0000008614D0: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008614D8: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008614DC: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 0000008614E4: 5624091B
	s_clause 0x3                                               // 0000008614E8: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000008614EC: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000008614F4: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000008614FC: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000861504: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 00000086150C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000861510: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000861518: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000086151C: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 000000861524: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000861528: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 000000861530: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000861534: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000861538: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 000000861540: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000861544: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000861548: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861550: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000861554: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000086155C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861564: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000861568: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000861570: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000861574: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086157C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000861580: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000861588: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861590: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000861594: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 00000086159C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000008615A0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008615A8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000008615AC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000008615B4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008615BC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000008615C0: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 0000008615C8: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 0000008615CC: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008615D4: 917E107E
	s_cbranch_execz 25                                         // 0000008615D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	s_waitcnt vmcnt(0)                                         // 0000008615DC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008615E0: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 32, v25    // 0000008615E4: CA200104 001832A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000008615EC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000008615F4: 7E060307
	.long 0xd4430002                                           // 0000008615F8: D4430002
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 0000008615FC: 0202320E
	s_mov_b32 s10, exec_lo                                     // 000000861600: BE8A007E
	.long 0xd4c4007e                                           // 000000861604: D4C4007E
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 000000861608: 0202320E
	s_cbranch_execz 64995                                      // 00000086160C: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000300                                           // 000000861610: D7000300
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 000000861614: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000861618: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 00000086161C: D5207C01 000E2280
	global_load_d16_b16 v26, v[13:14], off                     // 000000861624: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000086162C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000861634: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 000000861638: 7E34171A
	s_branch 64983                                             // 00000086163C: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000861640: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861644: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 000000861648: 8C7E0F7E
	.long 0xd71f0000                                           // 00000086164C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000861650: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000861654: 3A020090
	v_xor_b32_e32 v10, 8, v0                                   // 000000861658: 3A140088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000086165C: BF870092
	.long 0xd44c0002                                           // 000000861660: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000861664: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 000000861668: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861670: BF870113
	.long 0xd44c0002                                           // 000000861674: D44C0002
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000861678: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000086167C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000861680: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s2                         // 000000861684: D501000A 000A1500
	ds_bpermute_b32 v2, v1, v23                                // 00000086168C: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 000000861694: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000861698: 06040517
	s_waitcnt vmcnt(0)                                         // 00000086169C: BF8903F7
	ds_bpermute_b32 v4, v1, v21                                // 0000008616A0: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 0000008616A8: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 0000008616B0: DACC0000 05001401
	ds_bpermute_b32 v6, v1, v19                                // 0000008616B8: DACC0000 06001301
	ds_bpermute_b32 v7, v1, v18                                // 0000008616C0: DACC0000 07001201
	ds_bpermute_b32 v1, v1, v16                                // 0000008616C8: DACC0000 01001001
	v_lshlrev_b32_e32 v10, 2, v10                              // 0000008616D0: 30141482
	s_waitcnt lgkmcnt(4)                                       // 0000008616D4: BF89FC47
	v_dual_add_f32 v4, v21, v4 :: v_dual_add_f32 v3, v22, v3   // 0000008616D8: C9080915 04020716
	s_waitcnt lgkmcnt(2)                                       // 0000008616E0: BF89FC27
	v_dual_add_f32 v5, v20, v5 :: v_dual_add_f32 v6, v19, v6   // 0000008616E4: C9080B14 05060D13
	s_waitcnt lgkmcnt(1)                                       // 0000008616EC: BF89FC17
	v_add_f32_e32 v7, v18, v7                                  // 0000008616F0: 060E0F12
	ds_bpermute_b32 v13, v10, v4                               // 0000008616F4: DACC0000 0D00040A
	ds_bpermute_b32 v11, v10, v2                               // 0000008616FC: DACC0000 0B00020A
	ds_bpermute_b32 v12, v10, v3                               // 000000861704: DACC0000 0C00030A
	ds_bpermute_b32 v14, v10, v5                               // 00000086170C: DACC0000 0E00050A
	v_xor_b32_e32 v18, 4, v0                                   // 000000861714: 3A240084
	ds_bpermute_b32 v17, v10, v7                               // 000000861718: DACC0000 1100070A
	.long 0xd44c0002                                           // 000000861720: D44C0002
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000861724: 020224A0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000861728: BF870001
	v_cndmask_b32_e64 v18, v0, v18, s2                         // 00000086172C: D5010012 000A2500
	s_waitcnt lgkmcnt(5)                                       // 000000861734: BF89FC57
	v_add_f32_e32 v1, v16, v1                                  // 000000861738: 06020310
	ds_bpermute_b32 v16, v10, v6                               // 00000086173C: DACC0000 1000060A
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000861744: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 000000861748: DACC0000 0A00010A
	s_waitcnt lgkmcnt(6)                                       // 000000861750: BF89FC67
	v_add_f32_e32 v4, v4, v13                                  // 000000861754: 06081B04
	s_waitcnt lgkmcnt(4)                                       // 000000861758: BF89FC47
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 00000086175C: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 000000861764: BF89FC37
	v_add_f32_e32 v5, v5, v14                                  // 000000861768: 060A1D05
	s_waitcnt lgkmcnt(2)                                       // 00000086176C: BF89FC27
	v_add_f32_e32 v7, v7, v17                                  // 000000861770: 060E2307
	ds_bpermute_b32 v12, v18, v4                               // 000000861774: DACC0000 0C000412
	ds_bpermute_b32 v11, v18, v3                               // 00000086177C: DACC0000 0B000312
	ds_bpermute_b32 v13, v18, v5                               // 000000861784: DACC0000 0D000512
	s_waitcnt lgkmcnt(4)                                       // 00000086178C: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 000000861790: 060C2106
	ds_bpermute_b32 v16, v18, v7                               // 000000861794: DACC0000 10000712
	s_waitcnt lgkmcnt(4)                                       // 00000086179C: BF89FC47
	v_add_f32_e32 v1, v1, v10                                  // 0000008617A0: 06021501
	ds_bpermute_b32 v10, v18, v2                               // 0000008617A4: DACC0000 0A000212
	ds_bpermute_b32 v14, v18, v6                               // 0000008617AC: DACC0000 0E000612
	s_waitcnt lgkmcnt(5)                                       // 0000008617B4: BF89FC57
	v_add_f32_e32 v4, v4, v12                                  // 0000008617B8: 06081904
	ds_bpermute_b32 v17, v18, v1                               // 0000008617BC: DACC0000 11000112
	v_xor_b32_e32 v18, 2, v0                                   // 0000008617C4: 3A240082
	s_waitcnt lgkmcnt(4)                                       // 0000008617C8: BF89FC47
	v_add_f32_e32 v5, v5, v13                                  // 0000008617CC: 060A1B05
	v_xor_b32_e32 v12, 1, v0                                   // 0000008617D0: 3A180081
	v_add_f32_e32 v3, v3, v11                                  // 0000008617D4: 06061703
	.long 0xd44c0002                                           // 0000008617D8: D44C0002
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 0000008617DC: 020224A0
	s_waitcnt lgkmcnt(3)                                       // 0000008617E0: BF89FC37
	v_add_f32_e32 v7, v7, v16                                  // 0000008617E4: 060E2107
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008617E8: BF870002
	v_cndmask_b32_e64 v18, v0, v18, s2                         // 0000008617EC: D5010012 000A2500
	.long 0xd44c0002                                           // 0000008617F4: D44C0002
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000008617F8: 020218A0
	s_waitcnt lgkmcnt(2)                                       // 0000008617FC: BF89FC27
	v_add_f32_e32 v2, v2, v10                                  // 000000861800: 06041502
	s_waitcnt lgkmcnt(1)                                       // 000000861804: BF89FC17
	v_add_f32_e32 v6, v6, v14                                  // 000000861808: 060C1D06
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000086180C: 30242482
	v_cndmask_b32_e64 v0, v0, v12, s2                          // 000000861810: D5010000 000A1900
	.long 0xd44a0002                                           // 000000861818: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000086181C: 02021E80
	ds_bpermute_b32 v11, v18, v3                               // 000000861820: DACC0000 0B000312
	s_waitcnt lgkmcnt(1)                                       // 000000861828: BF89FC17
	v_add_f32_e32 v10, v1, v17                                 // 00000086182C: 06142301
	ds_bpermute_b32 v1, v18, v2                                // 000000861830: DACC0000 01000212
	ds_bpermute_b32 v14, v18, v4                               // 000000861838: DACC0000 0E000412
	ds_bpermute_b32 v16, v18, v5                               // 000000861840: DACC0000 10000512
	ds_bpermute_b32 v17, v18, v6                               // 000000861848: DACC0000 11000612
	ds_bpermute_b32 v19, v18, v7                               // 000000861850: DACC0000 13000712
	v_lshlrev_b32_e32 v20, 2, v0                               // 000000861858: 30280082
	s_and_b32 s2, s2, vcc_lo                                   // 00000086185C: 8B026A02
	s_waitcnt lgkmcnt(5)                                       // 000000861860: BF89FC57
	v_add_f32_e32 v13, v3, v11                                 // 000000861864: 061A1703
	ds_bpermute_b32 v18, v18, v10                              // 000000861868: DACC0000 12000A12
	s_waitcnt lgkmcnt(4)                                       // 000000861870: BF89FC47
	v_dual_add_f32 v12, v2, v1 :: v_dual_add_f32 v1, v4, v14   // 000000861874: C9080302 0C001D04
	s_waitcnt lgkmcnt(2)                                       // 00000086187C: BF89FC27
	v_dual_add_f32 v2, v5, v16 :: v_dual_add_f32 v3, v6, v17   // 000000861880: C9082105 02022306
	s_waitcnt lgkmcnt(1)                                       // 000000861888: BF89FC17
	v_add_f32_e32 v0, v7, v19                                  // 00000086188C: 06002707
	ds_bpermute_b32 v14, v20, v12                              // 000000861890: DACC0000 0E000C14
	ds_bpermute_b32 v16, v20, v13                              // 000000861898: DACC0000 10000D14
	ds_bpermute_b32 v6, v20, v1                                // 0000008618A0: DACC0000 06000114
	ds_bpermute_b32 v7, v20, v2                                // 0000008618A8: DACC0000 07000214
	s_waitcnt lgkmcnt(4)                                       // 0000008618B0: BF89FC47
	v_add_f32_e32 v5, v10, v18                                 // 0000008618B4: 060A250A
	ds_bpermute_b32 v10, v20, v3                               // 0000008618B8: DACC0000 0A000314
	ds_bpermute_b32 v4, v20, v0                                // 0000008618C0: DACC0000 04000014
	ds_bpermute_b32 v11, v20, v5                               // 0000008618C8: DACC0000 0B000514
	s_and_saveexec_b32 s3, s2                                  // 0000008618D0: BE832002
	s_cbranch_execz 321                                        // 0000008618D4: BFA50141 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x12dc>
	s_load_b32 s2, s[0:1], 0x48                                // 0000008618D8: F4000080 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000008618E0: BF89FC07
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v13, v13, v16// 0000008618E4: C9081D0C 0C0C210D
	v_add_f32_e32 v5, v5, v11                                  // 0000008618EC: 060A1705
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v10    // 0000008618F0: C9080F02 02021503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008618F8: BF870213
	v_bfe_u32 v14, v12, 16, 1                                  // 0000008618FC: D610000E 0205210C
	v_bfe_u32 v15, v13, 16, 1                                  // 000000861904: D610000F 0205210D
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000086190C: 8480820C
	s_lshl_b64 s[4:5], s[12:13], 3                             // 000000861910: 8484830C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861914: BF870112
	v_add3_u32 v11, v12, v14, 0x7fff                           // 000000861918: D655000B 03FE1D0C 00007FFF
	v_add3_u32 v12, v13, v15, 0x7fff                           // 000000861924: D655000C 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861930: BF870112
	v_dual_add_f32 v6, v1, v6 :: v_dual_and_b32 v7, 0xffff0000, v11// 000000861934: C9240D01 060616FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000861940: 361418FF FFFF0000
	v_add_f32_e32 v4, v0, v4                                   // 000000861948: 06080900
	.long 0xd73c0000                                           // 00000086194C: D73C0000
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000861950: 02021082
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000861954: BF870214
	v_bfe_u32 v9, v6, 16, 1                                    // 000000861958: D6100009 02052106
	v_dual_mul_f32 v7, s2, v7 :: v_dual_mul_f32 v8, s2, v10    // 000000861960: C8C60E02 07081402
	v_bfe_u32 v11, v3, 16, 1                                   // 000000861968: D610000B 02052103
	v_bfe_u32 v12, v4, 16, 1                                   // 000000861970: D610000C 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000861978: BF870214
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000086197C: D6550006 03FE1306 00007FFF
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 000000861988: 100E0EFF BFB8AA3B
	v_bfe_u32 v13, v5, 16, 1                                   // 000000861990: D610000D 02052105
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000861998: D6550003 03FE1703 00007FFF
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008619A4: D6550004 03FE1904 00007FFF
	v_bfe_u32 v10, v2, 16, 1                                   // 0000008619B0: D610000A 02052102
	v_exp_f32_e32 v7, v7                                       // 0000008619B8: 7E0E4B07
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000008619BC: 101010FF BFB8AA3B
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000008619C4: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000008619D0: 360808FF FFFF0000
	v_add3_u32 v2, v2, v10, 0x7fff                             // 0000008619D8: D6550002 03FE1502 00007FFF
	.long 0xd7006a00                                           // 0000008619E4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008619E8: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000008619EC: BF8702A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008619F0: D5207C01 01AA0209
	v_and_b32_e32 v9, 0xffff0000, v3                           // 0000008619F8: 361206FF FFFF0000
	v_add_f32_e32 v7, 1.0, v7                                  // 000000861A00: 060E0EF2
	v_exp_f32_e32 v8, v8                                       // 000000861A04: 7E104B08
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000861A08: 360C0CFF FFFF0000
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000861A10: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861A18: BF870112
	v_dual_mul_f32 v9, s2, v9 :: v_dual_mul_f32 v6, s2, v6     // 000000861A1C: C8C61202 09060C02
	v_mul_f32_e32 v5, s2, v5                                   // 000000861A24: 100A0A02
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 000000861A28: BF870105
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_add_f32 v8, 1.0, v8// 000000861A2C: C8C812FF 090810F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000861A38: BF870223
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 000000861A3C: 10060CFF BFB8AA3B
	v_div_scale_f32 v6, null, v7, v7, 1.0                      // 000000861A44: D6FC7C06 03CA0F07
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000861A4C: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000861A54: BF8701A4
	v_exp_f32_e32 v9, v9                                       // 000000861A58: 7E124B09
	v_div_scale_f32 v10, null, v8, v8, 1.0                     // 000000861A5C: D6FC7C0A 03CA1108
	v_rcp_f32_e32 v13, v6                                      // 000000861A64: 7E1A5506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861A68: BF870092
	v_exp_f32_e32 v5, v5                                       // 000000861A6C: 7E0A4B05
	v_rcp_f32_e32 v14, v10                                     // 000000861A70: 7E1C550A
	v_add_f32_e32 v9, 1.0, v9                                  // 000000861A74: 061212F2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000861A78: BF8702A7
	v_fma_f32 v15, -v6, v13, 1.0                               // 000000861A7C: D613000F 23CA1B06
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000861A84: 360404FF FFFF0000
	v_fma_f32 v16, -v10, v14, 1.0                              // 000000861A8C: D6130010 23CA1D0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861A94: BF870193
	v_fmac_f32_e32 v13, v15, v13                               // 000000861A98: 561A1B0F
	v_dual_mul_f32 v11, s2, v2 :: v_dual_mul_f32 v4, s2, v4    // 000000861A9C: C8C60402 0B040802
	v_exp_f32_e32 v12, v3                                      // 000000861AA4: 7E184B03
	.long 0xd7006a02                                           // 000000861AA8: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000861AAC: 02000100
	s_delay_alu instid0(VALU_DEP_2)                            // 000000861AB0: BF870002
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 000000861AB4: 101616FF BFB8AA3B
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000861ABC: D5207C03 01AA0201
	v_div_scale_f32 v17, vcc_lo, 1.0, v7, 1.0                  // 000000861AC4: D6FC6A11 03CA0EF2
	v_div_scale_f32 v18, s0, 1.0, v8, 1.0                      // 000000861ACC: D6FC0012 03CA10F2
	v_fmac_f32_e32 v14, v16, v14                               // 000000861AD4: 561C1D10
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000861AD8: 100808FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000861AE0: BF870005
	v_add_f32_e32 v12, 1.0, v12                                // 000000861AE4: 061818F2
	v_exp_f32_e32 v11, v11                                     // 000000861AE8: 7E164B0B
	v_mul_f32_e32 v16, v17, v13                                // 000000861AEC: 10201B11
	v_mul_f32_e32 v20, v18, v14                                // 000000861AF0: 10281D12
	v_exp_f32_e32 v4, v4                                       // 000000861AF4: 7E084B04
	v_div_scale_f32 v19, null, v12, v12, 1.0                   // 000000861AF8: D6FC7C13 03CA190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861B00: BF870112
	v_fma_f32 v22, -v10, v20, v18                              // 000000861B04: D6130016 244A290A
	v_rcp_f32_e32 v15, v19                                     // 000000861B0C: 7E1E5513
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000861B10: BF8701A7
	v_add_f32_e32 v11, 1.0, v11                                // 000000861B14: 061616F2
	v_fma_f32 v21, -v6, v16, v17                               // 000000861B18: D6130015 24462106
	v_fmac_f32_e32 v20, v22, v14                               // 000000861B20: 56281D16
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861B24: BF870113
	v_div_scale_f32 v22, null, v11, v11, 1.0                   // 000000861B28: D6FC7C16 03CA170B
	v_fma_f32 v10, -v10, v20, v18                              // 000000861B30: D613000A 244A290A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000861B38: BF8701B5
	v_fma_f32 v23, -v19, v15, 1.0                              // 000000861B3C: D6130017 23CA1F13
	v_fmac_f32_e32 v16, v21, v13                               // 000000861B44: 56201B15
	v_div_scale_f32 v21, s1, 1.0, v12, 1.0                     // 000000861B48: D6FC0115 03CA18F2
	v_fmac_f32_e32 v15, v23, v15                               // 000000861B50: 561E1F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000861B54: BF870093
	v_fma_f32 v6, -v6, v16, v17                                // 000000861B58: D6130006 24462106
	v_div_fmas_f32 v6, v6, v13, v16                            // 000000861B60: D6370006 04421B06
	s_mov_b32 vcc_lo, s0                                       // 000000861B68: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000861B6C: BF870003
	v_mul_f32_e32 v13, v21, v15                                // 000000861B70: 101A1F15
	v_div_scale_f32 v16, null, v9, v9, 1.0                     // 000000861B74: D6FC7C10 03CA1309
	v_div_fmas_f32 v10, v10, v14, v20                          // 000000861B7C: D637000A 04521D0A
	v_rcp_f32_e32 v14, v22                                     // 000000861B84: 7E1C5516
	s_mov_b32 vcc_lo, s1                                       // 000000861B88: BEEA0001
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 000000861B8C: D6270006 03CA0F06
	v_rcp_f32_e32 v17, v16                                     // 000000861B94: 7E225510
	v_div_fixup_f32 v7, v10, v8, 1.0                           // 000000861B98: D6270007 03CA110A
	v_add_f32_e32 v10, 1.0, v4                                 // 000000861BA0: 061408F2
	v_fma_f32 v8, -v19, v13, v21                               // 000000861BA4: D6130008 24561B13
	v_add_f32_e32 v4, v6, v6                                   // 000000861BAC: 06080D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000861BB0: BF870314
	v_add_f32_e32 v6, v7, v7                                   // 000000861BB4: 060C0F07
	v_fma_f32 v7, -v22, v14, 1.0                               // 000000861BB8: D6130007 23CA1D16
	s_delay_alu instid0(VALU_DEP_4)                            // 000000861BC0: BF870004
	v_fmac_f32_e32 v13, v8, v15                                // 000000861BC4: 561A1F08
	v_div_scale_f32 v8, null, v10, v10, 1.0                    // 000000861BC8: D6FC7C08 03CA150A
	v_div_scale_f32 v20, s2, 1.0, v10, 1.0                     // 000000861BD0: D6FC0214 03CA14F2
	s_clause 0x1                                               // 000000861BD8: BF850001
	global_store_b32 v[0:1], v4, off                           // 000000861BDC: DC6A0000 007C0400
	global_store_b32 v[2:3], v6, off                           // 000000861BE4: DC6A0000 007C0602
	v_fmac_f32_e32 v14, v7, v14                                // 000000861BEC: 561C1D07
	v_fma_f32 v3, -v16, v17, 1.0                               // 000000861BF0: D6130003 23CA2310
	v_rcp_f32_e32 v7, v8                                       // 000000861BF8: 7E0E5508
	v_fma_f32 v2, -v19, v13, v21                               // 000000861BFC: D6130002 24561B13
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 000000861C04: D6FC0006 03CA16F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861C0C: BF870193
	v_fmac_f32_e32 v17, v3, v17                                // 000000861C10: 56222303
	v_div_fmas_f32 v2, v2, v15, v13                            // 000000861C14: D6370002 04361F02
	v_div_scale_f32 v15, s1, 1.0, v9, 1.0                      // 000000861C1C: D6FC010F 03CA12F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861C24: BF870195
	v_fma_f32 v3, -v8, v7, 1.0                                 // 000000861C28: D6130003 23CA0F08
	v_div_fixup_f32 v2, v2, v12, 1.0                           // 000000861C30: D6270002 03CA1902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000861C38: BF8701A2
	v_fmac_f32_e32 v7, v3, v7                                  // 000000861C3C: 560E0F03
	.long 0xd7006a03                                           // 000000861C40: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000861C44: 02000900
	v_add_f32_e32 v21, v2, v2                                  // 000000861C48: 062A0502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000861C4C: BF870123
	v_dual_mul_f32 v23, v20, v7 :: v_dual_add_f32 v18, 1.0, v5 // 000000861C50: C8C80F14 17120AF2
	v_mul_f32_e32 v5, v6, v14                                  // 000000861C58: 100A1D06
	v_div_scale_f32 v13, null, v18, v18, 1.0                   // 000000861C5C: D6FC7C0D 03CA2512
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861C64: BF870112
	v_fma_f32 v4, -v22, v5, v6                                 // 000000861C68: D6130004 241A0B16
	v_rcp_f32_e32 v12, v13                                     // 000000861C70: 7E18550D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000861C74: BF870001
	v_fmac_f32_e32 v5, v4, v14                                 // 000000861C78: 560A1D04
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 000000861C7C: D5207C04 01AA0205
	s_mov_b32 vcc_lo, s0                                       // 000000861C84: BEEA0000
	v_mad_u64_u32 v[0:1], null, s12, 12, v[0:1]                // 000000861C88: D6FE7C00 0401180C
	v_fma_f32 v6, -v22, v5, v6                                 // 000000861C90: D6130006 241A0B16
	v_div_scale_f32 v22, s3, 1.0, v18, 1.0                     // 000000861C98: D6FC0316 03CA24F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861CA0: BF870195
	v_fma_f32 v24, -v13, v12, 1.0                              // 000000861CA4: D6130018 23CA190D
	v_div_fmas_f32 v5, v6, v14, v5                             // 000000861CAC: D6370005 04161D06
	s_mov_b32 vcc_lo, s1                                       // 000000861CB4: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861CB8: BF870112
	v_dual_fmac_f32 v12, v24, v12 :: v_dual_mul_f32 v19, v15, v17// 000000861CBC: C8061918 0C12230F
	v_div_fixup_f32 v5, v5, v11, 1.0                           // 000000861CC4: D6270005 03CA1705
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861CCC: BF870192
	v_mul_f32_e32 v14, v22, v12                                // 000000861CD0: 101C1916
	v_fma_f32 v2, -v16, v19, v15                               // 000000861CD4: D6130002 243E2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000861CDC: BF870121
	v_fmac_f32_e32 v19, v2, v17                                // 000000861CE0: 56262302
	v_fma_f32 v2, -v8, v23, v20                                // 000000861CE4: D6130002 24522F08
	v_fma_f32 v6, -v16, v19, v15                               // 000000861CEC: D6130006 243E2710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861CF4: BF870112
	v_fmac_f32_e32 v23, v2, v7                                 // 000000861CF8: 562E0F02
	v_div_fmas_f32 v2, v6, v17, v19                            // 000000861CFC: D6370002 044E2306
	v_fma_f32 v6, -v13, v14, v22                               // 000000861D04: D6130006 245A1D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000861D0C: BF8701A3
	v_fma_f32 v8, -v8, v23, v20                                // 000000861D10: D6130008 24522F08
	s_mov_b32 vcc_lo, s2                                       // 000000861D18: BEEA0002
	v_div_fixup_f32 v9, v2, v9, 1.0                            // 000000861D1C: D6270009 03CA1302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000861D24: BF8701C3
	v_fmac_f32_e32 v14, v6, v12                                // 000000861D28: 561C1906
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000861D2C: D6FE7C01 0405180D
	v_div_fmas_f32 v6, v8, v7, v23                             // 000000861D34: D6370006 045E0F08
	s_mov_b32 vcc_lo, s3                                       // 000000861D3C: BEEA0003
	v_fma_f32 v2, -v13, v14, v22                               // 000000861D40: D6130002 245A1D0D
	v_add_f32_e32 v13, v9, v9                                  // 000000861D48: 061A1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000861D4C: BF870193
	v_div_fixup_f32 v7, v6, v10, 1.0                           // 000000861D50: D6270007 03CA1506
	v_div_fmas_f32 v2, v2, v12, v14                            // 000000861D58: D6370002 043A1902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000861D60: BF870112
	v_add_f32_e32 v12, v7, v7                                  // 000000861D64: 06180F07
	v_div_fixup_f32 v2, v2, v18, 1.0                           // 000000861D68: D6270002 03CA2502
	v_add_f32_e32 v11, v5, v5                                  // 000000861D70: 06160B05
	.long 0xd7006a05                                           // 000000861D74: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000861D78: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000861D7C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 000000861D80: D5207C06 01AA0805
	.long 0xd7006a07                                           // 000000861D88: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000861D8C: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 000000861D90: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_4)                            // 000000861D98: BF870004
	.long 0xd7006a09                                           // 000000861D9C: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 000000861DA0: 02000905
	v_add_f32_e32 v2, v2, v2                                   // 000000861DA4: 06040502
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 000000861DA8: D5207C0A 01AA0C05
	s_clause 0x4                                               // 000000861DB0: BF850004
	global_store_b32 v[3:4], v21, off                          // 000000861DB4: DC6A0000 007C1503
	global_store_b32 v[0:1], v11, off                          // 000000861DBC: DC6A0000 007C0B00
	global_store_b32 v[5:6], v13, off                          // 000000861DC4: DC6A0000 007C0D05
	global_store_b32 v[7:8], v12, off                          // 000000861DCC: DC6A0000 007C0C07
	global_store_b32 v[9:10], v2, off                          // 000000861DD4: DC6A0000 007C0209
	s_endpgm                                                   // 000000861DDC: BFB00000
		...

