0000000000285a00 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi5ELb0EEEvPKhPtNS0_6AffDevEjjl>:
; _ZN7halogen12_GLOBAL__N_19k_deq_affILi5ELb0EEEvPKhPtNS0_6AffDevEjjl():
	s_load_b64 s[16:17], s[0:1], 0x40                          // 000000285A00: F4040400 F8000040
	v_lshl_or_b32 v2, s2, 8, v0                                // 000000285A08: D6560002 04011002
	s_mov_b32 s2, exec_lo                                      // 000000285A10: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 000000285A14: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000285A18: BF870001
	.long 0xd4cc007e                                           // 000000285A1C: D4CC007E
	v_cndmask_b32_e32 v1, s17, v2, vcc_lo                      // 000000285A20: 02020411
	s_cbranch_execz 611                                        // 000000285A24: BFA50263 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi5ELb0EEEvPKhPtNS0_6AffDevEjjl+0x9b4>
	s_clause 0x1                                               // 000000285A28: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000285A2C: F40C0100 F8000000
	s_load_b64 s[2:3], s[0:1], 0x48                            // 000000285A34: F4040080 F8000048
	s_cvt_f32_u32 s12, s16                                     // 000000285A3C: BE8C6510
	v_mov_b32_e32 v1, 0                                        // 000000285A40: 7E020280
	s_load_b32 s22, s[0:1], 0x50                               // 000000285A44: F4000580 F8000050
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000285A4C: BF8702A9
	v_rcp_iflag_f32_e32 v0, s12                                // 000000285A50: 7E00560C
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000285A54: F4080300 F8000020
	v_readfirstlane_b32 s20, v0                                // 000000285A5C: 7E280500
	s_waitcnt lgkmcnt(0)                                       // 000000285A60: BF89FC07
	s_add_u32 s8, s4, s8                                       // 000000285A64: 80080804
	s_addc_u32 s9, s5, s9                                      // 000000285A68: 82090905
	s_lshr_b32 s18, s3, 31                                     // 000000285A6C: 85129F03
	s_mul_f32 s20, s20, 0x4f7ffffe                             // 000000285A70: A214FF14 4F7FFFFE
	s_add_u32 s0, s2, s18                                      // 000000285A78: 80001202
	s_addc_u32 s1, s3, 0                                       // 000000285A7C: 82018003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000285A80: BF870009
	s_ashr_i64 s[18:19], s[0:1], 1                             // 000000285A84: 86928100
	s_add_u32 s10, s4, s10                                     // 000000285A88: 800A0A04
	s_addc_u32 s11, s5, s11                                    // 000000285A8C: 820B0B05
	s_ashr_i32 s0, s3, 31                                      // 000000285A90: 86009F03
	s_cvt_u32_f32 s23, s20                                     // 000000285A94: BE976714
	s_lshr_b32 s0, s0, 29                                      // 000000285A98: 85009D00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000285A9C: BF8704A9
	s_add_u32 s0, s2, s0                                       // 000000285AA0: 80000002
	s_addc_u32 s1, s3, 0                                       // 000000285AA4: 82018003
	s_ashr_i64 s[20:21], s[0:1], 3                             // 000000285AA8: 86948300
	s_add_u32 s4, s4, s12                                      // 000000285AAC: 80040C04
	s_addc_u32 s5, s5, s13                                     // 000000285AB0: 82050D05
	s_sub_i32 s0, 0, s16                                       // 000000285AB4: 81801080
	s_mov_b32 s1, 0                                            // 000000285AB8: BE810080
	s_mul_i32 s0, s0, s23                                      // 000000285ABC: 96001700
	s_lshl_b32 s12, s22, 8                                     // 000000285AC0: 840C8816
	s_mul_hi_u32 s0, s23, s0                                   // 000000285AC4: 96800017
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000285AC8: BF870009
	s_add_i32 s13, s23, s0                                     // 000000285ACC: 810D0017
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000285AD0: BF870099
	.long 0xd72d0000                                           // 000000285AD4: D72D0000
	v_cndmask_b32_e32 v0, v2, v13, vcc_lo                      // 000000285AD8: 02001B02
	.long 0xd72c0003                                           // 000000285ADC: D72C0003
	v_cndmask_b32_e32 v0, v0, v16, vcc_lo                      // 000000285AE0: 02002100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000285AE4: BF870091
	v_sub_nc_u32_e32 v3, v2, v3                                // 000000285AE8: 4C060702
	v_subrev_nc_u32_e32 v5, s16, v3                            // 000000285AEC: 4E0A0610
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 000000285AF0: 7C960610
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000285AF4: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v0// 000000285AF8: CA600B03 03040081
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000285B00: 02000900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000285B04: BF870112
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 000000285B08: 7C960610
	v_add_nc_u32_e32 v4, 1, v0                                 // 000000285B0C: 4A080081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000285B10: BF870091
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000285B14: 02000900
	.long 0xd72c0009                                           // 000000285B18: D72C0009
	v_cndmask_b32_e32 v0, v0, v16, vcc_lo                      // 000000285B1C: 02002100
	v_mad_u64_u32 v[3:4], null, s18, v0, s[8:9]                // 000000285B20: D6FE7C03 00220012
	v_mad_u64_u32 v[5:6], null, s20, v0, s[10:11]              // 000000285B28: D6FE7C05 002A0014
	v_mad_u64_u32 v[7:8], null, s14, v0, s[4:5]                // 000000285B30: D6FE7C07 0012000E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000285B38: BF870224
	v_sub_nc_u32_e32 v14, v2, v9                               // 000000285B3C: 4C1C1302
	v_add_nc_u32_e32 v2, s12, v2                               // 000000285B40: 4A04040C
	v_mad_u64_u32 v[9:10], null, s19, v0, v[4:5]               // 000000285B44: D6FE7C09 04120013
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000285B4C: BF870214
	v_mad_u64_u32 v[10:11], null, s21, v0, v[6:7]              // 000000285B50: D6FE7C0A 041A0015
	v_lshlrev_b32_e32 v4, 4, v14                               // 000000285B58: 30081C84
	v_lshlrev_b32_e32 v6, 2, v14                               // 000000285B5C: 300C1C82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000285B60: BF870194
	v_mad_u64_u32 v[11:12], null, s15, v0, v[8:9]              // 000000285B64: D6FE7C0B 0422000F
	.long 0xd7006a03                                           // 000000285B6C: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000285B70: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000285B74: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v9, vcc_lo                // 000000285B78: D5207C04 01AA1280
	.long 0xd7006a0c                                           // 000000285B80: D7006A0C
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000285B84: 02020D05
	s_delay_alu instid0(VALU_DEP_1)                            // 000000285B88: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v10, vcc_lo              // 000000285B8C: D5207C0D 01AA1480
	v_ashrrev_i32_e32 v5, 31, v6                               // 000000285B94: 340A0C9F
	.long 0xd7006a0a                                           // 000000285B98: D7006A0A
	v_cndmask_b32_e32 v1, v7, v6, vcc_lo                       // 000000285B9C: 02020D07
	s_clause 0x1                                               // 000000285BA0: BF850001
	global_load_b128 v[6:9], v[3:4], off                       // 000000285BA4: DC5E0000 067C0003
	global_load_b32 v3, v[12:13], off                          // 000000285BAC: DC520000 037C000C
	v_add_co_ci_u32_e64 v11, null, v11, v5, vcc_lo             // 000000285BB4: D5207C0B 01AA0B0B
	.long 0x7f0a3880                                           // 000000285BBC: 7F0A3880
	v_cmp_le_u32_e32 vcc_lo, s17, v2                           // 000000285BC0: 7C960411
	global_load_b32 v4, v[10:11], off                          // 000000285BC4: DC520000 047C000A
	s_or_b32 s1, vcc_lo, s1                                    // 000000285BCC: 8C01016A
	s_waitcnt vmcnt(2)                                         // 000000285BD0: BF890BF7
	v_and_b32_e32 v56, 15, v9                                  // 000000285BD4: 3670128F
	s_waitcnt vmcnt(1)                                         // 000000285BD8: BF8907F7
	v_lshlrev_b32_e32 v13, 3, v3                               // 000000285BDC: 301A0683
	v_mad_u64_u32 v[10:11], null, s2, v0, 0                    // 000000285BE0: D6FE7C0A 02020002
	v_lshlrev_b32_e32 v15, 2, v3                               // 000000285BE8: 301E0682
	v_bfe_u32 v58, v9, 4, 4                                    // 000000285BEC: D610003A 02110909
	v_bfe_u32 v60, v9, 8, 4                                    // 000000285BF4: D610003C 02111109
	v_bfe_u32 v62, v9, 12, 4                                   // 000000285BFC: D610003E 02111909
	v_bfe_u32 v64, v9, 16, 4                                   // 000000285C04: D6100040 02112109
	v_bfe_u32 v66, v9, 20, 4                                   // 000000285C0C: D6100042 02112909
	v_bfe_u32 v68, v9, 24, 4                                   // 000000285C14: D6100044 02113109
	v_mad_u64_u32 v[11:12], null, s3, v0, v[11:12]             // 000000285C1C: D6FE7C0B 042E0003
	v_lshlrev_b32_e32 v0, 5, v14                               // 000000285C24: 30001C85
	v_bfe_u32 v12, v6, 4, 4                                    // 000000285C28: D610000C 02110906
	v_bfe_u32 v14, v6, 8, 4                                    // 000000285C30: D610000E 02111106
	v_lshrrev_b32_e32 v9, 28, v9                               // 000000285C38: 3212129C
	v_lshrrev_b32_e32 v70, 27, v3                              // 000000285C3C: 328C069B
	.long 0xd73c0014                                           // 000000285C40: D73C0014
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000285C44: 02020081
	v_bfe_u32 v16, v6, 12, 4                                   // 000000285C48: D6100010 02111906
	.long 0xd73c000a                                           // 000000285C50: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000285C54: 02021481
	v_lshlrev_b32_e32 v17, 1, v3                               // 000000285C58: 30220681
	v_bfe_u32 v18, v6, 16, 4                                   // 000000285C5C: D6100012 02112106
	v_bfe_u32 v19, v6, 20, 4                                   // 000000285C64: D6100013 02112906
	v_lshrrev_b32_e32 v23, 1, v3                               // 000000285C6C: 322E0681
	v_bfe_u32 v24, v6, 24, 4                                   // 000000285C70: D6100018 02113106
	.long 0xd7000000                                           // 000000285C78: D7000000
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000285C7C: 02021406
	s_delay_alu instid0(VALU_DEP_1)                            // 000000285C80: BF870001
	v_add_co_ci_u32_e64 v22, null, s7, v11, s0                 // 000000285C84: D5207C16 00021607
	v_and_b32_e32 v10, 15, v6                                  // 000000285C8C: 36140C8F
	v_lshlrev_b32_e32 v11, 4, v3                               // 000000285C90: 30160684
	v_lshrrev_b32_e32 v25, 2, v3                               // 000000285C94: 32320682
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000285C98: 320C0C9C
	v_lshrrev_b32_e32 v26, 3, v3                               // 000000285C9C: 32340683
	v_and_or_b32 v9, v70, 16, v9                               // 000000285CA0: D6570009 04252146
	v_and_or_b32 v10, v11, 16, v10                             // 000000285CA8: D657000A 0429210B
	v_and_or_b32 v11, v13, 16, v12                             // 000000285CB0: D657000B 0431210D
	v_and_or_b32 v12, v15, 16, v14                             // 000000285CB8: D657000C 0439210F
	v_and_b32_e32 v27, 15, v7                                  // 000000285CC0: 36360E8F
	v_bfe_u32 v29, v7, 4, 4                                    // 000000285CC4: D610001D 02110907
	v_cvt_f32_ubyte0_e32 v10, v10                              // 000000285CCC: 7E14230A
	v_bfe_u32 v31, v7, 8, 4                                    // 000000285CD0: D610001F 02111107
	v_bfe_u32 v33, v7, 12, 4                                   // 000000285CD8: D6100021 02111907
	v_bfe_u32 v35, v7, 16, 4                                   // 000000285CE0: D6100023 02112107
	v_bfe_u32 v37, v7, 20, 4                                   // 000000285CE8: D6100025 02112907
	v_bfe_u32 v39, v7, 24, 4                                   // 000000285CF0: D6100027 02113107
	v_lshrrev_b32_e32 v40, 10, v3                              // 000000285CF8: 3250068A
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000285CFC: 320E0E9C
	v_lshrrev_b32_e32 v41, 11, v3                              // 000000285D00: 3252068B
	v_and_or_b32 v13, v17, 16, v16                             // 000000285D04: D657000D 04412111
	v_and_or_b32 v14, v3, 16, v18                              // 000000285D0C: D657000E 04492103
	v_and_or_b32 v15, v23, 16, v19                             // 000000285D14: D657000F 044D2117
	v_and_or_b32 v16, v25, 16, v24                             // 000000285D1C: D6570010 04612119
	v_and_or_b32 v6, v26, 16, v6                               // 000000285D24: D6570006 0419211A
	v_cvt_f32_ubyte0_e32 v11, v11                              // 000000285D2C: 7E16230B
	v_cvt_f32_ubyte0_e32 v12, v12                              // 000000285D30: 7E18230C
	v_cvt_f32_ubyte0_e32 v9, v9                                // 000000285D34: 7E122309
	s_waitcnt vmcnt(0)                                         // 000000285D38: BF8903F7
	v_fma_mix_f32 v10, v10, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285D3C: CC20600A 1412090A
	v_lshrrev_b32_e32 v28, 4, v3                               // 000000285D44: 32380684
	v_and_b32_e32 v42, 15, v8                                  // 000000285D48: 3654108F
	v_lshrrev_b32_e32 v43, 12, v3                              // 000000285D4C: 3256068C
	v_bfe_u32 v44, v8, 4, 4                                    // 000000285D50: D610002C 02110908
	v_bfe_u32 v46, v8, 8, 4                                    // 000000285D58: D610002E 02111108
	v_bfe_u32 v48, v8, 12, 4                                   // 000000285D60: D6100030 02111908
	v_bfe_u32 v50, v8, 16, 4                                   // 000000285D68: D6100032 02112108
	v_bfe_u32 v51, v8, 20, 4                                   // 000000285D70: D6100033 02112908
	v_bfe_u32 v53, v8, 24, 4                                   // 000000285D78: D6100035 02113108
	v_lshrrev_b32_e32 v8, 28, v8                               // 000000285D80: 3210109C
	v_lshrrev_b32_e32 v55, 19, v3                              // 000000285D84: 326E0693
	v_and_or_b32 v26, v40, 16, v39                             // 000000285D88: D657001A 049D2128
	v_and_or_b32 v7, v41, 16, v7                               // 000000285D90: D6570007 041D2129
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000285D98: 7E1A230D
	v_cvt_f32_ubyte0_e32 v14, v14                              // 000000285D9C: 7E1C230E
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000285DA0: 7E1E230F
	v_cvt_f32_ubyte0_e32 v16, v16                              // 000000285DA4: 7E202310
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000285DA8: 7E0C2306
	v_fma_mix_f32 v11, v11, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285DAC: CC20600B 1412090B
	v_fma_mix_f32 v12, v12, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285DB4: CC20600C 1412090C
	v_fma_mix_f32 v40, v9, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285DBC: CC206028 14120909
	v_bfe_u32 v9, v10, 16, 1                                   // 000000285DC4: D6100009 0205210A
	v_lshrrev_b32_e32 v30, 5, v3                               // 000000285DCC: 323C0685
	v_lshrrev_b32_e32 v32, 6, v3                               // 000000285DD0: 32400686
	v_lshrrev_b32_e32 v45, 13, v3                              // 000000285DD4: 325A068D
	v_lshrrev_b32_e32 v47, 14, v3                              // 000000285DD8: 325E068E
	v_and_or_b32 v17, v28, 16, v27                             // 000000285DDC: D6570011 046D211C
	v_and_or_b32 v27, v43, 16, v42                             // 000000285DE4: D657001B 04A9212B
	v_and_or_b32 v8, v55, 16, v8                               // 000000285DEC: D6570008 04212137
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000285DF4: 7E0E2307
	v_fma_mix_f32 v13, v13, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285DF8: CC20600D 1412090D
	v_fma_mix_f32 v14, v14, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285E00: CC20600E 1412090E
	v_fma_mix_f32 v15, v15, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285E08: CC20600F 1412090F
	v_fma_mix_f32 v16, v16, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285E10: CC206010 14120910
	v_fma_mix_f32 v6, v6, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285E18: CC206006 14120906
	v_bfe_u32 v41, v11, 16, 1                                  // 000000285E20: D6100029 0205210B
	v_bfe_u32 v42, v12, 16, 1                                  // 000000285E28: D610002A 0205210C
	v_add3_u32 v9, v10, v9, 0x7fff                             // 000000285E30: D6550009 03FE130A 00007FFF
	v_lshrrev_b32_e32 v34, 7, v3                               // 000000285E3C: 32440687
	v_lshrrev_b32_e32 v36, 8, v3                               // 000000285E40: 32480688
	v_lshrrev_b32_e32 v57, 20, v3                              // 000000285E44: 32720694
	v_and_or_b32 v18, v30, 16, v29                             // 000000285E48: D6570012 0475211E
	v_and_or_b32 v19, v32, 16, v31                             // 000000285E50: D6570013 047D2120
	v_and_or_b32 v28, v45, 16, v44                             // 000000285E58: D657001C 04B1212D
	v_and_or_b32 v29, v47, 16, v46                             // 000000285E60: D657001D 04B9212F
	v_cvt_f32_ubyte0_e32 v17, v17                              // 000000285E68: 7E222311
	v_cvt_f32_ubyte0_e32 v8, v8                                // 000000285E6C: 7E102308
	v_fma_mix_f32 v7, v7, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285E70: CC206007 14120907
	v_bfe_u32 v43, v13, 16, 1                                  // 000000285E78: D610002B 0205210D
	v_bfe_u32 v44, v14, 16, 1                                  // 000000285E80: D610002C 0205210E
	v_bfe_u32 v45, v15, 16, 1                                  // 000000285E88: D610002D 0205210F
	v_bfe_u32 v46, v16, 16, 1                                  // 000000285E90: D610002E 02052110
	v_bfe_u32 v47, v6, 16, 1                                   // 000000285E98: D610002F 02052106
	v_add3_u32 v10, v11, v41, 0x7fff                           // 000000285EA0: D655000A 03FE530B 00007FFF
	v_add3_u32 v11, v12, v42, 0x7fff                           // 000000285EAC: D655000B 03FE550C 00007FFF
	.long 0x7e0a3989                                           // 000000285EB8: 7E0A3989
	v_lshrrev_b32_e32 v38, 9, v3                               // 000000285EBC: 324C0689
	v_lshrrev_b32_e32 v49, 15, v3                              // 000000285EC0: 3262068F
	v_lshrrev_b32_e32 v63, 23, v3                              // 000000285EC4: 327E0697
	v_and_or_b32 v23, v34, 16, v33                             // 000000285EC8: D6570017 04852122
	v_and_or_b32 v24, v36, 16, v35                             // 000000285ED0: D6570018 048D2124
	v_and_or_b32 v33, v57, 16, v56                             // 000000285ED8: D6570021 04E12139
	v_cvt_f32_ubyte0_e32 v18, v18                              // 000000285EE0: 7E242312
	v_cvt_f32_ubyte0_e32 v19, v19                              // 000000285EE4: 7E262313
	v_fma_mix_f32 v17, v17, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285EE8: CC206011 14120911
	v_fma_mix_f32 v8, v8, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285EF0: CC206008 14120908
	v_bfe_u32 v56, v7, 16, 1                                   // 000000285EF8: D6100038 02052107
	v_add3_u32 v12, v13, v43, 0x7fff                           // 000000285F00: D655000C 03FE570D 00007FFF
	v_add3_u32 v13, v14, v44, 0x7fff                           // 000000285F0C: D655000D 03FE590E 00007FFF
	v_add3_u32 v14, v15, v45, 0x7fff                           // 000000285F18: D655000E 03FE5B0F 00007FFF
	v_add3_u32 v15, v16, v46, 0x7fff                           // 000000285F24: D655000F 03FE5D10 00007FFF
	v_add3_u32 v16, v6, v47, 0x7fff                            // 000000285F30: D6550010 03FE5F06 00007FFF
	v_and_or_b32 v6, 0xffff0000, v10, v5                       // 000000285F3C: D6570006 041614FF FFFF0000
	.long 0x7e0a398b                                           // 000000285F48: 7E0A398B
	v_lshrrev_b32_e32 v52, 17, v3                              // 000000285F4C: 32680691
	v_and_or_b32 v25, v38, 16, v37                             // 000000285F50: D6570019 04952126
	v_and_or_b32 v30, v49, 16, v48                             // 000000285F58: D657001E 04C12131
	v_and_or_b32 v36, v63, 16, v62                             // 000000285F60: D6570024 04F9213F
	v_cvt_f32_ubyte0_e32 v23, v23                              // 000000285F68: 7E2E2317
	v_cvt_f32_ubyte0_e32 v24, v24                              // 000000285F6C: 7E302318
	v_fma_mix_f32 v18, v18, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285F70: CC206012 14120912
	v_fma_mix_f32 v19, v19, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285F78: CC206013 14120913
	v_bfe_u32 v48, v17, 16, 1                                  // 000000285F80: D6100030 02052111
	v_bfe_u32 v63, v8, 16, 1                                   // 000000285F88: D610003F 02052108
	v_add3_u32 v41, v7, v56, 0x7fff                            // 000000285F90: D6550029 03FE7107 00007FFF
	v_and_or_b32 v7, 0xffff0000, v12, v5                       // 000000285F9C: D6570007 041618FF FFFF0000
	.long 0x7e0a398d                                           // 000000285FA8: 7E0A398D
	v_lshrrev_b32_e32 v54, 18, v3                              // 000000285FAC: 326C0692
	v_and_or_b32 v31, v52, 16, v51                             // 000000285FB0: D657001F 04CD2134
	v_cvt_f32_ubyte0_e32 v25, v25                              // 000000285FB8: 7E322319
	v_cvt_f32_ubyte0_e32 v26, v26                              // 000000285FBC: 7E34231A
	v_fma_mix_f32 v23, v23, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285FC0: CC206017 14120917
	v_fma_mix_f32 v24, v24, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000285FC8: CC206018 14120918
	v_bfe_u32 v49, v18, 16, 1                                  // 000000285FD0: D6100031 02052112
	v_bfe_u32 v51, v19, 16, 1                                  // 000000285FD8: D6100033 02052113
	v_add3_u32 v17, v17, v48, 0x7fff                           // 000000285FE0: D6550011 03FE6111 00007FFF
	v_add3_u32 v42, v8, v63, 0x7fff                            // 000000285FEC: D655002A 03FE7F08 00007FFF
	v_and_or_b32 v8, 0xffff0000, v14, v5                       // 000000285FF8: D6570008 04161CFF FFFF0000
	.long 0x7e0a398f                                           // 000000286004: 7E0A398F
	v_and_or_b32 v32, v54, 16, v53                             // 000000286008: D6570020 04D52136
	v_cvt_f32_ubyte0_e32 v27, v27                              // 000000286010: 7E36231B
	v_fma_mix_f32 v25, v25, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286014: CC206019 14120919
	v_fma_mix_f32 v26, v26, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028601C: CC20601A 1412091A
	v_bfe_u32 v52, v23, 16, 1                                  // 000000286024: D6100034 02052117
	v_bfe_u32 v53, v24, 16, 1                                  // 00000028602C: D6100035 02052118
	v_add3_u32 v18, v18, v49, 0x7fff                           // 000000286034: D6550012 03FE6312 00007FFF
	v_add3_u32 v19, v19, v51, 0x7fff                           // 000000286040: D6550013 03FE6713 00007FFF
	v_and_or_b32 v9, 0xffff0000, v16, v5                       // 00000028604C: D6570009 041620FF FFFF0000
	.long 0x7e0a3991                                           // 000000286058: 7E0A3991
	v_cvt_f32_ubyte0_e32 v28, v28                              // 00000028605C: 7E38231C
	v_cvt_f32_ubyte0_e32 v29, v29                              // 000000286060: 7E3A231D
	v_fma_mix_f32 v27, v27, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286064: CC20601B 1412091B
	v_bfe_u32 v54, v25, 16, 1                                  // 00000028606C: D6100036 02052119
	v_bfe_u32 v55, v26, 16, 1                                  // 000000286074: D6100037 0205211A
	v_add3_u32 v23, v23, v52, 0x7fff                           // 00000028607C: D6550017 03FE6917 00007FFF
	v_add3_u32 v24, v24, v53, 0x7fff                           // 000000286088: D6550018 03FE6B18 00007FFF
	v_and_or_b32 v10, 0xffff0000, v18, v5                      // 000000286094: D657000A 041624FF FFFF0000
	.long 0x7e0a3993                                           // 0000002860A0: 7E0A3993
	v_lshrrev_b32_e32 v59, 21, v3                              // 0000002860A4: 32760695
	v_cvt_f32_ubyte0_e32 v30, v30                              // 0000002860A8: 7E3C231E
	v_fma_mix_f32 v28, v28, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002860AC: CC20601C 1412091C
	v_fma_mix_f32 v29, v29, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002860B4: CC20601D 1412091D
	v_bfe_u32 v57, v27, 16, 1                                  // 0000002860BC: D6100039 0205211B
	v_add3_u32 v25, v25, v54, 0x7fff                           // 0000002860C4: D6550019 03FE6D19 00007FFF
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000002860D0: D655001A 03FE6F1A 00007FFF
	v_and_or_b32 v11, 0xffff0000, v23, v5                      // 0000002860DC: D657000B 04162EFF FFFF0000
	.long 0x7e0a3998                                           // 0000002860E8: 7E0A3998
	v_lshrrev_b32_e32 v61, 22, v3                              // 0000002860EC: 327A0696
	v_and_or_b32 v34, v59, 16, v58                             // 0000002860F0: D6570022 04E9213B
	v_fma_mix_f32 v30, v30, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002860F8: CC20601E 1412091E
	v_bfe_u32 v58, v28, 16, 1                                  // 000000286100: D610003A 0205211C
	v_bfe_u32 v59, v29, 16, 1                                  // 000000286108: D610003B 0205211D
	v_add3_u32 v27, v27, v57, 0x7fff                           // 000000286110: D655001B 03FE731B 00007FFF
	v_and_or_b32 v12, 0xffff0000, v25, v5                      // 00000028611C: D657000C 041632FF FFFF0000
	.long 0x7e0a399a                                           // 000000286128: 7E0A399A
	v_and_or_b32 v35, v61, 16, v60                             // 00000028612C: D6570023 04F1213D
	v_bfe_u32 v60, v30, 16, 1                                  // 000000286134: D610003C 0205211E
	v_add3_u32 v28, v28, v58, 0x7fff                           // 00000028613C: D655001C 03FE751C 00007FFF
	v_add3_u32 v29, v29, v59, 0x7fff                           // 000000286148: D655001D 03FE771D 00007FFF
	v_and_or_b32 v13, 0xffff0000, v41, v5                      // 000000286154: D657000D 041652FF FFFF0000
	.long 0x7e0a399b                                           // 000000286160: 7E0A399B
	v_add3_u32 v30, v30, v60, 0x7fff                           // 000000286164: D655001E 03FE791E 00007FFF
	v_lshrrev_b32_e32 v65, 24, v3                              // 000000286170: 32820698
	v_lshrrev_b32_e32 v67, 25, v3                              // 000000286174: 32860699
	v_lshrrev_b32_e32 v69, 26, v3                              // 000000286178: 328A069A
	v_and_or_b32 v14, 0xffff0000, v28, v5                      // 00000028617C: D657000E 041638FF FFFF0000
	.long 0x7e0a399d                                           // 000000286188: 7E0A399D
	v_and_or_b32 v37, v65, 16, v64                             // 00000028618C: D6570025 05012141
	v_and_or_b32 v38, v67, 16, v66                             // 000000286194: D6570026 05092143
	v_and_or_b32 v39, v69, 16, v68                             // 00000028619C: D6570027 05112145
	v_cvt_f32_ubyte0_e32 v31, v31                              // 0000002861A4: 7E3E231F
	v_and_or_b32 v15, 0xffff0000, v30, v5                      // 0000002861A8: D657000F 04163CFF FFFF0000
	.long 0x7e0a3983                                           // 0000002861B4: 7E0A3983
	v_cvt_f32_ubyte0_e32 v32, v32                              // 0000002861B8: 7E402320
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000002861BC: 7E422321
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000002861C0: 7E442322
	v_cvt_f32_ubyte0_e32 v35, v35                              // 0000002861C4: 7E462323
	v_and_or_b32 v3, v5, 16, v50                               // 0000002861C8: D6570003 04C92105
	v_cvt_f32_ubyte0_e32 v36, v36                              // 0000002861D0: 7E482324
	v_cvt_f32_ubyte0_e32 v37, v37                              // 0000002861D4: 7E4A2325
	v_cvt_f32_ubyte0_e32 v38, v38                              // 0000002861D8: 7E4C2326
	v_cvt_f32_ubyte0_e32 v39, v39                              // 0000002861DC: 7E4E2327
	v_cvt_f32_ubyte0_e32 v3, v3                                // 0000002861E0: 7E062303
	v_fma_mix_f32 v31, v31, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002861E4: CC20601F 1412091F
	v_fma_mix_f32 v32, v32, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002861EC: CC206020 14120920
	v_fma_mix_f32 v33, v33, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002861F4: CC206021 14120921
	v_fma_mix_f32 v34, v34, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002861FC: CC206022 14120922
	v_fma_mix_f32 v3, v3, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286204: CC206003 14120903
	v_fma_mix_f32 v35, v35, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028620C: CC206023 14120923
	v_fma_mix_f32 v36, v36, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286214: CC206024 14120924
	v_fma_mix_f32 v37, v37, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028621C: CC206025 14120925
	v_fma_mix_f32 v38, v38, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000286224: CC206026 14120926
	v_fma_mix_f32 v39, v39, v4, v4 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000028622C: CC206027 14120927
	v_bfe_u32 v4, v3, 16, 1                                    // 000000286234: D6100004 02052103
	v_bfe_u32 v61, v31, 16, 1                                  // 00000028623C: D610003D 0205211F
	v_bfe_u32 v62, v32, 16, 1                                  // 000000286244: D610003E 02052120
	v_bfe_u32 v64, v33, 16, 1                                  // 00000028624C: D6100040 02052121
	v_bfe_u32 v65, v34, 16, 1                                  // 000000286254: D6100041 02052122
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000028625C: D6550003 03FE0903 00007FFF
	v_add3_u32 v31, v31, v61, 0x7fff                           // 000000286268: D655001F 03FE7B1F 00007FFF
	v_add3_u32 v32, v32, v62, 0x7fff                           // 000000286274: D6550020 03FE7D20 00007FFF
	v_bfe_u32 v66, v35, 16, 1                                  // 000000286280: D6100042 02052123
	v_add3_u32 v33, v33, v64, 0x7fff                           // 000000286288: D6550021 03FE8121 00007FFF
	.long 0x7e0a3983                                           // 000000286294: 7E0A3983
	v_bfe_u32 v67, v36, 16, 1                                  // 000000286298: D6100043 02052124
	v_bfe_u32 v68, v37, 16, 1                                  // 0000002862A0: D6100044 02052125
	v_add3_u32 v34, v34, v65, 0x7fff                           // 0000002862A8: D6550022 03FE8322 00007FFF
	v_add3_u32 v35, v35, v66, 0x7fff                           // 0000002862B4: D6550023 03FE8523 00007FFF
	v_and_or_b32 v16, 0xffff0000, v31, v5                      // 0000002862C0: D6570010 04163EFF FFFF0000
	.long 0x7e0a39a0                                           // 0000002862CC: 7E0A39A0
	v_bfe_u32 v69, v38, 16, 1                                  // 0000002862D0: D6100045 02052126
	v_bfe_u32 v70, v39, 16, 1                                  // 0000002862D8: D6100046 02052127
	v_add3_u32 v36, v36, v67, 0x7fff                           // 0000002862E0: D6550024 03FE8724 00007FFF
	v_add3_u32 v3, v37, v68, 0x7fff                            // 0000002862EC: D6550003 03FE8925 00007FFF
	v_and_or_b32 v17, 0xffff0000, v42, v5                      // 0000002862F8: D6570011 041654FF FFFF0000
	.long 0x7e0a39a1                                           // 000000286304: 7E0A39A1
	v_bfe_u32 v71, v40, 16, 1                                  // 000000286308: D6100047 02052128
	v_add3_u32 v4, v38, v69, 0x7fff                            // 000000286310: D6550004 03FE8B26 00007FFF
	v_add3_u32 v23, v39, v70, 0x7fff                           // 00000028631C: D6550017 03FE8D27 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000286328: BF8700A4
	v_and_or_b32 v18, 0xffff0000, v34, v5                      // 00000028632C: D6570012 041644FF FFFF0000
	.long 0x7e0a39a3                                           // 000000286338: 7E0A39A3
	v_and_or_b32 v19, 0xffff0000, v36, v5                      // 00000028633C: D6570013 041648FF FFFF0000
	.long 0x7e0a3983                                           // 000000286348: 7E0A3983
	.long 0xd7000003                                           // 00000028634C: D7000003
	v_cndmask_b32_e32 v1, v0, v20, vcc_lo                      // 000000286350: 02022900
	v_add3_u32 v0, v40, v71, 0x7fff                            // 000000286354: D6550000 03FE8F28 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000286360: BF870133
	v_and_or_b32 v20, 0xffff0000, v4, v5                       // 000000286364: D6570014 041608FF FFFF0000
	.long 0x7e0a3997                                           // 000000286370: 7E0A3997
	v_add_co_ci_u32_e64 v4, null, v22, v21, s0                 // 000000286374: D5207C04 00022B16
	v_and_or_b32 v21, 0xffff0000, v0, v5                       // 00000028637C: D6570015 041600FF FFFF0000
	s_clause 0x3                                               // 000000286388: BF850003
	global_store_b128 v[3:4], v[6:9], off                      // 00000028638C: DC760000 007C0603
	global_store_b128 v[3:4], v[10:13], off offset:16          // 000000286394: DC760010 007C0A03
	global_store_b128 v[3:4], v[14:17], off offset:32          // 00000028639C: DC760020 007C0E03
	global_store_b128 v[3:4], v[18:21], off offset:48          // 0000002863A4: DC760030 007C1203
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000002863AC: 917E017E
	s_cbranch_execnz 64967                                     // 0000002863B0: BFA6FDC7 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi5ELb0EEEvPKhPtNS0_6AffDevEjjl+0xd0>
	s_endpgm                                                   // 0000002863B4: BFB00000
		...

