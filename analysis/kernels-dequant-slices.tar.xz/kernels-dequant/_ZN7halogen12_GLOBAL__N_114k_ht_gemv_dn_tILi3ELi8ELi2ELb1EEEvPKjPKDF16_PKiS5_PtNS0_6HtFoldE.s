00000000009b3500 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b512 s[4:19], s[0:1], null                          // 0000009B3500: F4100100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 0000009B3508: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009B3510: BF8704A9
	s_lshr_b32 s20, s3, 31                                     // 0000009B3514: 85149F03
	s_ashr_i32 s3, s3, 3                                       // 0000009B3518: 86038303
	s_add_i32 s20, s3, s20                                     // 0000009B351C: 81141403
	s_mov_b32 s3, exec_lo                                      // 0000009B3520: BE83007E
	s_ashr_i32 s21, s20, 31                                    // 0000009B3524: 86159F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B3528: BF870009
	s_lshl_b64 s[22:23], s[20:21], 2                           // 0000009B352C: 84968214
	s_waitcnt lgkmcnt(0)                                       // 0000009B3530: BF89FC07
	s_add_u32 s8, s8, s22                                      // 0000009B3534: 80081608
	s_addc_u32 s9, s9, s23                                     // 0000009B3538: 82091709
	s_load_b32 s8, s[8:9], null                                // 0000009B353C: F4000204 F8000000
	v_cmpx_gt_u32_e32 0x50, v0                                 // 0000009B3544: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 0000009B354C: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x80>
	s_mul_i32 s9, s20, 0x500                                   // 0000009B3550: 9609FF14 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 0000009B3558: 300A0084
	s_mul_hi_i32 s21, s20, 0x500                               // 0000009B355C: 9715FF14 00000500
	s_add_u32 s6, s6, s9                                       // 0000009B3564: 80060906
	s_addc_u32 s7, s7, s21                                     // 0000009B3568: 82071507
	global_load_b128 v[1:4], v5, s[6:7]                        // 0000009B356C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 0000009B3574: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 0000009B3578: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009B3580: 8C7E037E
	v_and_b32_e32 v41, 31, v0                                  // 0000009B3584: 3652009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 0000009B3588: 32500085
	s_mul_i32 s9, s20, 0xffffffec                              // 0000009B358C: 9609FF14 FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 0000009B3594: BF89FC07
	s_mul_i32 s6, s8, 0x96000                                  // 0000009B3598: 9606FF08 00096000
	s_mul_hi_i32 s3, s8, 0x96000                               // 0000009B35A0: 9703FF08 00096000
	v_mad_u32_u24 v4, v41, 24, 0x2f0                           // 0000009B35A8: D60B0004 03FD3129 000002F0
	v_mul_u32_u24_e32 v3, 5, v40                               // 0000009B35B4: 16065085
	v_cmp_eq_u32_e32 vcc_lo, 0, v41                            // 0000009B35B8: 7C945280
	s_add_i32 s9, s9, s2                                       // 0000009B35BC: 81090209
	s_add_u32 s4, s4, s6                                       // 0000009B35C0: 80040604
	v_lshrrev_b32_e32 v1, 5, v4                                // 0000009B35C4: 32020885
	v_min_u32_e32 v12, 35, v3                                  // 0000009B35C8: 261806A3
	s_addc_u32 s5, s5, s3                                      // 0000009B35CC: 82050305
	s_mul_i32 s6, s9, 0x7800                                   // 0000009B35D0: 9606FF09 00007800
	v_add_nc_u32_e32 v13, 8, v4                                // 0000009B35D8: 4A1A0888
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009B35DC: 4E020298
	v_add_nc_u32_e32 v42, 5, v12                               // 0000009B35E0: 4A541885
	s_mul_hi_i32 s7, s9, 0x7800                                // 0000009B35E4: 9707FF09 00007800
	s_add_u32 s6, s4, s6                                       // 0000009B35EC: 80060604
	s_addc_u32 s7, s5, s7                                      // 0000009B35F0: 82070705
	v_cndmask_b32_e64 v10, v1, 23, vcc_lo                      // 0000009B35F4: D501000A 01A92F01
	.long 0xd4490003                                           // 0000009B35FC: D4490003
	v_cndmask_b32_e32 v1, v3, v42, vcc_lo                      // 0000009B3600: 02025503
	s_barrier                                                  // 0000009B3604: BFBD0000
	buffer_gl0_inv                                             // 0000009B3608: E0AC0000 00000000
	s_and_saveexec_b32 s5, s3                                  // 0000009B3610: BE852003
	s_cbranch_execz 126                                        // 0000009B3614: BFA5007E <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x310>
	v_lshrrev_b32_e32 v1, 5, v13                               // 0000009B3618: 32021A85
	.long 0xd4440004                                           // 0000009B361C: D4440004
	v_cndmask_b32_e32 v1, 23, v10, vcc_lo                      // 0000009B3620: 02021497
	v_mov_b32_e32 v11, 0                                       // 0000009B3624: 7E160280
	v_mul_u32_u24_e32 v8, 0xf00, v40                           // 0000009B3628: 161050FF 00000F00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B3630: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000009B3634: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s4                          // 0000009B3638: D5010002 001102FF 000000E9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B3644: BF870194
	.long 0xd73c0005                                           // 0000009B3648: D73C0005
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000009B364C: 02021482
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 0000009B3650: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B3658: BF870113
	v_dual_mov_b32 v2, v11 :: v_dual_add_nc_u32 v7, v2, v10    // 0000009B365C: CA20010B 02061502
	.long 0xd4440004                                           // 0000009B3664: D4440004
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 0000009B3668: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B366C: BF8701A2
	v_lshlrev_b32_e32 v9, 24, v7                               // 0000009B3670: 30120E98
	v_bfe_i32 v7, v7, 7, 1                                     // 0000009B3674: D6110007 02050F07
	v_cndmask_b32_e64 v11, 0xe9, 1, s4                         // 0000009B367C: D501000B 001102FF 000000E9
	.long 0xd700040e                                           // 0000009B3688: D700040E
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 0000009B368C: 02021006
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B3690: BF870191
	v_add_co_ci_u32_e64 v15, null, s7, 0, s4                   // 0000009B3694: D5207C0F 00110007
	v_add_nc_u32_e32 v11, v11, v1                              // 0000009B369C: 4A16030B
	v_ashrrev_i32_e32 v8, 22, v9                               // 0000009B36A0: 34101296
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B36A4: BF870224
	.long 0xd7000405                                           // 0000009B36A8: D7000405
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000009B36AC: 02020B0E
	.long 0xd73c0001                                           // 0000009B36B0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009B36B4: 02020282
	v_lshlrev_b32_e32 v16, 24, v11                             // 0000009B36B8: 30201698
	v_add_co_ci_u32_e64 v6, null, v15, v6, s4                  // 0000009B36BC: D5207C06 00120D0F
	.long 0xd7000408                                           // 0000009B36C4: D7000408
	v_cndmask_b32_e32 v1, v14, v8, vcc_lo                      // 0000009B36C8: 0202110E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B36CC: BF870211
	v_add_co_ci_u32_e64 v9, null, v15, v7, s4                  // 0000009B36D0: D5207C09 00120F0F
	v_ashrrev_i32_e32 v7, 22, v16                              // 0000009B36D8: 340E2096
	v_bfe_i32 v11, v11, 7, 1                                   // 0000009B36DC: D611000B 02050F0B
	.long 0xd700042b                                           // 0000009B36E4: D700042B
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000009B36E8: 0202030E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B36EC: BF870211
	v_add_co_ci_u32_e64 v44, null, v15, v2, s4                 // 0000009B36F0: D5207C2C 0012050F
	.long 0xd700042d                                           // 0000009B36F8: D700042D
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000009B36FC: 02020F0E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B3700: BF870001
	v_add_co_ci_u32_e64 v46, null, v15, v11, s4                // 0000009B3704: D5207C2E 0012170F
	s_clause 0x1f                                              // 0000009B370C: BF85001F
	global_load_b32 v2, v[5:6], off                            // 0000009B3710: DC520000 027C0005
	global_load_b32 v35, v[5:6], off offset:96                 // 0000009B3718: DC520060 237C0005
	global_load_b32 v31, v[5:6], off offset:192                // 0000009B3720: DC5200C0 1F7C0005
	global_load_b32 v27, v[5:6], off offset:288                // 0000009B3728: DC520120 1B7C0005
	global_load_b32 v23, v[5:6], off offset:384                // 0000009B3730: DC520180 177C0005
	global_load_b32 v19, v[5:6], off offset:480                // 0000009B3738: DC5201E0 137C0005
	global_load_b32 v15, v[5:6], off offset:576                // 0000009B3740: DC520240 0F7C0005
	global_load_b32 v7, v[5:6], off offset:672                 // 0000009B3748: DC5202A0 077C0005
	global_load_b32 v1, v[8:9], off                            // 0000009B3750: DC520000 017C0008
	global_load_b32 v34, v[8:9], off offset:96                 // 0000009B3758: DC520060 227C0008
	global_load_b32 v30, v[8:9], off offset:192                // 0000009B3760: DC5200C0 1E7C0008
	global_load_b32 v26, v[8:9], off offset:288                // 0000009B3768: DC520120 1A7C0008
	global_load_b32 v22, v[8:9], off offset:384                // 0000009B3770: DC520180 167C0008
	global_load_b32 v18, v[8:9], off offset:480                // 0000009B3778: DC5201E0 127C0008
	global_load_b32 v14, v[8:9], off offset:576                // 0000009B3780: DC520240 0E7C0008
	global_load_b32 v6, v[8:9], off offset:672                 // 0000009B3788: DC5202A0 067C0008
	global_load_b32 v39, v[43:44], off                         // 0000009B3790: DC520000 277C002B
	global_load_b32 v37, v[43:44], off offset:96               // 0000009B3798: DC520060 257C002B
	global_load_b32 v33, v[43:44], off offset:192              // 0000009B37A0: DC5200C0 217C002B
	global_load_b32 v29, v[43:44], off offset:288              // 0000009B37A8: DC520120 1D7C002B
	global_load_b32 v25, v[43:44], off offset:384              // 0000009B37B0: DC520180 197C002B
	global_load_b32 v21, v[43:44], off offset:480              // 0000009B37B8: DC5201E0 157C002B
	global_load_b32 v17, v[43:44], off offset:576              // 0000009B37C0: DC520240 117C002B
	global_load_b32 v9, v[43:44], off offset:672               // 0000009B37C8: DC5202A0 097C002B
	global_load_b32 v38, v[45:46], off                         // 0000009B37D0: DC520000 267C002D
	global_load_b32 v36, v[45:46], off offset:96               // 0000009B37D8: DC520060 247C002D
	global_load_b32 v32, v[45:46], off offset:192              // 0000009B37E0: DC5200C0 207C002D
	global_load_b32 v28, v[45:46], off offset:288              // 0000009B37E8: DC520120 1C7C002D
	global_load_b32 v24, v[45:46], off offset:384              // 0000009B37F0: DC520180 187C002D
	global_load_b32 v20, v[45:46], off offset:480              // 0000009B37F8: DC5201E0 147C002D
	global_load_b32 v16, v[45:46], off offset:576              // 0000009B3800: DC520240 107C002D
	global_load_b32 v8, v[45:46], off offset:672               // 0000009B3808: DC5202A0 087C002D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000009B3810: 8C7E057E
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v44, 0              // 0000009B3814: CA100080 052C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v46, 0             // 0000009B381C: CA100080 2B2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v48, 0             // 0000009B3824: CA100080 2D300080
	v_mov_b32_e32 v47, 0                                       // 0000009B382C: 7E5E0280
	v_mov_b32_e32 v49, 0                                       // 0000009B3830: 7E620280
	s_and_saveexec_b32 s4, s3                                  // 0000009B3834: BE842003
	s_cbranch_execz 1096                                       // 0000009B3838: BFA50448 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x145c>
	v_lshrrev_b32_e32 v5, 5, v13                               // 0000009B383C: 320A1A85
	v_and_b32_e32 v44, 0x7e0, v4                               // 0000009B3840: 365808FF 000007E0
	v_sub_nc_u32_e32 v51, 0, v12                               // 0000009B3848: 4C661880
	v_lshl_or_b32 v45, v41, 3, 4                               // 0000009B384C: D656002D 02110729
	v_mul_i32_i24_e32 v43, 0xffffffe8, v41                     // 0000009B3854: 125652FF FFFFFFE8
	v_subrev_nc_u32_e32 v5, 24, v5                             // 0000009B385C: 4E0A0A98
	v_ashrrev_i32_e32 v11, 31, v10                             // 0000009B3860: 3416149F
	s_mov_b32 s3, 0                                            // 0000009B3864: BE830080
	v_mad_u32_u24 v48, v45, 3, 0x2f0                           // 0000009B3868: D60B0030 03FD072D 000002F0
	v_mul_i32_i24_e32 v49, -3, v45                             // 0000009B3874: 12625AC3
	v_cndmask_b32_e64 v4, v5, 23, vcc_lo                       // 0000009B3878: D5010004 01A92F05
	v_cmp_gt_i32_e32 vcc_lo, 23, v10                           // 0000009B3880: 7C881497
	v_mov_b32_e32 v5, 0                                        // 0000009B3884: 7E0A0280
	v_and_b32_e32 v47, 16, v0                                  // 0000009B3888: 365E0090
	v_add_nc_u32_e32 v50, 1, v3                                // 0000009B388C: 4A640681
	.long 0xd703000d                                           // 0000009B3890: D703000D
	v_cndmask_b32_e32 v0, v4, v129, vcc_lo                     // 0000009B3894: 02010304
	v_cndmask_b32_e64 v46, 0xe9, 1, vcc_lo                     // 0000009B3898: D501002E 01A902FF 000000E9
	v_add3_u32 v52, v43, v44, 0xfffffd34                       // 0000009B38A4: D6550034 03FE592B FFFFFD34
	v_mov_b32_e32 v44, v5                                      // 0000009B38B0: 7E580305
	v_lshl_or_b32 v53, v3, 5, v47                              // 0000009B38B4: D6560035 04BD0B03
	.long 0xd762000c                                           // 0000009B38BC: D762000C
	v_cndmask_b32_e32 v1, 0xff, v13, vcc_lo                    // 0000009B38C0: 02021AFF 000000FF
	v_dual_mov_b32 v45, v5 :: v_dual_add_nc_u32 v54, v46, v10  // 0000009B38C8: CA200105 2D36152E
	v_mov_b32_e32 v46, v5                                      // 0000009B38D0: 7E5C0305
	.long 0xd73c000a                                           // 0000009B38D4: D73C000A
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 0000009B38D8: 02021482
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B38DC: BF870004
	v_cmp_ne_u16_e32 vcc_lo, 24, v12                           // 0000009B38E0: 7C7A1898
	v_dual_mov_b32 v47, v5 :: v_dual_and_b32 v12, 0x7e0, v48   // 0000009B38E4: CA240105 2F0C60FF 000007E0
	v_mov_b32_e32 v43, v5                                      // 0000009B38F0: 7E560305
	s_mov_b32 s5, 0xdcd12d                                     // 0000009B38F4: BE8500FF 00DCD12D
	v_cndmask_b16 v3, 0, v13, vcc_lo                           // 0000009B38FC: D65D0003 01AA1A80
	v_and_b32_e32 v13, 0xff, v54                               // 0000009B3904: 361A6CFF 000000FF
	v_add3_u32 v54, v49, v12, 0xfffffd34                       // 0000009B390C: D6550036 03FE1931 FFFFFD34
	s_movk_i32 s21, 0x83                                       // 0000009B3918: B0150083
	s_movk_i32 s22, 0x1eee                                     // 0000009B391C: B0161EEE
	v_dual_mov_b32 v48, v5 :: v_dual_and_b32 v3, 0xff, v3      // 0000009B3920: CA240105 300206FF 000000FF
	v_lshlrev_b32_e32 v55, 2, v13                              // 0000009B392C: 306E1A82
	.long 0xd73c000c                                           // 0000009B3930: D73C000C
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 0000009B3934: 02020882
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B3938: BF870003
	v_dual_mov_b32 v49, v5 :: v_dual_lshlrev_b32 v56, 2, v3    // 0000009B393C: CA220105 31380682
	s_branch 936                                               // 0000009B3944: BFA003A8 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x12e8>
	s_or_b32 exec_lo, exec_lo, s23                             // 0000009B3948: 8C7E177E
	s_waitcnt vmcnt(23)                                        // 0000009B394C: BF895FF7
	.long 0xd73d0059                                           // 0000009B3950: D73D0059
	v_cndmask_b32_e32 v1, v52, v1, vcc_lo                      // 0000009B3954: 02020334
	s_waitcnt vmcnt(7)                                         // 0000009B3958: BF891FF7
	.long 0xd73d0026                                           // 0000009B395C: D73D0026
	v_cndmask_b32_e32 v1, v54, v38, vcc_lo                     // 0000009B3960: 02024D36
	ds_load_b128 v[1:4], v53                                   // 0000009B3964: DBFC0000 01000035
	.long 0xd73d0022                                           // 0000009B396C: D73D0022
	v_cndmask_b32_e32 v1, v52, v34, vcc_lo                     // 0000009B3970: 02024534
	s_waitcnt vmcnt(6)                                         // 0000009B3974: BF891BF7
	.long 0xd73d0023                                           // 0000009B3978: D73D0023
	v_cndmask_b32_e32 v1, v54, v36, vcc_lo                     // 0000009B397C: 02024936
	.long 0xd73d001e                                           // 0000009B3980: D73D001E
	v_cndmask_b32_e32 v1, v52, v30, vcc_lo                     // 0000009B3984: 02023D34
	v_bfe_u32 v39, v89, 9, 16                                  // 0000009B3988: D6100027 02411359
	v_mul_u32_u24_e32 v95, s5, v39                             // 0000009B3990: 16BE4E05
	v_mul_u32_u24_e32 v39, s21, v39                            // 0000009B3994: 164E4E15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000009B3998: BF870151
	v_lshl_add_u32 v39, v39, 24, v95                           // 0000009B399C: D6460027 057D3127
	v_bfe_u32 v90, v89, 6, 16                                  // 0000009B39A4: D610005A 02410D59
	v_bfe_u32 v91, v89, 3, 16                                  // 0000009B39AC: D610005B 02410759
	v_mul_u32_u24_e32 v95, s5, v90                             // 0000009B39B4: 16BEB405
	v_mul_u32_u24_e32 v90, s21, v90                            // 0000009B39B8: 16B4B415
	v_lshl_add_u32 v90, v90, 24, v95                           // 0000009B39BC: D646005A 057D315A
	v_mul_u32_u24_e32 v95, s5, v91                             // 0000009B39C4: 16BEB605
	v_mul_u32_u24_e32 v91, s21, v91                            // 0000009B39C8: 16B6B615
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009B39CC: D6220027 03FD0127 00006400
	v_lshl_add_u32 v91, v91, 24, v95                           // 0000009B39D8: D646005B 057D315B
	v_bfe_u32 v92, v38, 9, 16                                  // 0000009B39E0: D610005C 02411326
	v_and_b32_e32 v89, 0xffff, v89                             // 0000009B39E8: 36B2B2FF 0000FFFF
	v_mul_u32_u24_e32 v95, s5, v92                             // 0000009B39F0: 16BEB805
	v_mul_u32_u24_e32 v92, s21, v92                            // 0000009B39F4: 16B8B815
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B39F8: BF870002
	v_lshl_add_u32 v92, v92, 24, v95                           // 0000009B39FC: D646005C 057D315C
	v_mul_u32_u24_e32 v95, s5, v89                             // 0000009B3A04: 16BEB205
	v_mul_u32_u24_e32 v89, s21, v89                            // 0000009B3A08: 16B2B215
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000009B3A0C: D622005A 03FD015A 00006400
	v_and_b32_e32 v39, 0xffff, v39                             // 0000009B3A18: 364E4EFF 0000FFFF
	v_sad_u8 v91, v91, 0, 0x6400                               // 0000009B3A20: D622005B 03FD015B 00006400
	v_lshl_add_u32 v89, v89, 24, v95                           // 0000009B3A2C: D6460059 057D3159
	v_bfe_u32 v93, v38, 6, 16                                  // 0000009B3A34: D610005D 02410D26
	v_bfe_u32 v94, v38, 3, 16                                  // 0000009B3A3C: D610005E 02410726
	v_lshl_or_b32 v39, v90, 16, v39                            // 0000009B3A44: D6560027 049D215A
	v_and_b32_e32 v91, 0xffff, v91                             // 0000009B3A4C: 36B6B6FF 0000FFFF
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000009B3A54: D6220059 03FD0159 00006400
	v_mul_u32_u24_e32 v95, s5, v93                             // 0000009B3A60: 16BEBA05
	v_mul_u32_u24_e32 v93, s21, v93                            // 0000009B3A64: 16BABA15
	v_sad_u8 v92, v92, 0, 0x6400                               // 0000009B3A68: D622005C 03FD015C 00006400
	v_lshl_add_u32 v93, v93, 24, v95                           // 0000009B3A74: D646005D 057D315D
	v_mul_u32_u24_e32 v95, s5, v94                             // 0000009B3A7C: 16BEBC05
	v_mul_u32_u24_e32 v94, s21, v94                            // 0000009B3A80: 16BCBC15
	v_lshl_or_b32 v89, v89, 16, v91                            // 0000009B3A84: D6560059 056D2159
	v_pk_fma_f16 v39, v39, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3A8C: CC0E0027 0BFC2D27 0000C931
	v_lshl_add_u32 v94, v94, 24, v95                           // 0000009B3A98: D646005E 057D315E
	v_and_b32_e32 v38, 0xffff, v38                             // 0000009B3AA0: 364C4CFF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 0000009B3AA8: D622005D 03FD015D 00006400
	v_pk_fma_f16 v89, v89, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3AB4: CC0E0059 0BFC2D59 0000C931
	s_waitcnt lgkmcnt(0)                                       // 0000009B3AC0: BF89FC07
	v_dual_dot2acc_f32_f16 v49, v39, v1 :: v_dual_and_b32 v92, 0xffff, v92// 0000009B3AC4: CB240327 315CB8FF 0000FFFF
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000009B3AD0: D622005E 03FD015E 00006400
	v_mul_u32_u24_e32 v95, s5, v38                             // 0000009B3ADC: 16BE4C05
	v_mul_u32_u24_e32 v38, s21, v38                            // 0000009B3AE0: 164C4C15
	v_lshl_add_u32 v38, v38, 24, v95                           // 0000009B3AE4: D6460026 057D3126
	v_bfe_u32 v36, v34, 9, 16                                  // 0000009B3AEC: D6100024 02411322
	v_dot2acc_f32_f16 v49, v89, v2                             // 0000009B3AF4: 04620559
	v_lshl_or_b32 v90, v93, 16, v92                            // 0000009B3AF8: D656005A 0571215D
	v_and_b32_e32 v91, 0xffff, v94                             // 0000009B3B00: 36B6BCFF 0000FFFF
	v_mul_u32_u24_e32 v94, s5, v36                             // 0000009B3B08: 16BC4805
	v_mul_u32_u24_e32 v36, s21, v36                            // 0000009B3B0C: 16484815
	v_lshl_add_u32 v36, v36, 24, v94                           // 0000009B3B10: D6460024 05793124
	v_bfe_u32 v39, v34, 3, 16                                  // 0000009B3B18: D6100027 02410722
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000009B3B20: D6220026 03FD0126 00006400
	v_pk_fma_f16 v90, v90, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3B2C: CC0E005A 0BFC2D5A 0000C931
	v_bfe_u32 v37, v34, 6, 16                                  // 0000009B3B38: D6100025 02410D22
	v_mul_u32_u24_e32 v94, s5, v39                             // 0000009B3B40: 16BC4E05
	v_mul_u32_u24_e32 v39, s21, v39                            // 0000009B3B44: 164E4E15
	v_lshl_add_u32 v39, v39, 24, v94                           // 0000009B3B48: D6460027 05793127
	v_mul_u32_u24_e32 v94, s5, v37                             // 0000009B3B50: 16BC4A05
	v_mul_u32_u24_e32 v37, s21, v37                            // 0000009B3B54: 164A4A15
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009B3B58: D6220024 03FD0124 00006400
	v_lshl_add_u32 v37, v37, 24, v94                           // 0000009B3B64: D6460025 05793125
	v_dual_dot2acc_f32_f16 v49, v90, v3 :: v_dual_and_b32 v34, 0xffff, v34// 0000009B3B6C: CB24075A 312244FF 0000FFFF
	v_lshl_or_b32 v38, v38, 16, v91                            // 0000009B3B78: D6560026 056D2126
	v_bfe_u32 v91, v35, 9, 16                                  // 0000009B3B80: D610005B 02411323
	v_mul_u32_u24_e32 v94, s5, v34                             // 0000009B3B88: 16BC4405
	v_mul_u32_u24_e32 v34, s21, v34                            // 0000009B3B8C: 16444415
	v_lshl_add_u32 v34, v34, 24, v94                           // 0000009B3B90: D6460022 05793122
	v_mul_u32_u24_e32 v94, s5, v91                             // 0000009B3B98: 16BCB605
	v_mul_u32_u24_e32 v91, s21, v91                            // 0000009B3B9C: 16B6B615
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000009B3BA0: D6220027 03FD0127 00006400
	v_lshl_add_u32 v91, v91, 24, v94                           // 0000009B3BAC: D646005B 0579315B
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009B3BB4: 364848FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009B3BBC: D6220025 03FD0125 00006400
	v_bfe_u32 v92, v35, 6, 16                                  // 0000009B3BC8: D610005C 02410D23
	v_mul_u32_u24_e32 v94, s5, v92                             // 0000009B3BD0: 16BCB805
	v_mul_u32_u24_e32 v92, s21, v92                            // 0000009B3BD4: 16B8B815
	v_and_b32_e32 v39, 0xffff, v39                             // 0000009B3BD8: 364E4EFF 0000FFFF
	v_sad_u8 v34, v34, 0, 0x6400                               // 0000009B3BE0: D6220022 03FD0122 00006400
	v_sad_u8 v91, v91, 0, 0x6400                               // 0000009B3BEC: D622005B 03FD015B 00006400
	v_lshl_add_u32 v92, v92, 24, v94                           // 0000009B3BF8: D646005C 0579315C
	v_lshl_or_b32 v36, v37, 16, v36                            // 0000009B3C00: D6560024 04912125
	.long 0xd73d001a                                           // 0000009B3C08: D73D001A
	v_cndmask_b32_e32 v1, v52, v26, vcc_lo                     // 0000009B3C0C: 02023534
	v_lshl_or_b32 v34, v34, 16, v39                            // 0000009B3C10: D6560022 049D2122
	v_and_b32_e32 v37, 0xffff, v91                             // 0000009B3C18: 364AB6FF 0000FFFF
	v_sad_u8 v39, v92, 0, 0x6400                               // 0000009B3C20: D6220027 03FD015C 00006400
	v_pk_fma_f16 v36, v36, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3C2C: CC0E0024 0BFC2D24 0000C931
	s_waitcnt vmcnt(4)                                         // 0000009B3C38: BF8913F7
	.long 0xd73d001b                                           // 0000009B3C3C: D73D001B
	v_cndmask_b32_e32 v1, v54, v28, vcc_lo                     // 0000009B3C40: 02023936
	v_pk_fma_f16 v34, v34, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3C44: CC0E0022 0BFC2D22 0000C931
	v_bfe_u32 v28, v26, 9, 16                                  // 0000009B3C50: D610001C 0241131A
	v_lshl_or_b32 v37, v39, 16, v37                            // 0000009B3C58: D6560025 04952127
	v_dot2acc_f32_f16 v48, v36, v1                             // 0000009B3C60: 04600324
	v_bfe_u32 v36, v30, 9, 16                                  // 0000009B3C64: D6100024 0241131E
	v_bfe_u32 v29, v26, 6, 16                                  // 0000009B3C6C: D610001D 02410D1A
	v_bfe_u32 v93, v35, 3, 16                                  // 0000009B3C74: D610005D 02410723
	v_pk_fma_f16 v31, v37, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3C7C: CC0E001F 0BFC2D25 0000C931
	v_dot2acc_f32_f16 v48, v34, v2                             // 0000009B3C88: 04600522
	v_bfe_u32 v37, v30, 6, 16                                  // 0000009B3C8C: D6100025 02410D1E
	v_mul_u32_u24_e32 v89, s5, v37                             // 0000009B3C94: 16B24A05
	v_mul_u32_u24_e32 v37, s21, v37                            // 0000009B3C98: 164A4A15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B3C9C: BF8700D1
	v_lshl_add_u32 v37, v37, 24, v89                           // 0000009B3CA0: D6460025 05653125
	v_dot2acc_f32_f16 v48, v31, v3                             // 0000009B3CA8: 0460071F
	.long 0xd73d001f                                           // 0000009B3CAC: D73D001F
	v_cndmask_b32_e32 v1, v54, v32, vcc_lo                     // 0000009B3CB0: 02024136
	v_mul_u32_u24_e32 v32, s5, v36                             // 0000009B3CB4: 16404805
	v_mul_u32_u24_e32 v33, s21, v36                            // 0000009B3CB8: 16424815
	v_lshl_add_u32 v32, v33, 24, v32                           // 0000009B3CBC: D6460020 04813121
	v_bfe_u32 v33, v30, 3, 16                                  // 0000009B3CC4: D6100021 0241071E
	v_mul_u32_u24_e32 v89, s5, v33                             // 0000009B3CCC: 16B24205
	v_mul_u32_u24_e32 v33, s21, v33                            // 0000009B3CD0: 16424215
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000009B3CD4: BF870151
	v_lshl_add_u32 v33, v33, 24, v89                           // 0000009B3CD8: D6460021 05653121
	v_bfe_u32 v36, v31, 9, 16                                  // 0000009B3CE0: D6100024 0241131F
	v_and_b32_e32 v30, 0xffff, v30                             // 0000009B3CE8: 363C3CFF 0000FFFF
	v_mul_u32_u24_e32 v89, s5, v36                             // 0000009B3CF0: 16B24805
	v_mul_u32_u24_e32 v36, s21, v36                            // 0000009B3CF4: 16484815
	v_lshl_add_u32 v36, v36, 24, v89                           // 0000009B3CF8: D6460024 05653124
	v_mul_u32_u24_e32 v89, s5, v30                             // 0000009B3D00: 16B23C05
	v_mul_u32_u24_e32 v30, s21, v30                            // 0000009B3D04: 163C3C15
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000009B3D08: D6220021 03FD0121 00006400
	v_lshl_add_u32 v30, v30, 24, v89                           // 0000009B3D14: D646001E 0565311E
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009B3D1C: D6220020 03FD0120 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009B3D28: D6220025 03FD0125 00006400
	v_pk_fma_f16 v34, v38, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3D34: CC0E0022 0BFC2D26 0000C931
	v_and_b32_e32 v33, 0xffff, v33                             // 0000009B3D40: 364242FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000009B3D48: D622001E 03FD011E 00006400
	v_bfe_u32 v38, v31, 6, 16                                  // 0000009B3D54: D6100026 02410D1F
	v_mul_u32_u24_e32 v89, s5, v38                             // 0000009B3D5C: 16B24C05
	v_mul_u32_u24_e32 v38, s21, v38                            // 0000009B3D60: 164C4C15
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B3D64: BF870001
	v_lshl_add_u32 v38, v38, 24, v89                           // 0000009B3D68: D6460026 05653126
	v_lshl_or_b32 v30, v30, 16, v33                            // 0000009B3D70: D656001E 0485211E
	v_mul_u32_u24_e32 v89, s5, v28                             // 0000009B3D78: 16B23805
	v_mul_u32_u24_e32 v28, s21, v28                            // 0000009B3D7C: 16383815
	v_lshl_add_u32 v28, v28, 24, v89                           // 0000009B3D80: D646001C 0565311C
	v_dot2acc_f32_f16 v49, v34, v4                             // 0000009B3D88: 04620922
	v_pk_fma_f16 v30, v30, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3D8C: CC0E001E 0BFC2D1E 0000C931
	v_and_b32_e32 v32, 0xffff, v32                             // 0000009B3D98: 364040FF 0000FFFF
	v_mul_u32_u24_e32 v94, s5, v93                             // 0000009B3DA0: 16BCBA05
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009B3DA4: D622001C 03FD011C 00006400
	v_mul_u32_u24_e32 v93, s21, v93                            // 0000009B3DB0: 16BABA15
	v_lshl_add_u32 v93, v93, 24, v94                           // 0000009B3DB4: D646005D 0579315D
	v_lshl_or_b32 v32, v37, 16, v32                            // 0000009B3DBC: D6560020 04812125
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000009B3DC4: D6220024 03FD0124 00006400
	v_and_b32_e32 v28, 0xffff, v28                             // 0000009B3DD0: 363838FF 0000FFFF
	v_sad_u8 v37, v38, 0, 0x6400                               // 0000009B3DD8: D6220025 03FD0126 00006400
	v_sad_u8 v91, v93, 0, 0x6400                               // 0000009B3DE4: D622005B 03FD015D 00006400
	v_pk_fma_f16 v32, v32, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3DF0: CC0E0020 0BFC2D20 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009B3DFC: 364848FF 0000FFFF
	.long 0xd73d0016                                           // 0000009B3E04: D73D0016
	v_cndmask_b32_e32 v1, v52, v22, vcc_lo                     // 0000009B3E08: 02022D34
	.long 0xd73d0012                                           // 0000009B3E0C: D73D0012
	v_cndmask_b32_e32 v1, v52, v18, vcc_lo                     // 0000009B3E10: 02022534
	v_and_b32_e32 v39, 0xffff, v91                             // 0000009B3E14: 364EB6FF 0000FFFF
	v_dot2acc_f32_f16 v47, v32, v1                             // 0000009B3E1C: 045E0320
	v_bfe_u32 v32, v26, 3, 16                                  // 0000009B3E20: D6100020 0241071A
	v_mul_u32_u24_e32 v89, s5, v32                             // 0000009B3E28: 16B24005
	v_mul_u32_u24_e32 v32, s21, v32                            // 0000009B3E2C: 16404015
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B3E30: BF870001
	v_lshl_add_u32 v32, v32, 24, v89                           // 0000009B3E34: D6460020 05653120
	v_mul_u32_u24_e32 v89, s5, v29                             // 0000009B3E3C: 16B23A05
	v_mul_u32_u24_e32 v29, s21, v29                            // 0000009B3E40: 163A3A15
	v_lshl_add_u32 v29, v29, 24, v89                           // 0000009B3E44: D646001D 0565311D
	v_and_b32_e32 v26, 0xffff, v26                             // 0000009B3E4C: 363434FF 0000FFFF
	v_mul_u32_u24_e32 v89, s5, v26                             // 0000009B3E54: 16B23405
	v_mul_u32_u24_e32 v26, s21, v26                            // 0000009B3E58: 16343415
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000009B3E5C: D6220020 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000009B3E68: BF870232
	v_lshl_add_u32 v26, v26, 24, v89                           // 0000009B3E6C: D646001A 0565311A
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009B3E74: D622001D 03FD011D 00006400
	v_lshl_or_b32 v33, v37, 16, v36                            // 0000009B3E80: D6560021 04912125
	v_dual_dot2acc_f32_f16 v47, v30, v2 :: v_dual_and_b32 v32, 0xffff, v32// 0000009B3E88: CB24051E 2F2040FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B3E94: BF870214
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009B3E98: D622001A 03FD011A 00006400
	v_lshl_or_b32 v28, v29, 16, v28                            // 0000009B3EA4: D656001C 0471211D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B3EAC: BF870004
	v_pk_fma_f16 v33, v33, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3EB0: CC0E0021 0BFC2D21 0000C931
	s_waitcnt vmcnt(2)                                         // 0000009B3EBC: BF890BF7
	.long 0xd73d0013                                           // 0000009B3EC0: D73D0013
	v_cndmask_b32_e32 v1, v54, v20, vcc_lo                     // 0000009B3EC4: 02022936
	v_bfe_u32 v20, v18, 9, 16                                  // 0000009B3EC8: D6100014 02411312
	v_lshl_or_b32 v26, v26, 16, v32                            // 0000009B3ED0: D656001A 0481211A
	v_pk_fma_f16 v28, v28, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3ED8: CC0E001C 0BFC2D1C 0000C931
	v_dot2acc_f32_f16 v47, v33, v3                             // 0000009B3EE4: 045E0721
	v_bfe_u32 v21, v18, 6, 16                                  // 0000009B3EE8: D6100015 02410D12
	.long 0xd73d000e                                           // 0000009B3EF0: D73D000E
	v_cndmask_b32_e32 v1, v52, v14, vcc_lo                     // 0000009B3EF4: 02021D34
	v_pk_fma_f16 v26, v26, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B3EF8: CC0E001A 0BFC2D1A 0000C931
	v_dual_dot2acc_f32_f16 v46, v28, v1 :: v_dual_and_b32 v35, 0xffff, v35// 0000009B3F04: CB24031C 2E2246FF 0000FFFF
	.long 0xd73d0006                                           // 0000009B3F10: D73D0006
	v_cndmask_b32_e32 v1, v52, v6, vcc_lo                      // 0000009B3F14: 02020D34
	s_waitcnt vmcnt(0)                                         // 0000009B3F18: BF8903F7
	.long 0xd73d0007                                           // 0000009B3F1C: D73D0007
	v_cndmask_b32_e32 v1, v54, v8, vcc_lo                      // 0000009B3F20: 02021136
	v_add_nc_u32_e32 v50, 1, v50                               // 0000009B3F24: 4A646481
	v_dot2acc_f32_f16 v46, v26, v2                             // 0000009B3F28: 045C051A
	v_mul_u32_u24_e32 v92, s5, v35                             // 0000009B3F2C: 16B84605
	v_mul_u32_u24_e32 v35, s21, v35                            // 0000009B3F30: 16464615
	v_lshl_add_u32 v35, v35, 24, v92                           // 0000009B3F34: D6460023 05713123
	v_bfe_u32 v8, v6, 9, 16                                    // 0000009B3F3C: D6100008 02411306
	v_bfe_u32 v9, v6, 6, 16                                    // 0000009B3F44: D6100009 02410D06
	v_add_nc_u32_e32 v53, 32, v53                              // 0000009B3F4C: 4A6A6AA0
	v_mov_b32_e32 v33, v81                                     // 0000009B3F50: 7E420351
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000009B3F54: D6220023 03FD0123 00006400
	v_mov_b32_e32 v34, v77                                     // 0000009B3F60: 7E44034D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009B3F64: BF8700C2
	v_lshl_or_b32 v35, v35, 16, v39                            // 0000009B3F68: D6560023 049D2123
	v_bfe_u32 v39, v31, 3, 16                                  // 0000009B3F70: D6100027 0241071F
	v_mul_u32_u24_e32 v38, s5, v39                             // 0000009B3F78: 164C4E05
	v_mul_u32_u24_e32 v39, s21, v39                            // 0000009B3F7C: 164E4E15
	v_lshl_add_u32 v38, v39, 24, v38                           // 0000009B3F80: D6460026 04993127
	v_and_b32_e32 v31, 0xffff, v31                             // 0000009B3F88: 363E3EFF 0000FFFF
	v_mul_u32_u24_e32 v37, s5, v31                             // 0000009B3F90: 164A3E05
	v_mul_u32_u24_e32 v31, s21, v31                            // 0000009B3F94: 163E3E15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000009B3F98: BF870151
	v_lshl_add_u32 v31, v31, 24, v37                           // 0000009B3F9C: D646001F 0495311F
	v_bfe_u32 v37, v27, 9, 16                                  // 0000009B3FA4: D6100025 0241131B
	v_mul_u32_u24_e32 v89, s5, v37                             // 0000009B3FAC: 16B24A05
	v_mul_u32_u24_e32 v37, s21, v37                            // 0000009B3FB0: 164A4A15
	v_sad_u8 v36, v38, 0, 0x6400                               // 0000009B3FB4: D6220024 03FD0126 00006400
	v_lshl_add_u32 v37, v37, 24, v89                           // 0000009B3FC0: D6460025 05653125
	v_bfe_u32 v38, v27, 6, 16                                  // 0000009B3FC8: D6100026 02410D1B
	v_bfe_u32 v39, v27, 3, 16                                  // 0000009B3FD0: D6100027 0241071B
	v_mul_u32_u24_e32 v89, s5, v38                             // 0000009B3FD8: 16B24C05
	v_mul_u32_u24_e32 v38, s21, v38                            // 0000009B3FDC: 164C4C15
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B3FE0: BF870002
	v_lshl_add_u32 v38, v38, 24, v89                           // 0000009B3FE4: D6460026 05653126
	v_mul_u32_u24_e32 v89, s5, v39                             // 0000009B3FEC: 16B24E05
	v_mul_u32_u24_e32 v39, s21, v39                            // 0000009B3FF0: 164E4E15
	v_and_b32_e32 v36, 0xffff, v36                             // 0000009B3FF4: 364848FF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 0000009B3FFC: D622001F 03FD011F 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 0000009B4008: D6220025 03FD0125 00006400
	v_lshl_add_u32 v39, v39, 24, v89                           // 0000009B4014: D6460027 05653127
	v_and_b32_e32 v27, 0xffff, v27                             // 0000009B401C: 363636FF 0000FFFF
	v_sad_u8 v32, v38, 0, 0x6400                               // 0000009B4024: D6220020 03FD0126 00006400
	v_mul_u32_u24_e32 v38, s5, v27                             // 0000009B4030: 164C3605
	v_mul_u32_u24_e32 v27, s21, v27                            // 0000009B4034: 16363615
	v_and_b32_e32 v29, 0xffff, v37                             // 0000009B4038: 363A4AFF 0000FFFF
	v_sad_u8 v37, v39, 0, 0x6400                               // 0000009B4040: D6220025 03FD0127 00006400
	v_lshl_add_u32 v27, v27, 24, v38                           // 0000009B404C: D646001B 0499311B
	v_lshl_or_b32 v28, v31, 16, v36                            // 0000009B4054: D656001C 0491211F
	v_pk_fma_f16 v35, v35, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B405C: CC0E0023 0BFC2D23 0000C931
	v_lshl_or_b32 v29, v32, 16, v29                            // 0000009B4068: D656001D 04752120
	v_mov_b32_e32 v31, v62                                     // 0000009B4070: 7E3E033E
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009B4074: D622001B 03FD011B 00006400
	v_pk_fma_f16 v26, v28, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4080: CC0E001A 0BFC2D1C 0000C931
	v_and_b32_e32 v32, 0xffff, v37                             // 0000009B408C: 36404AFF 0000FFFF
	v_pk_fma_f16 v29, v29, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4094: CC0E001D 0BFC2D1D 0000C931
	v_dot2acc_f32_f16 v48, v35, v4                             // 0000009B40A0: 04600923
	v_mov_b32_e32 v37, v83                                     // 0000009B40A4: 7E4A0353
	v_dot2acc_f32_f16 v47, v26, v4                             // 0000009B40A8: 045E091A
	v_lshl_or_b32 v27, v27, 16, v32                            // 0000009B40AC: D656001B 0481211B
	v_dot2acc_f32_f16 v46, v29, v3                             // 0000009B40B4: 045C071D
	v_bfe_u32 v26, v22, 9, 16                                  // 0000009B40B8: D610001A 02411316
	v_mov_b32_e32 v35, v63                                     // 0000009B40C0: 7E46033F
	v_mov_b32_e32 v39, v85                                     // 0000009B40C4: 7E4E0355
	v_pk_fma_f16 v23, v27, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B40C8: CC0E0017 0BFC2D1B 0000C931
	v_bfe_u32 v27, v22, 6, 16                                  // 0000009B40D4: D610001B 02410D16
	v_mul_u32_u24_e32 v30, s5, v27                             // 0000009B40DC: 163C3605
	v_mul_u32_u24_e32 v27, s21, v27                            // 0000009B40E0: 16363615
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B40E4: BF870001
	v_lshl_add_u32 v27, v27, 24, v30                           // 0000009B40E8: D646001B 0479311B
	v_dot2acc_f32_f16 v46, v23, v4                             // 0000009B40F0: 045C0917
	.long 0xd73d0017                                           // 0000009B40F4: D73D0017
	v_cndmask_b32_e32 v1, v54, v24, vcc_lo                     // 0000009B40F8: 02023136
	v_mul_u32_u24_e32 v25, s5, v26                             // 0000009B40FC: 16323405
	v_mul_u32_u24_e32 v26, s21, v26                            // 0000009B4100: 16343415
	v_lshl_add_u32 v25, v26, 24, v25                           // 0000009B4104: D6460019 0465311A
	v_bfe_u32 v24, v22, 3, 16                                  // 0000009B410C: D6100018 02410716
	v_mul_u32_u24_e32 v30, s5, v24                             // 0000009B4114: 163C3005
	v_bfe_u32 v26, v23, 9, 16                                  // 0000009B4118: D610001A 02411317
	v_mul_u32_u24_e32 v24, s21, v24                            // 0000009B4120: 16303015
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009B4124: D6220019 03FD0119 00006400
	v_lshl_add_u32 v24, v24, 24, v30                           // 0000009B4130: D6460018 04793118
	v_mul_u32_u24_e32 v30, s5, v26                             // 0000009B4138: 163C3405
	v_mul_u32_u24_e32 v26, s21, v26                            // 0000009B413C: 16343415
	v_lshl_add_u32 v26, v26, 24, v30                           // 0000009B4140: D646001A 0479311A
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009B4148: 362C2CFF 0000FFFF
	v_bfe_u32 v28, v23, 6, 16                                  // 0000009B4150: D610001C 02410D17
	v_mul_u32_u24_e32 v30, s5, v22                             // 0000009B4158: 163C2C05
	v_mul_u32_u24_e32 v22, s21, v22                            // 0000009B415C: 162C2C15
	v_bfe_u32 v29, v23, 3, 16                                  // 0000009B4160: D610001D 02410717
	v_and_b32_e32 v25, 0xffff, v25                             // 0000009B4168: 363232FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 0000009B4170: D622001B 03FD011B 00006400
	v_lshl_add_u32 v22, v22, 24, v30                           // 0000009B417C: D6460016 04793116
	v_mul_u32_u24_e32 v30, s5, v28                             // 0000009B4184: 163C3805
	v_mul_u32_u24_e32 v28, s21, v28                            // 0000009B4188: 16383815
	v_lshl_add_u32 v28, v28, 24, v30                           // 0000009B418C: D646001C 0479311C
	v_mul_u32_u24_e32 v30, s5, v29                             // 0000009B4194: 163C3A05
	v_mul_u32_u24_e32 v29, s21, v29                            // 0000009B4198: 163A3A15
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000009B419C: D6220018 03FD0118 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009B41A8: D622001A 03FD011A 00006400
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000009B41B4: D646001D 0479311D
	v_lshl_or_b32 v25, v27, 16, v25                            // 0000009B41BC: D6560019 0465211B
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009B41C4: D6220016 03FD0116 00006400
	v_and_b32_e32 v24, 0xffff, v24                             // 0000009B41D0: 363030FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 0000009B41D8: 363434FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000009B41E0: D622001C 03FD011C 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000009B41EC: D622001D 03FD011D 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 0000009B41F8: 362E2EFF 0000FFFF
	v_mul_u32_u24_e32 v30, s5, v23                             // 0000009B4200: 163C2E05
	v_mul_u32_u24_e32 v23, s21, v23                            // 0000009B4204: 162E2E15
	v_pk_fma_f16 v25, v25, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4208: CC0E0019 0BFC2D19 0000C931
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B4214: BF870002
	v_lshl_add_u32 v23, v23, 24, v30                           // 0000009B4218: D6460017 04793117
	v_lshl_or_b32 v22, v22, 16, v24                            // 0000009B4220: D6560016 04612116
	v_lshl_or_b32 v24, v28, 16, v26                            // 0000009B4228: D6560018 0469211C
	v_and_b32_e32 v26, 0xffff, v29                             // 0000009B4230: 36343AFF 0000FFFF
	v_mul_u32_u24_e32 v29, s5, v20                             // 0000009B4238: 163A2805
	v_mul_u32_u24_e32 v20, s21, v20                            // 0000009B423C: 16282815
	v_lshl_add_u32 v20, v20, 24, v29                           // 0000009B4240: D6460014 04753114
	v_dot2acc_f32_f16 v45, v25, v1                             // 0000009B4248: 045A0319
	v_bfe_u32 v25, v18, 3, 16                                  // 0000009B424C: D6100019 02410712
	v_sad_u8 v23, v23, 0, 0x6400                               // 0000009B4254: D6220017 03FD0117 00006400
	v_mul_u32_u24_e32 v29, s5, v25                             // 0000009B4260: 163A3205
	v_mul_u32_u24_e32 v25, s21, v25                            // 0000009B4264: 16323215
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B4268: BF870002
	v_lshl_add_u32 v25, v25, 24, v29                           // 0000009B426C: D6460019 04753119
	v_mul_u32_u24_e32 v29, s5, v21                             // 0000009B4274: 163A2A05
	v_mul_u32_u24_e32 v21, s21, v21                            // 0000009B4278: 162A2A15
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009B427C: D6220014 03FD0114 00006400
	v_lshl_add_u32 v21, v21, 24, v29                           // 0000009B4288: D6460015 04753115
	v_and_b32_e32 v18, 0xffff, v18                             // 0000009B4290: 362424FF 0000FFFF
	v_lshl_or_b32 v23, v23, 16, v26                            // 0000009B4298: D6560017 04692117
	v_bfe_u32 v26, v19, 9, 16                                  // 0000009B42A0: D610001A 02411313
	v_mul_u32_u24_e32 v29, s5, v18                             // 0000009B42A8: 163A2405
	v_mul_u32_u24_e32 v18, s21, v18                            // 0000009B42AC: 16242415
	v_lshl_add_u32 v18, v18, 24, v29                           // 0000009B42B0: D6460012 04753112
	v_mul_u32_u24_e32 v29, s5, v26                             // 0000009B42B8: 163A3405
	v_mul_u32_u24_e32 v26, s21, v26                            // 0000009B42BC: 16343415
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000009B42C0: D6220019 03FD0119 00006400
	v_lshl_add_u32 v26, v26, 24, v29                           // 0000009B42CC: D646001A 0475311A
	v_and_b32_e32 v20, 0xffff, v20                             // 0000009B42D4: 362828FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009B42DC: D6220015 03FD0115 00006400
	v_bfe_u32 v27, v19, 6, 16                                  // 0000009B42E8: D610001B 02410D13
	v_mul_u32_u24_e32 v29, s5, v27                             // 0000009B42F0: 163A3605
	v_mul_u32_u24_e32 v27, s21, v27                            // 0000009B42F4: 16363615
	v_and_b32_e32 v25, 0xffff, v25                             // 0000009B42F8: 363232FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 0000009B4300: D6220012 03FD0112 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009B430C: D622001A 03FD011A 00006400
	v_lshl_add_u32 v27, v27, 24, v29                           // 0000009B4318: D646001B 0475311B
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000009B4320: D6560014 04512115
	v_pk_fma_f16 v22, v22, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4328: CC0E0016 0BFC2D16 0000C931
	v_lshl_or_b32 v18, v18, 16, v25                            // 0000009B4334: D6560012 04652112
	v_and_b32_e32 v21, 0xffff, v26                             // 0000009B433C: 362A34FF 0000FFFF
	v_sad_u8 v25, v27, 0, 0x6400                               // 0000009B4344: D6220019 03FD011B 00006400
	v_pk_fma_f16 v20, v20, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4350: CC0E0014 0BFC2D14 0000C931
	v_pk_fma_f16 v24, v24, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B435C: CC0E0018 0BFC2D18 0000C931
	v_pk_fma_f16 v18, v18, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4368: CC0E0012 0BFC2D12 0000C931
	v_dot2acc_f32_f16 v45, v22, v2                             // 0000009B4374: 045A0516
	v_lshl_or_b32 v21, v25, 16, v21                            // 0000009B4378: D6560015 04552119
	v_dot2acc_f32_f16 v44, v20, v1                             // 0000009B4380: 04580314
	v_bfe_u32 v20, v14, 9, 16                                  // 0000009B4384: D6100014 0241130E
	v_bfe_u32 v28, v19, 3, 16                                  // 0000009B438C: D610001C 02410713
	v_dot2acc_f32_f16 v45, v24, v3                             // 0000009B4394: 045A0718
	v_pk_fma_f16 v15, v21, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4398: CC0E000F 0BFC2D15 0000C931
	v_dot2acc_f32_f16 v44, v18, v2                             // 0000009B43A4: 04580512
	v_bfe_u32 v21, v14, 6, 16                                  // 0000009B43A8: D6100015 02410D0E
	v_mul_u32_u24_e32 v24, s5, v21                             // 0000009B43B0: 16302A05
	v_mul_u32_u24_e32 v21, s21, v21                            // 0000009B43B4: 162A2A15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000009B43B8: BF8700D1
	v_lshl_add_u32 v21, v21, 24, v24                           // 0000009B43BC: D6460015 04613115
	v_dot2acc_f32_f16 v44, v15, v3                             // 0000009B43C4: 0458070F
	.long 0xd73d000f                                           // 0000009B43C8: D73D000F
	v_cndmask_b32_e32 v1, v54, v16, vcc_lo                     // 0000009B43CC: 02022136
	v_mul_u32_u24_e32 v16, s5, v20                             // 0000009B43D0: 16202805
	v_mul_u32_u24_e32 v17, s21, v20                            // 0000009B43D4: 16222815
	v_lshl_add_u32 v16, v17, 24, v16                           // 0000009B43D8: D6460010 04413111
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009B43E0: D6220015 03FD0115 00006400
	v_pk_fma_f16 v18, v23, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B43EC: CC0E0012 0BFC2D17 0000C931
	v_bfe_u32 v17, v14, 3, 16                                  // 0000009B43F8: D6100011 0241070E
	v_bfe_u32 v20, v15, 9, 16                                  // 0000009B4400: D6100014 0241130F
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000009B4408: D6220010 03FD0110 00006400
	v_mul_u32_u24_e32 v24, s5, v17                             // 0000009B4414: 16302205
	v_mul_u32_u24_e32 v17, s21, v17                            // 0000009B4418: 16222215
	v_dual_dot2acc_f32_f16 v45, v18, v4 :: v_dual_and_b32 v14, 0xffff, v14// 0000009B441C: CB240912 2D0E1CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B4428: BF870002
	v_and_b32_e32 v16, 0xffff, v16                             // 0000009B442C: 362020FF 0000FFFF
	v_lshl_add_u32 v17, v17, 24, v24                           // 0000009B4434: D6460011 04613111
	v_mul_u32_u24_e32 v24, s5, v20                             // 0000009B443C: 16302805
	v_mul_u32_u24_e32 v20, s21, v20                            // 0000009B4440: 16282815
	v_bfe_u32 v22, v15, 6, 16                                  // 0000009B4444: D6100016 02410D0F
	v_lshl_or_b32 v16, v21, 16, v16                            // 0000009B444C: D6560010 04412115
	v_lshl_add_u32 v20, v20, 24, v24                           // 0000009B4454: D6460014 04613114
	v_mul_u32_u24_e32 v24, s5, v14                             // 0000009B445C: 16301C05
	v_mul_u32_u24_e32 v14, s21, v14                            // 0000009B4460: 161C1C15
	v_lshl_add_u32 v14, v14, 24, v24                           // 0000009B4464: D646000E 0461310E
	v_pk_fma_f16 v16, v16, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B446C: CC0E0010 0BFC2D10 0000C931
	v_mul_u32_u24_e32 v24, s5, v22                             // 0000009B4478: 16302C05
	v_mul_u32_u24_e32 v22, s21, v22                            // 0000009B447C: 162C2C15
	v_lshl_add_u32 v22, v22, 24, v24                           // 0000009B4480: D6460016 04613116
	v_mul_u32_u24_e32 v24, s5, v8                              // 0000009B4488: 16301005
	v_mul_u32_u24_e32 v8, s21, v8                              // 0000009B448C: 16101015
	v_lshl_add_u32 v8, v8, 24, v24                             // 0000009B4490: D6460008 04613108
	v_dot2acc_f32_f16 v43, v16, v1                             // 0000009B4498: 04560310
	v_bfe_u32 v16, v6, 3, 16                                   // 0000009B449C: D6100010 02410706
	v_mul_u32_u24_e32 v24, s5, v16                             // 0000009B44A4: 16302005
	v_mul_u32_u24_e32 v16, s21, v16                            // 0000009B44A8: 16202015
	v_sad_u8 v17, v17, 0, 0x6400                               // 0000009B44AC: D6220011 03FD0111 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000009B44B8: D6220014 03FD0114 00006400
	v_lshl_add_u32 v16, v16, 24, v24                           // 0000009B44C4: D6460010 04613110
	v_mul_u32_u24_e32 v24, s5, v9                              // 0000009B44CC: 16301205
	v_mul_u32_u24_e32 v9, s21, v9                              // 0000009B44D0: 16121215
	v_sad_u8 v8, v8, 0, 0x6400                                 // 0000009B44D4: D6220008 03FD0108 00006400
	v_lshl_add_u32 v9, v9, 24, v24                             // 0000009B44E0: D6460009 04613109
	v_bfe_u32 v23, v15, 3, 16                                  // 0000009B44E8: D6100017 0241070F
	v_and_b32_e32 v17, 0xffff, v17                             // 0000009B44F0: 362222FF 0000FFFF
	v_sad_u8 v14, v14, 0, 0x6400                               // 0000009B44F8: D622000E 03FD010E 00006400
	v_and_b32_e32 v20, 0xffff, v20                             // 0000009B4504: 362828FF 0000FFFF
	v_sad_u8 v21, v22, 0, 0x6400                               // 0000009B450C: D6220015 03FD0116 00006400
	v_mul_u32_u24_e32 v22, s5, v23                             // 0000009B4518: 162C2E05
	v_mul_u32_u24_e32 v23, s21, v23                            // 0000009B451C: 162E2E15
	v_lshl_add_u32 v22, v23, 24, v22                           // 0000009B4520: D6460016 04593117
	v_and_b32_e32 v8, 0xffff, v8                               // 0000009B4528: 361010FF 0000FFFF
	v_sad_u8 v9, v9, 0, 0x6400                                 // 0000009B4530: D6220009 03FD0109 00006400
	v_and_b32_e32 v15, 0xffff, v15                             // 0000009B453C: 361E1EFF 0000FFFF
	v_lshl_or_b32 v14, v14, 16, v17                            // 0000009B4544: D656000E 0445210E
	v_lshl_or_b32 v17, v21, 16, v20                            // 0000009B454C: D6560011 04512115
	v_mul_u32_u24_e32 v21, s5, v15                             // 0000009B4554: 162A1E05
	v_mul_u32_u24_e32 v15, s21, v15                            // 0000009B4558: 161E1E15
	v_sad_u8 v20, v22, 0, 0x6400                               // 0000009B455C: D6220014 03FD0116 00006400
	v_lshl_add_u32 v15, v15, 24, v21                           // 0000009B4568: D646000F 0455310F
	v_lshl_or_b32 v8, v9, 16, v8                               // 0000009B4570: D6560008 04212109
	v_pk_fma_f16 v14, v14, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4578: CC0E000E 0BFC2D0E 0000C931
	v_pk_fma_f16 v17, v17, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B4584: CC0E0011 0BFC2D11 0000C931
	v_and_b32_e32 v20, 0xffff, v20                             // 0000009B4590: 362828FF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000009B4598: D622000F 03FD010F 00006400
	v_pk_fma_f16 v8, v8, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B45A4: CC0E0008 0BFC2D08 0000C931
	v_dot2acc_f32_f16 v43, v14, v2                             // 0000009B45B0: 0456050E
	v_bfe_u32 v21, v7, 9, 16                                   // 0000009B45B4: D6100015 02411307
	v_sad_u8 v16, v16, 0, 0x6400                               // 0000009B45BC: D6220010 03FD0110 00006400
	v_bfe_u32 v22, v7, 6, 16                                   // 0000009B45C8: D6100016 02410D07
	v_dot2acc_f32_f16 v5, v8, v1                               // 0000009B45D0: 040A0308
	v_lshl_or_b32 v1, v15, 16, v20                             // 0000009B45D4: D6560001 0451210F
	v_dot2acc_f32_f16 v43, v17, v3                             // 0000009B45DC: 04560711
	v_mul_u32_u24_e32 v29, s5, v28                             // 0000009B45E0: 163A3805
	v_mul_u32_u24_e32 v28, s21, v28                            // 0000009B45E4: 16383815
	v_lshl_add_u32 v28, v28, 24, v29                           // 0000009B45E8: D646001C 0475311C
	v_pk_fma_f16 v1, v1, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B45F0: CC0E0001 0BFC2D01 0000C931
	v_and_b32_e32 v6, 0xffff, v6                               // 0000009B45FC: 360C0CFF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 0000009B4604: 362020FF 0000FFFF
	v_bfe_u32 v23, v7, 3, 16                                   // 0000009B460C: D6100017 02410707
	v_sad_u8 v26, v28, 0, 0x6400                               // 0000009B4614: D622001A 03FD011C 00006400
	v_dot2acc_f32_f16 v43, v1, v4                              // 0000009B4620: 04560901
	v_mul_u32_u24_e32 v24, s5, v6                              // 0000009B4624: 16300C05
	v_mul_u32_u24_e32 v6, s21, v6                              // 0000009B4628: 160C0C15
	v_lshl_add_u32 v6, v6, 24, v24                             // 0000009B462C: D6460006 04613106
	v_mul_u32_u24_e32 v24, s5, v21                             // 0000009B4634: 16302A05
	v_mul_u32_u24_e32 v21, s21, v21                            // 0000009B4638: 162A2A15
	v_lshl_add_u32 v21, v21, 24, v24                           // 0000009B463C: D6460015 04613115
	v_mul_u32_u24_e32 v24, s5, v22                             // 0000009B4644: 16302C05
	v_mul_u32_u24_e32 v22, s21, v22                            // 0000009B4648: 162C2C15
	v_sad_u8 v6, v6, 0, 0x6400                                 // 0000009B464C: D6220006 03FD0106 00006400
	v_lshl_add_u32 v22, v22, 24, v24                           // 0000009B4658: D6460016 04613116
	v_sad_u8 v21, v21, 0, 0x6400                               // 0000009B4660: D6220015 03FD0115 00006400
	v_mul_u32_u24_e32 v24, s5, v23                             // 0000009B466C: 16302E05
	v_mul_u32_u24_e32 v23, s21, v23                            // 0000009B4670: 162E2E15
	v_lshl_or_b32 v6, v6, 16, v16                              // 0000009B4674: D6560006 04412106
	v_sad_u8 v16, v22, 0, 0x6400                               // 0000009B467C: D6220010 03FD0116 00006400
	v_and_b32_e32 v9, 0xffff, v21                              // 0000009B4688: 36122AFF 0000FFFF
	v_dual_mov_b32 v18, v67 :: v_dual_and_b32 v25, 0xffff, v26 // 0000009B4690: CA240143 121834FF 0000FFFF
	v_lshl_add_u32 v23, v23, 24, v24                           // 0000009B469C: D6460017 04613117
	v_pk_fma_f16 v6, v6, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B46A4: CC0E0006 0BFC2D06 0000C931
	v_mov_b32_e32 v26, v71                                     // 0000009B46B0: 7E340347
	v_lshl_or_b32 v9, v16, 16, v9                              // 0000009B46B4: D6560009 04252110
	v_dual_mov_b32 v28, v84 :: v_dual_and_b32 v7, 0xffff, v7   // 0000009B46BC: CA240154 1C060EFF 0000FFFF
	v_mul_u32_u24_e32 v22, s5, v7                              // 0000009B46C8: 162C0E05
	v_mul_u32_u24_e32 v7, s21, v7                              // 0000009B46CC: 160E0E15
	v_sad_u8 v21, v23, 0, 0x6400                               // 0000009B46D0: D6220015 03FD0117 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009B46DC: BF870242
	v_lshl_add_u32 v7, v7, 24, v22                             // 0000009B46E0: D6460007 04593107
	v_pk_fma_f16 v8, v9, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B46E8: CC0E0008 0BFC2D09 0000C931
	v_dot2acc_f32_f16 v5, v6, v2                               // 0000009B46F4: 040A0506
	v_dual_mov_b32 v32, v86 :: v_dual_and_b32 v19, 0xffff, v19 // 0000009B46F8: CA240156 201226FF 0000FFFF
	v_sad_u8 v7, v7, 0, 0x6400                                 // 0000009B4704: D6220007 03FD0107 00006400
	v_mov_b32_e32 v9, v68                                      // 0000009B4710: 7E120344
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009B4714: BF870244
	v_dual_dot2acc_f32_f16 v5, v8, v3 :: v_dual_and_b32 v16, 0xffff, v21// 0000009B4718: CB240708 05102AFF 0000FFFF
	v_mov_b32_e32 v8, v73                                      // 0000009B4724: 7E100349
	v_dual_mov_b32 v6, v65 :: v_dual_mov_b32 v17, v70          // 0000009B4728: CA100141 06100146
	v_mov_b32_e32 v14, v66                                     // 0000009B4730: 7E1C0342
	v_lshl_or_b32 v7, v7, 16, v16                              // 0000009B4734: D6560007 04412107
	v_mov_b32_e32 v16, v76                                     // 0000009B473C: 7E20034C
	v_mul_u32_u24_e32 v27, s5, v19                             // 0000009B4740: 16362605
	v_mul_u32_u24_e32 v19, s21, v19                            // 0000009B4744: 16262615
	v_lshl_add_u32 v19, v19, 24, v27                           // 0000009B4748: D6460013 046D3113
	v_pk_fma_f16 v2, v7, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B4750: CC0E0002 0BFC2D07 0000C931
	v_mov_b32_e32 v7, v57                                      // 0000009B475C: 7E0E0339
	v_dual_mov_b32 v15, v58 :: v_dual_mov_b32 v20, v79         // 0000009B4760: CA10013A 0F14014F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4768: BF870214
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009B476C: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v5, v2, v4                               // 0000009B4778: 040A0902
	v_dual_mov_b32 v21, v72 :: v_dual_mov_b32 v24, v82         // 0000009B477C: CA100148 15180152
	v_mov_b32_e32 v22, v69                                     // 0000009B4784: 7E2C0345
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009B4788: BF870244
	v_lshl_or_b32 v19, v19, 16, v25                            // 0000009B478C: D6560013 04652113
	v_mov_b32_e32 v25, v75                                     // 0000009B4794: 7E32034B
	v_add_nc_u32_e32 v3, v51, v50                              // 0000009B4798: 4A066533
	v_dual_mov_b32 v23, v60 :: v_dual_mov_b32 v36, v87         // 0000009B479C: CA10013C 17240157
	v_pk_fma_f16 v19, v19, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B47A4: CC0E0013 0BFC2D13 0000C931
	v_mov_b32_e32 v29, v78                                     // 0000009B47B0: 7E3A034E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B47B4: BF870224
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 0000009B47B8: 7C940686
	v_dual_mov_b32 v27, v61 :: v_dual_mov_b32 v38, v88         // 0000009B47BC: CA10013D 1B260158
	v_dot2acc_f32_f16 v44, v19, v4                             // 0000009B47C4: 04580913
	v_dual_mov_b32 v19, v59 :: v_dual_mov_b32 v30, v74         // 0000009B47C8: CA10013B 131E014A
	v_mov_b32_e32 v1, v80                                      // 0000009B47D0: 7E020350
	v_mov_b32_e32 v2, v64                                      // 0000009B47D4: 7E040340
	s_or_b32 s3, vcc_lo, s3                                    // 0000009B47D8: 8C03036A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B47DC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000009B47E0: 917E037E
	s_cbranch_execz 92                                         // 0000009B47E4: BFA5005C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1458>
	s_mov_b32 s23, exec_lo                                     // 0000009B47E8: BE97007E
	.long 0xd4c9007e                                           // 0000009B47EC: D4C9007E
	v_cndmask_b32_e32 v1, v50, v42, vcc_lo                     // 0000009B47F0: 02025532
	s_cbranch_execz 64596                                      // 0000009B47F4: BFA5FC54 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x448>
	v_mad_u64_u32 v[3:4], null, 0x300, v50, s[6:7]             // 0000009B47F8: D6FE7C03 001A64FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B4804: BF870091
	.long 0xd7006a41                                           // 0000009B4808: D7006A41
	v_cndmask_b32_e32 v1, v3, v10, vcc_lo                      // 0000009B480C: 02021503
	v_add_co_ci_u32_e64 v66, null, v4, v11, vcc_lo             // 0000009B4810: D5207C42 01AA1704
	.long 0xd7006a48                                           // 0000009B4818: D7006A48
	v_cndmask_b32_e32 v1, v3, v55, vcc_lo                      // 0000009B481C: 02026F03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009B4820: BF8700A1
	v_add_co_ci_u32_e64 v73, null, 0, v4, vcc_lo               // 0000009B4824: D5207C49 01AA0880
	.long 0xd7006a56                                           // 0000009B482C: D7006A56
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 0000009B4830: 02021903
	v_add_co_ci_u32_e64 v87, null, v4, v13, vcc_lo             // 0000009B4834: D5207C57 01AA1B04
	.long 0xd7006a03                                           // 0000009B483C: D7006A03
	v_cndmask_b32_e32 v1, v3, v56, vcc_lo                      // 0000009B4840: 02027103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B4844: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000009B4848: D5207C04 01AA0880
	s_clause 0x1f                                              // 0000009B4850: BF85001F
	global_load_b32 v64, v[65:66], off                         // 0000009B4854: DC520000 407C0041
	global_load_b32 v63, v[65:66], off offset:96               // 0000009B485C: DC520060 3F7C0041
	global_load_b32 v62, v[65:66], off offset:192              // 0000009B4864: DC5200C0 3E7C0041
	global_load_b32 v61, v[65:66], off offset:288              // 0000009B486C: DC520120 3D7C0041
	global_load_b32 v60, v[65:66], off offset:384              // 0000009B4874: DC520180 3C7C0041
	global_load_b32 v59, v[65:66], off offset:480              // 0000009B487C: DC5201E0 3B7C0041
	global_load_b32 v58, v[65:66], off offset:576              // 0000009B4884: DC520240 3A7C0041
	global_load_b32 v57, v[65:66], off offset:672              // 0000009B488C: DC5202A0 397C0041
	global_load_b32 v80, v[72:73], off                         // 0000009B4894: DC520000 507C0048
	global_load_b32 v77, v[72:73], off offset:96               // 0000009B489C: DC520060 4D7C0048
	global_load_b32 v74, v[72:73], off offset:192              // 0000009B48A4: DC5200C0 4A7C0048
	global_load_b32 v71, v[72:73], off offset:288              // 0000009B48AC: DC520120 477C0048
	global_load_b32 v69, v[72:73], off offset:384              // 0000009B48B4: DC520180 457C0048
	global_load_b32 v67, v[72:73], off offset:480              // 0000009B48BC: DC5201E0 437C0048
	global_load_b32 v66, v[72:73], off offset:576              // 0000009B48C4: DC520240 427C0048
	global_load_b32 v65, v[72:73], off offset:672              // 0000009B48CC: DC5202A0 417C0048
	global_load_b32 v85, v[86:87], off                         // 0000009B48D4: DC520000 557C0056
	global_load_b32 v83, v[86:87], off offset:96               // 0000009B48DC: DC520060 537C0056
	global_load_b32 v81, v[86:87], off offset:192              // 0000009B48E4: DC5200C0 517C0056
	global_load_b32 v78, v[86:87], off offset:288              // 0000009B48EC: DC520120 4E7C0056
	global_load_b32 v75, v[86:87], off offset:384              // 0000009B48F4: DC520180 4B7C0056
	global_load_b32 v72, v[86:87], off offset:480              // 0000009B48FC: DC5201E0 487C0056
	global_load_b32 v70, v[86:87], off offset:576              // 0000009B4904: DC520240 467C0056
	global_load_b32 v68, v[86:87], off offset:672              // 0000009B490C: DC5202A0 447C0056
	global_load_b32 v88, v[3:4], off                           // 0000009B4914: DC520000 587C0003
	global_load_b32 v87, v[3:4], off offset:96                 // 0000009B491C: DC520060 577C0003
	global_load_b32 v86, v[3:4], off offset:192                // 0000009B4924: DC5200C0 567C0003
	global_load_b32 v84, v[3:4], off offset:288                // 0000009B492C: DC520120 547C0003
	global_load_b32 v82, v[3:4], off offset:384                // 0000009B4934: DC520180 527C0003
	global_load_b32 v79, v[3:4], off offset:480                // 0000009B493C: DC5201E0 4F7C0003
	global_load_b32 v76, v[3:4], off offset:576                // 0000009B4944: DC520240 4C7C0003
	global_load_b32 v73, v[3:4], off offset:672                // 0000009B494C: DC5202A0 497C0003
	s_branch 64508                                             // 0000009B4954: BFA0FBFC <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x448>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009B4958: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B495C: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000009B4960: 8C7E047E
	s_load_b128 s[4:7], s[0:1], 0x40                           // 0000009B4964: F4080100 F8000040
	s_waitcnt vmcnt(23)                                        // 0000009B496C: BF895FF7
	v_dual_mov_b32 v1, v49 :: v_dual_mov_b32 v2, v48           // 0000009B4970: CA100131 01020130
	v_dual_mov_b32 v3, v47 :: v_dual_mov_b32 v4, v46           // 0000009B4978: CA10012F 0304012E
	s_waitcnt vmcnt(16)                                        // 0000009B4980: BF8943F7
	v_dual_mov_b32 v6, v45 :: v_dual_mov_b32 v7, v44           // 0000009B4984: CA10012D 0606012C
	s_waitcnt vmcnt(0)                                         // 0000009B498C: BF8903F7
	v_dual_mov_b32 v8, v43 :: v_dual_mov_b32 v9, v5            // 0000009B4990: CA10012B 08080105
	s_mov_b32 s0, 0x76543210                                   // 0000009B4998: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v41                           // 0000009B49A0: 7C985290
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009B49A4: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009B49B0: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009B49BC: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009B49C8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009B49D4: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000009B49E0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000009B49EC: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 0000009B49F8: D65C0009 03FC0109 FEDCBA98
	s_waitcnt lgkmcnt(0)                                       // 0000009B4A04: BF89FC07
	s_barrier                                                  // 0000009B4A08: BFBD0000
	buffer_gl0_inv                                             // 0000009B4A0C: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009B4A14: BE80206A
	s_cbranch_execz 20                                         // 0000009B4A18: BFA50014 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x156c>
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v48, v2    // 0000009B4A1C: C9081305 05020530
	v_dual_add_f32 v4, v46, v4 :: v_dual_lshlrev_b32 v9, 2, v41// 0000009B4A24: C922092E 04085282
	v_dual_add_f32 v1, v49, v1 :: v_dual_add_f32 v8, v43, v8   // 0000009B4A2C: C9080331 0108112B
	v_dual_add_f32 v3, v47, v3 :: v_dual_add_f32 v6, v45, v6   // 0000009B4A34: C908072F 03060D2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B4A3C: BF870003
	v_lshl_or_b32 v9, v40, 9, v9                               // 0000009B4A40: D6560009 04251328
	v_add_f32_e32 v7, v44, v7                                  // 0000009B4A48: 060E0F2C
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 0000009B4A4C: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v4 offset0:32 offset1:48        // 0000009B4A54: D8383020 00040309
	ds_store_2addr_b32 v9, v6, v7 offset0:64 offset1:80        // 0000009B4A5C: D8385040 00070609
	ds_store_2addr_b32 v9, v8, v5 offset0:96 offset1:112       // 0000009B4A64: D8387060 00050809
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009B4A6C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B4A70: BF870009
	s_mov_b32 s21, exec_lo                                     // 0000009B4A74: BE95007E
	s_waitcnt lgkmcnt(0)                                       // 0000009B4A78: BF89FC07
	s_barrier                                                  // 0000009B4A7C: BFBD0000
	buffer_gl0_inv                                             // 0000009B4A80: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v40                                   // 0000009B4A88: 7D945080
	s_cbranch_execz 513                                        // 0000009B4A8C: BFA50201 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1d94>
	v_and_b32_e32 v1, 15, v0                                   // 0000009B4A90: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B4A94: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000009B4A98: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 0000009B4A9C: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 0000009B4AA4: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 0000009B4AAC: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 0000009B4AB0: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 0000009B4AB8: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 0000009B4AC0: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 0000009B4AC8: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000009B4AD0: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 0000009B4AD4: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 0000009B4AD8: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 0000009B4AE0: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 0000009B4AE8: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 0000009B4AF0: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 0000009B4AF8: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 0000009B4B00: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 0000009B4B08: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 0000009B4B10: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 0000009B4B18: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 0000009B4B20: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 0000009B4B28: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 0000009B4B30: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 0000009B4B38: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 0000009B4B40: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 0000009B4B48: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 0000009B4B50: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 0000009B4B58: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 0000009B4B60: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 0000009B4B68: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 0000009B4B70: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 0000009B4B78: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 0000009B4B80: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 0000009B4B84: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 0000009B4B88: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 0000009B4B8C: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 0000009B4B94: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 0000009B4B9C: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 0000009B4BA4: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 0000009B4BAC: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 0000009B4BB0: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 0000009B4BB8: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 0000009B4BBC: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 0000009B4BC4: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 0000009B4BC8: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 0000009B4BD0: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 0000009B4BD4: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 0000009B4BD8: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 0000009B4BDC: 06102908
	v_add_f32_e32 v12, v11, v13                                // 0000009B4BE0: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 0000009B4BE4: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 0000009B4BEC: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 0000009B4BF0: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 0000009B4BF4: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 0000009B4BFC: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 0000009B4C04: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B4C08: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 0000009B4C0C: 06103108
	s_waitcnt lgkmcnt(4)                                       // 0000009B4C10: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 0000009B4C14: 06265909
	s_waitcnt lgkmcnt(2)                                       // 0000009B4C18: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 0000009B4C1C: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 0000009B4C20: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 0000009B4C28: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 0000009B4C2C: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 0000009B4C30: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 0000009B4C34: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 0000009B4C38: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 0000009B4C40: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 0000009B4C48: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B4C4C: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 0000009B4C50: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 0000009B4C54: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 0000009B4C5C: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 0000009B4C64: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 0000009B4C68: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 0000009B4C6C: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 0000009B4C74: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 0000009B4C78: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 0000009B4C80: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 0000009B4C84: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009B4C8C: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 0000009B4C90: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 0000009B4C94: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 0000009B4C9C: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 0000009B4CA0: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 0000009B4CA8: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 0000009B4CAC: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 0000009B4CB4: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009B4CB8: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 0000009B4CBC: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 0000009B4CC4: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000009B4CC8: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B4CD0: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 0000009B4CD4: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 0000009B4CDC: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 0000009B4CE0: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 0000009B4CE4: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009B4CE8: 08040702
	v_add_f32_e32 v16, v16, v48                                // 0000009B4CEC: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B4CF0: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 0000009B4CF4: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 0000009B4CF8: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B4CFC: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 0000009B4D00: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 0000009B4D04: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 0000009B4D08: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B4D0C: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 0000009B4D10: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 0000009B4D18: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 0000009B4D1C: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4D20: BF870213
	.long 0xd44a0000                                           // 0000009B4D24: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009B4D28: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 0000009B4D2C: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4D30: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 0000009B4D34: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 0000009B4D38: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 0000009B4D3C: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 0000009B4D44: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B4D48: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 0000009B4D4C: 06105308
	.long 0xd44a0001                                           // 0000009B4D50: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000009B4D54: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009B4D58: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 0000009B4D5C: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 0000009B4D60: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 0000009B4D64: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 0000009B4D68: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B4D6C: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 0000009B4D70: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 0000009B4D78: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 0000009B4D7C: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 0000009B4D80: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 0000009B4D84: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4D88: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009B4D90: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B4D98: BF870113
	.long 0xd44a0003                                           // 0000009B4D9C: D44A0003
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000009B4DA0: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 0000009B4DA4: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 0000009B4DAC: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B4DB4: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4DB8: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009B4DC0: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 0000009B4DC8: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B4DCC: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4DD0: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009B4DD8: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 0000009B4DE0: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B4DE8: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4DEC: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 0000009B4DF4: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B4DF8: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4DFC: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009B4E04: D5010004 200E0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4E0C: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009B4E14: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009B4E1C: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 0000009B4E20: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 0000009B4E24: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4E2C: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009B4E34: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 0000009B4E3C: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4E40: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B4E48: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 0000009B4E4C: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009B4E50: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4E58: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009B4E60: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009B4E68: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4E6C: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 0000009B4E74: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 0000009B4E7C: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 0000009B4E80: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 0000009B4E84: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 0000009B4E88: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4E8C: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 0000009B4E94: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B4E9C: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4EA0: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009B4EA8: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4EB0: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009B4EB8: D501000B 200E170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4EC0: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4EC8: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 0000009B4ED0: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4ED4: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009B4EDC: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 0000009B4EE4: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4EE8: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009B4EF0: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B4EF8: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009B4F00: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 0000009B4F08: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4F0C: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009B4F14: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4F1C: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 0000009B4F20: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4F28: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009B4F30: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4F38: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 0000009B4F3C: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4F40: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B4F48: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009B4F50: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 0000009B4F58: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 0000009B4F60: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4F68: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B4F70: BF870214
	v_add_f32_e32 v10, v10, v12                                // 0000009B4F74: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 0000009B4F78: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B4F7C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4F80: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s3                         // 0000009B4F88: D501000F 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009B4F90: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4F98: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B4FA0: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009B4FA8: D501000A 200E150A
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000009B4FB0: D501000C 200E190C
	v_add_f32_e32 v14, v9, v11                                 // 0000009B4FB8: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 0000009B4FBC: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FC0: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 0000009B4FC8: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 0000009B4FCC: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FD0: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FD8: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FE0: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FE8: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B4FF0: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009B4FF8: 8B7E6A7E
	s_cbranch_execz 165                                        // 0000009B4FFC: BFA500A5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1d94>
	v_and_b32_e32 v26, 8, v0                                   // 0000009B5000: 36340088
	s_mul_i32 s0, s8, 0x1400                                   // 0000009B5004: 9600FF08 00001400
	s_mul_hi_i32 s1, s8, 0x1400                                // 0000009B500C: 9701FF08 00001400
	s_add_u32 s3, s10, s0                                      // 0000009B5014: 8003000A
	s_addc_u32 s8, s11, s1                                     // 0000009B5018: 8208010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v26                            // 0000009B501C: 7C943480
	s_lshl_b32 s0, s9, 7                                       // 0000009B5020: 84008709
	.long 0x7f243880                                           // 0000009B5024: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 0000009B5028: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B502C: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000009B5030: 84808100
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009B5034: D5010006 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000009B503C: 30020281
	s_add_u32 s10, s3, s0                                      // 0000009B5040: 800A0003
	s_addc_u32 s11, s8, s1                                     // 0000009B5044: 820B0108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009B5048: D5010003 21AA0703
	v_add_f32_e32 v4, v6, v4                                   // 0000009B5050: 06080906
	s_clause 0x7                                               // 0000009B5054: BF850007
	global_load_d16_b16 v18, v1, s[10:11] offset:32            // 0000009B5058: DC820020 120A0001
	global_load_d16_b16 v19, v1, s[10:11]                      // 0000009B5060: DC820000 130A0001
	global_load_d16_b16 v20, v1, s[10:11] offset:64            // 0000009B5068: DC820040 140A0001
	global_load_d16_b16 v21, v1, s[10:11] offset:96            // 0000009B5070: DC820060 150A0001
	global_load_d16_b16 v22, v1, s[10:11] offset:128           // 0000009B5078: DC820080 160A0001
	global_load_d16_b16 v23, v1, s[10:11] offset:160           // 0000009B5080: DC8200A0 170A0001
	global_load_d16_b16 v24, v1, s[10:11] offset:192           // 0000009B5088: DC8200C0 180A0001
	global_load_d16_b16 v25, v1, s[10:11] offset:224           // 0000009B5090: DC8200E0 190A0001
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 0000009B5098: D5010006 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009B50A0: D5010005 21AA0B05
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 0000009B50A8: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009B50B0: D501000E 21AA1D0E
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009B50B8: D5010010 21AA2311
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v4// 0000009B50C0: C9060503 020208FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B50CC: BF8701B4
	v_dual_add_f32 v4, v6, v8 :: v_dual_add_f32 v7, v7, v11    // 0000009B50D0: C9081106 04061707
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009B50D8: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v14, v10   // 0000009B50E0: C9081305 0506150E
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009B50E8: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B50F4: BF8701B2
	v_dual_add_f32 v8, v15, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000009B50F8: C906190F 08040AFF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 0000009B5104: BF8917F7
	.long 0x7f283992                                           // 0000009B5108: 7F283992
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009B510C: 101212FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 0000009B5114: BF8913F7
	.long 0x7f2a3992                                           // 0000009B5118: 7F2A3992
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000009B511C: C8C604FF 02060EFF 3DB504F3
	.long 0x7f263992                                           // 0000009B5128: 7F263992
	s_waitcnt vmcnt(3)                                         // 0000009B512C: BF890FF7
	.long 0x7f2c3992                                           // 0000009B5130: 7F2C3992
	s_mul_i32 s8, s20, 0x1400                                  // 0000009B5134: 9608FF14 00001400
	s_mul_hi_i32 s3, s20, 0x1400                               // 0000009B513C: 9703FF14 00001400
	s_add_u32 s8, s12, s8                                      // 0000009B5144: 8008080C
	s_addc_u32 s3, s13, s3                                     // 0000009B5148: 8203030D
	s_add_u32 s0, s8, s0                                       // 0000009B514C: 80000008
	s_addc_u32 s1, s3, s1                                      // 0000009B5150: 82010103
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009B5154: CC200003 8A020712
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 0000009B515C: CC200002 8A020513
	v_fma_mix_f32 v4, v20, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009B5164: CC200004 8A020914
	v_fma_mix_f32 v5, v21, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009B516C: CC200005 8A020B15
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B5174: BF870004
	.long 0x7e243983                                           // 0000009B5178: 7E243983
	s_waitcnt vmcnt(2)                                         // 0000009B517C: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000009B5180: CC200007 8A020F17
	.long 0x7e283984                                           // 0000009B5188: 7E283984
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000009B518C: 100C0CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000009B5194: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009B5198: CC200009 8A021319
	v_and_b32_e32 v10, 1, v18                                  // 0000009B51A0: 36142481
	.long 0x7e243985                                           // 0000009B51A4: 7E243985
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000009B51A8: 101010FF 3DB504F3
	v_and_b32_e32 v13, 1, v20                                  // 0000009B51B0: 361A2881
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009B51B4: CC200006 8A020D16
	.long 0x7e263982                                           // 0000009B51BC: 7E263982
	v_and_b32_e32 v11, 1, v18                                  // 0000009B51C0: 36162481
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009B51C4: CC200008 8A021118
	.long 0x7e243987                                           // 0000009B51CC: 7E243987
	.long 0x7e2a3986                                           // 0000009B51D0: 7E2A3986
	v_and_b32_e32 v12, 1, v19                                  // 0000009B51D4: 36182681
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000009B51D8: D6550003 03FE1503 00007FFF
	.long 0x7e2c3988                                           // 0000009B51E4: 7E2C3988
	v_and_b32_e32 v15, 1, v18                                  // 0000009B51E8: 361E2481
	.long 0x7e243989                                           // 0000009B51EC: 7E243989
	v_and_b32_e32 v14, 1, v21                                  // 0000009B51F0: 361C2A81
	v_add3_u32 v2, v2, v12, 0x7fff                             // 0000009B51F4: D6550002 03FE1902 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 0000009B5200: 36202C81
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000009B5204: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 0000009B5210: 36142481
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000009B5214: D6550005 03FE1705 00007FFF
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000009B5220: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000009B522C: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000009B5238: D6550007 03FE1F07 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000009B5244: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000009B5250: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009B5254: DC960000 00000201
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:32           // 0000009B525C: DC960020 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:64           // 0000009B5264: DC960040 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:96           // 0000009B526C: DC960060 00000501
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:128          // 0000009B5274: DC960080 00000601
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 0000009B527C: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 0000009B5284: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v9, s[0:1] offset:224          // 0000009B528C: DC9600E0 00000901
	s_or_b32 exec_lo, exec_lo, s21                             // 0000009B5294: 8C7E157E
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 0000009B5298: 9700FF02 51EB851F
	s_waitcnt_vscnt null, 0x0                                  // 0000009B52A0: BC7C0000
	buffer_gl1_inv                                             // 0000009B52A4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009B52AC: E0AC0000 00000000
	s_lshr_b32 s1, s0, 31                                      // 0000009B52B4: 85019F00
	s_ashr_i32 s0, s0, 6                                       // 0000009B52B8: 86008600
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B52BC: BF870009
	s_add_i32 s8, s0, s1                                       // 0000009B52C0: 81080100
	.long 0xd44a0000                                           // 0000009B52C4: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009B52C8: 02020080
	s_mul_i32 s1, s8, 20                                       // 0000009B52CC: 96019408
	s_barrier                                                  // 0000009B52D0: BFBD0000
	s_add_i32 s2, s9, s1                                       // 0000009B52D4: 81020109
	buffer_gl0_inv                                             // 0000009B52D8: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009B52E0: BE812000
	s_cbranch_execz 29                                         // 0000009B52E4: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1e5c>
	s_mov_b32 s11, exec_lo                                     // 0000009B52E8: BE8B007E
	s_mov_b32 s10, exec_lo                                     // 0000009B52EC: BE8A007E
	.long 0xd71f0001                                           // 0000009B52F0: D71F0001
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                    // 0000009B52F4: 0201000B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B52F8: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000009B52FC: 7D940280
	s_cbranch_execz 11                                         // 0000009B5300: BFA5000B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1e30>
	s_ashr_i32 s3, s2, 31                                      // 0000009B5304: 86039F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009B5308: BF870499
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000009B530C: 84948202
	s_add_u32 s20, s6, s20                                     // 0000009B5310: 80141406
	s_addc_u32 s21, s7, s21                                    // 0000009B5314: 82151507
	s_bcnt1_i32_b32 s3, s11                                    // 0000009B5318: BE83180B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B531C: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s3              // 0000009B5320: CA100080 02020003
	global_atomic_add_u32 v2, v2, v3, s[20:21] glc             // 0000009B5328: DCD64000 02140302
	s_or_b32 exec_lo, exec_lo, s10                             // 0000009B5330: 8C7E0A7E
	s_waitcnt vmcnt(0)                                         // 0000009B5334: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 0000009B5338: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B533C: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 0000009B5340: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 9, v1                             // 0000009B5348: 7C940289
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000009B534C: D5010001 01A90280
	ds_store_b32 v2, v1 offset:4096                            // 0000009B5354: D8341000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B535C: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000009B5360: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000009B5364: BF89FC07
	s_barrier                                                  // 0000009B5368: BFBD0000
	buffer_gl0_inv                                             // 0000009B536C: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:4096                             // 0000009B5374: D8D81000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009B537C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009B5380: 7C940280
	s_cbranch_vccnz 287                                        // 0000009B5384: BFA4011F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2304>
	s_mov_b32 s1, exec_lo                                      // 0000009B5388: BE81007E
	buffer_gl1_inv                                             // 0000009B538C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009B5394: E0AC0000 00000000
	v_cmpx_gt_u32_e32 64, v0                                   // 0000009B539C: 7D9800C0
	s_cbranch_execz 269                                        // 0000009B53A0: BFA5010D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x22d8>
	v_lshlrev_b32_e32 v0, 1, v0                                // 0000009B53A4: 30000081
	s_mul_i32 s10, s8, 10                                      // 0000009B53A8: 960A8A08
	v_mov_b32_e32 v6, 0                                        // 0000009B53AC: 7E0C0280
	s_ashr_i32 s11, s10, 31                                    // 0000009B53B0: 860B9F0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B53B4: BF870092
	v_lshl_or_b32 v0, s9, 7, v0                                // 0000009B53B8: D6560000 04010E09
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000009B53C0: 3402009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009B53C4: BF870121
	.long 0xd73c0002                                           // 0000009B53C8: D73C0002
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009B53CC: 02020081
	v_mad_i64_i32 v[0:1], null, 0xa00, s8, v[0:1]              // 0000009B53D0: D6FF7C00 040010FF 00000A00
	.long 0xd7006a02                                           // 0000009B53DC: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000009B53E0: 0202040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B53E4: BF870191
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000009B53E8: D5207C03 01AA060D
	.long 0xd73c0000                                           // 0000009B53F0: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009B53F4: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009B53F8: BF8704A2
	v_mad_i64_i32 v[2:3], null, 0x1400, s10, v[2:3]            // 0000009B53FC: D6FF7C02 040814FF 00001400
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000009B5408: 848A820A
	s_add_u32 s10, s14, s10                                    // 0000009B540C: 800A0A0E
	s_addc_u32 s11, s15, s11                                   // 0000009B5410: 820B0B0F
	s_ashr_i32 s9, s8, 31                                      // 0000009B5414: 86099F08
	global_load_b32 v7, v6, s[10:11]                           // 0000009B5418: DC520000 070A0006
	global_load_b32 v4, v[2:3], off glc                        // 0000009B5420: DC524000 047C0002
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000009B5428: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B542C: BF870009
	s_add_u32 s8, s18, s8                                      // 0000009B5430: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000009B5434: 82090913
	s_waitcnt vmcnt(0)                                         // 0000009B5438: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v4                               // 0000009B543C: 30100890
	v_and_b32_e32 v9, 0xffff0000, v4                           // 0000009B5440: 361208FF FFFF0000
	.long 0xd7006a04                                           // 0000009B5448: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000009B544C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5454: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B5458: D5207C05 01AA0680
	v_mul_f32_e32 v8, v7, v8                                   // 0000009B5460: 10101107
	v_mul_f32_e32 v7, v7, v9                                   // 0000009B5464: 100E1307
	global_load_b32 v9, v6, s[10:11] offset:4                  // 0000009B5468: DC520004 090A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009B5470: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B5478: BF8903F7
	v_dual_add_f32 v7, 0, v7 :: v_dual_lshlrev_b32 v10, 16, v4 // 0000009B547C: C9220E80 070A0890
	v_mul_f32_e32 v10, v9, v10                                 // 0000009B5484: 10141509
	v_and_b32_e32 v11, 0xffff0000, v4                          // 0000009B5488: 361608FF FFFF0000
	.long 0xd7006a04                                           // 0000009B5490: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000009B5494: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B549C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B54A0: D5207C05 01AA0680
	v_mul_f32_e32 v9, v9, v11                                  // 0000009B54A8: 10121709
	global_load_b32 v11, v6, s[10:11] offset:8                 // 0000009B54AC: DC520008 0B0A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009B54B4: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B54BC: BF8903F7
	v_dual_add_f32 v7, v7, v9 :: v_dual_lshlrev_b32 v12, 16, v4// 0000009B54C0: C9221307 070C0890
	v_and_b32_e32 v13, 0xffff0000, v4                          // 0000009B54C8: 361A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B54D0: D7006A04
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000009B54D4: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B54DC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B54E0: D5207C05 01AA0680
	v_mul_f32_e32 v12, v11, v12                                // 0000009B54E8: 1018190B
	v_mul_f32_e32 v11, v11, v13                                // 0000009B54EC: 10161B0B
	global_load_b32 v13, v6, s[10:11] offset:12                // 0000009B54F0: DC52000C 0D0A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009B54F8: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B5500: BF8903F7
	v_dual_add_f32 v7, v7, v11 :: v_dual_lshlrev_b32 v14, 16, v4// 0000009B5504: C9221707 070E0890
	v_and_b32_e32 v15, 0xffff0000, v4                          // 0000009B550C: 361E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B5514: D7006A04
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 0000009B5518: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5520: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B5524: D5207C05 01AA0680
	v_mul_f32_e32 v14, v13, v14                                // 0000009B552C: 101C1D0D
	v_mul_f32_e32 v13, v13, v15                                // 0000009B5530: 101A1F0D
	global_load_b32 v15, v6, s[10:11] offset:16                // 0000009B5534: DC520010 0F0A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009B553C: DC524000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B5544: BF8903F7
	v_dual_add_f32 v7, v7, v13 :: v_dual_lshlrev_b32 v16, 16, v4// 0000009B5548: C9221B07 07100890
	v_and_b32_e32 v17, 0xffff0000, v4                          // 0000009B5550: 362208FF FFFF0000
	.long 0xd7006a04                                           // 0000009B5558: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000009B555C: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5564: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B5568: D5207C05 01AA0680
	v_mul_f32_e32 v16, v15, v16                                // 0000009B5570: 1020210F
	v_mul_f32_e32 v15, v15, v17                                // 0000009B5574: 101E230F
	global_load_b32 v17, v6, s[10:11] offset:20                // 0000009B5578: DC520014 110A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009B5580: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B5588: BF8903F7
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v18, 16, v4// 0000009B558C: C9221F07 07120890
	v_and_b32_e32 v19, 0xffff0000, v4                          // 0000009B5594: 362608FF FFFF0000
	.long 0xd7006a04                                           // 0000009B559C: D7006A04
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000009B55A0: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B55A8: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B55AC: D5207C05 01AA0680
	v_mul_f32_e32 v18, v17, v18                                // 0000009B55B4: 10242511
	v_mul_f32_e32 v17, v17, v19                                // 0000009B55B8: 10222711
	global_load_b32 v19, v6, s[10:11] offset:24                // 0000009B55BC: DC520018 130A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009B55C4: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B55CC: BF8903F7
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 16, v4// 0000009B55D0: C9222307 07140890
	v_and_b32_e32 v21, 0xffff0000, v4                          // 0000009B55D8: 362A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B55E0: D7006A04
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 0000009B55E4: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B55EC: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B55F0: D5207C05 01AA0680
	v_mul_f32_e32 v20, v19, v20                                // 0000009B55F8: 10282913
	v_mul_f32_e32 v19, v19, v21                                // 0000009B55FC: 10262B13
	global_load_b32 v21, v6, s[10:11] offset:28                // 0000009B5600: DC52001C 150A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009B5608: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B5610: BF8903F7
	v_dual_add_f32 v7, v7, v19 :: v_dual_lshlrev_b32 v22, 16, v4// 0000009B5614: C9222707 07160890
	v_and_b32_e32 v23, 0xffff0000, v4                          // 0000009B561C: 362E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B5624: D7006A04
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 0000009B5628: 020204FF 0000A000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5630: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B5634: D5207C05 01AA0680
	v_mul_f32_e32 v22, v21, v22                                // 0000009B563C: 102C2D15
	v_mul_f32_e32 v21, v21, v23                                // 0000009B5640: 102A2F15
	global_load_b32 v23, v6, s[10:11] offset:32                // 0000009B5644: DC520020 170A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009B564C: DC524000 047C0004
	.long 0xd7006a02                                           // 0000009B5654: D7006A02
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000009B5658: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5660: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000009B5664: D5207C03 01AA0680
	v_add_f32_e32 v7, v7, v21                                  // 0000009B566C: 060E2B07
	s_waitcnt vmcnt(0)                                         // 0000009B5670: BF8903F7
	v_lshlrev_b32_e32 v5, 16, v4                               // 0000009B5674: 300A0890
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009B5678: 360808FF FFFF0000
	v_mul_f32_e32 v5, v23, v5                                  // 0000009B5680: 100A0B17
	v_mul_f32_e32 v4, v23, v4                                  // 0000009B5684: 10080917
	global_load_b32 v23, v6, s[10:11] offset:36                // 0000009B5688: DC520024 170A0006
	global_load_b32 v2, v[2:3], off offset:1024 glc            // 0000009B5690: DC524400 027C0002
	v_add_f32_e32 v4, v7, v4                                   // 0000009B5698: 06080907
	s_waitcnt vmcnt(0)                                         // 0000009B569C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v2                              // 0000009B56A0: 30300490
	v_and_b32_e32 v25, 0xffff0000, v2                          // 0000009B56A4: 363204FF FFFF0000
	.long 0xd7006a02                                           // 0000009B56AC: D7006A02
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000009B56B0: 02020010
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B56B4: BF870001
	v_add_co_ci_u32_e64 v3, null, s17, v1, vcc_lo              // 0000009B56B8: D5207C03 01AA0211
	v_mul_f32_e32 v24, v23, v24                                // 0000009B56C0: 10303117
	v_mul_f32_e32 v23, v23, v25                                // 0000009B56C4: 102E3317
	v_add_f32_e32 v4, v4, v23                                  // 0000009B56C8: 06082F04
	global_load_b32 v2, v[2:3], off                            // 0000009B56CC: DC520000 027C0002
	global_load_b32 v3, v6, s[8:9]                             // 0000009B56D4: DC520000 03080006
	v_add_f32_e32 v6, 0, v8                                    // 0000009B56DC: 060C1080
	.long 0xd7006a00                                           // 0000009B56E0: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000009B56E4: 02020004
	v_bfe_u32 v7, v4, 16, 1                                    // 0000009B56E8: D6100007 02052104
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000009B56F0: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B56F8: BF870194
	v_add_f32_e32 v6, v6, v10                                  // 0000009B56FC: 060C1506
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000009B5700: D6550004 03FE0F04 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B570C: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000009B5710: 060C1906
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009B5714: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B571C: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 0000009B5720: 060C1D06
	v_add_f32_e32 v6, v6, v16                                  // 0000009B5724: 060C2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5728: BF870091
	v_add_f32_e32 v6, v6, v18                                  // 0000009B572C: 060C2506
	v_add_f32_e32 v6, v6, v20                                  // 0000009B5730: 060C2906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5734: BF870091
	v_add_f32_e32 v6, v6, v22                                  // 0000009B5738: 060C2D06
	v_add_f32_e32 v5, v6, v5                                   // 0000009B573C: 060A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5740: BF870091
	v_add_f32_e32 v5, v5, v24                                  // 0000009B5744: 060A3105
	v_bfe_u32 v6, v5, 16, 1                                    // 0000009B5748: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5750: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000009B5754: D6550005 03FE0D05 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000009B5760: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000009B5768: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v2                               // 0000009B576C: 300C0490
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000009B5770: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000009B5778: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B577C: BF870112
	v_fmac_f32_e32 v5, v3, v6                                  // 0000009B5780: 560A0D03
	v_fmac_f32_e32 v4, v3, v2                                  // 0000009B5784: 56080503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B5788: BF870112
	v_bfe_u32 v2, v5, 16, 1                                    // 0000009B578C: D6100002 02052105
	v_bfe_u32 v3, v4, 16, 1                                    // 0000009B5794: D6100003 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B579C: BF8701A2
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000009B57A0: D6550002 03FE0505 00007FFF
	.long 0x7f0a3880                                           // 0000009B57AC: 7F0A3880
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000009B57B0: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B57BC: BF870093
	.long 0x7e0a3982                                           // 0000009B57C0: 7E0A3982
	v_and_or_b32 v2, 0xffff0000, v3, v5                        // 0000009B57C4: D6570002 041606FF FFFF0000
	global_store_b32 v[0:1], v2, off                           // 0000009B57D0: DC6A0000 007C0200
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B57D8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000009B57DC: BE812000
	s_cbranch_execz 8                                          // 0000009B57E0: BFA50008 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi3ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2304>
	s_ashr_i32 s3, s2, 31                                      // 0000009B57E4: 86039F02
	v_mov_b32_e32 v0, 0                                        // 0000009B57E8: 7E000280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000009B57EC: 84808202
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B57F0: BF870009
	s_add_u32 s0, s6, s0                                       // 0000009B57F4: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000009B57F8: 82010107
	global_store_b32 v0, v0, s[0:1]                            // 0000009B57FC: DC6A0000 00000000
	s_endpgm                                                   // 0000009B5804: BFB00000
		...

