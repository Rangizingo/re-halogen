00000000008b3700 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008B3700: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000008B3708: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008B3710: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008B3714: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000008B3718: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008B371C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B3720: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 0000008B3724: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 0000008B372C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 0000008B3730: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 0000008B3734: D610000F 02050B00
	.long 0x7f0e3880                                           // 0000008B373C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 0000008B3740: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000008B3744: BF89FC07
	s_clause 0x1                                               // 0000008B3748: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 0000008B374C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 0000008B3754: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 0000008B375C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008B3760: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008B3764: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 0000008B3768: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 0000008B376C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008B3770: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000008B3774: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008B3778: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 0000008B377C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 0000008B3780: CA640680 0310009F
	s_add_u32 s10, s10, s22                                    // 0000008B3788: 800A160A
	s_addc_u32 s11, s11, 0                                     // 0000008B378C: 820B800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 0000008B3790: D5010004 01A82A80
	s_lshr_b64 s[10:11], s[10:11], 5                           // 0000008B3798: 858A850A
	.long 0xd72c0008                                           // 0000008B379C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000008B37A0: 02020613
	s_add_i32 s11, s10, 1                                      // 0000008B37A4: 810B810A
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000008B37A8: D6FE7C09 00081D03
	s_lshr_b32 s19, s11, 31                                    // 0000008B37B0: 85139F0B
	.long 0xd72c0015                                           // 0000008B37B4: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000008B37B8: 02001D04
	s_add_i32 s11, s11, s19                                    // 0000008B37BC: 810B130B
	.long 0xd72c0016                                           // 0000008B37C0: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000008B37C4: 02020812
	s_ashr_i32 s11, s11, 1                                     // 0000008B37C8: 860B810B
	s_add_u32 s2, s4, s16                                      // 0000008B37CC: 80021004
	.long 0xd72c0013                                           // 0000008B37D0: D72C0013
	v_cndmask_b32_e32 v1, s11, v15, vcc_lo                     // 0000008B37D4: 02021E0B
	s_addc_u32 s3, s5, s17                                     // 0000008B37D8: 82031105
	.long 0xd72c000d                                           // 0000008B37DC: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000008B37E0: 02001F03
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000008B37E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008B37EC: BF870223
	v_add_nc_u32_e32 v4, s11, v19                              // 0000008B37F0: 4A08260B
	v_add_nc_u32_e32 v19, v19, v16                             // 0000008B37F4: 4A262113
	v_add3_u32 v10, v21, v10, v13                              // 0000008B37F8: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 0000008B3800: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 0000008B3804: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 0000008B380C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 0000008B3810: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B3818: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000008B381C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 0000008B3828: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 0000008B3830: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 0000008B383C: 7E060280
	v_min_i32_e32 v20, s10, v4                                 // 0000008B3840: 2228080A
	.long 0x7e0e3985                                           // 0000008B3844: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 0000008B3848: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 0000008B3850: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B3858: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 0000008B385C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000008B3868: 7C822913
	ds_store_b32 v5, v6                                        // 0000008B386C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 0000008B3874: BF89FC07
	s_barrier                                                  // 0000008B3878: BFBD0000
	buffer_gl0_inv                                             // 0000008B387C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008B3884: BE83206A
	s_cbranch_execz 21                                         // 0000008B3888: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000008B388C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000008B3890: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B3894: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008B3898: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008B389C: 3408069F
	.long 0xd7000201                                           // 0000008B38A0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008B38A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B38A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000008B38AC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000008B38B4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008B38B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008B38BC: D5207C04 000A090A
	s_clause 0x1                                               // 0000008B38C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000008B38C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008B38D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008B38D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000008B38DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B38E0: 8C7E037E
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008B38E4: BE83206A
	s_cbranch_execz 207                                        // 0000008B38E8: BFA500CF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x528>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008B38EC: BF870131
	v_dual_mov_b32 v24, v18 :: v_dual_add_nc_u32 v5, 32, v19   // 0000008B38F0: CA200112 180426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000008B38F8: CA220080 110C2685
	s_mov_b32 s4, 0                                            // 0000008B3900: BE840080
	v_lshlrev_b32_e32 v22, 4, v5                               // 0000008B3904: 302C0A84
	v_lshlrev_b32_e32 v23, 1, v5                               // 0000008B3908: 302E0A81
	s_branch 166                                               // 0000008B390C: BFA000A6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x4a8>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008B3910: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008B3914: 341A189F
	v_lshrrev_b32_e32 v41, 6, v1                               // 0000008B3918: 32520286
	v_lshrrev_b32_e32 v42, 14, v1                              // 0000008B391C: 3254028E
	v_and_b32_e32 v43, 0xff, v2                                // 0000008B3920: 365604FF 000000FF
	v_lshrrev_b32_e32 v44, 6, v2                               // 0000008B3928: 32580486
	.long 0xd73c0019                                           // 0000008B392C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008B3930: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000008B3934: 361A02FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v41                              // 0000008B393C: 365252FF 000003FC
	v_and_b32_e32 v42, 0x3fc, v42                              // 0000008B3944: 365454FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008B394C: 32020296
	v_lshrrev_b32_e32 v45, 14, v2                              // 0000008B3950: 325A048E
	.long 0xd7000225                                           // 0000008B3954: D7000225
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000008B3958: 02023206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008B395C: BF870001
	v_add_co_ci_u32_e64 v38, null, s7, v26, s2                 // 0000008B3960: D5207C26 000A3407
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008B3968: 301A1A82
	ds_load_b32 v41, v41                                       // 0000008B396C: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 0000008B3974: D8D80000 2A00002A
	s_clause 0x3                                               // 0000008B397C: BF850003
	global_load_b128 v[25:28], v[37:38], off                   // 0000008B3980: DC5E0000 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008B3988: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008B3990: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008B3998: DC5E0030 257C0025
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008B39A0: 32040496
	ds_load_b32 v13, v13                                       // 0000008B39A4: D8D80000 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008B39AC: 360202FF 000003FC
	v_lshlrev_b32_e32 v43, 2, v43                              // 0000008B39B4: 30565682
	v_and_b32_e32 v44, 0x3fc, v44                              // 0000008B39B8: 365858FF 000003FC
	v_and_b32_e32 v45, 0x3fc, v45                              // 0000008B39C0: 365A5AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008B39C8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008B39D0: D8D80000 01000001
	ds_load_b32 v43, v43                                       // 0000008B39D8: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 0000008B39E0: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 0000008B39E8: D8D80000 2D00002D
	ds_load_b32 v2, v2                                         // 0000008B39F0: D8D80000 02000002
	v_add_nc_u32_e32 v22, 0x200, v22                           // 0000008B39F8: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v23, 64, v23                              // 0000008B3A00: 4A2E2EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008B3A04: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000008B3A0C: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008B3A10: BF870149
	s_or_b32 s4, s2, s4                                        // 0000008B3A14: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000008B3A18: BF890C57
	v_dot2_f32_bf16 v13, v25, v13, 0                           // 0000008B3A1C: CC1A400D 1A021B19
	v_and_b32_e32 v25, 0xff, v3                                // 0000008B3A24: 363206FF 000000FF
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 0000008B3A2C: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 6, v3                               // 0000008B3A34: 32340686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B3A38: BF8701A2
	v_dot2_f32_bf16 v13, v27, v42, v13                         // 0000008B3A3C: CC1A400D 1C36551B
	v_lshrrev_b32_e32 v27, 14, v3                              // 0000008B3A44: 3236068E
	v_and_b32_e32 v26, 0x3fc, v26                              // 0000008B3A48: 363434FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008B3A50: 32060696
	s_waitcnt lgkmcnt(4)                                       // 0000008B3A54: BF89FC47
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 0000008B3A58: CC1A4001 1C36031C
	v_lshlrev_b32_e32 v13, 2, v25                              // 0000008B3A60: 301A3282
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008B3A64: 363636FF 000003FC
	v_and_b32_e32 v25, 0xff, v4                                // 0000008B3A6C: 363208FF 000000FF
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000008B3A74: 32380886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008B3A78: BF890837
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 0000008B3A7C: CC1A4001 1C06571D
	ds_load_b32 v13, v13                                       // 0000008B3A84: D8D80000 0D00000D
	ds_load_b32 v26, v26                                       // 0000008B3A8C: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000008B3A94: D8D80000 1B00001B
	v_lshrrev_b32_e32 v29, 14, v4                              // 0000008B3A9C: 323A088E
	s_waitcnt lgkmcnt(5)                                       // 0000008B3AA0: BF89FC57
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 0000008B3AA4: CC1A4001 1C06591E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008B3AAC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008B3AB0: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000008B3AB8: 30323282
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000008B3ABC: 363838FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008B3AC4: BF89FC47
	v_dot2_f32_bf16 v1, v31, v45, v1                           // 0000008B3AC8: CC1A4001 1C065B1F
	v_and_b32_e32 v29, 0x3fc, v29                              // 0000008B3AD0: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008B3AD8: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008B3AE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B3AE4: BF870003
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 0000008B3AE8: CC1A4001 1C060520
	ds_load_b32 v2, v3                                         // 0000008B3AF0: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000008B3AF8: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000008B3B00: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000008B3B08: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000008B3B10: D8D80000 1D000004
	v_mov_b32_e32 v4, v8                                       // 0000008B3B18: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008B3B1C: BF890477
	v_dot2_f32_bf16 v1, v33, v13, v1                           // 0000008B3B20: CC1A4001 1C061B21
	s_waitcnt lgkmcnt(6)                                       // 0000008B3B28: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B3B2C: BF8700A1
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 0000008B3B30: CC1A4001 1C063522
	s_waitcnt lgkmcnt(5)                                       // 0000008B3B38: BF89FC57
	v_dot2_f32_bf16 v1, v35, v27, v1                           // 0000008B3B3C: CC1A4001 1C063723
	s_waitcnt lgkmcnt(4)                                       // 0000008B3B44: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008B3B48: BF870131
	v_dot2_f32_bf16 v1, v36, v2, v1                            // 0000008B3B4C: CC1A4001 1C060524
	v_mov_b32_e32 v2, v6                                       // 0000008B3B54: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008B3B58: BF890037
	v_dot2_f32_bf16 v1, v37, v3, v1                            // 0000008B3B5C: CC1A4001 1C060725
	v_mov_b32_e32 v3, v7                                       // 0000008B3B64: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 0000008B3B68: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B3B6C: BF8700A2
	v_dot2_f32_bf16 v1, v38, v25, v1                           // 0000008B3B70: CC1A4001 1C063326
	s_waitcnt lgkmcnt(1)                                       // 0000008B3B78: BF89FC17
	v_dot2_f32_bf16 v1, v39, v28, v1                           // 0000008B3B7C: CC1A4001 1C063927
	s_waitcnt lgkmcnt(0)                                       // 0000008B3B84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008B3B88: BF870121
	v_dot2_f32_bf16 v8, v40, v29, v1                           // 0000008B3B8C: CC1A4008 1C063B28
	v_mov_b32_e32 v1, v5                                       // 0000008B3B94: 7E020305
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v24    // 0000008B3B98: C8101112 11120118
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000008B3BA0: 917E047E
	s_cbranch_execz 31                                         // 0000008B3BA4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x524>
	s_waitcnt vmcnt(0)                                         // 0000008B3BA8: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000008B3BAC: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008B3BB4: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008B3BBC: 7E0E0303
	s_mov_b32 s5, exec_lo                                      // 0000008B3BC0: BE85007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008B3BC4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000008B3BC8: 7C8C2913
	.long 0xd4c1007e                                           // 0000008B3BCC: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000008B3BD0: 02022913
	s_cbranch_execz 65358                                      // 0000008B3BD4: BFA5FF4E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	v_ashrrev_i32_e32 v6, 31, v23                              // 0000008B3BD8: 340C2E9F
	v_ashrrev_i32_e32 v8, 31, v22                              // 0000008B3BDC: 34102C9F
	.long 0xd7000205                                           // 0000008B3BE0: D7000205
	v_cndmask_b32_e32 v1, v11, v23, vcc_lo                     // 0000008B3BE4: 02022F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B3BE8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 0000008B3BEC: D5207C06 000A0D15
	.long 0xd7000207                                           // 0000008B3BF4: D7000207
	v_cndmask_b32_e32 v1, v9, v22, vcc_lo                      // 0000008B3BF8: 02022D09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 0000008B3BFC: D5207C08 000A110A
	s_clause 0x1                                               // 0000008B3C04: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000008B3C08: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000008B3C10: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000008B3C18: BF8907F7
	v_cvt_f32_f16_e32 v24, v13                                 // 0000008B3C1C: 7E30170D
	s_branch 65339                                             // 0000008B3C20: BFA0FF3B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008B3C24: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008B3C28: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008B3C2C: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000008B3C30: BF8903F7
	.long 0xd71f0001                                           // 0000008B3C34: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008B3C38: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008B3C3C: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008B3C40: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000008B3C44: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000008B3C48: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008B3C4C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008B3C50: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008B3C54: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000008B3C58: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000008B3C5C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B3C60: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000008B3C64: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008B3C68: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008B3C6C: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008B3C70: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008B3C74: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 0000008B3C78: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 0000008B3C80: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000008B3C84: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 0000008B3C88: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000008B3C90: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000008B3C94: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000008B3C98: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000008B3CA0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008B3CA4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B3CA8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000008B3CAC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000008B3CB0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000008B3CB4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000008B3CB8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000008B3CBC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000008B3CC4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B3CC8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000008B3CCC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000008B3CD0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000008B3CD4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000008B3CDC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000008B3CE0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008B3CE8: 7D942080
	s_cbranch_execz 8                                          // 0000008B3CEC: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_lshlrev_b32_e32 v3, 2, v15                               // 0000008B3CF0: 30061E82
	s_waitcnt lgkmcnt(0)                                       // 0000008B3CF4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000008B3CF8: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008B3CFC: BF870002
	v_lshl_or_b32 v3, v14, 3, v3                               // 0000008B3D00: D6560003 040D070E
	ds_store_b32 v3, v1 offset:1024                            // 0000008B3D08: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008B3D10: 8C7E027E
	v_or_b32_e32 v1, s20, v0                                   // 0000008B3D14: 38020014
	s_waitcnt lgkmcnt(0)                                       // 0000008B3D18: BF89FC07
	v_mov_b32_e32 v2, s21                                      // 0000008B3D1C: 7E040215
	.long 0xd44c0002                                           // 0000008B3D20: D44C0002
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 0000008B3D24: 02020084
	s_barrier                                                  // 0000008B3D28: BFBD0000
	buffer_gl0_inv                                             // 0000008B3D2C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008B3D34: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008B3D38: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008B3D3C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000008B3D40: BE832002
	s_cbranch_execz 58                                         // 0000008B3D44: BFA5003A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x730>
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008B3D48: 3406049F
	v_lshlrev_b32_e32 v0, 3, v0                                // 0000008B3D4C: 30000083
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008B3D50: F4040080 F8000040
	v_mov_b32_e32 v9, s8                                       // 0000008B3D58: 7E120208
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008B3D5C: BF8700B3
	v_lshrrev_b32_e32 v5, 23, v3                               // 0000008B3D60: 320A0697
	ds_load_b64 v[3:4], v0 offset:1024                         // 0000008B3D64: D9D80400 03000000
	.long 0xd7006a00                                           // 0000008B3D6C: D7006A00
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000008B3D70: 02020B01
	v_add_co_ci_u32_e64 v5, null, 0, v2, vcc_lo                // 0000008B3D74: D5207C05 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B3D7C: BF870092
	v_and_b32_e32 v6, 0xfffffe00, v0                           // 0000008B3D80: 360C00FF FFFFFE00
	.long 0xd7016a00                                           // 0000008B3D88: D7016A00
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000008B3D8C: 02020D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008B3D90: BF870111
	v_sub_co_ci_u32_e64 v1, null, v2, v5, vcc_lo               // 0000008B3D94: D5217C01 01AA0B02
	.long 0xd7000007                                           // 0000008B3D9C: D7000007
	v_cndmask_b32_e32 v1, 0xffffff00, v0, vcc_lo               // 0000008B3DA0: 020200FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008B3DA8: BF870142
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[0:1]                     // 0000008B3DAC: 7CA800FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008B3DB4: BF89FC07
	v_dual_add_f32 v3, 0, v3 :: v_dual_mov_b32 v2, s9          // 0000008B3DB8: C9100680 03020009
	v_add_co_ci_u32_e64 v8, null, -1, v1, s0                   // 0000008B3DC0: D5207C08 000202C1
	v_dual_add_f32 v3, v3, v4 :: v_dual_cndmask_b32 v2, s3, v2 // 0000008B3DC8: C9120903 03020403
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008B3DD0: BF8701A2
	v_dual_cndmask_b32 v1, v8, v1 :: v_dual_cndmask_b32 v0, v7, v0// 0000008B3DD4: CA520308 01000107
	v_cndmask_b32_e32 v4, s2, v9, vcc_lo                       // 0000008B3DDC: 02081202
	v_bfe_u32 v7, v3, 16, 1                                    // 0000008B3DE0: D6100007 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008B3DE8: BF870193
	.long 0xd73c0000                                           // 0000008B3DEC: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008B3DF0: 02020081
	.long 0xd7006a04                                           // 0000008B3DF4: D7006A04
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000008B3DF8: 02020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008B3DFC: BF870211
	v_add_co_ci_u32_e64 v2, null, v2, v5, vcc_lo               // 0000008B3E00: D5207C02 01AA0B02
	v_add3_u32 v3, v3, v7, 0x7fff                              // 0000008B3E08: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008B3E14: BF870093
	.long 0xd7006a00                                           // 0000008B3E18: D7006A00
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 0000008B3E1C: 02020104
	v_add_co_ci_u32_e64 v1, null, v2, v1, vcc_lo               // 0000008B3E20: D5207C01 01AA0302
	global_store_d16_hi_b16 v[0:1], v3, off                    // 0000008B3E28: DC960000 007C0300
	s_endpgm                                                   // 0000008B3E30: BFB00000
		...

