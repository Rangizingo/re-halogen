0000000000561c00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000561C00: F4100100 F8000000
	v_dual_mov_b32 v28, 0 :: v_dual_and_b32 v1, 15, v0         // 000000561C08: CA240080 1C00008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000561C10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000561C14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000561C18: 7E0A0280
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000561C1C: 84828202
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000561C20: 30020282
	v_and_b32_e32 v2, 60, v2                                   // 000000561C24: 360404BC
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000561C28: 321C0086
	v_bfe_u32 v15, v0, 5, 1                                    // 000000561C2C: D610000F 02050B00
	.long 0x7f103880                                           // 000000561C34: 7F103880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v6, 0              // 000000561C38: CA100080 11060080
	s_waitcnt lgkmcnt(0)                                       // 000000561C40: BF89FC07
	s_clause 0x1                                               // 000000561C44: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000561C48: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000561C50: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 000000561C58: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000561C5C: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000561C60: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000561C64: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000561C68: 850E9F0B
	v_and_b32_e32 v16, 31, v0                                  // 000000561C6C: 3620009F
	s_add_u32 s14, s10, s14                                    // 000000561C70: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000561C74: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000561C78: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000561C7C: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000561C80: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000561C84: 868E810E
	s_add_u32 s20, s10, s20                                    // 000000561C88: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000561C8C: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000561C90: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000561C94: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 000000561C98: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 000000561CA0: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 000000561CA4: BF870002
	.long 0xd72c0002                                           // 000000561CA8: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000561CAC: 02020213
	s_lshr_b32 s19, s21, 31                                    // 000000561CB0: 85139F15
	.long 0xd72c000d                                           // 000000561CB4: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 000000561CB8: 02001F01
	s_add_i32 s21, s21, s19                                    // 000000561CBC: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 000000561CC0: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 000000561CC8: 860F8115
	s_add_u32 s0, s4, s16                                      // 000000561CCC: 80001004
	.long 0xd72c0012                                           // 000000561CD0: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 000000561CD4: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 000000561CD8: 82011105
	.long 0xd72c0014                                           // 000000561CDC: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 000000561CE0: 02001D07
	.long 0xd72c0015                                           // 000000561CE4: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 000000561CE8: 02020E12
	v_mov_b32_e32 v7, 0                                        // 000000561CEC: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000561CF0: BF870153
	v_add3_u32 v10, v20, v10, v13                              // 000000561CF4: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000561CFC: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000561D00: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000561D08: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000561D0C: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000561D14: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000561D20: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000561D28: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000561D2C: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000561D30: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000561D3C: 4A242112
	.long 0x7e103983                                           // 000000561D40: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000561D44: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000561D48: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000561D4C: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000561D54: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000561D58: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 000000561D64: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000561D68: 7C822712
	ds_store_b32 v3, v1                                        // 000000561D6C: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 000000561D74: BF89FC07
	s_barrier                                                  // 000000561D78: BFBD0000
	buffer_gl0_inv                                             // 000000561D7C: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000561D84: BE81206A
	s_cbranch_execz 21                                         // 000000561D88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000561D8C: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000561D90: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000561D94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000561D98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000561D9C: 3408069F
	.long 0xd7000001                                           // 000000561DA0: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000561DA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000561DA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000561DAC: D5207C02 00020514
	.long 0xd7000003                                           // 000000561DB4: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000561DB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000561DBC: D5207C04 0002090A
	s_clause 0x1                                               // 000000561DC4: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000561DC8: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000561DD0: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000561DD8: BF8907F7
	v_cvt_f32_f16_e32 v28, v1                                  // 000000561DDC: 7E381701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000561DE0: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000561DE4: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 000000561DEC: CA100080 18140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000561DF4: BE81206A
	s_cbranch_execz 460                                        // 000000561DF8: BFA501CC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x92c>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 000000561DFC: CA200080 180024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 000000561E04: CA220080 150C2485
	v_mov_b32_e32 v17, 0                                       // 000000561E0C: 7E220280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000561E10: BF870003
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 000000561E14: CA220080 16180284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000561E1C: CA220080 171A0281
	v_mov_b32_e32 v27, v28                                     // 000000561E24: 7E36031C
	s_mul_i32 s0, s11, 6                                       // 000000561E28: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000561E2C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000561E30: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000561E34: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000561E38: 9610860A
	s_mov_b32 s15, 0                                           // 000000561E3C: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000561E40: 848A810A
	s_branch 409                                               // 000000561E44: BFA00199 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x8ac>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000561E48: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000561E4C: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000561E54: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000561E58: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000561E60: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 000000561E64: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000561E68: 301A1A82
	ds_load_b32 v45, v13                                       // 000000561E6C: D8D80000 2D00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000561E74: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000561E78: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000561E7C: 361A1AFF 000003FC
	ds_load_b32 v46, v13                                       // 000000561E84: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000561E8C: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000561E90: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000561E94: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000561E9C: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561EA0: 360A0AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000561EA8: D8D80000 2F00000D
	ds_load_b32 v48, v5                                        // 000000561EB0: D8D80000 30000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000561EB8: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000561EC0: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000561EC4: 300A0A82
	ds_load_b32 v49, v5                                        // 000000561EC8: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000561ED0: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000561ED4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561ED8: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 000000561EE0: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000561EE8: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561EEC: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000561EF4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000561EFC: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000561F00: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F04: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000561F0C: D8D80000 34000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000561F14: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000561F1C: 300A0A82
	ds_load_b32 v53, v5                                        // 000000561F20: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000561F28: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000561F2C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F30: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000561F38: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000561F40: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F44: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000561F4C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000561F54: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000561F58: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F5C: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000561F64: D8D80000 38000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000561F6C: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000561F74: 300A0A82
	ds_load_b32 v57, v5                                        // 000000561F78: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000561F80: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000561F84: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F88: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000561F90: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000561F98: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561F9C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 000000561FA4: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000561FAC: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000561FB0: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000561FB4: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 000000561FBC: D8D80000 3C000005
	.long 0xd73c0005                                           // 000000561FC4: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000561FC8: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000561FCC: 4A1818FF 00000400
	.long 0xd7006a29                                           // 000000561FD4: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000561FD8: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000561FDC: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 000000561FE0: D5207C2A 01AA0C07
	s_clause 0x3                                               // 000000561FE8: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 000000561FEC: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 000000561FF4: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 000000561FFC: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 000000562004: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056200C: BF890CF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000562010: CC1A4005 1A025B05
	s_waitcnt lgkmcnt(14)                                      // 000000562018: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056201C: BF8700A1
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000562020: CC1A4005 1C165D06
	s_waitcnt lgkmcnt(13)                                      // 000000562028: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 00000056202C: CC1A4005 1C165F07
	s_waitcnt lgkmcnt(12)                                      // 000000562034: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562038: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 00000056203C: CC1A4005 1C166108
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000562044: BF8908B7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000562048: CC1A4005 1C16631D
	s_waitcnt lgkmcnt(10)                                      // 000000562050: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562054: BF8700A1
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000562058: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(9)                                       // 000000562060: BF89FC97
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000562064: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(8)                                       // 00000056206C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562070: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000562074: CC1A4005 1C166920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056207C: BF890477
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000562080: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(6)                                       // 000000562088: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056208C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000562090: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(5)                                       // 000000562098: BF89FC57
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000056209C: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(4)                                       // 0000005620A4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005620A8: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005620AC: CC1A4005 1C167124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005620B4: BF890037
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005620B8: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000005620C0: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000005620C4: 02001529
	s_waitcnt lgkmcnt(2)                                       // 0000005620C8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005620CC: BF8701C2
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005620D0: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 0000005620D8: D5207C26 01AA540B
	.long 0xd7006a2b                                           // 0000005620E0: D7006A2B
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 0000005620E4: 02000929
	s_waitcnt lgkmcnt(1)                                       // 0000005620E8: BF89FC17
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005620EC: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v44, null, s5, v42, vcc_lo             // 0000005620F4: D5207C2C 01AA5405
	s_waitcnt lgkmcnt(0)                                       // 0000005620FC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562100: BF870092
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000562104: CC1A4005 1C167928
	v_fmac_f32_e32 v21, v28, v5                                // 00000056210C: 562A0B1C
	s_clause 0x3                                               // 000000562110: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 000000562114: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 00000056211C: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000562124: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 00000056212C: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 000000562134: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000562138: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562140: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000562144: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 00000056214C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562154: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000562158: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000562160: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000562164: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056216C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000562170: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000562178: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562180: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000562184: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 00000056218C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000562190: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562198: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000056219C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000005621A4: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005621AC: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000005621B0: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000005621B8: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000005621BC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005621C4: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005621C8: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005621D0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005621D8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005621DC: CC1A4005 1C167928
	v_fmac_f32_e32 v24, v28, v5                                // 0000005621E4: 56300B1C
	s_clause 0x3                                               // 0000005621E8: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000005621EC: DC5E0000 057C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000005621F4: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000005621FC: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 000000562204: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 00000056220C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000562210: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562218: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 00000056221C: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000562224: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056222C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000562230: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000562238: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 00000056223C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562244: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000562248: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000562250: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562258: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000056225C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000562264: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000562268: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562270: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000562274: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000056227C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562284: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000562288: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000562290: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000562294: CC1A4005 1C167325
	.long 0xd7006a25                                           // 00000056229C: D7006A25
	v_cndmask_b32_e32 v0, v41, v16, vcc_lo                     // 0000005622A0: 02002129
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005622A4: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000005622A8: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s14, v42, vcc_lo            // 0000005622B0: D5207C26 01AA540E
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005622B8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005622C0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005622C4: CC1A4005 1C167928
	v_fmac_f32_e32 v23, v28, v5                                // 0000005622CC: 562E0B1C
	s_clause 0x3                                               // 0000005622D0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000005622D4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000005622DC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000005622E4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000005622EC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000005622F4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000005622F8: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562300: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000562304: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 00000056230C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562314: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000562318: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000562320: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000562324: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056232C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000562330: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000562338: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562340: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000562344: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 00000056234C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000562350: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562358: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000056235C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000562364: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056236C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000562370: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000562378: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000056237C: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000562384: D7006A25
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 000000562388: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056238C: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000562390: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s5, v44, vcc_lo             // 000000562398: D5207C26 01AA5805
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000005623A0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005623A8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000005623AC: CC1A4005 1C167928
	v_fmac_f32_e32 v22, v28, v5                                // 0000005623B4: 562C0B1C
	s_clause 0x3                                               // 0000005623B8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000005623BC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000005623C4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000005623CC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000005623D4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000005623DC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000005623E0: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005623E8: BF870121
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000005623EC: CC1A4005 1C165D06
	v_mov_b32_e32 v6, v2                                       // 0000005623F4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000005623F8: CC1A4005 1C165F07
	v_mov_b32_e32 v7, v3                                       // 000000562400: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000562404: BF870132
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000562408: CC1A4005 1C166108
	v_mov_b32_e32 v8, v4                                       // 000000562410: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000562414: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000562418: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562420: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000562424: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000056242C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562434: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000562438: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000562440: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000562444: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056244C: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000562450: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000562458: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000562460: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000562464: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 00000056246C: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000562470: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562478: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000056247C: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000562484: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056248C: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000562490: CC1A4005 1C167928
	v_fmac_f32_e32 v17, v28, v5                                // 000000562498: 56220B1C
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v28, v27           // 00000056249C: CA100101 051C011B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 0000005624A4: 917E0F7E
	s_cbranch_execz 31                                         // 0000005624A8: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x928>
	s_waitcnt vmcnt(0)                                         // 0000005624AC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005624B0: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 0000005624B4: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000005624BC: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000005624C4: 7E080308
	s_mov_b32 s17, exec_lo                                     // 0000005624C8: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 0000005624CC: 7C8C2712
	.long 0xd4c1007e                                           // 0000005624D0: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000005624D4: 02022712
	s_cbranch_execz 65115                                      // 0000005624D8: BFA5FE5B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	v_ashrrev_i32_e32 v2, 31, v26                              // 0000005624DC: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 0000005624E0: 3408329F
	.long 0xd7000001                                           // 0000005624E4: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000005624E8: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005624EC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005624F0: D5207C02 00020514
	.long 0xd7000003                                           // 0000005624F8: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000005624FC: 02023309
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000562500: D5207C04 0002090A
	s_clause 0x1                                               // 000000562508: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000056250C: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000562514: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000056251C: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000562520: 7E36170D
	s_branch 65096                                             // 000000562524: BFA0FE48 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000562528: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056252C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000562530: 8C7E017E
	.long 0xd71f0001                                           // 000000562534: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000562538: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000056253C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000562540: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000562544: BF8903F7
	v_xor_b32_e32 v7, 8, v1                                    // 000000562548: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 00000056254C: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000562550: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000562554: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000562558: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000056255C: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000562560: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000562564: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000562568: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000056256C: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000562570: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000562574: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000056257C: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000562580: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 000000562584: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 00000056258C: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 000000562594: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v17                                // 00000056259C: DACC0000 02001102
	ds_bpermute_b32 v8, v7, v3                                 // 0000005625A4: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000005625AC: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 0000005625B0: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 0000005625B8: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 0000005625BC: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 0000005625C0: BF89FC07
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v3, v8    // 0000005625C4: C9080511 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000005625CC: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000005625D4: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000005625DC: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 0000005625E0: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000005625E8: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000005625F0: 30181882
	s_waitcnt lgkmcnt(2)                                       // 0000005625F4: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 0000005625F8: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 000000562600: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000562608: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000562610: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 000000562614: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000562618: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 00000056261C: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000562620: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 000000562624: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 00000056262C: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000562630: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 000000562634: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 00000056263C: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 000000562644: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562648: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000056264C: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000562650: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 000000562654: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 00000056265C: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000562660: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 000000562664: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000562668: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000056266C: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 000000562670: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000562678: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000562680: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 000000562688: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000562690: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 000000562698: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056269C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000005626A0: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 0000005626A4: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000005626A8: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000005626AC: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000005626B4: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000005626B8: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000005626C0: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000005626C4: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000005626C8: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000005626CC: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 0000005626D0: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 0000005626D8: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000005626E0: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 0000005626E8: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 0000005626F0: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v16                                   // 0000005626F8: 7D942080
	s_cbranch_execz 21                                         // 0000005626FC: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb54>
	.long 0xd72c000b                                           // 000000562700: D72C000B
	v_cndmask_b32_e32 v0, v14, v168, vcc_lo                    // 000000562704: 0201510E
	s_waitcnt lgkmcnt(0)                                       // 000000562708: BF89FC07
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 00000056270C: C9080B01 01020D02
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 000000562714: C9081507 07041304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056271C: BF870093
	v_mad_u32_u24 v11, v15, 20, v11                            // 000000562720: D60B000B 042D290F
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_nc_u32 v8, 0x408, v11// 000000562728: C9201103 030816FF 00000408
	v_add_nc_u32_e32 v5, 0x400, v11                            // 000000562734: 4A0A16FF 00000400
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 00000056273C: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000562744: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 00000056274C: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000562754: 8C7E007E
	.long 0xd7050001                                           // 000000562758: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 00000056275C: 020200FF 000000CD
	.long 0x7f063880                                           // 000000562764: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000562768: BF89FC07
	s_barrier                                                  // 00000056276C: BFBD0000
	buffer_gl0_inv                                             // 000000562770: E0AC0000 00000000
	.long 0xd7390003                                           // 000000562778: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000056277C: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562780: BF870091
	.long 0xd7000001                                           // 000000562784: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000562788: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 00000056278C: D5207C02 00010003
	.long 0xd44c0000                                           // 000000562794: D44C0000
	v_cndmask_b32_e32 v1, 20, v0, vcc_lo                       // 000000562798: 02020094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000056279C: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005627A0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000005627A4: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000005627A8: BE812000
	s_cbranch_execz 45                                         // 0000005627AC: BFA5002D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xc64>
	.long 0xd7054000                                           // 0000005627B0: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 0000005627B4: 02010B03
	v_mul_u32_u24_e32 v3, 40, v3                               // 0000005627B8: 160606A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005627BC: BF870092
	.long 0xd7041000                                           // 0000005627C0: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000005627C4: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000005627C8: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005627D0: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000005627D4: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000005627DC: 4A0606FF 00000400
	ds_load_2addr_b32 v[6:7], v3 offset1:5                     // 0000005627E4: D8DC0500 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000005627EC: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005627F4: BF870091
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000005627F8: D6FE7C04 0412000D
	.long 0xd73c0003                                           // 000000562800: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000562804: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000562808: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 00000056280C: 06000C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000562810: BF870112
	.long 0xd7006a03                                           // 000000562814: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000562818: 02020608
	v_add_f32_e32 v5, v0, v7                                   // 00000056281C: 060A0F00
	.long 0xd73c0000                                           // 000000562820: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000562824: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000562828: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000562830: BF870193
	v_bfe_u32 v2, v5, 16, 1                                    // 000000562834: D6100002 02052105
	.long 0xd7006a00                                           // 00000056283C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000562840: 02020103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000562844: BF870191
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000562848: D5207C01 01AA0304
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000562850: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000056285C: DC960000 007C0200
	s_endpgm                                                   // 000000562864: BFB00000
		...

