0000000000731a00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000731A00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000731A04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000731A0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 000000731A14: BE830080
	v_lshrrev_b32_e32 v14, 5, v0                               // 000000731A18: 321C0085
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 000000731A1C: CA240080 060E009F
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v5, 0              // 000000731A24: CA100080 10040080
	.long 0x7e1a3880                                           // 000000731A2C: 7E1A3880
	v_mov_b32_e32 v8, 0                                        // 000000731A30: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 000000731A34: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000731A38: 86009F0B
	.long 0xd451000e                                           // 000000731A3C: D451000E
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000731A40: 02001802
	s_lshr_b32 s0, s0, 28                                      // 000000731A44: 85009C00
	v_dual_mov_b32 v1, s4 :: v_dual_mov_b32 v2, s5             // 000000731A48: CA100004 01020005
	s_add_u32 s0, s10, s0                                      // 000000731A50: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000731A54: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000731A58: BF870499
	s_ashr_i64 s[0:1], s[0:1], 4                               // 000000731A5C: 86808400
	s_add_u32 s15, s10, s0                                     // 000000731A60: 800F000A
	s_addc_u32 s1, s11, s1                                     // 000000731A64: 8201010B
	s_add_u32 s15, s15, 15                                     // 000000731A68: 800F8F0F
	s_addc_u32 s1, s1, 0                                       // 000000731A6C: 82018001
	s_and_b32 s15, s15, -16                                    // 000000731A70: 8B0FD00F
	s_and_b32 s14, s14, exec_lo                                // 000000731A74: 8B0E7E0E
	s_cselect_b32 s14, s2, 0                                   // 000000731A78: 980E8002
	s_add_i32 s16, s0, 7                                       // 000000731A7C: 81108700
	v_mad_u64_u32 v[10:11], null, s14, s15, v[1:2]             // 000000731A80: D6FE7C0A 04041E0E
	s_ashr_i32 s17, s16, 31                                    // 000000731A88: 86119F10
	s_mul_i32 s14, s14, s1                                     // 000000731A8C: 960E010E
	s_lshr_b32 s17, s17, 29                                    // 000000731A90: 85119D11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000731A94: BF870499
	s_add_i32 s16, s16, s17                                    // 000000731A98: 81101110
	s_ashr_i32 s4, s16, 3                                      // 000000731A9C: 86048310
	v_add_nc_u32_e32 v11, s14, v11                             // 000000731AA0: 4A16160E
	.long 0xd72c0003                                           // 000000731AA4: D72C0003
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 000000731AA8: 02021C04
	.long 0xd7006a13                                           // 000000731AAC: D7006A13
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 000000731AB0: 0200150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731AB4: BF870191
	v_add_co_ci_u32_e64 v20, null, s11, v11, vcc_lo            // 000000731AB8: D5207C14 01AA160B
	v_add_nc_u32_e32 v1, s4, v3                                // 000000731AC0: 4A020604
	v_add_nc_u32_e32 v17, v3, v15                              // 000000731AC4: 4A221F03
	v_mov_b32_e32 v7, 0                                        // 000000731AC8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731ACC: BF870193
	v_min_i32_e32 v18, s0, v1                                  // 000000731AD0: 22240200
	v_lshlrev_b32_e32 v12, 4, v17                              // 000000731AD4: 30182284
	s_delay_alu instid0(VALU_DEP_2)                            // 000000731AD8: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 000000731ADC: 7C822511
	s_and_saveexec_b32 s1, vcc_lo                              // 000000731AE0: BE81206A
	s_cbranch_execz 19                                         // 000000731AE4: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x134>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000731AE8: 30022284
	v_and_b32_e32 v3, -2, v17                                  // 000000731AEC: 360622C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731AF0: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000731AF4: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000731AF8: 3408069F
	.long 0xd7000001                                           // 000000731AFC: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000731B00: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731B04: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000731B08: D5207C02 0002050B
	.long 0xd7000003                                           // 000000731B10: D7000003
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000731B14: 02020713
	v_add_co_ci_u32_e64 v4, null, v20, v4, s0                  // 000000731B18: D5207C04 00020914
	s_clause 0x1                                               // 000000731B20: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 000000731B24: DC5E0000 057C0001
	global_load_d16_b16 v13, v[3:4], off                       // 000000731B2C: DC820000 0D7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000731B34: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000731B38: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000731B40: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 000000731B48: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000731B50: BE81206A
	s_cbranch_execz 526                                        // 000000731B54: BFA5020E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x990>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v27, 0x200, v12 // 000000731B58: CA200080 1A1A18FF 00000200
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v24, 0             // 000000731B64: CA100080 15180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v22, 0             // 000000731B6C: CA100080 19160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v16, 0             // 000000731B74: CA100080 17100080
	s_mul_i32 s0, s11, 6                                       // 000000731B7C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000731B80: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000731B84: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000731B88: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000731B8C: 9610860A
	s_mov_b32 s15, 0                                           // 000000731B90: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000731B94: 848A810A
	s_branch 476                                               // 000000731B98: BFA001DC <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x90c>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000731B9C: 8C7E117E
	v_bfe_i32 v28, v5, 0, 8                                    // 000000731BA0: D611001C 02210105
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000731BA8: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 000000731BAC: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000731BB4: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731BB8: BF870092
	v_cvt_f32_i32_e32 v28, v28                                 // 000000731BBC: 7E380B1C
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 000000731BC0: CC20001C 8A02390D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731BC8: BF870091
	v_bfe_u32 v29, v28, 16, 1                                  // 000000731BCC: D610001D 0205211C
	v_add3_u32 v28, v28, v29, 0x7fff                           // 000000731BD4: D655001C 03FE3B1C 00007FFF
	.long 0x7f3a3880                                           // 000000731BE0: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731BE4: BF8700A2
	.long 0x7e3a399c                                           // 000000731BE8: 7E3A399C
	v_bfe_i32 v28, v5, 8, 8                                    // 000000731BEC: D611001C 02211105
	v_cvt_f32_i32_e32 v28, v28                                 // 000000731BF4: 7E380B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731BF8: BF870091
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 000000731BFC: CC20001C 8A02390D
	v_bfe_u32 v30, v28, 16, 1                                  // 000000731C04: D610001E 0205211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000731C0C: BF8701B1
	v_add3_u32 v28, v28, v30, 0x7fff                           // 000000731C10: D655001C 03FE3D1C 00007FFF
	v_bfe_i32 v30, v5, 16, 8                                   // 000000731C1C: D611001E 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000731C24: 340A0A98
	v_and_or_b32 v36, 0xffff0000, v28, v29                     // 000000731C28: D6570024 047638FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731C34: BF870193
	v_cvt_f32_i32_e32 v30, v30                                 // 000000731C38: 7E3C0B1E
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731C3C: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731C40: BF870112
	v_fma_mix_f32 v30, v13, v30, neg(0) op_sel_hi:[1,0,0]      // 000000731C44: CC20001E 8A023D0D
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731C4C: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731C54: BF870092
	v_bfe_u32 v31, v30, 16, 1                                  // 000000731C58: D610001F 0205211E
	v_add3_u32 v30, v30, v31, 0x7fff                           // 000000731C60: D655001E 03FE3F1E 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731C6C: BF870113
	v_bfe_u32 v31, v5, 16, 1                                   // 000000731C70: D610001F 02052105
	.long 0x7e3c399e                                           // 000000731C78: 7E3C399E
	.long 0x7f3c399d                                           // 000000731C7C: 7F3C399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731C80: BF870093
	v_add3_u32 v5, v5, v31, 0x7fff                             // 000000731C84: D6550005 03FE3F05 00007FFF
	v_and_or_b32 v37, 0xffff0000, v5, v30                      // 000000731C90: D6570025 047A0AFF FFFF0000
	v_bfe_i32 v5, v6, 0, 8                                     // 000000731C9C: D6110005 02210106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731CA4: BF870091
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731CA8: 7E0A0B05
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731CAC: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731CB4: BF870091
	v_bfe_u32 v28, v5, 16, 1                                   // 000000731CB8: D610001C 02052105
	v_add3_u32 v5, v5, v28, 0x7fff                             // 000000731CC0: D6550005 03FE3905 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731CCC: BF8700A1
	.long 0x7e3a3985                                           // 000000731CD0: 7E3A3985
	v_bfe_i32 v5, v6, 8, 8                                     // 000000731CD4: D6110005 02211106
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731CDC: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731CE0: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731CE4: CC200005 8A020B0D
	v_bfe_u32 v28, v5, 16, 1                                   // 000000731CEC: D610001C 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000731CF4: BF8701B1
	v_add3_u32 v5, v5, v28, 0x7fff                             // 000000731CF8: D6550005 03FE3905 00007FFF
	v_bfe_i32 v28, v6, 16, 8                                   // 000000731D04: D611001C 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000731D0C: 340C0C98
	v_and_or_b32 v38, 0xffff0000, v5, v29                      // 000000731D10: D6570026 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731D1C: BF870193
	v_cvt_f32_i32_e32 v28, v28                                 // 000000731D20: 7E380B1C
	v_cvt_f32_i32_e32 v6, v6                                   // 000000731D24: 7E0C0B06
	v_bfe_i32 v5, v7, 0, 8                                     // 000000731D28: D6110005 02210107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731D30: BF870193
	v_fma_mix_f32 v28, v13, v28, neg(0) op_sel_hi:[1,0,0]      // 000000731D34: CC20001C 8A02390D
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000731D3C: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731D44: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731D48: 7E0A0B05
	v_bfe_u32 v30, v28, 16, 1                                  // 000000731D4C: D610001E 0205211C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731D54: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731D58: CC200005 8A020B0D
	v_add3_u32 v28, v28, v30, 0x7fff                           // 000000731D60: D655001C 03FE3D1C 00007FFF
	v_bfe_u32 v30, v6, 16, 1                                   // 000000731D6C: D610001E 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000731D74: BF8701A2
	.long 0x7e38399c                                           // 000000731D78: 7E38399C
	.long 0x7f38399d                                           // 000000731D7C: 7F38399D
	v_add3_u32 v6, v6, v30, 0x7fff                             // 000000731D80: D6550006 03FE3D06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731D8C: BF8700A1
	v_and_or_b32 v39, 0xffff0000, v6, v28                      // 000000731D90: D6570027 04720CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000731D9C: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000731DA4: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731DB0: BF8700A1
	.long 0x7e3a3985                                           // 000000731DB4: 7E3A3985
	v_bfe_i32 v5, v7, 8, 8                                     // 000000731DB8: D6110005 02211107
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731DC0: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731DC4: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731DC8: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000731DD0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000731DD8: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000731DDC: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v7, 16, 8                                    // 000000731DE8: D6110006 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 000000731DF0: 340E0E98
	v_and_or_b32 v40, 0xffff0000, v5, v29                      // 000000731DF4: D6570028 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731E00: BF870193
	v_cvt_f32_i32_e32 v6, v6                                   // 000000731E04: 7E0C0B06
	v_cvt_f32_i32_e32 v7, v7                                   // 000000731E08: 7E0E0B07
	v_bfe_i32 v5, v8, 0, 8                                     // 000000731E0C: D6110005 02210108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731E14: BF870193
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000731E18: CC200006 8A020D0D
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000731E20: CC200007 8A020F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000731E28: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731E2C: 7E0A0B05
	v_bfe_u32 v28, v6, 16, 1                                   // 000000731E30: D610001C 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731E38: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731E3C: CC200005 8A020B0D
	v_add3_u32 v6, v6, v28, 0x7fff                             // 000000731E44: D6550006 03FE3906 00007FFF
	v_bfe_u32 v28, v7, 16, 1                                   // 000000731E50: D610001C 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000731E58: BF8701A2
	.long 0x7e0c3986                                           // 000000731E5C: 7E0C3986
	.long 0x7f0c399d                                           // 000000731E60: 7F0C399D
	v_add3_u32 v7, v7, v28, 0x7fff                             // 000000731E64: D6550007 03FE3907 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731E70: BF8700A1
	v_and_or_b32 v41, 0xffff0000, v7, v6                       // 000000731E74: D6570029 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 000000731E80: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000731E88: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731E94: BF8700A1
	.long 0x7e3a3985                                           // 000000731E98: 7E3A3985
	v_bfe_i32 v5, v8, 8, 8                                     // 000000731E9C: D6110005 02211108
	v_cvt_f32_i32_e32 v5, v5                                   // 000000731EA4: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731EA8: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000731EAC: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 000000731EB4: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731EBC: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000731EC0: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v8, 16, 8                                    // 000000731ECC: D6110006 02212108
	v_and_or_b32 v42, 0xffff0000, v5, v29                      // 000000731ED4: D657002A 04760AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731EE0: BF870092
	v_cvt_f32_i32_e32 v6, v6                                   // 000000731EE4: 7E0C0B06
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000731EE8: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731EF0: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000731EF4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000731EFC: D6550006 03FE0F06 00007FFF
	v_ashrrev_i32_e32 v7, 24, v8                               // 000000731F08: 340E1098
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000731F0C: BF870112
	.long 0x7e0c3986                                           // 000000731F10: 7E0C3986
	v_cvt_f32_i32_e32 v7, v7                                   // 000000731F14: 7E0E0B07
	.long 0x7f0c399d                                           // 000000731F18: 7F0C399D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000731F1C: BF870122
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 000000731F20: CC200007 8A020F0D
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000731F28: 341A189F
	v_bfe_u32 v8, v7, 16, 1                                    // 000000731F2C: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731F34: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 000000731F38: D6550007 03FE1107 00007FFF
	v_and_or_b32 v43, 0xffff0000, v7, v6                       // 000000731F44: D657002B 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000731F50: BF8701C4
	.long 0xd73c0005                                           // 000000731F54: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000731F58: 02021881
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000731F5C: 4A1818FF 00000200
	s_waitcnt vmcnt(0)                                         // 000000731F64: BF8903F7
	.long 0x7e1a3909                                           // 000000731F68: 7E1A3909
	.long 0xd7006a20                                           // 000000731F6C: D7006A20
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000731F70: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000731F74: BF870001
	v_add_co_ci_u32_e64 v33, null, s7, v6, vcc_lo              // 000000731F78: D5207C21 01AA0C07
	s_clause 0x1                                               // 000000731F80: BF850001
	global_load_b128 v[5:8], v[32:33], off                     // 000000731F84: DC5E0000 057C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000731F8C: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 000000731F94: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 000000731F98: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000731FA0: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 000000731FA4: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 000000731FAC: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000731FB4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 000000731FB8: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 000000731FC0: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000731FC4: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 000000731FCC: D7006A1C
	v_cndmask_b32_e32 v0, v32, v10, vcc_lo                     // 000000731FD0: 02001520
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000731FD4: BF8701B2
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000731FD8: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s11, v33, vcc_lo            // 000000731FE0: D5207C1D 01AA420B
	.long 0xd7006a22                                           // 000000731FE8: D7006A22
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 000000731FEC: 02000920
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000731FF0: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v35, null, s5, v33, vcc_lo             // 000000731FF8: D5207C23 01AA4205
	.long 0xd7006a20                                           // 000000732000: D7006A20
	v_cndmask_b32_e32 v0, v32, v16, vcc_lo                     // 000000732004: 02002120
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000732008: BF870123
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000073200C: CC1A4005 1C16571F
	v_add_co_ci_u32_e64 v33, null, s14, v33, vcc_lo            // 000000732014: D5207C21 01AA420E
	v_add_f32_e32 v21, v21, v5                                 // 00000073201C: 062A0B15
	s_clause 0x1                                               // 000000732020: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 000000732024: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 00000073202C: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000732034: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 000000732038: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732040: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 000000732044: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 00000073204C: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000732054: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 000000732058: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 000000732060: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000732064: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073206C: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000732070: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000732078: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732080: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000732084: CC1A4005 1C16571F
	v_add_f32_e32 v26, v26, v5                                 // 00000073208C: 06340B1A
	s_clause 0x1                                               // 000000732090: BF850001
	global_load_b128 v[5:8], v[34:35], off                     // 000000732094: DC5E0000 057C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 00000073209C: DC5E0010 1C7C0022
	.long 0xd7006a22                                           // 0000007320A4: D7006A22
	v_cndmask_b32_e32 v0, v34, v4, vcc_lo                      // 0000007320A8: 02000922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007320AC: BF8700B1
	v_add_co_ci_u32_e64 v35, null, s5, v35, vcc_lo             // 0000007320B0: D5207C23 01AA4605
	s_waitcnt vmcnt(1)                                         // 0000007320B8: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 0000007320BC: CC1A4005 1A024905
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 0000007320C4: CC1A4005 1C164B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007320CC: BF870091
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 0000007320D0: CC1A4005 1C164D07
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 0000007320D8: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 0000007320E0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007320E4: BF870091
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000007320E8: CC1A4005 1C16511C
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000007320F0: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007320F8: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000007320FC: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000732104: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000073210C: BF870001
	v_add_f32_e32 v25, v25, v5                                 // 000000732110: 06320B19
	s_clause 0x1                                               // 000000732114: BF850001
	global_load_b128 v[5:8], v[32:33], off                     // 000000732118: DC5E0000 057C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000732120: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 000000732128: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000073212C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732134: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 000000732138: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 000000732140: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000732148: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000073214C: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 000000732154: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000732158: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732160: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000732164: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000073216C: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732174: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000732178: CC1A4005 1C16571F
	v_add_f32_e32 v24, v24, v5                                 // 000000732180: 06300B18
	s_clause 0x1                                               // 000000732184: BF850001
	global_load_b128 v[5:8], v[34:35], off                     // 000000732188: DC5E0000 057C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 000000732190: DC5E0010 1C7C0022
	s_waitcnt vmcnt(1)                                         // 000000732198: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000073219C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007321A4: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 0000007321A8: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 0000007321B0: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007321B8: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 0000007321BC: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 0000007321C4: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000007321C8: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 0000007321D0: D7006A1C
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 0000007321D4: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007321D8: BF870122
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000007321DC: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s5, v33, vcc_lo             // 0000007321E4: D5207C1D 01AA4205
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000007321EC: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007321F4: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000007321F8: CC1A4005 1C16571F
	v_add_f32_e32 v23, v23, v5                                 // 000000732200: 062E0B17
	s_clause 0x1                                               // 000000732204: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 000000732208: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000732210: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000732218: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000073221C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732224: BF870091
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 000000732228: CC1A4005 1C164B06
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 000000732230: CC1A4005 1C164D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000732238: BF8700A1
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 00000073223C: CC1A4005 1C164F08
	s_waitcnt vmcnt(0)                                         // 000000732244: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 000000732248: CC1A4005 1C16511C
	.long 0xd7006a1c                                           // 000000732250: D7006A1C
	v_cndmask_b32_e32 v0, v34, v4, vcc_lo                      // 000000732254: 02000922
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000732258: BF870122
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 00000073225C: CC1A4005 1C16531D
	v_add_co_ci_u32_e64 v29, null, s5, v35, vcc_lo             // 000000732264: D5207C1D 01AA4605
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000073226C: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000732274: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000732278: CC1A4005 1C16571F
	v_add_f32_e32 v22, v22, v5                                 // 000000732280: 062C0B16
	s_clause 0x1                                               // 000000732284: BF850001
	global_load_b128 v[5:8], v[28:29], off                     // 000000732288: DC5E0000 057C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000732290: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000732298: BF8907F7
	v_dot2_f32_bf16 v5, v5, v36, 0                             // 00000073229C: CC1A4005 1A024905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007322A4: BF870121
	v_dot2_f32_bf16 v5, v6, v37, v5                            // 0000007322A8: CC1A4005 1C164B06
	v_mov_b32_e32 v6, v2                                       // 0000007322B0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v38, v5                            // 0000007322B4: CC1A4005 1C164D07
	v_mov_b32_e32 v7, v3                                       // 0000007322BC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007322C0: BF870132
	v_dot2_f32_bf16 v5, v8, v39, v5                            // 0000007322C4: CC1A4005 1C164F08
	v_mov_b32_e32 v8, v4                                       // 0000007322CC: 7E100304
	s_waitcnt vmcnt(0)                                         // 0000007322D0: BF8903F7
	v_dot2_f32_bf16 v5, v28, v40, v5                           // 0000007322D4: CC1A4005 1C16511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007322DC: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000007322E0: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000007322E8: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007322F0: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 0000007322F4: CC1A4005 1C16571F
	v_dual_add_f32 v16, v16, v5 :: v_dual_mov_b32 v5, v1       // 0000007322FC: C9100B10 10040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000732304: 917E0F7E
	s_cbranch_execz 32                                         // 000000732308: BFA50020 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x98c>
	s_waitcnt vmcnt(1)                                         // 00000073230C: BF8907F7
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v17, 32, v17    // 000000732310: CA200106 021022A0
	s_waitcnt vmcnt(0)                                         // 000000732318: BF8903F7
	.long 0x7e12390d                                           // 00000073231C: 7E12390D
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 000000732320: CA100105 01040108
	v_mov_b32_e32 v3, v7                                       // 000000732328: 7E060307
	s_mov_b32 s17, exec_lo                                     // 00000073232C: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 000000732330: 7C8C2511
	.long 0xd4c1007e                                           // 000000732334: D4C1007E
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000732338: 02022511
	s_cbranch_execz 65047                                      // 00000073233C: BFA5FE17 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x19c>
	v_and_b32_e32 v3, -2, v17                                  // 000000732340: 360622C2
	v_ashrrev_i32_e32 v2, 31, v27                              // 000000732344: 3404369F
	.long 0xd7000001                                           // 000000732348: D7000001
	v_cndmask_b32_e32 v1, v10, v27, vcc_lo                     // 00000073234C: 0202370A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000732350: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000732354: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000732358: D5207C02 0002050B
	.long 0xd700001c                                           // 000000732360: D700001C
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 000000732364: 02020713
	s_delay_alu instid0(VALU_DEP_1)                            // 000000732368: BF870001
	v_add_co_ci_u32_e64 v29, null, v20, v4, s0                 // 00000073236C: D5207C1D 00020914
	s_clause 0x1                                               // 000000732374: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000732378: DC5E0000 017C0001
	global_load_d16_b16 v9, v[28:29], off                      // 000000732380: DC820000 097C001C
	s_branch 65028                                             // 000000732388: BFA0FE04 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0x19c>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000073238C: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000732390: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000732394: 8C7E017E
	.long 0xd71f0001                                           // 000000732398: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000073239C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000007323A0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007323A4: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000007323A8: 3A120288
	v_xor_b32_e32 v18, 4, v1                                   // 0000007323AC: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007323B0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007323B4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007323B8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000007323BC: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000007323C0: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007323C4: 7C9824A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007323C8: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007323CC: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007323D0: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000007323D4: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000007323DC: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000007323E0: 06060715
	s_waitcnt vmcnt(1)                                         // 0000007323E4: BF8907F7
	ds_bpermute_b32 v5, v2, v25                                // 0000007323E8: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 0000007323F0: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 0000007323F8: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 000000732400: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 000000732408: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v16                                // 000000732410: DACC0000 02001002
	ds_bpermute_b32 v10, v9, v3                                // 000000732418: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 000000732420: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 000000732424: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 00000073242C: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 000000732430: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 000000732438: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 00000073243C: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 000000732440: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 000000732448: BF89FC27
	v_add_f32_e32 v2, v16, v2                                  // 00000073244C: 06040510
	ds_bpermute_b32 v11, v9, v4                                // 000000732450: DACC0000 0B000409
	ds_bpermute_b32 v16, v9, v7                                // 000000732458: DACC0000 10000709
	s_waitcnt vmcnt(0)                                         // 000000732460: BF8903F7
	ds_bpermute_b32 v13, v9, v6                                // 000000732464: DACC0000 0D000609
	ds_bpermute_b32 v17, v9, v8                                // 00000073246C: DACC0000 11000809
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000732474: 02242501
	s_waitcnt lgkmcnt(5)                                       // 000000732478: BF89FC57
	v_add_f32_e32 v3, v3, v10                                  // 00000073247C: 06061503
	s_waitcnt lgkmcnt(4)                                       // 000000732480: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 000000732484: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 000000732488: DACC0000 09000209
	s_waitcnt lgkmcnt(3)                                       // 000000732490: BF89FC37
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v7, v7, v16   // 000000732494: C9081704 04062107
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000073249C: 30242482
	s_waitcnt lgkmcnt(1)                                       // 0000007324A0: BF89FC17
	v_add_f32_e32 v8, v8, v17                                  // 0000007324A4: 06102308
	s_waitcnt lgkmcnt(0)                                       // 0000007324A8: BF89FC07
	v_add_f32_e32 v2, v2, v9                                   // 0000007324AC: 06041302
	ds_bpermute_b32 v9, v18, v3                                // 0000007324B0: DACC0000 09000312
	s_waitcnt lgkmcnt(0)                                       // 0000007324B8: BF89FC07
	v_add_f32_e32 v3, v3, v9                                   // 0000007324BC: 06061303
	ds_bpermute_b32 v11, v18, v5                               // 0000007324C0: DACC0000 0B000512
	v_add_f32_e32 v6, v6, v13                                  // 0000007324C8: 060C1B06
	ds_bpermute_b32 v13, v18, v7                               // 0000007324CC: DACC0000 0D000712
	ds_bpermute_b32 v17, v18, v2                               // 0000007324D4: DACC0000 11000212
	ds_bpermute_b32 v10, v18, v4                               // 0000007324DC: DACC0000 0A000412
	ds_bpermute_b32 v16, v18, v8                               // 0000007324E4: DACC0000 10000812
	s_waitcnt lgkmcnt(4)                                       // 0000007324EC: BF89FC47
	v_add_f32_e32 v5, v5, v11                                  // 0000007324F0: 060A1705
	ds_bpermute_b32 v12, v18, v6                               // 0000007324F4: DACC0000 0C000612
	v_xor_b32_e32 v18, 2, v1                                   // 0000007324FC: 3A240282
	s_waitcnt lgkmcnt(4)                                       // 000000732500: BF89FC47
	v_add_f32_e32 v7, v7, v13                                  // 000000732504: 060E1B07
	s_waitcnt lgkmcnt(3)                                       // 000000732508: BF89FC37
	v_add_f32_e32 v9, v2, v17                                  // 00000073250C: 06122302
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000732510: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000732514: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000732518: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000073251C: 30242482
	ds_bpermute_b32 v2, v18, v3                                // 000000732520: DACC0000 02000312
	s_waitcnt lgkmcnt(1)                                       // 000000732528: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 00000073252C: 060C1906
	ds_bpermute_b32 v13, v18, v7                               // 000000732530: DACC0000 0D000712
	v_add_f32_e32 v4, v4, v10                                  // 000000732538: 06081504
	ds_bpermute_b32 v17, v18, v9                               // 00000073253C: DACC0000 11000912
	v_add_f32_e32 v8, v8, v16                                  // 000000732544: 06102108
	ds_bpermute_b32 v11, v18, v5                               // 000000732548: DACC0000 0B000512
	ds_bpermute_b32 v12, v18, v6                               // 000000732550: DACC0000 0C000612
	ds_bpermute_b32 v10, v18, v4                               // 000000732558: DACC0000 0A000412
	ds_bpermute_b32 v16, v18, v8                               // 000000732560: DACC0000 10000812
	v_xor_b32_e32 v18, 1, v1                                   // 000000732568: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000073256C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000732570: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 000000732574: 02022501
	s_waitcnt lgkmcnt(6)                                       // 000000732578: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 00000073257C: C9220503 01120282
	s_waitcnt lgkmcnt(3)                                       // 000000732584: BF89FC37
	v_add_f32_e32 v2, v5, v11                                  // 000000732588: 06041705
	s_waitcnt lgkmcnt(2)                                       // 00000073258C: BF89FC27
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v3, v7, v13   // 000000732590: C9081906 06021B07
	s_waitcnt lgkmcnt(1)                                       // 000000732598: BF89FC17
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v9, v17   // 00000073259C: C9081504 04042309
	s_waitcnt lgkmcnt(0)                                       // 0000007325A4: BF89FC07
	v_add_f32_e32 v12, v8, v16                                 // 0000007325A8: 06182108
	ds_bpermute_b32 v7, v18, v1                                // 0000007325AC: DACC0000 07000112
	ds_bpermute_b32 v8, v18, v2                                // 0000007325B4: DACC0000 08000212
	ds_bpermute_b32 v10, v18, v4                               // 0000007325BC: DACC0000 0A000412
	ds_bpermute_b32 v13, v18, v6                               // 0000007325C4: DACC0000 0D000612
	ds_bpermute_b32 v9, v18, v3                                // 0000007325CC: DACC0000 09000312
	ds_bpermute_b32 v16, v18, v12                              // 0000007325D4: DACC0000 10000C12
	ds_bpermute_b32 v11, v18, v5                               // 0000007325DC: DACC0000 0B000512
	v_cmpx_eq_u32_e32 0, v15                                   // 0000007325E4: 7D941E80
	s_cbranch_execz 18                                         // 0000007325E8: BFA50012 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0xc34>
	s_waitcnt lgkmcnt(1)                                       // 0000007325EC: BF89FC17
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v1, v1, v7  // 0000007325F0: C908210C 0C000F01
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v3, v3, v9    // 0000007325F8: C9081504 04021303
	v_mul_u32_u24_e32 v7, 28, v14                              // 000000732600: 160E1C9C
	s_waitcnt lgkmcnt(0)                                       // 000000732604: BF89FC07
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v5, v5, v11   // 000000732608: C9081B06 06041705
	v_add_f32_e32 v2, v2, v8                                   // 000000732610: 06041102
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 000000732614: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 00000073261C: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v12 offset0:4 offset1:5         // 000000732624: D8380504 000C0307
	ds_store_b32 v7, v5 offset:24                              // 00000073262C: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 000000732634: 8C7E007E
	.long 0xd4510000                                           // 000000732638: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000073263C: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 000000732640: 7C980087
	s_waitcnt lgkmcnt(0)                                       // 000000732644: BF89FC07
	s_barrier                                                  // 000000732648: BFBD0000
	buffer_gl0_inv                                             // 00000073264C: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000732654: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000732658: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000073265C: BE812000
	s_cbranch_execz 43                                         // 000000732660: BFA5002B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi8ELb1EEEvPKhPKtPvll+0xd10>
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000732664: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000732668: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 00000073266C: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 000000732674: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 00000073267C: D8DC231C 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000732684: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000732688: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000073268C: BF870131
	v_add_f32_e32 v9, v1, v2                                   // 000000732690: 06120501
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000732694: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 00000073269C: BF89FC17
	v_add_f32_e32 v3, v9, v3                                   // 0000007326A0: 06060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007326A4: BF870191
	v_add_f32_e32 v4, v3, v4                                   // 0000007326A8: 06080903
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000007326AC: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 0000007326B4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007326B8: BF8700C2
	v_add_f32_e32 v0, v4, v5                                   // 0000007326BC: 06000B04
	ds_load_2addr_b32 v[7:8], v7 offset0:42 offset1:49         // 0000007326C0: D8DC312A 07000007
	v_add_f32_e32 v3, v0, v6                                   // 0000007326C8: 06060D00
	.long 0xd73c0000                                           // 0000007326CC: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000007326D0: 02020282
	.long 0xd7006a00                                           // 0000007326D4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007326D8: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007326DC: BF870111
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007326E0: D5207C01 01AA0209
	.long 0xd7006a00                                           // 0000007326E8: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007326EC: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007326F0: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007326F4: D5207C01 01AA0201
	s_waitcnt lgkmcnt(0)                                       // 0000007326FC: BF89FC07
	v_add_f32_e32 v2, v3, v7                                   // 000000732700: 06040F03
	v_add_f32_e32 v2, v2, v8                                   // 000000732704: 06041102
	global_store_b32 v[0:1], v2, off                           // 000000732708: DC6A0000 007C0200
	s_endpgm                                                   // 000000732710: BFB00000
		...

