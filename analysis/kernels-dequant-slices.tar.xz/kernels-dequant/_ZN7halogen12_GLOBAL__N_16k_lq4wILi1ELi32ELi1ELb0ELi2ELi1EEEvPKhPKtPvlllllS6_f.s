00000000007f8100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007F8100: F4100100 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000007F8108: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007F810C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007F8110: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000007F8114: 32060085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000007F8118: 84808302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F811C: 30020282
	v_dual_mov_b32 v17, s1 :: v_dual_and_b32 v2, 60, v2        // 0000007F8120: CA240001 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F8128: BF870003
	v_or_b32_e32 v16, s0, v3                                   // 0000007F812C: 38200600
	.long 0x7f063880                                           // 0000007F8130: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000007F8134: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007F8138: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000007F813C: BF89FC07
	s_clause 0x1                                               // 0000007F8140: BF850001
	global_load_b32 v1, v1, s[4:5]                             // 0000007F8144: DC520000 01040001
	global_load_b32 v2, v2, s[4:5]                             // 0000007F814C: DC520000 02040002
	.long 0xd4540000                                           // 0000007F8154: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 0000007F8158: 0202200C
	s_add_u32 s20, s4, s16                                     // 0000007F815C: 80141004
	s_addc_u32 s21, s5, s17                                    // 0000007F8160: 82151105
	s_ashr_i32 s2, s11, 31                                     // 0000007F8164: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F8168: BF870159
	s_lshr_b32 s2, s2, 27                                      // 0000007F816C: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 0000007F8170: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 0000007F8178: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 0000007F8180: 8002020A
	s_addc_u32 s3, s11, 0                                      // 0000007F8184: 8203800B
	.long 0xd72c0004                                           // 0000007F8188: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 0000007F818C: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 0000007F8190: D6FE7C0C 02021012
	s_lshr_b64 s[12:13], s[2:3], 5                             // 0000007F8198: 858C8502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007F819C: BF870009
	s_cmpk_lt_i32 s12, 0x101                                   // 0000007F81A0: B38C0101
	.long 0xd4440002                                           // 0000007F81A4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000007F81A8: 02022E0C
	s_cselect_b32 s1, -1, 0                                    // 0000007F81AC: 980180C1
	s_cmpk_gt_i32 s12, 0x100                                   // 0000007F81B0: B28C0100
	.long 0xd700030e                                           // 0000007F81B4: D700030E
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000007F81B8: 02021814
	s_cselect_b32 s13, -1, 0                                   // 0000007F81BC: 980D80C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F81C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000007F81C4: 8B6A0D7E
	s_waitcnt vmcnt(1)                                         // 0000007F81C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000007F81CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000007F81D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000007F81D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000007F81E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000007F81EC: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 0000007F81F0: 02021212
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F81F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007F81F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000007F8204: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F8208: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000007F820C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000007F8214: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F8220: BF870002
	v_add_co_ci_u32_e64 v15, null, s21, v13, s3                // 0000007F8224: D5207C0F 000E1A15
	ds_store_b32 v0, v1                                        // 0000007F822C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007F8234: BF89FC07
	s_barrier                                                  // 0000007F8238: BFBD0000
	buffer_gl0_inv                                             // 0000007F823C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007F8244: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007F8248: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 0000007F8250: BE832002
	s_cbranch_execz 10                                         // 0000007F8254: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007F8258: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F825C: BF870091
	.long 0xd7006a02                                           // 0000007F8260: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007F8264: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007F8268: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007F8270: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007F8278: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007F827C: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F8280: 8C7E037E
	v_or_b32_e32 v2, 32, v23                                   // 0000007F8284: 38042EA0
	s_mov_b32 s2, exec_lo                                      // 0000007F8288: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F828C: BF870001
	.long 0xd4c4007e                                           // 0000007F8290: D4C4007E
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000007F8294: 0202040C
	s_cbranch_execz 10                                         // 0000007F8298: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007F829C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F82A0: BF870091
	.long 0xd7006a01                                           // 0000007F82A4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007F82A8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007F82AC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007F82B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007F82BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007F82C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F82C4: 8C7E027E
	v_or_b32_e32 v4, 64, v23                                   // 0000007F82C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007F82CC: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 0000007F82D4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F82D8: BF870002
	.long 0xd4c4007e                                           // 0000007F82DC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000007F82E0: 0202080C
	s_cbranch_execz 10                                         // 0000007F82E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007F82E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F82EC: BF870091
	.long 0xd7006a04                                           // 0000007F82F0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007F82F4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007F82F8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007F8300: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007F8308: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007F830C: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F8310: 8C7E027E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000007F8314: 38082EFF 00000060
	s_mov_b32 s2, exec_lo                                      // 0000007F831C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F8320: BF870001
	.long 0xd4c4007e                                           // 0000007F8324: D4C4007E
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000007F8328: 0202080C
	s_cbranch_execz 10                                         // 0000007F832C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007F8330: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8334: BF870091
	.long 0xd7006a03                                           // 0000007F8338: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007F833C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007F8340: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007F8348: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007F8350: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007F8354: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F8358: 8C7E027E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000007F835C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007F8364: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 0000007F836C: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F8370: BF870002
	.long 0xd4c4007e                                           // 0000007F8374: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000007F8378: 02020C0C
	s_cbranch_execz 10                                         // 0000007F837C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007F8380: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8384: BF870091
	.long 0xd7006a06                                           // 0000007F8388: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007F838C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007F8390: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007F8398: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007F83A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007F83A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F83A8: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000007F83AC: 380C2EFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 0000007F83B4: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F83B8: BF870001
	.long 0xd4c4007e                                           // 0000007F83BC: D4C4007E
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000007F83C0: 02020C0C
	s_cbranch_execz 10                                         // 0000007F83C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007F83C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F83CC: BF870091
	.long 0xd7006a05                                           // 0000007F83D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007F83D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007F83D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007F83E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007F83E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007F83EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F83F0: 8C7E027E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000007F83F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007F83FC: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 0000007F8404: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F8408: BF870002
	.long 0xd4c4007e                                           // 0000007F840C: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 0000007F8410: 0202140C
	s_cbranch_execz 10                                         // 0000007F8414: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007F8418: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F841C: BF870091
	.long 0xd7006a0a                                           // 0000007F8420: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007F8424: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007F8428: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007F8430: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007F8438: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007F843C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F8440: 8C7E027E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000007F8444: 38142EFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 0000007F844C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F8450: BF870001
	.long 0xd4c4007e                                           // 0000007F8454: D4C4007E
	v_cndmask_b32_e32 v1, s12, v10, vcc_lo                     // 0000007F8458: 0202140C
	s_cbranch_execz 10                                         // 0000007F845C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007F8460: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8464: BF870091
	.long 0xd7006a0a                                           // 0000007F8468: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007F846C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007F8470: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007F8478: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007F8480: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007F8484: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007F8488: 8C7E027E
	s_branch 9                                                 // 0000007F848C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000007F8490: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F8494: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007F8498: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007F849C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007F84A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007F84A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007F84A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007F84AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007F84B0: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 0000007F84B4: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007F84B8: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007F84BC: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 0000007F84C0: 7E340280
	s_add_u32 s10, s10, s14                                    // 0000007F84C4: 800A0E0A
	s_addc_u32 s11, s11, 0                                     // 0000007F84C8: 820B800B
	v_cndmask_b32_e64 v24, 0, 1, s13                           // 0000007F84CC: D5010018 00350280
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000007F84D4: 868A810A
	v_mov_b32_e32 v27, 0                                       // 0000007F84D8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s10, s[2:3]              // 0000007F84DC: D6FE7C12 00081508
	.long 0xd72c000b                                           // 0000007F84E4: D72C000B
	v_cndmask_b32_e32 v0, v8, v11, vcc_lo                      // 0000007F84E8: 02001708
	.long 0xd72c0014                                           // 0000007F84EC: D72C0014
	v_cndmask_b32_e32 v0, v9, v10, vcc_lo                      // 0000007F84F0: 02001509
	.long 0xd4440002                                           // 0000007F84F4: D4440002
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000007F84F8: 02022E0C
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007F84FC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007F8504: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007F8508: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007F850C: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007F8514: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 0000007F8518: BE832002
	s_cbranch_execz 21                                         // 0000007F851C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007F8520: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8528: BF870091
	.long 0xd7006a08                                           // 0000007F852C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007F8530: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007F8534: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 0000007F853C: 916A0D7E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007F8540: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007F8548: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007F854C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8550: BF870091
	.long 0xd7006a0e                                           // 0000007F8554: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007F8558: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007F855C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007F8564: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007F856C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007F8570: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F8574: 8C7E037E
	s_and_saveexec_b32 s3, s2                                  // 0000007F8578: BE832002
	s_cbranch_execz 256                                        // 0000007F857C: BFA50100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x880>
	v_dual_mov_b32 v29, v23 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007F8580: CA220117 1D0E2E81
	.long 0xd7006a0c                                           // 0000007F8588: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 0000007F858C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F8590: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 0000007F8594: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007F859C: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007F85A4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007F85A8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F85AC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007F85B0: D5207C0D 01AA1A80
	v_lshl_or_b32 v28, v23, 4, 0x200                           // 0000007F85B8: D656001C 03FD0917 00000200
	.long 0xd7006a0c                                           // 0000007F85C4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000007F85C8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F85CC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000007F85D0: D5207C0D 01AA1A05
	v_mov_b32_e32 v26, v20                                     // 0000007F85D8: 7E340314
	.long 0xd7006a15                                           // 0000007F85DC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000007F85E0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F85E4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007F85E8: D5207C16 01AA1A80
	v_mov_b32_e32 v30, v27                                     // 0000007F85F0: 7E3C031B
	s_mov_b32 s4, 0                                            // 0000007F85F4: BE840080
	s_branch 196                                               // 0000007F85F8: BFA000C4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x80c>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F85FC: 8C7E057E
	.long 0xd73c001f                                           // 0000007F8600: D73C001F
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007F8604: 02022681
	v_and_b32_e32 v47, 0xff, v8                                // 0000007F8608: 365E10FF 000000FF
	v_lshrrev_b32_e32 v48, 6, v8                               // 0000007F8610: 32601086
	v_lshrrev_b32_e32 v49, 14, v8                              // 0000007F8614: 3262108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007F8618: 32101096
	v_and_b32_e32 v50, 0xff, v9                                // 0000007F861C: 366412FF 000000FF
	.long 0xd7006a2b                                           // 0000007F8624: D7006A2B
	v_cndmask_b32_e32 v1, s6, v31, vcc_lo                      // 0000007F8628: 02023E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F862C: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v32, vcc_lo             // 0000007F8630: D5207C2C 01AA4007
	v_lshlrev_b32_e32 v47, 2, v47                              // 0000007F8638: 305E5E82
	v_and_b32_e32 v48, 0x3fc, v48                              // 0000007F863C: 366060FF 000003FC
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000007F8644: 366262FF 000003FC
	s_clause 0x3                                               // 0000007F864C: BF850003
	global_load_b128 v[31:34], v[43:44], off                   // 0000007F8650: DC5E0000 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:16         // 0000007F8658: DC5E0010 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:32         // 0000007F8660: DC5E0020 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:48         // 0000007F8668: DC5E0030 2B7C002B
	v_lshrrev_b32_e32 v51, 6, v9                               // 0000007F8670: 32661286
	ds_load_b32 v47, v47                                       // 0000007F8674: D8D80000 2F00002F
	ds_load_b32 v48, v48                                       // 0000007F867C: D8D80000 30000030
	ds_load_b32 v49, v49                                       // 0000007F8684: D8D80000 31000031
	v_lshrrev_b32_e32 v52, 14, v9                              // 0000007F868C: 3268128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007F8690: 32121296
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007F8694: 361010FF 000003FC
	v_lshlrev_b32_e32 v50, 2, v50                              // 0000007F869C: 30646482
	v_and_b32_e32 v51, 0x3fc, v51                              // 0000007F86A0: 366666FF 000003FC
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000007F86A8: 366868FF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007F86B0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007F86B8: D8D80000 08000008
	ds_load_b32 v50, v50                                       // 0000007F86C0: D8D80000 32000032
	ds_load_b32 v51, v51                                       // 0000007F86C8: D8D80000 33000033
	ds_load_b32 v52, v52                                       // 0000007F86D0: D8D80000 34000034
	ds_load_b32 v9, v9                                         // 0000007F86D8: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007F86E0: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000007F86E4: 02018115
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007F86E8: BF8704A1
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007F86EC: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 0000007F86F4: 8B02027E
	s_or_b32 s4, s2, s4                                        // 0000007F86F8: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007F86FC: BF890C77
	v_dot2_f32_bf16 v31, v31, v47, 0                           // 0000007F8700: CC1A401F 1A025F1F
	v_lshrrev_b32_e32 v47, 14, v10                             // 0000007F8708: 325E148E
	s_waitcnt lgkmcnt(6)                                       // 0000007F870C: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F8710: BF870132
	v_dot2_f32_bf16 v31, v32, v48, v31                         // 0000007F8714: CC1A401F 1C7E6120
	v_and_b32_e32 v32, 0xff, v10                               // 0000007F871C: 364014FF 000000FF
	s_waitcnt lgkmcnt(5)                                       // 0000007F8724: BF89FC57
	v_dot2_f32_bf16 v31, v33, v49, v31                         // 0000007F8728: CC1A401F 1C7E6321
	v_lshrrev_b32_e32 v33, 6, v10                              // 0000007F8730: 32421486
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007F8734: 32141496
	s_waitcnt lgkmcnt(4)                                       // 0000007F8738: BF89FC47
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F873C: BF870003
	v_dot2_f32_bf16 v8, v34, v8, v31                           // 0000007F8740: CC1A4008 1C7E1122
	v_lshlrev_b32_e32 v31, 2, v32                              // 0000007F8748: 303E4082
	v_and_b32_e32 v33, 0x3fc, v33                              // 0000007F874C: 364242FF 000003FC
	v_and_b32_e32 v32, 0xff, v11                               // 0000007F8754: 364016FF 000000FF
	v_lshrrev_b32_e32 v34, 6, v11                              // 0000007F875C: 32441686
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007F8760: BF890837
	v_dot2_f32_bf16 v8, v35, v50, v8                           // 0000007F8764: CC1A4008 1C226523
	ds_load_b32 v31, v31                                       // 0000007F876C: D8D80000 1F00001F
	ds_load_b32 v33, v33                                       // 0000007F8774: D8D80000 21000021
	v_lshrrev_b32_e32 v35, 14, v11                             // 0000007F877C: 3246168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007F8780: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007F8784: BF89FC47
	v_dot2_f32_bf16 v8, v36, v51, v8                           // 0000007F8788: CC1A4008 1C226724
	v_lshlrev_b32_e32 v32, 2, v32                              // 0000007F8790: 30404082
	v_and_b32_e32 v34, 0x3fc, v34                              // 0000007F8794: 364444FF 000003FC
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007F879C: 364646FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007F87A4: BF89FC37
	v_dot2_f32_bf16 v8, v37, v52, v8                           // 0000007F87A8: CC1A4008 1C226925
	v_cndmask_b32_e64 v37, v6, v7, s1                          // 0000007F87B0: D5010025 00060F06
	v_and_b32_e32 v47, 0x3fc, v47                              // 0000007F87B8: 365E5EFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007F87C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F87C4: BF870003
	v_dot2_f32_bf16 v8, v38, v9, v8                            // 0000007F87C8: CC1A4008 1C221326
	ds_load_b32 v36, v47                                       // 0000007F87D0: D8D80000 2400002F
	s_waitcnt vmcnt(1) lgkmcnt(2)                              // 0000007F87D8: BF890427
	v_dot2_f32_bf16 v8, v39, v31, v8                           // 0000007F87DC: CC1A4008 1C223F27
	v_cndmask_b32_e64 v31, v0, v1, s1                          // 0000007F87E4: D501001F 00060300
	v_cndmask_b32_e64 v39, v27, v0, s1                         // 0000007F87EC: D5010027 0006011B
	v_mov_b32_e32 v27, v30                                     // 0000007F87F4: 7E36031E
	s_waitcnt lgkmcnt(1)                                       // 0000007F87F8: BF89FC17
	v_dot2_f32_bf16 v8, v40, v33, v8                           // 0000007F87FC: CC1A4008 1C224328
	v_cndmask_b32_e64 v33, v2, v3, s1                          // 0000007F8804: D5010021 00060702
	s_waitcnt lgkmcnt(0)                                       // 0000007F880C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F8810: BF870002
	v_dot2_f32_bf16 v8, v41, v36, v8                           // 0000007F8814: CC1A4008 1C224929
	v_cndmask_b32_e64 v36, v5, v6, s1                          // 0000007F881C: D5010024 00060D05
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007F8824: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007F882C: 361616FF 000003FC
	ds_load_b32 v9, v10                                        // 0000007F8834: D8D80000 0900000A
	ds_load_b32 v10, v32                                       // 0000007F883C: D8D80000 0A000020
	ds_load_b32 v38, v34                                       // 0000007F8844: D8D80000 26000022
	ds_load_b32 v47, v35                                       // 0000007F884C: D8D80000 2F000023
	ds_load_b32 v48, v11                                       // 0000007F8854: D8D80000 3000000B
	v_cndmask_b32_e64 v32, v1, v2, s1                          // 0000007F885C: D5010020 00060501
	v_cndmask_b32_e64 v35, v4, v5, s1                          // 0000007F8864: D5010023 00060B04
	v_cndmask_b32_e64 v34, v3, v4, s1                          // 0000007F886C: D5010022 00060903
	v_mov_b32_e32 v11, v15                                     // 0000007F8874: 7E16030F
	s_waitcnt lgkmcnt(4)                                       // 0000007F8878: BF89FC47
	v_dot2_f32_bf16 v8, v42, v9, v8                            // 0000007F887C: CC1A4008 1C22132A
	v_mov_b32_e32 v9, v13                                      // 0000007F8884: 7E12030D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007F8888: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007F888C: BF8701C2
	v_dot2_f32_bf16 v6, v43, v10, v8                           // 0000007F8890: CC1A4006 1C22152B
	v_mov_b32_e32 v10, v14                                     // 0000007F8898: 7E14030E
	v_mov_b32_e32 v8, v12                                      // 0000007F889C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007F88A0: BF89FC27
	v_dot2_f32_bf16 v2, v44, v38, v6                           // 0000007F88A4: CC1A4002 1C1A4D2C
	v_dual_mov_b32 v38, v7 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000007F88AC: CA200107 261226FF 00000400
	v_add_nc_u32_e32 v28, 0x200, v28                           // 0000007F88B8: 4A3838FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 0000007F88C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F88C4: BF8700A3
	v_dot2_f32_bf16 v0, v45, v47, v2                           // 0000007F88C8: CC1A4000 1C0A5F2D
	s_waitcnt lgkmcnt(0)                                       // 0000007F88D0: BF89FC07
	v_dot2_f32_bf16 v0, v46, v48, v0                           // 0000007F88D4: CC1A4000 1C02612E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F88DC: BF870001
	v_fmac_f32_e32 v26, v39, v0                                // 0000007F88E0: 56340127
	v_dual_mov_b32 v0, v31 :: v_dual_mov_b32 v1, v32           // 0000007F88E4: CA10011F 00000120
	v_dual_mov_b32 v2, v33 :: v_dual_mov_b32 v3, v34           // 0000007F88EC: CA100121 02020122
	v_dual_mov_b32 v4, v35 :: v_dual_mov_b32 v5, v36           // 0000007F88F4: CA100123 04040124
	v_dual_mov_b32 v6, v37 :: v_dual_mov_b32 v7, v38           // 0000007F88FC: CA100125 06060126
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000007F8904: 917E047E
	s_cbranch_execz 28                                         // 0000007F8908: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x87c>
	s_waitcnt vmcnt(0)                                         // 0000007F890C: BF8903F7
	v_dual_mov_b32 v12, v8 :: v_dual_add_nc_u32 v29, 32, v29   // 0000007F8910: CA200108 0C1C3AA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v14, v10          // 0000007F8918: CA100109 0D0E010A
	v_mov_b32_e32 v15, v11                                     // 0000007F8920: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F8924: BF870003
	.long 0xd4430002                                           // 0000007F8928: D4430002
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000007F892C: 02023A0C
	s_mov_b32 s5, exec_lo                                      // 0000007F8930: BE85007E
	.long 0xd4c4007e                                           // 0000007F8934: D4C4007E
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 0000007F8938: 02023A0C
	s_cbranch_execz 65327                                      // 0000007F893C: BFA5FF2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	.long 0xd7006a0c                                           // 0000007F8940: D7006A0C
	v_cndmask_b32_e32 v1, v18, v28, vcc_lo                     // 0000007F8944: 02023912
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F8948: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007F894C: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007F8954: 7C9A3081
	v_mov_b32_e32 v30, v27                                     // 0000007F8958: 7E3C031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007F895C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65317                                      // 0000007F8964: BFA4FF25 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	global_load_d16_b16 v30, v[21:22], off                     // 0000007F8968: DC820000 1E7C0015
	s_waitcnt vmcnt(0)                                         // 0000007F8970: BF8903F7
	v_cvt_f32_f16_e32 v30, v30                                 // 0000007F8974: 7E3C171E
	s_branch 65312                                             // 0000007F8978: BFA0FF20 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4fc>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F897C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F8980: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007F8984: 8C7E037E
	.long 0xd71f0000                                           // 0000007F8988: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007F898C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007F8990: 3A020090
	v_xor_b32_e32 v2, 8, v0                                    // 0000007F8994: 3A040088
	v_xor_b32_e32 v3, 4, v0                                    // 0000007F8998: 3A060084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F899C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007F89A0: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007F89A4: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007F89A8: 7C9804A0
	v_cndmask_b32_e32 v2, v0, v2, vcc_lo                       // 0000007F89AC: 02040500
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F89B0: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F89B4: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007F89B8: 30040482
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F89BC: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007F89C0: 02060700
	ds_bpermute_b32 v1, v1, v26                                // 0000007F89C4: DACC0000 01001A01
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007F89CC: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000007F89D0: BF89FC07
	v_add_f32_e32 v1, v26, v1                                  // 0000007F89D4: 0602031A
	ds_bpermute_b32 v2, v2, v1                                 // 0000007F89D8: DACC0000 02000102
	s_waitcnt lgkmcnt(0)                                       // 0000007F89E0: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007F89E4: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000007F89E8: DACC0000 02000103
	v_xor_b32_e32 v3, 2, v0                                    // 0000007F89F0: 3A060082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F89F4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F89F8: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007F89FC: 02060700
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007F8A00: 30060682
	s_waitcnt lgkmcnt(0)                                       // 0000007F8A04: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007F8A08: 06020501
	ds_bpermute_b32 v2, v3, v1                                 // 0000007F8A0C: DACC0000 02000103
	v_xor_b32_e32 v3, 1, v0                                    // 0000007F8A14: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F8A18: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F8A1C: 7C9806A0
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007F8A20: 02060700
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007F8A24: 7C942E80
	s_and_b32 s0, vcc_lo, s0                                   // 0000007F8A28: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000007F8A2C: BF89FC07
	v_dual_add_f32 v0, v1, v2 :: v_dual_lshlrev_b32 v1, 2, v3  // 0000007F8A30: C9220501 00000682
	ds_bpermute_b32 v1, v1, v0                                 // 0000007F8A38: DACC0000 01000001
	s_and_saveexec_b32 s1, s0                                  // 0000007F8A40: BE812000
	s_cbranch_execz 54                                         // 0000007F8A44: BFA50036 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xa20>
	s_waitcnt lgkmcnt(0)                                       // 0000007F8A48: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007F8A4C: 06000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8A50: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007F8A54: D6100001 02052100
	v_add3_u32 v0, v0, v1, 0x7fff                              // 0000007F8A5C: D6550000 03FE0300 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8A68: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007F8A6C: 360000FF FFFF0000
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000007F8A74: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007F8A7C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000007F8A80: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007F8A84: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F8A88: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000007F8A8C: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 0000007F8A94: D6FC6A04 03CA00F2
	v_rcp_f32_e32 v2, v1                                       // 0000007F8A9C: 7E045501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8AA0: BF870095
	v_fma_f32 v3, -v1, v2, 1.0                                 // 0000007F8AA4: D6130003 23CA0501
	v_fmac_f32_e32 v2, v3, v2                                  // 0000007F8AAC: 56040503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8AB0: BF870091
	v_mul_f32_e32 v3, v4, v2                                   // 0000007F8AB4: 10060504
	v_fma_f32 v5, -v1, v3, v4                                  // 0000007F8AB8: D6130005 24120701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8AC0: BF870091
	v_fmac_f32_e32 v3, v5, v2                                  // 0000007F8AC4: 56060505
	v_fma_f32 v1, -v1, v3, v4                                  // 0000007F8AC8: D6130001 24120701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F8AD0: BF870091
	v_div_fmas_f32 v1, v1, v2, v3                              // 0000007F8AD4: D6370001 040E0501
	v_div_fixup_f32 v2, v1, v0, 1.0                            // 0000007F8ADC: D6270002 03CA0101
	.long 0xd73c0000                                           // 0000007F8AE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007F8AE8: 02022081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F8AEC: BF870112
	v_bfe_u32 v3, v2, 16, 1                                    // 0000007F8AF0: D6100003 02052102
	.long 0xd7006a00                                           // 0000007F8AF8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007F8AFC: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007F8B00: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007F8B04: D5207C01 01AA0209
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000007F8B0C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007F8B18: DC960000 007C0200
	s_endpgm                                                   // 0000007F8B20: BFB00000
		...

