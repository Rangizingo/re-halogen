00000000005ab300 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi16ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi16ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 0000005AB300: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000005AB304: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000005AB30C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 0000005AB314: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000005AB318: 32020084
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000005AB31C: 84808402
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000005AB320: CA100080 08080080
	v_dual_mov_b32 v2, s1 :: v_dual_and_b32 v7, 15, v0         // 0000005AB328: CA240001 0206008F
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 0000005AB330: CA100080 0B0A0080
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v12, 0             // 0000005AB338: CA100080 0D0C0080
	v_or_b32_e32 v1, s0, v1                                    // 0000005AB340: 38020200
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v15, 0             // 0000005AB344: CA100080 0E0E0080
	s_waitcnt lgkmcnt(0)                                       // 0000005AB34C: BF89FC07
	s_ashr_i32 s1, s11, 31                                     // 0000005AB350: 86019F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005AB354: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005AB358: 7CA8020C
	s_lshr_b32 s1, s1, 28                                      // 0000005AB35C: 85019C01
	s_add_u32 s0, s10, s1                                      // 0000005AB360: 8000010A
	s_addc_u32 s1, s11, 0                                      // 0000005AB364: 8201800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005AB368: BF870009
	s_lshr_b64 s[14:15], s[0:1], 4                             // 0000005AB36C: 858E8400
	s_mov_b32 s1, exec_lo                                      // 0000005AB370: BE81007E
	.long 0xd4c4007e                                           // 0000005AB374: D4C4007E
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 0000005AB378: 02020E0E
	s_cbranch_execz 588                                        // 0000005AB37C: BFA5024C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi16ELi1ELb0EEEvPKhPKtPvll+0x9b0>
	s_ashr_i32 s0, s11, 31                                     // 0000005AB380: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v16, 4, v0  // 0000005AB384: CA640480 03100084
	s_lshr_b32 s0, s0, 24                                      // 0000005AB38C: 85009800
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_and_b32 v0, 6, v0   // 0000005AB390: CA640280 05000086
	s_add_u32 s16, s10, s0                                     // 0000005AB398: 8010000A
	s_addc_u32 s17, s11, 0                                     // 0000005AB39C: 8211800B
	v_lshrrev_b32_e32 v9, 3, v7                                // 0000005AB3A0: 32120E83
	s_ashr_i64 s[16:17], s[16:17], 8                           // 0000005AB3A4: 86908810
	v_mov_b32_e32 v6, 0                                        // 0000005AB3A8: 7E0C0280
	s_mul_i32 s0, s17, 0xd2                                    // 0000005AB3AC: 9600FF11 000000D2
	s_mul_hi_u32 s2, s16, 0xd2                                 // 0000005AB3B4: 9682FF10 000000D2
	s_mul_i32 s15, s16, 0xd2                                   // 0000005AB3BC: 960FFF10 000000D2
	s_add_i32 s2, s2, s0                                       // 0000005AB3C4: 81020002
	.long 0xd72c0008                                           // 0000005AB3C8: D72C0008
	v_cndmask_b32_e32 v1, s15, v3, vcc_lo                      // 0000005AB3CC: 0202060F
	v_mad_u64_u32 v[3:4], null, s15, v5, s[4:5]                // 0000005AB3D0: D6FE7C03 00120A0F
	.long 0xd72c0005                                           // 0000005AB3D8: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000005AB3DC: 02020A02
	v_lshlrev_b32_e32 v17, 6, v9                               // 0000005AB3E0: 30221286
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v18, 5, v9     // 0000005AB3E4: CA220080 19121285
	v_or_b32_e32 v19, 8, v16                                   // 0000005AB3EC: 38262088
	v_or_b32_e32 v20, 8, v0                                    // 0000005AB3F0: 38280088
	v_or_b32_e32 v21, 16, v16                                  // 0000005AB3F4: 382A2090
	v_or_b32_e32 v22, 16, v0                                   // 0000005AB3F8: 382C0090
	v_add3_u32 v4, v5, v4, v8                                  // 0000005AB3FC: D6550004 04220905
	v_or_b32_e32 v23, 24, v16                                  // 0000005AB404: 382E2098
	v_or_b32_e32 v24, 24, v0                                   // 0000005AB408: 38300098
	v_dual_mov_b32 v26, v7 :: v_dual_lshlrev_b32 v5, 4, v7     // 0000005AB40C: CA220107 1A040E84
	v_mov_b32_e32 v15, v6                                      // 0000005AB414: 7E1E0306
	v_mov_b32_e32 v14, v6                                      // 0000005AB418: 7E1C0306
	v_mov_b32_e32 v12, v6                                      // 0000005AB41C: 7E180306
	v_mov_b32_e32 v13, v6                                      // 0000005AB420: 7E1A0306
	v_mov_b32_e32 v10, v6                                      // 0000005AB424: 7E140306
	v_mov_b32_e32 v11, v6                                      // 0000005AB428: 7E160306
	v_mov_b32_e32 v9, v6                                       // 0000005AB42C: 7E120306
	v_mov_b32_e32 v8, v6                                       // 0000005AB430: 7E100306
	s_mul_i32 s0, s11, 6                                       // 0000005AB434: 9600860B
	s_mul_hi_u32 s2, s10, 6                                    // 0000005AB438: 9682860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005AB43C: 8484820A
	s_add_i32 s2, s2, s0                                       // 0000005AB440: 81020002
	s_mul_i32 s15, s10, 6                                      // 0000005AB444: 960F860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005AB448: 848A810A
	.long 0xd700003b                                           // 0000005AB44C: D700003B
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000005AB450: 02023303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005AB454: BF8701A1
	v_add_co_ci_u32_e64 v60, null, 0, v4, s0                   // 0000005AB458: D5207C3C 00020880
	.long 0xd73c001b                                           // 0000005AB460: D73C001B
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000005AB464: 02020A81
	.long 0xd700001e                                           // 0000005AB468: D700001E
	v_cndmask_b32_e32 v1, v59, v17, vcc_lo                     // 0000005AB46C: 0202233B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AB470: BF870001
	v_add_co_ci_u32_e64 v31, null, 0, v60, s0                  // 0000005AB474: D5207C1F 00027880
	.long 0xd7000020                                           // 0000005AB47C: D7000020
	v_cndmask_b32_e32 v1, v59, v18, vcc_lo                     // 0000005AB480: 0202253B
	v_and_b32_e32 v29, 32, v5                                  // 0000005AB484: 363A0AA0
	v_add_co_ci_u32_e64 v33, null, 0, v60, s0                  // 0000005AB488: D5207C21 00027880
	.long 0xd7000027                                           // 0000005AB490: D7000027
	v_cndmask_b32_e32 v1, v59, v7, vcc_lo                      // 0000005AB494: 02020F3B
	v_and_b32_e32 v41, 16, v5                                  // 0000005AB498: 36520A90
	v_add_co_ci_u32_e64 v40, null, 0, v60, s0                  // 0000005AB49C: D5207C28 00027880
	.long 0xd7000023                                           // 0000005AB4A4: D7000023
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000005AB4A8: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AB4AC: BF8700A1
	v_add_co_ci_u32_e64 v36, null, s7, v28, s0                 // 0000005AB4B0: D5207C24 00023807
	.long 0xd700002a                                           // 0000005AB4B8: D700002A
	v_cndmask_b32_e32 v1, v30, v29, vcc_lo                     // 0000005AB4BC: 02023B1E
	v_add_co_ci_u32_e64 v45, null, 0, v31, s0                  // 0000005AB4C0: D5207C2D 00023E80
	.long 0xd7000025                                           // 0000005AB4C8: D7000025
	v_cndmask_b32_e32 v1, v32, v41, vcc_lo                     // 0000005AB4CC: 02025320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AB4D0: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v33, s0                  // 0000005AB4D4: D5207C26 00024280
	.long 0xd700002b                                           // 0000005AB4DC: D700002B
	v_cndmask_b32_e32 v0, v35, v10, vcc_lo                     // 0000005AB4E0: 02001523
	v_add_co_ci_u32_e64 v44, null, s11, v36, s0                // 0000005AB4E4: D5207C2C 0002480B
	.long 0xd7000037                                           // 0000005AB4EC: D7000037
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 0000005AB4F0: 02000923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AB4F4: BF8700A1
	v_add_co_ci_u32_e64 v56, null, s5, v36, s0                 // 0000005AB4F8: D5207C38 00024805
	.long 0xd700003d                                           // 0000005AB500: D700003D
	v_cndmask_b32_e32 v0, v35, v15, vcc_lo                     // 0000005AB504: 02001F23
	v_add_co_ci_u32_e64 v62, null, s2, v36, s0                 // 0000005AB508: D5207C3E 00024802
	.long 0xd7000039                                           // 0000005AB510: D7000039
	v_cndmask_b32_e32 v1, v42, v41, vcc_lo                     // 0000005AB514: 0202532A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AB518: BF870001
	v_add_co_ci_u32_e64 v58, null, 0, v45, s0                  // 0000005AB51C: D5207C3A 00025A80
	.long 0xd700003f                                           // 0000005AB524: D700003F
	v_cndmask_b32_e32 v0, v55, v4, vcc_lo                      // 0000005AB528: 02000937
	s_clause 0x1                                               // 0000005AB52C: BF850001
	global_load_b128 v[27:30], v[35:36], off                   // 0000005AB530: DC5E0000 1B7C0023
	global_load_b128 v[31:34], v[35:36], off offset:16         // 0000005AB538: DC5E0010 1F7C0023
	s_clause 0x1                                               // 0000005AB540: BF850001
	global_load_b128 v[35:38], v[37:38], off offset:128        // 0000005AB544: DC5E0080 237C0025
	global_load_i8 v65, v[39:40], off offset:192               // 0000005AB54C: DC4600C0 417C0027
	s_clause 0x3                                               // 0000005AB554: BF850003
	global_load_b128 v[39:42], v[43:44], off                   // 0000005AB558: DC5E0000 277C002B
	global_load_b128 v[43:46], v[43:44], off offset:16         // 0000005AB560: DC5E0010 2B7C002B
	global_load_b128 v[47:50], v[55:56], off                   // 0000005AB568: DC5E0000 2F7C0037
	global_load_b128 v[51:54], v[55:56], off offset:16         // 0000005AB570: DC5E0010 337C0037
	v_add_co_ci_u32_e64 v64, null, s5, v56, s0                 // 0000005AB578: D5207C40 00027005
	s_clause 0x1                                               // 0000005AB580: BF850001
	global_load_b128 v[55:58], v[57:58], off                   // 0000005AB584: DC5E0000 377C0039
	global_load_d16_b16 v59, v[59:60], off offset:208          // 0000005AB58C: DC8200D0 3B7C003B
	.long 0xd7000047                                           // 0000005AB594: D7000047
	v_cndmask_b32_e32 v0, v61, v4, vcc_lo                      // 0000005AB598: 0200093D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AB59C: BF870001
	v_add_co_ci_u32_e64 v72, null, s5, v62, s0                 // 0000005AB5A0: D5207C48 00027C05
	v_add_nc_u32_e32 v25, 0xd2, v25                            // 0000005AB5A8: 4A3232FF 000000D2
	s_waitcnt vmcnt(7)                                         // 0000005AB5B0: BF891FF7
	v_lshrrev_b32_e32 v66, v20, v35                            // 0000005AB5B4: 32844714
	v_lshrrev_b32_e32 v74, v24, v36                            // 0000005AB5B8: 32944918
	v_lshrrev_b32_e32 v84, v24, v38                            // 0000005AB5BC: 32A84D18
	s_waitcnt vmcnt(1)                                         // 0000005AB5C0: BF8907F7
	v_bfe_u32 v75, v55, v16, 4                                 // 0000005AB5C4: D610004B 02122137
	v_bfe_u32 v76, v55, v19, 4                                 // 0000005AB5CC: D610004C 02122737
	v_bfe_u32 v85, v55, v21, 4                                 // 0000005AB5D4: D6100055 02122B37
	v_bfe_u32 v86, v55, v23, 4                                 // 0000005AB5DC: D6100056 02122F37
	v_cvt_f32_i32_e32 v55, v65                                 // 0000005AB5E4: 7E6E0B41
	v_bfe_u32 v87, v56, v16, 4                                 // 0000005AB5E8: D6100057 02122138
	v_bfe_u32 v88, v56, v19, 4                                 // 0000005AB5F0: D6100058 02122738
	v_bfe_u32 v89, v56, v21, 4                                 // 0000005AB5F8: D6100059 02122B38
	v_bfe_u32 v90, v56, v23, 4                                 // 0000005AB600: D610005A 02122F38
	s_waitcnt vmcnt(0)                                         // 0000005AB608: BF8903F7
	v_fma_mix_f32 v99, v59, v55, neg(0) op_sel_hi:[1,0,0]      // 0000005AB60C: CC200063 8A026F3B
	v_lshlrev_b32_e32 v56, 4, v66                              // 0000005AB614: 30708484
	v_lshlrev_b32_e32 v66, 4, v74                              // 0000005AB618: 30849484
	v_bfe_u32 v98, v58, v23, 4                                 // 0000005AB61C: D6100062 02122F3A
	v_lshlrev_b32_e32 v84, 4, v84                              // 0000005AB624: 30A8A884
	v_lshrrev_b32_e32 v60, v0, v35                             // 0000005AB628: 32784700
	v_lshrrev_b32_e32 v67, v22, v35                            // 0000005AB62C: 32864716
	v_and_or_b32 v74, v66, 48, v90                             // 0000005AB630: D657004A 05696142
	v_lshrrev_b32_e32 v78, v20, v37                            // 0000005AB638: 329C4B14
	v_and_or_b32 v84, v84, 48, v98                             // 0000005AB63C: D6570054 05896154
	v_lshrrev_b32_e32 v79, v22, v37                            // 0000005AB644: 329E4B16
	v_lshrrev_b32_e32 v83, v22, v38                            // 0000005AB648: 32A64D16
	v_subrev_nc_u32_e32 v74, 32, v74                           // 0000005AB64C: 4E9494A0
	v_bfe_u32 v92, v57, v19, 4                                 // 0000005AB650: D610005C 02122739
	v_subrev_nc_u32_e32 v84, 32, v84                           // 0000005AB658: 4EA8A8A0
	v_bfe_u32 v97, v58, v21, 4                                 // 0000005AB65C: D6100061 02122B3A
	v_lshlrev_b32_e32 v59, 4, v67                              // 0000005AB664: 30768684
	v_cvt_f32_i32_e32 v74, v74                                 // 0000005AB668: 7E940B4A
	v_lshlrev_b32_e32 v55, 4, v60                              // 0000005AB66C: 306E7884
	v_lshlrev_b32_e32 v66, 4, v78                              // 0000005AB670: 30849C84
	v_cvt_f32_i32_e32 v84, v84                                 // 0000005AB674: 7EA80B54
	v_lshlrev_b32_e32 v67, 4, v79                              // 0000005AB678: 30869E84
	v_dual_mul_f32 v74, v99, v74 :: v_dual_lshlrev_b32 v79, 4, v83// 0000005AB67C: C8E29563 4A4EA684
	v_and_or_b32 v100, v55, 48, v75                            // 0000005AB684: D6570064 052D6137
	v_and_or_b32 v78, v66, 48, v92                             // 0000005AB68C: D657004E 05716142
	v_lshrrev_b32_e32 v69, v0, v36                             // 0000005AB694: 328A4900
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005AB698: BF870004
	v_and_or_b32 v83, v79, 48, v97                             // 0000005AB69C: D6570053 0585614F
	v_lshrrev_b32_e32 v68, v24, v35                            // 0000005AB6A4: 32884718
	v_subrev_nc_u32_e32 v79, 32, v100                          // 0000005AB6A8: 4E9EC8A0
	v_subrev_nc_u32_e32 v78, 32, v78                           // 0000005AB6AC: 4E9C9CA0
	v_lshrrev_b32_e32 v70, v20, v36                            // 0000005AB6B0: 328C4914
	v_lshrrev_b32_e32 v73, v22, v36                            // 0000005AB6B4: 32924916
	v_lshrrev_b32_e32 v77, v0, v37                             // 0000005AB6B8: 329A4B00
	v_cvt_f32_i32_e32 v79, v79                                 // 0000005AB6BC: 7E9E0B4F
	v_lshrrev_b32_e32 v80, v24, v37                            // 0000005AB6C0: 32A04B18
	v_lshrrev_b32_e32 v81, v0, v38                             // 0000005AB6C4: 32A24D00
	v_lshrrev_b32_e32 v82, v20, v38                            // 0000005AB6C8: 32A44D14
	v_bfe_u32 v91, v57, v16, 4                                 // 0000005AB6CC: D610005B 02122139
	v_bfe_u32 v93, v57, v21, 4                                 // 0000005AB6D4: D610005D 02122B39
	v_bfe_u32 v94, v57, v23, 4                                 // 0000005AB6DC: D610005E 02122F39
	v_bfe_u32 v95, v58, v16, 4                                 // 0000005AB6E4: D610005F 0212213A
	v_bfe_u32 v96, v58, v19, 4                                 // 0000005AB6EC: D6100060 0212273A
	global_load_b128 v[35:38], v[61:62], off                   // 0000005AB6F4: DC5E0000 237C003D
	v_mul_f32_e32 v79, v99, v79                                // 0000005AB6FC: 109E9F63
	v_and_or_b32 v101, v56, 48, v76                            // 0000005AB700: D6570065 05316138
	global_load_b128 v[55:58], v[61:62], off offset:16         // 0000005AB708: DC5E0010 377C003D
	v_cvt_f32_i32_e32 v78, v78                                 // 0000005AB710: 7E9C0B4E
	v_lshlrev_b32_e32 v61, 4, v69                              // 0000005AB714: 307A8A84
	v_dual_mul_f32 v84, v99, v84 :: v_dual_lshlrev_b32 v69, 4, v81// 0000005AB718: C8E2A963 5444A284
	v_and_or_b32 v81, v67, 48, v93                             // 0000005AB720: D6570051 05756143
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005AB728: BF870214
	v_mul_f32_e32 v78, v99, v78                                // 0000005AB72C: 109C9D63
	v_and_or_b32 v87, v61, 48, v87                             // 0000005AB730: D6570057 055D613D
	.long 0xd700004b                                           // 0000005AB738: D700004B
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 0000005AB73C: 0200093F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005AB740: BF870224
	v_subrev_nc_u32_e32 v81, 32, v81                           // 0000005AB744: 4EA2A2A0
	v_add_co_ci_u32_e64 v76, null, s5, v64, s0                 // 0000005AB748: D5207C4C 00028005
	v_subrev_nc_u32_e32 v87, 32, v87                           // 0000005AB750: 4EAEAEA0
	v_subrev_nc_u32_e32 v83, 32, v83                           // 0000005AB754: 4EA6A6A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005AB758: BF870194
	v_cvt_f32_i32_e32 v81, v81                                 // 0000005AB75C: 7EA20B51
	v_cvt_f32_i32_e32 v87, v87                                 // 0000005AB760: 7EAE0B57
	v_lshlrev_b32_e32 v62, 4, v70                              // 0000005AB764: 307C8C84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005AB768: BF870223
	v_dual_mul_f32 v81, v99, v81 :: v_dual_lshlrev_b32 v70, 4, v82// 0000005AB76C: C8E2A363 5146A484
	v_cvt_f32_i32_e32 v83, v83                                 // 0000005AB774: 7EA60B53
	v_mul_f32_e32 v87, v99, v87                                // 0000005AB778: 10AEAF63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005AB77C: BF870194
	v_and_or_b32 v88, v62, 48, v88                             // 0000005AB780: D6570058 0561613E
	v_mul_f32_e32 v83, v99, v83                                // 0000005AB788: 10A6A763
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AB78C: BF870092
	v_subrev_nc_u32_e32 v88, 32, v88                           // 0000005AB790: 4EB0B0A0
	v_cvt_f32_i32_e32 v88, v88                                 // 0000005AB794: 7EB00B58
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005AB798: BF8700A1
	v_mul_f32_e32 v88, v99, v88                                // 0000005AB79C: 10B0B163
	v_and_or_b32 v85, v59, 48, v85                             // 0000005AB7A0: D6570055 0555613B
	v_subrev_nc_u32_e32 v85, 32, v85                           // 0000005AB7A8: 4EAAAAA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005AB7AC: BF870241
	v_cvt_f32_i32_e32 v85, v85                                 // 0000005AB7B0: 7EAA0B55
	v_lshlrev_b32_e32 v60, 4, v68                              // 0000005AB7B4: 30788884
	v_lshlrev_b32_e32 v68, 4, v80                              // 0000005AB7B8: 3088A084
	v_subrev_nc_u32_e32 v80, 32, v101                          // 0000005AB7BC: 4EA0CAA0
	v_mul_f32_e32 v85, v99, v85                                // 0000005AB7C0: 10AAAB63
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005AB7C4: BF870214
	v_and_or_b32 v86, v60, 48, v86                             // 0000005AB7C8: D6570056 0559613C
	v_and_or_b32 v82, v68, 48, v94                             // 0000005AB7D0: D6570052 05796144
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000005AB7D8: BF8701D4
	v_cvt_f32_i32_e32 v80, v80                                 // 0000005AB7DC: 7EA00B50
	global_load_b128 v[59:62], v[63:64], off                   // 0000005AB7E0: DC5E0000 3B7C003F
	v_subrev_nc_u32_e32 v86, 32, v86                           // 0000005AB7E8: 4EACACA0
	v_subrev_nc_u32_e32 v82, 32, v82                           // 0000005AB7EC: 4EA4A4A0
	v_mul_f32_e32 v80, v99, v80                                // 0000005AB7F0: 10A0A163
	v_cvt_f32_i32_e32 v86, v86                                 // 0000005AB7F4: 7EAC0B56
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB7F8: BF870113
	v_cvt_f32_i32_e32 v82, v82                                 // 0000005AB7FC: 7EA40B52
	v_dual_mul_f32 v86, v99, v86 :: v_dual_lshlrev_b32 v65, 4, v73// 0000005AB800: C8E2AD63 56409284
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB808: BF870112
	v_mul_f32_e32 v82, v99, v82                                // 0000005AB80C: 10A4A563
	v_and_or_b32 v73, v65, 48, v89                             // 0000005AB810: D6570049 05656141
	v_and_or_b32 v89, v69, 48, v95                             // 0000005AB818: D6570059 057D6145
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB820: BF870112
	v_subrev_nc_u32_e32 v73, 32, v73                           // 0000005AB824: 4E9292A0
	v_subrev_nc_u32_e32 v89, 32, v89                           // 0000005AB828: 4EB2B2A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB82C: BF870112
	v_cvt_f32_i32_e32 v73, v73                                 // 0000005AB830: 7E920B49
	v_cvt_f32_i32_e32 v89, v89                                 // 0000005AB834: 7EB20B59
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB838: BF870112
	v_mul_f32_e32 v73, v99, v73                                // 0000005AB83C: 10929363
	v_mul_f32_e32 v89, v99, v89                                // 0000005AB840: 10B2B363
	v_and_or_b32 v90, v70, 48, v96                             // 0000005AB844: D657005A 05816146
	global_load_b128 v[67:70], v[71:72], off                   // 0000005AB84C: DC5E0000 437C0047
	v_subrev_nc_u32_e32 v90, 32, v90                           // 0000005AB854: 4EB4B4A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005AB858: BF870091
	v_cvt_f32_i32_e32 v90, v90                                 // 0000005AB85C: 7EB40B5A
	v_dual_mul_f32 v90, v99, v90 :: v_dual_lshlrev_b32 v65, 4, v77// 0000005AB860: C8E2B563 5A409A84
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AB868: BF870001
	v_and_or_b32 v77, v65, 48, v91                             // 0000005AB86C: D657004D 056D6141
	v_bfe_u32 v91, v79, 16, 1                                  // 0000005AB874: D610005B 0205214F
	global_load_b128 v[63:66], v[63:64], off offset:16         // 0000005AB87C: DC5E0010 3F7C003F
	v_subrev_nc_u32_e32 v77, 32, v77                           // 0000005AB884: 4E9A9AA0
	v_add3_u32 v79, v79, v91, 0x7fff                           // 0000005AB888: D655004F 03FEB74F 00007FFF
	v_bfe_u32 v91, v80, 16, 1                                  // 0000005AB894: D610005B 02052150
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005AB89C: BF870113
	v_cvt_f32_i32_e32 v77, v77                                 // 0000005AB8A0: 7E9A0B4D
	v_add3_u32 v91, v80, v91, 0x7fff                           // 0000005AB8A4: D655005B 03FEB750 00007FFF
	v_bfe_u32 v80, v85, 16, 1                                  // 0000005AB8B0: D6100050 02052155
	.long 0x7eb639cf                                           // 0000005AB8B8: 7EB639CF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005AB8BC: BF870224
	v_mul_f32_e32 v77, v99, v77                                // 0000005AB8C0: 109A9B63
	.long 0xd700004f                                           // 0000005AB8C4: D700004F
	v_cndmask_b32_e32 v0, v71, v4, vcc_lo                      // 0000005AB8C8: 02000947
	v_add3_u32 v85, v85, v80, 0x7fff                           // 0000005AB8CC: D6550055 03FEA155 00007FFF
	v_bfe_u32 v80, v86, 16, 1                                  // 0000005AB8D8: D6100050 02052156
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005AB8E0: BF870004
	v_bfe_u32 v93, v77, 16, 1                                  // 0000005AB8E4: D610005D 0205214D
	v_dot2_f32_bf16 v27, v27, v91, 0                           // 0000005AB8EC: CC1A401B 1A02B71B
	v_dot2_f32_bf16 v39, v39, v91, 0                           // 0000005AB8F4: CC1A4027 1A02B727
	v_dot2_f32_bf16 v47, v47, v91, 0                           // 0000005AB8FC: CC1A402F 1A02B72F
	v_add3_u32 v86, v86, v80, 0x7fff                           // 0000005AB904: D6550056 03FEA156 00007FFF
	v_bfe_u32 v80, v87, 16, 1                                  // 0000005AB910: D6100050 02052157
	.long 0x7eac39d5                                           // 0000005AB918: 7EAC39D5
	v_add3_u32 v93, v77, v93, 0x7fff                           // 0000005AB91C: D655005D 03FEBB4D 00007FFF
	v_bfe_u32 v77, v78, 16, 1                                  // 0000005AB928: D610004D 0205214E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005AB930: BF870004
	v_add3_u32 v87, v87, v80, 0x7fff                           // 0000005AB934: D6550057 03FEA157 00007FFF
	v_bfe_u32 v80, v88, 16, 1                                  // 0000005AB940: D6100050 02052158
	v_dot2_f32_bf16 v27, v28, v86, v27                         // 0000005AB948: CC1A401B 1C6EAD1C
	v_dot2_f32_bf16 v39, v40, v86, v39                         // 0000005AB950: CC1A4027 1C9EAD28
	v_add3_u32 v94, v78, v77, 0x7fff                           // 0000005AB958: D655005E 03FE9B4E 00007FFF
	v_bfe_u32 v78, v82, 16, 1                                  // 0000005AB964: D610004E 02052152
	v_add3_u32 v88, v88, v80, 0x7fff                           // 0000005AB96C: D6550058 03FEA158 00007FFF
	v_bfe_u32 v80, v73, 16, 1                                  // 0000005AB978: D6100050 02052149
	.long 0x7eb039d7                                           // 0000005AB980: 7EB039D7
	v_bfe_u32 v77, v81, 16, 1                                  // 0000005AB984: D610004D 02052151
	v_add3_u32 v95, v82, v78, 0x7fff                           // 0000005AB98C: D655005F 03FE9D52 00007FFF
	v_bfe_u32 v78, v89, 16, 1                                  // 0000005AB998: D610004E 02052159
	v_add3_u32 v73, v73, v80, 0x7fff                           // 0000005AB9A0: D6550049 03FEA149 00007FFF
	v_bfe_u32 v80, v74, 16, 1                                  // 0000005AB9AC: D6100050 0205214A
	v_dot2_f32_bf16 v27, v29, v88, v27                         // 0000005AB9B4: CC1A401B 1C6EB11D
	v_dot2_f32_bf16 v39, v41, v88, v39                         // 0000005AB9BC: CC1A4027 1C9EB129
	v_add3_u32 v89, v89, v78, 0x7fff                           // 0000005AB9C4: D6550059 03FE9D59 00007FFF
	v_bfe_u32 v78, v90, 16, 1                                  // 0000005AB9D0: D610004E 0205215A
	v_add3_u32 v92, v74, v80, 0x7fff                           // 0000005AB9D8: D655005C 03FEA14A 00007FFF
	v_add_co_ci_u32_e64 v80, null, s5, v72, s0                 // 0000005AB9E4: D5207C50 00029005
	.long 0x7eb839c9                                           // 0000005AB9EC: 7EB839C9
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005AB9F0: BF870004
	v_add3_u32 v90, v90, v78, 0x7fff                           // 0000005AB9F4: D655005A 03FE9D5A 00007FFF
	v_bfe_u32 v78, v83, 16, 1                                  // 0000005ABA00: D610004E 02052153
	v_add3_u32 v77, v81, v77, 0x7fff                           // 0000005ABA08: D655004D 03FE9B51 00007FFF
	global_load_b128 v[71:74], v[71:72], off offset:16         // 0000005ABA14: DC5E0010 477C0047
	v_dot2_f32_bf16 v85, v30, v92, v27                         // 0000005ABA1C: CC1A4055 1C6EB91E
	global_load_b128 v[27:30], v[75:76], off                   // 0000005ABA24: DC5E0000 1B7C004B
	v_dot2_f32_bf16 v87, v42, v92, v39                         // 0000005ABA2C: CC1A4057 1C9EB92A
	global_load_b128 v[39:42], v[79:80], off                   // 0000005ABA34: DC5E0000 277C004F
	v_add3_u32 v81, v83, v78, 0x7fff                           // 0000005ABA3C: D6550051 03FE9D53 00007FFF
	v_bfe_u32 v78, v84, 16, 1                                  // 0000005ABA48: D610004E 02052154
	.long 0x7ebe39cd                                           // 0000005ABA50: 7EBE39CD
	v_dot2_f32_bf16 v47, v48, v86, v47                         // 0000005ABA54: CC1A402F 1CBEAD30
	.long 0x7ebc39dd                                           // 0000005ABA5C: 7EBC39DD
	.long 0x7eb439d9                                           // 0000005ABA60: 7EB439D9
	v_add3_u32 v83, v84, v78, 0x7fff                           // 0000005ABA64: D6550053 03FE9D54 00007FFF
	global_load_b128 v[75:78], v[75:76], off offset:16         // 0000005ABA70: DC5E0010 4B7C004B
	.long 0x7ea639d1                                           // 0000005ABA78: 7EA639D1
	global_load_b128 v[79:82], v[79:80], off offset:16         // 0000005ABA7C: DC5E0010 4F7C004F
	v_dot2_f32_bf16 v47, v49, v88, v47                         // 0000005ABA84: CC1A402F 1CBEB131
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005ABA8C: BF8700B1
	v_dot2_f32_bf16 v47, v50, v92, v47                         // 0000005ABA90: CC1A402F 1CBEB932
	s_waitcnt vmcnt(9)                                         // 0000005ABA98: BF8927F7
	v_dot2_f32_bf16 v35, v35, v91, 0                           // 0000005ABA9C: CC1A4023 1A02B723
	v_dot2_f32_bf16 v35, v36, v86, v35                         // 0000005ABAA4: CC1A4023 1C8EAD24
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005ABAAC: BF8700B1
	v_dot2_f32_bf16 v35, v37, v88, v35                         // 0000005ABAB0: CC1A4023 1C8EB125
	s_waitcnt vmcnt(7)                                         // 0000005ABAB8: BF891FF7
	v_dot2_f32_bf16 v48, v59, v91, 0                           // 0000005ABABC: CC1A4030 1A02B73B
	v_dot2_f32_bf16 v36, v60, v86, v48                         // 0000005ABAC4: CC1A4024 1CC2AD3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005ABACC: BF8700B1
	v_dot2_f32_bf16 v36, v61, v88, v36                         // 0000005ABAD0: CC1A4024 1C92B13D
	s_waitcnt vmcnt(6)                                         // 0000005ABAD8: BF891BF7
	v_dot2_f32_bf16 v49, v67, v91, 0                           // 0000005ABADC: CC1A4031 1A02B743
	v_dot2_f32_bf16 v48, v68, v86, v49                         // 0000005ABAE4: CC1A4030 1CC6AD44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005ABAEC: BF870151
	v_dot2_f32_bf16 v37, v69, v88, v48                         // 0000005ABAF0: CC1A4025 1CC2B145
	s_waitcnt vmcnt(3)                                         // 0000005ABAF8: BF890FF7
	v_dot2_f32_bf16 v27, v27, v91, 0                           // 0000005ABAFC: CC1A401B 1A02B71B
	s_waitcnt vmcnt(2)                                         // 0000005ABB04: BF890BF7
	v_dot2_f32_bf16 v39, v39, v91, 0                           // 0000005ABB08: CC1A4027 1A02B727
	v_dot2_f32_bf16 v27, v28, v86, v27                         // 0000005ABB10: CC1A401B 1C6EAD1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005ABB18: BF870112
	v_dot2_f32_bf16 v28, v40, v86, v39                         // 0000005ABB1C: CC1A401C 1C9EAD28
	v_dot2_f32_bf16 v27, v29, v88, v27                         // 0000005ABB24: CC1A401B 1C6EB11D
	v_dot2_f32_bf16 v29, v38, v92, v35                         // 0000005ABB2C: CC1A401D 1C8EB926
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005ABB34: BF870003
	v_dot2_f32_bf16 v28, v41, v88, v28                         // 0000005ABB38: CC1A401C 1C72B129
	v_dot2_f32_bf16 v35, v62, v92, v36                         // 0000005ABB40: CC1A4023 1C92B93E
	v_dot2_f32_bf16 v36, v70, v92, v37                         // 0000005ABB48: CC1A4024 1C96B946
	v_dot2_f32_bf16 v27, v30, v92, v27                         // 0000005ABB50: CC1A401B 1C6EB91E
	v_dot2_f32_bf16 v29, v55, v94, v29                         // 0000005ABB58: CC1A401D 1C76BD37
	v_dot2_f32_bf16 v28, v42, v92, v28                         // 0000005ABB60: CC1A401C 1C72B92A
	v_dot2_f32_bf16 v30, v31, v94, v85                         // 0000005ABB68: CC1A401E 1D56BD1F
	v_dot2_f32_bf16 v31, v43, v94, v87                         // 0000005ABB70: CC1A401F 1D5EBD2B
	v_dot2_f32_bf16 v37, v51, v94, v47                         // 0000005ABB78: CC1A4025 1CBEBD33
	v_dot2_f32_bf16 v35, v63, v94, v35                         // 0000005ABB80: CC1A4023 1C8EBD3F
	v_dot2_f32_bf16 v36, v71, v94, v36                         // 0000005ABB88: CC1A4024 1C92BD47
	s_waitcnt vmcnt(1)                                         // 0000005ABB90: BF8907F7
	v_dot2_f32_bf16 v27, v75, v94, v27                         // 0000005ABB94: CC1A401B 1C6EBD4B
	s_waitcnt vmcnt(0)                                         // 0000005ABB9C: BF8903F7
	v_dot2_f32_bf16 v28, v79, v94, v28                         // 0000005ABBA0: CC1A401C 1C72BD4F
	v_dot2_f32_bf16 v29, v56, v95, v29                         // 0000005ABBA8: CC1A401D 1C76BF38
	v_dot2_f32_bf16 v30, v32, v95, v30                         // 0000005ABBB0: CC1A401E 1C7ABF20
	v_dot2_f32_bf16 v31, v44, v95, v31                         // 0000005ABBB8: CC1A401F 1C7EBF2C
	v_dot2_f32_bf16 v32, v52, v95, v37                         // 0000005ABBC0: CC1A4020 1C96BF34
	v_dot2_f32_bf16 v35, v64, v95, v35                         // 0000005ABBC8: CC1A4023 1C8EBF40
	v_dot2_f32_bf16 v36, v72, v95, v36                         // 0000005ABBD0: CC1A4024 1C92BF48
	v_dot2_f32_bf16 v27, v76, v95, v27                         // 0000005ABBD8: CC1A401B 1C6EBF4C
	v_dot2_f32_bf16 v28, v80, v95, v28                         // 0000005ABBE0: CC1A401C 1C72BF50
	v_dot2_f32_bf16 v29, v57, v90, v29                         // 0000005ABBE8: CC1A401D 1C76B539
	v_dot2_f32_bf16 v30, v33, v90, v30                         // 0000005ABBF0: CC1A401E 1C7AB521
	v_dot2_f32_bf16 v31, v45, v90, v31                         // 0000005ABBF8: CC1A401F 1C7EB52D
	v_dot2_f32_bf16 v32, v53, v90, v32                         // 0000005ABC00: CC1A4020 1C82B535
	v_dot2_f32_bf16 v33, v65, v90, v35                         // 0000005ABC08: CC1A4021 1C8EB541
	v_dot2_f32_bf16 v35, v73, v90, v36                         // 0000005ABC10: CC1A4023 1C92B549
	v_dot2_f32_bf16 v27, v77, v90, v27                         // 0000005ABC18: CC1A401B 1C6EB54D
	v_dot2_f32_bf16 v28, v81, v90, v28                         // 0000005ABC20: CC1A401C 1C72B551
	v_dot2_f32_bf16 v29, v58, v83, v29                         // 0000005ABC28: CC1A401D 1C76A73A
	v_add_nc_u32_e32 v26, 16, v26                              // 0000005ABC30: 4A343490
	v_dot2_f32_bf16 v30, v34, v83, v30                         // 0000005ABC34: CC1A401E 1C7AA722
	v_dot2_f32_bf16 v31, v46, v83, v31                         // 0000005ABC3C: CC1A401F 1C7EA72E
	v_dot2_f32_bf16 v32, v54, v83, v32                         // 0000005ABC44: CC1A4020 1C82A736
	v_dot2_f32_bf16 v33, v66, v83, v33                         // 0000005ABC4C: CC1A4021 1C86A742
	v_dot2_f32_bf16 v34, v74, v83, v35                         // 0000005ABC54: CC1A4022 1C8EA74A
	v_dot2_f32_bf16 v27, v78, v83, v27                         // 0000005ABC5C: CC1A401B 1C6EA74E
	v_dot2_f32_bf16 v28, v82, v83, v28                         // 0000005ABC64: CC1A401C 1C72A752
	v_add_f32_e32 v13, v13, v29                                // 0000005ABC6C: 061A3B0D
	.long 0xd4430000                                           // 0000005ABC70: D4430000
	v_cndmask_b32_e32 v1, s14, v26, vcc_lo                     // 0000005ABC74: 0202340E
	v_add_nc_u32_e32 v5, 0x100, v5                             // 0000005ABC78: 4A0A0AFF 00000100
	v_dual_add_f32 v15, v15, v30 :: v_dual_add_f32 v10, v10, v33// 0000005ABC80: C9083D0F 0F0A430A
	v_add_f32_e32 v14, v14, v31                                // 0000005ABC88: 061C3F0E
	v_dual_add_f32 v12, v12, v32 :: v_dual_add_f32 v11, v11, v34// 0000005ABC8C: C908410C 0C0A450B
	v_dual_add_f32 v9, v9, v27 :: v_dual_add_f32 v8, v8, v28   // 0000005ABC94: C9083709 09083908
	s_or_b32 s3, s0, s3                                        // 0000005ABC9C: 8C030300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005ABCA0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000005ABCA4: 917E037E
	s_cbranch_execnz 65000                                     // 0000005ABCA8: BFA6FDE8 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi16ELi1ELb0EEEvPKhPKtPvll+0x14c>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005ABCAC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005ABCB0: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005ABCB4: 8C7E017E
	.long 0xd71f0000                                           // 0000005ABCB8: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005ABCBC: 020100C1
	v_xor_b32_e32 v3, 8, v0                                    // 0000005ABCC0: 3A060088
	v_xor_b32_e32 v20, 4, v0                                   // 0000005ABCC4: 3A280084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005ABCC8: BF870092
	.long 0xd44c0000                                           // 0000005ABCCC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000005ABCD0: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000005ABCD4: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005ABCDC: BF870113
	.long 0xd44c0000                                           // 0000005ABCE0: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000005ABCE4: 020228A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000005ABCE8: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005ABCEC: BF870002
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000005ABCF0: D5010014 00022900
	ds_bpermute_b32 v4, v3, v14                                // 0000005ABCF8: DACC0000 04000E03
	s_waitcnt lgkmcnt(0)                                       // 0000005ABD00: BF89FC07
	v_add_f32_e32 v4, v14, v4                                  // 0000005ABD04: 0608090E
	ds_bpermute_b32 v5, v3, v15                                // 0000005ABD08: DACC0000 05000F03
	ds_bpermute_b32 v6, v3, v13                                // 0000005ABD10: DACC0000 06000D03
	ds_bpermute_b32 v17, v3, v11                               // 0000005ABD18: DACC0000 11000B03
	ds_bpermute_b32 v16, v3, v12                               // 0000005ABD20: DACC0000 10000C03
	ds_bpermute_b32 v18, v3, v10                               // 0000005ABD28: DACC0000 12000A03
	ds_bpermute_b32 v19, v3, v8                                // 0000005ABD30: DACC0000 13000803
	ds_bpermute_b32 v3, v3, v9                                 // 0000005ABD38: DACC0000 03000903
	s_waitcnt lgkmcnt(6)                                       // 0000005ABD40: BF89FC67
	v_dual_add_f32 v5, v15, v5 :: v_dual_lshlrev_b32 v20, 2, v20// 0000005ABD44: C9220B0F 05142882
	s_waitcnt lgkmcnt(4)                                       // 0000005ABD4C: BF89FC47
	v_dual_add_f32 v6, v13, v6 :: v_dual_add_f32 v11, v11, v17 // 0000005ABD50: C9080D0D 060A230B
	s_waitcnt lgkmcnt(3)                                       // 0000005ABD58: BF89FC37
	v_add_f32_e32 v12, v12, v16                                // 0000005ABD5C: 0618210C
	ds_bpermute_b32 v13, v20, v5                               // 0000005ABD60: DACC0000 0D000514
	s_waitcnt lgkmcnt(3)                                       // 0000005ABD68: BF89FC37
	v_add_f32_e32 v10, v10, v18                                // 0000005ABD6C: 0614250A
	ds_bpermute_b32 v16, v20, v11                              // 0000005ABD70: DACC0000 10000B14
	s_waitcnt lgkmcnt(3)                                       // 0000005ABD78: BF89FC37
	v_add_f32_e32 v8, v8, v19                                  // 0000005ABD7C: 06102708
	s_waitcnt lgkmcnt(2)                                       // 0000005ABD80: BF89FC27
	v_add_f32_e32 v3, v9, v3                                   // 0000005ABD84: 06060709
	ds_bpermute_b32 v9, v20, v4                                // 0000005ABD88: DACC0000 09000414
	ds_bpermute_b32 v14, v20, v6                               // 0000005ABD90: DACC0000 0E000614
	ds_bpermute_b32 v15, v20, v12                              // 0000005ABD98: DACC0000 0F000C14
	ds_bpermute_b32 v19, v20, v3                               // 0000005ABDA0: DACC0000 13000314
	s_waitcnt lgkmcnt(5)                                       // 0000005ABDA8: BF89FC57
	v_add_f32_e32 v5, v5, v13                                  // 0000005ABDAC: 060A1B05
	ds_bpermute_b32 v17, v20, v10                              // 0000005ABDB0: DACC0000 11000A14
	s_waitcnt lgkmcnt(5)                                       // 0000005ABDB8: BF89FC57
	v_add_f32_e32 v13, v11, v16                                // 0000005ABDBC: 061A210B
	ds_bpermute_b32 v18, v20, v8                               // 0000005ABDC0: DACC0000 12000814
	v_xor_b32_e32 v20, 2, v0                                   // 0000005ABDC8: 3A280082
	s_waitcnt lgkmcnt(5)                                       // 0000005ABDCC: BF89FC57
	v_add_f32_e32 v4, v4, v9                                   // 0000005ABDD0: 06081304
	s_waitcnt lgkmcnt(3)                                       // 0000005ABDD4: BF89FC37
	v_add_f32_e32 v9, v12, v15                                 // 0000005ABDD8: 06121F0C
	v_xor_b32_e32 v15, 1, v0                                   // 0000005ABDDC: 3A1E0081
	.long 0xd44c0000                                           // 0000005ABDE0: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000005ABDE4: 020228A0
	s_waitcnt lgkmcnt(2)                                       // 0000005ABDE8: BF89FC27
	v_dual_add_f32 v3, v3, v19 :: v_dual_add_f32 v6, v6, v14   // 0000005ABDEC: C9082703 03061D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005ABDF4: BF870122
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000005ABDF8: D5010014 00022900
	.long 0xd44c0000                                           // 0000005ABE00: D44C0000
	v_cndmask_b32_e32 v1, 32, v15, vcc_lo                      // 0000005ABE04: 02021EA0
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000005ABE08: 30282882
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005ABE0C: BF870002
	v_cndmask_b32_e64 v0, v0, v15, s0                          // 0000005ABE10: D5010000 00021F00
	s_waitcnt lgkmcnt(1)                                       // 0000005ABE18: BF89FC17
	v_add_f32_e32 v10, v10, v17                                // 0000005ABE1C: 0614230A
	.long 0xd44a0000                                           // 0000005ABE20: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 0000005ABE24: 02020E80
	s_waitcnt lgkmcnt(0)                                       // 0000005ABE28: BF89FC07
	v_add_f32_e32 v14, v8, v18                                 // 0000005ABE2C: 061C2508
	ds_bpermute_b32 v8, v20, v4                                // 0000005ABE30: DACC0000 08000414
	ds_bpermute_b32 v11, v20, v5                               // 0000005ABE38: DACC0000 0B000514
	ds_bpermute_b32 v17, v20, v9                               // 0000005ABE40: DACC0000 11000914
	ds_bpermute_b32 v18, v20, v13                              // 0000005ABE48: DACC0000 12000D14
	ds_bpermute_b32 v19, v20, v10                              // 0000005ABE50: DACC0000 13000A14
	v_lshlrev_b32_e32 v22, 2, v0                               // 0000005ABE58: 302C0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000005ABE5C: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 0000005ABE60: BF89FC47
	v_add_f32_e32 v15, v4, v8                                  // 0000005ABE64: 061E1104
	ds_bpermute_b32 v12, v20, v6                               // 0000005ABE68: DACC0000 0C000614
	s_waitcnt lgkmcnt(0)                                       // 0000005ABE70: BF89FC07
	v_dual_add_f32 v16, v5, v11 :: v_dual_add_f32 v11, v6, v12 // 0000005ABE74: C9081705 100A1906
	ds_bpermute_b32 v21, v20, v14                              // 0000005ABE7C: DACC0000 15000E14
	ds_bpermute_b32 v20, v20, v3                               // 0000005ABE84: DACC0000 14000314
	v_add_f32_e32 v12, v9, v17                                 // 0000005ABE8C: 06182309
	v_add_f32_e32 v6, v13, v18                                 // 0000005ABE90: 060C250D
	ds_bpermute_b32 v17, v22, v16                              // 0000005ABE94: DACC0000 11001016
	ds_bpermute_b32 v18, v22, v15                              // 0000005ABE9C: DACC0000 12000F16
	ds_bpermute_b32 v13, v22, v11                              // 0000005ABEA4: DACC0000 0D000B16
	s_waitcnt lgkmcnt(3)                                       // 0000005ABEAC: BF89FC37
	v_dual_add_f32 v0, v14, v21 :: v_dual_add_f32 v3, v3, v20  // 0000005ABEB0: C9082B0E 00022903
	v_add_f32_e32 v8, v10, v19                                 // 0000005ABEB8: 0610270A
	ds_bpermute_b32 v14, v22, v12                              // 0000005ABEBC: DACC0000 0E000C16
	ds_bpermute_b32 v10, v22, v6                               // 0000005ABEC4: DACC0000 0A000616
	ds_bpermute_b32 v5, v22, v0                                // 0000005ABECC: DACC0000 05000016
	ds_bpermute_b32 v4, v22, v3                                // 0000005ABED4: DACC0000 04000316
	ds_bpermute_b32 v9, v22, v8                                // 0000005ABEDC: DACC0000 09000816
	s_and_saveexec_b32 s1, s0                                  // 0000005ABEE4: BE812000
	s_cbranch_execz 116                                        // 0000005ABEE8: BFA50074 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi8ELi16ELi1ELb0EEEvPKhPKtPvll+0xdbc>
	s_waitcnt lgkmcnt(6)                                       // 0000005ABEEC: BF89FC67
	v_add_f32_e32 v7, v15, v18                                 // 0000005ABEF0: 060E250F
	v_add_f32_e32 v15, v16, v17                                // 0000005ABEF4: 061E2310
	.long 0x7f223880                                           // 0000005ABEF8: 7F223880
	.long 0xd73c0001                                           // 0000005ABEFC: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005ABF00: 02020281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000005ABF04: 8480810C
	.long 0x7e223987                                           // 0000005ABF08: 7E223987
	.long 0x7e20398f                                           // 0000005ABF0C: 7E20398F
	.long 0x7f203991                                           // 0000005ABF10: 7F203991
	s_waitcnt lgkmcnt(4)                                       // 0000005ABF14: BF89FC47
	v_dual_add_f32 v14, v12, v14 :: v_dual_add_f32 v13, v11, v13// 0000005ABF18: C9081D0C 0E0C1B0B
	v_and_b32_e32 v18, 1, v17                                  // 0000005ABF20: 36242281
	.long 0xd7006a01                                           // 0000005ABF24: D7006A01
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000005ABF28: 02020208
	v_and_b32_e32 v16, 1, v16                                  // 0000005ABF2C: 36202081
	v_add_co_ci_u32_e64 v2, null, s9, v2, vcc_lo               // 0000005ABF30: D5207C02 01AA0409
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005ABF38: BF870224
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000005ABF3C: D6550007 03FE2507 00007FFF
	.long 0x7e22398d                                           // 0000005ABF48: 7E22398D
	v_add3_u32 v18, v15, v16, 0x7fff                           // 0000005ABF4C: D6550012 03FE210F 00007FFF
	.long 0xd7006a0f                                           // 0000005ABF58: D7006A0F
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000005ABF5C: 02000101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005ABF60: BF870001
	v_add_co_ci_u32_e64 v16, null, s1, v2, vcc_lo              // 0000005ABF64: D5207C10 01AA0401
	s_clause 0x1                                               // 0000005ABF6C: BF850001
	global_store_d16_hi_b16 v[1:2], v18, off                   // 0000005ABF70: DC960000 007C1201
	global_store_d16_hi_b16 v[15:16], v7, off                  // 0000005ABF78: DC960000 007C070F
	.long 0x7e0e398e                                           // 0000005ABF80: 7E0E398E
	.long 0x7f0e3991                                           // 0000005ABF84: 7F0E3991
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005ABF88: 8480820C
	s_waitcnt lgkmcnt(3)                                       // 0000005ABF8C: BF89FC37
	v_add_f32_e32 v10, v6, v10                                 // 0000005ABF90: 06141506
	.long 0xd7006a0b                                           // 0000005ABF94: D7006A0B
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000005ABF98: 02000101
	v_and_b32_e32 v15, 1, v7                                   // 0000005ABF9C: 361E0E81
	v_add_co_ci_u32_e64 v12, null, s1, v2, vcc_lo              // 0000005ABFA0: D5207C0C 01AA0401
	v_mad_u64_u32 v[6:7], null, s12, 6, v[1:2]                 // 0000005ABFA8: D6FE7C06 04050C0C
	v_and_b32_e32 v1, 1, v17                                   // 0000005ABFB0: 36022281
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005ABFB4: BF870004
	v_add3_u32 v2, v14, v15, 0x7fff                            // 0000005ABFB8: D6550002 03FE1F0E 00007FFF
	.long 0x7f1c3991                                           // 0000005ABFC4: 7F1C3991
	s_waitcnt lgkmcnt(0)                                       // 0000005ABFC8: BF89FC07
	v_add_f32_e32 v9, v8, v9                                   // 0000005ABFCC: 06121308
	.long 0x7e22398a                                           // 0000005ABFD0: 7E22398A
	v_add_f32_e32 v15, v0, v5                                  // 0000005ABFD4: 061E0B00
	global_store_d16_hi_b16 v[11:12], v2, off                  // 0000005ABFD8: DC960000 007C020B
	v_mad_u64_u32 v[7:8], null, s13, 6, v[7:8]                 // 0000005ABFE0: D6FE7C07 041D0C0D
	.long 0x7e1c3989                                           // 0000005ABFE8: 7E1C3989
	v_and_b32_e32 v2, 1, v17                                   // 0000005ABFEC: 36042281
	.long 0x7e22398f                                           // 0000005ABFF0: 7E22398F
	.long 0xd7006a00                                           // 0000005ABFF4: D7006A00
	v_cndmask_b32_e32 v0, v11, v0, vcc_lo                      // 0000005ABFF8: 0200010B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000005ABFFC: BF870254
	v_and_b32_e32 v8, 1, v14                                   // 0000005AC000: 36101C81
	v_add_f32_e32 v14, v3, v4                                  // 0000005AC004: 061C0903
	.long 0x7f083991                                           // 0000005AC008: 7F083991
	v_add3_u32 v13, v13, v1, 0x7fff                            // 0000005AC00C: D655000D 03FE030D 00007FFF
	v_add_co_ci_u32_e64 v1, null, s1, v12, vcc_lo              // 0000005AC018: D5207C01 01AA1801
	.long 0x7e08398e                                           // 0000005AC020: 7E08398E
	v_add3_u32 v10, v10, v2, 0x7fff                            // 0000005AC024: D655000A 03FE050A 00007FFF
	v_add3_u32 v11, v9, v8, 0x7fff                             // 0000005AC030: D655000B 03FE1109 00007FFF
	.long 0xd7006a02                                           // 0000005AC03C: D7006A02
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 0000005AC040: 02000106
	v_and_b32_e32 v8, 1, v17                                   // 0000005AC044: 36102281
	v_and_b32_e32 v9, 1, v4                                    // 0000005AC048: 36120881
	v_add_co_ci_u32_e64 v3, null, s1, v7, vcc_lo               // 0000005AC04C: D5207C03 01AA0E01
	.long 0xd7006a04                                           // 0000005AC054: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000005AC058: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005AC05C: BF870001
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000005AC060: D5207C05 01AA0201
	v_add3_u32 v12, v15, v8, 0x7fff                            // 0000005AC068: D655000C 03FE110F 00007FFF
	.long 0xd7006a08                                           // 0000005AC074: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000005AC078: 02000102
	v_add3_u32 v14, v14, v9, 0x7fff                            // 0000005AC07C: D655000E 03FE130E 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000005AC088: D5207C09 01AA0601
	s_clause 0x4                                               // 0000005AC090: BF850004
	global_store_d16_hi_b16 v[6:7], v13, off                   // 0000005AC094: DC960000 007C0D06
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000005AC09C: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000005AC0A4: DC960000 007C0A02
	global_store_d16_hi_b16 v[4:5], v14, off                   // 0000005AC0AC: DC960000 007C0E04
	global_store_d16_hi_b16 v[8:9], v12, off                   // 0000005AC0B4: DC960000 007C0C08
	s_nop 0                                                    // 0000005AC0BC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000005AC0C0: BFB60003
	s_endpgm                                                   // 0000005AC0C4: BFB00000
		...

