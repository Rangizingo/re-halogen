0000000000f84100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F84100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F84108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F8410C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 000000F84110: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 000000F84114: 362E009F
	.long 0x7f0a3880                                           // 000000F84118: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 000000F8411C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 000000F84120: BF89FC07
	.long 0xd4510000                                           // 000000F84124: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F84128: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F8412C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000F84130: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000F84134: 98158002
	s_add_u32 s0, s4, s16                                      // 000000F84138: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F8413C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000F84140: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000F84144: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000F84148: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8414C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000F84150: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F84154: 30020282
	s_add_u32 s16, s10, s16                                    // 000000F84158: 8010100A
	s_clause 0x1                                               // 000000F8415C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F84160: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F84168: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000F84170: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000F84174: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000F84178: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000F8417C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000F84180: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000F84184: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000F84188: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000F8418C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000F84190: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000F84194: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000F8419C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000F841A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000F841A4: B3900801
	.long 0xd72c0001                                           // 000000F841A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 000000F841AC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 000000F841B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F841B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 000000F841B8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 000000F841BC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 000000F841C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000F841C4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 000000F841C8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 000000F841CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F841D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000F841D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000F841D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000F841DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000F841E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 000000F841E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000F841F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000F841FC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F84200: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000F84204: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000F84210: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F84214: 02023318
	.long 0x7e0a3982                                           // 000000F84218: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F8421C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 000000F84220: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000F84224: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 000000F84230: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 000000F84238: BF89FC07
	s_barrier                                                  // 000000F8423C: BFBD0000
	buffer_gl0_inv                                             // 000000F84240: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000F84248: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000F8424C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000F84254: BE912001
	s_cbranch_execz 11                                         // 000000F84258: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000F8425C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84260: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000F84264: 3408029F
	.long 0xd7006a03                                           // 000000F84268: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000F8426C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 000000F84270: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000F84278: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000F84280: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F84284: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F84288: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000F8428C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 000000F84290: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84294: BF870001
	.long 0xd4c1007e                                           // 000000F84298: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 000000F8429C: 02023303
	s_cbranch_execz 11                                         // 000000F842A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000F842A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F842A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000F842AC: 3406049F
	.long 0xd7006a02                                           // 000000F842B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000F842B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 000000F842B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 000000F842C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000F842C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F842CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F842D0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 000000F842D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 000000F842DC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000F842E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F842E4: BF870002
	.long 0xd4c1007e                                           // 000000F842E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F842EC: 02023305
	s_cbranch_execz 11                                         // 000000F842F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000F842F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F842F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000F842FC: 340C069F
	.long 0xd7006a05                                           // 000000F84300: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000F84304: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000F84308: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 000000F84310: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000F84318: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F8431C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F84320: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000F84324: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000F8432C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84330: BF870001
	.long 0xd4c1007e                                           // 000000F84334: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000F84338: 02023305
	s_cbranch_execz 11                                         // 000000F8433C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000F84340: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84344: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000F84348: 340A089F
	.long 0xd7006a04                                           // 000000F8434C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000F84350: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000F84354: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000F8435C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000F84364: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F84368: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8436C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 000000F84370: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000F8437C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000F84380: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F84384: BF870002
	.long 0xd4c1007e                                           // 000000F84388: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F8438C: 02023307
	s_cbranch_execz 11                                         // 000000F84390: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000F84394: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84398: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 000000F8439C: 34100A9F
	.long 0xd7006a07                                           // 000000F843A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000F843A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 000000F843A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 000000F843B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 000000F843B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F843BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F843C0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 000000F843C4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000F843CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F843D0: BF870001
	.long 0xd4c1007e                                           // 000000F843D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000F843D8: 02023307
	s_cbranch_execz 11                                         // 000000F843DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 000000F843E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F843E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000F843E8: 340E0C9F
	.long 0xd7006a06                                           // 000000F843EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 000000F843F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000F843F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000F843FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000F84404: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F84408: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F8440C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 000000F84410: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000F8441C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000F84420: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F84424: BF870002
	.long 0xd4c1007e                                           // 000000F84428: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F8442C: 02023309
	s_cbranch_execz 11                                         // 000000F84430: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000F84434: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84438: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 000000F8443C: 34140E9F
	.long 0xd7006a09                                           // 000000F84440: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000F84444: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 000000F84448: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 000000F84450: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000F84458: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F8445C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F84460: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 000000F84464: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000F8446C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84470: BF870001
	.long 0xd4c1007e                                           // 000000F84474: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000F84478: 02023309
	s_cbranch_execz 11                                         // 000000F8447C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000F84480: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84484: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000F84488: 3412109F
	.long 0xd7006a08                                           // 000000F8448C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000F84490: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 000000F84494: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 000000F8449C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 000000F844A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000F844A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F844AC: 8C7E017E
	s_branch 9                                                 // 000000F844B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 000000F844B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F844B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000F844BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000F844C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000F844C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000F844C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000F844CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000F844D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000F844D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000F844D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000F844DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000F844E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v10, 0            // 000000F844E4: CA100015 090A0080
	s_add_u32 s14, s10, s1                                     // 000000F844EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000F844F0: 820F800B
	.long 0xd4410001                                           // 000000F844F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F844F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F844FC: 868E810E
	v_mov_b32_e32 v27, 0                                       // 000000F84500: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000F84504: D6FE7C12 00101D09
	.long 0xd72c000b                                           // 000000F8450C: D72C000B
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000F84510: 02001E15
	.long 0xd72c000c                                           // 000000F84514: D72C000C
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000F84518: 02001C14
	v_mov_b32_e32 v9, 0                                        // 000000F8451C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000F84520: D501001C 00410280
	v_mov_b32_e32 v31, 0                                       // 000000F84528: 7E3E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F8452C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 000000F84530: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000F84538: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 000000F84540: BE842001
	s_cbranch_execz 22                                         // 000000F84544: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000F84548: 30123084
	v_mov_b32_e32 v31, 0                                       // 000000F8454C: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F84550: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000F84554: 3414129F
	.long 0xd7006a09                                           // 000000F84558: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000F8455C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000F84560: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000F84568: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000F8456C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 000000F84574: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000F84578: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8457C: BF870091
	.long 0xd7006a0d                                           // 000000F84580: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 000000F84584: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000F84588: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000F84590: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 000000F84598: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 000000F8459C: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F845A0: 8C7E047E
	v_mov_b32_e32 v30, 0                                       // 000000F845A4: 7E3C0280
	s_and_saveexec_b32 s14, s1                                 // 000000F845A8: BE8E2001
	s_cbranch_execz 290                                        // 000000F845AC: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 000000F845B0: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 000000F845B8: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F845C0: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 000000F845C4: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 000000F845CC: 30421A81
	s_mov_b32 s15, 0                                           // 000000F845D0: BE8F0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000F845D4: 8484810A
	s_branch 243                                               // 000000F845D8: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x8a8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F845DC: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000F845E0: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 000000F845E4: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 000000F845E8: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 000000F845EC: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 000000F845F4: 328C1486
	.long 0xd73c0023                                           // 000000F845F8: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F845FC: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000F84600: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 000000F84608: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 000000F84610: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000F84618: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 000000F8461C: 328E148E
	.long 0xd7006a3b                                           // 000000F84620: D7006A3B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 000000F84624: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F84628: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s7, v36, vcc_lo             // 000000F8462C: D5207C3C 01AA4807
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000F84634: 30282882
	.long 0xd7006a3f                                           // 000000F84638: D7006A3F
	v_cndmask_b32_e32 v0, v59, v4, vcc_lo                      // 000000F8463C: 0200093B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84640: BF870001
	v_add_co_ci_u32_e64 v64, null, s5, v60, vcc_lo             // 000000F84644: D5207C40 01AA7805
	ds_load_b32 v20, v20                                       // 000000F8464C: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 000000F84654: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 000000F8465C: D8D80000 44000044
	s_clause 0x7                                               // 000000F84664: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 000000F84668: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 000000F84670: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 000000F84678: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 000000F84680: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 000000F84688: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000F84690: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000F84698: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 000000F846A0: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000F846A8: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F846AC: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 000000F846B4: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 000000F846B8: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 000000F846C0: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000F846C8: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 000000F846D0: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 000000F846D8: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 000000F846E0: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 000000F846E8: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 000000F846F0: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 000000F846F8: 4A4040FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 000000F84700: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F84704: BF870009
	s_or_b32 s15, s1, s15                                      // 000000F84708: 8C0F0F01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000F8470C: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 000000F84710: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 000000F84718: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 000000F8471C: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 000000F84724: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000F8472C: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 000000F84730: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F84738: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 000000F8473C: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 000000F84744: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 000000F84748: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000F8474C: 32161696
	s_waitcnt lgkmcnt(5)                                       // 000000F84750: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 000000F84754: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 000000F8475C: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 000000F84764: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 000000F8476C: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 000000F84770: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 000000F84778: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 000000F8477C: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 000000F84784: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 000000F8478C: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 000000F84790: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 000000F84798: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 000000F8479C: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 000000F847A0: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 000000F847A8: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 000000F847AC: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 000000F847B4: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 000000F847BC: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 000000F847C4: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 000000F847CC: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 000000F847D0: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 000000F847D8: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000F847E0: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 000000F847E4: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s0                          // 000000F847EC: D5010029 00021107
	s_waitcnt lgkmcnt(4)                                       // 000000F847F4: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 000000F847F8: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 000000F84800: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000F84808: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 000000F84810: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 000000F84814: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000F8481C: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 000000F84820: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 000000F84828: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000F84830: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 000000F84838: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 000000F84840: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 000000F84848: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 000000F84850: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 000000F84858: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s0                          // 000000F84860: D5010028 00020F06
	v_cndmask_b32_e64 v39, v5, v6, s0                          // 000000F84868: D5010027 00020D05
	v_cndmask_b32_e64 v37, v3, v4, s0                          // 000000F84870: D5010025 00020903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000F84878: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 000000F8487C: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 000000F84884: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 000000F84888: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s0                         // 000000F84890: D5010014 0002031F
	v_cndmask_b32_e64 v35, v1, v2, s0                          // 000000F84898: D5010023 00020501
	v_mov_b32_e32 v31, v34                                     // 000000F848A0: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 000000F848A4: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 000000F848A8: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 000000F848B0: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s0                          // 000000F848B8: D5010024 00020702
	s_waitcnt lgkmcnt(5)                                       // 000000F848C0: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F848C4: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 000000F848C8: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 000000F848D0: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s0                          // 000000F848D8: D5010026 00020B04
	s_waitcnt lgkmcnt(4)                                       // 000000F848E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F848E4: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 000000F848E8: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 000000F848F0: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 000000F848F8: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000F848FC: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F84900: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 000000F84904: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 000000F8490C: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 000000F84910: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 000000F84918: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 000000F84920: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 000000F84924: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 000000F84928: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 000000F84930: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 000000F84938: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000F84940: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 000000F84948: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 000000F8494C: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 000000F84954: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 000000F8495C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F84960: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 000000F84964: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 000000F8496C: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F84974: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 000000F84978: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 000000F8497C: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 000000F84980: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 000000F84988: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 000000F84990: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 000000F84998: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000F849A0: 917E0F7E
	s_cbranch_execz 35                                         // 000000F849A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 000000F849A8: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 000000F849AC: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 000000F849B4: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000F849BC: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F849C0: BF870003
	.long 0xd4460001                                           // 000000F849C4: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F849C8: 02023318
	s_mov_b32 s10, exec_lo                                     // 000000F849CC: BE8A007E
	.long 0xd4c1007e                                           // 000000F849D0: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000F849D4: 02023318
	s_cbranch_execz 65280                                      // 000000F849D8: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v14, 31, v32                             // 000000F849DC: 341C409F
	.long 0xd7006a0d                                           // 000000F849E0: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 000000F849E4: 02024112
	v_mov_b32_e32 v34, v31                                     // 000000F849E8: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F849EC: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 000000F849F0: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000F849F8: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 000000F849FC: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 000000F84A04: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v20, 31, v33                             // 000000F84A08: 3428429F
	.long 0xd7006a22                                           // 000000F84A0C: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 000000F84A10: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84A14: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 000000F84A18: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 000000F84A20: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 000000F84A28: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 000000F84A2C: 7E441714
	s_branch 65258                                             // 000000F84A30: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000F84A34: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F84A38: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000F84A3C: 8C7E0E7E
	.long 0xd71f0001                                           // 000000F84A40: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F84A44: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F84A48: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F84A4C: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 000000F84A50: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 000000F84A54: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F84A58: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F84A5C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F84A60: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000F84A64: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F84A68: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F84A6C: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000F84A70: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000F84A74: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 000000F84A78: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000F84A80: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 000000F84A84: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 000000F84A8C: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 000000F84A94: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000F84A98: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 000000F84A9C: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000F84AA4: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84AA8: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000F84AAC: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 000000F84AB0: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 000000F84AB4: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 000000F84AB8: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 000000F84AC0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000F84AC4: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 000000F84AC8: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 000000F84AD0: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 000000F84AD8: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F84ADC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000F84AE0: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000F84AE4: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 000000F84AE8: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 000000F84AEC: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 000000F84AF4: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000F84AF8: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 000000F84AFC: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 000000F84B04: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 000000F84B0C: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F84B10: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000F84B14: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000F84B18: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 000000F84B1C: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 000000F84B20: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 000000F84B28: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000F84B2C: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 000000F84B30: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 000000F84B38: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v23                                   // 000000F84B40: 7D942E80
	s_cbranch_execz 6                                          // 000000F84B44: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xa60>
	s_waitcnt lgkmcnt(0)                                       // 000000F84B48: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 000000F84B4C: C9220902 02042C83
	v_add_f32_e32 v1, v1, v3                                   // 000000F84B54: 06020701
	ds_store_b64 v5, v[1:2] offset:1024                        // 000000F84B58: D9340400 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F84B60: 8C7E007E
	.long 0xd4510000                                           // 000000F84B64: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F84B68: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 000000F84B6C: 7C980082
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000F84B70: BF890007
	s_barrier                                                  // 000000F84B74: BFBD0000
	buffer_gl0_inv                                             // 000000F84B78: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F84B80: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F84B84: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F84B88: BE812000
	s_cbranch_execz 74                                         // 000000F84B8C: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xbb8>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 000000F84B90: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F84B98: 84808202
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 000000F84B9C: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 000000F84BA4: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 000000F84BAC: D8DC0A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000F84BB4: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000F84BB8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000F84BBC: BF8700C1
	v_add_f32_e32 v8, v1, v2                                   // 000000F84BC0: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:12 offset1:14         // 000000F84BC4: D8DC0E0C 01000007
	s_waitcnt lgkmcnt(2)                                       // 000000F84BCC: BF89FC27
	v_add_f32_e32 v3, v8, v3                                   // 000000F84BD0: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 000000F84BD4: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000F84BD8: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84BDC: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000F84BE0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000F84BE4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000F84BE8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84BEC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000F84BF0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000F84BF4: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84BF8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000F84BFC: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 000000F84C04: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84C08: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000F84C0C: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000F84C10: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000F84C18: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F84C20: BF870292
	v_rcp_f32_e32 v6, v5                                       // 000000F84C24: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000F84C28: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F84C30: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 000000F84C34: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000F84C38: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000F84C40: 10100D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F84C44: BF870112
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000F84C48: D6FE7C02 040A000D
	v_fma_f32 v9, -v5, v8, v7                                  // 000000F84C50: D6130009 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F84C58: BF870191
	v_fmac_f32_e32 v8, v9, v6                                  // 000000F84C5C: 56100D09
	.long 0xd73c0000                                           // 000000F84C60: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000F84C64: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84C68: BF870092
	v_fma_f32 v3, -v5, v8, v7                                  // 000000F84C6C: D6130003 241E1105
	v_div_fmas_f32 v2, v3, v6, v8                              // 000000F84C74: D6370002 04220D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F84C7C: BF870093
	.long 0xd7006a00                                           // 000000F84C80: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F84C84: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000F84C88: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F84C90: BF870193
	v_div_fixup_f32 v2, v2, v4, 1.0                            // 000000F84C94: D6270002 03CA0902
	.long 0xd7006a00                                           // 000000F84C9C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000F84CA0: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F84CA4: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000F84CA8: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 000000F84CB0: DC6A0000 007C0200
	s_endpgm                                                   // 000000F84CB8: BFB00000
		...

