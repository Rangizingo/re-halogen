0000000000595200 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000595200: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000595204: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000059520C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000595214: 32020085
	s_mov_b32 s3, 0                                            // 000000595218: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000059521C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000595224: 84808302
	.long 0x7e383880                                           // 000000595228: 7E383880
	v_or_b32_e32 v9, s0, v1                                    // 00000059522C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000595230: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000595234: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000059523C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000595244: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000595248: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000059524C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000595250: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000595254: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000595258: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000059525C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000595260: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000595264: 02021280
	s_add_u32 s0, s10, s2                                      // 000000595268: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000059526C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000595274: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000595278: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000059527C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000595280: 8B00D000
	.long 0xd72c0003                                           // 000000595284: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000595288: 02000301
	.long 0xd72c0007                                           // 00000059528C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000595290: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000595294: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000059529C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000005952A0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005952A4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 0000005952A8: D6550002 041E0702
	.long 0xd7000112                                           // 0000005952B0: D7000112
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000005952B4: 02020204
	v_mov_b32_e32 v7, 0                                        // 0000005952B8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005952BC: BF870003
	v_add_co_ci_u32_e64 v19, null, s5, v2, s1                  // 0000005952C0: D5207C13 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000005952C8: BE832000
	s_cbranch_execz 21                                         // 0000005952CC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 0000005952D0: 30061E84
	.long 0xd7000105                                           // 0000005952D4: D7000105
	v_cndmask_b32_e32 v0, v18, v10, vcc_lo                     // 0000005952D8: 02001512
	v_and_b32_e32 v7, 30, v0                                   // 0000005952DC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v19, s1                 // 0000005952E0: D5207C06 0006260B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005952E8: BF870094
	.long 0xd7000103                                           // 0000005952EC: D7000103
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000005952F0: 02020712
	v_add_co_ci_u32_e64 v4, null, 0, v19, s1                   // 0000005952F4: D5207C04 00062680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005952FC: BF870094
	.long 0xd700010c                                           // 000000595300: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000595304: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000595308: D5207C0D 00060C80
	s_clause 0x1                                               // 000000595310: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000595314: DC5E0000 047C0003
	global_load_d16_b16 v28, v[12:13], off                     // 00000059531C: DC820000 1C7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000595324: 8C7E037E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v20, 0             // 000000595328: CA100080 11140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000595330: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000595338: CA100080 17180080
	v_mov_b32_e32 v25, 0                                       // 000000595340: 7E320280
	s_and_saveexec_b32 s3, s0                                  // 000000595344: BE832000
	s_cbranch_execz 572                                        // 000000595348: BFA5023C <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0xa3c>
	v_and_or_b32 v0, v0, 30, 32                                // 00000059534C: D6570000 02813D00
	.long 0xd7000001                                           // 000000595354: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000595358: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059535C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 000000595360: D5207C02 0002040B
	v_mov_b32_e32 v12, 0                                       // 000000595368: 7E180280
	.long 0xd7000000                                           // 00000059536C: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000595370: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595374: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000595378: D5207C01 00020480
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v25, v12         // 000000595380: CA10010F 1A18010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595388: BF870093
	.long 0xd700000d                                           // 00000059538C: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000595390: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 000000595394: D5207C0E 00020205
	v_mov_b32_e32 v24, v12                                     // 00000059539C: 7E30030C
	v_mov_b32_e32 v22, v12                                     // 0000005953A0: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 0000005953A4: 7E2E030C
	v_mov_b32_e32 v20, v12                                     // 0000005953A8: 7E28030C
	v_mov_b32_e32 v21, v12                                     // 0000005953AC: 7E2A030C
	v_mov_b32_e32 v17, v12                                     // 0000005953B0: 7E22030C
	v_mov_b32_e32 v16, v12                                     // 0000005953B4: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 0000005953B8: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000005953BC: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000005953C0: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000005953C4: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000005953C8: 9612860A
	s_mov_b32 s17, 0                                           // 0000005953CC: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000005953D0: 8484810A
	s_branch 507                                               // 0000005953D4: BFA001FB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0x9c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000005953D8: 8C7E0A7E
	v_bfe_i32 v29, v4, 0, 8                                    // 0000005953DC: D611001D 02210104
	s_and_b32 s0, exec_lo, s0                                  // 0000005953E4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005953E8: BF870099
	s_or_b32 s17, s0, s17                                      // 0000005953EC: 8C111100
	v_cvt_f32_i32_e32 v29, v29                                 // 0000005953F0: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005953F4: BF870091
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 0000005953F8: CC20001D 8A023B1C
	v_bfe_u32 v30, v29, 16, 1                                  // 000000595400: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595408: BF870121
	v_add3_u32 v29, v29, v30, 0x7fff                           // 00000059540C: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 000000595418: 7F3C3880
	.long 0x7e3c399d                                           // 00000059541C: 7E3C399D
	v_bfe_i32 v29, v4, 8, 8                                    // 000000595420: D611001D 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595428: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 00000059542C: 7E3A0B1D
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 000000595430: CC20001D 8A023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595438: BF870091
	v_bfe_u32 v31, v29, 16, 1                                  // 00000059543C: D610001F 0205211D
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000595444: D655001D 03FE3F1D 00007FFF
	v_bfe_i32 v31, v4, 16, 8                                   // 000000595450: D611001F 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000595458: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059545C: BF870193
	v_and_or_b32 v36, 0xffff0000, v29, v30                     // 000000595460: D6570024 047A3AFF FFFF0000
	v_cvt_f32_i32_e32 v31, v31                                 // 00000059546C: 7E3E0B1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595470: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 000000595474: 7E080B04
	v_fma_mix_f32 v31, v28, v31, neg(0) op_sel_hi:[1,0,0]      // 000000595478: CC20001F 8A023F1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595480: BF870112
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000595484: CC200004 8A02091C
	v_bfe_u32 v32, v31, 16, 1                                  // 00000059548C: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595494: BF870191
	v_add3_u32 v31, v31, v32, 0x7fff                           // 000000595498: D655001F 03FE411F 00007FFF
	v_bfe_u32 v32, v4, 16, 1                                   // 0000005954A4: D6100020 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005954AC: BF8701A2
	.long 0x7e3e399f                                           // 0000005954B0: 7E3E399F
	.long 0x7f3e399e                                           // 0000005954B4: 7F3E399E
	v_add3_u32 v4, v4, v32, 0x7fff                             // 0000005954B8: D6550004 03FE4104 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005954C4: BF8700A1
	v_and_or_b32 v37, 0xffff0000, v4, v31                      // 0000005954C8: D6570025 047E08FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 0000005954D4: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 0000005954DC: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005954E0: BF870091
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 0000005954E4: CC200004 8A02091C
	v_bfe_u32 v29, v4, 16, 1                                   // 0000005954EC: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005954F4: BF870091
	v_add3_u32 v4, v4, v29, 0x7fff                             // 0000005954F8: D6550004 03FE3B04 00007FFF
	.long 0x7e3c3984                                           // 000000595504: 7E3C3984
	v_bfe_i32 v4, v5, 8, 8                                     // 000000595508: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595510: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000595514: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000595518: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595520: BF870091
	v_bfe_u32 v29, v4, 16, 1                                   // 000000595524: D610001D 02052104
	v_add3_u32 v4, v4, v29, 0x7fff                             // 00000059552C: D6550004 03FE3B04 00007FFF
	v_bfe_i32 v29, v5, 16, 8                                   // 000000595538: D611001D 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000595540: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595544: BF870193
	v_and_or_b32 v38, 0xffff0000, v4, v30                      // 000000595548: D6570026 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v29, v29                                 // 000000595554: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000595558: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 00000059555C: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000595560: D6110004 02210106
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 000000595568: CC20001D 8A023B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595570: BF870193
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000595574: CC200005 8A020B1C
	v_cvt_f32_i32_e32 v4, v4                                   // 00000059557C: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595580: BF870113
	v_bfe_u32 v31, v29, 16, 1                                  // 000000595584: D610001F 0205211D
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 00000059558C: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595594: BF870122
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000595598: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v5, 16, 1                                   // 0000005955A4: D610001F 02052105
	.long 0x7e3a399d                                           // 0000005955AC: 7E3A399D
	.long 0x7f3a399e                                           // 0000005955B0: 7F3A399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005955B4: BF870093
	v_add3_u32 v5, v5, v31, 0x7fff                             // 0000005955B8: D6550005 03FE3F05 00007FFF
	v_and_or_b32 v39, 0xffff0000, v5, v29                      // 0000005955C4: D6570027 04760AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000005955D0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005955D8: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000005955DC: D6550004 03FE0B04 00007FFF
	.long 0x7e3c3984                                           // 0000005955E8: 7E3C3984
	v_bfe_i32 v4, v6, 8, 8                                     // 0000005955EC: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005955F4: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000005955F8: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 0000005955FC: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595604: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000595608: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000595610: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 00000059561C: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000595624: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595628: BF870193
	v_and_or_b32 v40, 0xffff0000, v4, v30                      // 00000059562C: D6570028 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000595638: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000059563C: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000595640: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 000000595644: D6110004 02210107
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 00000059564C: CC200005 8A020B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000595654: BF870193
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000595658: CC200006 8A020D1C
	v_cvt_f32_i32_e32 v4, v4                                   // 000000595660: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595664: BF870113
	v_bfe_u32 v29, v5, 16, 1                                   // 000000595668: D610001D 02052105
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000595670: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595678: BF870122
	v_add3_u32 v5, v5, v29, 0x7fff                             // 00000059567C: D6550005 03FE3B05 00007FFF
	v_bfe_u32 v29, v6, 16, 1                                   // 000000595688: D610001D 02052106
	.long 0x7e0a3985                                           // 000000595690: 7E0A3985
	.long 0x7f0a399e                                           // 000000595694: 7F0A399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595698: BF870093
	v_add3_u32 v6, v6, v29, 0x7fff                             // 00000059569C: D6550006 03FE3B06 00007FFF
	v_and_or_b32 v41, 0xffff0000, v6, v5                       // 0000005956A8: D6570029 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000005956B4: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005956BC: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000005956C0: D6550004 03FE0B04 00007FFF
	.long 0x7e3c3984                                           // 0000005956CC: 7E3C3984
	v_bfe_i32 v4, v7, 8, 8                                     // 0000005956D0: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005956D8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000005956DC: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 0000005956E0: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005956E8: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000005956EC: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000005956F4: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 000000595700: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595708: BF870112
	v_and_or_b32 v42, 0xffff0000, v4, v30                      // 00000059570C: D657002A 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000595718: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059571C: BF870091
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000595720: CC200005 8A020B1C
	v_bfe_u32 v6, v5, 16, 1                                    // 000000595728: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595730: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000595734: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000595740: 340C0E98
	.long 0x7e0a3985                                           // 000000595744: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595748: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000059574C: 7E0C0B06
	.long 0x7f0a399e                                           // 000000595750: 7F0A399E
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000595754: CC200006 8A020D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059575C: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000595760: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000595768: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000595774: BF870131
	v_and_or_b32 v43, 0xffff0000, v6, v5                       // 000000595778: D657002B 04160CFF FFFF0000
	.long 0xd73c0004                                           // 000000595784: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000595788: 02021681
	v_mov_b32_e32 v11, v27                                     // 00000059578C: 7E16031B
	.long 0xd7000020                                           // 000000595790: D7000020
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000595794: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000595798: BF870001
	v_add_co_ci_u32_e64 v33, null, s7, v5, s0                  // 00000059579C: D5207C21 00020A07
	s_clause 0x1                                               // 0000005957A4: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000005957A8: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000005957B0: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 0000005957B8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000005957BC: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005957C4: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000005957C8: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000005957D0: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005957D8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000005957DC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000005957E4: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000005957E8: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000005957F0: D700001C
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 0000005957F4: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005957F8: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000005957FC: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s5, v33, s0                 // 000000595804: D5207C1D 00024205
	.long 0xd7000022                                           // 00000059580C: D7000022
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000595810: 02001D20
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595814: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v35, null, s15, v33, s0                // 00000059581C: D5207C23 0002420F
	.long 0xd7000020                                           // 000000595824: D7000020
	v_cndmask_b32_e32 v0, v32, v18, vcc_lo                     // 000000595828: 02002520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000059582C: BF870123
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595830: CC1A4004 1C12571F
	v_add_co_ci_u32_e64 v33, null, s16, v33, s0                // 000000595838: D5207C21 00024210
	v_add_f32_e32 v24, v24, v4                                 // 000000595840: 06300918
	s_clause 0x1                                               // 000000595844: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 000000595848: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000595850: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000595858: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 00000059585C: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595864: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 000000595868: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000595870: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000595878: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 00000059587C: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000595884: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000595888: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595890: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595894: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 00000059589C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005958A4: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000005958A8: CC1A4004 1C12571F
	v_add_f32_e32 v25, v25, v4                                 // 0000005958B0: 06320919
	s_clause 0x1                                               // 0000005958B4: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000005958B8: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000005958C0: DC5E0010 1C7C0022
	.long 0xd7000022                                           // 0000005958C8: D7000022
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 0000005958CC: 02001D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005958D0: BF8700B1
	v_add_co_ci_u32_e64 v35, null, s15, v35, s0                // 0000005958D4: D5207C23 0002460F
	s_waitcnt vmcnt(1)                                         // 0000005958DC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000005958E0: CC1A4004 1A024904
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000005958E8: CC1A4004 1C124B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005958F0: BF870091
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000005958F4: CC1A4004 1C124D06
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000005958FC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000595904: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595908: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000059590C: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595914: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059591C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595920: CC1A4004 1C12551E
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595928: CC1A4004 1C12571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000595930: BF8700D1
	v_add_f32_e32 v22, v22, v4                                 // 000000595934: 062C0916
	s_clause 0x1                                               // 000000595938: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 00000059593C: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000595944: DC5E0010 1C7C0020
	.long 0xd7000020                                           // 00000059594C: D7000020
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000595950: 02001D20
	v_add_co_ci_u32_e64 v33, null, s15, v33, s0                // 000000595954: D5207C21 0002420F
	s_waitcnt vmcnt(1)                                         // 00000059595C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000595960: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595968: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 00000059596C: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000595974: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059597C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000595980: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000595988: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000059598C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595994: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595998: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000005959A0: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005959A8: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000005959AC: CC1A4004 1C12571F
	v_add_f32_e32 v23, v23, v4                                 // 0000005959B4: 062E0917
	s_clause 0x1                                               // 0000005959B8: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000005959BC: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000005959C4: DC5E0010 1C7C0022
	s_waitcnt vmcnt(1)                                         // 0000005959CC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000005959D0: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005959D8: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000005959DC: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000005959E4: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005959EC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000005959F0: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000005959F8: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000005959FC: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595A04: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595A08: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595A10: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595A18: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595A1C: CC1A4004 1C12571F
	v_add_f32_e32 v20, v20, v4                                 // 000000595A24: 06280914
	s_clause 0x1                                               // 000000595A28: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 000000595A2C: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000595A34: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 000000595A3C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000595A40: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595A48: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 000000595A4C: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000595A54: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000595A5C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000595A60: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000595A68: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000595A6C: CC1A4004 1C12511C
	.long 0xd700001c                                           // 000000595A74: D700001C
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 000000595A78: 02001D22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595A7C: BF870122
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595A80: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v35, s0                // 000000595A88: D5207C1D 0002460F
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595A90: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595A98: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595A9C: CC1A4004 1C12571F
	v_add_f32_e32 v21, v21, v4                                 // 000000595AA4: 062A0915
	s_clause 0x1                                               // 000000595AA8: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 000000595AAC: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000595AB4: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000595ABC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000595AC0: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595AC8: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 000000595ACC: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000595AD4: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000595ADC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000595AE0: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000595AE8: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000595AEC: CC1A4004 1C12511C
	.long 0xd700001c                                           // 000000595AF4: D700001C
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000595AF8: 02001D20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000595AFC: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595B00: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v33, s0                // 000000595B08: D5207C1D 0002420F
	.long 0xd700000d                                           // 000000595B10: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000595B14: 0201410D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595B18: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000595B20: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595B28: BF870092
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595B2C: CC1A4004 1C12571F
	v_add_f32_e32 v17, v17, v4                                 // 000000595B34: 06220911
	s_clause 0x1                                               // 000000595B38: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 000000595B3C: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000595B44: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000595B4C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000595B50: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000595B58: BF870121
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 000000595B5C: CC1A4004 1C124B05
	v_mov_b32_e32 v5, v1                                       // 000000595B64: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000595B68: CC1A4004 1C124D06
	v_mov_b32_e32 v6, v2                                       // 000000595B70: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000595B74: BF870132
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000595B78: CC1A4004 1C124F07
	v_mov_b32_e32 v7, v3                                       // 000000595B80: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000595B84: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000595B88: CC1A4004 1C12511C
	.long 0x7e383908                                           // 000000595B90: 7E383908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595B94: BF870092
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000595B98: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000595BA0: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595BA8: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000595BAC: CC1A4004 1C12571F
	v_add_f32_e32 v16, v16, v4                                 // 000000595BB4: 06200910
	v_mov_b32_e32 v4, v0                                       // 000000595BB8: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 000000595BBC: 917E117E
	s_cbranch_execz 29                                         // 000000595BC0: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0xa38>
	v_add_nc_u32_e32 v26, 32, v26                              // 000000595BC4: 4A3434A0
	v_add_nc_u32_e32 v27, 0x200, v11                           // 000000595BC8: 4A3616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000595BD0: BF8704A2
	.long 0xd4430000                                           // 000000595BD4: D4430000
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 000000595BD8: 02023402
	s_and_saveexec_b32 s1, s0                                  // 000000595BDC: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 000000595BE0: 8D01017E
	v_add_nc_u32_e32 v27, 0x200, v11                           // 000000595BE4: 4A3616FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 000000595BEC: BE8A2201
	s_waitcnt vmcnt(0)                                         // 000000595BF0: BF8903F7
	.long 0x7e10391c                                           // 000000595BF4: 7E10391C
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 000000595BF8: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000595C00: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000595C08: 8D7E0A7E
	s_cbranch_execz 65010                                      // 000000595C0C: BFA5FDF2 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0x1d8>
	.long 0xd7000100                                           // 000000595C10: D7000100
	v_cndmask_b32_e32 v1, v18, v27, vcc_lo                     // 000000595C14: 02023712
	s_delay_alu instid0(VALU_DEP_1)                            // 000000595C18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000595C1C: D5207C01 00062680
	global_load_b128 v[0:3], v[0:1], off                       // 000000595C24: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 000000595C2C: DC820000 087C000D
	s_branch 65000                                             // 000000595C34: BFA0FDE8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0x1d8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000595C38: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000595C3C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000595C40: 8C7E037E
	.long 0xd71f0000                                           // 000000595C44: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000595C48: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000595C4C: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 000000595C50: 3A160088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000595C54: BF870092
	.long 0xd44c0000                                           // 000000595C58: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000595C5C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000595C60: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000595C68: BF870113
	.long 0xd44c0000                                           // 000000595C6C: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000595C70: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000595C74: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000595C78: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 000000595C7C: D501000B 00021700
	ds_bpermute_b32 v2, v1, v25                                // 000000595C84: DACC0000 02001901
	s_waitcnt lgkmcnt(0)                                       // 000000595C8C: BF89FC07
	v_add_f32_e32 v2, v25, v2                                  // 000000595C90: 06040519
	s_waitcnt vmcnt(1)                                         // 000000595C94: BF8907F7
	ds_bpermute_b32 v4, v1, v23                                // 000000595C98: DACC0000 04001701
	ds_bpermute_b32 v7, v1, v20                                // 000000595CA0: DACC0000 07001401
	ds_bpermute_b32 v3, v1, v24                                // 000000595CA8: DACC0000 03001801
	ds_bpermute_b32 v5, v1, v22                                // 000000595CB0: DACC0000 05001601
	ds_bpermute_b32 v6, v1, v21                                // 000000595CB8: DACC0000 06001501
	ds_bpermute_b32 v8, v1, v16                                // 000000595CC0: DACC0000 08001001
	ds_bpermute_b32 v1, v1, v17                                // 000000595CC8: DACC0000 01001101
	s_waitcnt lgkmcnt(6)                                       // 000000595CD0: BF89FC67
	v_dual_add_f32 v4, v23, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 000000595CD4: C9220917 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 000000595CDC: DACC0000 0C00020B
	s_waitcnt lgkmcnt(6)                                       // 000000595CE4: BF89FC67
	v_add_f32_e32 v7, v20, v7                                  // 000000595CE8: 060E0F14
	v_xor_b32_e32 v20, 4, v0                                   // 000000595CEC: 3A280084
	s_waitcnt lgkmcnt(3)                                       // 000000595CF0: BF89FC37
	v_dual_add_f32 v3, v24, v3 :: v_dual_add_f32 v6, v21, v6   // 000000595CF4: C9080718 03060D15
	s_waitcnt lgkmcnt(2)                                       // 000000595CFC: BF89FC27
	v_dual_add_f32 v5, v22, v5 :: v_dual_add_f32 v8, v16, v8   // 000000595D00: C9080B16 05081110
	.long 0xd44c0000                                           // 000000595D08: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000595D0C: 020228A0
	s_waitcnt lgkmcnt(1)                                       // 000000595D10: BF89FC17
	v_add_f32_e32 v1, v17, v1                                  // 000000595D14: 06020311
	ds_bpermute_b32 v13, v11, v3                               // 000000595D18: DACC0000 0D00030B
	ds_bpermute_b32 v14, v11, v4                               // 000000595D20: DACC0000 0E00040B
	ds_bpermute_b32 v16, v11, v5                               // 000000595D28: DACC0000 1000050B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000595D30: D5010014 00022900
	ds_bpermute_b32 v17, v11, v6                               // 000000595D38: DACC0000 1100060B
	ds_bpermute_b32 v19, v11, v8                               // 000000595D40: DACC0000 1300080B
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000595D48: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 000000595D4C: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 000000595D54: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 000000595D58: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 000000595D5C: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 000000595D64: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 000000595D68: C9081B03 03041D04
	s_waitcnt lgkmcnt(3)                                       // 000000595D70: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 000000595D74: C9082105 05062306
	s_waitcnt lgkmcnt(2)                                       // 000000595D7C: BF89FC27
	v_add_f32_e32 v8, v8, v19                                  // 000000595D80: 06102708
	ds_bpermute_b32 v12, v20, v3                               // 000000595D84: DACC0000 0C000314
	ds_bpermute_b32 v13, v20, v4                               // 000000595D8C: DACC0000 0D000414
	ds_bpermute_b32 v14, v20, v5                               // 000000595D94: DACC0000 0E000514
	s_waitcnt lgkmcnt(4)                                       // 000000595D9C: BF89FC47
	v_add_f32_e32 v7, v7, v18                                  // 000000595DA0: 060E2507
	ds_bpermute_b32 v16, v20, v6                               // 000000595DA4: DACC0000 10000614
	ds_bpermute_b32 v18, v20, v8                               // 000000595DAC: DACC0000 12000814
	s_waitcnt lgkmcnt(5)                                       // 000000595DB4: BF89FC57
	v_add_f32_e32 v1, v1, v11                                  // 000000595DB8: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 000000595DBC: DACC0000 0B000214
	ds_bpermute_b32 v17, v20, v7                               // 000000595DC4: DACC0000 11000714
	ds_bpermute_b32 v19, v20, v1                               // 000000595DCC: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 000000595DD4: 3A280082
	s_delay_alu instid0(VALU_DEP_1)                            // 000000595DD8: BF870001
	.long 0xd44c0000                                           // 000000595DDC: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000595DE0: 020228A0
	s_waitcnt lgkmcnt(6)                                       // 000000595DE4: BF89FC67
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v4, v4, v13   // 000000595DE8: C9081903 03041B04
	s_waitcnt lgkmcnt(5)                                       // 000000595DF0: BF89FC57
	v_add_f32_e32 v5, v5, v14                                  // 000000595DF4: 060A1D05
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000595DF8: D5010014 00022900
	s_waitcnt lgkmcnt(4)                                       // 000000595E00: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 000000595E04: 060C2106
	v_xor_b32_e32 v14, 1, v0                                   // 000000595E08: 3A1C0081
	s_waitcnt lgkmcnt(2)                                       // 000000595E0C: BF89FC27
	v_add_f32_e32 v2, v2, v11                                  // 000000595E10: 06041702
	s_waitcnt lgkmcnt(1)                                       // 000000595E14: BF89FC17
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 2, v20// 000000595E18: C9222307 07142882
	s_waitcnt lgkmcnt(0)                                       // 000000595E20: BF89FC07
	v_dual_add_f32 v12, v8, v18 :: v_dual_add_f32 v1, v1, v19  // 000000595E24: C9082508 0C002701
	.long 0xd44c0000                                           // 000000595E2C: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 000000595E30: 02021CA0
	ds_bpermute_b32 v8, v20, v2                                // 000000595E34: DACC0000 08000214
	ds_bpermute_b32 v11, v20, v3                               // 000000595E3C: DACC0000 0B000314
	ds_bpermute_b32 v13, v20, v4                               // 000000595E44: DACC0000 0D000414
	ds_bpermute_b32 v17, v20, v5                               // 000000595E4C: DACC0000 11000514
	ds_bpermute_b32 v18, v20, v6                               // 000000595E54: DACC0000 12000614
	ds_bpermute_b32 v19, v20, v7                               // 000000595E5C: DACC0000 13000714
	ds_bpermute_b32 v21, v20, v12                              // 000000595E64: DACC0000 15000C14
	ds_bpermute_b32 v20, v20, v1                               // 000000595E6C: DACC0000 14000114
	v_cndmask_b32_e64 v0, v0, v14, s0                          // 000000595E74: D5010000 00021D00
	.long 0xd44a0000                                           // 000000595E7C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000595E80: 02021E80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000595E84: BF870002
	v_lshlrev_b32_e32 v22, 2, v0                               // 000000595E88: 302C0082
	s_and_b32 s0, s0, vcc_lo                                   // 000000595E8C: 8B006A00
	s_waitcnt lgkmcnt(7)                                       // 000000595E90: BF89FC77
	v_add_f32_e32 v14, v2, v8                                  // 000000595E94: 061C1102
	s_waitcnt lgkmcnt(6)                                       // 000000595E98: BF89FC67
	v_add_f32_e32 v16, v3, v11                                 // 000000595E9C: 06201703
	s_waitcnt lgkmcnt(5)                                       // 000000595EA0: BF89FC57
	v_add_f32_e32 v8, v4, v13                                  // 000000595EA4: 06101B04
	s_waitcnt lgkmcnt(3)                                       // 000000595EA8: BF89FC37
	v_dual_add_f32 v11, v5, v17 :: v_dual_add_f32 v4, v6, v18  // 000000595EAC: C9082305 0B042506
	s_waitcnt lgkmcnt(1)                                       // 000000595EB4: BF89FC17
	v_dual_add_f32 v5, v7, v19 :: v_dual_add_f32 v0, v12, v21  // 000000595EB8: C9082707 05002B0C
	s_waitcnt lgkmcnt(0)                                       // 000000595EC0: BF89FC07
	v_add_f32_e32 v1, v1, v20                                  // 000000595EC4: 06022901
	ds_bpermute_b32 v17, v22, v16                              // 000000595EC8: DACC0000 11001016
	ds_bpermute_b32 v18, v22, v14                              // 000000595ED0: DACC0000 12000E16
	ds_bpermute_b32 v13, v22, v11                              // 000000595ED8: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v8                               // 000000595EE0: DACC0000 0C000816
	ds_bpermute_b32 v6, v22, v5                                // 000000595EE8: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 000000595EF0: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 000000595EF8: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 000000595F00: DACC0000 03000016
	s_and_saveexec_b32 s1, s0                                  // 000000595F08: BE812000
	s_cbranch_execz 119                                        // 000000595F0C: BFA50077 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb0EEEvPKhPKtPvll+0xeec>
	s_waitcnt lgkmcnt(6)                                       // 000000595F10: BF89FC67
	v_dual_add_f32 v14, v14, v18 :: v_dual_add_f32 v15, v16, v17// 000000595F14: C908250E 0E0E2310
	.long 0x7f203880                                           // 000000595F1C: 7F203880
	.long 0xd73c0009                                           // 000000595F20: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000595F24: 02021281
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000595F28: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000595F2C: BF870003
	.long 0x7e20398e                                           // 000000595F30: 7E20398E
	.long 0x7e22398f                                           // 000000595F34: 7E22398F
	.long 0x7f223990                                           // 000000595F38: 7F223990
	s_waitcnt lgkmcnt(5)                                       // 000000595F3C: BF89FC57
	v_add_f32_e32 v13, v11, v13                                // 000000595F40: 061A1B0B
	.long 0xd7006a09                                           // 000000595F44: D7006A09
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000595F48: 02021208
	v_and_b32_e32 v18, 1, v16                                  // 000000595F4C: 36242081
	s_waitcnt lgkmcnt(4)                                       // 000000595F50: BF89FC47
	v_dual_add_f32 v8, v8, v12 :: v_dual_and_b32 v17, 1, v17   // 000000595F54: C9241908 08102281
	v_add_co_ci_u32_e64 v10, null, s9, v10, vcc_lo             // 000000595F5C: D5207C0A 01AA1409
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000595F64: BF870223
	v_add3_u32 v18, v14, v18, 0x7fff                           // 000000595F68: D6550012 03FE250E 00007FFF
	.long 0xd7006a0e                                           // 000000595F74: D7006A0E
	v_cndmask_b32_e32 v0, v9, v0, vcc_lo                       // 000000595F78: 02000109
	v_add3_u32 v17, v15, v17, 0x7fff                           // 000000595F7C: D6550011 03FE230F 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000595F88: BF870004
	v_add_co_ci_u32_e64 v15, null, s1, v10, vcc_lo             // 000000595F8C: D5207C0F 01AA1401
	s_clause 0x1                                               // 000000595F94: BF850001
	global_store_d16_hi_b16 v[9:10], v17, off                  // 000000595F98: DC960000 007C1109
	global_store_d16_hi_b16 v[14:15], v18, off                 // 000000595FA0: DC960000 007C120E
	.long 0x7e1c398d                                           // 000000595FA8: 7E1C398D
	.long 0x7f1c3990                                           // 000000595FAC: 7F1C3990
	.long 0x7e203988                                           // 000000595FB0: 7E203988
	s_waitcnt lgkmcnt(3)                                       // 000000595FB4: BF89FC37
	v_add_f32_e32 v15, v5, v6                                  // 000000595FB8: 061E0D05
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000595FBC: 8480820C
	s_waitcnt lgkmcnt(2)                                       // 000000595FC0: BF89FC27
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v14, 1, v14    // 000000595FC4: C9240F04 070E1C81
	v_mad_u64_u32 v[4:5], null, s12, 6, v[9:10]                // 000000595FCC: D6FE7C04 04250C0C
	.long 0xd7006a0b                                           // 000000595FD4: D7006A0B
	v_cndmask_b32_e32 v0, v9, v0, vcc_lo                       // 000000595FD8: 02000109
	s_delay_alu instid0(VALU_DEP_1)                            // 000000595FDC: BF870001
	v_add_co_ci_u32_e64 v12, null, s1, v10, vcc_lo             // 000000595FE0: D5207C0C 01AA1401
	v_and_b32_e32 v6, 1, v16                                   // 000000595FE8: 360C2081
	.long 0x7e14398f                                           // 000000595FEC: 7E14398F
	.long 0x7f143990                                           // 000000595FF0: 7F143990
	v_add3_u32 v9, v13, v14, 0x7fff                            // 000000595FF4: D6550009 03FE1D0D 00007FFF
	.long 0x7e203987                                           // 000000596000: 7E203987
	v_add3_u32 v13, v8, v6, 0x7fff                             // 000000596004: D655000D 03FE0D08 00007FFF
	v_mad_u64_u32 v[5:6], null, s13, 6, v[5:6]                 // 000000596010: D6FE7C05 04150C0D
	v_and_b32_e32 v8, 1, v10                                   // 000000596018: 36101481
	s_waitcnt lgkmcnt(0)                                       // 00000059601C: BF89FC07
	v_add_f32_e32 v10, v0, v3                                  // 000000596020: 06140700
	global_store_d16_hi_b16 v[11:12], v9, off                  // 000000596024: DC960000 007C090B
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v6, 1, v16     // 00000059602C: C9240501 09062081
	.long 0xd7006a00                                           // 000000596034: D7006A00
	v_cndmask_b32_e32 v0, v11, v0, vcc_lo                      // 000000596038: 0200010B
	.long 0x7e20398a                                           // 00000059603C: 7E20398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000596040: BF870213
	v_add3_u32 v11, v7, v6, 0x7fff                             // 000000596044: D655000B 03FE0D07 00007FFF
	.long 0x7e0c3989                                           // 000000596050: 7E0C3989
	.long 0x7f0c3990                                           // 000000596054: 7F0C3990
	v_add_co_ci_u32_e64 v1, null, s1, v12, vcc_lo              // 000000596058: D5207C01 01AA1801
	v_add3_u32 v12, v15, v8, 0x7fff                            // 000000596060: D655000C 03FE110F 00007FFF
	.long 0xd7006a02                                           // 00000059606C: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000596070: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 000000596074: 36102081
	v_and_b32_e32 v14, 1, v6                                   // 000000596078: 361C0C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 00000059607C: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 000000596084: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000596088: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059608C: BF870001
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 000000596090: D5207C07 01AA0201
	v_add3_u32 v10, v10, v8, 0x7fff                            // 000000596098: D655000A 03FE110A 00007FFF
	.long 0xd7006a08                                           // 0000005960A4: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000005960A8: 02000102
	v_add3_u32 v14, v9, v14, 0x7fff                            // 0000005960AC: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000005960B8: D5207C09 01AA0601
	s_clause 0x4                                               // 0000005960C0: BF850004
	global_store_d16_hi_b16 v[4:5], v13, off                   // 0000005960C4: DC960000 007C0D04
	global_store_d16_hi_b16 v[0:1], v12, off                   // 0000005960CC: DC960000 007C0C00
	global_store_d16_hi_b16 v[2:3], v11, off                   // 0000005960D4: DC960000 007C0B02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 0000005960DC: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000005960E4: DC960000 007C0A08
	s_endpgm                                                   // 0000005960EC: BFB00000
		...

