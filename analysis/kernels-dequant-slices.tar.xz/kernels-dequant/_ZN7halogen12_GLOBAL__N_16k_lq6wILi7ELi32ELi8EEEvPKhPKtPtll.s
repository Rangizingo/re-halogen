000000000034ad00 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 00000034AD00: F40C0100 F8000000
	v_mov_b32_e32 v6, 0                                        // 00000034AD08: 7E0C0280
	s_mov_b32 s3, 0                                            // 00000034AD0C: BE830080
	v_lshrrev_b32_e32 v16, 5, v0                               // 00000034AD10: 32200085
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v5, 0              // 00000034AD14: CA100080 12040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 00000034AD1C: CA100080 07080080
	v_mov_b32_e32 v15, 0                                       // 00000034AD24: 7E1E0280
	v_mov_b32_e32 v11, 0                                       // 00000034AD28: 7E160280
	v_dual_mov_b32 v14, 0 :: v_dual_and_b32 v17, 31, v0        // 00000034AD2C: CA240080 0E10009F
	s_waitcnt lgkmcnt(0)                                       // 00000034AD34: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 00000034AD38: 86109F0B
	v_mov_b32_e32 v1, s4                                       // 00000034AD3C: 7E020204
	s_lshr_b32 s12, s16, 27                                    // 00000034AD40: 850C9B10
	v_mov_b32_e32 v2, s5                                       // 00000034AD44: 7E040205
	s_add_u32 s12, s10, s12                                    // 00000034AD48: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 00000034AD4C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000034AD50: BF8704B9
	s_lshr_b64 s[18:19], s[12:13], 5                           // 00000034AD54: 8592850C
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000034AD58: F4040300 F8000020
	s_add_i32 s14, s18, 7                                      // 00000034AD60: 810E8712
	s_ashr_i32 s15, s14, 31                                    // 00000034AD64: 860F9F0E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000034AD68: BF870499
	s_lshr_b32 s0, s15, 29                                     // 00000034AD6C: 85009D0F
	s_add_i32 s14, s14, s0                                     // 00000034AD70: 810E000E
	s_lshr_b32 s0, s11, 31                                     // 00000034AD74: 85009F0B
	s_ashr_i32 s19, s14, 3                                     // 00000034AD78: 8613830E
	s_add_u32 s0, s10, s0                                      // 00000034AD7C: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000034AD80: 8201800B
	s_lshr_b32 s17, s16, 30                                    // 00000034AD84: 85119E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 00000034AD88: 868E8100
	s_add_u32 s0, s10, s17                                     // 00000034AD8C: 8000110A
	s_addc_u32 s1, s11, 0                                      // 00000034AD90: 8201800B
	s_lshr_b32 s20, s16, 28                                    // 00000034AD94: 85149C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 00000034AD98: 86908200
	s_add_u32 s0, s10, s20                                     // 00000034AD9C: 8000140A
	s_addc_u32 s1, s11, 0                                      // 00000034ADA0: 8201800B
	.long 0xd72c0003                                           // 00000034ADA4: D72C0003
	v_cndmask_b32_e32 v1, s19, v16, vcc_lo                     // 00000034ADA8: 02022013
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034ADAC: 86808400
	s_add_u32 s4, s16, s14                                     // 00000034ADB0: 80040E10
	s_addc_u32 s20, s17, s15                                   // 00000034ADB4: 82140F11
	s_add_u32 s0, s4, s0                                       // 00000034ADB8: 80000004
	s_addc_u32 s1, s20, s1                                     // 00000034ADBC: 82010114
	s_add_u32 s0, s0, 15                                       // 00000034ADC0: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000034ADC4: 82018001
	s_waitcnt lgkmcnt(0)                                       // 00000034ADC8: BF89FC07
	.long 0xd4510014                                           // 00000034ADCC: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000034ADD0: 02001802
	s_ashr_i32 s4, s1, 31                                      // 00000034ADD4: 86049F01
	v_add_nc_u32_e32 v19, v3, v17                              // 00000034ADD8: 4A262303
	s_lshr_b32 s4, s4, 28                                      // 00000034ADDC: 85049C04
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000034ADE0: BF870009
	s_add_u32 s0, s0, s4                                       // 00000034ADE4: 80000400
	s_addc_u32 s1, s1, 0                                       // 00000034ADE8: 82018001
	s_lshl_b64 s[4:5], s[2:3], 4                               // 00000034ADEC: 84848402
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000034ADF0: 86808400
	s_and_b32 s20, s20, exec_lo                                // 00000034ADF4: 8B147E14
	s_cselect_b32 s4, s4, 0                                    // 00000034ADF8: 98048004
	s_cselect_b32 s5, s5, 0                                    // 00000034ADFC: 98058005
	v_mad_u64_u32 v[9:10], null, s4, s0, v[1:2]                // 00000034AE00: D6FE7C09 04040004
	v_add_nc_u32_e32 v1, s19, v3                               // 00000034AE08: 4A020613
	s_mul_i32 s5, s5, s0                                       // 00000034AE0C: 96050005
	s_mul_i32 s4, s4, s1                                       // 00000034AE10: 96040104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034AE14: BF870191
	v_min_i32_e32 v20, s18, v1                                 // 00000034AE18: 22280212
	v_add_nc_u32_e32 v1, s5, v10                               // 00000034AE1C: 4A021405
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034AE20: BF870112
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 00000034AE24: 7C822913
	v_add_nc_u32_e32 v21, s4, v1                               // 00000034AE28: 4A2A0204
	s_and_saveexec_b32 s1, vcc_lo                              // 00000034AE2C: BE81206A
	s_cbranch_execz 39                                         // 00000034AE30: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x1d0>
	v_lshlrev_b32_e32 v1, 4, v19                               // 00000034AE34: 30022684
	v_lshlrev_b32_e32 v4, 1, v19                               // 00000034AE38: 30082681
	v_lshlrev_b32_e32 v3, 3, v19                               // 00000034AE3C: 30062683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034AE40: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000034AE44: 3404029F
	.long 0xd7000001                                           // 00000034AE48: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000034AE4C: 02020309
	v_and_b32_e32 v8, -4, v4                                   // 00000034AE50: 361008C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034AE54: BF870214
	v_ashrrev_i32_e32 v7, 31, v3                               // 00000034AE58: 340E069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000034AE5C: D5207C02 00020515
	.long 0xd7000005                                           // 00000034AE64: D7000005
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 00000034AE68: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034AE6C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s15, v21, s0                 // 00000034AE70: D5207C06 00022A0F
	v_ashrrev_i32_e32 v12, 31, v8                              // 00000034AE78: 3418109F
	.long 0xd700000a                                           // 00000034AE7C: D700000A
	v_cndmask_b32_e32 v0, v5, v16, vcc_lo                      // 00000034AE80: 02002105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034AE84: BF8700A1
	v_add_co_ci_u32_e64 v11, null, s17, v6, s0                 // 00000034AE88: D5207C0B 00020C11
	.long 0xd7000003                                           // 00000034AE90: D7000003
	v_cndmask_b32_e32 v1, v5, v3, vcc_lo                       // 00000034AE94: 02020705
	v_add_co_ci_u32_e64 v4, null, v6, v7, s0                   // 00000034AE98: D5207C04 00020F06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034AEA0: BF870094
	.long 0xd700000a                                           // 00000034AEA4: D700000A
	v_cndmask_b32_e32 v1, v10, v8, vcc_lo                      // 00000034AEA8: 0202110A
	v_add_co_ci_u32_e64 v11, null, v11, v12, s0                // 00000034AEAC: D5207C0B 0002190B
	s_clause 0x2                                               // 00000034AEB4: BF850002
	global_load_b128 v[5:8], v[1:2], off                       // 00000034AEB8: DC5E0000 057C0001
	global_load_b64 v[14:15], v[3:4], off                      // 00000034AEC0: DC560000 0E7C0003
	global_load_b32 v11, v[10:11], off                         // 00000034AEC8: DC520000 0B7C000A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000034AED0: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000034AED4: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000034AEDC: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 00000034AEE4: CA100080 1A1A0080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000034AEEC: BE81206A
	s_cbranch_execz 1071                                       // 00000034AEF0: BFA5042F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x12b0>
	.long 0xd7006a1c                                           // 00000034AEF4: D7006A1C
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 00000034AEF8: 02001D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034AEFC: BF8701A1
	v_add_co_ci_u32_e64 v29, null, s15, v21, vcc_lo            // 00000034AF00: D5207C1D 01AA2A0F
	v_dual_mov_b32 v18, 0 :: v_dual_add_nc_u32 v1, 32, v19     // 00000034AF08: CA200080 120026A0
	.long 0xd7006a1e                                           // 00000034AF10: D7006A1E
	v_cndmask_b32_e32 v0, v28, v16, vcc_lo                     // 00000034AF14: 0200211C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034AF18: BF870221
	v_add_co_ci_u32_e64 v31, null, s17, v29, vcc_lo            // 00000034AF1C: D5207C1F 01AA3A11
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v10, 5, v19    // 00000034AF24: CA220080 170A2685
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v32, 4, v1     // 00000034AF2C: CA220080 19200284
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v33, 3, v1     // 00000034AF34: CA220080 16200283
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v34, 1, v1     // 00000034AF3C: CA220080 1B220281
	s_waitcnt vmcnt(0)                                         // 00000034AF44: BF8903F7
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v35, v11           // 00000034AF48: CA100080 1822010B
	v_mov_b32_e32 v26, 0                                       // 00000034AF50: 7E340280
	s_mul_i32 s0, s11, 6                                       // 00000034AF54: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000034AF58: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000034AF5C: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000034AF60: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000034AF64: 9610860A
	s_mov_b32 s15, 0                                           // 00000034AF68: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000034AF6C: 848A810A
	s_branch 999                                               // 00000034AF70: BFA003E7 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x1210>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000034AF74: 8C7E117E
	v_lshlrev_b32_e32 v36, 4, v14                              // 00000034AF78: 30481C84
	v_lshlrev_b32_e32 v38, 2, v14                              // 00000034AF7C: 304C1C82
	v_lshrrev_b32_e32 v37, 4, v5                               // 00000034AF80: 324A0A84
	.long 0x7f5e3880                                           // 00000034AF84: 7F5E3880
	v_lshrrev_b32_e32 v39, 6, v14                              // 00000034AF88: 324E1C86
	v_and_b32_e32 v36, 48, v36                                 // 00000034AF8C: 364848B0
	v_and_b32_e32 v38, 48, v38                                 // 00000034AF90: 364C4CB0
	v_lshrrev_b32_e32 v40, 22, v14                             // 00000034AF94: 32501C96
	v_lshrrev_b32_e32 v44, 6, v15                              // 00000034AF98: 32581E86
	v_and_b32_e32 v39, 48, v39                                 // 00000034AF9C: 364E4EB0
	v_and_or_b32 v36, v5, 15, v36                              // 00000034AFA0: D6570024 04911F05
	v_and_or_b32 v37, v37, 15, v38                             // 00000034AFA8: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 00000034AFB0: 365050B0
	v_lshrrev_b32_e32 v42, 20, v7                              // 00000034AFB4: 32540E94
	v_and_b32_e32 v44, 48, v44                                 // 00000034AFB8: 365858B0
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034AFBC: 7E482324
	v_lshrrev_b32_e32 v49, 18, v15                             // 00000034AFC0: 32621E92
	v_lshrrev_b32_e32 v50, 22, v15                             // 00000034AFC4: 32641E96
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000034AFC8: 8B006A7E
	v_and_or_b32 v42, v42, 15, v44                             // 00000034AFCC: D657002A 04B11F2A
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034AFD4: CC206024 142E1724
	v_and_b32_e32 v49, 48, v49                                 // 00000034AFDC: 366262B0
	v_and_b32_e32 v50, 48, v50                                 // 00000034AFE0: 366464B0
	v_add_nc_u32_e32 v32, 0x200, v32                           // 00000034AFE4: 4A4040FF 00000200
	v_add_nc_u32_e32 v33, 0x100, v33                           // 00000034AFEC: 4A4242FF 00000100
	v_bfe_u32 v38, v36, 16, 1                                  // 00000034AFF4: D6100026 02052124
	v_add_nc_u32_e32 v34, 64, v34                              // 00000034AFFC: 4A4444C0
	s_or_b32 s15, s0, s15                                      // 00000034B000: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B004: BF870122
	v_add3_u32 v36, v36, v38, 0x7fff                           // 00000034B008: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 2, v14                              // 00000034B014: 324C1C82
	.long 0x7e5e39a4                                           // 00000034B018: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 00000034B01C: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B020: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 00000034B024: 364C4CB0
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B028: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B030: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034B034: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034B03C: D6550024 03FE4B24 00007FFF
	v_and_b32_e32 v37, 48, v14                                 // 00000034B048: 364A1CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B04C: BF8700A2
	v_and_or_b32 v41, 0xffff0000, v36, v47                     // 00000034B050: D6570029 04BE48FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v5                               // 00000034B05C: 32480A88
	v_and_or_b32 v36, v36, 15, v37                             // 00000034B060: D6570024 04951F24
	v_lshrrev_b32_e32 v37, 12, v5                              // 00000034B068: 324A0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B06C: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034B070: 7E482324
	v_and_or_b32 v37, v37, 15, v38                             // 00000034B074: D6570025 04991F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B07C: BF870092
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B080: CC206024 142E1724
	v_bfe_u32 v38, v36, 16, 1                                  // 00000034B088: D6100026 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B090: BF870121
	v_add3_u32 v36, v36, v38, 0x7fff                           // 00000034B094: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 20, v5                              // 00000034B0A0: 324C0A94
	.long 0x7e5e39a4                                           // 00000034B0A4: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 00000034B0A8: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B0AC: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 00000034B0B0: D6570026 049D1F26
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B0B8: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B0C0: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034B0C4: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034B0CC: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v14                              // 00000034B0D8: 324A1C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B0DC: BF8701A2
	v_and_or_b32 v43, 0xffff0000, v36, v47                     // 00000034B0E0: D657002B 04BE48FF FFFF0000
	.long 0x7e5e3985                                           // 00000034B0EC: 7E5E3985
	v_and_b32_e32 v37, 48, v37                                 // 00000034B0F0: 364A4AB0
	v_lshrrev_b32_e32 v36, 8, v14                              // 00000034B0F4: 32481C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B0F8: BF870112
	v_and_or_b32 v37, v47, 15, v37                             // 00000034B0FC: D6570025 04951F2F
	v_and_b32_e32 v36, 48, v36                                 // 00000034B104: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B108: BF870092
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034B10C: 7E4A2325
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B110: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B118: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 00000034B11C: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 00000034B124: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 18, v14                             // 00000034B130: 324E1C92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B134: BF8701A2
	.long 0x7e5e39a5                                           // 00000034B138: 7E5E39A5
	v_cvt_f32_ubyte0_e32 v37, v38                              // 00000034B13C: 7E4A2326
	v_and_b32_e32 v39, 48, v39                                 // 00000034B140: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B144: BF870092
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B148: CC206025 142E1725
	v_bfe_u32 v38, v37, 16, 1                                  // 00000034B150: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B158: BF870121
	v_add3_u32 v37, v37, v38, 0x7fff                           // 00000034B15C: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 12, v14                             // 00000034B168: 324C1C8C
	v_and_or_b32 v45, 0xffff0000, v37, v47                     // 00000034B16C: D657002D 04BE4AFF FFFF0000
	v_lshrrev_b32_e32 v37, 24, v5                              // 00000034B178: 324A0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 00000034B17C: 320A0A9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B180: BF870122
	v_and_or_b32 v36, v37, 15, v36                             // 00000034B184: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v14                             // 00000034B18C: 324A1C8A
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034B190: 7E482324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B194: BF870112
	v_and_or_b32 v5, v37, 48, v5                               // 00000034B198: D6570005 04156125
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B1A0: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B1A8: BF870112
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000034B1AC: 7E0A2305
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034B1B0: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B1B8: BF870112
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B1BC: CC206005 142E1705
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034B1C4: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 14, v14                             // 00000034B1D0: 324A1C8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034B1D4: BF870212
	.long 0x7e5e39a4                                           // 00000034B1D8: 7E5E39A4
	v_bfe_u32 v36, v5, 16, 1                                   // 00000034B1DC: D6100024 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B1E4: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 00000034B1E8: 364A4AB0
	v_add3_u32 v5, v5, v36, 0x7fff                             // 00000034B1EC: D6550005 03FE4905 00007FFF
	v_lshrrev_b32_e32 v36, 4, v6                               // 00000034B1F8: 32480C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B1FC: BF8701A2
	v_and_or_b32 v46, 0xffff0000, v5, v47                      // 00000034B200: D657002E 04BE0AFF FFFF0000
	v_and_b32_e32 v5, 48, v38                                  // 00000034B20C: 360A4CB0
	v_and_or_b32 v36, v36, 15, v37                             // 00000034B210: D6570024 04951F24
	.long 0x7e5e398e                                           // 00000034B218: 7E5E398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B21C: BF870193
	v_and_or_b32 v5, v6, 15, v5                                // 00000034B220: D6570005 04151F06
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034B228: 7E482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B22C: BF870193
	v_and_b32_e32 v38, 48, v47                                 // 00000034B230: 364C5EB0
	v_cvt_f32_ubyte0_e32 v5, v5                                // 00000034B234: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B238: BF870113
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B23C: CC206024 142E1724
	v_fma_mix_f32 v5, v5, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B244: CC206005 142E1705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B24C: BF870091
	v_bfe_u32 v37, v5, 16, 1                                   // 00000034B250: D6100025 02052105
	v_add3_u32 v5, v5, v37, 0x7fff                             // 00000034B258: D6550005 03FE4B05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B264: BF870114
	v_bfe_u32 v37, v36, 16, 1                                  // 00000034B268: D6100025 02052124
	.long 0x7e0a3985                                           // 00000034B270: 7E0A3985
	.long 0x7f0a39af                                           // 00000034B274: 7F0A39AF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B278: BF870123
	v_add3_u32 v36, v36, v37, 0x7fff                           // 00000034B27C: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 20, v14                             // 00000034B288: 324A1C94
	v_and_or_b32 v5, 0xffff0000, v36, v5                       // 00000034B28C: D6570005 041648FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v6                               // 00000034B298: 32480C88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B29C: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 00000034B2A0: 364A4AB0
	v_and_or_b32 v36, v36, 15, v38                             // 00000034B2A4: D6570024 04991F24
	v_lshrrev_b32_e32 v38, 12, v6                              // 00000034B2AC: 324C0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B2B0: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 00000034B2B4: 7E482324
	v_and_or_b32 v38, v38, 15, v39                             // 00000034B2B8: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B2C0: BF870092
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B2C4: CC206024 142E1724
	v_bfe_u32 v39, v36, 16, 1                                  // 00000034B2CC: D6100027 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B2D4: BF870121
	v_add3_u32 v36, v36, v39, 0x7fff                           // 00000034B2D8: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 20, v6                              // 00000034B2E4: 324E0C94
	.long 0x7e5e39a4                                           // 00000034B2E8: 7E5E39A4
	v_cvt_f32_ubyte0_e32 v36, v38                              // 00000034B2EC: 7E482326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B2F0: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 00000034B2F4: D6570027 04A11F27
	v_fma_mix_f32 v36, v36, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B2FC: CC206024 142E1724
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B304: BF870091
	v_bfe_u32 v38, v36, 16, 1                                  // 00000034B308: D6100026 02052124
	v_add3_u32 v36, v36, v38, 0x7fff                           // 00000034B310: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 24, v14                             // 00000034B31C: 324C1C98
	v_lshrrev_b32_e32 v14, 26, v14                             // 00000034B320: 321C1C9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034B324: BF870223
	v_and_or_b32 v36, 0xffff0000, v36, v47                     // 00000034B328: D6570024 04BE48FF FFFF0000
	.long 0x7e5e3986                                           // 00000034B334: 7E5E3986
	v_and_b32_e32 v38, 48, v38                                 // 00000034B338: 364C4CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B33C: BF870092
	v_and_or_b32 v37, v47, 15, v37                             // 00000034B340: D6570025 04951F2F
	v_cvt_f32_ubyte0_e32 v37, v37                              // 00000034B348: 7E4A2325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B34C: BF870091
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B350: CC206025 142E1725
	v_bfe_u32 v40, v37, 16, 1                                  // 00000034B358: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B360: BF870121
	v_add3_u32 v37, v37, v40, 0x7fff                           // 00000034B364: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 2, v15                              // 00000034B370: 32501E82
	.long 0x7e5e39a5                                           // 00000034B374: 7E5E39A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 00000034B378: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B37C: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 00000034B380: 365050B0
	v_fma_mix_f32 v37, v37, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B384: CC206025 142E1725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B38C: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 00000034B390: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 00000034B398: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v6                              // 00000034B3A4: 324E0C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 00000034B3A8: 320C0C9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B3AC: BF870193
	v_and_or_b32 v37, 0xffff0000, v37, v47                     // 00000034B3B0: D6570025 04BE4AFF FFFF0000
	v_and_or_b32 v38, v39, 15, v38                             // 00000034B3BC: D6570026 04991F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B3C4: BF8701A3
	v_and_or_b32 v6, v14, 48, v6                               // 00000034B3C8: D6570006 0419610E
	v_lshlrev_b32_e32 v39, 2, v15                              // 00000034B3D0: 304E1E82
	v_cvt_f32_ubyte0_e32 v14, v38                              // 00000034B3D4: 7E1C2326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B3D8: BF870193
	v_cvt_f32_ubyte0_e32 v6, v6                                // 00000034B3DC: 7E0C2306
	v_and_b32_e32 v39, 48, v39                                 // 00000034B3E0: 364E4EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B3E4: BF870193
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B3E8: CC20600E 142E170E
	v_fma_mix_f32 v6, v6, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B3F0: CC206006 142E1706
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B3F8: BF870092
	v_bfe_u32 v38, v14, 16, 1                                  // 00000034B3FC: D6100026 0205210E
	v_add3_u32 v14, v14, v38, 0x7fff                           // 00000034B404: D655000E 03FE4D0E 00007FFF
	v_lshrrev_b32_e32 v38, 4, v7                               // 00000034B410: 324C0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B414: BF8701A2
	.long 0x7e5e398e                                           // 00000034B418: 7E5E398E
	v_bfe_u32 v14, v6, 16, 1                                   // 00000034B41C: D610000E 02052106
	v_and_or_b32 v38, v38, 15, v39                             // 00000034B424: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B42C: BF870122
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000034B430: D6550006 03FE1D06 00007FFF
	v_lshlrev_b32_e32 v14, 4, v15                              // 00000034B43C: 301C1E84
	v_and_or_b32 v6, 0xffff0000, v6, v47                       // 00000034B440: D6570006 04BE0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B44C: BF870092
	v_and_b32_e32 v14, 48, v14                                 // 00000034B450: 361C1CB0
	v_and_or_b32 v14, v7, 15, v14                              // 00000034B454: D657000E 04391F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B45C: BF870091
	v_cvt_f32_ubyte0_e32 v14, v14                              // 00000034B460: 7E1C230E
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B464: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B46C: BF870091
	v_bfe_u32 v39, v14, 16, 1                                  // 00000034B470: D6100027 0205210E
	v_add3_u32 v14, v14, v39, 0x7fff                           // 00000034B478: D655000E 03FE4F0E 00007FFF
	v_and_b32_e32 v39, 48, v15                                 // 00000034B484: 364E1EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B488: BF8700A2
	.long 0x7e5e398e                                           // 00000034B48C: 7E5E398E
	v_cvt_f32_ubyte0_e32 v14, v38                              // 00000034B490: 7E1C2326
	v_fma_mix_f32 v14, v14, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B494: CC20600E 142E170E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B49C: BF870091
	v_bfe_u32 v38, v14, 16, 1                                  // 00000034B4A0: D6100026 0205210E
	v_add3_u32 v14, v14, v38, 0x7fff                           // 00000034B4A8: D655000E 03FE4D0E 00007FFF
	v_lshrrev_b32_e32 v38, 8, v7                               // 00000034B4B4: 324C0E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B4B8: BF870112
	v_and_or_b32 v14, 0xffff0000, v14, v47                     // 00000034B4BC: D657000E 04BE1CFF FFFF0000
	v_and_or_b32 v38, v38, 15, v39                             // 00000034B4C8: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v7                              // 00000034B4D0: 324E0E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B4D4: BF870112
	v_cvt_f32_ubyte0_e32 v38, v38                              // 00000034B4D8: 7E4C2326
	v_and_or_b32 v39, v39, 15, v40                             // 00000034B4DC: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B4E4: BF870092
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B4E8: CC206026 142E1726
	v_bfe_u32 v40, v38, 16, 1                                  // 00000034B4F0: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B4F8: BF870121
	v_add3_u32 v38, v38, v40, 0x7fff                           // 00000034B4FC: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 8, v15                              // 00000034B508: 32501E88
	.long 0x7e5e39a6                                           // 00000034B50C: 7E5E39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 00000034B510: 7E4C2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B514: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 00000034B518: 365050B0
	v_fma_mix_f32 v38, v38, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B51C: CC206026 142E1726
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B524: BF870091
	v_bfe_u32 v39, v38, 16, 1                                  // 00000034B528: D6100027 02052126
	v_add3_u32 v38, v38, v39, 0x7fff                           // 00000034B530: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v15                              // 00000034B53C: 324E1E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034B540: BF8701A2
	v_and_or_b32 v38, 0xffff0000, v38, v47                     // 00000034B544: D6570026 04BE4CFF FFFF0000
	.long 0x7e5e3987                                           // 00000034B550: 7E5E3987
	v_and_b32_e32 v39, 48, v39                                 // 00000034B554: 364E4EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B558: BF870091
	v_and_or_b32 v39, v47, 15, v39                             // 00000034B55C: D6570027 049D1F2F
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000034B564: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B568: BF870091
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B56C: CC206027 142E1727
	v_bfe_u32 v44, v39, 16, 1                                  // 00000034B574: D610002C 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B57C: BF870121
	v_add3_u32 v39, v39, v44, 0x7fff                           // 00000034B580: D6550027 03FE5927 00007FFF
	v_lshrrev_b32_e32 v44, 12, v15                             // 00000034B58C: 32581E8C
	.long 0x7e5e39a7                                           // 00000034B590: 7E5E39A7
	v_cvt_f32_ubyte0_e32 v39, v42                              // 00000034B594: 7E4E232A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B598: BF870091
	v_fma_mix_f32 v39, v39, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B59C: CC206027 142E1727
	v_bfe_u32 v42, v39, 16, 1                                  // 00000034B5A4: D610002A 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034B5AC: BF8701B1
	v_add3_u32 v39, v39, v42, 0x7fff                           // 00000034B5B0: D6550027 03FE5527 00007FFF
	v_lshrrev_b32_e32 v42, 24, v7                              // 00000034B5BC: 32540E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 00000034B5C0: 320E0E9C
	v_and_or_b32 v39, 0xffff0000, v39, v47                     // 00000034B5C4: D6570027 04BE4EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B5D0: BF870123
	v_and_or_b32 v40, v42, 15, v40                             // 00000034B5D4: D6570028 04A11F2A
	v_lshrrev_b32_e32 v42, 10, v15                             // 00000034B5DC: 32541E8A
	v_cvt_f32_ubyte0_e32 v40, v40                              // 00000034B5E0: 7E502328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B5E4: BF870112
	v_and_or_b32 v7, v42, 48, v7                               // 00000034B5E8: D6570007 041D612A
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B5F0: CC206028 142E1728
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B5F8: BF870112
	v_cvt_f32_ubyte0_e32 v7, v7                                // 00000034B5FC: 7E0E2307
	v_bfe_u32 v42, v40, 16, 1                                  // 00000034B600: D610002A 02052128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B608: BF870112
	v_fma_mix_f32 v7, v7, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B60C: CC206007 142E1707
	v_add3_u32 v40, v40, v42, 0x7fff                           // 00000034B614: D6550028 03FE5528 00007FFF
	v_lshrrev_b32_e32 v42, 4, v8                               // 00000034B620: 32541084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034B624: BF870212
	.long 0x7e5e39a8                                           // 00000034B628: 7E5E39A8
	v_bfe_u32 v40, v7, 16, 1                                   // 00000034B62C: D6100028 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B634: BF870121
	v_add3_u32 v7, v7, v40, 0x7fff                             // 00000034B638: D6550007 03FE5107 00007FFF
	v_and_b32_e32 v40, 15, v8                                  // 00000034B644: 3650108F
	v_and_or_b32 v7, 0xffff0000, v7, v47                       // 00000034B648: D6570007 04BE0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034B654: BF8701B2
	v_and_or_b32 v40, v44, 48, v40                             // 00000034B658: D6570028 04A1612C
	v_lshrrev_b32_e32 v44, 14, v15                             // 00000034B660: 32581E8E
	.long 0x7e5e398f                                           // 00000034B664: 7E5E398F
	v_cvt_f32_ubyte0_e32 v40, v40                              // 00000034B668: 7E502328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B66C: BF870193
	v_and_b32_e32 v44, 48, v44                                 // 00000034B670: 365858B0
	v_and_b32_e32 v48, 48, v47                                 // 00000034B674: 36605EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B678: BF870193
	v_fma_mix_f32 v40, v40, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B67C: CC206028 142E1728
	v_and_or_b32 v42, v42, 15, v44                             // 00000034B684: D657002A 04B11F2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B68C: BF870112
	v_bfe_u32 v44, v40, 16, 1                                  // 00000034B690: D610002C 02052128
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034B698: 7E54232A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B69C: BF870112
	v_add3_u32 v40, v40, v44, 0x7fff                           // 00000034B6A0: D6550028 03FE5928 00007FFF
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B6AC: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B6B4: BF870112
	.long 0x7e5039a8                                           // 00000034B6B8: 7E5039A8
	v_bfe_u32 v44, v42, 16, 1                                  // 00000034B6BC: D610002C 0205212A
	.long 0x7f5039af                                           // 00000034B6C4: 7F5039AF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B6C8: BF870122
	v_add3_u32 v42, v42, v44, 0x7fff                           // 00000034B6CC: D655002A 03FE592A 00007FFF
	v_lshrrev_b32_e32 v44, 20, v15                             // 00000034B6D8: 32581E94
	v_and_or_b32 v40, 0xffff0000, v42, v40                     // 00000034B6DC: D6570028 04A254FF FFFF0000
	v_lshrrev_b32_e32 v42, 8, v8                               // 00000034B6E8: 32541088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B6EC: BF870113
	v_and_b32_e32 v44, 48, v44                                 // 00000034B6F0: 365858B0
	v_and_or_b32 v42, v42, 15, v48                             // 00000034B6F4: D657002A 04C11F2A
	v_lshrrev_b32_e32 v48, 12, v8                              // 00000034B6FC: 3260108C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B700: BF870112
	v_cvt_f32_ubyte0_e32 v42, v42                              // 00000034B704: 7E54232A
	v_and_or_b32 v48, v48, 15, v49                             // 00000034B708: D6570030 04C51F30
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B710: BF870092
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B714: CC20602A 142E172A
	v_bfe_u32 v49, v42, 16, 1                                  // 00000034B71C: D6100031 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034B724: BF870121
	v_add3_u32 v42, v42, v49, 0x7fff                           // 00000034B728: D655002A 03FE632A 00007FFF
	v_lshrrev_b32_e32 v49, 20, v8                              // 00000034B734: 32621094
	.long 0x7e5e39aa                                           // 00000034B738: 7E5E39AA
	v_cvt_f32_ubyte0_e32 v42, v48                              // 00000034B73C: 7E542330
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B740: BF870113
	v_and_or_b32 v49, v49, 15, v50                             // 00000034B744: D6570031 04C91F31
	v_fma_mix_f32 v42, v42, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B74C: CC20602A 142E172A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B754: BF870091
	v_bfe_u32 v48, v42, 16, 1                                  // 00000034B758: D6100030 0205212A
	v_add3_u32 v42, v42, v48, 0x7fff                           // 00000034B760: D655002A 03FE612A 00007FFF
	v_lshrrev_b32_e32 v48, 24, v15                             // 00000034B76C: 32601E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 00000034B770: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000034B774: BF870223
	v_and_or_b32 v42, 0xffff0000, v42, v47                     // 00000034B778: D657002A 04BE54FF FFFF0000
	.long 0x7e5e3988                                           // 00000034B784: 7E5E3988
	v_and_b32_e32 v48, 48, v48                                 // 00000034B788: 366060B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B78C: BF870092
	v_and_or_b32 v44, v47, 15, v44                             // 00000034B790: D657002C 04B11F2F
	v_cvt_f32_ubyte0_e32 v44, v44                              // 00000034B798: 7E58232C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B79C: BF870091
	v_fma_mix_f32 v44, v44, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B7A0: CC20602C 142E172C
	v_bfe_u32 v50, v44, 16, 1                                  // 00000034B7A8: D6100032 0205212C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B7B0: BF870091
	v_add3_u32 v44, v44, v50, 0x7fff                           // 00000034B7B4: D655002C 03FE652C 00007FFF
	.long 0x7e5e39ac                                           // 00000034B7C0: 7E5E39AC
	v_cvt_f32_ubyte0_e32 v44, v49                              // 00000034B7C4: 7E582331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B7C8: BF870091
	v_fma_mix_f32 v44, v44, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B7CC: CC20602C 142E172C
	v_bfe_u32 v49, v44, 16, 1                                  // 00000034B7D4: D6100031 0205212C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034B7DC: BF8701B1
	v_add3_u32 v44, v44, v49, 0x7fff                           // 00000034B7E0: D655002C 03FE632C 00007FFF
	v_lshrrev_b32_e32 v49, 24, v8                              // 00000034B7EC: 32621098
	v_lshrrev_b32_e32 v8, 28, v8                               // 00000034B7F0: 3210109C
	v_and_or_b32 v44, 0xffff0000, v44, v47                     // 00000034B7F4: D657002C 04BE58FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034B800: BF870193
	v_and_or_b32 v48, v49, 15, v48                             // 00000034B804: D6570030 04C11F31
	v_and_or_b32 v8, v15, 48, v8                               // 00000034B80C: D6570008 0421610F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B814: BF870112
	v_cvt_f32_ubyte0_e32 v15, v48                              // 00000034B818: 7E1E2330
	v_cvt_f32_ubyte0_e32 v8, v8                                // 00000034B81C: 7E102308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B820: BF870112
	v_fma_mix_f32 v15, v15, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B824: CC20600F 142E170F
	v_fma_mix_f32 v8, v8, v11, v11 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000034B82C: CC206008 142E1708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B834: BF870112
	v_bfe_u32 v48, v15, 16, 1                                  // 00000034B838: D6100030 0205210F
	v_bfe_u32 v11, v8, 16, 1                                   // 00000034B840: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034B848: BF870112
	v_add3_u32 v15, v15, v48, 0x7fff                           // 00000034B84C: D655000F 03FE610F 00007FFF
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000034B858: D6550008 03FE1708 00007FFF
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000034B864: 3416149F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034B868: BF870133
	.long 0x7e5e398f                                           // 00000034B86C: 7E5E398F
	s_waitcnt vmcnt(1)                                         // 00000034B870: BF8907F7
	v_mov_b32_e32 v15, v13                                     // 00000034B874: 7E1E030D
	v_and_or_b32 v8, 0xffff0000, v8, v47                       // 00000034B878: D6570008 04BE10FF FFFF0000
	.long 0xd73c002f                                           // 00000034B884: D73C002F
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000034B888: 02021481
	v_add_nc_u32_e32 v10, 0x400, v10                           // 00000034B88C: 4A1414FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B894: BF870092
	.long 0xd7006a3f                                           // 00000034B898: D7006A3F
	v_cndmask_b32_e32 v1, s6, v47, vcc_lo                      // 00000034B89C: 02025E06
	v_add_co_ci_u32_e64 v64, null, s7, v48, vcc_lo             // 00000034B8A0: D5207C40 01AA6007
	s_clause 0x3                                               // 00000034B8A8: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 00000034B8AC: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 00000034B8B4: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 00000034B8BC: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 00000034B8C4: DC5E0030 3B7C003F
	s_waitcnt vmcnt(3)                                         // 00000034B8CC: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034B8D0: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B8D8: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034B8DC: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034B8E4: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B8EC: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034B8F0: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034B8F8: BF890BF7
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034B8FC: CC1A400B 1C2E0B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B904: BF870091
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034B908: CC1A400B 1C2E4934
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034B910: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B918: BF8700A1
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034B91C: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034B924: BF8907F7
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034B928: CC1A400B 1C2E1D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B930: BF870091
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034B934: CC1A400B 1C2E4D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034B93C: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B944: BF8700A1
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034B948: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034B950: BF8903F7
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034B954: CC1A400B 1C2E513B
	.long 0xd7006a3b                                           // 00000034B95C: D7006A3B
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 00000034B960: 0200153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000034B964: BF8701B2
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034B968: CC1A400B 1C2E553C
	v_add_co_ci_u32_e64 v60, null, s11, v64, vcc_lo            // 00000034B970: D5207C3C 01AA800B
	.long 0xd7006a41                                           // 00000034B978: D7006A41
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 00000034B97C: 0200093F
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034B980: CC1A400B 1C2E593D
	v_add_co_ci_u32_e64 v66, null, s5, v64, vcc_lo             // 00000034B988: D5207C42 01AA8005
	.long 0xd7006a3f                                           // 00000034B990: D7006A3F
	v_cndmask_b32_e32 v0, v63, v16, vcc_lo                     // 00000034B994: 0200213F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000034B998: BF870003
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034B99C: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034B9A4: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 00000034B9A8: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 00000034B9B0: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 00000034B9B8: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 00000034B9C0: DC5E0030 3B7C003B
	v_add_co_ci_u32_e64 v64, null, s14, v64, vcc_lo            // 00000034B9C8: D5207C40 01AA800E
	v_add_f32_e32 v27, v27, v11                                // 00000034B9D0: 0636171B
	s_waitcnt vmcnt(3)                                         // 00000034B9D4: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034B9D8: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034B9E0: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034B9E4: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034B9EC: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034B9F4: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034B9F8: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BA00: BF890BF7
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034BA04: CC1A400B 1C2E0B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BA0C: BF870091
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034BA10: CC1A400B 1C2E4934
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034BA18: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BA20: BF8700A1
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034BA24: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034BA2C: BF8907F7
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034BA30: CC1A400B 1C2E1D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BA38: BF870091
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034BA3C: CC1A400B 1C2E4D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034BA44: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BA4C: BF8700A1
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034BA50: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034BA58: BF8903F7
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034BA5C: CC1A400B 1C2E513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BA64: BF870091
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034BA68: CC1A400B 1C2E553C
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034BA70: CC1A400B 1C2E593D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034BA78: BF870001
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034BA7C: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034BA84: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 00000034BA88: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 00000034BA90: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 00000034BA98: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 00000034BAA0: DC5E0030 3B7C0041
	.long 0xd7006a41                                           // 00000034BAA8: D7006A41
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 00000034BAAC: 02000941
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000034BAB0: BF8700C1
	v_add_co_ci_u32_e64 v66, null, s5, v66, vcc_lo             // 00000034BAB4: D5207C42 01AA8405
	v_add_f32_e32 v26, v26, v11                                // 00000034BABC: 0634171A
	s_waitcnt vmcnt(3)                                         // 00000034BAC0: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034BAC4: CC1A400B 1A02532F
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034BACC: CC1A400B 1C2E5730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BAD4: BF870091
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034BAD8: CC1A400B 1C2E5B31
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034BAE0: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BAE8: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BAEC: BF870091
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034BAF0: CC1A400B 1C2E0B33
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034BAF8: CC1A400B 1C2E4934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BB00: BF870091
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034BB04: CC1A400B 1C2E4B35
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034BB0C: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034BB14: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BB18: BF870091
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034BB1C: CC1A400B 1C2E1D37
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034BB24: CC1A400B 1C2E4D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BB2C: BF870091
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034BB30: CC1A400B 1C2E4F39
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034BB38: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034BB40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BB44: BF870091
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034BB48: CC1A400B 1C2E513B
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034BB50: CC1A400B 1C2E553C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BB58: BF870091
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034BB5C: CC1A400B 1C2E593D
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034BB64: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034BB6C: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 00000034BB70: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 00000034BB78: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 00000034BB80: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 00000034BB88: DC5E0030 3B7C003F
	v_add_f32_e32 v25, v25, v11                                // 00000034BB90: 06321719
	s_waitcnt vmcnt(3)                                         // 00000034BB94: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034BB98: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BBA0: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034BBA4: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034BBAC: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BBB4: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034BBB8: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BBC0: BF890BF7
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034BBC4: CC1A400B 1C2E0B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BBCC: BF870091
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034BBD0: CC1A400B 1C2E4934
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034BBD8: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BBE0: BF8700A1
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034BBE4: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034BBEC: BF8907F7
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034BBF0: CC1A400B 1C2E1D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BBF8: BF870091
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034BBFC: CC1A400B 1C2E4D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034BC04: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BC0C: BF8700A1
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034BC10: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034BC18: BF8903F7
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034BC1C: CC1A400B 1C2E513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BC24: BF870091
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034BC28: CC1A400B 1C2E553C
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034BC30: CC1A400B 1C2E593D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034BC38: BF870001
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034BC3C: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034BC44: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 00000034BC48: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 00000034BC50: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 00000034BC58: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 00000034BC60: DC5E0030 3B7C0041
	v_add_f32_e32 v24, v24, v11                                // 00000034BC68: 06301718
	s_waitcnt vmcnt(3)                                         // 00000034BC6C: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034BC70: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BC78: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034BC7C: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034BC84: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BC8C: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034BC90: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BC98: BF890BF7
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034BC9C: CC1A400B 1C2E0B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BCA4: BF870091
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034BCA8: CC1A400B 1C2E4934
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034BCB0: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BCB8: BF8700A1
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034BCBC: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034BCC4: BF8907F7
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034BCC8: CC1A400B 1C2E1D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BCD0: BF870091
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034BCD4: CC1A400B 1C2E4D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034BCDC: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BCE4: BF8700A1
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034BCE8: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034BCF0: BF8903F7
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034BCF4: CC1A400B 1C2E513B
	.long 0xd7006a3b                                           // 00000034BCFC: D7006A3B
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 00000034BD00: 0200093F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034BD04: BF870122
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034BD08: CC1A400B 1C2E553C
	v_add_co_ci_u32_e64 v60, null, s5, v64, vcc_lo             // 00000034BD10: D5207C3C 01AA8005
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034BD18: CC1A400B 1C2E593D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034BD20: BF870001
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034BD24: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034BD2C: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 00000034BD30: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 00000034BD38: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 00000034BD40: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 00000034BD48: DC5E0030 3B7C003B
	v_add_f32_e32 v23, v23, v11                                // 00000034BD50: 062E1717
	s_waitcnt vmcnt(3)                                         // 00000034BD54: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034BD58: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BD60: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034BD64: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034BD6C: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BD74: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034BD78: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BD80: BF890BF7
	v_dot2_f32_bf16 v11, v51, v5, v11                          // 00000034BD84: CC1A400B 1C2E0B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BD8C: BF870091
	v_dot2_f32_bf16 v11, v52, v36, v11                         // 00000034BD90: CC1A400B 1C2E4934
	v_dot2_f32_bf16 v11, v53, v37, v11                         // 00000034BD98: CC1A400B 1C2E4B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BDA0: BF8700A1
	v_dot2_f32_bf16 v11, v54, v6, v11                          // 00000034BDA4: CC1A400B 1C2E0D36
	s_waitcnt vmcnt(1)                                         // 00000034BDAC: BF8907F7
	v_dot2_f32_bf16 v11, v55, v14, v11                         // 00000034BDB0: CC1A400B 1C2E1D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BDB8: BF870091
	v_dot2_f32_bf16 v11, v56, v38, v11                         // 00000034BDBC: CC1A400B 1C2E4D38
	v_dot2_f32_bf16 v11, v57, v39, v11                         // 00000034BDC4: CC1A400B 1C2E4F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BDCC: BF8700A1
	v_dot2_f32_bf16 v11, v58, v7, v11                          // 00000034BDD0: CC1A400B 1C2E0F3A
	s_waitcnt vmcnt(0)                                         // 00000034BDD8: BF8903F7
	v_dot2_f32_bf16 v11, v59, v40, v11                         // 00000034BDDC: CC1A400B 1C2E513B
	.long 0xd7006a3b                                           // 00000034BDE4: D7006A3B
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 00000034BDE8: 02000941
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034BDEC: BF870122
	v_dot2_f32_bf16 v11, v60, v42, v11                         // 00000034BDF0: CC1A400B 1C2E553C
	v_add_co_ci_u32_e64 v60, null, s5, v66, vcc_lo             // 00000034BDF8: D5207C3C 01AA8405
	v_dot2_f32_bf16 v11, v61, v44, v11                         // 00000034BE00: CC1A400B 1C2E593D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034BE08: BF870001
	v_dot2_f32_bf16 v11, v62, v8, v11                          // 00000034BE0C: CC1A400B 1C2E113E
	s_clause 0x3                                               // 00000034BE14: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 00000034BE18: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 00000034BE20: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 00000034BE28: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 00000034BE30: DC5E0030 3B7C003B
	v_add_f32_e32 v22, v22, v11                                // 00000034BE38: 062C1716
	s_waitcnt vmcnt(3)                                         // 00000034BE3C: BF890FF7
	v_dot2_f32_bf16 v11, v47, v41, 0                           // 00000034BE40: CC1A400B 1A02532F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BE48: BF870091
	v_dot2_f32_bf16 v11, v48, v43, v11                         // 00000034BE4C: CC1A400B 1C2E5730
	v_dot2_f32_bf16 v11, v49, v45, v11                         // 00000034BE54: CC1A400B 1C2E5B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BE5C: BF8700A1
	v_dot2_f32_bf16 v11, v50, v46, v11                         // 00000034BE60: CC1A400B 1C2E5D32
	s_waitcnt vmcnt(2)                                         // 00000034BE68: BF890BF7
	v_dot2_f32_bf16 v5, v51, v5, v11                           // 00000034BE6C: CC1A4005 1C2E0B33
	v_mov_b32_e32 v11, v35                                     // 00000034BE74: 7E160323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BE78: BF870092
	v_dot2_f32_bf16 v5, v52, v36, v5                           // 00000034BE7C: CC1A4005 1C164934
	v_dot2_f32_bf16 v5, v53, v37, v5                           // 00000034BE84: CC1A4005 1C164B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034BE8C: BF870131
	v_dot2_f32_bf16 v5, v54, v6, v5                            // 00000034BE90: CC1A4005 1C160D36
	v_mov_b32_e32 v6, v2                                       // 00000034BE98: 7E0C0302
	s_waitcnt vmcnt(1)                                         // 00000034BE9C: BF8907F7
	v_dot2_f32_bf16 v5, v55, v14, v5                           // 00000034BEA0: CC1A4005 1C161D37
	v_mov_b32_e32 v14, v12                                     // 00000034BEA8: 7E1C030C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BEAC: BF870092
	v_dot2_f32_bf16 v5, v56, v38, v5                           // 00000034BEB0: CC1A4005 1C164D38
	v_dot2_f32_bf16 v5, v57, v39, v5                           // 00000034BEB8: CC1A4005 1C164F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034BEC0: BF870131
	v_dot2_f32_bf16 v5, v58, v7, v5                            // 00000034BEC4: CC1A4005 1C160F3A
	v_mov_b32_e32 v7, v3                                       // 00000034BECC: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 00000034BED0: BF8903F7
	v_dot2_f32_bf16 v5, v59, v40, v5                           // 00000034BED4: CC1A4005 1C16513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034BEDC: BF870091
	v_dot2_f32_bf16 v5, v60, v42, v5                           // 00000034BEE0: CC1A4005 1C16553C
	v_dot2_f32_bf16 v5, v61, v44, v5                           // 00000034BEE8: CC1A4005 1C16593D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000034BEF0: BF870121
	v_dot2_f32_bf16 v5, v62, v8, v5                            // 00000034BEF4: CC1A4005 1C16113E
	v_mov_b32_e32 v8, v4                                       // 00000034BEFC: 7E100304
	v_dual_add_f32 v18, v18, v5 :: v_dual_mov_b32 v5, v1       // 00000034BF00: C9100B12 12040101
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000034BF08: 917E0F7E
	s_cbranch_execz 39                                         // 00000034BF0C: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x12ac>
	v_dual_mov_b32 v2, v6 :: v_dual_add_nc_u32 v19, 32, v19    // 00000034BF10: CA200106 021226A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000034BF18: BF870002
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v4, v8             // 00000034BF1C: CA100105 01040108
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v12, v14           // 00000034BF24: CA100107 030C010E
	v_mov_b32_e32 v13, v15                                     // 00000034BF2C: 7E1A030F
	s_mov_b32 s17, exec_lo                                     // 00000034BF30: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 00000034BF34: 7C8C2913
	.long 0xd4c1007e                                           // 00000034BF38: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 00000034BF3C: 02022913
	s_cbranch_execz 64524                                      // 00000034BF40: BFA5FC0C <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x274>
	v_and_b32_e32 v3, -4, v34                                  // 00000034BF44: 360644C4
	v_ashrrev_i32_e32 v2, 31, v32                              // 00000034BF48: 3404409F
	v_ashrrev_i32_e32 v4, 31, v33                              // 00000034BF4C: 3408429F
	.long 0xd7000001                                           // 00000034BF50: D7000001
	v_cndmask_b32_e32 v1, v9, v32, vcc_lo                      // 00000034BF54: 02024109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034BF58: BF870214
	v_ashrrev_i32_e32 v36, 31, v3                              // 00000034BF5C: 3448069F
	v_add_co_ci_u32_e64 v2, null, v21, v2, s0                  // 00000034BF60: D5207C02 00020515
	.long 0xd700000c                                           // 00000034BF68: D700000C
	v_cndmask_b32_e32 v1, v28, v33, vcc_lo                     // 00000034BF6C: 0202431C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034BF70: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v29, v4, s0                 // 00000034BF74: D5207C0D 0002091D
	.long 0xd7000023                                           // 00000034BF7C: D7000023
	v_cndmask_b32_e32 v1, v30, v3, vcc_lo                      // 00000034BF80: 0202071E
	v_add_co_ci_u32_e64 v36, null, v31, v36, s0                // 00000034BF84: D5207C24 0002491F
	s_clause 0x2                                               // 00000034BF8C: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 00000034BF90: DC5E0000 017C0001
	global_load_b64 v[12:13], v[12:13], off                    // 00000034BF98: DC560000 0C7C000C
	global_load_b32 v35, v[35:36], off                         // 00000034BFA0: DC520000 237C0023
	s_branch 64498                                             // 00000034BFA8: BFA0FBF2 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x274>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000034BFAC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000034BFB0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000034BFB4: 8C7E017E
	.long 0xd71f0001                                           // 00000034BFB8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000034BFBC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000034BFC0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000034BFC4: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000034BFC8: 3A120288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000034BFCC: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000034BFD0: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000034BFD4: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000034BFD8: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000034BFDC: 02121301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000034BFE0: BF870211
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000034BFE4: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000034BFE8: 30040482
	ds_bpermute_b32 v3, v2, v27                                // 00000034BFEC: DACC0000 03001B02
	s_waitcnt lgkmcnt(0)                                       // 00000034BFF4: BF89FC07
	v_add_f32_e32 v3, v27, v3                                  // 00000034BFF8: 0606071B
	ds_bpermute_b32 v4, v2, v26                                // 00000034BFFC: DACC0000 04001A02
	s_waitcnt vmcnt(2)                                         // 00000034C004: BF890BF7
	ds_bpermute_b32 v5, v2, v25                                // 00000034C008: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 00000034C010: DACC0000 06001802
	ds_bpermute_b32 v7, v2, v23                                // 00000034C018: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 00000034C020: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v18                                // 00000034C028: DACC0000 02001202
	ds_bpermute_b32 v10, v9, v3                                // 00000034C030: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 00000034C038: BF89FC57
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v5, v25, v5   // 00000034C03C: C908091A 04040B19
	s_waitcnt lgkmcnt(3)                                       // 00000034C044: BF89FC37
	v_dual_add_f32 v6, v24, v6 :: v_dual_add_f32 v7, v23, v7   // 00000034C048: C9080D18 06060F17
	s_waitcnt lgkmcnt(2)                                       // 00000034C050: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 00000034C054: 06101116
	s_waitcnt vmcnt(0)                                         // 00000034C058: BF8903F7
	ds_bpermute_b32 v11, v9, v4                                // 00000034C05C: DACC0000 0B000409
	ds_bpermute_b32 v12, v9, v5                                // 00000034C064: DACC0000 0C000509
	s_waitcnt lgkmcnt(3)                                       // 00000034C06C: BF89FC37
	v_add_f32_e32 v2, v18, v2                                  // 00000034C070: 06040512
	v_xor_b32_e32 v18, 4, v1                                   // 00000034C074: 3A240284
	s_waitcnt lgkmcnt(2)                                       // 00000034C078: BF89FC27
	v_add_f32_e32 v3, v3, v10                                  // 00000034C07C: 06061503
	ds_bpermute_b32 v13, v9, v6                                // 00000034C080: DACC0000 0D000609
	ds_bpermute_b32 v14, v9, v7                                // 00000034C088: DACC0000 0E000709
	ds_bpermute_b32 v15, v9, v8                                // 00000034C090: DACC0000 0F000809
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 00000034C098: 7C9824A0
	s_waitcnt lgkmcnt(4)                                       // 00000034C09C: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 00000034C0A0: 06081704
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 00000034C0A4: 02242501
	s_waitcnt lgkmcnt(3)                                       // 00000034C0A8: BF89FC37
	v_add_f32_e32 v5, v5, v12                                  // 00000034C0AC: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 00000034C0B0: DACC0000 09000209
	s_waitcnt lgkmcnt(2)                                       // 00000034C0B8: BF89FC27
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v7, v7, v14   // 00000034C0BC: C9081B06 06061D07
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000034C0C4: 30242482
	ds_bpermute_b32 v11, v18, v5                               // 00000034C0C8: DACC0000 0B000512
	s_waitcnt lgkmcnt(0)                                       // 00000034C0D0: BF89FC07
	v_dual_add_f32 v2, v2, v9 :: v_dual_add_f32 v5, v5, v11    // 00000034C0D4: C9081302 02041705
	ds_bpermute_b32 v13, v18, v7                               // 00000034C0DC: DACC0000 0D000712
	v_add_f32_e32 v8, v8, v15                                  // 00000034C0E4: 06101F08
	ds_bpermute_b32 v9, v18, v3                                // 00000034C0E8: DACC0000 09000312
	ds_bpermute_b32 v15, v18, v2                               // 00000034C0F0: DACC0000 0F000212
	ds_bpermute_b32 v10, v18, v4                               // 00000034C0F8: DACC0000 0A000412
	ds_bpermute_b32 v12, v18, v6                               // 00000034C100: DACC0000 0C000612
	s_waitcnt lgkmcnt(4)                                       // 00000034C108: BF89FC47
	v_add_f32_e32 v7, v7, v13                                  // 00000034C10C: 060E1B07
	ds_bpermute_b32 v14, v18, v8                               // 00000034C110: DACC0000 0E000812
	v_xor_b32_e32 v18, 2, v1                                   // 00000034C118: 3A240282
	s_waitcnt lgkmcnt(4)                                       // 00000034C11C: BF89FC47
	v_add_f32_e32 v3, v3, v9                                   // 00000034C120: 06061303
	s_waitcnt lgkmcnt(3)                                       // 00000034C124: BF89FC37
	v_add_f32_e32 v9, v2, v15                                  // 00000034C128: 06121F02
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 00000034C12C: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 00000034C130: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034C134: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 00000034C138: 30242482
	s_waitcnt lgkmcnt(0)                                       // 00000034C13C: BF89FC07
	v_add_f32_e32 v8, v8, v14                                  // 00000034C140: 06101D08
	ds_bpermute_b32 v2, v18, v3                                // 00000034C144: DACC0000 02000312
	v_add_f32_e32 v6, v6, v12                                  // 00000034C14C: 060C1906
	ds_bpermute_b32 v15, v18, v9                               // 00000034C150: DACC0000 0F000912
	v_add_f32_e32 v4, v4, v10                                  // 00000034C158: 06081504
	ds_bpermute_b32 v11, v18, v5                               // 00000034C15C: DACC0000 0B000512
	ds_bpermute_b32 v13, v18, v7                               // 00000034C164: DACC0000 0D000712
	ds_bpermute_b32 v12, v18, v6                               // 00000034C16C: DACC0000 0C000612
	ds_bpermute_b32 v14, v18, v8                               // 00000034C174: DACC0000 0E000812
	ds_bpermute_b32 v10, v18, v4                               // 00000034C17C: DACC0000 0A000412
	v_xor_b32_e32 v18, 1, v1                                   // 00000034C184: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000034C188: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 00000034C18C: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 00000034C190: 02022501
	s_waitcnt lgkmcnt(6)                                       // 00000034C194: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 00000034C198: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 00000034C1A0: BF89FC47
	v_add_f32_e32 v2, v5, v11                                  // 00000034C1A4: 06041705
	s_waitcnt lgkmcnt(2)                                       // 00000034C1A8: BF89FC27
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v3, v7, v13   // 00000034C1AC: C9081906 06021B07
	s_waitcnt lgkmcnt(1)                                       // 00000034C1B4: BF89FC17
	v_dual_add_f32 v12, v8, v14 :: v_dual_add_f32 v5, v9, v15  // 00000034C1B8: C9081D08 0C041F09
	s_waitcnt lgkmcnt(0)                                       // 00000034C1C0: BF89FC07
	v_add_f32_e32 v4, v4, v10                                  // 00000034C1C4: 06081504
	ds_bpermute_b32 v7, v18, v1                                // 00000034C1C8: DACC0000 07000112
	ds_bpermute_b32 v8, v18, v2                                // 00000034C1D0: DACC0000 08000212
	ds_bpermute_b32 v13, v18, v6                               // 00000034C1D8: DACC0000 0D000612
	ds_bpermute_b32 v9, v18, v3                                // 00000034C1E0: DACC0000 09000312
	ds_bpermute_b32 v10, v18, v4                               // 00000034C1E8: DACC0000 0A000412
	ds_bpermute_b32 v14, v18, v12                              // 00000034C1F0: DACC0000 0E000C12
	ds_bpermute_b32 v11, v18, v5                               // 00000034C1F8: DACC0000 0B000512
	v_cmpx_eq_u32_e32 0, v17                                   // 00000034C200: 7D942280
	s_cbranch_execz 18                                         // 00000034C204: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x1550>
	s_waitcnt lgkmcnt(1)                                       // 00000034C208: BF89FC17
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v1, v1, v7  // 00000034C20C: C9081D0C 0C000F01
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v3, v3, v9    // 00000034C214: C9081504 04021303
	v_mul_u32_u24_e32 v7, 28, v16                              // 00000034C21C: 160E209C
	s_waitcnt lgkmcnt(0)                                       // 00000034C220: BF89FC07
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v5, v5, v11   // 00000034C224: C9081B06 06041705
	v_add_f32_e32 v2, v2, v8                                   // 00000034C22C: 06041102
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 00000034C230: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 00000034C238: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v12 offset0:4 offset1:5         // 00000034C240: D8380504 000C0307
	ds_store_b32 v7, v5 offset:24                              // 00000034C248: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 00000034C250: 8C7E007E
	.long 0xd4510000                                           // 00000034C254: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000034C258: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 00000034C25C: 7C980087
	s_waitcnt lgkmcnt(0)                                       // 00000034C260: BF89FC07
	s_barrier                                                  // 00000034C264: BFBD0000
	buffer_gl0_inv                                             // 00000034C268: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000034C270: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000034C274: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000034C278: BE812000
	s_cbranch_execz 50                                         // 00000034C27C: BFA50032 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi7ELi32ELi8EEEvPKhPKtPtll+0x1648>
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000034C280: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000034C284: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 00000034C288: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 00000034C290: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 00000034C298: D8DC231C 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000034C2A0: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000034C2A4: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000034C2A8: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000034C2AC: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000034C2B0: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 00000034C2B4: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000034C2B8: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 00000034C2BC: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000034C2C0: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 00000034C2C8: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000034C2CC: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000034C2D0: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 00000034C2D4: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:42 offset1:49         // 00000034C2D8: D8DC312A 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000034C2E0: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 00000034C2E8: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 00000034C2EC: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000034C2F0: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000034C2F4: BF870113
	.long 0xd73c0000                                           // 00000034C2F8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000034C2FC: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000034C300: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000034C308: BF870092
	.long 0xd7006a00                                           // 00000034C30C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000034C310: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000034C314: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000034C31C: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000034C320: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000034C32C: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000034C330: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000034C334: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000034C338: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000034C340: DC960000 007C0200
	s_endpgm                                                   // 00000034C348: BFB00000
		...

