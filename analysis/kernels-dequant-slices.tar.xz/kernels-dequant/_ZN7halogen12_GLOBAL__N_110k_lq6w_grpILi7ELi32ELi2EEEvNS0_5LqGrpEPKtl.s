0000000000377000 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000377000: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000377004: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000037700C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000377014: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000037701C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000377024: 320A0085
	v_and_b32_e32 v71, 31, v0                                  // 000000377028: 368E009F
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v2, 0              // 00000037702C: CA100080 49020080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v91, 0             // 000000377034: CA100080 365A0080
	v_mov_b32_e32 v55, 0                                       // 00000037703C: 7E6E0280
	s_waitcnt lgkmcnt(0)                                       // 000000377040: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000377044: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000377048: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000037704C: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000377050: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000377054: BF870009
	s_and_b32 s4, s7, s4                                       // 000000377058: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000037705C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000377060: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000377068: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000037706C: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000377070: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000377074: BF870009
	s_and_b32 s4, s7, s5                                       // 000000377078: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000037707C: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000377080: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000377084: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000377088: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000037708C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000377090: BF870009
	s_and_b32 s3, s3, s6                                       // 000000377094: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000377098: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000037709C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000003770A0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000003770A4: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 0000003770A8: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 0000003770B0: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003770B4: BF870009
	s_add_u32 s10, s0, s3                                      // 0000003770B8: 800A0300
	s_addc_u32 s11, s1, 0                                      // 0000003770BC: 820B8001
	s_clause 0x2                                               // 0000003770C0: BF850002
	s_load_b64 s[8:9], s[10:11], 0x30                          // 0000003770C4: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 0000003770CC: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 0000003770D4: F4040005 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000003770DC: BF89FC07
	.long 0xd4510011                                           // 0000003770E0: D4510011
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 0000003770E4: 02011208
	s_and_b32 s3, s17, exec_lo                                 // 0000003770E8: 8B037E11
	s_cselect_b32 s16, 8, 2                                    // 0000003770EC: 98108288
	s_cselect_b32 s18, 3, 1                                    // 0000003770F0: 98128183
	v_cvt_f32_ubyte0_e32 v1, s16                               // 0000003770F4: 7E022210
	s_sub_i32 s2, s2, s12                                      // 0000003770F8: 81820C02
	s_add_i32 s14, s16, -1                                     // 0000003770FC: 810EC110
	s_and_b32 s13, s17, exec_lo                                // 000000377100: 8B0D7E11
	s_cselect_b32 s13, 0, 2                                    // 000000377104: 980D8280
	v_rcp_iflag_f32_e32 v3, v1                                 // 000000377108: 7E065701
	s_ashr_i32 s19, s7, 31                                     // 00000037710C: 86139F07
	s_mov_b32 s3, 0                                            // 000000377110: BE830080
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v72, s14, v5        // 000000377114: CA240080 01480A0E
	s_lshl_b64 s[2:3], s[2:3], s13                             // 00000037711C: 84820D02
	v_lshrrev_b32_e32 v70, s18, v5                             // 000000377120: 328C0A12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000377124: BF870115
	v_readfirstlane_b32 s12, v3                                // 000000377128: 7E180503
	.long 0xd7001703                                           // 00000037712C: D7001703
	v_cndmask_b32_e32 v1, s2, v70, vcc_lo                      // 000000377130: 02028C02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000377134: BF8704B1
	v_add_co_ci_u32_e64 v4, null, s3, 0, s23                   // 000000377138: D5207C04 005D0003
	s_mul_f32 s15, s12, 0x4f7ffffe                             // 000000377140: A20FFF0C 4F7FFFFE
	s_lshr_b32 s12, s19, 27                                    // 000000377148: 850C9B13
	s_add_u32 s12, s6, s12                                     // 00000037714C: 800C0C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000377150: BF870009
	s_cvt_u32_f32 s15, s15                                     // 000000377154: BE8F670F
	s_addc_u32 s13, s7, 0                                      // 000000377158: 820D8007
	s_sub_i32 s22, 0, s16                                      // 00000037715C: 81961080
	s_lshr_b64 s[20:21], s[12:13], 5                           // 000000377160: 8594850C
	s_mul_i32 s22, s22, s15                                    // 000000377164: 96160F16
	s_add_i32 s12, s14, s20                                    // 000000377168: 810C140E
	s_mul_hi_u32 s13, s15, s22                                 // 00000037716C: 968D160F
	s_abs_i32 s21, s12                                         // 000000377170: BE95150C
	s_add_i32 s15, s15, s13                                    // 000000377174: 810F0D0F
	s_ashr_i32 s12, s12, 31                                    // 000000377178: 860C9F0C
	s_mul_hi_u32 s13, s21, s15                                 // 00000037717C: 968D0F15
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[3:4]                    // 000000377180: 7CA80608
	s_mul_i32 s15, s13, s16                                    // 000000377184: 960F100D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000377188: BF870009
	s_sub_i32 s15, s21, s15                                    // 00000037718C: 818F0F15
	s_add_i32 s21, s13, 1                                      // 000000377190: 8115810D
	s_sub_i32 s22, s15, s16                                    // 000000377194: 8196100F
	s_cmp_ge_u32 s15, s16                                      // 000000377198: BF09100F
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_cndmask_b32 v4, 0, v4// 00000037719C: CA520680 03040880
	s_cselect_b32 s13, s21, s13                                // 0000003771A4: 980D0D15
	s_cselect_b32 s15, s22, s15                                // 0000003771A8: 980F0F16
	s_add_i32 s21, s13, 1                                      // 0000003771AC: 8115810D
	s_cmp_ge_u32 s15, s16                                      // 0000003771B0: BF09100F
	s_cselect_b32 s13, s21, s13                                // 0000003771B4: 980D0D15
	s_lshr_b32 s14, s7, 31                                     // 0000003771B8: 850E9F07
	s_xor_b32 s13, s13, s12                                    // 0000003771BC: 8D0D0C0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003771C0: BF870009
	s_sub_i32 s21, s13, s12                                    // 0000003771C4: 81950C0D
	s_add_u32 s12, s6, s14                                     // 0000003771C8: 800C0E06
	s_addc_u32 s13, s7, 0                                      // 0000003771CC: 820D8007
	s_lshr_b32 s14, s19, 30                                    // 0000003771D0: 850E9E13
	s_ashr_i64 s[12:13], s[12:13], 1                           // 0000003771D4: 868C810C
	s_add_u32 s14, s6, s14                                     // 0000003771D8: 800E0E06
	s_addc_u32 s15, s7, 0                                      // 0000003771DC: 820F8007
	s_lshr_b32 s19, s19, 28                                    // 0000003771E0: 85139C13
	s_ashr_i64 s[14:15], s[14:15], 2                           // 0000003771E4: 868E820E
	s_add_u32 s22, s6, s19                                     // 0000003771E8: 80161306
	s_addc_u32 s23, s7, 0                                      // 0000003771EC: 82178007
	.long 0xd72c0005                                           // 0000003771F0: D72C0005
	v_cndmask_b32_e32 v0, v72, v21, vcc_lo                     // 0000003771F4: 02002B48
	s_ashr_i64 s[22:23], s[22:23], 4                           // 0000003771F8: 86968416
	s_add_u32 s19, s14, s12                                    // 0000003771FC: 80130C0E
	s_addc_u32 s24, s15, s13                                   // 000000377200: 82180D0F
	s_add_u32 s19, s19, s22                                    // 000000377204: 80131613
	s_addc_u32 s22, s24, s23                                   // 000000377208: 82161718
	s_add_u32 s19, s19, 15                                     // 00000037720C: 80138F13
	s_addc_u32 s22, s22, 0                                     // 000000377210: 82168016
	v_add_nc_u32_e32 v6, s21, v5                               // 000000377214: 4A0C0A15
	s_ashr_i32 s23, s22, 31                                    // 000000377218: 86179F16
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000037721C: BF870499
	s_lshr_b32 s23, s23, 28                                    // 000000377220: 85179C17
	s_add_u32 s19, s19, s23                                    // 000000377224: 80131713
	s_addc_u32 s21, s22, 0                                     // 000000377228: 82158016
	s_and_b32 s19, s19, -16                                    // 00000037722C: 8B13D013
	.long 0xd72c0007                                           // 000000377230: D72C0007
	v_cndmask_b32_e32 v1, s21, v3, vcc_lo                      // 000000377234: 02020615
	.long 0xd72c0008                                           // 000000377238: D72C0008
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 00000037723C: 02020813
	v_mad_u64_u32 v[49:50], null, s19, v3, s[0:1]              // 000000377240: D6FE7C31 00020613
	v_mov_b32_e32 v3, 0                                        // 000000377248: 7E060280
	v_min_i32_e32 v75, s20, v6                                 // 00000037724C: 22960C14
	v_mov_b32_e32 v4, 0                                        // 000000377250: 7E080280
	v_add_nc_u32_e32 v74, v5, v71                              // 000000377254: 4A948F05
	v_add3_u32 v76, v7, v50, v8                                // 000000377258: D655004C 04226507
	s_delay_alu instid0(VALU_DEP_2)                            // 000000377260: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v74, v75                          // 000000377264: 7C82974A
	s_and_saveexec_b32 s1, vcc_lo                              // 000000377268: BE81206A
	s_cbranch_execz 39                                         // 00000037726C: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x30c>
	v_lshlrev_b32_e32 v1, 4, v74                               // 000000377270: 30029484
	v_lshlrev_b32_e32 v4, 1, v74                               // 000000377274: 30089481
	v_lshlrev_b32_e32 v3, 3, v74                               // 000000377278: 30069483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000037727C: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000377280: 3404029F
	.long 0xd7000001                                           // 000000377284: D7000001
	v_cndmask_b32_e32 v1, v49, v1, vcc_lo                      // 000000377288: 02020331
	v_and_b32_e32 v4, -4, v4                                   // 00000037728C: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000377290: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 000000377294: 3410069F
	v_add_co_ci_u32_e64 v2, null, v76, v2, s0                  // 000000377298: D5207C02 0002054C
	.long 0xd7000006                                           // 0000003772A0: D7000006
	v_cndmask_b32_e32 v0, v49, v12, vcc_lo                     // 0000003772A4: 02001931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003772A8: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s13, v76, s0                 // 0000003772AC: D5207C07 0002980D
	v_ashrrev_i32_e32 v11, 31, v4                              // 0000003772B4: 3416089F
	.long 0xd7000009                                           // 0000003772B8: D7000009
	v_cndmask_b32_e32 v0, v6, v14, vcc_lo                      // 0000003772BC: 02001D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003772C0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s15, v7, s0                 // 0000003772C4: D5207C0A 00020E0F
	.long 0xd7000006                                           // 0000003772CC: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003772D0: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 0000003772D4: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003772DC: BF870094
	.long 0xd7000008                                           // 0000003772E0: D7000008
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000003772E4: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, s0                 // 0000003772E8: D5207C09 0002170A
	s_clause 0x2                                               // 0000003772F0: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003772F4: DC5E0000 017C0001
	global_load_b64 v[54:55], v[6:7], off                      // 0000003772FC: DC560000 367C0006
	global_load_b32 v91, v[8:9], off                           // 000000377304: DC520000 5B7C0008
	s_or_b32 exec_lo, exec_lo, s1                              // 00000037730C: 8C7E017E
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 000000377310: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v80, 0             // 000000377318: CA100080 4F500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v82, 0             // 000000377320: CA100080 51520080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000377328: BE81206A
	s_cbranch_execz 935                                        // 00000037732C: BFA503A7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11cc>
	.long 0xd7006a53                                           // 000000377330: D7006A53
	v_cndmask_b32_e32 v0, v49, v12, vcc_lo                     // 000000377334: 02001931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000377338: BF870231
	v_add_co_ci_u32_e64 v84, null, s13, v76, vcc_lo            // 00000037733C: D5207C54 01AA980D
	v_dual_mov_b32 v73, 0 :: v_dual_lshlrev_b32 v6, 5, v71     // 000000377344: CA220080 49068E85
	v_dual_mov_b32 v78, 0 :: v_dual_add_nc_u32 v7, 32, v74     // 00000037734C: CA200080 4E0694A0
	.long 0xd7006a55                                           // 000000377354: D7006A55
	v_cndmask_b32_e32 v0, v83, v14, vcc_lo                     // 000000377358: 02001D53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000037735C: BF870211
	v_add_co_ci_u32_e64 v86, null, s15, v84, vcc_lo            // 000000377360: D5207C56 01AAA80F
	v_lshl_add_u32 v50, v5, 5, v6                              // 000000377368: D6460032 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000377370: BF870004
	v_dual_mov_b32 v80, 0 :: v_dual_lshlrev_b32 v87, 4, v7     // 000000377374: CA220080 50560E84
	v_dual_mov_b32 v77, 0 :: v_dual_lshlrev_b32 v88, 3, v7     // 00000037737C: CA220080 4D580E83
	v_dual_mov_b32 v82, 0 :: v_dual_lshlrev_b32 v89, 1, v7     // 000000377384: CA220080 52580E81
	s_waitcnt vmcnt(0)                                         // 00000037738C: BF8903F7
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v90, v91           // 000000377390: CA100080 4F5A015B
	v_mov_b32_e32 v81, 0                                       // 000000377398: 7EA20280
	s_mul_i32 s0, s7, 6                                        // 00000037739C: 96008607
	s_mul_hi_u32 s14, s6, 6                                    // 0000003773A0: 968E8606
	s_lshl_b64 s[12:13], s[6:7], 2                             // 0000003773A4: 848C8206
	s_add_i32 s14, s14, s0                                     // 0000003773A8: 810E000E
	s_mul_i32 s19, s6, 6                                       // 0000003773AC: 96138606
	s_mov_b32 s15, 0                                           // 0000003773B0: BE8F0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000003773B4: 84868106
	s_branch 860                                               // 0000003773B8: BFA0035C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x112c>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000003773BC: 8C7E147E
	v_ashrrev_i32_e32 v51, 31, v50                             // 0000003773C0: 3466649F
	v_lshlrev_b32_e32 v92, 2, v54                              // 0000003773C4: 30B86C82
	v_lshrrev_b32_e32 v93, 4, v1                               // 0000003773C8: 32BA0284
	v_lshrrev_b32_e32 v94, 8, v1                               // 0000003773CC: 32BC0288
	v_lshrrev_b32_e32 v95, 2, v54                              // 0000003773D0: 32BE6C82
	.long 0xd73c0009                                           // 0000003773D4: D73C0009
	v_cndmask_b32_e32 v1, 1, v50, vcc_lo                       // 0000003773D8: 02026481
	v_lshlrev_b32_e32 v51, 4, v54                              // 0000003773DC: 30666C84
	v_and_b32_e32 v92, 48, v92                                 // 0000003773E0: 36B8B8B0
	v_and_b32_e32 v96, 48, v54                                 // 0000003773E4: 36C06CB0
	v_lshrrev_b32_e32 v97, 12, v1                              // 0000003773E8: 32C2028C
	v_and_b32_e32 v95, 48, v95                                 // 0000003773EC: 36BEBEB0
	.long 0xd7000040                                           // 0000003773F0: D7000040
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 0000003773F4: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003773F8: BF8701A1
	v_add_co_ci_u32_e64 v65, null, s5, v10, s0                 // 0000003773FC: D5207C41 00021405
	v_and_b32_e32 v51, 48, v51                                 // 000000377404: 366666B0
	.long 0xd700003c                                           // 000000377408: D700003C
	v_cndmask_b32_e32 v0, v64, v6, vcc_lo                      // 00000037740C: 02000D40
	global_load_b128 v[9:12], v[64:65], off                    // 000000377410: DC5E0000 097C0040
	v_add_co_ci_u32_e64 v61, null, s7, v65, s0                 // 000000377418: D5207C3D 00028207
	.long 0xd7000038                                           // 000000377420: D7000038
	v_cndmask_b32_e32 v0, v64, v12, vcc_lo                     // 000000377424: 02001940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000377428: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s13, v65, s0                // 00000037742C: D5207C39 0002820D
	global_load_b128 v[13:16], v[60:61], off                   // 000000377434: DC5E0000 0D7C003C
	.long 0xd700003a                                           // 00000037743C: D700003A
	v_cndmask_b32_e32 v0, v64, v19, vcc_lo                     // 000000377440: 02002740
	v_add_co_ci_u32_e64 v59, null, s14, v65, s0                // 000000377444: D5207C3B 0002820E
	.long 0xd700003e                                           // 00000037744C: D700003E
	v_cndmask_b32_e32 v0, v56, v12, vcc_lo                     // 000000377450: 02001938
	s_delay_alu instid0(VALU_DEP_1)                            // 000000377454: BF870001
	v_add_co_ci_u32_e64 v63, null, s13, v57, s0                // 000000377458: D5207C3F 0002720D
	s_clause 0x2                                               // 000000377460: BF850002
	global_load_b128 v[17:20], v[56:57], off                   // 000000377464: DC5E0000 117C0038
	global_load_b128 v[25:28], v[58:59], off                   // 00000037746C: DC5E0000 197C003A
	global_load_b128 v[21:24], v[62:63], off                   // 000000377474: DC5E0000 157C003E
	.long 0xd7000042                                           // 00000037747C: D7000042
	v_cndmask_b32_e32 v0, v58, v12, vcc_lo                     // 000000377480: 0200193A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000377484: BF8700A1
	v_add_co_ci_u32_e64 v67, null, s13, v59, s0                // 000000377488: D5207C43 0002760D
	.long 0xd7000044                                           // 000000377490: D7000044
	v_cndmask_b32_e32 v0, v62, v12, vcc_lo                     // 000000377494: 0200193E
	v_add_co_ci_u32_e64 v69, null, s13, v63, s0                // 000000377498: D5207C45 00027E0D
	s_clause 0x4                                               // 0000003774A0: BF850004
	global_load_b128 v[33:36], v[66:67], off                   // 0000003774A4: DC5E0000 217C0042
	global_load_b128 v[45:48], v[68:69], off                   // 0000003774AC: DC5E0000 2D7C0044
	global_load_b128 v[37:40], v[64:65], off offset:16         // 0000003774B4: DC5E0010 257C0040
	global_load_b128 v[29:32], v[60:61], off offset:16         // 0000003774BC: DC5E0010 1D7C003C
	global_load_b128 v[41:44], v[56:57], off offset:16         // 0000003774C4: DC5E0010 297C0038
	v_and_or_b32 v51, v1, 15, v51                              // 0000003774CC: D6570033 04CD1F01
	v_and_or_b32 v92, v93, 15, v92                             // 0000003774D4: D657005C 05711F5D
	v_and_or_b32 v93, v94, 15, v96                             // 0000003774DC: D657005D 05811F5E
	v_and_or_b32 v94, v97, 15, v95                             // 0000003774E4: D657005E 057D1F61
	v_lshrrev_b32_e32 v99, 10, v54                             // 0000003774EC: 32C66C8A
	v_cvt_f32_ubyte0_e32 v51, v51                              // 0000003774F0: 7E662333
	v_cvt_f32_ubyte0_e32 v92, v92                              // 0000003774F4: 7EB8235C
	v_cvt_f32_ubyte0_e32 v93, v93                              // 0000003774F8: 7EBA235D
	v_cvt_f32_ubyte0_e32 v94, v94                              // 0000003774FC: 7EBC235E
	v_lshrrev_b32_e32 v100, 8, v2                              // 000000377500: 32C80488
	v_fma_mix_f32 v51, v51, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377504: CC206033 156EB733
	v_fma_mix_f32 v92, v92, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037750C: CC20605C 156EB75C
	v_fma_mix_f32 v93, v93, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377514: CC20605D 156EB75D
	v_fma_mix_f32 v94, v94, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037751C: CC20605E 156EB75E
	v_lshrrev_b32_e32 v101, 18, v54                            // 000000377524: 32CA6C92
	v_bfe_u32 v95, v51, 16, 1                                  // 000000377528: D610005F 02052133
	v_bfe_u32 v96, v92, 16, 1                                  // 000000377530: D6100060 0205215C
	v_bfe_u32 v97, v93, 16, 1                                  // 000000377538: D6100061 0205215D
	v_bfe_u32 v98, v94, 16, 1                                  // 000000377540: D6100062 0205215E
	v_and_b32_e32 v101, 48, v101                               // 000000377548: 36CACAB0
	v_add3_u32 v95, v51, v95, 0x7fff                           // 00000037754C: D655005F 03FEBF33 00007FFF
	.long 0x7f663880                                           // 000000377558: 7F663880
	v_add3_u32 v92, v92, v96, 0x7fff                           // 00000037755C: D655005C 03FEC15C 00007FFF
	v_add3_u32 v93, v93, v97, 0x7fff                           // 000000377568: D655005D 03FEC35D 00007FFF
	v_add3_u32 v94, v94, v98, 0x7fff                           // 000000377574: D655005E 03FEC55E 00007FFF
	.long 0x7e6639df                                           // 000000377580: 7E6639DF
	v_lshrrev_b32_e32 v95, 4, v54                              // 000000377584: 32BE6C84
	v_lshrrev_b32_e32 v96, 8, v54                              // 000000377588: 32C06C88
	v_lshrrev_b32_e32 v97, 6, v54                              // 00000037758C: 32C26C86
	v_lshrrev_b32_e32 v98, 24, v1                              // 000000377590: 32C40298
	v_and_or_b32 v92, 0xffff0000, v92, v51                     // 000000377594: D657005C 04CEB8FF FFFF0000
	.long 0x7e6639dd                                           // 0000003775A0: 7E6639DD
	v_and_b32_e32 v95, 48, v95                                 // 0000003775A4: 36BEBEB0
	v_and_b32_e32 v97, 48, v97                                 // 0000003775A8: 36C2C2B0
	v_and_b32_e32 v96, 48, v96                                 // 0000003775AC: 36C0C0B0
	v_lshrrev_b32_e32 v103, 24, v54                            // 0000003775B0: 32CE6C98
	v_and_or_b32 v93, 0xffff0000, v94, v51                     // 0000003775B4: D657005D 04CEBCFF FFFF0000
	.long 0x7e663981                                           // 0000003775C0: 7E663981
	v_lshrrev_b32_e32 v94, 20, v1                              // 0000003775C4: 32BC0294
	v_lshrrev_b32_e32 v1, 28, v1                               // 0000003775C8: 3202029C
	v_and_or_b32 v96, v98, 15, v96                             // 0000003775CC: D6570060 05811F62
	v_lshrrev_b32_e32 v98, 12, v2                              // 0000003775D4: 32C4048C
	v_and_or_b32 v95, v51, 15, v95                             // 0000003775D8: D657005F 057D1F33
	v_and_or_b32 v94, v94, 15, v97                             // 0000003775E0: D657005E 05851F5E
	v_and_or_b32 v1, v99, 48, v1                               // 0000003775E8: D6570001 04056163
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003775F0: 7EC02360
	v_and_or_b32 v98, v98, 15, v101                            // 0000003775F4: D6570062 05951F62
	v_cvt_f32_ubyte0_e32 v95, v95                              // 0000003775FC: 7EBE235F
	v_cvt_f32_ubyte0_e32 v94, v94                              // 000000377600: 7EBC235E
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000377604: 7E022301
	v_fma_mix_f32 v96, v96, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377608: CC206060 156EB760
	v_cvt_f32_ubyte0_e32 v98, v98                              // 000000377610: 7EC42362
	v_fma_mix_f32 v95, v95, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377614: CC20605F 156EB75F
	v_fma_mix_f32 v94, v94, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037761C: CC20605E 156EB75E
	v_fma_mix_f32 v1, v1, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377624: CC206001 156EB701
	v_lshrrev_b32_e32 v97, 20, v54                             // 00000037762C: 32C26C94
	v_fma_mix_f32 v98, v98, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377630: CC206062 156EB762
	v_bfe_u32 v99, v95, 16, 1                                  // 000000377638: D6100063 0205215F
	v_bfe_u32 v102, v94, 16, 1                                 // 000000377640: D6100066 0205215E
	v_bfe_u32 v104, v1, 16, 1                                  // 000000377648: D6100068 02052101
	v_and_b32_e32 v97, 48, v97                                 // 000000377650: 36C2C2B0
	v_bfe_u32 v124, v98, 16, 1                                 // 000000377654: D610007C 02052162
	v_add3_u32 v95, v95, v99, 0x7fff                           // 00000037765C: D655005F 03FEC75F 00007FFF
	v_bfe_u32 v99, v96, 16, 1                                  // 000000377668: D6100063 02052160
	v_add3_u32 v94, v94, v102, 0x7fff                          // 000000377670: D655005E 03FECD5E 00007FFF
	v_add3_u32 v1, v1, v104, 0x7fff                            // 00000037767C: D6550001 03FED101 00007FFF
	v_add3_u32 v98, v98, v124, 0x7fff                          // 000000377688: D6550062 03FEF962 00007FFF
	.long 0x7e6639df                                           // 000000377694: 7E6639DF
	v_add3_u32 v95, v96, v99, 0x7fff                           // 000000377698: D655005F 03FEC760 00007FFF
	v_lshrrev_b32_e32 v99, 22, v54                             // 0000003776A4: 32C66C96
	v_lshrrev_b32_e32 v96, 20, v2                              // 0000003776A8: 32C00494
	v_lshlrev_b32_e32 v105, 4, v55                             // 0000003776AC: 30D26E84
	v_and_or_b32 v94, 0xffff0000, v94, v51                     // 0000003776B0: D657005E 04CEBCFF FFFF0000
	.long 0x7e6639df                                           // 0000003776BC: 7E6639DF
	v_and_b32_e32 v99, 48, v99                                 // 0000003776C0: 36C6C6B0
	v_lshrrev_b32_e32 v95, 24, v2                              // 0000003776C4: 32BE0498
	v_lshrrev_b32_e32 v102, 28, v2                             // 0000003776C8: 32CC049C
	v_lshrrev_b32_e32 v104, 26, v54                            // 0000003776CC: 32D06C9A
	v_and_or_b32 v1, 0xffff0000, v1, v51                       // 0000003776D0: D6570001 04CE02FF FFFF0000
	.long 0x7e6639b6                                           // 0000003776DC: 7E6639B6
	v_and_or_b32 v96, v96, 15, v99                             // 0000003776E0: D6570060 058D1F60
	v_lshlrev_b32_e32 v109, 2, v55                             // 0000003776E8: 30DA6E82
	v_lshrrev_b32_e32 v106, 8, v3                              // 0000003776EC: 32D40688
	v_and_b32_e32 v107, 48, v55                                // 0000003776F0: 36D66EB0
	v_and_b32_e32 v110, 48, v51                                // 0000003776F4: 36DC66B0
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003776F8: 7EC02360
	v_lshrrev_b32_e32 v108, 4, v3                              // 0000003776FC: 32D80684
	v_lshrrev_b32_e32 v112, 2, v55                             // 000000377700: 32E06E82
	v_and_or_b32 v102, v104, 48, v102                          // 000000377704: D6570066 05996168
	v_and_or_b32 v100, v100, 15, v110                          // 00000037770C: D6570064 05B91F64
	v_and_b32_e32 v99, 48, v109                                // 000000377714: 36C6DAB0
	v_fma_mix_f32 v96, v96, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377718: CC206060 156EB760
	v_lshrrev_b32_e32 v111, 12, v3                             // 000000377720: 32DE068C
	v_cvt_f32_ubyte0_e32 v102, v102                            // 000000377724: 7ECC2366
	v_cvt_f32_ubyte0_e32 v100, v100                            // 000000377728: 7EC82364
	v_and_or_b32 v99, v108, 15, v99                            // 00000037772C: D6570063 058D1F6C
	v_lshrrev_b32_e32 v114, 4, v55                             // 000000377734: 32E46E84
	v_lshrrev_b32_e32 v115, 8, v55                             // 000000377738: 32E66E88
	v_fma_mix_f32 v102, v102, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037773C: CC206066 156EB766
	v_fma_mix_f32 v100, v100, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377744: CC206064 156EB764
	v_cvt_f32_ubyte0_e32 v99, v99                              // 00000037774C: 7EC62363
	v_lshrrev_b32_e32 v101, 6, v55                             // 000000377750: 32CA6E86
	v_lshrrev_b32_e32 v113, 12, v54                            // 000000377754: 32E26C8C
	v_lshrrev_b32_e32 v116, 20, v3                             // 000000377758: 32E80694
	v_bfe_u32 v120, v100, 16, 1                                // 00000037775C: D6100078 02052164
	v_fma_mix_f32 v99, v99, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377764: CC206063 156EB763
	v_lshrrev_b32_e32 v117, 24, v3                             // 00000037776C: 32EA0698
	v_lshrrev_b32_e32 v118, 28, v3                             // 000000377770: 32EC069C
	v_lshrrev_b32_e32 v119, 10, v55                            // 000000377774: 32EE6E8A
	v_add3_u32 v100, v100, v120, 0x7fff                        // 000000377778: D6550064 03FEF164 00007FFF
	v_lshrrev_b32_e32 v110, 4, v2                              // 000000377784: 32DC0484
	v_lshrrev_b32_e32 v54, 14, v54                             // 000000377788: 326C6C8E
	v_lshrrev_b32_e32 v123, 18, v55                            // 00000037778C: 32F66E92
	v_lshrrev_b32_e32 v120, 8, v4                              // 000000377790: 32F00888
	.long 0x7e6639e4                                           // 000000377794: 7E6639E4
	v_and_or_b32 v100, v106, 15, v107                          // 000000377798: D6570064 05AD1F6A
	v_and_b32_e32 v54, 48, v54                                 // 0000003777A0: 366C6CB0
	v_lshrrev_b32_e32 v121, 12, v55                            // 0000003777A4: 32F26E8C
	v_lshrrev_b32_e32 v122, 12, v4                             // 0000003777A8: 32F4088C
	v_and_or_b32 v128, 0xffff0000, v98, v51                    // 0000003777AC: D6570080 04CEC4FF FFFF0000
	.long 0x7e663982                                           // 0000003777B8: 7E663982
	v_and_b32_e32 v98, 48, v103                                // 0000003777BC: 36C4CEB0
	v_and_b32_e32 v103, 48, v105                               // 0000003777C0: 36CED2B0
	v_cvt_f32_ubyte0_e32 v100, v100                            // 0000003777C4: 7EC82364
	v_and_or_b32 v54, v110, 15, v54                            // 0000003777C8: D6570036 04D91F6E
	v_and_or_b32 v97, v51, 15, v97                             // 0000003777D0: D6570061 05851F33
	v_and_or_b32 v95, v95, 15, v98                             // 0000003777D8: D657005F 05891F5F
	v_and_or_b32 v103, v3, 15, v103                            // 0000003777E0: D6570067 059D1F03
	v_and_b32_e32 v98, 48, v112                                // 0000003777E8: 36C4E0B0
	v_fma_mix_f32 v100, v100, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003777EC: CC206064 156EB764
	v_cvt_f32_ubyte0_e32 v97, v97                              // 0000003777F4: 7EC22361
	v_cvt_f32_ubyte0_e32 v95, v95                              // 0000003777F8: 7EBE235F
	v_cvt_f32_ubyte0_e32 v103, v103                            // 0000003777FC: 7ECE2367
	v_and_or_b32 v98, v111, 15, v98                            // 000000377800: D6570062 05891F6F
	v_cvt_f32_ubyte0_e32 v54, v54                              // 000000377808: 7E6C2336
	v_fma_mix_f32 v97, v97, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037780C: CC206061 156EB761
	v_fma_mix_f32 v95, v95, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377814: CC20605F 156EB75F
	v_fma_mix_f32 v103, v103, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037781C: CC206067 156EB767
	v_cvt_f32_ubyte0_e32 v98, v98                              // 000000377824: 7EC42362
	v_fma_mix_f32 v54, v54, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377828: CC206036 156EB736
	v_bfe_u32 v104, v97, 16, 1                                 // 000000377830: D6100068 02052161
	v_lshrrev_b32_e32 v125, 14, v55                            // 000000377838: 32FA6E8E
	v_lshrrev_b32_e32 v124, 20, v55                            // 00000037783C: 32F86E94
	v_fma_mix_f32 v98, v98, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377840: CC206062 156EB762
	v_lshrrev_b32_e32 v126, 24, v55                            // 000000377848: 32FC6E98
	v_add3_u32 v97, v97, v104, 0x7fff                          // 00000037784C: D6550061 03FED161 00007FFF
	v_bfe_u32 v104, v96, 16, 1                                 // 000000377858: D6100068 02052160
	v_lshrrev_b32_e32 v127, 22, v55                            // 000000377860: 32FE6E96
	v_lshrrev_b32_e32 v107, 26, v55                            // 000000377864: 32D66E9A
	v_and_b32_e32 v109, 15, v4                                 // 000000377868: 36DA088F
	.long 0x7e6639e1                                           // 00000037786C: 7E6639E1
	v_add3_u32 v96, v96, v104, 0x7fff                          // 000000377870: D6550060 03FED160 00007FFF
	v_bfe_u32 v104, v95, 16, 1                                 // 00000037787C: D6100068 0205215F
	v_bfe_u32 v97, v102, 16, 1                                 // 000000377884: D6100061 02052166
	v_lshrrev_b32_e32 v108, 28, v4                             // 00000037788C: 32D8089C
	v_lshrrev_b32_e32 v129, 4, v4                              // 000000377890: 33020884
	v_and_or_b32 v111, 0xffff0000, v96, v51                    // 000000377894: D657006F 04CEC0FF FFFF0000
	v_add3_u32 v95, v95, v104, 0x7fff                          // 0000003778A0: D655005F 03FED15F 00007FFF
	v_bfe_u32 v104, v103, 16, 1                                // 0000003778AC: D6100068 02052167
	v_add3_u32 v97, v102, v97, 0x7fff                          // 0000003778B4: D6550061 03FEC366 00007FFF
	v_bfe_u32 v102, v99, 16, 1                                 // 0000003778C0: D6100066 02052163
	v_bfe_u32 v96, v100, 16, 1                                 // 0000003778C8: D6100060 02052164
	.long 0x7e6639df                                           // 0000003778D0: 7E6639DF
	v_add3_u32 v95, v103, v104, 0x7fff                         // 0000003778D4: D655005F 03FED167 00007FFF
	v_bfe_u32 v103, v98, 16, 1                                 // 0000003778E0: D6100067 02052162
	v_add3_u32 v99, v99, v102, 0x7fff                          // 0000003778E8: D6550063 03FECD63 00007FFF
	v_lshrrev_b32_e32 v130, 20, v4                             // 0000003778F4: 33040894
	v_and_or_b32 v112, 0xffff0000, v97, v51                    // 0000003778F8: D6570070 04CEC2FF FFFF0000
	.long 0x7e6639df                                           // 000000377904: 7E6639DF
	v_add3_u32 v95, v100, v96, 0x7fff                          // 000000377908: D655005F 03FEC164 00007FFF
	v_add3_u32 v96, v98, v103, 0x7fff                          // 000000377914: D6550060 03FECF62 00007FFF
	v_and_b32_e32 v97, 48, v101                                // 000000377920: 36C2CAB0
	v_and_or_b32 v98, v119, 48, v118                           // 000000377924: D6570062 05D96177
	v_and_or_b32 v131, 0xffff0000, v99, v51                    // 00000037792C: D6570083 04CEC6FF FFFF0000
	.long 0x7e6639df                                           // 000000377938: 7E6639DF
	v_and_b32_e32 v95, 48, v114                                // 00000037793C: 36BEE4B0
	v_and_or_b32 v97, v116, 15, v97                            // 000000377940: D6570061 05851F74
	v_cvt_f32_ubyte0_e32 v98, v98                              // 000000377948: 7EC42362
	v_and_b32_e32 v99, 48, v123                                // 00000037794C: 36C6F6B0
	v_and_or_b32 v114, 0xffff0000, v96, v51                    // 000000377950: D6570072 04CEC0FF FFFF0000
	.long 0x7e663983                                           // 00000037795C: 7E663983
	v_and_b32_e32 v3, 48, v115                                 // 000000377960: 3606E6B0
	v_and_b32_e32 v96, 48, v113                                // 000000377964: 36C0E2B0
	v_fma_mix_f32 v101, v98, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377968: CC206065 156EB762
	v_and_or_b32 v99, v122, 15, v99                            // 000000377970: D6570063 058D1F7A
	v_and_or_b32 v95, v51, 15, v95                             // 000000377978: D657005F 057D1F33
	v_and_or_b32 v3, v117, 15, v3                              // 000000377980: D6570003 040D1F75
	v_and_or_b32 v2, v2, 15, v96                               // 000000377988: D6570002 05811F02
	v_cvt_f32_ubyte0_e32 v96, v97                              // 000000377990: 7EC02361
	v_lshrrev_b32_e32 v132, 24, v4                             // 000000377994: 33080898
	v_cvt_f32_ubyte0_e32 v95, v95                              // 000000377998: 7EBE235F
	v_cvt_f32_ubyte0_e32 v3, v3                                // 00000037799C: 7E062303
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003779A0: 7E042302
	v_fma_mix_f32 v102, v96, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003779A4: CC206066 156EB760
	v_add_nc_u32_e32 v50, 0x400, v50                           // 0000003779AC: 4A6464FF 00000400
	v_fma_mix_f32 v100, v95, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003779B4: CC206064 156EB75F
	v_fma_mix_f32 v3, v3, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003779BC: CC206003 156EB703
	v_fma_mix_f32 v2, v2, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003779C4: CC206002 156EB702
	v_bfe_u32 v104, v102, 16, 1                                // 0000003779CC: D6100068 02052166
	global_load_b128 v[95:98], v[64:65], off offset:32         // 0000003779D4: DC5E0020 5F7C0040
	v_bfe_u32 v103, v100, 16, 1                                // 0000003779DC: D6100067 02052164
	v_add_nc_u32_e32 v87, 0x200, v87                           // 0000003779E4: 4AAEAEFF 00000200
	v_add_nc_u32_e32 v88, 0x100, v88                           // 0000003779EC: 4AB0B0FF 00000100
	v_add3_u32 v102, v102, v104, 0x7fff                        // 0000003779F4: D6550066 03FED166 00007FFF
	v_add_nc_u32_e32 v89, 64, v89                              // 000000377A00: 4AB2B2C0
	v_add3_u32 v100, v100, v103, 0x7fff                        // 000000377A04: D6550064 03FECF64 00007FFF
	v_bfe_u32 v103, v101, 16, 1                                // 000000377A10: D6100067 02052165
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000377A18: 8B006A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000377A1C: BF870119
	s_or_b32 s15, s0, s15                                      // 000000377A20: 8C0F0F00
	.long 0x7e6639e4                                           // 000000377A24: 7E6639E4
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000377A28: BF8701A2
	v_add3_u32 v100, v101, v103, 0x7fff                        // 000000377A2C: D6550064 03FECF65 00007FFF
	v_bfe_u32 v101, v2, 16, 1                                  // 000000377A38: D6100065 02052102
	v_and_or_b32 v113, 0xffff0000, v102, v51                   // 000000377A40: D6570071 04CECCFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000377A4C: BF8700B2
	v_add3_u32 v2, v2, v101, 0x7fff                            // 000000377A50: D6550002 03FECB02 00007FFF
	s_waitcnt vmcnt(10)                                        // 000000377A5C: BF892BF7
	v_dot2_f32_bf16 v9, v9, v92, 0                             // 000000377A60: CC1A4009 1A02B909
	v_dot2_f32_bf16 v9, v10, v93, v9                           // 000000377A68: CC1A4009 1C26BB0A
	s_waitcnt vmcnt(9)                                         // 000000377A70: BF8927F7
	v_dot2_f32_bf16 v10, v13, v92, 0                           // 000000377A74: CC1A400A 1A02B90D
	v_bfe_u32 v13, v3, 16, 1                                   // 000000377A7C: D610000D 02052103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000377A84: BF870193
	v_dot2_f32_bf16 v9, v11, v94, v9                           // 000000377A88: CC1A4009 1C26BD0B
	v_dot2_f32_bf16 v14, v14, v93, v10                         // 000000377A90: CC1A400E 1C2ABB0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000377A98: BF870193
	v_add3_u32 v3, v3, v13, 0x7fff                             // 000000377A9C: D6550003 03FE1B03 00007FFF
	v_dot2_f32_bf16 v104, v12, v1, v9                          // 000000377AA8: CC1A4068 1C26030C
	global_load_b128 v[9:12], v[58:59], off offset:16          // 000000377AB0: DC5E0010 097C003A
	v_dot2_f32_bf16 v13, v15, v94, v14                         // 000000377AB8: CC1A400D 1C3ABD0F
	.long 0x7e663983                                           // 000000377AC0: 7E663983
	s_waitcnt vmcnt(9)                                         // 000000377AC4: BF8927F7
	v_dot2_f32_bf16 v3, v17, v92, 0                            // 000000377AC8: CC1A4003 1A02B911
	s_waitcnt vmcnt(8)                                         // 000000377AD0: BF8923F7
	v_dot2_f32_bf16 v17, v25, v92, 0                           // 000000377AD4: CC1A4011 1A02B919
	v_dot2_f32_bf16 v115, v16, v1, v13                         // 000000377ADC: CC1A4073 1C360310
	v_and_or_b32 v116, 0xffff0000, v100, v51                   // 000000377AE4: D6570074 04CEC8FF FFFF0000
	v_dot2_f32_bf16 v3, v18, v93, v3                           // 000000377AF0: CC1A4003 1C0EBB12
	.long 0x7e6639b7                                           // 000000377AF8: 7E6639B7
	s_waitcnt vmcnt(7)                                         // 000000377AFC: BF891FF7
	v_dot2_f32_bf16 v18, v21, v92, 0                           // 000000377B00: CC1A4012 1A02B915
	v_dot2_f32_bf16 v17, v26, v93, v17                         // 000000377B08: CC1A4011 1C46BB1A
	v_bfe_u32 v55, v54, 16, 1                                  // 000000377B10: D6100037 02052136
	v_dot2_f32_bf16 v3, v19, v94, v3                           // 000000377B18: CC1A4003 1C0EBD13
	v_and_b32_e32 v100, 48, v51                                // 000000377B20: 36C866B0
	v_dot2_f32_bf16 v21, v22, v93, v18                         // 000000377B24: CC1A4015 1C4ABB16
	v_dot2_f32_bf16 v22, v27, v94, v17                         // 000000377B2C: CC1A4016 1C46BD1B
	global_load_b128 v[13:16], v[62:63], off offset:16         // 000000377B34: DC5E0010 0D7C003E
	v_dot2_f32_bf16 v117, v20, v1, v3                          // 000000377B3C: CC1A4075 1C0E0314
	v_and_or_b32 v100, v120, 15, v100                          // 000000377B44: D6570064 05911F78
	v_dot2_f32_bf16 v3, v23, v94, v21                          // 000000377B4C: CC1A4003 1C56BD17
	v_dot2_f32_bf16 v118, v28, v1, v22                         // 000000377B54: CC1A4076 1C5A031C
	global_load_b128 v[25:28], v[68:69], off offset:16         // 000000377B5C: DC5E0010 197C0044
	s_waitcnt vmcnt(8)                                         // 000000377B64: BF8923F7
	v_dot2_f32_bf16 v33, v33, v92, 0                           // 000000377B68: CC1A4021 1A02B921
	global_load_b128 v[17:20], v[66:67], off offset:16         // 000000377B70: DC5E0010 117C0042
	v_dot2_f32_bf16 v119, v24, v1, v3                          // 000000377B78: CC1A4077 1C0E0318
	v_add3_u32 v3, v54, v55, 0x7fff                            // 000000377B80: D6550003 03FE6F36 00007FFF
	.long 0x7f6c39b3                                           // 000000377B8C: 7F6C39B3
	v_cvt_f32_ubyte0_e32 v55, v100                             // 000000377B90: 7E6E2364
	v_dot2_f32_bf16 v33, v34, v93, v33                         // 000000377B94: CC1A4021 1C86BB22
	s_waitcnt vmcnt(8)                                         // 000000377B9C: BF8923F7
	v_dot2_f32_bf16 v34, v45, v92, 0                           // 000000377BA0: CC1A4022 1A02B92D
	.long 0x7e6c3982                                           // 000000377BA8: 7E6C3982
	v_cvt_f32_ubyte0_e32 v45, v99                              // 000000377BAC: 7E5A2363
	v_fma_mix_f32 v2, v55, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377BB0: CC206002 156EB737
	v_dot2_f32_bf16 v33, v35, v94, v33                         // 000000377BB8: CC1A4021 1C86BD23
	v_dot2_f32_bf16 v34, v46, v93, v34                         // 000000377BC0: CC1A4022 1C8ABB2E
	v_and_or_b32 v92, 0xffff0000, v3, v54                      // 000000377BC8: D657005C 04DA06FF FFFF0000
	v_fma_mix_f32 v55, v45, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377BD4: CC206037 156EB72D
	v_bfe_u32 v3, v2, 16, 1                                    // 000000377BDC: D6100003 02052102
	v_dot2_f32_bf16 v93, v36, v1, v33                          // 000000377BE4: CC1A405D 1C860324
	v_dot2_f32_bf16 v45, v47, v94, v34                         // 000000377BEC: CC1A402D 1C8ABD2F
	s_waitcnt vmcnt(7)                                         // 000000377BF4: BF891FF7
	v_dot2_f32_bf16 v37, v37, v92, v104                        // 000000377BF8: CC1A4025 1DA2B925
	v_bfe_u32 v54, v55, 16, 1                                  // 000000377C00: D6100036 02052137
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000377C08: D6550002 03FE0702 00007FFF
	global_load_b128 v[21:24], v[60:61], off offset:32         // 000000377C14: DC5E0020 157C003C
	v_dot2_f32_bf16 v94, v48, v1, v45                          // 000000377C1C: CC1A405E 1CB60330
	v_dot2_f32_bf16 v1, v38, v128, v37                         // 000000377C24: CC1A4001 1C970126
	v_add3_u32 v3, v55, v54, 0x7fff                            // 000000377C2C: D6550003 03FE6D37 00007FFF
	.long 0x7e663982                                           // 000000377C38: 7E663982
	s_clause 0x1                                               // 000000377C3C: BF850001
	global_load_b128 v[45:48], v[56:57], off offset:32         // 000000377C40: DC5E0020 2D7C0038
	global_load_b128 v[103:106], v[58:59], off offset:32       // 000000377C48: DC5E0020 677C003A
	v_and_or_b32 v120, v121, 48, v109                          // 000000377C50: D6570078 05B56179
	v_dot2_f32_bf16 v37, v39, v111, v1                         // 000000377C58: CC1A4025 1C06DF27
	v_and_or_b32 v121, v107, 48, v108                          // 000000377C60: D6570079 05B1616B
	global_load_b128 v[107:110], v[62:63], off offset:32       // 000000377C68: DC5E0020 6B7C003E
	v_and_or_b32 v122, 0xffff0000, v3, v51                     // 000000377C70: D657007A 04CE06FF FFFF0000
	.long 0x7e663984                                           // 000000377C7C: 7E663984
	global_load_b128 v[1:4], v[66:67], off offset:32           // 000000377C80: DC5E0020 017C0042
	v_dot2_f32_bf16 v123, v40, v112, v37                       // 000000377C88: CC1A407B 1C96E128
	global_load_b128 v[37:40], v[68:69], off offset:32         // 000000377C90: DC5E0020 257C0044
	s_waitcnt vmcnt(12)                                        // 000000377C98: BF8933F7
	v_dot2_f32_bf16 v29, v29, v92, v115                        // 000000377C9C: CC1A401D 1DCEB91D
	s_waitcnt vmcnt(11)                                        // 000000377CA4: BF892FF7
	v_dot2_f32_bf16 v41, v41, v92, v117                        // 000000377CA8: CC1A4029 1DD6B929
	v_and_b32_e32 v54, 48, v127                                // 000000377CB0: 366CFEB0
	s_clause 0x1                                               // 000000377CB4: BF850001
	global_load_b128 v[99:102], v[64:65], off offset:48        // 000000377CB8: DC5E0030 637C0040
	global_load_b128 v[33:36], v[60:61], off offset:48         // 000000377CC0: DC5E0030 217C003C
	v_dot2_f32_bf16 v29, v30, v128, v29                        // 000000377CC8: CC1A401D 1C77011E
	v_dot2_f32_bf16 v41, v42, v128, v41                        // 000000377CD0: CC1A4029 1CA7012A
	v_and_b32_e32 v30, 48, v125                                // 000000377CD8: 363CFAB0
	v_and_or_b32 v117, v130, 15, v54                           // 000000377CDC: D6570075 04D91F82
	global_load_b128 v[54:57], v[56:57], off offset:48         // 000000377CE4: DC5E0030 367C0038
	v_dot2_f32_bf16 v29, v31, v111, v29                        // 000000377CEC: CC1A401D 1C76DF1F
	v_dot2_f32_bf16 v41, v43, v111, v41                        // 000000377CF4: CC1A4029 1CA6DF2B
	v_and_or_b32 v115, v129, 15, v30                           // 000000377CFC: D6570073 04791F81
	v_cvt_f32_ubyte0_e32 v117, v117                            // 000000377D04: 7EEA2375
	s_delay_alu instid0(VALU_DEP_4)                            // 000000377D08: BF870004
	v_dot2_f32_bf16 v125, v32, v112, v29                       // 000000377D0C: CC1A407D 1C76E120
	s_clause 0x1                                               // 000000377D14: BF850001
	global_load_b128 v[29:32], v[58:59], off offset:48         // 000000377D18: DC5E0030 1D7C003A
	global_load_b128 v[58:61], v[62:63], off offset:48         // 000000377D20: DC5E0030 3A7C003E
	v_dot2_f32_bf16 v127, v44, v112, v41                       // 000000377D28: CC1A407F 1CA6E12C
	s_clause 0x1                                               // 000000377D30: BF850001
	global_load_b128 v[41:44], v[66:67], off offset:48         // 000000377D34: DC5E0030 297C0042
	global_load_b128 v[62:65], v[68:69], off offset:48         // 000000377D3C: DC5E0030 3E7C0044
	v_and_b32_e32 v67, 48, v124                                // 000000377D44: 3686F8B0
	v_cvt_f32_ubyte0_e32 v66, v120                             // 000000377D48: 7E842378
	v_and_b32_e32 v68, 48, v126                                // 000000377D4C: 3688FCB0
	v_cvt_f32_ubyte0_e32 v69, v115                             // 000000377D50: 7E8A2373
	v_cvt_f32_ubyte0_e32 v115, v121                            // 000000377D54: 7EE62379
	v_and_or_b32 v67, v51, 15, v67                             // 000000377D58: D6570043 050D1F33
	v_fma_mix_f32 v66, v66, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377D60: CC206042 156EB742
	v_and_or_b32 v68, v132, 15, v68                            // 000000377D68: D6570044 05111F84
	v_fma_mix_f32 v69, v69, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377D70: CC206045 156EB745
	v_fma_mix_f32 v117, v117, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377D78: CC206075 156EB775
	v_cvt_f32_ubyte0_e32 v67, v67                              // 000000377D80: 7E862343
	v_bfe_u32 v120, v66, 16, 1                                 // 000000377D84: D6100078 02052142
	v_cvt_f32_ubyte0_e32 v68, v68                              // 000000377D8C: 7E882344
	v_fma_mix_f32 v115, v115, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377D90: CC206073 156EB773
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000377D98: BF870214
	v_fma_mix_f32 v67, v67, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377D9C: CC206043 156EB743
	v_add3_u32 v66, v66, v120, 0x7fff                          // 000000377DA4: D6550042 03FEF142 00007FFF
	v_bfe_u32 v120, v69, 16, 1                                 // 000000377DB0: D6100078 02052145
	v_fma_mix_f32 v68, v68, v91, v91 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000377DB8: CC206044 156EB744
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000377DC0: BF870214
	v_bfe_u32 v91, v67, 16, 1                                  // 000000377DC4: D610005B 02052143
	.long 0x7e8439c2                                           // 000000377DCC: 7E8439C2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000377DD0: BF870254
	v_add3_u32 v69, v69, v120, 0x7fff                          // 000000377DD4: D6550045 03FEF145 00007FFF
	v_bfe_u32 v120, v117, 16, 1                                // 000000377DE0: D6100078 02052175
	.long 0x7f8439b3                                           // 000000377DE8: 7F8439B3
	v_add3_u32 v67, v67, v91, 0x7fff                           // 000000377DEC: D6550043 03FEB743 00007FFF
	v_bfe_u32 v91, v115, 16, 1                                 // 000000377DF8: D610005B 02052173
	v_add3_u32 v117, v117, v120, 0x7fff                        // 000000377E00: D6550075 03FEF175 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000377E0C: BF8700B3
	.long 0x7e6639c3                                           // 000000377E10: 7E6639C3
	s_waitcnt vmcnt(16)                                        // 000000377E14: BF8943F7
	v_dot2_f32_bf16 v9, v9, v92, v118                          // 000000377E18: CC1A4009 1DDAB909
	v_dot2_f32_bf16 v9, v10, v128, v9                          // 000000377E20: CC1A4009 1C27010A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000377E28: BF870091
	v_dot2_f32_bf16 v9, v11, v111, v9                          // 000000377E2C: CC1A4009 1C26DF0B
	v_dot2_f32_bf16 v9, v12, v112, v9                          // 000000377E34: CC1A4009 1C26E10C
	s_waitcnt vmcnt(15)                                        // 000000377E3C: BF893FF7
	v_dot2_f32_bf16 v10, v13, v92, v119                        // 000000377E40: CC1A400A 1DDEB90D
	v_bfe_u32 v13, v68, 16, 1                                  // 000000377E48: D610000D 02052144
	s_waitcnt vmcnt(14)                                        // 000000377E50: BF893BF7
	v_dot2_f32_bf16 v11, v25, v92, v94                         // 000000377E54: CC1A400B 1D7AB919
	s_delay_alu instid0(VALU_DEP_3)                            // 000000377E5C: BF870003
	v_dot2_f32_bf16 v10, v14, v128, v10                        // 000000377E60: CC1A400A 1C2B010E
	s_waitcnt vmcnt(13)                                        // 000000377E68: BF8937F7
	v_dot2_f32_bf16 v17, v17, v92, v93                         // 000000377E6C: CC1A4011 1D76B911
	v_add3_u32 v13, v68, v13, 0x7fff                           // 000000377E74: D655000D 03FE1B44 00007FFF
	v_dot2_f32_bf16 v14, v95, v131, v123                       // 000000377E80: CC1A400E 1DEF075F
	v_dot2_f32_bf16 v11, v26, v128, v11                        // 000000377E88: CC1A400B 1C2F011A
	v_dot2_f32_bf16 v10, v15, v111, v10                        // 000000377E90: CC1A400A 1C2ADF0F
	v_dot2_f32_bf16 v17, v18, v128, v17                        // 000000377E98: CC1A4011 1C470112
	v_and_or_b32 v18, 0xffff0000, v117, v51                    // 000000377EA0: D6570012 04CEEAFF FFFF0000
	.long 0x7e66398d                                           // 000000377EAC: 7E66398D
	v_dot2_f32_bf16 v11, v27, v111, v11                        // 000000377EB0: CC1A400B 1C2EDF1B
	v_dot2_f32_bf16 v10, v16, v112, v10                        // 000000377EB8: CC1A400A 1C2AE110
	v_dot2_f32_bf16 v15, v19, v111, v17                        // 000000377EC0: CC1A400F 1C46DF13
	v_dot2_f32_bf16 v12, v96, v114, v14                        // 000000377EC8: CC1A400C 1C3AE560
	v_and_or_b32 v16, 0xffff0000, v69, v66                     // 000000377ED0: D6570010 050A8AFF FFFF0000
	v_dot2_f32_bf16 v11, v28, v112, v11                        // 000000377EDC: CC1A400B 1C2EE11C
	v_add3_u32 v17, v115, v91, 0x7fff                          // 000000377EE4: D6550011 03FEB773 00007FFF
	v_dot2_f32_bf16 v15, v20, v112, v15                        // 000000377EF0: CC1A400F 1C3EE114
	v_dot2_f32_bf16 v12, v97, v113, v12                        // 000000377EF8: CC1A400C 1C32E361
	v_mov_b32_e32 v91, v90                                     // 000000377F00: 7EB6035A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000377F04: BF870004
	v_and_or_b32 v17, 0xffff0000, v17, v51                     // 000000377F08: D6570011 04CE22FF FFFF0000
	s_waitcnt vmcnt(12)                                        // 000000377F14: BF8933F7
	v_dot2_f32_bf16 v21, v21, v131, v125                       // 000000377F18: CC1A4015 1DF70715
	v_dot2_f32_bf16 v12, v98, v116, v12                        // 000000377F20: CC1A400C 1C32E962
	s_waitcnt vmcnt(11)                                        // 000000377F28: BF892FF7
	v_dot2_f32_bf16 v13, v45, v131, v127                       // 000000377F2C: CC1A400D 1DFF072D
	s_waitcnt vmcnt(10)                                        // 000000377F34: BF892BF7
	v_dot2_f32_bf16 v9, v103, v131, v9                         // 000000377F38: CC1A4009 1C270767
	v_dot2_f32_bf16 v14, v22, v114, v21                        // 000000377F40: CC1A400E 1C56E516
	s_waitcnt vmcnt(9)                                         // 000000377F48: BF8927F7
	v_dot2_f32_bf16 v10, v107, v131, v10                       // 000000377F4C: CC1A400A 1C2B076B
	v_dot2_f32_bf16 v13, v46, v114, v13                        // 000000377F54: CC1A400D 1C36E52E
	v_dot2_f32_bf16 v9, v104, v114, v9                         // 000000377F5C: CC1A4009 1C26E568
	s_waitcnt vmcnt(8)                                         // 000000377F64: BF8923F7
	v_dot2_f32_bf16 v1, v1, v131, v15                          // 000000377F68: CC1A4001 1C3F0701
	v_dot2_f32_bf16 v14, v23, v113, v14                        // 000000377F70: CC1A400E 1C3AE317
	s_waitcnt vmcnt(7)                                         // 000000377F78: BF891FF7
	v_dot2_f32_bf16 v11, v37, v131, v11                        // 000000377F7C: CC1A400B 1C2F0725
	v_dot2_f32_bf16 v10, v108, v114, v10                       // 000000377F84: CC1A400A 1C2AE56C
	v_dot2_f32_bf16 v9, v105, v113, v9                         // 000000377F8C: CC1A4009 1C26E369
	v_dot2_f32_bf16 v1, v2, v114, v1                           // 000000377F94: CC1A4001 1C06E502
	v_dot2_f32_bf16 v14, v24, v116, v14                        // 000000377F9C: CC1A400E 1C3AE918
	v_dot2_f32_bf16 v2, v38, v114, v11                         // 000000377FA4: CC1A4002 1C2EE526
	v_dot2_f32_bf16 v11, v47, v113, v13                        // 000000377FAC: CC1A400B 1C36E32F
	v_dot2_f32_bf16 v10, v109, v113, v10                       // 000000377FB4: CC1A400A 1C2AE36D
	v_dot2_f32_bf16 v1, v3, v113, v1                           // 000000377FBC: CC1A4001 1C06E303
	v_dot2_f32_bf16 v9, v106, v116, v9                         // 000000377FC4: CC1A4009 1C26E96A
	v_dot2_f32_bf16 v2, v39, v113, v2                          // 000000377FCC: CC1A4002 1C0AE327
	v_dot2_f32_bf16 v3, v48, v116, v11                         // 000000377FD4: CC1A4003 1C2EE930
	v_dot2_f32_bf16 v10, v110, v116, v10                       // 000000377FDC: CC1A400A 1C2AE96E
	v_dot2_f32_bf16 v1, v4, v116, v1                           // 000000377FE4: CC1A4001 1C06E904
	s_waitcnt vmcnt(6)                                         // 000000377FEC: BF891BF7
	v_dot2_f32_bf16 v12, v99, v16, v12                         // 000000377FF0: CC1A400C 1C322163
	v_dot2_f32_bf16 v2, v40, v116, v2                          // 000000377FF8: CC1A4002 1C0AE928
	s_waitcnt vmcnt(5)                                         // 000000378000: BF8917F7
	v_dot2_f32_bf16 v14, v33, v16, v14                         // 000000378004: CC1A400E 1C3A2121
	s_waitcnt vmcnt(4)                                         // 00000037800C: BF8913F7
	v_dot2_f32_bf16 v3, v54, v16, v3                           // 000000378010: CC1A4003 1C0E2136
	s_waitcnt vmcnt(3)                                         // 000000378018: BF890FF7
	v_dot2_f32_bf16 v4, v29, v16, v9                           // 00000037801C: CC1A4004 1C26211D
	s_waitcnt vmcnt(2)                                         // 000000378024: BF890BF7
	v_dot2_f32_bf16 v9, v58, v16, v10                          // 000000378028: CC1A4009 1C2A213A
	s_waitcnt vmcnt(1)                                         // 000000378030: BF8907F7
	v_dot2_f32_bf16 v1, v41, v16, v1                           // 000000378034: CC1A4001 1C062129
	s_waitcnt vmcnt(0)                                         // 00000037803C: BF8903F7
	v_dot2_f32_bf16 v2, v62, v16, v2                           // 000000378040: CC1A4002 1C0A213E
	v_dot2_f32_bf16 v12, v100, v122, v12                       // 000000378048: CC1A400C 1C32F564
	v_dot2_f32_bf16 v14, v34, v122, v14                        // 000000378050: CC1A400E 1C3AF522
	v_dot2_f32_bf16 v3, v55, v122, v3                          // 000000378058: CC1A4003 1C0EF537
	v_dot2_f32_bf16 v4, v30, v122, v4                          // 000000378060: CC1A4004 1C12F51E
	v_dot2_f32_bf16 v9, v59, v122, v9                          // 000000378068: CC1A4009 1C26F53B
	v_dot2_f32_bf16 v1, v42, v122, v1                          // 000000378070: CC1A4001 1C06F52A
	v_dot2_f32_bf16 v2, v63, v122, v2                          // 000000378078: CC1A4002 1C0AF53F
	v_dot2_f32_bf16 v12, v101, v18, v12                        // 000000378080: CC1A400C 1C322565
	v_dot2_f32_bf16 v14, v35, v18, v14                         // 000000378088: CC1A400E 1C3A2523
	v_dot2_f32_bf16 v3, v56, v18, v3                           // 000000378090: CC1A4003 1C0E2538
	v_dot2_f32_bf16 v4, v31, v18, v4                           // 000000378098: CC1A4004 1C12251F
	v_dot2_f32_bf16 v9, v60, v18, v9                           // 0000003780A0: CC1A4009 1C26253C
	v_dot2_f32_bf16 v1, v43, v18, v1                           // 0000003780A8: CC1A4001 1C06252B
	v_dot2_f32_bf16 v2, v64, v18, v2                           // 0000003780B0: CC1A4002 1C0A2540
	v_dot2_f32_bf16 v12, v102, v17, v12                        // 0000003780B8: CC1A400C 1C322366
	v_dot2_f32_bf16 v14, v36, v17, v14                         // 0000003780C0: CC1A400E 1C3A2324
	v_dot2_f32_bf16 v3, v57, v17, v3                           // 0000003780C8: CC1A4003 1C0E2339
	v_dot2_f32_bf16 v4, v32, v17, v4                           // 0000003780D0: CC1A4004 1C122320
	v_dot2_f32_bf16 v9, v61, v17, v9                           // 0000003780D8: CC1A4009 1C26233D
	v_dot2_f32_bf16 v1, v44, v17, v1                           // 0000003780E0: CC1A4001 1C06232C
	v_dot2_f32_bf16 v2, v65, v17, v2                           // 0000003780E8: CC1A4002 1C0A2341
	v_dual_add_f32 v82, v82, v12 :: v_dual_add_f32 v81, v81, v14// 0000003780F0: C9081952 52501D51
	v_dual_add_f32 v80, v80, v3 :: v_dual_add_f32 v79, v79, v4 // 0000003780F8: C9080750 504E094F
	v_add_f32_e32 v78, v78, v9                                 // 000000378100: 069C134E
	v_add_f32_e32 v77, v77, v1                                 // 000000378104: 069A034D
	v_add_f32_e32 v73, v73, v2                                 // 000000378108: 06920549
	v_dual_mov_b32 v55, v53 :: v_dual_mov_b32 v54, v52         // 00000037810C: CA100135 37360134
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000378114: CA100108 04020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 00000037811C: CA100106 02000105
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000378124: 917E0F7E
	s_cbranch_execz 39                                         // 000000378128: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11c8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000037812C: BF870111
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v74, 32, v74    // 000000378130: CA200101 054A94A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000378138: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v53, v55           // 000000378140: CA100104 08340137
	v_mov_b32_e32 v52, v54                                     // 000000378148: 7E680336
	s_mov_b32 s20, exec_lo                                     // 00000037814C: BE94007E
	v_cmp_ge_i32_e32 vcc_lo, v74, v75                          // 000000378150: 7C8C974A
	.long 0xd4c1007e                                           // 000000378154: D4C1007E
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000378158: 0202974A
	s_cbranch_execz 64663                                      // 00000037815C: BFA5FC97 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x3bc>
	v_and_b32_e32 v7, -4, v89                                  // 000000378160: 360EB2C4
	v_ashrrev_i32_e32 v6, 31, v87                              // 000000378164: 340CAE9F
	v_ashrrev_i32_e32 v8, 31, v88                              // 000000378168: 3410B09F
	.long 0xd7000005                                           // 00000037816C: D7000005
	v_cndmask_b32_e32 v1, v49, v87, vcc_lo                     // 000000378170: 0202AF31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000378174: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000378178: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v76, v6, s0                  // 00000037817C: D5207C06 00020D4C
	.long 0xd7000009                                           // 000000378184: D7000009
	v_cndmask_b32_e32 v1, v83, v88, vcc_lo                     // 000000378188: 0202B153
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000037818C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v84, v8, s0                 // 000000378190: D5207C0A 00021154
	.long 0xd700000b                                           // 000000378198: D700000B
	v_cndmask_b32_e32 v1, v85, v7, vcc_lo                      // 00000037819C: 02020F55
	v_add_co_ci_u32_e64 v12, null, v86, v12, s0                // 0000003781A0: D5207C0C 00021956
	s_clause 0x2                                               // 0000003781A8: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 0000003781AC: DC5E0000 057C0005
	global_load_b64 v[52:53], v[9:10], off                     // 0000003781B4: DC560000 347C0009
	global_load_b32 v90, v[11:12], off                         // 0000003781BC: DC520000 5A7C000B
	s_branch 64637                                             // 0000003781C4: BFA0FC7D <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x3bc>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000003781C8: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003781CC: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000003781D0: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 0000003781D4: BF890BF7
	.long 0xd71f0001                                           // 0000003781D8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003781DC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003781E0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000003781E4: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000003781E8: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 0000003781EC: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003781F0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003781F4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003781F8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000003781FC: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000378200: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 000000378204: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000378208: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000037820C: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000378210: 30040482
	ds_bpermute_b32 v3, v2, v82                                // 000000378214: DACC0000 03005202
	s_waitcnt lgkmcnt(0)                                       // 00000037821C: BF89FC07
	v_add_f32_e32 v3, v82, v3                                  // 000000378220: 06060752
	ds_bpermute_b32 v4, v2, v81                                // 000000378224: DACC0000 04005102
	ds_bpermute_b32 v5, v2, v80                                // 00000037822C: DACC0000 05005002
	ds_bpermute_b32 v7, v2, v78                                // 000000378234: DACC0000 07004E02
	ds_bpermute_b32 v6, v2, v79                                // 00000037823C: DACC0000 06004F02
	ds_bpermute_b32 v8, v2, v77                                // 000000378244: DACC0000 08004D02
	ds_bpermute_b32 v2, v2, v73                                // 00000037824C: DACC0000 02004902
	ds_bpermute_b32 v10, v9, v3                                // 000000378254: DACC0000 0A000309
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 00000037825C: 02202101
	s_waitcnt lgkmcnt(5)                                       // 000000378260: BF89FC57
	v_dual_add_f32 v4, v81, v4 :: v_dual_add_f32 v5, v80, v5   // 000000378264: C9080951 04040B50
	s_waitcnt lgkmcnt(3)                                       // 00000037826C: BF89FC37
	v_dual_add_f32 v7, v78, v7 :: v_dual_add_f32 v6, v79, v6   // 000000378270: C9080F4E 07060D4F
	s_waitcnt lgkmcnt(2)                                       // 000000378278: BF89FC27
	v_add_f32_e32 v8, v77, v8                                  // 00000037827C: 0610114D
	ds_bpermute_b32 v11, v9, v4                                // 000000378280: DACC0000 0B000409
	ds_bpermute_b32 v12, v9, v5                                // 000000378288: DACC0000 0C000509
	ds_bpermute_b32 v14, v9, v7                                // 000000378290: DACC0000 0E000709
	ds_bpermute_b32 v13, v9, v6                                // 000000378298: DACC0000 0D000609
	s_waitcnt lgkmcnt(4)                                       // 0000003782A0: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 0000003782A4: 06061503
	v_add_f32_e32 v2, v73, v2                                  // 0000003782A8: 06040549
	ds_bpermute_b32 v15, v9, v8                                // 0000003782AC: DACC0000 0F000809
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000003782B4: 30202082
	ds_bpermute_b32 v9, v9, v2                                 // 0000003782B8: DACC0000 09000209
	s_waitcnt lgkmcnt(4)                                       // 0000003782C0: BF89FC47
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000003782C4: C9081704 04041905
	s_waitcnt lgkmcnt(3)                                       // 0000003782CC: BF89FC37
	v_add_f32_e32 v7, v7, v14                                  // 0000003782D0: 060E1D07
	ds_bpermute_b32 v10, v16, v4                               // 0000003782D4: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 0000003782DC: DACC0000 0B000510
	s_waitcnt lgkmcnt(4)                                       // 0000003782E4: BF89FC47
	v_add_f32_e32 v6, v6, v13                                  // 0000003782E8: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 0000003782EC: DACC0000 0D000710
	s_waitcnt lgkmcnt(4)                                       // 0000003782F4: BF89FC47
	v_add_f32_e32 v8, v8, v15                                  // 0000003782F8: 06101F08
	s_waitcnt lgkmcnt(3)                                       // 0000003782FC: BF89FC37
	v_add_f32_e32 v2, v2, v9                                   // 000000378300: 06041302
	ds_bpermute_b32 v9, v16, v3                                // 000000378304: DACC0000 09000310
	ds_bpermute_b32 v15, v16, v2                               // 00000037830C: DACC0000 0F000210
	s_waitcnt lgkmcnt(3)                                       // 000000378314: BF89FC37
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000378318: C9081504 04041705
	ds_bpermute_b32 v12, v16, v6                               // 000000378320: DACC0000 0C000610
	s_waitcnt lgkmcnt(3)                                       // 000000378328: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 00000037832C: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 000000378330: DACC0000 0E000810
	v_xor_b32_e32 v16, 2, v1                                   // 000000378338: 3A200282
	s_waitcnt lgkmcnt(3)                                       // 00000037833C: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 000000378340: 06061303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000378344: BF8700C2
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 000000378348: 7C9820A0
	s_waitcnt lgkmcnt(2)                                       // 00000037834C: BF89FC27
	v_add_f32_e32 v10, v2, v15                                 // 000000378350: 06141F02
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 000000378354: 02202101
	v_lshlrev_b32_e32 v16, 2, v16                              // 000000378358: 30202082
	s_waitcnt lgkmcnt(0)                                       // 00000037835C: BF89FC07
	v_add_f32_e32 v8, v8, v14                                  // 000000378360: 06101D08
	ds_bpermute_b32 v2, v16, v3                                // 000000378364: DACC0000 02000310
	ds_bpermute_b32 v9, v16, v4                                // 00000037836C: DACC0000 09000410
	ds_bpermute_b32 v11, v16, v5                               // 000000378374: DACC0000 0B000510
	ds_bpermute_b32 v13, v16, v7                               // 00000037837C: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v8                               // 000000378384: DACC0000 0E000810
	v_add_f32_e32 v6, v6, v12                                  // 00000037838C: 060C1906
	ds_bpermute_b32 v15, v16, v10                              // 000000378390: DACC0000 0F000A10
	ds_bpermute_b32 v12, v16, v6                               // 000000378398: DACC0000 0C000610
	v_xor_b32_e32 v16, 1, v1                                   // 0000003783A0: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000003783A4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000003783A8: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 0000003783AC: 02022101
	s_waitcnt lgkmcnt(6)                                       // 0000003783B0: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v16, 2, v1 // 0000003783B4: C9220503 01100282
	s_waitcnt lgkmcnt(3)                                       // 0000003783BC: BF89FC37
	v_dual_add_f32 v2, v5, v11 :: v_dual_add_f32 v3, v7, v13   // 0000003783C0: C9081705 02021B07
	s_waitcnt lgkmcnt(1)                                       // 0000003783C8: BF89FC17
	v_dual_add_f32 v5, v10, v15 :: v_dual_add_f32 v4, v4, v9   // 0000003783CC: C9081F0A 05041304
	s_waitcnt lgkmcnt(0)                                       // 0000003783D4: BF89FC07
	v_dual_add_f32 v9, v8, v14 :: v_dual_add_f32 v6, v6, v12   // 0000003783D8: C9081D08 09061906
	ds_bpermute_b32 v7, v16, v1                                // 0000003783E0: DACC0000 07000110
	ds_bpermute_b32 v8, v16, v2                                // 0000003783E8: DACC0000 08000210
	ds_bpermute_b32 v11, v16, v4                               // 0000003783F0: DACC0000 0B000410
	ds_bpermute_b32 v10, v16, v3                               // 0000003783F8: DACC0000 0A000310
	ds_bpermute_b32 v13, v16, v6                               // 000000378400: DACC0000 0D000610
	ds_bpermute_b32 v14, v16, v9                               // 000000378408: DACC0000 0E000910
	ds_bpermute_b32 v12, v16, v5                               // 000000378410: DACC0000 0C000510
	v_cmpx_eq_u32_e32 0, v71                                   // 000000378418: 7D948E80
	s_cbranch_execz 22                                         // 00000037841C: BFA50016 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1478>
	v_lshl_add_u32 v15, v70, s18, v72                          // 000000378420: D646000F 05202546
	s_waitcnt lgkmcnt(3)                                       // 000000378428: BF89FC37
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v10   // 00000037842C: C9081704 04021503
	v_dual_add_f32 v1, v1, v7 :: v_dual_add_f32 v2, v2, v8     // 000000378434: C9080F01 01021102
	s_delay_alu instid0(VALU_DEP_3)                            // 00000037843C: BF870003
	v_mul_u32_u24_e32 v7, 28, v15                              // 000000378440: 160E1E9C
	s_waitcnt lgkmcnt(1)                                       // 000000378444: BF89FC17
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v6, v6, v13   // 000000378448: C9081D09 09061B06
	s_waitcnt lgkmcnt(0)                                       // 000000378450: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000378454: 060A1905
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 000000378458: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 000000378460: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v9 offset0:4 offset1:5          // 000000378468: D8380504 00090307
	ds_store_b32 v7, v5 offset:24                              // 000000378470: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 000000378478: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000037847C: BF870009
	s_and_b32 s0, s17, exec_lo                                 // 000000378480: 8B007E11
	s_cselect_b32 s0, 7, 28                                    // 000000378484: 98009C87
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000378488: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 00000037848C: 7C980000
	s_barrier                                                  // 000000378490: BFBD0000
	buffer_gl0_inv                                             // 000000378494: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000037849C: BE80206A
	s_cbranch_execz 411                                        // 0000003784A0: BFA5019B <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1b10>
	.long 0xd7054000                                           // 0000003784A4: D7054000
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000003784A8: 02014B00
	.long 0x7f063880                                           // 0000003784AC: 7F063880
	v_mov_b32_e32 v4, 0                                        // 0000003784B0: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003784B4: BF870093
	.long 0xd7395000                                           // 0000003784B8: D7395000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000003784BC: 02020088
	.long 0xd7041001                                           // 0000003784C0: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003784C4: 02020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003784C8: BF870091
	.long 0xd7390001                                           // 0000003784CC: D7390001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003784D0: 02020281
	.long 0xd7620001                                           // 0000003784D4: D7620001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000003784D8: 020202FF 0000007F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003784E0: BF870091
	.long 0xd7035000                                           // 0000003784E4: D7035000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000003784E8: 02020101
	.long 0xd7391003                                           // 0000003784EC: D7391003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003784F0: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003784F4: BF870091
	.long 0xd7000001                                           // 0000003784F8: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000003784FC: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000378500: D5207C02 00010003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000378508: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 00000037850C: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000378510: 8B7E6A7E
	s_cbranch_execz 382                                        // 000000378514: BFA5017E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1b10>
	.long 0xd7054000                                           // 000000378518: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 00000037851C: 02010F03
	v_lshlrev_b32_e32 v3, s18, v3                              // 000000378520: 30060612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000378524: BF870112
	.long 0xd7041000                                           // 000000378528: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000037852C: 02020100
	v_mul_u32_u24_e32 v3, 28, v3                               // 000000378530: 1606069C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378534: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 000000378538: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 000000378540: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 000000378548: D8D80000 05000003
	v_add_nc_u32_e32 v3, 28, v3                                // 000000378550: 4A06069C
	s_add_i32 s16, s16, -1                                     // 000000378554: 8110C110
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000378558: BF870009
	s_cmp_eq_u32 s16, 0                                        // 00000037855C: BF068010
	s_waitcnt lgkmcnt(0)                                       // 000000378560: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 000000378564: 06080B04
	s_cbranch_scc0 65527                                       // 000000378568: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1548>
	s_clause 0x1                                               // 00000037856C: BF850001
	s_load_b64 s[2:3], s[10:11], 0x38                          // 000000378570: F4040085 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 000000378578: F4040005 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 000000378580: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 000000378588: BE8600C1
	s_mov_b32 s4, 0                                            // 00000037858C: BE840080
	s_mov_b32 s5, 0                                            // 000000378590: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000378594: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000378598: BF048303
	s_cbranch_scc1 183                                         // 00000037859C: BFA200B7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x187c>
	s_cmp_gt_i32 s3, 3                                         // 0000003785A0: BF028303
	s_cbranch_scc0 117                                         // 0000003785A4: BFA10075 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x177c>
	s_cmp_gt_i32 s3, 4                                         // 0000003785A8: BF028403
	s_cbranch_scc0 62                                          // 0000003785AC: BFA1003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x16a8>
	s_cmp_eq_u32 s3, 5                                         // 0000003785B0: BF068503
	s_mov_b32 s5, -1                                           // 0000003785B4: BE8500C1
	s_cbranch_scc0 58                                          // 0000003785B8: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x16a4>
	s_load_b64 s[6:7], s[10:11], 0x10                          // 0000003785BC: F4040185 F8000010
	s_lshr_b64 s[10:11], s[8:9], 1                             // 0000003785C4: 858A8108
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v0, 7, v2           // 0000003785C8: CA240080 09000487
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 0000003785D0: D6FE7C05 0202060A
	v_and_b32_e32 v8, 0x1ff, v1                                // 0000003785D8: 361002FF 000001FF
	s_lshr_b32 s5, s9, 1                                       // 0000003785E0: 85058109
	v_dual_mov_b32 v11, s0 :: v_dual_and_b32 v10, 0xfffffe00, v1// 0000003785E4: CA240000 0B0A02FF FFFFFE00
	v_bfe_u32 v14, v4, 16, 1                                   // 0000003785F0: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003785F8: BF8700C4
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 0000003785FC: D6FE7C06 041A0605
	v_mov_b32_e32 v7, s1                                       // 000000378604: 7E0E0201
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[8:9]                     // 000000378608: 7CB810FF 00000100
	.long 0xd7000509                                           // 000000378610: D7000509
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 000000378614: 020210FF FFFFFF00
	v_add_co_ci_u32_e64 v12, null, 0, -1, s5                   // 00000037861C: D5207C0C 00158280
	s_mov_b32 s5, 0                                            // 000000378624: BE850080
	.long 0xd73c0005                                           // 000000378628: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000037862C: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 000000378630: BF89FC07
	v_cndmask_b32_e32 v11, s6, v11, vcc_lo                     // 000000378634: 02161606
	v_cndmask_b32_e32 v13, s7, v7, vcc_lo                      // 000000378638: 021A0E07
	v_cndmask_b32_e32 v7, v9, v8, vcc_lo                       // 00000037863C: 020E1109
	v_cndmask_b32_e64 v8, v12, 0, vcc_lo                       // 000000378640: D5010008 01A9010C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378648: BF870094
	.long 0xd7006a09                                           // 00000037864C: D7006A09
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000378650: 02020B0B
	v_add_co_ci_u32_e64 v11, null, v13, v6, vcc_lo             // 000000378654: D5207C0B 01AA0D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000037865C: BF870193
	.long 0xd73c0005                                           // 000000378660: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000378664: 02020E81
	.long 0xd7006a07                                           // 000000378668: D7006A07
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000037866C: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000378670: BF8701A1
	v_add_co_ci_u32_e64 v0, null, v11, v0, vcc_lo              // 000000378674: D5207C00 01AA010B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 00000037867C: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 000000378688: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000037868C: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000378690: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v6, vcc_lo               // 000000378694: D5207C06 01AA0D00
	global_store_d16_hi_b16 v[5:6], v8, off                    // 00000037869C: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 0000003786A4: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003786A8: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000003786AC: 8B6A067E
	s_cbranch_vccz 49                                          // 0000003786B0: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1778>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000003786B4: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003786BC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000003786C0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003786C4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003786C8: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000003786CC: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000003786D4: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000003786DC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003786E0: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000003786E4: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000003786EC: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000003786F0: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003786F8: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 0000003786FC: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000378700: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378708: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 00000037870C: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 000000378714: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000378718: BF870113
	.long 0xd73c0005                                           // 00000037871C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000378720: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 000000378724: D613000A 242A1708
	.long 0xd73c0007                                           // 00000037872C: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000378730: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000378734: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 000000378738: D6370009 042E130A
	.long 0xd7006a05                                           // 000000378740: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000378744: 02020A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000378748: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 00000037874C: D5207C06 01AA0C01
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000378754: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000037875C: BF870093
	.long 0xd7006a05                                           // 000000378760: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000378764: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000378768: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000378770: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000378778: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000037877C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000378780: 8B6A067E
	s_cbranch_vccz 60                                          // 000000378784: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1878>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000378788: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378790: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 000000378794: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003787A0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003787A8: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000003787AC: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003787B0: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003787B8: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000003787BC: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003787C0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003787C4: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000003787C8: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000003787D0: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000003787D8: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003787DC: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000003787E0: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 0000003787E8: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000003787EC: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003787F4: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 0000003787F8: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 0000003787FC: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000378804: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 000000378808: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 00000037880C: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000378814: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 000000378818: D6130007 242A1708
	.long 0xd73c0005                                           // 000000378820: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000378824: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000378828: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 00000037882C: D6370009 042E1307
	.long 0xd73c0007                                           // 000000378834: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000378838: 02020282
	.long 0xd7006a05                                           // 00000037883C: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000378840: 02020A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000378844: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000378848: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000378850: D5207C06 01AA0C01
	.long 0xd7006a05                                           // 000000378858: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000037885C: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000378860: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 000000378864: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000378868: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 000000378870: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000378878: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000037887C: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000378880: 8B6A067E
	s_cbranch_vccz 73                                          // 000000378884: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x19ac>
	s_cmp_gt_i32 s3, 1                                         // 000000378888: BF028103
	s_mov_b32 s4, -1                                           // 00000037888C: BE8400C1
	s_cbranch_scc0 64                                          // 000000378890: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1994>
	v_bfe_u32 v0, v4, 16, 1                                    // 000000378894: D6100000 02052104
	s_mov_b32 s4, 0                                            // 00000037889C: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003788A0: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000003788A4: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003788B0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003788B8: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003788BC: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000003788C4: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003788C8: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003788CC: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000003788D0: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000003788D8: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003788E0: BF870292
	v_rcp_f32_e32 v8, v7                                       // 0000003788E4: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000003788E8: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003788F0: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 0000003788F4: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 0000003788F8: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000378900: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378904: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 000000378908: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 000000378910: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000378914: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 000000378918: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000378920: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 000000378928: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000378930: BF870112
	.long 0xd73c0005                                           // 000000378934: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000378938: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 00000037893C: D6270000 03CA0107
	.long 0xd73c0007                                           // 000000378944: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000378948: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000037894C: BF870193
	.long 0xd7006a05                                           // 000000378950: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000378954: 02020A00
	v_bfe_u32 v9, v0, 16, 1                                    // 000000378958: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000378960: D5207C06 01AA0C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000378968: BF870193
	.long 0xd7006a05                                           // 00000037896C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000378970: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 000000378974: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000378980: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000378984: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 00000037898C: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000378994: 916A047E
	s_mov_b32 s4, 0                                            // 000000378998: BE840080
	s_cbranch_vccnz 3                                          // 00000037899C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x19ac>
	s_cmp_lg_u32 s3, 1                                         // 0000003789A0: BF078103
	s_mov_b32 s4, -1                                           // 0000003789A4: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 0000003789A8: 980580C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003789AC: D6100005 02052104
	.long 0xd73c0000                                           // 0000003789B4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003789B8: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000003789BC: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003789C0: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000003789C4: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000003789D0: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1a24>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000003789D4: D6FE7C04 02020608
	s_mov_b32 s4, 0                                            // 0000003789DC: BE840080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000003789E0: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003789E8: BF870091
	.long 0xd73c0004                                           // 0000003789EC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003789F0: 02020881
	.long 0xd7006a04                                           // 0000003789F4: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000003789F8: 02020800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003789FC: BF870111
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 000000378A00: D5207C05 01AA0A01
	.long 0xd7006a04                                           // 000000378A08: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 000000378A0C: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 000000378A10: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 000000378A14: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 000000378A1C: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000378A24: 916A047E
	s_cbranch_vccnz 57                                         // 000000378A28: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi7ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1b10>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378A2C: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000378A30: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 000000378A38: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378A3C: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 000000378A40: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000378A48: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378A4C: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 000000378A50: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 000000378A54: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 000000378A5C: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000378A64: BF870292
	v_rcp_f32_e32 v8, v6                                       // 000000378A68: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 000000378A6C: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000378A74: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 000000378A78: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 000000378A7C: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 000000378A84: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378A88: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 000000378A8C: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 000000378A94: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000378A98: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 000000378A9C: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 000000378AA4: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 000000378AAC: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000378AB4: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 000000378AB8: D6270006 040A0F03
	.long 0xd73c0002                                           // 000000378AC0: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000378AC4: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000378AC8: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 000000378ACC: D6100004 02052106
	.long 0xd7006a02                                           // 000000378AD4: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000378AD8: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000378ADC: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 000000378AE0: D5207C03 01AA0601
	v_add3_u32 v4, v6, v4, 0x7fff                              // 000000378AE8: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000378AF4: BF870093
	.long 0xd7006a00                                           // 000000378AF8: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 000000378AFC: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 000000378B00: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 000000378B08: DC960000 007C0400
	s_nop 0                                                    // 000000378B10: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000378B14: BFB60003
	s_endpgm                                                   // 000000378B18: BFB00000
		...

