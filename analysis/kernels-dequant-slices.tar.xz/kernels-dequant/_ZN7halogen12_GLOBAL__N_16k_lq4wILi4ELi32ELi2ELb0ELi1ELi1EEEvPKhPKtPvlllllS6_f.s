00000000007c9f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C9F00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007C9F08: 86039F02
	v_lshrrev_b32_e32 v21, 2, v0                               // 0000007C9F0C: 322A0082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007C9F10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000007C9F14: 3602008F
	v_lshrrev_b32_e32 v22, 6, v0                               // 0000007C9F18: 322C0086
	v_bfe_u32 v23, v0, 5, 1                                    // 0000007C9F1C: D6100017 02050B00
	v_and_b32_e32 v2, 60, v21                                  // 0000007C9F24: 36042ABC
	.long 0x7f0a3880                                           // 0000007C9F28: 7F0A3880
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C9F2C: 30020282
	s_waitcnt lgkmcnt(0)                                       // 0000007C9F30: BF89FC07
	s_clause 0x1                                               // 0000007C9F34: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007C9F38: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007C9F40: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000007C9F48: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000007C9F4C: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000007C9F50: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000007C9F54: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000007C9F58: 85109B10
	v_or_b32_e32 v1, s20, v22                                  // 0000007C9F5C: 38022C14
	s_add_u32 s16, s10, s16                                    // 0000007C9F60: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007C9F64: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C9F68: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007C9F6C: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007C9F70: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007C9F74: 81118110
	v_and_b32_e32 v24, 31, v0                                  // 0000007C9F78: 3630009F
	s_lshr_b32 s22, s17, 31                                    // 0000007C9F7C: 85169F11
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C9F80: BF870009
	s_add_i32 s17, s17, s22                                    // 0000007C9F84: 81111611
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 0000007C9F88: 02120280
	s_ashr_i32 s17, s17, 1                                     // 0000007C9F8C: 86118111
	v_cndmask_b32_e64 v10, 0, s21, vcc_lo                      // 0000007C9F90: D501000A 01A82A80
	.long 0xd72c0002                                           // 0000007C9F98: D72C0002
	v_cndmask_b32_e32 v1, s17, v23, vcc_lo                     // 0000007C9F9C: 02022E11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007C9FA0: B3900201
	.long 0xd72c0007                                           // 0000007C9FA4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000007C9FA8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[2:3]              // 0000007C9FAC: D6FE7C11 000A1212
	s_cselect_b32 s2, -1, 0                                    // 0000007C9FB4: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007C9FB8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000007C9FBC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000007C9FC0: 4A160411
	v_add_nc_u32_e32 v25, v2, v24                              // 0000007C9FC4: 4A323102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007C9FC8: BF8704A2
	v_min_i32_e32 v26, s16, v11                                // 0000007C9FCC: 22341610
	s_cselect_b32 s16, -1, 0                                   // 0000007C9FD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007C9FD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C9FD8: BF870151
	.long 0xd4410003                                           // 0000007C9FDC: D4410003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000007C9FE0: 02023519
	s_waitcnt vmcnt(1)                                         // 0000007C9FE4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007C9FE8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000007C9FF0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000007C9FF4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007C9FFC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 0000007CA008: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 0000007CA00C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CA010: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000007CA014: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 0000007CA020: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CA024: BF870113
	v_add3_u32 v27, v7, v18, v6                                // 0000007CA028: D655001B 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 0000007CA030: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 0000007CA03C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 0000007CA044: BF89FC07
	s_barrier                                                  // 0000007CA048: BFBD0000
	buffer_gl0_inv                                             // 0000007CA04C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007CA054: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007CA058: CA100080 02000080
	s_and_saveexec_b32 s17, s3                                 // 0000007CA060: BE912003
	s_cbranch_execz 11                                         // 0000007CA064: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v25                               // 0000007CA068: 30023281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA06C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007CA070: 3408029F
	.long 0xd7006a03                                           // 0000007CA074: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007CA078: 02020311
	v_add_co_ci_u32_e64 v4, null, v27, v4, vcc_lo              // 0000007CA07C: D5207C04 01AA091B
	global_load_d16_b16 v1, v[3:4], off                        // 0000007CA084: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007CA08C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007CA090: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007CA094: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v25                               // 0000007CA098: 4A0632A0
	s_mov_b32 s3, exec_lo                                      // 0000007CA09C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA0A0: BF870001
	.long 0xd4c1007e                                           // 0000007CA0A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v26, vcc_lo                      // 0000007CA0A8: 02023503
	s_cbranch_execz 11                                         // 0000007CA0AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007CA0B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA0B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007CA0B8: 3406049F
	.long 0xd7006a02                                           // 0000007CA0BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007CA0C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v27, v3, vcc_lo              // 0000007CA0C4: D5207C03 01AA071B
	global_load_d16_b16 v2, v[2:3], off                        // 0000007CA0CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007CA0D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007CA0D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA0DC: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v25      // 0000007CA0E0: CA200080 040432C0
	v_mov_b32_e32 v3, 0                                        // 0000007CA0E8: 7E060280
	s_mov_b32 s3, exec_lo                                      // 0000007CA0EC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CA0F0: BF870002
	.long 0xd4c1007e                                           // 0000007CA0F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 0000007CA0F8: 02023505
	s_cbranch_execz 11                                         // 0000007CA0FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007CA100: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA104: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007CA108: 340C069F
	.long 0xd7006a05                                           // 0000007CA10C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007CA110: 02020711
	v_add_co_ci_u32_e64 v6, null, v27, v6, vcc_lo              // 0000007CA114: D5207C06 01AA0D1B
	global_load_d16_b16 v3, v[5:6], off                        // 0000007CA11C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007CA124: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007CA128: 7E061703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA12C: 8C7E037E
	v_add_nc_u32_e32 v5, 0x60, v25                             // 0000007CA130: 4A0A32FF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000007CA138: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA13C: BF870001
	.long 0xd4c1007e                                           // 0000007CA140: D4C1007E
	v_cndmask_b32_e32 v1, v5, v26, vcc_lo                      // 0000007CA144: 02023505
	s_cbranch_execz 11                                         // 0000007CA148: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007CA14C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA150: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007CA154: 340A089F
	.long 0xd7006a04                                           // 0000007CA158: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007CA15C: 02020911
	v_add_co_ci_u32_e64 v5, null, v27, v5, vcc_lo              // 0000007CA160: D5207C05 01AA0B1B
	global_load_d16_b16 v4, v[4:5], off                        // 0000007CA168: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007CA170: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007CA174: 7E081704
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA178: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v25    // 0000007CA17C: CA200080 060632FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007CA188: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 0000007CA18C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CA190: BF870002
	.long 0xd4c1007e                                           // 0000007CA194: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 0000007CA198: 02023507
	s_cbranch_execz 11                                         // 0000007CA19C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007CA1A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA1A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007CA1A8: 34100A9F
	.long 0xd7006a07                                           // 0000007CA1AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007CA1B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v27, v8, vcc_lo              // 0000007CA1B4: D5207C08 01AA111B
	global_load_d16_b16 v5, v[7:8], off                        // 0000007CA1BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007CA1C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007CA1C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA1CC: 8C7E037E
	v_add_nc_u32_e32 v7, 0xa0, v25                             // 0000007CA1D0: 4A0E32FF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000007CA1D8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA1DC: BF870001
	.long 0xd4c1007e                                           // 0000007CA1E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v26, vcc_lo                      // 0000007CA1E4: 02023507
	s_cbranch_execz 11                                         // 0000007CA1E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007CA1EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA1F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007CA1F4: 340E0C9F
	.long 0xd7006a06                                           // 0000007CA1F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007CA1FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v27, v7, vcc_lo              // 0000007CA200: D5207C07 01AA0F1B
	global_load_d16_b16 v6, v[6:7], off                        // 0000007CA208: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007CA210: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007CA214: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA218: 8C7E037E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v25   // 0000007CA21C: CA200080 080A32FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007CA228: 7E0E0280
	s_mov_b32 s3, exec_lo                                      // 0000007CA22C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CA230: BF870002
	.long 0xd4c1007e                                           // 0000007CA234: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000007CA238: 0202350B
	s_cbranch_execz 11                                         // 0000007CA23C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 0000007CA240: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA244: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 0000007CA248: 34180E9F
	.long 0xd7006a0b                                           // 0000007CA24C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007CA250: 02020F11
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 0000007CA254: D5207C0C 01AA191B
	global_load_d16_b16 v7, v[11:12], off                      // 0000007CA25C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 0000007CA264: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007CA268: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA26C: 8C7E037E
	v_add_nc_u32_e32 v11, 0xe0, v25                            // 0000007CA270: 4A1632FF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000007CA278: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA27C: BF870001
	.long 0xd4c1007e                                           // 0000007CA280: D4C1007E
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000007CA284: 0202350B
	s_cbranch_execz 11                                         // 0000007CA288: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 0000007CA28C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA290: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 0000007CA294: 3418109F
	.long 0xd7006a0b                                           // 0000007CA298: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007CA29C: 02021111
	v_add_co_ci_u32_e64 v12, null, v27, v12, vcc_lo            // 0000007CA2A0: D5207C0C 01AA191B
	global_load_d16_b16 v8, v[11:12], off                      // 0000007CA2A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000007CA2B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007CA2B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007CA2B8: 8C7E037E
	s_branch 9                                                 // 0000007CA2BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000007CA2C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA2C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007CA2C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007CA2CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007CA2D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007CA2D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007CA2D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007CA2DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007CA2E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007CA2E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007CA2E8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000007CA2EC: 85039F0B
	v_dual_mov_b32 v13, 0 :: v_dual_mov_b32 v28, 0             // 0000007CA2F0: CA100080 0D1C0080
	s_add_u32 s14, s10, s3                                     // 0000007CA2F8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 0000007CA2FC: 820F800B
	.long 0xd4410003                                           // 0000007CA300: D4410003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000007CA304: 02023519
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007CA308: 868E810E
	v_cndmask_b32_e64 v29, 0, 1, s16                           // 0000007CA30C: D501001D 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 0000007CA314: D6FE7C12 00101D09
	.long 0xd72c0009                                           // 0000007CA31C: D72C0009
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 0000007CA320: 02001F09
	.long 0xd72c000a                                           // 0000007CA324: D72C000A
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000007CA328: 02001D0A
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v15, 0             // 0000007CA32C: CA100080 140E0080
	v_mov_b32_e32 v14, 0                                       // 0000007CA334: 7E1C0280
	v_mov_b32_e32 v16, 0                                       // 0000007CA338: 7E200280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007CA33C: BF870004
	v_add3_u32 v30, v10, v19, v9                               // 0000007CA340: D655001E 0426270A
	s_and_saveexec_b32 s4, s3                                  // 0000007CA348: BE842003
	s_cbranch_execz 22                                         // 0000007CA34C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v9, 4, v25     // 0000007CA350: CA220080 14083284
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA358: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007CA35C: 3414129F
	.long 0xd7006a09                                           // 0000007CA360: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007CA364: 02021312
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 0000007CA368: D5207C0A 01AA151E
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007CA370: 916A107E
	global_load_b128 v[13:16], v[9:10], off                    // 0000007CA374: DC5E0000 0D7C0009
	s_cbranch_vccnz 10                                         // 0000007CA37C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 1, v25                               // 0000007CA380: 30123281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA384: BF870091
	.long 0xd7006a09                                           // 0000007CA388: D7006A09
	v_cndmask_b32_e32 v1, v17, v9, vcc_lo                      // 0000007CA38C: 02021311
	v_add_co_ci_u32_e64 v10, null, 0, v27, vcc_lo              // 0000007CA390: D5207C0A 01AA3680
	global_load_d16_b16 v9, v[9:10], off                       // 0000007CA398: DC820000 097C0009
	s_waitcnt vmcnt(0)                                         // 0000007CA3A0: BF8903F7
	v_cvt_f32_f16_e32 v20, v9                                  // 0000007CA3A4: 7E281709
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007CA3A8: 8C7E047E
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v33, 0             // 0000007CA3AC: CA100080 20200080
	v_mov_b32_e32 v31, 0                                       // 0000007CA3B4: 7E3E0280
	s_and_saveexec_b32 s14, s3                                 // 0000007CA3B8: BE8E2003
	s_cbranch_execz 430                                        // 0000007CA3BC: BFA501AE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_dual_mov_b32 v32, 0 :: v_dual_add_nc_u32 v9, 32, v25     // 0000007CA3C0: CA200080 200832A0
	v_dual_mov_b32 v28, 0 :: v_dual_lshlrev_b32 v19, 5, v25    // 0000007CA3C8: CA220080 1C123285
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CA3D0: BF870002
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v34, 4, v9     // 0000007CA3D4: CA220080 21221284
	v_mov_b32_e32 v31, 0                                       // 0000007CA3DC: 7E3E0280
	v_dual_mov_b32 v36, v20 :: v_dual_lshlrev_b32 v35, 1, v9   // 0000007CA3E0: CA220114 24221281
	s_mul_i32 s3, s11, 6                                       // 0000007CA3E8: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000007CA3EC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007CA3F0: 8484820A
	s_add_i32 s15, s15, s3                                     // 0000007CA3F4: 810F030F
	s_mul_i32 s17, s10, 6                                      // 0000007CA3F8: 9611860A
	s_mov_b32 s16, 0                                           // 0000007CA3FC: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007CA400: 848A810A
	s_branch 376                                               // 0000007CA404: BFA00178 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xae8>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007CA408: 8C7E127E
	v_cndmask_b32_e64 v51, v20, v1, s2                         // 0000007CA40C: D5010033 000A0314
	v_cndmask_b32_e64 v37, v1, v2, s2                          // 0000007CA414: D5010025 000A0501
	v_dual_mov_b32 v44, v8 :: v_dual_and_b32 v1, 0xff, v13     // 0000007CA41C: CA240108 2C001AFF 000000FF
	v_cndmask_b32_e64 v43, v7, v8, s2                          // 0000007CA428: D501002B 000A1107
	v_cndmask_b32_e64 v42, v6, v7, s2                          // 0000007CA430: D501002A 000A0F06
	v_cndmask_b32_e64 v41, v5, v6, s2                          // 0000007CA438: D5010029 000A0D05
	v_cndmask_b32_e64 v40, v4, v5, s2                          // 0000007CA440: D5010028 000A0B04
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007CA448: 30020282
	v_cndmask_b32_e64 v39, v3, v4, s2                          // 0000007CA44C: D5010027 000A0903
	v_cndmask_b32_e64 v38, v2, v3, s2                          // 0000007CA454: D5010026 000A0702
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007CA45C: 3428269F
	s_and_b32 s3, exec_lo, s3                                  // 0000007CA460: 8B03037E
	ds_load_b32 v52, v1                                        // 0000007CA464: D8D80000 34000001
	v_lshrrev_b32_e32 v1, 6, v13                               // 0000007CA46C: 32021A86
	s_or_b32 s16, s3, s16                                      // 0000007CA470: 8C101003
	v_add_nc_u32_e32 v34, 0x200, v34                           // 0000007CA474: 4A4444FF 00000200
	v_add_nc_u32_e32 v35, 64, v35                              // 0000007CA47C: 4A4646C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA480: BF8700B3
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA484: 360202FF 000003FC
	ds_load_b32 v53, v1                                        // 0000007CA48C: D8D80000 35000001
	v_lshrrev_b32_e32 v1, 14, v13                              // 0000007CA494: 32021A8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA498: 360202FF 000003FC
	ds_load_b32 v54, v1                                        // 0000007CA4A0: D8D80000 36000001
	v_lshrrev_b32_e32 v1, 22, v13                              // 0000007CA4A8: 32021A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA4AC: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA4B0: 360202FF 000003FC
	ds_load_b32 v55, v1                                        // 0000007CA4B8: D8D80000 37000001
	v_and_b32_e32 v1, 0xff, v14                                // 0000007CA4C0: 36021CFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007CA4C8: 30020282
	ds_load_b32 v56, v1                                        // 0000007CA4CC: D8D80000 38000001
	v_lshrrev_b32_e32 v1, 6, v14                               // 0000007CA4D4: 32021C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA4D8: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA4DC: 360202FF 000003FC
	ds_load_b32 v57, v1                                        // 0000007CA4E4: D8D80000 39000001
	v_lshrrev_b32_e32 v1, 14, v14                              // 0000007CA4EC: 32021C8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA4F0: 360202FF 000003FC
	ds_load_b32 v58, v1                                        // 0000007CA4F8: D8D80000 3A000001
	v_lshrrev_b32_e32 v1, 22, v14                              // 0000007CA500: 32021C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA504: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA508: 360202FF 000003FC
	ds_load_b32 v59, v1                                        // 0000007CA510: D8D80000 3B000001
	v_and_b32_e32 v1, 0xff, v15                                // 0000007CA518: 36021EFF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007CA520: 30020282
	ds_load_b32 v60, v1                                        // 0000007CA524: D8D80000 3C000001
	v_lshrrev_b32_e32 v1, 6, v15                               // 0000007CA52C: 32021E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA530: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA534: 360202FF 000003FC
	ds_load_b32 v61, v1                                        // 0000007CA53C: D8D80000 3D000001
	v_lshrrev_b32_e32 v1, 14, v15                              // 0000007CA544: 32021E8E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA548: 360202FF 000003FC
	ds_load_b32 v62, v1                                        // 0000007CA550: D8D80000 3E000001
	v_lshrrev_b32_e32 v1, 22, v15                              // 0000007CA558: 32021E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA55C: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA560: 360202FF 000003FC
	ds_load_b32 v63, v1                                        // 0000007CA568: D8D80000 3F000001
	v_and_b32_e32 v1, 0xff, v16                                // 0000007CA570: 360220FF 000000FF
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007CA578: 30020282
	ds_load_b32 v64, v1                                        // 0000007CA57C: D8D80000 40000001
	v_lshrrev_b32_e32 v1, 6, v16                               // 0000007CA584: 32022086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CA588: BF8700B1
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA58C: 360202FF 000003FC
	ds_load_b32 v65, v1                                        // 0000007CA594: D8D80000 41000001
	v_lshrrev_b32_e32 v1, 14, v16                              // 0000007CA59C: 3202208E
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA5A0: 360202FF 000003FC
	ds_load_b32 v66, v1                                        // 0000007CA5A8: D8D80000 42000001
	v_lshrrev_b32_e32 v1, 22, v16                              // 0000007CA5B0: 32022096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007CA5B4: BF870141
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CA5B8: 360202FF 000003FC
	ds_load_b32 v67, v1                                        // 0000007CA5C0: D8D80000 43000001
	.long 0xd73c0001                                           // 0000007CA5C8: D73C0001
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007CA5CC: 02022681
	v_dual_mov_b32 v20, v36 :: v_dual_add_nc_u32 v19, 0x400, v19// 0000007CA5D0: CA200124 141226FF 00000400
	.long 0xd7006a31                                           // 0000007CA5DC: D7006A31
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 0000007CA5E0: 02020206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CA5E4: BF870001
	v_add_co_ci_u32_e64 v50, null, s7, v2, vcc_lo              // 0000007CA5E8: D5207C32 01AA0407
	s_clause 0x3                                               // 0000007CA5F0: BF850003
	global_load_b128 v[1:4], v[49:50], off                     // 0000007CA5F4: DC5E0000 017C0031
	global_load_b128 v[5:8], v[49:50], off offset:16           // 0000007CA5FC: DC5E0010 057C0031
	global_load_b128 v[13:16], v[49:50], off offset:32         // 0000007CA604: DC5E0020 0D7C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 0000007CA60C: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007CA614: BF890CF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 0000007CA618: CC1A4001 1A026901
	s_waitcnt lgkmcnt(14)                                      // 0000007CA620: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA624: BF8700A1
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 0000007CA628: CC1A4001 1C066B02
	s_waitcnt lgkmcnt(13)                                      // 0000007CA630: BF89FCD7
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 0000007CA634: CC1A4001 1C066D03
	s_waitcnt lgkmcnt(12)                                      // 0000007CA63C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA640: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 0000007CA644: CC1A4001 1C066F04
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007CA64C: BF8908B7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 0000007CA650: CC1A4001 1C067105
	s_waitcnt lgkmcnt(10)                                      // 0000007CA658: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA65C: BF8700A1
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 0000007CA660: CC1A4001 1C067306
	s_waitcnt lgkmcnt(9)                                       // 0000007CA668: BF89FC97
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 0000007CA66C: CC1A4001 1C067507
	s_waitcnt lgkmcnt(8)                                       // 0000007CA674: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA678: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 0000007CA67C: CC1A4001 1C067708
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007CA684: BF890477
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 0000007CA688: CC1A4001 1C06790D
	s_waitcnt lgkmcnt(6)                                       // 0000007CA690: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA694: BF8700A1
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 0000007CA698: CC1A4001 1C067B0E
	s_waitcnt lgkmcnt(5)                                       // 0000007CA6A0: BF89FC57
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 0000007CA6A4: CC1A4001 1C067D0F
	s_waitcnt lgkmcnt(4)                                       // 0000007CA6AC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA6B0: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007CA6B4: CC1A4001 1C067F10
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007CA6BC: BF890037
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007CA6C0: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000007CA6C8: D7006A2D
	v_cndmask_b32_e32 v0, v49, v10, vcc_lo                     // 0000007CA6CC: 02001531
	s_waitcnt lgkmcnt(2)                                       // 0000007CA6D0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007CA6D4: BF870132
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007CA6D8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s11, v50, vcc_lo            // 0000007CA6E0: D5207C2E 01AA640B
	s_waitcnt lgkmcnt(1)                                       // 0000007CA6E8: BF89FC17
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007CA6EC: CC1A4001 1C06852F
	s_waitcnt lgkmcnt(0)                                       // 0000007CA6F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA6F8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007CA6FC: CC1A4001 1C068730
	v_fmac_f32_e32 v31, v51, v1                                // 0000007CA704: 563E0333
	s_clause 0x3                                               // 0000007CA708: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 0000007CA70C: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 0000007CA714: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 0000007CA71C: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007CA724: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000007CA72C: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 0000007CA730: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA738: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 0000007CA73C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 0000007CA744: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA74C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 0000007CA750: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 0000007CA758: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 0000007CA75C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA764: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 0000007CA768: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 0000007CA770: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA778: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 0000007CA77C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 0000007CA784: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 0000007CA788: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA790: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 0000007CA794: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 0000007CA79C: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA7A4: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007CA7A8: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 0000007CA7B0: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007CA7B4: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000007CA7BC: D7006A2D
	v_cndmask_b32_e32 v0, v49, v4, vcc_lo                      // 0000007CA7C0: 02000931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CA7C4: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007CA7C8: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s5, v50, vcc_lo             // 0000007CA7D0: D5207C2E 01AA6405
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007CA7D8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA7E0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007CA7E4: CC1A4001 1C068730
	v_fmac_f32_e32 v33, v51, v1                                // 0000007CA7EC: 56420333
	s_clause 0x3                                               // 0000007CA7F0: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 0000007CA7F4: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 0000007CA7FC: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 0000007CA804: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007CA80C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000007CA814: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 0000007CA818: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA820: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 0000007CA824: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 0000007CA82C: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA834: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 0000007CA838: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 0000007CA840: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 0000007CA844: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA84C: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 0000007CA850: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 0000007CA858: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA860: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 0000007CA864: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 0000007CA86C: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 0000007CA870: CC1A4001 1C06790D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA878: BF870091
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 0000007CA87C: CC1A4001 1C067B0E
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 0000007CA884: CC1A4001 1C067D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA88C: BF8700A1
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007CA890: CC1A4001 1C067F10
	s_waitcnt vmcnt(0)                                         // 0000007CA898: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007CA89C: CC1A4001 1C06812D
	.long 0xd7006a2d                                           // 0000007CA8A4: D7006A2D
	v_cndmask_b32_e32 v0, v49, v17, vcc_lo                     // 0000007CA8A8: 02002331
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CA8AC: BF870122
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007CA8B0: CC1A4001 1C06832E
	v_add_co_ci_u32_e64 v46, null, s15, v50, vcc_lo            // 0000007CA8B8: D5207C2E 01AA640F
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007CA8C0: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA8C8: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007CA8CC: CC1A4001 1C068730
	v_fmac_f32_e32 v32, v51, v1                                // 0000007CA8D4: 56400333
	s_clause 0x3                                               // 0000007CA8D8: BF850003
	global_load_b128 v[1:4], v[45:46], off                     // 0000007CA8DC: DC5E0000 017C002D
	global_load_b128 v[5:8], v[45:46], off offset:16           // 0000007CA8E4: DC5E0010 057C002D
	global_load_b128 v[13:16], v[45:46], off offset:32         // 0000007CA8EC: DC5E0020 0D7C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007CA8F4: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000007CA8FC: BF890FF7
	v_dot2_f32_bf16 v1, v1, v52, 0                             // 0000007CA900: CC1A4001 1A026901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA908: BF870091
	v_dot2_f32_bf16 v1, v2, v53, v1                            // 0000007CA90C: CC1A4001 1C066B02
	v_dot2_f32_bf16 v1, v3, v54, v1                            // 0000007CA914: CC1A4001 1C066D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA91C: BF8700A1
	v_dot2_f32_bf16 v1, v4, v55, v1                            // 0000007CA920: CC1A4001 1C066F04
	s_waitcnt vmcnt(2)                                         // 0000007CA928: BF890BF7
	v_dot2_f32_bf16 v1, v5, v56, v1                            // 0000007CA92C: CC1A4001 1C067105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA934: BF870091
	v_dot2_f32_bf16 v1, v6, v57, v1                            // 0000007CA938: CC1A4001 1C067306
	v_dot2_f32_bf16 v1, v7, v58, v1                            // 0000007CA940: CC1A4001 1C067507
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CA948: BF8700A1
	v_dot2_f32_bf16 v1, v8, v59, v1                            // 0000007CA94C: CC1A4001 1C067708
	s_waitcnt vmcnt(1)                                         // 0000007CA954: BF8907F7
	v_dot2_f32_bf16 v1, v13, v60, v1                           // 0000007CA958: CC1A4001 1C06790D
	v_mov_b32_e32 v13, v9                                      // 0000007CA960: 7E1A0309
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CA964: BF870122
	v_dot2_f32_bf16 v1, v14, v61, v1                           // 0000007CA968: CC1A4001 1C067B0E
	v_mov_b32_e32 v14, v10                                     // 0000007CA970: 7E1C030A
	v_dot2_f32_bf16 v1, v15, v62, v1                           // 0000007CA974: CC1A4001 1C067D0F
	v_mov_b32_e32 v15, v11                                     // 0000007CA97C: 7E1E030B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007CA980: BF870132
	v_dot2_f32_bf16 v1, v16, v63, v1                           // 0000007CA984: CC1A4001 1C067F10
	v_mov_b32_e32 v16, v12                                     // 0000007CA98C: 7E20030C
	s_waitcnt vmcnt(0)                                         // 0000007CA990: BF8903F7
	v_dot2_f32_bf16 v1, v45, v64, v1                           // 0000007CA994: CC1A4001 1C06812D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA99C: BF870091
	v_dot2_f32_bf16 v1, v46, v65, v1                           // 0000007CA9A0: CC1A4001 1C06832E
	v_dot2_f32_bf16 v1, v47, v66, v1                           // 0000007CA9A8: CC1A4001 1C06852F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CA9B0: BF870091
	v_dot2_f32_bf16 v1, v48, v67, v1                           // 0000007CA9B4: CC1A4001 1C068730
	v_dual_fmac_f32 v28, v51, v1 :: v_dual_mov_b32 v1, v37     // 0000007CA9BC: C8100333 1C000125
	v_dual_mov_b32 v2, v38 :: v_dual_mov_b32 v3, v39           // 0000007CA9C4: CA100126 02020127
	v_dual_mov_b32 v4, v40 :: v_dual_mov_b32 v5, v41           // 0000007CA9CC: CA100128 04040129
	v_dual_mov_b32 v6, v42 :: v_dual_mov_b32 v7, v43           // 0000007CA9D4: CA10012A 0606012B
	v_mov_b32_e32 v8, v44                                      // 0000007CA9DC: 7E10032C
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007CA9E0: 917E107E
	s_cbranch_execz 35                                         // 0000007CA9E4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xb74>
	s_waitcnt vmcnt(0)                                         // 0000007CA9E8: BF8903F7
	v_dual_mov_b32 v10, v14 :: v_dual_add_nc_u32 v25, 32, v25  // 0000007CA9EC: CA20010E 0A1832A0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v12, v16          // 0000007CA9F4: CA10010D 090C0110
	v_mov_b32_e32 v11, v15                                     // 0000007CA9FC: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CAA00: BF870003
	.long 0xd4460003                                           // 0000007CAA04: D4460003
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000007CAA08: 02023519
	s_mov_b32 s18, exec_lo                                     // 0000007CAA0C: BE92007E
	.long 0xd4c1007e                                           // 0000007CAA10: D4C1007E
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000007CAA14: 02023519
	s_cbranch_execz 65147                                      // 0000007CAA18: BFA5FE7B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v10, 31, v34                             // 0000007CAA1C: 3414449F
	.long 0xd7006a09                                           // 0000007CAA20: D7006A09
	v_cndmask_b32_e32 v1, v18, v34, vcc_lo                     // 0000007CAA24: 02024512
	v_mov_b32_e32 v36, v20                                     // 0000007CAA28: 7E480314
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CAA2C: BF870003
	v_add_co_ci_u32_e64 v10, null, v30, v10, vcc_lo            // 0000007CAA30: D5207C0A 01AA151E
	v_cmp_ne_u32_e32 vcc_lo, 1, v29                            // 0000007CAA38: 7C9A3A81
	global_load_b128 v[9:12], v[9:10], off                     // 0000007CAA3C: DC5E0000 097C0009
	s_cbranch_vccnz 65136                                      // 0000007CAA44: BFA4FE70 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	v_ashrrev_i32_e32 v37, 31, v35                             // 0000007CAA48: 344A469F
	.long 0xd7006a24                                           // 0000007CAA4C: D7006A24
	v_cndmask_b32_e32 v1, v17, v35, vcc_lo                     // 0000007CAA50: 02024711
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CAA54: BF870001
	v_add_co_ci_u32_e64 v37, null, v27, v37, vcc_lo            // 0000007CAA58: D5207C25 01AA4B1B
	global_load_d16_b16 v36, v[36:37], off                     // 0000007CAA60: DC820000 247C0024
	s_waitcnt vmcnt(0)                                         // 0000007CAA68: BF8903F7
	v_cvt_f32_f16_e32 v36, v36                                 // 0000007CAA6C: 7E481724
	s_branch 65125                                             // 0000007CAA70: BFA0FE65 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007CAA74: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CAA78: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007CAA7C: 8C7E0E7E
	.long 0xd71f0001                                           // 0000007CAA80: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007CAA84: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007CAA88: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007CAA8C: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 0000007CAA90: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 0000007CAA94: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007CAA98: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007CAA9C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007CAAA0: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007CAAA4: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CAAA8: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007CAAAC: 30040482
	ds_bpermute_b32 v5, v2, v32                                // 0000007CAAB0: DACC0000 05002002
	s_waitcnt lgkmcnt(0)                                       // 0000007CAAB8: BF89FC07
	v_add_f32_e32 v5, v32, v5                                  // 0000007CAABC: 060A0B20
	ds_bpermute_b32 v3, v2, v31                                // 0000007CAAC0: DACC0000 03001F02
	ds_bpermute_b32 v4, v2, v33                                // 0000007CAAC8: DACC0000 04002102
	ds_bpermute_b32 v2, v2, v28                                // 0000007CAAD0: DACC0000 02001C02
	s_waitcnt lgkmcnt(2)                                       // 0000007CAAD8: BF89FC27
	v_dual_add_f32 v3, v31, v3 :: v_dual_cndmask_b32 v6, v1, v6// 0000007CAADC: C912071F 03060D01
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007CAAE4: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CAAE8: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000007CAAEC: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007CAAF0: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000007CAAF4: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000007CAAFC: BF89FC07
	v_dual_add_f32 v5, v5, v9 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007CAB00: C9221305 050A1482
	ds_bpermute_b32 v7, v6, v3                                 // 0000007CAB08: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 0000007CAB10: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_add_f32 v3, v3, v7    // 0000007CAB14: C908051C 02020F03
	v_add_f32_e32 v4, v33, v4                                  // 0000007CAB1C: 06080921
	ds_bpermute_b32 v8, v6, v4                                 // 0000007CAB20: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 0000007CAB28: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 0000007CAB30: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 0000007CAB34: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 0000007CAB38: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 0000007CAB40: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 0000007CAB48: BF89FC17
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 0000007CAB4C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000007CAB54: DACC0000 0800050A
	s_waitcnt lgkmcnt(1)                                       // 0000007CAB5C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 0000007CAB60: 060C1302
	ds_bpermute_b32 v7, v10, v4                                // 0000007CAB64: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 0000007CAB6C: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CAB70: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007CAB74: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007CAB78: 02141501
	s_waitcnt lgkmcnt(1)                                       // 0000007CAB7C: BF89FC17
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007CAB80: C9221105 050A1482
	ds_bpermute_b32 v2, v10, v3                                // 0000007CAB88: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 0000007CAB90: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000007CAB94: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 0000007CAB98: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 0000007CABA0: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 0000007CABA8: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 0000007CABB0: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CABB4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007CABB8: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000007CABBC: 02021501
	s_waitcnt lgkmcnt(3)                                       // 0000007CABC0: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 0000007CABC4: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 0000007CABCC: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 0000007CABD0: 06061105
	s_waitcnt lgkmcnt(0)                                       // 0000007CABD4: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 0000007CABD8: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 0000007CABE0: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000007CABE8: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000007CABF0: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000007CABF8: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v24                                   // 0000007CAC00: 7D943080
	s_cbranch_execz 12                                         // 0000007CAC04: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xd38>
	s_waitcnt lgkmcnt(1)                                       // 0000007CAC08: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, 4, v23 // 0000007CAC0C: C9221105 08082E84
	s_waitcnt lgkmcnt(0)                                       // 0000007CAC14: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 0000007CAC18: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 0000007CAC20: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CAC24: BF870003
	v_lshl_or_b32 v1, v22, 5, v9                               // 0000007CAC28: D6560001 04250B16
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000007CAC30: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007CAC38: 8C7E027E
	v_or_b32_e32 v1, s20, v21                                  // 0000007CAC3C: 38022A14
	v_mov_b32_e32 v2, s21                                      // 0000007CAC40: 7E040215
	.long 0xd44c0002                                           // 0000007CAC44: D44C0002
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 0000007CAC48: 02020090
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007CAC4C: BF890007
	s_barrier                                                  // 0000007CAC50: BFBD0000
	buffer_gl0_inv                                             // 0000007CAC54: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007CAC5C: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007CAC60: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007CAC64: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007CAC68: BE832002
	s_cbranch_execz 80                                         // 0000007CAC6C: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xeb0>
	v_and_b32_e32 v0, 3, v0                                    // 0000007CAC70: 36000083
	s_load_b32 s0, s[0:1], 0x48                                // 0000007CAC74: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CAC7C: BF870091
	v_lshlrev_b32_e32 v3, 2, v0                                // 0000007CAC80: 30060082
	v_lshl_or_b32 v3, v21, 5, v3                               // 0000007CAC84: D6560003 040D0B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007CAC8C: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007CAC90: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:4                     // 0000007CAC98: D8DC0400 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007CACA0: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007CACA4: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000007CACA8: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CACAC: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007CACB0: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007CACB8: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CACC4: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007CACC8: 360606FF FFFF0000
	v_mul_f32_e32 v6, s0, v3                                   // 0000007CACD0: 100C0600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CACD4: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 0000007CACD8: 10060CFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000007CACE0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CACE4: BF870095
	v_add_f32_e32 v7, 1.0, v3                                  // 0000007CACE8: 060E06F2
	v_div_scale_f32 v5, null, v7, v7, v6                       // 0000007CACEC: D6FC7C05 041A0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CACF4: BF870291
	v_rcp_f32_e32 v8, v5                                       // 0000007CACF8: 7E105505
	v_fma_f32 v3, -v5, v8, 1.0                                 // 0000007CACFC: D6130003 23CA1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007CAD04: BF870131
	v_fmac_f32_e32 v8, v3, v8                                  // 0000007CAD08: 56101103
	v_div_scale_f32 v9, vcc_lo, v6, v7, v6                     // 0000007CAD0C: D6FC6A09 041A0F06
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000007CAD14: D6FE7C03 0202000C
	v_mul_f32_e32 v10, v9, v8                                  // 0000007CAD1C: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CAD20: BF870091
	v_fma_f32 v11, -v5, v10, v9                                // 0000007CAD24: D613000B 24261505
	v_fmac_f32_e32 v10, v11, v8                                // 0000007CAD2C: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CAD30: BF870121
	v_fma_f32 v9, -v5, v10, v9                                 // 0000007CAD34: D6130009 24261505
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000007CAD3C: D6FE7C04 0412000D
	v_div_fmas_f32 v0, v9, v8, v10                             // 0000007CAD44: D6370000 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CAD4C: BF870112
	.long 0xd73c0003                                           // 0000007CAD50: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007CAD54: 02020681
	v_div_fixup_f32 v5, v0, v7, v6                             // 0000007CAD58: D6270005 041A0F00
	.long 0xd73c0000                                           // 0000007CAD60: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007CAD64: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CAD68: BF870193
	.long 0xd7006a03                                           // 0000007CAD6C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007CAD70: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007CAD74: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007CAD7C: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CAD84: BF870193
	.long 0xd7006a00                                           // 0000007CAD88: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007CAD8C: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007CAD90: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CAD9C: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007CADA0: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007CADA8: DC960000 007C0200
	s_endpgm                                                   // 0000007CADB0: BFB00000
		...

