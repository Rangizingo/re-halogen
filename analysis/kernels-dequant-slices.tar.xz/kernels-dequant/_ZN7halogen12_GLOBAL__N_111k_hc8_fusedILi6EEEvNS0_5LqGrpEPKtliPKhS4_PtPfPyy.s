000000000030d500 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy>:
; _ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy():
	s_clause 0x2                                               // 00000030D500: BF850002
	s_load_b32 s3, s[0:1], 0x138                               // 00000030D504: F40000C0 F8000138
	s_load_b128 s[16:19], s[0:1], 0x128                        // 00000030D50C: F4080400 F8000128
	s_load_b128 s[12:15], s[0:1], 0x160                        // 00000030D514: F4080300 F8000160
	s_mov_b32 s4, -1                                           // 00000030D51C: BE8400C1
	s_waitcnt lgkmcnt(0)                                       // 00000030D520: BF89FC07
	s_cmp_ge_i32 s2, s3                                        // 00000030D524: BF030302
	s_cbranch_scc0 1131                                        // 00000030D528: BFA1046B <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x11d8>
	s_load_b256 s[4:11], s[0:1], 0x140                         // 00000030D52C: F40C0100 F8000140
	v_bfe_u32 v1, v0, 4, 2                                     // 00000030D534: D6100001 02090900
	v_lshrrev_b32_e32 v2, 6, v0                                // 00000030D53C: 32040086
	s_sub_i32 s3, s2, s3                                       // 00000030D540: 81830302
	v_and_b32_e32 v11, 15, v0                                  // 00000030D544: 3616008F
	s_lshl_b32 s3, s3, 2                                       // 00000030D548: 84038203
	v_mul_u32_u24_e32 v1, 0xa00, v1                            // 00000030D54C: 160202FF 00000A00
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v3, 12, v0         // 00000030D554: CA240080 0C02008C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000030D55C: BF870223
	v_lshlrev_b32_e32 v15, 4, v11                              // 00000030D560: 301E1684
	v_or_b32_e32 v13, 16, v11                                  // 00000030D564: 381A1690
	v_or_b32_e32 v1, v1, v2                                    // 00000030D568: 38020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030D56C: BF8700A1
	v_add_nc_u32_e32 v1, s3, v1                                // 00000030D570: 4A020203
	s_waitcnt lgkmcnt(0)                                       // 00000030D574: BF89FC07
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 00000030D578: D6FE7C09 001202FF 00000154
	s_mov_b32 s4, exec_lo                                      // 00000030D584: BE84007E
	.long 0xd7006a01                                           // 00000030D588: D7006A01
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                      // 00000030D58C: 02021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030D590: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 00000030D594: D5207C02 01AA1480
	.long 0xd7006a03                                           // 00000030D59C: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000030D5A0: 02020709
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 00000030D5A4: D5207C04 01AA1480
	s_clause 0x1                                               // 00000030D5AC: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 00000030D5B0: DC5E0000 057C0001
	global_load_b32 v14, v[3:4], off offset:320                // 00000030D5B8: DC520140 0E7C0003
	v_cmpx_gt_u32_e32 20, v13                                  // 00000030D5C0: 7D981A94
	s_cbranch_execz 5                                          // 00000030D5C4: BFA50005 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0xdc>
	s_clause 0x1                                               // 00000030D5C8: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 00000030D5CC: DC5E0100 017C0001
	global_load_b32 v12, v[9:10], off offset:336               // 00000030D5D4: DC520150 0C7C0009
	s_or_b32 exec_lo, exec_lo, s4                              // 00000030D5DC: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030D5E0: BF870009
	s_mov_b32 s4, exec_lo                                      // 00000030D5E4: BE84007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000030D5E8: 7D940080
	s_xor_b32 s4, exec_lo, s4                                  // 00000030D5EC: 8D04047E
	s_cbranch_execz 20                                         // 00000030D5F0: BFA50014 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x144>
	v_mov_b32_e32 v9, 0                                        // 00000030D5F4: 7E120280
	global_load_b64 v[16:17], v9, s[12:13] glc                 // 00000030D5F8: DC564000 100C0009
	s_waitcnt vmcnt(0)                                         // 00000030D600: BF8903F7
	buffer_gl1_inv                                             // 00000030D604: E0B00000 00000000
	buffer_gl0_inv                                             // 00000030D60C: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[16:17]                // 00000030D614: 7CB6200E
	s_cbranch_vccnz 10                                         // 00000030D618: BFA4000A <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x144>
	s_sleep 1                                                  // 00000030D61C: BF830001
	global_load_b64 v[16:17], v9, s[12:13] glc                 // 00000030D620: DC564000 100C0009
	s_waitcnt vmcnt(0)                                         // 00000030D628: BF8903F7
	buffer_gl1_inv                                             // 00000030D62C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000030D634: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[16:17]                // 00000030D63C: 7CB8200E
	s_cbranch_vccnz 65526                                      // 00000030D640: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x11c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000030D644: 8C7E047E
	v_lshlrev_b32_e32 v15, 1, v15                              // 00000030D648: 301E1E81
	s_waitcnt vmcnt(0)                                         // 00000030D64C: BF8903F7
	s_barrier                                                  // 00000030D650: BFBD0000
	buffer_gl0_inv                                             // 00000030D654: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000030D65C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000030D664: E0AC0000 00000000
	s_clause 0xb                                               // 00000030D66C: BF85000B
	global_load_b128 v[16:19], v15, s[6:7]                     // 00000030D670: DC5E0000 1006000F
	global_load_b128 v[20:23], v15, s[6:7] offset:640          // 00000030D678: DC5E0280 1406000F
	global_load_b128 v[24:27], v15, s[6:7] offset:1280         // 00000030D680: DC5E0500 1806000F
	global_load_b128 v[28:31], v15, s[6:7] offset:1920         // 00000030D688: DC5E0780 1C06000F
	global_load_b128 v[32:35], v15, s[6:7] offset:2560         // 00000030D690: DC5E0A00 2006000F
	global_load_b128 v[36:39], v15, s[6:7] offset:3200         // 00000030D698: DC5E0C80 2406000F
	global_load_b128 v[40:43], v15, s[6:7] offset:16           // 00000030D6A0: DC5E0010 2806000F
	global_load_b128 v[44:47], v15, s[6:7] offset:656          // 00000030D6A8: DC5E0290 2C06000F
	global_load_b128 v[48:51], v15, s[6:7] offset:1296         // 00000030D6B0: DC5E0510 3006000F
	global_load_b128 v[52:55], v15, s[6:7] offset:1936         // 00000030D6B8: DC5E0790 3406000F
	global_load_b128 v[56:59], v15, s[6:7] offset:2576         // 00000030D6C0: DC5E0A10 3806000F
	global_load_b128 v[60:63], v15, s[6:7] offset:3216         // 00000030D6C8: DC5E0C90 3C06000F
	v_cvt_f32_ubyte0_e32 v10, v5                               // 00000030D6D0: 7E142305
	v_cvt_f32_ubyte1_e32 v64, v5                               // 00000030D6D4: 7E802505
	v_cvt_f32_ubyte2_e32 v65, v5                               // 00000030D6D8: 7E822705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 00000030D6DC: 7E0A2905
	v_cvt_f32_ubyte0_e32 v66, v6                               // 00000030D6E0: 7E842306
	v_cvt_f32_ubyte1_e32 v67, v6                               // 00000030D6E4: 7E862506
	v_cvt_f32_ubyte2_e32 v68, v6                               // 00000030D6E8: 7E882706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 00000030D6EC: 7E0C2906
	v_cvt_f32_ubyte0_e32 v69, v7                               // 00000030D6F0: 7E8A2307
	v_cvt_f32_ubyte1_e32 v70, v7                               // 00000030D6F4: 7E8C2507
	v_cvt_f32_ubyte2_e32 v71, v7                               // 00000030D6F8: 7E8E2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 00000030D6FC: 7E0E2907
	v_cvt_f32_ubyte0_e32 v72, v8                               // 00000030D700: 7E902308
	v_cvt_f32_ubyte1_e32 v73, v8                               // 00000030D704: 7E922508
	v_cvt_f32_ubyte2_e32 v74, v8                               // 00000030D708: 7E942708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 00000030D70C: 7E102908
	v_fma_mix_f32 v10, v10, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D710: CC20600A 143A1D0A
	v_fma_mix_f32 v64, v64, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D718: CC206040 143A1D40
	v_fma_mix_f32 v65, v65, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D720: CC206041 143A1D41
	v_fma_mix_f32 v5, v5, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D728: CC206005 143A1D05
	v_fma_mix_f32 v66, v66, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D730: CC206042 143A1D42
	v_fma_mix_f32 v67, v67, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D738: CC206043 143A1D43
	v_fma_mix_f32 v68, v68, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D740: CC206044 143A1D44
	v_fma_mix_f32 v6, v6, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D748: CC206006 143A1D06
	v_fma_mix_f32 v69, v69, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D750: CC206045 143A1D45
	v_fma_mix_f32 v70, v70, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D758: CC206046 143A1D46
	v_fma_mix_f32 v71, v71, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D760: CC206047 143A1D47
	v_fma_mix_f32 v7, v7, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D768: CC206007 143A1D07
	v_fma_mix_f32 v72, v72, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D770: CC206048 143A1D48
	v_fma_mix_f32 v73, v73, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D778: CC206049 143A1D49
	v_fma_mix_f32 v74, v74, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D780: CC20604A 143A1D4A
	v_fma_mix_f32 v8, v8, v14, v14 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030D788: CC206008 143A1D08
	v_bfe_u32 v14, v10, 16, 1                                  // 00000030D790: D610000E 0205210A
	v_bfe_u32 v79, v64, 16, 1                                  // 00000030D798: D610004F 02052140
	v_bfe_u32 v80, v65, 16, 1                                  // 00000030D7A0: D6100050 02052141
	.long 0x7f123880                                           // 00000030D7A8: 7F123880
	v_bfe_u32 v81, v5, 16, 1                                   // 00000030D7AC: D6100051 02052105
	v_add3_u32 v10, v10, v14, 0x7fff                           // 00000030D7B4: D655000A 03FE1D0A 00007FFF
	v_bfe_u32 v82, v66, 16, 1                                  // 00000030D7C0: D6100052 02052142
	v_add3_u32 v14, v64, v79, 0x7fff                           // 00000030D7C8: D655000E 03FE9F40 00007FFF
	v_add3_u32 v64, v65, v80, 0x7fff                           // 00000030D7D4: D6550040 03FEA141 00007FFF
	.long 0x7f963989                                           // 00000030D7E0: 7F963989
	.long 0x7e12398a                                           // 00000030D7E4: 7E12398A
	v_bfe_u32 v83, v67, 16, 1                                  // 00000030D7E8: D6100053 02052143
	v_bfe_u32 v84, v68, 16, 1                                  // 00000030D7F0: D6100054 02052144
	v_add3_u32 v5, v5, v81, 0x7fff                             // 00000030D7F8: D6550005 03FEA305 00007FFF
	v_add3_u32 v65, v66, v82, 0x7fff                           // 00000030D804: D6550041 03FEA542 00007FFF
	v_and_or_b32 v14, 0xffff0000, v14, v9                      // 00000030D810: D657000E 04261CFF FFFF0000
	.long 0x7e9639c0                                           // 00000030D81C: 7E9639C0
	v_bfe_u32 v85, v6, 16, 1                                   // 00000030D820: D6100055 02052106
	v_bfe_u32 v86, v69, 16, 1                                  // 00000030D828: D6100056 02052145
	v_add3_u32 v66, v67, v83, 0x7fff                           // 00000030D830: D6550042 03FEA743 00007FFF
	v_add3_u32 v67, v68, v84, 0x7fff                           // 00000030D83C: D6550043 03FEA944 00007FFF
	.long 0x7e1239c1                                           // 00000030D848: 7E1239C1
	v_and_or_b32 v5, 0xffff0000, v5, v75                       // 00000030D84C: D6570005 052E0AFF FFFF0000
	.long 0x7f983989                                           // 00000030D858: 7F983989
	v_bfe_u32 v87, v70, 16, 1                                  // 00000030D85C: D6100057 02052146
	v_bfe_u32 v88, v71, 16, 1                                  // 00000030D864: D6100058 02052147
	v_add3_u32 v6, v6, v85, 0x7fff                             // 00000030D86C: D6550006 03FEAB06 00007FFF
	v_add3_u32 v10, v69, v86, 0x7fff                           // 00000030D878: D655000A 03FEAD45 00007FFF
	v_and_or_b32 v66, 0xffff0000, v66, v9                      // 00000030D884: D6570042 042684FF FFFF0000
	.long 0x7e9839c3                                           // 00000030D890: 7E9839C3
	v_bfe_u32 v89, v7, 16, 1                                   // 00000030D894: D6100059 02052107
	v_bfe_u32 v90, v72, 16, 1                                  // 00000030D89C: D610005A 02052148
	v_add3_u32 v68, v70, v87, 0x7fff                           // 00000030D8A4: D6550044 03FEAF46 00007FFF
	v_add3_u32 v69, v71, v88, 0x7fff                           // 00000030D8B0: D6550045 03FEB147 00007FFF
	.long 0x7e12398a                                           // 00000030D8BC: 7E12398A
	v_and_or_b32 v6, 0xffff0000, v6, v76                       // 00000030D8C0: D6570006 05320CFF FFFF0000
	.long 0x7f9a3989                                           // 00000030D8CC: 7F9A3989
	v_bfe_u32 v91, v73, 16, 1                                  // 00000030D8D0: D610005B 02052149
	v_bfe_u32 v92, v74, 16, 1                                  // 00000030D8D8: D610005C 0205214A
	v_add3_u32 v7, v7, v89, 0x7fff                             // 00000030D8E0: D6550007 03FEB307 00007FFF
	v_add3_u32 v65, v72, v90, 0x7fff                           // 00000030D8EC: D6550041 03FEB548 00007FFF
	.long 0x7e9a39c5                                           // 00000030D8F8: 7E9A39C5
	v_and_or_b32 v10, 0xffff0000, v68, v9                      // 00000030D8FC: D657000A 042688FF FFFF0000
	v_bfe_u32 v93, v8, 16, 1                                   // 00000030D908: D610005D 02052108
	v_add3_u32 v70, v73, v91, 0x7fff                           // 00000030D910: D6550046 03FEB749 00007FFF
	v_add3_u32 v71, v74, v92, 0x7fff                           // 00000030D91C: D6550047 03FEB94A 00007FFF
	.long 0x7e1239c1                                           // 00000030D928: 7E1239C1
	v_and_or_b32 v7, 0xffff0000, v7, v77                       // 00000030D92C: D6570007 05360EFF FFFF0000
	.long 0x7f9c3989                                           // 00000030D938: 7F9C3989
	v_add3_u32 v8, v8, v93, 0x7fff                             // 00000030D93C: D6550008 03FEBB08 00007FFF
	.long 0x7e9c39c7                                           // 00000030D948: 7E9C39C7
	v_and_or_b32 v64, 0xffff0000, v70, v9                      // 00000030D94C: D6570040 04268CFF FFFF0000
	s_mov_b32 s4, exec_lo                                      // 00000030D958: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000030D95C: BF870002
	v_and_or_b32 v8, 0xffff0000, v8, v78                       // 00000030D960: D6570008 053A10FF FFFF0000
	s_waitcnt vmcnt(11)                                        // 00000030D96C: BF892FF7
	v_dot2_f32_bf16 v16, v16, v14, 0                           // 00000030D970: CC1A4010 1A021D10
	s_waitcnt vmcnt(10)                                        // 00000030D978: BF892BF7
	v_dot2_f32_bf16 v20, v20, v14, 0                           // 00000030D97C: CC1A4014 1A021D14
	s_waitcnt vmcnt(9)                                         // 00000030D984: BF8927F7
	v_dot2_f32_bf16 v24, v24, v14, 0                           // 00000030D988: CC1A4018 1A021D18
	s_waitcnt vmcnt(8)                                         // 00000030D990: BF8923F7
	v_dot2_f32_bf16 v28, v28, v14, 0                           // 00000030D994: CC1A401C 1A021D1C
	s_waitcnt vmcnt(7)                                         // 00000030D99C: BF891FF7
	v_dot2_f32_bf16 v32, v32, v14, 0                           // 00000030D9A0: CC1A4020 1A021D20
	s_waitcnt vmcnt(6)                                         // 00000030D9A8: BF891BF7
	v_dot2_f32_bf16 v14, v36, v14, 0                           // 00000030D9AC: CC1A400E 1A021D24
	v_dot2_f32_bf16 v16, v17, v5, v16                          // 00000030D9B4: CC1A4010 1C420B11
	v_dot2_f32_bf16 v17, v21, v5, v20                          // 00000030D9BC: CC1A4011 1C520B15
	v_dot2_f32_bf16 v20, v25, v5, v24                          // 00000030D9C4: CC1A4014 1C620B19
	v_dot2_f32_bf16 v21, v29, v5, v28                          // 00000030D9CC: CC1A4015 1C720B1D
	v_dot2_f32_bf16 v24, v33, v5, v32                          // 00000030D9D4: CC1A4018 1C820B21
	v_dot2_f32_bf16 v5, v37, v5, v14                           // 00000030D9DC: CC1A4005 1C3A0B25
	v_dot2_f32_bf16 v14, v18, v66, v16                         // 00000030D9E4: CC1A400E 1C428512
	v_dot2_f32_bf16 v16, v22, v66, v17                         // 00000030D9EC: CC1A4010 1C468516
	v_dot2_f32_bf16 v17, v26, v66, v20                         // 00000030D9F4: CC1A4011 1C52851A
	v_dot2_f32_bf16 v18, v30, v66, v21                         // 00000030D9FC: CC1A4012 1C56851E
	v_dot2_f32_bf16 v20, v34, v66, v24                         // 00000030DA04: CC1A4014 1C628522
	v_dot2_f32_bf16 v5, v38, v66, v5                           // 00000030DA0C: CC1A4005 1C168526
	v_dot2_f32_bf16 v14, v19, v6, v14                          // 00000030DA14: CC1A400E 1C3A0D13
	v_dot2_f32_bf16 v16, v23, v6, v16                          // 00000030DA1C: CC1A4010 1C420D17
	v_dot2_f32_bf16 v17, v27, v6, v17                          // 00000030DA24: CC1A4011 1C460D1B
	v_dot2_f32_bf16 v18, v31, v6, v18                          // 00000030DA2C: CC1A4012 1C4A0D1F
	v_dot2_f32_bf16 v19, v35, v6, v20                          // 00000030DA34: CC1A4013 1C520D23
	v_dot2_f32_bf16 v5, v39, v6, v5                            // 00000030DA3C: CC1A4005 1C160D27
	s_waitcnt vmcnt(5)                                         // 00000030DA44: BF8917F7
	v_dot2_f32_bf16 v6, v40, v10, v14                          // 00000030DA48: CC1A4006 1C3A1528
	s_waitcnt vmcnt(4)                                         // 00000030DA50: BF8913F7
	v_dot2_f32_bf16 v14, v44, v10, v16                         // 00000030DA54: CC1A400E 1C42152C
	s_waitcnt vmcnt(3)                                         // 00000030DA5C: BF890FF7
	v_dot2_f32_bf16 v16, v48, v10, v17                         // 00000030DA60: CC1A4010 1C461530
	s_waitcnt vmcnt(2)                                         // 00000030DA68: BF890BF7
	v_dot2_f32_bf16 v17, v52, v10, v18                         // 00000030DA6C: CC1A4011 1C4A1534
	s_waitcnt vmcnt(1)                                         // 00000030DA74: BF8907F7
	v_dot2_f32_bf16 v18, v56, v10, v19                         // 00000030DA78: CC1A4012 1C4E1538
	s_waitcnt vmcnt(0)                                         // 00000030DA80: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v5                           // 00000030DA84: CC1A4005 1C16153C
	v_dot2_f32_bf16 v6, v41, v7, v6                            // 00000030DA8C: CC1A4006 1C1A0F29
	v_dot2_f32_bf16 v10, v45, v7, v14                          // 00000030DA94: CC1A400A 1C3A0F2D
	v_dot2_f32_bf16 v14, v49, v7, v16                          // 00000030DA9C: CC1A400E 1C420F31
	v_dot2_f32_bf16 v16, v53, v7, v17                          // 00000030DAA4: CC1A4010 1C460F35
	v_dot2_f32_bf16 v17, v57, v7, v18                          // 00000030DAAC: CC1A4011 1C4A0F39
	v_dot2_f32_bf16 v5, v61, v7, v5                            // 00000030DAB4: CC1A4005 1C160F3D
	v_dot2_f32_bf16 v6, v42, v64, v6                           // 00000030DABC: CC1A4006 1C1A812A
	v_dot2_f32_bf16 v7, v46, v64, v10                          // 00000030DAC4: CC1A4007 1C2A812E
	v_dot2_f32_bf16 v10, v50, v64, v14                         // 00000030DACC: CC1A400A 1C3A8132
	v_dot2_f32_bf16 v14, v54, v64, v16                         // 00000030DAD4: CC1A400E 1C428136
	v_dot2_f32_bf16 v16, v58, v64, v17                         // 00000030DADC: CC1A4010 1C46813A
	v_dot2_f32_bf16 v5, v62, v64, v5                           // 00000030DAE4: CC1A4005 1C16813E
	v_dot2_f32_bf16 v6, v43, v8, v6                            // 00000030DAEC: CC1A4006 1C1A112B
	v_dot2_f32_bf16 v7, v47, v8, v7                            // 00000030DAF4: CC1A4007 1C1E112F
	v_dot2_f32_bf16 v17, v51, v8, v10                          // 00000030DAFC: CC1A4011 1C2A1133
	v_dot2_f32_bf16 v18, v55, v8, v14                          // 00000030DB04: CC1A4012 1C3A1137
	v_dot2_f32_bf16 v16, v59, v8, v16                          // 00000030DB0C: CC1A4010 1C42113B
	v_dot2_f32_bf16 v19, v63, v8, v5                           // 00000030DB14: CC1A4013 1C16113F
	v_add_f32_e32 v10, 0, v6                                   // 00000030DB1C: 06140C80
	v_dual_add_f32 v14, 0, v7 :: v_dual_add_f32 v7, 0, v17     // 00000030DB20: C9080E80 0E062280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030DB28: BF870214
	v_dual_add_f32 v8, 0, v18 :: v_dual_add_f32 v5, 0, v16     // 00000030DB2C: C9082480 08042080
	v_add_f32_e32 v6, 0, v19                                   // 00000030DB34: 060C2680
	v_cmpx_gt_u32_e32 20, v13                                  // 00000030DB38: 7D981A94
	s_cbranch_execz 311                                        // 00000030DB3C: BFA50137 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0xb1c>
	.long 0xd700053b                                           // 00000030DB40: D700053B
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 00000030DB44: 02021E06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030DB48: BF870001
	v_add_co_ci_u32_e64 v60, null, s7, 0, s5                   // 00000030DB4C: D5207C3C 00150007
	v_cvt_f32_ubyte0_e32 v13, v1                               // 00000030DB54: 7E1A2301
	v_cvt_f32_ubyte1_e32 v63, v1                               // 00000030DB58: 7E7E2501
	v_cvt_f32_ubyte2_e32 v64, v1                               // 00000030DB5C: 7E802701
	s_clause 0xb                                               // 00000030DB60: BF85000B
	global_load_b128 v[15:18], v[59:60], off offset:512        // 00000030DB64: DC5E0200 0F7C003B
	global_load_b128 v[19:22], v[59:60], off offset:1152       // 00000030DB6C: DC5E0480 137C003B
	global_load_b128 v[23:26], v[59:60], off offset:1792       // 00000030DB74: DC5E0700 177C003B
	global_load_b128 v[27:30], v[59:60], off offset:2432       // 00000030DB7C: DC5E0980 1B7C003B
	global_load_b128 v[31:34], v[59:60], off offset:3072       // 00000030DB84: DC5E0C00 1F7C003B
	global_load_b128 v[35:38], v[59:60], off offset:3712       // 00000030DB8C: DC5E0E80 237C003B
	global_load_b128 v[39:42], v[59:60], off offset:528        // 00000030DB94: DC5E0210 277C003B
	global_load_b128 v[43:46], v[59:60], off offset:1168       // 00000030DB9C: DC5E0490 2B7C003B
	global_load_b128 v[47:50], v[59:60], off offset:1808       // 00000030DBA4: DC5E0710 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:2448       // 00000030DBAC: DC5E0990 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:3088       // 00000030DBB4: DC5E0C10 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:3728       // 00000030DBBC: DC5E0E90 3B7C003B
	v_cvt_f32_ubyte3_e32 v1, v1                                // 00000030DBC4: 7E022901
	v_cvt_f32_ubyte0_e32 v66, v2                               // 00000030DBC8: 7E842302
	v_cvt_f32_ubyte1_e32 v67, v2                               // 00000030DBCC: 7E862502
	v_cvt_f32_ubyte2_e32 v68, v2                               // 00000030DBD0: 7E882702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 00000030DBD4: 7E042902
	v_cvt_f32_ubyte0_e32 v70, v3                               // 00000030DBD8: 7E8C2303
	v_cvt_f32_ubyte1_e32 v71, v3                               // 00000030DBDC: 7E8E2503
	v_cvt_f32_ubyte2_e32 v72, v3                               // 00000030DBE0: 7E902703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 00000030DBE4: 7E062903
	v_cvt_f32_ubyte0_e32 v74, v4                               // 00000030DBE8: 7E942304
	v_cvt_f32_ubyte1_e32 v75, v4                               // 00000030DBEC: 7E962504
	v_cvt_f32_ubyte2_e32 v76, v4                               // 00000030DBF0: 7E982704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 00000030DBF4: 7E082904
	v_fma_mix_f32 v13, v13, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DBF8: CC20600D 1432190D
	v_fma_mix_f32 v63, v63, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC00: CC20603F 1432193F
	v_fma_mix_f32 v64, v64, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC08: CC206040 14321940
	v_fma_mix_f32 v1, v1, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC10: CC206001 14321901
	v_fma_mix_f32 v66, v66, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC18: CC206042 14321942
	v_fma_mix_f32 v67, v67, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC20: CC206043 14321943
	v_fma_mix_f32 v68, v68, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC28: CC206044 14321944
	v_fma_mix_f32 v2, v2, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC30: CC206002 14321902
	v_fma_mix_f32 v70, v70, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC38: CC206046 14321946
	v_fma_mix_f32 v71, v71, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC40: CC206047 14321947
	v_fma_mix_f32 v72, v72, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC48: CC206048 14321948
	v_fma_mix_f32 v3, v3, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC50: CC206003 14321903
	v_fma_mix_f32 v74, v74, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC58: CC20604A 1432194A
	v_fma_mix_f32 v75, v75, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC60: CC20604B 1432194B
	v_fma_mix_f32 v76, v76, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC68: CC20604C 1432194C
	v_fma_mix_f32 v4, v4, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030DC70: CC206004 14321904
	v_bfe_u32 v12, v13, 16, 1                                  // 00000030DC78: D610000C 0205210D
	v_bfe_u32 v78, v63, 16, 1                                  // 00000030DC80: D610004E 0205213F
	v_bfe_u32 v79, v64, 16, 1                                  // 00000030DC88: D610004F 02052140
	v_bfe_u32 v80, v1, 16, 1                                   // 00000030DC90: D6100050 02052101
	v_bfe_u32 v81, v66, 16, 1                                  // 00000030DC98: D6100051 02052142
	v_add3_u32 v12, v13, v12, 0x7fff                           // 00000030DCA0: D655000C 03FE190D 00007FFF
	v_add3_u32 v13, v63, v78, 0x7fff                           // 00000030DCAC: D655000D 03FE9D3F 00007FFF
	v_add3_u32 v63, v64, v79, 0x7fff                           // 00000030DCB8: D655003F 03FE9F40 00007FFF
	.long 0x7f823989                                           // 00000030DCC4: 7F823989
	v_bfe_u32 v82, v67, 16, 1                                  // 00000030DCC8: D6100052 02052143
	.long 0x7e12398c                                           // 00000030DCD0: 7E12398C
	v_bfe_u32 v83, v68, 16, 1                                  // 00000030DCD4: D6100053 02052144
	v_add3_u32 v1, v1, v80, 0x7fff                             // 00000030DCDC: D6550001 03FEA101 00007FFF
	v_add3_u32 v64, v66, v81, 0x7fff                           // 00000030DCE8: D6550040 03FEA342 00007FFF
	.long 0x7e8239bf                                           // 00000030DCF4: 7E8239BF
	v_and_or_b32 v13, 0xffff0000, v13, v9                      // 00000030DCF8: D657000D 04261AFF FFFF0000
	v_bfe_u32 v84, v2, 16, 1                                   // 00000030DD04: D6100054 02052102
	v_bfe_u32 v85, v70, 16, 1                                  // 00000030DD0C: D6100055 02052146
	v_add3_u32 v66, v67, v82, 0x7fff                           // 00000030DD14: D6550042 03FEA543 00007FFF
	v_add3_u32 v67, v68, v83, 0x7fff                           // 00000030DD20: D6550043 03FEA744 00007FFF
	.long 0x7e1239c0                                           // 00000030DD2C: 7E1239C0
	v_and_or_b32 v1, 0xffff0000, v1, v65                       // 00000030DD30: D6570001 050602FF FFFF0000
	.long 0x7f8a3989                                           // 00000030DD3C: 7F8A3989
	v_bfe_u32 v86, v71, 16, 1                                  // 00000030DD40: D6100056 02052147
	v_bfe_u32 v87, v72, 16, 1                                  // 00000030DD48: D6100057 02052148
	v_add3_u32 v2, v2, v84, 0x7fff                             // 00000030DD50: D6550002 03FEA902 00007FFF
	v_add3_u32 v12, v70, v85, 0x7fff                           // 00000030DD5C: D655000C 03FEAB46 00007FFF
	v_and_or_b32 v66, 0xffff0000, v66, v9                      // 00000030DD68: D6570042 042684FF FFFF0000
	.long 0x7e8a39c3                                           // 00000030DD74: 7E8A39C3
	v_bfe_u32 v88, v3, 16, 1                                   // 00000030DD78: D6100058 02052103
	v_bfe_u32 v89, v74, 16, 1                                  // 00000030DD80: D6100059 0205214A
	v_add3_u32 v68, v71, v86, 0x7fff                           // 00000030DD88: D6550044 03FEAD47 00007FFF
	v_add3_u32 v70, v72, v87, 0x7fff                           // 00000030DD94: D6550046 03FEAF48 00007FFF
	.long 0x7e12398c                                           // 00000030DDA0: 7E12398C
	v_and_or_b32 v2, 0xffff0000, v2, v69                       // 00000030DDA4: D6570002 051604FF FFFF0000
	.long 0x7f923989                                           // 00000030DDB0: 7F923989
	v_bfe_u32 v90, v75, 16, 1                                  // 00000030DDB4: D610005A 0205214B
	v_bfe_u32 v91, v76, 16, 1                                  // 00000030DDBC: D610005B 0205214C
	v_add3_u32 v3, v3, v88, 0x7fff                             // 00000030DDC4: D6550003 03FEB103 00007FFF
	v_add3_u32 v64, v74, v89, 0x7fff                           // 00000030DDD0: D6550040 03FEB34A 00007FFF
	.long 0x7e9239c6                                           // 00000030DDDC: 7E9239C6
	v_and_or_b32 v12, 0xffff0000, v68, v9                      // 00000030DDE0: D657000C 042688FF FFFF0000
	v_bfe_u32 v92, v4, 16, 1                                   // 00000030DDEC: D610005C 02052104
	v_add3_u32 v71, v75, v90, 0x7fff                           // 00000030DDF4: D6550047 03FEB54B 00007FFF
	v_add3_u32 v72, v76, v91, 0x7fff                           // 00000030DE00: D6550048 03FEB74C 00007FFF
	.long 0x7e1239c0                                           // 00000030DE0C: 7E1239C0
	v_and_or_b32 v3, 0xffff0000, v3, v73                       // 00000030DE10: D6570003 052606FF FFFF0000
	.long 0x7f9a3989                                           // 00000030DE1C: 7F9A3989
	v_add3_u32 v4, v4, v92, 0x7fff                             // 00000030DE20: D6550004 03FEB904 00007FFF
	.long 0x7e9a39c8                                           // 00000030DE2C: 7E9A39C8
	v_and_or_b32 v9, 0xffff0000, v71, v9                       // 00000030DE30: D6570009 04268EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 00000030DE3C: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v77                       // 00000030DE40: D6570004 053608FF FFFF0000
	s_waitcnt vmcnt(11)                                        // 00000030DE4C: BF892FF7
	v_dot2_f32_bf16 v15, v15, v13, 0                           // 00000030DE50: CC1A400F 1A021B0F
	s_waitcnt vmcnt(10)                                        // 00000030DE58: BF892BF7
	v_dot2_f32_bf16 v19, v19, v13, 0                           // 00000030DE5C: CC1A4013 1A021B13
	s_waitcnt vmcnt(9)                                         // 00000030DE64: BF8927F7
	v_dot2_f32_bf16 v23, v23, v13, 0                           // 00000030DE68: CC1A4017 1A021B17
	s_waitcnt vmcnt(8)                                         // 00000030DE70: BF8923F7
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 00000030DE74: CC1A401B 1A021B1B
	s_waitcnt vmcnt(7)                                         // 00000030DE7C: BF891FF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 00000030DE80: CC1A401F 1A021B1F
	s_waitcnt vmcnt(6)                                         // 00000030DE88: BF891BF7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 00000030DE8C: CC1A400D 1A021B23
	v_dot2_f32_bf16 v15, v16, v1, v15                          // 00000030DE94: CC1A400F 1C3E0310
	v_dot2_f32_bf16 v16, v20, v1, v19                          // 00000030DE9C: CC1A4010 1C4E0314
	v_dot2_f32_bf16 v19, v24, v1, v23                          // 00000030DEA4: CC1A4013 1C5E0318
	v_dot2_f32_bf16 v20, v28, v1, v27                          // 00000030DEAC: CC1A4014 1C6E031C
	v_dot2_f32_bf16 v23, v32, v1, v31                          // 00000030DEB4: CC1A4017 1C7E0320
	v_dot2_f32_bf16 v1, v36, v1, v13                           // 00000030DEBC: CC1A4001 1C360324
	v_dot2_f32_bf16 v13, v17, v66, v15                         // 00000030DEC4: CC1A400D 1C3E8511
	v_dot2_f32_bf16 v15, v21, v66, v16                         // 00000030DECC: CC1A400F 1C428515
	v_dot2_f32_bf16 v16, v25, v66, v19                         // 00000030DED4: CC1A4010 1C4E8519
	v_dot2_f32_bf16 v17, v29, v66, v20                         // 00000030DEDC: CC1A4011 1C52851D
	v_dot2_f32_bf16 v19, v33, v66, v23                         // 00000030DEE4: CC1A4013 1C5E8521
	v_dot2_f32_bf16 v1, v37, v66, v1                           // 00000030DEEC: CC1A4001 1C068525
	v_dot2_f32_bf16 v13, v18, v2, v13                          // 00000030DEF4: CC1A400D 1C360512
	v_dot2_f32_bf16 v15, v22, v2, v15                          // 00000030DEFC: CC1A400F 1C3E0516
	v_dot2_f32_bf16 v16, v26, v2, v16                          // 00000030DF04: CC1A4010 1C42051A
	v_dot2_f32_bf16 v17, v30, v2, v17                          // 00000030DF0C: CC1A4011 1C46051E
	v_dot2_f32_bf16 v18, v34, v2, v19                          // 00000030DF14: CC1A4012 1C4E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 00000030DF1C: CC1A4001 1C060526
	s_waitcnt vmcnt(5)                                         // 00000030DF24: BF8917F7
	v_dot2_f32_bf16 v2, v39, v12, v13                          // 00000030DF28: CC1A4002 1C361927
	s_waitcnt vmcnt(4)                                         // 00000030DF30: BF8913F7
	v_dot2_f32_bf16 v13, v43, v12, v15                         // 00000030DF34: CC1A400D 1C3E192B
	s_waitcnt vmcnt(3)                                         // 00000030DF3C: BF890FF7
	v_dot2_f32_bf16 v15, v47, v12, v16                         // 00000030DF40: CC1A400F 1C42192F
	s_waitcnt vmcnt(2)                                         // 00000030DF48: BF890BF7
	v_dot2_f32_bf16 v16, v51, v12, v17                         // 00000030DF4C: CC1A4010 1C461933
	s_waitcnt vmcnt(1)                                         // 00000030DF54: BF8907F7
	v_dot2_f32_bf16 v17, v55, v12, v18                         // 00000030DF58: CC1A4011 1C4A1937
	s_waitcnt vmcnt(0)                                         // 00000030DF60: BF8903F7
	v_dot2_f32_bf16 v1, v59, v12, v1                           // 00000030DF64: CC1A4001 1C06193B
	v_dot2_f32_bf16 v2, v40, v3, v2                            // 00000030DF6C: CC1A4002 1C0A0728
	v_dot2_f32_bf16 v12, v44, v3, v13                          // 00000030DF74: CC1A400C 1C36072C
	v_dot2_f32_bf16 v13, v48, v3, v15                          // 00000030DF7C: CC1A400D 1C3E0730
	v_dot2_f32_bf16 v15, v52, v3, v16                          // 00000030DF84: CC1A400F 1C420734
	v_dot2_f32_bf16 v16, v56, v3, v17                          // 00000030DF8C: CC1A4010 1C460738
	v_dot2_f32_bf16 v1, v60, v3, v1                            // 00000030DF94: CC1A4001 1C06073C
	v_dot2_f32_bf16 v2, v41, v9, v2                            // 00000030DF9C: CC1A4002 1C0A1329
	v_dot2_f32_bf16 v3, v45, v9, v12                           // 00000030DFA4: CC1A4003 1C32132D
	v_dot2_f32_bf16 v12, v49, v9, v13                          // 00000030DFAC: CC1A400C 1C361331
	v_dot2_f32_bf16 v13, v53, v9, v15                          // 00000030DFB4: CC1A400D 1C3E1335
	v_dot2_f32_bf16 v15, v57, v9, v16                          // 00000030DFBC: CC1A400F 1C421339
	v_dot2_f32_bf16 v1, v61, v9, v1                            // 00000030DFC4: CC1A4001 1C06133D
	v_dot2_f32_bf16 v2, v42, v4, v2                            // 00000030DFCC: CC1A4002 1C0A092A
	v_dot2_f32_bf16 v3, v46, v4, v3                            // 00000030DFD4: CC1A4003 1C0E092E
	v_dot2_f32_bf16 v9, v50, v4, v12                           // 00000030DFDC: CC1A4009 1C320932
	v_dot2_f32_bf16 v12, v54, v4, v13                          // 00000030DFE4: CC1A400C 1C360936
	v_dot2_f32_bf16 v13, v58, v4, v15                          // 00000030DFEC: CC1A400D 1C3E093A
	v_dot2_f32_bf16 v1, v62, v4, v1                            // 00000030DFF4: CC1A4001 1C06093E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030DFFC: BF870194
	v_dual_add_f32 v10, v10, v2 :: v_dual_add_f32 v7, v7, v9   // 00000030E000: C908050A 0A061307
	v_dual_add_f32 v14, v14, v3 :: v_dual_add_f32 v5, v5, v13  // 00000030E008: C908070E 0E041B05
	v_add_f32_e32 v8, v8, v12                                  // 00000030E010: 06101908
	s_delay_alu instid0(VALU_DEP_4)                            // 00000030E014: BF870004
	v_add_f32_e32 v6, v6, v1                                   // 00000030E018: 060C0306
	s_or_b32 exec_lo, exec_lo, s4                              // 00000030E01C: 8C7E047E
	.long 0xd71f0001                                           // 00000030E020: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000030E024: 020100C1
	s_mov_b32 s4, exec_lo                                      // 00000030E028: BE84007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030E02C: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 00000030E030: 3A040288
	v_xor_b32_e32 v15, 4, v1                                   // 00000030E034: 3A1E0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000030E038: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000030E03C: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030E040: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 00000030E044: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 00000030E048: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 00000030E04C: 301E1E82
	s_delay_alu instid0(VALU_DEP_4)                            // 00000030E050: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000030E054: 30040482
	ds_bpermute_b32 v3, v2, v14                                // 00000030E058: DACC0000 03000E02
	s_waitcnt lgkmcnt(0)                                       // 00000030E060: BF89FC07
	v_add_f32_e32 v3, v14, v3                                  // 00000030E064: 0606070E
	ds_bpermute_b32 v4, v2, v10                                // 00000030E068: DACC0000 04000A02
	ds_bpermute_b32 v9, v2, v8                                 // 00000030E070: DACC0000 09000802
	ds_bpermute_b32 v12, v2, v7                                // 00000030E078: DACC0000 0C000702
	ds_bpermute_b32 v13, v2, v6                                // 00000030E080: DACC0000 0D000602
	ds_bpermute_b32 v2, v2, v5                                 // 00000030E088: DACC0000 02000502
	s_waitcnt lgkmcnt(4)                                       // 00000030E090: BF89FC47
	v_add_f32_e32 v4, v10, v4                                  // 00000030E094: 0608090A
	s_waitcnt lgkmcnt(2)                                       // 00000030E098: BF89FC27
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v7, v7, v12    // 00000030E09C: C9081308 08061907
	s_waitcnt lgkmcnt(1)                                       // 00000030E0A4: BF89FC17
	v_add_f32_e32 v6, v6, v13                                  // 00000030E0A8: 060C1B06
	s_waitcnt lgkmcnt(0)                                       // 00000030E0AC: BF89FC07
	v_add_f32_e32 v2, v5, v2                                   // 00000030E0B0: 06040505
	ds_bpermute_b32 v5, v15, v3                                // 00000030E0B4: DACC0000 0500030F
	ds_bpermute_b32 v9, v15, v4                                // 00000030E0BC: DACC0000 0900040F
	ds_bpermute_b32 v10, v15, v8                               // 00000030E0C4: DACC0000 0A00080F
	ds_bpermute_b32 v12, v15, v7                               // 00000030E0CC: DACC0000 0C00070F
	ds_bpermute_b32 v13, v15, v6                               // 00000030E0D4: DACC0000 0D00060F
	ds_bpermute_b32 v14, v15, v2                               // 00000030E0DC: DACC0000 0E00020F
	v_xor_b32_e32 v15, 2, v1                                   // 00000030E0E4: 3A1E0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030E0E8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 00000030E0EC: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 00000030E0F0: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 00000030E0F4: 301E1E82
	s_waitcnt lgkmcnt(5)                                       // 00000030E0F8: BF89FC57
	v_add_f32_e32 v3, v3, v5                                   // 00000030E0FC: 06060B03
	s_waitcnt lgkmcnt(2)                                       // 00000030E100: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v12    // 00000030E104: C9081304 04061907
	s_waitcnt lgkmcnt(1)                                       // 00000030E10C: BF89FC17
	v_dual_add_f32 v5, v8, v10 :: v_dual_add_f32 v8, v6, v13   // 00000030E110: C9081508 05081B06
	s_waitcnt lgkmcnt(0)                                       // 00000030E118: BF89FC07
	v_add_f32_e32 v2, v2, v14                                  // 00000030E11C: 06041D02
	ds_bpermute_b32 v6, v15, v3                                // 00000030E120: DACC0000 0600030F
	ds_bpermute_b32 v9, v15, v4                                // 00000030E128: DACC0000 0900040F
	ds_bpermute_b32 v12, v15, v5                               // 00000030E130: DACC0000 0C00050F
	ds_bpermute_b32 v13, v15, v7                               // 00000030E138: DACC0000 0D00070F
	ds_bpermute_b32 v14, v15, v8                               // 00000030E140: DACC0000 0E00080F
	ds_bpermute_b32 v15, v15, v2                               // 00000030E148: DACC0000 0F00020F
	v_xor_b32_e32 v10, 1, v1                                   // 00000030E150: 3A140281
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030E154: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000030E158: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000030E15C: 02021501
	s_waitcnt lgkmcnt(4)                                       // 00000030E160: BF89FC47
	v_dual_add_f32 v10, v3, v6 :: v_dual_add_f32 v9, v4, v9    // 00000030E164: C9080D03 0A081304
	s_waitcnt lgkmcnt(2)                                       // 00000030E16C: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v7, v13   // 00000030E170: C9081905 05061B07
	s_waitcnt lgkmcnt(1)                                       // 00000030E178: BF89FC17
	v_dual_add_f32 v1, v8, v14 :: v_dual_lshlrev_b32 v16, 2, v1// 00000030E17C: C9221D08 01100282
	s_waitcnt lgkmcnt(0)                                       // 00000030E184: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 00000030E188: 06041F02
	ds_bpermute_b32 v12, v16, v9                               // 00000030E18C: DACC0000 0C000910
	ds_bpermute_b32 v13, v16, v10                              // 00000030E194: DACC0000 0D000A10
	ds_bpermute_b32 v8, v16, v6                                // 00000030E19C: DACC0000 08000610
	ds_bpermute_b32 v7, v16, v5                                // 00000030E1A4: DACC0000 07000510
	ds_bpermute_b32 v4, v16, v2                                // 00000030E1AC: DACC0000 04000210
	ds_bpermute_b32 v3, v16, v1                                // 00000030E1B4: DACC0000 03000110
	v_cmpx_eq_u32_e32 0, v11                                   // 00000030E1BC: 7D941680
	s_cbranch_execz 54                                         // 00000030E1C0: BFA50036 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0xd9c>
	s_waitcnt lgkmcnt(4)                                       // 00000030E1C4: BF89FC47
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v9, v9, v12 // 00000030E1C8: C9081B0A 0A081909
	v_lshrrev_b32_e32 v11, 4, v0                               // 00000030E1D0: 32160084
	.long 0x7f183880                                           // 00000030E1D4: 7F183880
	s_waitcnt lgkmcnt(2)                                       // 00000030E1D8: BF89FC27
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 00000030E1DC: C9081106 06040F05
	.long 0x7e18398a                                           // 00000030E1E4: 7E18398A
	s_waitcnt lgkmcnt(0)                                       // 00000030E1E8: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v1, v3     // 00000030E1EC: C9080902 02000701
	v_mul_u32_u24_e32 v7, 12, v11                              // 00000030E1F4: 160E168C
	.long 0x7e103989                                           // 00000030E1F8: 7E103989
	.long 0x7f10398c                                           // 00000030E1FC: 7F10398C
	v_and_b32_e32 v11, 1, v12                                  // 00000030E200: 36161881
	.long 0x7e183985                                           // 00000030E204: 7E183985
	.long 0x7e083986                                           // 00000030E208: 7E083986
	.long 0x7f08398c                                           // 00000030E20C: 7F08398C
	.long 0x7e063982                                           // 00000030E210: 7E063982
	.long 0x7f06398c                                           // 00000030E214: 7F06398C
	v_and_b32_e32 v8, 1, v8                                    // 00000030E218: 36101081
	v_and_b32_e32 v13, 1, v12                                  // 00000030E21C: 361A1881
	v_and_b32_e32 v4, 1, v4                                    // 00000030E220: 36080881
	.long 0x7e183981                                           // 00000030E224: 7E183981
	v_and_b32_e32 v3, 1, v3                                    // 00000030E228: 36060681
	v_add3_u32 v8, v9, v8, 0x7fff                              // 00000030E22C: D6550008 03FE1109 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E238: BF870214
	v_add3_u32 v4, v6, v4, 0x7fff                              // 00000030E23C: D6550004 03FE0906 00007FFF
	v_and_b32_e32 v9, 1, v12                                   // 00000030E248: 36121881
	s_delay_alu instid0(VALU_DEP_4)                            // 00000030E24C: BF870004
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000030E250: D6550002 03FE0702 00007FFF
	v_add3_u32 v6, v10, v11, 0x7fff                            // 00000030E25C: D6550006 03FE170A 00007FFF
	v_add3_u32 v3, v5, v13, 0x7fff                             // 00000030E268: D6550003 03FE1B05 00007FFF
	.long 0x7e063984                                           // 00000030E274: 7E063984
	.long 0x7e0c3988                                           // 00000030E278: 7E0C3988
	v_add3_u32 v1, v1, v9, 0x7fff                              // 00000030E27C: D6550001 03FE1301 00007FFF
	.long 0x7e023982                                           // 00000030E288: 7E023982
	ds_store_2addr_b32 v7, v6, v3 offset1:1                    // 00000030E28C: D8380100 00030607
	ds_store_b32 v7, v1 offset:8                               // 00000030E294: D8340008 00000107
	s_or_b32 exec_lo, exec_lo, s4                              // 00000030E29C: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E2A0: BF870009
	s_mov_b32 s6, exec_lo                                      // 00000030E2A4: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 00000030E2A8: BF89FC07
	s_barrier                                                  // 00000030E2AC: BFBD0000
	buffer_gl0_inv                                             // 00000030E2B0: E0AC0000 00000000
	v_cmpx_gt_u32_e32 24, v0                                   // 00000030E2B8: 7D980098
	s_cbranch_execz 260                                        // 00000030E2BC: BFA50104 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x11d0>
	.long 0xd7050001                                           // 00000030E2C0: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000030E2C4: 020200FF 000000AB
	.long 0x7f163880                                           // 00000030E2CC: 7F163880
	s_cmp_eq_u64 s[10:11], 0                                   // 00000030E2D0: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E2D4: BF870092
	.long 0xd739000b                                           // 00000030E2D8: D739000B
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000030E2DC: 0202028A
	.long 0xd7050001                                           // 00000030E2E0: D7050001
	v_cndmask_b32_e32 v0, v11, v134, vcc_lo                    // 00000030E2E4: 02010D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030E2E8: BF870121
	.long 0xd7040002                                           // 00000030E2EC: D7040002
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000030E2F0: 02020300
	v_add_nc_u32_e32 v1, s3, v11                               // 00000030E2F4: 4A021603
	v_and_b32_e32 v12, 0xff, v2                                // 00000030E2F8: 361804FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E300: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000030E304: 3404029F
	v_mad_u64_u32 v[3:4], null, 0x5000, v12, s[16:17]          // 00000030E308: D6FE7C03 004218FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E314: BF870092
	.long 0xd73c0005                                           // 00000030E318: D73C0005
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000030E31C: 02020281
	.long 0xd7006a03                                           // 00000030E320: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000030E324: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E328: BF870111
	v_add_co_ci_u32_e64 v4, null, v4, v6, vcc_lo               // 00000030E32C: D5207C04 01AA0D04
	.long 0xd7006a05                                           // 00000030E334: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000030E338: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030E340: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 00000030E344: D5207C06 01AA0880
	.long 0xd7006a07                                           // 00000030E34C: D7006A07
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 00000030E350: 020206FF 00003000
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000030E358: D5207C08 01AA0880
	.long 0xd7006a09                                           // 00000030E360: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 00000030E364: 020206FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030E36C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v4, vcc_lo               // 00000030E370: D5207C0A 01AA0880
	s_clause 0x3                                               // 00000030E378: BF850003
	global_load_u16 v5, v[5:6], off offset:2048                // 00000030E37C: DC4A0800 057C0005
	global_load_u16 v6, v[7:8], off offset:3072                // 00000030E384: DC4A0C00 067C0007
	global_load_u16 v3, v[3:4], off                            // 00000030E38C: DC4A0000 037C0003
	global_load_u16 v4, v[9:10], off offset:1024               // 00000030E394: DC4A0400 047C0009
	v_mul_u32_u24_e32 v7, 48, v11                              // 00000030E39C: 160E16B0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030E3A0: BF870001
	v_lshl_add_u32 v7, v12, 1, v7                              // 00000030E3A4: D6460007 041D030C
	ds_load_u16 v8, v7                                         // 00000030E3AC: D8F00000 08000007
	ds_load_u16 v9, v7 offset:12                               // 00000030E3B4: D8F0000C 09000007
	ds_load_u16 v10, v7 offset:24                              // 00000030E3BC: D8F00018 0A000007
	ds_load_u16 v7, v7 offset:36                               // 00000030E3C4: D8F00024 07000007
	s_waitcnt lgkmcnt(0)                                       // 00000030E3CC: BF89FC07
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000030E3D0: 300E0E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E3D4: BF870091
	v_dual_mul_f32 v7, 0xbfb8aa3b, v7 :: v_dual_lshlrev_b32 v10, 16, v10// 00000030E3D8: C8E20EFF 070A1490 BFB8AA3B
	v_dual_mul_f32 v10, 0xbfb8aa3b, v10 :: v_dual_lshlrev_b32 v9, 16, v9// 00000030E3E4: C8E214FF 0A081290 BFB8AA3B
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000030E3F0: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E3F4: BF870113
	v_exp_f32_e32 v7, v7                                       // 00000030E3F8: 7E0E4B07
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000030E3FC: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E404: BF870113
	v_exp_f32_e32 v10, v10                                     // 00000030E408: 7E144B0A
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000030E40C: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E414: BF870092
	v_exp_f32_e32 v9, v9                                       // 00000030E418: 7E124B09
	v_exp_f32_e32 v8, v8                                       // 00000030E41C: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E420: BF870097
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_add_f32 v10, 1.0, v10 // 00000030E424: C9080EF2 070A14F2
	v_div_scale_f32 v15, null, v7, v7, 1.0                     // 00000030E42C: D6FC7C0F 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E434: BF870196
	v_add_f32_e32 v9, 1.0, v9                                  // 00000030E438: 061212F2
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 00000030E43C: D6FC7C0E 03CA150A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000030E444: BF870005
	v_add_f32_e32 v8, 1.0, v8                                  // 00000030E448: 061010F2
	v_div_scale_f32 v25, s4, 1.0, v10, 1.0                     // 00000030E44C: D6FC0419 03CA14F2
	v_rcp_f32_e32 v19, v15                                     // 00000030E454: 7E26550F
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 00000030E458: D6FC7C0D 03CA1309
	v_rcp_f32_e32 v18, v14                                     // 00000030E460: 7E24550E
	v_div_scale_f32 v11, null, v8, v8, 1.0                     // 00000030E464: D6FC7C0B 03CA1108
	v_div_scale_f32 v20, vcc_lo, 1.0, v8, 1.0                  // 00000030E46C: D6FC6A14 03CA10F2
	v_div_scale_f32 v21, s3, 1.0, v9, 1.0                      // 00000030E474: D6FC0315 03CA12F2
	v_rcp_f32_e32 v17, v13                                     // 00000030E47C: 7E22550D
	v_mad_u64_u32 v[1:2], null, 0xa00, v12, v[1:2]             // 00000030E480: D6FE7C01 040618FF 00000A00
	v_rcp_f32_e32 v16, v11                                     // 00000030E48C: 7E20550B
	v_fma_f32 v26, -v15, v19, 1.0                              // 00000030E490: D613001A 23CA270F
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E498: BF870117
	v_fma_f32 v24, -v14, v18, 1.0                              // 00000030E49C: D6130018 23CA250E
	v_fmac_f32_e32 v19, v26, v19                               // 00000030E4A4: 5626271A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E4A8: BF870196
	v_fma_f32 v23, -v13, v17, 1.0                              // 00000030E4AC: D6130017 23CA230D
	v_fmac_f32_e32 v18, v24, v18                               // 00000030E4B4: 56242518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E4B8: BF870095
	v_fma_f32 v22, -v11, v16, 1.0                              // 00000030E4BC: D6130016 23CA210B
	v_dual_fmac_f32 v17, v23, v17 :: v_dual_fmac_f32 v16, v22, v16// 00000030E4C4: C8002317 11102116
	v_div_scale_f32 v22, s5, 1.0, v7, 1.0                      // 00000030E4CC: D6FC0516 03CA0EF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E4D4: BF870194
	v_mul_f32_e32 v26, v25, v18                                // 00000030E4D8: 10342519
	v_dual_mul_f32 v24, v21, v17 :: v_dual_mul_f32 v23, v20, v16// 00000030E4DC: C8C62315 18162114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E4E4: BF870193
	v_mul_f32_e32 v27, v22, v19                                // 00000030E4E8: 10362716
	v_fma_f32 v30, -v14, v26, v25                              // 00000030E4EC: D613001E 2466350E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E4F4: BF870213
	v_fma_f32 v29, -v13, v24, v21                              // 00000030E4F8: D613001D 2456310D
	v_fma_f32 v28, -v11, v23, v20                              // 00000030E500: D613001C 24522F0B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E508: BF870214
	v_fma_f32 v31, -v15, v27, v22                              // 00000030E50C: D613001F 245A370F
	v_fmac_f32_e32 v26, v30, v18                               // 00000030E514: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E518: BF870193
	v_dual_fmac_f32 v24, v29, v17 :: v_dual_fmac_f32 v23, v28, v16// 00000030E51C: C800231D 1816211C
	v_fmac_f32_e32 v27, v31, v19                               // 00000030E524: 5636271F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E528: BF870193
	v_fma_f32 v14, -v14, v26, v25                              // 00000030E52C: D613000E 2466350E
	v_fma_f32 v13, -v13, v24, v21                              // 00000030E534: D613000D 2456310D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E53C: BF870214
	v_fma_f32 v11, -v11, v23, v20                              // 00000030E540: D613000B 24522F0B
	v_fma_f32 v15, -v15, v27, v22                              // 00000030E548: D613000F 245A370F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000030E550: BF870142
	v_div_fmas_f32 v11, v11, v16, v23                          // 00000030E554: D637000B 045E210B
	s_mov_b32 vcc_lo, s3                                       // 00000030E55C: BEEA0003
	v_div_fmas_f32 v13, v13, v17, v24                          // 00000030E560: D637000D 0462230D
	s_mov_b32 vcc_lo, s4                                       // 00000030E568: BEEA0004
	v_div_fixup_f32 v8, v11, v8, 1.0                           // 00000030E56C: D6270008 03CA110B
	v_div_fmas_f32 v11, v14, v18, v26                          // 00000030E574: D637000B 046A250E
	s_mov_b32 vcc_lo, s5                                       // 00000030E57C: BEEA0005
	v_div_fixup_f32 v9, v13, v9, 1.0                           // 00000030E580: D6270009 03CA130D
	v_div_fmas_f32 v14, v15, v19, v27                          // 00000030E588: D637000E 046E270F
	v_bfe_u32 v13, v8, 16, 1                                   // 00000030E590: D610000D 02052108
	v_div_fixup_f32 v10, v11, v10, 1.0                         // 00000030E598: D627000A 03CA150B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E5A0: BF870214
	v_bfe_u32 v11, v9, 16, 1                                   // 00000030E5A4: D610000B 02052109
	v_div_fixup_f32 v7, v14, v7, 1.0                           // 00000030E5AC: D6270007 03CA0F0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E5B4: BF870214
	v_add3_u32 v8, v8, v13, 0x7fff                             // 00000030E5B8: D6550008 03FE1B08 00007FFF
	v_bfe_u32 v13, v10, 16, 1                                  // 00000030E5C4: D610000D 0205210A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030E5CC: BF870214
	v_add3_u32 v9, v9, v11, 0x7fff                             // 00000030E5D0: D6550009 03FE1709 00007FFF
	v_bfe_u32 v11, v7, 16, 1                                   // 00000030E5DC: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E5E4: BF870193
	v_add3_u32 v10, v10, v13, 0x7fff                           // 00000030E5E8: D655000A 03FE1B0A 00007FFF
	v_and_b32_e32 v9, 0xffff0000, v9                           // 00000030E5F4: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030E5FC: BF870003
	v_add3_u32 v7, v7, v11, 0x7fff                             // 00000030E600: D6550007 03FE1707 00007FFF
	s_waitcnt vmcnt(3)                                         // 00000030E60C: BF890FF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000030E610: 300A0A90
	s_waitcnt vmcnt(2)                                         // 00000030E614: BF890BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000030E618: 300C0C90
	s_waitcnt vmcnt(1)                                         // 00000030E61C: BF8907F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 00000030E620: 30060690
	s_waitcnt vmcnt(0)                                         // 00000030E624: BF8903F7
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000030E628: 30080890
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000030E62C: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E634: BF870091
	v_fma_f32 v3, v3, v8, 0                                    // 00000030E638: D6130003 02021103
	v_dual_fmac_f32 v3, v4, v9 :: v_dual_and_b32 v4, 0xffff0000, v7// 00000030E640: C8241304 03040EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 00000030E64C: 361014FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E654: BF870091
	v_fmac_f32_e32 v3, v5, v8                                  // 00000030E658: 56061105
	v_fmac_f32_e32 v3, v6, v4                                  // 00000030E65C: 56060906
	.long 0xd73c0004                                           // 00000030E660: D73C0004
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000030E664: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E668: BF870112
	v_mul_f32_e32 v3, 0x3e800000, v3                           // 00000030E66C: 100606FF 3E800000
	.long 0xd7006a04                                           // 00000030E674: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 00000030E678: 02020808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E67C: BF870191
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 00000030E680: D5207C05 01AA0A09
	v_bfe_u32 v6, v3, 16, 1                                    // 00000030E688: D6100006 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030E690: BF870001
	v_add3_u32 v6, v3, v6, 0x7fff                              // 00000030E694: D6550006 03FE0D03 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000030E6A0: DC960000 007C0604
	s_cbranch_scc1 9                                           // 00000030E6A8: BFA20009 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x11d0>
	.long 0xd73c0001                                           // 00000030E6AC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000030E6B0: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030E6B4: BF870091
	.long 0xd7006a01                                           // 00000030E6B8: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 00000030E6BC: 0202020A
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 00000030E6C0: D5207C02 01AA040B
	global_store_b32 v[1:2], v3, off                           // 00000030E6C8: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 00000030E6D0: 8C7E067E
	s_mov_b32 s4, 0                                            // 00000030E6D4: BE840080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E6D8: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000030E6DC: 8B6A047E
	s_cbranch_vccz 1176                                        // 00000030E6E0: BFA30498 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2444>
	s_clause 0x3                                               // 00000030E6E4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 00000030E6E8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 00000030E6F0: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 00000030E6F8: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 00000030E700: F4000180 F8000118
	v_lshrrev_b32_e32 v3, 5, v0                                // 00000030E708: 32060085
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000030E70C: CA240080 100E009F
	s_waitcnt lgkmcnt(0)                                       // 00000030E714: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 00000030E718: BF028103
	s_cselect_b32 s7, -1, 0                                    // 00000030E71C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 00000030E720: BF030402
	s_cselect_b32 s4, -1, 0                                    // 00000030E724: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E728: BF870009
	s_and_b32 s4, s7, s4                                       // 00000030E72C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 00000030E730: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000030E734: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 00000030E73C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 00000030E740: BF030502
	s_cselect_b32 s5, -1, 0                                    // 00000030E744: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E748: BF870009
	s_and_b32 s4, s7, s5                                       // 00000030E74C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 00000030E750: BF028303
	v_readfirstlane_b32 s5, v1                                 // 00000030E754: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 00000030E758: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 00000030E75C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 00000030E760: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000030E764: BF8704D9
	s_and_b32 s3, s3, s6                                       // 00000030E768: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 00000030E76C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 00000030E770: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 00000030E774: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000030E778: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000030E77C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E780: BF870009
	s_add_u32 s6, s0, s3                                       // 00000030E784: 80060300
	s_addc_u32 s7, s1, 0                                       // 00000030E788: 82078001
	s_clause 0x1                                               // 00000030E78C: BF850001
	s_load_b64 s[4:5], s[6:7], 0x30                            // 00000030E790: F4040103 F8000030
	s_load_b32 s0, s[6:7], 0x40                                // 00000030E798: F4000003 F8000040
	s_waitcnt lgkmcnt(0)                                       // 00000030E7A0: BF89FC07
	.long 0xd451000e                                           // 00000030E7A4: D451000E
	v_cndmask_b32_e32 v0, s4, v137, vcc_lo                     // 00000030E7A8: 02011204
	s_and_b32 s1, s14, exec_lo                                 // 00000030E7AC: 8B017E0E
	s_cselect_b32 s1, 8, 2                                     // 00000030E7B0: 98018288
	s_cselect_b32 s3, 3, 1                                     // 00000030E7B4: 98038183
	v_cvt_f32_ubyte0_e32 v1, s1                                // 00000030E7B8: 7E022201
	s_sub_i32 s8, s2, s0                                       // 00000030E7BC: 81880002
	s_add_i32 s0, s1, -1                                       // 00000030E7C0: 8100C101
	s_ashr_i32 s9, s8, 31                                      // 00000030E7C4: 86099F08
	s_and_b32 s10, s14, exec_lo                                // 00000030E7C8: 8B0A7E0E
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000030E7CC: 7E025701
	s_cselect_b32 s15, 0, 2                                    // 00000030E7D0: 980F8280
	s_ashr_i32 s10, s19, 31                                    // 00000030E7D4: 860A9F13
	s_lshl_b64 s[8:9], s[8:9], s15                             // 00000030E7D8: 84880F08
	s_lshr_b32 s10, s10, 28                                    // 00000030E7DC: 850A9C0A
	v_lshrrev_b32_e32 v13, s3, v3                              // 00000030E7E0: 321A0603
	s_add_u32 s10, s18, s10                                    // 00000030E7E4: 800A0A12
	s_addc_u32 s11, s19, 0                                     // 00000030E7E8: 820B8013
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000030E7EC: BF870299
	s_ashr_i64 s[10:11], s[10:11], 4                           // 00000030E7F0: 868A840A
	v_readfirstlane_b32 s20, v1                                // 00000030E7F4: 7E280501
	s_add_u32 s22, s10, s18                                    // 00000030E7F8: 8016120A
	s_addc_u32 s11, s11, s19                                   // 00000030E7FC: 820B130B
	s_sub_i32 s21, 0, s1                                       // 00000030E800: 81950180
	s_add_i32 s23, s0, s10                                     // 00000030E804: 81170A00
	s_mul_f32 s20, s20, 0x4f7ffffe                             // 00000030E808: A214FF14 4F7FFFFE
	s_abs_i32 s24, s23                                         // 00000030E810: BE981517
	.long 0xd7000801                                           // 00000030E814: D7000801
	v_cndmask_b32_e32 v1, s8, v13, vcc_lo                      // 00000030E818: 02021A08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000030E81C: BF8704B9
	s_cvt_u32_f32 s20, s20                                     // 00000030E820: BE946714
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 00000030E824: D5207C02 00210009
	s_ashr_i32 s9, s23, 31                                     // 00000030E82C: 86099F17
	s_mul_i32 s21, s21, s20                                    // 00000030E830: 96151415
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030E834: BF870009
	s_mul_hi_u32 s21, s20, s21                                 // 00000030E838: 96951514
	v_cmp_gt_i64_e32 vcc_lo, s[4:5], v[1:2]                    // 00000030E83C: 7CA80204
	s_add_i32 s25, s20, s21                                    // 00000030E840: 81191514
	s_load_b64 s[20:21], s[6:7], null                          // 00000030E844: F4040503 F8000000
	s_mul_hi_u32 s25, s24, s25                                 // 00000030E84C: 96991918
	v_and_b32_e32 v14, s0, v3                                  // 00000030E850: 361C0600
	s_mul_i32 s8, s25, s1                                      // 00000030E854: 96080119
	s_add_i32 s23, s25, 1                                      // 00000030E858: 81178119
	s_sub_i32 s8, s24, s8                                      // 00000030E85C: 81880818
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000030E860: 02040480
	s_sub_i32 s24, s8, s1                                      // 00000030E864: 81980108
	s_cmp_ge_u32 s8, s1                                        // 00000030E868: BF090108
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000030E86C: 02020280
	s_cselect_b32 s23, s23, s25                                // 00000030E870: 98171917
	s_cselect_b32 s8, s24, s8                                  // 00000030E874: 98080818
	s_add_i32 s24, s23, 1                                      // 00000030E878: 81188117
	s_cmp_ge_u32 s8, s1                                        // 00000030E87C: BF090108
	.long 0xd72c0004                                           // 00000030E880: D72C0004
	v_cndmask_b32_e32 v0, v2, v22, vcc_lo                      // 00000030E884: 02002D02
	s_cselect_b32 s0, s24, s23                                 // 00000030E888: 98001718
	.long 0xd72c0006                                           // 00000030E88C: D72C0006
	v_cndmask_b32_e32 v0, v1, v11, vcc_lo                      // 00000030E890: 02001701
	s_xor_b32 s0, s0, s9                                       // 00000030E894: 8D000900
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 00000030E898: CA100080 02020080
	s_sub_i32 s0, s0, s9                                       // 00000030E8A0: 81800900
	s_waitcnt lgkmcnt(0)                                       // 00000030E8A4: BF89FC07
	v_mad_u64_u32 v[9:10], null, v1, s22, s[20:21]             // 00000030E8A8: D6FE7C09 00502D01
	.long 0xd72c0005                                           // 00000030E8B0: D72C0005
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 00000030E8B4: 0200010E
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v1, 0              // 00000030E8B8: CA100080 1A000080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030E8C0: BF870193
	v_add3_u32 v10, v4, v10, v6                                // 00000030E8C4: D655000A 041A1504
	v_add_nc_u32_e32 v7, s0, v5                                // 00000030E8CC: 4A0E0A00
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v17, v5, v15     // 00000030E8D0: CA200080 04101F05
	.long 0xd7006a13                                           // 00000030E8D8: D7006A13
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 00000030E8DC: 02002509
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030E8E0: BF870123
	v_min_i32_e32 v18, s10, v7                                 // 00000030E8E4: 22240E0A
	v_add_co_ci_u32_e64 v20, null, s19, v10, vcc_lo            // 00000030E8E8: D5207C14 01AA1413
	v_cmp_lt_i32_e32 vcc_lo, v17, v18                          // 00000030E8F0: 7C822511
	s_and_saveexec_b32 s8, vcc_lo                              // 00000030E8F4: BE88206A
	s_cbranch_execz 19                                         // 00000030E8F8: BFA50013 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1448>
	v_lshlrev_b32_e32 v1, 4, v17                               // 00000030E8FC: 30022284
	v_and_b32_e32 v3, -4, v17                                  // 00000030E900: 360622C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030E904: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000030E908: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000030E90C: 3408069F
	.long 0xd7000001                                           // 00000030E910: D7000001
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000030E914: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030E918: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, s0                  // 00000030E91C: D5207C02 0002050A
	.long 0xd7000006                                           // 00000030E924: D7000006
	v_cndmask_b32_e32 v1, v19, v3, vcc_lo                      // 00000030E928: 02020713
	v_add_co_ci_u32_e64 v7, null, v20, v4, s0                  // 00000030E92C: D5207C07 00020914
	s_clause 0x1                                               // 00000030E934: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 00000030E938: DC5E0000 017C0001
	global_load_b32 v26, v[6:7], off                           // 00000030E940: DC520000 1A7C0006
	s_or_b32 exec_lo, exec_lo, s8                              // 00000030E948: 8C7E087E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000030E94C: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000030E954: CA100080 18180080
	v_mov_b32_e32 v21, 0                                       // 00000030E95C: 7E2A0280
	s_and_saveexec_b32 s20, vcc_lo                             // 00000030E960: BE94206A
	s_cbranch_execz 410                                        // 00000030E964: BFA5019A <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1ad0>
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 00000030E968: CA220080 15061E84
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v24, 0             // 00000030E970: CA100080 19180080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000030E978: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030E980: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 00000030E984: D646000B 04190905
	v_mov_b32_e32 v16, 0                                       // 00000030E98C: 7E200280
	s_mul_i32 s0, s19, 6                                       // 00000030E990: 96008613
	s_mul_hi_u32 s10, s18, 6                                   // 00000030E994: 968A8612
	s_lshl_b64 s[8:9], s[18:19], 2                             // 00000030E998: 84888212
	s_add_i32 s21, s10, s0                                     // 00000030E99C: 8115000A
	s_mul_i32 s23, s18, 6                                      // 00000030E9A0: 96178612
	s_mov_b32 s22, 0                                           // 00000030E9A4: BE960080
	s_lshl_b64 s[10:11], s[18:19], 1                           // 00000030E9A8: 848A8112
	s_branch 354                                               // 00000030E9AC: BFA00162 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1a38>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000030E9B0: 8C7E127E
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000030E9B4: 3418169F
	v_cvt_f32_ubyte1_e32 v77, v1                               // 00000030E9B8: 7E9A2501
	v_cvt_f32_ubyte2_e32 v78, v1                               // 00000030E9BC: 7E9C2701
	v_cvt_f32_ubyte3_e32 v79, v1                               // 00000030E9C0: 7E9E2901
	v_cvt_f32_ubyte0_e32 v80, v2                               // 00000030E9C4: 7EA02302
	.long 0xd73c000b                                           // 00000030E9C8: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000030E9CC: 02021681
	v_cvt_f32_ubyte1_e32 v81, v2                               // 00000030E9D0: 7EA22502
	v_cvt_f32_ubyte2_e32 v82, v2                               // 00000030E9D4: 7EA42702
	v_cvt_f32_ubyte3_e32 v83, v2                               // 00000030E9D8: 7EA62902
	s_waitcnt vmcnt(1)                                         // 00000030E9DC: BF8907F7
	v_mov_b32_e32 v2, v6                                       // 00000030E9E0: 7E040306
	v_cvt_f32_ubyte0_e32 v84, v3                               // 00000030E9E4: 7EA82303
	.long 0xd700000b                                           // 00000030E9E8: D700000B
	v_cndmask_b32_e32 v1, s16, v11, vcc_lo                     // 00000030E9EC: 02021610
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000030E9F0: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s17, v12, s0                // 00000030E9F4: D5207C0C 00021811
	v_cvt_f32_ubyte1_e32 v85, v3                               // 00000030E9FC: 7EAA2503
	.long 0xd7000039                                           // 00000030EA00: D7000039
	v_cndmask_b32_e32 v0, v11, v10, vcc_lo                     // 00000030EA04: 0200150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030EA08: BF8700A1
	v_add_co_ci_u32_e64 v58, null, s11, v12, s0                // 00000030EA0C: D5207C3A 0002180B
	.long 0xd700003d                                           // 00000030EA14: D700003D
	v_cndmask_b32_e32 v0, v11, v8, vcc_lo                      // 00000030EA18: 0200110B
	v_add_co_ci_u32_e64 v62, null, s9, v12, s0                 // 00000030EA1C: D5207C3E 00021809
	.long 0xd7000041                                           // 00000030EA24: D7000041
	v_cndmask_b32_e32 v0, v11, v23, vcc_lo                     // 00000030EA28: 02002F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030EA2C: BF870001
	v_add_co_ci_u32_e64 v66, null, s21, v12, s0                // 00000030EA30: D5207C42 00021815
	s_clause 0x3                                               // 00000030EA38: BF850003
	global_load_b128 v[29:32], v[11:12], off                   // 00000030EA3C: DC5E0000 1D7C000B
	global_load_b128 v[33:36], v[57:58], off                   // 00000030EA44: DC5E0000 217C0039
	global_load_b128 v[37:40], v[61:62], off                   // 00000030EA4C: DC5E0000 257C003D
	global_load_b128 v[41:44], v[65:66], off                   // 00000030EA54: DC5E0000 297C0041
	.long 0xd7000045                                           // 00000030EA5C: D7000045
	v_cndmask_b32_e32 v0, v61, v8, vcc_lo                      // 00000030EA60: 0200113D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030EA64: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s9, v62, s0                 // 00000030EA68: D5207C46 00027C09
	.long 0xd7000049                                           // 00000030EA70: D7000049
	v_cndmask_b32_e32 v0, v65, v8, vcc_lo                      // 00000030EA74: 02001141
	v_add_co_ci_u32_e64 v74, null, s9, v66, s0                 // 00000030EA78: D5207C4A 00028409
	s_clause 0x7                                               // 00000030EA80: BF850007
	global_load_b128 v[45:48], v[69:70], off                   // 00000030EA84: DC5E0000 2D7C0045
	global_load_b128 v[49:52], v[73:74], off                   // 00000030EA8C: DC5E0000 317C0049
	global_load_b128 v[53:56], v[11:12], off offset:16         // 00000030EA94: DC5E0010 357C000B
	global_load_b128 v[57:60], v[57:58], off offset:16         // 00000030EA9C: DC5E0010 397C0039
	global_load_b128 v[61:64], v[61:62], off offset:16         // 00000030EAA4: DC5E0010 3D7C003D
	global_load_b128 v[65:68], v[65:66], off offset:16         // 00000030EAAC: DC5E0010 417C0041
	global_load_b128 v[69:72], v[69:70], off offset:16         // 00000030EAB4: DC5E0010 457C0045
	global_load_b128 v[73:76], v[73:74], off offset:16         // 00000030EABC: DC5E0010 497C0049
	v_cvt_f32_ubyte0_e32 v11, v1                               // 00000030EAC4: 7E162301
	v_mov_b32_e32 v1, v5                                       // 00000030EAC8: 7E020305
	v_cvt_f32_ubyte2_e32 v86, v3                               // 00000030EACC: 7EAC2703
	v_cvt_f32_ubyte3_e32 v87, v3                               // 00000030EAD0: 7EAE2903
	v_cvt_f32_ubyte0_e32 v88, v4                               // 00000030EAD4: 7EB02304
	v_fma_mix_f32 v5, v11, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EAD8: CC206005 146A350B
	v_cvt_f32_ubyte1_e32 v89, v4                               // 00000030EAE0: 7EB22504
	v_cvt_f32_ubyte2_e32 v90, v4                               // 00000030EAE4: 7EB42704
	v_cvt_f32_ubyte3_e32 v91, v4                               // 00000030EAE8: 7EB62904
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000030EAEC: CA100108 04020107
	v_fma_mix_f32 v6, v77, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EAF4: CC206006 146A354D
	v_fma_mix_f32 v7, v78, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EAFC: CC206007 146A354E
	v_fma_mix_f32 v78, v80, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB04: CC20604E 146A3550
	v_mov_b32_e32 v11, v28                                     // 00000030EB0C: 7E16031C
	v_bfe_u32 v28, v5, 16, 1                                   // 00000030EB10: D610001C 02052105
	v_fma_mix_f32 v77, v79, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB18: CC20604D 146A354F
	v_fma_mix_f32 v79, v81, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB20: CC20604F 146A3551
	v_fma_mix_f32 v80, v82, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB28: CC206050 146A3552
	v_fma_mix_f32 v82, v83, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB30: CC206052 146A3553
	v_fma_mix_f32 v83, v84, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB38: CC206053 146A3554
	v_fma_mix_f32 v84, v85, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB40: CC206054 146A3555
	v_fma_mix_f32 v85, v86, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB48: CC206055 146A3556
	v_fma_mix_f32 v87, v87, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB50: CC206057 146A3557
	v_fma_mix_f32 v88, v88, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB58: CC206058 146A3558
	v_fma_mix_f32 v89, v89, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB60: CC206059 146A3559
	v_fma_mix_f32 v90, v90, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB68: CC20605A 146A355A
	v_fma_mix_f32 v26, v91, v26, v26 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000030EB70: CC20601A 146A355B
	v_bfe_u32 v91, v6, 16, 1                                   // 00000030EB78: D610005B 02052106
	v_bfe_u32 v93, v7, 16, 1                                   // 00000030EB80: D610005D 02052107
	v_bfe_u32 v95, v78, 16, 1                                  // 00000030EB88: D610005F 0205214E
	v_add3_u32 v5, v5, v28, 0x7fff                             // 00000030EB90: D6550005 03FE3905 00007FFF
	.long 0x7f183880                                           // 00000030EB9C: 7F183880
	v_bfe_u32 v94, v77, 16, 1                                  // 00000030EBA0: D610005E 0205214D
	v_bfe_u32 v96, v79, 16, 1                                  // 00000030EBA8: D6100060 0205214F
	v_bfe_u32 v99, v83, 16, 1                                  // 00000030EBB0: D6100063 02052153
	v_add3_u32 v6, v6, v91, 0x7fff                             // 00000030EBB8: D6550006 03FEB706 00007FFF
	v_add3_u32 v7, v7, v93, 0x7fff                             // 00000030EBC4: D6550007 03FEBB07 00007FFF
	v_add3_u32 v78, v78, v95, 0x7fff                           // 00000030EBD0: D655004E 03FEBF4E 00007FFF
	.long 0x7e183985                                           // 00000030EBDC: 7E183985
	.long 0x7f10398c                                           // 00000030EBE0: 7F10398C
	v_bfe_u32 v97, v80, 16, 1                                  // 00000030EBE4: D6100061 02052150
	v_bfe_u32 v100, v84, 16, 1                                 // 00000030EBEC: D6100064 02052154
	v_bfe_u32 v28, v85, 16, 1                                  // 00000030EBF4: D610001C 02052155
	v_bfe_u32 v91, v87, 16, 1                                  // 00000030EBFC: D610005B 02052157
	v_bfe_u32 v93, v88, 16, 1                                  // 00000030EC04: D610005D 02052158
	v_add3_u32 v77, v77, v94, 0x7fff                           // 00000030EC0C: D655004D 03FEBD4D 00007FFF
	v_add3_u32 v79, v79, v96, 0x7fff                           // 00000030EC18: D655004F 03FEC14F 00007FFF
	v_add3_u32 v83, v83, v99, 0x7fff                           // 00000030EC24: D6550053 03FEC753 00007FFF
	.long 0x7e103987                                           // 00000030EC30: 7E103987
	v_and_or_b32 v6, 0xffff0000, v6, v12                       // 00000030EC34: D6570006 04320CFF FFFF0000
	.long 0x7e1839ce                                           // 00000030EC40: 7E1839CE
	v_bfe_u32 v98, v82, 16, 1                                  // 00000030EC44: D6100062 02052152
	v_bfe_u32 v94, v89, 16, 1                                  // 00000030EC4C: D610005E 02052159
	v_add3_u32 v80, v80, v97, 0x7fff                           // 00000030EC54: D6550050 03FEC350 00007FFF
	v_add3_u32 v84, v84, v100, 0x7fff                          // 00000030EC60: D6550054 03FEC954 00007FFF
	v_add3_u32 v28, v85, v28, 0x7fff                           // 00000030EC6C: D655001C 03FE3955 00007FFF
	v_add3_u32 v85, v87, v91, 0x7fff                           // 00000030EC78: D6550055 03FEB757 00007FFF
	v_add3_u32 v87, v88, v93, 0x7fff                           // 00000030EC84: D6550057 03FEBB58 00007FFF
	v_and_or_b32 v7, 0xffff0000, v77, v8                       // 00000030EC90: D6570007 04229AFF FFFF0000
	v_and_or_b32 v8, 0xffff0000, v79, v12                      // 00000030EC9C: D6570008 04329EFF FFFF0000
	.long 0x7e1839d3                                           // 00000030ECA8: 7E1839D3
	.long 0x7fa2398c                                           // 00000030ECAC: 7FA2398C
	v_add3_u32 v82, v82, v98, 0x7fff                           // 00000030ECB0: D6550052 03FEC552 00007FFF
	v_add3_u32 v5, v89, v94, 0x7fff                            // 00000030ECBC: D6550005 03FEBD59 00007FFF
	.long 0x7ea239d0                                           // 00000030ECC8: 7EA239D0
	v_and_or_b32 v78, 0xffff0000, v84, v12                     // 00000030ECCC: D657004E 0432A8FF FFFF0000
	.long 0x7e1839d7                                           // 00000030ECD8: 7E1839D7
	.long 0x7fac398c                                           // 00000030ECDC: 7FAC398C
	.long 0x7fb8398c                                           // 00000030ECE0: 7FB8398C
	.long 0x7eac399c                                           // 00000030ECE4: 7EAC399C
	v_and_or_b32 v28, 0xffff0000, v82, v81                     // 00000030ECE8: D657001C 0546A4FF FFFF0000
	v_and_or_b32 v5, 0xffff0000, v5, v12                       // 00000030ECF4: D6570005 04320AFF FFFF0000
	v_bfe_u32 v95, v90, 16, 1                                  // 00000030ED00: D610005F 0205215A
	v_bfe_u32 v96, v26, 16, 1                                  // 00000030ED08: D6100060 0205211A
	v_and_or_b32 v77, 0xffff0000, v85, v86                     // 00000030ED10: D657004D 055AAAFF FFFF0000
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000030ED1C: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030ED20: BF870193
	v_add3_u32 v88, v90, v95, 0x7fff                           // 00000030ED24: D6550058 03FEBF5A 00007FFF
	v_add3_u32 v26, v26, v96, 0x7fff                           // 00000030ED30: D655001A 03FEC11A 00007FFF
	s_or_b32 s22, s0, s22                                      // 00000030ED3C: 8C161600
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030ED40: BF870092
	.long 0x7eb839d8                                           // 00000030ED44: 7EB839D8
	v_and_or_b32 v26, 0xffff0000, v26, v92                     // 00000030ED48: D657001A 057234FF FFFF0000
	s_waitcnt vmcnt(11)                                        // 00000030ED54: BF892FF7
	v_dot2_f32_bf16 v29, v29, v6, 0                            // 00000030ED58: CC1A401D 1A020D1D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030ED60: BF870001
	v_dot2_f32_bf16 v29, v30, v7, v29                          // 00000030ED64: CC1A401D 1C760F1E
	s_waitcnt vmcnt(10)                                        // 00000030ED6C: BF892BF7
	v_dot2_f32_bf16 v30, v33, v6, 0                            // 00000030ED70: CC1A401E 1A020D21
	s_waitcnt vmcnt(9)                                         // 00000030ED78: BF8927F7
	v_dot2_f32_bf16 v33, v37, v6, 0                            // 00000030ED7C: CC1A4021 1A020D25
	s_waitcnt vmcnt(8)                                         // 00000030ED84: BF8923F7
	v_dot2_f32_bf16 v37, v41, v6, 0                            // 00000030ED88: CC1A4025 1A020D29
	v_dot2_f32_bf16 v12, v31, v8, v29                          // 00000030ED90: CC1A400C 1C76111F
	v_dot2_f32_bf16 v29, v34, v7, v30                          // 00000030ED98: CC1A401D 1C7A0F22
	v_dot2_f32_bf16 v30, v38, v7, v33                          // 00000030EDA0: CC1A401E 1C860F26
	s_delay_alu instid0(VALU_DEP_4)                            // 00000030EDA8: BF870004
	v_dot2_f32_bf16 v31, v42, v7, v37                          // 00000030EDAC: CC1A401F 1C960F2A
	s_waitcnt vmcnt(7)                                         // 00000030EDB4: BF891FF7
	v_dot2_f32_bf16 v33, v45, v6, 0                            // 00000030EDB8: CC1A4021 1A020D2D
	s_waitcnt vmcnt(6)                                         // 00000030EDC0: BF891BF7
	v_dot2_f32_bf16 v6, v49, v6, 0                             // 00000030EDC4: CC1A4006 1A020D31
	v_dot2_f32_bf16 v12, v32, v28, v12                         // 00000030EDCC: CC1A400C 1C323920
	v_dot2_f32_bf16 v29, v35, v8, v29                          // 00000030EDD4: CC1A401D 1C761123
	v_dot2_f32_bf16 v30, v39, v8, v30                          // 00000030EDDC: CC1A401E 1C7A1127
	v_dot2_f32_bf16 v31, v43, v8, v31                          // 00000030EDE4: CC1A401F 1C7E112B
	v_dot2_f32_bf16 v32, v46, v7, v33                          // 00000030EDEC: CC1A4020 1C860F2E
	v_dot2_f32_bf16 v6, v50, v7, v6                            // 00000030EDF4: CC1A4006 1C1A0F32
	s_waitcnt vmcnt(5)                                         // 00000030EDFC: BF8917F7
	v_dot2_f32_bf16 v7, v53, v78, v12                          // 00000030EE00: CC1A4007 1C329D35
	v_dot2_f32_bf16 v12, v36, v28, v29                         // 00000030EE08: CC1A400C 1C763924
	v_dot2_f32_bf16 v29, v40, v28, v30                         // 00000030EE10: CC1A401D 1C7A3928
	v_dot2_f32_bf16 v30, v44, v28, v31                         // 00000030EE18: CC1A401E 1C7E392C
	v_dot2_f32_bf16 v31, v47, v8, v32                          // 00000030EE20: CC1A401F 1C82112F
	v_dot2_f32_bf16 v6, v51, v8, v6                            // 00000030EE28: CC1A4006 1C1A1133
	v_dot2_f32_bf16 v7, v54, v77, v7                           // 00000030EE30: CC1A4007 1C1E9B36
	s_waitcnt vmcnt(4)                                         // 00000030EE38: BF8913F7
	v_dot2_f32_bf16 v8, v57, v78, v12                          // 00000030EE3C: CC1A4008 1C329D39
	s_waitcnt vmcnt(3)                                         // 00000030EE44: BF890FF7
	v_dot2_f32_bf16 v12, v61, v78, v29                         // 00000030EE48: CC1A400C 1C769D3D
	s_waitcnt vmcnt(2)                                         // 00000030EE50: BF890BF7
	v_dot2_f32_bf16 v29, v65, v78, v30                         // 00000030EE54: CC1A401D 1C7A9D41
	v_dot2_f32_bf16 v30, v48, v28, v31                         // 00000030EE5C: CC1A401E 1C7E3930
	v_dot2_f32_bf16 v6, v52, v28, v6                           // 00000030EE64: CC1A4006 1C1A3934
	v_dot2_f32_bf16 v7, v55, v5, v7                            // 00000030EE6C: CC1A4007 1C1E0B37
	v_dot2_f32_bf16 v8, v58, v77, v8                           // 00000030EE74: CC1A4008 1C229B3A
	v_dot2_f32_bf16 v12, v62, v77, v12                         // 00000030EE7C: CC1A400C 1C329B3E
	s_waitcnt vmcnt(1)                                         // 00000030EE84: BF8907F7
	v_dot2_f32_bf16 v28, v69, v78, v30                         // 00000030EE88: CC1A401C 1C7A9D45
	s_waitcnt vmcnt(0)                                         // 00000030EE90: BF8903F7
	v_dot2_f32_bf16 v6, v73, v78, v6                           // 00000030EE94: CC1A4006 1C1A9D49
	v_dot2_f32_bf16 v29, v66, v77, v29                         // 00000030EE9C: CC1A401D 1C769B42
	v_dot2_f32_bf16 v7, v56, v26, v7                           // 00000030EEA4: CC1A4007 1C1E3538
	v_dot2_f32_bf16 v8, v59, v5, v8                            // 00000030EEAC: CC1A4008 1C220B3B
	v_dot2_f32_bf16 v28, v70, v77, v28                         // 00000030EEB4: CC1A401C 1C729B46
	v_dot2_f32_bf16 v6, v74, v77, v6                           // 00000030EEBC: CC1A4006 1C1A9B4A
	v_dot2_f32_bf16 v12, v63, v5, v12                          // 00000030EEC4: CC1A400C 1C320B3F
	v_dot2_f32_bf16 v29, v67, v5, v29                          // 00000030EECC: CC1A401D 1C760B43
	v_add_f32_e32 v21, v21, v7                                 // 00000030EED4: 062A0F15
	v_dot2_f32_bf16 v7, v71, v5, v28                           // 00000030EED8: CC1A4007 1C720B47
	v_dot2_f32_bf16 v5, v75, v5, v6                            // 00000030EEE0: CC1A4005 1C1A0B4B
	v_dot2_f32_bf16 v6, v60, v26, v8                           // 00000030EEE8: CC1A4006 1C22353C
	v_dot2_f32_bf16 v8, v64, v26, v12                          // 00000030EEF0: CC1A4008 1C323540
	v_dot2_f32_bf16 v12, v68, v26, v29                         // 00000030EEF8: CC1A400C 1C763544
	v_dot2_f32_bf16 v7, v72, v26, v7                           // 00000030EF00: CC1A4007 1C1E3548
	v_dot2_f32_bf16 v5, v76, v26, v5                           // 00000030EF08: CC1A4005 1C16354C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030EF10: BF870194
	v_dual_add_f32 v25, v25, v6 :: v_dual_add_f32 v24, v24, v8 // 00000030EF14: C9080D19 19181118
	v_dual_add_f32 v23, v23, v12 :: v_dual_add_f32 v22, v22, v7// 00000030EF1C: C9081917 17160F16
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030EF24: BF870003
	v_add_f32_e32 v16, v16, v5                                 // 00000030EF28: 06200B10
	v_mov_b32_e32 v26, v27                                     // 00000030EF2C: 7E34031B
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000030EF30: 917E167E
	s_cbranch_execz 37                                         // 00000030EF34: BFA50025 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1acc>
	v_add_nc_u32_e32 v17, 32, v17                              // 00000030EF38: 4A2222A0
	v_add_nc_u32_e32 v28, 0x200, v11                           // 00000030EF3C: 4A3816FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000030EF44: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v17, v18                          // 00000030EF48: 7C8C2511
	s_and_saveexec_b32 s0, vcc_lo                              // 00000030EF4C: BE80206A
	s_xor_b32 s0, exec_lo, s0                                  // 00000030EF50: 8D00007E
	v_add_nc_u32_e32 v28, 0x200, v11                           // 00000030EF54: 4A3816FF 00000200
	s_or_saveexec_b32 s18, s0                                  // 00000030EF5C: BE922200
	s_waitcnt vmcnt(0)                                         // 00000030EF60: BF8903F7
	v_dual_mov_b32 v27, v26 :: v_dual_mov_b32 v8, v4           // 00000030EF64: CA10011A 1B080104
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 00000030EF6C: CA100101 05060102
	v_mov_b32_e32 v7, v3                                       // 00000030EF74: 7E0E0303
	s_xor_b32 exec_lo, exec_lo, s18                            // 00000030EF78: 8D7E127E
	s_cbranch_execz 65164                                      // 00000030EF7C: BFA5FE8C <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x14b0>
	v_and_b32_e32 v7, -4, v17                                  // 00000030EF80: 360E22C4
	v_ashrrev_i32_e32 v6, 31, v28                              // 00000030EF84: 340C389F
	.long 0xd7000005                                           // 00000030EF88: D7000005
	v_cndmask_b32_e32 v1, v9, v28, vcc_lo                      // 00000030EF8C: 02023909
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030EF90: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000030EF94: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s0                  // 00000030EF98: D5207C06 00020D0A
	.long 0xd700001d                                           // 00000030EFA0: D700001D
	v_cndmask_b32_e32 v1, v19, v7, vcc_lo                      // 00000030EFA4: 02020F13
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030EFA8: BF870001
	v_add_co_ci_u32_e64 v30, null, v20, v8, s0                 // 00000030EFAC: D5207C1E 00021114
	s_clause 0x1                                               // 00000030EFB4: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 00000030EFB8: DC5E0000 057C0005
	global_load_b32 v27, v[29:30], off                         // 00000030EFC0: DC520000 1B7C001D
	s_branch 65145                                             // 00000030EFC8: BFA0FE79 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x14b0>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000030EFCC: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000030EFD0: BF8700C9
	s_or_b32 exec_lo, exec_lo, s20                             // 00000030EFD4: 8C7E147E
	s_waitcnt vmcnt(1)                                         // 00000030EFD8: BF8907F7
	.long 0xd71f0001                                           // 00000030EFDC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000030EFE0: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000030EFE4: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000030EFE8: 3A040290
	v_xor_b32_e32 v8, 8, v1                                    // 00000030EFEC: 3A100288
	v_xor_b32_e32 v17, 4, v1                                   // 00000030EFF0: 3A220284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000030EFF4: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000030EFF8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000030EFFC: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000030F000: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000030F004: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000030F008: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000030F00C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000030F014: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000030F018: 06060715
	ds_bpermute_b32 v5, v2, v24                                // 00000030F01C: DACC0000 05001802
	ds_bpermute_b32 v7, v2, v22                                // 00000030F024: DACC0000 07001602
	ds_bpermute_b32 v4, v2, v25                                // 00000030F02C: DACC0000 04001902
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 00000030F034: 02101101
	ds_bpermute_b32 v6, v2, v23                                // 00000030F038: DACC0000 06001702
	ds_bpermute_b32 v2, v2, v16                                // 00000030F040: DACC0000 02001002
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000030F048: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 00000030F04C: 02222301
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030F050: BF870001
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000030F054: 30222282
	s_waitcnt lgkmcnt(4)                                       // 00000030F058: BF89FC47
	v_add_f32_e32 v5, v24, v5                                  // 00000030F05C: 060A0B18
	s_waitcnt lgkmcnt(3)                                       // 00000030F060: BF89FC37
	v_dual_add_f32 v7, v22, v7 :: v_dual_lshlrev_b32 v8, 2, v8 // 00000030F064: C9220F16 07081082
	s_waitcnt lgkmcnt(2)                                       // 00000030F06C: BF89FC27
	v_add_f32_e32 v4, v25, v4                                  // 00000030F070: 06080919
	ds_bpermute_b32 v9, v8, v3                                 // 00000030F074: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v5                                // 00000030F07C: DACC0000 0B000508
	s_waitcnt lgkmcnt(3)                                       // 00000030F084: BF89FC37
	v_add_f32_e32 v6, v23, v6                                  // 00000030F088: 060C0D17
	s_waitcnt lgkmcnt(2)                                       // 00000030F08C: BF89FC27
	v_add_f32_e32 v2, v16, v2                                  // 00000030F090: 06040510
	ds_bpermute_b32 v10, v8, v4                                // 00000030F094: DACC0000 0A000408
	ds_bpermute_b32 v16, v8, v7                                // 00000030F09C: DACC0000 10000708
	s_waitcnt lgkmcnt(3)                                       // 00000030F0A4: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 00000030F0A8: 06061303
	s_waitcnt lgkmcnt(2)                                       // 00000030F0AC: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 00000030F0B0: 060A1705
	ds_bpermute_b32 v12, v8, v6                                // 00000030F0B4: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 00000030F0BC: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 00000030F0C4: BF89FC27
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v7, v7, v16   // 00000030F0C8: C9081504 04062107
	ds_bpermute_b32 v10, v17, v5                               // 00000030F0D0: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 00000030F0D8: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 00000030F0E0: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 00000030F0E4: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 00000030F0E8: BF89FC27
	v_add_f32_e32 v2, v2, v8                                   // 00000030F0EC: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 00000030F0F0: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v7                               // 00000030F0F8: DACC0000 0C000711
	ds_bpermute_b32 v11, v17, v6                               // 00000030F100: DACC0000 0B000611
	ds_bpermute_b32 v16, v17, v2                               // 00000030F108: DACC0000 10000211
	v_xor_b32_e32 v17, 2, v1                                   // 00000030F110: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 00000030F114: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 00000030F118: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000030F11C: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000030F120: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 00000030F124: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 00000030F128: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 00000030F12C: 30222282
	s_waitcnt lgkmcnt(1)                                       // 00000030F130: BF89FC17
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v6, v6, v11    // 00000030F134: C9081103 03061706
	s_waitcnt lgkmcnt(0)                                       // 00000030F13C: BF89FC07
	v_add_f32_e32 v8, v2, v16                                  // 00000030F140: 06102102
	ds_bpermute_b32 v9, v17, v4                                // 00000030F144: DACC0000 09000411
	v_add_f32_e32 v7, v7, v12                                  // 00000030F14C: 060E1907
	ds_bpermute_b32 v2, v17, v3                                // 00000030F150: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 00000030F158: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 00000030F160: DACC0000 0B000611
	ds_bpermute_b32 v16, v17, v8                               // 00000030F168: DACC0000 10000811
	ds_bpermute_b32 v12, v17, v7                               // 00000030F170: DACC0000 0C000711
	v_xor_b32_e32 v17, 1, v1                                   // 00000030F178: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000030F17C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 00000030F180: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 00000030F184: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 00000030F188: 30220282
	s_waitcnt lgkmcnt(4)                                       // 00000030F18C: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 00000030F190: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 00000030F198: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 00000030F19C: C9081505 04041706
	s_waitcnt lgkmcnt(0)                                       // 00000030F1A4: BF89FC07
	v_add_f32_e32 v3, v7, v12                                  // 00000030F1A8: 06061907
	v_add_f32_e32 v11, v8, v16                                 // 00000030F1AC: 06162108
	ds_bpermute_b32 v6, v17, v1                                // 00000030F1B0: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 00000030F1B8: DACC0000 07000211
	ds_bpermute_b32 v9, v17, v4                                // 00000030F1C0: DACC0000 09000411
	ds_bpermute_b32 v10, v17, v5                               // 00000030F1C8: DACC0000 0A000511
	ds_bpermute_b32 v8, v17, v3                                // 00000030F1D0: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v11                              // 00000030F1D8: DACC0000 0C000B11
	v_cmpx_eq_u32_e32 0, v15                                   // 00000030F1E0: 7D941E80
	s_cbranch_execz 15                                         // 00000030F1E4: BFA5000F <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1d24>
	s_waitcnt lgkmcnt(0)                                       // 00000030F1E8: BF89FC07
	v_dual_add_f32 v11, v11, v12 :: v_dual_add_f32 v4, v4, v9  // 00000030F1EC: C908190B 0B041304
	v_lshl_add_u32 v12, v13, s3, v14                           // 00000030F1F4: D646000C 0438070D
	v_dual_add_f32 v5, v5, v10 :: v_dual_add_f32 v2, v2, v7    // 00000030F1FC: C9081505 05020F02
	v_dual_add_f32 v1, v1, v6 :: v_dual_add_f32 v10, v3, v8    // 00000030F204: C9080D01 010A1103
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030F20C: BF870003
	v_mul_u32_u24_e32 v6, 24, v12                              // 00000030F210: 160C1898
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:24 offset1:25// 00000030F214: D9381918 00040106
	ds_store_b64 v6, v[10:11] offset:208                       // 00000030F21C: D93400D0 00000A06
	s_or_b32 exec_lo, exec_lo, s0                              // 00000030F224: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F228: BF870009
	s_and_b32 s0, s14, exec_lo                                 // 00000030F22C: 8B007E0E
	s_cselect_b32 s0, 6, 24                                    // 00000030F230: 98009886
	s_mov_b32 s10, exec_lo                                     // 00000030F234: BE8A007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000030F238: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 00000030F23C: BC7C0000
	s_barrier                                                  // 00000030F240: BFBD0000
	buffer_gl0_inv                                             // 00000030F244: E0AC0000 00000000
	.long 0xd4cc007e                                           // 00000030F24C: D4CC007E
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000030F250: 02020000
	s_cbranch_execz 417                                        // 00000030F254: BFA501A1 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x23dc>
	s_load_b32 s0, s[6:7], 0x40                                // 00000030F258: F4000003 F8000040
	.long 0xd7050001                                           // 00000030F260: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 00000030F264: 020200FF 000000AB
	.long 0x7f0a3880                                           // 00000030F26C: 7F0A3880
	v_mov_b32_e32 v4, 0                                        // 00000030F270: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000030F274: BF8704B3
	.long 0xd7390005                                           // 00000030F278: D7390005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000030F27C: 0202028A
	s_waitcnt lgkmcnt(0)                                       // 00000030F280: BF89FC07
	s_sub_i32 s8, s2, s0                                       // 00000030F284: 81880002
	s_ashr_i32 s9, s8, 31                                      // 00000030F288: 86099F08
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000030F28C: BF870499
	s_lshl_b64 s[8:9], s[8:9], s15                             // 00000030F290: 84880F08
	.long 0xd7000001                                           // 00000030F294: D7000001
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 00000030F298: 02020A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F29C: BF870091
	v_add_co_ci_u32_e64 v2, null, s9, 0, s0                    // 00000030F2A0: D5207C02 00010009
	v_cmp_gt_i64_e32 vcc_lo, s[4:5], v[1:2]                    // 00000030F2A8: 7CA80204
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000030F2AC: 8B7E6A7E
	s_cbranch_execz 394                                        // 00000030F2B0: BFA5018A <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x23dc>
	.long 0xd7050003                                           // 00000030F2B4: D7050003
	v_cndmask_b32_e32 v0, v5, v134, vcc_lo                     // 00000030F2B8: 02010D05
	v_lshlrev_b32_e32 v5, s3, v5                               // 00000030F2BC: 300A0A03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F2C0: BF870112
	.long 0xd7040003                                           // 00000030F2C4: D7040003
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 00000030F2C8: 02020700
	v_mul_u32_u24_e32 v5, 24, v5                               // 00000030F2CC: 160A0A98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F2D0: BF870092
	v_and_b32_e32 v6, 0xff, v3                                 // 00000030F2D4: 360C06FF 000000FF
	v_lshl_add_u32 v5, v6, 2, v5                               // 00000030F2DC: D6460005 04150506
	ds_load_b32 v6, v5 offset:192                              // 00000030F2E4: D8D800C0 06000005
	v_add_nc_u32_e32 v5, 24, v5                                // 00000030F2EC: 4A0A0A98
	s_add_i32 s1, s1, -1                                       // 00000030F2F0: 8101C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F2F4: BF870009
	s_cmp_eq_u32 s1, 0                                         // 00000030F2F8: BF068001
	s_waitcnt lgkmcnt(0)                                       // 00000030F2FC: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000030F300: 06080D04
	s_cbranch_scc0 65527                                       // 00000030F304: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1de4>
	s_clause 0x1                                               // 00000030F308: BF850001
	s_load_b64 s[8:9], s[6:7], 0x38                            // 00000030F30C: F4040203 F8000038
	s_load_b64 s[2:3], s[6:7], 0x8                             // 00000030F314: F4040083 F8000008
	v_and_b32_e32 v3, 0xff, v3                                 // 00000030F31C: 360606FF 000000FF
	s_mov_b32 s11, -1                                          // 00000030F324: BE8B00C1
	s_mov_b32 s1, 0                                            // 00000030F328: BE810080
	s_mov_b32 s0, 0                                            // 00000030F32C: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000030F330: BF89FC07
	s_cmp_lt_i32 s9, 3                                         // 00000030F334: BF048309
	s_cbranch_scc1 195                                         // 00000030F338: BFA200C3 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2148>
	s_cmp_gt_i32 s9, 3                                         // 00000030F33C: BF028309
	s_cbranch_scc0 73                                          // 00000030F340: BFA10049 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1f68>
	s_cmp_gt_i32 s9, 4                                         // 00000030F344: BF028409
	s_cbranch_scc0 73                                          // 00000030F348: BFA10049 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1f70>
	s_cmp_eq_u32 s9, 5                                         // 00000030F34C: BF068509
	s_mov_b32 s0, -1                                           // 00000030F350: BE8000C1
	s_cbranch_scc0 66                                          // 00000030F354: BFA10042 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1f60>
	v_lshrrev_b32_e32 v5, 23, v2                               // 00000030F358: 320A0497
	s_lshr_b32 s0, s5, 31                                      // 00000030F35C: 85009F05
	s_load_b64 s[6:7], s[6:7], 0x10                            // 00000030F360: F4040183 F8000010
	s_add_u32 s14, s4, s0                                      // 00000030F368: 800E0004
	s_addc_u32 s15, s5, 0                                      // 00000030F36C: 820F8005
	.long 0xd7006a05                                           // 00000030F370: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 00000030F374: 02020B01
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000030F378: 868E810E
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000030F37C: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s3 :: v_dual_and_b32 v11, 0xfffffe00, v5// 00000030F384: CA240003 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s14, v3, 0                     // 00000030F390: D6FE7C05 0202060E
	v_bfe_u32 v15, v4, 16, 1                                   // 00000030F398: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F3A0: BF870093
	.long 0xd7016a08                                           // 00000030F3A4: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000030F3A8: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 00000030F3AC: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F3B4: BF870194
	v_mad_u64_u32 v[6:7], null, s15, v3, v[6:7]                // 00000030F3B8: D6FE7C06 041A060F
	.long 0xd700000d                                           // 00000030F3C0: D700000D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 00000030F3C4: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030F3CC: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 00000030F3D0: 7CA810FF 00000100
	v_mov_b32_e32 v7, s2                                       // 00000030F3D8: 7E0E0202
	v_add_co_ci_u32_e64 v14, null, -1, v9, s0                  // 00000030F3DC: D5207C0E 000212C1
	s_mov_b32 s0, 0                                            // 00000030F3E4: BE800080
	.long 0xd73c0005                                           // 00000030F3E8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000030F3EC: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 00000030F3F0: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s6, v7// 00000030F3F4: CA52110D 08060E06
	v_dual_cndmask_b32 v12, s7, v12 :: v_dual_cndmask_b32 v9, v14, v9// 00000030F3FC: CA521807 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F404: BF870092
	.long 0xd7006a07                                           // 00000030F408: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000030F40C: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 00000030F410: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F418: BF870193
	.long 0xd73c0005                                           // 00000030F41C: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000030F420: 02021081
	.long 0xd7006a07                                           // 00000030F424: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 00000030F428: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000030F42C: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 00000030F430: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 00000030F438: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 00000030F444: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 00000030F448: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030F44C: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 00000030F450: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000030F458: DC960000 007C0905
	s_mov_b32 s6, 0                                            // 00000030F460: BE860080
	s_branch 3                                                 // 00000030F464: BFA00003 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x1f74>
	s_mov_b32 s6, -1                                           // 00000030F468: BE8600C1
	s_branch 54                                                // 00000030F46C: BFA00036 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2048>
	s_mov_b32 s6, -1                                           // 00000030F470: BE8600C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F474: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000030F478: 8B6A067E
	s_cbranch_vccz 49                                          // 00000030F47C: BFA30031 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2044>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 00000030F480: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000030F488: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000030F48C: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000030F490: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F494: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000030F498: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000030F4A0: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F4A4: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000030F4A8: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000030F4B0: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000030F4B4: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000030F4BC: D6FE7C05 02020604
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F4C4: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 00000030F4C8: 1018150B
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000030F4CC: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F4D4: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 00000030F4D8: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 00000030F4E0: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F4E4: BF870113
	.long 0xd73c0005                                           // 00000030F4E8: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000030F4EC: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 00000030F4F0: D613000B 242E1908
	.long 0xd73c0007                                           // 00000030F4F8: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000030F4FC: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030F500: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 00000030F504: D637000A 0432150B
	.long 0xd7006a05                                           // 00000030F50C: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000030F510: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F514: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000030F518: D5207C06 01AA0C03
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000030F520: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F528: BF870093
	.long 0xd7006a05                                           // 00000030F52C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000030F530: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000030F534: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000030F53C: DC6A0000 007C0905
	s_mov_b32 s6, 0                                            // 00000030F544: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F548: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000030F54C: 8B6A067E
	s_cbranch_vccz 60                                          // 00000030F550: BFA3003C <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2144>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000030F554: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F55C: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000030F560: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000030F56C: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F574: BF870091
	v_mul_f32_e32 v5, s8, v5                                   // 00000030F578: 100A0A08
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000030F57C: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000030F584: BF870291
	v_exp_f32_e32 v5, v5                                       // 00000030F588: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 00000030F58C: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F590: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000030F594: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 00000030F59C: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F5A0: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000030F5A4: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 00000030F5AC: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000030F5B0: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000030F5B8: D6FE7C05 02020604
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F5C0: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 00000030F5C4: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 00000030F5C8: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000030F5D0: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 00000030F5D4: 56181507
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000030F5D8: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F5E0: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 00000030F5E4: D6130007 242E1908
	.long 0xd73c0005                                           // 00000030F5EC: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000030F5F0: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000030F5F4: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 00000030F5F8: D637000A 04321507
	.long 0xd73c0007                                           // 00000030F600: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000030F604: 02020282
	.long 0xd7006a05                                           // 00000030F608: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000030F60C: 02020A02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000030F610: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 00000030F614: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000030F61C: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 00000030F624: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000030F628: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F62C: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 00000030F630: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000030F634: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 00000030F63C: DC6A0000 007C0905
	s_mov_b32 s11, 0                                           // 00000030F644: BE8B0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F648: BF870009
	s_and_b32 vcc_lo, exec_lo, s11                             // 00000030F64C: 8B6A0B7E
	s_cbranch_vccz 73                                          // 00000030F650: BFA30049 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2278>
	s_cmp_gt_i32 s9, 1                                         // 00000030F654: BF028109
	s_mov_b32 s1, -1                                           // 00000030F658: BE8100C1
	s_cbranch_scc0 64                                          // 00000030F65C: BFA10040 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2260>
	v_bfe_u32 v5, v4, 16, 1                                    // 00000030F660: D6100005 02052104
	s_mov_b32 s1, 0                                            // 00000030F668: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F66C: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 00000030F670: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000030F67C: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F684: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 00000030F688: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 00000030F690: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F694: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 00000030F698: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 00000030F69C: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 00000030F6A4: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000030F6AC: BF870292
	v_rcp_f32_e32 v9, v7                                       // 00000030F6B0: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 00000030F6B4: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030F6BC: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 00000030F6C0: 56121305
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000030F6C4: D6FE7C05 02020604
	v_mul_f32_e32 v11, v10, v9                                 // 00000030F6CC: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F6D0: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 00000030F6D4: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 00000030F6DC: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030F6E0: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 00000030F6E4: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000030F6EC: D6FE7C06 041A0605
	v_div_fmas_f32 v7, v10, v9, v11                            // 00000030F6F4: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F6FC: BF870112
	.long 0xd73c0005                                           // 00000030F700: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000030F704: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 00000030F708: D6270009 03CA1107
	.long 0xd73c0007                                           // 00000030F710: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000030F714: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F718: BF870193
	.long 0xd7006a05                                           // 00000030F71C: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000030F720: 02020A02
	v_bfe_u32 v10, v9, 16, 1                                   // 00000030F724: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000030F72C: D5207C06 01AA0C03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F734: BF870193
	.long 0xd7006a05                                           // 00000030F738: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000030F73C: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000030F740: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000030F74C: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 00000030F750: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 00000030F758: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000030F760: 916A017E
	s_mov_b32 s1, 0                                            // 00000030F764: BE810080
	s_cbranch_vccnz 3                                          // 00000030F768: BFA40003 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2278>
	s_cmp_lg_u32 s9, 1                                         // 00000030F76C: BF078109
	s_mov_b32 s1, -1                                           // 00000030F770: BE8100C1
	s_cselect_b32 s0, -1, 0                                    // 00000030F774: 980080C1
	v_bfe_u32 v5, v4, 16, 1                                    // 00000030F778: D6100005 02052104
	.long 0xd73c0001                                           // 00000030F780: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000030F784: 02020281
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000030F788: 8B6A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000030F78C: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000030F790: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 00000030F79C: BFA30014 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x22f0>
	v_mad_u64_u32 v[5:6], null, s4, v3, 0                      // 00000030F7A0: D6FE7C05 02020604
	s_mov_b32 s1, 0                                            // 00000030F7A8: BE810080
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 00000030F7AC: D6FE7C06 041A0605
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F7B4: BF870091
	.long 0xd73c0005                                           // 00000030F7B8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000030F7BC: 02020A81
	.long 0xd7006a05                                           // 00000030F7C0: D7006A05
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000030F7C4: 02020A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F7C8: BF870111
	v_add_co_ci_u32_e64 v6, null, s3, v6, vcc_lo               // 00000030F7CC: D5207C06 01AA0C03
	.long 0xd7006a05                                           // 00000030F7D4: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 00000030F7D8: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 00000030F7DC: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 00000030F7E0: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000030F7E8: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000030F7F0: 916A017E
	s_cbranch_vccnz 57                                         // 00000030F7F4: BFA40039 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x23dc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F7F8: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000030F7FC: 360808FF FFFF0000
	v_mul_f32_e32 v7, s8, v4                                   // 00000030F804: 100E0808
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F808: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 00000030F80C: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000030F814: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F818: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 00000030F81C: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 00000030F820: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000030F828: BF870291
	v_rcp_f32_e32 v9, v6                                       // 00000030F82C: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 00000030F830: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000030F838: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 00000030F83C: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 00000030F840: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s4, v3, 0                      // 00000030F848: D6FE7C04 02020604
	v_mul_f32_e32 v11, v10, v9                                 // 00000030F850: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F854: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 00000030F858: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 00000030F860: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000030F864: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 00000030F868: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s5, v3, v[5:6]                 // 00000030F870: D6FE7C05 04160605
	v_div_fmas_f32 v3, v10, v9, v11                            // 00000030F878: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F880: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 00000030F884: D6270006 041E1103
	.long 0xd73c0003                                           // 00000030F88C: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000030F890: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000030F894: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 00000030F898: D6100005 02052106
	.long 0xd7006a03                                           // 00000030F8A0: D7006A03
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000030F8A4: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000030F8A8: BF870191
	v_add_co_ci_u32_e64 v4, null, s3, v4, vcc_lo               // 00000030F8AC: D5207C04 01AA0803
	v_add3_u32 v5, v6, v5, 0x7fff                              // 00000030F8B4: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000030F8C0: BF870093
	.long 0xd7006a01                                           // 00000030F8C4: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000030F8C8: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000030F8CC: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 00000030F8D4: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s10                             // 00000030F8DC: 8C7E0A7E
	s_waitcnt_vscnt null, 0x0                                  // 00000030F8E0: BC7C0000
	s_barrier                                                  // 00000030F8E4: BFBD0000
	buffer_gl0_inv                                             // 00000030F8E8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000030F8F0: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000030F8F4: 7D940080
	s_cbranch_execz 18                                         // 00000030F8F8: BFA50012 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2444>
	s_mov_b32 s0, exec_lo                                      // 00000030F8FC: BE80007E
	buffer_gl1_inv                                             // 00000030F900: E0B00000 00000000
	buffer_gl0_inv                                             // 00000030F908: E0AC0000 00000000
	.long 0xd71f0000                                           // 00000030F910: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 00000030F914: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000030F918: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000030F91C: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000030F920: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 00000030F924: BEFE0001
	s_cbranch_execz 6                                          // 00000030F928: BFA50006 <_ZN7halogen12_GLOBAL__N_111k_hc8_fusedILi6EEEvNS0_5LqGrpEPKtliPKhS4_PtPfPyy+0x2444>
	s_bcnt1_i32_b32 s0, s0                                     // 00000030F92C: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000030F930: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 00000030F934: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 00000030F93C: DD0E0000 000C0001
	s_nop 0                                                    // 00000030F944: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000030F948: BFB60003
	s_endpgm                                                   // 00000030F94C: BFB00000
		...

