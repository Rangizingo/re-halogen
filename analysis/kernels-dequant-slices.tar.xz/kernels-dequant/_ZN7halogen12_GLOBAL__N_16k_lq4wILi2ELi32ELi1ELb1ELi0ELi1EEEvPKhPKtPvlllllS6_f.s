0000000000740b00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000740B00: F4100100 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 000000740B08: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000740B0C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000740B10: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000740B14: 32060085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000740B18: 84808302
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000740B1C: 30020282
	v_dual_mov_b32 v17, s1 :: v_dual_and_b32 v2, 60, v2        // 000000740B20: CA240001 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000740B28: BF870003
	v_or_b32_e32 v16, s0, v3                                   // 000000740B2C: 38200600
	.long 0x7f063880                                           // 000000740B30: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 000000740B34: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000740B38: 30000082
	s_waitcnt lgkmcnt(0)                                       // 000000740B3C: BF89FC07
	s_clause 0x1                                               // 000000740B40: BF850001
	global_load_b32 v1, v1, s[4:5]                             // 000000740B44: DC520000 01040001
	global_load_b32 v2, v2, s[4:5]                             // 000000740B4C: DC520000 02040002
	.long 0xd4540000                                           // 000000740B54: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000740B58: 0202200C
	s_add_u32 s22, s4, s16                                     // 000000740B5C: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000740B60: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000740B64: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000740B68: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000740B6C: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 000000740B70: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 000000740B78: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 000000740B80: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000740B84: 8203800B
	.long 0xd72c0004                                           // 000000740B88: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 000000740B8C: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 000000740B90: D6FE7C0C 02021012
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000740B98: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000740B9C: BF870009
	s_cmpk_lt_i32 s20, 0x101                                   // 000000740BA0: B3940101
	.long 0xd4440002                                           // 000000740BA4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000740BA8: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 000000740BAC: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 000000740BB0: B2940100
	.long 0xd700030e                                           // 000000740BB4: D700030E
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 000000740BB8: 02021816
	s_waitcnt vmcnt(1)                                         // 000000740BBC: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 000000740BC0: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 000000740BC8: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 000000740BCC: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000740BD4: BF8701A2
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000740BD8: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 000000740BE4: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 000000740BE8: 02021212
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000740BEC: D6550002 03FE0D02 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000740BF8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000740BFC: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000740C00: 8B6A127E
	.long 0x7e063981                                           // 000000740C04: 7E063981
	v_add3_u32 v13, v13, v5, v4                                // 000000740C08: D655000D 04120B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000740C10: BF870112
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 000000740C14: D6570001 040E04FF FFFF0000
	v_add_co_ci_u32_e64 v15, null, s23, v13, s3                // 000000740C20: D5207C0F 000E1A17
	ds_store_b32 v0, v1                                        // 000000740C28: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000740C30: BF89FC07
	s_barrier                                                  // 000000740C34: BFBD0000
	buffer_gl0_inv                                             // 000000740C38: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000740C40: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000740C44: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000740C4C: BE832002
	s_cbranch_execz 10                                         // 000000740C50: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x17c>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000740C54: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740C58: BF870091
	.long 0xd7006a02                                           // 000000740C5C: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 000000740C60: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000740C64: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000740C6C: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000740C74: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000740C78: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000740C7C: 8C7E037E
	v_or_b32_e32 v2, 32, v23                                   // 000000740C80: 38042EA0
	s_mov_b32 s2, exec_lo                                      // 000000740C84: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740C88: BF870001
	.long 0xd4c4007e                                           // 000000740C8C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000740C90: 02020414
	s_cbranch_execz 10                                         // 000000740C94: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1c0>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000740C98: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740C9C: BF870091
	.long 0xd7006a01                                           // 000000740CA0: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 000000740CA4: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 000000740CA8: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 000000740CB0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000740CB8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000740CBC: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740CC0: 8C7E027E
	v_or_b32_e32 v4, 64, v23                                   // 000000740CC4: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000740CC8: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000740CD0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000740CD4: BF870002
	.long 0xd4c4007e                                           // 000000740CD8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000740CDC: 02020814
	s_cbranch_execz 10                                         // 000000740CE0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x20c>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000740CE4: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740CE8: BF870091
	.long 0xd7006a04                                           // 000000740CEC: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 000000740CF0: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 000000740CF4: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 000000740CFC: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000740D04: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000740D08: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740D0C: 8C7E027E
	v_or_b32_e32 v4, 0x60, v23                                 // 000000740D10: 38082EFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000740D18: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740D1C: BF870001
	.long 0xd4c4007e                                           // 000000740D20: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000740D24: 02020814
	s_cbranch_execz 10                                         // 000000740D28: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x254>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000740D2C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740D30: BF870091
	.long 0xd7006a03                                           // 000000740D34: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 000000740D38: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000740D3C: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 000000740D44: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000740D4C: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000740D50: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740D54: 8C7E027E
	v_or_b32_e32 v6, 0x80, v23                                 // 000000740D58: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000740D60: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000740D68: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000740D6C: BF870002
	.long 0xd4c4007e                                           // 000000740D70: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000740D74: 02020C14
	s_cbranch_execz 10                                         // 000000740D78: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2a4>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000740D7C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740D80: BF870091
	.long 0xd7006a06                                           // 000000740D84: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 000000740D88: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000740D8C: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000740D94: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000740D9C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000740DA0: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740DA4: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v23                                 // 000000740DA8: 380C2EFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 000000740DB0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740DB4: BF870001
	.long 0xd4c4007e                                           // 000000740DB8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000740DBC: 02020C14
	s_cbranch_execz 10                                         // 000000740DC0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2ec>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000740DC4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740DC8: BF870091
	.long 0xd7006a05                                           // 000000740DCC: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 000000740DD0: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 000000740DD4: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 000000740DDC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000740DE4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000740DE8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740DEC: 8C7E027E
	v_or_b32_e32 v10, 0xc0, v23                                // 000000740DF0: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000740DF8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000740E00: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000740E04: BF870002
	.long 0xd4c4007e                                           // 000000740E08: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000740E0C: 02021414
	s_cbranch_execz 10                                         // 000000740E10: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x33c>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000740E14: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740E18: BF870091
	.long 0xd7006a0a                                           // 000000740E1C: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000740E20: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000740E24: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000740E2C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000740E34: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000740E38: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740E3C: 8C7E027E
	v_or_b32_e32 v10, 0xe0, v23                                // 000000740E40: 38142EFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000740E48: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740E4C: BF870001
	.long 0xd4c4007e                                           // 000000740E50: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 000000740E54: 02021414
	s_cbranch_execz 10                                         // 000000740E58: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x384>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000740E5C: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740E60: BF870091
	.long 0xd7006a0a                                           // 000000740E64: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 000000740E68: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000740E6C: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000740E74: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000740E7C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000740E80: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000740E84: 8C7E027E
	s_branch 9                                                 // 000000740E88: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b0>
	v_mov_b32_e32 v0, 0                                        // 000000740E8C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740E90: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000740E94: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000740E98: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000740E9C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000740EA0: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000740EA4: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000740EA8: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000740EAC: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000740EB0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000740EB4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000740EB8: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 000000740EBC: 7E340280
	s_add_u32 s14, s10, s14                                    // 000000740EC0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000740EC4: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 000000740EC8: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000740ED0: 868E810E
	v_mov_b32_e32 v27, 0                                       // 000000740ED4: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s14, s[2:3]              // 000000740ED8: D6FE7C12 00081D08
	.long 0xd72c000b                                           // 000000740EE0: D72C000B
	v_cndmask_b32_e32 v0, v8, v15, vcc_lo                      // 000000740EE4: 02001F08
	.long 0xd72c0014                                           // 000000740EE8: D72C0014
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 000000740EEC: 02001D09
	.long 0xd4440002                                           // 000000740EF0: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000740EF4: 02022E14
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 000000740EF8: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 000000740F00: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000740F04: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 000000740F08: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000740F10: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 000000740F14: BE832002
	s_cbranch_execz 21                                         // 000000740F18: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 000000740F1C: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740F24: BF870091
	.long 0xd7006a08                                           // 000000740F28: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 000000740F2C: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000740F30: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000740F38: 916A127E
	global_load_b128 v[8:11], v[8:9], off                      // 000000740F3C: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000740F44: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_lshlrev_b32_e32 v19, 1, v23                              // 000000740F48: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000740F4C: BF870091
	.long 0xd7006a0e                                           // 000000740F50: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000740F54: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 000000740F58: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000740F60: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 000000740F68: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 000000740F6C: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000740F70: 8C7E037E
	v_mov_b32_e32 v28, 0                                       // 000000740F74: 7E380280
	s_and_saveexec_b32 s3, s2                                  // 000000740F78: BE832002
	s_cbranch_execz 305                                        // 000000740F7C: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x944>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 000000740F80: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 000000740F88: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 000000740F8C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000740F90: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 000000740F94: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000740F9C: CA220080 14122E85
	.long 0xd7006a0c                                           // 000000740FA4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 000000740FA8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000740FAC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 000000740FB0: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 000000740FB8: D656001D 03FD0917 00000200
	.long 0xd7006a0c                                           // 000000740FC4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 000000740FC8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000740FCC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 000000740FD0: D5207C0D 01AA1A05
	v_mov_b32_e32 v30, v23                                     // 000000740FD8: 7E3C0317
	.long 0xd7006a15                                           // 000000740FDC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 000000740FE0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000740FE4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 000000740FE8: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 000000740FF0: 7E380314
	v_mov_b32_e32 v26, v20                                     // 000000740FF4: 7E340314
	s_mov_b32 s14, 0                                           // 000000740FF8: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000740FFC: 8484810A
	s_branch 243                                               // 000000741000: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x8d0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000741004: 8C7E0A7E
	.long 0xd73c0020                                           // 000000741008: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000074100C: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 000000741010: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 000000741018: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 00000074101C: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000741020: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 000000741024: 368612FF 000000FF
	.long 0xd7006a38                                           // 00000074102C: D7006A38
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 000000741030: 02024006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000741034: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s7, v33, vcc_lo             // 000000741038: D5207C39 01AA4207
	v_lshlrev_b32_e32 v64, 2, v64                              // 000000741040: 30808082
	.long 0xd7006a3c                                           // 000000741044: D7006A3C
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000741048: 02000938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074104C: BF870001
	v_add_co_ci_u32_e64 v61, null, s5, v57, vcc_lo             // 000000741050: D5207C3D 01AA7205
	v_and_b32_e32 v65, 0x3fc, v65                              // 000000741058: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 000000741060: D8D80000 40000040
	s_clause 0x7                                               // 000000741068: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 00000074106C: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 000000741074: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 00000074107C: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 000000741084: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 00000074108C: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 000000741094: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 00000074109C: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007410A4: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000007410AC: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000007410B4: 32881286
	ds_load_b32 v65, v65                                       // 0000007410B8: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000007410C0: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007410C4: 32121296
	ds_load_b32 v66, v66                                       // 0000007410C8: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007410D0: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000007410D8: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007410DC: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000007410E4: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007410EC: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007410F4: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000007410FC: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 000000741104: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 00000074110C: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 000000741114: D8D80000 09000009
	.long 0xd7006a15                                           // 00000074111C: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 000000741120: 02018115
	v_add_nc_u32_e32 v29, 0x200, v29                           // 000000741124: 4A3A3AFF 00000200
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 00000074112C: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 000000741134: 8B02027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000741138: BF870009
	s_or_b32 s14, s2, s14                                      // 00000074113C: 8C0E0E02
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000741140: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 000000741144: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 00000074114C: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 000000741150: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 000000741158: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000741160: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 000000741164: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 00000074116C: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 000000741170: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 000000741178: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 00000074117C: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000741180: 32141496
	s_waitcnt lgkmcnt(5)                                       // 000000741184: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 000000741188: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 000000741190: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 000000741198: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000007411A0: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000007411A4: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000007411A8: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000007411AC: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000007411B4: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000007411BC: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000007411C4: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007411CC: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007411D0: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000007411D4: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000007411DC: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000007411E0: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007411E8: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007411F0: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000007411F4: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007411FC: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 000000741200: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 000000741208: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 000000741210: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000741218: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 000000741220: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 000000741228: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 000000741230: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 000000741234: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s1                         // 00000074123C: D501002A 0006011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 000000741244: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 000000741248: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 000000741250: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 000000741254: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 000000741258: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 000000741260: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 000000741268: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 000000741270: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 000000741278: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 000000741280: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 000000741288: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 000000741290: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s1                          // 000000741298: D5010025 00060D05
	v_cndmask_b32_e64 v38, v6, v7, s1                          // 0000007412A0: D5010026 00060F06
	v_cndmask_b32_e64 v34, v2, v3, s1                          // 0000007412A8: D5010022 00060702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007412B0: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000007412B4: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000007412BC: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000007412C0: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s1                          // 0000007412C8: D5010021 00060501
	v_cndmask_b32_e64 v32, v0, v1, s1                          // 0000007412D0: D5010020 00060300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000007412D8: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007412E0: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000007412E4: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s1                          // 0000007412EC: D5010023 00060903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000007412F4: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007412FC: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 000000741300: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s1                          // 000000741308: D5010024 00060B04
	s_waitcnt lgkmcnt(4)                                       // 000000741310: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 000000741314: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000074131C: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 000000741320: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 000000741328: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000074132C: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 000000741330: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 000000741338: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 00000074133C: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 000000741344: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 00000074134C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 000000741350: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 000000741354: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 00000074135C: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 000000741364: 7E4E0307
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000741368: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 000000741370: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 000000741374: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 00000074137C: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 000000741384: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000741388: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 00000074138C: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 000000741394: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000074139C: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000007413A0: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 0000007413A4: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 0000007413A8: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007413B0: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007413B8: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007413C0: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007413C8: 917E0E7E
	s_cbranch_execz 28                                         // 0000007413CC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x940>
	s_waitcnt vmcnt(0)                                         // 0000007413D0: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 0000007413D4: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000007413DC: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000007413E4: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007413E8: BF870003
	.long 0xd4430002                                           // 0000007413EC: D4430002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000007413F0: 02023C14
	s_mov_b32 s10, exec_lo                                     // 0000007413F4: BE8A007E
	.long 0xd4c4007e                                           // 0000007413F8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000007413FC: 02023C14
	s_cbranch_execz 65280                                      // 000000741400: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	.long 0xd7006a0c                                           // 000000741404: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 000000741408: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000074140C: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000741410: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000741418: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 00000074141C: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 000000741420: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 000000741428: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	global_load_d16_b16 v31, v[21:22], off                     // 00000074142C: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 000000741434: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 000000741438: 7E3E171F
	s_branch 65265                                             // 00000074143C: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000741440: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000741444: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000741448: 8C7E037E
	.long 0xd71f0000                                           // 00000074144C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000741450: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000741454: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 000000741458: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 00000074145C: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000741460: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000741464: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000741468: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000074146C: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000741470: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000741474: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 000000741478: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000074147C: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 000000741480: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 000000741488: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 00000074148C: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 000000741494: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 00000074149C: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 0000007414A4: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 0000007414A8: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000007414AC: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007414B0: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000007414B4: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007414BC: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007414C0: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007414C4: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000007414C8: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007414CC: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007414D0: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007414D8: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000007414E0: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007414E4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007414E8: 7C980AA0
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007414EC: 020A0B00
	s_waitcnt lgkmcnt(1)                                       // 0000007414F0: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 0000007414F4: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 0000007414FC: BF89FC07
	v_add_f32_e32 v3, v1, v4                                   // 000000741500: 06060901
	ds_bpermute_b32 v1, v5, v2                                 // 000000741504: DACC0000 01000205
	ds_bpermute_b32 v4, v5, v3                                 // 00000074150C: DACC0000 04000305
	v_xor_b32_e32 v5, 1, v0                                    // 000000741514: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000741518: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 00000074151C: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 000000741520: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000741524: 7C942E80
	v_lshlrev_b32_e32 v5, 2, v0                                // 000000741528: 300A0082
	s_waitcnt lgkmcnt(1)                                       // 00000074152C: BF89FC17
	v_add_f32_e32 v1, v2, v1                                   // 000000741530: 06020302
	s_and_b32 s0, vcc_lo, s0                                   // 000000741534: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 000000741538: BF89FC07
	v_add_f32_e32 v0, v3, v4                                   // 00000074153C: 06000903
	ds_bpermute_b32 v3, v5, v1                                 // 000000741540: DACC0000 03000105
	ds_bpermute_b32 v2, v5, v0                                 // 000000741548: DACC0000 02000005
	s_and_saveexec_b32 s1, s0                                  // 000000741550: BE812000
	s_cbranch_execz 21                                         // 000000741554: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xaac>
	.long 0xd73c0004                                           // 000000741558: D73C0004
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000074155C: 02022082
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000741560: 8480820C
	s_waitcnt lgkmcnt(0)                                       // 000000741564: BF89FC07
	v_dual_add_f32 v1, v1, v3 :: v_dual_add_f32 v0, v0, v2     // 000000741568: C9080701 01000500
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000741570: BF870092
	.long 0xd7006a04                                           // 000000741574: D7006A04
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000741578: 02020808
	v_add_co_ci_u32_e64 v5, null, s9, v5, vcc_lo               // 00000074157C: D5207C05 01AA0A09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000741584: BF870092
	.long 0xd7006a06                                           // 000000741588: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000074158C: 02000104
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 000000741590: D5207C07 01AA0A01
	s_clause 0x1                                               // 000000741598: BF850001
	global_store_b32 v[4:5], v1, off                           // 00000074159C: DC6A0000 007C0104
	global_store_b32 v[6:7], v0, off                           // 0000007415A4: DC6A0000 007C0006
	s_endpgm                                                   // 0000007415AC: BFB00000
		...

