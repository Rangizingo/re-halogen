0000000000d81500 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[8:15], s[0:1], null                          // 000000D81500: F40C0200 F8000000
	s_mov_b32 s3, 0                                            // 000000D81508: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D8150C: BF870009
	s_lshl_b64 s[4:5], s[2:3], 4                               // 000000D81510: 84848402
	s_waitcnt lgkmcnt(0)                                       // 000000D81514: BF89FC07
	s_add_u32 s4, s12, s4                                      // 000000D81518: 8004040C
	s_addc_u32 s5, s13, s5                                     // 000000D8151C: 8205050D
	s_load_b128 s[16:19], s[4:5], null                         // 000000D81520: F4080402 F8000000
	s_load_b64 s[6:7], s[0:1], 0x20                            // 000000D81528: F4040180 F8000020
	s_waitcnt lgkmcnt(0)                                       // 000000D81530: BF89FC07
	s_sub_i32 s0, s19, s18                                     // 000000D81534: 81801213
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000D81538: BF870499
	s_min_i32 s19, s0, 64                                      // 000000D8153C: 8913C000
	s_add_i32 s0, s19, 15                                      // 000000D81540: 81008F13
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D81544: BF870009
	s_ashr_i32 s20, s0, 4                                      // 000000D81548: 86148400
	s_mov_b32 s0, -1                                           // 000000D8154C: BE8000C1
	s_cmp_lt_i32 s20, 3                                        // 000000D81550: BF048314
	s_cbranch_scc1 6732                                        // 000000D81554: BFA21A4C <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6988>
	v_or_b32_e32 v55, 0x200, v0                                // 000000D81558: 386E00FF 00000200
	.long 0xd44c0000                                           // 000000D81560: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000D81564: 020200FF 00000300
	s_cmp_gt_i32 s20, 3                                        // 000000D8156C: BF028314
	s_mov_b32 s1, -1                                           // 000000D81570: BE8100C1
	s_cbranch_scc0 3713                                        // 000000D81574: BFA10E81 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3a7c>
	v_lshrrev_b32_e32 v19, 4, v0                               // 000000D81578: 32260084
	v_or_b32_e32 v1, 0x100, v0                                 // 000000D8157C: 380200FF 00000100
	s_add_i32 s1, s19, -1                                      // 000000D81584: 8101C113
	v_or_b32_e32 v4, 0x300, v0                                 // 000000D81588: 380800FF 00000300
	v_lshlrev_b32_e32 v2, 3, v0                                // 000000D81590: 30040083
	v_min_i32_e32 v3, s1, v19                                  // 000000D81594: 22062601
	v_lshrrev_b32_e32 v9, 4, v1                                // 000000D81598: 32120284
	v_lshrrev_b32_e32 v1, 4, v55                               // 000000D8159C: 32026E84
	v_lshrrev_b32_e32 v4, 4, v4                                // 000000D815A0: 32080884
	v_and_b32_e32 v56, 0x78, v2                                // 000000D815A4: 367004FF 00000078
	v_add_nc_u32_e32 v2, s18, v3                               // 000000D815AC: 4A040612
	v_min_i32_e32 v3, s1, v9                                   // 000000D815B0: 22061201
	v_min_i32_e32 v5, s1, v1                                   // 000000D815B4: 220A0201
	v_min_i32_e32 v7, s1, v4                                   // 000000D815B8: 220E0801
	v_lshlrev_b32_e32 v10, 1, v56                              // 000000D815BC: 30147081
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000D815C0: D6FF7C01 020204FF 00000500
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D815CC: 4A060612
	v_add_nc_u32_e32 v5, s18, v5                               // 000000D815D0: 4A0A0A12
	v_add_nc_u32_e32 v7, s18, v7                               // 000000D815D4: 4A0E0E12
	.long 0xd7000111                                           // 000000D815D8: D7000111
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000D815DC: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D815E0: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D815E4: D6FF7C03 020206FF 00000500
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000D815F0: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v18, null, s11, 0, s1                  // 000000D815FC: D5207C12 0005000B
	v_mad_i64_i32 v[7:8], null, 0x500, v7, 0                   // 000000D81604: D6FF7C07 02020EFF 00000500
	.long 0xd7006a0b                                           // 000000D81610: D7006A0B
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000D81614: 02020311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81618: BF8700A1
	v_add_co_ci_u32_e64 v12, null, v18, v2, vcc_lo             // 000000D8161C: D5207C0C 01AA0512
	.long 0xd7006a0d                                           // 000000D81624: D7006A0D
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000D81628: 02020711
	v_add_co_ci_u32_e64 v14, null, v18, v4, vcc_lo             // 000000D8162C: D5207C0E 01AA0912
	.long 0xd7006a0f                                           // 000000D81634: D7006A0F
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000D81638: 02020B11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8163C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v18, v6, vcc_lo             // 000000D81640: D5207C10 01AA0D12
	.long 0xd7006a11                                           // 000000D81648: D7006A11
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000D8164C: 02020F11
	v_add_co_ci_u32_e64 v18, null, v18, v8, vcc_lo             // 000000D81650: D5207C12 01AA1112
	s_clause 0x3                                               // 000000D81658: BF850003
	global_load_b128 v[33:36], v[11:12], off                   // 000000D8165C: DC5E0000 217C000B
	global_load_b128 v[37:40], v[13:14], off                   // 000000D81664: DC5E0000 257C000D
	global_load_b128 v[41:44], v[15:16], off                   // 000000D8166C: DC5E0000 297C000F
	global_load_b128 v[45:48], v[17:18], off                   // 000000D81674: DC5E0000 2D7C0011
	v_mul_u32_u24_e32 v59, 0x88, v19                           // 000000D8167C: 167626FF 00000088
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D81684: BF870001
	v_lshl_add_u32 v11, v59, 1, v10                            // 000000D81688: D646000B 0429033B
	s_waitcnt vmcnt(3)                                         // 000000D81690: BF890FF7
	ds_store_b128 v11, v[33:36]                                // 000000D81694: DB7C0000 0000210B
	s_and_saveexec_b32 s1, s0                                  // 000000D8169C: BE812000
	s_cbranch_execnz 10505                                     // 000000D816A0: BFA62909 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa5c8>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D816A4: 8C7E017E
	.long 0xd44c0001                                           // 000000D816A8: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D816AC: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D816B4: BE822001
	s_cbranch_execnz 10511                                     // 000000D816B8: BFA6290F <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa5f8>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D816BC: 8C7E027E
	.long 0xd44c0002                                           // 000000D816C0: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D816C4: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000D816CC: BE832002
	s_cbranch_execz 3                                          // 000000D816D0: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	s_waitcnt vmcnt(0)                                         // 000000D816D4: BF8903F7
	ds_store_b128 v11, v[45:48] offset:13056                   // 000000D816D8: DB7C3300 00002D0B
	s_or_b32 exec_lo, exec_lo, s3                              // 000000D816E0: 8C7E037E
	s_mul_i32 s5, s16, 0xc8000                                 // 000000D816E4: 9605FF10 000C8000
	s_mul_i32 s12, s17, 0xa000                                 // 000000D816EC: 960CFF11 0000A000
	s_mul_hi_i32 s4, s16, 0xc8000                              // 000000D816F4: 9704FF10 000C8000
	s_add_u32 s5, s5, s12                                      // 000000D816FC: 80050C05
	s_mul_hi_i32 s12, s17, 0xa000                              // 000000D81700: 970CFF11 0000A000
	.long 0xd7006a07                                           // 000000D81708: D7006A07
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000D8170C: 02020E0A
	s_addc_u32 s4, s4, s12                                     // 000000D81710: 82040C04
	v_and_b32_e32 v57, 31, v0                                  // 000000D81714: 3672009F
	v_mov_b32_e32 v25, 0                                       // 000000D81718: 7E320280
	v_add_co_ci_u32_e64 v8, null, s11, v8, vcc_lo              // 000000D8171C: D5207C08 01AA100B
	.long 0xd7006a42                                           // 000000D81724: D7006A42
	v_cndmask_b32_e32 v1, 0x100, v7, vcc_lo                    // 000000D81728: 02020EFF 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81730: BF870194
	v_lshlrev_b32_e32 v10, 5, v57                              // 000000D81734: 30147285
	v_add_co_ci_u32_e64 v67, null, 0, v8, vcc_lo               // 000000D81738: D5207C43 01AA1080
	.long 0xd7006a05                                           // 000000D81740: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000D81744: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D81748: BF870233
	v_add_nc_u32_e32 v11, 0x3f0, v10                           // 000000D8174C: 4A1614FF 000003F0
	v_mov_b32_e32 v29, v25                                     // 000000D81754: 7E3A0319
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000D81758: D5207C06 01AA0C0B
	.long 0xd7006a44                                           // 000000D81760: D7006A44
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000D81764: 02020AFF 00000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8176C: BF870224
	v_and_b32_e32 v12, 0x7e0, v11                              // 000000D81770: 361816FF 000007E0
	v_lshrrev_b32_e32 v8, 3, v11                               // 000000D81778: 32101683
	v_add_co_ci_u32_e64 v69, null, 0, v6, vcc_lo               // 000000D8177C: D5207C45 01AA0C80
	v_mov_b32_e32 v19, v25                                     // 000000D81784: 7E260319
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D81788: BF870244
	v_sub_nc_u32_e32 v10, v12, v10                             // 000000D8178C: 4C14150C
	v_mul_u32_u24_e32 v60, 0x110, v9                           // 000000D81790: 167812FF 00000110
	v_dual_mov_b32 v27, v25 :: v_dual_and_b32 v58, 15, v0      // 000000D81798: CA240119 1B3A008F
	v_mov_b32_e32 v26, v25                                     // 000000D817A0: 7E340319
	v_dual_mov_b32 v31, v25 :: v_dual_add_nc_u32 v62, 0xfffffc3c, v10// 000000D817A4: CA200119 1F3E14FF FFFFFC3C
	v_dual_mov_b32 v30, v25 :: v_dual_add_nc_u32 v63, 0xfffffc38, v10// 000000D817B0: CA200119 1E3E14FF FFFFFC38
	v_dual_mov_b32 v17, v25 :: v_dual_add_nc_u32 v64, 0xfffffc34, v10// 000000D817BC: CA200119 114014FF FFFFFC34
	v_dual_mov_b32 v32, v25 :: v_dual_add_nc_u32 v65, 0xfffffc30, v10// 000000D817C8: CA200119 204014FF FFFFFC30
	v_lshlrev_b32_e32 v10, 2, v0                               // 000000D817D4: 30140082
	v_mul_u32_u24_e32 v12, 0x88, v58                           // 000000D817D8: 161874FF 00000088
	v_dual_mov_b32 v18, v25 :: v_dual_lshlrev_b32 v61, 4, v58  // 000000D817E0: CA220119 123C7484
	v_mov_b32_e32 v20, v25                                     // 000000D817E8: 7E280319
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D817EC: BF870244
	v_and_or_b32 v7, 0x380, v10, s5                            // 000000D817F0: D6570007 001614FF 00000380
	v_mov_b32_e32 v10, s4                                      // 000000D817FC: 7E140204
	.long 0xd44c0003                                           // 000000D81800: D44C0003
	v_cndmask_b32_e32 v1, 16, v57, vcc_lo                      // 000000D81804: 02027290
	v_dual_mov_b32 v21, v25 :: v_dual_lshlrev_b32 v80, 1, v12  // 000000D81808: CA220119 15501881
	v_and_or_b32 v8, 0x7c, v8, v7                              // 000000D81810: D6570008 041E10FF 0000007C
	v_mov_b32_e32 v22, v25                                     // 000000D8181C: 7E2C0319
	v_mov_b32_e32 v23, v25                                     // 000000D81820: 7E2E0319
	v_mov_b32_e32 v24, v25                                     // 000000D81824: 7E300319
	v_mov_b32_e32 v12, v25                                     // 000000D81828: 7E180319
	.long 0xd7006a46                                           // 000000D8182C: D7006A46
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000D81830: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81834: BF8700A1
	v_add_co_ci_u32_e64 v71, null, s9, v10, vcc_lo             // 000000D81838: D5207C47 01AA1409
	.long 0xd7006a03                                           // 000000D81840: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000D81844: 0202060A
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000D81848: D5207C04 01AA080B
	.long 0xd7006a01                                           // 000000D81850: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000D81854: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D81858: BF870211
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 000000D8185C: D5207C02 01AA040B
	.long 0xd7006a48                                           // 000000D81864: D7006A48
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000D81868: 020206FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D81870: BF870211
	v_add_co_ci_u32_e64 v73, null, 0, v4, vcc_lo               // 000000D81874: D5207C49 01AA0880
	.long 0xd7006a4a                                           // 000000D8187C: D7006A4A
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 000000D81880: 020202FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D81888: BF870001
	v_add_co_ci_u32_e64 v75, null, 0, v2, vcc_lo               // 000000D8188C: D5207C4B 01AA0480
	v_mov_b32_e32 v2, s4                                       // 000000D81894: 7E040204
	v_lshrrev_b32_e32 v9, 5, v11                               // 000000D81898: 32121685
	v_mov_b32_e32 v4, s4                                       // 000000D8189C: 7E080204
	v_mov_b32_e32 v28, v25                                     // 000000D818A0: 7E380319
	v_lshl_or_b32 v3, v57, 2, v7                               // 000000D818A4: D6560003 041D0539
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D818AC: BF870004
	v_dual_mov_b32 v10, v25 :: v_dual_add_nc_u32 v9, 1, v9     // 000000D818B0: CA200119 0A081281
	v_mov_b32_e32 v11, v25                                     // 000000D818B8: 7E160319
	v_mov_b32_e32 v13, v25                                     // 000000D818BC: 7E1A0319
	v_mov_b32_e32 v14, v25                                     // 000000D818C0: 7E1C0319
	v_mov_b32_e32 v15, v25                                     // 000000D818C4: 7E1E0319
	v_dual_mov_b32 v16, v25 :: v_dual_and_b32 v9, 31, v9       // 000000D818C8: CA240119 1008129F
	v_mov_b32_e32 v5, v25                                      // 000000D818D0: 7E0A0319
	v_mov_b32_e32 v6, v25                                      // 000000D818D4: 7E0C0319
	v_mov_b32_e32 v8, v25                                      // 000000D818D8: 7E100319
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D818DC: BF870004
	v_lshl_or_b32 v1, v9, 2, v7                                // 000000D818E0: D6560001 041D0509
	v_mov_b32_e32 v9, v25                                      // 000000D818E8: 7E120319
	v_mov_b32_e32 v7, v25                                      // 000000D818EC: 7E0E0319
	s_mov_b32 s12, 0                                           // 000000D818F0: BE8C0080
	s_mov_b64 s[4:5], 0                                        // 000000D818F4: BE840180
	.long 0xd7006a4c                                           // 000000D818F8: D7006A4C
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D818FC: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81900: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s9, v2, vcc_lo              // 000000D81904: D5207C4D 01AA0409
	.long 0xd7006a4e                                           // 000000D8190C: D7006A4E
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D81910: 02020608
	v_add_co_ci_u32_e64 v79, null, s9, v4, vcc_lo              // 000000D81914: D5207C4F 01AA0809
	v_mov_b32_e32 v1, v25                                      // 000000D8191C: 7E020319
	v_mov_b32_e32 v2, v25                                      // 000000D81920: 7E040319
	v_mov_b32_e32 v3, v25                                      // 000000D81924: 7E060319
	v_mov_b32_e32 v4, v25                                      // 000000D81928: 7E080319
	s_movk_i32 s13, 0x1eee                                     // 000000D8192C: B00D1EEE
	s_mov_b32 s21, 0x76543210                                  // 000000D81930: BE9500FF 76543210
	s_movk_i32 s22, 0x60                                       // 000000D81938: B0160060
	s_movk_i32 s23, 0x80                                       // 000000D8193C: B0170080
	s_movk_i32 s24, 0xa0                                       // 000000D81940: B01800A0
	s_movk_i32 s25, 0xc0                                       // 000000D81944: B01900C0
	s_movk_i32 s26, 0xe0                                       // 000000D81948: B01A00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D8194C: BF890007
	s_barrier                                                  // 000000D81950: BFBD0000
	buffer_gl0_inv                                             // 000000D81954: E0AC0000 00000000
	s_branch 33                                                // 000000D8195C: BFA00021 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x4e4>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D81960: 8C7E1B7E
	.long 0xd7006a42                                           // 000000D81964: D7006A42
	v_cndmask_b32_e32 v1, 0x100, v66, vcc_lo                   // 000000D81968: 020284FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81970: BF8700A1
	v_add_co_ci_u32_e64 v67, null, 0, v67, vcc_lo              // 000000D81974: D5207C43 01AA8680
	.long 0xd7006a44                                           // 000000D8197C: D7006A44
	v_cndmask_b32_e32 v1, 0x100, v68, vcc_lo                   // 000000D81980: 020288FF 00000100
	v_add_co_ci_u32_e64 v69, null, 0, v69, vcc_lo              // 000000D81988: D5207C45 01AA8A80
	.long 0xd7006a48                                           // 000000D81990: D7006A48
	v_cndmask_b32_e32 v1, 0x100, v72, vcc_lo                   // 000000D81994: 020290FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8199C: BF8700A1
	v_add_co_ci_u32_e64 v73, null, 0, v73, vcc_lo              // 000000D819A0: D5207C49 01AA9280
	.long 0xd7006a4a                                           // 000000D819A8: D7006A4A
	v_cndmask_b32_e32 v1, 0x100, v74, vcc_lo                   // 000000D819AC: 020294FF 00000100
	v_add_co_ci_u32_e64 v75, null, 0, v75, vcc_lo              // 000000D819B4: D5207C4B 01AA9680
	s_add_u32 s4, s4, 0x2000                                   // 000000D819BC: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D819C4: 82058005
	s_add_i32 s12, s12, 1                                      // 000000D819C8: 810C810C
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D819CC: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D819D0: BF89FC07
	s_barrier                                                  // 000000D819D4: BFBD0000
	buffer_gl0_inv                                             // 000000D819D8: E0AC0000 00000000
	s_cbranch_scc1 1656                                        // 000000D819E0: BFA20678 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1ec4>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D819E4: B5048000
	s_cselect_b32 s27, -1, 0                                   // 000000D819E8: 981B80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D819EC: B4848000
	s_cbranch_scc1 26                                          // 000000D819F0: BFA2001A <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x55c>
	.long 0xd7006a21                                           // 000000D819F4: D7006A21
	v_cndmask_b32_e32 v1, v74, v61, vcc_lo                     // 000000D819F8: 02027B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D819FC: BF8700A1
	v_add_co_ci_u32_e64 v34, null, 0, v75, vcc_lo              // 000000D81A00: D5207C22 01AA9680
	.long 0xd7006a25                                           // 000000D81A08: D7006A25
	v_cndmask_b32_e32 v1, v72, v61, vcc_lo                     // 000000D81A0C: 02027B48
	v_add_co_ci_u32_e64 v38, null, 0, v73, vcc_lo              // 000000D81A10: D5207C26 01AA9280
	.long 0xd7006a29                                           // 000000D81A18: D7006A29
	v_cndmask_b32_e32 v1, v68, v61, vcc_lo                     // 000000D81A1C: 02027B44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81A20: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v69, vcc_lo              // 000000D81A24: D5207C2A 01AA8A80
	.long 0xd7006a2d                                           // 000000D81A2C: D7006A2D
	v_cndmask_b32_e32 v1, v66, v61, vcc_lo                     // 000000D81A30: 02027B42
	v_add_co_ci_u32_e64 v46, null, 0, v67, vcc_lo              // 000000D81A34: D5207C2E 01AA8680
	global_load_b128 v[33:36], v[33:34], off                   // 000000D81A3C: DC5E0000 217C0021
	global_load_b128 v[37:40], v[37:38], off                   // 000000D81A44: DC5E0000 257C0025
	global_load_b128 v[41:44], v[41:42], off                   // 000000D81A4C: DC5E0000 297C0029
	global_load_b128 v[45:48], v[45:46], off                   // 000000D81A54: DC5E0000 2D7C002D
	.long 0xd7006a31                                           // 000000D81A5C: D7006A31
	v_cndmask_b32_e32 v0, v78, v4, vcc_lo                      // 000000D81A60: 0200094E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000D81A64: BF8704A1
	v_add_co_ci_u32_e64 v50, null, s5, v79, vcc_lo             // 000000D81A68: D5207C32 01AA9E05
	s_bfe_i32 s28, s12, 0x10000                                // 000000D81A70: 939CFF0C 00010000
	s_and_b32 s28, s28, 0x4400                                 // 000000D81A78: 8B1CFF1C 00004400
	global_load_b32 v51, v[49:50], off                         // 000000D81A80: DC520000 337C0031
	v_add_nc_u32_e32 v97, s28, v80                             // 000000D81A88: 4AC2A01C
	s_and_b32 s28, s12, 1                                      // 000000D81A8C: 8B1C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000D81A90: BF8704A9
	s_cmp_eq_u32 s28, 0                                        // 000000D81A94: BF06801C
	s_cselect_b32 s28, -1, 0                                   // 000000D81A98: 981C80C1
	s_and_b32 s29, s28, exec_lo                                // 000000D81A9C: 8B1D7E1C
	s_cselect_b32 s29, 32, 0x4420                              // 000000D81AA0: 981DFFA0 00004420
	s_waitcnt vmcnt(0)                                         // 000000D81AA8: BF8903F7
	v_bfe_u32 v52, v51, 12, 16                                 // 000000D81AAC: D6100034 02411933
	v_bfe_u32 v53, v51, 8, 16                                  // 000000D81AB4: D6100035 02411133
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81ABC: BF870112
	.long 0xd72c0034                                           // 000000D81AC0: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D81AC4: 020268FF 83DCD12D
	.long 0xd72c0035                                           // 000000D81ACC: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000D81AD0: 02026AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81AD8: BF870112
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D81ADC: D6220034 03FD0134 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 000000D81AE8: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81AF4: BF870092
	v_and_b32_e32 v52, 0xffff, v52                             // 000000D81AF8: 366868FF 0000FFFF
	v_lshl_or_b32 v52, v53, 16, v52                            // 000000D81B00: D6560034 04D12135
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81B08: BF870091
	v_pk_fma_f16 v52, v52, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81B0C: CC0E0034 0BFC1B34 0000C931
	v_mov_b32_e32 v53, v52                                     // 000000D81B18: 7E6A0334
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81B1C: BF870091
	v_permlanex16_b32 v53, v53, s21, 0xfedcba98                // 000000D81B20: D65C0035 03FC2B35 FEDCBA98
	v_cndmask_b32_e64 v83, v53, v52, s3                        // 000000D81B2C: D5010053 000E6935
	v_cndmask_b32_e64 v87, v52, v53, s3                        // 000000D81B34: D5010057 000E6B34
	v_and_b32_e32 v52, 0xffff, v51                             // 000000D81B3C: 366866FF 0000FFFF
	v_bfe_u32 v51, v51, 4, 16                                  // 000000D81B44: D6100033 02410933
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81B4C: BF870112
	.long 0xd72c0034                                           // 000000D81B50: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D81B54: 020268FF 83DCD12D
	.long 0xd72c0033                                           // 000000D81B5C: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D81B60: 020266FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81B68: BF870112
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D81B6C: D6220034 03FD0134 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D81B78: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81B84: BF870092
	v_lshlrev_b32_e32 v52, 16, v52                             // 000000D81B88: 30686890
	v_and_or_b32 v51, 0xffff, v51, v52                         // 000000D81B8C: D6570033 04D266FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81B98: BF870091
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81B9C: CC0E0033 0BFC1B33 0000C931
	v_mov_b32_e32 v52, v51                                     // 000000D81BA8: 7E680333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81BAC: BF870091
	v_permlanex16_b32 v52, v52, s21, 0xfedcba98                // 000000D81BB0: D65C0034 03FC2B34 FEDCBA98
	v_cndmask_b32_e64 v84, v52, v51, s3                        // 000000D81BBC: D5010054 000E6734
	v_cndmask_b32_e64 v88, v51, v52, s3                        // 000000D81BC4: D5010058 000E6933
	.long 0xd7006a33                                           // 000000D81BCC: D7006A33
	v_cndmask_b32_e32 v0, v70, v4, vcc_lo                      // 000000D81BD0: 02000946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D81BD4: BF8700A1
	v_add_co_ci_u32_e64 v52, null, s5, v71, vcc_lo             // 000000D81BD8: D5207C34 01AA8E05
	.long 0xd7006a35                                           // 000000D81BE0: D7006A35
	v_cndmask_b32_e32 v0, v76, v4, vcc_lo                      // 000000D81BE4: 0200094C
	v_add_co_ci_u32_e64 v54, null, s5, v77, vcc_lo             // 000000D81BE8: D5207C36 01AA9A05
	s_clause 0x1                                               // 000000D81BF0: BF850001
	global_load_b32 v90, v[51:52], off                         // 000000D81BF4: DC520000 5A7C0033
	global_load_b32 v89, v[53:54], off                         // 000000D81BFC: DC520000 597C0035
	s_waitcnt vmcnt(0)                                         // 000000D81C04: BF8903F7
	.long 0xd73d0051                                           // 000000D81C08: D73D0051
	v_cndmask_b32_e32 v1, v62, v89, vcc_lo                     // 000000D81C0C: 0202B33E
	.long 0xd73d005b                                           // 000000D81C10: D73D005B
	v_cndmask_b32_e32 v1, v64, v89, vcc_lo                     // 000000D81C14: 0202B340
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D81C18: BF8701B2
	v_and_b32_e32 v85, 0xffff, v81                             // 000000D81C1C: 36AAA2FF 0000FFFF
	.long 0xd73d0051                                           // 000000D81C24: D73D0051
	v_cndmask_b32_e32 v1, v63, v89, vcc_lo                     // 000000D81C28: 0202B33F
	.long 0xd73d0059                                           // 000000D81C2C: D73D0059
	v_cndmask_b32_e32 v1, v65, v89, vcc_lo                     // 000000D81C30: 0202B341
	.long 0xd72c0052                                           // 000000D81C34: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D81C38: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81C40: BF870193
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D81C44: 36A2A2FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v89                             // 000000D81C4C: 36ACB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D81C54: BF870212
	.long 0xd72c0051                                           // 000000D81C58: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D81C5C: 0202A2FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D81C64: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81C70: BF870113
	.long 0xd72c0056                                           // 000000D81C74: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D81C78: 0202ACFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D81C80: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81C88: BF870194
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D81C8C: D6220051 03FD0151 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D81C98: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81CA4: BF870092
	v_lshl_or_b32 v81, v81, 16, v82                            // 000000D81CA8: D6560051 05492151
	v_pk_fma_f16 v82, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81CB0: CC0E0052 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81CBC: BF870091
	v_mov_b32_e32 v85, v82                                     // 000000D81CC0: 7EAA0352
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D81CC4: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D81CD0: BF8700B1
	v_cndmask_b32_e64 v81, v85, v82, s3                        // 000000D81CD4: D5010051 000EA555
	v_cndmask_b32_e64 v85, v82, v85, s3                        // 000000D81CDC: D5010055 000EAB52
	v_and_b32_e32 v82, 0xffff, v91                             // 000000D81CE4: 36A4B6FF 0000FFFF
	.long 0xd72c0052                                           // 000000D81CEC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D81CF0: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81CF8: BF870091
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D81CFC: D6220052 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D81D08: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81D10: BF870091
	v_lshl_or_b32 v82, v86, 16, v82                            // 000000D81D14: D6560052 05492156
	v_pk_fma_f16 v86, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81D1C: CC0E0056 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81D28: BF870091
	v_mov_b32_e32 v89, v86                                     // 000000D81D2C: 7EB20356
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D81D30: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D81D3C: BF870001
	v_cndmask_b32_e64 v82, v89, v86, s3                        // 000000D81D40: D5010052 000EAD59
	v_cndmask_b32_e64 v86, v86, v89, s3                        // 000000D81D48: D5010056 000EB356
	ds_load_b128 v[89:92], v97                                 // 000000D81D50: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D81D58: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D81D60: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D81D64: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D81D6C: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D81D74: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D81D7C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D81D80: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D81D88: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D81D90: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D81D98: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D81D9C: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D81DA4: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D81DAC: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D81DB4: 4AC2A01D
	s_cselect_b32 s29, 64, 0x4440                              // 000000D81DB8: 981DFFC0 00004440
	s_waitcnt lgkmcnt(0)                                       // 000000D81DC0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D81DC4: CC404001 1C06B351
	s_clause 0x2                                               // 000000D81DCC: BF850002
	global_load_b32 v81, v[49:50], off offset:1024             // 000000D81DD0: DC520400 517C0031
	global_load_b32 v90, v[51:52], off offset:1024             // 000000D81DD8: DC520400 5A7C0033
	global_load_b32 v89, v[53:54], off offset:1024             // 000000D81DE0: DC520400 597C0035
	s_waitcnt vmcnt(2)                                         // 000000D81DE8: BF890BF7
	v_bfe_u32 v82, v81, 12, 16                                 // 000000D81DEC: D6100052 02411951
	v_bfe_u32 v83, v81, 8, 16                                  // 000000D81DF4: D6100053 02411151
	s_waitcnt vmcnt(0)                                         // 000000D81DFC: BF8903F7
	.long 0xd73d005b                                           // 000000D81E00: D73D005B
	v_cndmask_b32_e32 v1, v64, v89, vcc_lo                     // 000000D81E04: 0202B340
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81E08: BF870193
	.long 0xd72c0052                                           // 000000D81E0C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D81E10: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000D81E18: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D81E1C: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81E24: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D81E28: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D81E34: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81E40: BF870092
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D81E44: 36A4A4FF 0000FFFF
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000D81E4C: D6560052 05492153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81E54: BF870091
	v_pk_fma_f16 v82, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81E58: CC0E0052 0BFC1B52 0000C931
	v_mov_b32_e32 v84, v82                                     // 000000D81E64: 7EA80352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81E68: BF870091
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D81E6C: D65C0054 03FC2B54 FEDCBA98
	v_cndmask_b32_e64 v83, v84, v82, s3                        // 000000D81E78: D5010053 000EA554
	v_cndmask_b32_e64 v87, v82, v84, s3                        // 000000D81E80: D5010057 000EA952
	v_and_b32_e32 v82, 0xffff, v81                             // 000000D81E88: 36A4A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 000000D81E90: D6100051 02410951
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81E98: BF870112
	.long 0xd72c0052                                           // 000000D81E9C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D81EA0: 0202A4FF 83DCD12D
	.long 0xd72c0051                                           // 000000D81EA8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D81EAC: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81EB4: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D81EB8: D6220052 03FD0152 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D81EC4: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81ED0: BF870092
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000D81ED4: 30A4A490
	v_and_or_b32 v81, 0xffff, v81, v82                         // 000000D81ED8: D6570051 054AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81EE4: BF870091
	v_pk_fma_f16 v81, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81EE8: CC0E0051 0BFC1B51 0000C931
	v_mov_b32_e32 v82, v81                                     // 000000D81EF4: 7EA40351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81EF8: BF870091
	v_permlanex16_b32 v82, v82, s21, 0xfedcba98                // 000000D81EFC: D65C0052 03FC2B52 FEDCBA98
	v_cndmask_b32_e64 v84, v82, v81, s3                        // 000000D81F08: D5010054 000EA352
	v_cndmask_b32_e64 v88, v81, v82, s3                        // 000000D81F10: D5010058 000EA551
	.long 0xd73d0051                                           // 000000D81F18: D73D0051
	v_cndmask_b32_e32 v1, v62, v89, vcc_lo                     // 000000D81F1C: 0202B33E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D81F20: BF8701B1
	v_and_b32_e32 v85, 0xffff, v81                             // 000000D81F24: 36AAA2FF 0000FFFF
	.long 0xd73d0051                                           // 000000D81F2C: D73D0051
	v_cndmask_b32_e32 v1, v63, v89, vcc_lo                     // 000000D81F30: 0202B33F
	.long 0xd73d0059                                           // 000000D81F34: D73D0059
	v_cndmask_b32_e32 v1, v65, v89, vcc_lo                     // 000000D81F38: 0202B341
	.long 0xd72c0052                                           // 000000D81F3C: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D81F40: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81F48: BF870193
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D81F4C: 36A2A2FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v89                             // 000000D81F54: 36ACB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D81F5C: BF870212
	.long 0xd72c0051                                           // 000000D81F60: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D81F64: 0202A2FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D81F6C: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D81F78: BF870113
	.long 0xd72c0056                                           // 000000D81F7C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D81F80: 0202ACFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D81F88: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D81F90: BF870194
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D81F94: D6220051 03FD0151 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D81FA0: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81FAC: BF870092
	v_lshl_or_b32 v81, v81, 16, v82                            // 000000D81FB0: D6560051 05492151
	v_pk_fma_f16 v82, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D81FB8: CC0E0052 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D81FC4: BF870091
	v_mov_b32_e32 v85, v82                                     // 000000D81FC8: 7EAA0352
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D81FCC: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D81FD8: BF8700B1
	v_cndmask_b32_e64 v81, v85, v82, s3                        // 000000D81FDC: D5010051 000EA555
	v_cndmask_b32_e64 v85, v82, v85, s3                        // 000000D81FE4: D5010055 000EAB52
	v_and_b32_e32 v82, 0xffff, v91                             // 000000D81FEC: 36A4B6FF 0000FFFF
	.long 0xd72c0052                                           // 000000D81FF4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D81FF8: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82000: BF870091
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82004: D6220052 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82010: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82018: BF870091
	v_lshl_or_b32 v82, v86, 16, v82                            // 000000D8201C: D6560052 05492156
	v_pk_fma_f16 v86, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82024: CC0E0056 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82030: BF870091
	v_mov_b32_e32 v89, v86                                     // 000000D82034: 7EB20356
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D82038: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D82044: BF870001
	v_cndmask_b32_e64 v82, v89, v86, s3                        // 000000D82048: D5010052 000EAD59
	v_cndmask_b32_e64 v86, v86, v89, s3                        // 000000D82050: D5010056 000EB356
	ds_load_b128 v[89:92], v97                                 // 000000D82058: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D82060: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82068: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D8206C: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D82074: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D8207C: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82084: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D82088: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D82090: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D82098: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D820A0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D820A4: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D820AC: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D820B4: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D820BC: 4AC2A01D
	s_cselect_b32 s29, s22, 0x4460                             // 000000D820C0: 981DFF16 00004460
	s_waitcnt lgkmcnt(0)                                       // 000000D820C8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D820CC: CC404001 1C06B351
	s_clause 0x2                                               // 000000D820D4: BF850002
	global_load_b32 v81, v[49:50], off offset:2048             // 000000D820D8: DC520800 517C0031
	global_load_b32 v90, v[51:52], off offset:2048             // 000000D820E0: DC520800 5A7C0033
	global_load_b32 v89, v[53:54], off offset:2048             // 000000D820E8: DC520800 597C0035
	s_waitcnt vmcnt(2)                                         // 000000D820F0: BF890BF7
	v_bfe_u32 v82, v81, 12, 16                                 // 000000D820F4: D6100052 02411951
	v_bfe_u32 v83, v81, 8, 16                                  // 000000D820FC: D6100053 02411151
	s_waitcnt vmcnt(0)                                         // 000000D82104: BF8903F7
	.long 0xd73d005b                                           // 000000D82108: D73D005B
	v_cndmask_b32_e32 v1, v64, v89, vcc_lo                     // 000000D8210C: 0202B340
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82110: BF870193
	.long 0xd72c0052                                           // 000000D82114: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82118: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000D82120: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D82124: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8212C: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82130: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D8213C: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82148: BF870092
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D8214C: 36A4A4FF 0000FFFF
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000D82154: D6560052 05492153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8215C: BF870091
	v_pk_fma_f16 v82, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82160: CC0E0052 0BFC1B52 0000C931
	v_mov_b32_e32 v84, v82                                     // 000000D8216C: 7EA80352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82170: BF870091
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D82174: D65C0054 03FC2B54 FEDCBA98
	v_cndmask_b32_e64 v83, v84, v82, s3                        // 000000D82180: D5010053 000EA554
	v_cndmask_b32_e64 v87, v82, v84, s3                        // 000000D82188: D5010057 000EA952
	v_and_b32_e32 v82, 0xffff, v81                             // 000000D82190: 36A4A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 000000D82198: D6100051 02410951
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D821A0: BF870112
	.long 0xd72c0052                                           // 000000D821A4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D821A8: 0202A4FF 83DCD12D
	.long 0xd72c0051                                           // 000000D821B0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D821B4: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D821BC: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D821C0: D6220052 03FD0152 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D821CC: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D821D8: BF870092
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000D821DC: 30A4A490
	v_and_or_b32 v81, 0xffff, v81, v82                         // 000000D821E0: D6570051 054AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D821EC: BF870091
	v_pk_fma_f16 v81, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D821F0: CC0E0051 0BFC1B51 0000C931
	v_mov_b32_e32 v82, v81                                     // 000000D821FC: 7EA40351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82200: BF870091
	v_permlanex16_b32 v82, v82, s21, 0xfedcba98                // 000000D82204: D65C0052 03FC2B52 FEDCBA98
	v_cndmask_b32_e64 v84, v82, v81, s3                        // 000000D82210: D5010054 000EA352
	v_cndmask_b32_e64 v88, v81, v82, s3                        // 000000D82218: D5010058 000EA551
	.long 0xd73d0051                                           // 000000D82220: D73D0051
	v_cndmask_b32_e32 v1, v62, v89, vcc_lo                     // 000000D82224: 0202B33E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D82228: BF8701B1
	v_and_b32_e32 v85, 0xffff, v81                             // 000000D8222C: 36AAA2FF 0000FFFF
	.long 0xd73d0051                                           // 000000D82234: D73D0051
	v_cndmask_b32_e32 v1, v63, v89, vcc_lo                     // 000000D82238: 0202B33F
	.long 0xd73d0059                                           // 000000D8223C: D73D0059
	v_cndmask_b32_e32 v1, v65, v89, vcc_lo                     // 000000D82240: 0202B341
	.long 0xd72c0052                                           // 000000D82244: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D82248: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82250: BF870193
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D82254: 36A2A2FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v89                             // 000000D8225C: 36ACB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D82264: BF870212
	.long 0xd72c0051                                           // 000000D82268: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D8226C: 0202A2FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82274: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82280: BF870113
	.long 0xd72c0056                                           // 000000D82284: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D82288: 0202ACFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82290: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82298: BF870194
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D8229C: D6220051 03FD0151 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D822A8: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D822B4: BF870092
	v_lshl_or_b32 v81, v81, 16, v82                            // 000000D822B8: D6560051 05492151
	v_pk_fma_f16 v82, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D822C0: CC0E0052 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D822CC: BF870091
	v_mov_b32_e32 v85, v82                                     // 000000D822D0: 7EAA0352
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D822D4: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D822E0: BF8700B1
	v_cndmask_b32_e64 v81, v85, v82, s3                        // 000000D822E4: D5010051 000EA555
	v_cndmask_b32_e64 v85, v82, v85, s3                        // 000000D822EC: D5010055 000EAB52
	v_and_b32_e32 v82, 0xffff, v91                             // 000000D822F4: 36A4B6FF 0000FFFF
	.long 0xd72c0052                                           // 000000D822FC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82300: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82308: BF870091
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D8230C: D6220052 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82318: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82320: BF870091
	v_lshl_or_b32 v82, v86, 16, v82                            // 000000D82324: D6560052 05492156
	v_pk_fma_f16 v86, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D8232C: CC0E0056 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82338: BF870091
	v_mov_b32_e32 v89, v86                                     // 000000D8233C: 7EB20356
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D82340: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8234C: BF870001
	v_cndmask_b32_e64 v82, v89, v86, s3                        // 000000D82350: D5010052 000EAD59
	v_cndmask_b32_e64 v86, v86, v89, s3                        // 000000D82358: D5010056 000EB356
	ds_load_b128 v[89:92], v97                                 // 000000D82360: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D82368: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82370: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D82374: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D8237C: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D82384: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D8238C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D82390: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D82398: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D823A0: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D823A8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D823AC: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D823B4: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D823BC: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D823C4: 4AC2A01D
	s_cselect_b32 s29, s23, 0x4480                             // 000000D823C8: 981DFF17 00004480
	s_waitcnt lgkmcnt(0)                                       // 000000D823D0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D823D4: CC404001 1C06B351
	s_clause 0x2                                               // 000000D823DC: BF850002
	global_load_b32 v81, v[49:50], off offset:3072             // 000000D823E0: DC520C00 517C0031
	global_load_b32 v89, v[53:54], off offset:3072             // 000000D823E8: DC520C00 597C0035
	global_load_b32 v90, v[51:52], off offset:3072             // 000000D823F0: DC520C00 5A7C0033
	.long 0xd7006a33                                           // 000000D823F8: D7006A33
	v_cndmask_b32_e32 v1, 0x1000, v51, vcc_lo                  // 000000D823FC: 020266FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D82404: BF8700A1
	v_add_co_ci_u32_e64 v52, null, 0, v52, vcc_lo              // 000000D82408: D5207C34 01AA6880
	.long 0xd7006a31                                           // 000000D82410: D7006A31
	v_cndmask_b32_e32 v1, 0x1000, v49, vcc_lo                  // 000000D82414: 020262FF 00001000
	v_add_co_ci_u32_e64 v50, null, 0, v50, vcc_lo              // 000000D8241C: D5207C32 01AA6480
	.long 0xd7006a35                                           // 000000D82424: D7006A35
	v_cndmask_b32_e32 v1, 0x1000, v53, vcc_lo                  // 000000D82428: 02026AFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D82430: BF870001
	v_add_co_ci_u32_e64 v54, null, 0, v54, vcc_lo              // 000000D82434: D5207C36 01AA6C80
	s_waitcnt vmcnt(2)                                         // 000000D8243C: BF890BF7
	v_bfe_u32 v82, v81, 12, 16                                 // 000000D82440: D6100052 02411951
	v_bfe_u32 v83, v81, 8, 16                                  // 000000D82448: D6100053 02411151
	s_waitcnt vmcnt(0)                                         // 000000D82450: BF8903F7
	.long 0xd73d005b                                           // 000000D82454: D73D005B
	v_cndmask_b32_e32 v1, v64, v89, vcc_lo                     // 000000D82458: 0202B340
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8245C: BF870193
	.long 0xd72c0052                                           // 000000D82460: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82464: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000D8246C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D82470: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82478: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D8247C: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82488: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82494: BF870092
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82498: 36A4A4FF 0000FFFF
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000D824A0: D6560052 05492153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D824A8: BF870091
	v_pk_fma_f16 v82, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D824AC: CC0E0052 0BFC1B52 0000C931
	v_mov_b32_e32 v84, v82                                     // 000000D824B8: 7EA80352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D824BC: BF870091
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D824C0: D65C0054 03FC2B54 FEDCBA98
	v_cndmask_b32_e64 v83, v84, v82, s3                        // 000000D824CC: D5010053 000EA554
	v_cndmask_b32_e64 v87, v82, v84, s3                        // 000000D824D4: D5010057 000EA952
	v_and_b32_e32 v82, 0xffff, v81                             // 000000D824DC: 36A4A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 000000D824E4: D6100051 02410951
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D824EC: BF870112
	.long 0xd72c0052                                           // 000000D824F0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D824F4: 0202A4FF 83DCD12D
	.long 0xd72c0051                                           // 000000D824FC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D82500: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82508: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D8250C: D6220052 03FD0152 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D82518: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82524: BF870092
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000D82528: 30A4A490
	v_and_or_b32 v81, 0xffff, v81, v82                         // 000000D8252C: D6570051 054AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82538: BF870091
	v_pk_fma_f16 v81, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D8253C: CC0E0051 0BFC1B51 0000C931
	v_mov_b32_e32 v82, v81                                     // 000000D82548: 7EA40351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8254C: BF870091
	v_permlanex16_b32 v82, v82, s21, 0xfedcba98                // 000000D82550: D65C0052 03FC2B52 FEDCBA98
	v_cndmask_b32_e64 v84, v82, v81, s3                        // 000000D8255C: D5010054 000EA352
	v_cndmask_b32_e64 v88, v81, v82, s3                        // 000000D82564: D5010058 000EA551
	.long 0xd73d0051                                           // 000000D8256C: D73D0051
	v_cndmask_b32_e32 v1, v62, v89, vcc_lo                     // 000000D82570: 0202B33E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D82574: BF8701B1
	v_and_b32_e32 v85, 0xffff, v81                             // 000000D82578: 36AAA2FF 0000FFFF
	.long 0xd73d0051                                           // 000000D82580: D73D0051
	v_cndmask_b32_e32 v1, v63, v89, vcc_lo                     // 000000D82584: 0202B33F
	.long 0xd73d0059                                           // 000000D82588: D73D0059
	v_cndmask_b32_e32 v1, v65, v89, vcc_lo                     // 000000D8258C: 0202B341
	.long 0xd72c0052                                           // 000000D82590: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D82594: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8259C: BF870193
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D825A0: 36A2A2FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v89                             // 000000D825A8: 36ACB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D825B0: BF870212
	.long 0xd72c0051                                           // 000000D825B4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D825B8: 0202A2FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D825C0: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D825CC: BF870113
	.long 0xd72c0056                                           // 000000D825D0: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D825D4: 0202ACFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D825DC: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D825E4: BF870194
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D825E8: D6220051 03FD0151 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D825F4: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82600: BF870092
	v_lshl_or_b32 v81, v81, 16, v82                            // 000000D82604: D6560051 05492151
	v_pk_fma_f16 v82, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D8260C: CC0E0052 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82618: BF870091
	v_mov_b32_e32 v85, v82                                     // 000000D8261C: 7EAA0352
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D82620: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D8262C: BF8700B1
	v_cndmask_b32_e64 v81, v85, v82, s3                        // 000000D82630: D5010051 000EA555
	v_cndmask_b32_e64 v85, v82, v85, s3                        // 000000D82638: D5010055 000EAB52
	v_and_b32_e32 v82, 0xffff, v91                             // 000000D82640: 36A4B6FF 0000FFFF
	.long 0xd72c0052                                           // 000000D82648: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D8264C: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82654: BF870091
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82658: D6220052 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82664: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8266C: BF870091
	v_lshl_or_b32 v82, v86, 16, v82                            // 000000D82670: D6560052 05492156
	v_pk_fma_f16 v86, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82678: CC0E0056 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82684: BF870091
	v_mov_b32_e32 v89, v86                                     // 000000D82688: 7EB20356
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D8268C: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D82698: BF870001
	v_cndmask_b32_e64 v82, v89, v86, s3                        // 000000D8269C: D5010052 000EAD59
	v_cndmask_b32_e64 v86, v86, v89, s3                        // 000000D826A4: D5010056 000EB356
	ds_load_b128 v[89:92], v97                                 // 000000D826AC: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D826B4: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D826BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D826C0: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D826C8: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D826D0: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D826D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D826DC: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D826E4: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D826EC: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D826F4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D826F8: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D82700: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D82708: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D82710: 4AC2A01D
	s_cselect_b32 s29, s24, 0x44a0                             // 000000D82714: 981DFF18 000044A0
	s_waitcnt lgkmcnt(0)                                       // 000000D8271C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D82720: CC404001 1C06B351
	s_clause 0x2                                               // 000000D82728: BF850002
	global_load_b32 v81, v[49:50], off                         // 000000D8272C: DC520000 517C0031
	global_load_b32 v90, v[51:52], off                         // 000000D82734: DC520000 5A7C0033
	global_load_b32 v89, v[53:54], off                         // 000000D8273C: DC520000 597C0035
	s_waitcnt vmcnt(2)                                         // 000000D82744: BF890BF7
	v_bfe_u32 v82, v81, 12, 16                                 // 000000D82748: D6100052 02411951
	v_bfe_u32 v83, v81, 8, 16                                  // 000000D82750: D6100053 02411151
	s_waitcnt vmcnt(0)                                         // 000000D82758: BF8903F7
	.long 0xd73d005b                                           // 000000D8275C: D73D005B
	v_cndmask_b32_e32 v1, v64, v89, vcc_lo                     // 000000D82760: 0202B340
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82764: BF870193
	.long 0xd72c0052                                           // 000000D82768: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D8276C: 0202A4FF 83DCD12D
	.long 0xd72c0053                                           // 000000D82774: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D82778: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82780: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82784: D6220052 03FD0152 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82790: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8279C: BF870092
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D827A0: 36A4A4FF 0000FFFF
	v_lshl_or_b32 v82, v83, 16, v82                            // 000000D827A8: D6560052 05492153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D827B0: BF870091
	v_pk_fma_f16 v82, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D827B4: CC0E0052 0BFC1B52 0000C931
	v_mov_b32_e32 v84, v82                                     // 000000D827C0: 7EA80352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D827C4: BF870091
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D827C8: D65C0054 03FC2B54 FEDCBA98
	v_cndmask_b32_e64 v83, v84, v82, s3                        // 000000D827D4: D5010053 000EA554
	v_cndmask_b32_e64 v87, v82, v84, s3                        // 000000D827DC: D5010057 000EA952
	v_and_b32_e32 v82, 0xffff, v81                             // 000000D827E4: 36A4A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 000000D827EC: D6100051 02410951
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D827F4: BF870112
	.long 0xd72c0052                                           // 000000D827F8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D827FC: 0202A4FF 83DCD12D
	.long 0xd72c0051                                           // 000000D82804: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D82808: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82810: BF870112
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82814: D6220052 03FD0152 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D82820: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8282C: BF870092
	v_lshlrev_b32_e32 v82, 16, v82                             // 000000D82830: 30A4A490
	v_and_or_b32 v81, 0xffff, v81, v82                         // 000000D82834: D6570051 054AA2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82840: BF870091
	v_pk_fma_f16 v81, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82844: CC0E0051 0BFC1B51 0000C931
	v_mov_b32_e32 v82, v81                                     // 000000D82850: 7EA40351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82854: BF870091
	v_permlanex16_b32 v82, v82, s21, 0xfedcba98                // 000000D82858: D65C0052 03FC2B52 FEDCBA98
	v_cndmask_b32_e64 v84, v82, v81, s3                        // 000000D82864: D5010054 000EA352
	v_cndmask_b32_e64 v88, v81, v82, s3                        // 000000D8286C: D5010058 000EA551
	.long 0xd73d0051                                           // 000000D82874: D73D0051
	v_cndmask_b32_e32 v1, v62, v89, vcc_lo                     // 000000D82878: 0202B33E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8287C: BF8701B1
	v_and_b32_e32 v85, 0xffff, v81                             // 000000D82880: 36AAA2FF 0000FFFF
	.long 0xd73d0051                                           // 000000D82888: D73D0051
	v_cndmask_b32_e32 v1, v63, v89, vcc_lo                     // 000000D8288C: 0202B33F
	.long 0xd73d0059                                           // 000000D82890: D73D0059
	v_cndmask_b32_e32 v1, v65, v89, vcc_lo                     // 000000D82894: 0202B341
	.long 0xd72c0052                                           // 000000D82898: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D8289C: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D828A4: BF870193
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D828A8: 36A2A2FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v89                             // 000000D828B0: 36ACB2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D828B8: BF870212
	.long 0xd72c0051                                           // 000000D828BC: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D828C0: 0202A2FF 83DCD12D
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D828C8: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D828D4: BF870113
	.long 0xd72c0056                                           // 000000D828D8: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D828DC: 0202ACFF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D828E4: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D828EC: BF870194
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D828F0: D6220051 03FD0151 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D828FC: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82908: BF870092
	v_lshl_or_b32 v81, v81, 16, v82                            // 000000D8290C: D6560051 05492151
	v_pk_fma_f16 v82, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82914: CC0E0052 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82920: BF870091
	v_mov_b32_e32 v85, v82                                     // 000000D82924: 7EAA0352
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D82928: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D82934: BF8700B1
	v_cndmask_b32_e64 v81, v85, v82, s3                        // 000000D82938: D5010051 000EA555
	v_cndmask_b32_e64 v85, v82, v85, s3                        // 000000D82940: D5010055 000EAB52
	v_and_b32_e32 v82, 0xffff, v91                             // 000000D82948: 36A4B6FF 0000FFFF
	.long 0xd72c0052                                           // 000000D82950: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82954: 0202A4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8295C: BF870091
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82960: D6220052 03FD0152 00006400
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D8296C: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82974: BF870091
	v_lshl_or_b32 v82, v86, 16, v82                            // 000000D82978: D6560052 05492156
	v_pk_fma_f16 v86, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82980: CC0E0056 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8298C: BF870091
	v_mov_b32_e32 v89, v86                                     // 000000D82990: 7EB20356
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D82994: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D829A0: BF870001
	v_cndmask_b32_e64 v82, v89, v86, s3                        // 000000D829A4: D5010052 000EAD59
	v_cndmask_b32_e64 v86, v86, v89, s3                        // 000000D829AC: D5010056 000EB356
	ds_load_b128 v[89:92], v97                                 // 000000D829B4: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D829BC: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D829C4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D829C8: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D829D0: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D829D8: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D829E0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D829E4: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D829EC: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D829F4: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D829FC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D82A00: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D82A08: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D82A10: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D82A18: 4AC2A01D
	s_cselect_b32 s29, s25, 0x44c0                             // 000000D82A1C: 981DFF19 000044C0
	s_waitcnt lgkmcnt(0)                                       // 000000D82A24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D82A28: CC404001 1C06B351
	s_clause 0x1                                               // 000000D82A30: BF850001
	global_load_b32 v83, v[51:52], off offset:1024             // 000000D82A34: DC520400 537C0033
	global_load_b32 v82, v[53:54], off offset:1024             // 000000D82A3C: DC520400 527C0035
	s_waitcnt vmcnt(0)                                         // 000000D82A44: BF8903F7
	.long 0xd73d0054                                           // 000000D82A48: D73D0054
	v_cndmask_b32_e32 v1, v62, v82, vcc_lo                     // 000000D82A4C: 0202A53E
	.long 0xd73d0056                                           // 000000D82A50: D73D0056
	v_cndmask_b32_e32 v1, v64, v82, vcc_lo                     // 000000D82A54: 0202A540
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D82A58: BF8701B2
	v_and_b32_e32 v81, 0xffff, v84                             // 000000D82A5C: 36A2A8FF 0000FFFF
	.long 0xd73d0054                                           // 000000D82A64: D73D0054
	v_cndmask_b32_e32 v1, v63, v82, vcc_lo                     // 000000D82A68: 0202A53F
	.long 0xd73d0052                                           // 000000D82A6C: D73D0052
	v_cndmask_b32_e32 v1, v65, v82, vcc_lo                     // 000000D82A70: 0202A541
	.long 0xd72c0051                                           // 000000D82A74: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D82A78: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82A80: BF870193
	v_and_b32_e32 v84, 0xffff, v84                             // 000000D82A84: 36A8A8FF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82A8C: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D82A94: BF870212
	.long 0xd72c0054                                           // 000000D82A98: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82A9C: 0202A8FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D82AA4: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82AB0: BF870113
	.long 0xd72c0052                                           // 000000D82AB4: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82AB8: 0202A4FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D82AC0: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82AC8: BF870194
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D82ACC: D6220054 03FD0154 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82AD8: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82AE4: BF870092
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000D82AE8: D6560051 05452154
	v_pk_fma_f16 v84, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82AF0: CC0E0054 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82AFC: BF870091
	v_mov_b32_e32 v85, v84                                     // 000000D82B00: 7EAA0354
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D82B04: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D82B10: BF8700B1
	v_cndmask_b32_e64 v81, v85, v84, s3                        // 000000D82B14: D5010051 000EA955
	v_cndmask_b32_e64 v85, v84, v85, s3                        // 000000D82B1C: D5010055 000EAB54
	v_and_b32_e32 v84, 0xffff, v86                             // 000000D82B24: 36A8ACFF 0000FFFF
	.long 0xd72c0053                                           // 000000D82B2C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82B30: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82B38: BF870091
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82B3C: D6220053 03FD0153 00006400
	v_and_b32_e32 v83, 0xffff, v83                             // 000000D82B48: 36A6A6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82B50: BF870091
	v_lshl_or_b32 v82, v82, 16, v83                            // 000000D82B54: D6560052 054D2152
	v_pk_fma_f16 v83, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82B5C: CC0E0053 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82B68: BF870091
	v_mov_b32_e32 v84, v83                                     // 000000D82B6C: 7EA80353
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D82B70: D65C0054 03FC2B54 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D82B7C: BF870001
	v_cndmask_b32_e64 v82, v84, v83, s3                        // 000000D82B80: D5010052 000EA754
	v_cndmask_b32_e64 v86, v83, v84, s3                        // 000000D82B88: D5010056 000EA953
	global_load_b32 v84, v[49:50], off offset:1024             // 000000D82B90: DC520400 547C0031
	s_waitcnt vmcnt(0)                                         // 000000D82B98: BF8903F7
	v_bfe_u32 v83, v84, 12, 16                                 // 000000D82B9C: D6100053 02411954
	v_bfe_u32 v87, v84, 8, 16                                  // 000000D82BA4: D6100057 02411154
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82BAC: BF870112
	.long 0xd72c0053                                           // 000000D82BB0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D82BB4: 0202A6FF 83DCD12D
	.long 0xd72c0057                                           // 000000D82BBC: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000D82BC0: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82BC8: BF870112
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82BCC: D6220053 03FD0153 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000D82BD8: D6220057 03FD0157 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82BE4: BF870092
	v_and_b32_e32 v83, 0xffff, v83                             // 000000D82BE8: 36A6A6FF 0000FFFF
	v_lshl_or_b32 v83, v87, 16, v83                            // 000000D82BF0: D6560053 054D2157
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82BF8: BF870091
	v_pk_fma_f16 v87, v83, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82BFC: CC0E0057 0BFC1B53 0000C931
	v_mov_b32_e32 v88, v87                                     // 000000D82C08: 7EB00357
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82C0C: BF870091
	v_permlanex16_b32 v88, v88, s21, 0xfedcba98                // 000000D82C10: D65C0058 03FC2B58 FEDCBA98
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D82C1C: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D82C24: D5010057 000EB157
	v_and_b32_e32 v88, 0xffff, v84                             // 000000D82C2C: 36B0A8FF 0000FFFF
	v_bfe_u32 v84, v84, 4, 16                                  // 000000D82C34: D6100054 02410954
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82C3C: BF870112
	.long 0xd72c0058                                           // 000000D82C40: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000D82C44: 0202B0FF 83DCD12D
	.long 0xd72c0054                                           // 000000D82C4C: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82C50: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82C58: BF870112
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000D82C5C: D6220058 03FD0158 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D82C68: D6220054 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82C74: BF870092
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000D82C78: 30B0B090
	v_and_or_b32 v84, 0xffff, v84, v88                         // 000000D82C7C: D6570054 0562A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82C88: BF870091
	v_pk_fma_f16 v88, v84, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82C8C: CC0E0058 0BFC1B54 0000C931
	v_mov_b32_e32 v89, v88                                     // 000000D82C98: 7EB20358
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82C9C: BF870091
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D82CA0: D65C0059 03FC2B59 FEDCBA98
	v_cndmask_b32_e64 v84, v89, v88, s3                        // 000000D82CAC: D5010054 000EB159
	v_cndmask_b32_e64 v88, v88, v89, s3                        // 000000D82CB4: D5010058 000EB358
	ds_load_b128 v[89:92], v97                                 // 000000D82CBC: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D82CC4: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82CCC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D82CD0: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D82CD8: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D82CE0: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82CE8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D82CEC: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D82CF4: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D82CFC: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D82D04: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D82D08: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D82D10: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D82D18: DBFC3310 5D000061
	v_add_nc_u32_e32 v97, s29, v80                             // 000000D82D20: 4AC2A01D
	s_and_b32 s29, s28, exec_lo                                // 000000D82D24: 8B1D7E1C
	s_cselect_b32 s29, s26, 0x44e0                             // 000000D82D28: 981DFF1A 000044E0
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 000000D82D30: 916A1B7E
	s_waitcnt lgkmcnt(0)                                       // 000000D82D34: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D82D38: CC404001 1C06B351
	s_clause 0x3                                               // 000000D82D40: BF850003
	global_load_b32 v83, v[51:52], off offset:2048             // 000000D82D44: DC520800 537C0033
	global_load_b32 v82, v[53:54], off offset:2048             // 000000D82D4C: DC520800 527C0035
	global_load_b32 v53, v[53:54], off offset:3072             // 000000D82D54: DC520C00 357C0035
	global_load_b32 v54, v[51:52], off offset:3072             // 000000D82D5C: DC520C00 367C0033
	s_waitcnt vmcnt(2)                                         // 000000D82D64: BF890BF7
	.long 0xd73d0054                                           // 000000D82D68: D73D0054
	v_cndmask_b32_e32 v1, v62, v82, vcc_lo                     // 000000D82D6C: 0202A53E
	.long 0xd73d0056                                           // 000000D82D70: D73D0056
	v_cndmask_b32_e32 v1, v64, v82, vcc_lo                     // 000000D82D74: 0202A540
	s_waitcnt vmcnt(0)                                         // 000000D82D78: BF8903F7
	.long 0xd73d0033                                           // 000000D82D7C: D73D0033
	v_cndmask_b32_e32 v1, v62, v53, vcc_lo                     // 000000D82D80: 02026B3E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D82D84: BF8701B3
	v_and_b32_e32 v81, 0xffff, v84                             // 000000D82D88: 36A2A8FF 0000FFFF
	.long 0xd73d0054                                           // 000000D82D90: D73D0054
	v_cndmask_b32_e32 v1, v63, v82, vcc_lo                     // 000000D82D94: 0202A53F
	.long 0xd73d0052                                           // 000000D82D98: D73D0052
	v_cndmask_b32_e32 v1, v65, v82, vcc_lo                     // 000000D82D9C: 0202A541
	.long 0xd72c0051                                           // 000000D82DA0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D82DA4: 0202A2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82DAC: BF870193
	v_and_b32_e32 v84, 0xffff, v84                             // 000000D82DB0: 36A8A8FF 0000FFFF
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D82DB8: 36A4A4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D82DC0: BF870212
	.long 0xd72c0054                                           // 000000D82DC4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82DC8: 0202A8FF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D82DD0: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82DDC: BF870113
	.long 0xd72c0052                                           // 000000D82DE0: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D82DE4: 0202A4FF 83DCD12D
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D82DEC: 36A2A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82DF4: BF870194
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D82DF8: D6220054 03FD0154 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D82E04: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82E10: BF870092
	v_lshl_or_b32 v81, v84, 16, v81                            // 000000D82E14: D6560051 05452154
	v_pk_fma_f16 v84, v81, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82E1C: CC0E0054 0BFC1B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82E28: BF870091
	v_mov_b32_e32 v85, v84                                     // 000000D82E2C: 7EAA0354
	v_permlanex16_b32 v85, v85, s21, 0xfedcba98                // 000000D82E30: D65C0055 03FC2B55 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D82E3C: BF8700B1
	v_cndmask_b32_e64 v81, v85, v84, s3                        // 000000D82E40: D5010051 000EA955
	v_cndmask_b32_e64 v85, v84, v85, s3                        // 000000D82E48: D5010055 000EAB54
	v_and_b32_e32 v84, 0xffff, v86                             // 000000D82E50: 36A8ACFF 0000FFFF
	.long 0xd72c0053                                           // 000000D82E58: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82E5C: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82E64: BF870091
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82E68: D6220053 03FD0153 00006400
	v_and_b32_e32 v83, 0xffff, v83                             // 000000D82E74: 36A6A6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82E7C: BF870091
	v_lshl_or_b32 v82, v82, 16, v83                            // 000000D82E80: D6560052 054D2152
	v_pk_fma_f16 v83, v82, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82E88: CC0E0053 0BFC1B52 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82E94: BF870091
	v_mov_b32_e32 v84, v83                                     // 000000D82E98: 7EA80353
	v_permlanex16_b32 v84, v84, s21, 0xfedcba98                // 000000D82E9C: D65C0054 03FC2B54 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D82EA8: BF870001
	v_cndmask_b32_e64 v82, v84, v83, s3                        // 000000D82EAC: D5010052 000EA754
	v_cndmask_b32_e64 v86, v83, v84, s3                        // 000000D82EB4: D5010056 000EA953
	s_clause 0x1                                               // 000000D82EBC: BF850001
	global_load_b32 v84, v[49:50], off offset:2048             // 000000D82EC0: DC520800 547C0031
	global_load_b32 v49, v[49:50], off offset:3072             // 000000D82EC8: DC520C00 317C0031
	s_waitcnt vmcnt(1)                                         // 000000D82ED0: BF8907F7
	v_bfe_u32 v83, v84, 12, 16                                 // 000000D82ED4: D6100053 02411954
	v_bfe_u32 v87, v84, 8, 16                                  // 000000D82EDC: D6100057 02411154
	s_waitcnt vmcnt(0)                                         // 000000D82EE4: BF8903F7
	v_bfe_u32 v50, v49, 12, 16                                 // 000000D82EE8: D6100032 02411931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82EF0: BF870193
	.long 0xd72c0053                                           // 000000D82EF4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D82EF8: 0202A6FF 83DCD12D
	.long 0xd72c0057                                           // 000000D82F00: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000D82F04: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82F0C: BF870193
	.long 0xd72c0032                                           // 000000D82F10: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000D82F14: 020264FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D82F1C: D6220053 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D82F28: BF870193
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000D82F2C: D6220057 03FD0157 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D82F38: D6220032 03FD0132 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82F44: BF870113
	v_and_b32_e32 v83, 0xffff, v83                             // 000000D82F48: 36A6A6FF 0000FFFF
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D82F50: 366464FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82F58: BF870092
	v_lshl_or_b32 v83, v87, 16, v83                            // 000000D82F5C: D6560053 054D2157
	v_pk_fma_f16 v87, v83, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82F64: CC0E0057 0BFC1B53 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82F70: BF870091
	v_mov_b32_e32 v88, v87                                     // 000000D82F74: 7EB00357
	v_permlanex16_b32 v88, v88, s21, 0xfedcba98                // 000000D82F78: D65C0058 03FC2B58 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000D82F84: BF870141
	v_cndmask_b32_e64 v83, v88, v87, s3                        // 000000D82F88: D5010053 000EAF58
	v_cndmask_b32_e64 v87, v87, v88, s3                        // 000000D82F90: D5010057 000EB157
	v_and_b32_e32 v88, 0xffff, v84                             // 000000D82F98: 36B0A8FF 0000FFFF
	v_bfe_u32 v84, v84, 4, 16                                  // 000000D82FA0: D6100054 02410954
	.long 0xd72c0058                                           // 000000D82FA8: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000D82FAC: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82FB4: BF870112
	.long 0xd72c0054                                           // 000000D82FB8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D82FBC: 0202A8FF 83DCD12D
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000D82FC4: D6220058 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D82FD0: BF870112
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D82FD4: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000D82FE0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D82FE4: BF870091
	v_and_or_b32 v84, 0xffff, v84, v88                         // 000000D82FE8: D6570054 0562A8FF 0000FFFF
	v_pk_fma_f16 v88, v84, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D82FF4: CC0E0058 0BFC1B54 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83000: BF870091
	v_mov_b32_e32 v89, v88                                     // 000000D83004: 7EB20358
	v_permlanex16_b32 v89, v89, s21, 0xfedcba98                // 000000D83008: D65C0059 03FC2B59 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D83014: BF870001
	v_cndmask_b32_e64 v84, v89, v88, s3                        // 000000D83018: D5010054 000EB159
	v_cndmask_b32_e64 v88, v88, v89, s3                        // 000000D83020: D5010058 000EB358
	ds_load_b128 v[89:92], v97                                 // 000000D83028: DBFC0000 59000061
	ds_load_b128 v[93:96], v97 offset:16                       // 000000D83030: DBFC0010 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D83038: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D8303C: CC404019 1C66B351
	ds_load_b128 v[89:92], v97 offset:4352                     // 000000D83044: DBFC1100 59000061
	ds_load_b128 v[93:96], v97 offset:4368                     // 000000D8304C: DBFC1110 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D83054: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D83058: CC404011 1C46B351
	ds_load_b128 v[89:92], v97 offset:8704                     // 000000D83060: DBFC2200 59000061
	ds_load_b128 v[93:96], v97 offset:8720                     // 000000D83068: DBFC2210 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D83070: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D83074: CC404009 1C26B351
	ds_load_b128 v[89:92], v97 offset:13056                    // 000000D8307C: DBFC3300 59000061
	ds_load_b128 v[93:96], v97 offset:13072                    // 000000D83084: DBFC3310 5D000061
	s_waitcnt lgkmcnt(0)                                       // 000000D8308C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D83090: CC404001 1C06B351
	v_and_b32_e32 v81, 0xffff, v51                             // 000000D83098: 36A266FF 0000FFFF
	.long 0xd73d0033                                           // 000000D830A0: D73D0033
	v_cndmask_b32_e32 v1, v63, v53, vcc_lo                     // 000000D830A4: 02026B3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D830A8: BF870112
	.long 0xd72c0034                                           // 000000D830AC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D830B0: 0202A2FF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000D830B8: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D830C0: BF870191
	.long 0xd72c0033                                           // 000000D830C4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D830C8: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D830D0: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D830DC: BF870191
	v_and_b32_e32 v52, 0xffff, v52                             // 000000D830E0: 366868FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D830E8: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D830F4: BF870091
	v_lshl_or_b32 v51, v51, 16, v52                            // 000000D830F8: D6560033 04D12133
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D83100: CC0E0033 0BFC1B33 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8310C: BF870091
	v_mov_b32_e32 v52, v51                                     // 000000D83110: 7E680333
	v_permlanex16_b32 v52, v52, s21, 0xfedcba98                // 000000D83114: D65C0034 03FC2B34 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D83120: BF8700B1
	v_cndmask_b32_e64 v81, v52, v51, s3                        // 000000D83124: D5010051 000E6734
	v_cndmask_b32_e64 v85, v51, v52, s3                        // 000000D8312C: D5010055 000E6933
	.long 0xd73d0033                                           // 000000D83134: D73D0033
	v_cndmask_b32_e32 v1, v64, v53, vcc_lo                     // 000000D83138: 02026B40
	v_and_b32_e32 v82, 0xffff, v51                             // 000000D8313C: 36A466FF 0000FFFF
	.long 0xd73d0033                                           // 000000D83144: D73D0033
	v_cndmask_b32_e32 v1, v65, v53, vcc_lo                     // 000000D83148: 02026B41
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8314C: BF870112
	.long 0xd72c0034                                           // 000000D83150: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D83154: 0202A4FF 83DCD12D
	v_and_b32_e32 v51, 0xffff, v51                             // 000000D8315C: 366666FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83164: BF870191
	.long 0xd72c0033                                           // 000000D83168: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D8316C: 020266FF 83DCD12D
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D83174: D6220034 03FD0134 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83180: BF870191
	v_and_b32_e32 v52, 0xffff, v52                             // 000000D83184: 366868FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D8318C: D6220033 03FD0133 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83198: BF870091
	v_lshl_or_b32 v51, v51, 16, v52                            // 000000D8319C: D6560033 04D12133
	v_pk_fma_f16 v51, v51, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D831A4: CC0E0033 0BFC1B33 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D831B0: BF870091
	v_mov_b32_e32 v52, v51                                     // 000000D831B4: 7E680333
	v_permlanex16_b32 v52, v52, s21, 0xfedcba98                // 000000D831B8: D65C0034 03FC2B34 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D831C4: BF8700B1
	v_cndmask_b32_e64 v82, v52, v51, s3                        // 000000D831C8: D5010052 000E6734
	v_cndmask_b32_e64 v86, v51, v52, s3                        // 000000D831D0: D5010056 000E6933
	v_bfe_u32 v51, v49, 8, 16                                  // 000000D831D8: D6100033 02411131
	.long 0xd72c0033                                           // 000000D831E0: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D831E4: 020266FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D831EC: BF870091
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D831F0: D6220033 03FD0133 00006400
	v_lshl_or_b32 v50, v51, 16, v50                            // 000000D831FC: D6560032 04C92133
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83204: BF870091
	v_pk_fma_f16 v50, v50, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D83208: CC0E0032 0BFC1B32 0000C931
	v_mov_b32_e32 v51, v50                                     // 000000D83214: 7E660332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83218: BF870091
	v_permlanex16_b32 v51, v51, s21, 0xfedcba98                // 000000D8321C: D65C0033 03FC2B33 FEDCBA98
	v_cndmask_b32_e64 v83, v51, v50, s3                        // 000000D83228: D5010053 000E6533
	v_cndmask_b32_e64 v87, v50, v51, s3                        // 000000D83230: D5010057 000E6732
	v_and_b32_e32 v50, 0xffff, v49                             // 000000D83238: 366462FF 0000FFFF
	v_bfe_u32 v49, v49, 4, 16                                  // 000000D83240: D6100031 02410931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83248: BF870112
	.long 0xd72c0032                                           // 000000D8324C: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000D83250: 020264FF 83DCD12D
	.long 0xd72c0031                                           // 000000D83258: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000D8325C: 020262FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83264: BF870112
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D83268: D6220032 03FD0132 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000D83274: D6220031 03FD0131 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83280: BF870092
	v_lshlrev_b32_e32 v50, 16, v50                             // 000000D83284: 30646490
	v_and_or_b32 v49, 0xffff, v49, v50                         // 000000D83288: D6570031 04CA62FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83294: BF870091
	v_pk_fma_f16 v49, v49, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D83298: CC0E0031 0BFC1B31 0000C931
	v_mov_b32_e32 v50, v49                                     // 000000D832A4: 7E640331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D832A8: BF870091
	v_permlanex16_b32 v50, v50, s21, 0xfedcba98                // 000000D832AC: D65C0032 03FC2B32 FEDCBA98
	v_cndmask_b32_e64 v84, v50, v49, s3                        // 000000D832B8: D5010054 000E6332
	v_cndmask_b32_e64 v88, v49, v50, s3                        // 000000D832C0: D5010058 000E6531
	v_add_nc_u32_e32 v49, s29, v80                             // 000000D832C8: 4A62A01D
	ds_load_b128 v[89:92], v49                                 // 000000D832CC: DBFC0000 59000031
	ds_load_b128 v[93:96], v49 offset:16                       // 000000D832D4: DBFC0010 5D000031
	s_waitcnt lgkmcnt(0)                                       // 000000D832DC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 000000D832E0: CC404019 1C66B351
	ds_load_b128 v[89:92], v49 offset:4352                     // 000000D832E8: DBFC1100 59000031
	ds_load_b128 v[93:96], v49 offset:4368                     // 000000D832F0: DBFC1110 5D000031
	s_waitcnt lgkmcnt(0)                                       // 000000D832F8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[89:96], v[17:24]// 000000D832FC: CC404011 1C46B351
	ds_load_b128 v[89:92], v49 offset:8704                     // 000000D83304: DBFC2200 59000031
	ds_load_b128 v[93:96], v49 offset:8720                     // 000000D8330C: DBFC2210 5D000031
	s_waitcnt lgkmcnt(0)                                       // 000000D83314: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[89:96], v[9:16]// 000000D83318: CC404009 1C26B351
	ds_load_b128 v[89:92], v49 offset:13056                    // 000000D83320: DBFC3300 59000031
	ds_load_b128 v[93:96], v49 offset:13072                    // 000000D83328: DBFC3310 5D000031
	s_waitcnt lgkmcnt(0)                                       // 000000D83330: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[89:96], v[1:8] // 000000D83334: CC404001 1C06B351
	s_cbranch_vccnz 63881                                      // 000000D8333C: BFA4F989 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x464>
	s_and_b32 s27, s28, exec_lo                                // 000000D83340: 8B1B7E1C
	s_cselect_b32 s27, 0x4400, 0                               // 000000D83344: 981B80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8334C: BF870099
	v_lshl_or_b32 v50, v56, 1, s27                             // 000000D83350: D6560032 006D0338
	v_lshl_add_u32 v49, v59, 1, v50                            // 000000D83358: D6460031 04C9033B
	ds_store_b128 v49, v[33:36]                                // 000000D83360: DB7C0000 00002131
	s_and_saveexec_b32 s27, s0                                 // 000000D83368: BE9B2000
	s_cbranch_execnz 7                                         // 000000D8336C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e8c>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D83370: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000D83374: BE9B2001
	s_cbranch_execnz 10                                        // 000000D83378: BFA6000A <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1ea4>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D8337C: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000D83380: BE9B2002
	s_cbranch_execz 63862                                      // 000000D83384: BFA5F976 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x460>
	s_branch 11                                                // 000000D83388: BFA0000B <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1eb8>
	v_add_nc_u32_e32 v50, v50, v60                             // 000000D8338C: 4A647932
	ds_store_b128 v50, v[37:40]                                // 000000D83390: DB7C0000 00002532
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D83398: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000D8339C: BE9B2001
	s_cbranch_execz 65526                                      // 000000D833A0: BFA5FFF6 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e7c>
	ds_store_b128 v49, v[41:44] offset:8704                    // 000000D833A4: DB7C2200 00002931
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D833AC: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000D833B0: BE9B2002
	s_cbranch_execz 63850                                      // 000000D833B4: BFA5F96A <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x460>
	ds_store_b128 v49, v[45:48] offset:13056                   // 000000D833B8: DB7C3300 00002D31
	s_branch 63847                                             // 000000D833C0: BFA0F967 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x460>
	s_mul_i32 s0, s16, 0x1400                                  // 000000D833C4: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000D833CC: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000D833D4: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000D833D8: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000D833DC: 84008711
	v_lshrrev_b32_e32 v34, 5, v0                               // 000000D833E0: 32440085
	s_ashr_i32 s1, s0, 31                                      // 000000D833E4: 86019F00
	v_and_b32_e32 v35, 1, v0                                   // 000000D833E8: 36460081
	v_and_b32_e32 v36, 2, v0                                   // 000000D833EC: 36480082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D833F0: 84848100
	v_lshrrev_b32_e32 v39, 2, v57                              // 000000D833F4: 324E7282
	s_add_u32 s12, s2, s4                                      // 000000D833F8: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D833FC: 820D0503
	.long 0xd44a0003                                           // 000000D83400: D44A0003
	v_cndmask_b32_e32 v1, 0, v35, vcc_lo                       // 000000D83404: 02024680
	v_lshlrev_b32_e32 v35, 6, v34                              // 000000D83408: 30464486
	.long 0xd44a0002                                           // 000000D8340C: D44A0002
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 000000D83410: 02024880
	v_and_b32_e32 v36, 4, v0                                   // 000000D83414: 36480084
	v_and_b32_e32 v37, 8, v0                                   // 000000D83418: 364A0088
	v_lshlrev_b32_e32 v33, 2, v57                              // 000000D8341C: 30427282
	v_mad_u32_u24 v35, 0x210, v58, v35                         // 000000D83420: D60B0023 048E74FF 00000210
	v_and_b32_e32 v38, 16, v0                                  // 000000D8342C: 364C0090
	.long 0xd44a0001                                           // 000000D83430: D44A0001
	v_cndmask_b32_e32 v1, 0, v36, vcc_lo                       // 000000D83434: 02024880
	v_lshlrev_b32_e32 v36, 3, v57                              // 000000D83438: 30487283
	.long 0xd44a0000                                           // 000000D8343C: D44A0000
	v_cndmask_b32_e32 v1, 0, v37, vcc_lo                       // 000000D83440: 02024A80
	v_and_or_b32 v35, v39, 4, v35                              // 000000D83444: D6570023 048D0927
	ds_store_2addr_b32 v35, v25, v26 offset1:2                 // 000000D8344C: D8380200 001A1923
	ds_store_2addr_b32 v35, v27, v28 offset0:4 offset1:6       // 000000D83454: D8380604 001C1B23
	ds_store_2addr_b32 v35, v29, v30 offset0:8 offset1:10      // 000000D8345C: D8380A08 001E1D23
	.long 0xd7001524                                           // 000000D83464: D7001524
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000D83468: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8346C: BF8701A1
	v_add_co_ci_u32_e64 v37, null, s7, 0, s21                  // 000000D83470: D5207C25 00550007
	v_mul_u32_u24_e32 v28, 0x210, v34                          // 000000D83478: 163844FF 00000210
	.long 0xd7000419                                           // 000000D83480: D7000419
	v_cndmask_b32_e32 v0, v36, v4, vcc_lo                      // 000000D83484: 02000924
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D83488: BF870001
	v_add_co_ci_u32_e64 v26, null, s5, v37, s4                 // 000000D8348C: D5207C1A 00124A05
	v_lshlrev_b32_e32 v27, 1, v33                              // 000000D83494: 30364281
	s_mov_b32 s5, exec_lo                                      // 000000D83498: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v38                            // 000000D8349C: 7C944C80
	ds_store_2addr_b32 v35, v31, v32 offset0:12 offset1:14     // 000000D834A0: D8380E0C 00201F23
	s_waitcnt lgkmcnt(0)                                       // 000000D834A8: BF89FC07
	s_barrier                                                  // 000000D834AC: BFBD0000
	buffer_gl0_inv                                             // 000000D834B0: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D834B8: D4C4007E
	v_cndmask_b32_e32 v1, s19, v34, vcc_lo                     // 000000D834BC: 02024413
	s_cbranch_execz 200                                        // 000000D834C0: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x22e4>
	global_load_b64 v[36:37], v27, s[12:13]                    // 000000D834C4: DC560000 240C001B
	v_lshl_add_u32 v29, v33, 2, v28                            // 000000D834CC: D646001D 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000D834D4: BE8400FF 76543210
	ds_load_b128 v[29:32], v29                                 // 000000D834DC: DBFC0000 1D00001D
	s_waitcnt lgkmcnt(0)                                       // 000000D834E4: BF89FC07
	v_dual_add_f32 v38, v29, v30 :: v_dual_add_f32 v39, v31, v32// 000000D834E8: C9083D1D 2626411F
	v_dual_sub_f32 v29, v29, v30 :: v_dual_sub_f32 v30, v31, v32// 000000D834F0: C94A3D1D 1D1E411F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D834F8: BF870112
	v_sub_f32_e32 v32, v38, v39                                // 000000D834FC: 08404F26
	v_dual_add_f32 v31, v38, v39 :: v_dual_add_f32 v38, v29, v30// 000000D83500: C9084F26 1F263D1D
	v_sub_f32_e32 v29, v29, v30                                // 000000D83508: 083A3D1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8350C: BF870223
	v_mov_b32_dpp v39, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83510: 7E4E02FA FF016120
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000D83518: D5010020 200E4120
	v_mov_b32_dpp v30, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83520: 7E3C02FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D83528: D501001F 200E3F1F
	v_mov_b32_dpp v40, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83530: 7E5002FA FF016126
	v_mov_b32_dpp v41, v29 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83538: 7E5202FA FF01611D
	v_cndmask_b32_e64 v29, -v29, v29, s3                       // 000000D83540: D501001D 200E3B1D
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D83548: D5010026 200E4D26
	v_add_f32_e32 v32, v32, v39                                // 000000D83550: 06404F20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83554: BF870193
	v_dual_add_f32 v30, v31, v30 :: v_dual_add_f32 v29, v29, v41// 000000D83558: C9083D1F 1E1C531D
	v_add_f32_e32 v31, v38, v40                                // 000000D83560: 063E5126
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D83564: BF870223
	v_mov_b32_dpp v38, v32 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83568: 7E4C02FA FF016220
	v_cndmask_b32_e64 v32, -v32, v32, s2                       // 000000D83570: D5010020 200A4120
	v_mov_b32_dpp v39, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83578: 7E4E02FA FF01621E
	v_mov_b32_dpp v40, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83580: 7E5002FA FF01621D
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D83588: D501001D 200A3B1D
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D83590: D501001E 200A3D1E
	v_add_f32_e32 v32, v32, v38                                // 000000D83598: 06404D20
	v_mov_b32_dpp v38, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8359C: 7E4C02FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D835A4: D501001F 200A3F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D835AC: BF870214
	v_dual_add_f32 v29, v29, v40 :: v_dual_add_f32 v30, v30, v39// 000000D835B0: C908511D 1D1E4F1E
	v_mov_b32_dpp v39, v32 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D835B8: 7E4E02FA FF016420
	v_cndmask_b32_e64 v32, -v32, v32, s1                       // 000000D835C0: D5010020 20064120
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D835C8: BF870214
	v_add_f32_e32 v31, v31, v38                                // 000000D835CC: 063E4D1F
	v_mov_b32_dpp v38, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D835D0: 7E4C02FA FF01641D
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D835D8: D501001D 20063B1D
	v_mov_b32_dpp v40, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D835E0: 7E5002FA FF01641E
	v_add_f32_e32 v32, v32, v39                                // 000000D835E8: 06404F20
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D835EC: D501001E 20063D1E
	v_mov_b32_dpp v39, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D835F4: 7E4E02FA FF01641F
	v_add_f32_e32 v29, v29, v38                                // 000000D835FC: 063A4D1D
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D83600: D501001F 20063F1F
	v_mov_b32_dpp v38, v32 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83608: 7E4C02FA FF016820
	v_cndmask_b32_e64 v32, -v32, v32, s0                       // 000000D83610: D5010020 20024120
	v_add_f32_e32 v30, v30, v40                                // 000000D83618: 063C511E
	v_mov_b32_dpp v40, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8361C: 7E5002FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D83624: D501001D 20023B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8362C: BF870214
	v_dual_add_f32 v31, v31, v39 :: v_dual_add_f32 v32, v32, v38// 000000D83630: C9084F1F 1F204D20
	v_mov_b32_dpp v38, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83638: 7E4C02FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D83640: D501001E 20023D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83648: BF870214
	v_add_f32_e32 v29, v29, v40                                // 000000D8364C: 063A511D
	v_mov_b32_dpp v40, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83650: 7E5002FA FF01681F
	v_mov_b32_e32 v39, v32                                     // 000000D83658: 7E4E0320
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000D8365C: D501001F 20023F1F
	v_cndmask_b32_e64 v32, -v32, v32, vcc_lo                   // 000000D83664: D5010020 21AA4120
	v_mov_b32_e32 v42, v29                                     // 000000D8366C: 7E54031D
	v_add_f32_e32 v30, v30, v38                                // 000000D83670: 063C4D1E
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000D83674: D65C0027 03FC0927 FEDCBA98
	v_add_f32_e32 v31, v31, v40                                // 000000D83680: 063E511F
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000D83684: D501001D 21AA3B1D
	v_permlanex16_b32 v42, v42, s4, 0xfedcba98                 // 000000D8368C: D65C002A 03FC092A FEDCBA98
	v_mov_b32_e32 v38, v30                                     // 000000D83698: 7E4C031E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8369C: BF870224
	v_dual_add_f32 v32, v32, v39 :: v_dual_mov_b32 v39, v31    // 000000D836A0: C9104F20 2026011F
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000D836A8: D501001E 21AA3D1E
	v_add_f32_e32 v29, v29, v42                                // 000000D836B0: 063A551D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D836B4: BF870214
	v_permlanex16_b32 v38, v38, s4, 0xfedcba98                 // 000000D836B8: D65C0026 03FC0926 FEDCBA98
	v_mul_f32_e32 v32, 0x3db504f3, v32                         // 000000D836C4: 104040FF 3DB504F3
	.long 0x7f523880                                           // 000000D836CC: 7F523880
	v_cndmask_b32_e64 v31, -v31, v31, vcc_lo                   // 000000D836D0: D501001F 21AA3F1F
	v_permlanex16_b32 v39, v39, s4, 0xfedcba98                 // 000000D836D8: D65C0027 03FC0927 FEDCBA98
	v_dual_mul_f32 v29, 0x3db504f3, v29 :: v_dual_add_f32 v30, v30, v38// 000000D836E4: C8C83AFF 1D1E4D1E 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D836F0: BF870114
	.long 0x7f4c39a9                                           // 000000D836F4: 7F4C39A9
	v_dual_add_f32 v31, v31, v39 :: v_dual_mul_f32 v30, 0x3db504f3, v30// 000000D836F8: C9064F1F 1F1E3CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D83704: BF870001
	v_mul_f32_e32 v31, 0x3db504f3, v31                         // 000000D83708: 103E3EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D83710: BF8903F7
	v_fma_mix_f32 v32, v37, v32, neg(0) op_sel_hi:[1,0,0]      // 000000D83714: CC200020 8A024125
	v_fma_mix_f32 v29, v37, v29, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8371C: CC20081D 8A023B25
	.long 0x7f4a39a9                                           // 000000D83724: 7F4A39A9
	v_fma_mix_f32 v30, v36, v30, neg(0) op_sel_hi:[1,0,0]      // 000000D83728: CC20001E 8A023D24
	v_fma_mix_f32 v31, v36, v31, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D83730: CC20081F 8A023F24
	.long 0x7e4c39a0                                           // 000000D83738: 7E4C39A0
	.long 0x7e4a399d                                           // 000000D8373C: 7E4A399D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83740: BF870193
	v_bfe_u32 v39, v31, 16, 1                                  // 000000D83744: D6100027 0205211F
	v_and_b32_e32 v38, 1, v38                                  // 000000D8374C: 364C4C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D83750: BF870223
	v_and_b32_e32 v36, 1, v37                                  // 000000D83754: 36484A81
	v_bfe_u32 v37, v30, 16, 1                                  // 000000D83758: D6100025 0205211E
	v_add3_u32 v31, v31, v39, 0x7fff                           // 000000D83760: D655001F 03FE4F1F 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D8376C: BF870244
	v_add3_u32 v32, v32, v38, 0x7fff                           // 000000D83770: D6550020 03FE4D20 00007FFF
	.long 0x7f4c39a9                                           // 000000D8377C: 7F4C39A9
	v_add3_u32 v29, v29, v36, 0x7fff                           // 000000D83780: D655001D 03FE491D 00007FFF
	v_add3_u32 v30, v30, v37, 0x7fff                           // 000000D8378C: D655001E 03FE4B1E 00007FFF
	.long 0x7e4c39a0                                           // 000000D83798: 7E4C39A0
	v_add_nc_u32_e32 v32, s18, v34                             // 000000D8379C: 4A404412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D837A0: BF870214
	v_and_b32_e32 v36, 0xffff0000, v29                         // 000000D837A4: 36483AFF FFFF0000
	.long 0x7e52399e                                           // 000000D837AC: 7E52399E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D837B0: BF870214
	v_and_b32_e32 v37, 0xffff, v38                             // 000000D837B4: 364A4CFF 0000FFFF
	v_mad_i64_i32 v[29:30], null, 0x1400, v32, v[25:26]        // 000000D837BC: D6FF7C1D 046640FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D837C8: BF870193
	v_and_or_b32 v31, 0xffff0000, v31, v41                     // 000000D837CC: D657001F 04A63EFF FFFF0000
	v_or_b32_e32 v32, v36, v37                                 // 000000D837D8: 38404B24
	global_store_b64 v[29:30], v[31:32], off                   // 000000D837DC: DC6E0000 007C1F1D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D837E4: 8C7E057E
	v_or_b32_e32 v30, 8, v34                                   // 000000D837E8: 383C4488
	s_mov_b32 s5, exec_lo                                      // 000000D837EC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D837F0: BF870001
	v_mul_u32_u24_e32 v29, 0x210, v30                          // 000000D837F4: 163A3CFF 00000210
	.long 0xd4c4007e                                           // 000000D837FC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000D83800: 02023C13
	s_cbranch_execz 199                                        // 000000D83804: BFA500C7 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2624>
	global_load_b64 v[31:32], v27, s[12:13]                    // 000000D83808: DC560000 1F0C001B
	v_lshl_add_u32 v36, v33, 2, v29                            // 000000D83810: D6460024 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000D83818: BE8400FF 76543210
	v_add_nc_u32_e32 v30, s18, v30                             // 000000D83820: 4A3C3C12
	ds_load_b128 v[36:39], v36                                 // 000000D83824: DBFC0000 24000024
	s_waitcnt lgkmcnt(0)                                       // 000000D8382C: BF89FC07
	v_dual_add_f32 v40, v36, v37 :: v_dual_add_f32 v41, v38, v39// 000000D83830: C9084B24 28284F26
	v_dual_sub_f32 v36, v36, v37 :: v_dual_sub_f32 v37, v38, v39// 000000D83838: C94A4B24 24244F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D83840: BF8701A2
	v_sub_f32_e32 v39, v40, v41                                // 000000D83844: 084E5328
	v_add_f32_e32 v38, v40, v41                                // 000000D83848: 064C5328
	v_add_f32_e32 v40, v36, v37                                // 000000D8384C: 06504B24
	v_sub_f32_e32 v36, v36, v37                                // 000000D83850: 08484B24
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D83854: BF870004
	v_mov_b32_dpp v41, v39 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83858: 7E5202FA FF016127
	v_cndmask_b32_e64 v39, -v39, v39, s3                       // 000000D83860: D5010027 200E4F27
	v_mov_b32_dpp v37, v38 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83868: 7E4A02FA FF016126
	v_cndmask_b32_e64 v38, -v38, v38, s3                       // 000000D83870: D5010026 200E4D26
	v_mov_b32_dpp v42, v40 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83878: 7E5402FA FF016128
	v_mov_b32_dpp v43, v36 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83880: 7E5602FA FF016124
	v_cndmask_b32_e64 v36, -v36, v36, s3                       // 000000D83888: D5010024 200E4924
	v_cndmask_b32_e64 v40, -v40, v40, s3                       // 000000D83890: D5010028 200E5128
	v_add_f32_e32 v39, v39, v41                                // 000000D83898: 064E5327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8389C: BF870193
	v_dual_add_f32 v37, v38, v37 :: v_dual_add_f32 v36, v36, v43// 000000D838A0: C9084B26 25245724
	v_add_f32_e32 v38, v40, v42                                // 000000D838A8: 064C5528
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D838AC: BF870223
	v_mov_b32_dpp v40, v39 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D838B0: 7E5002FA FF016227
	v_cndmask_b32_e64 v39, -v39, v39, s2                       // 000000D838B8: D5010027 200A4F27
	v_mov_b32_dpp v41, v37 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D838C0: 7E5202FA FF016225
	v_mov_b32_dpp v42, v36 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D838C8: 7E5402FA FF016224
	v_cndmask_b32_e64 v36, -v36, v36, s2                       // 000000D838D0: D5010024 200A4924
	v_cndmask_b32_e64 v37, -v37, v37, s2                       // 000000D838D8: D5010025 200A4B25
	v_add_f32_e32 v39, v39, v40                                // 000000D838E0: 064E5127
	v_mov_b32_dpp v40, v38 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D838E4: 7E5002FA FF016226
	v_cndmask_b32_e64 v38, -v38, v38, s2                       // 000000D838EC: D5010026 200A4D26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D838F4: BF870214
	v_dual_add_f32 v36, v36, v42 :: v_dual_add_f32 v37, v37, v41// 000000D838F8: C9085524 24245325
	v_mov_b32_dpp v41, v39 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83900: 7E5202FA FF016427
	v_cndmask_b32_e64 v39, -v39, v39, s1                       // 000000D83908: D5010027 20064F27
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83910: BF870214
	v_add_f32_e32 v38, v38, v40                                // 000000D83914: 064C5126
	v_mov_b32_dpp v40, v36 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83918: 7E5002FA FF016424
	v_cndmask_b32_e64 v36, -v36, v36, s1                       // 000000D83920: D5010024 20064924
	v_mov_b32_dpp v42, v37 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83928: 7E5402FA FF016425
	v_add_f32_e32 v39, v39, v41                                // 000000D83930: 064E5327
	v_cndmask_b32_e64 v37, -v37, v37, s1                       // 000000D83934: D5010025 20064B25
	v_mov_b32_dpp v41, v38 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8393C: 7E5202FA FF016426
	v_add_f32_e32 v36, v36, v40                                // 000000D83944: 06485124
	v_cndmask_b32_e64 v38, -v38, v38, s1                       // 000000D83948: D5010026 20064D26
	v_mov_b32_dpp v40, v39 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83950: 7E5002FA FF016827
	v_cndmask_b32_e64 v39, -v39, v39, s0                       // 000000D83958: D5010027 20024F27
	v_add_f32_e32 v37, v37, v42                                // 000000D83960: 064A5525
	v_mov_b32_dpp v42, v36 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83964: 7E5402FA FF016824
	v_cndmask_b32_e64 v36, -v36, v36, s0                       // 000000D8396C: D5010024 20024924
	.long 0x7f563880                                           // 000000D83974: 7F563880
	v_dual_add_f32 v39, v39, v40 :: v_dual_add_f32 v38, v38, v41// 000000D83978: C9085127 27265326
	v_mov_b32_dpp v40, v37 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83980: 7E5002FA FF016825
	v_cndmask_b32_e64 v37, -v37, v37, s0                       // 000000D83988: D5010025 20024B25
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D83990: BF870003
	v_dual_add_f32 v36, v36, v42 :: v_dual_mov_b32 v41, v39    // 000000D83994: C9105524 24280127
	v_cndmask_b32_e64 v39, -v39, v39, vcc_lo                   // 000000D8399C: D5010027 21AA4F27
	v_mov_b32_dpp v42, v38 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D839A4: 7E5402FA FF016826
	v_cndmask_b32_e64 v38, -v38, v38, s0                       // 000000D839AC: D5010026 20024D26
	v_add_f32_e32 v37, v37, v40                                // 000000D839B4: 064A5125
	v_permlanex16_b32 v41, v41, s4, 0xfedcba98                 // 000000D839B8: D65C0029 03FC0929 FEDCBA98
	v_mov_b32_e32 v44, v36                                     // 000000D839C4: 7E580324
	v_cndmask_b32_e64 v36, -v36, v36, vcc_lo                   // 000000D839C8: D5010024 21AA4924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D839D0: BF870193
	v_dual_add_f32 v39, v39, v41 :: v_dual_add_f32 v38, v38, v42// 000000D839D4: C9085327 27265526
	v_permlanex16_b32 v44, v44, s4, 0xfedcba98                 // 000000D839DC: D65C002C 03FC092C FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D839E8: BF870192
	v_dual_mul_f32 v39, 0x3db504f3, v39 :: v_dual_mov_b32 v40, v37// 000000D839EC: C8D04EFF 27280125 3DB504F3
	v_mov_b32_e32 v41, v38                                     // 000000D839F8: 7E520326
	v_cndmask_b32_e64 v37, -v37, v37, vcc_lo                   // 000000D839FC: D5010025 21AA4B25
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D83A04: BF870244
	v_add_f32_e32 v36, v36, v44                                // 000000D83A08: 06485924
	v_cndmask_b32_e64 v38, -v38, v38, vcc_lo                   // 000000D83A0C: D5010026 21AA4D26
	v_permlanex16_b32 v40, v40, s4, 0xfedcba98                 // 000000D83A14: D65C0028 03FC0928 FEDCBA98
	v_permlanex16_b32 v41, v41, s4, 0xfedcba98                 // 000000D83A20: D65C0029 03FC0929 FEDCBA98
	v_mul_f32_e32 v36, 0x3db504f3, v36                         // 000000D83A2C: 104848FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D83A34: BF870122
	v_dual_add_f32 v37, v37, v40 :: v_dual_add_f32 v38, v38, v41// 000000D83A38: C9085125 25265326
	.long 0x7f5039ab                                           // 000000D83A40: 7F5039AB
	v_mul_f32_e32 v38, 0x3db504f3, v38                         // 000000D83A44: 104C4CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D83A4C: BF8903F7
	v_fma_mix_f32 v39, v32, v39, neg(0) op_sel_hi:[1,0,0]      // 000000D83A50: CC200027 8A024F20
	v_fma_mix_f32 v32, v32, v36, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D83A58: CC200820 8A024920
	v_mul_f32_e32 v36, 0x3db504f3, v37                         // 000000D83A60: 10484AFF 3DB504F3
	.long 0x7f4a39ab                                           // 000000D83A68: 7F4A39AB
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83A6C: BF870214
	.long 0x7e5039a7                                           // 000000D83A70: 7E5039A7
	.long 0x7e4a39a0                                           // 000000D83A74: 7E4A39A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D83A78: BF870224
	v_fma_mix_f32 v36, v31, v36, neg(0) op_sel_hi:[1,0,0]      // 000000D83A7C: CC200024 8A02491F
	v_fma_mix_f32 v31, v31, v38, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D83A84: CC20081F 8A024D1F
	v_and_b32_e32 v40, 1, v40                                  // 000000D83A8C: 36505081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83A90: BF870194
	v_and_b32_e32 v37, 1, v37                                  // 000000D83A94: 364A4A81
	v_bfe_u32 v41, v31, 16, 1                                  // 000000D83A98: D6100029 0205211F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D83AA0: BF870243
	v_add3_u32 v38, v39, v40, 0x7fff                           // 000000D83AA4: D6550026 03FE5127 00007FFF
	v_bfe_u32 v39, v36, 16, 1                                  // 000000D83AB0: D6100027 02052124
	.long 0x7f5039ab                                           // 000000D83AB8: 7F5039AB
	v_add3_u32 v32, v32, v37, 0x7fff                           // 000000D83ABC: D6550020 03FE4B20 00007FFF
	.long 0x7e5039a6                                           // 000000D83AC8: 7E5039A6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D83ACC: BF870224
	v_add3_u32 v36, v36, v39, 0x7fff                           // 000000D83AD0: D6550024 03FE4F24 00007FFF
	v_add3_u32 v38, v31, v41, 0x7fff                           // 000000D83ADC: D6550026 03FE531F 00007FFF
	v_and_b32_e32 v32, 0xffff0000, v32                         // 000000D83AE8: 364040FF FFFF0000
	v_mad_i64_i32 v[30:31], null, 0x1400, v30, v[25:26]        // 000000D83AF0: D6FF7C1E 04663CFF 00001400
	v_and_b32_e32 v37, 0xffff, v40                             // 000000D83AFC: 364A50FF 0000FFFF
	.long 0x7e5639a4                                           // 000000D83B04: 7E5639A4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83B08: BF870112
	v_or_b32_e32 v37, v32, v37                                 // 000000D83B0C: 384A4B20
	v_and_or_b32 v36, 0xffff0000, v38, v43                     // 000000D83B10: D6570024 04AE4CFF FFFF0000
	global_store_b64 v[30:31], v[36:37], off                   // 000000D83B1C: DC6E0000 007C241E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D83B24: 8C7E057E
	v_or_b32_e32 v30, 16, v34                                  // 000000D83B28: 383C4490
	s_mov_b32 s5, exec_lo                                      // 000000D83B2C: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D83B30: BC7C0000
	s_barrier                                                  // 000000D83B34: BFBD0000
	buffer_gl0_inv                                             // 000000D83B38: E0AC0000 00000000
	ds_store_2addr_b32 v35, v17, v18 offset1:2                 // 000000D83B40: D8380200 00121123
	ds_store_2addr_b32 v35, v19, v20 offset0:4 offset1:6       // 000000D83B48: D8380604 00141323
	ds_store_2addr_b32 v35, v21, v22 offset0:8 offset1:10      // 000000D83B50: D8380A08 00161523
	ds_store_2addr_b32 v35, v23, v24 offset0:12 offset1:14     // 000000D83B58: D8380E0C 00181723
	s_waitcnt lgkmcnt(0)                                       // 000000D83B60: BF89FC07
	s_barrier                                                  // 000000D83B64: BFBD0000
	buffer_gl0_inv                                             // 000000D83B68: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D83B70: D4C4007E
	v_cndmask_b32_e32 v1, s19, v30, vcc_lo                     // 000000D83B74: 02023C13
	s_cbranch_execz 201                                        // 000000D83B78: BFA500C9 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x29a0>
	global_load_b64 v[21:22], v27, s[12:13]                    // 000000D83B7C: DC560000 150C001B
	v_lshl_add_u32 v17, v33, 2, v28                            // 000000D83B84: D6460011 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000D83B8C: BE8400FF 76543210
	ds_load_b128 v[17:20], v17                                 // 000000D83B94: DBFC0000 11000011
	s_waitcnt lgkmcnt(0)                                       // 000000D83B9C: BF89FC07
	v_dual_add_f32 v23, v17, v18 :: v_dual_add_f32 v24, v19, v20// 000000D83BA0: C9082511 17182913
	v_dual_sub_f32 v17, v17, v18 :: v_dual_sub_f32 v18, v19, v20// 000000D83BA8: C94A2511 11122913
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83BB0: BF870112
	v_add_f32_e32 v19, v23, v24                                // 000000D83BB4: 06263117
	v_dual_sub_f32 v20, v23, v24 :: v_dual_add_f32 v23, v17, v18// 000000D83BB8: C9483117 14162511
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D83BC0: BF870001
	v_mov_b32_dpp v24, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83BC4: 7E3002FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D83BCC: D5010014 200E2914
	v_sub_f32_e32 v17, v17, v18                                // 000000D83BD4: 08222511
	v_mov_b32_dpp v18, v19 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83BD8: 7E2402FA FF016113
	v_cndmask_b32_e64 v19, -v19, v19, s3                       // 000000D83BE0: D5010013 200E2713
	v_mov_b32_dpp v31, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83BE8: 7E3E02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D83BF0: D5010017 200E2F17
	v_add_f32_e32 v20, v20, v24                                // 000000D83BF8: 06283114
	v_mov_b32_dpp v32, v17 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83BFC: 7E4002FA FF016111
	v_cndmask_b32_e64 v17, -v17, v17, s3                       // 000000D83C04: D5010011 200E2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83C0C: BF870091
	v_dual_add_f32 v18, v19, v18 :: v_dual_add_f32 v17, v17, v32// 000000D83C10: C9082513 12104111
	v_mov_b32_dpp v24, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83C18: 7E3002FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D83C20: D5010012 200A2512
	v_add_f32_e32 v19, v23, v31                                // 000000D83C28: 06263F17
	v_mov_b32_dpp v23, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83C2C: 7E2E02FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D83C34: D5010014 200A2914
	v_mov_b32_dpp v31, v17 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83C3C: 7E3E02FA FF016211
	v_cndmask_b32_e64 v17, -v17, v17, s2                       // 000000D83C44: D5010011 200A2311
	v_add_f32_e32 v18, v18, v24                                // 000000D83C4C: 06243112
	.long 0x7f403880                                           // 000000D83C50: 7F403880
	v_add_f32_e32 v20, v20, v23                                // 000000D83C54: 06282F14
	v_mov_b32_dpp v23, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83C58: 7E2E02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D83C60: D5010013 200A2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D83C68: BF870233
	v_mov_b32_dpp v24, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83C6C: 7E3002FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D83C74: D5010014 20062914
	v_add_f32_e32 v17, v17, v31                                // 000000D83C7C: 06223F11
	v_add_f32_e32 v19, v19, v23                                // 000000D83C80: 06262F13
	v_mov_b32_dpp v31, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83C84: 7E3E02FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D83C8C: D5010012 20062512
	v_add_f32_e32 v20, v20, v24                                // 000000D83C94: 06283114
	v_mov_b32_dpp v23, v17 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83C98: 7E2E02FA FF016411
	v_cndmask_b32_e64 v17, -v17, v17, s1                       // 000000D83CA0: D5010011 20062311
	v_mov_b32_dpp v24, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83CA8: 7E3002FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D83CB0: D5010013 20062713
	v_add_f32_e32 v18, v18, v31                                // 000000D83CB8: 06243F12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D83CBC: BF8700B4
	v_add_f32_e32 v17, v17, v23                                // 000000D83CC0: 06222F11
	v_mov_b32_dpp v23, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83CC4: 7E2E02FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D83CCC: D5010014 20022914
	v_dual_add_f32 v19, v19, v24 :: v_dual_add_f32 v20, v20, v23// 000000D83CD4: C9083113 13142F14
	v_mov_b32_dpp v23, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83CDC: 7E2E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D83CE4: D5010012 20022512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83CEC: BF870091
	v_add_f32_e32 v18, v18, v23                                // 000000D83CF0: 06242F12
	v_dual_mov_b32 v23, v18 :: v_dual_mov_b32 v24, v20         // 000000D83CF4: CA100112 17180114
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D83CFC: D5010014 21AA2914
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83D04: BF870192
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D83D08: D65C0017 03FC0917 FEDCBA98
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D83D14: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D83D20: BF8700B1
	v_add_f32_e32 v20, v20, v24                                // 000000D83D24: 06283114
	v_mov_b32_dpp v31, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83D28: 7E3E02FA FF016811
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000D83D30: D5010011 20022311
	v_dual_mul_f32 v20, 0x3db504f3, v20 :: v_dual_add_f32 v17, v17, v31// 000000D83D38: C8C828FF 14103F11 3DB504F3
	v_mov_b32_dpp v31, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D83D44: 7E3E02FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D83D4C: D5010013 20022713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D83D54: BF870091
	v_add_f32_e32 v19, v19, v31                                // 000000D83D58: 06263F13
	v_mov_b32_e32 v24, v19                                     // 000000D83D5C: 7E300313
	v_mov_b32_e32 v36, v17                                     // 000000D83D60: 7E480311
	v_cndmask_b32_e64 v17, -v17, v17, vcc_lo                   // 000000D83D64: D5010011 21AA2311
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000D83D6C: D5010013 21AA2713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83D74: BF870214
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D83D78: D65C0018 03FC0918 FEDCBA98
	v_permlanex16_b32 v36, v36, s4, 0xfedcba98                 // 000000D83D84: D65C0024 03FC0924 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83D90: BF870112
	v_add_f32_e32 v19, v19, v24                                // 000000D83D94: 06263113
	v_add_f32_e32 v17, v17, v36                                // 000000D83D98: 06224911
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000D83D9C: D5010012 21AA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83DA4: BF870113
	v_mul_f32_e32 v19, 0x3db504f3, v19                         // 000000D83DA8: 102626FF 3DB504F3
	v_dual_mul_f32 v17, 0x3db504f3, v17 :: v_dual_add_f32 v18, v18, v23// 000000D83DB0: C8C822FF 11122F12 3DB504F3
	.long 0x7f2e39a0                                           // 000000D83DBC: 7F2E39A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D83DC0: BF870002
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000D83DC4: 102424FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D83DCC: BF8903F7
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel_hi:[1,0,0]      // 000000D83DD0: CC200014 8A022916
	v_fma_mix_f32 v17, v22, v17, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D83DD8: CC200811 8A022316
	.long 0x7f2c39a0                                           // 000000D83DE0: 7F2C39A0
	v_fma_mix_f32 v18, v21, v18, neg(0) op_sel_hi:[1,0,0]      // 000000D83DE4: CC200012 8A022515
	v_fma_mix_f32 v19, v21, v19, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D83DEC: CC200813 8A022715
	.long 0x7e2e3994                                           // 000000D83DF4: 7E2E3994
	.long 0x7e2c3991                                           // 000000D83DF8: 7E2C3991
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83DFC: BF870193
	v_bfe_u32 v24, v19, 16, 1                                  // 000000D83E00: D6100018 02052113
	v_and_b32_e32 v23, 1, v23                                  // 000000D83E08: 362E2E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D83E0C: BF870223
	v_and_b32_e32 v21, 1, v22                                  // 000000D83E10: 362A2C81
	v_bfe_u32 v22, v18, 16, 1                                  // 000000D83E14: D6100016 02052112
	v_add3_u32 v19, v19, v24, 0x7fff                           // 000000D83E1C: D6550013 03FE3113 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D83E28: BF870244
	v_add3_u32 v20, v20, v23, 0x7fff                           // 000000D83E2C: D6550014 03FE2F14 00007FFF
	.long 0x7f2e39a0                                           // 000000D83E38: 7F2E39A0
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000D83E3C: D6550011 03FE2B11 00007FFF
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000D83E48: D6550012 03FE2D12 00007FFF
	.long 0x7e2e3994                                           // 000000D83E54: 7E2E3994
	v_add_nc_u32_e32 v20, s18, v30                             // 000000D83E58: 4A283C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83E5C: BF870214
	v_and_b32_e32 v21, 0xffff0000, v17                         // 000000D83E60: 362A22FF FFFF0000
	.long 0x7e403992                                           // 000000D83E68: 7E403992
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83E6C: BF870214
	v_and_b32_e32 v22, 0xffff, v23                             // 000000D83E70: 362C2EFF 0000FFFF
	v_mad_i64_i32 v[17:18], null, 0x1400, v20, v[25:26]        // 000000D83E78: D6FF7C11 046628FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D83E84: BF870193
	v_and_or_b32 v19, 0xffff0000, v19, v32                     // 000000D83E88: D6570013 048226FF FFFF0000
	v_or_b32_e32 v20, v21, v22                                 // 000000D83E94: 38282D15
	global_store_b64 v[17:18], v[19:20], off                   // 000000D83E98: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D83EA0: 8C7E057E
	v_or_b32_e32 v17, 24, v34                                  // 000000D83EA4: 38224498
	s_mov_b32 s5, exec_lo                                      // 000000D83EA8: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D83EAC: BF870001
	.long 0xd4c4007e                                           // 000000D83EB0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000D83EB4: 02022213
	s_cbranch_execz 206                                        // 000000D83EB8: BFA500CE <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x2cf4>
	global_load_b64 v[22:23], v27, s[12:13]                    // 000000D83EBC: DC560000 160C001B
	v_lshl_add_u32 v18, v33, 2, v29                            // 000000D83EC4: D6460012 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000D83ECC: BE8400FF 76543210
	v_add_nc_u32_e32 v17, s18, v17                             // 000000D83ED4: 4A222212
	ds_load_b128 v[18:21], v18                                 // 000000D83ED8: DBFC0000 12000012
	s_waitcnt lgkmcnt(0)                                       // 000000D83EE0: BF89FC07
	v_add_f32_e32 v24, v18, v19                                // 000000D83EE4: 06302712
	v_add_f32_e32 v30, v20, v21                                // 000000D83EE8: 063C2B14
	v_dual_sub_f32 v18, v18, v19 :: v_dual_sub_f32 v19, v20, v21// 000000D83EEC: C94A2712 12122B14
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D83EF4: BF8700A2
	v_add_f32_e32 v20, v24, v30                                // 000000D83EF8: 06283D18
	v_sub_f32_e32 v21, v24, v30                                // 000000D83EFC: 082A3D18
	v_mov_b32_dpp v30, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83F00: 7E3C02FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D83F08: D5010015 200E2B15
	v_add_f32_e32 v24, v18, v19                                // 000000D83F10: 06302712
	v_sub_f32_e32 v18, v18, v19                                // 000000D83F14: 08242712
	v_mov_b32_dpp v19, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83F18: 7E2602FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D83F20: D5010014 200E2914
	v_add_f32_e32 v21, v21, v30                                // 000000D83F28: 062A3D15
	v_mov_b32_dpp v31, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83F2C: 7E3E02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D83F34: D5010018 200E3118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83F3C: BF870114
	v_add_f32_e32 v19, v20, v19                                // 000000D83F40: 06262714
	v_add_f32_e32 v20, v24, v31                                // 000000D83F44: 06283F18
	v_mov_b32_dpp v24, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83F48: 7E3002FA FF016215
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D83F50: BF870133
	v_mov_b32_dpp v30, v19 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83F54: 7E3C02FA FF016213
	v_cndmask_b32_e64 v19, -v19, v19, s2                       // 000000D83F5C: D5010013 200A2713
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D83F64: D5010015 200A2B15
	v_add_f32_e32 v19, v19, v30                                // 000000D83F6C: 06263D13
	v_mov_b32_dpp v32, v18 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D83F70: 7E4002FA FF016112
	v_cndmask_b32_e64 v18, -v18, v18, s3                       // 000000D83F78: D5010012 200E2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D83F80: BF870114
	v_add_f32_e32 v21, v21, v24                                // 000000D83F84: 062A3115
	v_add_f32_e32 v18, v18, v32                                // 000000D83F88: 06244112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D83F8C: BF870232
	v_mov_b32_dpp v30, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83F90: 7E3C02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D83F98: D5010015 20062B15
	.long 0x7f403880                                           // 000000D83FA0: 7F403880
	v_mov_b32_dpp v31, v18 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83FA4: 7E3E02FA FF016212
	v_cndmask_b32_e64 v18, -v18, v18, s2                       // 000000D83FAC: D5010012 200A2512
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D83FB4: BF870234
	v_add_f32_e32 v21, v21, v30                                // 000000D83FB8: 062A3D15
	v_mov_b32_dpp v24, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D83FBC: 7E3002FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D83FC4: D5010014 200A2914
	v_add_f32_e32 v18, v18, v31                                // 000000D83FCC: 06243F12
	v_mov_b32_dpp v31, v19 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83FD0: 7E3E02FA FF016413
	v_cndmask_b32_e64 v19, -v19, v19, s1                       // 000000D83FD8: D5010013 20062713
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83FE0: BF870214
	v_add_f32_e32 v20, v20, v24                                // 000000D83FE4: 06283114
	v_mov_b32_dpp v24, v18 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D83FE8: 7E3002FA FF016412
	v_cndmask_b32_e64 v18, -v18, v18, s1                       // 000000D83FF0: D5010012 20062512
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D83FF8: BF870214
	v_add_f32_e32 v19, v19, v31                                // 000000D83FFC: 06263F13
	v_mov_b32_dpp v30, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84000: 7E3C02FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D84008: D5010014 20062914
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D84010: BF8700B4
	v_add_f32_e32 v18, v18, v24                                // 000000D84014: 06243112
	v_mov_b32_dpp v24, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84018: 7E3002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D84020: D5010015 20022B15
	v_add_f32_e32 v21, v21, v24                                // 000000D84028: 062A3115
	v_mov_b32_dpp v24, v19 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8402C: 7E3002FA FF016813
	v_cndmask_b32_e64 v19, -v19, v19, s0                       // 000000D84034: D5010013 20022713
	v_add_f32_e32 v20, v20, v30                                // 000000D8403C: 06283D14
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84040: BF870224
	v_mov_b32_e32 v30, v21                                     // 000000D84044: 7E3C0315
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D84048: D5010015 21AA2B15
	v_add_f32_e32 v19, v19, v24                                // 000000D84050: 06263113
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D84054: BF870113
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D84058: D65C001E 03FC091E FEDCBA98
	v_mov_b32_e32 v24, v19                                     // 000000D84064: 7E300313
	v_cndmask_b32_e64 v19, -v19, v19, vcc_lo                   // 000000D84068: D5010013 21AA2713
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84070: BF870193
	v_add_f32_e32 v21, v21, v30                                // 000000D84074: 062A3D15
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D84078: D65C0018 03FC0918 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D84084: BF870232
	v_mul_f32_e32 v21, 0x3db504f3, v21                         // 000000D84088: 102A2AFF 3DB504F3
	v_mov_b32_dpp v31, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84090: 7E3E02FA FF016812
	v_cndmask_b32_e64 v18, -v18, v18, s0                       // 000000D84098: D5010012 20022512
	v_add_f32_e32 v19, v19, v24                                // 000000D840A0: 06263113
	.long 0x7f3039a0                                           // 000000D840A4: 7F3039A0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D840A8: BF8701B3
	v_add_f32_e32 v18, v18, v31                                // 000000D840AC: 06243F12
	v_mov_b32_dpp v31, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D840B0: 7E3E02FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D840B8: D5010014 20022914
	v_dual_mul_f32 v19, 0x3db504f3, v19 :: v_dual_mov_b32 v36, v18// 000000D840C0: C8D026FF 13240112 3DB504F3
	v_cndmask_b32_e64 v18, -v18, v18, vcc_lo                   // 000000D840CC: D5010012 21AA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D840D4: BF870193
	v_add_f32_e32 v20, v20, v31                                // 000000D840D8: 06283F14
	v_permlanex16_b32 v36, v36, s4, 0xfedcba98                 // 000000D840DC: D65C0024 03FC0924 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D840E8: BF8701A2
	v_mov_b32_e32 v30, v20                                     // 000000D840EC: 7E3C0314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D840F0: D5010014 21AA2914
	v_add_f32_e32 v18, v18, v36                                // 000000D840F8: 06244912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D840FC: BF870113
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D84100: D65C001E 03FC091E FEDCBA98
	v_mul_f32_e32 v18, 0x3db504f3, v18                         // 000000D8410C: 102424FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D84114: BF870092
	v_add_f32_e32 v20, v20, v30                                // 000000D84118: 06283D14
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000D8411C: 102828FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D84124: BF8903F7
	v_fma_mix_f32 v21, v23, v21, neg(0) op_sel_hi:[1,0,0]      // 000000D84128: CC200015 8A022B17
	v_fma_mix_f32 v18, v23, v18, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84130: CC200812 8A022517
	.long 0x7f2e39a0                                           // 000000D84138: 7F2E39A0
	v_fma_mix_f32 v19, v22, v19, neg(0) op_sel_hi:[1,0,0]      // 000000D8413C: CC200013 8A022716
	v_fma_mix_f32 v20, v22, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84144: CC200814 8A022916
	.long 0x7e303995                                           // 000000D8414C: 7E303995
	.long 0x7e2e3992                                           // 000000D84150: 7E2E3992
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84154: BF870193
	v_bfe_u32 v30, v20, 16, 1                                  // 000000D84158: D610001E 02052114
	v_and_b32_e32 v24, 1, v24                                  // 000000D84160: 36303081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84164: BF8701A3
	v_and_b32_e32 v22, 1, v23                                  // 000000D84168: 362C2E81
	v_bfe_u32 v23, v19, 16, 1                                  // 000000D8416C: D6100017 02052113
	v_add3_u32 v21, v21, v24, 0x7fff                           // 000000D84174: D6550015 03FE3115 00007FFF
	.long 0x7f3039a0                                           // 000000D84180: 7F3039A0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84184: BF870214
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000D84188: D6550012 03FE2D12 00007FFF
	v_add3_u32 v19, v19, v23, 0x7fff                           // 000000D84194: D6550013 03FE2F13 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D841A0: BF870224
	.long 0x7e303995                                           // 000000D841A4: 7E303995
	v_add3_u32 v21, v20, v30, 0x7fff                           // 000000D841A8: D6550015 03FE3D14 00007FFF
	v_and_b32_e32 v20, 0xffff0000, v18                         // 000000D841B4: 362824FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D841BC: BF8701B4
	.long 0x7e403993                                           // 000000D841C0: 7E403993
	v_mad_i64_i32 v[17:18], null, 0x1400, v17, v[25:26]        // 000000D841C4: D6FF7C11 046622FF 00001400
	v_and_b32_e32 v22, 0xffff, v24                             // 000000D841D0: 362C30FF 0000FFFF
	v_and_or_b32 v19, 0xffff0000, v21, v32                     // 000000D841D8: D6570013 04822AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D841E4: BF870002
	v_or_b32_e32 v20, v20, v22                                 // 000000D841E8: 38282D14
	global_store_b64 v[17:18], v[19:20], off                   // 000000D841EC: DC6E0000 007C1311
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D841F4: 8C7E057E
	v_or_b32_e32 v17, 32, v34                                  // 000000D841F8: 382244A0
	s_mov_b32 s5, exec_lo                                      // 000000D841FC: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D84200: BC7C0000
	s_barrier                                                  // 000000D84204: BFBD0000
	buffer_gl0_inv                                             // 000000D84208: E0AC0000 00000000
	ds_store_2addr_b32 v35, v9, v10 offset1:2                  // 000000D84210: D8380200 000A0923
	ds_store_2addr_b32 v35, v11, v12 offset0:4 offset1:6       // 000000D84218: D8380604 000C0B23
	ds_store_2addr_b32 v35, v13, v14 offset0:8 offset1:10      // 000000D84220: D8380A08 000E0D23
	ds_store_2addr_b32 v35, v15, v16 offset0:12 offset1:14     // 000000D84228: D8380E0C 00100F23
	s_waitcnt lgkmcnt(0)                                       // 000000D84230: BF89FC07
	s_barrier                                                  // 000000D84234: BFBD0000
	buffer_gl0_inv                                             // 000000D84238: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D84240: D4C4007E
	v_cndmask_b32_e32 v1, s19, v17, vcc_lo                     // 000000D84244: 02022213
	s_cbranch_execz 200                                        // 000000D84248: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x306c>
	global_load_b64 v[13:14], v27, s[12:13]                    // 000000D8424C: DC560000 0D0C001B
	v_lshl_add_u32 v9, v33, 2, v28                             // 000000D84254: D6460009 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000D8425C: BE8400FF 76543210
	ds_load_b128 v[9:12], v9                                   // 000000D84264: DBFC0000 09000009
	s_waitcnt lgkmcnt(0)                                       // 000000D8426C: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000D84270: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000D84278: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D84280: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000D84284: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000D84288: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D84290: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84294: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D8429C: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000D842A4: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D842A8: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D842B0: D501000B 200E170B
	v_mov_b32_dpp v18, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D842B8: 7E2402FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D842C0: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000D842C8: 0618210C
	v_mov_b32_dpp v19, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D842CC: 7E2602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D842D4: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D842DC: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v19 // 000000D842E0: C908150B 0A082709
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D842E8: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D842F0: D501000A 200A150A
	v_add_f32_e32 v11, v15, v18                                // 000000D842F8: 0616250F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D842FC: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D84304: D501000C 200A190C
	v_mov_b32_dpp v18, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8430C: 7E2402FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D84314: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000D8431C: 0614210A
	.long 0x7f263880                                           // 000000D84320: 7F263880
	v_add_f32_e32 v12, v12, v15                                // 000000D84324: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84328: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D84330: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D84338: BF870253
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8433C: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D84344: D501000C 2006190C
	v_add_f32_e32 v9, v9, v18                                  // 000000D8434C: 06122509
	v_mov_b32_dpp v18, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84350: 7E2402FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D84358: D501000A 2006150A
	v_dual_add_f32 v11, v11, v15 :: v_dual_add_f32 v12, v12, v16// 000000D84360: C9081F0B 0B0C210C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84368: BF870224
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8436C: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D84374: D5010009 20061309
	v_add_f32_e32 v10, v10, v18                                // 000000D8437C: 0614250A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84380: BF870224
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84384: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D8438C: D501000B 2006170B
	v_add_f32_e32 v9, v9, v15                                  // 000000D84394: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84398: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D843A0: D501000C 2002190C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D843A8: BF8701B1
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000D843AC: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D843B4: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D843BC: D501000A 2002150A
	v_mov_b32_e32 v16, v12                                     // 000000D843C4: 7E20030C
	v_mov_b32_dpp v18, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D843C8: 7E2402FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D843D0: D5010009 20021309
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D843D8: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v15                                // 000000D843E0: 06141F0A
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D843E4: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D843F0: BF870234
	v_add_f32_e32 v9, v9, v18                                  // 000000D843F4: 06122509
	v_mov_b32_dpp v18, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D843F8: 7E2402FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D84400: D501000B 2002170B
	v_dual_add_f32 v12, v12, v16 :: v_dual_mov_b32 v15, v10    // 000000D84408: C910210C 0C0E010A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84410: BF870224
	v_mov_b32_e32 v20, v9                                      // 000000D84414: 7E280309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D84418: D5010009 21AA1309
	v_add_f32_e32 v11, v11, v18                                // 000000D84420: 0616250B
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D84424: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D8442C: D65C000F 03FC090F FEDCBA98
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000D84438: D65C0014 03FC0914 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84444: BF8701A4
	v_mov_b32_e32 v16, v11                                     // 000000D84448: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D8444C: D501000B 21AA170B
	v_add_f32_e32 v9, v9, v20                                  // 000000D84454: 06122909
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D84458: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D84460: BF8701C4
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D84464: D65C0010 03FC0910 FEDCBA98
	v_add_f32_e32 v10, v10, v15                                // 000000D84470: 06141F0A
	.long 0x7f1e3993                                           // 000000D84474: 7F1E3993
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000D84478: 101212FF 3DB504F3
	v_dual_add_f32 v11, v11, v16 :: v_dual_mul_f32 v10, 0x3db504f3, v10// 000000D84480: C906210B 0B0A14FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8448C: BF870001
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000D84490: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D84498: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D8449C: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D844A4: CC200809 8A02130E
	.long 0x7f1c3993                                           // 000000D844AC: 7F1C3993
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D844B0: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D844B8: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000D844C0: 7E1E398C
	.long 0x7e1c3989                                           // 000000D844C4: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D844C8: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000D844CC: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000D844D4: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D844D8: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000D844DC: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000D844E0: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000D844E8: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D844F4: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000D844F8: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3993                                           // 000000D84504: 7F1E3993
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000D84508: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D84514: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000D84520: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v17                             // 000000D84524: 4A182212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84528: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000D8452C: 361A12FF FFFF0000
	.long 0x7e26398a                                           // 000000D84534: 7E26398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84538: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000D8453C: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[25:26]         // 000000D84544: D6FF7C09 046618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84550: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v19                     // 000000D84554: D657000B 044E16FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000D84560: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000D84564: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D8456C: 8C7E057E
	v_or_b32_e32 v9, 40, v34                                   // 000000D84570: 381244A8
	s_mov_b32 s5, exec_lo                                      // 000000D84574: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D84578: BF870001
	.long 0xd4c4007e                                           // 000000D8457C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D84580: 02021213
	s_cbranch_execz 202                                        // 000000D84584: BFA500CA <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x33b0>
	global_load_b64 v[14:15], v27, s[12:13]                    // 000000D84588: DC560000 0E0C001B
	v_lshl_add_u32 v10, v33, 2, v29                            // 000000D84590: D646000A 04750521
	s_mov_b32 s4, 0x76543210                                   // 000000D84598: BE8400FF 76543210
	v_add_nc_u32_e32 v9, s18, v9                               // 000000D845A0: 4A121212
	ds_load_b128 v[10:13], v10                                 // 000000D845A4: DBFC0000 0A00000A
	s_waitcnt lgkmcnt(0)                                       // 000000D845AC: BF89FC07
	v_dual_add_f32 v16, v10, v11 :: v_dual_add_f32 v17, v12, v13// 000000D845B0: C908170A 10101B0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v12, v13// 000000D845B8: C94A170A 0A0A1B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D845C0: BF8701A2
	v_sub_f32_e32 v13, v16, v17                                // 000000D845C4: 081A2310
	v_add_f32_e32 v12, v16, v17                                // 000000D845C8: 06182310
	v_add_f32_e32 v16, v10, v11                                // 000000D845CC: 0620170A
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D845D0: BF870003
	v_mov_b32_dpp v17, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D845D4: 7E2202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D845DC: D501000D 200E1B0D
	v_sub_f32_e32 v10, v10, v11                                // 000000D845E4: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D845E8: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D845F0: D501000C 200E190C
	v_mov_b32_dpp v18, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D845F8: 7E2402FA FF016110
	v_add_f32_e32 v13, v13, v17                                // 000000D84600: 061A230D
	v_mov_b32_dpp v19, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84604: 7E2602FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D8460C: D501000A 200E150A
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000D84614: D5010010 200E2110
	v_add_f32_e32 v11, v12, v11                                // 000000D8461C: 0616170C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84620: BF870193
	v_add_f32_e32 v10, v10, v19                                // 000000D84624: 0614270A
	v_add_f32_e32 v12, v16, v18                                // 000000D84628: 06182510
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8462C: 7E2002FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D84634: D501000D 200A1B0D
	.long 0x7f263880                                           // 000000D8463C: 7F263880
	v_mov_b32_dpp v18, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84640: 7E2402FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D84648: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D84650: BF8700B1
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v10, v10, v18// 000000D84654: C908210D 0D0A250A
	v_mov_b32_dpp v17, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8465C: 7E2202FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D84664: D501000B 200A170B
	v_add_f32_e32 v11, v11, v17                                // 000000D8466C: 0616230B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84670: BF8701A4
	v_mov_b32_dpp v17, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84674: 7E2202FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000D8467C: D501000D 20061B0D
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84684: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D8468C: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D84694: BF8700B3
	v_add_f32_e32 v13, v13, v17                                // 000000D84698: 061A230D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8469C: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D846A4: D501000C 200A190C
	v_dual_add_f32 v11, v11, v18 :: v_dual_add_f32 v12, v12, v16// 000000D846AC: C908250B 0B0C210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D846B4: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D846BC: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D846C4: BF8701A3
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D846C8: 7E2202FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D846D0: D501000C 2006190C
	v_add_f32_e32 v10, v10, v16                                // 000000D846D8: 0614210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D846DC: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D846E4: D501000D 20021B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D846EC: BF8701B1
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v13, v13, v16// 000000D846F0: C908230C 0C0C210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D846F8: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D84700: D501000B 2002170B
	v_mov_b32_e32 v17, v13                                     // 000000D84708: 7E22030D
	v_mov_b32_dpp v18, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8470C: 7E2402FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D84714: D501000A 2002150A
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000D8471C: D501000D 21AA1B0D
	v_add_f32_e32 v11, v11, v16                                // 000000D84724: 0616210B
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000D84728: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84734: BF8701B4
	v_add_f32_e32 v10, v10, v18                                // 000000D84738: 0614250A
	v_mov_b32_dpp v18, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8473C: 7E2402FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D84744: D501000C 2002190C
	v_dual_add_f32 v13, v13, v17 :: v_dual_mov_b32 v20, v10    // 000000D8474C: C910230D 0D14010A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D84754: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8475C: BF870222
	v_dual_add_f32 v12, v12, v18 :: v_dual_mul_f32 v13, 0x3db504f3, v13// 000000D84760: C906250C 0C0C1AFF 3DB504F3
	v_mov_b32_e32 v16, v11                                     // 000000D8476C: 7E20030B
	v_permlanex16_b32 v20, v20, s4, 0xfedcba98                 // 000000D84770: D65C0014 03FC0914 FEDCBA98
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D8477C: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84784: BF8701B4
	v_mov_b32_e32 v17, v12                                     // 000000D84788: 7E22030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D8478C: D501000C 21AA190C
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D84794: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v17, v17, s4, 0xfedcba98                 // 000000D847A0: D65C0011 03FC0911 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D847AC: BF8701A2
	v_add_f32_e32 v11, v11, v16                                // 000000D847B0: 0616210B
	.long 0x7f203993                                           // 000000D847B4: 7F203993
	v_add_f32_e32 v12, v12, v17                                // 000000D847B8: 0618230C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D847BC: BF870113
	v_dual_add_f32 v10, v10, v20 :: v_dual_mul_f32 v11, 0x3db504f3, v11// 000000D847C0: C906290A 0A0A16FF 3DB504F3
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D847CC: 101818FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D847D4: BF870132
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D847D8: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D847E0: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000D847E4: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D847EC: CC20080A 8A02150F
	.long 0x7f1e3993                                           // 000000D847F4: 7F1E3993
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000D847F8: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84800: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000D84808: 7E20398D
	.long 0x7e1e398a                                           // 000000D8480C: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84810: BF870193
	v_bfe_u32 v17, v12, 16, 1                                  // 000000D84814: D6100011 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000D8481C: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84820: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000D84824: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000D84828: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000D84830: D655000D 03FE210D 00007FFF
	.long 0x7f203993                                           // 000000D8483C: 7F203993
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84840: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D84844: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000D84850: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8485C: BF870224
	.long 0x7e20398d                                           // 000000D84860: 7E20398D
	v_add3_u32 v13, v12, v17, 0x7fff                           // 000000D84864: D655000D 03FE230C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000D84870: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84878: BF8701B4
	.long 0x7e26398b                                           // 000000D8487C: 7E26398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[25:26]          // 000000D84880: D6FF7C09 046612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000D8488C: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v19                     // 000000D84894: D657000B 044E1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D848A0: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000D848A4: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000D848A8: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D848B0: 8C7E057E
	v_or_b32_e32 v9, 48, v34                                   // 000000D848B4: 381244B0
	s_mov_b32 s5, exec_lo                                      // 000000D848B8: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D848BC: BC7C0000
	s_barrier                                                  // 000000D848C0: BFBD0000
	buffer_gl0_inv                                             // 000000D848C4: E0AC0000 00000000
	ds_store_2addr_b32 v35, v1, v2 offset1:2                   // 000000D848CC: D8380200 00020123
	ds_store_2addr_b32 v35, v3, v4 offset0:4 offset1:6         // 000000D848D4: D8380604 00040323
	ds_store_2addr_b32 v35, v5, v6 offset0:8 offset1:10        // 000000D848DC: D8380A08 00060523
	ds_store_2addr_b32 v35, v7, v8 offset0:12 offset1:14       // 000000D848E4: D8380E0C 00080723
	s_waitcnt lgkmcnt(0)                                       // 000000D848EC: BF89FC07
	s_barrier                                                  // 000000D848F0: BFBD0000
	buffer_gl0_inv                                             // 000000D848F4: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D848FC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D84900: 02021213
	s_cbranch_execz 200                                        // 000000D84904: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3728>
	global_load_b64 v[5:6], v27, s[12:13]                      // 000000D84908: DC560000 050C001B
	v_lshl_add_u32 v1, v33, 2, v28                             // 000000D84910: D6460001 04710521
	s_mov_b32 s4, 0x76543210                                   // 000000D84918: BE8400FF 76543210
	ds_load_b128 v[1:4], v1                                    // 000000D84920: DBFC0000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000D84928: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000D8492C: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000D84934: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8493C: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000D84940: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000D84944: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8494C: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84950: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D84958: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000D84960: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84964: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D8496C: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84974: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D8497C: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000D84984: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84988: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000D84990: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D84998: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000D8499C: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D849A4: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D849AC: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000D849B4: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D849B8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D849C0: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D849C8: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000D849D0: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000D849D8: 06041102
	.long 0x7f163880                                           // 000000D849DC: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000D849E0: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D849E4: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D849EC: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D849F4: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D849F8: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D84A00: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000D84A08: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84A0C: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D84A14: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000D84A1C: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84A24: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84A28: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000D84A30: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000D84A38: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84A3C: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84A40: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D84A48: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000D84A50: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84A54: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D84A5C: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84A64: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000D84A68: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84A70: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D84A78: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000D84A80: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84A84: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000D84A8C: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D84A94: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000D84A9C: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D84AA0: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D84AAC: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000D84AB0: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84AB4: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D84ABC: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000D84AC4: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84ACC: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000D84AD0: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000D84AD4: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000D84ADC: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D84AE0: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000D84AE8: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D84AF4: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84B00: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000D84B04: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D84B08: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000D84B10: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D84B14: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D84B1C: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D84B20: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000D84B2C: 06040F02
	.long 0x7f0e398b                                           // 000000D84B30: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000D84B34: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000D84B3C: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D84B48: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D84B4C: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D84B54: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D84B58: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84B60: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000D84B68: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D84B6C: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84B74: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000D84B7C: 7E0E3984
	.long 0x7e0c3981                                           // 000000D84B80: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84B84: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000D84B88: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000D84B90: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84B94: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000D84B98: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000D84B9C: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D84BA4: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D84BB0: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000D84BB4: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000D84BC0: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000D84BC4: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D84BD0: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000D84BDC: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000D84BE0: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84BE4: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000D84BE8: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000D84BF0: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84BF4: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000D84BF8: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[25:26]           // 000000D84C00: D6FF7C01 046608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84C0C: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000D84C10: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000D84C1C: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000D84C20: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D84C28: 8C7E057E
	v_or_b32_e32 v1, 56, v34                                   // 000000D84C2C: 380244B8
	s_mov_b32 s5, exec_lo                                      // 000000D84C30: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D84C34: BF870001
	.long 0xd4c4007e                                           // 000000D84C38: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000D84C3C: 02020213
	s_cbranch_execz 202                                        // 000000D84C40: BFA500CA <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3a6c>
	global_load_b64 v[6:7], v27, s[12:13]                      // 000000D84C44: DC560000 060C001B
	v_lshl_add_u32 v2, v33, 2, v29                             // 000000D84C4C: D6460002 04750521
	v_add_nc_u32_e32 v1, s18, v1                               // 000000D84C54: 4A020212
	ds_load_b128 v[2:5], v2                                    // 000000D84C58: DBFC0000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000D84C60: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_f32 v9, v4, v5     // 000000D84C64: C9080702 08080B04
	v_dual_sub_f32 v2, v2, v3 :: v_dual_sub_f32 v3, v4, v5     // 000000D84C6C: C94A0702 02020B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84C74: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000D84C78: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000D84C7C: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000D84C80: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D84C84: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84C88: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D84C90: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000D84C98: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84C9C: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D84CA4: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84CAC: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000D84CB4: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D84CB8: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D84CC0: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D84CC8: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000D84CD0: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000D84CD4: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84CDC: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000D84CE0: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000D84CE4: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84CE8: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D84CF0: D5010005 200A0B05
	.long 0x7f163880                                           // 000000D84CF8: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84CFC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D84D04: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D84D0C: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000D84D10: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84D18: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D84D20: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000D84D28: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84D2C: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84D30: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D84D38: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84D40: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D84D48: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D84D50: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000D84D54: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D84D58: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D84D60: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000D84D68: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84D70: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D84D78: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84D80: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D84D84: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D84D8C: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000D84D94: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84D98: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D84DA0: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84DA8: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000D84DAC: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84DB4: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D84DBC: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000D84DC4: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84DC8: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D84DD0: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D84DD8: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D84DE0: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D84DE4: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84DF0: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000D84DF4: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D84DF8: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D84E00: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000D84E08: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D84E10: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84E18: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D84E1C: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000D84E28: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000D84E2C: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D84E38: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84E40: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000D84E44: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D84E48: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D84E50: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D84E5C: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84E68: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000D84E6C: 06061103
	.long 0x7f10398b                                           // 000000D84E70: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000D84E74: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D84E78: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000D84E7C: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D84E88: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D84E90: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D84E94: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D84E9C: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D84EA0: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84EA8: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000D84EB0: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000D84EB4: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D84EBC: CC200804 8A020906
	.long 0x7e103985                                           // 000000D84EC4: 7E103985
	.long 0x7e0e3982                                           // 000000D84EC8: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D84ECC: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000D84ED0: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000D84ED8: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84EDC: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000D84EE0: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000D84EE4: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000D84EEC: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000D84EF8: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84EFC: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D84F00: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D84F0C: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84F18: BF870224
	.long 0x7e103985                                           // 000000D84F1C: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000D84F20: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000D84F2C: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84F34: BF8701B4
	.long 0x7e163983                                           // 000000D84F38: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[25:26]           // 000000D84F3C: D6FF7C01 046602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000D84F48: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000D84F50: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D84F5C: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000D84F60: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000D84F64: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D84F6C: 8C7E057E
	s_mov_b32 s1, 0                                            // 000000D84F70: BE810080
	s_waitcnt_vscnt null, 0x0                                  // 000000D84F74: BC7C0000
	s_barrier                                                  // 000000D84F78: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000D84F7C: 8B6A017E
	s_cbranch_vccz 3007                                        // 000000D84F80: BFA30BBF <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6980>
	v_or_b32_e32 v1, 0x100, v0                                 // 000000D84F84: 380200FF 00000100
	v_lshrrev_b32_e32 v8, 4, v0                                // 000000D84F8C: 32100084
	s_add_i32 s0, s19, -1                                      // 000000D84F90: 8100C113
	v_lshrrev_b32_e32 v9, 4, v55                               // 000000D84F94: 32126E84
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D84F98: BF8701B3
	v_lshrrev_b32_e32 v7, 4, v1                                // 000000D84F9C: 320E0284
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000D84FA0: 30020083
	v_min_i32_e32 v2, s0, v8                                   // 000000D84FA4: 22041000
	v_min_i32_e32 v3, s0, v7                                   // 000000D84FA8: 22060E00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D84FAC: BF870223
	v_and_b32_e32 v79, 0x78, v1                                // 000000D84FB0: 369E02FF 00000078
	v_min_i32_e32 v1, s0, v9                                   // 000000D84FB8: 22021200
	v_add_nc_u32_e32 v2, s18, v2                               // 000000D84FBC: 4A040412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84FC0: BF870214
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D84FC4: 4A060612
	v_lshlrev_b32_e32 v10, 1, v79                              // 000000D84FC8: 30149E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84FCC: BF870214
	v_add_nc_u32_e32 v5, s18, v1                               // 000000D84FD0: 4A0A0212
	v_mad_i64_i32 v[1:2], null, 0x500, v2, 0                   // 000000D84FD4: D6FF7C01 020204FF 00000500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D84FE0: BF870214
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D84FE4: D6FF7C03 020206FF 00000500
	.long 0xd700000f                                           // 000000D84FF0: D700000F
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 000000D84FF4: 0202140A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D84FF8: BF8701A4
	v_mad_i64_i32 v[5:6], null, 0x500, v5, 0                   // 000000D84FFC: D6FF7C05 02020AFF 00000500
	v_add_co_ci_u32_e64 v16, null, s11, 0, s0                  // 000000D85008: D5207C10 0001000B
	.long 0xd7006a0b                                           // 000000D85010: D7006A0B
	v_cndmask_b32_e32 v1, v15, v1, vcc_lo                      // 000000D85014: 0202030F
	.long 0xd44c0000                                           // 000000D85018: D44C0000
	v_cndmask_b32_e32 v1, 0x300, v0, vcc_lo                    // 000000D8501C: 020200FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D85024: BF8700A3
	v_add_co_ci_u32_e64 v12, null, v16, v2, vcc_lo             // 000000D85028: D5207C0C 01AA0510
	.long 0xd7006a0d                                           // 000000D85030: D7006A0D
	v_cndmask_b32_e32 v1, v15, v3, vcc_lo                      // 000000D85034: 0202070F
	v_add_co_ci_u32_e64 v14, null, v16, v4, vcc_lo             // 000000D85038: D5207C0E 01AA0910
	.long 0xd7006a0f                                           // 000000D85040: D7006A0F
	v_cndmask_b32_e32 v1, v15, v5, vcc_lo                      // 000000D85044: 02020B0F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D85048: BF870001
	v_add_co_ci_u32_e64 v16, null, v16, v6, vcc_lo             // 000000D8504C: D5207C10 01AA0D10
	s_clause 0x2                                               // 000000D85054: BF850002
	global_load_b128 v[49:52], v[11:12], off                   // 000000D85058: DC5E0000 317C000B
	global_load_b128 v[53:56], v[13:14], off                   // 000000D85060: DC5E0000 357C000D
	global_load_b128 v[57:60], v[15:16], off                   // 000000D85068: DC5E0000 397C000F
	s_and_saveexec_b32 s1, s0                                  // 000000D85070: BE812000
	s_cbranch_execz 6                                          // 000000D85074: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3b90>
	v_mad_u32_u24 v11, 0x110, v8, v10                          // 000000D85078: D60B000B 042A10FF 00000110
	s_waitcnt vmcnt(2)                                         // 000000D85084: BF890BF7
	ds_store_b128 v11, v[49:52]                                // 000000D85088: DB7C0000 0000310B
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D85090: 8C7E017E
	.long 0xd44c0001                                           // 000000D85094: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D85098: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D850A0: BE822001
	s_cbranch_execz 6                                          // 000000D850A4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3bc0>
	v_mad_u32_u24 v11, 0x110, v7, v10                          // 000000D850A8: D60B000B 042A0EFF 00000110
	s_waitcnt vmcnt(1)                                         // 000000D850B4: BF8907F7
	ds_store_b128 v11, v[53:56]                                // 000000D850B8: DB7C0000 0000350B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D850C0: 8C7E027E
	.long 0xd44c0002                                           // 000000D850C4: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D850C8: 020200FF 00000100
	v_mul_u32_u24_e32 v82, 0x88, v9                            // 000000D850D0: 16A412FF 00000088
	s_and_saveexec_b32 s3, s2                                  // 000000D850D8: BE832002
	s_cbranch_execz 6                                          // 000000D850DC: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3bf8>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D850E0: BF870001
	v_lshl_add_u32 v9, v82, 1, v10                             // 000000D850E4: D6460009 04290352
	s_waitcnt vmcnt(0)                                         // 000000D850EC: BF8903F7
	ds_store_b128 v9, v[57:60]                                 // 000000D850F0: DB7C0000 00003909
	s_or_b32 exec_lo, exec_lo, s3                              // 000000D850F8: 8C7E037E
	s_mul_i32 s5, s16, 0xc8000                                 // 000000D850FC: 9605FF10 000C8000
	s_mul_i32 s12, s17, 0xa000                                 // 000000D85104: 960CFF11 0000A000
	s_mul_hi_i32 s4, s16, 0xc8000                              // 000000D8510C: 9704FF10 000C8000
	s_add_u32 s5, s5, s12                                      // 000000D85114: 80050C05
	s_mul_hi_i32 s12, s17, 0xa000                              // 000000D85118: 970CFF11 0000A000
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v80, 31, v0        // 000000D85120: CA240080 1150009F
	s_addc_u32 s4, s4, s12                                     // 000000D85128: 82040C04
	v_and_b32_e32 v81, 15, v0                                  // 000000D8512C: 36A2008F
	v_mul_u32_u24_e32 v83, 0x110, v8                           // 000000D85130: 16A610FF 00000110
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D85138: BF870003
	v_lshlrev_b32_e32 v9, 5, v80                               // 000000D8513C: 3012A085
	v_mov_b32_e32 v21, v17                                     // 000000D85140: 7E2A0311
	.long 0xd44c0003                                           // 000000D85144: D44C0003
	v_cndmask_b32_e32 v1, 16, v80, vcc_lo                      // 000000D85148: 0202A090
	v_lshlrev_b32_e32 v12, 4, v81                              // 000000D8514C: 3018A284
	v_mul_u32_u24_e32 v88, 0x110, v7                           // 000000D85150: 16B00EFF 00000110
	v_mov_b32_e32 v14, v17                                     // 000000D85158: 7E1C0311
	v_mov_b32_e32 v15, v17                                     // 000000D8515C: 7E1E0311
	v_mov_b32_e32 v16, v17                                     // 000000D85160: 7E200311
	.long 0xd7006a05                                           // 000000D85164: D7006A05
	v_cndmask_b32_e32 v1, v5, v12, vcc_lo                      // 000000D85168: 02021905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8516C: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000D85170: D5207C06 01AA0C80
	v_mov_b32_e32 v7, v17                                      // 000000D85178: 7E0E0311
	.long 0xd7006a05                                           // 000000D8517C: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000D85180: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D85184: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000D85188: D5207C06 01AA0C0B
	v_mov_b32_e32 v24, v17                                     // 000000D85190: 7E300311
	.long 0xd7006a3d                                           // 000000D85194: D7006A3D
	v_cndmask_b32_e32 v1, 0x100, v5, vcc_lo                    // 000000D85198: 02020AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D851A0: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v6, vcc_lo               // 000000D851A4: D5207C3E 01AA0C80
	.long 0xd7006a03                                           // 000000D851AC: D7006A03
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 000000D851B0: 02021903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000D851B4: D5207C04 01AA0880
	v_lshlrev_b32_e32 v5, 2, v0                                // 000000D851BC: 300A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D851C0: BF870093
	.long 0xd7006a03                                           // 000000D851C4: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000D851C8: 0202060A
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000D851CC: D5207C04 01AA080B
	v_mov_b32_e32 v19, v17                                     // 000000D851D4: 7E260311
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D851D8: BF870093
	.long 0xd7006a3f                                           // 000000D851DC: D7006A3F
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000D851E0: 020206FF 00000100
	v_add_co_ci_u32_e64 v64, null, 0, v4, vcc_lo               // 000000D851E8: D5207C40 01AA0880
	v_mov_b32_e32 v4, s4                                       // 000000D851F0: 7E080204
	v_add_nc_u32_e32 v10, 0x3f0, v9                            // 000000D851F4: 4A1412FF 000003F0
	v_and_or_b32 v5, 0x380, v5, s5                             // 000000D851FC: D6570005 00160AFF 00000380
	.long 0xd7006a01                                           // 000000D85208: D7006A01
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 000000D8520C: 02021901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D85210: BF870211
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000D85214: D5207C02 01AA0480
	v_lshrrev_b32_e32 v8, 5, v10                               // 000000D8521C: 32101485
	v_lshrrev_b32_e32 v6, 3, v10                               // 000000D85220: 320C1483
	v_dual_mov_b32 v18, v17 :: v_dual_and_b32 v11, 0x7e0, v10  // 000000D85224: CA240111 120A14FF 000007E0
	.long 0xd7006a01                                           // 000000D85230: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000D85234: 0202020A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D85238: BF870214
	v_dual_mov_b32 v23, v17 :: v_dual_add_nc_u32 v8, 1, v8     // 000000D8523C: CA200111 17081081
	v_and_or_b32 v3, 0x7c, v6, v5                              // 000000D85244: D6570003 04160CFF 0000007C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D85250: BF870224
	v_sub_nc_u32_e32 v9, v11, v9                               // 000000D85254: 4C12130B
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 000000D85258: D5207C02 01AA040B
	v_and_b32_e32 v8, 31, v8                                   // 000000D85260: 3610109F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D85264: BF870214
	.long 0xd7006a59                                           // 000000D85268: D7006A59
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D8526C: 02020608
	v_dual_mov_b32 v11, v17 :: v_dual_add_nc_u32 v84, 0xfffffc3c, v9// 000000D85270: CA200111 0B5412FF FFFFFC3C
	v_dual_mov_b32 v20, v17 :: v_dual_add_nc_u32 v85, 0xfffffc38, v9// 000000D8527C: CA200111 145412FF FFFFFC38
	v_add_nc_u32_e32 v86, 0xfffffc34, v9                       // 000000D85288: 4AAC12FF FFFFFC34
	v_dual_mov_b32 v22, v17 :: v_dual_add_nc_u32 v87, 0xfffffc30, v9// 000000D85290: CA200111 165612FF FFFFFC30
	v_add_co_ci_u32_e64 v90, null, s9, v4, vcc_lo              // 000000D8529C: D5207C5A 01AA0809
	.long 0xd7006a41                                           // 000000D852A4: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 000000D852A8: 020202FF 00000100
	v_mov_b32_e32 v9, v17                                      // 000000D852B0: 7E120311
	v_lshl_or_b32 v1, v8, 2, v5                                // 000000D852B4: D6560001 04150508
	v_add_co_ci_u32_e64 v66, null, 0, v2, vcc_lo               // 000000D852BC: D5207C42 01AA0480
	v_mov_b32_e32 v2, s4                                       // 000000D852C4: 7E040204
	v_lshl_or_b32 v3, v80, 2, v5                               // 000000D852C8: D6560003 04150550
	v_mul_u32_u24_e32 v13, 0x88, v81                           // 000000D852D0: 161AA2FF 00000088
	.long 0xd7006a5b                                           // 000000D852D8: D7006A5B
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D852DC: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D852E0: BF870211
	v_add_co_ci_u32_e64 v92, null, s9, v2, vcc_lo              // 000000D852E4: D5207C5C 01AA0409
	.long 0xd7006a5d                                           // 000000D852EC: D7006A5D
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D852F0: 02020608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D852F4: BF870001
	v_add_co_ci_u32_e64 v94, null, s9, v4, vcc_lo              // 000000D852F8: D5207C5E 01AA0809
	v_dual_mov_b32 v10, v17 :: v_dual_lshlrev_b32 v95, 1, v13  // 000000D85300: CA220111 0A5E1A81
	v_mov_b32_e32 v12, v17                                     // 000000D85308: 7E180311
	v_mov_b32_e32 v13, v17                                     // 000000D8530C: 7E1A0311
	v_mov_b32_e32 v1, v17                                      // 000000D85310: 7E020311
	v_mov_b32_e32 v2, v17                                      // 000000D85314: 7E040311
	v_mov_b32_e32 v3, v17                                      // 000000D85318: 7E060311
	v_mov_b32_e32 v4, v17                                      // 000000D8531C: 7E080311
	v_mov_b32_e32 v5, v17                                      // 000000D85320: 7E0A0311
	v_mov_b32_e32 v6, v17                                      // 000000D85324: 7E0C0311
	v_mov_b32_e32 v8, v17                                      // 000000D85328: 7E100311
	s_mov_b32 s12, 0                                           // 000000D8532C: BE8C0080
	s_mov_b64 s[4:5], 0                                        // 000000D85330: BE840180
	s_movk_i32 s13, 0x1eee                                     // 000000D85334: B00D1EEE
	s_mov_b32 s21, 0x76543210                                  // 000000D85338: BE9500FF 76543210
	s_movk_i32 s22, 0x60                                       // 000000D85340: B0160060
	s_movk_i32 s23, 0x80                                       // 000000D85344: B0170080
	s_movk_i32 s24, 0xa0                                       // 000000D85348: B01800A0
	s_movk_i32 s25, 0xc0                                       // 000000D8534C: B01900C0
	s_movk_i32 s26, 0xe0                                       // 000000D85350: B01A00E0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D85354: BF890007
	s_barrier                                                  // 000000D85358: BFBD0000
	buffer_gl0_inv                                             // 000000D8535C: E0AC0000 00000000
	s_branch 28                                                // 000000D85364: BFA0001C <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3ed8>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D85368: 8C7E1B7E
	.long 0xd7006a3d                                           // 000000D8536C: D7006A3D
	v_cndmask_b32_e32 v1, 0x100, v61, vcc_lo                   // 000000D85370: 02027AFF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D85378: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v62, vcc_lo              // 000000D8537C: D5207C3E 01AA7C80
	.long 0xd7006a3f                                           // 000000D85384: D7006A3F
	v_cndmask_b32_e32 v1, 0x100, v63, vcc_lo                   // 000000D85388: 02027EFF 00000100
	v_add_co_ci_u32_e64 v64, null, 0, v64, vcc_lo              // 000000D85390: D5207C40 01AA8080
	.long 0xd7006a41                                           // 000000D85398: D7006A41
	v_cndmask_b32_e32 v1, 0x100, v65, vcc_lo                   // 000000D8539C: 020282FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D853A4: BF870001
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 000000D853A8: D5207C42 01AA8480
	s_add_u32 s4, s4, 0x2000                                   // 000000D853B0: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D853B8: 82058005
	s_add_i32 s12, s12, 1                                      // 000000D853BC: 810C810C
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D853C0: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D853C4: BF89FC07
	s_barrier                                                  // 000000D853C8: BFBD0000
	buffer_gl0_inv                                             // 000000D853CC: E0AC0000 00000000
	s_cbranch_scc1 1388                                        // 000000D853D4: BFA2056C <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5488>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D853D8: B5048000
	s_cselect_b32 s27, -1, 0                                   // 000000D853DC: 981B80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D853E0: B4848000
	s_cbranch_scc1 6                                           // 000000D853E4: BFA20006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3f00>
	global_load_b128 v[49:52], v[65:66], off                   // 000000D853E8: DC5E0000 317C0041
	global_load_b128 v[53:56], v[63:64], off                   // 000000D853F0: DC5E0000 357C003F
	global_load_b128 v[57:60], v[61:62], off                   // 000000D853F8: DC5E0000 397C003D
	.long 0xd7006a19                                           // 000000D85400: D7006A19
	v_cndmask_b32_e32 v0, v89, v4, vcc_lo                      // 000000D85404: 02000959
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D85408: BF8700A1
	v_add_co_ci_u32_e64 v26, null, s5, v90, vcc_lo             // 000000D8540C: D5207C1A 01AAB405
	.long 0xd7006a1b                                           // 000000D85414: D7006A1B
	v_cndmask_b32_e32 v0, v91, v4, vcc_lo                      // 000000D85418: 0200095B
	v_add_co_ci_u32_e64 v28, null, s5, v92, vcc_lo             // 000000D8541C: D5207C1C 01AAB805
	.long 0xd7006a1d                                           // 000000D85424: D7006A1D
	v_cndmask_b32_e32 v0, v93, v4, vcc_lo                      // 000000D85428: 0200095D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8542C: BF870001
	v_add_co_ci_u32_e64 v30, null, s5, v94, vcc_lo             // 000000D85430: D5207C1E 01AABC05
	s_clause 0xb                                               // 000000D85438: BF85000B
	global_load_b32 v68, v[25:26], off                         // 000000D8543C: DC520000 447C0019
	global_load_b32 v67, v[27:28], off                         // 000000D85444: DC520000 437C001B
	global_load_b32 v96, v[29:30], off                         // 000000D8544C: DC520000 607C001D
	global_load_b32 v70, v[25:26], off offset:1024             // 000000D85454: DC520400 467C0019
	global_load_b32 v69, v[27:28], off offset:1024             // 000000D8545C: DC520400 457C001B
	global_load_b32 v97, v[29:30], off offset:1024             // 000000D85464: DC520400 617C001D
	global_load_b32 v72, v[25:26], off offset:2048             // 000000D8546C: DC520800 487C0019
	global_load_b32 v71, v[27:28], off offset:2048             // 000000D85474: DC520800 477C001B
	global_load_b32 v98, v[29:30], off offset:2048             // 000000D8547C: DC520800 627C001D
	global_load_b32 v73, v[27:28], off offset:3072             // 000000D85484: DC520C00 497C001B
	global_load_b32 v74, v[25:26], off offset:3072             // 000000D8548C: DC520C00 4A7C0019
	global_load_b32 v99, v[29:30], off offset:3072             // 000000D85494: DC520C00 637C001D
	.long 0xd7006a66                                           // 000000D8549C: D7006A66
	v_cndmask_b32_e32 v1, 0x1000, v25, vcc_lo                  // 000000D854A0: 020232FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D854A8: BF8700A1
	v_add_co_ci_u32_e64 v103, null, 0, v26, vcc_lo             // 000000D854AC: D5207C67 01AA3480
	.long 0xd7006a68                                           // 000000D854B4: D7006A68
	v_cndmask_b32_e32 v1, 0x1000, v27, vcc_lo                  // 000000D854B8: 020236FF 00001000
	v_add_co_ci_u32_e64 v105, null, 0, v28, vcc_lo             // 000000D854C0: D5207C69 01AA3880
	.long 0xd7006a6a                                           // 000000D854C8: D7006A6A
	v_cndmask_b32_e32 v1, 0x1000, v29, vcc_lo                  // 000000D854CC: 02023AFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D854D4: BF870001
	v_add_co_ci_u32_e64 v107, null, 0, v30, vcc_lo             // 000000D854D8: D5207C6B 01AA3C80
	s_clause 0xb                                               // 000000D854E0: BF85000B
	global_load_b32 v76, v[102:103], off                       // 000000D854E4: DC520000 4C7C0066
	global_load_b32 v75, v[104:105], off                       // 000000D854EC: DC520000 4B7C0068
	global_load_b32 v101, v[106:107], off                      // 000000D854F4: DC520000 657C006A
	global_load_b32 v199, v[102:103], off offset:1024          // 000000D854FC: DC520400 C77C0066
	global_load_b32 v198, v[104:105], off offset:1024          // 000000D85504: DC520400 C67C0068
	global_load_b32 v100, v[106:107], off offset:1024          // 000000D8550C: DC520400 647C006A
	global_load_b32 v78, v[102:103], off offset:2048           // 000000D85514: DC520800 4E7C0066
	global_load_b32 v77, v[104:105], off offset:2048           // 000000D8551C: DC520800 4D7C0068
	global_load_b32 v230, v[104:105], off offset:3072          // 000000D85524: DC520C00 E67C0068
	global_load_b32 v231, v[102:103], off offset:3072          // 000000D8552C: DC520C00 E77C0066
	global_load_b32 v232, v[106:107], off offset:2048          // 000000D85534: DC520800 E87C006A
	global_load_b32 v233, v[106:107], off offset:3072          // 000000D8553C: DC520C00 E97C006A
	s_bfe_i32 s28, s12, 0x10000                                // 000000D85544: 939CFF0C 00010000
	s_and_b32 s29, s12, 1                                      // 000000D8554C: 8B1D810C
	s_and_b32 s30, s28, 0x4400                                 // 000000D85550: 8B1EFF1C 00004400
	s_cmp_eq_u32 s29, 0                                        // 000000D85558: BF06801D
	s_cselect_b32 s28, -1, 0                                   // 000000D8555C: 981C80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D85560: BF870009
	s_and_b32 s29, s28, exec_lo                                // 000000D85564: 8B1D7E1C
	s_cselect_b32 s29, 32, 0x4420                              // 000000D85568: 981DFFA0 00004420
	s_cselect_b32 s31, s22, 0x4460                             // 000000D85570: 981FFF16 00004460
	s_cselect_b32 s33, s23, 0x4480                             // 000000D85578: 9821FF17 00004480
	s_waitcnt vmcnt(22)                                        // 000000D85580: BF895BF7
	.long 0xd73d00c8                                           // 000000D85584: D73D00C8
	v_cndmask_b32_e32 v1, v84, v67, vcc_lo                     // 000000D85588: 02028754
	.long 0xd73d00c9                                           // 000000D8558C: D73D00C9
	v_cndmask_b32_e32 v1, v85, v67, vcc_lo                     // 000000D85590: 02028755
	.long 0xd73d00ca                                           // 000000D85594: D73D00CA
	v_cndmask_b32_e32 v1, v86, v67, vcc_lo                     // 000000D85598: 02028756
	s_waitcnt vmcnt(19)                                        // 000000D8559C: BF894FF7
	.long 0xd73d00cb                                           // 000000D855A0: D73D00CB
	v_cndmask_b32_e32 v1, v84, v69, vcc_lo                     // 000000D855A4: 02028B54
	.long 0xd73d0043                                           // 000000D855A8: D73D0043
	v_cndmask_b32_e32 v1, v87, v67, vcc_lo                     // 000000D855AC: 02028757
	.long 0xd73d00cc                                           // 000000D855B0: D73D00CC
	v_cndmask_b32_e32 v1, v85, v69, vcc_lo                     // 000000D855B4: 02028B55
	.long 0xd73d00cd                                           // 000000D855B8: D73D00CD
	v_cndmask_b32_e32 v1, v86, v69, vcc_lo                     // 000000D855BC: 02028B56
	.long 0xd73d0044                                           // 000000D855C0: D73D0044
	v_cndmask_b32_e32 v1, v87, v69, vcc_lo                     // 000000D855C4: 02028B57
	s_waitcnt vmcnt(16)                                        // 000000D855C8: BF8943F7
	.long 0xd73d0045                                           // 000000D855CC: D73D0045
	v_cndmask_b32_e32 v1, v84, v71, vcc_lo                     // 000000D855D0: 02028F54
	v_bfe_u32 v209, v96, 12, 16                                // 000000D855D4: D61000D1 02411960
	v_bfe_u32 v210, v96, 8, 16                                 // 000000D855DC: D61000D2 02411160
	v_bfe_u32 v211, v96, 4, 16                                 // 000000D855E4: D61000D3 02410960
	v_and_b32_e32 v212, 0xffff, v96                            // 000000D855EC: 37A8C0FF 0000FFFF
	v_bfe_u32 v213, v97, 12, 16                                // 000000D855F4: D61000D5 02411961
	v_bfe_u32 v214, v97, 8, 16                                 // 000000D855FC: D61000D6 02411161
	v_bfe_u32 v215, v97, 4, 16                                 // 000000D85604: D61000D7 02410961
	v_and_b32_e32 v216, 0xffff, v97                            // 000000D8560C: 37B0C2FF 0000FFFF
	.long 0xd73d0060                                           // 000000D85614: D73D0060
	v_cndmask_b32_e32 v1, v85, v71, vcc_lo                     // 000000D85618: 02028F55
	.long 0xd73d00ce                                           // 000000D8561C: D73D00CE
	v_cndmask_b32_e32 v1, v86, v71, vcc_lo                     // 000000D85620: 02028F56
	.long 0xd73d0046                                           // 000000D85624: D73D0046
	v_cndmask_b32_e32 v1, v87, v71, vcc_lo                     // 000000D85628: 02028F57
	s_waitcnt vmcnt(13)                                        // 000000D8562C: BF8937F7
	.long 0xd73d0047                                           // 000000D85630: D73D0047
	v_cndmask_b32_e32 v1, v84, v73, vcc_lo                     // 000000D85634: 02029354
	v_bfe_u32 v217, v98, 12, 16                                // 000000D85638: D61000D9 02411962
	v_bfe_u32 v218, v98, 8, 16                                 // 000000D85640: D61000DA 02411162
	v_bfe_u32 v219, v98, 4, 16                                 // 000000D85648: D61000DB 02410962
	v_and_b32_e32 v220, 0xffff, v98                            // 000000D85650: 37B8C4FF 0000FFFF
	.long 0xd73d0061                                           // 000000D85658: D73D0061
	v_cndmask_b32_e32 v1, v85, v73, vcc_lo                     // 000000D8565C: 02029355
	v_and_b32_e32 v71, 0xffff, v71                             // 000000D85660: 368E8EFF 0000FFFF
	v_and_b32_e32 v96, 0xffff, v96                             // 000000D85668: 36C0C0FF 0000FFFF
	.long 0xd73d00cf                                           // 000000D85670: D73D00CF
	v_cndmask_b32_e32 v1, v86, v73, vcc_lo                     // 000000D85674: 02029356
	.long 0xd73d0048                                           // 000000D85678: D73D0048
	v_cndmask_b32_e32 v1, v87, v73, vcc_lo                     // 000000D8567C: 02029357
	s_waitcnt vmcnt(12)                                        // 000000D85680: BF8933F7
	v_bfe_u32 v73, v99, 12, 16                                 // 000000D85684: D6100049 02411963
	v_and_b32_e32 v97, 0xffff, v97                             // 000000D8568C: 36C2C2FF 0000FFFF
	.long 0xd72c0047                                           // 000000D85694: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000D85698: 02028EFF 83DCD12D
	.long 0xd72c0060                                           // 000000D856A0: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000D856A4: 0202C0FF 83DCD12D
	v_bfe_u32 v74, v99, 8, 16                                  // 000000D856AC: D610004A 02411163
	v_bfe_u32 v98, v99, 4, 16                                  // 000000D856B4: D6100062 02410963
	.long 0xd72c0061                                           // 000000D856BC: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000D856C0: 0202C2FF 83DCD12D
	v_and_b32_e32 v99, 0xffff, v99                             // 000000D856C8: 36C6C6FF 0000FFFF
	.long 0xd72c00dd                                           // 000000D856D0: D72C00DD
	v_cndmask_b32_e32 v1, 0x83dcd12d, v209, vcc_lo             // 000000D856D4: 0203A2FF 83DCD12D
	.long 0xd72c00e0                                           // 000000D856DC: D72C00E0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000D856E0: 020292FF 83DCD12D
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000D856E8: D6220047 03FD0147 00006400
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000D856F4: D6220060 03FD0160 00006400
	.long 0xd72c00e1                                           // 000000D85700: D72C00E1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000D85704: 020294FF 83DCD12D
	.long 0xd72c00e3                                           // 000000D8570C: D72C00E3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000D85710: 0202C6FF 83DCD12D
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000D85718: D6220061 03FD0161 00006400
	v_and_b32_e32 v71, 0xffff, v71                             // 000000D85724: 368E8EFF 0000FFFF
	s_waitcnt vmcnt(10)                                        // 000000D8572C: BF892BF7
	.long 0xd73d0049                                           // 000000D85730: D73D0049
	v_cndmask_b32_e32 v1, v84, v75, vcc_lo                     // 000000D85734: 02029754
	.long 0xd73d00d0                                           // 000000D85738: D73D00D0
	v_cndmask_b32_e32 v1, v86, v75, vcc_lo                     // 000000D8573C: 02029756
	.long 0xd72c00de                                           // 000000D85740: D72C00DE
	v_cndmask_b32_e32 v1, 0x83dcd12d, v210, vcc_lo             // 000000D85744: 0203A4FF 83DCD12D
	.long 0xd72c00e2                                           // 000000D8574C: D72C00E2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000D85750: 0202C4FF 83DCD12D
	v_lshl_or_b32 v71, v97, 16, v71                            // 000000D85758: D6560047 051D2161
	.long 0xd73d0062                                           // 000000D85760: D73D0062
	v_cndmask_b32_e32 v1, v85, v75, vcc_lo                     // 000000D85764: 02029755
	.long 0xd73d004a                                           // 000000D85768: D73D004A
	v_cndmask_b32_e32 v1, v87, v75, vcc_lo                     // 000000D8576C: 02029757
	s_waitcnt vmcnt(7)                                         // 000000D85770: BF891FF7
	.long 0xd73d00d1                                           // 000000D85774: D73D00D1
	v_cndmask_b32_e32 v1, v85, v198, vcc_lo                    // 000000D85778: 02038D55
	.long 0xd72c00df                                           // 000000D8577C: D72C00DF
	v_cndmask_b32_e32 v1, 0x83dcd12d, v211, vcc_lo             // 000000D85780: 0203A6FF 83DCD12D
	v_pk_fma_f16 v238, v71, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85788: CC0E00EE 0BFC1B47 0000C931
	v_and_b32_e32 v69, 0xffff, v69                             // 000000D85794: 368A8AFF 0000FFFF
	.long 0xd73d004b                                           // 000000D8579C: D73D004B
	v_cndmask_b32_e32 v1, v84, v198, vcc_lo                    // 000000D857A0: 02038D54
	.long 0xd73d00d2                                           // 000000D857A4: D73D00D2
	v_cndmask_b32_e32 v1, v86, v198, vcc_lo                    // 000000D857A8: 02038D56
	.long 0xd73d00c6                                           // 000000D857AC: D73D00C6
	v_cndmask_b32_e32 v1, v87, v198, vcc_lo                    // 000000D857B0: 02038D57
	v_mov_b32_e32 v244, v238                                   // 000000D857B4: 7FE803EE
	.long 0xd72c0045                                           // 000000D857B8: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000D857BC: 02028AFF 83DCD12D
	v_and_b32_e32 v199, 0xffff, v200                           // 000000D857C4: 378F90FF 0000FFFF
	v_and_b32_e32 v200, 0xffff, v201                           // 000000D857CC: 379192FF 0000FFFF
	v_and_b32_e32 v201, 0xffff, v202                           // 000000D857D4: 379394FF 0000FFFF
	v_and_b32_e32 v202, 0xffff, v203                           // 000000D857DC: 379596FF 0000FFFF
	v_and_b32_e32 v236, 0xffff, v198                           // 000000D857E4: 37D98CFF 0000FFFF
	v_sad_u8 v198, v221, 0, 0x6400                             // 000000D857EC: D62200C6 03FD01DD 00006400
	v_sad_u8 v221, v224, 0, 0x6400                             // 000000D857F8: D62200DD 03FD01E0 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D85804: D6220045 03FD0145 00006400
	v_sad_u8 v224, v227, 0, 0x6400                             // 000000D85810: D62200E0 03FD01E3 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000D8581C: 369090FF 0000FFFF
	v_and_b32_e32 v68, 0xffff, v68                             // 000000D85824: 368888FF 0000FFFF
	v_and_b32_e32 v208, 0xffff, v208                           // 000000D8582C: 37A1A0FF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v69                             // 000000D85834: 368A8AFF 0000FFFF
	v_and_b32_e32 v74, 0xffff, v74                             // 000000D8583C: 369494FF 0000FFFF
	.long 0xd72c0048                                           // 000000D85844: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000D85848: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000D85850: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000D85854: 020288FF 83DCD12D
	.long 0xd72c00d0                                           // 000000D8585C: D72C00D0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v208, vcc_lo             // 000000D85860: 0203A0FF 83DCD12D
	v_lshl_or_b32 v69, v96, 16, v69                            // 000000D85868: D6560045 05152160
	.long 0xd72c004a                                           // 000000D85870: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000D85874: 020294FF 83DCD12D
	v_and_b32_e32 v235, 0xffff, v210                           // 000000D8587C: 37D7A4FF 0000FFFF
	v_sad_u8 v210, v223, 0, 0x6400                             // 000000D85884: D62200D2 03FD01DF 00006400
	v_sad_u8 v223, v226, 0, 0x6400                             // 000000D85890: D62200DF 03FD01E2 00006400
	v_pk_fma_f16 v227, v69, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D8589C: CC0E00E3 0BFC1B45 0000C931
	v_and_b32_e32 v203, 0xffff, v204                           // 000000D858A8: 379798FF 0000FFFF
	v_and_b32_e32 v204, 0xffff, v205                           // 000000D858B0: 37999AFF 0000FFFF
	v_and_b32_e32 v205, 0xffff, v206                           // 000000D858B8: 379B9CFF 0000FFFF
	v_and_b32_e32 v206, 0xffff, v207                           // 000000D858C0: 379D9EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D858C8: D6220048 03FD0148 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000D858D4: D6220044 03FD0144 00006400
	v_sad_u8 v208, v208, 0, 0x6400                             // 000000D858E0: D62200D0 03FD01D0 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000D858EC: D622004A 03FD014A 00006400
	.long 0xd72c00ce                                           // 000000D858F8: D72C00CE
	v_cndmask_b32_e32 v1, 0x83dcd12d, v206, vcc_lo             // 000000D858FC: 02039CFF 83DCD12D
	v_and_b32_e32 v70, 0xffff, v70                             // 000000D85904: 368C8CFF 0000FFFF
	.long 0xd72c00c7                                           // 000000D8590C: D72C00C7
	v_cndmask_b32_e32 v1, 0x83dcd12d, v199, vcc_lo             // 000000D85910: 02038EFF 83DCD12D
	v_and_b32_e32 v96, 0xffff, v208                            // 000000D85918: 36C1A0FF 0000FFFF
	.long 0xd72c00d4                                           // 000000D85920: D72C00D4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v212, vcc_lo             // 000000D85924: 0203A8FF 83DCD12D
	.long 0xd72c00d8                                           // 000000D8592C: D72C00D8
	v_cndmask_b32_e32 v1, 0x83dcd12d, v216, vcc_lo             // 000000D85930: 0203B0FF 83DCD12D
	.long 0xd72c0046                                           // 000000D85938: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000D8593C: 02028CFF 83DCD12D
	v_mov_b32_e32 v242, v227                                   // 000000D85944: 7FE403E3
	v_sad_u8 v206, v206, 0, 0x6400                             // 000000D85948: D62200CE 03FD01CE 00006400
	.long 0xd72c00cb                                           // 000000D85954: D72C00CB
	v_cndmask_b32_e32 v1, 0x83dcd12d, v203, vcc_lo             // 000000D85958: 020396FF 83DCD12D
	v_sad_u8 v199, v199, 0, 0x6400                             // 000000D85960: D62200C7 03FD01C7 00006400
	.long 0xd72c00d7                                           // 000000D8596C: D72C00D7
	v_cndmask_b32_e32 v1, 0x83dcd12d, v215, vcc_lo             // 000000D85970: 0203AEFF 83DCD12D
	v_bfe_u32 v229, v101, 4, 16                                // 000000D85978: D61000E5 02410965
	v_and_b32_e32 v206, 0xffff, v206                           // 000000D85980: 379D9CFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D85988: D6220046 03FD0146 00006400
	v_sad_u8 v212, v212, 0, 0x6400                             // 000000D85994: D62200D4 03FD01D4 00006400
	v_sad_u8 v216, v216, 0, 0x6400                             // 000000D859A0: D62200D8 03FD01D8 00006400
	v_sad_u8 v203, v203, 0, 0x6400                             // 000000D859AC: D62200CB 03FD01CB 00006400
	v_lshl_or_b32 v72, v72, 16, v206                           // 000000D859B8: D6560048 07392148
	v_and_b32_e32 v199, 0xffff, v199                           // 000000D859C0: 378F8EFF 0000FFFF
	v_bfe_u32 v99, v101, 12, 16                                // 000000D859C8: D6100063 02411965
	.long 0xd72c00d3                                           // 000000D859D0: D72C00D3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v229, vcc_lo             // 000000D859D4: 0203CAFF 83DCD12D
	v_and_b32_e32 v229, 0xffff, v209                           // 000000D859DC: 37CBA2FF 0000FFFF
	v_pk_fma_f16 v239, v72, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D859E4: CC0E00EF 0BFC1B48 0000C931
	v_sad_u8 v209, v222, 0, 0x6400                             // 000000D859F0: D62200D1 03FD01DE 00006400
	v_sad_u8 v215, v215, 0, 0x6400                             // 000000D859FC: D62200D7 03FD01D7 00006400
	v_and_b32_e32 v198, 0xffff, v198                           // 000000D85A08: 378D8CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D85A10: BF870004
	v_dual_mov_b32 v245, v239 :: v_dual_lshlrev_b32 v212, 16, v212// 000000D85A14: CA2201EF F5D5A890
	.long 0xd72c00cc                                           // 000000D85A1C: D72C00CC
	v_cndmask_b32_e32 v1, 0x83dcd12d, v204, vcc_lo             // 000000D85A20: 020398FF 83DCD12D
	v_lshlrev_b32_e32 v216, 16, v216                           // 000000D85A28: 31B1B090
	v_lshlrev_b32_e32 v224, 16, v224                           // 000000D85A2C: 31C1C090
	.long 0xd72c00d5                                           // 000000D85A30: D72C00D5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v213, vcc_lo             // 000000D85A34: 0203AAFF 83DCD12D
	v_bfe_u32 v228, v101, 8, 16                                // 000000D85A3C: D61000E4 02411165
	.long 0xd72c0063                                           // 000000D85A44: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000D85A48: 0202C6FF 83DCD12D
	.long 0xd72c00c9                                           // 000000D85A50: D72C00C9
	v_cndmask_b32_e32 v1, 0x83dcd12d, v201, vcc_lo             // 000000D85A54: 020392FF 83DCD12D
	v_lshl_or_b32 v198, v209, 16, v198                         // 000000D85A5C: D65600C6 071921D1
	v_sad_u8 v204, v204, 0, 0x6400                             // 000000D85A64: D62200CC 03FD01CC 00006400
	v_and_or_b32 v209, 0xffff, v210, v212                      // 000000D85A70: D65700D1 0753A4FF 0000FFFF
	v_and_or_b32 v212, 0xffff, v215, v216                      // 000000D85A7C: D65700D4 0763AEFF 0000FFFF
	v_and_or_b32 v216, 0xffff, v223, v224                      // 000000D85A88: D65700D8 0783BEFF 0000FFFF
	.long 0xd72c00d6                                           // 000000D85A94: D72C00D6
	v_cndmask_b32_e32 v1, 0x83dcd12d, v214, vcc_lo             // 000000D85A98: 0203ACFF 83DCD12D
	v_and_b32_e32 v204, 0xffff, v204                           // 000000D85AA0: 379998FF 0000FFFF
	.long 0xd72c00cf                                           // 000000D85AA8: D72C00CF
	v_cndmask_b32_e32 v1, 0x83dcd12d, v228, vcc_lo             // 000000D85AAC: 0203C8FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000D85AB4: 369292FF 0000FFFF
	v_sad_u8 v213, v213, 0, 0x6400                             // 000000D85ABC: D62200D5 03FD01D5 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000D85AC8: D6220063 03FD0163 00006400
	v_lshl_or_b32 v68, v68, 16, v204                           // 000000D85AD4: D6560044 07312144
	v_sad_u8 v201, v201, 0, 0x6400                             // 000000D85ADC: D62200C9 03FD01C9 00006400
	v_and_b32_e32 v98, 0xffff, v98                             // 000000D85AE8: 36C4C4FF 0000FFFF
	.long 0xd72c0049                                           // 000000D85AF0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000D85AF4: 020292FF 83DCD12D
	v_sad_u8 v214, v214, 0, 0x6400                             // 000000D85AFC: D62200D6 03FD01D6 00006400
	v_pk_fma_f16 v226, v68, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85B08: CC0E00E2 0BFC1B44 0000C931
	v_lshl_or_b32 v68, v74, 16, v96                            // 000000D85B14: D6560044 0581214A
	v_and_b32_e32 v213, 0xffff, v213                           // 000000D85B1C: 37ABAAFF 0000FFFF
	v_sad_u8 v207, v207, 0, 0x6400                             // 000000D85B24: D62200CF 03FD01CF 00006400
	v_and_b32_e32 v99, 0xffff, v99                             // 000000D85B30: 36C6C6FF 0000FFFF
	v_mov_b32_e32 v241, v226                                   // 000000D85B38: 7FE203E2
	v_pk_fma_f16 v247, v68, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85B3C: CC0E00F7 0BFC1B44 0000C931
	.long 0xd72c00c8                                           // 000000D85B48: D72C00C8
	v_cndmask_b32_e32 v1, 0x83dcd12d, v200, vcc_lo             // 000000D85B4C: 020390FF 83DCD12D
	v_and_b32_e32 v201, 0xffff, v201                           // 000000D85B54: 379392FF 0000FFFF
	.long 0xd72c0062                                           // 000000D85B5C: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000D85B60: 0202C4FF 83DCD12D
	v_lshl_or_b32 v210, v214, 16, v213                         // 000000D85B68: D65600D2 075521D6
	v_mov_b32_e32 v248, v247                                   // 000000D85B70: 7FF003F7
	.long 0xd72c00cd                                           // 000000D85B74: D72C00CD
	v_cndmask_b32_e32 v1, 0x83dcd12d, v205, vcc_lo             // 000000D85B78: 02039AFF 83DCD12D
	v_sad_u8 v222, v225, 0, 0x6400                             // 000000D85B80: D62200DE 03FD01E1 00006400
	v_and_b32_e32 v221, 0xffff, v221                           // 000000D85B8C: 37BBBAFF 0000FFFF
	v_sad_u8 v200, v200, 0, 0x6400                             // 000000D85B94: D62200C8 03FD01C8 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000D85BA0: D6220049 03FD0149 00006400
	v_lshl_or_b32 v99, v207, 16, v99                           // 000000D85BAC: D6560063 058D21CF
	v_pk_fma_f16 v210, v210, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85BB4: CC0E00D2 0BFC1BD2 0000C931
	v_add_nc_u32_e32 v45, s30, v95                             // 000000D85BC0: 4A5ABE1E
	v_sad_u8 v205, v205, 0, 0x6400                             // 000000D85BC4: D62200CD 03FD01CD 00006400
	v_lshl_or_b32 v199, v200, 16, v199                         // 000000D85BD0: D65600C7 071D21C8
	v_lshl_or_b32 v215, v222, 16, v221                         // 000000D85BD8: D65600D7 077521DE
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000D85BE0: D6220062 03FD0162 00006400
	v_pk_fma_f16 v198, v198, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85BEC: CC0E00C6 0BFC1BC6 0000C931
	v_and_b32_e32 v205, 0xffff, v205                           // 000000D85BF8: 379B9AFF 0000FFFF
	v_pk_fma_f16 v209, v209, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85C00: CC0E00D1 0BFC1BD1 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 000000D85C0C: 369292FF 0000FFFF
	v_pk_fma_f16 v99, v99, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D85C14: CC0E0063 0BFC1B63 0000C931
	v_pk_fma_f16 v199, v199, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85C20: CC0E00C7 0BFC1BC7 0000C931
	v_lshl_or_b32 v70, v70, 16, v205                           // 000000D85C2C: D6560046 07352146
	v_and_b32_e32 v101, 0xffff, v101                           // 000000D85C34: 36CACAFF 0000FFFF
	s_cselect_b32 s30, 64, 0x4440                              // 000000D85C3C: 981EFFC0 00004440
	v_dual_mov_b32 v97, v198 :: v_dual_add_nc_u32 v122, s29, v95// 000000D85C44: CA2001C6 617ABE1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D85C4C: BF870243
	v_pk_fma_f16 v237, v70, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85C50: CC0E00ED 0BFC1B46 0000C931
	v_dual_mov_b32 v71, v99 :: v_dual_add_nc_u32 v146, s30, v95// 000000D85C5C: CA200163 4792BE1E
	v_mov_b32_e32 v72, v199                                    // 000000D85C64: 7E9003C7
	.long 0xd72c0065                                           // 000000D85C68: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000D85C6C: 0202CAFF 83DCD12D
	v_mov_b32_e32 v243, v237                                   // 000000D85C74: 7FE603ED
	.long 0xd72c00ca                                           // 000000D85C78: D72C00CA
	v_cndmask_b32_e32 v1, 0x83dcd12d, v202, vcc_lo             // 000000D85C7C: 020394FF 83DCD12D
	v_permlanex16_b32 v97, v97, s21, 0xfedcba98                // 000000D85C84: D65C0061 03FC2B61 FEDCBA98
	v_permlanex16_b32 v71, v71, s21, 0xfedcba98                // 000000D85C90: D65C0047 03FC2B47 FEDCBA98
	v_permlanex16_b32 v72, v72, s21, 0xfedcba98                // 000000D85C9C: D65C0048 03FC2B48 FEDCBA98
	s_waitcnt vmcnt(6)                                         // 000000D85CA8: BF891BF7
	v_bfe_u32 v76, v100, 12, 16                                // 000000D85CAC: D610004C 02411964
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D85CB4: 369696FF 0000FFFF
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000D85CBC: D6220065 03FD0165 00006400
	v_cndmask_b32_e64 v69, v97, v198, s3                       // 000000D85CC8: D5010045 000F8D61
	v_sad_u8 v202, v202, 0, 0x6400                             // 000000D85CD0: D62200CA 03FD01CA 00006400
	v_cndmask_b32_e64 v224, v71, v99, s3                       // 000000D85CDC: D50100E0 000EC747
	v_cndmask_b32_e64 v228, v99, v71, s3                       // 000000D85CE4: D50100E4 000E8F63
	v_cndmask_b32_e64 v71, v199, v72, s3                       // 000000D85CEC: D5010047 000E91C7
	v_sad_u8 v211, v211, 0, 0x6400                             // 000000D85CF4: D62200D3 03FD01D3 00006400
	v_and_b32_e32 v202, 0xffff, v202                           // 000000D85D00: 379594FF 0000FFFF
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000D85D08: 30CACA90
	.long 0xd72c00d9                                           // 000000D85D0C: D72C00D9
	v_cndmask_b32_e32 v1, 0x83dcd12d, v217, vcc_lo             // 000000D85D10: 0203B2FF 83DCD12D
	.long 0xd72c00dc                                           // 000000D85D18: D72C00DC
	v_cndmask_b32_e32 v1, 0x83dcd12d, v220, vcc_lo             // 000000D85D1C: 0203B8FF 83DCD12D
	v_bfe_u32 v234, v100, 8, 16                                // 000000D85D24: D61000EA 02411164
	v_lshl_or_b32 v200, v203, 16, v202                         // 000000D85D2C: D65600C8 072921CB
	v_mov_b32_e32 v202, v210                                   // 000000D85D34: 7F9403D2
	ds_load_b128 v[25:28], v45                                 // 000000D85D38: DBFC0000 1900002D
	ds_load_b128 v[29:32], v45 offset:16                       // 000000D85D40: DBFC0010 1D00002D
	ds_load_b128 v[33:36], v45 offset:4352                     // 000000D85D48: DBFC1100 2100002D
	ds_load_b128 v[37:40], v45 offset:4368                     // 000000D85D50: DBFC1110 2500002D
	ds_load_b128 v[41:44], v45 offset:8704                     // 000000D85D58: DBFC2200 2900002D
	ds_load_b128 v[45:48], v45 offset:8720                     // 000000D85D60: DBFC2210 2D00002D
	.long 0xd72c004b                                           // 000000D85D68: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000D85D6C: 020296FF 83DCD12D
	v_and_or_b32 v101, 0xffff, v211, v101                      // 000000D85D74: D6570065 0597A6FF 0000FFFF
	v_pk_fma_f16 v223, v200, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85D80: CC0E00DF 0BFC1BC8 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 000000D85D8C: 368686FF 0000FFFF
	.long 0xd72c00da                                           // 000000D85D94: D72C00DA
	v_cndmask_b32_e32 v1, 0x83dcd12d, v218, vcc_lo             // 000000D85D98: 0203B4FF 83DCD12D
	.long 0xd72c00db                                           // 000000D85DA0: D72C00DB
	v_cndmask_b32_e32 v1, 0x83dcd12d, v219, vcc_lo             // 000000D85DA4: 0203B6FF 83DCD12D
	v_sad_u8 v217, v217, 0, 0x6400                             // 000000D85DAC: D62200D9 03FD01D9 00006400
	v_mov_b32_e32 v240, v223                                   // 000000D85DB8: 7FE003DF
	.long 0xd72c0043                                           // 000000D85DBC: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000D85DC0: 020286FF 83DCD12D
	v_sad_u8 v220, v220, 0, 0x6400                             // 000000D85DC8: D62200DC 03FD01DC 00006400
	v_pk_fma_f16 v212, v212, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85DD4: CC0E00D4 0BFC1BD4 0000C931
	v_pk_fma_f16 v101, v101, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85DE0: CC0E0065 0BFC1B65 0000C931
	v_sad_u8 v218, v218, 0, 0x6400                             // 000000D85DEC: D62200DA 03FD01DA 00006400
	v_sad_u8 v219, v219, 0, 0x6400                             // 000000D85DF8: D62200DB 03FD01DB 00006400
	v_and_b32_e32 v217, 0xffff, v217                           // 000000D85E04: 37B3B2FF 0000FFFF
	v_lshlrev_b32_e32 v220, 16, v220                           // 000000D85E0C: 31B9B890
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000D85E10: D6220043 03FD0143 00006400
	v_dual_mov_b32 v203, v212 :: v_dual_add_nc_u32 v170, s31, v95// 000000D85E1C: CA2001D4 CBAABE1F
	v_mov_b32_e32 v96, v101                                    // 000000D85E24: 7EC00365
	v_lshl_or_b32 v213, v218, 16, v217                         // 000000D85E28: D65600D5 076521DA
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D85E30: BF870004
	v_lshl_or_b32 v67, v67, 16, v201                           // 000000D85E34: D6560043 07252143
	v_mov_b32_e32 v201, v209                                   // 000000D85E3C: 7F9203D1
	v_and_or_b32 v214, 0xffff, v219, v220                      // 000000D85E40: D65700D6 0773B6FF 0000FFFF
	v_permlanex16_b32 v203, v203, s21, 0xfedcba98              // 000000D85E4C: D65C00CB 03FC2BCB FEDCBA98
	v_permlanex16_b32 v96, v96, s21, 0xfedcba98                // 000000D85E58: D65C0060 03FC2B60 FEDCBA98
	v_pk_fma_f16 v222, v67, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85E64: CC0E00DE 0BFC1B43 0000C931
	v_lshl_or_b32 v67, v98, 16, v73                            // 000000D85E70: D6560043 05252162
	v_permlanex16_b32 v201, v201, s21, 0xfedcba98              // 000000D85E78: D65C00C9 03FC2BC9 FEDCBA98
	v_cndmask_b32_e64 v73, v198, v97, s3                       // 000000D85E84: D5010049 000EC3C6
	v_permlanex16_b32 v241, v241, s21, 0xfedcba98              // 000000D85E8C: D65C00F1 03FC2BF1 FEDCBA98
	v_mov_b32_e32 v98, v222                                    // 000000D85E98: 7EC403DE
	v_pk_fma_f16 v246, v67, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D85E9C: CC0E00F6 0BFC1B43 0000C931
	v_cndmask_b32_e64 v70, v201, v209, s3                      // 000000D85EA8: D5010046 000FA3C9
	v_cndmask_b32_e64 v74, v209, v201, s3                      // 000000D85EB0: D501004A 000F93D1
	v_cndmask_b32_e64 v67, v72, v199, s3                       // 000000D85EB8: D5010043 000F8F48
	v_permlanex16_b32 v98, v98, s21, 0xfedcba98                // 000000D85EC0: D65C0062 03FC2B62 FEDCBA98
	v_mov_b32_e32 v97, v246                                    // 000000D85ECC: 7EC203F6
	v_pk_fma_f16 v213, v213, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85ED0: CC0E00D5 0BFC1BD5 0000C931
	v_pk_fma_f16 v214, v214, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85EDC: CC0E00D6 0BFC1BD6 0000C931
	v_pk_fma_f16 v215, v215, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D85EE8: CC0E00D7 0BFC1BD7 0000C931
	v_cndmask_b32_e64 v68, v98, v222, s3                       // 000000D85EF4: D5010044 000FBD62
	v_cndmask_b32_e64 v72, v222, v98, s3                       // 000000D85EFC: D5010048 000EC5DE
	v_permlanex16_b32 v97, v97, s21, 0xfedcba98                // 000000D85F04: D65C0061 03FC2B61 FEDCBA98
	v_cndmask_b32_e64 v201, v203, v212, s3                     // 000000D85F10: D50100C9 000FA9CB
	v_cndmask_b32_e64 v205, v212, v203, s3                     // 000000D85F18: D50100CD 000F97D4
	v_cndmask_b32_e64 v225, v96, v101, s3                      // 000000D85F20: D50100E1 000ECB60
	s_waitcnt lgkmcnt(4)                                       // 000000D85F28: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[67:74], v[25:32], v[17:24]// 000000D85F2C: CC404011 1C463343
	.long 0xd72c001a                                           // 000000D85F34: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v235, vcc_lo             // 000000D85F38: 0203D6FF 83DCD12D
	v_and_b32_e32 v27, 0xffff, v100                            // 000000D85F40: 3636C8FF 0000FFFF
	.long 0xd72c001d                                           // 000000D85F48: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000D85F4C: 020298FF 83DCD12D
	v_bfe_u32 v28, v100, 4, 16                                 // 000000D85F54: D610001C 02410964
	.long 0xd72c001e                                           // 000000D85F5C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v229, vcc_lo             // 000000D85F60: 0203CAFF 83DCD12D
	.long 0xd72c001f                                           // 000000D85F68: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v236, vcc_lo             // 000000D85F6C: 0203D8FF 83DCD12D
	.long 0xd72c001b                                           // 000000D85F74: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000D85F78: 020236FF 83DCD12D
	.long 0xd72c0020                                           // 000000D85F80: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v234, vcc_lo             // 000000D85F84: 0203D4FF 83DCD12D
	v_sad_u8 v25, v75, 0, 0x6400                               // 000000D85F8C: D6220019 03FD014B 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000D85F98: D622001A 03FD011A 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000D85FA4: D622001D 03FD011D 00006400
	.long 0xd72c001c                                           // 000000D85FB0: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 000000D85FB4: 020238FF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000D85FBC: D622001E 03FD011E 00006400
	v_and_b32_e32 v25, 0xffff, v25                             // 000000D85FC8: 363232FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 000000D85FD0: 363434FF 0000FFFF
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000D85FD8: D622001B 03FD011B 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000D85FE4: D622001F 03FD011F 00006400
	v_and_b32_e32 v29, 0xffff, v29                             // 000000D85FF0: 363A3AFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000D85FF8: D6220020 03FD0120 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000D86004: D622001C 03FD011C 00006400
	v_lshlrev_b32_e32 v27, 16, v27                             // 000000D86010: 30363690
	v_lshl_or_b32 v25, v30, 16, v25                            // 000000D86014: D6560019 0465211E
	v_lshl_or_b32 v26, v31, 16, v26                            // 000000D8601C: D656001A 0469211F
	v_lshl_or_b32 v29, v32, 16, v29                            // 000000D86024: D656001D 04752120
	v_cndmask_b32_e64 v199, v241, v226, s3                     // 000000D8602C: D50100C7 000FC5F1
	v_and_or_b32 v27, 0xffff, v28, v27                         // 000000D86034: D657001B 046E38FF 0000FFFF
	v_pk_fma_f16 v28, v25, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D86040: CC0E001C 0BFC1B19 0000C931
	v_pk_fma_f16 v30, v26, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D8604C: CC0E001E 0BFC1B1A 0000C931
	v_pk_fma_f16 v31, v29, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D86058: CC0E001F 0BFC1B1D 0000C931
	v_cndmask_b32_e64 v203, v226, v241, s3                     // 000000D86064: D50100CB 000FE3E2
	s_waitcnt lgkmcnt(2)                                       // 000000D8606C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[67:74], v[33:40], v[9:16]// 000000D86070: CC404009 1C264343
	v_cndmask_b32_e64 v222, v97, v246, s3                      // 000000D86078: D50100DE 000FED61
	v_cndmask_b32_e64 v226, v246, v97, s3                      // 000000D86080: D50100E2 000EC3F6
	v_cndmask_b32_e64 v229, v101, v96, s3                      // 000000D86088: D50100E5 000EC165
	s_waitcnt vmcnt(4)                                         // 000000D86090: BF8913F7
	.long 0xd73d0020                                           // 000000D86094: D73D0020
	v_cndmask_b32_e32 v1, v84, v77, vcc_lo                     // 000000D86098: 02029B54
	.long 0xd73d0060                                           // 000000D8609C: D73D0060
	v_cndmask_b32_e32 v1, v86, v77, vcc_lo                     // 000000D860A0: 02029B56
	v_dual_mov_b32 v207, v214 :: v_dual_add_nc_u32 v194, s33, v95// 000000D860A4: CA2001D6 CFC2BE21
	v_pk_fma_f16 v218, v216, s13, 0xc931 op_sel_hi:[1,0,0]     // 000000D860AC: CC0E00DA 0BFC1BD8 0000C931
	v_dual_mov_b32 v206, v213 :: v_dual_mov_b32 v211, v215     // 000000D860B8: CA1001D5 CED201D7
	v_permlanex16_b32 v202, v202, s21, 0xfedcba98              // 000000D860C0: D65C00CA 03FC2BCA FEDCBA98
	v_permlanex16_b32 v240, v240, s21, 0xfedcba98              // 000000D860CC: D65C00F0 03FC2BF0 FEDCBA98
	v_pk_fma_f16 v98, v27, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D860D8: CC0E0062 0BFC1B1B 0000C931
	v_dual_mov_b32 v26, v28 :: v_dual_mov_b32 v27, v30         // 000000D860E4: CA10011C 1A1A011E
	v_mov_b32_e32 v34, v31                                     // 000000D860EC: 7E44031F
	.long 0xd73d004b                                           // 000000D860F0: D73D004B
	v_cndmask_b32_e32 v1, v85, v77, vcc_lo                     // 000000D860F4: 02029B55
	.long 0xd73d004c                                           // 000000D860F8: D73D004C
	v_cndmask_b32_e32 v1, v87, v77, vcc_lo                     // 000000D860FC: 02029B57
	v_and_b32_e32 v32, 0xffff, v32                             // 000000D86100: 364040FF 0000FFFF
	v_and_b32_e32 v77, 0xffff, v96                             // 000000D86108: 369AC0FF 0000FFFF
	s_cselect_b32 s29, s24, 0x44a0                             // 000000D86110: 981DFF18 000044A0
	v_mov_b32_e32 v219, v218                                   // 000000D86118: 7FB603DA
	v_permlanex16_b32 v206, v206, s21, 0xfedcba98              // 000000D8611C: D65C00CE 03FC2BCE FEDCBA98
	v_permlanex16_b32 v207, v207, s21, 0xfedcba98              // 000000D86128: D65C00CF 03FC2BCF FEDCBA98
	v_permlanex16_b32 v211, v211, s21, 0xfedcba98              // 000000D86134: D65C00D3 03FC2BD3 FEDCBA98
	v_cndmask_b32_e64 v200, v202, v210, s3                     // 000000D86140: D50100C8 000FA5CA
	v_cndmask_b32_e64 v204, v210, v202, s3                     // 000000D86148: D50100CC 000F95D2
	v_permlanex16_b32 v242, v242, s21, 0xfedcba98              // 000000D86150: D65C00F2 03FC2BF2 FEDCBA98
	v_permlanex16_b32 v243, v243, s21, 0xfedcba98              // 000000D8615C: D65C00F3 03FC2BF3 FEDCBA98
	v_cndmask_b32_e64 v198, v240, v223, s3                     // 000000D86168: D50100C6 000FBFF0
	v_cndmask_b32_e64 v202, v223, v240, s3                     // 000000D86170: D50100CA 000FE1DF
	s_waitcnt lgkmcnt(0)                                       // 000000D86178: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[67:74], v[41:48], v[1:8] // 000000D8617C: CC404001 1C065343
	v_permlanex16_b32 v26, v26, s21, 0xfedcba98                // 000000D86184: D65C001A 03FC2B1A FEDCBA98
	v_permlanex16_b32 v27, v27, s21, 0xfedcba98                // 000000D86190: D65C001B 03FC2B1B FEDCBA98
	v_permlanex16_b32 v34, v34, s21, 0xfedcba98                // 000000D8619C: D65C0022 03FC2B22 FEDCBA98
	v_add_nc_u32_e32 v71, s29, v95                             // 000000D861A8: 4A8EBE1D
	.long 0xd72c0020                                           // 000000D861AC: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000D861B0: 020240FF 83DCD12D
	v_and_b32_e32 v75, 0xffff, v75                             // 000000D861B8: 369696FF 0000FFFF
	v_and_b32_e32 v76, 0xffff, v76                             // 000000D861C0: 369898FF 0000FFFF
	.long 0xd72c004d                                           // 000000D861C8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000D861CC: 02029AFF 83DCD12D
	ds_load_b128 v[102:105], v122                              // 000000D861D4: DBFC0000 6600007A
	ds_load_b128 v[106:109], v122 offset:16                    // 000000D861DC: DBFC0010 6A00007A
	ds_load_b128 v[110:113], v122 offset:4352                  // 000000D861E4: DBFC1100 6E00007A
	ds_load_b128 v[114:117], v122 offset:4368                  // 000000D861EC: DBFC1110 7200007A
	ds_load_b128 v[118:121], v122 offset:8704                  // 000000D861F4: DBFC2200 7600007A
	ds_load_b128 v[122:125], v122 offset:8720                  // 000000D861FC: DBFC2210 7A00007A
	ds_load_b128 v[126:129], v146                              // 000000D86204: DBFC0000 7E000092
	ds_load_b128 v[130:133], v146 offset:16                    // 000000D8620C: DBFC0010 82000092
	ds_load_b128 v[134:137], v146 offset:4352                  // 000000D86214: DBFC1100 86000092
	ds_load_b128 v[138:141], v146 offset:4368                  // 000000D8621C: DBFC1110 8A000092
	ds_load_b128 v[142:145], v146 offset:8704                  // 000000D86224: DBFC2200 8E000092
	ds_load_b128 v[146:149], v146 offset:8720                  // 000000D8622C: DBFC2210 92000092
	ds_load_b128 v[150:153], v170                              // 000000D86234: DBFC0000 960000AA
	ds_load_b128 v[154:157], v170 offset:16                    // 000000D8623C: DBFC0010 9A0000AA
	ds_load_b128 v[158:161], v170 offset:4352                  // 000000D86244: DBFC1100 9E0000AA
	ds_load_b128 v[162:165], v170 offset:4368                  // 000000D8624C: DBFC1110 A20000AA
	ds_load_b128 v[166:169], v170 offset:8704                  // 000000D86254: DBFC2200 A60000AA
	ds_load_b128 v[170:173], v170 offset:8720                  // 000000D8625C: DBFC2210 AA0000AA
	ds_load_b128 v[174:177], v194                              // 000000D86264: DBFC0000 AE0000C2
	ds_load_b128 v[178:181], v194 offset:16                    // 000000D8626C: DBFC0010 B20000C2
	ds_load_b128 v[182:185], v194 offset:4352                  // 000000D86274: DBFC1100 B60000C2
	ds_load_b128 v[186:189], v194 offset:4368                  // 000000D8627C: DBFC1110 BA0000C2
	ds_load_b128 v[190:193], v194 offset:8704                  // 000000D86284: DBFC2200 BE0000C2
	ds_load_b128 v[194:197], v194 offset:8720                  // 000000D8628C: DBFC2210 C20000C2
	v_permlanex16_b32 v219, v219, s21, 0xfedcba98              // 000000D86294: D65C00DB 03FC2BDB FEDCBA98
	v_cndmask_b32_e64 v208, v206, v213, s3                     // 000000D862A0: D50100D0 000FABCE
	v_cndmask_b32_e64 v212, v213, v206, s3                     // 000000D862A8: D50100D4 000F9DD5
	v_cndmask_b32_e64 v209, v207, v214, s3                     // 000000D862B0: D50100D1 000FADCF
	v_cndmask_b32_e64 v213, v214, v207, s3                     // 000000D862B8: D50100D5 000F9FD6
	v_cndmask_b32_e64 v216, v211, v215, s3                     // 000000D862C0: D50100D8 000FAFD3
	v_cndmask_b32_e64 v220, v215, v211, s3                     // 000000D862C8: D50100DC 000FA7D7
	v_permlanex16_b32 v244, v244, s21, 0xfedcba98              // 000000D862D0: D65C00F4 03FC2BF4 FEDCBA98
	v_permlanex16_b32 v245, v245, s21, 0xfedcba98              // 000000D862DC: D65C00F5 03FC2BF5 FEDCBA98
	v_cndmask_b32_e64 v206, v242, v227, s3                     // 000000D862E8: D50100CE 000FC7F2
	v_cndmask_b32_e64 v210, v227, v242, s3                     // 000000D862F0: D50100D2 000FE5E3
	v_cndmask_b32_e64 v207, v243, v237, s3                     // 000000D862F8: D50100CF 000FDBF3
	v_cndmask_b32_e64 v211, v237, v243, s3                     // 000000D86300: D50100D3 000FE7ED
	s_waitcnt lgkmcnt(22)                                      // 000000D86308: BF89FD67
	v_wmma_f32_16x16x16_f16 v[17:24], v[198:205], v[102:109], v[17:24]// 000000D8630C: CC404011 1C46CDC6
	v_cndmask_b32_e64 v25, v26, v28, s3                        // 000000D86314: D5010019 000E391A
	v_cndmask_b32_e64 v29, v28, v26, s3                        // 000000D8631C: D501001D 000E351C
	v_cndmask_b32_e64 v26, v27, v30, s3                        // 000000D86324: D501001A 000E3D1B
	v_cndmask_b32_e64 v30, v30, v27, s3                        // 000000D8632C: D501001E 000E371E
	v_cndmask_b32_e64 v27, v34, v31, s3                        // 000000D86334: D501001B 000E3F22
	v_cndmask_b32_e64 v31, v31, v34, s3                        // 000000D8633C: D501001F 000E451F
	ds_load_b128 v[33:36], v71                                 // 000000D86344: DBFC0000 21000047
	ds_load_b128 v[37:40], v71 offset:16                       // 000000D8634C: DBFC0010 25000047
	.long 0xd72c004b                                           // 000000D86354: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000D86358: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 000000D86360: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000D86364: 020298FF 83DCD12D
	v_cndmask_b32_e64 v217, v219, v218, s3                     // 000000D8636C: D50100D9 000FB5DB
	v_cndmask_b32_e64 v221, v218, v219, s3                     // 000000D86374: D50100DD 000FB7DA
	v_cndmask_b32_e64 v214, v244, v238, s3                     // 000000D8637C: D50100D6 000FDDF4
	v_cndmask_b32_e64 v218, v238, v244, s3                     // 000000D86384: D50100DA 000FE9EE
	v_cndmask_b32_e64 v215, v245, v239, s3                     // 000000D8638C: D50100D7 000FDFF5
	v_cndmask_b32_e64 v219, v239, v245, s3                     // 000000D86394: D50100DB 000FEBEF
	v_permlanex16_b32 v248, v248, s21, 0xfedcba98              // 000000D8639C: D65C00F8 03FC2BF8 FEDCBA98
	s_waitcnt lgkmcnt(18)                                      // 000000D863A8: BF89FD27
	v_wmma_f32_16x16x16_f16 v[17:24], v[206:213], v[126:133], v[17:24]// 000000D863AC: CC404011 1C46FDCE
	v_mov_b32_e32 v99, v98                                     // 000000D863B4: 7EC60362
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000D863B8: D6220020 03FD0120 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D863C4: D622004D 03FD014D 00006400
	v_cndmask_b32_e64 v223, v248, v247, s3                     // 000000D863D0: D50100DF 000FEFF8
	v_cndmask_b32_e64 v227, v247, v248, s3                     // 000000D863D8: D50100E3 000FF1F7
	s_waitcnt lgkmcnt(12)                                      // 000000D863E0: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[17:24], v[214:221], v[150:157], v[17:24]// 000000D863E4: CC404011 1C472DD6
	v_permlanex16_b32 v99, v99, s21, 0xfedcba98                // 000000D863EC: D65C0063 03FC2B63 FEDCBA98
	v_and_b32_e32 v32, 0xffff, v32                             // 000000D863F8: 364040FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D86400: D622004B 03FD014B 00006400
	v_and_b32_e32 v77, 0xffff, v77                             // 000000D8640C: 369A9AFF 0000FFFF
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D86414: D622004C 03FD014C 00006400
	v_wmma_f32_16x16x16_f16 v[9:16], v[198:205], v[110:117], v[9:16]// 000000D86420: CC404009 1C26DDC6
	v_wmma_f32_16x16x16_f16 v[1:8], v[198:205], v[118:125], v[1:8]// 000000D86428: CC404001 1C06EDC6
	s_waitcnt lgkmcnt(6)                                       // 000000D86430: BF89FC67
	v_wmma_f32_16x16x16_f16 v[17:24], v[222:229], v[174:181], v[17:24]// 000000D86434: CC404011 1C475DDE
	v_cndmask_b32_e64 v28, v99, v98, s3                        // 000000D8643C: D501001C 000EC563
	ds_load_b128 v[41:44], v71 offset:4352                     // 000000D86444: DBFC1100 29000047
	ds_load_b128 v[45:48], v71 offset:4368                     // 000000D8644C: DBFC1110 2D000047
	ds_load_b128 v[67:70], v71 offset:8704                     // 000000D86454: DBFC2200 43000047
	ds_load_b128 v[71:74], v71 offset:8720                     // 000000D8645C: DBFC2210 47000047
	v_lshl_or_b32 v75, v75, 16, v32                            // 000000D86464: D656004B 0481214B
	v_cndmask_b32_e64 v32, v98, v99, s3                        // 000000D8646C: D5010020 000EC762
	v_lshl_or_b32 v76, v76, 16, v77                            // 000000D86474: D656004C 0535214C
	v_wmma_f32_16x16x16_f16 v[9:16], v[206:213], v[134:141], v[9:16]// 000000D8647C: CC404009 1C270DCE
	v_wmma_f32_16x16x16_f16 v[1:8], v[206:213], v[142:149], v[1:8]// 000000D86484: CC404001 1C071DCE
	v_pk_fma_f16 v75, v75, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D8648C: CC0E004B 0BFC1B4B 0000C931
	s_waitcnt lgkmcnt(4)                                       // 000000D86498: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000D8649C: CC404011 1C464319
	v_pk_fma_f16 v33, v76, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D864A4: CC0E0021 0BFC1B4C 0000C931
	v_wmma_f32_16x16x16_f16 v[9:16], v[214:221], v[158:165], v[9:16]// 000000D864B0: CC404009 1C273DD6
	v_wmma_f32_16x16x16_f16 v[1:8], v[214:221], v[166:173], v[1:8]// 000000D864B8: CC404001 1C074DD6
	v_mov_b32_e32 v34, v75                                     // 000000D864C0: 7E44034B
	s_waitcnt vmcnt(1)                                         // 000000D864C4: BF8907F7
	v_bfe_u32 v78, v232, 12, 16                                // 000000D864C8: D610004E 024119E8
	v_mov_b32_e32 v37, v33                                     // 000000D864D0: 7E4A0321
	v_wmma_f32_16x16x16_f16 v[9:16], v[222:229], v[182:189], v[9:16]// 000000D864D4: CC404009 1C276DDE
	v_wmma_f32_16x16x16_f16 v[1:8], v[222:229], v[190:197], v[1:8]// 000000D864DC: CC404001 1C077DDE
	v_permlanex16_b32 v34, v34, s21, 0xfedcba98                // 000000D864E4: D65C0022 03FC2B22 FEDCBA98
	v_and_b32_e32 v97, 0xffff, v232                            // 000000D864F0: 36C3D0FF 0000FFFF
	v_permlanex16_b32 v37, v37, s21, 0xfedcba98                // 000000D864F8: D65C0025 03FC2B25 FEDCBA98
	s_waitcnt lgkmcnt(2)                                       // 000000D86504: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000D86508: CC404009 1C265319
	s_waitcnt lgkmcnt(0)                                       // 000000D86510: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[67:74], v[1:8] // 000000D86514: CC404001 1C068719
	v_cndmask_b32_e64 v25, v34, v75, s3                        // 000000D8651C: D5010019 000E9722
	v_cndmask_b32_e64 v29, v75, v34, s3                        // 000000D86524: D501001D 000E454B
	v_cndmask_b32_e64 v26, v37, v33, s3                        // 000000D8652C: D501001A 000E4325
	v_cndmask_b32_e64 v30, v33, v37, s3                        // 000000D86534: D501001E 000E4B21
	.long 0xd73d0021                                           // 000000D8653C: D73D0021
	v_cndmask_b32_e32 v1, v84, v230, vcc_lo                    // 000000D86540: 0203CD54
	v_bfe_u32 v96, v232, 8, 16                                 // 000000D86544: D6100060 024111E8
	v_bfe_u32 v100, v232, 4, 16                                // 000000D8654C: D6100064 024109E8
	.long 0xd72c004e                                           // 000000D86554: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000D86558: 02029CFF 83DCD12D
	.long 0xd72c0061                                           // 000000D86560: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000D86564: 0202C2FF 83DCD12D
	.long 0xd73d0029                                           // 000000D8656C: D73D0029
	v_cndmask_b32_e32 v1, v85, v230, vcc_lo                    // 000000D86570: 0203CD55
	.long 0xd72c0060                                           // 000000D86574: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000D86578: 0202C0FF 83DCD12D
	.long 0xd72c0064                                           // 000000D86580: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000D86584: 0202C8FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v33                             // 000000D8658C: 365442FF 0000FFFF
	.long 0xd73d0043                                           // 000000D86594: D73D0043
	v_cndmask_b32_e32 v1, v86, v230, vcc_lo                    // 000000D86598: 0203CD56
	.long 0xd73d0044                                           // 000000D8659C: D73D0044
	v_cndmask_b32_e32 v1, v87, v230, vcc_lo                    // 000000D865A0: 0203CD57
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000D865A4: D622004E 03FD014E 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000D865B0: D6220061 03FD0161 00006400
	v_and_b32_e32 v69, 0xffff, v41                             // 000000D865BC: 368A52FF 0000FFFF
	.long 0xd72c0046                                           // 000000D865C4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000D865C8: 020254FF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000D865D0: D6220060 03FD0160 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000D865DC: 369C9CFF 0000FFFF
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000D865E4: D6220064 03FD0164 00006400
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000D865F0: 30C2C290
	v_and_b32_e32 v67, 0xffff, v67                             // 000000D865F4: 368686FF 0000FFFF
	s_waitcnt vmcnt(0)                                         // 000000D865FC: BF8903F7
	v_bfe_u32 v72, v233, 12, 16                                // 000000D86600: D6100048 024119E9
	.long 0xd72c0045                                           // 000000D86608: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000D8660C: 02028AFF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v233                            // 000000D86614: 3695D2FF 0000FFFF
	v_lshl_or_b32 v77, v96, 16, v78                            // 000000D8661C: D656004D 05392160
	v_and_or_b32 v78, 0xffff, v100, v97                        // 000000D86624: D657004E 0586C8FF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D86630: D6220046 03FD0146 00006400
	v_and_b32_e32 v68, 0xffff, v68                             // 000000D8663C: 368888FF 0000FFFF
	v_bfe_u32 v73, v233, 8, 16                                 // 000000D86644: D6100049 024111E9
	.long 0xd72c0043                                           // 000000D8664C: D72C0043
	v_cndmask_b32_e32 v1, 0x83dcd12d, v67, vcc_lo              // 000000D86650: 020286FF 83DCD12D
	.long 0xd72c0048                                           // 000000D86658: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000D8665C: 020290FF 83DCD12D
	v_bfe_u32 v75, v233, 4, 16                                 // 000000D86664: D610004B 024109E9
	.long 0xd72c004a                                           // 000000D8666C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000D86670: 020294FF 83DCD12D
	v_pk_fma_f16 v35, v77, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D86678: CC0E0023 0BFC1B4D 0000C931
	v_pk_fma_f16 v36, v78, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D86684: CC0E0024 0BFC1B4E 0000C931
	v_and_b32_e32 v70, 0xffff, v70                             // 000000D86690: 368C8CFF 0000FFFF
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D86698: D6220045 03FD0145 00006400
	.long 0xd72c0044                                           // 000000D866A4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000D866A8: 020288FF 83DCD12D
	.long 0xd72c0049                                           // 000000D866B0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000D866B4: 020292FF 83DCD12D
	.long 0xd72c004b                                           // 000000D866BC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000D866C0: 020296FF 83DCD12D
	v_dual_mov_b32 v38, v35 :: v_dual_mov_b32 v39, v36         // 000000D866C8: CA100123 26260124
	v_sad_u8 v67, v67, 0, 0x6400                               // 000000D866D0: D6220043 03FD0143 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D866DC: D6220048 03FD0148 00006400
	v_lshl_or_b32 v69, v69, 16, v70                            // 000000D866E8: D6560045 05192145
	v_sad_u8 v70, v74, 0, 0x6400                               // 000000D866F0: D6220046 03FD014A 00006400
	s_cselect_b32 s29, s25, 0x44c0                             // 000000D866FC: 981DFF19 000044C0
	v_permlanex16_b32 v38, v38, s21, 0xfedcba98                // 000000D86704: D65C0026 03FC2B26 FEDCBA98
	v_permlanex16_b32 v39, v39, s21, 0xfedcba98                // 000000D86710: D65C0027 03FC2B27 FEDCBA98
	v_add_nc_u32_e32 v71, s29, v95                             // 000000D8671C: 4A8EBE1D
	v_and_b32_e32 v67, 0xffff, v67                             // 000000D86720: 368686FF 0000FFFF
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000D86728: D6220044 03FD0144 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000D86734: 369090FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000D8673C: D6220049 03FD0149 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D86748: D622004B 03FD014B 00006400
	v_lshlrev_b32_e32 v77, 16, v70                             // 000000D86754: 309A8C90
	s_cselect_b32 s29, s26, 0x44e0                             // 000000D86758: 981DFF1A 000044E0
	v_cndmask_b32_e64 v27, v38, v35, s3                        // 000000D86760: D501001B 000E4726
	v_cndmask_b32_e64 v31, v35, v38, s3                        // 000000D86768: D501001F 000E4D23
	v_cndmask_b32_e64 v28, v39, v36, s3                        // 000000D86770: D501001C 000E4927
	v_cndmask_b32_e64 v32, v36, v39, s3                        // 000000D86778: D5010020 000E4F24
	ds_load_b128 v[33:36], v71                                 // 000000D86780: DBFC0000 21000047
	ds_load_b128 v[37:40], v71 offset:16                       // 000000D86788: DBFC0010 25000047
	ds_load_b128 v[41:44], v71 offset:4352                     // 000000D86790: DBFC1100 29000047
	ds_load_b128 v[45:48], v71 offset:4368                     // 000000D86798: DBFC1110 2D000047
	v_pk_fma_f16 v76, v69, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D867A0: CC0E004C 0BFC1B45 0000C931
	v_lshl_or_b32 v78, v68, 16, v67                            // 000000D867AC: D656004E 050D2144
	v_lshl_or_b32 v96, v73, 16, v72                            // 000000D867B4: D6560060 05212149
	ds_load_b128 v[67:70], v71 offset:8704                     // 000000D867BC: DBFC2200 43000047
	ds_load_b128 v[71:74], v71 offset:8720                     // 000000D867C4: DBFC2210 47000047
	v_and_or_b32 v75, 0xffff, v75, v77                         // 000000D867CC: D657004B 053696FF 0000FFFF
	v_add_nc_u32_e32 v116, s29, v95                            // 000000D867D8: 4AE8BE1D
	v_pk_fma_f16 v77, v78, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D867DC: CC0E004D 0BFC1B4E 0000C931
	v_pk_fma_f16 v120, v96, s13, 0xc931 op_sel_hi:[1,0,0]      // 000000D867E8: CC0E0078 0BFC1B60 0000C931
	ds_load_b128 v[96:99], v116                                // 000000D867F4: DBFC0000 60000074
	ds_load_b128 v[100:103], v116 offset:16                    // 000000D867FC: DBFC0010 64000074
	ds_load_b128 v[104:107], v116 offset:4352                  // 000000D86804: DBFC1100 68000074
	ds_load_b128 v[108:111], v116 offset:4368                  // 000000D8680C: DBFC1110 6C000074
	ds_load_b128 v[112:115], v116 offset:8704                  // 000000D86814: DBFC2200 70000074
	ds_load_b128 v[116:119], v116 offset:8720                  // 000000D8681C: DBFC2210 74000074
	v_pk_fma_f16 v75, v75, s13, 0xc931 op_sel_hi:[1,0,0]       // 000000D86824: CC0E004B 0BFC1B4B 0000C931
	v_dual_mov_b32 v78, v76 :: v_dual_mov_b32 v121, v77        // 000000D86830: CA10014C 4E78014D
	v_mov_b32_e32 v122, v120                                   // 000000D86838: 7EF40378
	s_and_not1_b32 vcc_lo, exec_lo, s27                        // 000000D8683C: 916A1B7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86840: BF870193
	v_mov_b32_e32 v123, v75                                    // 000000D86844: 7EF6034B
	v_permlanex16_b32 v78, v78, s21, 0xfedcba98                // 000000D86848: D65C004E 03FC2B4E FEDCBA98
	v_permlanex16_b32 v121, v121, s21, 0xfedcba98              // 000000D86854: D65C0079 03FC2B79 FEDCBA98
	v_permlanex16_b32 v122, v122, s21, 0xfedcba98              // 000000D86860: D65C007A 03FC2B7A FEDCBA98
	s_waitcnt lgkmcnt(10)                                      // 000000D8686C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[17:24], v[25:32], v[33:40], v[17:24]// 000000D86870: CC404011 1C464319
	v_permlanex16_b32 v123, v123, s21, 0xfedcba98              // 000000D86878: D65C007B 03FC2B7B FEDCBA98
	v_cndmask_b32_e64 v33, v78, v76, s3                        // 000000D86884: D5010021 000E994E
	v_cndmask_b32_e64 v37, v76, v78, s3                        // 000000D8688C: D5010025 000E9D4C
	v_cndmask_b32_e64 v34, v121, v77, s3                       // 000000D86894: D5010022 000E9B79
	v_cndmask_b32_e64 v38, v77, v121, s3                       // 000000D8689C: D5010026 000EF34D
	v_cndmask_b32_e64 v35, v122, v120, s3                      // 000000D868A4: D5010023 000EF17A
	v_cndmask_b32_e64 v39, v120, v122, s3                      // 000000D868AC: D5010027 000EF578
	v_cndmask_b32_e64 v36, v123, v75, s3                       // 000000D868B4: D5010024 000E977B
	v_cndmask_b32_e64 v40, v75, v123, s3                       // 000000D868BC: D5010028 000EF74B
	s_waitcnt lgkmcnt(8)                                       // 000000D868C4: BF89FC87
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[41:48], v[9:16]// 000000D868C8: CC404009 1C265319
	s_waitcnt lgkmcnt(6)                                       // 000000D868D0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[67:74], v[1:8] // 000000D868D4: CC404001 1C068719
	s_waitcnt lgkmcnt(4)                                       // 000000D868DC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[96:103], v[17:24]// 000000D868E0: CC404011 1C46C121
	s_waitcnt lgkmcnt(2)                                       // 000000D868E8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[104:111], v[9:16]// 000000D868EC: CC404009 1C26D121
	s_waitcnt lgkmcnt(0)                                       // 000000D868F4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[112:119], v[1:8]// 000000D868F8: CC404001 1C06E121
	s_cbranch_vccnz 64154                                      // 000000D86900: BFA4FA9A <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3e6c>
	s_and_b32 s27, s28, exec_lo                                // 000000D86904: 8B1B7E1C
	s_cselect_b32 s27, 0x4400, 0                               // 000000D86908: 981B80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D86910: BF870009
	v_lshl_or_b32 v25, v79, 1, s27                             // 000000D86914: D6560019 006D034F
	s_and_saveexec_b32 s27, s0                                 // 000000D8691C: BE9B2000
	s_cbranch_execnz 7                                         // 000000D86920: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5440>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D86924: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000D86928: BE9B2001
	s_cbranch_execnz 11                                        // 000000D8692C: BFA6000B <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x545c>
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D86930: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000D86934: BE9B2002
	s_cbranch_execz 64139                                      // 000000D86938: BFA5FA8B <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3e68>
	s_branch 13                                                // 000000D8693C: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5474>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D86940: BF870001
	v_add_nc_u32_e32 v26, v25, v83                             // 000000D86944: 4A34A719
	ds_store_b128 v26, v[49:52]                                // 000000D86948: DB7C0000 0000311A
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D86950: 8C7E1B7E
	s_and_saveexec_b32 s27, s1                                 // 000000D86954: BE9B2001
	s_cbranch_execz 65525                                      // 000000D86958: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5430>
	v_add_nc_u32_e32 v26, v25, v88                             // 000000D8695C: 4A34B119
	ds_store_b128 v26, v[53:56]                                // 000000D86960: DB7C0000 0000351A
	s_or_b32 exec_lo, exec_lo, s27                             // 000000D86968: 8C7E1B7E
	s_and_saveexec_b32 s27, s2                                 // 000000D8696C: BE9B2002
	s_cbranch_execz 64125                                      // 000000D86970: BFA5FA7D <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3e68>
	v_lshl_add_u32 v25, v82, 1, v25                            // 000000D86974: D6460019 04650352
	ds_store_b128 v25, v[57:60]                                // 000000D8697C: DB7C0000 00003919
	s_branch 64120                                             // 000000D86984: BFA0FA78 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x3e68>
	s_mul_i32 s0, s16, 0x1400                                  // 000000D86988: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000D86990: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000D86998: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000D8699C: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000D869A0: 84008711
	v_lshrrev_b32_e32 v26, 5, v0                               // 000000D869A4: 32340085
	s_ashr_i32 s1, s0, 31                                      // 000000D869A8: 86019F00
	v_and_b32_e32 v27, 1, v0                                   // 000000D869AC: 36360081
	v_and_b32_e32 v28, 2, v0                                   // 000000D869B0: 36380082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D869B4: 84848100
	v_lshrrev_b32_e32 v31, 2, v80                              // 000000D869B8: 323EA082
	s_add_u32 s12, s2, s4                                      // 000000D869BC: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D869C0: 820D0503
	.long 0xd44a0003                                           // 000000D869C4: D44A0003
	v_cndmask_b32_e32 v1, 0, v27, vcc_lo                       // 000000D869C8: 02023680
	v_lshlrev_b32_e32 v27, 6, v26                              // 000000D869CC: 30363486
	.long 0xd44a0002                                           // 000000D869D0: D44A0002
	v_cndmask_b32_e32 v1, 0, v28, vcc_lo                       // 000000D869D4: 02023880
	v_and_b32_e32 v28, 4, v0                                   // 000000D869D8: 36380084
	v_and_b32_e32 v29, 8, v0                                   // 000000D869DC: 363A0088
	v_lshlrev_b32_e32 v25, 2, v80                              // 000000D869E0: 3032A082
	v_mad_u32_u24 v27, 0x210, v81, v27                         // 000000D869E4: D60B001B 046EA2FF 00000210
	v_and_b32_e32 v30, 16, v0                                  // 000000D869F0: 363C0090
	.long 0xd44a0001                                           // 000000D869F4: D44A0001
	v_cndmask_b32_e32 v1, 0, v28, vcc_lo                       // 000000D869F8: 02023880
	v_lshlrev_b32_e32 v28, 3, v80                              // 000000D869FC: 3038A083
	.long 0xd44a0000                                           // 000000D86A00: D44A0000
	v_cndmask_b32_e32 v1, 0, v29, vcc_lo                       // 000000D86A04: 02023A80
	v_and_or_b32 v27, v31, 4, v27                              // 000000D86A08: D657001B 046D091F
	ds_store_2addr_b32 v27, v17, v18 offset1:2                 // 000000D86A10: D8380200 0012111B
	ds_store_2addr_b32 v27, v19, v20 offset0:4 offset1:6       // 000000D86A18: D8380604 0014131B
	ds_store_2addr_b32 v27, v21, v22 offset0:8 offset1:10      // 000000D86A20: D8380A08 0016151B
	.long 0xd700151c                                           // 000000D86A28: D700151C
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 000000D86A2C: 02023806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D86A30: BF8701A1
	v_add_co_ci_u32_e64 v29, null, s7, 0, s21                  // 000000D86A34: D5207C1D 00550007
	v_mul_u32_u24_e32 v20, 0x210, v26                          // 000000D86A3C: 162834FF 00000210
	.long 0xd7000411                                           // 000000D86A44: D7000411
	v_cndmask_b32_e32 v0, v28, v4, vcc_lo                      // 000000D86A48: 0200091C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D86A4C: BF870001
	v_add_co_ci_u32_e64 v18, null, s5, v29, s4                 // 000000D86A50: D5207C12 00123A05
	v_lshlrev_b32_e32 v19, 1, v25                              // 000000D86A58: 30263281
	s_mov_b32 s5, exec_lo                                      // 000000D86A5C: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000D86A60: 7C943C80
	ds_store_2addr_b32 v27, v23, v24 offset0:12 offset1:14     // 000000D86A64: D8380E0C 0018171B
	s_waitcnt lgkmcnt(0)                                       // 000000D86A6C: BF89FC07
	s_barrier                                                  // 000000D86A70: BFBD0000
	buffer_gl0_inv                                             // 000000D86A74: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D86A7C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v26, vcc_lo                     // 000000D86A80: 02023413
	s_cbranch_execz 200                                        // 000000D86A84: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x58a8>
	global_load_b64 v[28:29], v19, s[12:13]                    // 000000D86A88: DC560000 1C0C0013
	v_lshl_add_u32 v21, v25, 2, v20                            // 000000D86A90: D6460015 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000D86A98: BE8400FF 76543210
	ds_load_b128 v[21:24], v21                                 // 000000D86AA0: DBFC0000 15000015
	s_waitcnt lgkmcnt(0)                                       // 000000D86AA8: BF89FC07
	v_dual_add_f32 v30, v21, v22 :: v_dual_add_f32 v31, v23, v24// 000000D86AAC: C9082D15 1E1E3117
	v_dual_sub_f32 v21, v21, v22 :: v_dual_sub_f32 v22, v23, v24// 000000D86AB4: C94A2D15 15163117
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D86ABC: BF870112
	v_sub_f32_e32 v24, v30, v31                                // 000000D86AC0: 08303F1E
	v_dual_add_f32 v23, v30, v31 :: v_dual_add_f32 v30, v21, v22// 000000D86AC4: C9083F1E 171E2D15
	v_sub_f32_e32 v21, v21, v22                                // 000000D86ACC: 082A2D15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D86AD0: BF870223
	v_mov_b32_dpp v31, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86AD4: 7E3E02FA FF016118
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D86ADC: D5010018 200E3118
	v_mov_b32_dpp v22, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86AE4: 7E2C02FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D86AEC: D5010017 200E2F17
	v_mov_b32_dpp v32, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86AF4: 7E4002FA FF01611E
	v_mov_b32_dpp v33, v21 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86AFC: 7E4202FA FF016115
	v_cndmask_b32_e64 v21, -v21, v21, s3                       // 000000D86B04: D5010015 200E2B15
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D86B0C: D501001E 200E3D1E
	v_add_f32_e32 v24, v24, v31                                // 000000D86B14: 06303F18
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86B18: BF870193
	v_dual_add_f32 v22, v23, v22 :: v_dual_add_f32 v21, v21, v33// 000000D86B1C: C9082D17 16144315
	v_add_f32_e32 v23, v30, v32                                // 000000D86B24: 062E411E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D86B28: BF870223
	v_mov_b32_dpp v30, v24 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86B2C: 7E3C02FA FF016218
	v_cndmask_b32_e64 v24, -v24, v24, s2                       // 000000D86B34: D5010018 200A3118
	v_mov_b32_dpp v31, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86B3C: 7E3E02FA FF016216
	v_mov_b32_dpp v32, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86B44: 7E4002FA FF016215
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D86B4C: D5010015 200A2B15
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D86B54: D5010016 200A2D16
	v_add_f32_e32 v24, v24, v30                                // 000000D86B5C: 06303D18
	v_mov_b32_dpp v30, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86B60: 7E3C02FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000D86B68: D5010017 200A2F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86B70: BF870214
	v_dual_add_f32 v21, v21, v32 :: v_dual_add_f32 v22, v22, v31// 000000D86B74: C9084115 15163F16
	v_mov_b32_dpp v31, v24 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86B7C: 7E3E02FA FF016418
	v_cndmask_b32_e64 v24, -v24, v24, s1                       // 000000D86B84: D5010018 20063118
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86B8C: BF870214
	v_add_f32_e32 v23, v23, v30                                // 000000D86B90: 062E3D17
	v_mov_b32_dpp v30, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86B94: 7E3C02FA FF016415
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D86B9C: D5010015 20062B15
	v_mov_b32_dpp v32, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86BA4: 7E4002FA FF016416
	v_add_f32_e32 v24, v24, v31                                // 000000D86BAC: 06303F18
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D86BB0: D5010016 20062D16
	v_mov_b32_dpp v31, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86BB8: 7E3E02FA FF016417
	v_add_f32_e32 v21, v21, v30                                // 000000D86BC0: 062A3D15
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000D86BC4: D5010017 20062F17
	v_mov_b32_dpp v30, v24 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86BCC: 7E3C02FA FF016818
	v_cndmask_b32_e64 v24, -v24, v24, s0                       // 000000D86BD4: D5010018 20023118
	v_add_f32_e32 v22, v22, v32                                // 000000D86BDC: 062C4116
	v_mov_b32_dpp v32, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86BE0: 7E4002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D86BE8: D5010015 20022B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86BF0: BF870214
	v_dual_add_f32 v23, v23, v31 :: v_dual_add_f32 v24, v24, v30// 000000D86BF4: C9083F17 17183D18
	v_mov_b32_dpp v30, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86BFC: 7E3C02FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D86C04: D5010016 20022D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86C0C: BF870214
	v_add_f32_e32 v21, v21, v32                                // 000000D86C10: 062A4115
	v_mov_b32_dpp v32, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86C14: 7E4002FA FF016817
	v_mov_b32_e32 v31, v24                                     // 000000D86C1C: 7E3E0318
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000D86C20: D5010017 20022F17
	v_cndmask_b32_e64 v24, -v24, v24, vcc_lo                   // 000000D86C28: D5010018 21AA3118
	v_mov_b32_e32 v34, v21                                     // 000000D86C30: 7E440315
	v_add_f32_e32 v22, v22, v30                                // 000000D86C34: 062C3D16
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000D86C38: D65C001F 03FC091F FEDCBA98
	v_add_f32_e32 v23, v23, v32                                // 000000D86C44: 062E4117
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D86C48: D5010015 21AA2B15
	v_permlanex16_b32 v34, v34, s4, 0xfedcba98                 // 000000D86C50: D65C0022 03FC0922 FEDCBA98
	v_mov_b32_e32 v30, v22                                     // 000000D86C5C: 7E3C0316
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D86C60: BF870224
	v_dual_add_f32 v24, v24, v31 :: v_dual_mov_b32 v31, v23    // 000000D86C64: C9103F18 181E0117
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000D86C6C: D5010016 21AA2D16
	v_add_f32_e32 v21, v21, v34                                // 000000D86C74: 062A4515
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86C78: BF870214
	v_permlanex16_b32 v30, v30, s4, 0xfedcba98                 // 000000D86C7C: D65C001E 03FC091E FEDCBA98
	v_mul_f32_e32 v24, 0x3db504f3, v24                         // 000000D86C88: 103030FF 3DB504F3
	.long 0x7f423880                                           // 000000D86C90: 7F423880
	v_cndmask_b32_e64 v23, -v23, v23, vcc_lo                   // 000000D86C94: D5010017 21AA2F17
	v_permlanex16_b32 v31, v31, s4, 0xfedcba98                 // 000000D86C9C: D65C001F 03FC091F FEDCBA98
	v_dual_mul_f32 v21, 0x3db504f3, v21 :: v_dual_add_f32 v22, v22, v30// 000000D86CA8: C8C82AFF 15163D16 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D86CB4: BF870114
	.long 0x7f3c39a1                                           // 000000D86CB8: 7F3C39A1
	v_dual_add_f32 v23, v23, v31 :: v_dual_mul_f32 v22, 0x3db504f3, v22// 000000D86CBC: C9063F17 17162CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D86CC8: BF870001
	v_mul_f32_e32 v23, 0x3db504f3, v23                         // 000000D86CCC: 102E2EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D86CD4: BF8903F7
	v_fma_mix_f32 v24, v29, v24, neg(0) op_sel_hi:[1,0,0]      // 000000D86CD8: CC200018 8A02311D
	v_fma_mix_f32 v21, v29, v21, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D86CE0: CC200815 8A022B1D
	.long 0x7f3a39a1                                           // 000000D86CE8: 7F3A39A1
	v_fma_mix_f32 v22, v28, v22, neg(0) op_sel_hi:[1,0,0]      // 000000D86CEC: CC200016 8A022D1C
	v_fma_mix_f32 v23, v28, v23, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D86CF4: CC200817 8A022F1C
	.long 0x7e3c3998                                           // 000000D86CFC: 7E3C3998
	.long 0x7e3a3995                                           // 000000D86D00: 7E3A3995
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86D04: BF870193
	v_bfe_u32 v31, v23, 16, 1                                  // 000000D86D08: D610001F 02052117
	v_and_b32_e32 v30, 1, v30                                  // 000000D86D10: 363C3C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D86D14: BF870223
	v_and_b32_e32 v28, 1, v29                                  // 000000D86D18: 36383A81
	v_bfe_u32 v29, v22, 16, 1                                  // 000000D86D1C: D610001D 02052116
	v_add3_u32 v23, v23, v31, 0x7fff                           // 000000D86D24: D6550017 03FE3F17 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D86D30: BF870244
	v_add3_u32 v24, v24, v30, 0x7fff                           // 000000D86D34: D6550018 03FE3D18 00007FFF
	.long 0x7f3c39a1                                           // 000000D86D40: 7F3C39A1
	v_add3_u32 v21, v21, v28, 0x7fff                           // 000000D86D44: D6550015 03FE3915 00007FFF
	v_add3_u32 v22, v22, v29, 0x7fff                           // 000000D86D50: D6550016 03FE3B16 00007FFF
	.long 0x7e3c3998                                           // 000000D86D5C: 7E3C3998
	v_add_nc_u32_e32 v24, s18, v26                             // 000000D86D60: 4A303412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86D64: BF870214
	v_and_b32_e32 v28, 0xffff0000, v21                         // 000000D86D68: 36382AFF FFFF0000
	.long 0x7e423996                                           // 000000D86D70: 7E423996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86D74: BF870214
	v_and_b32_e32 v29, 0xffff, v30                             // 000000D86D78: 363A3CFF 0000FFFF
	v_mad_i64_i32 v[21:22], null, 0x1400, v24, v[17:18]        // 000000D86D80: D6FF7C15 044630FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86D8C: BF870193
	v_and_or_b32 v23, 0xffff0000, v23, v33                     // 000000D86D90: D6570017 04862EFF FFFF0000
	v_or_b32_e32 v24, v28, v29                                 // 000000D86D9C: 38303B1C
	global_store_b64 v[21:22], v[23:24], off                   // 000000D86DA0: DC6E0000 007C1715
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D86DA8: 8C7E057E
	v_or_b32_e32 v22, 8, v26                                   // 000000D86DAC: 382C3488
	s_mov_b32 s5, exec_lo                                      // 000000D86DB0: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D86DB4: BF870001
	v_mul_u32_u24_e32 v21, 0x210, v22                          // 000000D86DB8: 162A2CFF 00000210
	.long 0xd4c4007e                                           // 000000D86DC0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000D86DC4: 02022C13
	s_cbranch_execz 199                                        // 000000D86DC8: BFA500C7 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5be8>
	global_load_b64 v[23:24], v19, s[12:13]                    // 000000D86DCC: DC560000 170C0013
	v_lshl_add_u32 v28, v25, 2, v21                            // 000000D86DD4: D646001C 04550519
	s_mov_b32 s4, 0x76543210                                   // 000000D86DDC: BE8400FF 76543210
	v_add_nc_u32_e32 v22, s18, v22                             // 000000D86DE4: 4A2C2C12
	ds_load_b128 v[28:31], v28                                 // 000000D86DE8: DBFC0000 1C00001C
	s_waitcnt lgkmcnt(0)                                       // 000000D86DF0: BF89FC07
	v_dual_add_f32 v32, v28, v29 :: v_dual_add_f32 v33, v30, v31// 000000D86DF4: C9083B1C 20203F1E
	v_dual_sub_f32 v28, v28, v29 :: v_dual_sub_f32 v29, v30, v31// 000000D86DFC: C94A3B1C 1C1C3F1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D86E04: BF8701A2
	v_sub_f32_e32 v31, v32, v33                                // 000000D86E08: 083E4320
	v_add_f32_e32 v30, v32, v33                                // 000000D86E0C: 063C4320
	v_add_f32_e32 v32, v28, v29                                // 000000D86E10: 06403B1C
	v_sub_f32_e32 v28, v28, v29                                // 000000D86E14: 08383B1C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D86E18: BF870004
	v_mov_b32_dpp v33, v31 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86E1C: 7E4202FA FF01611F
	v_cndmask_b32_e64 v31, -v31, v31, s3                       // 000000D86E24: D501001F 200E3F1F
	v_mov_b32_dpp v29, v30 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86E2C: 7E3A02FA FF01611E
	v_cndmask_b32_e64 v30, -v30, v30, s3                       // 000000D86E34: D501001E 200E3D1E
	v_mov_b32_dpp v34, v32 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86E3C: 7E4402FA FF016120
	v_mov_b32_dpp v35, v28 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D86E44: 7E4602FA FF01611C
	v_cndmask_b32_e64 v28, -v28, v28, s3                       // 000000D86E4C: D501001C 200E391C
	v_cndmask_b32_e64 v32, -v32, v32, s3                       // 000000D86E54: D5010020 200E4120
	v_add_f32_e32 v31, v31, v33                                // 000000D86E5C: 063E431F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86E60: BF870193
	v_dual_add_f32 v29, v30, v29 :: v_dual_add_f32 v28, v28, v35// 000000D86E64: C9083B1E 1D1C471C
	v_add_f32_e32 v30, v32, v34                                // 000000D86E6C: 063C4520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D86E70: BF870223
	v_mov_b32_dpp v32, v31 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86E74: 7E4002FA FF01621F
	v_cndmask_b32_e64 v31, -v31, v31, s2                       // 000000D86E7C: D501001F 200A3F1F
	v_mov_b32_dpp v33, v29 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86E84: 7E4202FA FF01621D
	v_mov_b32_dpp v34, v28 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86E8C: 7E4402FA FF01621C
	v_cndmask_b32_e64 v28, -v28, v28, s2                       // 000000D86E94: D501001C 200A391C
	v_cndmask_b32_e64 v29, -v29, v29, s2                       // 000000D86E9C: D501001D 200A3B1D
	v_add_f32_e32 v31, v31, v32                                // 000000D86EA4: 063E411F
	v_mov_b32_dpp v32, v30 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D86EA8: 7E4002FA FF01621E
	v_cndmask_b32_e64 v30, -v30, v30, s2                       // 000000D86EB0: D501001E 200A3D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86EB8: BF870214
	v_dual_add_f32 v28, v28, v34 :: v_dual_add_f32 v29, v29, v33// 000000D86EBC: C908451C 1C1C431D
	v_mov_b32_dpp v33, v31 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86EC4: 7E4202FA FF01641F
	v_cndmask_b32_e64 v31, -v31, v31, s1                       // 000000D86ECC: D501001F 20063F1F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D86ED4: BF870214
	v_add_f32_e32 v30, v30, v32                                // 000000D86ED8: 063C411E
	v_mov_b32_dpp v32, v28 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86EDC: 7E4002FA FF01641C
	v_cndmask_b32_e64 v28, -v28, v28, s1                       // 000000D86EE4: D501001C 2006391C
	v_mov_b32_dpp v34, v29 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86EEC: 7E4402FA FF01641D
	v_add_f32_e32 v31, v31, v33                                // 000000D86EF4: 063E431F
	v_cndmask_b32_e64 v29, -v29, v29, s1                       // 000000D86EF8: D501001D 20063B1D
	v_mov_b32_dpp v33, v30 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D86F00: 7E4202FA FF01641E
	v_add_f32_e32 v28, v28, v32                                // 000000D86F08: 0638411C
	v_cndmask_b32_e64 v30, -v30, v30, s1                       // 000000D86F0C: D501001E 20063D1E
	v_mov_b32_dpp v32, v31 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86F14: 7E4002FA FF01681F
	v_cndmask_b32_e64 v31, -v31, v31, s0                       // 000000D86F1C: D501001F 20023F1F
	v_add_f32_e32 v29, v29, v34                                // 000000D86F24: 063A451D
	v_mov_b32_dpp v34, v28 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86F28: 7E4402FA FF01681C
	v_cndmask_b32_e64 v28, -v28, v28, s0                       // 000000D86F30: D501001C 2002391C
	.long 0x7f463880                                           // 000000D86F38: 7F463880
	v_dual_add_f32 v31, v31, v32 :: v_dual_add_f32 v30, v30, v33// 000000D86F3C: C908411F 1F1E431E
	v_mov_b32_dpp v32, v29 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86F44: 7E4002FA FF01681D
	v_cndmask_b32_e64 v29, -v29, v29, s0                       // 000000D86F4C: D501001D 20023B1D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D86F54: BF870003
	v_dual_add_f32 v28, v28, v34 :: v_dual_mov_b32 v33, v31    // 000000D86F58: C910451C 1C20011F
	v_cndmask_b32_e64 v31, -v31, v31, vcc_lo                   // 000000D86F60: D501001F 21AA3F1F
	v_mov_b32_dpp v34, v30 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D86F68: 7E4402FA FF01681E
	v_cndmask_b32_e64 v30, -v30, v30, s0                       // 000000D86F70: D501001E 20023D1E
	v_add_f32_e32 v29, v29, v32                                // 000000D86F78: 063A411D
	v_permlanex16_b32 v33, v33, s4, 0xfedcba98                 // 000000D86F7C: D65C0021 03FC0921 FEDCBA98
	v_mov_b32_e32 v36, v28                                     // 000000D86F88: 7E48031C
	v_cndmask_b32_e64 v28, -v28, v28, vcc_lo                   // 000000D86F8C: D501001C 21AA391C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86F94: BF870193
	v_dual_add_f32 v31, v31, v33 :: v_dual_add_f32 v30, v30, v34// 000000D86F98: C908431F 1F1E451E
	v_permlanex16_b32 v36, v36, s4, 0xfedcba98                 // 000000D86FA0: D65C0024 03FC0924 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D86FAC: BF870192
	v_dual_mul_f32 v31, 0x3db504f3, v31 :: v_dual_mov_b32 v32, v29// 000000D86FB0: C8D03EFF 1F20011D 3DB504F3
	v_mov_b32_e32 v33, v30                                     // 000000D86FBC: 7E42031E
	v_cndmask_b32_e64 v29, -v29, v29, vcc_lo                   // 000000D86FC0: D501001D 21AA3B1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D86FC8: BF870244
	v_add_f32_e32 v28, v28, v36                                // 000000D86FCC: 0638491C
	v_cndmask_b32_e64 v30, -v30, v30, vcc_lo                   // 000000D86FD0: D501001E 21AA3D1E
	v_permlanex16_b32 v32, v32, s4, 0xfedcba98                 // 000000D86FD8: D65C0020 03FC0920 FEDCBA98
	v_permlanex16_b32 v33, v33, s4, 0xfedcba98                 // 000000D86FE4: D65C0021 03FC0921 FEDCBA98
	v_mul_f32_e32 v28, 0x3db504f3, v28                         // 000000D86FF0: 103838FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D86FF8: BF870122
	v_dual_add_f32 v29, v29, v32 :: v_dual_add_f32 v30, v30, v33// 000000D86FFC: C908411D 1D1E431E
	.long 0x7f4039a3                                           // 000000D87004: 7F4039A3
	v_mul_f32_e32 v30, 0x3db504f3, v30                         // 000000D87008: 103C3CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D87010: BF8903F7
	v_fma_mix_f32 v31, v24, v31, neg(0) op_sel_hi:[1,0,0]      // 000000D87014: CC20001F 8A023F18
	v_fma_mix_f32 v24, v24, v28, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8701C: CC200818 8A023918
	v_mul_f32_e32 v28, 0x3db504f3, v29                         // 000000D87024: 10383AFF 3DB504F3
	.long 0x7f3a39a3                                           // 000000D8702C: 7F3A39A3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87030: BF870214
	.long 0x7e40399f                                           // 000000D87034: 7E40399F
	.long 0x7e3a3998                                           // 000000D87038: 7E3A3998
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8703C: BF870224
	v_fma_mix_f32 v28, v23, v28, neg(0) op_sel_hi:[1,0,0]      // 000000D87040: CC20001C 8A023917
	v_fma_mix_f32 v23, v23, v30, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87048: CC200817 8A023D17
	v_and_b32_e32 v32, 1, v32                                  // 000000D87050: 36404081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87054: BF870194
	v_and_b32_e32 v29, 1, v29                                  // 000000D87058: 363A3A81
	v_bfe_u32 v33, v23, 16, 1                                  // 000000D8705C: D6100021 02052117
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D87064: BF870243
	v_add3_u32 v30, v31, v32, 0x7fff                           // 000000D87068: D655001E 03FE411F 00007FFF
	v_bfe_u32 v31, v28, 16, 1                                  // 000000D87074: D610001F 0205211C
	.long 0x7f4039a3                                           // 000000D8707C: 7F4039A3
	v_add3_u32 v24, v24, v29, 0x7fff                           // 000000D87080: D6550018 03FE3B18 00007FFF
	.long 0x7e40399e                                           // 000000D8708C: 7E40399E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87090: BF870224
	v_add3_u32 v28, v28, v31, 0x7fff                           // 000000D87094: D655001C 03FE3F1C 00007FFF
	v_add3_u32 v30, v23, v33, 0x7fff                           // 000000D870A0: D655001E 03FE4317 00007FFF
	v_and_b32_e32 v24, 0xffff0000, v24                         // 000000D870AC: 363030FF FFFF0000
	v_mad_i64_i32 v[22:23], null, 0x1400, v22, v[17:18]        // 000000D870B4: D6FF7C16 04462CFF 00001400
	v_and_b32_e32 v29, 0xffff, v32                             // 000000D870C0: 363A40FF 0000FFFF
	.long 0x7e46399c                                           // 000000D870C8: 7E46399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D870CC: BF870112
	v_or_b32_e32 v29, v24, v29                                 // 000000D870D0: 383A3B18
	v_and_or_b32 v28, 0xffff0000, v30, v35                     // 000000D870D4: D657001C 048E3CFF FFFF0000
	global_store_b64 v[22:23], v[28:29], off                   // 000000D870E0: DC6E0000 007C1C16
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D870E8: 8C7E057E
	v_or_b32_e32 v22, 16, v26                                  // 000000D870EC: 382C3490
	s_mov_b32 s5, exec_lo                                      // 000000D870F0: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D870F4: BC7C0000
	s_barrier                                                  // 000000D870F8: BFBD0000
	buffer_gl0_inv                                             // 000000D870FC: E0AC0000 00000000
	ds_store_2addr_b32 v27, v9, v10 offset1:2                  // 000000D87104: D8380200 000A091B
	ds_store_2addr_b32 v27, v11, v12 offset0:4 offset1:6       // 000000D8710C: D8380604 000C0B1B
	ds_store_2addr_b32 v27, v13, v14 offset0:8 offset1:10      // 000000D87114: D8380A08 000E0D1B
	ds_store_2addr_b32 v27, v15, v16 offset0:12 offset1:14     // 000000D8711C: D8380E0C 00100F1B
	s_waitcnt lgkmcnt(0)                                       // 000000D87124: BF89FC07
	s_barrier                                                  // 000000D87128: BFBD0000
	buffer_gl0_inv                                             // 000000D8712C: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D87134: D4C4007E
	v_cndmask_b32_e32 v1, s19, v22, vcc_lo                     // 000000D87138: 02022C13
	s_cbranch_execz 201                                        // 000000D8713C: BFA500C9 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x5f64>
	global_load_b64 v[13:14], v19, s[12:13]                    // 000000D87140: DC560000 0D0C0013
	v_lshl_add_u32 v9, v25, 2, v20                             // 000000D87148: D6460009 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000D87150: BE8400FF 76543210
	ds_load_b128 v[9:12], v9                                   // 000000D87158: DBFC0000 09000009
	s_waitcnt lgkmcnt(0)                                       // 000000D87160: BF89FC07
	v_dual_add_f32 v15, v9, v10 :: v_dual_add_f32 v16, v11, v12// 000000D87164: C9081509 0F10190B
	v_dual_sub_f32 v9, v9, v10 :: v_dual_sub_f32 v10, v11, v12 // 000000D8716C: C94A1509 090A190B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87174: BF870112
	v_add_f32_e32 v11, v15, v16                                // 000000D87178: 0616210F
	v_dual_sub_f32 v12, v15, v16 :: v_dual_add_f32 v15, v9, v10// 000000D8717C: C948210F 0C0E1509
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87184: BF870001
	v_mov_b32_dpp v16, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87188: 7E2002FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D87190: D501000C 200E190C
	v_sub_f32_e32 v9, v9, v10                                  // 000000D87198: 08121509
	v_mov_b32_dpp v10, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8719C: 7E1402FA FF01610B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D871A4: D501000B 200E170B
	v_mov_b32_dpp v23, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D871AC: 7E2E02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D871B4: D501000F 200E1F0F
	v_add_f32_e32 v12, v12, v16                                // 000000D871BC: 0618210C
	v_mov_b32_dpp v24, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D871C0: 7E3002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 000000D871C8: D5010009 200E1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D871D0: BF870091
	v_dual_add_f32 v10, v11, v10 :: v_dual_add_f32 v9, v9, v24 // 000000D871D4: C908150B 0A083109
	v_mov_b32_dpp v16, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D871DC: 7E2002FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D871E4: D501000A 200A150A
	v_add_f32_e32 v11, v15, v23                                // 000000D871EC: 06162F0F
	v_mov_b32_dpp v15, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D871F0: 7E1E02FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D871F8: D501000C 200A190C
	v_mov_b32_dpp v23, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87200: 7E2E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000D87208: D5010009 200A1309
	v_add_f32_e32 v10, v10, v16                                // 000000D87210: 0614210A
	.long 0x7f303880                                           // 000000D87214: 7F303880
	v_add_f32_e32 v12, v12, v15                                // 000000D87218: 06181F0C
	v_mov_b32_dpp v15, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8721C: 7E1E02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D87224: D501000B 200A170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8722C: BF870233
	v_mov_b32_dpp v16, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87230: 7E2002FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D87238: D501000C 2006190C
	v_add_f32_e32 v9, v9, v23                                  // 000000D87240: 06122F09
	v_add_f32_e32 v11, v11, v15                                // 000000D87244: 06161F0B
	v_mov_b32_dpp v23, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87248: 7E2E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D87250: D501000A 2006150A
	v_add_f32_e32 v12, v12, v16                                // 000000D87258: 0618210C
	v_mov_b32_dpp v15, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8725C: 7E1E02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000D87264: D5010009 20061309
	v_mov_b32_dpp v16, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8726C: 7E2002FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D87274: D501000B 2006170B
	v_add_f32_e32 v10, v10, v23                                // 000000D8727C: 06142F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D87280: BF8700B4
	v_add_f32_e32 v9, v9, v15                                  // 000000D87284: 06121F09
	v_mov_b32_dpp v15, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87288: 7E1E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D87290: D501000C 2002190C
	v_dual_add_f32 v11, v11, v16 :: v_dual_add_f32 v12, v12, v15// 000000D87298: C908210B 0B0C1F0C
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D872A0: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D872A8: D501000A 2002150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D872B0: BF870091
	v_add_f32_e32 v10, v10, v15                                // 000000D872B4: 06141F0A
	v_dual_mov_b32 v15, v10 :: v_dual_mov_b32 v16, v12         // 000000D872B8: CA10010A 0F10010C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D872C0: D501000C 21AA190C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D872C8: BF870192
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D872CC: D65C000F 03FC090F FEDCBA98
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D872D8: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D872E4: BF8700B1
	v_add_f32_e32 v12, v12, v16                                // 000000D872E8: 0618210C
	v_mov_b32_dpp v23, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D872EC: 7E2E02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000D872F4: D5010009 20021309
	v_dual_mul_f32 v12, 0x3db504f3, v12 :: v_dual_add_f32 v9, v9, v23// 000000D872FC: C8C818FF 0C082F09 3DB504F3
	v_mov_b32_dpp v23, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87308: 7E2E02FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D87310: D501000B 2002170B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D87318: BF870091
	v_add_f32_e32 v11, v11, v23                                // 000000D8731C: 06162F0B
	v_mov_b32_e32 v16, v11                                     // 000000D87320: 7E20030B
	v_mov_b32_e32 v28, v9                                      // 000000D87324: 7E380309
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000D87328: D5010009 21AA1309
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D87330: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87338: BF870214
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D8733C: D65C0010 03FC0910 FEDCBA98
	v_permlanex16_b32 v28, v28, s4, 0xfedcba98                 // 000000D87348: D65C001C 03FC091C FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87354: BF870112
	v_add_f32_e32 v11, v11, v16                                // 000000D87358: 0616210B
	v_add_f32_e32 v9, v9, v28                                  // 000000D8735C: 06123909
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D87360: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87368: BF870113
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000D8736C: 101616FF 3DB504F3
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_add_f32 v10, v10, v15// 000000D87374: C8C812FF 090A1F0A 3DB504F3
	.long 0x7f1e3998                                           // 000000D87380: 7F1E3998
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D87384: BF870002
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D87388: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D87390: BF8903F7
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel_hi:[1,0,0]      // 000000D87394: CC20000C 8A02190E
	v_fma_mix_f32 v9, v14, v9, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8739C: CC200809 8A02130E
	.long 0x7f1c3998                                           // 000000D873A4: 7F1C3998
	v_fma_mix_f32 v10, v13, v10, neg(0) op_sel_hi:[1,0,0]      // 000000D873A8: CC20000A 8A02150D
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D873B0: CC20080B 8A02170D
	.long 0x7e1e398c                                           // 000000D873B8: 7E1E398C
	.long 0x7e1c3989                                           // 000000D873BC: 7E1C3989
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D873C0: BF870193
	v_bfe_u32 v16, v11, 16, 1                                  // 000000D873C4: D6100010 0205210B
	v_and_b32_e32 v15, 1, v15                                  // 000000D873CC: 361E1E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D873D0: BF870223
	v_and_b32_e32 v13, 1, v14                                  // 000000D873D4: 361A1C81
	v_bfe_u32 v14, v10, 16, 1                                  // 000000D873D8: D610000E 0205210A
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000D873E0: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D873EC: BF870244
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000D873F0: D655000C 03FE1F0C 00007FFF
	.long 0x7f1e3998                                           // 000000D873FC: 7F1E3998
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000D87400: D6550009 03FE1B09 00007FFF
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D8740C: D655000A 03FE1D0A 00007FFF
	.long 0x7e1e398c                                           // 000000D87418: 7E1E398C
	v_add_nc_u32_e32 v12, s18, v22                             // 000000D8741C: 4A182C12
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87420: BF870214
	v_and_b32_e32 v13, 0xffff0000, v9                          // 000000D87424: 361A12FF FFFF0000
	.long 0x7e30398a                                           // 000000D8742C: 7E30398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87430: BF870214
	v_and_b32_e32 v14, 0xffff, v15                             // 000000D87434: 361C1EFF 0000FFFF
	v_mad_i64_i32 v[9:10], null, 0x1400, v12, v[17:18]         // 000000D8743C: D6FF7C09 044618FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87448: BF870193
	v_and_or_b32 v11, 0xffff0000, v11, v24                     // 000000D8744C: D657000B 046216FF FFFF0000
	v_or_b32_e32 v12, v13, v14                                 // 000000D87458: 38181D0D
	global_store_b64 v[9:10], v[11:12], off                    // 000000D8745C: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D87464: 8C7E057E
	v_or_b32_e32 v9, 24, v26                                   // 000000D87468: 38123498
	s_mov_b32 s5, exec_lo                                      // 000000D8746C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87470: BF870001
	.long 0xd4c4007e                                           // 000000D87474: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D87478: 02021213
	s_cbranch_execz 206                                        // 000000D8747C: BFA500CE <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x62b8>
	global_load_b64 v[14:15], v19, s[12:13]                    // 000000D87480: DC560000 0E0C0013
	v_lshl_add_u32 v10, v25, 2, v21                            // 000000D87488: D646000A 04550519
	s_mov_b32 s4, 0x76543210                                   // 000000D87490: BE8400FF 76543210
	v_add_nc_u32_e32 v9, s18, v9                               // 000000D87498: 4A121212
	ds_load_b128 v[10:13], v10                                 // 000000D8749C: DBFC0000 0A00000A
	s_waitcnt lgkmcnt(0)                                       // 000000D874A4: BF89FC07
	v_add_f32_e32 v16, v10, v11                                // 000000D874A8: 0620170A
	v_add_f32_e32 v22, v12, v13                                // 000000D874AC: 062C1B0C
	v_dual_sub_f32 v10, v10, v11 :: v_dual_sub_f32 v11, v12, v13// 000000D874B0: C94A170A 0A0A1B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D874B8: BF8700A2
	v_add_f32_e32 v12, v16, v22                                // 000000D874BC: 06182D10
	v_sub_f32_e32 v13, v16, v22                                // 000000D874C0: 081A2D10
	v_mov_b32_dpp v22, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D874C4: 7E2C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D874CC: D501000D 200E1B0D
	v_add_f32_e32 v16, v10, v11                                // 000000D874D4: 0620170A
	v_sub_f32_e32 v10, v10, v11                                // 000000D874D8: 0814170A
	v_mov_b32_dpp v11, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D874DC: 7E1602FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 000000D874E4: D501000C 200E190C
	v_add_f32_e32 v13, v13, v22                                // 000000D874EC: 061A2D0D
	v_mov_b32_dpp v23, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D874F0: 7E2E02FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000D874F8: D5010010 200E2110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87500: BF870114
	v_add_f32_e32 v11, v12, v11                                // 000000D87504: 0616170C
	v_add_f32_e32 v12, v16, v23                                // 000000D87508: 06182F10
	v_mov_b32_dpp v16, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8750C: 7E2002FA FF01620D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D87514: BF870133
	v_mov_b32_dpp v22, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87518: 7E2C02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000D87520: D501000B 200A170B
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D87528: D501000D 200A1B0D
	v_add_f32_e32 v11, v11, v22                                // 000000D87530: 06162D0B
	v_mov_b32_dpp v24, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87534: 7E3002FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 000000D8753C: D501000A 200E150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87544: BF870114
	v_add_f32_e32 v13, v13, v16                                // 000000D87548: 061A210D
	v_add_f32_e32 v10, v10, v24                                // 000000D8754C: 0614310A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D87550: BF870232
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87554: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000D8755C: D501000D 20061B0D
	.long 0x7f303880                                           // 000000D87564: 7F303880
	v_mov_b32_dpp v23, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87568: 7E2E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000D87570: D501000A 200A150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D87578: BF870234
	v_add_f32_e32 v13, v13, v22                                // 000000D8757C: 061A2D0D
	v_mov_b32_dpp v16, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87580: 7E2002FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000D87588: D501000C 200A190C
	v_add_f32_e32 v10, v10, v23                                // 000000D87590: 06142F0A
	v_mov_b32_dpp v23, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87594: 7E2E02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000D8759C: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D875A4: BF870214
	v_add_f32_e32 v12, v12, v16                                // 000000D875A8: 0618210C
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D875AC: 7E2002FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000D875B4: D501000A 2006150A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D875BC: BF870214
	v_add_f32_e32 v11, v11, v23                                // 000000D875C0: 06162F0B
	v_mov_b32_dpp v22, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D875C4: 7E2C02FA FF01640C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000D875CC: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D875D4: BF8700B4
	v_add_f32_e32 v10, v10, v16                                // 000000D875D8: 0614210A
	v_mov_b32_dpp v16, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D875DC: 7E2002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D875E4: D501000D 20021B0D
	v_add_f32_e32 v13, v13, v16                                // 000000D875EC: 061A210D
	v_mov_b32_dpp v16, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D875F0: 7E2002FA FF01680B
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000D875F8: D501000B 2002170B
	v_add_f32_e32 v12, v12, v22                                // 000000D87600: 06182D0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87604: BF870224
	v_mov_b32_e32 v22, v13                                     // 000000D87608: 7E2C030D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000D8760C: D501000D 21AA1B0D
	v_add_f32_e32 v11, v11, v16                                // 000000D87614: 0616210B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87618: BF870113
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000D8761C: D65C0016 03FC0916 FEDCBA98
	v_mov_b32_e32 v16, v11                                     // 000000D87628: 7E20030B
	v_cndmask_b32_e64 v11, -v11, v11, vcc_lo                   // 000000D8762C: D501000B 21AA170B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87634: BF870193
	v_add_f32_e32 v13, v13, v22                                // 000000D87638: 061A2D0D
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D8763C: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D87648: BF870232
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000D8764C: 101A1AFF 3DB504F3
	v_mov_b32_dpp v23, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87654: 7E2E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000D8765C: D501000A 2002150A
	v_add_f32_e32 v11, v11, v16                                // 000000D87664: 0616210B
	.long 0x7f203998                                           // 000000D87668: 7F203998
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8766C: BF8701B3
	v_add_f32_e32 v10, v10, v23                                // 000000D87670: 06142F0A
	v_mov_b32_dpp v23, v12 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87674: 7E2E02FA FF01680C
	v_cndmask_b32_e64 v12, -v12, v12, s0                       // 000000D8767C: D501000C 2002190C
	v_dual_mul_f32 v11, 0x3db504f3, v11 :: v_dual_mov_b32 v28, v10// 000000D87684: C8D016FF 0B1C010A 3DB504F3
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000D87690: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87698: BF870193
	v_add_f32_e32 v12, v12, v23                                // 000000D8769C: 06182F0C
	v_permlanex16_b32 v28, v28, s4, 0xfedcba98                 // 000000D876A0: D65C001C 03FC091C FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D876AC: BF8701A2
	v_mov_b32_e32 v22, v12                                     // 000000D876B0: 7E2C030C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000D876B4: D501000C 21AA190C
	v_add_f32_e32 v10, v10, v28                                // 000000D876BC: 0614390A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D876C0: BF870113
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000D876C4: D65C0016 03FC0916 FEDCBA98
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000D876D0: 101414FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D876D8: BF870092
	v_add_f32_e32 v12, v12, v22                                // 000000D876DC: 06182D0C
	v_mul_f32_e32 v12, 0x3db504f3, v12                         // 000000D876E0: 101818FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D876E8: BF8903F7
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000D876EC: CC20000D 8A021B0F
	v_fma_mix_f32 v10, v15, v10, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D876F4: CC20080A 8A02150F
	.long 0x7f1e3998                                           // 000000D876FC: 7F1E3998
	v_fma_mix_f32 v11, v14, v11, neg(0) op_sel_hi:[1,0,0]      // 000000D87700: CC20000B 8A02170E
	v_fma_mix_f32 v12, v14, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87708: CC20080C 8A02190E
	.long 0x7e20398d                                           // 000000D87710: 7E20398D
	.long 0x7e1e398a                                           // 000000D87714: 7E1E398A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87718: BF870193
	v_bfe_u32 v22, v12, 16, 1                                  // 000000D8771C: D6100016 0205210C
	v_and_b32_e32 v16, 1, v16                                  // 000000D87724: 36202081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87728: BF8701A3
	v_and_b32_e32 v14, 1, v15                                  // 000000D8772C: 361C1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 000000D87730: D610000F 0205210B
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000D87738: D655000D 03FE210D 00007FFF
	.long 0x7f203998                                           // 000000D87744: 7F203998
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87748: BF870214
	v_add3_u32 v10, v10, v14, 0x7fff                           // 000000D8774C: D655000A 03FE1D0A 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 000000D87758: D655000B 03FE1F0B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87764: BF870224
	.long 0x7e20398d                                           // 000000D87768: 7E20398D
	v_add3_u32 v13, v12, v22, 0x7fff                           // 000000D8776C: D655000D 03FE2D0C 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v10                         // 000000D87778: 361814FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D87780: BF8701B4
	.long 0x7e30398b                                           // 000000D87784: 7E30398B
	v_mad_i64_i32 v[9:10], null, 0x1400, v9, v[17:18]          // 000000D87788: D6FF7C09 044612FF 00001400
	v_and_b32_e32 v14, 0xffff, v16                             // 000000D87794: 361C20FF 0000FFFF
	v_and_or_b32 v11, 0xffff0000, v13, v24                     // 000000D8779C: D657000B 04621AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D877A8: BF870002
	v_or_b32_e32 v12, v12, v14                                 // 000000D877AC: 38181D0C
	global_store_b64 v[9:10], v[11:12], off                    // 000000D877B0: DC6E0000 007C0B09
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D877B8: 8C7E057E
	v_or_b32_e32 v9, 32, v26                                   // 000000D877BC: 381234A0
	s_mov_b32 s5, exec_lo                                      // 000000D877C0: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D877C4: BC7C0000
	s_barrier                                                  // 000000D877C8: BFBD0000
	buffer_gl0_inv                                             // 000000D877CC: E0AC0000 00000000
	ds_store_2addr_b32 v27, v1, v2 offset1:2                   // 000000D877D4: D8380200 0002011B
	ds_store_2addr_b32 v27, v3, v4 offset0:4 offset1:6         // 000000D877DC: D8380604 0004031B
	ds_store_2addr_b32 v27, v5, v6 offset0:8 offset1:10        // 000000D877E4: D8380A08 0006051B
	ds_store_2addr_b32 v27, v7, v8 offset0:12 offset1:14       // 000000D877EC: D8380E0C 0008071B
	s_waitcnt lgkmcnt(0)                                       // 000000D877F4: BF89FC07
	s_barrier                                                  // 000000D877F8: BFBD0000
	buffer_gl0_inv                                             // 000000D877FC: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D87804: D4C4007E
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 000000D87808: 02021213
	s_cbranch_execz 200                                        // 000000D8780C: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6630>
	global_load_b64 v[5:6], v19, s[12:13]                      // 000000D87810: DC560000 050C0013
	v_lshl_add_u32 v1, v25, 2, v20                             // 000000D87818: D6460001 04510519
	s_mov_b32 s4, 0x76543210                                   // 000000D87820: BE8400FF 76543210
	ds_load_b128 v[1:4], v1                                    // 000000D87828: DBFC0000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000D87830: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000D87834: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000D8783C: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87844: BF870112
	v_add_f32_e32 v3, v7, v8                                   // 000000D87848: 06061107
	v_dual_sub_f32 v4, v7, v8 :: v_dual_add_f32 v7, v1, v2     // 000000D8784C: C9481107 04060501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87854: BF870001
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87858: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D87860: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000D87868: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8786C: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D87874: D5010003 200E0703
	v_mov_b32_dpp v10, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8787C: 7E1402FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D87884: D5010007 200E0F07
	v_add_f32_e32 v4, v4, v8                                   // 000000D8788C: 06081104
	v_mov_b32_dpp v11, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87890: 7E1602FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000D87898: D5010001 200E0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D878A0: BF870091
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v11    // 000000D878A4: C9080503 02001701
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D878AC: 7E1002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D878B4: D5010002 200A0502
	v_add_f32_e32 v3, v7, v10                                  // 000000D878BC: 06061507
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D878C0: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D878C8: D5010004 200A0904
	v_mov_b32_dpp v10, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D878D0: 7E1402FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000D878D8: D5010001 200A0301
	v_add_f32_e32 v2, v2, v8                                   // 000000D878E0: 06041102
	.long 0x7f163880                                           // 000000D878E4: 7F163880
	v_add_f32_e32 v4, v4, v7                                   // 000000D878E8: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D878EC: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D878F4: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000D878FC: BF870253
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87900: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D87908: D5010004 20060904
	v_add_f32_e32 v1, v1, v10                                  // 000000D87910: 06021501
	v_mov_b32_dpp v10, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87914: 7E1402FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D8791C: D5010002 20060502
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 000000D87924: C9080F03 03041104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8792C: BF870224
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87930: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000D87938: D5010001 20060301
	v_add_f32_e32 v2, v2, v10                                  // 000000D87940: 06041502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87944: BF870224
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87948: 7E1002FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D87950: D5010003 20060703
	v_add_f32_e32 v1, v1, v7                                   // 000000D87958: 06020F01
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8795C: 7E0E02FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D87964: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8796C: BF8701B1
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v7     // 000000D87970: C9081103 03040F04
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87978: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D87980: D5010002 20020502
	v_mov_b32_e32 v8, v4                                       // 000000D87988: 7E100304
	v_mov_b32_dpp v10, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8798C: 7E1402FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000D87994: D5010001 20020301
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D8799C: D5010004 21AA0904
	v_add_f32_e32 v2, v2, v7                                   // 000000D879A4: 06040F02
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D879A8: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D879B4: BF870234
	v_add_f32_e32 v1, v1, v10                                  // 000000D879B8: 06021501
	v_mov_b32_dpp v10, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D879BC: 7E1402FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D879C4: D5010003 20020703
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000D879CC: C9101104 04060102
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D879D4: BF870224
	v_mov_b32_e32 v12, v1                                      // 000000D879D8: 7E180301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000D879DC: D5010001 21AA0301
	v_add_f32_e32 v3, v3, v10                                  // 000000D879E4: 06061503
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D879E8: D5010002 21AA0502
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000D879F0: D65C0007 03FC0907 FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D879FC: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87A08: BF8701A4
	v_mov_b32_e32 v8, v3                                       // 000000D87A0C: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D87A10: D5010003 21AA0703
	v_add_f32_e32 v1, v1, v12                                  // 000000D87A18: 06021901
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D87A1C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D87A24: BF8701C4
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D87A28: D65C0008 03FC0908 FEDCBA98
	v_add_f32_e32 v2, v2, v7                                   // 000000D87A34: 06040F02
	.long 0x7f0e398b                                           // 000000D87A38: 7F0E398B
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000D87A3C: 100202FF 3DB504F3
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000D87A44: C9061103 030204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87A50: BF870001
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D87A54: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D87A5C: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D87A60: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87A68: CC200801 8A020306
	.long 0x7f0c398b                                           // 000000D87A70: 7F0C398B
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D87A74: CC200002 8A020505
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87A7C: CC200803 8A020705
	.long 0x7e0e3984                                           // 000000D87A84: 7E0E3984
	.long 0x7e0c3981                                           // 000000D87A88: 7E0C3981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87A8C: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000D87A90: D6100008 02052103
	v_and_b32_e32 v7, 1, v7                                    // 000000D87A98: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87A9C: BF870223
	v_and_b32_e32 v5, 1, v6                                    // 000000D87AA0: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000D87AA4: D6100006 02052102
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D87AAC: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D87AB8: BF870244
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000D87ABC: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398b                                           // 000000D87AC8: 7F0E398B
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000D87ACC: D6550001 03FE0B01 00007FFF
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D87AD8: D6550002 03FE0D02 00007FFF
	.long 0x7e0e3984                                           // 000000D87AE4: 7E0E3984
	v_add_nc_u32_e32 v4, s18, v9                               // 000000D87AE8: 4A081212
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87AEC: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000D87AF0: 360A02FF FFFF0000
	.long 0x7e163982                                           // 000000D87AF8: 7E163982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87AFC: BF870214
	v_and_b32_e32 v6, 0xffff, v7                               // 000000D87B00: 360C0EFF 0000FFFF
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[17:18]           // 000000D87B08: D6FF7C01 044608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87B14: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v11                       // 000000D87B18: D6570003 042E06FF FFFF0000
	v_or_b32_e32 v4, v5, v6                                    // 000000D87B24: 38080D05
	global_store_b64 v[1:2], v[3:4], off                       // 000000D87B28: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D87B30: 8C7E057E
	v_or_b32_e32 v1, 40, v26                                   // 000000D87B34: 380234A8
	s_mov_b32 s5, exec_lo                                      // 000000D87B38: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87B3C: BF870001
	.long 0xd4c4007e                                           // 000000D87B40: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000D87B44: 02020213
	s_cbranch_execz 202                                        // 000000D87B48: BFA500CA <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6974>
	global_load_b64 v[6:7], v19, s[12:13]                      // 000000D87B4C: DC560000 060C0013
	v_lshl_add_u32 v2, v25, 2, v21                             // 000000D87B54: D6460002 04550519
	v_add_nc_u32_e32 v1, s18, v1                               // 000000D87B5C: 4A020212
	ds_load_b128 v[2:5], v2                                    // 000000D87B60: DBFC0000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000D87B68: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_f32 v9, v4, v5     // 000000D87B6C: C9080702 08080B04
	v_dual_sub_f32 v2, v2, v3 :: v_dual_sub_f32 v3, v4, v5     // 000000D87B74: C94A0702 02020B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87B7C: BF8701A2
	v_sub_f32_e32 v5, v8, v9                                   // 000000D87B80: 080A1308
	v_add_f32_e32 v4, v8, v9                                   // 000000D87B84: 06081308
	v_add_f32_e32 v8, v2, v3                                   // 000000D87B88: 06100702
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D87B8C: BF870003
	v_mov_b32_dpp v9, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87B90: 7E1202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D87B98: D5010005 200E0B05
	v_sub_f32_e32 v2, v2, v3                                   // 000000D87BA0: 08040702
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87BA4: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D87BAC: D5010004 200E0904
	v_mov_b32_dpp v10, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87BB4: 7E1402FA FF016108
	v_add_f32_e32 v5, v5, v9                                   // 000000D87BBC: 060A1305
	v_mov_b32_dpp v11, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D87BC0: 7E1602FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D87BC8: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D87BD0: D5010008 200E1108
	v_add_f32_e32 v3, v4, v3                                   // 000000D87BD8: 06060704
	s_mov_b32 s3, 0x76543210                                   // 000000D87BDC: BE8300FF 76543210
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87BE4: BF870193
	v_add_f32_e32 v2, v2, v11                                  // 000000D87BE8: 06041702
	v_add_f32_e32 v4, v8, v10                                  // 000000D87BEC: 06081508
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87BF0: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D87BF8: D5010005 200A0B05
	.long 0x7f163880                                           // 000000D87C00: 7F163880
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87C04: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D87C0C: D5010002 200A0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D87C14: BF8700B1
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v10    // 000000D87C18: C9081105 05021502
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87C20: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D87C28: D5010003 200A0703
	v_add_f32_e32 v3, v3, v9                                   // 000000D87C30: 06061303
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87C34: BF8701A4
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87C38: 7E1202FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D87C40: D5010005 20060B05
	v_mov_b32_dpp v10, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87C48: 7E1402FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D87C50: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D87C58: BF8700B3
	v_add_f32_e32 v5, v5, v9                                   // 000000D87C5C: 060A1305
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D87C60: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D87C68: D5010004 200A0904
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v8    // 000000D87C70: C9081503 03041104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87C78: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D87C80: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87C88: BF8701A3
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D87C8C: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D87C94: D5010004 20060904
	v_add_f32_e32 v2, v2, v8                                   // 000000D87C9C: 06041102
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87CA0: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D87CA8: D5010005 20020B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D87CB0: BF8701B1
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000D87CB4: C9081304 04041105
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87CBC: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D87CC4: D5010003 20020703
	v_mov_b32_e32 v9, v5                                       // 000000D87CCC: 7E120305
	v_mov_b32_dpp v10, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87CD0: 7E1402FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D87CD8: D5010002 20020502
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D87CE0: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D87CE8: 06061103
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D87CEC: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D87CF8: BF8701B4
	v_add_f32_e32 v2, v2, v10                                  // 000000D87CFC: 06041502
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D87D00: 7E1402FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D87D08: D5010004 20020904
	v_dual_add_f32 v5, v5, v9 :: v_dual_mov_b32 v12, v2        // 000000D87D10: C9101305 050C0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D87D18: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87D20: BF870222
	v_dual_add_f32 v4, v4, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D87D24: C9061504 04040AFF 3DB504F3
	v_mov_b32_e32 v8, v3                                       // 000000D87D30: 7E100303
	v_permlanex16_b32 v12, v12, s3, 0xfedcba98                 // 000000D87D34: D65C000C 03FC070C FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D87D40: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D87D48: BF8701B4
	v_mov_b32_e32 v9, v4                                       // 000000D87D4C: 7E120304
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D87D50: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D87D58: D65C0008 03FC0708 FEDCBA98
	v_permlanex16_b32 v9, v9, s3, 0xfedcba98                   // 000000D87D64: D65C0009 03FC0709 FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87D70: BF8701A2
	v_add_f32_e32 v3, v3, v8                                   // 000000D87D74: 06061103
	.long 0x7f10398b                                           // 000000D87D78: 7F10398B
	v_add_f32_e32 v4, v4, v9                                   // 000000D87D7C: 06081304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D87D80: BF870113
	v_dual_add_f32 v2, v2, v12 :: v_dual_mul_f32 v3, 0x3db504f3, v3// 000000D87D84: C9061902 020206FF 3DB504F3
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D87D90: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D87D98: BF870132
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D87D9C: 100404FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D87DA4: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D87DA8: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87DB0: CC200802 8A020507
	.long 0x7f0e398b                                           // 000000D87DB8: 7F0E398B
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000D87DBC: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D87DC4: CC200804 8A020906
	.long 0x7e103985                                           // 000000D87DCC: 7E103985
	.long 0x7e0e3982                                           // 000000D87DD0: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87DD4: BF870193
	v_bfe_u32 v9, v4, 16, 1                                    // 000000D87DD8: D6100009 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000D87DE0: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87DE4: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000D87DE8: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000D87DEC: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000D87DF4: D6550005 03FE1105 00007FFF
	.long 0x7f10398b                                           // 000000D87E00: 7F10398B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D87E04: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D87E08: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D87E14: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D87E20: BF870224
	.long 0x7e103985                                           // 000000D87E24: 7E103985
	v_add3_u32 v5, v4, v9, 0x7fff                              // 000000D87E28: D6550005 03FE1304 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000D87E34: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D87E3C: BF8701B4
	.long 0x7e163983                                           // 000000D87E40: 7E163983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[17:18]           // 000000D87E44: D6FF7C01 044602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000D87E50: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v11                       // 000000D87E58: D6570003 042E0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D87E64: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000D87E68: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000D87E6C: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D87E74: 8C7E057E
	s_waitcnt_vscnt null, 0x0                                  // 000000D87E78: BC7C0000
	s_barrier                                                  // 000000D87E7C: BFBD0000
	s_mov_b32 s0, 0                                            // 000000D87E80: BE800080
	s_mov_b32 s3, -1                                           // 000000D87E84: BE8300C1
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000D87E88: 916A007E
	s_cbranch_vccnz 4350                                       // 000000D87E8C: BFA410FE <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad88>
	s_cmp_gt_i32 s20, 1                                        // 000000D87E90: BF028114
	s_mov_b32 s0, -1                                           // 000000D87E94: BE8000C1
	s_cbranch_scc0 2450                                        // 000000D87E98: BFA10992 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8fe4>
	v_or_b32_e32 v1, 0x100, v0                                 // 000000D87E9C: 380200FF 00000100
	v_lshrrev_b32_e32 v5, 4, v0                                // 000000D87EA4: 320A0084
	s_add_i32 s0, s19, -1                                      // 000000D87EA8: 8100C113
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87EAC: BF8701A2
	v_lshrrev_b32_e32 v6, 4, v1                                // 000000D87EB0: 320C0284
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000D87EB4: 30020083
	v_min_i32_e32 v2, s0, v5                                   // 000000D87EB8: 22040A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87EBC: BF870193
	v_min_i32_e32 v3, s0, v6                                   // 000000D87EC0: 22060C00
	v_and_b32_e32 v55, 0x78, v1                                // 000000D87EC4: 366E02FF 00000078
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87ECC: BF870193
	v_add_nc_u32_e32 v1, s18, v2                               // 000000D87ED0: 4A020412
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D87ED4: 4A060612
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87ED8: BF870193
	v_lshlrev_b32_e32 v7, 1, v55                               // 000000D87EDC: 300E6E81
	v_mad_i64_i32 v[1:2], null, 0x500, v1, 0                   // 000000D87EE0: D6FF7C01 020202FF 00000500
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D87EEC: BF870193
	v_mad_i64_i32 v[3:4], null, 0x500, v3, 0                   // 000000D87EF0: D6FF7C03 020206FF 00000500
	.long 0xd700000a                                           // 000000D87EFC: D700000A
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 000000D87F00: 02020E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D87F04: BF8701A1
	v_add_co_ci_u32_e64 v11, null, s11, 0, s0                  // 000000D87F08: D5207C0B 0001000B
	.long 0xd44c0000                                           // 000000D87F10: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D87F14: 020200FF 00000200
	.long 0xd7006a08                                           // 000000D87F1C: D7006A08
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000D87F20: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D87F24: BF8700A1
	v_add_co_ci_u32_e64 v9, null, v11, v2, vcc_lo              // 000000D87F28: D5207C09 01AA050B
	.long 0xd7006a0a                                           // 000000D87F30: D7006A0A
	v_cndmask_b32_e32 v1, v10, v3, vcc_lo                      // 000000D87F34: 0202070A
	v_add_co_ci_u32_e64 v11, null, v11, v4, vcc_lo             // 000000D87F38: D5207C0B 01AA090B
	s_clause 0x1                                               // 000000D87F40: BF850001
	global_load_b128 v[33:36], v[8:9], off                     // 000000D87F44: DC5E0000 217C0008
	global_load_b128 v[37:40], v[10:11], off                   // 000000D87F4C: DC5E0000 257C000A
	s_and_saveexec_b32 s1, s0                                  // 000000D87F54: BE812000
	s_cbranch_execz 6                                          // 000000D87F58: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6a74>
	v_mad_u32_u24 v8, 0x110, v5, v7                            // 000000D87F5C: D60B0008 041E0AFF 00000110
	s_waitcnt vmcnt(1)                                         // 000000D87F68: BF8907F7
	ds_store_b128 v8, v[33:36]                                 // 000000D87F6C: DB7C0000 00002108
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D87F74: 8C7E017E
	.long 0xd44c0001                                           // 000000D87F78: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D87F7C: 020200FF 00000100
	v_mul_u32_u24_e32 v56, 0x88, v6                            // 000000D87F84: 16700CFF 00000088
	s_and_saveexec_b32 s2, s1                                  // 000000D87F8C: BE822001
	s_cbranch_execz 6                                          // 000000D87F90: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6aac>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D87F94: BF870001
	v_lshl_add_u32 v6, v56, 1, v7                              // 000000D87F98: D6460006 041D0338
	s_waitcnt vmcnt(0)                                         // 000000D87FA0: BF8903F7
	ds_store_b128 v6, v[37:40]                                 // 000000D87FA4: DB7C0000 00002506
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D87FAC: 8C7E027E
	s_mul_i32 s4, s16, 0xc8000                                 // 000000D87FB0: 9604FF10 000C8000
	s_mul_i32 s5, s17, 0xa000                                  // 000000D87FB8: 9605FF11 0000A000
	s_mul_hi_i32 s3, s16, 0xc8000                              // 000000D87FC0: 9703FF10 000C8000
	s_add_u32 s4, s4, s5                                       // 000000D87FC8: 80040504
	s_mul_hi_i32 s5, s17, 0xa000                               // 000000D87FCC: 9705FF11 0000A000
	v_mul_u32_u24_e32 v61, 0x110, v5                           // 000000D87FD4: 167A0AFF 00000110
	s_addc_u32 s3, s3, s5                                      // 000000D87FDC: 82030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000D87FE0: BF870149
	v_dual_mov_b32 v5, s3 :: v_dual_and_b32 v54, 15, v0        // 000000D87FE4: CA240003 0536008F
	v_and_b32_e32 v53, 31, v0                                  // 000000D87FEC: 366A009F
	s_movk_i32 s12, 0x1eee                                     // 000000D87FF0: B00C1EEE
	s_mov_b32 s13, 0x76543210                                  // 000000D87FF4: BE8D00FF 76543210
	v_lshlrev_b32_e32 v11, 4, v54                              // 000000D87FFC: 30166C84
	v_mul_u32_u24_e32 v12, 0x88, v54                           // 000000D88000: 16186CFF 00000088
	s_movk_i32 s21, 0x60                                       // 000000D88008: B0150060
	s_movk_i32 s22, 0x80                                       // 000000D8800C: B0160080
	s_movk_i32 s23, 0xa0                                       // 000000D88010: B01700A0
	.long 0xd7006a03                                           // 000000D88014: D7006A03
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 000000D88018: 02021703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000D8801C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000D88020: D5207C04 01AA0880
	s_movk_i32 s24, 0xc0                                       // 000000D88028: B01800C0
	.long 0xd7006a03                                           // 000000D8802C: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000D88030: 0202060A
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000D88034: D5207C04 01AA080B
	s_movk_i32 s25, 0xe0                                       // 000000D8803C: B01900E0
	.long 0xd7006a29                                           // 000000D88040: D7006A29
	v_cndmask_b32_e32 v1, 0x100, v3, vcc_lo                    // 000000D88044: 020206FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8804C: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v4, vcc_lo               // 000000D88050: D5207C2A 01AA0880
	.long 0xd7006a01                                           // 000000D88058: D7006A01
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 000000D8805C: 02021701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000D88060: D5207C02 01AA0480
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D88068: BF890007
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8806C: BF870092
	.long 0xd7006a01                                           // 000000D88070: D7006A01
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000D88074: 0202020A
	v_add_co_ci_u32_e64 v2, null, s11, v2, vcc_lo              // 000000D88078: D5207C02 01AA040B
	v_mov_b32_e32 v9, 0                                        // 000000D88080: 7E120280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D88084: BF870093
	.long 0xd7006a2b                                           // 000000D88088: D7006A2B
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 000000D8808C: 020202FF 00000100
	v_add_co_ci_u32_e64 v44, null, 0, v2, vcc_lo               // 000000D88094: D5207C2C 01AA0480
	v_mov_b32_e32 v2, s3                                       // 000000D8809C: 7E040203
	v_lshlrev_b32_e32 v6, 5, v53                               // 000000D880A0: 300C6A85
	v_dual_mov_b32 v16, v9 :: v_dual_lshlrev_b32 v3, 2, v0     // 000000D880A4: CA220109 10020082
	.long 0xd44c0002                                           // 000000D880AC: D44C0002
	v_cndmask_b32_e32 v1, 16, v53, vcc_lo                      // 000000D880B0: 02026A90
	v_lshlrev_b32_e32 v68, 1, v12                              // 000000D880B4: 30881881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D880B8: BF870214
	v_add_nc_u32_e32 v7, 0x3f0, v6                             // 000000D880BC: 4A0E0CFF 000003F0
	v_and_or_b32 v3, 0x380, v3, s4                             // 000000D880C4: D6570003 001206FF 00000380
	s_mov_b64 s[4:5], 0                                        // 000000D880D0: BE840180
	s_barrier                                                  // 000000D880D4: BFBD0000
	buffer_gl0_inv                                             // 000000D880D8: E0AC0000 00000000
	v_lshrrev_b32_e32 v4, 3, v7                                // 000000D880E0: 32080E83
	v_lshl_or_b32 v1, v53, 2, v3                               // 000000D880E4: D6560001 040D0535
	v_mov_b32_e32 v11, v9                                      // 000000D880EC: 7E160309
	v_mov_b32_e32 v13, v9                                      // 000000D880F0: 7E1A0309
	v_mov_b32_e32 v15, v9                                      // 000000D880F4: 7E1E0309
	v_and_or_b32 v4, 0x7c, v4, v3                              // 000000D880F8: D6570004 040E08FF 0000007C
	v_mov_b32_e32 v12, v9                                      // 000000D88104: 7E180309
	v_mov_b32_e32 v14, v9                                      // 000000D88108: 7E1C0309
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8810C: BF870003
	.long 0xd7006a3e                                           // 000000D88110: D7006A3E
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000D88114: 02020808
	v_mov_b32_e32 v4, s3                                       // 000000D88118: 7E080203
	v_lshrrev_b32_e32 v8, 5, v7                                // 000000D8811C: 32100E85
	v_and_b32_e32 v10, 0x7e0, v7                               // 000000D88120: 36140EFF 000007E0
	v_add_co_ci_u32_e64 v63, null, s9, v5, vcc_lo              // 000000D88128: D5207C3F 01AA0A09
	.long 0xd7006a40                                           // 000000D88130: D7006A40
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 000000D88134: 02020208
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D88138: BF870214
	v_add_nc_u32_e32 v8, 1, v8                                 // 000000D8813C: 4A101081
	v_sub_nc_u32_e32 v6, v10, v6                               // 000000D88140: 4C0C0D0A
	v_add_co_ci_u32_e64 v65, null, s9, v2, vcc_lo              // 000000D88144: D5207C41 01AA0409
	v_mov_b32_e32 v10, v9                                      // 000000D8814C: 7E140309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D88150: BF870214
	v_and_b32_e32 v8, 31, v8                                   // 000000D88154: 3610109F
	v_add_nc_u32_e32 v57, 0xfffffc3c, v6                       // 000000D88158: 4A720CFF FFFFFC3C
	v_dual_mov_b32 v1, v9 :: v_dual_add_nc_u32 v58, 0xfffffc38, v6// 000000D88160: CA200109 013A0CFF FFFFFC38
	v_add_nc_u32_e32 v59, 0xfffffc34, v6                       // 000000D8816C: 4A760CFF FFFFFC34
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D88174: BF870004
	v_lshl_or_b32 v3, v8, 2, v3                                // 000000D88178: D6560003 040D0508
	v_add_nc_u32_e32 v60, 0xfffffc30, v6                       // 000000D88180: 4A780CFF FFFFFC30
	v_mov_b32_e32 v2, v9                                       // 000000D88188: 7E040309
	v_mov_b32_e32 v5, v9                                       // 000000D8818C: 7E0A0309
	v_mov_b32_e32 v6, v9                                       // 000000D88190: 7E0C0309
	.long 0xd7006a42                                           // 000000D88194: D7006A42
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000D88198: 02020608
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8819C: BF870001
	v_add_co_ci_u32_e64 v67, null, s9, v4, vcc_lo              // 000000D881A0: D5207C43 01AA0809
	v_mov_b32_e32 v3, v9                                       // 000000D881A8: 7E060309
	v_mov_b32_e32 v4, v9                                       // 000000D881AC: 7E080309
	v_mov_b32_e32 v7, v9                                       // 000000D881B0: 7E0E0309
	v_mov_b32_e32 v8, v9                                       // 000000D881B4: 7E100309
	s_mov_b32 s3, 0                                            // 000000D881B8: BE830080
	s_branch 22                                                // 000000D881BC: BFA00016 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6d18>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000D881C0: 8C7E1A7E
	.long 0xd7006a29                                           // 000000D881C4: D7006A29
	v_cndmask_b32_e32 v1, 0x100, v41, vcc_lo                   // 000000D881C8: 020252FF 00000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D881D0: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000D881D4: D5207C2A 01AA5480
	.long 0xd7006a2b                                           // 000000D881DC: D7006A2B
	v_cndmask_b32_e32 v1, 0x100, v43, vcc_lo                   // 000000D881E0: 020256FF 00000100
	v_add_co_ci_u32_e64 v44, null, 0, v44, vcc_lo              // 000000D881E8: D5207C2C 01AA5880
	s_add_u32 s4, s4, 0x2000                                   // 000000D881F0: 8004FF04 00002000
	s_addc_u32 s5, s5, 0                                       // 000000D881F8: 82058005
	s_add_i32 s3, s3, 1                                        // 000000D881FC: 81038103
	s_cmpk_eq_u32 s4, 0xa000                                   // 000000D88200: B484A000
	s_waitcnt lgkmcnt(0)                                       // 000000D88204: BF89FC07
	s_barrier                                                  // 000000D88208: BFBD0000
	buffer_gl0_inv                                             // 000000D8820C: E0AC0000 00000000
	s_cbranch_scc1 1320                                        // 000000D88214: BFA20528 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x81b8>
	s_cmpk_lg_u32 s4, 0x8000                                   // 000000D88218: B5048000
	s_cselect_b32 s26, -1, 0                                   // 000000D8821C: 981A80C1
	s_cmpk_eq_u32 s4, 0x8000                                   // 000000D88220: B4848000
	s_cbranch_scc1 4                                           // 000000D88224: BFA20004 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6d38>
	global_load_b128 v[33:36], v[43:44], off                   // 000000D88228: DC5E0000 217C002B
	global_load_b128 v[37:40], v[41:42], off                   // 000000D88230: DC5E0000 257C0029
	.long 0xd7006a11                                           // 000000D88238: D7006A11
	v_cndmask_b32_e32 v0, v62, v4, vcc_lo                      // 000000D8823C: 0200093E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D88240: BF8700A1
	v_add_co_ci_u32_e64 v18, null, s5, v63, vcc_lo             // 000000D88244: D5207C12 01AA7E05
	.long 0xd7006a13                                           // 000000D8824C: D7006A13
	v_cndmask_b32_e32 v0, v66, v4, vcc_lo                      // 000000D88250: 02000942
	v_add_co_ci_u32_e64 v20, null, s5, v67, vcc_lo             // 000000D88254: D5207C14 01AA8605
	.long 0xd7006a15                                           // 000000D8825C: D7006A15
	v_cndmask_b32_e32 v0, v64, v4, vcc_lo                      // 000000D88260: 02000940
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D88264: BF870001
	v_add_co_ci_u32_e64 v22, null, s5, v65, vcc_lo             // 000000D88268: D5207C16 01AA8205
	s_clause 0xb                                               // 000000D88270: BF85000B
	global_load_b32 v46, v[17:18], off                         // 000000D88274: DC520000 2E7C0011
	global_load_b32 v45, v[19:20], off                         // 000000D8827C: DC520000 2D7C0013
	global_load_b32 v69, v[21:22], off                         // 000000D88284: DC520000 457C0015
	global_load_b32 v48, v[17:18], off offset:1024             // 000000D8828C: DC520400 307C0011
	global_load_b32 v47, v[19:20], off offset:1024             // 000000D88294: DC520400 2F7C0013
	global_load_b32 v70, v[21:22], off offset:1024             // 000000D8829C: DC520400 467C0015
	global_load_b32 v50, v[17:18], off offset:2048             // 000000D882A4: DC520800 327C0011
	global_load_b32 v49, v[19:20], off offset:2048             // 000000D882AC: DC520800 317C0013
	global_load_b32 v71, v[21:22], off offset:2048             // 000000D882B4: DC520800 477C0015
	global_load_b32 v51, v[19:20], off offset:3072             // 000000D882BC: DC520C00 337C0013
	global_load_b32 v52, v[17:18], off offset:3072             // 000000D882C4: DC520C00 347C0011
	global_load_b32 v72, v[21:22], off offset:3072             // 000000D882CC: DC520C00 487C0015
	.long 0xd7006a49                                           // 000000D882D4: D7006A49
	v_cndmask_b32_e32 v1, 0x1000, v17, vcc_lo                  // 000000D882D8: 020222FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D882E0: BF8700A1
	v_add_co_ci_u32_e64 v74, null, 0, v18, vcc_lo              // 000000D882E4: D5207C4A 01AA2480
	.long 0xd7006a4b                                           // 000000D882EC: D7006A4B
	v_cndmask_b32_e32 v1, 0x1000, v19, vcc_lo                  // 000000D882F0: 020226FF 00001000
	v_add_co_ci_u32_e64 v76, null, 0, v20, vcc_lo              // 000000D882F8: D5207C4C 01AA2880
	.long 0xd7006a4d                                           // 000000D88300: D7006A4D
	v_cndmask_b32_e32 v1, 0x1000, v21, vcc_lo                  // 000000D88304: 02022AFF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8830C: BF870001
	v_add_co_ci_u32_e64 v78, null, 0, v22, vcc_lo              // 000000D88310: D5207C4E 01AA2C80
	s_clause 0xb                                               // 000000D88318: BF85000B
	global_load_b32 v138, v[73:74], off                        // 000000D8831C: DC520000 8A7C0049
	global_load_b32 v137, v[75:76], off                        // 000000D88324: DC520000 897C004B
	global_load_b32 v151, v[77:78], off                        // 000000D8832C: DC520000 977C004D
	global_load_b32 v140, v[73:74], off offset:1024            // 000000D88334: DC520400 8C7C0049
	global_load_b32 v139, v[75:76], off offset:1024            // 000000D8833C: DC520400 8B7C004B
	global_load_b32 v154, v[77:78], off offset:1024            // 000000D88344: DC520400 9A7C004D
	global_load_b32 v170, v[73:74], off offset:2048            // 000000D8834C: DC520800 AA7C0049
	global_load_b32 v169, v[75:76], off offset:2048            // 000000D88354: DC520800 A97C004B
	global_load_b32 v171, v[75:76], off offset:3072            // 000000D8835C: DC520C00 AB7C004B
	global_load_b32 v172, v[73:74], off offset:3072            // 000000D88364: DC520C00 AC7C0049
	global_load_b32 v173, v[77:78], off offset:2048            // 000000D8836C: DC520800 AD7C004D
	global_load_b32 v174, v[77:78], off offset:3072            // 000000D88374: DC520C00 AE7C004D
	s_bfe_i32 s27, s3, 0x10000                                 // 000000D8837C: 939BFF03 00010000
	s_and_b32 s28, s3, 1                                       // 000000D88384: 8B1C8103
	s_and_b32 s29, s27, 0x4400                                 // 000000D88388: 8B1DFF1B 00004400
	s_cmp_eq_u32 s28, 0                                        // 000000D88390: BF06801C
	s_cselect_b32 s27, -1, 0                                   // 000000D88394: 981B80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D88398: BF870009
	s_and_b32 s28, s27, exec_lo                                // 000000D8839C: 8B1C7E1B
	s_cselect_b32 s31, s22, 0x4480                             // 000000D883A0: 981FFF16 00004480
	s_cselect_b32 s28, 32, 0x4420                              // 000000D883A8: 981CFFA0 00004420
	s_cselect_b32 s30, s21, 0x4460                             // 000000D883B0: 981EFF15 00004460
	s_waitcnt vmcnt(22)                                        // 000000D883B8: BF895BF7
	.long 0xd73d008d                                           // 000000D883BC: D73D008D
	v_cndmask_b32_e32 v1, v57, v45, vcc_lo                     // 000000D883C0: 02025B39
	.long 0xd73d008e                                           // 000000D883C4: D73D008E
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 000000D883C8: 02025B3A
	.long 0xd73d008f                                           // 000000D883CC: D73D008F
	v_cndmask_b32_e32 v1, v59, v45, vcc_lo                     // 000000D883D0: 02025B3B
	s_waitcnt vmcnt(19)                                        // 000000D883D4: BF894FF7
	.long 0xd73d0090                                           // 000000D883D8: D73D0090
	v_cndmask_b32_e32 v1, v57, v47, vcc_lo                     // 000000D883DC: 02025F39
	.long 0xd73d002d                                           // 000000D883E0: D73D002D
	v_cndmask_b32_e32 v1, v60, v45, vcc_lo                     // 000000D883E4: 02025B3C
	.long 0xd73d0091                                           // 000000D883E8: D73D0091
	v_cndmask_b32_e32 v1, v58, v47, vcc_lo                     // 000000D883EC: 02025F3A
	.long 0xd73d0092                                           // 000000D883F0: D73D0092
	v_cndmask_b32_e32 v1, v59, v47, vcc_lo                     // 000000D883F4: 02025F3B
	.long 0xd73d002e                                           // 000000D883F8: D73D002E
	v_cndmask_b32_e32 v1, v60, v47, vcc_lo                     // 000000D883FC: 02025F3C
	s_waitcnt vmcnt(16)                                        // 000000D88400: BF8943F7
	.long 0xd73d002f                                           // 000000D88404: D73D002F
	v_cndmask_b32_e32 v1, v57, v49, vcc_lo                     // 000000D88408: 02026339
	v_bfe_u32 v150, v69, 12, 16                                // 000000D8840C: D6100096 02411945
	v_bfe_u32 v152, v69, 8, 16                                 // 000000D88414: D6100098 02411145
	v_bfe_u32 v153, v69, 4, 16                                 // 000000D8841C: D6100099 02410945
	v_and_b32_e32 v155, 0xffff, v69                            // 000000D88424: 37368AFF 0000FFFF
	v_bfe_u32 v156, v70, 12, 16                                // 000000D8842C: D610009C 02411946
	v_bfe_u32 v157, v70, 8, 16                                 // 000000D88434: D610009D 02411146
	v_bfe_u32 v158, v70, 4, 16                                 // 000000D8843C: D610009E 02410946
	v_and_b32_e32 v159, 0xffff, v70                            // 000000D88444: 373E8CFF 0000FFFF
	.long 0xd73d0045                                           // 000000D8844C: D73D0045
	v_cndmask_b32_e32 v1, v58, v49, vcc_lo                     // 000000D88450: 0202633A
	.long 0xd73d0093                                           // 000000D88454: D73D0093
	v_cndmask_b32_e32 v1, v59, v49, vcc_lo                     // 000000D88458: 0202633B
	.long 0xd73d0030                                           // 000000D8845C: D73D0030
	v_cndmask_b32_e32 v1, v60, v49, vcc_lo                     // 000000D88460: 0202633C
	s_waitcnt vmcnt(13)                                        // 000000D88464: BF8937F7
	.long 0xd73d0031                                           // 000000D88468: D73D0031
	v_cndmask_b32_e32 v1, v57, v51, vcc_lo                     // 000000D8846C: 02026739
	v_bfe_u32 v160, v71, 12, 16                                // 000000D88470: D61000A0 02411947
	v_bfe_u32 v161, v71, 8, 16                                 // 000000D88478: D61000A1 02411147
	v_bfe_u32 v162, v71, 4, 16                                 // 000000D88480: D61000A2 02410947
	v_and_b32_e32 v163, 0xffff, v71                            // 000000D88488: 37468EFF 0000FFFF
	.long 0xd73d0046                                           // 000000D88490: D73D0046
	v_cndmask_b32_e32 v1, v58, v51, vcc_lo                     // 000000D88494: 0202673A
	v_and_b32_e32 v49, 0xffff, v49                             // 000000D88498: 366262FF 0000FFFF
	.long 0xd73d0094                                           // 000000D884A0: D73D0094
	v_cndmask_b32_e32 v1, v59, v51, vcc_lo                     // 000000D884A4: 0202673B
	.long 0xd73d0032                                           // 000000D884A8: D73D0032
	v_cndmask_b32_e32 v1, v60, v51, vcc_lo                     // 000000D884AC: 0202673C
	s_waitcnt vmcnt(12)                                        // 000000D884B0: BF8933F7
	v_bfe_u32 v51, v72, 12, 16                                 // 000000D884B4: D6100033 02411948
	v_bfe_u32 v52, v72, 8, 16                                  // 000000D884BC: D6100034 02411148
	v_and_b32_e32 v70, 0xffff, v70                             // 000000D884C4: 368C8CFF 0000FFFF
	.long 0xd72c0031                                           // 000000D884CC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000D884D0: 020262FF 83DCD12D
	v_bfe_u32 v71, v72, 4, 16                                  // 000000D884D8: D6100047 02410948
	v_and_b32_e32 v72, 0xffff, v72                             // 000000D884E0: 369090FF 0000FFFF
	.long 0xd72c00a4                                           // 000000D884E8: D72C00A4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v150, vcc_lo             // 000000D884EC: 02032CFF 83DCD12D
	.long 0xd72c0046                                           // 000000D884F4: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000D884F8: 02028CFF 83DCD12D
	.long 0xd72c00a7                                           // 000000D88500: D72C00A7
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D88504: 020266FF 83DCD12D
	.long 0xd72c00a8                                           // 000000D8850C: D72C00A8
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D88510: 020268FF 83DCD12D
	.long 0xd72c00af                                           // 000000D88518: D72C00AF
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000D8851C: 02028EFF 83DCD12D
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000D88524: D6220031 03FD0131 00006400
	.long 0xd72c00b0                                           // 000000D88530: D72C00B0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000D88534: 020290FF 83DCD12D
	s_waitcnt vmcnt(10)                                        // 000000D8853C: BF892BF7
	.long 0xd73d0033                                           // 000000D88540: D73D0033
	v_cndmask_b32_e32 v1, v57, v137, vcc_lo                    // 000000D88544: 02031339
	.long 0xd73d0047                                           // 000000D88548: D73D0047
	v_cndmask_b32_e32 v1, v58, v137, vcc_lo                    // 000000D8854C: 0203133A
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D88550: D6220046 03FD0146 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 000000D8855C: 366262FF 0000FFFF
	.long 0xd73d0095                                           // 000000D88564: D73D0095
	v_cndmask_b32_e32 v1, v59, v137, vcc_lo                    // 000000D88568: 0203133B
	s_waitcnt vmcnt(9)                                         // 000000D8856C: BF8927F7
	v_bfe_u32 v52, v151, 12, 16                                // 000000D88570: D6100034 02411997
	v_bfe_u32 v72, v151, 8, 16                                 // 000000D88578: D6100048 02411197
	v_bfe_u32 v177, v151, 4, 16                                // 000000D88580: D61000B1 02410997
	v_and_b32_e32 v178, 0xffff, v151                           // 000000D88588: 37652EFF 0000FFFF
	s_waitcnt vmcnt(7)                                         // 000000D88590: BF891FF7
	.long 0xd73d0096                                           // 000000D88594: D73D0096
	v_cndmask_b32_e32 v1, v57, v139, vcc_lo                    // 000000D88598: 02031739
	.long 0xd72c00a5                                           // 000000D8859C: D72C00A5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v152, vcc_lo             // 000000D885A0: 020330FF 83DCD12D
	.long 0xd73d0089                                           // 000000D885A8: D73D0089
	v_cndmask_b32_e32 v1, v60, v137, vcc_lo                    // 000000D885AC: 0203133C
	.long 0xd73d0097                                           // 000000D885B0: D73D0097
	v_cndmask_b32_e32 v1, v58, v139, vcc_lo                    // 000000D885B4: 0203173A
	.long 0xd72c00a6                                           // 000000D885B8: D72C00A6
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 000000D885BC: 020332FF 83DCD12D
	.long 0xd73d0098                                           // 000000D885C4: D73D0098
	v_cndmask_b32_e32 v1, v59, v139, vcc_lo                    // 000000D885C8: 0203173B
	.long 0xd73d008a                                           // 000000D885CC: D73D008A
	v_cndmask_b32_e32 v1, v60, v139, vcc_lo                    // 000000D885D0: 0203173C
	s_waitcnt vmcnt(6)                                         // 000000D885D4: BF891BF7
	v_bfe_u32 v139, v154, 12, 16                               // 000000D885D8: D610008B 0241199A
	v_bfe_u32 v140, v154, 8, 16                                // 000000D885E0: D610008C 0241119A
	v_and_b32_e32 v141, 0xffff, v141                           // 000000D885E8: 371B1AFF 0000FFFF
	v_and_b32_e32 v142, 0xffff, v142                           // 000000D885F0: 371D1CFF 0000FFFF
	v_and_b32_e32 v143, 0xffff, v143                           // 000000D885F8: 371F1EFF 0000FFFF
	v_lshl_or_b32 v49, v70, 16, v49                            // 000000D88600: D6560031 04C52146
	v_and_b32_e32 v45, 0xffff, v45                             // 000000D88608: 365A5AFF 0000FFFF
	.long 0xd72c008b                                           // 000000D88610: D72C008B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v139, vcc_lo             // 000000D88614: 020316FF 83DCD12D
	.long 0xd72c00b3                                           // 000000D8861C: D72C00B3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v140, vcc_lo             // 000000D88620: 020318FF 83DCD12D
	.long 0xd72c008c                                           // 000000D88628: D72C008C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v141, vcc_lo             // 000000D8862C: 02031AFF 83DCD12D
	.long 0xd72c008d                                           // 000000D88634: D72C008D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v142, vcc_lo             // 000000D88638: 02031CFF 83DCD12D
	.long 0xd72c008e                                           // 000000D88640: D72C008E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v143, vcc_lo             // 000000D88644: 02031EFF 83DCD12D
	v_pk_fma_f16 v182, v49, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D8864C: CC0E00B6 0BFC1931 0000C931
	v_and_b32_e32 v144, 0xffff, v144                           // 000000D88658: 372120FF 0000FFFF
	v_and_b32_e32 v145, 0xffff, v145                           // 000000D88660: 372322FF 0000FFFF
	v_and_b32_e32 v146, 0xffff, v146                           // 000000D88668: 372524FF 0000FFFF
	v_and_b32_e32 v147, 0xffff, v147                           // 000000D88670: 372726FF 0000FFFF
	v_and_b32_e32 v148, 0xffff, v148                           // 000000D88678: 372928FF 0000FFFF
	.long 0xd72c009b                                           // 000000D88680: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 000000D88684: 020336FF 83DCD12D
	.long 0xd72c009c                                           // 000000D8868C: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 000000D88690: 020338FF 83DCD12D
	.long 0xd72c009f                                           // 000000D88698: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 000000D8869C: 02033EFF 83DCD12D
	.long 0xd72c00a0                                           // 000000D886A4: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 000000D886A8: 020340FF 83DCD12D
	.long 0xd72c002d                                           // 000000D886B0: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000D886B4: 02025AFF 83DCD12D
	v_dual_mov_b32 v188, v182 :: v_dual_and_b32 v51, 0xffff, v51// 000000D886BC: CA2401B6 BC3266FF 0000FFFF
	.long 0xd72c00a3                                           // 000000D886C8: D72C00A3
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 000000D886CC: 020346FF 83DCD12D
	.long 0xd72c008f                                           // 000000D886D4: D72C008F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v144, vcc_lo             // 000000D886D8: 020320FF 83DCD12D
	.long 0xd72c0090                                           // 000000D886E0: D72C0090
	v_cndmask_b32_e32 v1, 0x83dcd12d, v145, vcc_lo             // 000000D886E4: 020322FF 83DCD12D
	.long 0xd72c0091                                           // 000000D886EC: D72C0091
	v_cndmask_b32_e32 v1, 0x83dcd12d, v146, vcc_lo             // 000000D886F0: 020324FF 83DCD12D
	.long 0xd72c0092                                           // 000000D886F8: D72C0092
	v_cndmask_b32_e32 v1, 0x83dcd12d, v147, vcc_lo             // 000000D886FC: 020326FF 83DCD12D
	.long 0xd72c0093                                           // 000000D88704: D72C0093
	v_cndmask_b32_e32 v1, 0x83dcd12d, v148, vcc_lo             // 000000D88708: 020328FF 83DCD12D
	v_and_b32_e32 v148, 0xffff, v149                           // 000000D88710: 37292AFF 0000FFFF
	v_and_b32_e32 v149, 0xffff, v150                           // 000000D88718: 372B2CFF 0000FFFF
	v_and_b32_e32 v150, 0xffff, v151                           // 000000D88720: 372D2EFF 0000FFFF
	v_and_b32_e32 v151, 0xffff, v152                           // 000000D88728: 372F30FF 0000FFFF
	v_sad_u8 v152, v164, 0, 0x6400                             // 000000D88730: D6220098 03FD01A4 00006400
	v_sad_u8 v164, v167, 0, 0x6400                             // 000000D8873C: D62200A4 03FD01A7 00006400
	v_sad_u8 v167, v176, 0, 0x6400                             // 000000D88748: D62200A7 03FD01B0 00006400
	v_sad_u8 v176, v139, 0, 0x6400                             // 000000D88754: D62200B0 03FD018B 00006400
	v_sad_u8 v139, v140, 0, 0x6400                             // 000000D88760: D622008B 03FD018C 00006400
	v_sad_u8 v140, v141, 0, 0x6400                             // 000000D8876C: D622008C 03FD018D 00006400
	v_sad_u8 v141, v142, 0, 0x6400                             // 000000D88778: D622008D 03FD018E 00006400
	.long 0xd72c009d                                           // 000000D88784: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 000000D88788: 02033AFF 83DCD12D
	.long 0xd72c00a2                                           // 000000D88790: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 000000D88794: 020344FF 83DCD12D
	v_and_b32_e32 v71, 0xffff, v71                             // 000000D8879C: 368E8EFF 0000FFFF
	.long 0xd72c0033                                           // 000000D887A4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D887A8: 020266FF 83DCD12D
	v_bfe_u32 v153, v154, 4, 16                                // 000000D887B0: D6100099 0241099A
	v_and_b32_e32 v154, 0xffff, v154                           // 000000D887B8: 373534FF 0000FFFF
	v_and_b32_e32 v138, 0xffff, v138                           // 000000D887C0: 371514FF 0000FFFF
	v_sad_u8 v155, v155, 0, 0x6400                             // 000000D887C8: D622009B 03FD019B 00006400
	v_sad_u8 v156, v156, 0, 0x6400                             // 000000D887D4: D622009C 03FD019C 00006400
	v_sad_u8 v159, v159, 0, 0x6400                             // 000000D887E0: D622009F 03FD019F 00006400
	v_sad_u8 v160, v160, 0, 0x6400                             // 000000D887EC: D62200A0 03FD01A0 00006400
	v_sad_u8 v163, v163, 0, 0x6400                             // 000000D887F8: D62200A3 03FD01A3 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000D88804: D622002D 03FD012D 00006400
	v_and_b32_e32 v141, 0xffff, v141                           // 000000D88810: 371B1AFF 0000FFFF
	.long 0xd72c0047                                           // 000000D88818: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000D8881C: 02028EFF 83DCD12D
	v_and_b32_e32 v47, 0xffff, v47                             // 000000D88824: 365E5EFF 0000FFFF
	.long 0xd72c00b4                                           // 000000D8882C: D72C00B4
	v_cndmask_b32_e32 v1, 0x83dcd12d, v153, vcc_lo             // 000000D88830: 020332FF 83DCD12D
	.long 0xd72c00b5                                           // 000000D88838: D72C00B5
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 000000D8883C: 020334FF 83DCD12D
	v_sad_u8 v153, v165, 0, 0x6400                             // 000000D88844: D6220099 03FD01A5 00006400
	v_sad_u8 v154, v166, 0, 0x6400                             // 000000D88850: D622009A 03FD01A6 00006400
	v_sad_u8 v157, v157, 0, 0x6400                             // 000000D8885C: D622009D 03FD019D 00006400
	v_sad_u8 v162, v162, 0, 0x6400                             // 000000D88868: D62200A2 03FD01A2 00006400
	v_sad_u8 v165, v168, 0, 0x6400                             // 000000D88874: D62200A5 03FD01A8 00006400
	.long 0xd72c00a8                                           // 000000D88880: D72C00A8
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 000000D88884: 020314FF 83DCD12D
	v_and_b32_e32 v138, 0xffff, v152                           // 000000D8888C: 371530FF 0000FFFF
	v_lshlrev_b32_e32 v152, 16, v155                           // 000000D88894: 31313690
	v_and_b32_e32 v155, 0xffff, v156                           // 000000D88898: 373738FF 0000FFFF
	v_lshlrev_b32_e32 v156, 16, v159                           // 000000D888A0: 31393E90
	v_and_b32_e32 v159, 0xffff, v160                           // 000000D888A4: 373F40FF 0000FFFF
	v_lshlrev_b32_e32 v160, 16, v163                           // 000000D888AC: 31414690
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D888B0: D6220033 03FD0133 00006400
	v_lshl_or_b32 v45, v45, 16, v141                           // 000000D888BC: D656002D 0635212D
	v_and_b32_e32 v69, 0xffff, v69                             // 000000D888C4: 368A8AFF 0000FFFF
	.long 0xd72c002f                                           // 000000D888CC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000D888D0: 02025EFF 83DCD12D
	v_sad_u8 v142, v143, 0, 0x6400                             // 000000D888D8: D622008E 03FD018F 00006400
	v_sad_u8 v143, v144, 0, 0x6400                             // 000000D888E4: D622008F 03FD0190 00006400
	v_sad_u8 v144, v145, 0, 0x6400                             // 000000D888F0: D6220090 03FD0191 00006400
	v_sad_u8 v145, v146, 0, 0x6400                             // 000000D888FC: D6220091 03FD0192 00006400
	v_sad_u8 v146, v147, 0, 0x6400                             // 000000D88908: D6220092 03FD0193 00006400
	v_and_or_b32 v147, 0xffff, v154, v152                      // 000000D88914: D6570093 066334FF 0000FFFF
	v_lshl_or_b32 v152, v157, 16, v155                         // 000000D88920: D6560098 066D219D
	v_and_or_b32 v155, 0xffff, v162, v160                      // 000000D88928: D657009B 068344FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000D88934: D6220047 03FD0147 00006400
	v_and_b32_e32 v51, 0xffff, v51                             // 000000D88940: 366666FF 0000FFFF
	v_pk_fma_f16 v162, v45, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88948: CC0E00A2 0BFC192D 0000C931
	v_and_b32_e32 v46, 0xffff, v46                             // 000000D88954: 365C5CFF 0000FFFF
	.long 0xd72c0045                                           // 000000D8895C: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000D88960: 02028AFF 83DCD12D
	v_and_b32_e32 v137, 0xffff, v137                           // 000000D88968: 371312FF 0000FFFF
	.long 0xd72c0094                                           // 000000D88970: D72C0094
	v_cndmask_b32_e32 v1, 0x83dcd12d, v148, vcc_lo             // 000000D88974: 020328FF 83DCD12D
	v_lshl_or_b32 v45, v71, 16, v51                            // 000000D8897C: D656002D 04CD2147
	v_mov_b32_e32 v71, v162                                    // 000000D88984: 7E8E03A2
	.long 0xd72c002e                                           // 000000D88988: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000D8898C: 02025CFF 83DCD12D
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000D88994: D622002F 03FD012F 00006400
	.long 0xd72c0089                                           // 000000D889A0: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 000000D889A4: 020312FF 83DCD12D
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D889AC: D6220045 03FD0145 00006400
	v_and_b32_e32 v144, 0xffff, v144                           // 000000D889B8: 372120FF 0000FFFF
	v_sad_u8 v148, v148, 0, 0x6400                             // 000000D889C0: D6220094 03FD0194 00006400
	v_and_b32_e32 v47, 0xffff, v47                             // 000000D889CC: 365E5EFF 0000FFFF
	.long 0xd72c0096                                           // 000000D889D4: D72C0096
	v_cndmask_b32_e32 v1, 0x83dcd12d, v150, vcc_lo             // 000000D889D8: 02032CFF 83DCD12D
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000D889E0: D622002E 03FD012E 00006400
	.long 0xd72c0097                                           // 000000D889EC: D72C0097
	v_cndmask_b32_e32 v1, 0x83dcd12d, v151, vcc_lo             // 000000D889F0: 02032EFF 83DCD12D
	v_sad_u8 v166, v175, 0, 0x6400                             // 000000D889F8: D62200A6 03FD01AF 00006400
	v_and_b32_e32 v163, 0xffff, v164                           // 000000D88A04: 374748FF 0000FFFF
	v_lshlrev_b32_e32 v164, 16, v167                           // 000000D88A0C: 31494E90
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000D88A10: D6220089 03FD0189 00006400
	v_lshl_or_b32 v46, v46, 16, v144                           // 000000D88A1C: D656002E 0641212E
	v_lshl_or_b32 v47, v69, 16, v47                            // 000000D88A24: D656002F 04BD2145
	v_and_b32_e32 v69, 0xffff, v148                            // 000000D88A2C: 368B28FF 0000FFFF
	.long 0xd72c0034                                           // 000000D88A34: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D88A38: 020268FF 83DCD12D
	v_and_or_b32 v157, 0xffff, v166, v164                      // 000000D88A40: D657009D 06934CFF 0000FFFF
	v_and_b32_e32 v139, 0xffff, v139                           // 000000D88A4C: 371716FF 0000FFFF
	v_and_b32_e32 v142, 0xffff, v142                           // 000000D88A54: 371D1CFF 0000FFFF
	v_sad_u8 v164, v150, 0, 0x6400                             // 000000D88A5C: D62200A4 03FD0196 00006400
	v_sad_u8 v150, v151, 0, 0x6400                             // 000000D88A68: D6220096 03FD0197 00006400
	v_pk_fma_f16 v151, v152, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88A74: CC0E0097 0BFC1998 0000C931
	v_pk_fma_f16 v166, v46, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88A80: CC0E00A6 0BFC192E 0000C931
	v_lshl_or_b32 v46, v137, 16, v69                           // 000000D88A8C: D656002E 05152189
	.long 0xd72c009e                                           // 000000D88A94: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 000000D88A98: 02033CFF 83DCD12D
	.long 0xd72c0048                                           // 000000D88AA0: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000D88AA4: 020290FF 83DCD12D
	v_lshl_or_b32 v139, v140, 16, v139                         // 000000D88AAC: D656008B 062D218C
	v_lshl_or_b32 v140, v143, 16, v142                         // 000000D88AB4: D656008C 0639218F
	v_mov_b32_e32 v143, v151                                   // 000000D88ABC: 7F1E0397
	.long 0xd72c00b2                                           // 000000D88AC0: D72C00B2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v178, vcc_lo             // 000000D88AC4: 020364FF 83DCD12D
	v_pk_fma_f16 v191, v46, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88ACC: CC0E00BF 0BFC192E 0000C931
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D88AD8: 366464FF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D88AE0: D6220034 03FD0134 00006400
	.long 0xd72c00a1                                           // 000000D88AEC: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 000000D88AF0: 020342FF 83DCD12D
	.long 0xd72c00b1                                           // 000000D88AF8: D72C00B1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v177, vcc_lo             // 000000D88AFC: 020362FF 83DCD12D
	v_mov_b32_e32 v193, v191                                   // 000000D88B04: 7F8203BF
	.long 0xd72c0032                                           // 000000D88B08: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000D88B0C: 020264FF 83DCD12D
	v_sad_u8 v158, v158, 0, 0x6400                             // 000000D88B14: D622009E 03FD019E 00006400
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D88B20: D6220048 03FD0148 00006400
	v_sad_u8 v175, v178, 0, 0x6400                             // 000000D88B2C: D62200AF 03FD01B2 00006400
	v_and_b32_e32 v52, 0xffff, v52                             // 000000D88B38: 366868FF 0000FFFF
	v_dual_mov_b32 v185, v166 :: v_dual_and_b32 v48, 0xffff, v48// 000000D88B40: CA2401A6 B93060FF 0000FFFF
	v_sad_u8 v161, v161, 0, 0x6400                             // 000000D88B4C: D62200A1 03FD01A1 00006400
	v_sad_u8 v167, v177, 0, 0x6400                             // 000000D88B58: D62200A7 03FD01B1 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D88B64: D6220032 03FD0132 00006400
	v_lshl_or_b32 v138, v153, 16, v138                         // 000000D88B70: D656008A 06292199
	v_and_or_b32 v153, 0xffff, v158, v156                      // 000000D88B78: D6570099 06733CFF 0000FFFF
	v_lshlrev_b32_e32 v158, 16, v175                           // 000000D88B84: 313D5E90
	v_and_b32_e32 v146, 0xffff, v146                           // 000000D88B88: 372524FF 0000FFFF
	v_lshl_or_b32 v52, v72, 16, v52                            // 000000D88B90: D6560034 04D12148
	.long 0xd72c0030                                           // 000000D88B98: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000D88B9C: 020260FF 83DCD12D
	v_pk_fma_f16 v147, v147, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88BA4: CC0E0093 0BFC1993 0000C931
	v_add_nc_u32_e32 v29, s29, v68                             // 000000D88BB0: 4A3A881D
	v_lshl_or_b32 v154, v161, 16, v159                         // 000000D88BB4: D656009A 067D21A1
	v_pk_fma_f16 v138, v138, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88BBC: CC0E008A 0BFC198A 0000C931
	v_and_or_b32 v72, 0xffff, v167, v158                       // 000000D88BC8: D6570048 067B4EFF 0000FFFF
	v_lshl_or_b32 v50, v50, 16, v146                           // 000000D88BD4: D6560032 06492132
	v_pk_fma_f16 v158, v52, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88BDC: CC0E009E 0BFC1934 0000C931
	v_pk_fma_f16 v161, v139, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88BE8: CC0E00A1 0BFC198B 0000C931
	.long 0xd72c0095                                           // 000000D88BF4: D72C0095
	v_cndmask_b32_e32 v1, 0x83dcd12d, v149, vcc_lo             // 000000D88BF8: 02032AFF 83DCD12D
	v_mov_b32_e32 v142, v147                                   // 000000D88C00: 7F1C0393
	ds_load_b128 v[17:20], v29                                 // 000000D88C04: DBFC0000 1100001D
	ds_load_b128 v[21:24], v29 offset:16                       // 000000D88C0C: DBFC0010 1500001D
	ds_load_b128 v[25:28], v29 offset:4352                     // 000000D88C14: DBFC1100 1900001D
	ds_load_b128 v[29:32], v29 offset:4368                     // 000000D88C1C: DBFC1110 1D00001D
	v_add_nc_u32_e32 v133, s31, v68                            // 000000D88C24: 4B0A881F
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000D88C28: D6220030 03FD0130 00006400
	v_and_b32_e32 v145, 0xffff, v145                           // 000000D88C34: 372322FF 0000FFFF
	v_mov_b32_e32 v141, v138                                   // 000000D88C3C: 7F1A038A
	v_pk_fma_f16 v183, v50, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88C40: CC0E00B7 0BFC1932 0000C931
	v_dual_mov_b32 v49, v158 :: v_dual_mov_b32 v50, v161       // 000000D88C4C: CA10019E 313201A1
	v_sad_u8 v149, v149, 0, 0x6400                             // 000000D88C54: D6220095 03FD0195 00006400
	v_lshl_or_b32 v48, v48, 16, v145                           // 000000D88C60: D6560030 06452130
	v_permlanex16_b32 v141, v141, s13, 0xfedcba98              // 000000D88C68: D65C008D 03FC1B8D FEDCBA98
	v_permlanex16_b32 v142, v142, s13, 0xfedcba98              // 000000D88C74: D65C008E 03FC1B8E FEDCBA98
	v_permlanex16_b32 v49, v49, s13, 0xfedcba98                // 000000D88C80: D65C0031 03FC1B31 FEDCBA98
	v_permlanex16_b32 v50, v50, s13, 0xfedcba98                // 000000D88C8C: D65C0032 03FC1B32 FEDCBA98
	v_permlanex16_b32 v71, v71, s13, 0xfedcba98                // 000000D88C98: D65C0047 03FC1B47 FEDCBA98
	v_lshl_or_b32 v156, v165, 16, v163                         // 000000D88CA4: D656009C 068D21A5
	v_and_b32_e32 v70, 0xffff, v149                            // 000000D88CAC: 368D2AFF 0000FFFF
	v_pk_fma_f16 v177, v47, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88CB4: CC0E00B1 0BFC192F 0000C931
	v_pk_fma_f16 v178, v48, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88CC0: CC0E00B2 0BFC1930 0000C931
	v_pk_fma_f16 v190, v45, s12, 0xc931 op_sel_hi:[1,0,0]      // 000000D88CCC: CC0E00BE 0BFC192D 0000C931
	v_cndmask_b32_e64 v47, v141, v138, s2                      // 000000D88CD8: D501002F 000B158D
	v_cndmask_b32_e64 v51, v138, v141, s2                      // 000000D88CE0: D5010033 000B1B8A
	v_cndmask_b32_e64 v48, v142, v147, s2                      // 000000D88CE8: D5010030 000B278E
	v_cndmask_b32_e64 v52, v147, v142, s2                      // 000000D88CF0: D5010034 000B1D93
	v_cndmask_b32_e64 v163, v49, v158, s2                      // 000000D88CF8: D50100A3 000B3D31
	v_cndmask_b32_e64 v167, v158, v49, s2                      // 000000D88D00: D50100A7 000A639E
	v_cndmask_b32_e64 v45, v50, v161, s2                       // 000000D88D08: D501002D 000B4332
	v_cndmask_b32_e64 v49, v161, v50, s2                       // 000000D88D10: D5010031 000A65A1
	v_cndmask_b32_e64 v46, v71, v162, s2                       // 000000D88D18: D501002E 000B4547
	v_cndmask_b32_e64 v50, v162, v71, s2                       // 000000D88D20: D5010032 000A8FA2
	v_pk_fma_f16 v152, v153, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88D28: CC0E0098 0BFC1999 0000C931
	v_and_b32_e32 v175, 0xffff, v150                           // 000000D88D34: 375F2CFF 0000FFFF
	v_pk_fma_f16 v165, v140, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88D3C: CC0E00A5 0BFC198C 0000C931
	v_pk_fma_f16 v72, v72, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D88D48: CC0E0048 0BFC1948 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000D88D54: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[45:52], v[17:24], v[9:16]// 000000D88D58: CC404009 1C26232D
	v_sad_u8 v18, v168, 0, 0x6400                              // 000000D88D60: D6220012 03FD01A8 00006400
	v_and_b32_e32 v19, 0xffff, v176                            // 000000D88D6C: 362760FF 0000FFFF
	v_sad_u8 v20, v179, 0, 0x6400                              // 000000D88D74: D6220014 03FD01B3 00006400
	v_lshl_or_b32 v22, v164, 16, v70                           // 000000D88D80: D6560016 051921A4
	v_dual_mov_b32 v144, v152 :: v_dual_add_nc_u32 v85, s28, v68// 000000D88D88: CA200198 9054881C
	v_mov_b32_e32 v184, v165                                   // 000000D88D90: 7F7003A5
	v_sad_u8 v17, v181, 0, 0x6400                              // 000000D88D94: D6220011 03FD01B5 00006400
	v_lshl_or_b32 v18, v18, 16, v175                           // 000000D88DA0: D6560012 06BD2112
	v_lshl_or_b32 v19, v20, 16, v19                            // 000000D88DA8: D6560013 044D2114
	v_pk_fma_f16 v20, v22, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D88DB0: CC0E0014 0BFC1916 0000C931
	v_mov_b32_e32 v69, v72                                     // 000000D88DBC: 7E8A0348
	v_pk_fma_f16 v153, v154, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88DC0: CC0E0099 0BFC199A 0000C931
	v_pk_fma_f16 v154, v155, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88DCC: CC0E009A 0BFC199B 0000C931
	v_pk_fma_f16 v157, v157, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88DD8: CC0E009D 0BFC199D 0000C931
	v_permlanex16_b32 v143, v143, s13, 0xfedcba98              // 000000D88DE4: D65C008F 03FC1B8F FEDCBA98
	v_permlanex16_b32 v144, v144, s13, 0xfedcba98              // 000000D88DF0: D65C0090 03FC1B90 FEDCBA98
	v_permlanex16_b32 v184, v184, s13, 0xfedcba98              // 000000D88DFC: D65C00B8 03FC1BB8 FEDCBA98
	v_permlanex16_b32 v185, v185, s13, 0xfedcba98              // 000000D88E08: D65C00B9 03FC1BB9 FEDCBA98
	v_sad_u8 v21, v180, 0, 0x6400                              // 000000D88E14: D6220015 03FD01B4 00006400
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000D88E20: 30222290
	v_pk_fma_f16 v22, v18, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D88E24: CC0E0016 0BFC1912 0000C931
	v_pk_fma_f16 v23, v19, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D88E30: CC0E0017 0BFC1913 0000C931
	v_mov_b32_e32 v18, v20                                     // 000000D88E3C: 7E240314
	s_cselect_b32 s29, 64, 0x4440                              // 000000D88E40: 981DFFC0 00004440
	v_dual_mov_b32 v150, v157 :: v_dual_add_nc_u32 v117, s30, v68// 000000D88E48: CA20019D 9674881E
	v_dual_mov_b32 v146, v154 :: v_dual_add_nc_u32 v101, s29, v68// 000000D88E50: CA20019A 9264881D
	v_permlanex16_b32 v69, v69, s13, 0xfedcba98                // 000000D88E58: D65C0045 03FC1B45 FEDCBA98
	ds_load_b128 v[73:76], v85                                 // 000000D88E64: DBFC0000 49000055
	ds_load_b128 v[77:80], v85 offset:16                       // 000000D88E6C: DBFC0010 4D000055
	ds_load_b128 v[81:84], v85 offset:4352                     // 000000D88E74: DBFC1100 51000055
	ds_load_b128 v[85:88], v85 offset:4368                     // 000000D88E7C: DBFC1110 55000055
	ds_load_b128 v[89:92], v101                                // 000000D88E84: DBFC0000 59000065
	ds_load_b128 v[93:96], v101 offset:16                      // 000000D88E8C: DBFC0010 5D000065
	ds_load_b128 v[97:100], v101 offset:4352                   // 000000D88E94: DBFC1100 61000065
	ds_load_b128 v[101:104], v101 offset:4368                  // 000000D88E9C: DBFC1110 65000065
	ds_load_b128 v[105:108], v117                              // 000000D88EA4: DBFC0000 69000075
	ds_load_b128 v[109:112], v117 offset:16                    // 000000D88EAC: DBFC0010 6D000075
	ds_load_b128 v[113:116], v117 offset:4352                  // 000000D88EB4: DBFC1100 71000075
	ds_load_b128 v[117:120], v117 offset:4368                  // 000000D88EBC: DBFC1110 75000075
	ds_load_b128 v[121:124], v133                              // 000000D88EC4: DBFC0000 79000085
	ds_load_b128 v[125:128], v133 offset:16                    // 000000D88ECC: DBFC0010 7D000085
	ds_load_b128 v[129:132], v133 offset:4352                  // 000000D88ED4: DBFC1100 81000085
	ds_load_b128 v[133:136], v133 offset:4368                  // 000000D88EDC: DBFC1110 85000085
	v_cndmask_b32_e64 v139, v143, v151, s2                     // 000000D88EE4: D501008B 000B2F8F
	v_cndmask_b32_e64 v143, v151, v143, s2                     // 000000D88EEC: D501008F 000B1F97
	v_cndmask_b32_e64 v140, v144, v152, s2                     // 000000D88EF4: D501008C 000B3190
	v_cndmask_b32_e64 v144, v152, v144, s2                     // 000000D88EFC: D5010090 000B2198
	v_cndmask_b32_e64 v137, v184, v165, s2                     // 000000D88F04: D5010089 000B4BB8
	v_cndmask_b32_e64 v141, v165, v184, s2                     // 000000D88F0C: D501008D 000B71A5
	v_cndmask_b32_e64 v138, v185, v166, s2                     // 000000D88F14: D501008A 000B4DB9
	v_cndmask_b32_e64 v142, v166, v185, s2                     // 000000D88F1C: D501008E 000B73A6
	s_waitcnt lgkmcnt(16)                                      // 000000D88F24: BF89FD07
	v_wmma_f32_16x16x16_f16 v[1:8], v[45:52], v[25:32], v[1:8] // 000000D88F28: CC404001 1C06332D
	v_and_or_b32 v17, 0xffff, v21, v17                         // 000000D88F30: D6570011 04462AFF 0000FFFF
	v_dual_mov_b32 v19, v22 :: v_dual_mov_b32 v26, v23         // 000000D88F3C: CA100116 131A0117
	v_permlanex16_b32 v18, v18, s13, 0xfedcba98                // 000000D88F44: D65C0012 03FC1B12 FEDCBA98
	v_cndmask_b32_e64 v164, v69, v72, s2                       // 000000D88F50: D50100A4 000A9145
	v_cndmask_b32_e64 v168, v72, v69, s2                       // 000000D88F58: D50100A8 000A8B48
	s_cselect_b32 s28, s23, 0x44a0                             // 000000D88F60: 981CFF17 000044A0
	s_waitcnt vmcnt(4)                                         // 000000D88F68: BF8913F7
	.long 0xd73d0045                                           // 000000D88F6C: D73D0045
	v_cndmask_b32_e32 v1, v58, v169, vcc_lo                    // 000000D88F70: 0203533A
	.long 0xd73d0018                                           // 000000D88F74: D73D0018
	v_cndmask_b32_e32 v1, v57, v169, vcc_lo                    // 000000D88F78: 02035339
	.long 0xd73d0046                                           // 000000D88F7C: D73D0046
	v_cndmask_b32_e32 v1, v59, v169, vcc_lo                    // 000000D88F80: 0203533B
	s_waitcnt lgkmcnt(14)                                      // 000000D88F84: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[9:16], v[137:144], v[73:80], v[9:16]// 000000D88F88: CC404009 1C269389
	v_pk_fma_f16 v73, v17, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D88F90: CC0E0049 0BFC1911 0000C931
	v_permlanex16_b32 v19, v19, s13, 0xfedcba98                // 000000D88F9C: D65C0013 03FC1B13 FEDCBA98
	v_permlanex16_b32 v26, v26, s13, 0xfedcba98                // 000000D88FA8: D65C001A 03FC1B1A FEDCBA98
	v_cndmask_b32_e64 v17, v18, v20, s2                        // 000000D88FB4: D5010011 000A2912
	v_cndmask_b32_e64 v21, v20, v18, s2                        // 000000D88FBC: D5010015 000A2514
	v_add_nc_u32_e32 v20, s28, v68                             // 000000D88FC4: 4A28881C
	v_pk_fma_f16 v156, v156, s12, 0xc931 op_sel_hi:[1,0,0]     // 000000D88FC8: CC0E009C 0BFC199C 0000C931
	.long 0xd73d0047                                           // 000000D88FD4: D73D0047
	v_cndmask_b32_e32 v1, v60, v169, vcc_lo                    // 000000D88FD8: 0203533C
	v_cndmask_b32_e64 v18, v19, v22, s2                        // 000000D88FDC: D5010012 000A2D13
	v_cndmask_b32_e64 v22, v22, v19, s2                        // 000000D88FE4: D5010016 000A2716
	v_cndmask_b32_e64 v19, v26, v23, s2                        // 000000D88FEC: D5010013 000A2F1A
	v_cndmask_b32_e64 v23, v23, v26, s2                        // 000000D88FF4: D5010017 000A3517
	v_and_b32_e32 v24, 0xffff, v24                             // 000000D88FFC: 363030FF 0000FFFF
	ds_load_b128 v[25:28], v20                                 // 000000D89004: DBFC0000 19000014
	ds_load_b128 v[29:32], v20 offset:16                       // 000000D8900C: DBFC0010 1D000014
	ds_load_b128 v[45:48], v20 offset:4352                     // 000000D89014: DBFC1100 2D000014
	ds_load_b128 v[49:52], v20 offset:4368                     // 000000D8901C: DBFC1110 31000014
	v_and_b32_e32 v20, 0xffff, v69                             // 000000D89024: 36288AFF 0000FFFF
	v_and_b32_e32 v69, 0xffff, v70                             // 000000D8902C: 368A8CFF 0000FFFF
	v_mov_b32_e32 v145, v153                                   // 000000D89034: 7F220399
	v_dual_mov_b32 v149, v156 :: v_dual_mov_b32 v186, v177     // 000000D89038: CA10019C 95BA01B1
	v_mov_b32_e32 v187, v178                                   // 000000D89040: 7F7603B2
	.long 0xd72c0018                                           // 000000D89044: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000D89048: 020230FF 83DCD12D
	v_and_b32_e32 v70, 0xffff, v71                             // 000000D89050: 368C8EFF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 000000D89058: BF8907F7
	v_bfe_u32 v71, v173, 12, 16                                // 000000D8905C: D6100047 024119AD
	.long 0xd72c0045                                           // 000000D89064: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000D89068: 02028AFF 83DCD12D
	v_permlanex16_b32 v145, v145, s13, 0xfedcba98              // 000000D89070: D65C0091 03FC1B91 FEDCBA98
	v_permlanex16_b32 v146, v146, s13, 0xfedcba98              // 000000D8907C: D65C0092 03FC1B92 FEDCBA98
	v_permlanex16_b32 v149, v149, s13, 0xfedcba98              // 000000D89088: D65C0095 03FC1B95 FEDCBA98
	v_permlanex16_b32 v150, v150, s13, 0xfedcba98              // 000000D89094: D65C0096 03FC1B96 FEDCBA98
	v_mov_b32_e32 v189, v183                                   // 000000D890A0: 7F7A03B7
	v_permlanex16_b32 v186, v186, s13, 0xfedcba98              // 000000D890A4: D65C00BA 03FC1BBA FEDCBA98
	v_permlanex16_b32 v187, v187, s13, 0xfedcba98              // 000000D890B0: D65C00BB 03FC1BBB FEDCBA98
	v_bfe_u32 v72, v173, 8, 16                                 // 000000D890BC: D6100048 024111AD
	.long 0xd72c0047                                           // 000000D890C4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000D890C8: 02028EFF 83DCD12D
	.long 0xd72c0014                                           // 000000D890D0: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 000000D890D4: 020228FF 83DCD12D
	.long 0xd72c0046                                           // 000000D890DC: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000D890E0: 02028CFF 83DCD12D
	v_cndmask_b32_e64 v147, v145, v153, s2                     // 000000D890E8: D5010093 000B3391
	v_cndmask_b32_e64 v151, v153, v145, s2                     // 000000D890F0: D5010097 000B2399
	v_cndmask_b32_e64 v148, v146, v154, s2                     // 000000D890F8: D5010094 000B3592
	v_cndmask_b32_e64 v152, v154, v146, s2                     // 000000D89100: D5010098 000B259A
	v_cndmask_b32_e64 v155, v149, v156, s2                     // 000000D89108: D501009B 000B3995
	v_cndmask_b32_e64 v159, v156, v149, s2                     // 000000D89110: D501009F 000B2B9C
	v_cndmask_b32_e64 v156, v150, v157, s2                     // 000000D89118: D501009C 000B3B96
	v_cndmask_b32_e64 v160, v157, v150, s2                     // 000000D89120: D50100A0 000B2D9D
	v_permlanex16_b32 v188, v188, s13, 0xfedcba98              // 000000D89128: D65C00BC 03FC1BBC FEDCBA98
	v_permlanex16_b32 v189, v189, s13, 0xfedcba98              // 000000D89134: D65C00BD 03FC1BBD FEDCBA98
	v_mov_b32_e32 v192, v190                                   // 000000D89140: 7F8003BE
	v_cndmask_b32_e64 v145, v186, v177, s2                     // 000000D89144: D5010091 000B63BA
	v_cndmask_b32_e64 v149, v177, v186, s2                     // 000000D8914C: D5010095 000B75B1
	v_cndmask_b32_e64 v146, v187, v178, s2                     // 000000D89154: D5010092 000B65BB
	v_cndmask_b32_e64 v150, v178, v187, s2                     // 000000D8915C: D5010096 000B77B2
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000D89164: D6220018 03FD0118 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D89170: D6220045 03FD0145 00006400
	.long 0xd72c0048                                           // 000000D8917C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000D89180: 020290FF 83DCD12D
	v_cndmask_b32_e64 v153, v188, v182, s2                     // 000000D89188: D5010099 000B6DBC
	v_cndmask_b32_e64 v157, v182, v188, s2                     // 000000D89190: D501009D 000B79B6
	v_cndmask_b32_e64 v154, v189, v183, s2                     // 000000D89198: D501009A 000B6FBD
	v_permlanex16_b32 v192, v192, s13, 0xfedcba98              // 000000D891A0: D65C00C0 03FC1BC0 FEDCBA98
	v_cndmask_b32_e64 v158, v183, v189, s2                     // 000000D891AC: D501009E 000B7BB7
	v_permlanex16_b32 v193, v193, s13, 0xfedcba98              // 000000D891B4: D65C00C1 03FC1BC1 FEDCBA98
	s_waitcnt lgkmcnt(14)                                      // 000000D891C0: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[9:16], v[145:152], v[89:96], v[9:16]// 000000D891C4: CC404009 1C26B391
	v_mov_b32_e32 v74, v73                                     // 000000D891CC: 7E940349
	v_and_b32_e32 v24, 0xffff, v24                             // 000000D891D0: 363030FF 0000FFFF
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000D891D8: D6220047 03FD0147 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000D891E4: D6220014 03FD0114 00006400
	v_and_b32_e32 v69, 0xffff, v69                             // 000000D891F0: 368A8AFF 0000FFFF
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000D891F8: D6220046 03FD0146 00006400
	v_wmma_f32_16x16x16_f16 v[1:8], v[137:144], v[81:88], v[1:8]// 000000D89204: CC404001 1C06A389
	v_cndmask_b32_e64 v161, v192, v190, s2                     // 000000D8920C: D50100A1 000B7DC0
	v_cndmask_b32_e64 v165, v190, v192, s2                     // 000000D89214: D50100A5 000B81BE
	v_cndmask_b32_e64 v162, v193, v191, s2                     // 000000D8921C: D50100A2 000B7FC1
	v_cndmask_b32_e64 v166, v191, v193, s2                     // 000000D89224: D50100A6 000B83BF
	s_waitcnt lgkmcnt(10)                                      // 000000D8922C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[9:16], v[153:160], v[105:112], v[9:16]// 000000D89230: CC404009 1C26D399
	v_permlanex16_b32 v74, v74, s13, 0xfedcba98                // 000000D89238: D65C004A 03FC1B4A FEDCBA98
	v_and_b32_e32 v71, 0xffff, v71                             // 000000D89244: 368E8EFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000D8924C: D6220048 03FD0148 00006400
	v_lshl_or_b32 v24, v20, 16, v24                            // 000000D89258: D6560018 04612114
	v_lshl_or_b32 v69, v70, 16, v69                            // 000000D89260: D6560045 05152146
	v_and_b32_e32 v75, 0xffff, v173                            // 000000D89268: 36975AFF 0000FFFF
	v_wmma_f32_16x16x16_f16 v[1:8], v[145:152], v[97:104], v[1:8]// 000000D89270: CC404001 1C06C391
	s_waitcnt lgkmcnt(6)                                       // 000000D89278: BF89FC67
	v_wmma_f32_16x16x16_f16 v[9:16], v[161:168], v[121:128], v[9:16]// 000000D8927C: CC404009 1C26F3A1
	v_cndmask_b32_e64 v20, v74, v73, s2                        // 000000D89284: D5010014 000A934A
	v_lshl_or_b32 v70, v72, 16, v71                            // 000000D8928C: D6560046 051D2148
	v_pk_fma_f16 v72, v24, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D89294: CC0E0048 0BFC1918 0000C931
	v_cndmask_b32_e64 v24, v73, v74, s2                        // 000000D892A0: D5010018 000A9549
	v_pk_fma_f16 v69, v69, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D892A8: CC0E0045 0BFC1945 0000C931
	v_bfe_u32 v76, v173, 4, 16                                 // 000000D892B4: D610004C 024109AD
	.long 0xd72c004b                                           // 000000D892BC: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000D892C0: 020296FF 83DCD12D
	v_wmma_f32_16x16x16_f16 v[1:8], v[153:160], v[113:120], v[1:8]// 000000D892C8: CC404001 1C06E399
	s_waitcnt lgkmcnt(2)                                       // 000000D892D0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[17:24], v[25:32], v[9:16]// 000000D892D4: CC404009 1C263311
	v_mov_b32_e32 v25, v69                                     // 000000D892DC: 7E320345
	.long 0xd72c004c                                           // 000000D892E0: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000D892E4: 020298FF 83DCD12D
	v_pk_fma_f16 v70, v70, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D892EC: CC0E0046 0BFC1946 0000C931
	v_wmma_f32_16x16x16_f16 v[1:8], v[161:168], v[129:136], v[1:8]// 000000D892F8: CC404001 1C0703A1
	v_mov_b32_e32 v73, v72                                     // 000000D89300: 7E920348
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000D89304: D622004B 03FD014B 00006400
	v_permlanex16_b32 v25, v25, s13, 0xfedcba98                // 000000D89310: D65C0019 03FC1B19 FEDCBA98
	v_mov_b32_e32 v27, v70                                     // 000000D8931C: 7E360346
	s_waitcnt lgkmcnt(0)                                       // 000000D89320: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[17:24], v[45:52], v[1:8] // 000000D89324: CC404001 1C065B11
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000D8932C: D622004C 03FD014C 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000D89338: 30969690
	.long 0xd73d002d                                           // 000000D8933C: D73D002D
	v_cndmask_b32_e32 v1, v58, v171, vcc_lo                    // 000000D89340: 0203573A
	v_cndmask_b32_e64 v18, v25, v69, s2                        // 000000D89344: D5010012 000A8B19
	v_cndmask_b32_e64 v22, v69, v25, s2                        // 000000D8934C: D5010016 000A3345
	.long 0xd73d0019                                           // 000000D89354: D73D0019
	v_cndmask_b32_e32 v1, v57, v171, vcc_lo                    // 000000D89358: 02035739
	.long 0xd73d002e                                           // 000000D8935C: D73D002E
	v_cndmask_b32_e32 v1, v59, v171, vcc_lo                    // 000000D89360: 0203573B
	v_and_or_b32 v71, 0xffff, v76, v75                         // 000000D89364: D6570047 052E98FF 0000FFFF
	.long 0xd73d002f                                           // 000000D89370: D73D002F
	v_cndmask_b32_e32 v1, v60, v171, vcc_lo                    // 000000D89374: 0203573C
	s_waitcnt vmcnt(0)                                         // 000000D89378: BF8903F7
	v_bfe_u32 v50, v174, 12, 16                                // 000000D8937C: D6100032 024119AE
	v_and_b32_e32 v52, 0xffff, v174                            // 000000D89384: 36695CFF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 000000D8938C: 363232FF 0000FFFF
	v_and_b32_e32 v46, 0xffff, v46                             // 000000D89394: 365C5CFF 0000FFFF
	v_pk_fma_f16 v71, v71, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D8939C: CC0E0047 0BFC1947 0000C931
	v_and_b32_e32 v45, 0xffff, v45                             // 000000D893A8: 365A5AFF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 000000D893B0: 365E5EFF 0000FFFF
	.long 0xd72c0030                                           // 000000D893B8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000D893BC: 020232FF 83DCD12D
	v_bfe_u32 v51, v174, 8, 16                                 // 000000D893C4: D6100033 024111AE
	.long 0xd72c002e                                           // 000000D893CC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000D893D0: 02025CFF 83DCD12D
	.long 0xd72c0032                                           // 000000D893D8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000D893DC: 020264FF 83DCD12D
	v_bfe_u32 v69, v174, 4, 16                                 // 000000D893E4: D6100045 024109AE
	.long 0xd72c0034                                           // 000000D893EC: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D893F0: 020268FF 83DCD12D
	v_mov_b32_e32 v28, v71                                     // 000000D893F8: 7E380347
	.long 0xd72c002d                                           // 000000D893FC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000D89400: 02025AFF 83DCD12D
	.long 0xd72c002f                                           // 000000D89408: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000D8940C: 02025EFF 83DCD12D
	.long 0xd72c0033                                           // 000000D89414: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000D89418: 020266FF 83DCD12D
	.long 0xd72c0045                                           // 000000D89420: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000D89424: 02028AFF 83DCD12D
	v_permlanex16_b32 v28, v28, s13, 0xfedcba98                // 000000D8942C: D65C001C 03FC1B1C FEDCBA98
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000D89438: D6220030 03FD0130 00006400
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000D89444: D622002E 03FD012E 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 000000D89450: D6220032 03FD0132 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D8945C: D6220034 03FD0134 00006400
	s_cselect_b32 s28, s24, 0x44c0                             // 000000D89468: 981CFF18 000044C0
	v_permlanex16_b32 v73, v73, s13, 0xfedcba98                // 000000D89470: D65C0049 03FC1B49 FEDCBA98
	v_permlanex16_b32 v27, v27, s13, 0xfedcba98                // 000000D8947C: D65C001B 03FC1B1B FEDCBA98
	v_cndmask_b32_e64 v20, v28, v71, s2                        // 000000D89488: D5010014 000A8F1C
	v_cndmask_b32_e64 v24, v71, v28, s2                        // 000000D89490: D5010018 000A3947
	v_add_nc_u32_e32 v49, s28, v68                             // 000000D89498: 4A62881C
	v_and_b32_e32 v48, 0xffff, v48                             // 000000D8949C: 366060FF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000D894A4: D622002D 03FD012D 00006400
	v_and_b32_e32 v46, 0xffff, v46                             // 000000D894B0: 365C5CFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000D894B8: D622002F 03FD012F 00006400
	v_and_b32_e32 v50, 0xffff, v50                             // 000000D894C4: 366464FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000D894CC: D6220033 03FD0133 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000D894D8: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v71, 16, v52                             // 000000D894E4: 308E6890
	s_cselect_b32 s28, s25, 0x44e0                             // 000000D894E8: 981CFF19 000044E0
	v_cndmask_b32_e64 v17, v73, v72, s2                        // 000000D894F0: D5010011 000A9149
	v_cndmask_b32_e64 v21, v72, v73, s2                        // 000000D894F8: D5010015 000A9348
	v_cndmask_b32_e64 v19, v27, v70, s2                        // 000000D89500: D5010013 000A8D1B
	v_cndmask_b32_e64 v23, v70, v27, s2                        // 000000D89508: D5010017 000A3746
	ds_load_b128 v[25:28], v49                                 // 000000D89510: DBFC0000 19000031
	ds_load_b128 v[29:32], v49 offset:16                       // 000000D89518: DBFC0010 1D000031
	v_lshl_or_b32 v70, v45, 16, v48                            // 000000D89520: D6560046 04C1212D
	v_lshl_or_b32 v72, v47, 16, v46                            // 000000D89528: D6560048 04B9212F
	v_lshl_or_b32 v73, v51, 16, v50                            // 000000D89530: D6560049 04C92133
	ds_load_b128 v[45:48], v49 offset:4352                     // 000000D89538: DBFC1100 2D000031
	ds_load_b128 v[49:52], v49 offset:4368                     // 000000D89540: DBFC1110 31000031
	v_and_or_b32 v69, 0xffff, v69, v71                         // 000000D89548: D6570045 051E8AFF 0000FFFF
	v_add_nc_u32_e32 v81, s28, v68                             // 000000D89554: 4AA2881C
	v_pk_fma_f16 v85, v70, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D89558: CC0E0055 0BFC1946 0000C931
	v_pk_fma_f16 v86, v72, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D89564: CC0E0056 0BFC1948 0000C931
	v_pk_fma_f16 v87, v73, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D89570: CC0E0057 0BFC1949 0000C931
	v_pk_fma_f16 v88, v69, s12, 0xc931 op_sel_hi:[1,0,0]       // 000000D8957C: CC0E0058 0BFC1945 0000C931
	ds_load_b128 v[69:72], v81                                 // 000000D89588: DBFC0000 45000051
	ds_load_b128 v[73:76], v81 offset:16                       // 000000D89590: DBFC0010 49000051
	ds_load_b128 v[77:80], v81 offset:4352                     // 000000D89598: DBFC1100 4D000051
	ds_load_b128 v[81:84], v81 offset:4368                     // 000000D895A0: DBFC1110 51000051
	v_dual_mov_b32 v89, v85 :: v_dual_mov_b32 v90, v86         // 000000D895A8: CA100155 595A0156
	v_dual_mov_b32 v91, v87 :: v_dual_mov_b32 v92, v88         // 000000D895B0: CA100157 5B5C0158
	s_and_not1_b32 vcc_lo, exec_lo, s26                        // 000000D895B8: 916A1A7E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D895BC: BF870192
	v_permlanex16_b32 v89, v89, s13, 0xfedcba98                // 000000D895C0: D65C0059 03FC1B59 FEDCBA98
	v_permlanex16_b32 v90, v90, s13, 0xfedcba98                // 000000D895CC: D65C005A 03FC1B5A FEDCBA98
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D895D8: BF870003
	v_permlanex16_b32 v91, v91, s13, 0xfedcba98                // 000000D895DC: D65C005B 03FC1B5B FEDCBA98
	v_permlanex16_b32 v92, v92, s13, 0xfedcba98                // 000000D895E8: D65C005C 03FC1B5C FEDCBA98
	s_waitcnt lgkmcnt(6)                                       // 000000D895F4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[9:16], v[17:24], v[25:32], v[9:16]// 000000D895F8: CC404009 1C263311
	v_cndmask_b32_e64 v25, v89, v85, s2                        // 000000D89600: D5010019 000AAB59
	v_cndmask_b32_e64 v29, v85, v89, s2                        // 000000D89608: D501001D 000AB355
	v_cndmask_b32_e64 v26, v90, v86, s2                        // 000000D89610: D501001A 000AAD5A
	v_cndmask_b32_e64 v30, v86, v90, s2                        // 000000D89618: D501001E 000AB556
	v_cndmask_b32_e64 v27, v91, v87, s2                        // 000000D89620: D501001B 000AAF5B
	v_cndmask_b32_e64 v31, v87, v91, s2                        // 000000D89628: D501001F 000AB757
	v_cndmask_b32_e64 v28, v92, v88, s2                        // 000000D89630: D501001C 000AB15C
	v_cndmask_b32_e64 v32, v88, v92, s2                        // 000000D89638: D5010020 000AB958
	s_waitcnt lgkmcnt(4)                                       // 000000D89640: BF89FC47
	v_wmma_f32_16x16x16_f16 v[1:8], v[17:24], v[45:52], v[1:8] // 000000D89644: CC404001 1C065B11
	s_waitcnt lgkmcnt(2)                                       // 000000D8964C: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D89650: BF870122
	v_wmma_f32_16x16x16_f16 v[9:16], v[25:32], v[69:76], v[9:16]// 000000D89654: CC404009 1C268B19
	s_waitcnt lgkmcnt(0)                                       // 000000D8965C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[25:32], v[77:84], v[1:8] // 000000D89660: CC404001 1C069B19
	s_cbranch_vccnz 64214                                      // 000000D89668: BFA4FAD6 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6cc4>
	s_and_b32 s26, s27, exec_lo                                // 000000D8966C: 8B1A7E1B
	s_cselect_b32 s26, 0x4400, 0                               // 000000D89670: 981A80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D89678: BF870009
	v_lshl_or_b32 v17, v55, 1, s26                             // 000000D8967C: D6560011 00690337
	s_and_saveexec_b32 s26, s0                                 // 000000D89684: BE9A2000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D89688: BF870001
	v_add_nc_u32_e32 v18, v17, v61                             // 000000D8968C: 4A247B11
	ds_store_b128 v18, v[33:36]                                // 000000D89690: DB7C0000 00002112
	s_or_b32 exec_lo, exec_lo, s26                             // 000000D89698: 8C7E1A7E
	s_and_saveexec_b32 s26, s1                                 // 000000D8969C: BE9A2001
	s_cbranch_execz 64199                                      // 000000D896A0: BFA5FAC7 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6cc0>
	v_lshl_add_u32 v17, v56, 1, v17                            // 000000D896A4: D6460011 04450338
	ds_store_b128 v17, v[37:40]                                // 000000D896AC: DB7C0000 00002511
	s_branch 64194                                             // 000000D896B4: BFA0FAC2 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x6cc0>
	s_mul_i32 s0, s16, 0x1400                                  // 000000D896B8: 9600FF10 00001400
	s_mul_hi_i32 s1, s16, 0x1400                               // 000000D896C0: 9701FF10 00001400
	s_add_u32 s2, s14, s0                                      // 000000D896C8: 8002000E
	s_addc_u32 s3, s15, s1                                     // 000000D896CC: 8203010F
	s_lshl_b32 s0, s17, 7                                      // 000000D896D0: 84008711
	v_lshrrev_b32_e32 v18, 5, v0                               // 000000D896D4: 32240085
	s_ashr_i32 s1, s0, 31                                      // 000000D896D8: 86019F00
	v_and_b32_e32 v19, 1, v0                                   // 000000D896DC: 36260081
	v_and_b32_e32 v20, 2, v0                                   // 000000D896E0: 36280082
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D896E4: 84848100
	v_lshrrev_b32_e32 v23, 2, v53                              // 000000D896E8: 322E6A82
	s_add_u32 s12, s2, s4                                      // 000000D896EC: 800C0402
	s_addc_u32 s13, s3, s5                                     // 000000D896F0: 820D0503
	.long 0xd44a0003                                           // 000000D896F4: D44A0003
	v_cndmask_b32_e32 v1, 0, v19, vcc_lo                       // 000000D896F8: 02022680
	v_lshlrev_b32_e32 v19, 6, v18                              // 000000D896FC: 30262486
	.long 0xd44a0002                                           // 000000D89700: D44A0002
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 000000D89704: 02022880
	v_and_b32_e32 v20, 4, v0                                   // 000000D89708: 36280084
	v_and_b32_e32 v21, 8, v0                                   // 000000D8970C: 362A0088
	v_lshlrev_b32_e32 v17, 2, v53                              // 000000D89710: 30226A82
	v_mad_u32_u24 v19, 0x210, v54, v19                         // 000000D89714: D60B0013 044E6CFF 00000210
	v_and_b32_e32 v22, 16, v0                                  // 000000D89720: 362C0090
	.long 0xd44a0001                                           // 000000D89724: D44A0001
	v_cndmask_b32_e32 v1, 0, v20, vcc_lo                       // 000000D89728: 02022880
	v_lshlrev_b32_e32 v20, 3, v53                              // 000000D8972C: 30286A83
	.long 0xd44a0000                                           // 000000D89730: D44A0000
	v_cndmask_b32_e32 v1, 0, v21, vcc_lo                       // 000000D89734: 02022A80
	v_and_or_b32 v19, v23, 4, v19                              // 000000D89738: D6570013 044D0917
	ds_store_2addr_b32 v19, v9, v10 offset1:2                  // 000000D89740: D8380200 000A0913
	ds_store_2addr_b32 v19, v11, v12 offset0:4 offset1:6       // 000000D89748: D8380604 000C0B13
	ds_store_2addr_b32 v19, v13, v14 offset0:8 offset1:10      // 000000D89750: D8380A08 000E0D13
	.long 0xd7001514                                           // 000000D89758: D7001514
	v_cndmask_b32_e32 v1, s6, v20, vcc_lo                      // 000000D8975C: 02022806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D89760: BF8701A1
	v_add_co_ci_u32_e64 v21, null, s7, 0, s21                  // 000000D89764: D5207C15 00550007
	v_mul_u32_u24_e32 v12, 0x210, v18                          // 000000D8976C: 161824FF 00000210
	.long 0xd7000409                                           // 000000D89774: D7000409
	v_cndmask_b32_e32 v0, v20, v4, vcc_lo                      // 000000D89778: 02000914
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8977C: BF870001
	v_add_co_ci_u32_e64 v10, null, s5, v21, s4                 // 000000D89780: D5207C0A 00122A05
	v_lshlrev_b32_e32 v11, 1, v17                              // 000000D89788: 30162281
	s_mov_b32 s5, exec_lo                                      // 000000D8978C: BE85007E
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 000000D89790: 7C942C80
	ds_store_2addr_b32 v19, v15, v16 offset0:12 offset1:14     // 000000D89794: D8380E0C 00100F13
	s_waitcnt lgkmcnt(0)                                       // 000000D8979C: BF89FC07
	s_barrier                                                  // 000000D897A0: BFBD0000
	buffer_gl0_inv                                             // 000000D897A4: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D897AC: D4C4007E
	v_cndmask_b32_e32 v1, s19, v18, vcc_lo                     // 000000D897B0: 02022413
	s_cbranch_execz 200                                        // 000000D897B4: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x85d8>
	global_load_b64 v[20:21], v11, s[12:13]                    // 000000D897B8: DC560000 140C000B
	v_lshl_add_u32 v13, v17, 2, v12                            // 000000D897C0: D646000D 04310511
	s_mov_b32 s4, 0x76543210                                   // 000000D897C8: BE8400FF 76543210
	ds_load_b128 v[13:16], v13                                 // 000000D897D0: DBFC0000 0D00000D
	s_waitcnt lgkmcnt(0)                                       // 000000D897D8: BF89FC07
	v_dual_add_f32 v22, v13, v14 :: v_dual_add_f32 v23, v15, v16// 000000D897DC: C9081D0D 1616210F
	v_dual_sub_f32 v13, v13, v14 :: v_dual_sub_f32 v14, v15, v16// 000000D897E4: C94A1D0D 0D0E210F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D897EC: BF870112
	v_sub_f32_e32 v16, v22, v23                                // 000000D897F0: 08202F16
	v_dual_add_f32 v15, v22, v23 :: v_dual_add_f32 v22, v13, v14// 000000D897F4: C9082F16 0F161D0D
	v_sub_f32_e32 v13, v13, v14                                // 000000D897FC: 081A1D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89800: BF870223
	v_mov_b32_dpp v23, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89804: 7E2E02FA FF016110
	v_cndmask_b32_e64 v16, -v16, v16, s3                       // 000000D8980C: D5010010 200E2110
	v_mov_b32_dpp v14, v15 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89814: 7E1C02FA FF01610F
	v_cndmask_b32_e64 v15, -v15, v15, s3                       // 000000D8981C: D501000F 200E1F0F
	v_mov_b32_dpp v24, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89824: 7E3002FA FF016116
	v_mov_b32_dpp v25, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8982C: 7E3202FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s3                       // 000000D89834: D501000D 200E1B0D
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D8983C: D5010016 200E2D16
	v_add_f32_e32 v16, v16, v23                                // 000000D89844: 06202F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89848: BF870193
	v_dual_add_f32 v14, v15, v14 :: v_dual_add_f32 v13, v13, v25// 000000D8984C: C9081D0F 0E0C330D
	v_add_f32_e32 v15, v22, v24                                // 000000D89854: 061E3116
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89858: BF870223
	v_mov_b32_dpp v22, v16 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8985C: 7E2C02FA FF016210
	v_cndmask_b32_e64 v16, -v16, v16, s2                       // 000000D89864: D5010010 200A2110
	v_mov_b32_dpp v23, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8986C: 7E2E02FA FF01620E
	v_mov_b32_dpp v24, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89874: 7E3002FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000D8987C: D501000D 200A1B0D
	v_cndmask_b32_e64 v14, -v14, v14, s2                       // 000000D89884: D501000E 200A1D0E
	v_add_f32_e32 v16, v16, v22                                // 000000D8988C: 06202D10
	v_mov_b32_dpp v22, v15 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89890: 7E2C02FA FF01620F
	v_cndmask_b32_e64 v15, -v15, v15, s2                       // 000000D89898: D501000F 200A1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D898A0: BF870214
	v_dual_add_f32 v13, v13, v24 :: v_dual_add_f32 v14, v14, v23// 000000D898A4: C908310D 0D0E2F0E
	v_mov_b32_dpp v23, v16 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D898AC: 7E2E02FA FF016410
	v_cndmask_b32_e64 v16, -v16, v16, s1                       // 000000D898B4: D5010010 20062110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D898BC: BF870214
	v_add_f32_e32 v15, v15, v22                                // 000000D898C0: 061E2D0F
	v_mov_b32_dpp v22, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D898C4: 7E2C02FA FF01640D
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 000000D898CC: D501000D 20061B0D
	v_mov_b32_dpp v24, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D898D4: 7E3002FA FF01640E
	v_add_f32_e32 v16, v16, v23                                // 000000D898DC: 06202F10
	v_cndmask_b32_e64 v14, -v14, v14, s1                       // 000000D898E0: D501000E 20061D0E
	v_mov_b32_dpp v23, v15 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D898E8: 7E2E02FA FF01640F
	v_add_f32_e32 v13, v13, v22                                // 000000D898F0: 061A2D0D
	v_cndmask_b32_e64 v15, -v15, v15, s1                       // 000000D898F4: D501000F 20061F0F
	v_mov_b32_dpp v22, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D898FC: 7E2C02FA FF016810
	v_cndmask_b32_e64 v16, -v16, v16, s0                       // 000000D89904: D5010010 20022110
	v_add_f32_e32 v14, v14, v24                                // 000000D8990C: 061C310E
	v_mov_b32_dpp v24, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89910: 7E3002FA FF01680D
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000D89918: D501000D 20021B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89920: BF870214
	v_dual_add_f32 v15, v15, v23 :: v_dual_add_f32 v16, v16, v22// 000000D89924: C9082F0F 0F102D10
	v_mov_b32_dpp v22, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8992C: 7E2C02FA FF01680E
	v_cndmask_b32_e64 v14, -v14, v14, s0                       // 000000D89934: D501000E 20021D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8993C: BF870214
	v_add_f32_e32 v13, v13, v24                                // 000000D89940: 061A310D
	v_mov_b32_dpp v24, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89944: 7E3002FA FF01680F
	v_mov_b32_e32 v23, v16                                     // 000000D8994C: 7E2E0310
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000D89950: D501000F 20021F0F
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000D89958: D5010010 21AA2110
	v_mov_b32_e32 v26, v13                                     // 000000D89960: 7E34030D
	v_add_f32_e32 v14, v14, v22                                // 000000D89964: 061C2D0E
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D89968: D65C0017 03FC0917 FEDCBA98
	v_add_f32_e32 v15, v15, v24                                // 000000D89974: 061E310F
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000D89978: D501000D 21AA1B0D
	v_permlanex16_b32 v26, v26, s4, 0xfedcba98                 // 000000D89980: D65C001A 03FC091A FEDCBA98
	v_mov_b32_e32 v22, v14                                     // 000000D8998C: 7E2C030E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89990: BF870224
	v_dual_add_f32 v16, v16, v23 :: v_dual_mov_b32 v23, v15    // 000000D89994: C9102F10 1016010F
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000D8999C: D501000E 21AA1D0E
	v_add_f32_e32 v13, v13, v26                                // 000000D899A4: 061A350D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D899A8: BF870214
	v_permlanex16_b32 v22, v22, s4, 0xfedcba98                 // 000000D899AC: D65C0016 03FC0916 FEDCBA98
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 000000D899B8: 102020FF 3DB504F3
	.long 0x7f323880                                           // 000000D899C0: 7F323880
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000D899C4: D501000F 21AA1F0F
	v_permlanex16_b32 v23, v23, s4, 0xfedcba98                 // 000000D899CC: D65C0017 03FC0917 FEDCBA98
	v_dual_mul_f32 v13, 0x3db504f3, v13 :: v_dual_add_f32 v14, v14, v22// 000000D899D8: C8C81AFF 0D0E2D0E 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D899E4: BF870114
	.long 0x7f2c3999                                           // 000000D899E8: 7F2C3999
	v_dual_add_f32 v15, v15, v23 :: v_dual_mul_f32 v14, 0x3db504f3, v14// 000000D899EC: C9062F0F 0F0E1CFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D899F8: BF870001
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000D899FC: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D89A04: BF8903F7
	v_fma_mix_f32 v16, v21, v16, neg(0) op_sel_hi:[1,0,0]      // 000000D89A08: CC200010 8A022115
	v_fma_mix_f32 v13, v21, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D89A10: CC20080D 8A021B15
	.long 0x7f2a3999                                           // 000000D89A18: 7F2A3999
	v_fma_mix_f32 v14, v20, v14, neg(0) op_sel_hi:[1,0,0]      // 000000D89A1C: CC20000E 8A021D14
	v_fma_mix_f32 v15, v20, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D89A24: CC20080F 8A021F14
	.long 0x7e2c3990                                           // 000000D89A2C: 7E2C3990
	.long 0x7e2a398d                                           // 000000D89A30: 7E2A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89A34: BF870193
	v_bfe_u32 v23, v15, 16, 1                                  // 000000D89A38: D6100017 0205210F
	v_and_b32_e32 v22, 1, v22                                  // 000000D89A40: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89A44: BF870223
	v_and_b32_e32 v20, 1, v21                                  // 000000D89A48: 36282A81
	v_bfe_u32 v21, v14, 16, 1                                  // 000000D89A4C: D6100015 0205210E
	v_add3_u32 v15, v15, v23, 0x7fff                           // 000000D89A54: D655000F 03FE2F0F 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D89A60: BF870244
	v_add3_u32 v16, v16, v22, 0x7fff                           // 000000D89A64: D6550010 03FE2D10 00007FFF
	.long 0x7f2c3999                                           // 000000D89A70: 7F2C3999
	v_add3_u32 v13, v13, v20, 0x7fff                           // 000000D89A74: D655000D 03FE290D 00007FFF
	v_add3_u32 v14, v14, v21, 0x7fff                           // 000000D89A80: D655000E 03FE2B0E 00007FFF
	.long 0x7e2c3990                                           // 000000D89A8C: 7E2C3990
	v_add_nc_u32_e32 v16, s18, v18                             // 000000D89A90: 4A202412
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89A94: BF870214
	v_and_b32_e32 v20, 0xffff0000, v13                         // 000000D89A98: 36281AFF FFFF0000
	.long 0x7e32398e                                           // 000000D89AA0: 7E32398E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89AA4: BF870214
	v_and_b32_e32 v21, 0xffff, v22                             // 000000D89AA8: 362A2CFF 0000FFFF
	v_mad_i64_i32 v[13:14], null, 0x1400, v16, v[9:10]         // 000000D89AB0: D6FF7C0D 042620FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89ABC: BF870193
	v_and_or_b32 v15, 0xffff0000, v15, v25                     // 000000D89AC0: D657000F 04661EFF FFFF0000
	v_or_b32_e32 v16, v20, v21                                 // 000000D89ACC: 38202B14
	global_store_b64 v[13:14], v[15:16], off                   // 000000D89AD0: DC6E0000 007C0F0D
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D89AD8: 8C7E057E
	v_or_b32_e32 v14, 8, v18                                   // 000000D89ADC: 381C2488
	s_mov_b32 s5, exec_lo                                      // 000000D89AE0: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D89AE4: BF870001
	v_mul_u32_u24_e32 v13, 0x210, v14                          // 000000D89AE8: 161A1CFF 00000210
	.long 0xd4c4007e                                           // 000000D89AF0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v14, vcc_lo                     // 000000D89AF4: 02021C13
	s_cbranch_execz 199                                        // 000000D89AF8: BFA500C7 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8918>
	global_load_b64 v[15:16], v11, s[12:13]                    // 000000D89AFC: DC560000 0F0C000B
	v_lshl_add_u32 v20, v17, 2, v13                            // 000000D89B04: D6460014 04350511
	s_mov_b32 s4, 0x76543210                                   // 000000D89B0C: BE8400FF 76543210
	v_add_nc_u32_e32 v14, s18, v14                             // 000000D89B14: 4A1C1C12
	ds_load_b128 v[20:23], v20                                 // 000000D89B18: DBFC0000 14000014
	s_waitcnt lgkmcnt(0)                                       // 000000D89B20: BF89FC07
	v_dual_add_f32 v24, v20, v21 :: v_dual_add_f32 v25, v22, v23// 000000D89B24: C9082B14 18182F16
	v_dual_sub_f32 v20, v20, v21 :: v_dual_sub_f32 v21, v22, v23// 000000D89B2C: C94A2B14 14142F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D89B34: BF8701A2
	v_sub_f32_e32 v23, v24, v25                                // 000000D89B38: 082E3318
	v_add_f32_e32 v22, v24, v25                                // 000000D89B3C: 062C3318
	v_add_f32_e32 v24, v20, v21                                // 000000D89B40: 06302B14
	v_sub_f32_e32 v20, v20, v21                                // 000000D89B44: 08282B14
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D89B48: BF870004
	v_mov_b32_dpp v25, v23 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89B4C: 7E3202FA FF016117
	v_cndmask_b32_e64 v23, -v23, v23, s3                       // 000000D89B54: D5010017 200E2F17
	v_mov_b32_dpp v21, v22 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89B5C: 7E2A02FA FF016116
	v_cndmask_b32_e64 v22, -v22, v22, s3                       // 000000D89B64: D5010016 200E2D16
	v_mov_b32_dpp v26, v24 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89B6C: 7E3402FA FF016118
	v_mov_b32_dpp v27, v20 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89B74: 7E3602FA FF016114
	v_cndmask_b32_e64 v20, -v20, v20, s3                       // 000000D89B7C: D5010014 200E2914
	v_cndmask_b32_e64 v24, -v24, v24, s3                       // 000000D89B84: D5010018 200E3118
	v_add_f32_e32 v23, v23, v25                                // 000000D89B8C: 062E3317
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89B90: BF870193
	v_dual_add_f32 v21, v22, v21 :: v_dual_add_f32 v20, v20, v27// 000000D89B94: C9082B16 15143714
	v_add_f32_e32 v22, v24, v26                                // 000000D89B9C: 062C3518
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89BA0: BF870223
	v_mov_b32_dpp v24, v23 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89BA4: 7E3002FA FF016217
	v_cndmask_b32_e64 v23, -v23, v23, s2                       // 000000D89BAC: D5010017 200A2F17
	v_mov_b32_dpp v25, v21 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89BB4: 7E3202FA FF016215
	v_mov_b32_dpp v26, v20 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89BBC: 7E3402FA FF016214
	v_cndmask_b32_e64 v20, -v20, v20, s2                       // 000000D89BC4: D5010014 200A2914
	v_cndmask_b32_e64 v21, -v21, v21, s2                       // 000000D89BCC: D5010015 200A2B15
	v_add_f32_e32 v23, v23, v24                                // 000000D89BD4: 062E3117
	v_mov_b32_dpp v24, v22 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89BD8: 7E3002FA FF016216
	v_cndmask_b32_e64 v22, -v22, v22, s2                       // 000000D89BE0: D5010016 200A2D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89BE8: BF870214
	v_dual_add_f32 v20, v20, v26 :: v_dual_add_f32 v21, v21, v25// 000000D89BEC: C9083514 14143315
	v_mov_b32_dpp v25, v23 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89BF4: 7E3202FA FF016417
	v_cndmask_b32_e64 v23, -v23, v23, s1                       // 000000D89BFC: D5010017 20062F17
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89C04: BF870214
	v_add_f32_e32 v22, v22, v24                                // 000000D89C08: 062C3116
	v_mov_b32_dpp v24, v20 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89C0C: 7E3002FA FF016414
	v_cndmask_b32_e64 v20, -v20, v20, s1                       // 000000D89C14: D5010014 20062914
	v_mov_b32_dpp v26, v21 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89C1C: 7E3402FA FF016415
	v_add_f32_e32 v23, v23, v25                                // 000000D89C24: 062E3317
	v_cndmask_b32_e64 v21, -v21, v21, s1                       // 000000D89C28: D5010015 20062B15
	v_mov_b32_dpp v25, v22 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89C30: 7E3202FA FF016416
	v_add_f32_e32 v20, v20, v24                                // 000000D89C38: 06283114
	v_cndmask_b32_e64 v22, -v22, v22, s1                       // 000000D89C3C: D5010016 20062D16
	v_mov_b32_dpp v24, v23 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89C44: 7E3002FA FF016817
	v_cndmask_b32_e64 v23, -v23, v23, s0                       // 000000D89C4C: D5010017 20022F17
	v_add_f32_e32 v21, v21, v26                                // 000000D89C54: 062A3515
	v_mov_b32_dpp v26, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89C58: 7E3402FA FF016814
	v_cndmask_b32_e64 v20, -v20, v20, s0                       // 000000D89C60: D5010014 20022914
	.long 0x7f363880                                           // 000000D89C68: 7F363880
	v_dual_add_f32 v23, v23, v24 :: v_dual_add_f32 v22, v22, v25// 000000D89C6C: C9083117 17163316
	v_mov_b32_dpp v24, v21 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89C74: 7E3002FA FF016815
	v_cndmask_b32_e64 v21, -v21, v21, s0                       // 000000D89C7C: D5010015 20022B15
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D89C84: BF870003
	v_dual_add_f32 v20, v20, v26 :: v_dual_mov_b32 v25, v23    // 000000D89C88: C9103514 14180117
	v_cndmask_b32_e64 v23, -v23, v23, vcc_lo                   // 000000D89C90: D5010017 21AA2F17
	v_mov_b32_dpp v26, v22 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89C98: 7E3402FA FF016816
	v_cndmask_b32_e64 v22, -v22, v22, s0                       // 000000D89CA0: D5010016 20022D16
	v_add_f32_e32 v21, v21, v24                                // 000000D89CA8: 062A3115
	v_permlanex16_b32 v25, v25, s4, 0xfedcba98                 // 000000D89CAC: D65C0019 03FC0919 FEDCBA98
	v_mov_b32_e32 v28, v20                                     // 000000D89CB8: 7E380314
	v_cndmask_b32_e64 v20, -v20, v20, vcc_lo                   // 000000D89CBC: D5010014 21AA2914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89CC4: BF870193
	v_dual_add_f32 v23, v23, v25 :: v_dual_add_f32 v22, v22, v26// 000000D89CC8: C9083317 17163516
	v_permlanex16_b32 v28, v28, s4, 0xfedcba98                 // 000000D89CD0: D65C001C 03FC091C FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89CDC: BF870192
	v_dual_mul_f32 v23, 0x3db504f3, v23 :: v_dual_mov_b32 v24, v21// 000000D89CE0: C8D02EFF 17180115 3DB504F3
	v_mov_b32_e32 v25, v22                                     // 000000D89CEC: 7E320316
	v_cndmask_b32_e64 v21, -v21, v21, vcc_lo                   // 000000D89CF0: D5010015 21AA2B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D89CF8: BF870244
	v_add_f32_e32 v20, v20, v28                                // 000000D89CFC: 06283914
	v_cndmask_b32_e64 v22, -v22, v22, vcc_lo                   // 000000D89D00: D5010016 21AA2D16
	v_permlanex16_b32 v24, v24, s4, 0xfedcba98                 // 000000D89D08: D65C0018 03FC0918 FEDCBA98
	v_permlanex16_b32 v25, v25, s4, 0xfedcba98                 // 000000D89D14: D65C0019 03FC0919 FEDCBA98
	v_mul_f32_e32 v20, 0x3db504f3, v20                         // 000000D89D20: 102828FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D89D28: BF870122
	v_dual_add_f32 v21, v21, v24 :: v_dual_add_f32 v22, v22, v25// 000000D89D2C: C9083115 15163316
	.long 0x7f30399b                                           // 000000D89D34: 7F30399B
	v_mul_f32_e32 v22, 0x3db504f3, v22                         // 000000D89D38: 102C2CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D89D40: BF8903F7
	v_fma_mix_f32 v23, v16, v23, neg(0) op_sel_hi:[1,0,0]      // 000000D89D44: CC200017 8A022F10
	v_fma_mix_f32 v16, v16, v20, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D89D4C: CC200810 8A022910
	v_mul_f32_e32 v20, 0x3db504f3, v21                         // 000000D89D54: 10282AFF 3DB504F3
	.long 0x7f2a399b                                           // 000000D89D5C: 7F2A399B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D89D60: BF870214
	.long 0x7e303997                                           // 000000D89D64: 7E303997
	.long 0x7e2a3990                                           // 000000D89D68: 7E2A3990
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89D6C: BF870224
	v_fma_mix_f32 v20, v15, v20, neg(0) op_sel_hi:[1,0,0]      // 000000D89D70: CC200014 8A02290F
	v_fma_mix_f32 v15, v15, v22, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D89D78: CC20080F 8A022D0F
	v_and_b32_e32 v24, 1, v24                                  // 000000D89D80: 36303081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D89D84: BF870194
	v_and_b32_e32 v21, 1, v21                                  // 000000D89D88: 362A2A81
	v_bfe_u32 v25, v15, 16, 1                                  // 000000D89D8C: D6100019 0205210F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000D89D94: BF870243
	v_add3_u32 v22, v23, v24, 0x7fff                           // 000000D89D98: D6550016 03FE3117 00007FFF
	v_bfe_u32 v23, v20, 16, 1                                  // 000000D89DA4: D6100017 02052114
	.long 0x7f30399b                                           // 000000D89DAC: 7F30399B
	v_add3_u32 v16, v16, v21, 0x7fff                           // 000000D89DB0: D6550010 03FE2B10 00007FFF
	.long 0x7e303996                                           // 000000D89DBC: 7E303996
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89DC0: BF870224
	v_add3_u32 v20, v20, v23, 0x7fff                           // 000000D89DC4: D6550014 03FE2F14 00007FFF
	v_add3_u32 v22, v15, v25, 0x7fff                           // 000000D89DD0: D6550016 03FE330F 00007FFF
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000D89DDC: 362020FF FFFF0000
	v_mad_i64_i32 v[14:15], null, 0x1400, v14, v[9:10]         // 000000D89DE4: D6FF7C0E 04261CFF 00001400
	v_and_b32_e32 v21, 0xffff, v24                             // 000000D89DF0: 362A30FF 0000FFFF
	.long 0x7e363994                                           // 000000D89DF8: 7E363994
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D89DFC: BF870112
	v_or_b32_e32 v21, v16, v21                                 // 000000D89E00: 382A2B10
	v_and_or_b32 v20, 0xffff0000, v22, v27                     // 000000D89E04: D6570014 046E2CFF FFFF0000
	global_store_b64 v[14:15], v[20:21], off                   // 000000D89E10: DC6E0000 007C140E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D89E18: 8C7E057E
	v_or_b32_e32 v14, 16, v18                                  // 000000D89E1C: 381C2490
	s_mov_b32 s5, exec_lo                                      // 000000D89E20: BE85007E
	s_waitcnt_vscnt null, 0x0                                  // 000000D89E24: BC7C0000
	s_barrier                                                  // 000000D89E28: BFBD0000
	buffer_gl0_inv                                             // 000000D89E2C: E0AC0000 00000000
	ds_store_2addr_b32 v19, v1, v2 offset1:2                   // 000000D89E34: D8380200 00020113
	ds_store_2addr_b32 v19, v3, v4 offset0:4 offset1:6         // 000000D89E3C: D8380604 00040313
	ds_store_2addr_b32 v19, v5, v6 offset0:8 offset1:10        // 000000D89E44: D8380A08 00060513
	ds_store_2addr_b32 v19, v7, v8 offset0:12 offset1:14       // 000000D89E4C: D8380E0C 00080713
	s_waitcnt lgkmcnt(0)                                       // 000000D89E54: BF89FC07
	s_barrier                                                  // 000000D89E58: BFBD0000
	buffer_gl0_inv                                             // 000000D89E5C: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D89E64: D4C4007E
	v_cndmask_b32_e32 v1, s19, v14, vcc_lo                     // 000000D89E68: 02021C13
	s_cbranch_execz 200                                        // 000000D89E6C: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8c90>
	global_load_b64 v[5:6], v11, s[12:13]                      // 000000D89E70: DC560000 050C000B
	v_lshl_add_u32 v1, v17, 2, v12                             // 000000D89E78: D6460001 04310511
	s_mov_b32 s4, 0x76543210                                   // 000000D89E80: BE8400FF 76543210
	ds_load_b128 v[1:4], v1                                    // 000000D89E88: DBFC0000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000D89E90: BF89FC07
	v_dual_add_f32 v7, v1, v2 :: v_dual_add_f32 v8, v3, v4     // 000000D89E94: C9080501 07080903
	v_dual_sub_f32 v1, v1, v2 :: v_dual_sub_f32 v2, v3, v4     // 000000D89E9C: C94A0501 01020903
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D89EA4: BF8701A2
	v_sub_f32_e32 v4, v7, v8                                   // 000000D89EA8: 08081107
	v_add_f32_e32 v3, v7, v8                                   // 000000D89EAC: 06061107
	v_add_f32_e32 v7, v1, v2                                   // 000000D89EB0: 060E0501
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D89EB4: BF870003
	v_mov_b32_dpp v8, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89EB8: 7E1002FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D89EC0: D5010004 200E0904
	v_sub_f32_e32 v1, v1, v2                                   // 000000D89EC8: 08020501
	v_mov_b32_dpp v2, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89ECC: 7E0402FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D89ED4: D5010003 200E0703
	v_mov_b32_dpp v12, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89EDC: 7E1802FA FF016107
	v_add_f32_e32 v4, v4, v8                                   // 000000D89EE4: 06081104
	v_mov_b32_dpp v15, v1 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D89EE8: 7E1E02FA FF016101
	v_cndmask_b32_e64 v1, -v1, v1, s3                          // 000000D89EF0: D5010001 200E0301
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D89EF8: D5010007 200E0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D89F00: BF870112
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v1, v15    // 000000D89F04: C9080503 02001F01
	v_add_f32_e32 v3, v7, v12                                  // 000000D89F0C: 06061907
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89F10: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D89F18: D5010004 200A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D89F20: BF870004
	v_mov_b32_dpp v8, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89F24: 7E1002FA FF016202
	v_mov_b32_dpp v12, v1 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89F2C: 7E1802FA FF016201
	v_cndmask_b32_e64 v1, -v1, v1, s2                          // 000000D89F34: D5010001 200A0301
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D89F3C: D5010002 200A0502
	v_add_f32_e32 v4, v4, v7                                   // 000000D89F44: 06080F04
	v_mov_b32_dpp v7, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D89F48: 7E0E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D89F50: D5010003 200A0703
	v_add_f32_e32 v1, v1, v12                                  // 000000D89F58: 06021901
	v_add_f32_e32 v2, v2, v8                                   // 000000D89F5C: 06041102
	v_mov_b32_dpp v8, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89F60: 7E1002FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D89F68: D5010004 20060904
	v_add_f32_e32 v3, v3, v7                                   // 000000D89F70: 06060F03
	v_mov_b32_dpp v7, v1 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89F74: 7E0E02FA FF016401
	v_cndmask_b32_e64 v1, -v1, v1, s1                          // 000000D89F7C: D5010001 20060301
	v_mov_b32_dpp v12, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89F84: 7E1802FA FF016402
	v_add_f32_e32 v4, v4, v8                                   // 000000D89F8C: 06081104
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D89F90: D5010002 20060502
	v_mov_b32_dpp v8, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D89F98: 7E1002FA FF016403
	v_add_f32_e32 v1, v1, v7                                   // 000000D89FA0: 06020F01
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D89FA4: D5010003 20060703
	v_mov_b32_dpp v7, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89FAC: 7E0E02FA FF016804
	v_add_f32_e32 v2, v2, v12                                  // 000000D89FB4: 06041902
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D89FB8: D5010004 20020904
	v_mov_b32_dpp v12, v1 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D89FC0: 7E1802FA FF016801
	v_cndmask_b32_e64 v1, -v1, v1, s0                          // 000000D89FC8: D5010001 20020301
	.long 0x7f1e3880                                           // 000000D89FD0: 7F1E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D89FD4: BF870092
	v_dual_add_f32 v4, v4, v7 :: v_dual_add_f32 v1, v1, v12    // 000000D89FD8: C9080F04 04001901
	v_dual_add_f32 v3, v3, v8 :: v_dual_mov_b32 v8, v4         // 000000D89FE0: C9101103 03080104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D89FE8: D5010004 21AA0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D89FF0: BF870223
	v_mov_b32_e32 v16, v1                                      // 000000D89FF4: 7E200301
	v_cndmask_b32_e64 v1, -v1, v1, vcc_lo                      // 000000D89FF8: D5010001 21AA0301
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A000: 7E1802FA FF016803
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D8A008: D65C0008 03FC0908 FEDCBA98
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D8A014: D5010003 20020703
	v_permlanex16_b32 v16, v16, s4, 0xfedcba98                 // 000000D8A01C: D65C0010 03FC0910 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A028: BF870091
	v_add_f32_e32 v1, v1, v16                                  // 000000D8A02C: 06022101
	v_mul_f32_e32 v1, 0x3db504f3, v1                           // 000000D8A030: 100202FF 3DB504F3
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A038: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D8A040: D5010002 20020502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A048: BF870091
	v_add_f32_e32 v2, v2, v7                                   // 000000D8A04C: 06040F02
	v_dual_add_f32 v4, v4, v8 :: v_dual_mov_b32 v7, v2         // 000000D8A050: C9101104 04060102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D8A058: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A060: BF870092
	v_permlanex16_b32 v7, v7, s4, 0xfedcba98                   // 000000D8A064: D65C0007 03FC0907 FEDCBA98
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v2, v2, v7    // 000000D8A070: C9081903 03020F02
	.long 0x7f0e398f                                           // 000000D8A078: 7F0E398F
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000D8A07C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8A084: BF8701B3
	v_mov_b32_e32 v8, v3                                       // 000000D8A088: 7E100303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D8A08C: D5010003 21AA0703
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D8A094: 100404FF 3DB504F3
	v_permlanex16_b32 v8, v8, s4, 0xfedcba98                   // 000000D8A09C: D65C0008 03FC0908 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A0A8: BF870001
	v_add_f32_e32 v3, v3, v8                                   // 000000D8A0AC: 06061103
	s_waitcnt vmcnt(0)                                         // 000000D8A0B0: BF8903F7
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D8A0B4: CC200004 8A020906
	v_fma_mix_f32 v1, v6, v1, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8A0BC: CC200801 8A020306
	.long 0x7f0c398f                                           // 000000D8A0C4: 7F0C398F
	v_fma_mix_f32 v2, v5, v2, neg(0) op_sel_hi:[1,0,0]         // 000000D8A0C8: CC200002 8A020505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8A0D0: BF870214
	.long 0x7e0e3984                                           // 000000D8A0D4: 7E0E3984
	.long 0x7e0c3981                                           // 000000D8A0D8: 7E0C3981
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A0DC: BF870092
	v_and_b32_e32 v7, 1, v7                                    // 000000D8A0E0: 360E0E81
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000D8A0E4: D6550004 03FE0F04 00007FFF
	.long 0x7f0e398f                                           // 000000D8A0F0: 7F0E398F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8A0F4: BF8700A2
	.long 0x7e0e3984                                           // 000000D8A0F8: 7E0E3984
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_add_nc_u32 v4, s18, v14// 000000D8A0FC: C8E006FF 03041C12 3DB504F3
	v_fma_mix_f32 v3, v5, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8A108: CC200803 8A020705
	v_and_b32_e32 v5, 1, v6                                    // 000000D8A110: 360A0C81
	v_bfe_u32 v6, v2, 16, 1                                    // 000000D8A114: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A11C: BF870193
	v_bfe_u32 v8, v3, 16, 1                                    // 000000D8A120: D6100008 02052103
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000D8A128: D6550001 03FE0B01 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8A134: BF870223
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D8A138: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v6, 0xffff, v7                               // 000000D8A144: 360C0EFF 0000FFFF
	v_add3_u32 v3, v3, v8, 0x7fff                              // 000000D8A14C: D6550003 03FE1103 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8A158: BF870214
	v_and_b32_e32 v5, 0xffff0000, v1                           // 000000D8A15C: 360A02FF FFFF0000
	.long 0x7e1e3982                                           // 000000D8A164: 7E1E3982
	v_mad_i64_i32 v[1:2], null, 0x1400, v4, v[9:10]            // 000000D8A168: D6FF7C01 042608FF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A174: BF870193
	v_or_b32_e32 v4, v5, v6                                    // 000000D8A178: 38080D05
	v_and_or_b32 v3, 0xffff0000, v3, v15                       // 000000D8A17C: D6570003 043E06FF FFFF0000
	global_store_b64 v[1:2], v[3:4], off                       // 000000D8A188: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D8A190: 8C7E057E
	v_or_b32_e32 v1, 24, v18                                   // 000000D8A194: 38022498
	s_mov_b32 s5, exec_lo                                      // 000000D8A198: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A19C: BF870001
	.long 0xd4c4007e                                           // 000000D8A1A0: D4C4007E
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 000000D8A1A4: 02020213
	s_cbranch_execz 201                                        // 000000D8A1A8: BFA500C9 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x8fd0>
	global_load_b64 v[6:7], v11, s[12:13]                      // 000000D8A1AC: DC560000 060C000B
	v_lshl_add_u32 v2, v17, 2, v13                             // 000000D8A1B4: D6460002 04350511
	v_add_nc_u32_e32 v1, s18, v1                               // 000000D8A1BC: 4A020212
	ds_load_b128 v[2:5], v2                                    // 000000D8A1C0: DBFC0000 02000002
	s_waitcnt lgkmcnt(0)                                       // 000000D8A1C8: BF89FC07
	v_dual_add_f32 v8, v2, v3 :: v_dual_add_f32 v11, v4, v5    // 000000D8A1CC: C9080702 080A0B04
	v_dual_sub_f32 v2, v2, v3 :: v_dual_sub_f32 v3, v4, v5     // 000000D8A1D4: C94A0702 02020B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8A1DC: BF8701A2
	v_add_f32_e32 v4, v8, v11                                  // 000000D8A1E0: 06081708
	v_sub_f32_e32 v5, v8, v11                                  // 000000D8A1E4: 080A1708
	v_add_f32_e32 v8, v2, v3                                   // 000000D8A1E8: 06100702
	v_sub_f32_e32 v2, v2, v3                                   // 000000D8A1EC: 08040702
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8A1F0: BF870224
	v_mov_b32_dpp v3, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8A1F4: 7E0602FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D8A1FC: D5010004 200E0904
	v_mov_b32_dpp v12, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8A204: 7E1802FA FF016108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000D8A20C: BF870134
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8A210: 7E1A02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D8A218: D5010002 200E0502
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 000000D8A220: D5010008 200E1108
	v_dual_add_f32 v3, v4, v3 :: v_dual_add_f32 v2, v2, v13    // 000000D8A228: C9080704 03021B02
	v_mov_b32_dpp v11, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8A230: 7E1602FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D8A238: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8A240: BF870004
	v_add_f32_e32 v4, v8, v12                                  // 000000D8A244: 06081908
	s_mov_b32 s3, 0x76543210                                   // 000000D8A248: BE8300FF 76543210
	v_mov_b32_dpp v12, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8A250: 7E1802FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D8A258: D5010002 200A0502
	v_add_f32_e32 v5, v5, v11                                  // 000000D8A260: 060A1705
	.long 0x7f1a3880                                           // 000000D8A264: 7F1A3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A268: BF870193
	v_add_f32_e32 v2, v2, v12                                  // 000000D8A26C: 06041902
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8A270: 7E1002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D8A278: D5010005 200A0B05
	v_mov_b32_dpp v11, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8A280: 7E1602FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D8A288: D5010003 200A0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8A290: BF870233
	v_add_f32_e32 v5, v5, v8                                   // 000000D8A294: 060A1105
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8A298: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D8A2A0: D5010004 200A0904
	v_add_f32_e32 v3, v3, v11                                  // 000000D8A2A8: 06061703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8A2AC: BF870224
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8A2B0: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D8A2B8: D5010005 20060B05
	v_add_f32_e32 v4, v4, v8                                   // 000000D8A2C0: 06081104
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8A2C4: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D8A2CC: D5010002 20060502
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8A2D4: 7E1802FA FF016403
	v_add_f32_e32 v5, v5, v11                                  // 000000D8A2DC: 060A1705
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D8A2E0: D5010003 20060703
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8A2E8: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v8                                   // 000000D8A2F0: 06041102
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D8A2F4: D5010004 20060904
	v_mov_b32_dpp v8, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A2FC: 7E1002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D8A304: D5010005 20020B05
	v_add_f32_e32 v3, v3, v12                                  // 000000D8A30C: 06061903
	v_mov_b32_dpp v12, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A310: 7E1802FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D8A318: D5010002 20020502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8A320: BF870214
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v4, v4, v11    // 000000D8A324: C9081105 05041704
	v_mov_b32_dpp v8, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A32C: 7E1002FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D8A334: D5010003 20020703
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8A33C: BF8701A3
	v_mov_b32_e32 v11, v5                                      // 000000D8A340: 7E160305
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D8A344: D5010005 21AA0B05
	v_add_f32_e32 v3, v3, v8                                   // 000000D8A34C: 06061103
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D8A350: BF8701C3
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000D8A354: D65C000B 03FC070B FEDCBA98
	v_add_f32_e32 v2, v2, v12                                  // 000000D8A360: 06041902
	v_mov_b32_dpp v12, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8A364: 7E1802FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D8A36C: D5010004 20020904
	v_dual_add_f32 v5, v5, v11 :: v_dual_mov_b32 v14, v2       // 000000D8A374: C9101705 050E0102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D8A37C: D5010002 21AA0502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A384: BF870192
	v_dual_add_f32 v4, v4, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000D8A388: C9061904 04040AFF 3DB504F3
	v_permlanex16_b32 v14, v14, s3, 0xfedcba98                 // 000000D8A394: D65C000E 03FC070E FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8A3A0: BF8701B2
	v_dual_mov_b32 v8, v3 :: v_dual_mov_b32 v11, v4            // 000000D8A3A4: CA100103 080A0104
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D8A3AC: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D8A3B4: D5010004 21AA0904
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D8A3BC: D65C0008 03FC0708 FEDCBA98
	v_add_f32_e32 v2, v2, v14                                  // 000000D8A3C8: 06041D02
	v_permlanex16_b32 v11, v11, s3, 0xfedcba98                 // 000000D8A3CC: D65C000B 03FC070B FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8A3D8: BF8701A2
	v_dual_add_f32 v3, v3, v8 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000D8A3DC: C9061103 030204FF 3DB504F3
	.long 0x7f10398d                                           // 000000D8A3E8: 7F10398D
	v_add_f32_e32 v4, v4, v11                                  // 000000D8A3EC: 06081704
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A3F0: BF870001
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000D8A3F4: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D8A400: BF8903F7
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel_hi:[1,0,0]         // 000000D8A404: CC200005 8A020B07
	v_fma_mix_f32 v2, v7, v2, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8A40C: CC200802 8A020507
	.long 0x7f0e398d                                           // 000000D8A414: 7F0E398D
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel_hi:[1,0,0]         // 000000D8A418: CC200003 8A020706
	v_fma_mix_f32 v4, v6, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8A420: CC200804 8A020906
	.long 0x7e103985                                           // 000000D8A428: 7E103985
	.long 0x7e0e3982                                           // 000000D8A42C: 7E0E3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A430: BF870193
	v_bfe_u32 v11, v4, 16, 1                                   // 000000D8A434: D610000B 02052104
	v_and_b32_e32 v8, 1, v8                                    // 000000D8A43C: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8A440: BF8701A3
	v_and_b32_e32 v6, 1, v7                                    // 000000D8A444: 360C0E81
	v_bfe_u32 v7, v3, 16, 1                                    // 000000D8A448: D6100007 02052103
	v_add3_u32 v5, v5, v8, 0x7fff                              // 000000D8A450: D6550005 03FE1105 00007FFF
	.long 0x7f10398d                                           // 000000D8A45C: 7F10398D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8A460: BF870214
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000D8A464: D6550002 03FE0D02 00007FFF
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D8A470: D6550003 03FE0F03 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8A47C: BF870224
	.long 0x7e103985                                           // 000000D8A480: 7E103985
	v_add3_u32 v5, v4, v11, 0x7fff                             // 000000D8A484: D6550005 03FE1704 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v2                           // 000000D8A490: 360804FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000D8A498: BF8701B4
	.long 0x7e1a3983                                           // 000000D8A49C: 7E1A3983
	v_mad_i64_i32 v[1:2], null, 0x1400, v1, v[9:10]            // 000000D8A4A0: D6FF7C01 042602FF 00001400
	v_and_b32_e32 v6, 0xffff, v8                               // 000000D8A4AC: 360C10FF 0000FFFF
	v_and_or_b32 v3, 0xffff0000, v5, v13                       // 000000D8A4B4: D6570003 04360AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8A4C0: BF870002
	v_or_b32_e32 v4, v4, v6                                    // 000000D8A4C4: 38080D04
	global_store_b64 v[1:2], v[3:4], off                       // 000000D8A4C8: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D8A4D0: 8C7E057E
	s_mov_b32 s0, 0                                            // 000000D8A4D4: BE800080
	s_mov_b32 s3, -1                                           // 000000D8A4D8: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000D8A4DC: BC7C0000
	s_barrier                                                  // 000000D8A4E0: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000D8A4E4: 8B6A007E
	s_cbranch_vccz 1895                                        // 000000D8A4E8: BFA30767 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad88>
	s_cmp_eq_u32 s20, 1                                        // 000000D8A4EC: BF068114
	s_cbranch_scc0 1893                                        // 000000D8A4F0: BFA10765 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad88>
	v_lshrrev_b32_e32 v7, 4, v0                                // 000000D8A4F4: 320E0084
	v_lshlrev_b32_e32 v1, 3, v0                                // 000000D8A4F8: 30020083
	s_add_i32 s0, s19, -1                                      // 000000D8A4FC: 8100C113
	s_mov_b32 s1, exec_lo                                      // 000000D8A500: BE81007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8A504: BF870112
	v_min_i32_e32 v2, s0, v7                                   // 000000D8A508: 22040E00
	v_and_b32_e32 v20, 0x78, v1                                // 000000D8A50C: 362802FF 00000078
	v_mul_u32_u24_e32 v22, 0x88, v7                            // 000000D8A514: 162C0EFF 00000088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A51C: BF870193
	v_add_nc_u32_e32 v1, s18, v2                               // 000000D8A520: 4A020412
	v_lshlrev_b32_e32 v4, 1, v20                               // 000000D8A524: 30082881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8A528: BF870112
	v_mad_i64_i32 v[2:3], null, 0x500, v1, 0                   // 000000D8A52C: D6FF7C02 020202FF 00000500
	.long 0xd7000001                                           // 000000D8A538: D7000001
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 000000D8A53C: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000D8A540: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, 0, s0                   // 000000D8A544: D5207C06 0001000B
	.long 0xd4490000                                           // 000000D8A54C: D4490000
	v_cndmask_b32_e32 v1, 0xff, v0, vcc_lo                     // 000000D8A550: 020200FF 000000FF
	.long 0xd7006a05                                           // 000000D8A558: D7006A05
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000D8A55C: 02020501
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A560: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v3, vcc_lo               // 000000D8A564: D5207C06 01AA0706
	v_mov_b32_e32 v1, 0                                        // 000000D8A56C: 7E020280
	global_load_b128 v[9:12], v[5:6], off                      // 000000D8A570: DC5E0000 097C0005
	v_cmpx_gt_u32_e32 0x100, v0                                // 000000D8A578: 7D9800FF 00000100
	s_cbranch_execz 5                                          // 000000D8A580: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9098>
	v_lshl_add_u32 v4, v22, 1, v4                              // 000000D8A584: D6460004 04110316
	s_waitcnt vmcnt(0)                                         // 000000D8A58C: BF8903F7
	ds_store_b128 v4, v[9:12]                                  // 000000D8A590: DB7C0000 00000904
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D8A598: 8C7E017E
	v_and_b32_e32 v21, 15, v0                                  // 000000D8A59C: 362A008F
	s_mul_i32 s3, s16, 0xc8000                                 // 000000D8A5A0: 9603FF10 000C8000
	s_mul_i32 s4, s17, 0xa000                                  // 000000D8A5A8: 9604FF11 0000A000
	s_mul_hi_i32 s2, s16, 0xc8000                              // 000000D8A5B0: 9702FF10 000C8000
	s_add_u32 s3, s3, s4                                       // 000000D8A5B8: 80030403
	v_lshlrev_b32_e32 v13, 4, v21                              // 000000D8A5BC: 301A2A84
	s_mul_hi_i32 s4, s17, 0xa000                               // 000000D8A5C0: 9704FF11 0000A000
	s_movk_i32 s5, 0x1eee                                      // 000000D8A5C8: B0051EEE
	s_addc_u32 s2, s2, s4                                      // 000000D8A5CC: 82020402
	v_and_b32_e32 v19, 31, v0                                  // 000000D8A5D0: 3626009F
	.long 0xd7006a02                                           // 000000D8A5D4: D7006A02
	v_cndmask_b32_e32 v1, v2, v13, vcc_lo                      // 000000D8A5D8: 02021B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A5DC: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000D8A5E0: D5207C03 01AA0680
	v_lshlrev_b32_e32 v4, 5, v19                               // 000000D8A5E8: 30082685
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A5EC: BF870093
	.long 0xd7006a02                                           // 000000D8A5F0: D7006A02
	v_cndmask_b32_e32 v1, s10, v2, vcc_lo                      // 000000D8A5F4: 0202040A
	v_add_co_ci_u32_e64 v3, null, s11, v3, vcc_lo              // 000000D8A5F8: D5207C03 01AA060B
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000D8A600: 300C0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8A604: BF870093
	.long 0xd7006a0d                                           // 000000D8A608: D7006A0D
	v_cndmask_b32_e32 v1, 0x100, v2, vcc_lo                    // 000000D8A60C: 020204FF 00000100
	v_add_co_ci_u32_e64 v14, null, 0, v3, vcc_lo               // 000000D8A614: D5207C0E 01AA0680
	v_mov_b32_e32 v3, s2                                       // 000000D8A61C: 7E060202
	v_add_nc_u32_e32 v5, 0x3f0, v4                             // 000000D8A620: 4A0A08FF 000003F0
	s_mov_b32 s4, 0                                            // 000000D8A628: BE840080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000D8A62C: BF890007
	s_barrier                                                  // 000000D8A630: BFBD0000
	buffer_gl0_inv                                             // 000000D8A634: E0AC0000 00000000
	v_and_b32_e32 v8, 0x7e0, v5                                // 000000D8A63C: 36100AFF 000007E0
	v_lshrrev_b32_e32 v7, 5, v5                                // 000000D8A644: 320E0A85
	v_lshrrev_b32_e32 v5, 3, v5                                // 000000D8A648: 320A0A83
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8A64C: BF870193
	v_sub_nc_u32_e32 v4, v8, v4                                // 000000D8A650: 4C080908
	v_dual_mov_b32 v8, v1 :: v_dual_add_nc_u32 v7, 1, v7       // 000000D8A654: CA200101 08060E81
	s_delay_alu instid0(VALU_DEP_2)                            // 000000D8A65C: BF870002
	v_add_nc_u32_e32 v24, 0xfffffc3c, v4                       // 000000D8A660: 4A3008FF FFFFFC3C
	v_add_nc_u32_e32 v25, 0xfffffc38, v4                       // 000000D8A668: 4A3208FF FFFFFC38
	v_add_nc_u32_e32 v26, 0xfffffc34, v4                       // 000000D8A670: 4A3408FF FFFFFC34
	v_add_nc_u32_e32 v27, 0xfffffc30, v4                       // 000000D8A678: 4A3608FF FFFFFC30
	v_and_or_b32 v4, 0x380, v6, s3                             // 000000D8A680: D6570004 000E0CFF 00000380
	v_dual_mov_b32 v6, s2 :: v_dual_and_b32 v7, 31, v7         // 000000D8A68C: CA240002 06060E9F
	.long 0xd44c0001                                           // 000000D8A694: D44C0001
	v_cndmask_b32_e32 v1, 16, v19, vcc_lo                      // 000000D8A698: 02022690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8A69C: BF870223
	v_and_or_b32 v5, 0x7c, v5, v4                              // 000000D8A6A0: D6570005 04120AFF 0000007C
	v_lshl_or_b32 v2, v19, 2, v4                               // 000000D8A6AC: D6560002 04110513
	v_lshl_or_b32 v4, v7, 2, v4                                // 000000D8A6B4: D6560004 04110507
	v_mov_b32_e32 v7, v1                                       // 000000D8A6BC: 7E0E0301
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000D8A6C0: BF8700C4
	.long 0xd7006a1c                                           // 000000D8A6C4: D7006A1C
	v_cndmask_b32_e32 v1, s8, v5, vcc_lo                       // 000000D8A6C8: 02020A08
	v_mov_b32_e32 v5, s2                                       // 000000D8A6CC: 7E0A0202
	v_add_co_ci_u32_e64 v29, null, s9, v6, vcc_lo              // 000000D8A6D0: D5207C1D 01AA0C09
	.long 0xd7006a1e                                           // 000000D8A6D8: D7006A1E
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000D8A6DC: 02020408
	v_add_co_ci_u32_e64 v31, null, s9, v3, vcc_lo              // 000000D8A6E0: D5207C1F 01AA0609
	.long 0xd7006a20                                           // 000000D8A6E8: D7006A20
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000D8A6EC: 02020808
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A6F0: BF870001
	v_add_co_ci_u32_e64 v33, null, s9, v5, vcc_lo              // 000000D8A6F4: D5207C21 01AA0A09
	v_mov_b32_e32 v2, v1                                       // 000000D8A6FC: 7E040301
	v_mul_u32_u24_e32 v23, 0x110, v21                          // 000000D8A700: 162E2AFF 00000110
	v_mov_b32_e32 v3, v1                                       // 000000D8A708: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000D8A70C: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000D8A710: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000D8A714: 7E0C0301
	s_mov_b64 s[2:3], 0                                        // 000000D8A718: BE820180
	s_mov_b32 s8, 0x76543210                                   // 000000D8A71C: BE8800FF 76543210
	s_branch 17                                                // 000000D8A724: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x926c>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000D8A728: 8C7E097E
	.long 0xd7006a0d                                           // 000000D8A72C: D7006A0D
	v_cndmask_b32_e32 v1, 0x100, v13, vcc_lo                   // 000000D8A730: 02021AFF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A738: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, vcc_lo              // 000000D8A73C: D5207C0E 01AA1C80
	s_add_u32 s2, s2, 0x2000                                   // 000000D8A744: 8002FF02 00002000
	s_addc_u32 s3, s3, 0                                       // 000000D8A74C: 82038003
	s_add_i32 s4, s4, 1                                        // 000000D8A750: 81048104
	s_cmpk_eq_u32 s2, 0xa000                                   // 000000D8A754: B482A000
	s_waitcnt lgkmcnt(0)                                       // 000000D8A758: BF89FC07
	s_barrier                                                  // 000000D8A75C: BFBD0000
	buffer_gl0_inv                                             // 000000D8A760: E0AC0000 00000000
	s_cbranch_scc1 1261                                        // 000000D8A768: BFA204ED <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xa620>
	s_cmpk_eq_u32 s2, 0x8000                                   // 000000D8A76C: B4828000
	s_cselect_b32 s9, -1, 0                                    // 000000D8A770: 980980C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000D8A774: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 000000D8A778: 8B6A097E
	s_cbranch_vccnz 2                                          // 000000D8A77C: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9288>
	global_load_b128 v[9:12], v[13:14], off                    // 000000D8A780: DC5E0000 097C000D
	.long 0xd7006a25                                           // 000000D8A788: D7006A25
	v_cndmask_b32_e32 v0, v28, v2, vcc_lo                      // 000000D8A78C: 0200051C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8A790: BF8700A1
	v_add_co_ci_u32_e64 v38, null, s3, v29, vcc_lo             // 000000D8A794: D5207C26 01AA3A03
	.long 0xd7006a27                                           // 000000D8A79C: D7006A27
	v_cndmask_b32_e32 v0, v32, v2, vcc_lo                      // 000000D8A7A0: 02000520
	v_add_co_ci_u32_e64 v40, null, s3, v33, vcc_lo             // 000000D8A7A4: D5207C28 01AA4203
	.long 0xd7006a29                                           // 000000D8A7AC: D7006A29
	v_cndmask_b32_e32 v0, v30, v2, vcc_lo                      // 000000D8A7B0: 0200051E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A7B4: BF870001
	v_add_co_ci_u32_e64 v42, null, s3, v31, vcc_lo             // 000000D8A7B8: D5207C2A 01AA3E03
	s_clause 0xb                                               // 000000D8A7C0: BF85000B
	global_load_b32 v16, v[37:38], off                         // 000000D8A7C4: DC520000 107C0025
	global_load_b32 v15, v[39:40], off                         // 000000D8A7CC: DC520000 0F7C0027
	global_load_b32 v34, v[41:42], off                         // 000000D8A7D4: DC520000 227C0029
	global_load_b32 v18, v[37:38], off offset:1024             // 000000D8A7DC: DC520400 127C0025
	global_load_b32 v17, v[39:40], off offset:1024             // 000000D8A7E4: DC520400 117C0027
	global_load_b32 v36, v[41:42], off offset:1024             // 000000D8A7EC: DC520400 247C0029
	global_load_b32 v78, v[37:38], off offset:2048             // 000000D8A7F4: DC520800 4E7C0025
	global_load_b32 v77, v[39:40], off offset:2048             // 000000D8A7FC: DC520800 4D7C0027
	global_load_b32 v94, v[41:42], off offset:2048             // 000000D8A804: DC520800 5E7C0029
	global_load_b32 v79, v[39:40], off offset:3072             // 000000D8A80C: DC520C00 4F7C0027
	global_load_b32 v80, v[37:38], off offset:3072             // 000000D8A814: DC520C00 507C0025
	global_load_b32 v97, v[41:42], off offset:3072             // 000000D8A81C: DC520C00 617C0029
	.long 0xd7006a25                                           // 000000D8A824: D7006A25
	v_cndmask_b32_e32 v1, 0x1000, v37, vcc_lo                  // 000000D8A828: 02024AFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000D8A830: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v38, vcc_lo              // 000000D8A834: D5207C26 01AA4C80
	.long 0xd7006a27                                           // 000000D8A83C: D7006A27
	v_cndmask_b32_e32 v1, 0x1000, v39, vcc_lo                  // 000000D8A840: 02024EFF 00001000
	v_add_co_ci_u32_e64 v40, null, 0, v40, vcc_lo              // 000000D8A848: D5207C28 01AA5080
	.long 0xd7006a29                                           // 000000D8A850: D7006A29
	v_cndmask_b32_e32 v1, 0x1000, v41, vcc_lo                  // 000000D8A854: 020252FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8A85C: BF870001
	v_add_co_ci_u32_e64 v42, null, 0, v42, vcc_lo              // 000000D8A860: D5207C2A 01AA5480
	s_clause 0xb                                               // 000000D8A868: BF85000B
	global_load_b32 v82, v[37:38], off                         // 000000D8A86C: DC520000 527C0025
	global_load_b32 v81, v[39:40], off                         // 000000D8A874: DC520000 517C0027
	global_load_b32 v99, v[41:42], off                         // 000000D8A87C: DC520000 637C0029
	global_load_b32 v84, v[37:38], off offset:1024             // 000000D8A884: DC520400 547C0025
	global_load_b32 v83, v[39:40], off offset:1024             // 000000D8A88C: DC520400 537C0027
	global_load_b32 v101, v[41:42], off offset:1024            // 000000D8A894: DC520400 657C0029
	global_load_b32 v118, v[37:38], off offset:2048            // 000000D8A89C: DC520800 767C0025
	global_load_b32 v117, v[39:40], off offset:2048            // 000000D8A8A4: DC520800 757C0027
	global_load_b32 v120, v[37:38], off offset:3072            // 000000D8A8AC: DC520C00 787C0025
	global_load_b32 v123, v[41:42], off offset:2048            // 000000D8A8B4: DC520800 7B7C0029
	global_load_b32 v124, v[41:42], off offset:3072            // 000000D8A8BC: DC520C00 7C7C0029
	global_load_b32 v119, v[39:40], off offset:3072            // 000000D8A8C4: DC520C00 777C0027
	s_and_b32 s10, s4, 1                                       // 000000D8A8CC: 8B0A8104
	s_bfe_i32 s11, s4, 0x10000                                 // 000000D8A8D0: 938BFF04 00010000
	s_cmp_eq_u32 s10, 0                                        // 000000D8A8D8: BF06800A
	s_cselect_b32 s10, -1, 0                                   // 000000D8A8DC: 980A80C1
	s_and_b32 s11, s11, 0x4400                                 // 000000D8A8E0: 8B0BFF0B 00004400
	s_waitcnt vmcnt(22)                                        // 000000D8A8E8: BF895BF7
	.long 0xd73d0055                                           // 000000D8A8EC: D73D0055
	v_cndmask_b32_e32 v1, v24, v15, vcc_lo                     // 000000D8A8F0: 02021F18
	.long 0xd73d0056                                           // 000000D8A8F4: D73D0056
	v_cndmask_b32_e32 v1, v25, v15, vcc_lo                     // 000000D8A8F8: 02021F19
	.long 0xd73d0057                                           // 000000D8A8FC: D73D0057
	v_cndmask_b32_e32 v1, v26, v15, vcc_lo                     // 000000D8A900: 02021F1A
	s_waitcnt vmcnt(19)                                        // 000000D8A904: BF894FF7
	.long 0xd73d0058                                           // 000000D8A908: D73D0058
	v_cndmask_b32_e32 v1, v24, v17, vcc_lo                     // 000000D8A90C: 02022318
	.long 0xd73d0059                                           // 000000D8A910: D73D0059
	v_cndmask_b32_e32 v1, v25, v17, vcc_lo                     // 000000D8A914: 02022319
	.long 0xd73d005a                                           // 000000D8A918: D73D005A
	v_cndmask_b32_e32 v1, v26, v17, vcc_lo                     // 000000D8A91C: 0202231A
	.long 0xd73d000f                                           // 000000D8A920: D73D000F
	v_cndmask_b32_e32 v1, v27, v15, vcc_lo                     // 000000D8A924: 02021F1B
	.long 0xd73d0010                                           // 000000D8A928: D73D0010
	v_cndmask_b32_e32 v1, v27, v17, vcc_lo                     // 000000D8A92C: 0202231B
	s_waitcnt vmcnt(18)                                        // 000000D8A930: BF894BF7
	v_bfe_u32 v103, v36, 12, 16                                // 000000D8A934: D6100067 02411924
	v_bfe_u32 v104, v36, 8, 16                                 // 000000D8A93C: D6100068 02411124
	v_bfe_u32 v105, v36, 4, 16                                 // 000000D8A944: D6100069 02410924
	v_and_b32_e32 v90, 0xffff, v90                             // 000000D8A94C: 36B4B4FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v36                             // 000000D8A954: 364848FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D8A95C: 362020FF 0000FFFF
	s_waitcnt vmcnt(16)                                        // 000000D8A964: BF8943F7
	.long 0xd73d005b                                           // 000000D8A968: D73D005B
	v_cndmask_b32_e32 v1, v25, v77, vcc_lo                     // 000000D8A96C: 02029B19
	.long 0xd73d0011                                           // 000000D8A970: D73D0011
	v_cndmask_b32_e32 v1, v24, v77, vcc_lo                     // 000000D8A974: 02029B18
	.long 0xd72c005a                                           // 000000D8A978: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000D8A97C: 0202B4FF 83DCD12D
	.long 0xd73d005c                                           // 000000D8A984: D73D005C
	v_cndmask_b32_e32 v1, v26, v77, vcc_lo                     // 000000D8A988: 02029B1A
	.long 0xd72c0010                                           // 000000D8A98C: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000D8A990: 020220FF 83DCD12D
	s_waitcnt vmcnt(15)                                        // 000000D8A998: BF893FF7
	v_bfe_u32 v18, v94, 12, 16                                 // 000000D8A99C: D6100012 0241195E
	v_bfe_u32 v106, v94, 8, 16                                 // 000000D8A9A4: D610006A 0241115E
	v_bfe_u32 v107, v94, 4, 16                                 // 000000D8A9AC: D610006B 0241095E
	v_and_b32_e32 v108, 0xffff, v94                            // 000000D8A9B4: 36D8BCFF 0000FFFF
	s_waitcnt vmcnt(13)                                        // 000000D8A9BC: BF8937F7
	.long 0xd73d005d                                           // 000000D8A9C0: D73D005D
	v_cndmask_b32_e32 v1, v24, v79, vcc_lo                     // 000000D8A9C4: 02029F18
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000D8A9C8: D622005A 03FD015A 00006400
	.long 0xd72c0024                                           // 000000D8A9D4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000D8A9D8: 020248FF 83DCD12D
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000D8A9E0: D6220010 03FD0110 00006400
	.long 0xd73d005e                                           // 000000D8A9EC: D73D005E
	v_cndmask_b32_e32 v1, v25, v79, vcc_lo                     // 000000D8A9F0: 02029F19
	.long 0xd72c0069                                           // 000000D8A9F4: D72C0069
	v_cndmask_b32_e32 v1, 0x83dcd12d, v105, vcc_lo             // 000000D8A9F8: 0202D2FF 83DCD12D
	v_and_b32_e32 v90, 0xffff, v90                             // 000000D8AA00: 36B4B4FF 0000FFFF
	v_and_b32_e32 v87, 0xffff, v87                             // 000000D8AA08: 36AEAEFF 0000FFFF
	v_and_b32_e32 v93, 0xffff, v93                             // 000000D8AA10: 36BABAFF 0000FFFF
	v_bfe_u32 v98, v34, 12, 16                                 // 000000D8AA18: D6100062 02411922
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000D8AA20: D6220024 03FD0124 00006400
	v_lshl_or_b32 v16, v16, 16, v90                            // 000000D8AA2C: D6560010 05692110
	v_and_b32_e32 v94, 0xffff, v94                             // 000000D8AA34: 36BCBCFF 0000FFFF
	.long 0xd72c0057                                           // 000000D8AA3C: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000D8AA40: 0202AEFF 83DCD12D
	.long 0xd72c005d                                           // 000000D8AA48: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 000000D8AA4C: 0202BAFF 83DCD12D
	v_sad_u8 v105, v105, 0, 0x6400                             // 000000D8AA54: D6220069 03FD0169 00006400
	v_pk_fma_f16 v16, v16, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8AA60: CC0E0010 0BFC0B10 0000C931
	v_and_b32_e32 v15, 0xffff, v15                             // 000000D8AA6C: 361E1EFF 0000FFFF
	v_lshlrev_b32_e32 v36, 16, v36                             // 000000D8AA74: 30484890
	.long 0xd72c005e                                           // 000000D8AA78: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 000000D8AA7C: 0202BCFF 83DCD12D
	v_bfe_u32 v100, v34, 8, 16                                 // 000000D8AA84: D6100064 02411122
	v_mov_b32_e32 v130, v16                                    // 000000D8AA8C: 7F040310
	.long 0xd72c000f                                           // 000000D8AA90: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000D8AA94: 02021EFF 83DCD12D
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000D8AA9C: D6220057 03FD0157 00006400
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000D8AAA8: D622005D 03FD015D 00006400
	v_and_or_b32 v36, 0xffff, v105, v36                        // 000000D8AAB4: D6570024 0492D2FF 0000FFFF
	v_bfe_u32 v102, v34, 4, 16                                 // 000000D8AAC0: D6100066 02410922
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000D8AAC8: D622005E 03FD015E 00006400
	v_and_b32_e32 v87, 0xffff, v87                             // 000000D8AAD4: 36AEAEFF 0000FFFF
	v_and_b32_e32 v93, 0xffff, v93                             // 000000D8AADC: 36BABAFF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000D8AAE4: D622000F 03FD010F 00006400
	v_pk_fma_f16 v36, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8AAF0: CC0E0024 0BFC0B24 0000C931
	v_and_b32_e32 v34, 0xffff, v34                             // 000000D8AAFC: 364444FF 0000FFFF
	.long 0xd73d004d                                           // 000000D8AB04: D73D004D
	v_cndmask_b32_e32 v1, v27, v77, vcc_lo                     // 000000D8AB08: 02029B1B
	.long 0xd72c0067                                           // 000000D8AB0C: D72C0067
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 000000D8AB10: 0202CEFF 83DCD12D
	v_lshl_or_b32 v15, v15, 16, v87                            // 000000D8AB18: D656000F 055D210F
	v_lshl_or_b32 v87, v94, 16, v93                            // 000000D8AB20: D6560057 0575215E
	v_mov_b32_e32 v93, v36                                     // 000000D8AB28: 7EBA0324
	.long 0xd72c0022                                           // 000000D8AB2C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000D8AB30: 020244FF 83DCD12D
	.long 0xd73d005f                                           // 000000D8AB38: D73D005F
	v_cndmask_b32_e32 v1, v26, v79, vcc_lo                     // 000000D8AB3C: 02029F1A
	.long 0xd73d004e                                           // 000000D8AB40: D73D004E
	v_cndmask_b32_e32 v1, v27, v79, vcc_lo                     // 000000D8AB44: 02029F1B
	s_waitcnt vmcnt(12)                                        // 000000D8AB48: BF8933F7
	v_bfe_u32 v79, v97, 12, 16                                 // 000000D8AB4C: D610004F 02411961
	.long 0xd72c0066                                           // 000000D8AB54: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 000000D8AB58: 0202CCFF 83DCD12D
	.long 0xd72c0068                                           // 000000D8AB60: D72C0068
	v_cndmask_b32_e32 v1, 0x83dcd12d, v104, vcc_lo             // 000000D8AB64: 0202D0FF 83DCD12D
	v_and_b32_e32 v92, 0xffff, v92                             // 000000D8AB6C: 36B8B8FF 0000FFFF
	v_bfe_u32 v80, v97, 8, 16                                  // 000000D8AB74: D6100050 02411161
	.long 0xd72c006f                                           // 000000D8AB7C: D72C006F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000D8AB80: 02029EFF 83DCD12D
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000D8AB88: D6220022 03FD0122 00006400
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000D8AB94: D6220067 03FD0167 00006400
	.long 0xd72c0012                                           // 000000D8ABA0: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000D8ABA4: 020224FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000D8ABAC: 369A9AFF 0000FFFF
	.long 0xd72c005c                                           // 000000D8ABB4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 000000D8ABB8: 0202B8FF 83DCD12D
	.long 0xd72c0070                                           // 000000D8ABC0: D72C0070
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000D8ABC4: 0202A0FF 83DCD12D
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000D8ABCC: D6220066 03FD0166 00006400
	v_sad_u8 v104, v104, 0, 0x6400                             // 000000D8ABD8: D6220068 03FD0168 00006400
	v_lshlrev_b32_e32 v34, 16, v34                             // 000000D8ABE4: 30444490
	v_and_b32_e32 v103, 0xffff, v103                           // 000000D8ABE8: 36CECEFF 0000FFFF
	.long 0xd72c006a                                           // 000000D8ABF0: D72C006A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v106, vcc_lo             // 000000D8ABF4: 0202D4FF 83DCD12D
	.long 0xd72c004d                                           // 000000D8ABFC: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000D8AC00: 02029AFF 83DCD12D
	v_sad_u8 v111, v111, 0, 0x6400                             // 000000D8AC08: D622006F 03FD016F 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000D8AC14: D6220012 03FD0112 00006400
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000D8AC20: D622005C 03FD015C 00006400
	v_and_or_b32 v34, 0xffff, v102, v34                        // 000000D8AC2C: D6570022 048ACCFF 0000FFFF
	v_lshl_or_b32 v102, v104, 16, v103                         // 000000D8AC38: D6560066 059D2168
	v_sad_u8 v112, v112, 0, 0x6400                             // 000000D8AC40: D6220070 03FD0170 00006400
	v_and_b32_e32 v111, 0xffff, v111                           // 000000D8AC4C: 36DEDEFF 0000FFFF
	v_sad_u8 v106, v106, 0, 0x6400                             // 000000D8AC54: D622006A 03FD016A 00006400
	v_and_b32_e32 v18, 0xffff, v18                             // 000000D8AC60: 362424FF 0000FFFF
	v_bfe_u32 v96, v97, 4, 16                                  // 000000D8AC68: D6100060 02410961
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000D8AC70: D622004D 03FD014D 00006400
	v_and_b32_e32 v92, 0xffff, v92                             // 000000D8AC7C: 36B8B8FF 0000FFFF
	v_pk_fma_f16 v102, v102, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8AC84: CC0E0066 0BFC0B66 0000C931
	v_and_b32_e32 v97, 0xffff, v97                             // 000000D8AC90: 36C2C2FF 0000FFFF
	v_lshl_or_b32 v104, v112, 16, v111                         // 000000D8AC98: D6560068 05BD2170
	v_lshl_or_b32 v18, v106, 16, v18                           // 000000D8ACA0: D6560012 0449216A
	.long 0xd72c0071                                           // 000000D8ACA8: D72C0071
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000D8ACAC: 0202C0FF 83DCD12D
	s_waitcnt vmcnt(10)                                        // 000000D8ACB4: BF892BF7
	.long 0xd73d004f                                           // 000000D8ACB8: D73D004F
	v_cndmask_b32_e32 v1, v24, v81, vcc_lo                     // 000000D8ACBC: 0202A318
	v_lshl_or_b32 v77, v77, 16, v92                            // 000000D8ACC0: D656004D 0571214D
	v_mov_b32_e32 v92, v102                                    // 000000D8ACC8: 7EB80366
	.long 0xd72c0072                                           // 000000D8ACCC: D72C0072
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000D8ACD0: 0202C2FF 83DCD12D
	.long 0xd73d0060                                           // 000000D8ACD8: D73D0060
	v_cndmask_b32_e32 v1, v25, v81, vcc_lo                     // 000000D8ACDC: 0202A319
	.long 0xd72c006d                                           // 000000D8ACE0: D72C006D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000D8ACE4: 0202C4FF 83DCD12D
	.long 0xd73d0061                                           // 000000D8ACEC: D73D0061
	v_cndmask_b32_e32 v1, v26, v81, vcc_lo                     // 000000D8ACF0: 0202A31A
	.long 0xd73d0050                                           // 000000D8ACF4: D73D0050
	v_cndmask_b32_e32 v1, v27, v81, vcc_lo                     // 000000D8ACF8: 0202A31B
	s_waitcnt vmcnt(9)                                         // 000000D8ACFC: BF8927F7
	v_bfe_u32 v115, v99, 12, 16                                // 000000D8AD00: D6100073 02411963
	v_bfe_u32 v116, v99, 8, 16                                 // 000000D8AD08: D6100074 02411163
	v_bfe_u32 v125, v99, 4, 16                                 // 000000D8AD10: D610007D 02410963
	s_waitcnt vmcnt(7)                                         // 000000D8AD18: BF891FF7
	.long 0xd73d0051                                           // 000000D8AD1C: D73D0051
	v_cndmask_b32_e32 v1, v24, v83, vcc_lo                     // 000000D8AD20: 0202A718
	v_pk_fma_f16 v104, v104, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8AD24: CC0E0068 0BFC0B68 0000C931
	v_and_b32_e32 v126, 0xffff, v99                            // 000000D8AD30: 36FCC6FF 0000FFFF
	.long 0xd73d0062                                           // 000000D8AD38: D73D0062
	v_cndmask_b32_e32 v1, v25, v83, vcc_lo                     // 000000D8AD3C: 0202A719
	.long 0xd72c006e                                           // 000000D8AD40: D72C006E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000D8AD44: 0202C8FF 83DCD12D
	.long 0xd73d0063                                           // 000000D8AD4C: D73D0063
	v_cndmask_b32_e32 v1, v26, v83, vcc_lo                     // 000000D8AD50: 0202A71A
	.long 0xd73d0052                                           // 000000D8AD54: D73D0052
	v_cndmask_b32_e32 v1, v27, v83, vcc_lo                     // 000000D8AD58: 0202A71B
	s_waitcnt vmcnt(6)                                         // 000000D8AD5C: BF891BF7
	v_bfe_u32 v83, v101, 12, 16                                // 000000D8AD60: D6100053 02411965
	v_bfe_u32 v84, v101, 8, 16                                 // 000000D8AD68: D6100054 02411165
	v_bfe_u32 v100, v101, 4, 16                                // 000000D8AD70: D6100064 02410965
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8AD78: CC0E0012 0BFC0B12 0000C931
	v_and_b32_e32 v101, 0xffff, v101                           // 000000D8AD84: 36CACAFF 0000FFFF
	.long 0xd72c0053                                           // 000000D8AD8C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000D8AD90: 0202A6FF 83DCD12D
	.long 0xd72c0054                                           // 000000D8AD98: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000D8AD9C: 0202A8FF 83DCD12D
	.long 0xd72c0064                                           // 000000D8ADA4: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 000000D8ADA8: 0202C8FF 83DCD12D
	v_mov_b32_e32 v94, v18                                     // 000000D8ADB0: 7EBC0312
	.long 0xd72c0065                                           // 000000D8ADB4: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 000000D8ADB8: 0202CAFF 83DCD12D
	.long 0xd72c006c                                           // 000000D8ADC0: D72C006C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v108, vcc_lo             // 000000D8ADC4: 0202D8FF 83DCD12D
	s_waitcnt vmcnt(4)                                         // 000000D8ADCC: BF8913F7
	.long 0xd73d0079                                           // 000000D8ADD0: D73D0079
	v_cndmask_b32_e32 v1, v24, v117, vcc_lo                    // 000000D8ADD4: 0202EB18
	v_sad_u8 v114, v114, 0, 0x6400                             // 000000D8ADD8: D6220072 03FD0172 00006400
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000D8ADE4: D6220053 03FD0153 00006400
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000D8ADF0: D6220054 03FD0154 00006400
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000D8ADFC: D6220064 03FD0164 00006400
	.long 0xd72c006b                                           // 000000D8AE08: D72C006B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v107, vcc_lo             // 000000D8AE0C: 0202D6FF 83DCD12D
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000D8AE14: D6220065 03FD0165 00006400
	v_and_b32_e32 v83, 0xffff, v83                             // 000000D8AE20: 36A6A6FF 0000FFFF
	.long 0xd72c0073                                           // 000000D8AE28: D72C0073
	v_cndmask_b32_e32 v1, 0x83dcd12d, v115, vcc_lo             // 000000D8AE2C: 0202E6FF 83DCD12D
	.long 0xd72c007a                                           // 000000D8AE34: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000D8AE38: 0202FAFF 83DCD12D
	v_sad_u8 v108, v108, 0, 0x6400                             // 000000D8AE40: D622006C 03FD016C 00006400
	v_lshlrev_b32_e32 v101, 16, v101                           // 000000D8AE4C: 30CACA90
	v_lshl_or_b32 v83, v84, 16, v83                            // 000000D8AE50: D6560053 054D2154
	v_and_b32_e32 v95, 0xffff, v95                             // 000000D8AE58: 36BEBEFF 0000FFFF
	v_sad_u8 v113, v113, 0, 0x6400                             // 000000D8AE60: D6220071 03FD0171 00006400
	v_lshlrev_b32_e32 v114, 16, v114                           // 000000D8AE6C: 30E4E490
	v_and_or_b32 v84, 0xffff, v100, v101                       // 000000D8AE70: D6570054 0596C8FF 0000FFFF
	v_mov_b32_e32 v101, v104                                   // 000000D8AE7C: 7ECA0368
	.long 0xd72c007d                                           // 000000D8AE80: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000D8AE84: 0202FCFF 83DCD12D
	.long 0xd72c0074                                           // 000000D8AE8C: D72C0074
	v_cndmask_b32_e32 v1, 0x83dcd12d, v116, vcc_lo             // 000000D8AE90: 0202E8FF 83DCD12D
	v_and_b32_e32 v79, 0xffff, v79                             // 000000D8AE98: 369E9EFF 0000FFFF
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D8AEA0: 36A2A2FF 0000FFFF
	v_sad_u8 v107, v107, 0, 0x6400                             // 000000D8AEA8: D622006B 03FD016B 00006400
	v_lshlrev_b32_e32 v108, 16, v108                           // 000000D8AEB4: 30D8D890
	v_sad_u8 v115, v115, 0, 0x6400                             // 000000D8AEB8: D6220073 03FD0173 00006400
	.long 0xd72c005f                                           // 000000D8AEC4: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 000000D8AEC8: 0202BEFF 83DCD12D
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000D8AED0: D622007D 03FD017D 00006400
	v_and_or_b32 v105, 0xffff, v113, v114                      // 000000D8AEDC: D6570069 05CAE2FF 0000FFFF
	v_pk_fma_f16 v114, v87, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8AEE8: CC0E0072 0BFC0B57 0000C931
	v_and_b32_e32 v78, 0xffff, v78                             // 000000D8AEF4: 369C9CFF 0000FFFF
	v_and_b32_e32 v96, 0xffff, v96                             // 000000D8AEFC: 36C0C0FF 0000FFFF
	v_and_b32_e32 v98, 0xffff, v98                             // 000000D8AF04: 36C4C4FF 0000FFFF
	.long 0xd72c004f                                           // 000000D8AF0C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000D8AF10: 02029EFF 83DCD12D
	.long 0xd72c0051                                           // 000000D8AF18: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000D8AF1C: 0202A2FF 83DCD12D
	v_sad_u8 v109, v109, 0, 0x6400                             // 000000D8AF24: D622006D 03FD016D 00006400
	v_sad_u8 v116, v116, 0, 0x6400                             // 000000D8AF30: D6220074 03FD0174 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000D8AF3C: D622007A 03FD017A 00006400
	v_and_or_b32 v103, 0xffff, v107, v108                      // 000000D8AF48: D6570067 05B2D6FF 0000FFFF
	v_and_b32_e32 v106, 0xffff, v115                           // 000000D8AF54: 36D4E6FF 0000FFFF
	v_lshlrev_b32_e32 v107, 16, v125                           // 000000D8AF5C: 30D6FA90
	v_mov_b32_e32 v133, v114                                   // 000000D8AF60: 7F0A0372
	.long 0xd72c004e                                           // 000000D8AF64: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000D8AF68: 02029CFF 83DCD12D
	.long 0xd72c0060                                           // 000000D8AF70: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 000000D8AF74: 0202C0FF 83DCD12D
	.long 0xd72c0062                                           // 000000D8AF7C: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 000000D8AF80: 0202C4FF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000D8AF88: D622005F 03FD015F 00006400
	v_sad_u8 v110, v110, 0, 0x6400                             // 000000D8AF94: D622006E 03FD016E 00006400
	v_and_b32_e32 v109, 0xffff, v109                           // 000000D8AFA0: 36DADAFF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000D8AFA8: D622004F 03FD014F 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000D8AFB4: D6220051 03FD0151 00006400
	v_lshl_or_b32 v106, v116, 16, v106                         // 000000D8AFC0: D656006A 05A92174
	v_and_or_b32 v107, 0xffff, v122, v107                      // 000000D8AFC8: D657006B 05AEF4FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000D8AFD4: D622004E 03FD014E 00006400
	v_and_b32_e32 v95, 0xffff, v95                             // 000000D8AFE0: 36BEBEFF 0000FFFF
	v_lshl_or_b32 v109, v110, 16, v109                         // 000000D8AFE8: D656006D 05B5216E
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000D8AFF0: D6220060 03FD0160 00006400
	v_sad_u8 v98, v98, 0, 0x6400                               // 000000D8AFFC: D6220062 03FD0162 00006400
	v_and_b32_e32 v79, 0xffff, v79                             // 000000D8B008: 369E9EFF 0000FFFF
	v_and_b32_e32 v81, 0xffff, v81                             // 000000D8B010: 36A2A2FF 0000FFFF
	v_pk_fma_f16 v106, v106, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8B018: CC0E006A 0BFC0B6A 0000C931
	v_and_b32_e32 v88, 0xffff, v88                             // 000000D8B024: 36B0B0FF 0000FFFF
	v_pk_fma_f16 v110, v107, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8B02C: CC0E006E 0BFC0B6B 0000C931
	v_and_b32_e32 v85, 0xffff, v85                             // 000000D8B038: 36AAAAFF 0000FFFF
	v_lshl_or_b32 v78, v78, 16, v95                            // 000000D8B040: D656004E 057D214E
	v_pk_fma_f16 v113, v77, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B048: CC0E0071 0BFC0B4D 0000C931
	v_and_b32_e32 v17, 0xffff, v17                             // 000000D8B054: 362222FF 0000FFFF
	v_and_b32_e32 v97, 0xffff, v97                             // 000000D8B05C: 36C2C2FF 0000FFFF
	.long 0xd72c0055                                           // 000000D8B064: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000D8B068: 0202AAFF 83DCD12D
	v_pk_fma_f16 v105, v105, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8B070: CC0E0069 0BFC0B69 0000C931
	v_and_b32_e32 v86, 0xffff, v86                             // 000000D8B07C: 36ACACFF 0000FFFF
	v_pk_fma_f16 v15, v15, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B084: CC0E000F 0BFC0B0F 0000C931
	v_and_b32_e32 v89, 0xffff, v89                             // 000000D8B090: 36B2B2FF 0000FFFF
	v_lshl_or_b32 v77, v96, 16, v79                            // 000000D8B098: D656004D 053D2160
	v_lshl_or_b32 v79, v98, 16, v81                            // 000000D8B0A0: D656004F 05452162
	v_mov_b32_e32 v81, v106                                    // 000000D8B0A8: 7EA2036A
	.long 0xd72c0058                                           // 000000D8B0AC: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000D8B0B0: 0202B0FF 83DCD12D
	v_pk_fma_f16 v126, v78, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B0B8: CC0E007E 0BFC0B4E 0000C931
	v_dual_mov_b32 v132, v113 :: v_dual_and_b32 v91, 0xffff, v91// 000000D8B0C4: CA240171 845AB6FF 0000FFFF
	.long 0xd72c0011                                           // 000000D8B0D0: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 000000D8B0D4: 020222FF 83DCD12D
	v_and_b32_e32 v80, 0xffff, v80                             // 000000D8B0DC: 36A0A0FF 0000FFFF
	v_and_b32_e32 v99, 0xffff, v99                             // 000000D8B0E4: 36C6C6FF 0000FFFF
	.long 0xd72c0061                                           // 000000D8B0EC: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 000000D8B0F0: 0202C2FF 83DCD12D
	v_pk_fma_f16 v108, v109, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8B0F8: CC0E006C 0BFC0B6D 0000C931
	v_mov_b32_e32 v109, v105                                   // 000000D8B104: 7EDA0369
	.long 0xd72c0056                                           // 000000D8B108: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000D8B10C: 0202ACFF 83DCD12D
	v_mov_b32_e32 v98, v15                                     // 000000D8B114: 7EC4030F
	.long 0xd72c0059                                           // 000000D8B118: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 000000D8B11C: 0202B2FF 83DCD12D
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000D8B124: D6220055 03FD0155 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000D8B130: D6220058 03FD0158 00006400
	v_mov_b32_e32 v134, v126                                   // 000000D8B13C: 7F0C037E
	.long 0xd72c005b                                           // 000000D8B140: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000D8B144: 0202B6FF 83DCD12D
	v_and_b32_e32 v82, 0xffff, v82                             // 000000D8B14C: 36A4A4FF 0000FFFF
	.long 0xd72c0050                                           // 000000D8B154: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000D8B158: 0202A0FF 83DCD12D
	.long 0xd72c0063                                           // 000000D8B160: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 000000D8B164: 0202C6FF 83DCD12D
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000D8B16C: D6220011 03FD0111 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000D8B178: D6220056 03FD0156 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000D8B184: D6220059 03FD0159 00006400
	v_and_b32_e32 v85, 0xffff, v85                             // 000000D8B190: 36AAAAFF 0000FFFF
	v_and_b32_e32 v88, 0xffff, v88                             // 000000D8B198: 36B0B0FF 0000FFFF
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000D8B1A0: D6220061 03FD0161 00006400
	.long 0xd72c0052                                           // 000000D8B1AC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000D8B1B0: 0202A4FF 83DCD12D
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000D8B1B8: D622005B 03FD015B 00006400
	v_and_b32_e32 v17, 0xffff, v17                             // 000000D8B1C4: 362222FF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000D8B1CC: D6220050 03FD0150 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 000000D8B1D8: D6220063 03FD0163 00006400
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B1E4: CC0E0022 0BFC0B22 0000C931
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000D8B1F0: D6560055 05552156
	v_lshl_or_b32 v86, v89, 16, v88                            // 000000D8B1F8: D6560056 05612159
	v_and_b32_e32 v88, 0xffff, v97                             // 000000D8B200: 36B0C2FF 0000FFFF
	v_lshl_or_b32 v17, v91, 16, v17                            // 000000D8B208: D6560011 0445215B
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000D8B210: D6220052 03FD0152 00006400
	v_and_b32_e32 v89, 0xffff, v99                             // 000000D8B21C: 36B2C6FF 0000FFFF
	v_mov_b32_e32 v91, v34                                     // 000000D8B224: 7EB60322
	v_lshl_or_b32 v78, v80, 16, v88                            // 000000D8B228: D656004E 05612150
	v_pk_fma_f16 v85, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B230: CC0E0055 0BFC0B55 0000C931
	v_pk_fma_f16 v86, v86, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B23C: CC0E0056 0BFC0B56 0000C931
	v_pk_fma_f16 v103, v103, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000D8B248: CC0E0067 0BFC0B67 0000C931
	v_pk_fma_f16 v17, v17, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B254: CC0E0011 0BFC0B11 0000C931
	v_lshl_or_b32 v80, v82, 16, v89                            // 000000D8B260: D6560050 05652152
	v_permlanex16_b32 v91, v91, s8, 0xfedcba98                 // 000000D8B268: D65C005B 03FC115B FEDCBA98
	v_pk_fma_f16 v136, v78, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B274: CC0E0088 0BFC0B4E 0000C931
	v_dual_mov_b32 v90, v108 :: v_dual_add_nc_u32 v35, s11, v23// 000000D8B280: CA20016C 5A222E0B
	v_dual_mov_b32 v82, v110 :: v_dual_mov_b32 v89, v85        // 000000D8B288: CA10016E 52580155
	v_mov_b32_e32 v129, v86                                    // 000000D8B290: 7F020356
	v_mov_b32_e32 v97, v103                                    // 000000D8B294: 7EC20367
	v_permlanex16_b32 v94, v94, s8, 0xfedcba98                 // 000000D8B298: D65C005E 03FC115E FEDCBA98
	v_mov_b32_e32 v131, v17                                    // 000000D8B2A4: 7F060311
	v_pk_fma_f16 v135, v77, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B2A8: CC0E0087 0BFC0B4D 0000C931
	v_pk_fma_f16 v125, v84, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B2B4: CC0E007D 0BFC0B54 0000C931
	v_pk_fma_f16 v138, v80, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B2C0: CC0E008A 0BFC0B50 0000C931
	v_cndmask_b32_e64 v80, v91, v34, s1                        // 000000D8B2CC: D5010050 0006455B
	v_cndmask_b32_e64 v84, v34, v91, s1                        // 000000D8B2D4: D5010054 0006B722
	v_mov_b32_e32 v34, v136                                    // 000000D8B2DC: 7E440388
	v_permlanex16_b32 v90, v90, s8, 0xfedcba98                 // 000000D8B2E0: D65C005A 03FC115A FEDCBA98
	v_permlanex16_b32 v81, v81, s8, 0xfedcba98                 // 000000D8B2EC: D65C0051 03FC1151 FEDCBA98
	v_permlanex16_b32 v82, v82, s8, 0xfedcba98                 // 000000D8B2F8: D65C0052 03FC1152 FEDCBA98
	v_permlanex16_b32 v89, v89, s8, 0xfedcba98                 // 000000D8B304: D65C0059 03FC1159 FEDCBA98
	v_permlanex16_b32 v98, v98, s8, 0xfedcba98                 // 000000D8B310: D65C0062 03FC1162 FEDCBA98
	v_permlanex16_b32 v129, v129, s8, 0xfedcba98               // 000000D8B31C: D65C0081 03FC1181 FEDCBA98
	v_permlanex16_b32 v130, v130, s8, 0xfedcba98               // 000000D8B328: D65C0082 03FC1182 FEDCBA98
	v_permlanex16_b32 v92, v92, s8, 0xfedcba98                 // 000000D8B334: D65C005C 03FC115C FEDCBA98
	v_permlanex16_b32 v93, v93, s8, 0xfedcba98                 // 000000D8B340: D65C005D 03FC115D FEDCBA98
	v_permlanex16_b32 v97, v97, s8, 0xfedcba98                 // 000000D8B34C: D65C0061 03FC1161 FEDCBA98
	v_cndmask_b32_e64 v95, v94, v18, s1                        // 000000D8B358: D501005F 0006255E
	v_cndmask_b32_e64 v99, v18, v94, s1                        // 000000D8B360: D5010063 0006BD12
	v_permlanex16_b32 v131, v131, s8, 0xfedcba98               // 000000D8B368: D65C0083 03FC1183 FEDCBA98
	v_mov_b32_e32 v18, v135                                    // 000000D8B374: 7E240387
	v_permlanex16_b32 v101, v101, s8, 0xfedcba98               // 000000D8B378: D65C0065 03FC1165 FEDCBA98
	v_permlanex16_b32 v109, v109, s8, 0xfedcba98               // 000000D8B384: D65C006D 03FC116D FEDCBA98
	v_permlanex16_b32 v133, v133, s8, 0xfedcba98               // 000000D8B390: D65C0085 03FC1185 FEDCBA98
	v_permlanex16_b32 v34, v34, s8, 0xfedcba98                 // 000000D8B39C: D65C0022 03FC1122 FEDCBA98
	ds_load_b128 v[37:40], v35                                 // 000000D8B3A8: DBFC0000 25000023
	ds_load_b128 v[41:44], v35 offset:16                       // 000000D8B3B0: DBFC0010 29000023
	ds_load_b128 v[45:48], v35 offset:32                       // 000000D8B3B8: DBFC0020 2D000023
	ds_load_b128 v[49:52], v35 offset:48                       // 000000D8B3C0: DBFC0030 31000023
	ds_load_b128 v[53:56], v35 offset:64                       // 000000D8B3C8: DBFC0040 35000023
	ds_load_b128 v[57:60], v35 offset:80                       // 000000D8B3D0: DBFC0050 39000023
	ds_load_b128 v[61:64], v35 offset:96                       // 000000D8B3D8: DBFC0060 3D000023
	ds_load_b128 v[65:68], v35 offset:112                      // 000000D8B3E0: DBFC0070 41000023
	ds_load_b128 v[69:72], v35 offset:128                      // 000000D8B3E8: DBFC0080 45000023
	ds_load_b128 v[73:76], v35 offset:144                      // 000000D8B3F0: DBFC0090 49000023
	v_pk_fma_f16 v122, v83, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B3F8: CC0E007A 0BFC0B53 0000C931
	v_pk_fma_f16 v137, v79, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000D8B404: CC0E0089 0BFC0B4F 0000C931
	v_cndmask_b32_e64 v79, v90, v108, s1                       // 000000D8B410: D501004F 0006D95A
	v_cndmask_b32_e64 v83, v108, v90, s1                       // 000000D8B418: D5010053 0006B56C
	v_cndmask_b32_e64 v111, v81, v106, s1                      // 000000D8B420: D501006F 0006D551
	v_cndmask_b32_e64 v115, v106, v81, s1                      // 000000D8B428: D5010073 0006A36A
	v_cndmask_b32_e64 v112, v82, v110, s1                      // 000000D8B430: D5010070 0006DD52
	v_cndmask_b32_e64 v116, v110, v82, s1                      // 000000D8B438: D5010074 0006A56E
	v_cndmask_b32_e64 v77, v89, v85, s1                        // 000000D8B440: D501004D 0006AB59
	v_cndmask_b32_e64 v81, v85, v89, s1                        // 000000D8B448: D5010051 0006B355
	v_cndmask_b32_e64 v78, v98, v15, s1                        // 000000D8B450: D501004E 00061F62
	v_cndmask_b32_e64 v82, v15, v98, s1                        // 000000D8B458: D5010052 0006C50F
	v_cndmask_b32_e64 v85, v129, v86, s1                       // 000000D8B460: D5010055 0006AD81
	v_cndmask_b32_e64 v89, v86, v129, s1                       // 000000D8B468: D5010059 00070356
	v_cndmask_b32_e64 v86, v130, v16, s1                       // 000000D8B470: D5010056 00062182
	v_cndmask_b32_e64 v90, v16, v130, s1                       // 000000D8B478: D501005A 00070510
	.long 0xd73d000f                                           // 000000D8B480: D73D000F
	v_cndmask_b32_e32 v1, v25, v117, vcc_lo                    // 000000D8B484: 0202EB19
	v_cndmask_b32_e64 v87, v92, v102, s1                       // 000000D8B488: D5010057 0006CD5C
	v_cndmask_b32_e64 v91, v102, v92, s1                       // 000000D8B490: D501005B 0006B966
	v_cndmask_b32_e64 v88, v93, v36, s1                        // 000000D8B498: D5010058 0006495D
	v_cndmask_b32_e64 v92, v36, v93, s1                        // 000000D8B4A0: D501005C 0006BB24
	v_cndmask_b32_e64 v96, v97, v103, s1                       // 000000D8B4A8: D5010060 0006CF61
	v_cndmask_b32_e64 v100, v103, v97, s1                      // 000000D8B4B0: D5010064 0006C367
	v_permlanex16_b32 v132, v132, s8, 0xfedcba98               // 000000D8B4B8: D65C0084 03FC1184 FEDCBA98
	v_cndmask_b32_e64 v93, v131, v17, s1                       // 000000D8B4C4: D501005D 00062383
	v_cndmask_b32_e64 v97, v17, v131, s1                       // 000000D8B4CC: D5010061 00070711
	v_permlanex16_b32 v18, v18, s8, 0xfedcba98                 // 000000D8B4D4: D65C0012 03FC1112 FEDCBA98
	.long 0xd73d0010                                           // 000000D8B4E0: D73D0010
	v_cndmask_b32_e32 v1, v26, v117, vcc_lo                    // 000000D8B4E4: 0202EB1A
	v_cndmask_b32_e64 v103, v101, v104, s1                     // 000000D8B4E8: D5010067 0006D165
	v_cndmask_b32_e64 v107, v104, v101, s1                     // 000000D8B4F0: D501006B 0006CB68
	v_cndmask_b32_e64 v104, v109, v105, s1                     // 000000D8B4F8: D5010068 0006D36D
	v_cndmask_b32_e64 v108, v105, v109, s1                     // 000000D8B500: D501006C 0006DB69
	v_cndmask_b32_e64 v101, v133, v114, s1                     // 000000D8B508: D5010065 0006E585
	v_cndmask_b32_e64 v105, v114, v133, s1                     // 000000D8B510: D5010069 00070B72
	v_cndmask_b32_e64 v110, v34, v136, s1                      // 000000D8B518: D501006E 00071122
	v_cndmask_b32_e64 v114, v136, v34, s1                      // 000000D8B520: D5010072 00064588
	v_and_b32_e32 v34, 0xffff, v121                            // 000000D8B528: 3644F2FF 0000FFFF
	v_cndmask_b32_e64 v94, v132, v113, s1                      // 000000D8B530: D501005E 0006E384
	v_cndmask_b32_e64 v98, v113, v132, s1                      // 000000D8B538: D5010062 00070971
	v_cndmask_b32_e64 v109, v18, v135, s1                      // 000000D8B540: D501006D 00070F12
	v_cndmask_b32_e64 v113, v135, v18, s1                      // 000000D8B548: D5010071 00062587
	.long 0xd73d0011                                           // 000000D8B550: D73D0011
	v_cndmask_b32_e32 v1, v27, v117, vcc_lo                    // 000000D8B554: 0202EB1B
	.long 0xd72c0012                                           // 000000D8B558: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000D8B55C: 020244FF 83DCD12D
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D8B564: 362020FF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 000000D8B56C: BF890BF7
	v_bfe_u32 v34, v123, 12, 16                                // 000000D8B570: D6100022 0241197B
	s_waitcnt lgkmcnt(8)                                       // 000000D8B578: BF89FC87
	v_wmma_f32_16x16x16_f16 v[1:8], v[77:84], v[37:44], v[1:8] // 000000D8B57C: CC404001 1C064B4D
	v_and_b32_e32 v15, 0xffff, v15                             // 000000D8B584: 361E1EFF 0000FFFF
	v_and_b32_e32 v42, 0xffff, v123                            // 000000D8B58C: 3654F6FF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v17                             // 000000D8B594: 362222FF 0000FFFF
	v_bfe_u32 v39, v123, 8, 16                                 // 000000D8B59C: D6100027 0241117B
	.long 0xd72c0010                                           // 000000D8B5A4: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000D8B5A8: 020220FF 83DCD12D
	.long 0xd72c0022                                           // 000000D8B5B0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000D8B5B4: 020244FF 83DCD12D
	v_bfe_u32 v43, v123, 4, 16                                 // 000000D8B5BC: D610002B 0241097B
	.long 0xd72c000f                                           // 000000D8B5C4: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000D8B5C8: 02021EFF 83DCD12D
	.long 0xd72c002a                                           // 000000D8B5D0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000D8B5D4: 020254FF 83DCD12D
	.long 0xd72c0011                                           // 000000D8B5DC: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 000000D8B5E0: 020222FF 83DCD12D
	.long 0xd72c0027                                           // 000000D8B5E8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000D8B5EC: 02024EFF 83DCD12D
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000D8B5F4: D6220012 03FD0112 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000D8B600: D6220010 03FD0110 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000D8B60C: D6220022 03FD0122 00006400
	.long 0xd72c002b                                           // 000000D8B618: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000D8B61C: 020256FF 83DCD12D
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000D8B624: D622000F 03FD010F 00006400
	v_and_b32_e32 v18, 0xffff, v18                             // 000000D8B630: 362424FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000D8B638: D622002A 03FD012A 00006400
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D8B644: 362020FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000D8B64C: D6220011 03FD0111 00006400
	v_and_b32_e32 v34, 0xffff, v34                             // 000000D8B658: 364444FF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000D8B660: D6220027 03FD0127 00006400
	v_permlanex16_b32 v134, v134, s8, 0xfedcba98               // 000000D8B66C: D65C0086 03FC1186 FEDCBA98
	s_waitcnt lgkmcnt(6)                                       // 000000D8B678: BF89FC67
	v_wmma_f32_16x16x16_f16 v[1:8], v[85:92], v[45:52], v[1:8] // 000000D8B67C: CC404001 1C065B55
	ds_load_b128 v[44:47], v35 offset:160                      // 000000D8B684: DBFC00A0 2C000023
	ds_load_b128 v[48:51], v35 offset:176                      // 000000D8B68C: DBFC00B0 30000023
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000D8B694: D622002B 03FD012B 00006400
	v_lshlrev_b32_e32 v52, 16, v42                             // 000000D8B6A0: 30685490
	v_lshl_or_b32 v15, v15, 16, v18                            // 000000D8B6A4: D656000F 0449210F
	v_lshl_or_b32 v16, v17, 16, v16                            // 000000D8B6AC: D6560010 04412111
	v_lshl_or_b32 v17, v39, 16, v34                            // 000000D8B6B4: D6560011 04892127
	v_dual_mov_b32 v127, v122 :: v_dual_mov_b32 v128, v125     // 000000D8B6BC: CA10017A 7F80017D
	v_dual_mov_b32 v139, v137 :: v_dual_mov_b32 v140, v138     // 000000D8B6C4: CA100189 8B8C018A
	v_cndmask_b32_e64 v102, v134, v126, s1                     // 000000D8B6CC: D5010066 0006FD86
	v_cndmask_b32_e64 v106, v126, v134, s1                     // 000000D8B6D4: D501006A 00070D7E
	s_waitcnt lgkmcnt(6)                                       // 000000D8B6DC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[1:8], v[93:100], v[53:60], v[1:8]// 000000D8B6E0: CC404001 1C066B5D
	v_and_or_b32 v18, 0xffff, v43, v52                         // 000000D8B6E8: D6570012 04D256FF 0000FFFF
	v_pk_fma_f16 v34, v15, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B6F4: CC0E0022 0BFC0B0F 0000C931
	v_pk_fma_f16 v17, v17, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B700: CC0E0011 0BFC0B11 0000C931
	v_permlanex16_b32 v127, v127, s8, 0xfedcba98               // 000000D8B70C: D65C007F 03FC117F FEDCBA98
	v_permlanex16_b32 v139, v139, s8, 0xfedcba98               // 000000D8B718: D65C008B 03FC118B FEDCBA98
	s_waitcnt lgkmcnt(4)                                       // 000000D8B724: BF89FC47
	v_wmma_f32_16x16x16_f16 v[1:8], v[101:108], v[61:68], v[1:8]// 000000D8B728: CC404001 1C067B65
	v_permlanex16_b32 v140, v140, s8, 0xfedcba98               // 000000D8B730: D65C008C 03FC118C FEDCBA98
	v_permlanex16_b32 v128, v128, s8, 0xfedcba98               // 000000D8B73C: D65C0080 03FC1180 FEDCBA98
	v_pk_fma_f16 v53, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B748: CC0E0035 0BFC0B12 0000C931
	v_dual_mov_b32 v18, v34 :: v_dual_mov_b32 v55, v17         // 000000D8B754: CA100122 12360111
	v_pk_fma_f16 v52, v16, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B75C: CC0E0034 0BFC0B10 0000C931
	s_waitcnt vmcnt(0)                                         // 000000D8B768: BF8903F7
	.long 0xd73d000f                                           // 000000D8B76C: D73D000F
	v_cndmask_b32_e32 v1, v24, v119, vcc_lo                    // 000000D8B770: 0202EF18
	v_cndmask_b32_e64 v36, v139, v137, s1                      // 000000D8B774: D5010024 0007138B
	v_cndmask_b32_e64 v40, v137, v139, s1                      // 000000D8B77C: D5010028 00071789
	s_waitcnt lgkmcnt(2)                                       // 000000D8B784: BF89FC27
	v_wmma_f32_16x16x16_f16 v[1:8], v[109:116], v[69:76], v[1:8]// 000000D8B788: CC404001 1C068B6D
	v_cndmask_b32_e64 v37, v140, v138, s1                      // 000000D8B790: D5010025 0007158C
	v_cndmask_b32_e64 v41, v138, v140, s1                      // 000000D8B798: D5010029 0007198A
	v_cndmask_b32_e64 v38, v127, v122, s1                      // 000000D8B7A0: D5010026 0006F57F
	v_cndmask_b32_e64 v42, v122, v127, s1                      // 000000D8B7A8: D501002A 0006FF7A
	v_cndmask_b32_e64 v39, v128, v125, s1                      // 000000D8B7B0: D5010027 0006FB80
	v_cndmask_b32_e64 v43, v125, v128, s1                      // 000000D8B7B8: D501002B 0007017D
	v_permlanex16_b32 v18, v18, s8, 0xfedcba98                 // 000000D8B7C0: D65C0012 03FC1112 FEDCBA98
	v_permlanex16_b32 v55, v55, s8, 0xfedcba98                 // 000000D8B7CC: D65C0037 03FC1137 FEDCBA98
	v_mov_b32_e32 v54, v52                                     // 000000D8B7D8: 7E6C0334
	v_mov_b32_e32 v56, v53                                     // 000000D8B7DC: 7E700335
	s_waitcnt lgkmcnt(0)                                       // 000000D8B7E0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[36:43], v[44:51], v[1:8] // 000000D8B7E4: CC404001 1C065924
	v_cndmask_b32_e64 v36, v18, v34, s1                        // 000000D8B7EC: D5010024 00064512
	v_cndmask_b32_e64 v40, v34, v18, s1                        // 000000D8B7F4: D5010028 00062522
	v_and_b32_e32 v34, 0xffff, v15                             // 000000D8B7FC: 36441EFF 0000FFFF
	.long 0xd73d000f                                           // 000000D8B804: D73D000F
	v_cndmask_b32_e32 v1, v25, v119, vcc_lo                    // 000000D8B808: 0202EF19
	v_cndmask_b32_e64 v38, v55, v17, s1                        // 000000D8B80C: D5010026 00062337
	v_cndmask_b32_e64 v42, v17, v55, s1                        // 000000D8B814: D501002A 00066F11
	.long 0xd73d0010                                           // 000000D8B81C: D73D0010
	v_cndmask_b32_e32 v1, v26, v119, vcc_lo                    // 000000D8B820: 0202EF1A
	.long 0xd73d0011                                           // 000000D8B824: D73D0011
	v_cndmask_b32_e32 v1, v27, v119, vcc_lo                    // 000000D8B828: 0202EF1B
	v_permlanex16_b32 v54, v54, s8, 0xfedcba98                 // 000000D8B82C: D65C0036 03FC1136 FEDCBA98
	.long 0xd72c0012                                           // 000000D8B838: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000D8B83C: 020244FF 83DCD12D
	v_bfe_u32 v34, v124, 12, 16                                // 000000D8B844: D6100022 0241197C
	v_and_b32_e32 v43, 0xffff, v124                            // 000000D8B84C: 3656F8FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D8B854: 362020FF 0000FFFF
	v_cndmask_b32_e64 v37, v54, v52, s1                        // 000000D8B85C: D5010025 00066936
	v_cndmask_b32_e64 v41, v52, v54, s1                        // 000000D8B864: D5010029 00066D34
	v_and_b32_e32 v15, 0xffff, v15                             // 000000D8B86C: 361E1EFF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v17                             // 000000D8B874: 362222FF 0000FFFF
	v_bfe_u32 v39, v124, 8, 16                                 // 000000D8B87C: D6100027 0241117C
	.long 0xd72c0010                                           // 000000D8B884: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000D8B888: 020220FF 83DCD12D
	v_bfe_u32 v52, v124, 4, 16                                 // 000000D8B890: D6100034 0241097C
	.long 0xd72c0022                                           // 000000D8B898: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000D8B89C: 020244FF 83DCD12D
	.long 0xd72c002b                                           // 000000D8B8A4: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000D8B8A8: 020256FF 83DCD12D
	.long 0xd72c000f                                           // 000000D8B8B0: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 000000D8B8B4: 02021EFF 83DCD12D
	.long 0xd72c0011                                           // 000000D8B8BC: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 000000D8B8C0: 020222FF 83DCD12D
	.long 0xd72c0027                                           // 000000D8B8C8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000D8B8CC: 02024EFF 83DCD12D
	.long 0xd72c0034                                           // 000000D8B8D4: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000D8B8D8: 020268FF 83DCD12D
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000D8B8E0: D6220012 03FD0112 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000D8B8EC: D6220010 03FD0110 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000D8B8F8: D6220022 03FD0122 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000D8B904: D622002B 03FD012B 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 000000D8B910: D622000F 03FD010F 00006400
	v_and_b32_e32 v18, 0xffff, v18                             // 000000D8B91C: 362424FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v16                             // 000000D8B924: 362020FF 0000FFFF
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000D8B92C: D6220011 03FD0111 00006400
	v_and_b32_e32 v34, 0xffff, v34                             // 000000D8B938: 364444FF 0000FFFF
	v_sad_u8 v54, v39, 0, 0x6400                               // 000000D8B940: D6220036 03FD0127 00006400
	v_sad_u8 v52, v52, 0, 0x6400                               // 000000D8B94C: D6220034 03FD0134 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000D8B958: 30565690
	v_permlanex16_b32 v56, v56, s8, 0xfedcba98                 // 000000D8B95C: D65C0038 03FC1138 FEDCBA98
	ds_load_b128 v[44:47], v35 offset:192                      // 000000D8B968: DBFC00C0 2C000023
	ds_load_b128 v[48:51], v35 offset:208                      // 000000D8B970: DBFC00D0 30000023
	v_lshl_or_b32 v15, v15, 16, v18                            // 000000D8B978: D656000F 0449210F
	v_lshl_or_b32 v16, v17, 16, v16                            // 000000D8B980: D6560010 04412111
	v_lshl_or_b32 v17, v54, 16, v34                            // 000000D8B988: D6560011 04892136
	v_and_or_b32 v18, 0xffff, v52, v43                         // 000000D8B990: D6570012 04AE68FF 0000FFFF
	v_cndmask_b32_e64 v39, v56, v53, s1                        // 000000D8B99C: D5010027 00066B38
	v_pk_fma_f16 v15, v15, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B9A4: CC0E000F 0BFC0B0F 0000C931
	v_pk_fma_f16 v16, v16, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B9B0: CC0E0010 0BFC0B10 0000C931
	v_cndmask_b32_e64 v43, v53, v56, s1                        // 000000D8B9BC: D501002B 00067135
	v_pk_fma_f16 v17, v17, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B9C4: CC0E0011 0BFC0B11 0000C931
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000D8B9D0: CC0E0012 0BFC0B12 0000C931
	ds_load_b128 v[52:55], v35 offset:224                      // 000000D8B9DC: DBFC00E0 34000023
	ds_load_b128 v[56:59], v35 offset:240                      // 000000D8B9E4: DBFC00F0 38000023
	v_dual_mov_b32 v60, v15 :: v_dual_mov_b32 v61, v16         // 000000D8B9EC: CA10010F 3C3C0110
	v_dual_mov_b32 v62, v17 :: v_dual_mov_b32 v63, v18         // 000000D8B9F4: CA100111 3E3E0112
	s_nor_b32 s11, s0, s9                                      // 000000D8B9FC: 8F0B0900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BA00: BF870192
	v_permlanex16_b32 v60, v60, s8, 0xfedcba98                 // 000000D8BA04: D65C003C 03FC113C FEDCBA98
	v_permlanex16_b32 v61, v61, s8, 0xfedcba98                 // 000000D8BA10: D65C003D 03FC113D FEDCBA98
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8BA1C: BF870003
	v_permlanex16_b32 v62, v62, s8, 0xfedcba98                 // 000000D8BA20: D65C003E 03FC113E FEDCBA98
	v_permlanex16_b32 v63, v63, s8, 0xfedcba98                 // 000000D8BA2C: D65C003F 03FC113F FEDCBA98
	s_waitcnt lgkmcnt(2)                                       // 000000D8BA38: BF89FC27
	v_wmma_f32_16x16x16_f16 v[1:8], v[36:43], v[44:51], v[1:8] // 000000D8BA3C: CC404001 1C065924
	v_cndmask_b32_e64 v34, v60, v15, s1                        // 000000D8BA44: D5010022 00061F3C
	v_cndmask_b32_e64 v38, v15, v60, s1                        // 000000D8BA4C: D5010026 0006790F
	v_cndmask_b32_e64 v35, v61, v16, s1                        // 000000D8BA54: D5010023 0006213D
	v_cndmask_b32_e64 v39, v16, v61, s1                        // 000000D8BA5C: D5010027 00067B10
	v_cndmask_b32_e64 v36, v62, v17, s1                        // 000000D8BA64: D5010024 0006233E
	v_cndmask_b32_e64 v40, v17, v62, s1                        // 000000D8BA6C: D5010028 00067D11
	v_cndmask_b32_e64 v37, v63, v18, s1                        // 000000D8BA74: D5010025 0006253F
	v_cndmask_b32_e64 v41, v18, v63, s1                        // 000000D8BA7C: D5010029 00067F12
	s_waitcnt lgkmcnt(0)                                       // 000000D8BA84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8BA88: BF870001
	v_wmma_f32_16x16x16_f16 v[1:8], v[34:41], v[52:59], v[1:8] // 000000D8BA8C: CC404001 1C066922
	s_and_saveexec_b32 s9, s11                                 // 000000D8BA94: BE89200B
	s_cbranch_execz 64291                                      // 000000D8BA98: BFA5FB23 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9228>
	s_and_b32 s10, s10, exec_lo                                // 000000D8BA9C: 8B0A7E0A
	s_cselect_b32 s10, 0x4400, 0                               // 000000D8BAA0: 980A80FF 00004400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8BAA8: BF870099
	v_lshl_add_u32 v15, v22, 1, s10                            // 000000D8BAAC: D646000F 00290316
	v_lshl_add_u32 v15, v20, 1, v15                            // 000000D8BAB4: D646000F 043D0314
	ds_store_b128 v15, v[9:12]                                 // 000000D8BABC: DB7C0000 0000090F
	s_branch 64280                                             // 000000D8BAC4: BFA0FB18 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x9228>
	v_mad_u32_u24 v10, 0x110, v9, v10                          // 000000D8BAC8: D60B000A 042A12FF 00000110
	s_waitcnt vmcnt(2)                                         // 000000D8BAD4: BF890BF7
	ds_store_b128 v10, v[37:40]                                // 000000D8BAD8: DB7C0000 0000250A
	s_or_b32 exec_lo, exec_lo, s1                              // 000000D8BAE0: 8C7E017E
	.long 0xd44c0001                                           // 000000D8BAE4: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000D8BAE8: 020200FF 00000200
	s_and_saveexec_b32 s2, s1                                  // 000000D8BAF0: BE822001
	s_cbranch_execz 55025                                      // 000000D8BAF4: BFA5D6F1 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1bc>
	s_waitcnt vmcnt(1)                                         // 000000D8BAF8: BF8907F7
	ds_store_b128 v11, v[41:44] offset:8704                    // 000000D8BAFC: DB7C2200 0000290B
	s_or_b32 exec_lo, exec_lo, s2                              // 000000D8BB04: 8C7E027E
	.long 0xd44c0002                                           // 000000D8BB08: D44C0002
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000D8BB0C: 020200FF 00000100
	s_and_saveexec_b32 s3, s2                                  // 000000D8BB14: BE832002
	s_cbranch_execnz 55022                                     // 000000D8BB18: BFA6D6EE <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1d4>
	s_branch 55024                                             // 000000D8BB1C: BFA0D6F0 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1e0>
	v_lshrrev_b32_e32 v10, 5, v0                               // 000000D8BB20: 32140085
	v_and_b32_e32 v11, 1, v0                                   // 000000D8BB24: 36160081
	v_and_b32_e32 v12, 2, v0                                   // 000000D8BB28: 36180082
	v_and_b32_e32 v15, 4, v0                                   // 000000D8BB2C: 361E0084
	v_and_b32_e32 v16, 8, v0                                   // 000000D8BB30: 36200088
	v_lshlrev_b32_e32 v9, 6, v10                               // 000000D8BB34: 30121486
	v_and_b32_e32 v0, 16, v0                                   // 000000D8BB38: 36000090
	v_lshrrev_b32_e32 v13, 2, v19                              // 000000D8BB3C: 321A2682
	s_lshl_b32 s0, s17, 7                                      // 000000D8BB40: 84008711
	s_mul_i32 s3, s16, 0x1400                                  // 000000D8BB44: 9603FF10 00001400
	v_mad_u32_u24 v14, 0x210, v21, v9                          // 000000D8BB4C: D60B000E 04262AFF 00000210
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000D8BB58: 7C940080
	v_lshlrev_b32_e32 v0, 3, v19                               // 000000D8BB5C: 30002683
	s_mul_hi_i32 s2, s16, 0x1400                               // 000000D8BB60: 9702FF10 00001400
	s_ashr_i32 s1, s0, 31                                      // 000000D8BB68: 86019F00
	v_and_or_b32 v13, v13, 4, v14                              // 000000D8BB6C: D657000D 0439090D
	s_add_u32 s3, s14, s3                                      // 000000D8BB74: 8003030E
	s_addc_u32 s9, s15, s2                                     // 000000D8BB78: 8209020F
	s_lshl_b64 s[4:5], s[0:1], 1                               // 000000D8BB7C: 84848100
	.long 0xd7000000                                           // 000000D8BB80: D7000000
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000D8BB84: 02020006
	v_lshlrev_b32_e32 v9, 2, v19                               // 000000D8BB88: 30122682
	ds_store_2addr_b32 v13, v1, v2 offset1:2                   // 000000D8BB8C: D8380200 0002010D
	ds_store_2addr_b32 v13, v3, v4 offset0:4 offset1:6         // 000000D8BB94: D8380604 0004030D
	ds_store_2addr_b32 v13, v5, v6 offset0:8 offset1:10        // 000000D8BB9C: D8380A08 0006050D
	v_add_co_ci_u32_e64 v1, null, s7, 0, s0                    // 000000D8BBA4: D5207C01 00010007
	s_add_u32 s8, s3, s4                                       // 000000D8BBAC: 80080403
	.long 0xd7000400                                           // 000000D8BBB0: D7000400
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000D8BBB4: 02000900
	.long 0xd44a0003                                           // 000000D8BBB8: D44A0003
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000D8BBBC: 02021680
	.long 0xd44a0002                                           // 000000D8BBC0: D44A0002
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000D8BBC4: 02021880
	.long 0xd44a0001                                           // 000000D8BBC8: D44A0001
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000D8BBCC: 02021E80
	.long 0xd44a0000                                           // 000000D8BBD0: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 000000D8BBD4: 02022080
	v_add_co_ci_u32_e64 v1, null, s5, v1, s4                   // 000000D8BBD8: D5207C01 00120205
	v_lshlrev_b32_e32 v2, 1, v9                                // 000000D8BBE0: 30041281
	s_addc_u32 s9, s9, s5                                      // 000000D8BBE4: 82090509
	s_mov_b32 s5, exec_lo                                      // 000000D8BBE8: BE85007E
	ds_store_2addr_b32 v13, v7, v8 offset0:12 offset1:14       // 000000D8BBEC: D8380E0C 0008070D
	s_waitcnt lgkmcnt(0)                                       // 000000D8BBF4: BF89FC07
	s_barrier                                                  // 000000D8BBF8: BFBD0000
	buffer_gl0_inv                                             // 000000D8BBFC: E0AC0000 00000000
	.long 0xd4c4007e                                           // 000000D8BC04: D4C4007E
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000D8BC08: 02021413
	s_cbranch_execz 203                                        // 000000D8BC0C: BFA500CB <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xaa3c>
	global_load_b64 v[7:8], v2, s[8:9]                         // 000000D8BC10: DC560000 07080002
	v_mul_u32_u24_e32 v3, 0x210, v10                           // 000000D8BC18: 160614FF 00000210
	s_mov_b32 s4, 0x76543210                                   // 000000D8BC20: BE8400FF 76543210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000D8BC28: BF870151
	v_lshl_add_u32 v3, v9, 2, v3                               // 000000D8BC2C: D6460003 040D0509
	ds_load_b128 v[3:6], v3                                    // 000000D8BC34: DBFC0000 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000D8BC3C: BF89FC07
	v_dual_add_f32 v11, v3, v4 :: v_dual_add_f32 v12, v5, v6   // 000000D8BC40: C9080903 0B0C0D05
	v_dual_sub_f32 v3, v3, v4 :: v_dual_sub_f32 v4, v5, v6     // 000000D8BC48: C94A0903 03040D05
	v_sub_f32_e32 v6, v11, v12                                 // 000000D8BC50: 080C190B
	v_add_f32_e32 v5, v11, v12                                 // 000000D8BC54: 060A190B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8BC58: BF870223
	v_add_f32_e32 v11, v3, v4                                  // 000000D8BC5C: 06160903
	v_sub_f32_e32 v3, v3, v4                                   // 000000D8BC60: 08060903
	v_mov_b32_dpp v12, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BC64: 7E1802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000D8BC6C: D5010006 200E0D06
	v_mov_b32_dpp v4, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BC74: 7E0802FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000D8BC7C: D5010005 200E0B05
	v_mov_b32_dpp v13, v11 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BC84: 7E1A02FA FF01610B
	v_mov_b32_dpp v14, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BC8C: 7E1C02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000D8BC94: D5010003 200E0703
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 000000D8BC9C: D501000B 200E170B
	v_add_f32_e32 v6, v6, v12                                  // 000000D8BCA4: 060C1906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BCA8: BF870193
	v_dual_add_f32 v4, v5, v4 :: v_dual_add_f32 v3, v3, v14    // 000000D8BCAC: C9080905 04021D03
	v_add_f32_e32 v5, v11, v13                                 // 000000D8BCB4: 060A1B0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8BCB8: BF870223
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8BCBC: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D8BCC4: D5010006 200A0D06
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8BCCC: 7E1802FA FF016204
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8BCD4: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s2                          // 000000D8BCDC: D5010003 200A0703
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D8BCE4: D5010004 200A0904
	v_add_f32_e32 v6, v6, v11                                  // 000000D8BCEC: 060C1706
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8BCF0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D8BCF8: D5010005 200A0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8BD00: BF870214
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v12   // 000000D8BD04: C9081B03 03041904
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8BD0C: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D8BD14: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8BD1C: BF870214
	v_add_f32_e32 v5, v5, v11                                  // 000000D8BD20: 060A1705
	v_mov_b32_dpp v11, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8BD24: 7E1602FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000D8BD2C: D5010003 20060703
	v_mov_b32_dpp v13, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8BD34: 7E1A02FA FF016404
	v_add_f32_e32 v6, v6, v12                                  // 000000D8BD3C: 060C1906
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D8BD40: D5010004 20060904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8BD48: 7E1802FA FF016405
	v_add_f32_e32 v3, v3, v11                                  // 000000D8BD50: 06061703
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D8BD54: D5010005 20060B05
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8BD5C: 7E1602FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D8BD64: D5010006 20020D06
	v_add_f32_e32 v4, v4, v13                                  // 000000D8BD6C: 06081B04
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8BD70: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000D8BD78: D5010003 20020703
	.long 0x7f1c3880                                           // 000000D8BD80: 7F1C3880
	v_dual_add_f32 v6, v6, v11 :: v_dual_add_f32 v5, v5, v12   // 000000D8BD84: C9081706 06041905
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8BD8C: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D8BD94: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3)                            // 000000D8BD9C: BF870003
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v6       // 000000D8BDA0: C9101B03 030C0106
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D8BDA8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8BDB0: 7E1A02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D8BDB8: D5010005 20020B05
	v_add_f32_e32 v4, v4, v11                                  // 000000D8BDC0: 06081704
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D8BDC4: D65C000C 03FC090C FEDCBA98
	v_mov_b32_e32 v15, v3                                      // 000000D8BDD0: 7E1E0303
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000D8BDD4: D5010003 21AA0703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BDDC: BF870193
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v5, v5, v13   // 000000D8BDE0: C9081906 06041B05
	v_permlanex16_b32 v15, v15, s4, 0xfedcba98                 // 000000D8BDE8: D65C000F 03FC090F FEDCBA98
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BDF4: BF870192
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mov_b32 v11, v4// 000000D8BDF8: C8D00CFF 060A0104 3DB504F3
	v_mov_b32_e32 v12, v5                                      // 000000D8BE04: 7E180305
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D8BE08: D5010004 21AA0904
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D8BE10: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8BE18: BF870214
	v_permlanex16_b32 v11, v11, s4, 0xfedcba98                 // 000000D8BE1C: D65C000B 03FC090B FEDCBA98
	v_permlanex16_b32 v12, v12, s4, 0xfedcba98                 // 000000D8BE28: D65C000C 03FC090C FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8BE34: BF870121
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000D8BE38: C9081704 04041905
	.long 0x7f16398e                                           // 000000D8BE40: 7F16398E
	v_dual_add_f32 v3, v3, v15 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000D8BE44: C9061F03 030408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8BE50: BF870113
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000D8BE54: 100A0AFF 3DB504F3
	v_mul_f32_e32 v3, 0x3db504f3, v3                           // 000000D8BE5C: 100606FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D8BE64: BF8903F7
	v_fma_mix_f32 v6, v8, v6, neg(0) op_sel_hi:[1,0,0]         // 000000D8BE68: CC200006 8A020D08
	v_fma_mix_f32 v4, v7, v4, neg(0) op_sel_hi:[1,0,0]         // 000000D8BE70: CC200004 8A020907
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8BE78: CC200805 8A020B07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8BE80: BF870113
	.long 0x7e163986                                           // 000000D8BE84: 7E163986
	v_bfe_u32 v12, v5, 16, 1                                   // 000000D8BE88: D610000C 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8BE90: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 000000D8BE94: 36161681
	v_add3_u32 v5, v5, v12, 0x7fff                             // 000000D8BE98: D6550005 03FE1905 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000D8BEA4: BF870122
	v_add3_u32 v6, v6, v11, 0x7fff                             // 000000D8BEA8: D6550006 03FE1706 00007FFF
	.long 0x7f16398e                                           // 000000D8BEB4: 7F16398E
	.long 0x7e163986                                           // 000000D8BEB8: 7E163986
	v_add_nc_u32_e32 v6, s18, v10                              // 000000D8BEBC: 4A0C1412
	v_fma_mix_f32 v3, v8, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8BEC0: CC200803 8A020708
	.long 0x7f10398e                                           // 000000D8BEC8: 7F10398E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8BECC: BF870092
	.long 0x7e103983                                           // 000000D8BED0: 7E103983
	v_and_b32_e32 v7, 1, v8                                    // 000000D8BED4: 360E1081
	v_bfe_u32 v8, v4, 16, 1                                    // 000000D8BED8: D6100008 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8BEE0: BF870112
	v_add3_u32 v3, v3, v7, 0x7fff                              // 000000D8BEE4: D6550003 03FE0F03 00007FFF
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000D8BEF0: D6550004 03FE1104 00007FFF
	v_and_b32_e32 v8, 0xffff, v11                              // 000000D8BEFC: 361016FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BF04: BF870193
	v_and_b32_e32 v7, 0xffff0000, v3                           // 000000D8BF08: 360E06FF FFFF0000
	.long 0x7e1c3984                                           // 000000D8BF10: 7E1C3984
	v_mad_i64_i32 v[3:4], null, 0x1400, v6, v[0:1]             // 000000D8BF14: D6FF7C03 04020CFF 00001400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8BF20: BF870193
	v_or_b32_e32 v6, v7, v8                                    // 000000D8BF24: 380C1107
	v_and_or_b32 v5, 0xffff0000, v5, v14                       // 000000D8BF28: D6570005 043A0AFF FFFF0000
	global_store_b64 v[3:4], v[5:6], off                       // 000000D8BF34: DC6E0000 007C0503
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D8BF3C: 8C7E057E
	v_or_b32_e32 v3, 8, v10                                    // 000000D8BF40: 38061488
	s_mov_b32 s5, exec_lo                                      // 000000D8BF44: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000D8BF48: BF870001
	.long 0xd4c4007e                                           // 000000D8BF4C: D4C4007E
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 000000D8BF50: 02020613
	s_cbranch_execz 200                                        // 000000D8BF54: BFA500C8 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad78>
	global_load_b64 v[10:11], v2, s[8:9]                       // 000000D8BF58: DC560000 0A080002
	v_mul_u32_u24_e32 v2, 0x210, v3                            // 000000D8BF60: 160406FF 00000210
	v_add_nc_u32_e32 v3, s18, v3                               // 000000D8BF68: 4A060612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8BF6C: BF870112
	v_lshl_add_u32 v2, v9, 2, v2                               // 000000D8BF70: D6460002 04090509
	v_mad_i64_i32 v[0:1], null, 0x1400, v3, v[0:1]             // 000000D8BF78: D6FF7C00 040206FF 00001400
	ds_load_b128 v[4:7], v2                                    // 000000D8BF84: DBFC0000 04000002
	s_waitcnt lgkmcnt(0)                                       // 000000D8BF8C: BF89FC07
	v_add_f32_e32 v2, v4, v5                                   // 000000D8BF90: 06040B04
	v_dual_sub_f32 v4, v4, v5 :: v_dual_sub_f32 v5, v6, v7     // 000000D8BF94: C94A0B04 04040F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000D8BF9C: BF870091
	v_dual_add_f32 v8, v6, v7 :: v_dual_add_f32 v7, v4, v5     // 000000D8BFA0: C9080F06 08060B04
	v_add_f32_e32 v6, v2, v8                                   // 000000D8BFA8: 060C1102
	v_sub_f32_e32 v2, v2, v8                                   // 000000D8BFAC: 08041102
	v_sub_f32_e32 v4, v4, v5                                   // 000000D8BFB0: 08080B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8BFB4: BF870214
	v_mov_b32_dpp v9, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BFB8: 7E1202FA FF016107
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BFC0: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8BFC8: BF870004
	v_mov_b32_dpp v8, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BFCC: 7E1002FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000D8BFD4: D5010002 200E0502
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000D8BFDC: D5010006 200E0D06
	v_mov_b32_dpp v12, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000D8BFE4: 7E1802FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000D8BFEC: D5010004 200E0904
	v_cndmask_b32_e64 v7, -v7, v7, s3                          // 000000D8BFF4: D5010007 200E0F07
	v_add_f32_e32 v2, v2, v8                                   // 000000D8BFFC: 06041102
	v_add_f32_e32 v5, v6, v5                                   // 000000D8C000: 060A0B06
	s_mov_b32 s3, 0x76543210                                   // 000000D8C004: BE8300FF 76543210
	v_add_f32_e32 v4, v4, v12                                  // 000000D8C00C: 06081904
	v_add_f32_e32 v6, v7, v9                                   // 000000D8C010: 060C1307
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8C014: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s2                          // 000000D8C01C: D5010002 200A0502
	v_mov_b32_dpp v8, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8C024: 7E1002FA FF016205
	v_mov_b32_dpp v9, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8C02C: 7E1202FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000D8C034: D5010004 200A0904
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000D8C03C: D5010005 200A0B05
	v_add_f32_e32 v2, v2, v7                                   // 000000D8C044: 06040F02
	v_mov_b32_dpp v7, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000D8C048: 7E0E02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s2                          // 000000D8C050: D5010006 200A0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C058: BF870214
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v8     // 000000D8C05C: C9081304 04041105
	v_mov_b32_dpp v8, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8C064: 7E1002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000D8C06C: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C074: BF870214
	v_add_f32_e32 v6, v6, v7                                   // 000000D8C078: 060C0F06
	v_mov_b32_dpp v7, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8C07C: 7E0E02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000D8C084: D5010004 20060904
	v_mov_b32_dpp v9, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8C08C: 7E1202FA FF016405
	v_add_f32_e32 v2, v2, v8                                   // 000000D8C094: 06041102
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000D8C098: D5010005 20060B05
	v_mov_b32_dpp v8, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000D8C0A0: 7E1002FA FF016406
	v_add_f32_e32 v4, v4, v7                                   // 000000D8C0A8: 06080F04
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000D8C0AC: D5010006 20060D06
	v_mov_b32_dpp v7, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8C0B4: 7E0E02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000D8C0BC: D5010002 20020502
	v_add_f32_e32 v5, v5, v9                                   // 000000D8C0C4: 060A1305
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8C0C8: 7E1202FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000D8C0D0: D5010004 20020904
	v_add_f32_e32 v6, v6, v8                                   // 000000D8C0D8: 060C1106
	v_add_f32_e32 v2, v2, v7                                   // 000000D8C0DC: 06040F02
	v_mov_b32_dpp v7, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8C0E0: 7E0E02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000D8C0E8: D5010005 20020B05
	v_add_f32_e32 v4, v4, v9                                   // 000000D8C0F0: 06081304
	v_mov_b32_dpp v9, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000D8C0F4: 7E1202FA FF016806
	v_mov_b32_e32 v8, v2                                       // 000000D8C0FC: 7E100302
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 000000D8C100: D5010006 20020D06
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000D8C108: D5010002 21AA0502
	v_mov_b32_e32 v13, v4                                      // 000000D8C110: 7E1A0304
	v_add_f32_e32 v5, v5, v7                                   // 000000D8C114: 060A0F05
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D8C118: D65C0008 03FC0708 FEDCBA98
	v_add_f32_e32 v6, v6, v9                                   // 000000D8C124: 060C1306
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000D8C128: D5010004 21AA0904
	v_permlanex16_b32 v13, v13, s3, 0xfedcba98                 // 000000D8C130: D65C000D 03FC070D FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000D8C13C: BF870234
	v_dual_mov_b32 v7, v5 :: v_dual_add_f32 v2, v2, v8         // 000000D8C140: CA080105 07021102
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000D8C148: D5010005 21AA0B05
	v_mov_b32_e32 v8, v6                                       // 000000D8C150: 7E100306
	v_add_f32_e32 v4, v4, v13                                  // 000000D8C154: 06081B04
	s_delay_alu instid0(VALU_DEP_4)                            // 000000D8C158: BF870004
	v_permlanex16_b32 v7, v7, s3, 0xfedcba98                   // 000000D8C15C: D65C0007 03FC0707 FEDCBA98
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000D8C168: 100404FF 3DB504F3
	.long 0x7f183880                                           // 000000D8C170: 7F183880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000D8C174: D5010006 21AA0D06
	v_permlanex16_b32 v8, v8, s3, 0xfedcba98                   // 000000D8C17C: D65C0008 03FC0708 FEDCBA98
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_add_f32 v5, v5, v7// 000000D8C188: C8C808FF 04040F05 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8C194: BF870224
	.long 0x7f0e398c                                           // 000000D8C198: 7F0E398C
	.long 0x7f12398c                                           // 000000D8C19C: 7F12398C
	v_add_f32_e32 v6, v6, v8                                   // 000000D8C1A0: 060C1106
	.long 0x7f10398c                                           // 000000D8C1A4: 7F10398C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000D8C1A8: BF8701C2
	v_dual_mul_f32 v5, 0x3db504f3, v5 :: v_dual_mul_f32 v6, 0x3db504f3, v6// 000000D8C1AC: C8C60AFF 05060CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000D8C1B8: BF8903F7
	v_fma_mix_f32 v2, v11, v2, neg(0) op_sel_hi:[1,0,0]        // 000000D8C1BC: CC200002 8A02050B
	v_fma_mix_f32 v4, v11, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8C1C4: CC200804 8A02090B
	v_fma_mix_f32 v5, v10, v5, neg(0) op_sel_hi:[1,0,0]        // 000000D8C1CC: CC200005 8A020B0A
	v_fma_mix_f32 v6, v10, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000D8C1D4: CC200806 8A020D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C1DC: BF870214
	.long 0x7e0e3982                                           // 000000D8C1E0: 7E0E3982
	.long 0x7e103984                                           // 000000D8C1E4: 7E103984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C1E8: BF870193
	v_bfe_u32 v10, v6, 16, 1                                   // 000000D8C1EC: D610000A 02052106
	v_and_b32_e32 v7, 1, v7                                    // 000000D8C1F4: 360E0E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8C1F8: BF870113
	v_and_b32_e32 v8, 1, v8                                    // 000000D8C1FC: 36101081
	v_add3_u32 v2, v2, v7, 0x7fff                              // 000000D8C200: D6550002 03FE0F02 00007FFF
	v_bfe_u32 v7, v5, 16, 1                                    // 000000D8C20C: D6100007 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000D8C214: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000D8C218: D6550004 03FE1104 00007FFF
	.long 0x7e123982                                           // 000000D8C224: 7E123982
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000D8C228: BF870223
	v_add3_u32 v2, v5, v7, 0x7fff                              // 000000D8C22C: D6550002 03FE0F05 00007FFF
	v_add3_u32 v5, v6, v10, 0x7fff                             // 000000D8C238: D6550005 03FE1506 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000D8C244: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000D8C24C: BF870214
	v_and_b32_e32 v6, 0xffff, v9                               // 000000D8C250: 360C12FF 0000FFFF
	.long 0x7e183982                                           // 000000D8C258: 7E183982
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000D8C25C: BF870112
	v_or_b32_e32 v3, v4, v6                                    // 000000D8C260: 38060D04
	v_and_or_b32 v2, 0xffff0000, v5, v12                       // 000000D8C264: D6570002 04320AFF FFFF0000
	global_store_b64 v[0:1], v[2:3], off                       // 000000D8C270: DC6E0000 007C0200
	s_or_b32 exec_lo, exec_lo, s5                              // 000000D8C278: 8C7E057E
	s_mov_b32 s3, -1                                           // 000000D8C27C: BE8300C1
	s_waitcnt_vscnt null, 0x0                                  // 000000D8C280: BC7C0000
	s_barrier                                                  // 000000D8C284: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000D8C288: 8B6A037E
	s_cbranch_vccz 2                                           // 000000D8C28C: BFA30002 <_ZN7halogen12_GLOBAL__N_112k_ht_moe_dn2ILi4ELi64ELi0EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0xad98>
	buffer_gl0_inv                                             // 000000D8C290: E0AC0000 00000000
	s_endpgm                                                   // 000000D8C298: BFB00000
		...

