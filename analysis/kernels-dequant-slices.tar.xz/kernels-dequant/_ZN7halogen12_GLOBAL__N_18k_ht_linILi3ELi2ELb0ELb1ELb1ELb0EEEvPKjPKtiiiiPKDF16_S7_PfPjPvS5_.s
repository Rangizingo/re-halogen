0000000000452000 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000452000: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000452004: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000045200C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000452014: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 00000045201C: BE840003
	v_and_b32_e32 v44, 31, v0                                  // 000000452020: 3658009F
	v_lshrrev_b32_e32 v42, 5, v0                               // 000000452024: 32540085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000452028: BF870002
	v_lshlrev_b32_e32 v8, 3, v44                               // 00000045202C: 30105883
	s_waitcnt lgkmcnt(0)                                       // 000000452030: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000452034: 86229F19
	s_mul_i32 s33, s27, s4                                     // 000000452038: 9621041B
	s_lshr_b32 s3, s34, 25                                     // 00000045203C: 85039922
	s_add_i32 s5, s33, s27                                     // 000000452040: 81051B21
	s_add_i32 s3, s25, s3                                      // 000000452044: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000452048: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000045204C: 86038703
	s_min_i32 s3, s3, s5                                       // 000000452050: 89030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000452054: BF8704B9
	s_sub_i32 s11, s3, s33                                     // 000000452058: 818B2103
	s_mov_b32 s3, exec_lo                                      // 00000045205C: BE83007E
	s_lshl_b32 s10, s11, 1                                     // 000000452060: 840A810B
	.long 0xd4c3007e                                           // 000000452064: D4C3007E
	v_cndmask_b32_e32 v1, s10, v42, vcc_lo                     // 000000452068: 0202540A
	s_xor_b32 s3, exec_lo, s3                                  // 00000045206C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v44                               // 000000452070: 30105883
	s_or_saveexec_b32 s35, s3                                  // 000000452074: BEA32203
	s_clause 0x1                                               // 000000452078: BF850001
	s_load_b32 s27, s[0:1], 0x54                               // 00000045207C: F40006C0 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000452084: F4080700 F8000000
	v_lshlrev_b32_e32 v43, 2, v44                              // 00000045208C: 30565882
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000452090: 8D7E237E
	s_cbranch_execz 499                                        // 000000452094: BFA501F3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	s_add_i32 s36, s24, -1                                     // 000000452098: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000045209C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 0000004520A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 0000004520A4: 982580C1
	s_abs_i32 s38, s11                                         // 0000004520A8: BEA6150B
	v_and_b32_e32 v3, 2, v0                                    // 0000004520AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 0000004520B0: BE806526
	v_dual_mov_b32 v9, v42 :: v_dual_and_b32 v4, 4, v0         // 0000004520B4: CA24012A 09040084
	v_and_b32_e32 v5, 8, v0                                    // 0000004520BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004520C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000004520C4: 7E045600
	v_lshl_or_b32 v6, v42, 8, v8                               // 0000004520C8: D6560006 0421112A
	v_add_nc_u32_e32 v7, s33, v42                              // 0000004520D0: 4A0E5421
	s_ashr_i32 s42, s11, 31                                    // 0000004520D4: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 0000004520D8: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 0000004520DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000004520E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 0000004520E8: 02025890
	.long 0xd44a0001                                           // 0000004520EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004520F0: 02020280
	.long 0xd44a0005                                           // 0000004520F4: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004520F8: 02020880
	.long 0xd44a0006                                           // 0000004520FC: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000452100: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000452104: 7E060502
	v_lshl_or_b32 v1, v7, 7, v43                               // 000000452108: D6560001 04AD0F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000452110: 4E140C2C
	s_lshl_b32 s7, s11, 7                                      // 000000452114: 8407870B
	s_mov_b32 s39, s25                                         // 000000452118: BEA70019
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 00000045211C: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000452124: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000452128: 02020680
	s_mov_b32 s40, 0                                           // 00000045212C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000452130: BEA900FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 000000452138: BE886708
	s_lshl_b32 s43, s11, 8                                     // 00000045213C: 842B880B
	s_sub_i32 s44, 0, s7                                       // 000000452140: 81AC0780
	s_mov_b32 s46, 0x3db504f3                                  // 000000452144: BEAE00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 00000045214C: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000452150: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 000000452154: 96890908
	s_add_i32 s45, s8, s9                                      // 000000452158: 812D0908
	s_branch 161                                               // 00000045215C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452160: BF870091
	.long 0xd7006a02                                           // 000000452164: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000452168: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000045216C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000452174: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000045217C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000452184: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000452188: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000045218C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000452194: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000452198: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004521A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 0000004521A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 0000004521AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004521B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004521B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004521C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 0000004521C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004521CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004521D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004521DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 0000004521E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004521E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004521F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004521F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 0000004521FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000452200: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000452208: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000452210: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000452218: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000045221C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000452224: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000045222C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000452230: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000452238: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000452240: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000452248: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045224C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000452254: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000045225C: 060A1905
	.long 0xd72c0007                                           // 000000452260: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000452264: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000452268: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045226C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000452274: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000452278: D5010004 20160904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000452280: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000452288: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000452290: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000452298: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000004522A0: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 0000004522A8: D5010003 20160703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000004522B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004522B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 0000004522BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000004522C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004522C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 0000004522D0: D5010004 201A0904
	v_add_f32_e32 v3, v3, v13                                  // 0000004522D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004522DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 0000004522E4: D5010005 201A0B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004522EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 0000004522F4: D5010002 201A0502
	v_add_f32_e32 v4, v4, v11                                  // 0000004522FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000452300: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 000000452308: D5010003 201A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000452310: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000452314: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 00000045231C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000452320: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000452328: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 00000045232C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000452334: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000452338: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000045233C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000452348: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000452350: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000452354: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000045235C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000452364: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000452370: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 00000045237C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000452380: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s10, v9                           // 00000045238C: 7C86120A
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000452390: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000452398: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045239C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 0000004523A0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 0000004523AC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 0000004523B4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004523BC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 0000004523C0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 0000004523C8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 0000004523D0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 0000004523D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 0000004523DC: 917E287E
	s_cbranch_execz 287                                        // 0000004523E0: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	.long 0xd72d0002                                           // 0000004523E4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 0000004523E8: 02005B09
	s_mov_b32 s7, -1                                           // 0000004523EC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004523F0: BF870091
	.long 0xd72c0003                                           // 0000004523F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 0000004523F8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 0000004523FC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000452400: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000452404: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000452408: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000045240C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000452414: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000452418: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000045241C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452420: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000452424: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000452428: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000045242C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452430: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000452434: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000452438: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045243C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000452440: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000452448: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000045244C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452454: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000452458: 340E0C9F
	.long 0xd73c0002                                           // 00000045245C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000452460: 02020C81
	s_cbranch_vccnz 209                                        // 000000452464: BFA400D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7ac>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452468: BF870093
	.long 0xd7006a06                                           // 00000045246C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000452470: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000452474: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 00000045247C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000452480: BF870112
	.long 0xd73c0006                                           // 000000452484: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000452488: 02020C81
	.long 0x7f40399d                                           // 00000045248C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000452490: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452494: BF870092
	.long 0xd7006a0d                                           // 000000452498: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000045249C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 0000004524A0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 0000004524A8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000004524AC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004524B0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000004524B4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 0000004524BC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 0000004524C4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004524C8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000004524CC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 0000004524D4: D5207C10 01AA060D
	s_clause 0x1                                               // 0000004524DC: BF850001
	global_load_b32 v17, v[15:16], off                         // 0000004524E0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 0000004524E8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 0000004524F0: BF890FF7
	.long 0x7e20390d                                           // 0000004524F4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 0000004524F8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 0000004524FC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000452504: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452508: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000045250C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000452510: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000452518: BF870291
	v_exp_f32_e32 v20, v20                                     // 00000045251C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000452520: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045252C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000452530: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000452538: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000452540: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000452544: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000452548: 30241C90
	v_div_scale_f32 v37, s8, v16, v20, v16                     // 00000045254C: D6FC0825 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000452554: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000452558: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 00000045255C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000452560: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000452568: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 00000045256C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000452574: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 00000045257C: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000452580: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000452584: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 00000045258C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000452594: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000452598: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000045259C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 0000004525A0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004525AC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 0000004525B0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 0000004525B8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004525C0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 0000004525C4: 7E2C4B16
	v_div_scale_f32 v35, s7, v18, v21, v18                     // 0000004525C8: D6FC0723 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 0000004525D0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000004525D4: BF870313
	v_rcp_f32_e32 v30, v25                                     // 0000004525D8: 7E3C5519
	v_add_f32_e32 v22, 1.0, v22                                // 0000004525DC: 062C2CF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004525E0: BF870115
	v_fma_f32 v38, -v25, v30, 1.0                              // 0000004525E4: D6130026 23CA3D19
	v_div_scale_f32 v27, null, v22, v22, v14                   // 0000004525EC: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s9, v14, v22, v14                     // 0000004525F4: D6FC0924 043A2D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004525FC: BF870193
	v_fmac_f32_e32 v30, v38, v30                               // 000000452600: 563C3D26
	v_rcp_f32_e32 v31, v27                                     // 000000452604: 7E3E551B
	v_mul_f32_e32 v38, v33, v26                                // 000000452608: 104C3521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000045260C: BF870291
	v_fma_f32 v41, -v23, v38, v33                              // 000000452610: D6130029 24864D17
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000452618: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452620: BF870091
	v_dual_fmac_f32 v38, v41, v26 :: v_dual_fmac_f32 v31, v34, v31// 000000452624: C8003529 261E3F22
	v_fma_f32 v23, -v23, v38, v33                              // 00000045262C: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452634: BF870092
	v_dual_mul_f32 v34, v37, v28 :: v_dual_mul_f32 v45, v36, v31// 000000452638: C8C63925 222C3F24
	v_fma_f32 v46, -v24, v34, v37                              // 000000452640: D613002E 24964518
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000452648: BF870092
	v_fma_f32 v41, -v27, v45, v36                              // 00000045264C: D6130029 24925B1B
	v_dual_fmac_f32 v34, v46, v28 :: v_dual_fmac_f32 v45, v41, v31// 000000452654: C800392E 222C3F29
	v_div_fmas_f32 v23, v23, v26, v38                          // 00000045265C: D6370017 049A3517
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000452664: BF870122
	v_fma_f32 v24, -v24, v34, v37                              // 000000452668: D6130018 24964518
	s_mov_b32 vcc_lo, s8                                       // 000000452670: BEEA0008
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000452674: D627000D 04362717
	s_delay_alu instid0(VALU_DEP_2)                            // 00000045267C: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000452680: D6370018 048A3918
	s_mov_b32 vcc_lo, s7                                       // 000000452688: BEEA0007
	v_fma_f32 v23, -v27, v45, v36                              // 00000045268C: D6130017 24925B1B
	s_mov_b32 s7, 0                                            // 000000452694: BE870080
	v_dual_mul_f32 v13, v13, v39 :: v_dual_mul_f32 v40, v35, v30// 000000452698: C8C64F0D 0D283D23
	v_div_fixup_f32 v16, v24, v20, v16                         // 0000004526A0: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 0000004526A8: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000004526AC: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004526B4: BF870134
	.long 0x7e3a398d                                           // 0000004526B8: 7E3A398D
	v_fma_f32 v47, -v25, v40, v35                              // 0000004526BC: D613002F 248E5119
	v_mul_f32_e32 v6, v16, v6                                  // 0000004526C4: 100C0D10
	v_fmac_f32_e32 v40, v47, v30                               // 0000004526C8: 56503D2F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004526CC: BF870112
	.long 0x7e403986                                           // 0000004526D0: 7E403986
	v_fma_f32 v25, -v25, v40, v35                              // 0000004526D4: D6130019 248E5119
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004526DC: BF870131
	v_div_fmas_f32 v19, v25, v30, v40                          // 0000004526E0: D6370013 04A23D19
	s_mov_b32 vcc_lo, s9                                       // 0000004526E8: BEEA0009
	v_div_fmas_f32 v16, v23, v31, v45                          // 0000004526EC: D6370010 04B63F17
	v_div_fixup_f32 v18, v19, v21, v18                         // 0000004526F4: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004526FC: BF8701A2
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000452700: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000452708: 36203A81
	v_mul_f32_e32 v18, v18, v20                                // 00000045270C: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000452710: BF870193
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000452714: C8E40F0E 07144081
	v_add3_u32 v13, v13, v16, 0x7fff                           // 00000045271C: D655000D 03FE210D 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000452728: BF870193
	v_bfe_u32 v19, v18, 16, 1                                  // 00000045272C: D6100013 02052112
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000452734: D6550006 03FE2906 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000452740: BF870214
	v_bfe_u32 v16, v7, 16, 1                                   // 000000452744: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000045274C: 361A1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000452754: BF870214
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000452758: D655000E 03FE2712 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000452764: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045276C: BF870194
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000452770: D6550007 03FE2107 00007FFF
	v_and_b32_e32 v18, 0xffff0000, v14                         // 00000045277C: 36241CFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000452784: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000452788: CC20080E 8A021B11
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000452790: CC200010 8A020D11
	s_waitcnt vmcnt(0)                                         // 000000452798: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 00000045279C: CC20000D 8A02250F
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000004527A4: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000004527AC: 916A077E
	s_cbranch_vccnz 65131                                      // 0000004527B0: BFA4FE6B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004527B4: BF8700A3
	.long 0xd73c0004                                           // 0000004527B8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004527BC: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000004527C0: BF89FC07
	.long 0xd7006a04                                           // 0000004527C4: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000004527C8: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004527CC: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000004527D0: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000004527D8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004527DC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004527E0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004527E4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004527EC: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000004527F0: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000004527F4: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 0000004527FC: DC560000 047C0004
	s_clause 0x1                                               // 000000452804: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000452808: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000452810: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000452818: BF890BF7
	.long 0x7e0e3904                                           // 00000045281C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000452820: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000452828: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045282C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000452830: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000452834: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000452838: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000452840: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000452844: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 00000045284C: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000452854: 361E0AFF FFFF0000
	s_branch 65088                                             // 00000045285C: BFA0FE40 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000452860: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000452864: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 000000452868: 8C7E237E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000045286C: 938AFF0B 0001001C
	v_mad_u32_u24 v10, v44, 24, 0x2f0                          // 000000452874: D60B000A 03FD312C 000002F0
	s_lshr_b64 s[0:1], s[10:11], 29                            // 000000452880: 85809D0A
	s_lshr_b32 s1, s34, 28                                     // 000000452884: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000452888: 81008700
	s_add_i32 s1, s25, s1                                      // 00000045288C: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000452890: 86008300
	v_lshrrev_b32_e32 v1, 5, v10                               // 000000452894: 32021485
	.long 0xd72c0007                                           // 000000452898: D72C0007
	v_cndmask_b32_e32 v1, s0, v42, vcc_lo                      // 00000045289C: 02025400
	s_ashr_i32 s1, s1, 4                                       // 0000004528A0: 86018401
	s_lshl_b32 s3, s11, 3                                      // 0000004528A4: 8403830B
	s_lshl_b32 s5, s33, 3                                      // 0000004528A8: 84058321
	s_mul_i32 s7, s1, s2                                       // 0000004528AC: 96070201
	s_ashr_i32 s6, s5, 31                                      // 0000004528B0: 86069F05
	v_subrev_nc_u32_e32 v1, 24, v1                             // 0000004528B4: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v44                            // 0000004528B8: 7C945880
	v_add_nc_u32_e32 v2, s0, v7                                // 0000004528BC: 4A040E00
	s_mul_hi_i32 s0, s1, s2                                    // 0000004528C0: 97000201
	s_add_u32 s1, s7, s5                                       // 0000004528C4: 80010507
	s_addc_u32 s0, s0, s6                                      // 0000004528C8: 82000600
	s_mul_hi_u32 s5, s1, 0x300                                 // 0000004528CC: 9685FF01 00000300
	v_min_i32_e32 v45, s3, v2                                  // 0000004528D4: 225A0403
	s_mul_i32 s3, s0, 0x300                                    // 0000004528D8: 9603FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000004528E0: B8010300
	v_cndmask_b32_e64 v5, v1, 23, vcc_lo                       // 0000004528E4: D5010005 01A92F01
	v_add_nc_u32_e32 v11, 8, v10                               // 0000004528EC: 4A161488
	.long 0xd4410000                                           // 0000004528F0: D4410000
	v_cndmask_b32_e32 v1, v7, v45, vcc_lo                      // 0000004528F4: 02025B07
	s_add_i32 s5, s5, s3                                       // 0000004528F8: 81050305
	s_waitcnt lgkmcnt(0)                                       // 0000004528FC: BF89FC07
	s_add_u32 s6, s28, s1                                      // 000000452900: 8006011C
	s_addc_u32 s7, s29, s5                                     // 000000452904: 8207051D
	s_barrier                                                  // 000000452908: BFBD0000
	buffer_gl0_inv                                             // 00000045290C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000452914: BE832000
	s_cbranch_execz 122                                        // 000000452918: BFA5007A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb04>
	v_lshrrev_b32_e32 v1, 5, v11                               // 00000045291C: 32021685
	.long 0xd4440001                                           // 000000452920: D4440001
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 000000452924: 02020A97
	v_mad_i64_i32 v[3:4], null, 0x300, v7, s[6:7]              // 000000452928: D6FF7C03 001A0EFF 00000300
	v_mov_b32_e32 v6, 0                                        // 000000452934: 7E0C0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000452938: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000045293C: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 000000452940: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045294C: BF870193
	.long 0xd73c000c                                           // 000000452950: D73C000C
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000452954: 02020A82
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 000000452958: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000452960: BF870113
	v_add_nc_u32_e32 v9, v2, v5                                // 000000452964: 4A120B02
	.long 0xd4440001                                           // 000000452968: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 00000045296C: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000452970: BF870112
	v_lshlrev_b32_e32 v14, 24, v9                              // 000000452974: 301C1298
	v_cndmask_b32_e64 v15, 0xe9, 1, s1                         // 000000452978: D501000F 000502FF 000000E9
	.long 0xd700010c                                           // 000000452984: D700010C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 000000452988: 02021903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045298C: BF870191
	v_add_co_ci_u32_e64 v13, null, v4, v13, s1                 // 000000452990: D5207C0D 00061B04
	v_add_nc_u32_e32 v16, v15, v1                              // 000000452998: 4A20030F
	v_mov_b32_e32 v2, v6                                       // 00000045299C: 7E040306
	v_bfe_i32 v6, v9, 7, 1                                     // 0000004529A0: D6110006 02050F09
	v_ashrrev_i32_e32 v9, 22, v14                              // 0000004529A8: 34121C96
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004529AC: BF870214
	v_lshlrev_b32_e32 v17, 24, v16                             // 0000004529B0: 30222098
	.long 0xd73c0001                                           // 0000004529B4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000004529B8: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004529BC: BF870193
	.long 0xd700010e                                           // 0000004529C0: D700010E
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004529C4: 02021303
	v_ashrrev_i32_e32 v9, 22, v17                              // 0000004529C8: 34122296
	v_add_co_ci_u32_e64 v15, null, v4, v6, s1                  // 0000004529CC: D5207C0F 00060D04
	v_bfe_i32 v6, v16, 7, 1                                    // 0000004529D4: D6110006 02050F10
	.long 0xd7000110                                           // 0000004529DC: D7000110
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000004529E0: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004529E4: BF8700A1
	v_add_co_ci_u32_e64 v17, null, v4, v2, s1                  // 0000004529E8: D5207C11 00060504
	.long 0xd700012e                                           // 0000004529F0: D700012E
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 0000004529F4: 02021303
	v_add_co_ci_u32_e64 v47, null, v4, v6, s1                  // 0000004529F8: D5207C2F 00060D04
	s_clause 0x1f                                              // 000000452A00: BF85001F
	global_load_b32 v2, v[12:13], off                          // 000000452A04: DC520000 027C000C
	global_load_b32 v39, v[12:13], off offset:96               // 000000452A0C: DC520060 277C000C
	global_load_b32 v35, v[12:13], off offset:192              // 000000452A14: DC5200C0 237C000C
	global_load_b32 v31, v[12:13], off offset:288              // 000000452A1C: DC520120 1F7C000C
	global_load_b32 v27, v[12:13], off offset:384              // 000000452A24: DC520180 1B7C000C
	global_load_b32 v23, v[12:13], off offset:480              // 000000452A2C: DC5201E0 177C000C
	global_load_b32 v19, v[12:13], off offset:576              // 000000452A34: DC520240 137C000C
	global_load_b32 v13, v[12:13], off offset:672              // 000000452A3C: DC5202A0 0D7C000C
	global_load_b32 v1, v[14:15], off                          // 000000452A44: DC520000 017C000E
	global_load_b32 v38, v[14:15], off offset:96               // 000000452A4C: DC520060 267C000E
	global_load_b32 v34, v[14:15], off offset:192              // 000000452A54: DC5200C0 227C000E
	global_load_b32 v30, v[14:15], off offset:288              // 000000452A5C: DC520120 1E7C000E
	global_load_b32 v26, v[14:15], off offset:384              // 000000452A64: DC520180 1A7C000E
	global_load_b32 v22, v[14:15], off offset:480              // 000000452A6C: DC5201E0 167C000E
	global_load_b32 v18, v[14:15], off offset:576              // 000000452A74: DC520240 127C000E
	global_load_b32 v12, v[14:15], off offset:672              // 000000452A7C: DC5202A0 0C7C000E
	global_load_b32 v4, v[16:17], off                          // 000000452A84: DC520000 047C0010
	global_load_b32 v41, v[16:17], off offset:96               // 000000452A8C: DC520060 297C0010
	global_load_b32 v37, v[16:17], off offset:192              // 000000452A94: DC5200C0 257C0010
	global_load_b32 v33, v[16:17], off offset:288              // 000000452A9C: DC520120 217C0010
	global_load_b32 v29, v[16:17], off offset:384              // 000000452AA4: DC520180 1D7C0010
	global_load_b32 v25, v[16:17], off offset:480              // 000000452AAC: DC5201E0 197C0010
	global_load_b32 v21, v[16:17], off offset:576              // 000000452AB4: DC520240 157C0010
	global_load_b32 v15, v[16:17], off offset:672              // 000000452ABC: DC5202A0 0F7C0010
	global_load_b32 v3, v[46:47], off                          // 000000452AC4: DC520000 037C002E
	global_load_b32 v40, v[46:47], off offset:96               // 000000452ACC: DC520060 287C002E
	global_load_b32 v36, v[46:47], off offset:192              // 000000452AD4: DC5200C0 247C002E
	global_load_b32 v32, v[46:47], off offset:288              // 000000452ADC: DC520120 207C002E
	global_load_b32 v28, v[46:47], off offset:384              // 000000452AE4: DC520180 1C7C002E
	global_load_b32 v24, v[46:47], off offset:480              // 000000452AEC: DC5201E0 187C002E
	global_load_b32 v20, v[46:47], off offset:576              // 000000452AF4: DC520240 147C002E
	global_load_b32 v14, v[46:47], off offset:672              // 000000452AFC: DC5202A0 0E7C002E
	s_or_b32 exec_lo, exec_lo, s3                              // 000000452B04: 8C7E037E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v46, 0              // 000000452B08: CA100080 092E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 000000452B10: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 000000452B18: CA100080 31320080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000452B20: CA100080 34320080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 000000452B28: CA100080 37380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v54, 0             // 000000452B30: CA100080 35360080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v59, 0             // 000000452B38: CA100080 3A3A0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v60, 0             // 000000452B40: CA100080 393C0080
	s_ashr_i32 s3, s2, 31                                      // 000000452B48: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000452B4C: BE812000
	s_cbranch_execz 1146                                       // 000000452B50: BFA5047A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d3c>
	v_lshrrev_b32_e32 v6, 5, v11                               // 000000452B54: 320C1685
	v_or_b32_e32 v17, 4, v8                                    // 000000452B58: 38221084
	v_dual_mov_b32 v46, 23 :: v_dual_and_b32 v47, 16, v0       // 000000452B5C: CA240097 2E2E0090
	.long 0xd7030010                                           // 000000452B64: D7030010
	v_cndmask_b32_e32 v0, v5, v129, vcc_lo                     // 000000452B68: 02010305
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000452B6C: BF870244
	v_subrev_nc_u32_e32 v8, 24, v6                             // 000000452B70: 4E100C98
	v_mul_i32_i24_e32 v11, 0xffffffe8, v44                     // 000000452B74: 121658FF FFFFFFE8
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v10, 0x7e0, v10     // 000000452B7C: CA240080 090A14FF 000007E0
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000452B88: 340C0A9F
	v_cndmask_b32_e64 v8, v8, 23, vcc_lo                       // 000000452B8C: D5010008 01A92F08
	v_mad_u32_u24 v50, v17, 3, 0x2f0                           // 000000452B94: D60B0032 03FD0711 000002F0
	v_mul_i32_i24_e32 v51, -3, v17                             // 000000452BA0: 126622C3
	.long 0x7e22392e                                           // 000000452BA4: 7E22392E
	.long 0xd7624011                                           // 000000452BA8: D7624011
	v_cndmask_b32_e32 v1, 0xff, v16, vcc_lo                    // 000000452BAC: 020220FF 000000FF
	.long 0xd7034010                                           // 000000452BB4: D7034010
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 000000452BB8: 02010308
	v_add3_u32 v63, v11, v10, 0xfffffd34                       // 000000452BBC: D655003F 03FE150B FFFFFD34
	.long 0xd73c000a                                           // 000000452BC8: D73C000A
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000452BCC: 02020A82
	.long 0xd7040005                                           // 000000452BD0: D7040005
	v_cndmask_b32_e32 v1, v5, v17, vcc_lo                      // 000000452BD4: 02022305
	v_cmp_gt_u16_e32 vcc_lo, 24, v145/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 000000452BD8: 7C792298
	.long 0xd762102e                                           // 000000452BDC: D762102E
	v_cndmask_b32_e32 v1, 0xff, v16, vcc_lo                    // 000000452BE0: 020220FF 000000FF
	v_add_nc_u32_e32 v61, 1, v7                                // 000000452BE8: 4A7A0E81
	v_lshl_or_b32 v64, v7, 5, v47                              // 000000452BEC: D6560040 04BD0B07
	v_dual_mov_b32 v48, v9 :: v_dual_and_b32 v7, 0x7e0, v50    // 000000452BF4: CA240109 300664FF 000007E0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000452C00: BF870004
	.long 0xd43d0000                                           // 000000452C04: D43D0000
	v_cndmask_b32_e32 v1, 24, v46, vcc_lo                      // 000000452C08: 02025C98
	v_cndmask_b16 v5, v5, v16, vcc_lo                          // 000000452C0C: D65D0005 01AA2105
	v_mov_b32_e32 v50, v9                                      // 000000452C14: 7E640309
	v_sub_nc_u32_e32 v62, 0, v45                               // 000000452C18: 4C7C5A80
	v_mov_b32_e32 v46, v9                                      // 000000452C1C: 7E5C0309
	v_cndmask_b16 v6, 0, v16, s0                               // 000000452C20: D65D1006 00022080
	v_mov_b32_e32 v47, v9                                      // 000000452C28: 7E5E0309
	v_and_b32_e32 v5, 0xff, v5                                 // 000000452C2C: 360A0AFF 000000FF
	.long 0xd73c0010                                           // 000000452C34: D73C0010
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000452C38: 02021082
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000452C3C: BF870244
	v_dual_mov_b32 v49, v9 :: v_dual_and_b32 v6, 0xff, v6      // 000000452C40: CA240109 31060CFF 000000FF
	v_mov_b32_e32 v52, v9                                      // 000000452C4C: 7E680309
	v_add3_u32 v65, v51, v7, 0xfffffd34                        // 000000452C50: D6550041 03FE0F33 FFFFFD34
	v_dual_mov_b32 v51, v9 :: v_dual_lshlrev_b32 v66, 2, v5    // 000000452C5C: CA220109 33420A82
	v_lshlrev_b32_e32 v67, 2, v6                               // 000000452C64: 30860C82
	v_mov_b32_e32 v55, v9                                      // 000000452C68: 7E6E0309
	v_mov_b32_e32 v56, v9                                      // 000000452C6C: 7E700309
	v_mov_b32_e32 v53, v9                                      // 000000452C70: 7E6A0309
	v_mov_b32_e32 v54, v9                                      // 000000452C74: 7E6C0309
	v_mov_b32_e32 v58, v9                                      // 000000452C78: 7E740309
	v_mov_b32_e32 v59, v9                                      // 000000452C7C: 7E760309
	v_mov_b32_e32 v57, v9                                      // 000000452C80: 7E720309
	v_mov_b32_e32 v60, v9                                      // 000000452C84: 7E780309
	s_mov_b32 s5, 0                                            // 000000452C88: BE850080
	s_mov_b32 s0, 0xdcd12d                                     // 000000452C8C: BE8000FF 00DCD12D
	s_movk_i32 s8, 0x83                                        // 000000452C94: B0080083
	s_movk_i32 s9, 0x1eee                                      // 000000452C98: B0091EEE
	s_branch 970                                               // 000000452C9C: BFA003CA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1bc8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000452CA0: 8C7E0A7E
	s_waitcnt vmcnt(23)                                        // 000000452CA4: BF895FF7
	.long 0xd73d0064                                           // 000000452CA8: D73D0064
	v_cndmask_b32_e32 v1, v63, v1, vcc_lo                      // 000000452CAC: 0202033F
	s_waitcnt vmcnt(7)                                         // 000000452CB0: BF891FF7
	.long 0xd73d0065                                           // 000000452CB4: D73D0065
	v_cndmask_b32_e32 v1, v65, v3, vcc_lo                      // 000000452CB8: 02020741
	ds_load_b128 v[1:4], v64                                   // 000000452CBC: DBFC0000 01000040
	ds_load_b128 v[5:8], v64 offset:5120                       // 000000452CC4: DBFC1400 05000040
	.long 0xd73d0026                                           // 000000452CCC: D73D0026
	v_cndmask_b32_e32 v1, v63, v38, vcc_lo                     // 000000452CD0: 02024D3F
	s_waitcnt vmcnt(6)                                         // 000000452CD4: BF891BF7
	.long 0xd73d0027                                           // 000000452CD8: D73D0027
	v_cndmask_b32_e32 v1, v65, v40, vcc_lo                     // 000000452CDC: 02025141
	.long 0xd73d0022                                           // 000000452CE0: D73D0022
	v_cndmask_b32_e32 v1, v63, v34, vcc_lo                     // 000000452CE4: 0202453F
	v_bfe_u32 v102, v100, 9, 16                                // 000000452CE8: D6100066 02411364
	v_mul_u32_u24_e32 v108, s0, v102                           // 000000452CF0: 16D8CC00
	v_mul_u32_u24_e32 v102, s8, v102                           // 000000452CF4: 16CCCC08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000452CF8: BF870151
	v_lshl_add_u32 v102, v102, 24, v108                        // 000000452CFC: D6460066 05B13166
	v_bfe_u32 v104, v100, 3, 16                                // 000000452D04: D6100068 02410764
	v_bfe_u32 v103, v100, 6, 16                                // 000000452D0C: D6100067 02410D64
	v_mul_u32_u24_e32 v108, s0, v104                           // 000000452D14: 16D8D000
	v_mul_u32_u24_e32 v104, s8, v104                           // 000000452D18: 16D0D008
	v_lshl_add_u32 v104, v104, 24, v108                        // 000000452D1C: D6460068 05B13168
	v_mul_u32_u24_e32 v108, s0, v103                           // 000000452D24: 16D8CE00
	v_mul_u32_u24_e32 v103, s8, v103                           // 000000452D28: 16CECE08
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000452D2C: D6220066 03FD0166 00006400
	v_lshl_add_u32 v103, v103, 24, v108                        // 000000452D38: D6460067 05B13167
	v_bfe_u32 v105, v101, 9, 16                                // 000000452D40: D6100069 02411365
	v_sad_u8 v104, v104, 0, 0x6400                             // 000000452D48: D6220068 03FD0168 00006400
	v_bfe_u32 v106, v101, 6, 16                                // 000000452D54: D610006A 02410D65
	v_and_b32_e32 v102, 0xffff, v102                           // 000000452D5C: 36CCCCFF 0000FFFF
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000452D64: D6220067 03FD0167 00006400
	v_bfe_u32 v107, v101, 3, 16                                // 000000452D70: D610006B 02410765
	v_bfe_u32 v40, v38, 9, 16                                  // 000000452D78: D6100028 02411326
	v_bfe_u32 v41, v38, 6, 16                                  // 000000452D80: D6100029 02410D26
	s_waitcnt vmcnt(5)                                         // 000000452D88: BF8917F7
	.long 0xd73d0023                                           // 000000452D8C: D73D0023
	v_cndmask_b32_e32 v1, v65, v36, vcc_lo                     // 000000452D90: 02024941
	v_lshl_or_b32 v102, v103, 16, v102                         // 000000452D94: D6560066 05992167
	v_bfe_u32 v36, v34, 9, 16                                  // 000000452D9C: D6100024 02411322
	v_bfe_u32 v37, v34, 6, 16                                  // 000000452DA4: D6100025 02410D22
	.long 0xd73d001e                                           // 000000452DAC: D73D001E
	v_cndmask_b32_e32 v1, v63, v30, vcc_lo                     // 000000452DB0: 02023D3F
	s_waitcnt vmcnt(4)                                         // 000000452DB4: BF8913F7
	.long 0xd73d001f                                           // 000000452DB8: D73D001F
	v_cndmask_b32_e32 v1, v65, v32, vcc_lo                     // 000000452DBC: 02024141
	v_pk_fma_f16 v102, v102, s9, 0xc931 op_sel_hi:[1,0,0]      // 000000452DC0: CC0E0066 0BFC1366 0000C931
	v_and_b32_e32 v100, 0xffff, v100                           // 000000452DCC: 36C8C8FF 0000FFFF
	.long 0xd73d001a                                           // 000000452DD4: D73D001A
	v_cndmask_b32_e32 v1, v63, v26, vcc_lo                     // 000000452DD8: 0202353F
	s_waitcnt vmcnt(3)                                         // 000000452DDC: BF890FF7
	.long 0xd73d001b                                           // 000000452DE0: D73D001B
	v_cndmask_b32_e32 v1, v65, v28, vcc_lo                     // 000000452DE4: 02023941
	v_bfe_u32 v32, v30, 9, 16                                  // 000000452DE8: D6100020 0241131E
	s_waitcnt lgkmcnt(0)                                       // 000000452DF0: BF89FC07
	v_dot2acc_f32_f16 v57, v102, v5                            // 000000452DF4: 04720B66
	v_mul_u32_u24_e32 v108, s0, v100                           // 000000452DF8: 16D8C800
	v_mul_u32_u24_e32 v100, s8, v100                           // 000000452DFC: 16C8C808
	v_lshl_add_u32 v100, v100, 24, v108                        // 000000452E00: D6460064 05B13164
	v_mul_u32_u24_e32 v108, s0, v105                           // 000000452E08: 16D8D200
	v_mul_u32_u24_e32 v105, s8, v105                           // 000000452E0C: 16D2D208
	v_lshl_add_u32 v105, v105, 24, v108                        // 000000452E10: D6460069 05B13169
	v_and_b32_e32 v104, 0xffff, v104                           // 000000452E18: 36D0D0FF 0000FFFF
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000452E20: D6220064 03FD0164 00006400
	v_mul_u32_u24_e32 v108, s0, v106                           // 000000452E2C: 16D8D400
	v_mul_u32_u24_e32 v106, s8, v106                           // 000000452E30: 16D4D408
	v_sad_u8 v105, v105, 0, 0x6400                             // 000000452E34: D6220069 03FD0169 00006400
	v_lshl_add_u32 v106, v106, 24, v108                        // 000000452E40: D646006A 05B1316A
	v_lshl_or_b32 v100, v100, 16, v104                         // 000000452E48: D6560064 05A12164
	v_mul_u32_u24_e32 v108, s0, v107                           // 000000452E50: 16D8D600
	v_mul_u32_u24_e32 v107, s8, v107                           // 000000452E54: 16D6D608
	v_and_b32_e32 v103, 0xffff, v105                           // 000000452E58: 36CED2FF 0000FFFF
	v_sad_u8 v104, v106, 0, 0x6400                             // 000000452E60: D6220068 03FD016A 00006400
	v_pk_fma_f16 v100, v100, s9, 0xc931 op_sel_hi:[1,0,0]      // 000000452E6C: CC0E0064 0BFC1364 0000C931
	v_dot2acc_f32_f16 v60, v102, v1                            // 000000452E78: 04780366
	v_lshl_add_u32 v107, v107, 24, v108                        // 000000452E7C: D646006B 05B1316B
	v_and_b32_e32 v101, 0xffff, v101                           // 000000452E84: 36CACAFF 0000FFFF
	v_lshl_or_b32 v103, v104, 16, v103                         // 000000452E8C: D6560067 059D2168
	v_dot2acc_f32_f16 v57, v100, v6                            // 000000452E94: 04720D64
	v_dot2acc_f32_f16 v60, v100, v2                            // 000000452E98: 04780564
	v_mul_u32_u24_e32 v106, s0, v101                           // 000000452E9C: 16D4CA00
	v_mul_u32_u24_e32 v101, s8, v101                           // 000000452EA0: 16CACA08
	v_sad_u8 v105, v107, 0, 0x6400                             // 000000452EA4: D6220069 03FD016B 00006400
	v_lshl_add_u32 v101, v101, 24, v106                        // 000000452EB0: D6460065 05A93165
	v_pk_fma_f16 v103, v103, s9, 0xc931 op_sel_hi:[1,0,0]      // 000000452EB8: CC0E0067 0BFC1367 0000C931
	v_bfe_u32 v100, v38, 3, 16                                 // 000000452EC4: D6100064 02410726
	v_and_b32_e32 v38, 0xffff, v38                             // 000000452ECC: 364C4CFF 0000FFFF
	v_bfe_u32 v102, v39, 9, 16                                 // 000000452ED4: D6100066 02411327
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000452EDC: D6220065 03FD0165 00006400
	v_dual_dot2acc_f32_f16 v57, v103, v7 :: v_dual_and_b32 v104, 0xffff, v105// 000000452EE8: CB240F67 3968D2FF 0000FFFF
	v_mul_u32_u24_e32 v105, s0, v38                            // 000000452EF4: 16D24C00
	v_mul_u32_u24_e32 v38, s8, v38                             // 000000452EF8: 164C4C08
	v_lshl_add_u32 v38, v38, 24, v105                          // 000000452EFC: D6460026 05A53126
	v_dot2acc_f32_f16 v60, v103, v3                            // 000000452F04: 04780767
	v_lshl_or_b32 v101, v101, 16, v104                         // 000000452F08: D6560065 05A12165
	v_mul_u32_u24_e32 v104, s0, v100                           // 000000452F10: 16D0C800
	v_mul_u32_u24_e32 v100, s8, v100                           // 000000452F14: 16C8C808
	v_lshl_add_u32 v100, v100, 24, v104                        // 000000452F18: D6460064 05A13164
	v_mul_u32_u24_e32 v104, s0, v41                            // 000000452F20: 16D05200
	v_mul_u32_u24_e32 v41, s8, v41                             // 000000452F24: 16525208
	v_lshl_add_u32 v41, v41, 24, v104                          // 000000452F28: D6460029 05A13129
	v_bfe_u32 v104, v39, 3, 16                                 // 000000452F30: D6100068 02410727
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000452F38: D6220064 03FD0164 00006400
	v_mul_u32_u24_e32 v105, s0, v104                           // 000000452F44: 16D2D000
	v_mul_u32_u24_e32 v104, s8, v104                           // 000000452F48: 16D0D008
	s_delay_alu instid0(VALU_DEP_2)                            // 000000452F4C: BF870002
	v_lshl_add_u32 v104, v104, 24, v105                        // 000000452F50: D6460068 05A53168
	v_mul_u32_u24_e32 v103, s0, v40                            // 000000452F58: 16CE5000
	v_mul_u32_u24_e32 v40, s8, v40                             // 000000452F5C: 16505008
	v_lshl_add_u32 v40, v40, 24, v103                          // 000000452F60: D6460028 059D3128
	v_bfe_u32 v103, v39, 6, 16                                 // 000000452F68: D6100067 02410D27
	v_and_b32_e32 v39, 0xffff, v39                             // 000000452F70: 364E4EFF 0000FFFF
	v_and_b32_e32 v100, 0xffff, v100                           // 000000452F78: 36C8C8FF 0000FFFF
	v_mul_u32_u24_e32 v105, s0, v103                           // 000000452F80: 16D2CE00
	v_mul_u32_u24_e32 v103, s8, v103                           // 000000452F84: 16CECE08
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000452F88: D6220026 03FD0126 00006400
	v_lshl_add_u32 v103, v103, 24, v105                        // 000000452F94: D6460067 05A53167
	v_mul_u32_u24_e32 v105, s0, v39                            // 000000452F9C: 16D24E00
	v_mul_u32_u24_e32 v39, s8, v39                             // 000000452FA0: 164E4E08
	v_sad_u8 v104, v104, 0, 0x6400                             // 000000452FA4: D6220068 03FD0168 00006400
	v_lshl_add_u32 v39, v39, 24, v105                          // 000000452FB0: D6460027 05A53127
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000452FB8: D6220028 03FD0128 00006400
	v_lshl_or_b32 v38, v38, 16, v100                           // 000000452FC4: D6560026 05912126
	v_mul_u32_u24_e32 v106, s0, v102                           // 000000452FCC: 16D4CC00
	v_mul_u32_u24_e32 v102, s8, v102                           // 000000452FD0: 16CCCC08
	v_lshl_add_u32 v102, v102, 24, v106                        // 000000452FD4: D6460066 05A93166
	v_and_b32_e32 v104, 0xffff, v104                           // 000000452FDC: 36D0D0FF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000452FE4: D6220027 03FD0127 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000452FF0: D6220029 03FD0129 00006400
	v_pk_fma_f16 v38, v38, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000452FFC: CC0E0026 0BFC1326 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000453008: 365050FF 0000FFFF
	v_sad_u8 v102, v102, 0, 0x6400                             // 000000453010: D6220066 03FD0166 00006400
	v_lshl_or_b32 v39, v39, 16, v104                           // 00000045301C: D6560027 05A12127
	v_sad_u8 v103, v103, 0, 0x6400                             // 000000453024: D6220067 03FD0167 00006400
	v_pk_fma_f16 v101, v101, s9, 0xc931 op_sel_hi:[1,0,0]      // 000000453030: CC0E0065 0BFC1365 0000C931
	v_lshl_or_b32 v40, v41, 16, v40                            // 00000045303C: D6560028 04A12129
	v_bfe_u32 v100, v35, 9, 16                                 // 000000453044: D6100064 02411323
	v_pk_fma_f16 v39, v39, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000045304C: CC0E0027 0BFC1327 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000453058: BF870214
	v_dual_dot2acc_f32_f16 v57, v101, v8 :: v_dual_and_b32 v102, 0xffff, v102// 00000045305C: CB241165 3966CCFF 0000FFFF
	v_pk_fma_f16 v40, v40, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453068: CC0E0028 0BFC1328 0000C931
	v_bfe_u32 v33, v30, 6, 16                                  // 000000453074: D6100021 02410D1E
	v_bfe_u32 v28, v26, 9, 16                                  // 00000045307C: D610001C 0241131A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000453084: BF870004
	v_lshl_or_b32 v41, v103, 16, v102                          // 000000453088: D6560029 05992167
	v_mul_u32_u24_e32 v103, s0, v36                            // 000000453090: 16CE4800
	v_mul_u32_u24_e32 v36, s8, v36                             // 000000453094: 16484808
	v_lshl_add_u32 v36, v36, 24, v103                          // 000000453098: D6460024 059D3124
	v_dot2acc_f32_f16 v59, v40, v1                             // 0000004530A0: 04760328
	v_dot2acc_f32_f16 v58, v40, v5                             // 0000004530A4: 04740B28
	v_bfe_u32 v40, v34, 3, 16                                  // 0000004530A8: D6100028 02410722
	v_mul_u32_u24_e32 v103, s0, v40                            // 0000004530B0: 16CE5000
	v_mul_u32_u24_e32 v40, s8, v40                             // 0000004530B4: 16505008
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004530B8: BF870001
	v_lshl_add_u32 v40, v40, 24, v103                          // 0000004530BC: D6460028 059D3128
	v_mul_u32_u24_e32 v103, s0, v37                            // 0000004530C4: 16CE4A00
	v_mul_u32_u24_e32 v37, s8, v37                             // 0000004530C8: 164A4A08
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000004530CC: D6220024 03FD0124 00006400
	v_lshl_add_u32 v37, v37, 24, v103                          // 0000004530D8: D6460025 059D3125
	v_and_b32_e32 v34, 0xffff, v34                             // 0000004530E0: 364444FF 0000FFFF
	v_mul_u32_u24_e32 v103, s0, v34                            // 0000004530E8: 16CE4400
	v_mul_u32_u24_e32 v34, s8, v34                             // 0000004530EC: 16444408
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004530F0: BF870001
	v_lshl_add_u32 v34, v34, 24, v103                          // 0000004530F4: D6460022 059D3122
	v_mul_u32_u24_e32 v103, s0, v100                           // 0000004530FC: 16CEC800
	v_mul_u32_u24_e32 v100, s8, v100                           // 000000453100: 16C8C808
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000453104: D6220028 03FD0128 00006400
	v_lshl_add_u32 v100, v100, 24, v103                        // 000000453110: D6460064 059D3164
	v_and_b32_e32 v36, 0xffff, v36                             // 000000453118: 364848FF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000453120: D6220025 03FD0125 00006400
	v_dot2acc_f32_f16 v60, v101, v4                            // 00000045312C: 04780965
	v_bfe_u32 v101, v35, 6, 16                                 // 000000453130: D6100065 02410D23
	v_mul_u32_u24_e32 v103, s0, v101                           // 000000453138: 16CECA00
	v_mul_u32_u24_e32 v101, s8, v101                           // 00000045313C: 16CACA08
	v_and_b32_e32 v40, 0xffff, v40                             // 000000453140: 365050FF 0000FFFF
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000453148: D6220022 03FD0122 00006400
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000453154: D6220064 03FD0164 00006400
	v_lshl_add_u32 v101, v101, 24, v103                        // 000000453160: D6460065 059D3165
	v_lshl_or_b32 v36, v37, 16, v36                            // 000000453168: D6560024 04912125
	v_pk_fma_f16 v41, v41, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453170: CC0E0029 0BFC1329 0000C931
	v_lshl_or_b32 v34, v34, 16, v40                            // 00000045317C: D6560022 04A12122
	v_bfe_u32 v102, v35, 3, 16                                 // 000000453184: D6100066 02410723
	v_sad_u8 v40, v101, 0, 0x6400                              // 00000045318C: D6220028 03FD0165 00006400
	v_pk_fma_f16 v36, v36, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453198: CC0E0024 0BFC1324 0000C931
	v_and_b32_e32 v37, 0xffff, v100                            // 0000004531A4: 364AC8FF 0000FFFF
	v_pk_fma_f16 v34, v34, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004531AC: CC0E0022 0BFC1322 0000C931
	v_and_b32_e32 v35, 0xffff, v35                             // 0000004531B8: 364646FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004531C0: BF870214
	v_dual_dot2acc_f32_f16 v59, v38, v2 :: v_dual_dot2acc_f32_f16 v54, v36, v1// 0000004531C4: CB180526 3B360324
	v_lshl_or_b32 v37, v40, 16, v37                            // 0000004531CC: D6560025 04952128
	v_dual_dot2acc_f32_f16 v53, v36, v5 :: v_dual_dot2acc_f32_f16 v58, v38, v6// 0000004531D4: CB180B24 353A0D26
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004531DC: BF870223
	v_dot2acc_f32_f16 v59, v41, v3                             // 0000004531E0: 04760729
	v_bfe_u32 v36, v31, 9, 16                                  // 0000004531E4: D6100024 0241131F
	v_pk_fma_f16 v37, v37, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004531EC: CC0E0025 0BFC1325 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004531F8: BF870004
	v_dot2acc_f32_f16 v53, v34, v6                             // 0000004531FC: 046A0D22
	v_mul_u32_u24_e32 v103, s0, v102                           // 000000453200: 16CECC00
	v_dot2acc_f32_f16 v59, v39, v4                             // 000000453204: 04760927
	v_mul_u32_u24_e32 v102, s8, v102                           // 000000453208: 16CCCC08
	v_lshl_add_u32 v102, v102, 24, v103                        // 00000045320C: D6460066 059D3166
	v_dual_dot2acc_f32_f16 v53, v37, v7 :: v_dual_dot2acc_f32_f16 v54, v34, v2// 000000453214: CB180F25 35360522
	v_bfe_u32 v34, v30, 3, 16                                  // 00000045321C: D6100022 0241071E
	v_mul_u32_u24_e32 v38, s0, v34                             // 000000453224: 164C4400
	v_mul_u32_u24_e32 v34, s8, v34                             // 000000453228: 16444408
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045322C: BF870001
	v_lshl_add_u32 v34, v34, 24, v38                           // 000000453230: D6460022 04993122
	v_dot2acc_f32_f16 v54, v37, v3                             // 000000453238: 046C0725
	v_mul_u32_u24_e32 v37, s0, v32                             // 00000045323C: 164A4000
	v_mul_u32_u24_e32 v32, s8, v32                             // 000000453240: 16404008
	v_mul_u32_u24_e32 v38, s0, v33                             // 000000453244: 164C4200
	v_mul_u32_u24_e32 v33, s8, v33                             // 000000453248: 16424208
	v_lshl_add_u32 v32, v32, 24, v37                           // 00000045324C: D6460020 04953120
	v_bfe_u32 v37, v31, 6, 16                                  // 000000453254: D6100025 02410D1F
	v_lshl_add_u32 v33, v33, 24, v38                           // 00000045325C: D6460021 04993121
	v_bfe_u32 v38, v31, 3, 16                                  // 000000453264: D6100026 0241071F
	v_and_b32_e32 v31, 0xffff, v31                             // 00000045326C: 363E3EFF 0000FFFF
	v_dot2acc_f32_f16 v58, v41, v7                             // 000000453274: 04740F29
	v_and_b32_e32 v30, 0xffff, v30                             // 000000453278: 363C3CFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000453280: D6220020 03FD0120 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000045328C: D6220022 03FD0122 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000453298: D6220021 03FD0121 00006400
	v_dot2acc_f32_f16 v58, v39, v8                             // 0000004532A4: 04741127
	v_mul_u32_u24_e32 v39, s0, v30                             // 0000004532A8: 164E3C00
	v_mul_u32_u24_e32 v30, s8, v30                             // 0000004532AC: 163C3C08
	v_lshl_add_u32 v30, v30, 24, v39                           // 0000004532B0: D646001E 049D311E
	v_mul_u32_u24_e32 v39, s0, v38                             // 0000004532B8: 164E4C00
	v_mul_u32_u24_e32 v38, s8, v38                             // 0000004532BC: 164C4C08
	v_lshl_add_u32 v38, v38, 24, v39                           // 0000004532C0: D6460026 049D3126
	v_mul_u32_u24_e32 v39, s0, v37                             // 0000004532C8: 164E4A00
	v_mul_u32_u24_e32 v37, s8, v37                             // 0000004532CC: 164A4A08
	v_lshl_add_u32 v37, v37, 24, v39                           // 0000004532D0: D6460025 049D3125
	v_mul_u32_u24_e32 v39, s0, v31                             // 0000004532D8: 164E3E00
	v_mul_u32_u24_e32 v31, s8, v31                             // 0000004532DC: 163E3E08
	v_sad_u8 v38, v38, 0, 0x6400                               // 0000004532E0: D6220026 03FD0126 00006400
	v_lshl_add_u32 v31, v31, 24, v39                           // 0000004532EC: D646001F 049D311F
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004532F4: 364040FF 0000FFFF
	v_sad_u8 v30, v30, 0, 0x6400                               // 0000004532FC: D622001E 03FD011E 00006400
	v_mul_u32_u24_e32 v101, s0, v35                            // 000000453308: 16CA4600
	v_and_b32_e32 v38, 0xffff, v38                             // 00000045330C: 364C4CFF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000453314: D622001F 03FD011F 00006400
	v_lshl_or_b32 v32, v33, 16, v32                            // 000000453320: D6560020 04812121
	v_mul_u32_u24_e32 v35, s8, v35                             // 000000453328: 16464608
	v_sad_u8 v100, v102, 0, 0x6400                             // 00000045332C: D6220064 03FD0166 00006400
	v_lshl_add_u32 v35, v35, 24, v101                          // 000000453338: D6460023 05953123
	v_lshl_or_b32 v31, v31, 16, v38                            // 000000453340: D656001F 0499211F
	v_pk_fma_f16 v32, v32, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453348: CC0E0020 0BFC1320 0000C931
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000453354: D6220025 03FD0125 00006400
	.long 0xd73d0016                                           // 000000453360: D73D0016
	v_cndmask_b32_e32 v1, v63, v22, vcc_lo                     // 000000453364: 02022D3F
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000453368: D6220023 03FD0123 00006400
	v_pk_fma_f16 v31, v31, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453374: CC0E001F 0BFC131F 0000C931
	v_dual_dot2acc_f32_f16 v55, v32, v5 :: v_dual_and_b32 v34, 0xffff, v34// 000000453380: CB240B20 372244FF 0000FFFF
	s_waitcnt vmcnt(2)                                         // 00000045338C: BF890BF7
	.long 0xd73d0017                                           // 000000453390: D73D0017
	v_cndmask_b32_e32 v1, v65, v24, vcc_lo                     // 000000453394: 02023141
	v_dot2acc_f32_f16 v56, v32, v1                             // 000000453398: 04700320
	v_bfe_u32 v32, v26, 3, 16                                  // 00000045339C: D6100020 0241071A
	v_lshl_or_b32 v30, v30, 16, v34                            // 0000004533A4: D656001E 0489211E
	v_bfe_u32 v29, v26, 6, 16                                  // 0000004533AC: D610001D 02410D1A
	v_and_b32_e32 v26, 0xffff, v26                             // 0000004533B4: 363434FF 0000FFFF
	v_bfe_u32 v34, v27, 9, 16                                  // 0000004533BC: D6100022 0241131B
	.long 0xd73d0012                                           // 0000004533C4: D73D0012
	v_cndmask_b32_e32 v1, v63, v18, vcc_lo                     // 0000004533C8: 0202253F
	v_pk_fma_f16 v30, v30, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004533CC: CC0E001E 0BFC131E 0000C931
	v_and_b32_e32 v40, 0xffff, v100                            // 0000004533D8: 3650C8FF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 0000004533E0: BF8907F7
	.long 0xd73d0013                                           // 0000004533E4: D73D0013
	v_cndmask_b32_e32 v1, v65, v20, vcc_lo                     // 0000004533E8: 02022941
	.long 0xd73d000c                                           // 0000004533EC: D73D000C
	v_cndmask_b32_e32 v1, v63, v12, vcc_lo                     // 0000004533F0: 0202193F
	s_waitcnt vmcnt(0)                                         // 0000004533F4: BF8903F7
	.long 0xd73d000d                                           // 0000004533F8: D73D000D
	v_cndmask_b32_e32 v1, v65, v14, vcc_lo                     // 0000004533FC: 02021D41
	v_dot2acc_f32_f16 v55, v30, v6                             // 000000453400: 046E0D1E
	v_lshl_or_b32 v35, v35, 16, v40                            // 000000453404: D6560023 04A12123
	v_mul_u32_u24_e32 v40, s0, v36                             // 00000045340C: 16504800
	v_mul_u32_u24_e32 v36, s8, v36                             // 000000453410: 16484808
	v_lshl_add_u32 v36, v36, 24, v40                           // 000000453414: D6460024 04A13124
	v_dot2acc_f32_f16 v56, v30, v2                             // 00000045341C: 0470051E
	v_pk_fma_f16 v35, v35, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453420: CC0E0023 0BFC1323 0000C931
	v_bfe_u32 v30, v23, 3, 16                                  // 00000045342C: D610001E 02410717
	v_bfe_u32 v20, v18, 9, 16                                  // 000000453434: D6100014 02411312
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000045343C: D6220024 03FD0124 00006400
	v_bfe_u32 v21, v18, 6, 16                                  // 000000453448: D6100015 02410D12
	v_dot2acc_f32_f16 v53, v35, v8                             // 000000453450: 046A1123
	v_bfe_u32 v14, v12, 9, 16                                  // 000000453454: D610000E 0241130C
	v_bfe_u32 v15, v12, 6, 16                                  // 00000045345C: D610000F 02410D0C
	v_and_b32_e32 v36, 0xffff, v36                             // 000000453464: 364848FF 0000FFFF
	v_add_nc_u32_e32 v64, 32, v64                              // 00000045346C: 4A8080A0
	v_mov_b32_e32 v40, v98                                     // 000000453470: 7E500362
	v_dual_mov_b32 v38, v88 :: v_dual_add_nc_u32 v61, 1, v61   // 000000453474: CA200158 263C7A81
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045347C: BF870004
	v_lshl_or_b32 v33, v37, 16, v36                            // 000000453480: D6560021 04912125
	v_mul_u32_u24_e32 v37, s0, v28                             // 000000453488: 164A3800
	v_mul_u32_u24_e32 v28, s8, v28                             // 00000045348C: 16383808
	v_lshl_add_u32 v28, v28, 24, v37                           // 000000453490: D646001C 0495311C
	v_mul_u32_u24_e32 v37, s0, v32                             // 000000453498: 164A4000
	v_mul_u32_u24_e32 v32, s8, v32                             // 00000045349C: 16404008
	v_lshl_add_u32 v32, v32, 24, v37                           // 0000004534A0: D6460020 04953120
	v_mul_u32_u24_e32 v37, s0, v29                             // 0000004534A8: 164A3A00
	v_mul_u32_u24_e32 v29, s8, v29                             // 0000004534AC: 163A3A08
	v_sad_u8 v28, v28, 0, 0x6400                               // 0000004534B0: D622001C 03FD011C 00006400
	v_lshl_add_u32 v29, v29, 24, v37                           // 0000004534BC: D646001D 0495311D
	v_mul_u32_u24_e32 v37, s0, v26                             // 0000004534C4: 164A3400
	v_mul_u32_u24_e32 v26, s8, v26                             // 0000004534C8: 16343408
	v_sad_u8 v32, v32, 0, 0x6400                               // 0000004534CC: D6220020 03FD0120 00006400
	v_lshl_add_u32 v26, v26, 24, v37                           // 0000004534D8: D646001A 0495311A
	v_and_b32_e32 v28, 0xffff, v28                             // 0000004534E0: 363838FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004534E8: D622001D 03FD011D 00006400
	v_mul_u32_u24_e32 v37, s0, v34                             // 0000004534F4: 164A4400
	v_and_b32_e32 v32, 0xffff, v32                             // 0000004534F8: 364040FF 0000FFFF
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000453500: D622001A 03FD011A 00006400
	v_mul_u32_u24_e32 v34, s8, v34                             // 00000045350C: 16444408
	v_lshl_or_b32 v28, v29, 16, v28                            // 000000453510: D656001C 0471211D
	v_lshl_add_u32 v34, v34, 24, v37                           // 000000453518: D6460022 04953122
	v_pk_fma_f16 v33, v33, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453520: CC0E0021 0BFC1321 0000C931
	v_lshl_or_b32 v26, v26, 16, v32                            // 00000045352C: D656001A 0481211A
	v_bfe_u32 v36, v27, 3, 16                                  // 000000453534: D6100024 0241071B
	v_pk_fma_f16 v28, v28, s9, 0xc931 op_sel_hi:[1,0,0]        // 00000045353C: CC0E001C 0BFC131C 0000C931
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000453548: D6220022 03FD0122 00006400
	v_dot2acc_f32_f16 v55, v33, v7                             // 000000453554: 046E0F21
	v_pk_fma_f16 v26, v26, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453558: CC0E001A 0BFC131A 0000C931
	v_mov_b32_e32 v41, v94                                     // 000000453564: 7E52035E
	v_dot2acc_f32_f16 v51, v28, v1                             // 000000453568: 0466031C
	v_dual_dot2acc_f32_f16 v52, v28, v5 :: v_dual_and_b32 v29, 0xffff, v34// 00000045356C: CB240B1C 341C44FF 0000FFFF
	v_bfe_u32 v28, v22, 9, 16                                  // 000000453578: D610001C 02411316
	v_mul_u32_u24_e32 v24, s0, v28                             // 000000453580: 16303800
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000453584: BF8700C3
	v_dual_dot2acc_f32_f16 v51, v26, v2 :: v_dual_dot2acc_f32_f16 v54, v35, v4// 000000453588: CB18051A 33360923
	v_bfe_u32 v35, v27, 6, 16                                  // 000000453590: D6100023 02410D1B
	v_mul_u32_u24_e32 v37, s0, v35                             // 000000453598: 164A4600
	v_mul_u32_u24_e32 v35, s8, v35                             // 00000045359C: 16464608
	v_lshl_add_u32 v35, v35, 24, v37                           // 0000004535A0: D6460023 04953123
	v_dot2acc_f32_f16 v52, v26, v6                             // 0000004535A8: 04680D1A
	v_mul_u32_u24_e32 v25, s8, v28                             // 0000004535AC: 16323808
	v_lshl_add_u32 v24, v25, 24, v24                           // 0000004535B0: D6460018 04613119
	v_bfe_u32 v25, v22, 6, 16                                  // 0000004535B8: D6100019 02410D16
	v_sad_u8 v32, v35, 0, 0x6400                               // 0000004535C0: D6220020 03FD0123 00006400
	v_bfe_u32 v26, v22, 3, 16                                  // 0000004535CC: D610001A 02410716
	v_and_b32_e32 v22, 0xffff, v22                             // 0000004535D4: 362C2CFF 0000FFFF
	v_sad_u8 v24, v24, 0, 0x6400                               // 0000004535DC: D6220018 03FD0118 00006400
	v_bfe_u32 v28, v23, 9, 16                                  // 0000004535E8: D610001C 02411317
	v_lshl_or_b32 v29, v32, 16, v29                            // 0000004535F0: D656001D 04752120
	v_mul_u32_u24_e32 v37, s0, v36                             // 0000004535F8: 164A4800
	v_mul_u32_u24_e32 v36, s8, v36                             // 0000004535FC: 16484808
	v_and_b32_e32 v24, 0xffff, v24                             // 000000453600: 363030FF 0000FFFF
	v_lshl_add_u32 v36, v36, 24, v37                           // 000000453608: D6460024 04953124
	v_pk_fma_f16 v29, v29, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453610: CC0E001D 0BFC131D 0000C931
	v_and_b32_e32 v27, 0xffff, v27                             // 00000045361C: 363636FF 0000FFFF
	v_mul_u32_u24_e32 v35, s0, v27                             // 000000453624: 16463600
	v_mul_u32_u24_e32 v27, s8, v27                             // 000000453628: 16363608
	v_sad_u8 v34, v36, 0, 0x6400                               // 00000045362C: D6220022 03FD0124 00006400
	v_dot2acc_f32_f16 v51, v29, v3                             // 000000453638: 0466071D
	v_dot2acc_f32_f16 v52, v29, v7                             // 00000045363C: 04680F1D
	v_mul_u32_u24_e32 v29, s0, v25                             // 000000453640: 163A3200
	v_mul_u32_u24_e32 v25, s8, v25                             // 000000453644: 16323208
	v_lshl_add_u32 v25, v25, 24, v29                           // 000000453648: D6460019 04753119
	v_mul_u32_u24_e32 v29, s0, v26                             // 000000453650: 163A3400
	v_mul_u32_u24_e32 v26, s8, v26                             // 000000453654: 16343408
	v_lshl_add_u32 v26, v26, 24, v29                           // 000000453658: D646001A 0475311A
	v_bfe_u32 v29, v23, 6, 16                                  // 000000453660: D610001D 02410D17
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000453668: D6220019 03FD0119 00006400
	v_and_b32_e32 v23, 0xffff, v23                             // 000000453674: 362E2EFF 0000FFFF
	v_lshl_add_u32 v27, v27, 24, v35                           // 00000045367C: D646001B 048D311B
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000453684: D622001A 03FD011A 00006400
	v_mov_b32_e32 v35, v73                                     // 000000453690: 7E460349
	v_lshl_or_b32 v24, v25, 16, v24                            // 000000453694: D6560018 04612119
	v_mul_u32_u24_e32 v25, s0, v22                             // 00000045369C: 16322C00
	v_mul_u32_u24_e32 v22, s8, v22                             // 0000004536A0: 162C2C08
	v_lshl_add_u32 v22, v22, 24, v25                           // 0000004536A4: D6460016 04653116
	v_and_b32_e32 v25, 0xffff, v26                             // 0000004536AC: 363234FF 0000FFFF
	v_mul_u32_u24_e32 v26, s0, v28                             // 0000004536B4: 16343800
	v_mul_u32_u24_e32 v28, s8, v28                             // 0000004536B8: 16383808
	v_lshl_add_u32 v26, v28, 24, v26                           // 0000004536BC: D646001A 0469311C
	v_mul_u32_u24_e32 v28, s0, v30                             // 0000004536C4: 16383C00
	v_mul_u32_u24_e32 v30, s8, v30                             // 0000004536C8: 163C3C08
	v_lshl_add_u32 v28, v30, 24, v28                           // 0000004536CC: D646001C 0471311E
	v_mul_u32_u24_e32 v30, s0, v29                             // 0000004536D4: 163C3A00
	v_mul_u32_u24_e32 v29, s8, v29                             // 0000004536D8: 163A3A08
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000004536DC: D6220016 03FD0116 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000004536E8: D622001A 03FD011A 00006400
	v_lshl_add_u32 v29, v29, 24, v30                           // 0000004536F4: D646001D 0479311D
	v_mul_u32_u24_e32 v30, s0, v23                             // 0000004536FC: 163C2E00
	v_mul_u32_u24_e32 v23, s8, v23                             // 000000453700: 162E2E08
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000453704: D622001C 03FD011C 00006400
	v_lshl_add_u32 v23, v23, 24, v30                           // 000000453710: D6460017 04793117
	v_lshl_or_b32 v22, v22, 16, v25                            // 000000453718: D6560016 04652116
	v_and_b32_e32 v25, 0xffff, v26                             // 000000453720: 363234FF 0000FFFF
	v_sad_u8 v26, v29, 0, 0x6400                               // 000000453728: D622001A 03FD011D 00006400
	v_pk_fma_f16 v24, v24, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453734: CC0E0018 0BFC1318 0000C931
	v_and_b32_e32 v28, 0xffff, v28                             // 000000453740: 363838FF 0000FFFF
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000453748: D6220017 03FD0117 00006400
	v_pk_fma_f16 v22, v22, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453754: CC0E0016 0BFC1316 0000C931
	v_lshl_or_b32 v25, v26, 16, v25                            // 000000453760: D6560019 0465211A
	v_dot2acc_f32_f16 v49, v24, v5                             // 000000453768: 04620B18
	v_dot2acc_f32_f16 v50, v24, v1                             // 00000045376C: 04640318
	v_lshl_or_b32 v23, v23, 16, v28                            // 000000453770: D6560017 04712117
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000453778: D622001B 03FD011B 00006400
	v_pk_fma_f16 v24, v25, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453784: CC0E0018 0BFC1319 0000C931
	v_dot2acc_f32_f16 v49, v22, v6                             // 000000453790: 04620D16
	v_mul_u32_u24_e32 v28, s0, v20                             // 000000453794: 16382800
	v_pk_fma_f16 v23, v23, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453798: CC0E0017 0BFC1317 0000C931
	v_mul_u32_u24_e32 v20, s8, v20                             // 0000004537A4: 16282808
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004537A8: BF870002
	v_dual_dot2acc_f32_f16 v50, v22, v2 :: v_dual_dot2acc_f32_f16 v49, v24, v7// 0000004537AC: CB180516 32300F18
	v_and_b32_e32 v32, 0xffff, v34                             // 0000004537B4: 364044FF 0000FFFF
	v_bfe_u32 v22, v18, 3, 16                                  // 0000004537BC: D6100016 02410712
	v_lshl_add_u32 v20, v20, 24, v28                           // 0000004537C4: D6460014 04713114
	v_mul_u32_u24_e32 v28, s0, v22                             // 0000004537CC: 16382C00
	v_dot2acc_f32_f16 v49, v23, v8                             // 0000004537D0: 04621117
	v_lshl_or_b32 v27, v27, 16, v32                            // 0000004537D4: D656001B 0481211B
	v_mul_u32_u24_e32 v22, s8, v22                             // 0000004537DC: 162C2C08
	v_lshl_add_u32 v22, v22, 24, v28                           // 0000004537E0: D6460016 04713116
	v_and_b32_e32 v18, 0xffff, v18                             // 0000004537E8: 362424FF 0000FFFF
	v_mul_u32_u24_e32 v28, s0, v21                             // 0000004537F0: 16382A00
	v_mul_u32_u24_e32 v21, s8, v21                             // 0000004537F4: 162A2A08
	v_pk_fma_f16 v27, v27, s9, 0xc931 op_sel_hi:[1,0,0]        // 0000004537F8: CC0E001B 0BFC131B 0000C931
	v_bfe_u32 v25, v19, 9, 16                                  // 000000453804: D6100019 02411313
	v_sad_u8 v20, v20, 0, 0x6400                               // 00000045380C: D6220014 03FD0114 00006400
	v_lshl_add_u32 v21, v21, 24, v28                           // 000000453818: D6460015 04713115
	v_mul_u32_u24_e32 v28, s0, v18                             // 000000453820: 16382400
	v_mul_u32_u24_e32 v18, s8, v18                             // 000000453824: 16242408
	v_lshl_add_u32 v18, v18, 24, v28                           // 000000453828: D6460012 04713112
	v_mul_u32_u24_e32 v28, s0, v25                             // 000000453830: 16383200
	v_mul_u32_u24_e32 v25, s8, v25                             // 000000453834: 16323208
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000453838: D6220016 03FD0116 00006400
	v_lshl_add_u32 v25, v25, 24, v28                           // 000000453844: D6460019 04713119
	v_bfe_u32 v26, v19, 6, 16                                  // 00000045384C: D610001A 02410D13
	v_dot2acc_f32_f16 v51, v27, v4                             // 000000453854: 0466091B
	v_dot2acc_f32_f16 v52, v27, v8                             // 000000453858: 0468111B
	v_bfe_u32 v27, v19, 3, 16                                  // 00000045385C: D610001B 02410713
	v_and_b32_e32 v20, 0xffff, v20                             // 000000453864: 362828FF 0000FFFF
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000045386C: D6220015 03FD0115 00006400
	v_mul_u32_u24_e32 v28, s0, v26                             // 000000453878: 16383400
	v_mul_u32_u24_e32 v26, s8, v26                             // 00000045387C: 16343408
	v_lshl_add_u32 v26, v26, 24, v28                           // 000000453880: D646001A 0471311A
	v_mul_u32_u24_e32 v28, s0, v27                             // 000000453888: 16383600
	v_mul_u32_u24_e32 v27, s8, v27                             // 00000045388C: 16363608
	v_and_b32_e32 v22, 0xffff, v22                             // 000000453890: 362C2CFF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000453898: D6220012 03FD0112 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 0000004538A4: D6220019 03FD0119 00006400
	v_lshl_add_u32 v27, v27, 24, v28                           // 0000004538B0: D646001B 0471311B
	v_lshl_or_b32 v20, v21, 16, v20                            // 0000004538B8: D6560014 04512115
	v_and_b32_e32 v19, 0xffff, v19                             // 0000004538C0: 362626FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004538C8: BF870004
	v_dual_dot2acc_f32_f16 v56, v33, v3 :: v_dual_and_b32 v21, 0xffff, v25// 0000004538CC: CB240721 381432FF 0000FFFF
	v_lshl_or_b32 v18, v18, 16, v22                            // 0000004538D8: D6560012 04592112
	v_sad_u8 v22, v26, 0, 0x6400                               // 0000004538E0: D6220016 03FD011A 00006400
	v_sad_u8 v25, v27, 0, 0x6400                               // 0000004538EC: D6220019 03FD011B 00006400
	v_mul_u32_u24_e32 v26, s0, v19                             // 0000004538F8: 16342600
	v_mul_u32_u24_e32 v19, s8, v19                             // 0000004538FC: 16262608
	v_pk_fma_f16 v20, v20, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453900: CC0E0014 0BFC1314 0000C931
	v_lshl_add_u32 v19, v19, 24, v26                           // 00000045390C: D6460013 04693113
	v_lshl_or_b32 v21, v22, 16, v21                            // 000000453914: D6560015 04552116
	v_dual_mov_b32 v29, v86 :: v_dual_and_b32 v22, 0xffff, v25 // 00000045391C: CA240156 1D1632FF 0000FFFF
	v_mul_u32_u24_e32 v25, s0, v14                             // 000000453928: 16321C00
	v_mul_u32_u24_e32 v14, s8, v14                             // 00000045392C: 161C1C08
	v_lshl_add_u32 v14, v14, 24, v25                           // 000000453930: D646000E 0465310E
	v_dual_dot2acc_f32_f16 v48, v20, v1 :: v_dual_mov_b32 v27, v71// 000000453938: CB100314 301A0147
	v_dot2acc_f32_f16 v47, v20, v5                             // 000000453940: 045E0B14
	v_bfe_u32 v20, v12, 3, 16                                  // 000000453944: D6100014 0241070C
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000045394C: D6220013 03FD0113 00006400
	v_mul_u32_u24_e32 v25, s0, v20                             // 000000453958: 16322800
	v_mul_u32_u24_e32 v20, s8, v20                             // 00000045395C: 16282808
	s_delay_alu instid0(VALU_DEP_2)                            // 000000453960: BF870002
	v_lshl_add_u32 v20, v20, 24, v25                           // 000000453964: D6460014 04653114
	v_mul_u32_u24_e32 v25, s0, v15                             // 00000045396C: 16321E00
	v_mul_u32_u24_e32 v15, s8, v15                             // 000000453970: 161E1E08
	v_sad_u8 v14, v14, 0, 0x6400                               // 000000453974: D622000E 03FD010E 00006400
	v_lshl_add_u32 v15, v15, 24, v25                           // 000000453980: D646000F 0465310F
	v_and_b32_e32 v12, 0xffff, v12                             // 000000453988: 361818FF 0000FFFF
	v_dot2acc_f32_f16 v50, v24, v3                             // 000000453990: 04640718
	v_lshl_or_b32 v19, v19, 16, v22                            // 000000453994: D6560013 04592113
	v_bfe_u32 v22, v13, 9, 16                                  // 00000045399C: D6100016 0241130D
	v_mul_u32_u24_e32 v25, s0, v12                             // 0000004539A4: 16321800
	v_mul_u32_u24_e32 v12, s8, v12                             // 0000004539A8: 16181808
	v_lshl_add_u32 v12, v12, 24, v25                           // 0000004539AC: D646000C 0465310C
	v_mul_u32_u24_e32 v25, s0, v22                             // 0000004539B4: 16322C00
	v_mul_u32_u24_e32 v22, s8, v22                             // 0000004539B8: 162C2C08
	v_sad_u8 v20, v20, 0, 0x6400                               // 0000004539BC: D6220014 03FD0114 00006400
	v_lshl_add_u32 v22, v22, 24, v25                           // 0000004539C8: D6460016 04653116
	v_and_b32_e32 v14, 0xffff, v14                             // 0000004539D0: 361C1CFF 0000FFFF
	v_sad_u8 v15, v15, 0, 0x6400                               // 0000004539D8: D622000F 03FD010F 00006400
	v_dot2acc_f32_f16 v50, v23, v4                             // 0000004539E4: 04640917
	v_bfe_u32 v23, v13, 6, 16                                  // 0000004539E8: D6100017 02410D0D
	v_mul_u32_u24_e32 v25, s0, v23                             // 0000004539F0: 16322E00
	v_mul_u32_u24_e32 v23, s8, v23                             // 0000004539F4: 162E2E08
	v_dual_mov_b32 v39, v74 :: v_dual_and_b32 v20, 0xffff, v20 // 0000004539F8: CA24014A 271428FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000453A04: D622000C 03FD010C 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000453A10: D6220016 03FD0116 00006400
	v_lshl_add_u32 v23, v23, 24, v25                           // 000000453A1C: D6460017 04653117
	v_lshl_or_b32 v14, v15, 16, v14                            // 000000453A24: D656000E 0439210F
	v_bfe_u32 v24, v13, 3, 16                                  // 000000453A2C: D6100018 0241070D
	v_mul_u32_u24_e32 v25, s0, v24                             // 000000453A34: 16323000
	v_mul_u32_u24_e32 v24, s8, v24                             // 000000453A38: 16303008
	v_pk_fma_f16 v18, v18, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453A3C: CC0E0012 0BFC1312 0000C931
	s_delay_alu instid0(VALU_DEP_2)                            // 000000453A48: BF870002
	v_lshl_add_u32 v24, v24, 24, v25                           // 000000453A4C: D6460018 04653118
	v_lshl_or_b32 v12, v12, 16, v20                            // 000000453A54: D656000C 0451210C
	v_and_b32_e32 v15, 0xffff, v22                             // 000000453A5C: 361E2CFF 0000FFFF
	v_sad_u8 v20, v23, 0, 0x6400                               // 000000453A64: D6220014 03FD0117 00006400
	v_pk_fma_f16 v14, v14, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453A70: CC0E000E 0BFC130E 0000C931
	v_dual_dot2acc_f32_f16 v56, v31, v4 :: v_dual_and_b32 v13, 0xffff, v13// 000000453A7C: CB24091F 380C1AFF 0000FFFF
	v_mul_u32_u24_e32 v23, s0, v13                             // 000000453A88: 162E1A00
	v_mul_u32_u24_e32 v13, s8, v13                             // 000000453A8C: 161A1A08
	v_pk_fma_f16 v21, v21, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453A90: CC0E0015 0BFC1315 0000C931
	v_dual_dot2acc_f32_f16 v48, v18, v2 :: v_dual_mov_b32 v33, v89// 000000453A9C: CB100512 30200159
	v_sad_u8 v22, v24, 0, 0x6400                               // 000000453AA4: D6220016 03FD0118 00006400
	v_lshl_add_u32 v13, v13, 24, v23                           // 000000453AB0: D646000D 045D310D
	v_pk_fma_f16 v12, v12, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453AB8: CC0E000C 0BFC130C 0000C931
	v_lshl_or_b32 v15, v20, 16, v15                            // 000000453AC4: D656000F 043D2114
	v_dot2acc_f32_f16 v46, v14, v1                             // 000000453ACC: 045C030E
	v_dot2acc_f32_f16 v47, v18, v6                             // 000000453AD0: 045E0D12
	v_dot2acc_f32_f16 v9, v14, v5                              // 000000453AD4: 04120B0E
	v_pk_fma_f16 v19, v19, s9, 0xc931 op_sel_hi:[1,0,0]        // 000000453AD8: CC0E0013 0BFC1313 0000C931
	v_dual_dot2acc_f32_f16 v48, v21, v3 :: v_dual_mov_b32 v37, v92// 000000453AE4: CB100715 3024015C
	v_and_b32_e32 v20, 0xffff, v22                             // 000000453AEC: 36282CFF 0000FFFF
	v_sad_u8 v13, v13, 0, 0x6400                               // 000000453AF4: D622000D 03FD010D 00006400
	v_pk_fma_f16 v1, v15, s9, 0xc931 op_sel_hi:[1,0,0]         // 000000453B00: CC0E0001 0BFC130F 0000C931
	v_dual_dot2acc_f32_f16 v46, v12, v2 :: v_dual_dot2acc_f32_f16 v47, v21, v7// 000000453B0C: CB18050C 2E2E0F15
	v_dual_dot2acc_f32_f16 v9, v12, v6 :: v_dual_dot2acc_f32_f16 v48, v19, v4// 000000453B14: CB180D0C 09300913
	v_mov_b32_e32 v21, v81                                     // 000000453B1C: 7E2A0351
	v_dot2acc_f32_f16 v55, v31, v8                             // 000000453B20: 046E111F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000453B24: BF870004
	v_dot2acc_f32_f16 v47, v19, v8                             // 000000453B28: 045E1113
	v_mov_b32_e32 v19, v69                                     // 000000453B2C: 7E260345
	v_dual_dot2acc_f32_f16 v46, v1, v3 :: v_dual_mov_b32 v3, v99// 000000453B30: CB100701 2E020163
	v_lshl_or_b32 v5, v13, 16, v20                             // 000000453B38: D6560005 0451210D
	v_dot2acc_f32_f16 v9, v1, v7                               // 000000453B40: 04120F01
	v_add_nc_u32_e32 v1, v62, v61                              // 000000453B44: 4A027B3E
	v_dual_mov_b32 v24, v90 :: v_dual_mov_b32 v25, v83         // 000000453B48: CA10015A 18180153
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000453B50: BF870224
	v_pk_fma_f16 v2, v5, s9, 0xc931 op_sel_hi:[1,0,0]          // 000000453B54: CC0E0002 0BFC1305 0000C931
	v_mov_b32_e32 v22, v78                                     // 000000453B60: 7E2C034E
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 000000453B64: 7C940281
	v_dual_mov_b32 v23, v70 :: v_dual_mov_b32 v28, v93         // 000000453B68: CA100146 171C015D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000453B70: BF870004
	v_dual_dot2acc_f32_f16 v9, v2, v8 :: v_dual_mov_b32 v26, v80// 000000453B74: CB101102 091A0150
	v_mov_b32_e32 v32, v95                                     // 000000453B7C: 7E40035F
	v_dual_mov_b32 v30, v82 :: v_dual_mov_b32 v31, v72         // 000000453B80: CA100152 1E1E0148
	v_mov_b32_e32 v36, v97                                     // 000000453B88: 7E480361
	v_dual_mov_b32 v34, v85 :: v_dual_mov_b32 v1, v91          // 000000453B8C: CA100155 2200015B
	v_mov_b32_e32 v18, v77                                     // 000000453B94: 7E24034D
	v_dual_mov_b32 v20, v87 :: v_dual_mov_b32 v13, v68         // 000000453B98: CA100157 140C0144
	v_dual_dot2acc_f32_f16 v46, v2, v4 :: v_dual_mov_b32 v15, v79// 000000453BA0: CB100902 2E0E014F
	v_mov_b32_e32 v4, v96                                      // 000000453BA8: 7E080360
	v_mov_b32_e32 v2, v75                                      // 000000453BAC: 7E04034B
	v_mov_b32_e32 v12, v76                                     // 000000453BB0: 7E18034C
	v_mov_b32_e32 v14, v84                                     // 000000453BB4: 7E1C0354
	s_or_b32 s5, vcc_lo, s5                                    // 000000453BB8: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000453BBC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000453BC0: 917E057E
	s_cbranch_execz 92                                         // 000000453BC4: BFA5005C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d38>
	s_mov_b32 s10, exec_lo                                     // 000000453BC8: BE8A007E
	.long 0xd4c1007e                                           // 000000453BCC: D4C1007E
	v_cndmask_b32_e32 v1, v61, v45, vcc_lo                     // 000000453BD0: 02025B3D
	s_cbranch_execz 64562                                      // 000000453BD4: BFA5FC32 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xca0>
	v_mad_i64_i32 v[5:6], null, 0x300, v61, s[6:7]             // 000000453BD8: D6FF7C05 001A7AFF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000453BE4: BF870091
	.long 0xd7006a07                                           // 000000453BE8: D7006A07
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 000000453BEC: 02021505
	v_add_co_ci_u32_e64 v8, null, v6, v11, vcc_lo              // 000000453BF0: D5207C08 01AA1706
	.long 0xd7006a53                                           // 000000453BF8: D7006A53
	v_cndmask_b32_e32 v1, v5, v66, vcc_lo                      // 000000453BFC: 02028505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000453C00: BF8700A1
	v_add_co_ci_u32_e64 v84, null, 0, v6, vcc_lo               // 000000453C04: D5207C54 01AA0C80
	.long 0xd7006a61                                           // 000000453C0C: D7006A61
	v_cndmask_b32_e32 v1, v5, v16, vcc_lo                      // 000000453C10: 02022105
	v_add_co_ci_u32_e64 v98, null, v6, v17, vcc_lo             // 000000453C14: D5207C62 01AA2306
	.long 0xd7006a05                                           // 000000453C1C: D7006A05
	v_cndmask_b32_e32 v1, v5, v67, vcc_lo                      // 000000453C20: 02028705
	s_delay_alu instid0(VALU_DEP_1)                            // 000000453C24: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 000000453C28: D5207C06 01AA0C80
	s_clause 0x1f                                              // 000000453C30: BF85001F
	global_load_b32 v75, v[7:8], off                           // 000000453C34: DC520000 4B7C0007
	global_load_b32 v74, v[7:8], off offset:96                 // 000000453C3C: DC520060 4A7C0007
	global_load_b32 v73, v[7:8], off offset:192                // 000000453C44: DC5200C0 497C0007
	global_load_b32 v72, v[7:8], off offset:288                // 000000453C4C: DC520120 487C0007
	global_load_b32 v71, v[7:8], off offset:384                // 000000453C54: DC520180 477C0007
	global_load_b32 v70, v[7:8], off offset:480                // 000000453C5C: DC5201E0 467C0007
	global_load_b32 v69, v[7:8], off offset:576                // 000000453C64: DC520240 457C0007
	global_load_b32 v68, v[7:8], off offset:672                // 000000453C6C: DC5202A0 447C0007
	global_load_b32 v91, v[83:84], off                         // 000000453C74: DC520000 5B7C0053
	global_load_b32 v88, v[83:84], off offset:96               // 000000453C7C: DC520060 587C0053
	global_load_b32 v85, v[83:84], off offset:192              // 000000453C84: DC5200C0 557C0053
	global_load_b32 v82, v[83:84], off offset:288              // 000000453C8C: DC520120 527C0053
	global_load_b32 v80, v[83:84], off offset:384              // 000000453C94: DC520180 507C0053
	global_load_b32 v78, v[83:84], off offset:480              // 000000453C9C: DC5201E0 4E7C0053
	global_load_b32 v77, v[83:84], off offset:576              // 000000453CA4: DC520240 4D7C0053
	global_load_b32 v76, v[83:84], off offset:672              // 000000453CAC: DC5202A0 4C7C0053
	global_load_b32 v96, v[97:98], off                         // 000000453CB4: DC520000 607C0061
	global_load_b32 v94, v[97:98], off offset:96               // 000000453CBC: DC520060 5E7C0061
	global_load_b32 v92, v[97:98], off offset:192              // 000000453CC4: DC5200C0 5C7C0061
	global_load_b32 v89, v[97:98], off offset:288              // 000000453CCC: DC520120 597C0061
	global_load_b32 v86, v[97:98], off offset:384              // 000000453CD4: DC520180 567C0061
	global_load_b32 v83, v[97:98], off offset:480              // 000000453CDC: DC5201E0 537C0061
	global_load_b32 v81, v[97:98], off offset:576              // 000000453CE4: DC520240 517C0061
	global_load_b32 v79, v[97:98], off offset:672              // 000000453CEC: DC5202A0 4F7C0061
	global_load_b32 v99, v[5:6], off                           // 000000453CF4: DC520000 637C0005
	global_load_b32 v98, v[5:6], off offset:96                 // 000000453CFC: DC520060 627C0005
	global_load_b32 v97, v[5:6], off offset:192                // 000000453D04: DC5200C0 617C0005
	global_load_b32 v95, v[5:6], off offset:288                // 000000453D0C: DC520120 5F7C0005
	global_load_b32 v93, v[5:6], off offset:384                // 000000453D14: DC520180 5D7C0005
	global_load_b32 v90, v[5:6], off offset:480                // 000000453D1C: DC5201E0 5A7C0005
	global_load_b32 v87, v[5:6], off offset:576                // 000000453D24: DC520240 577C0005
	global_load_b32 v84, v[5:6], off offset:672                // 000000453D2C: DC5202A0 547C0005
	s_branch 64474                                             // 000000453D34: BFA0FBDA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xca0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000453D38: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000453D3C: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000453D40: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 000000453D44: BF895FF7
	v_dual_mov_b32 v1, v60 :: v_dual_mov_b32 v2, v57           // 000000453D48: CA10013C 01020139
	s_waitcnt vmcnt(7)                                         // 000000453D50: BF891FF7
	v_dual_mov_b32 v3, v59 :: v_dual_mov_b32 v6, v58           // 000000453D54: CA10013B 0306013A
	v_dual_mov_b32 v4, v54 :: v_dual_mov_b32 v5, v53           // 000000453D5C: CA100136 04040135
	v_dual_mov_b32 v8, v56 :: v_dual_mov_b32 v7, v51           // 000000453D64: CA100138 08060133
	v_dual_mov_b32 v10, v55 :: v_dual_mov_b32 v11, v52         // 000000453D6C: CA100137 0A0A0134
	v_dual_mov_b32 v12, v50 :: v_dual_mov_b32 v13, v49         // 000000453D74: CA100132 0C0C0131
	s_waitcnt vmcnt(0)                                         // 000000453D7C: BF8903F7
	v_dual_mov_b32 v14, v48 :: v_dual_mov_b32 v15, v47         // 000000453D80: CA100130 0E0E012F
	v_dual_mov_b32 v16, v46 :: v_dual_mov_b32 v17, v9          // 000000453D88: CA10012E 10100109
	s_mov_b32 s0, 0x76543210                                   // 000000453D90: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000453D98: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000453D9C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000453DA8: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000453DB4: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000453DC0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000453DCC: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000453DD8: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000453DE4: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000453DF0: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000453DFC: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000453E08: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000453E14: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000453E20: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000453E2C: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000453E38: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000453E44: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000453E50: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000453E5C: D44C0000
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000453E60: 02025890
	s_barrier                                                  // 000000453E64: BFBD0000
	buffer_gl0_inv                                             // 000000453E68: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000453E70: BE812000
	s_cbranch_execz 34                                         // 000000453E74: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f00>
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v16, v46, v16 // 000000453E78: C9082309 0910212E
	v_dual_add_f32 v8, v56, v8 :: v_dual_add_f32 v3, v59, v3   // 000000453E80: C9081138 0802073B
	v_dual_add_f32 v6, v58, v6 :: v_dual_add_f32 v1, v60, v1   // 000000453E88: C9080D3A 0600033C
	v_lshl_or_b32 v17, v42, 10, v43                            // 000000453E90: D6560011 04AD152A
	v_dual_add_f32 v2, v57, v2 :: v_dual_add_f32 v7, v51, v7   // 000000453E98: C9080539 02060F33
	v_dual_add_f32 v4, v54, v4 :: v_dual_add_f32 v5, v53, v5   // 000000453EA0: C9080936 04040B35
	v_dual_add_f32 v11, v52, v11 :: v_dual_add_f32 v10, v55, v10// 000000453EA8: C9081734 0B0A1537
	v_dual_add_f32 v13, v49, v13 :: v_dual_add_f32 v12, v50, v12// 000000453EB0: C9081B31 0D0C1932
	v_dual_add_f32 v15, v47, v15 :: v_dual_add_f32 v14, v48, v14// 000000453EB8: C9081F2F 0F0E1D30
	ds_store_2addr_b32 v17, v1, v3 offset1:16                  // 000000453EC0: D8381000 00030111
	ds_store_2addr_b32 v17, v2, v6 offset0:128 offset1:144     // 000000453EC8: D8389080 00060211
	ds_store_2addr_b32 v17, v4, v8 offset0:32 offset1:48       // 000000453ED0: D8383020 00080411
	ds_store_2addr_b32 v17, v5, v10 offset0:160 offset1:176    // 000000453ED8: D838B0A0 000A0511
	ds_store_2addr_b32 v17, v7, v12 offset0:64 offset1:80      // 000000453EE0: D8385040 000C0711
	ds_store_2addr_b32 v17, v11, v13 offset0:192 offset1:208   // 000000453EE8: D838D0C0 000D0B11
	ds_store_2addr_b32 v17, v14, v16 offset0:96 offset1:112    // 000000453EF0: D8387060 00100E11
	ds_store_2addr_b32 v17, v15, v9 offset0:224 offset1:240    // 000000453EF8: D838F0E0 00090F11
	s_or_b32 exec_lo, exec_lo, s1                              // 000000453F00: 8C7E017E
	.long 0xd44c0001                                           // 000000453F04: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000453F08: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000453F10: BF89FC07
	s_barrier                                                  // 000000453F14: BFBD0000
	buffer_gl0_inv                                             // 000000453F18: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000453F20: BE852001
	s_cbranch_execnz 9                                         // 000000453F24: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f4c>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000453F28: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 000000453F2C: BF04821B
	s_mov_b32 s5, -1                                           // 000000453F30: BE8500C1
	s_cbranch_scc0 35                                          // 000000453F34: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fc4>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000453F38: 8B6A057E
	s_cbranch_vccnz 196                                        // 000000453F3C: BFA400C4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2250>
	s_nop 0                                                    // 000000453F40: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000453F44: BFB60003
	s_endpgm                                                   // 000000453F48: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000453F4C: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000453F50: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000453F58: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000453F60: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000453F68: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000453F6C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000453F70: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000453F74: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000453F78: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000453F7C: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000453F80: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000453F88: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000453F8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000453F90: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 000000453F94: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000453F98: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000453F9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000453FA0: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 000000453FA4: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 000000453FA8: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 000000453FAC: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 000000453FB4: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 000000453FB8: BF04821B
	s_mov_b32 s5, -1                                           // 000000453FBC: BE8500C1
	s_cbranch_scc1 65501                                       // 000000453FC0: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f38>
	s_waitcnt lgkmcnt(0)                                       // 000000453FC4: BF89FC07
	s_barrier                                                  // 000000453FC8: BFBD0000
	buffer_gl0_inv                                             // 000000453FCC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000453FD4: BE852001
	s_cbranch_execz 41                                         // 000000453FD8: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2080>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000453FDC: 32020087
	s_ashr_i32 s6, s26, 31                                     // 000000453FE0: 86069F1A
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000453FE4: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 000000453FE8: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 000000453FEC: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 000000453FF4: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 000000453FF8: D8D82000 04000004
	s_mul_i32 s4, s4, s26                                      // 000000454000: 96041A04
	.long 0xd72c0003                                           // 000000454004: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000454008: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000045400C: D6FE7C01 02003501
	s_lshl_b32 s6, s2, 7                                       // 000000454014: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000454018: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000045401C: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000454020: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 000000454024: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000045402C: 360600FF 0000007F
	s_add_u32 s4, s16, s6                                      // 000000454034: 80040610
	s_addc_u32 s6, s17, s7                                     // 000000454038: 82060711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045403C: BF870112
	.long 0xd73c0001                                           // 000000454040: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000454044: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000454048: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045404C: BF870092
	.long 0xd7006a01                                           // 000000454050: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000454054: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 000000454058: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000454060: BF870092
	.long 0xd7006a01                                           // 000000454064: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000454068: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000045406C: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 000000454074: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000454078: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 000000454080: 8C7E057E
	.long 0xd44a0004                                           // 000000454084: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000454088: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000045408C: BC7C0000
	buffer_gl1_inv                                             // 000000454090: E0B00000 00000000
	buffer_gl0_inv                                             // 000000454098: E0AC0000 00000000
	s_barrier                                                  // 0000004540A0: BFBD0000
	buffer_gl0_inv                                             // 0000004540A4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000004540AC: BE852004
	s_cbranch_execz 29                                         // 0000004540B0: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2128>
	s_mov_b32 s7, exec_lo                                      // 0000004540B4: BE87007E
	s_mov_b32 s6, exec_lo                                      // 0000004540B8: BE86007E
	.long 0xd71f0001                                           // 0000004540BC: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 0000004540C0: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004540C4: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000004540C8: 7D940280
	s_cbranch_execz 9                                          // 0000004540CC: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20f4>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000004540D0: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004540D4: BF8704B9
	s_add_u32 s8, s18, s8                                      // 0000004540D8: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000004540DC: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 0000004540E0: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 0000004540E4: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 0000004540EC: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004540F4: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 0000004540F8: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 0000004540FC: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000454100: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000454104: CA200080 02000206
	s_add_i32 s6, s27, -1                                      // 00000045410C: 8106C11B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000454110: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000454114: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000454118: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 000000454120: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000454128: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000045412C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000454130: BF89FC07
	s_barrier                                                  // 000000454134: BFBD0000
	buffer_gl0_inv                                             // 000000454138: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 000000454140: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000454148: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000045414C: 7C940280
	s_cbranch_vccnz 62                                         // 000000454150: BFA4003E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x224c>
	buffer_gl1_inv                                             // 000000454154: E0B00000 00000000
	buffer_gl0_inv                                             // 00000045415C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000454164: BE852001
	s_cbranch_execz 44                                         // 000000454168: BFA5002C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x221c>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000045416C: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 000000454174: 84068702
	s_ashr_i32 s1, s26, 31                                     // 000000454178: 86019F1A
	s_ashr_i32 s7, s6, 31                                      // 00000045417C: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000454180: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 000000454184: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000045418C: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000454190: BF8700A9
	s_add_u32 s6, s16, s6                                      // 000000454194: 80060610
	s_addc_u32 s7, s17, s7                                     // 000000454198: 82070711
	.long 0xd7000603                                           // 00000045419C: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 0000004541A0: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004541A4: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 0000004541A8: D5207C04 00190007
	s_nop 0                                                    // 0000004541B0: BF800000
	s_nop 0                                                    // 0000004541B4: BF800000
	s_nop 0                                                    // 0000004541B8: BF800000
	s_nop 0                                                    // 0000004541BC: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s26, 0                     // 0000004541C0: D6FE7C05 02003501
	s_add_i32 s27, s27, -1                                     // 0000004541C8: 811BC11B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004541CC: BF870139
	s_cmp_eq_u32 s27, 0                                        // 0000004541D0: BF06801B
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 0000004541D4: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000004541DC: 4A020282
	.long 0xd73c0005                                           // 0000004541E0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004541E4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004541E8: BF870091
	.long 0xd7006a05                                           // 0000004541EC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004541F0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004541F4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000004541FC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000454204: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000454208: 06040B02
	s_cbranch_scc0 65516                                       // 00000045420C: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21c0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000454210: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000454214: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000045421C: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000454220: BE812004
	s_cbranch_execz 6                                          // 000000454224: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2240>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000454228: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000045422C: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000454230: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000454234: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000454238: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000454240: 8C7E017E
	s_cbranch_execz 65342                                      // 000000454244: BFA5FF3E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f40>
	s_branch 1                                                 // 000000454248: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2250>
	s_branch 65340                                             // 00000045424C: BFA0FF3C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f40>
	v_cmp_gt_i32_e32 vcc_lo, s24, v42                          // 000000454250: 7C885418
	.long 0xd44c0001                                           // 000000454254: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000454258: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000045425C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000454260: BC7C0000
	s_barrier                                                  // 000000454264: BFBD0000
	buffer_gl0_inv                                             // 000000454268: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000454270: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000454274: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000454278: BE832001
	s_cbranch_execz 65328                                      // 00000045427C: BFA5FF30 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f40>
	v_and_b32_e32 v1, 15, v0                                   // 000000454280: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000454284: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000454288: 30040282
	v_lshl_or_b32 v2, v42, 9, v2                               // 00000045428C: D6560002 0409132A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000454294: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000454298: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004542A0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004542A8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004542B0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004542B8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004542C0: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004542C4: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004542C8: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004542CC: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004542D4: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000004542D8: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000004542E0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004542E4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004542EC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004542F0: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000004542F8: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000454300: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000454304: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000454308: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000454310: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000454318: 7C941480
	.long 0xd44a0001                                           // 00000045431C: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000454320: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000454324: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000045432C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000454330: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000454334: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000454338: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000045433C: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000454344: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000454348: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000045434C: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000454350: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000454358: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000454360: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000454368: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000454370: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000454378: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000454380: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000454388: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000454390: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000454398: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004543A0: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000004543A8: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004543B0: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 0000004543B8: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 0000004543C0: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004543C8: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 0000004543CC: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004543D4: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 0000004543DC: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004543E4: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004543E8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000004543F0: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 0000004543F8: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004543FC: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000454404: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045440C: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000454414: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000454418: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000454420: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000454428: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000045442C: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000454434: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000454438: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000454440: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000454444: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000045444C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000454454: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 00000045445C: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000454460: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000454468: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000454470: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000454474: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000045447C: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000454484: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000454488: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000454490: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000454498: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 00000045449C: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 0000004544A0: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004544A8: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 0000004544B0: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004544B4: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 0000004544BC: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004544C4: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 0000004544C8: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004544CC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000004544D4: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 0000004544DC: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004544E0: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004544E8: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004544F0: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 0000004544F8: 06081504
	v_add_f32_e32 v10, v19, v18                                // 0000004544FC: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000454500: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000454504: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000045450C: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000454514: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000454518: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045451C: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000454524: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045452C: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000454530: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000454538: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000454540: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000454548: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000454550: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000454554: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045455C: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000454560: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000454564: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000454568: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000454570: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000454578: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045457C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000454584: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000045458C: 8B7E007E
	s_cbranch_execz 65131                                      // 000000454590: BFA5FE6B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f40>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000454594: D6560012 04050E02
	.long 0x7f2c3880                                           // 00000045459C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004545A0: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000004545A4: 3426249F
	.long 0x7f2e3996                                           // 0000004545A8: 7F2E3996
	.long 0x7f303996                                           // 0000004545AC: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004545B0: BF870093
	.long 0xd73c0012                                           // 0000004545B4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000004545B8: 02022481
	.long 0xd7006a14                                           // 0000004545BC: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 0000004545C0: 0202240E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004545C4: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 0000004545C8: D5207C15 01AA260F
	s_clause 0x7                                               // 0000004545D0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 0000004545D4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 0000004545DC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 0000004545E4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 0000004545EC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 0000004545F4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 0000004545FC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000454604: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 00000045460C: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000454614: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v42, 0                    // 000000454618: D6FF7C00 0202541A
	s_waitcnt vmcnt(0)                                         // 000000454620: BF8903F7
	.long 0x7f283996                                           // 000000454624: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000454628: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 00000045462C: 7C942A80
	.long 0x7f2a3996                                           // 000000454630: 7F2A3996
	.long 0xd73c0000                                           // 000000454634: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000454638: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000045463C: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000454644: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000045464C: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000454654: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000045465C: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000454664: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000454668: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000454670: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000454678: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000454680: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000454684: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000454690: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000454698: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004546A4: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 0000004546A8: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 0000004546B0: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004546B8: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000004546BC: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000004546C8: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 0000004546D4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000004546D8: 02020014
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004546DC: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000004546E0: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000004546E8: D5207C01 01AA0215
	.long 0xd7006a00                                           // 0000004546F0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 0000004546F4: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004546F8: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 0000004546FC: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000454704: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000045470C: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000454714: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000045471C: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000454724: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 00000045472C: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000454730: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000454738: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000454740: CC200008 8A02111C
	.long 0x7e2a3985                                           // 000000454748: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 00000045474C: 36142C81
	.long 0x7e2c3984                                           // 000000454750: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000454754: CC200009 8A021314
	.long 0x7e283982                                           // 00000045475C: 7E283982
	.long 0x7e2e3986                                           // 000000454760: 7E2E3986
	.long 0x7e303988                                           // 000000454764: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 000000454768: 36162C81
	.long 0x7e2c3987                                           // 00000045476C: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 000000454770: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 000000454774: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 000000454778: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000045477C: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 000000454780: 361E2C81
	.long 0x7e2c3989                                           // 000000454784: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000454788: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000454794: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 0000004547A0: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 0000004547AC: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 0000004547B8: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000004547BC: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000004547C8: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000004547D4: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004547E0: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000004547E4: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000004547F0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004547F4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 0000004547FC: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 000000454804: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 00000045480C: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000454814: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000045481C: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000454824: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000045482C: DC9600E0 007C0900
	s_nop 0                                                    // 000000454834: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000454838: BFB60003
	s_endpgm                                                   // 00000045483C: BFB00000
		...

