0000000000800200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000800200: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000800208: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000080020C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000800210: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000800214: 3602008F
	v_lshrrev_b32_e32 v21, 6, v0                               // 000000800218: 322A0086
	v_bfe_u32 v22, v0, 5, 1                                    // 00000080021C: D6100016 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 000000800224: 360404BC
	v_and_b32_e32 v23, 31, v0                                  // 000000800228: 362E009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000080022C: 30020282
	.long 0x7f0a3880                                           // 000000800230: 7F0A3880
	s_waitcnt lgkmcnt(0)                                       // 000000800234: BF89FC07
	s_clause 0x1                                               // 000000800238: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000080023C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000800244: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000080024C: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000800250: 82011105
	s_ashr_i32 s16, s11, 31                                    // 000000800254: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 000000800258: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000080025C: 85109B10
	v_or_b32_e32 v1, s2, v21                                   // 000000800260: 38022A02
	s_add_u32 s16, s10, s16                                    // 000000800264: 8010100A
	s_addc_u32 s17, s11, 0                                     // 000000800268: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080026C: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000800270: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000800274: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 000000800278: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000080027C: BF870499
	s_lshr_b32 s20, s17, 31                                    // 000000800280: 85149F11
	s_add_i32 s17, s17, s20                                    // 000000800284: 81111411
	v_cndmask_b32_e32 v9, 0, v1, vcc_lo                        // 000000800288: 02120280
	s_ashr_i32 s17, s17, 1                                     // 00000080028C: 86118111
	v_cndmask_b32_e64 v10, 0, s3, vcc_lo                       // 000000800290: D501000A 01A80680
	.long 0xd72c0002                                           // 000000800298: D72C0002
	v_cndmask_b32_e32 v1, s17, v22, vcc_lo                     // 00000080029C: 02022C11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000008002A0: B3900201
	.long 0xd72c0007                                           // 0000008002A4: D72C0007
	v_cndmask_b32_e32 v1, s19, v9, vcc_lo                      // 0000008002A8: 02021213
	v_mad_u64_u32 v[17:18], null, s18, v9, s[0:1]              // 0000008002AC: D6FE7C11 00021212
	s_cselect_b32 s0, -1, 0                                    // 0000008002B4: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000008002B8: B2900200
	v_lshlrev_b32_e32 v1, 2, v0                                // 0000008002BC: 30020082
	v_add_nc_u32_e32 v11, s17, v2                              // 0000008002C0: 4A160411
	v_add_nc_u32_e32 v24, v2, v23                              // 0000008002C4: 4A302F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008002C8: BF8704A2
	v_min_i32_e32 v25, s16, v11                                // 0000008002CC: 22321610
	s_cselect_b32 s16, -1, 0                                   // 0000008002D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000008002D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008002D8: BF870151
	.long 0xd4410001                                           // 0000008002DC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000008002E0: 02023318
	s_waitcnt vmcnt(1)                                         // 0000008002E4: BF8907F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000008002E8: D6100006 02052103
	s_waitcnt vmcnt(0)                                         // 0000008002F0: BF8903F7
	v_bfe_u32 v8, v4, 16, 1                                    // 0000008002F4: D6100008 02052104
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000008002FC: D6550003 03FE0D03 00007FFF
	.long 0xd72c0006                                           // 000000800308: D72C0006
	v_cndmask_b32_e32 v1, s18, v10, vcc_lo                     // 00000080030C: 02021412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800310: BF870193
	v_add3_u32 v4, v4, v8, 0x7fff                              // 000000800314: D6550004 03FE1104 00007FFF
	.long 0x7e0a3983                                           // 000000800320: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000800324: BF870113
	v_add3_u32 v26, v7, v18, v6                                // 000000800328: D655001A 041A2507
	v_and_or_b32 v2, 0xffff0000, v4, v5                        // 000000800330: D6570002 041608FF FFFF0000
	ds_store_b32 v1, v2                                        // 00000080033C: D8340000 00000201
	s_waitcnt lgkmcnt(0)                                       // 000000800344: BF89FC07
	s_barrier                                                  // 000000800348: BFBD0000
	buffer_gl0_inv                                             // 00000080034C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000800354: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000800358: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000800360: BE912001
	s_cbranch_execz 11                                         // 000000800364: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v1, 1, v24                               // 000000800368: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080036C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000800370: 3408029F
	.long 0xd7006a03                                           // 000000800374: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000800378: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000080037C: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 000000800384: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000080038C: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000800390: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000800394: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 000000800398: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 00000080039C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008003A0: BF870001
	.long 0xd4c1007e                                           // 0000008003A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000008003A8: 02023303
	s_cbranch_execz 11                                         // 0000008003AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000008003B0: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008003B4: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000008003B8: 3406049F
	.long 0xd7006a02                                           // 0000008003BC: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000008003C0: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000008003C4: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000008003CC: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008003D4: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008003D8: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008003DC: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000008003E0: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000008003E8: 7E060280
	s_mov_b32 s1, exec_lo                                      // 0000008003EC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008003F0: BF870002
	.long 0xd4c1007e                                           // 0000008003F4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000008003F8: 02023305
	s_cbranch_execz 11                                         // 0000008003FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000800400: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800404: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000800408: 340C069F
	.long 0xd7006a05                                           // 00000080040C: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000800410: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 000000800414: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 00000080041C: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000800424: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000800428: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080042C: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 000000800430: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000800438: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080043C: BF870001
	.long 0xd4c1007e                                           // 000000800440: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 000000800444: 02023305
	s_cbranch_execz 11                                         // 000000800448: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000080044C: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800450: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000800454: 340A089F
	.long 0xd7006a04                                           // 000000800458: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000080045C: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 000000800460: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 000000800468: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000800470: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000800474: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000800478: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 00000080047C: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000800488: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000080048C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000800490: BF870002
	.long 0xd4c1007e                                           // 000000800494: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 000000800498: 02023307
	s_cbranch_execz 11                                         // 00000080049C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000008004A0: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008004A4: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000008004A8: 34100A9F
	.long 0xd7006a07                                           // 0000008004AC: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000008004B0: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000008004B4: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000008004BC: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000008004C4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008004C8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008004CC: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000008004D0: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000008004D8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008004DC: BF870001
	.long 0xd4c1007e                                           // 0000008004E0: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000008004E4: 02023307
	s_cbranch_execz 11                                         // 0000008004E8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000008004EC: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008004F0: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000008004F4: 340E0C9F
	.long 0xd7006a06                                           // 0000008004F8: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000008004FC: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 000000800500: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 000000800508: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000800510: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000800514: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000800518: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v11, 0xc0, v24   // 00000080051C: CA200080 080A30FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000800528: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000080052C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000800530: BF870002
	.long 0xd4c1007e                                           // 000000800534: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000800538: 0202330B
	s_cbranch_execz 11                                         // 00000080053C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v7, 1, v11                               // 000000800540: 300E1681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800544: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000800548: 34180E9F
	.long 0xd7006a0b                                           // 00000080054C: D7006A0B
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000800550: 02020F11
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 000000800554: D5207C0C 01AA191A
	global_load_d16_b16 v7, v[11:12], off                      // 00000080055C: DC820000 077C000B
	s_waitcnt vmcnt(0)                                         // 000000800564: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000800568: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080056C: 8C7E017E
	v_add_nc_u32_e32 v11, 0xe0, v24                            // 000000800570: 4A1630FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000800578: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080057C: BF870001
	.long 0xd4c1007e                                           // 000000800580: D4C1007E
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 000000800584: 0202330B
	s_cbranch_execz 11                                         // 000000800588: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v8, 1, v11                               // 00000080058C: 30101681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800590: BF8700A1
	v_ashrrev_i32_e32 v12, 31, v8                              // 000000800594: 3418109F
	.long 0xd7006a0b                                           // 000000800598: D7006A0B
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000080059C: 02021111
	v_add_co_ci_u32_e64 v12, null, v26, v12, vcc_lo            // 0000008005A0: D5207C0C 01AA191A
	global_load_d16_b16 v8, v[11:12], off                      // 0000008005A8: DC820000 087C000B
	s_waitcnt vmcnt(0)                                         // 0000008005B0: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000008005B4: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008005B8: 8C7E017E
	s_branch 9                                                 // 0000008005BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v1, 0                                        // 0000008005C0: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008005C4: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000008005C8: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000008005CC: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000008005D0: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000008005D4: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000008005D8: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000008005DC: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000008005E0: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000008005E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000008005E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000008005EC: 85019F0B
	v_mov_b32_e32 v27, 0                                       // 0000008005F0: 7E360280
	s_add_u32 s14, s10, s1                                     // 0000008005F4: 800E010A
	s_addc_u32 s15, s11, 0                                     // 0000008005F8: 820F800B
	.long 0xd4410001                                           // 0000008005FC: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000800600: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000800604: 868E810E
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 000000800608: D501001C 00410280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 000000800610: D6FE7C12 00101D09
	.long 0xd72c000c                                           // 000000800618: D72C000C
	v_cndmask_b32_e32 v0, v9, v15, vcc_lo                      // 00000080061C: 02001F09
	.long 0xd72c000d                                           // 000000800620: D72C000D
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000800624: 02001D0A
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 000000800628: CA100080 090A0080
	v_mov_b32_e32 v35, 0                                       // 000000800630: 7E460280
	v_mov_b32_e32 v11, 0                                       // 000000800634: 7E160280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000800638: BF870004
	v_add3_u32 v29, v13, v19, v12                              // 00000080063C: D655001D 0432270D
	v_mov_b32_e32 v12, 0                                       // 000000800644: 7E180280
	s_and_saveexec_b32 s4, s1                                  // 000000800648: BE842001
	s_cbranch_execz 22                                         // 00000080064C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v9, 4, v24                               // 000000800650: 30123084
	v_mov_b32_e32 v35, 0                                       // 000000800654: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800658: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000080065C: 3414129F
	.long 0xd7006a09                                           // 000000800660: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000800664: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 000000800668: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000800670: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000800674: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000080067C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v13, 1, v24                              // 000000800680: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800684: BF870091
	.long 0xd7006a0d                                           // 000000800688: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 00000080068C: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 000000800690: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 000000800698: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000008006A0: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 0000008006A4: 7E46170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008006A8: 8C7E047E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 0000008006AC: CA100080 1F1E0080
	s_and_saveexec_b32 s14, s1                                 // 0000008006B4: BE8E2001
	s_cbranch_execz 338                                        // 0000008006B8: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xa04>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000008006BC: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000008006C4: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008006CC: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000008006D0: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000008006D8: 30421A81
	v_mov_b32_e32 v27, 0                                       // 0000008006DC: 7E360280
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008006E0: 8484820A
	s_mov_b32 s15, 0                                           // 0000008006E4: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008006E8: 848A810A
	s_branch 289                                               // 0000008006EC: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x974>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008006F0: 8C7E107E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000008006F4: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s0                         // 0000008006F8: D5010054 00020323
	v_lshrrev_b32_e32 v35, 6, v9                               // 000000800700: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 000000800704: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 000000800708: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 000000800710: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000800714: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000800718: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000800720: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 000000800728: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000800730: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 000000800734: 32AE1486
	.long 0xd7006a48                                           // 000000800738: D7006A48
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 00000080073C: 02024806
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000800740: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s7, v37, vcc_lo             // 000000800744: D5207C49 01AA4A07
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000080074C: 30282882
	.long 0xd7006a4c                                           // 000000800750: D7006A4C
	v_cndmask_b32_e32 v0, v72, v10, vcc_lo                     // 000000800754: 02001548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800758: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s11, v73, vcc_lo            // 00000080075C: D5207C4D 01AA920B
	.long 0xd7006a50                                           // 000000800764: D7006A50
	v_cndmask_b32_e32 v0, v72, v4, vcc_lo                      // 000000800768: 02000948
	v_add_co_ci_u32_e64 v81, null, s5, v73, vcc_lo             // 00000080076C: D5207C51 01AA9205
	s_clause 0xb                                               // 000000800774: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 000000800778: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 000000800780: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 000000800788: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 000000800790: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 000000800798: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 0000008007A0: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 0000008007A8: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 0000008007B0: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 0000008007B8: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 0000008007C0: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 0000008007C8: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 0000008007D0: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 0000008007D8: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 0000008007E0: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 0000008007E8: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 0000008007F0: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008007F4: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 0000008007F8: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 0000008007FC: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 000000800804: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 00000080080C: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 000000800814: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 000000800818: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000080081C: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 000000800820: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 000000800824: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000800828: 4A2626FF 00000400
	s_and_b32 s1, exec_lo, s1                                  // 000000800830: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000800834: BF870009
	s_or_b32 s15, s1, s15                                      // 000000800838: 8C0F0F01
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 00000080083C: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 000000800840: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 000000800848: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 00000080084C: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 000000800854: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 000000800858: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 000000800860: 32581886
	s_waitcnt lgkmcnt(1)                                       // 000000800864: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 000000800868: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 000000800870: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 000000800878: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 000000800880: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 000000800888: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 000000800890: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 000000800894: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 00000080089C: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s0                          // 0000008008A4: D501002A 00021107
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008008AC: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008008B4: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000008008BC: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 0000008008C4: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 0000008008CC: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 0000008008D4: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 0000008008DC: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 0000008008E4: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 0000008008EC: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 0000008008F0: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 0000008008F8: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 000000800900: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 000000800908: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 00000080090C: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 000000800914: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 00000080091C: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 000000800924: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 00000080092C: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 000000800934: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 000000800938: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 000000800940: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 000000800944: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 00000080094C: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 000000800950: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000800958: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s0                          // 00000080095C: D5010028 00020D05
	s_waitcnt lgkmcnt(5)                                       // 000000800964: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 000000800968: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 000000800970: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 000000800978: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000800980: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 000000800988: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 00000080098C: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 000000800990: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 000000800998: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 0000008009A0: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 0000008009A8: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000008009B0: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008009B8: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 0000008009BC: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 0000008009C4: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 0000008009CC: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 0000008009D4: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 0000008009DC: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 0000008009E4: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 0000008009EC: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 0000008009F4: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s0                          // 0000008009FC: D5010029 00020F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 000000800A04: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 000000800A08: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 000000800A10: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 000000800A14: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 000000800A1C: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 000000800A20: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s0                          // 000000800A28: D5010027 00020B04
	v_cndmask_b32_e64 v37, v2, v3, s0                          // 000000800A30: D5010025 00020702
	s_waitcnt lgkmcnt(6)                                       // 000000800A38: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 000000800A3C: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 000000800A44: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 000000800A4C: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s0                          // 000000800A54: D5010026 00020903
	v_cndmask_b32_e64 v36, v1, v2, s0                          // 000000800A5C: D5010024 00020501
	s_waitcnt lgkmcnt(5)                                       // 000000800A64: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 000000800A68: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 000000800A70: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 000000800A78: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 000000800A80: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 000000800A8C: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 000000800A90: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 000000800A98: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 000000800AA0: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 000000800AA8: 7E180310
	v_mov_b32_e32 v10, v14                                     // 000000800AAC: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000800AB0: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 000000800AB4: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 000000800ABC: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 000000800AC0: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 000000800AC8: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 000000800ACC: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 000000800AD4: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 000000800AD8: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 000000800ADC: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 000000800AE0: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 000000800AE8: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 000000800AF0: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 000000800AF8: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 000000800AFC: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 000000800B00: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 000000800B08: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 000000800B10: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 000000800B18: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800B1C: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 000000800B20: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 000000800B28: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800B30: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 000000800B34: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 000000800B3C: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800B40: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 000000800B44: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 000000800B48: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 000000800B4C: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 000000800B54: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 000000800B5C: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 000000800B64: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000800B6C: 917E0F7E
	s_cbranch_execz 35                                         // 000000800B70: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xa00>
	s_waitcnt vmcnt(0)                                         // 000000800B74: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 000000800B78: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 000000800B80: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 000000800B88: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000800B8C: BF870003
	.long 0xd4460001                                           // 000000800B90: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000800B94: 02023318
	s_mov_b32 s16, exec_lo                                     // 000000800B98: BE90007E
	.long 0xd4c1007e                                           // 000000800B9C: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000800BA0: 02023318
	s_cbranch_execz 65234                                      // 000000800BA4: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v14, 31, v32                             // 000000800BA8: 341C409F
	.long 0xd7006a0d                                           // 000000800BAC: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 000000800BB0: 02024112
	v_mov_b32_e32 v34, v35                                     // 000000800BB4: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 000000800BB8: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 000000800BBC: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 000000800BC4: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 000000800BC8: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 000000800BD0: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	v_ashrrev_i32_e32 v20, 31, v33                             // 000000800BD4: 3428429F
	.long 0xd7006a24                                           // 000000800BD8: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 000000800BDC: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000800BE0: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 000000800BE4: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 000000800BEC: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 000000800BF4: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 000000800BF8: 7E441714
	s_branch 65212                                             // 000000800BFC: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4f0>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000800C00: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000800C04: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000800C08: 8C7E0E7E
	.long 0xd71f0001                                           // 000000800C0C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000800C10: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000800C14: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000800C18: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000800C1C: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000800C20: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000800C24: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000800C28: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000800C2C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000800C30: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000800C34: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000800C38: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000800C3C: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000800C40: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000800C44: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 000000800C48: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 000000800C50: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 000000800C54: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 000000800C58: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 000000800C60: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 000000800C68: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000800C70: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000800C74: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 000000800C78: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 000000800C7C: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 000000800C80: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 000000800C84: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000800C88: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000800C8C: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 000000800C94: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000800C9C: 30101082
	s_waitcnt lgkmcnt(0)                                       // 000000800CA0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 000000800CA4: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000800CA8: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 000000800CB0: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 000000800CB4: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 000000800CBC: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000800CC4: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 000000800CCC: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800CD0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000800CD4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000800CD8: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000800CDC: 30101082
	s_waitcnt lgkmcnt(1)                                       // 000000800CE0: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 000000800CE4: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 000000800CE8: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000800CEC: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 000000800CF0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000800CF8: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 000000800D00: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 000000800D08: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800D0C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000800D10: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000800D14: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000800D18: 30100282
	s_waitcnt lgkmcnt(1)                                       // 000000800D1C: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 000000800D20: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 000000800D28: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 000000800D2C: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 000000800D30: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 000000800D38: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 000000800D40: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 000000800D48: 7D942E80
	s_cbranch_execz 16                                         // 000000800D4C: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xb90>
	.long 0xd72c0007                                           // 000000800D50: D72C0007
	v_cndmask_b32_e32 v0, v21, v152, vcc_lo                    // 000000800D54: 02013115
	s_waitcnt lgkmcnt(1)                                       // 000000800D58: BF89FC17
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 000000800D5C: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000800D64: BF8700A2
	v_mad_u32_u24 v7, v22, 12, v7                              // 000000800D68: D60B0007 041D1916
	s_waitcnt lgkmcnt(0)                                       // 000000800D70: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 000000800D74: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000800D80: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 000000800D88: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s0                              // 000000800D90: 8C7E007E
	.long 0xd7050001                                           // 000000800D94: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000800D98: 020200FF 000000AB
	.long 0x7f063880                                           // 000000800DA0: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000800DA4: BF890007
	s_barrier                                                  // 000000800DA8: BFBD0000
	buffer_gl0_inv                                             // 000000800DAC: E0AC0000 00000000
	.long 0xd7390003                                           // 000000800DB4: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 000000800DB8: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800DBC: BF870091
	.long 0xd7000001                                           // 000000800DC0: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000800DC4: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000800DC8: D5207C02 00010003
	.long 0xd44c0000                                           // 000000800DD0: D44C0000
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 000000800DD4: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000800DD8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000800DDC: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000800DE0: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 000000800DE4: BE812000
	s_cbranch_execz 82                                         // 000000800DE8: BFA50052 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xd34>
	.long 0xd7054000                                           // 000000800DEC: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 000000800DF0: 02010703
	v_mul_u32_u24_e32 v3, 24, v3                               // 000000800DF4: 16060698
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800DF8: BF870092
	.long 0xd7041000                                           // 000000800DFC: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000800E00: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000800E04: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800E0C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000800E10: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000800E18: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:3                     // 000000800E20: D8DC0300 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000800E28: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000800E2C: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800E30: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 000000800E34: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 000000800E38: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800E40: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000800E44: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000800E50: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800E58: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000800E5C: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000800E64: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800E68: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 000000800E6C: 060C06F2
	v_div_scale_f32 v5, null, v6, v6, 1.0                      // 000000800E70: D6FC7C05 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 000000800E78: D6FC6A08 03CA0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000800E80: BF870292
	v_rcp_f32_e32 v7, v5                                       // 000000800E84: 7E0E5505
	v_fma_f32 v3, -v5, v7, 1.0                                 // 000000800E88: D6130003 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000800E90: BF870121
	v_fmac_f32_e32 v7, v3, v7                                  // 000000800E94: 560E0F03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000800E98: D6FE7C03 0202000C
	v_mul_f32_e32 v9, v8, v7                                   // 000000800EA0: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000800EA4: BF870091
	v_fma_f32 v10, -v5, v9, v8                                 // 000000800EA8: D613000A 24221305
	v_fmac_f32_e32 v9, v10, v7                                 // 000000800EB0: 56120F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000800EB4: BF870121
	v_fma_f32 v8, -v5, v9, v8                                  // 000000800EB8: D6130008 24221305
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000800EC0: D6FE7C04 0412000D
	v_div_fmas_f32 v0, v8, v7, v9                              // 000000800EC8: D6370000 04260F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000800ED0: BF870112
	.long 0xd73c0003                                           // 000000800ED4: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000800ED8: 02020681
	v_div_fixup_f32 v5, v0, v6, 1.0                            // 000000800EDC: D6270005 03CA0D00
	.long 0xd73c0000                                           // 000000800EE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000800EE8: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800EEC: BF870193
	.long 0xd7006a03                                           // 000000800EF0: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000800EF4: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 000000800EF8: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000800F00: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000800F08: BF870193
	.long 0xd7006a00                                           // 000000800F0C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000800F10: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000800F14: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000800F20: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000800F24: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000800F2C: DC960000 007C0200
	s_endpgm                                                   // 000000800F34: BFB00000
		...

