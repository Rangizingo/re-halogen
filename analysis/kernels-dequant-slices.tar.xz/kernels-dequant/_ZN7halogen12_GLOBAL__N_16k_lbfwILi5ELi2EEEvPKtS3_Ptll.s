00000000002da900 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002DA900: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002DA908: 32020085
	s_mov_b32 s3, 0                                            // 0000002DA90C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DA910: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002DA914: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002DA918: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002DA91C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002DA920: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002DA924: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002DA928: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DA92C: BF870001
	.long 0xd4d4007e                                           // 0000002DA930: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002DA934: 02020208
	s_cbranch_execz 409                                        // 0000002DA938: BFA50199 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll+0x6a0>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002DA93C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002DA944: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002DA948: BF89FC07
	.long 0xd451000a                                           // 0000002DA94C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002DA950: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002DA954: 8B6A0A7E
	s_cbranch_vccnz 205                                        // 0000002DA958: BFA400CD <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll+0x390>
	.long 0xd72c0007                                           // 0000002DA95C: D72C0007
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002DA960: 02020207
	.long 0xd72c0008                                           // 0000002DA964: D72C0008
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002DA968: 02020406
	v_mad_u64_u32 v[5:6], null, s6, v1, 0                      // 0000002DA96C: D6FE7C05 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002DA974: 848A8106
	s_mul_i32 s14, s7, 6                                       // 0000002DA978: 960E8607
	s_add_u32 s10, s2, s10                                     // 0000002DA97C: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002DA980: 820B0B03
	s_lshl_b64 s[12:13], s[6:7], 3                             // 0000002DA984: 848C8306
	s_mul_hi_u32 s15, s6, 6                                    // 0000002DA988: 968F8606
	s_mul_i32 s16, s6, 6                                       // 0000002DA98C: 96108606
	v_add3_u32 v6, v6, v8, v7                                  // 0000002DA990: D6550006 041E1106
	s_add_u32 s12, s2, s12                                     // 0000002DA998: 800C0C02
	s_addc_u32 s13, s3, s13                                    // 0000002DA99C: 820D0D03
	s_add_i32 s15, s15, s14                                    // 0000002DA9A0: 810F0E0F
	s_add_u32 s14, s2, s16                                     // 0000002DA9A4: 800E1002
	.long 0xd73c0005                                           // 0000002DA9A8: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000002DA9AC: 02020A81
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v4, 4, v0       // 0000002DA9B0: CA220080 03040084
	s_addc_u32 s15, s3, s15                                    // 0000002DA9B8: 820F0F03
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v7, 0              // 0000002DA9BC: CA100080 0A060080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DA9C4: BF870093
	.long 0xd7006a08                                           // 0000002DA9C8: D7006A08
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 0000002DA9CC: 02020A00
	v_add_co_ci_u32_e64 v9, null, s1, v6, vcc_lo               // 0000002DA9D0: D5207C09 01AA0C01
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002DA9D8: 84808206
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 0000002DA9DC: CA100080 06040080
	s_add_u32 s16, s2, s0                                      // 0000002DA9E4: 80100002
	s_addc_u32 s17, s3, s1                                     // 0000002DA9E8: 82110103
	s_mov_b64 s[0:1], 0                                        // 0000002DA9EC: BE800180
	.long 0xd7001227                                           // 0000002DA9F0: D7001227
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 0000002DA9F4: 02020802
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DA9F8: BF870001
	v_add_co_ci_u32_e64 v40, null, s3, 0, s18                  // 0000002DA9FC: D5207C28 00490003
	.long 0xd700122b                                           // 0000002DAA04: D700122B
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002DAA08: 0202080A
	.long 0xd7006a23                                           // 0000002DAA0C: D7006A23
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 0000002DAA10: 02020908
	v_add_co_ci_u32_e64 v44, null, s11, 0, s18                 // 0000002DAA14: D5207C2C 0049000B
	.long 0xd700122f                                           // 0000002DAA1C: D700122F
	v_cndmask_b32_e32 v1, s16, v4, vcc_lo                      // 0000002DAA20: 02020810
	v_add_co_ci_u32_e64 v36, null, 0, v9, vcc_lo               // 0000002DAA24: D5207C24 01AA1280
	v_add_co_ci_u32_e64 v48, null, s17, 0, s18                 // 0000002DAA2C: D5207C30 00490011
	.long 0xd7001233                                           // 0000002DAA34: D7001233
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000002DAA38: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DAA3C: BF8700A1
	v_add_co_ci_u32_e64 v52, null, s15, 0, s18                 // 0000002DAA40: D5207C34 0049000F
	.long 0xd7001237                                           // 0000002DAA48: D7001237
	v_cndmask_b32_e32 v1, s12, v4, vcc_lo                      // 0000002DAA4C: 0202080C
	v_add_co_ci_u32_e64 v56, null, s13, 0, s18                 // 0000002DAA50: D5207C38 0049000D
	global_load_b128 v[11:14], v[35:36], off                   // 0000002DAA58: DC5E0000 0B7C0023
	global_load_b128 v[15:18], v[39:40], off                   // 0000002DAA60: DC5E0000 0F7C0027
	global_load_b128 v[19:22], v[43:44], off                   // 0000002DAA68: DC5E0000 137C002B
	global_load_b128 v[23:26], v[47:48], off                   // 0000002DAA70: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000002DAA78: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[55:56], off                   // 0000002DAA80: DC5E0000 1F7C0037
	global_load_b128 v[35:38], v[35:36], off offset:512        // 0000002DAA88: DC5E0200 237C0023
	global_load_b128 v[39:42], v[39:40], off offset:512        // 0000002DAA90: DC5E0200 277C0027
	global_load_b128 v[43:46], v[43:44], off offset:512        // 0000002DAA98: DC5E0200 2B7C002B
	global_load_b128 v[47:50], v[47:48], off offset:512        // 0000002DAAA0: DC5E0200 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:512        // 0000002DAAA8: DC5E0200 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:512        // 0000002DAAB0: DC5E0200 377C0037
	s_add_u32 s0, s0, 0x200                                    // 0000002DAAB8: 8000FF00 00000200
	s_addc_u32 s1, s1, 0                                       // 0000002DAAC0: 82018001
	s_add_u32 s10, s10, 0x400                                  // 0000002DAAC4: 800AFF0A 00000400
	s_addc_u32 s11, s11, 0                                     // 0000002DAACC: 820B800B
	s_add_u32 s12, s12, 0x400                                  // 0000002DAAD0: 800CFF0C 00000400
	.long 0xd4560012                                           // 0000002DAAD8: D4560012
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002DAADC: 02000C00
	s_addc_u32 s13, s13, 0                                     // 0000002DAAE0: 820D800D
	.long 0xd7006a08                                           // 0000002DAAE4: D7006A08
	v_cndmask_b32_e32 v1, 0x400, v8, vcc_lo                    // 0000002DAAE8: 020210FF 00000400
	s_add_u32 s2, s2, 0x400                                    // 0000002DAAF0: 8002FF02 00000400
	s_addc_u32 s3, s3, 0                                       // 0000002DAAF8: 82038003
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 0000002DAAFC: D5207C09 01AA1280
	s_add_u32 s14, s14, 0x400                                  // 0000002DAB04: 800EFF0E 00000400
	s_addc_u32 s15, s15, 0                                     // 0000002DAB0C: 820F800F
	s_add_u32 s16, s16, 0x400                                  // 0000002DAB10: 8010FF10 00000400
	s_addc_u32 s17, s17, 0                                     // 0000002DAB18: 82118011
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000002DAB1C: 8B6A127E
	s_waitcnt vmcnt(10)                                        // 0000002DAB20: BF892BF7
	v_dot2_f32_bf16 v3, v15, v11, v3                           // 0000002DAB24: CC1A4003 1C0E170F
	s_waitcnt vmcnt(9)                                         // 0000002DAB2C: BF8927F7
	v_dot2_f32_bf16 v10, v19, v11, v10                         // 0000002DAB30: CC1A400A 1C2A1713
	s_waitcnt vmcnt(8)                                         // 0000002DAB38: BF8923F7
	v_dot2_f32_bf16 v7, v23, v11, v7                           // 0000002DAB3C: CC1A4007 1C1E1717
	s_waitcnt vmcnt(7)                                         // 0000002DAB44: BF891FF7
	v_dot2_f32_bf16 v6, v27, v11, v6                           // 0000002DAB48: CC1A4006 1C1A171B
	s_waitcnt vmcnt(6)                                         // 0000002DAB50: BF891BF7
	v_dot2_f32_bf16 v5, v31, v11, v5                           // 0000002DAB54: CC1A4005 1C16171F
	v_dot2_f32_bf16 v3, v16, v12, v3                           // 0000002DAB5C: CC1A4003 1C0E1910
	v_dot2_f32_bf16 v10, v20, v12, v10                         // 0000002DAB64: CC1A400A 1C2A1914
	v_dot2_f32_bf16 v7, v24, v12, v7                           // 0000002DAB6C: CC1A4007 1C1E1918
	v_dot2_f32_bf16 v6, v28, v12, v6                           // 0000002DAB74: CC1A4006 1C1A191C
	v_dot2_f32_bf16 v5, v32, v12, v5                           // 0000002DAB7C: CC1A4005 1C161920
	v_dot2_f32_bf16 v3, v17, v13, v3                           // 0000002DAB84: CC1A4003 1C0E1B11
	v_dot2_f32_bf16 v10, v21, v13, v10                         // 0000002DAB8C: CC1A400A 1C2A1B15
	v_dot2_f32_bf16 v7, v25, v13, v7                           // 0000002DAB94: CC1A4007 1C1E1B19
	v_dot2_f32_bf16 v6, v29, v13, v6                           // 0000002DAB9C: CC1A4006 1C1A1B1D
	v_dot2_f32_bf16 v5, v33, v13, v5                           // 0000002DABA4: CC1A4005 1C161B21
	v_dot2_f32_bf16 v3, v18, v14, v3                           // 0000002DABAC: CC1A4003 1C0E1D12
	v_dot2_f32_bf16 v10, v22, v14, v10                         // 0000002DABB4: CC1A400A 1C2A1D16
	v_dot2_f32_bf16 v7, v26, v14, v7                           // 0000002DABBC: CC1A4007 1C1E1D1A
	v_dot2_f32_bf16 v6, v30, v14, v6                           // 0000002DABC4: CC1A4006 1C1A1D1E
	v_dot2_f32_bf16 v5, v34, v14, v5                           // 0000002DABCC: CC1A4005 1C161D22
	s_waitcnt vmcnt(4)                                         // 0000002DABD4: BF8913F7
	v_dot2_f32_bf16 v3, v39, v35, v3                           // 0000002DABD8: CC1A4003 1C0E4727
	s_waitcnt vmcnt(3)                                         // 0000002DABE0: BF890FF7
	v_dot2_f32_bf16 v10, v43, v35, v10                         // 0000002DABE4: CC1A400A 1C2A472B
	s_waitcnt vmcnt(2)                                         // 0000002DABEC: BF890BF7
	v_dot2_f32_bf16 v7, v47, v35, v7                           // 0000002DABF0: CC1A4007 1C1E472F
	s_waitcnt vmcnt(1)                                         // 0000002DABF8: BF8907F7
	v_dot2_f32_bf16 v6, v51, v35, v6                           // 0000002DABFC: CC1A4006 1C1A4733
	s_waitcnt vmcnt(0)                                         // 0000002DAC04: BF8903F7
	v_dot2_f32_bf16 v5, v55, v35, v5                           // 0000002DAC08: CC1A4005 1C164737
	v_dot2_f32_bf16 v3, v40, v36, v3                           // 0000002DAC10: CC1A4003 1C0E4928
	v_dot2_f32_bf16 v10, v44, v36, v10                         // 0000002DAC18: CC1A400A 1C2A492C
	v_dot2_f32_bf16 v7, v48, v36, v7                           // 0000002DAC20: CC1A4007 1C1E4930
	v_dot2_f32_bf16 v6, v52, v36, v6                           // 0000002DAC28: CC1A4006 1C1A4934
	v_dot2_f32_bf16 v5, v56, v36, v5                           // 0000002DAC30: CC1A4005 1C164938
	v_dot2_f32_bf16 v3, v41, v37, v3                           // 0000002DAC38: CC1A4003 1C0E4B29
	v_dot2_f32_bf16 v10, v45, v37, v10                         // 0000002DAC40: CC1A400A 1C2A4B2D
	v_dot2_f32_bf16 v7, v49, v37, v7                           // 0000002DAC48: CC1A4007 1C1E4B31
	v_dot2_f32_bf16 v6, v53, v37, v6                           // 0000002DAC50: CC1A4006 1C1A4B35
	v_dot2_f32_bf16 v5, v57, v37, v5                           // 0000002DAC58: CC1A4005 1C164B39
	v_dot2_f32_bf16 v3, v42, v38, v3                           // 0000002DAC60: CC1A4003 1C0E4D2A
	v_dot2_f32_bf16 v10, v46, v38, v10                         // 0000002DAC68: CC1A400A 1C2A4D2E
	v_dot2_f32_bf16 v7, v50, v38, v7                           // 0000002DAC70: CC1A4007 1C1E4D32
	v_dot2_f32_bf16 v6, v54, v38, v6                           // 0000002DAC78: CC1A4006 1C1A4D36
	v_dot2_f32_bf16 v5, v58, v38, v5                           // 0000002DAC80: CC1A4005 1C164D3A
	s_cbranch_vccz 65369                                       // 0000002DAC88: BFA3FF59 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll+0xf0>
	s_branch 5                                                 // 0000002DAC8C: BFA00005 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll+0x3a4>
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000002DAC90: CA100080 05060080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v10, 0              // 0000002DAC98: CA100080 070A0080
	v_mov_b32_e32 v3, 0                                        // 0000002DACA0: 7E060280
	.long 0xd71f0004                                           // 0000002DACA4: D71F0004
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DACA8: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DACAC: BF870121
	v_xor_b32_e32 v8, 16, v4                                   // 0000002DACB0: 3A100890
	v_xor_b32_e32 v14, 8, v4                                   // 0000002DACB4: 3A1C0888
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002DACB8: 7C9810A0
	v_cndmask_b32_e32 v8, v4, v8, vcc_lo                       // 0000002DACBC: 02101104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DACC0: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DACC4: 7C981CA0
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000002DACC8: 30101082
	ds_bpermute_b32 v9, v8, v3                                 // 0000002DACCC: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v10                               // 0000002DACD4: DACC0000 0B000A08
	s_waitcnt lgkmcnt(1)                                       // 0000002DACDC: BF89FC17
	v_add_f32_e32 v3, v3, v9                                   // 0000002DACE0: 06061303
	s_waitcnt lgkmcnt(0)                                       // 0000002DACE4: BF89FC07
	v_add_f32_e32 v9, v10, v11                                 // 0000002DACE8: 0612170A
	ds_bpermute_b32 v12, v8, v7                                // 0000002DACEC: DACC0000 0C000708
	ds_bpermute_b32 v13, v8, v6                                // 0000002DACF4: DACC0000 0D000608
	ds_bpermute_b32 v8, v8, v5                                 // 0000002DACFC: DACC0000 08000508
	s_waitcnt lgkmcnt(2)                                       // 0000002DAD04: BF89FC27
	v_dual_cndmask_b32 v14, v4, v14 :: v_dual_add_f32 v7, v7, v12// 0000002DAD08: CA481D04 0E061907
	s_waitcnt lgkmcnt(0)                                       // 0000002DAD10: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DAD14: BF870001
	v_dual_add_f32 v5, v5, v8 :: v_dual_lshlrev_b32 v14, 2, v14// 0000002DAD18: C9221105 050E1C82
	ds_bpermute_b32 v8, v14, v3                                // 0000002DAD20: DACC0000 0800030E
	v_add_f32_e32 v6, v6, v13                                  // 0000002DAD28: 060C1B06
	ds_bpermute_b32 v11, v14, v7                               // 0000002DAD2C: DACC0000 0B00070E
	ds_bpermute_b32 v10, v14, v9                               // 0000002DAD34: DACC0000 0A00090E
	ds_bpermute_b32 v13, v14, v5                               // 0000002DAD3C: DACC0000 0D00050E
	s_waitcnt lgkmcnt(3)                                       // 0000002DAD44: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 0000002DAD48: 06061103
	ds_bpermute_b32 v12, v14, v6                               // 0000002DAD4C: DACC0000 0C00060E
	v_xor_b32_e32 v14, 4, v4                                   // 0000002DAD54: 3A1C0884
	s_waitcnt lgkmcnt(2)                                       // 0000002DAD58: BF89FC27
	v_dual_add_f32 v8, v9, v10 :: v_dual_add_f32 v7, v7, v11   // 0000002DAD5C: C9081509 08061707
	s_waitcnt lgkmcnt(1)                                       // 0000002DAD64: BF89FC17
	v_add_f32_e32 v5, v5, v13                                  // 0000002DAD68: 060A1B05
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DAD6C: 7C981CA0
	v_cndmask_b32_e32 v14, v4, v14, vcc_lo                     // 0000002DAD70: 021C1D04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DAD74: BF870001
	v_lshlrev_b32_e32 v14, 2, v14                              // 0000002DAD78: 301C1C82
	ds_bpermute_b32 v9, v14, v3                                // 0000002DAD7C: DACC0000 0900030E
	ds_bpermute_b32 v11, v14, v7                               // 0000002DAD84: DACC0000 0B00070E
	s_waitcnt lgkmcnt(2)                                       // 0000002DAD8C: BF89FC27
	v_add_f32_e32 v6, v6, v12                                  // 0000002DAD90: 060C1906
	ds_bpermute_b32 v13, v14, v5                               // 0000002DAD94: DACC0000 0D00050E
	s_waitcnt lgkmcnt(2)                                       // 0000002DAD9C: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 0000002DADA0: 06061303
	ds_bpermute_b32 v10, v14, v8                               // 0000002DADA4: DACC0000 0A00080E
	s_waitcnt lgkmcnt(2)                                       // 0000002DADAC: BF89FC27
	v_add_f32_e32 v7, v7, v11                                  // 0000002DADB0: 060E1707
	ds_bpermute_b32 v12, v14, v6                               // 0000002DADB4: DACC0000 0C00060E
	v_xor_b32_e32 v14, 2, v4                                   // 0000002DADBC: 3A1C0882
	s_waitcnt lgkmcnt(2)                                       // 0000002DADC0: BF89FC27
	v_add_f32_e32 v5, v5, v13                                  // 0000002DADC4: 060A1B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DADC8: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DADCC: 7C981CA0
	v_cndmask_b32_e32 v14, v4, v14, vcc_lo                     // 0000002DADD0: 021C1D04
	v_lshlrev_b32_e32 v14, 2, v14                              // 0000002DADD4: 301C1C82
	ds_bpermute_b32 v9, v14, v3                                // 0000002DADD8: DACC0000 0900030E
	s_waitcnt lgkmcnt(0)                                       // 0000002DADE0: BF89FC07
	v_add_f32_e32 v9, v3, v9                                   // 0000002DADE4: 06121303
	ds_bpermute_b32 v11, v14, v7                               // 0000002DADE8: DACC0000 0B00070E
	ds_bpermute_b32 v13, v14, v5                               // 0000002DADF0: DACC0000 0D00050E
	v_add_f32_e32 v8, v8, v10                                  // 0000002DADF8: 06101508
	s_waitcnt lgkmcnt(1)                                       // 0000002DADFC: BF89FC17
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v3, v7, v11   // 0000002DAE00: C9081906 06021707
	ds_bpermute_b32 v10, v14, v8                               // 0000002DAE08: DACC0000 0A00080E
	s_waitcnt lgkmcnt(1)                                       // 0000002DAE10: BF89FC17
	v_add_f32_e32 v7, v5, v13                                  // 0000002DAE14: 060E1B05
	ds_bpermute_b32 v12, v14, v6                               // 0000002DAE18: DACC0000 0C00060E
	v_xor_b32_e32 v14, 1, v4                                   // 0000002DAE20: 3A1C0881
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002DAE24: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DAE28: 7C981CA0
	v_cndmask_b32_e32 v4, v4, v14, vcc_lo                      // 0000002DAE2C: 02081D04
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002DAE30: 7C940080
	v_lshlrev_b32_e32 v14, 2, v4                               // 0000002DAE34: 301C0882
	s_waitcnt lgkmcnt(1)                                       // 0000002DAE38: BF89FC17
	v_add_f32_e32 v10, v8, v10                                 // 0000002DAE3C: 06141508
	s_waitcnt lgkmcnt(0)                                       // 0000002DAE40: BF89FC07
	v_add_f32_e32 v4, v6, v12                                  // 0000002DAE44: 06081906
	ds_bpermute_b32 v11, v14, v9                               // 0000002DAE48: DACC0000 0B00090E
	ds_bpermute_b32 v5, v14, v3                                // 0000002DAE50: DACC0000 0500030E
	ds_bpermute_b32 v12, v14, v10                              // 0000002DAE58: DACC0000 0C000A0E
	ds_bpermute_b32 v8, v14, v7                                // 0000002DAE60: DACC0000 0800070E
	ds_bpermute_b32 v6, v14, v4                                // 0000002DAE68: DACC0000 0600040E
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002DAE70: 8B7E6A7E
	s_cbranch_execz 74                                         // 0000002DAE74: BFA5004A <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi2EEEvPKtS3_Ptll+0x6a0>
	s_waitcnt lgkmcnt(2)                                       // 0000002DAE78: BF89FC27
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v9, v9, v11 // 0000002DAE7C: C908190A 0A081709
	.long 0x7f163880                                           // 0000002DAE84: 7F163880
	.long 0xd73c0000                                           // 0000002DAE88: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002DAE8C: 02020281
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002DAE90: 84808108
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DAE94: BF870003
	.long 0x7e16398a                                           // 0000002DAE98: 7E16398A
	.long 0x7e183989                                           // 0000002DAE9C: 7E183989
	.long 0x7f18398b                                           // 0000002DAEA0: 7F18398B
	s_waitcnt lgkmcnt(1)                                       // 0000002DAEA4: BF89FC17
	v_add_f32_e32 v13, v7, v8                                  // 0000002DAEA8: 061A1107
	.long 0xd7006a07                                           // 0000002DAEAC: D7006A07
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002DAEB0: 02020004
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DAEB4: BF8701B3
	v_dual_add_f32 v15, v3, v5 :: v_dual_and_b32 v12, 1, v12   // 0000002DAEB8: C9240B03 0F0C1881
	.long 0x7f00398b                                           // 0000002DAEC0: 7F00398B
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 0000002DAEC4: D5207C08 01AA0205
	.long 0x7e00398f                                           // 0000002DAECC: 7E00398F
	s_waitcnt lgkmcnt(0)                                       // 0000002DAED0: BF89FC07
	v_add_f32_e32 v14, v4, v6                                  // 0000002DAED4: 061C0D04
	v_and_b32_e32 v2, 1, v11                                   // 0000002DAED8: 36041681
	v_add3_u32 v12, v9, v12, 0x7fff                            // 0000002DAEDC: D655000C 03FE1909 00007FFF
	.long 0xd7006a03                                           // 0000002DAEE8: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DAEEC: 02000107
	v_and_b32_e32 v9, 1, v0                                    // 0000002DAEF0: 36120081
	.long 0x7e16398e                                           // 0000002DAEF4: 7E16398E
	v_mad_u64_u32 v[0:1], null, s8, 6, v[7:8]                  // 0000002DAEF8: D6FE7C00 041D0C08
	v_add3_u32 v16, v10, v2, 0x7fff                            // 0000002DAF00: D6550010 03FE050A 00007FFF
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 0000002DAF0C: D5207C04 01AA1001
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002DAF14: 84808208
	v_and_b32_e32 v2, 1, v11                                   // 0000002DAF18: 36041681
	.long 0xd7006a05                                           // 0000002DAF1C: D7006A05
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DAF20: 02000107
	v_bfe_u32 v10, v13, 16, 1                                  // 0000002DAF24: D610000A 0205210D
	v_add_co_ci_u32_e64 v6, null, s1, v8, vcc_lo               // 0000002DAF2C: D5207C06 01AA1001
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002DAF34: BF870004
	v_add3_u32 v11, v14, v2, 0x7fff                            // 0000002DAF38: D655000B 03FE050E 00007FFF
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002DAF44: D6FE7C01 04050C09
	v_add3_u32 v14, v15, v9, 0x7fff                            // 0000002DAF4C: D655000E 03FE130F 00007FFF
	.long 0xd7006a09                                           // 0000002DAF58: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 0000002DAF5C: 02000105
	v_add3_u32 v2, v13, v10, 0x7fff                            // 0000002DAF60: D6550002 03FE150D 00007FFF
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 0000002DAF6C: D5207C0A 01AA0C01
	s_clause 0x4                                               // 0000002DAF74: BF850004
	global_store_d16_hi_b16 v[7:8], v12, off                   // 0000002DAF78: DC960000 007C0C07
	global_store_d16_hi_b16 v[3:4], v16, off                   // 0000002DAF80: DC960000 007C1003
	global_store_d16_hi_b16 v[5:6], v14, off                   // 0000002DAF88: DC960000 007C0E05
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000002DAF90: DC960000 007C0B00
	global_store_d16_hi_b16 v[9:10], v2, off                   // 0000002DAF98: DC960000 007C0209
	s_endpgm                                                   // 0000002DAFA0: BFB00000
		...

