0000000000820100 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000820100: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000820108: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000082010C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 000000820110: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 000000820114: 3602008F
	v_mov_b32_e32 v5, 0                                        // 000000820118: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000082011C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 000000820120: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 000000820124: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000820128: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 000000820130: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 000000820138: CA240080 1110009F
	.long 0x7f103880                                           // 000000820140: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 000000820144: BF89FC07
	s_clause 0x1                                               // 000000820148: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000082014C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000820154: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 00000082015C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 000000820160: 38021C02
	s_add_u32 s0, s4, s14                                      // 000000820164: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000820168: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000082016C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000820170: BF870009
	s_add_u32 s14, s10, s14                                    // 000000820174: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000820178: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000082017C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000820180: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 000000820184: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000820188: 868E810E
	s_add_u32 s20, s10, s20                                    // 00000082018C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000820190: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000820194: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 000000820198: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 00000082019C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 0000008201A4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008201A8: BF870002
	.long 0xd72c0002                                           // 0000008201AC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000008201B0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 0000008201B4: 85139F15
	.long 0xd72c000d                                           // 0000008201B8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000008201BC: 02001F01
	s_add_i32 s21, s21, s19                                    // 0000008201C0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 0000008201C4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 0000008201CC: 860F8115
	s_add_u32 s0, s4, s16                                      // 0000008201D0: 80001004
	.long 0xd72c0012                                           // 0000008201D4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000008201D8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 0000008201DC: 82011105
	.long 0xd72c0014                                           // 0000008201E0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 0000008201E4: 02001D07
	.long 0xd72c0015                                           // 0000008201E8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 0000008201EC: 02020E12
	v_mov_b32_e32 v29, 0                                       // 0000008201F0: 7E3A0280
	v_mov_b32_e32 v7, 0                                        // 0000008201F4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008201F8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 0000008201FC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 000000820204: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000820208: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000820210: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 000000820214: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000082021C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 000000820228: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 000000820230: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000820234: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 000000820238: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 000000820244: 4A242112
	.long 0x7e103983                                           // 000000820248: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000082024C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 000000820250: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 000000820254: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000082025C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 000000820260: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 00000082026C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 000000820270: 7C822712
	ds_store_b32 v3, v1                                        // 000000820274: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 00000082027C: BF89FC07
	s_barrier                                                  // 000000820280: BFBD0000
	buffer_gl0_inv                                             // 000000820284: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000082028C: BE81206A
	s_cbranch_execz 21                                         // 000000820290: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 000000820294: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 000000820298: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000082029C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008202A0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008202A4: 3408069F
	.long 0xd7000001                                           // 0000008202A8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008202AC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008202B0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000008202B4: D5207C02 00020514
	.long 0xd7000003                                           // 0000008202BC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008202C0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 0000008202C4: D5207C04 0002090A
	s_clause 0x1                                               // 0000008202CC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008202D0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008202D8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008202E0: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000008202E4: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000008202E8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008202EC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008202F4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 0000008202FC: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000820304: BE81206A
	s_cbranch_execz 579                                        // 000000820308: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb18>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 00000082030C: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 000000820314: CA220080 150C2485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000082031C: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000820324: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 000000820328: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 000000820330: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 000000820338: CA100080 111E011D
	s_mul_i32 s0, s11, 6                                       // 000000820340: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000820344: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000820348: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000082034C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 000000820350: 9610860A
	s_mov_b32 s15, 0                                           // 000000820354: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000820358: 848A810A
	s_branch 526                                               // 00000082035C: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xa98>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000820360: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000820364: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000082036C: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 000000820370: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000820378: 8C0F0F00
	v_add_nc_u32_e32 v28, 64, v28                              // 00000082037C: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000820380: 301A1A82
	ds_load_b32 v47, v13                                       // 000000820384: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000082038C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000820390: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000820394: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 00000082039C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008203A4: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008203A8: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008203AC: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008203B4: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008203B8: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 0000008203C0: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 0000008203C8: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008203D0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008203D8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008203DC: 300A0A82
	ds_load_b32 v51, v5                                        // 0000008203E0: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008203E8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008203EC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008203F0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008203F8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000820400: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000820404: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000082040C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000820414: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000820418: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082041C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000820424: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000082042C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000820434: 300A0A82
	ds_load_b32 v55, v5                                        // 000000820438: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000820440: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000820444: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000820448: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000820450: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000820458: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000082045C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000820464: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000082046C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000820470: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000820474: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000082047C: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000820484: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000082048C: 300A0A82
	ds_load_b32 v59, v5                                        // 000000820490: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000820498: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082049C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008204A0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008204A8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008204B0: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008204B4: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000008204BC: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008204C4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008204C8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008204CC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 0000008204D4: D8D80000 3E000005
	.long 0xd73c0005                                           // 0000008204DC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008204E0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008204E4: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 0000008204EC: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008204F0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008204F4: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 0000008204F8: D5207C2C 01AA0C07
	s_clause 0x3                                               // 000000820500: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000820504: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 00000082050C: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000820514: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 00000082051C: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000820524: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000820528: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 000000820530: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820534: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000820538: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 000000820540: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820544: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 00000082054C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820550: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820554: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000082055C: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820560: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 000000820568: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082056C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820570: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 000000820578: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082057C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 000000820584: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820588: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000082058C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000820594: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000820598: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 0000008205A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008205A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008205A8: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 0000008205B0: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008205B4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 0000008205BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008205C0: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008205C4: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008205CC: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008205D0: CC1A4005 1C167727
	.long 0xd7006a27                                           // 0000008205D8: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 0000008205DC: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 0000008205E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008205E4: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008205E8: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 0000008205F0: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 0000008205F8: D7006A2D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 0000008205FC: 0200092B
	s_waitcnt lgkmcnt(1)                                       // 000000820600: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000820604: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s5, v44, vcc_lo             // 00000082060C: D5207C2E 01AA5805
	.long 0xd7006a2b                                           // 000000820614: D7006A2B
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 000000820618: 0200212B
	s_waitcnt lgkmcnt(0)                                       // 00000082061C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000820620: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000820624: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s14, v44, vcc_lo            // 00000082062C: D5207C2C 01AA580E
	v_fmac_f32_e32 v21, v29, v5                                // 000000820634: 562A0B1D
	s_clause 0x3                                               // 000000820638: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000082063C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000820644: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000082064C: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000820654: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000082065C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000820660: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820668: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000082066C: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820674: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082067C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820680: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000820688: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000082068C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820694: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820698: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008206A0: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008206A8: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008206AC: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000008206B4: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008206B8: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008206C0: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008206C4: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008206CC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008206D4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008206D8: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008206E0: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008206E4: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008206EC: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008206F0: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008206F8: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820700: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000820704: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 00000082070C: 56340B1D
	s_clause 0x3                                               // 000000820710: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 000000820714: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 00000082071C: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 000000820724: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 00000082072C: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 000000820734: D7006A2D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000820738: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000082073C: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, vcc_lo             // 000000820740: D5207C2E 01AA5C05
	s_waitcnt vmcnt(3)                                         // 000000820748: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000082074C: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000820754: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082075C: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820760: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820768: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000820770: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820774: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820778: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820780: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820788: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082078C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000820794: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000082079C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008207A0: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008207A4: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008207AC: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008207B4: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008207B8: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008207C0: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008207C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008207CC: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008207D0: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008207D8: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008207E0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008207E4: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008207EC: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008207F4: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 0000008207F8: 56320B1D
	s_clause 0x3                                               // 0000008207FC: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000820800: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000820808: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000820810: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 000000820818: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 000000820820: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000820824: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082082C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000820830: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820838: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820840: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820844: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000082084C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820850: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820858: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000082085C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000820864: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000082086C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000820870: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000820878: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000082087C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820884: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000820888: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000820890: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820898: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000082089C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000008208A4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008208A8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008208B0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008208B4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008208BC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008208C4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008208C8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 0000008208D0: 56300B1D
	s_clause 0x3                                               // 0000008208D4: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 0000008208D8: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 0000008208E0: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 0000008208E8: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 0000008208F0: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 0000008208F8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008208FC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820904: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000820908: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820910: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820918: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000082091C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000820924: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820928: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820930: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820934: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000082093C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820944: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000820948: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000820950: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000820954: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000082095C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000820960: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000820968: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820970: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000820974: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000082097C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000820980: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000820988: D7006A27
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000082098C: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000820990: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000820994: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v44, vcc_lo             // 00000082099C: D5207C28 01AA5805
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008209A4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008209AC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000008209B0: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 0000008209B8: 562E0B1D
	s_clause 0x3                                               // 0000008209BC: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000008209C0: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000008209C8: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000008209D0: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000008209D8: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000008209E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000008209E4: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008209EC: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000008209F0: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000008209F8: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820A00: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820A04: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000820A0C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820A10: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820A18: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820A1C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000820A24: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820A2C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000820A30: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000820A38: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000820A3C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820A44: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000820A48: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000820A50: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820A58: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000820A5C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000820A64: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000820A68: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000820A70: D7006A27
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000820A74: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000820A78: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000820A7C: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v46, vcc_lo             // 000000820A84: D5207C28 01AA5C05
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000820A8C: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820A94: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000820A98: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 000000820AA0: 562C0B1D
	s_clause 0x3                                               // 000000820AA4: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 000000820AA8: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000820AB0: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 000000820AB8: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000820AC0: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 000000820AC8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000820ACC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000820AD4: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000820AD8: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 000000820AE0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000820AE4: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 000000820AEC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000820AF0: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000820AF4: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 000000820AFC: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000820B00: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000820B04: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820B0C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000820B10: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000820B18: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820B20: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000820B24: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000820B2C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000820B30: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820B38: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000820B3C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000820B44: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820B4C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000820B50: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000820B58: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000820B5C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820B64: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000820B68: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000820B70: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820B78: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000820B7C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 000000820B84: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000820B88: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 000000820B8C: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000820B90: 917E0F7E
	s_cbranch_execz 31                                         // 000000820B94: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xb14>
	s_waitcnt vmcnt(0)                                         // 000000820B98: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000820B9C: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000820BA4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000820BAC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000820BB0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000820BB4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000820BB8: 7C8C2712
	.long 0xd4c1007e                                           // 000000820BBC: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000820BC0: 02022712
	s_cbranch_execz 64998                                      // 000000820BC4: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	v_ashrrev_i32_e32 v2, 31, v28                              // 000000820BC8: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 000000820BCC: 3408369F
	.long 0xd7000001                                           // 000000820BD0: D7000001
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 000000820BD4: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820BD8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000820BDC: D5207C02 00020514
	.long 0xd7000003                                           // 000000820BE4: D7000003
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 000000820BE8: 02023709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 000000820BEC: D5207C04 0002090A
	s_clause 0x1                                               // 000000820BF4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000820BF8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000820C00: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000820C08: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 000000820C0C: 7E3C170D
	s_branch 64979                                             // 000000820C10: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000820C14: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000820C18: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000820C1C: 8C7E017E
	.long 0xd71f0001                                           // 000000820C20: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000820C24: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000820C28: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000820C2C: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 000000820C30: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 000000820C34: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000820C38: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000820C3C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000820C40: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000820C44: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000820C48: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000820C4C: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000820C50: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000820C54: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000820C58: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 000000820C5C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000820C64: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000820C68: 06060715
	s_waitcnt vmcnt(0)                                         // 000000820C6C: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 000000820C70: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 000000820C78: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 000000820C80: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 000000820C88: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 000000820C90: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 000000820C98: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 000000820CA0: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 000000820CA8: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 000000820CAC: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 000000820CB4: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 000000820CB8: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 000000820CC0: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 000000820CC4: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 000000820CC8: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 000000820CD0: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 000000820CD8: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 000000820CE0: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 000000820CE4: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 000000820CEC: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 000000820CF0: 06061503
	s_waitcnt lgkmcnt(2)                                       // 000000820CF4: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 000000820CF8: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 000000820D00: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 000000820D08: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 000000820D10: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 000000820D14: 06081704
	s_waitcnt lgkmcnt(1)                                       // 000000820D18: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 000000820D1C: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 000000820D20: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 000000820D28: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 000000820D30: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 000000820D38: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 000000820D40: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 000000820D44: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 000000820D48: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 000000820D50: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 000000820D54: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 000000820D58: DACC0000 09000313
	s_waitcnt lgkmcnt(3)                                       // 000000820D60: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000820D64: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000820D68: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 000000820D6C: 06081504
	ds_bpermute_b32 v13, v19, v7                               // 000000820D70: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000820D78: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 000000820D80: 3A260282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820D84: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000820D88: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 000000820D8C: 02262701
	v_lshlrev_b32_e32 v19, 2, v19                              // 000000820D90: 30262682
	s_waitcnt lgkmcnt(2)                                       // 000000820D94: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 000000820D98: 06061303
	s_waitcnt lgkmcnt(0)                                       // 000000820D9C: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v2, v2, v18   // 000000820DA0: C9081B07 07022502
	ds_bpermute_b32 v10, v19, v4                               // 000000820DA8: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 000000820DB0: DACC0000 0C000613
	ds_bpermute_b32 v13, v19, v7                               // 000000820DB8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000820DC0: DACC0000 12000213
	v_add_f32_e32 v5, v5, v11                                  // 000000820DC8: 060A1705
	v_add_f32_e32 v9, v8, v17                                  // 000000820DCC: 06122308
	ds_bpermute_b32 v8, v19, v3                                // 000000820DD0: DACC0000 08000313
	ds_bpermute_b32 v11, v19, v5                               // 000000820DD8: DACC0000 0B000513
	s_waitcnt lgkmcnt(2)                                       // 000000820DE0: BF89FC27
	v_add_f32_e32 v2, v2, v18                                  // 000000820DE4: 06042502
	ds_bpermute_b32 v17, v19, v9                               // 000000820DE8: DACC0000 11000913
	v_xor_b32_e32 v19, 1, v1                                   // 000000820DF0: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000820DF4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000820DF8: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 000000820DFC: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 000000820E00: 30260282
	s_waitcnt lgkmcnt(2)                                       // 000000820E04: BF89FC27
	v_add_f32_e32 v1, v3, v8                                   // 000000820E08: 06021103
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v8, v7, v13   // 000000820E0C: C9081504 03081B07
	s_waitcnt lgkmcnt(1)                                       // 000000820E14: BF89FC17
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v5, v6, v12   // 000000820E18: C9081705 04041906
	s_waitcnt lgkmcnt(0)                                       // 000000820E20: BF89FC07
	v_add_f32_e32 v10, v9, v17                                 // 000000820E24: 06142309
	ds_bpermute_b32 v6, v19, v1                                // 000000820E28: DACC0000 06000113
	ds_bpermute_b32 v9, v19, v3                                // 000000820E30: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v4                               // 000000820E38: DACC0000 0B000413
	ds_bpermute_b32 v12, v19, v5                               // 000000820E40: DACC0000 0C000513
	ds_bpermute_b32 v13, v19, v8                               // 000000820E48: DACC0000 0D000813
	ds_bpermute_b32 v17, v19, v10                              // 000000820E50: DACC0000 11000A13
	ds_bpermute_b32 v7, v19, v2                                // 000000820E58: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 000000820E60: 7D942080
	s_cbranch_execz 29                                         // 000000820E64: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xddc>
	.long 0xd72c000e                                           // 000000820E68: D72C000E
	v_cndmask_b32_e32 v0, v14, v184, vcc_lo                    // 000000820E6C: 0201710E
	s_waitcnt lgkmcnt(2)                                       // 000000820E70: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 000000820E74: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 000000820E7C: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 000000820E84: BF89FC17
	v_dual_add_f32 v10, v10, v17 :: v_dual_add_f32 v5, v5, v12 // 000000820E88: C908230A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 000000820E90: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 000000820E94: 06040F02
	v_mad_u32_u24 v13, v15, 28, v14                            // 000000820E98: D60B000D 0439390F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000820EA0: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 000000820EA4: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 000000820EAC: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 000000820EB4: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 000000820EBC: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 000000820EC4: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 000000820ECC: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 000000820ED4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 000000820EDC: 8C7E007E
	.long 0xd7050001                                           // 000000820EE0: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 000000820EE4: 02014B00
	.long 0x7f063880                                           // 000000820EE8: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000820EEC: BF89FC07
	s_barrier                                                  // 000000820EF0: BFBD0000
	buffer_gl0_inv                                             // 000000820EF4: E0AC0000 00000000
	.long 0xd7390001                                           // 000000820EFC: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000820F00: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820F04: BF870091
	.long 0xd7044001                                           // 000000820F08: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000820F0C: 02020300
	.long 0xd7395001                                           // 000000820F10: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000820F14: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820F18: BF870091
	.long 0xd7625001                                           // 000000820F1C: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 000000820F20: 020202FF 0000007F
	.long 0xd7030801                                           // 000000820F28: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 000000820F2C: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820F30: BF870091
	.long 0xd7390003                                           // 000000820F34: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000820F38: 02020282
	.long 0xd7000001                                           // 000000820F3C: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000820F40: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000820F44: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000820F48: D5207C02 00010003
	.long 0xd44c0000                                           // 000000820F50: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 000000820F54: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000820F58: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 000000820F5C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000820F60: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000820F64: BE812000
	s_cbranch_execz 82                                         // 000000820F68: BFA50052 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0xfb4>
	.long 0xd7054000                                           // 000000820F6C: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 000000820F70: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 000000820F74: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820F78: BF870092
	.long 0xd7041000                                           // 000000820F7C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000820F80: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000820F84: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820F8C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000820F90: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000820F98: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:7                     // 000000820FA0: D8DC0700 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000820FA8: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000820FAC: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820FB0: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 000000820FB4: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 000000820FB8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820FC0: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000820FC4: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000820FD0: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820FD8: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000820FDC: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000820FE4: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000820FE8: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 000000820FEC: 060C06F2
	v_div_scale_f32 v5, null, v6, v6, 1.0                      // 000000820FF0: D6FC7C05 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 000000820FF8: D6FC6A08 03CA0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000821000: BF870292
	v_rcp_f32_e32 v7, v5                                       // 000000821004: 7E0E5505
	v_fma_f32 v3, -v5, v7, 1.0                                 // 000000821008: D6130003 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000821010: BF870121
	v_fmac_f32_e32 v7, v3, v7                                  // 000000821014: 560E0F03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000821018: D6FE7C03 0202000C
	v_mul_f32_e32 v9, v8, v7                                   // 000000821020: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000821024: BF870091
	v_fma_f32 v10, -v5, v9, v8                                 // 000000821028: D613000A 24221305
	v_fmac_f32_e32 v9, v10, v7                                 // 000000821030: 56120F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000821034: BF870121
	v_fma_f32 v8, -v5, v9, v8                                  // 000000821038: D6130008 24221305
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000821040: D6FE7C04 0412000D
	v_div_fmas_f32 v0, v8, v7, v9                              // 000000821048: D6370000 04260F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000821050: BF870112
	.long 0xd73c0003                                           // 000000821054: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000821058: 02020681
	v_div_fixup_f32 v5, v0, v6, 1.0                            // 00000082105C: D6270005 03CA0D00
	.long 0xd73c0000                                           // 000000821064: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000821068: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000082106C: BF870193
	.long 0xd7006a03                                           // 000000821070: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000821074: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 000000821078: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000821080: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000821088: BF870193
	.long 0xd7006a00                                           // 00000082108C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000821090: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000821094: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008210A0: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008210A4: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008210AC: DC960000 007C0200
	s_endpgm                                                   // 0000008210B4: BFB00000
		...

