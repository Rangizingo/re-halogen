00000000007fca00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007FCA00: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 0000007FCA08: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007FCA0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007FCA10: 86039F02
	.long 0x7f103880                                           // 0000007FCA14: 7F103880
	s_lshl_b64 s[0:1], s[2:3], 4                               // 0000007FCA18: 84808402
	v_mov_b32_e32 v17, 0                                       // 0000007FCA1C: 7E220280
	v_dual_mov_b32 v10, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000007FCA20: CA220001 0A020282
	v_or_b32_e32 v9, s0, v1                                    // 0000007FCA28: 38120200
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 0000007FCA2C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 0000007FCA34: BF89FC07
	s_clause 0x1                                               // 0000007FCA38: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 0000007FCA3C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 0000007FCA44: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000007FCA4C: 7CA8120C
	s_add_u32 s2, s4, s14                                      // 0000007FCA50: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007FCA54: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 0000007FCA58: 85009F0B
	v_mov_b32_e32 v18, 0                                       // 0000007FCA5C: 7E240280
	s_add_u32 s14, s10, s0                                     // 0000007FCA60: 800E000A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000007FCA64: 02161280
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 0000007FCA68: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 0000007FCA70: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 0000007FCA74: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 0000007FCA78: 8680810E
	.long 0xd72c000d                                           // 0000007FCA7C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000007FCA80: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000007FCA84: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000007FCA8C: D72C000F
	v_cndmask_b32_e32 v0, v11, v1, vcc_lo                      // 0000007FCA90: 0200030B
	.long 0xd72c0014                                           // 0000007FCA94: D72C0014
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000007FCA98: 0200010E
	.long 0xd72c000e                                           // 0000007FCA9C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007FCAA0: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 0000007FCAA4: 850E9B14
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000007FCAA8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007FCAB0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000007FCAB4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000007FCABC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000007FCAC0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000007FCAC8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000007FCACC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000007FCAD4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s0, s[2:3]              // 0000007FCAE0: D6FE7C0B 0008010B
	s_add_u32 s2, s10, s14                                     // 0000007FCAE8: 80020E0A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000007FCAEC: D6550007 03FE2707 00007FFF
	s_addc_u32 s3, s11, 0                                      // 0000007FCAF8: 8203800B
	.long 0x7e103984                                           // 0000007FCAFC: 7E103984
	s_lshr_b64 s[2:3], s[2:3], 5                               // 0000007FCB00: 85828502
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 0000007FCB04: CA220080 04120082
	.long 0xd4440000                                           // 0000007FCB0C: D4440000
	v_cndmask_b32_e32 v1, s2, v16, vcc_lo                      // 0000007FCB10: 02022002
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FCB14: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000007FCB18: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 0000007FCB24: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000007FCB2C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000007FCB34: BF89FC07
	s_barrier                                                  // 0000007FCB38: BFBD0000
	buffer_gl0_inv                                             // 0000007FCB3C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 0000007FCB44: BE832000
	s_cbranch_execz 26                                         // 0000007FCB48: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s1, s4, s16                                      // 0000007FCB4C: 80011004
	s_addc_u32 s14, s5, s17                                    // 0000007FCB50: 820E1105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000007FCB54: 30022081
	.long 0xd7000102                                           // 0000007FCB58: D7000102
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 0000007FCB5C: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCB60: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s14, v6, s1                  // 0000007FCB64: D5207C03 00060C0E
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000007FCB6C: 30082084
	.long 0xd7000101                                           // 0000007FCB70: D7000101
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000007FCB74: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FCB78: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s1                    // 0000007FCB7C: D5207C02 00060680
	.long 0xd7000103                                           // 0000007FCB84: D7000103
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000007FCB88: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FCB8C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s1                    // 0000007FCB90: D5207C04 00060080
	s_clause 0x1                                               // 0000007FCB98: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000007FCB9C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007FCBA4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007FCBAC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000007FCBB0: 7E241707
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007FCBB4: 8C7E037E
	v_mov_b32_e32 v19, 0                                       // 0000007FCBB8: 7E260280
	s_and_saveexec_b32 s3, s0                                  // 0000007FCBBC: BE832000
	s_cbranch_execz 281                                        // 0000007FCBC0: BFA50119 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x628>
	v_dual_mov_b32 v22, v18 :: v_dual_lshlrev_b32 v7, 1, v16   // 0000007FCBC4: CA220112 16062081
	.long 0xd7000005                                           // 0000007FCBCC: D7000005
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000007FCBD0: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCBD4: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s0                  // 0000007FCBD8: D5207C06 00020C11
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000007FCBE0: CA220080 0D0C2085
	.long 0xd7000005                                           // 0000007FCBE8: D7000005
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000007FCBEC: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCBF0: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 0000007FCBF4: D5207C06 00020C80
	v_lshl_or_b32 v20, v16, 4, 0x100                           // 0000007FCBFC: D6560014 03FD0910 00000100
	.long 0xd7000005                                           // 0000007FCC08: D7000005
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000007FCC0C: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCC10: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s0                   // 0000007FCC14: D5207C06 00020C05
	v_mov_b32_e32 v21, v16                                     // 0000007FCC1C: 7E2A0310
	.long 0xd700000e                                           // 0000007FCC20: D700000E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 0000007FCC24: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FCC28: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s0                   // 0000007FCC2C: D5207C0F 00020C80
	v_mov_b32_e32 v19, v13                                     // 0000007FCC34: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000007FCC38: 7E22030D
	s_mov_b32 s14, 0                                           // 0000007FCC3C: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007FCC40: 8484810A
	s_branch 222                                               // 0000007FCC44: BFA000DE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x5c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007FCC48: 8C7E0A7E
	.long 0xd73c0017                                           // 0000007FCC4C: D73C0017
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007FCC50: 02021881
	v_and_b32_e32 v55, 0xff, v1                                // 0000007FCC54: 366E02FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v1                               // 0000007FCC5C: 32700286
	v_lshrrev_b32_e32 v57, 14, v1                              // 0000007FCC60: 3272028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007FCC64: 32020296
	v_and_b32_e32 v58, 0xff, v2                                // 0000007FCC68: 367404FF 000000FF
	.long 0xd700012f                                           // 0000007FCC70: D700012F
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007FCC74: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCC78: BF8701A1
	v_add_co_ci_u32_e64 v48, null, s7, v24, s1                 // 0000007FCC7C: D5207C30 00063007
	v_lshlrev_b32_e32 v55, 2, v55                              // 0000007FCC84: 306E6E82
	.long 0xd7000133                                           // 0000007FCC88: D7000133
	v_cndmask_b32_e32 v0, v47, v4, vcc_lo                      // 0000007FCC8C: 0200092F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FCC90: BF870001
	v_add_co_ci_u32_e64 v52, null, s5, v48, s1                 // 0000007FCC94: D5207C34 00066005
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000007FCC9C: 367070FF 000003FC
	ds_load_b32 v55, v55                                       // 0000007FCCA4: D8D80000 37000037
	s_clause 0x7                                               // 0000007FCCAC: BF850007
	global_load_b128 v[23:26], v[47:48], off                   // 0000007FCCB0: DC5E0000 177C002F
	global_load_b128 v[27:30], v[51:52], off                   // 0000007FCCB8: DC5E0000 1B7C0033
	global_load_b128 v[31:34], v[47:48], off offset:16         // 0000007FCCC0: DC5E0010 1F7C002F
	global_load_b128 v[35:38], v[51:52], off offset:16         // 0000007FCCC8: DC5E0010 237C0033
	global_load_b128 v[39:42], v[47:48], off offset:32         // 0000007FCCD0: DC5E0020 277C002F
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000007FCCD8: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000007FCCE0: DC5E0030 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:48         // 0000007FCCE8: DC5E0030 337C0033
	v_and_b32_e32 v57, 0x3fc, v57                              // 0000007FCCF0: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v2                               // 0000007FCCF8: 32760486
	ds_load_b32 v56, v56                                       // 0000007FCCFC: D8D80000 38000038
	v_lshrrev_b32_e32 v60, 14, v2                              // 0000007FCD04: 3278048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007FCD08: 32040496
	ds_load_b32 v57, v57                                       // 0000007FCD0C: D8D80000 39000039
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007FCD14: 360202FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 0000007FCD1C: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000007FCD20: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 0000007FCD28: 367878FF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007FCD30: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007FCD38: D8D80000 01000001
	ds_load_b32 v58, v58                                       // 0000007FCD40: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000007FCD48: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 0000007FCD50: D8D80000 3C00003C
	ds_load_b32 v2, v2                                         // 0000007FCD58: D8D80000 02000002
	s_and_b32 s1, exec_lo, s0                                  // 0000007FCD60: 8B01007E
	.long 0xd700000e                                           // 0000007FCD64: D700000E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 0000007FCD68: 0201410E
	v_add_nc_u32_e32 v12, 0x200, v12                           // 0000007FCD6C: 4A1818FF 00000200
	v_add_nc_u32_e32 v20, 0x100, v20                           // 0000007FCD74: 4A2828FF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s0                  // 0000007FCD7C: D5207C0F 00021E80
	s_or_b32 s14, s1, s14                                      // 0000007FCD84: 8C0E0E01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007FCD88: BF891C77
	v_dot2_f32_bf16 v23, v23, v55, 0                           // 0000007FCD8C: CC1A4017 1A026F17
	s_waitcnt vmcnt(6)                                         // 0000007FCD94: BF891BF7
	v_dot2_f32_bf16 v27, v27, v55, 0                           // 0000007FCD98: CC1A401B 1A026F1B
	v_and_b32_e32 v55, 0xff, v3                                // 0000007FCDA0: 366E06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007FCDA8: BF89FC67
	v_dot2_f32_bf16 v23, v24, v56, v23                         // 0000007FCDAC: CC1A4017 1C5E7118
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FCDB4: BF870003
	v_dot2_f32_bf16 v24, v28, v56, v27                         // 0000007FCDB8: CC1A4018 1C6E711C
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000007FCDC0: 32360686
	v_lshrrev_b32_e32 v28, 14, v3                              // 0000007FCDC4: 3238068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007FCDC8: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000007FCDCC: BF89FC57
	v_dot2_f32_bf16 v23, v25, v57, v23                         // 0000007FCDD0: CC1A4017 1C5E7319
	v_dot2_f32_bf16 v24, v29, v57, v24                         // 0000007FCDD8: CC1A4018 1C62731D
	v_and_b32_e32 v25, 0xff, v4                                // 0000007FCDE0: 363208FF 000000FF
	v_lshrrev_b32_e32 v29, 6, v4                               // 0000007FCDE8: 323A0886
	v_lshrrev_b32_e32 v56, 14, v4                              // 0000007FCDEC: 3270088E
	s_waitcnt lgkmcnt(4)                                       // 0000007FCDF0: BF89FC47
	v_dot2_f32_bf16 v23, v26, v1, v23                          // 0000007FCDF4: CC1A4017 1C5E031A
	v_dot2_f32_bf16 v1, v30, v1, v24                           // 0000007FCDFC: CC1A4001 1C62031E
	v_lshlrev_b32_e32 v24, 2, v55                              // 0000007FCE04: 30306E82
	v_and_b32_e32 v26, 0x3fc, v27                              // 0000007FCE08: 363436FF 000003FC
	v_and_b32_e32 v27, 0x3fc, v28                              // 0000007FCE10: 363638FF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007FCE18: BF891437
	v_dot2_f32_bf16 v23, v31, v58, v23                         // 0000007FCE1C: CC1A4017 1C5E751F
	s_waitcnt vmcnt(4)                                         // 0000007FCE24: BF8913F7
	v_dot2_f32_bf16 v1, v35, v58, v1                           // 0000007FCE28: CC1A4001 1C067523
	ds_load_b32 v24, v24                                       // 0000007FCE30: D8D80000 18000018
	ds_load_b32 v26, v26                                       // 0000007FCE38: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 0000007FCE40: D8D80000 1B00001B
	s_waitcnt lgkmcnt(5)                                       // 0000007FCE48: BF89FC57
	v_dot2_f32_bf16 v23, v32, v59, v23                         // 0000007FCE4C: CC1A4017 1C5E7720
	v_dot2_f32_bf16 v1, v36, v59, v1                           // 0000007FCE54: CC1A4001 1C067724
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007FCE5C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007FCE60: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 0000007FCE68: 30323282
	s_waitcnt lgkmcnt(4)                                       // 0000007FCE6C: BF89FC47
	v_dot2_f32_bf16 v23, v33, v60, v23                         // 0000007FCE70: CC1A4017 1C5E7921
	v_dot2_f32_bf16 v1, v37, v60, v1                           // 0000007FCE78: CC1A4001 1C067925
	v_and_b32_e32 v28, 0x3fc, v29                              // 0000007FCE80: 36383AFF 000003FC
	v_and_b32_e32 v29, 0x3fc, v56                              // 0000007FCE88: 363A70FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007FCE90: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007FCE98: BF89FC37
	v_dot2_f32_bf16 v23, v34, v2, v23                          // 0000007FCE9C: CC1A4017 1C5E0522
	v_dot2_f32_bf16 v1, v38, v2, v1                            // 0000007FCEA4: CC1A4001 1C060526
	ds_load_b32 v2, v3                                         // 0000007FCEAC: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 0000007FCEB4: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 0000007FCEBC: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 0000007FCEC4: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 0000007FCECC: D8D80000 1D000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007FCED4: BF890C77
	v_dot2_f32_bf16 v4, v39, v24, v23                          // 0000007FCED8: CC1A4004 1C5E3127
	s_waitcnt vmcnt(2)                                         // 0000007FCEE0: BF890BF7
	v_dot2_f32_bf16 v1, v43, v24, v1                           // 0000007FCEE4: CC1A4001 1C06312B
	s_waitcnt lgkmcnt(6)                                       // 0000007FCEEC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FCEF0: BF870112
	v_dot2_f32_bf16 v4, v40, v26, v4                           // 0000007FCEF4: CC1A4004 1C123528
	v_dot2_f32_bf16 v1, v44, v26, v1                           // 0000007FCEFC: CC1A4001 1C06352C
	s_waitcnt lgkmcnt(5)                                       // 0000007FCF04: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FCF08: BF870112
	v_dot2_f32_bf16 v4, v41, v27, v4                           // 0000007FCF0C: CC1A4004 1C123729
	v_dot2_f32_bf16 v1, v45, v27, v1                           // 0000007FCF14: CC1A4001 1C06372D
	s_waitcnt lgkmcnt(4)                                       // 0000007FCF1C: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FCF20: BF870112
	v_dot2_f32_bf16 v4, v42, v2, v4                            // 0000007FCF24: CC1A4004 1C12052A
	v_dot2_f32_bf16 v1, v46, v2, v1                            // 0000007FCF2C: CC1A4001 1C06052E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007FCF34: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007FCF38: BF870122
	v_dot2_f32_bf16 v2, v47, v3, v4                            // 0000007FCF3C: CC1A4002 1C12072F
	s_waitcnt vmcnt(0)                                         // 0000007FCF44: BF8903F7
	v_dot2_f32_bf16 v1, v51, v3, v1                            // 0000007FCF48: CC1A4001 1C060733
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000007FCF50: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000007FCF58: BF89FC27
	v_dot2_f32_bf16 v2, v48, v25, v2                           // 0000007FCF5C: CC1A4002 1C0A3330
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007FCF64: BF870123
	v_dot2_f32_bf16 v1, v52, v25, v1                           // 0000007FCF68: CC1A4001 1C063334
	s_waitcnt lgkmcnt(1)                                       // 0000007FCF70: BF89FC17
	v_dot2_f32_bf16 v2, v49, v28, v2                           // 0000007FCF74: CC1A4002 1C0A3931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007FCF7C: BF870122
	v_dot2_f32_bf16 v1, v53, v28, v1                           // 0000007FCF80: CC1A4001 1C063935
	s_waitcnt lgkmcnt(0)                                       // 0000007FCF88: BF89FC07
	v_dot2_f32_bf16 v8, v50, v29, v2                           // 0000007FCF8C: CC1A4008 1C0A3B32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FCF94: BF8701A2
	v_dot2_f32_bf16 v23, v54, v29, v1                          // 0000007FCF98: CC1A4017 1C063B36
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007FCFA0: CA100106 02000105
	v_fmac_f32_e32 v19, v18, v8                                // 0000007FCFA8: 56261112
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FCFAC: BF870003
	v_fmac_f32_e32 v17, v18, v23                               // 0000007FCFB0: 56222F12
	v_mov_b32_e32 v18, v22                                     // 0000007FCFB4: 7E240316
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007FCFB8: 917E0E7E
	s_cbranch_execz 25                                         // 0000007FCFBC: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x624>
	s_waitcnt vmcnt(0)                                         // 0000007FCFC0: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v21, 16, v21    // 0000007FCFC4: CA200102 06142A90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007FCFCC: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007FCFD4: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FCFD8: BF870003
	.long 0xd4430000                                           // 0000007FCFDC: D4430000
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 0000007FCFE0: 02022A02
	s_mov_b32 s10, exec_lo                                     // 0000007FCFE4: BE8A007E
	.long 0xd4c4007e                                           // 0000007FCFE8: D4C4007E
	v_cndmask_b32_e32 v1, s2, v21, vcc_lo                      // 0000007FCFEC: 02022A02
	s_cbranch_execz 65301                                      // 0000007FCFF0: BFA5FF15 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	.long 0xd7000105                                           // 0000007FCFF4: D7000105
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 0000007FCFF8: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FCFFC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s1                    // 0000007FD000: D5207C06 00060080
	global_load_d16_b16 v22, v[14:15], off                     // 0000007FD008: DC820000 167C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007FD010: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000007FD018: BF8907F7
	v_cvt_f32_f16_e32 v22, v22                                 // 0000007FD01C: 7E2C1716
	s_branch 65289                                             // 0000007FD020: BFA0FF09 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x248>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007FD024: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007FD028: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007FD02C: 8C7E037E
	.long 0xd71f0000                                           // 0000007FD030: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007FD034: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000007FD038: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000007FD03C: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000007FD040: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 0000007FD044: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD048: BF870093
	.long 0xd44c0000                                           // 0000007FD04C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007FD050: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000007FD054: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FD05C: BF870114
	.long 0xd44c0000                                           // 0000007FD060: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000007FD064: 020206A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007FD068: 30020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000007FD06C: BF8700D2
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 0000007FD070: D5010003 00020700
	.long 0xd44c0000                                           // 0000007FD078: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007FD07C: 02020AA0
	ds_bpermute_b32 v2, v1, v19                                // 0000007FD080: DACC0000 02001301
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 0000007FD088: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 0000007FD090: BF89FC07
	v_dual_add_f32 v2, v19, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000007FD094: C9220513 02040A82
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007FD09C: 30060682
	ds_bpermute_b32 v1, v1, v17                                // 0000007FD0A0: DACC0000 01001101
	ds_bpermute_b32 v4, v3, v2                                 // 0000007FD0A8: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000007FD0B0: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v17, v1    // 0000007FD0B4: C9080902 02000311
	ds_bpermute_b32 v3, v3, v1                                 // 0000007FD0BC: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000007FD0C4: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007FD0C8: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007FD0CC: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007FD0D4: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000007FD0DC: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD0E0: BF870091
	.long 0xd44c0000                                           // 0000007FD0E4: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007FD0E8: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 0000007FD0EC: D5010000 00020B00
	.long 0xd44a0000                                           // 0000007FD0F4: D44A0000
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000007FD0F8: 02022080
	s_waitcnt lgkmcnt(1)                                       // 0000007FD0FC: BF89FC17
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007FD100: BF870002
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000007FD104: C9220702 00040082
	s_and_b32 s0, s0, vcc_lo                                   // 0000007FD10C: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000007FD110: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007FD114: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 0000007FD118: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 0000007FD120: DACC0000 03000105
	s_and_saveexec_b32 s1, s0                                  // 0000007FD128: BE812000
	s_cbranch_execz 108                                        // 0000007FD12C: BFA5006C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi2ELi0EEEvPKhPKtPvlllllS6_f+0x8e0>
	s_waitcnt lgkmcnt(0)                                       // 0000007FD130: BF89FC07
	v_dual_add_f32 v0, v0, v2 :: v_dual_add_f32 v1, v1, v3     // 0000007FD134: C9080500 00000701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FD13C: BF870111
	v_bfe_u32 v2, v0, 16, 1                                    // 0000007FD140: D6100002 02052100
	v_bfe_u32 v3, v1, 16, 1                                    // 0000007FD148: D6100003 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FD150: BF870112
	v_add3_u32 v0, v0, v2, 0x7fff                              // 0000007FD154: D6550000 03FE0500 00007FFF
	v_add3_u32 v1, v1, v3, 0x7fff                              // 0000007FD160: D6550001 03FE0701 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD16C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007FD170: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000007FD178: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007FD180: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000007FD184: 7E024B01
	v_dual_add_f32 v1, 1.0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 0000007FD188: C92402F2 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD194: BF870091
	v_div_scale_f32 v3, null, v1, v1, 1.0                      // 0000007FD198: D6FC7C03 03CA0301
	v_rcp_f32_e32 v5, v3                                       // 0000007FD1A0: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD1A4: BF870095
	v_fma_f32 v7, -v3, v5, 1.0                                 // 0000007FD1A8: D6130007 23CA0B03
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_fmac_f32 v5, v7, v5// 0000007FD1B0: C8C000FF 00040B07 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007FD1BC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000007FD1C0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007FD1C4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007FD1C8: BF870121
	v_div_scale_f32 v2, null, v0, v0, 1.0                      // 0000007FD1CC: D6FC7C02 03CA0100
	v_div_scale_f32 v8, vcc_lo, 1.0, v0, 1.0                   // 0000007FD1D4: D6FC6A08 03CA00F2
	v_rcp_f32_e32 v4, v2                                       // 0000007FD1DC: 7E085502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD1E0: BF870095
	v_fma_f32 v6, -v2, v4, 1.0                                 // 0000007FD1E4: D6130006 23CA0902
	v_fmac_f32_e32 v4, v6, v4                                  // 0000007FD1EC: 56080906
	v_div_scale_f32 v6, s0, 1.0, v1, 1.0                       // 0000007FD1F0: D6FC0006 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD1F8: BF870092
	v_mul_f32_e32 v7, v8, v4                                   // 0000007FD1FC: 100E0908
	v_fma_f32 v12, -v2, v7, v8                                 // 0000007FD200: D613000C 24220F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD208: BF870091
	v_fmac_f32_e32 v7, v12, v4                                 // 0000007FD20C: 560E090C
	v_fma_f32 v2, -v2, v7, v8                                  // 0000007FD210: D6130002 24220F02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD218: BF870001
	v_div_fmas_f32 v2, v2, v4, v7                              // 0000007FD21C: D6370002 041E0902
	.long 0x7f083880                                           // 0000007FD224: 7F083880
	v_mul_f32_e32 v11, v6, v5                                  // 0000007FD228: 10160B06
	s_mov_b32 vcc_lo, s0                                       // 0000007FD22C: BEEA0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000007FD230: 8480810C
	v_div_fixup_f32 v2, v2, v0, 1.0                            // 0000007FD234: D6270002 03CA0102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD23C: BF870092
	v_fma_f32 v13, -v3, v11, v6                                // 0000007FD240: D613000D 241A1703
	v_fmac_f32_e32 v11, v13, v5                                // 0000007FD248: 56160B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD24C: BF870091
	v_fma_f32 v3, -v3, v11, v6                                 // 0000007FD250: D6130003 241A1703
	v_div_fmas_f32 v3, v3, v5, v11                             // 0000007FD258: D6370003 042E0B03
	.long 0x7f0a3984                                           // 0000007FD260: 7F0A3984
	.long 0x7e0a3982                                           // 0000007FD264: 7E0A3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD268: BF8701A3
	v_div_fixup_f32 v3, v3, v1, 1.0                            // 0000007FD26C: D6270003 03CA0303
	.long 0xd73c0000                                           // 0000007FD274: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000007FD278: 02021281
	v_and_b32_e32 v5, 1, v5                                    // 0000007FD27C: 360A0A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FD280: BF870193
	.long 0x7e083983                                           // 0000007FD284: 7E083983
	.long 0xd7006a00                                           // 0000007FD288: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007FD28C: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FD290: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007FD294: D5207C01 01AA0209
	v_and_b32_e32 v4, 1, v4                                    // 0000007FD29C: 36080881
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000007FD2A0: D6550005 03FE0B02 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FD2AC: BF870194
	.long 0xd7006a02                                           // 0000007FD2B0: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007FD2B4: 02000100
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000007FD2B8: D6550004 03FE0903 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007FD2C4: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007FD2CC: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007FD2D0: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000007FD2D8: DC960000 007C0402
	s_endpgm                                                   // 0000007FD2E0: BFB00000
		...

