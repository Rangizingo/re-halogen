000000000070d000 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi16ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi16ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000070D000: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000070D004: F40C0100 F8000000
	s_load_b64 s[0:1], s[0:1], 0x20                            // 00000070D00C: F4040000 F8000020
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000070D014: 32020084
	s_mov_b32 s3, 0                                            // 00000070D018: BE830080
	v_mov_b32_e32 v8, 0                                        // 00000070D01C: 7E100280
	s_lshl_b64 s[12:13], s[2:3], 4                             // 00000070D020: 848C8402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000070D024: BF8700C9
	v_dual_mov_b32 v2, s13 :: v_dual_and_b32 v7, 15, v0        // 00000070D028: CA24000D 0206008F
	v_or_b32_e32 v1, s12, v1                                   // 00000070D030: 3802020C
	s_waitcnt lgkmcnt(0)                                       // 00000070D034: BF89FC07
	s_ashr_i32 s2, s11, 31                                     // 00000070D038: 86029F0B
	v_cmp_gt_i64_e32 vcc_lo, s[0:1], v[1:2]                    // 00000070D03C: 7CA80200
	s_lshr_b32 s2, s2, 28                                      // 00000070D040: 85029C02
	s_mov_b32 s1, exec_lo                                      // 00000070D044: BE81007E
	s_add_u32 s12, s10, s2                                     // 00000070D048: 800C020A
	s_addc_u32 s13, s11, 0                                     // 00000070D04C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000070D050: BF870499
	s_lshr_b64 s[12:13], s[12:13], 4                           // 00000070D054: 858C840C
	.long 0xd4c4007e                                           // 00000070D058: D4C4007E
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 00000070D05C: 02020E0C
	s_cbranch_execz 364                                        // 00000070D060: BFA5016C <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi16ELi1ELb1EEEvPKhPKtPvll+0x614>
	s_ashr_i32 s0, s11, 31                                     // 00000070D064: 86009F0B
	v_cndmask_b32_e32 v3, 0, v2, vcc_lo                        // 00000070D068: 02060480
	s_lshr_b32 s0, s0, 24                                      // 00000070D06C: 85009800
	v_dual_cndmask_b32 v5, 0, v1 :: v_dual_mov_b32 v6, 0       // 00000070D070: CA500280 05060080
	s_add_u32 s10, s10, s0                                     // 00000070D078: 800A000A
	s_addc_u32 s11, s11, 0                                     // 00000070D07C: 820B800B
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v9, 4, v0          // 00000070D080: CA240080 12080084
	s_ashr_i64 s[10:11], s[10:11], 8                           // 00000070D088: 868A880A
	v_and_b32_e32 v0, 6, v0                                    // 00000070D08C: 36000086
	s_mul_i32 s0, s11, 0xd2                                    // 00000070D090: 9600FF0B 000000D2
	s_mul_hi_u32 s2, s10, 0xd2                                 // 00000070D098: 9682FF0A 000000D2
	s_mulk_i32 s10, 0xd2                                       // 00000070D0A0: B80A00D2
	s_add_i32 s2, s2, s0                                       // 00000070D0A4: 81020002
	.long 0xd72c0008                                           // 00000070D0A8: D72C0008
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000070D0AC: 0202060A
	v_mad_u64_u32 v[3:4], null, s10, v5, s[4:5]                // 00000070D0B0: D6FE7C03 00120A0A
	.long 0xd72c0005                                           // 00000070D0B8: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000070D0BC: 02020A02
	v_lshrrev_b32_e32 v11, 3, v7                               // 00000070D0C0: 32160E83
	v_or_b32_e32 v12, 8, v9                                    // 00000070D0C4: 38181288
	v_or_b32_e32 v13, 8, v0                                    // 00000070D0C8: 381A0088
	v_or_b32_e32 v14, 16, v9                                   // 00000070D0CC: 381C1290
	v_or_b32_e32 v15, 16, v0                                   // 00000070D0D0: 381E0090
	v_dual_mov_b32 v19, v7 :: v_dual_lshlrev_b32 v10, 6, v11   // 00000070D0D4: CA220107 130A1686
	v_lshlrev_b32_e32 v11, 5, v11                              // 00000070D0DC: 30161685
	v_add3_u32 v4, v5, v4, v8                                  // 00000070D0E0: D6550004 04220905
	v_or_b32_e32 v16, 24, v9                                   // 00000070D0E8: 38201298
	v_or_b32_e32 v17, 24, v0                                   // 00000070D0EC: 38220098
	v_dual_mov_b32 v8, v6 :: v_dual_lshlrev_b32 v5, 4, v7      // 00000070D0F0: CA220106 08040E84
	.long 0xd700001c                                           // 00000070D0F8: D700001C
	v_cndmask_b32_e32 v1, v3, v18, vcc_lo                      // 00000070D0FC: 02022503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000070D100: BF870191
	v_add_co_ci_u32_e64 v29, null, 0, v4, s0                   // 00000070D104: D5207C1D 00020880
	v_and_b32_e32 v24, 16, v5                                  // 00000070D10C: 36300A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D110: BF870093
	.long 0xd700001a                                           // 00000070D114: D700001A
	v_cndmask_b32_e32 v1, v28, v10, vcc_lo                     // 00000070D118: 0202151C
	v_add_co_ci_u32_e64 v27, null, 0, v29, s0                  // 00000070D11C: D5207C1B 00023A80
	.long 0xd7000016                                           // 00000070D124: D7000016
	v_cndmask_b32_e32 v1, v28, v11, vcc_lo                     // 00000070D128: 0202171C
	v_and_b32_e32 v25, 32, v5                                  // 00000070D12C: 36320AA0
	v_add_co_ci_u32_e64 v23, null, 0, v29, s0                  // 00000070D130: D5207C17 00023A80
	.long 0xd7000014                                           // 00000070D138: D7000014
	v_cndmask_b32_e32 v1, v28, v7, vcc_lo                      // 00000070D13C: 02020F1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000070D140: BF8700A1
	v_add_co_ci_u32_e64 v21, null, 0, v29, s0                  // 00000070D144: D5207C15 00023A80
	.long 0xd7000016                                           // 00000070D14C: D7000016
	v_cndmask_b32_e32 v1, v22, v24, vcc_lo                     // 00000070D150: 02023116
	v_add_co_ci_u32_e64 v23, null, 0, v23, s0                  // 00000070D154: D5207C17 00022E80
	.long 0xd7000019                                           // 00000070D15C: D7000019
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 00000070D160: 0202331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000070D164: BF8700D1
	v_add_co_ci_u32_e64 v26, null, 0, v27, s0                  // 00000070D168: D5207C1A 00023680
	s_clause 0x1                                               // 00000070D170: BF850001
	global_load_i8 v36, v[20:21], off offset:192               // 00000070D174: DC4600C0 247C0014
	global_load_b128 v[20:23], v[22:23], off offset:128        // 00000070D17C: DC5E0080 147C0016
	.long 0xd7000018                                           // 00000070D184: D7000018
	v_cndmask_b32_e32 v1, v25, v24, vcc_lo                     // 00000070D188: 02023119
	v_add_co_ci_u32_e64 v25, null, 0, v26, s0                  // 00000070D18C: D5207C19 00023480
	s_clause 0x1                                               // 00000070D194: BF850001
	global_load_b128 v[24:27], v[24:25], off                   // 00000070D198: DC5E0000 187C0018
	global_load_d16_b16 v37, v[28:29], off offset:208          // 00000070D1A0: DC8200D0 257C001C
	.long 0xd73c001c                                           // 00000070D1A8: D73C001C
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000070D1AC: 02020A81
	v_add_nc_u32_e32 v19, 16, v19                              // 00000070D1B0: 4A262690
	v_add_nc_u32_e32 v5, 0x100, v5                             // 00000070D1B4: 4A0A0AFF 00000100
	v_add_nc_u32_e32 v18, 0xd2, v18                            // 00000070D1BC: 4A2424FF 000000D2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D1C4: BF870094
	.long 0xd7000020                                           // 00000070D1C8: D7000020
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 00000070D1CC: 02023806
	v_add_co_ci_u32_e64 v33, null, s7, v29, s0                 // 00000070D1D0: D5207C21 00023A07
	s_clause 0x1                                               // 00000070D1D8: BF850001
	global_load_b128 v[28:31], v[32:33], off                   // 00000070D1DC: DC5E0000 1C7C0020
	global_load_b128 v[32:35], v[32:33], off offset:16         // 00000070D1E4: DC5E0010 207C0020
	.long 0xd4430000                                           // 00000070D1EC: D4430000
	v_cndmask_b32_e32 v1, s12, v19, vcc_lo                     // 00000070D1F0: 0202260C
	s_or_b32 s3, s0, s3                                        // 00000070D1F4: 8C030300
	s_waitcnt vmcnt(5)                                         // 00000070D1F8: BF8917F7
	v_cvt_f32_i32_e32 v36, v36                                 // 00000070D1FC: 7E480B24
	s_waitcnt vmcnt(4)                                         // 00000070D200: BF8913F7
	v_lshrrev_b32_e32 v41, v0, v21                             // 00000070D204: 32522B00
	v_lshrrev_b32_e32 v42, v13, v21                            // 00000070D208: 32542B0D
	v_lshrrev_b32_e32 v43, v15, v21                            // 00000070D20C: 32562B0F
	v_lshrrev_b32_e32 v21, v17, v21                            // 00000070D210: 322A2B11
	v_lshrrev_b32_e32 v47, v0, v23                             // 00000070D214: 325E2F00
	v_lshrrev_b32_e32 v48, v13, v23                            // 00000070D218: 32602F0D
	v_lshrrev_b32_e32 v49, v15, v23                            // 00000070D21C: 32622F0F
	v_lshrrev_b32_e32 v23, v17, v23                            // 00000070D220: 322E2F11
	s_waitcnt vmcnt(2)                                         // 00000070D224: BF890BF7
	v_fma_mix_f32 v36, v37, v36, neg(0) op_sel_hi:[1,0,0]      // 00000070D228: CC200024 8A024925
	v_bfe_u32 v52, v25, v9, 4                                  // 00000070D230: D6100034 02121319
	v_bfe_u32 v53, v25, v12, 4                                 // 00000070D238: D6100035 02121919
	v_bfe_u32 v54, v25, v14, 4                                 // 00000070D240: D6100036 02121D19
	v_bfe_u32 v25, v25, v16, 4                                 // 00000070D248: D6100019 02122119
	v_lshlrev_b32_e32 v21, 4, v21                              // 00000070D250: 302A2A84
	v_bfe_u32 v58, v27, v9, 4                                  // 00000070D254: D610003A 0212131B
	v_bfe_u32 v59, v27, v12, 4                                 // 00000070D25C: D610003B 0212191B
	v_bfe_u32 v60, v27, v14, 4                                 // 00000070D264: D610003C 02121D1B
	v_bfe_u32 v27, v27, v16, 4                                 // 00000070D26C: D610001B 0212211B
	v_lshlrev_b32_e32 v23, 4, v23                              // 00000070D274: 302E2E84
	v_and_or_b32 v21, v21, 48, v25                             // 00000070D278: D6570015 04656115
	v_lshrrev_b32_e32 v38, v0, v20                             // 00000070D280: 324C2900
	v_lshrrev_b32_e32 v39, v13, v20                            // 00000070D284: 324E290D
	v_lshrrev_b32_e32 v40, v15, v20                            // 00000070D288: 3250290F
	v_and_or_b32 v23, v23, 48, v27                             // 00000070D28C: D6570017 046D6117
	v_lshrrev_b32_e32 v20, v17, v20                            // 00000070D294: 32282911
	v_subrev_nc_u32_e32 v21, 32, v21                           // 00000070D298: 4E2A2AA0
	v_lshrrev_b32_e32 v44, v0, v22                             // 00000070D29C: 32582D00
	v_lshrrev_b32_e32 v45, v13, v22                            // 00000070D2A0: 325A2D0D
	v_lshrrev_b32_e32 v46, v15, v22                            // 00000070D2A4: 325C2D0F
	v_lshrrev_b32_e32 v22, v17, v22                            // 00000070D2A8: 322C2D11
	v_subrev_nc_u32_e32 v23, 32, v23                           // 00000070D2AC: 4E2E2EA0
	v_bfe_u32 v37, v24, v9, 4                                  // 00000070D2B0: D6100025 02121318
	v_bfe_u32 v50, v24, v12, 4                                 // 00000070D2B8: D6100032 02121918
	v_bfe_u32 v51, v24, v14, 4                                 // 00000070D2C0: D6100033 02121D18
	v_bfe_u32 v24, v24, v16, 4                                 // 00000070D2C8: D6100018 02122118
	v_cvt_f32_i32_e32 v21, v21                                 // 00000070D2D0: 7E2A0B15
	v_lshlrev_b32_e32 v20, 4, v20                              // 00000070D2D4: 30282884
	v_bfe_u32 v55, v26, v9, 4                                  // 00000070D2D8: D6100037 0212131A
	v_lshlrev_b32_e32 v44, 4, v44                              // 00000070D2E0: 30585884
	v_bfe_u32 v56, v26, v12, 4                                 // 00000070D2E4: D6100038 0212191A
	v_bfe_u32 v57, v26, v14, 4                                 // 00000070D2EC: D6100039 02121D1A
	v_bfe_u32 v26, v26, v16, 4                                 // 00000070D2F4: D610001A 0212211A
	v_cvt_f32_i32_e32 v23, v23                                 // 00000070D2FC: 7E2E0B17
	v_dual_mul_f32 v21, v36, v21 :: v_dual_lshlrev_b32 v22, 4, v22// 00000070D300: C8E22B24 15162C84
	v_and_or_b32 v20, v20, 48, v24                             // 00000070D308: D6570014 04616114
	v_and_or_b32 v25, v44, 48, v55                             // 00000070D310: D6570019 04DD612C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000070D318: BF870214
	v_mul_f32_e32 v23, v36, v23                                // 00000070D31C: 102E2F24
	v_and_or_b32 v22, v22, 48, v26                             // 00000070D320: D6570016 04696116
	v_lshlrev_b32_e32 v38, 4, v38                              // 00000070D328: 304C4C84
	v_subrev_nc_u32_e32 v20, 32, v20                           // 00000070D32C: 4E2828A0
	v_subrev_nc_u32_e32 v25, 32, v25                           // 00000070D330: 4E3232A0
	v_lshlrev_b32_e32 v40, 4, v40                              // 00000070D334: 30505084
	v_subrev_nc_u32_e32 v22, 32, v22                           // 00000070D338: 4E2C2CA0
	v_lshlrev_b32_e32 v41, 4, v41                              // 00000070D33C: 30525284
	v_cvt_f32_i32_e32 v20, v20                                 // 00000070D340: 7E280B14
	v_lshlrev_b32_e32 v39, 4, v39                              // 00000070D344: 304E4E84
	v_lshlrev_b32_e32 v43, 4, v43                              // 00000070D348: 30565684
	v_lshlrev_b32_e32 v46, 4, v46                              // 00000070D34C: 305C5C84
	v_lshlrev_b32_e32 v47, 4, v47                              // 00000070D350: 305E5E84
	v_lshlrev_b32_e32 v48, 4, v48                              // 00000070D354: 30606084
	v_lshlrev_b32_e32 v49, 4, v49                              // 00000070D358: 30626284
	v_and_or_b32 v37, v38, 48, v37                             // 00000070D35C: D6570025 04956126
	v_cvt_f32_i32_e32 v25, v25                                 // 00000070D364: 7E320B19
	v_lshlrev_b32_e32 v42, 4, v42                              // 00000070D368: 30545484
	v_cvt_f32_i32_e32 v22, v22                                 // 00000070D36C: 7E2C0B16
	v_dual_mul_f32 v20, v36, v20 :: v_dual_lshlrev_b32 v45, 4, v45// 00000070D370: C8E22924 142C5A84
	v_and_or_b32 v38, v39, 48, v50                             // 00000070D378: D6570026 04C96127
	v_and_or_b32 v39, v40, 48, v51                             // 00000070D380: D6570027 04CD6128
	v_and_or_b32 v24, v41, 48, v52                             // 00000070D388: D6570018 04D16129
	v_and_or_b32 v41, v43, 48, v54                             // 00000070D390: D6570029 04D9612B
	v_and_or_b32 v43, v46, 48, v57                             // 00000070D398: D657002B 04E5612E
	v_and_or_b32 v26, v47, 48, v58                             // 00000070D3A0: D657001A 04E9612F
	v_and_or_b32 v44, v48, 48, v59                             // 00000070D3A8: D657002C 04ED6130
	v_subrev_nc_u32_e32 v27, 32, v37                           // 00000070D3B0: 4E364AA0
	v_mul_f32_e32 v25, v36, v25                                // 00000070D3B4: 10323324
	v_and_or_b32 v40, v42, 48, v53                             // 00000070D3B8: D6570028 04D5612A
	v_mul_f32_e32 v22, v36, v22                                // 00000070D3C0: 102C2D24
	v_and_or_b32 v42, v45, 48, v56                             // 00000070D3C4: D657002A 04E1612D
	v_and_or_b32 v45, v49, 48, v60                             // 00000070D3CC: D657002D 04F16131
	v_subrev_nc_u32_e32 v37, 32, v38                           // 00000070D3D4: 4E4A4CA0
	v_subrev_nc_u32_e32 v38, 32, v39                           // 00000070D3D8: 4E4C4EA0
	v_subrev_nc_u32_e32 v24, 32, v24                           // 00000070D3DC: 4E3030A0
	v_subrev_nc_u32_e32 v39, 32, v40                           // 00000070D3E0: 4E4E50A0
	v_subrev_nc_u32_e32 v40, 32, v41                           // 00000070D3E4: 4E5052A0
	v_subrev_nc_u32_e32 v41, 32, v42                           // 00000070D3E8: 4E5254A0
	v_subrev_nc_u32_e32 v42, 32, v43                           // 00000070D3EC: 4E5456A0
	v_subrev_nc_u32_e32 v26, 32, v26                           // 00000070D3F0: 4E3434A0
	v_subrev_nc_u32_e32 v43, 32, v44                           // 00000070D3F4: 4E5658A0
	v_subrev_nc_u32_e32 v44, 32, v45                           // 00000070D3F8: 4E585AA0
	v_cvt_f32_i32_e32 v27, v27                                 // 00000070D3FC: 7E360B1B
	v_cvt_f32_i32_e32 v37, v37                                 // 00000070D400: 7E4A0B25
	v_cvt_f32_i32_e32 v38, v38                                 // 00000070D404: 7E4C0B26
	v_cvt_f32_i32_e32 v24, v24                                 // 00000070D408: 7E300B18
	v_cvt_f32_i32_e32 v39, v39                                 // 00000070D40C: 7E4E0B27
	v_cvt_f32_i32_e32 v40, v40                                 // 00000070D410: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 00000070D414: 7E520B29
	v_cvt_f32_i32_e32 v42, v42                                 // 00000070D418: 7E540B2A
	v_cvt_f32_i32_e32 v26, v26                                 // 00000070D41C: 7E340B1A
	v_cvt_f32_i32_e32 v43, v43                                 // 00000070D420: 7E560B2B
	v_cvt_f32_i32_e32 v44, v44                                 // 00000070D424: 7E580B2C
	v_mul_f32_e32 v27, v36, v27                                // 00000070D428: 10363724
	v_mul_f32_e32 v37, v36, v37                                // 00000070D42C: 104A4B24
	v_mul_f32_e32 v38, v36, v38                                // 00000070D430: 104C4D24
	v_mul_f32_e32 v24, v36, v24                                // 00000070D434: 10303124
	v_mul_f32_e32 v39, v36, v39                                // 00000070D438: 104E4F24
	v_mul_f32_e32 v40, v36, v40                                // 00000070D43C: 10505124
	v_mul_f32_e32 v41, v36, v41                                // 00000070D440: 10525324
	v_mul_f32_e32 v42, v36, v42                                // 00000070D444: 10545524
	v_mul_f32_e32 v26, v36, v26                                // 00000070D448: 10343524
	v_mul_f32_e32 v43, v36, v43                                // 00000070D44C: 10565724
	v_mul_f32_e32 v44, v36, v44                                // 00000070D450: 10585924
	v_bfe_u32 v36, v27, 16, 1                                  // 00000070D454: D6100024 0205211B
	v_bfe_u32 v45, v37, 16, 1                                  // 00000070D45C: D610002D 02052125
	v_bfe_u32 v46, v38, 16, 1                                  // 00000070D464: D610002E 02052126
	v_bfe_u32 v47, v20, 16, 1                                  // 00000070D46C: D610002F 02052114
	v_bfe_u32 v48, v24, 16, 1                                  // 00000070D474: D6100030 02052118
	v_add3_u32 v27, v27, v36, 0x7fff                           // 00000070D47C: D655001B 03FE491B 00007FFF
	v_add3_u32 v37, v37, v45, 0x7fff                           // 00000070D488: D6550025 03FE5B25 00007FFF
	v_add3_u32 v38, v38, v46, 0x7fff                           // 00000070D494: D6550026 03FE5D26 00007FFF
	v_bfe_u32 v49, v39, 16, 1                                  // 00000070D4A0: D6100031 02052127
	v_add3_u32 v20, v20, v47, 0x7fff                           // 00000070D4A8: D6550014 03FE5F14 00007FFF
	.long 0x7e4a399b                                           // 00000070D4B4: 7E4A399B
	v_bfe_u32 v50, v40, 16, 1                                  // 00000070D4B8: D6100032 02052128
	v_add3_u32 v24, v24, v48, 0x7fff                           // 00000070D4C0: D6550018 03FE6118 00007FFF
	.long 0x7e2839a6                                           // 00000070D4CC: 7E2839A6
	v_bfe_u32 v51, v21, 16, 1                                  // 00000070D4D0: D6100033 02052115
	s_waitcnt vmcnt(1)                                         // 00000070D4D8: BF8907F7
	v_dot2_f32_bf16 v28, v28, v37, 0                           // 00000070D4DC: CC1A401C 1A024B1C
	v_add3_u32 v38, v39, v49, 0x7fff                           // 00000070D4E4: D6550026 03FE6327 00007FFF
	v_bfe_u32 v36, v25, 16, 1                                  // 00000070D4F0: D6100024 02052119
	v_add3_u32 v39, v40, v50, 0x7fff                           // 00000070D4F8: D6550027 03FE6528 00007FFF
	.long 0x7e4c3998                                           // 00000070D504: 7E4C3998
	v_dot2_f32_bf16 v20, v29, v20, v28                         // 00000070D508: CC1A4014 1C72291D
	v_bfe_u32 v52, v41, 16, 1                                  // 00000070D510: D6100034 02052129
	v_add3_u32 v21, v21, v51, 0x7fff                           // 00000070D518: D6550015 03FE6715 00007FFF
	v_bfe_u32 v27, v42, 16, 1                                  // 00000070D524: D610001B 0205212A
	v_add3_u32 v25, v25, v36, 0x7fff                           // 00000070D52C: D6550019 03FE4919 00007FFF
	.long 0x7e2a39a7                                           // 00000070D538: 7E2A39A7
	v_dot2_f32_bf16 v20, v30, v38, v20                         // 00000070D53C: CC1A4014 1C524D1E
	v_bfe_u32 v37, v22, 16, 1                                  // 00000070D544: D6100025 02052116
	v_add3_u32 v29, v41, v52, 0x7fff                           // 00000070D54C: D655001D 03FE6929 00007FFF
	v_bfe_u32 v24, v26, 16, 1                                  // 00000070D558: D6100018 0205211A
	v_add3_u32 v27, v42, v27, 0x7fff                           // 00000070D560: D655001B 03FE372A 00007FFF
	.long 0x7e3a3999                                           // 00000070D56C: 7E3A3999
	v_dot2_f32_bf16 v20, v31, v21, v20                         // 00000070D570: CC1A4014 1C522B1F
	v_bfe_u32 v28, v43, 16, 1                                  // 00000070D578: D610001C 0205212B
	v_add3_u32 v22, v22, v37, 0x7fff                           // 00000070D580: D6550016 03FE4B16 00007FFF
	v_bfe_u32 v21, v44, 16, 1                                  // 00000070D58C: D6100015 0205212C
	v_add3_u32 v24, v26, v24, 0x7fff                           // 00000070D594: D6550018 03FE311A 00007FFF
	.long 0x7e2c399b                                           // 00000070D5A0: 7E2C399B
	s_waitcnt vmcnt(0)                                         // 00000070D5A4: BF8903F7
	v_dot2_f32_bf16 v20, v32, v29, v20                         // 00000070D5A8: CC1A4014 1C523B20
	v_bfe_u32 v25, v23, 16, 1                                  // 00000070D5B0: D6100019 02052117
	v_add3_u32 v26, v43, v28, 0x7fff                           // 00000070D5B8: D655001A 03FE392B 00007FFF
	v_add3_u32 v21, v44, v21, 0x7fff                           // 00000070D5C4: D6550015 03FE2B2C 00007FFF
	.long 0x7e343998                                           // 00000070D5D0: 7E343998
	v_dot2_f32_bf16 v20, v33, v22, v20                         // 00000070D5D4: CC1A4014 1C522D21
	v_add3_u32 v22, v23, v25, 0x7fff                           // 00000070D5DC: D6550016 03FE3317 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000070D5E8: BF870194
	.long 0x7e2c3995                                           // 00000070D5EC: 7E2C3995
	v_dot2_f32_bf16 v20, v34, v26, v20                         // 00000070D5F0: CC1A4014 1C523522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D5F8: BF870091
	v_dot2_f32_bf16 v20, v35, v22, v20                         // 00000070D5FC: CC1A4014 1C522D23
	v_add_f32_e32 v8, v8, v20                                  // 00000070D604: 06102908
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 00000070D608: 917E037E
	s_cbranch_execnz 65210                                     // 00000070D60C: BFA6FEBA <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi16ELi1ELb1EEEvPKhPKtPvll+0xf8>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000070D610: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000070D614: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000070D618: 8C7E017E
	.long 0xd71f0000                                           // 00000070D61C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000070D620: 020100C1
	v_xor_b32_e32 v3, 8, v0                                    // 00000070D624: 3A060088
	v_xor_b32_e32 v4, 4, v0                                    // 00000070D628: 3A080084
	v_xor_b32_e32 v5, 2, v0                                    // 00000070D62C: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D630: BF870093
	.long 0xd44c0000                                           // 00000070D634: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 00000070D638: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 00000070D63C: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000070D644: BF870114
	.long 0xd44c0000                                           // 00000070D648: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 00000070D64C: 020208A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000070D650: 30060682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000070D654: BF870002
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 00000070D658: D5010004 00020900
	.long 0xd44c0000                                           // 00000070D660: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000070D664: 02020AA0
	ds_bpermute_b32 v3, v3, v8                                 // 00000070D668: DACC0000 03000803
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000070D670: 30080882
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 00000070D674: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 00000070D67C: BF89FC07
	v_add_f32_e32 v3, v8, v3                                   // 00000070D680: 06060708
	ds_bpermute_b32 v4, v4, v3                                 // 00000070D684: DACC0000 04000304
	s_waitcnt lgkmcnt(0)                                       // 00000070D68C: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 00000070D690: 06060903
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000070D694: 300A0A82
	ds_bpermute_b32 v4, v5, v3                                 // 00000070D698: DACC0000 04000305
	v_xor_b32_e32 v5, 1, v0                                    // 00000070D6A0: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D6A4: BF870091
	.long 0xd44c0000                                           // 00000070D6A8: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000070D6AC: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 00000070D6B0: D5010005 00020B00
	.long 0xd44a0000                                           // 00000070D6B8: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000070D6BC: 02020E80
	s_and_b32 s0, s0, vcc_lo                                   // 00000070D6C0: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000070D6C4: BF89FC07
	v_dual_add_f32 v0, v3, v4 :: v_dual_lshlrev_b32 v3, 2, v5  // 00000070D6C8: C9220903 00020A82
	ds_bpermute_b32 v3, v3, v0                                 // 00000070D6D0: DACC0000 03000003
	s_and_saveexec_b32 s1, s0                                  // 00000070D6D8: BE812000
	s_cbranch_execz 11                                         // 00000070D6DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi16ELi1ELb1EEEvPKhPKtPvll+0x70c>
	.long 0xd73c0001                                           // 00000070D6E0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000070D6E4: 02020282
	s_waitcnt lgkmcnt(0)                                       // 00000070D6E8: BF89FC07
	v_add_f32_e32 v3, v0, v3                                   // 00000070D6EC: 06060700
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000070D6F0: BF870092
	.long 0xd7006a00                                           // 00000070D6F4: D7006A00
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 00000070D6F8: 02020208
	v_add_co_ci_u32_e64 v1, null, s9, v2, vcc_lo               // 00000070D6FC: D5207C01 01AA0409
	global_store_b32 v[0:1], v3, off                           // 00000070D704: DC6A0000 007C0300
	s_endpgm                                                   // 00000070D70C: BFB00000
		...

