0000000000510c00 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000510C00: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000510C04: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 000000510C0C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000510C14: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 000000510C1C: BE8A0003
	v_and_b32_e32 v21, 31, v0                                  // 000000510C20: 362A009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000510C24: 32260085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000510C28: BF870002
	v_lshlrev_b32_e32 v8, 3, v21                               // 000000510C2C: 30102A83
	s_waitcnt lgkmcnt(0)                                       // 000000510C30: BF89FC07
	s_ashr_i32 s11, s25, 31                                    // 000000510C34: 860B9F19
	s_mul_i32 s34, s27, s10                                    // 000000510C38: 96220A1B
	s_lshr_b32 s3, s11, 25                                     // 000000510C3C: 8503990B
	s_add_i32 s4, s34, s27                                     // 000000510C40: 81041B22
	s_add_i32 s3, s25, s3                                      // 000000510C44: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000510C48: BF870499
	s_ashr_i32 s3, s3, 7                                       // 000000510C4C: 86038703
	s_min_i32 s3, s3, s4                                       // 000000510C50: 89030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000510C54: BF8704B9
	s_sub_i32 s9, s3, s34                                      // 000000510C58: 81892203
	s_mov_b32 s3, exec_lo                                      // 000000510C5C: BE83007E
	s_lshl_b32 s27, s9, 2                                      // 000000510C60: 841B8209
	.long 0xd4c3007e                                           // 000000510C64: D4C3007E
	v_cndmask_b32_e32 v1, s27, v19, vcc_lo                     // 000000510C68: 0202261B
	s_xor_b32 s3, exec_lo, s3                                  // 000000510C6C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v21                               // 000000510C70: 30102A83
	s_or_saveexec_b32 s35, s3                                  // 000000510C74: BEA32203
	s_clause 0x1                                               // 000000510C78: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 000000510C7C: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000510C84: F4080700 F8000000
	v_lshlrev_b32_e32 v20, 2, v21                              // 000000510C8C: 30282A82
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000510C90: 8D7E237E
	s_cbranch_execz 500                                        // 000000510C94: BFA501F4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	s_add_i32 s36, s24, -1                                     // 000000510C98: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 000000510C9C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 000000510CA0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 000000510CA4: 982580C1
	s_abs_i32 s38, s9                                          // 000000510CA8: BEA61509
	v_and_b32_e32 v3, 2, v0                                    // 000000510CAC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 000000510CB0: BE806526
	v_dual_mov_b32 v9, v19 :: v_dual_and_b32 v4, 4, v0         // 000000510CB4: CA240113 09040084
	v_and_b32_e32 v5, 8, v0                                    // 000000510CBC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000510CC0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 000000510CC4: 7E045600
	v_lshl_or_b32 v6, v19, 8, v8                               // 000000510CC8: D6560006 04211113
	v_add_nc_u32_e32 v7, s34, v19                              // 000000510CD0: 4A0E2622
	s_ashr_i32 s42, s9, 31                                     // 000000510CD4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 000000510CD8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 000000510CDC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 000000510CE4: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000510CE8: 02022A90
	.long 0xd44a0001                                           // 000000510CEC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000510CF0: 02020280
	.long 0xd44a0004                                           // 000000510CF4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 000000510CF8: 02020880
	.long 0xd44a0005                                           // 000000510CFC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000510D00: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000510D04: 7E060502
	v_lshl_or_b32 v1, v7, 7, v20                               // 000000510D08: D6560001 04510F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000510D10: 4E140C2C
	s_lshl_b32 s6, s9, 7                                       // 000000510D14: 84068709
	s_mov_b32 s39, s25                                         // 000000510D18: BEA70019
	s_mul_f32 s7, s3, 0x4f7ffffe                               // 000000510D1C: A207FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000510D24: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000510D28: 02020680
	s_mov_b32 s40, 0                                           // 000000510D2C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000510D30: BEA900FF 76543210
	s_cvt_u32_f32 s7, s7                                       // 000000510D38: BE876707
	s_lshl_b32 s43, s9, 8                                      // 000000510D3C: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000510D40: 81AC0680
	s_mov_b32 s46, 0x3db504f3                                  // 000000510D44: BEAE00FF 3DB504F3
	s_mul_i32 s8, s8, s7                                       // 000000510D4C: 96080708
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000510D50: BF870499
	s_mul_hi_u32 s8, s7, s8                                    // 000000510D54: 96880807
	s_add_i32 s45, s7, s8                                      // 000000510D58: 812D0807
	s_branch 161                                               // 000000510D5C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000510D60: BF870091
	.long 0xd7006a02                                           // 000000510D64: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000510D68: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000510D6C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000510D74: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000510D7C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000510D84: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000510D88: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 000000510D8C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000510D94: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000510D98: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000510DA0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 000000510DA4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 000000510DAC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510DB0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000510DB8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000510DC0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 000000510DC4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510DCC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000510DD4: D5010007 20060F07
	.long 0xd72c0006                                           // 000000510DDC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 000000510DE0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510DE8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000510DF0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 000000510DF8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 000000510DFC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510E00: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000510E08: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510E10: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000510E18: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000510E1C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510E24: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 000000510E2C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000510E30: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510E38: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000510E40: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000510E48: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510E4C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000510E54: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 000000510E5C: 060A1905
	.long 0xd72c0007                                           // 000000510E60: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000510E64: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000510E68: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510E6C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000510E74: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000510E78: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510E80: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000510E88: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510E90: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510E98: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000510EA0: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000510EA8: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 000000510EB0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000510EB8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 000000510EBC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000510EC4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510EC8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000510ED0: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 000000510ED8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510EDC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000510EE4: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510EEC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000510EF4: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 000000510EFC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510F00: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000510F08: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000510F10: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000510F14: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 000000510F1C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000510F20: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000510F28: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 000000510F2C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000510F34: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000510F38: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 000000510F3C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000510F48: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000510F50: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000510F54: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000510F5C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000510F64: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000510F70: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 000000510F7C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000510F80: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s27, v9                           // 000000510F8C: 7C86121B
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000510F90: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000510F98: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000510F9C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 000000510FA0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000510FAC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000510FB4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000510FBC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000510FC0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 000000510FC8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 000000510FD0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 000000510FD4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000510FDC: 917E287E
	s_cbranch_execz 288                                        // 000000510FE0: BFA50120 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x864>
	.long 0xd72d0002                                           // 000000510FE4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 000000510FE8: 02005B09
	s_mov_b32 s6, -1                                           // 000000510FEC: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000510FF0: BF870091
	.long 0xd72c0003                                           // 000000510FF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000510FF8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 000000510FFC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000511000: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000511004: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000511008: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000051100C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511014: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000511018: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000051101C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511020: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000511024: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000511028: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000051102C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511030: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000511034: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000511038: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000051103C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000511040: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000511048: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000051104C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511054: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000511058: 340E0C9F
	.long 0xd73c0002                                           // 00000051105C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000511060: 02020C81
	s_cbranch_vccnz 210                                        // 000000511064: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511068: BF870093
	.long 0xd7006a06                                           // 00000051106C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000511070: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000511074: D5207C07 01AA0F05
	.long 0x7f403880                                           // 00000051107C: 7F403880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511080: BF870112
	.long 0xd73c0006                                           // 000000511084: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000511088: 02020C81
	.long 0x7f4639a0                                           // 00000051108C: 7F4639A0
	s_waitcnt lgkmcnt(0)                                       // 000000511090: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511094: BF870092
	.long 0xd7006a0d                                           // 000000511098: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000051109C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 0000005110A0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 0000005110A8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 0000005110AC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005110B0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 0000005110B4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 0000005110BC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 0000005110C4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005110C8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 0000005110CC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 0000005110D4: D5207C10 01AA060D
	s_clause 0x1                                               // 0000005110DC: BF850001
	global_load_b32 v17, v[15:16], off                         // 0000005110E0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 0000005110E8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 0000005110F0: BF890FF7
	.long 0x7e20390d                                           // 0000005110F4: 7E20390D
	v_lshlrev_b32_e32 v18, 16, v14                             // 0000005110F8: 30241C90
	v_and_b32_e32 v14, 0xffff0000, v14                         // 0000005110FC: 361C1CFF FFFF0000
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000511104: 361A1AFF FFFF0000
	s_waitcnt vmcnt(2)                                         // 00000051110C: BF890BF7
	v_and_b32_e32 v42, 0xffff0000, v6                          // 000000511110: 36540CFF FFFF0000
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000511118: 30202090
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000051111C: 300C0C90
	v_mul_f32_e32 v25, 0xbfb8aa3b, v14                         // 000000511120: 10321CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511128: BF870113
	v_mul_f32_e32 v23, 0xbfb8aa3b, v16                         // 00000051112C: 102E20FF BFB8AA3B
	v_exp_f32_e32 v25, v25                                     // 000000511134: 7E324B19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000511138: BF870321
	v_exp_f32_e32 v23, v23                                     // 00000051113C: 7E2E4B17
	v_mul_f32_e32 v22, 0xbfb8aa3b, v13                         // 000000511140: 102C1AFF BFB8AA3B
	v_add_f32_e32 v25, 1.0, v25                                // 000000511148: 063232F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000051114C: BF870195
	v_add_f32_e32 v23, 1.0, v23                                // 000000511150: 062E2EF2
	v_exp_f32_e32 v22, v22                                     // 000000511154: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511158: BF870112
	v_div_scale_f32 v30, null, v25, v25, v14                   // 00000051115C: D6FC7C1E 043A3319
	v_div_scale_f32 v27, null, v23, v23, v16                   // 000000511164: D6FC7C1B 04422F17
	v_div_scale_f32 v40, s7, v16, v23, v16                     // 00000051116C: D6FC0728 04422F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511174: BF870113
	v_rcp_f32_e32 v34, v30                                     // 000000511178: 7E44551E
	v_rcp_f32_e32 v31, v27                                     // 00000051117C: 7E3E551B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511180: BF870097
	v_add_f32_e32 v22, 1.0, v22                                // 000000511184: 062C2CF2
	v_div_scale_f32 v26, null, v22, v22, v13                   // 000000511188: D6FC7C1A 04362D16
	v_div_scale_f32 v36, vcc_lo, v13, v22, v13                 // 000000511190: D6FC6A24 04362D0D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000511198: BF870195
	v_fma_f32 v39, -v27, v31, 1.0                              // 00000051119C: D6130027 23CA3F1B
	v_rcp_f32_e32 v29, v26                                     // 0000005111A4: 7E3A551A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000005111A8: BF8702A1
	v_fmac_f32_e32 v31, v39, v31                               // 0000005111AC: 563E3F27
	v_div_scale_f32 v39, s8, v14, v25, v14                     // 0000005111B0: D6FC0827 043A330E
	v_fma_f32 v37, -v26, v29, 1.0                              // 0000005111B8: D6130025 23CA3B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005111C0: BF870091
	v_dual_mul_f32 v24, 0xbfb8aa3b, v18 :: v_dual_fmac_f32 v29, v37, v29// 0000005111C4: C8C024FF 181C3B25 BFB8AA3B
	v_exp_f32_e32 v24, v24                                     // 0000005111D0: 7E304B18
	v_fma_f32 v37, -v30, v34, 1.0                              // 0000005111D4: D6130025 23CA451E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000005111DC: BF870291
	v_dual_fmac_f32 v34, v37, v34 :: v_dual_mul_f32 v37, v40, v31// 0000005111E0: C8064525 22243F28
	v_add_f32_e32 v24, 1.0, v24                                // 0000005111E8: 063030F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005111EC: BF870112
	v_fma_f32 v46, -v27, v37, v40                              // 0000005111F0: D613002E 24A24B1B
	v_div_scale_f32 v28, null, v24, v24, v18                   // 0000005111F8: D6FC7C1C 044A3118
	v_div_scale_f32 v38, s6, v18, v24, v18                     // 000000511200: D6FC0626 044A3112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000511208: BF870193
	v_fmac_f32_e32 v37, v46, v31                               // 00000051120C: 564A3F2E
	v_rcp_f32_e32 v33, v28                                     // 000000511210: 7E42551C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000511214: BF870291
	v_fma_f32 v27, -v27, v37, v40                              // 000000511218: D613001B 24A24B1B
	v_fma_f32 v41, -v28, v33, 1.0                              // 000000511220: D6130029 23CA431C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000511228: BF8700A1
	v_fmac_f32_e32 v33, v41, v33                               // 00000051122C: 56424329
	v_mul_f32_e32 v41, v36, v29                                // 000000511230: 10523B24
	v_fma_f32 v44, -v26, v41, v36                              // 000000511234: D613002C 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000051123C: BF870091
	v_fmac_f32_e32 v41, v44, v29                               // 000000511240: 56523B2C
	v_fma_f32 v26, -v26, v41, v36                              // 000000511244: D613001A 2492531A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000051124C: BF870141
	v_div_fmas_f32 v26, v26, v29, v41                          // 000000511250: D637001A 04A63B1A
	s_mov_b32 vcc_lo, s7                                       // 000000511258: BEEA0007
	v_div_fmas_f32 v27, v27, v31, v37                          // 00000051125C: D637001B 04963F1B
	s_mov_b32 vcc_lo, s6                                       // 000000511264: BEEA0006
	v_div_fixup_f32 v13, v26, v22, v13                         // 000000511268: D627000D 04362D1A
	s_mov_b32 s6, 0                                            // 000000511270: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000511274: BF870242
	v_div_fixup_f32 v16, v27, v23, v16                         // 000000511278: D6270010 04422F1B
	v_mul_f32_e32 v43, v38, v33                                // 000000511280: 10564326
	v_lshlrev_b32_e32 v23, 16, v7                              // 000000511284: 302E0E90
	v_mul_f32_e32 v13, v13, v42                                // 000000511288: 101A550D
	v_dual_mul_f32 v6, v16, v6 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000051128C: C8E40D10 06060EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000511298: BF870194
	v_fma_f32 v47, -v28, v43, v38                              // 00000051129C: D613002F 249A571C
	.long 0x7e40398d                                           // 0000005112A4: 7E40398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005112A8: BF870193
	.long 0x7e463986                                           // 0000005112AC: 7E463986
	v_fmac_f32_e32 v43, v47, v33                               // 0000005112B0: 5656432F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005112B4: BF870091
	v_fma_f32 v28, -v28, v43, v38                              // 0000005112B8: D613001C 249A571C
	v_div_fmas_f32 v22, v28, v33, v43                          // 0000005112C0: D6370016 04AE431C
	s_mov_b32 vcc_lo, s8                                       // 0000005112C8: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005112CC: BF870091
	v_div_fixup_f32 v18, v22, v24, v18                         // 0000005112D0: D6270012 044A3116
	v_dual_mul_f32 v45, v39, v34 :: v_dual_mul_f32 v18, v18, v23// 0000005112D8: C8C64527 2D122F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005112E0: BF8701A1
	v_fma_f32 v44, -v30, v45, v39                              // 0000005112E4: D613002C 249E5B1E
	v_and_b32_e32 v23, 1, v35                                  // 0000005112EC: 362E4681
	v_bfe_u32 v22, v18, 16, 1                                  // 0000005112F0: D6100016 02052112
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005112F8: BF870193
	v_fmac_f32_e32 v45, v44, v34                               // 0000005112FC: 565A452C
	v_add3_u32 v6, v6, v23, 0x7fff                             // 000000511300: D6550006 03FE2F06 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000051130C: BF870112
	v_fma_f32 v26, -v30, v45, v39                              // 000000511310: D613001A 249E5B1E
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000511318: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511320: BF870092
	v_div_fmas_f32 v16, v26, v34, v45                          // 000000511324: D6370010 04B6451A
	v_div_fixup_f32 v14, v16, v25, v14                         // 00000051132C: D627000E 043A3310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511334: BF870091
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v16, 1, v32   // 000000511338: C8E40F0E 07104081
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000511340: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v22, 0x7fff                           // 00000051134C: D655000E 03FE2D12 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000511358: BF870193
	v_bfe_u32 v16, v7, 16, 1                                   // 00000051135C: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000511364: 361A1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000051136C: BF870193
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000511370: 36241CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000511378: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000511384: BF8907F7
	s_delay_alu instid0(VALU_DEP_3)                            // 000000511388: BF870003
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000051138C: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000511394: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000511398: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 0000005113A0: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 0000005113A8: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000005113B0: 916A067E
	s_cbranch_vccnz 65130                                      // 0000005113B4: BFA4FE6A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005113B8: BF8700A3
	.long 0xd73c0004                                           // 0000005113BC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000005113C0: 02020881
	s_waitcnt lgkmcnt(0)                                       // 0000005113C4: BF89FC07
	.long 0xd7006a04                                           // 0000005113C8: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 0000005113CC: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005113D0: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 0000005113D4: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 0000005113DC: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000005113E0: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005113E4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000005113E8: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000005113F0: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000005113F4: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 0000005113F8: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000511400: DC560000 047C0004
	s_clause 0x1                                               // 000000511408: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000051140C: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000511414: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000051141C: BF890BF7
	.long 0x7e0e3904                                           // 000000511420: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000511424: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000051142C: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000511430: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000511434: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000511438: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000051143C: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000511444: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000511448: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000511450: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000511458: 361E0AFF FFFF0000
	s_branch 65087                                             // 000000511460: BFA0FE3F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000511464: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000511468: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 00000051146C: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 000000511470: 9388FF09 0001001C
	s_lshr_b32 s4, s11, 28                                     // 000000511478: 85049C0B
	s_lshr_b64 s[0:1], s[8:9], 29                              // 00000051147C: 85809D08
	s_add_i32 s4, s25, s4                                      // 000000511480: 81040419
	s_add_i32 s0, s0, 7                                        // 000000511484: 81008700
	s_lshl_b32 s3, s9, 3                                       // 000000511488: 84038309
	s_ashr_i32 s0, s0, 3                                       // 00000051148C: 86008300
	s_lshl_b32 s1, s34, 3                                      // 000000511490: 84018322
	.long 0xd72c0001                                           // 000000511494: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000511498: 02022600
	v_mov_b32_e32 v57, 0                                       // 00000051149C: 7E720280
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v56, 0             // 0000005114A0: CA100080 17380080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v58, 0             // 0000005114A8: CA100080 373A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 0000005114B0: CA100080 3B3C0080
	v_add_nc_u32_e32 v2, s0, v1                                // 0000005114B8: 4A040200
	s_ashr_i32 s0, s4, 4                                       // 0000005114BC: 86008404
	s_ashr_i32 s4, s1, 31                                      // 0000005114C0: 86049F01
	s_mul_hi_i32 s5, s0, s2                                    // 0000005114C4: 97050200
	s_mul_i32 s0, s0, s2                                       // 0000005114C8: 96000200
	v_min_i32_e32 v54, s3, v2                                  // 0000005114CC: 226C0403
	s_add_u32 s0, s0, s1                                       // 0000005114D0: 80000100
	s_addc_u32 s1, s5, s4                                      // 0000005114D4: 82010405
	s_mul_hi_u32 s3, s0, 0x300                                 // 0000005114D8: 9683FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 0000005114E0: B8010300
	v_cmp_lt_i32_e32 vcc_lo, v1, v54                           // 0000005114E4: 7C826D01
	s_add_i32 s5, s3, s1                                       // 0000005114E8: 81050103
	s_mul_i32 s4, s0, 0x300                                    // 0000005114EC: 9604FF00 00000300
	s_waitcnt lgkmcnt(0)                                       // 0000005114F4: BF89FC07
	s_barrier                                                  // 0000005114F8: BFBD0000
	buffer_gl0_inv                                             // 0000005114FC: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000511504: BE81206A
	s_cbranch_execz 24                                         // 000000511508: BFA50018 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x96c>
	s_add_u32 s6, s28, s4                                      // 00000051150C: 8006041C
	s_addc_u32 s7, s29, s5                                     // 000000511510: 8207051D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000511514: BF870099
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[6:7]              // 000000511518: D6FF7C02 001A02FF 00000300
	.long 0xd7000002                                           // 000000511524: D7000002
	v_cndmask_b32_e32 v1, v2, v20, vcc_lo                      // 000000511528: 02022902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000051152C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000511530: D5207C03 00020680
	s_clause 0x5                                               // 000000511538: BF850005
	global_load_b32 v55, v[2:3], off                           // 00000051153C: DC520000 377C0002
	global_load_b32 v56, v[2:3], off offset:128                // 000000511544: DC520080 387C0002
	global_load_b32 v57, v[2:3], off offset:256                // 00000051154C: DC520100 397C0002
	global_load_b32 v58, v[2:3], off offset:384                // 000000511554: DC520180 3A7C0002
	global_load_b32 v59, v[2:3], off offset:512                // 00000051155C: DC520200 3B7C0002
	global_load_b32 v60, v[2:3], off offset:640                // 000000511564: DC520280 3C7C0002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000051156C: 8C7E017E
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v52, 0             // 000000511570: CA100080 35340080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v50, 0             // 000000511578: CA100080 33320080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v48, 0             // 000000511580: CA100080 31300080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v46, 0             // 000000511588: CA100080 2F2E0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v44, 0             // 000000511590: CA100080 2D2C0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v42, 0             // 000000511598: CA100080 2B2A0080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v40, 0             // 0000005115A0: CA100080 29280080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 0000005115A8: CA100080 27260080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v36, 0             // 0000005115B0: CA100080 25240080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v34, 0             // 0000005115B8: CA100080 23220080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v32, 0             // 0000005115C0: CA100080 21200080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v31, 0             // 0000005115C8: CA100080 181E0080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v29, 0             // 0000005115D0: CA100080 1E1C0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v25, 0             // 0000005115D8: CA100080 1C180080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v26, 0             // 0000005115E0: CA100080 1B1A0080
	v_mov_b32_e32 v22, 0                                       // 0000005115E8: 7E2C0280
	s_ashr_i32 s3, s2, 31                                      // 0000005115EC: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005115F0: BE81206A
	s_cbranch_execz 1197                                       // 0000005115F4: BFA504AD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1cac>
	v_or_b32_e32 v4, 4, v8                                     // 0000005115F8: 38081084
	v_mad_u32_u24 v7, v21, 24, 0x2f0                           // 0000005115FC: D60B0007 03FD3115 000002F0
	v_mad_i64_i32 v[2:3], null, 0x300, v1, s[4:5]              // 000000511608: D6FF7C02 001202FF 00000300
	v_mul_u32_u24_e32 v6, 0x320, v19                           // 000000511614: 160C26FF 00000320
	v_mul_i32_i24_e32 v8, 0xffffffe8, v21                      // 00000051161C: 12102AFF FFFFFFE8
	v_mad_u32_u24 v5, v4, 3, 0x2f0                             // 000000511624: D60B0005 03FD0704 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v4                             // 000000511630: 7C920885
	v_lshrrev_b32_e32 v12, 5, v7                               // 000000511634: 32180E85
	v_mul_i32_i24_e32 v13, -3, v4                              // 000000511638: 121A08C3
	v_mad_u32_u24 v10, 0x320, v19, v20                         // 00000051163C: D60B000A 045226FF 00000320
	v_lshrrev_b32_e32 v9, 5, v5                                // 000000511648: 32120A85
	v_dual_mov_b32 v26, 0 :: v_dual_and_b32 v5, 0x7e0, v5      // 00000051164C: CA240080 1A040AFF 000007E0
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v11, 16, v0        // 000000511658: CA240080 160A0090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000511660: BF870223
	v_subrev_nc_u32_e32 v9, 24, v9                             // 000000511664: 4E121298
	v_and_b32_e32 v7, 0x7e0, v7                                // 000000511668: 360E0EFF 000007E0
	v_add3_u32 v62, v13, v5, 0xfffffd34                        // 000000511670: D655003E 03FE0B0D FFFFFD34
	v_sub_nc_u32_e32 v64, 0, v54                               // 00000051167C: 4C806C80
	v_lshl_or_b32 v63, v1, 5, v11                              // 000000511680: D656003F 042D0B01
	v_cndmask_b32_e32 v4, 23, v9, vcc_lo                       // 000000511688: 02081297
	.long 0xd7006a02                                           // 00000051168C: D7006A02
	v_cndmask_b32_e32 v1, v2, v20, vcc_lo                      // 000000511690: 02022902
	s_delay_alu instid0(VALU_DEP_1)                            // 000000511694: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000511698: D5207C03 01AA0680
	v_subrev_nc_u32_e32 v9, 24, v12                            // 0000005116A0: 4E121898
	v_cmp_ne_u32_e32 vcc_lo, 0, v21                            // 0000005116A4: 7C9A2A80
	v_add_nc_u32_e32 v12, 1, v4                                // 0000005116A8: 4A180881
	v_subrev_nc_u32_e32 v14, 23, v4                            // 0000005116AC: 4E1C0897
	v_add3_u32 v61, v8, v7, 0xfffffd34                         // 0000005116B0: D655003D 03FE0F08 FFFFFD34
	v_lshl_add_u32 v4, v4, 2, v6                               // 0000005116BC: D6460004 04190504
	v_cndmask_b32_e32 v9, 23, v9, vcc_lo                       // 0000005116C4: 02121297
	v_cmp_gt_u32_e32 vcc_lo, 24, v12                           // 0000005116C8: 7C981898
	v_dual_mov_b32 v28, 0 :: v_dual_add_nc_u32 v65, 1, v1      // 0000005116CC: CA200080 1C400281
	v_add_nc_u32_e32 v66, 0x5000, v10                          // 0000005116D4: 4A8414FF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005116DC: BF870244
	v_lshl_add_u32 v7, v9, 2, v6                               // 0000005116E0: D6460007 04190509
	v_cndmask_b32_e32 v5, v14, v12, vcc_lo                     // 0000005116E8: 020A190E
	v_cmp_gt_i32_e32 vcc_lo, 23, v9                            // 0000005116EC: 7C881297
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v69, 0x5000, v4 // 0000005116F0: CA200080 184408FF 00005000
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v67, 0x5000, v7 // 0000005116FC: CA200080 1E420EFF 00005000
	v_cndmask_b32_e64 v8, 0xffffffa4, 4, vcc_lo                // 000000511708: D5010008 01A908FF FFFFFFA4
	.long 0xd7006a02                                           // 000000511714: D7006A02
	v_cndmask_b32_e32 v1, s28, v2, vcc_lo                      // 000000511718: 0202041C
	v_lshl_add_u32 v5, v5, 2, v6                               // 00000051171C: D6460005 04190505
	v_add_co_ci_u32_e64 v3, null, s29, v3, vcc_lo              // 000000511724: D5207C03 01AA061D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000051172C: BF8701A3
	.long 0xd7006a11                                           // 000000511730: D7006A11
	v_cndmask_b32_e32 v1, 0x300, v2, vcc_lo                    // 000000511734: 020204FF 00000300
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v2, v7, v8      // 00000051173C: CA200080 1B021107
	v_add_co_ci_u32_e64 v18, null, 0, v3, vcc_lo               // 000000511744: D5207C12 01AA0680
	v_dual_mov_b32 v29, 0 :: v_dual_add_nc_u32 v70, 0x5000, v5 // 00000051174C: CA200080 1D460AFF 00005000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000511758: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v68, 0x5000, v2 // 00000051175C: CA200080 194404FF 00005000
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 000000511768: CA100080 1F200080
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, 0             // 000000511770: CA100080 21220080
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 000000511778: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000511780: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 000000511788: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 000000511790: CA100080 292A0080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v44, 0             // 000000511798: CA100080 2B2C0080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v46, 0             // 0000005117A0: CA100080 2D2E0080
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v48, 0             // 0000005117A8: CA100080 2F300080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v50, 0             // 0000005117B0: CA100080 31320080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 0000005117B8: CA100080 33340080
	v_mov_b32_e32 v53, 0                                       // 0000005117C0: 7E6A0280
	v_mov_b32_e32 v23, 0                                       // 0000005117C4: 7E2E0280
	s_mov_b32 s4, 0                                            // 0000005117C8: BE840080
	s_movk_i32 s5, 0x1eee                                      // 0000005117CC: B0051EEE
	s_branch 1050                                              // 0000005117D0: BFA0041A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005117D4: 8C7E007E
	ds_load_2addr_b32 v[71:72], v68 offset1:24                 // 0000005117D8: D8DC1800 47000044
	ds_load_2addr_b32 v[73:74], v70 offset1:24                 // 0000005117E0: D8DC1800 49000046
	ds_load_2addr_b32 v[10:11], v67 offset1:24                 // 0000005117E8: D8DC1800 0A000043
	ds_load_2addr_b32 v[77:78], v69 offset1:24                 // 0000005117F0: D8DC1800 4D000045
	ds_load_b128 v[5:8], v63                                   // 0000005117F8: DBFC0000 0500003F
	ds_load_b128 v[1:4], v63 offset:5120                       // 000000511800: DBFC1400 0100003F
	.long 0xd7000011                                           // 000000511808: D7000011
	v_cndmask_b32_e32 v1, 0x300, v17, vcc_lo                   // 00000051180C: 020222FF 00000300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000511814: BF870001
	v_add_co_ci_u32_e64 v18, null, 0, v18, s0                  // 000000511818: D5207C12 00022480
	v_add_nc_u32_e32 v65, 1, v65                               // 000000511820: 4A828281
	s_waitcnt lgkmcnt(4)                                       // 000000511824: BF89FC47
	v_dual_mov_b32 v9, v71 :: v_dual_mov_b32 v76, v73          // 000000511828: CA100147 094C0149
	s_waitcnt lgkmcnt(2)                                       // 000000511830: BF89FC27
	v_mov_b32_e32 v75, v78                                     // 000000511834: 7E96034E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000511838: BF870192
	.long 0xd73d004e                                           // 00000051183C: D73D004E
	v_cndmask_b32_e32 v1, v61, v9, vcc_lo                      // 000000511840: 0202133D
	.long 0xd73d004c                                           // 000000511844: D73D004C
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000511848: 0202993E
	v_mov_b32_e32 v73, v11                                     // 00000051184C: 7E92030B
	ds_load_b128 v[9:12], v63 offset:10240                     // 000000511850: DBFC2800 0900003F
	ds_load_b128 v[13:16], v63 offset:15360                    // 000000511858: DBFC3C00 0D00003F
	v_add_nc_u32_e32 v63, 32, v63                              // 000000511860: 4A7E7EA0
	.long 0xd73d0047                                           // 000000511864: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000511868: 0202913D
	.long 0xd73d0048                                           // 00000051186C: D73D0048
	v_cndmask_b32_e32 v1, v62, v74, vcc_lo                     // 000000511870: 0202953E
	v_bfe_u32 v73, v78, 9, 16                                  // 000000511874: D6100049 0241134E
	v_bfe_u32 v74, v78, 6, 16                                  // 00000051187C: D610004A 02410D4E
	v_bfe_u32 v75, v78, 3, 16                                  // 000000511884: D610004B 0241074E
	v_bfe_u32 v79, v76, 6, 16                                  // 00000051188C: D610004F 02410D4C
	v_bfe_u32 v80, v76, 3, 16                                  // 000000511894: D6100050 0241074C
	.long 0xd72c0049                                           // 00000051189C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000005118A0: 020292FF 83DCD12D
	.long 0xd72c004a                                           // 0000005118A8: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000005118AC: 020294FF 83DCD12D
	.long 0xd72c004b                                           // 0000005118B4: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000005118B8: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 0000005118C0: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 0000005118C4: 02029EFF 83DCD12D
	v_bfe_u32 v81, v71, 9, 16                                  // 0000005118CC: D6100051 02411347
	v_bfe_u32 v82, v71, 6, 16                                  // 0000005118D4: D6100052 02410D47
	v_bfe_u32 v83, v71, 3, 16                                  // 0000005118DC: D6100053 02410747
	.long 0xd72c0050                                           // 0000005118E4: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000005118E8: 0202A0FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005118F0: D6220049 03FD0149 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000005118FC: D622004A 03FD014A 00006400
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000511908: D622004B 03FD014B 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000511914: D622004F 03FD014F 00006400
	.long 0xd72c0053                                           // 000000511920: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000511924: 0202A6FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 00000051192C: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 000000511934: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000511938: 0202A2FF 83DCD12D
	.long 0xd72c0052                                           // 000000511940: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000511944: 0202A4FF 83DCD12D
	v_bfe_u32 v84, v72, 9, 16                                  // 00000051194C: D6100054 02411348
	v_bfe_u32 v85, v72, 6, 16                                  // 000000511954: D6100055 02410D48
	v_lshl_or_b32 v73, v74, 16, v73                            // 00000051195C: D6560049 0525214A
	v_sad_u8 v74, v80, 0, 0x6400                               // 000000511964: D622004A 03FD0150 00006400
	v_bfe_u32 v86, v72, 3, 16                                  // 000000511970: D6100056 02410748
	v_and_b32_e32 v72, 0xffff, v72                             // 000000511978: 369090FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511980: BF870004
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511984: CC0E0049 0BFC0B49 0000C931
	v_and_b32_e32 v77, 0xffff, v78                             // 000000511990: 369A9CFF 0000FFFF
	v_bfe_u32 v78, v76, 9, 16                                  // 000000511998: D610004E 0241134C
	v_and_b32_e32 v76, 0xffff, v76                             // 0000005119A0: 369898FF 0000FFFF
	s_waitcnt lgkmcnt(2)                                       // 0000005119A8: BF89FC27
	v_dual_dot2acc_f32_f16 v26, v73, v1 :: v_dual_and_b32 v71, 0xffff, v71// 0000005119AC: CB240349 1A468EFF 0000FFFF
	v_dot2acc_f32_f16 v22, v73, v5                             // 0000005119B8: 042C0B49
	.long 0xd72c004d                                           // 0000005119BC: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000005119C0: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 0000005119C8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000005119CC: 02029CFF 83DCD12D
	.long 0xd72c004c                                           // 0000005119D4: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 0000005119D8: 020298FF 83DCD12D
	.long 0xd72c0047                                           // 0000005119E0: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000005119E4: 02028EFF 83DCD12D
	s_waitcnt lgkmcnt(1)                                       // 0000005119EC: BF89FC17
	v_dot2acc_f32_f16 v27, v73, v9                             // 0000005119F0: 04361349
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000005119F4: D622004D 03FD014D 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000511A00: D622004E 03FD014E 00006400
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000511A0C: D622004C 03FD014C 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000511A18: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511A24: BF870214
	v_lshlrev_b32_e32 v77, 16, v77                             // 000000511A28: 309A9A90
	v_and_b32_e32 v78, 0xffff, v78                             // 000000511A2C: 369C9CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511A34: BF870214
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000511A38: 30989890
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000511A3C: 308E8E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511A40: BF870214
	v_and_or_b32 v75, 0xffff, v75, v77                         // 000000511A44: D657004B 053696FF 0000FFFF
	v_lshl_or_b32 v78, v79, 16, v78                            // 000000511A50: D656004E 0539214F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511A58: BF870004
	v_and_or_b32 v74, 0xffff, v74, v76                         // 000000511A5C: D657004A 053294FF 0000FFFF
	.long 0xd72c004d                                           // 000000511A68: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000511A6C: 0202A8FF 83DCD12D
	.long 0xd72c004f                                           // 000000511A74: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000511A78: 020290FF 83DCD12D
	v_pk_fma_f16 v75, v75, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511A80: CC0E004B 0BFC0B4B 0000C931
	v_pk_fma_f16 v76, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511A8C: CC0E004C 0BFC0B4E 0000C931
	v_pk_fma_f16 v78, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511A98: CC0E004E 0BFC0B4A 0000C931
	v_sad_u8 v74, v82, 0, 0x6400                               // 000000511AA4: D622004A 03FD0152 00006400
	s_waitcnt lgkmcnt(0)                                       // 000000511AB0: BF89FC07
	v_dual_dot2acc_f32_f16 v22, v75, v6 :: v_dual_dot2acc_f32_f16 v25, v73, v13// 000000511AB4: CB180D4B 16181B49
	v_dot2acc_f32_f16 v26, v75, v2                             // 000000511ABC: 0434054B
	v_dot2acc_f32_f16 v27, v75, v10                            // 000000511AC0: 0436154B
	v_sad_u8 v73, v81, 0, 0x6400                               // 000000511AC4: D6220049 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000511AD0: BF8701B4
	v_dual_dot2acc_f32_f16 v22, v76, v7 :: v_dual_dot2acc_f32_f16 v25, v75, v14// 000000511AD4: CB180F4C 16181D4B
	v_sad_u8 v75, v83, 0, 0x6400                               // 000000511ADC: D622004B 03FD0153 00006400
	v_dot2acc_f32_f16 v26, v76, v3                             // 000000511AE8: 0434074C
	v_dual_dot2acc_f32_f16 v27, v76, v11 :: v_dual_dot2acc_f32_f16 v22, v78, v8// 000000511AEC: CB18174C 1B16114E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511AF4: BF870214
	v_dot2acc_f32_f16 v25, v76, v15                            // 000000511AF8: 04321F4C
	v_and_or_b32 v80, 0xffff, v75, v71                         // 000000511AFC: D6570050 051E96FF 0000FFFF
	.long 0xd72c004c                                           // 000000511B08: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000511B0C: 0202AAFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000511B14: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v26, v78, v4                             // 000000511B20: 0434094E
	ds_load_2addr_b32 v[71:72], v68 offset0:48 offset1:72      // 000000511B24: D8DC4830 47000044
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511B2C: CC0E0053 0BFC0B50 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 000000511B38: 369292FF 0000FFFF
	.long 0xd72c0051                                           // 000000511B40: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000511B44: 0202ACFF 83DCD12D
	v_dot2acc_f32_f16 v25, v78, v16                            // 000000511B4C: 0432214E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000511B50: D622004C 03FD014C 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511B5C: BF870004
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000511B60: D6560049 0525214A
	ds_load_2addr_b32 v[74:75], v67 offset0:48 offset1:72      // 000000511B68: D8DC4830 4A000043
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000511B70: D6220051 03FD0151 00006400
	v_pk_fma_f16 v82, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511B7C: CC0E0052 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000511B88: D6220049 03FD014F 00006400
	ds_load_2addr_b32 v[79:80], v69 offset0:48 offset1:72      // 000000511B94: D8DC4830 4F000045
	v_dot2acc_f32_f16 v28, v82, v5                             // 000000511B9C: 04380B52
	v_dot2acc_f32_f16 v27, v78, v12                            // 000000511BA0: 0436194E
	v_dot2acc_f32_f16 v30, v82, v9                             // 000000511BA4: 043C1352
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511BA8: BF870113
	v_dual_dot2acc_f32_f16 v28, v83, v6 :: v_dual_and_b32 v77, 0xffff, v77// 000000511BAC: CB240D53 1C4C9AFF 0000FFFF
	v_dot2acc_f32_f16 v30, v83, v10                            // 000000511BB8: 043C1553
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000511BBC: BF8700B2
	v_lshl_or_b32 v84, v76, 16, v77                            // 000000511BC0: D6560054 0535214C
	ds_load_2addr_b32 v[76:77], v70 offset0:48 offset1:72      // 000000511BC8: D8DC4830 4C000046
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511BD0: CC0E0054 0BFC0B54 0000C931
	v_dual_dot2acc_f32_f16 v30, v84, v11 :: v_dual_lshlrev_b32 v73, 16, v73// 000000511BDC: CB221754 1E489290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000511BE4: BF870131
	v_and_or_b32 v81, 0xffff, v81, v73                         // 000000511BE8: D6570051 0526A2FF 0000FFFF
	s_waitcnt lgkmcnt(3)                                       // 000000511BF4: BF89FC37
	v_dual_mov_b32 v73, v71 :: v_dual_dot2acc_f32_f16 v28, v84, v7// 000000511BF8: CA180147 491C0F54
	v_pk_fma_f16 v71, v81, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511C00: CC0E0047 0BFC0B51 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000511C0C: BF8701C1
	v_dual_dot2acc_f32_f16 v29, v82, v1 :: v_dual_dot2acc_f32_f16 v28, v71, v8// 000000511C10: CB180352 1D1C1147
	s_waitcnt lgkmcnt(0)                                       // 000000511C18: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 000000511C1C: 7E9C034C
	.long 0xd73d0049                                           // 000000511C20: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000511C24: 0202933D
	v_dot2acc_f32_f16 v29, v83, v2                             // 000000511C28: 043A0553
	v_dot2acc_f32_f16 v30, v71, v12                            // 000000511C2C: 043C1947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511C30: BF870214
	.long 0xd73d004e                                           // 000000511C34: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000511C38: 02029D3E
	v_bfe_u32 v74, v73, 9, 16                                  // 000000511C3C: D610004A 02411349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000511C44: BF870234
	v_dual_dot2acc_f32_f16 v29, v84, v3 :: v_dual_and_b32 v76, 0xffff, v73// 000000511C48: CB240754 1D4C92FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 000000511C54: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000511C5C: D6100049 02410749
	.long 0xd72c004a                                           // 000000511C64: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000511C68: 020294FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511C70: BF870004
	.long 0xd72c004c                                           // 000000511C74: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000511C78: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v29, v71, v4                             // 000000511C80: 043A0947
	v_bfe_u32 v81, v78, 9, 16                                  // 000000511C84: D6100051 0241134E
	.long 0xd72c004f                                           // 000000511C8C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000511C90: 02029EFF 83DCD12D
	.long 0xd72c0049                                           // 000000511C98: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000511C9C: 020292FF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000511CA4: D622004A 03FD014A 00006400
	v_dot2acc_f32_f16 v31, v82, v13                            // 000000511CB0: 043E1B52
	v_bfe_u32 v82, v78, 6, 16                                  // 000000511CB4: D6100052 02410D4E
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000511CBC: D622004C 03FD014C 00006400
	.long 0xd72c0051                                           // 000000511CC8: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000511CCC: 0202A2FF 83DCD12D
	v_and_b32_e32 v74, 0xffff, v74                             // 000000511CD4: 369494FF 0000FFFF
	v_dot2acc_f32_f16 v31, v83, v14                            // 000000511CDC: 043E1D53
	v_bfe_u32 v83, v78, 3, 16                                  // 000000511CE0: D6100053 0241074E
	v_and_b32_e32 v78, 0xffff, v78                             // 000000511CE8: 369C9CFF 0000FFFF
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000511CF0: D622004F 03FD014F 00006400
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000511CFC: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 000000511D08: 30989890
	.long 0xd72c0053                                           // 000000511D0C: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000511D10: 0202A6FF 83DCD12D
	.long 0xd72c004e                                           // 000000511D18: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000511D1C: 02029CFF 83DCD12D
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000511D24: D6220051 03FD0151 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 000000511D30: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 000000511D38: D6570049 053292FF 0000FFFF
	v_dot2acc_f32_f16 v31, v84, v15                            // 000000511D44: 043E1F54
	.long 0xd72c0052                                           // 000000511D48: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000511D4C: 0202A4FF 83DCD12D
	v_and_b32_e32 v76, 0xffff, v81                             // 000000511D54: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511D5C: CC0E004A 0BFC0B4A 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000511D68: D622004E 03FD014E 00006400
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511D74: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v83, 0, 0x6400                               // 000000511D80: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000511D8C: BF870214
	v_dual_dot2acc_f32_f16 v31, v71, v16 :: v_dual_dot2acc_f32_f16 v24, v74, v5// 000000511D90: CB182147 1F180B4A
	v_lshlrev_b32_e32 v78, 16, v78                             // 000000511D98: 309C9C90
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000511D9C: D622004F 03FD0152 00006400
	v_dot2acc_f32_f16 v33, v74, v9                             // 000000511DA8: 0442134A
	v_dot2acc_f32_f16 v32, v74, v1                             // 000000511DAC: 0440034A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000511DB0: BF870244
	v_and_or_b32 v71, 0xffff, v73, v78                         // 000000511DB4: D6570047 053A92FF 0000FFFF
	v_dual_mov_b32 v73, v75 :: v_dual_mov_b32 v78, v80         // 000000511DC0: CA10014B 494E0150
	v_dot2acc_f32_f16 v24, v81, v6                             // 000000511DC8: 04300D51
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000511DCC: D656004C 0531214F
	v_pk_fma_f16 v82, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511DD4: CC0E0052 0BFC0B47 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511DE0: BF870004
	.long 0xd73d0047                                           // 000000511DE4: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000511DE8: 0202913D
	v_dot2acc_f32_f16 v34, v74, v13                            // 000000511DEC: 04441B4A
	.long 0xd73d0048                                           // 000000511DF0: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000511DF4: 02029B3E
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511DF8: CC0E004C 0BFC0B4C 0000C931
	v_dot2acc_f32_f16 v33, v81, v10                            // 000000511E04: 04421551
	v_dot2acc_f32_f16 v32, v81, v2                             // 000000511E08: 04400551
	v_bfe_u32 v74, v71, 9, 16                                  // 000000511E0C: D610004A 02411347
	v_dual_dot2acc_f32_f16 v34, v81, v14 :: v_dual_and_b32 v75, 0xffff, v71// 000000511E14: CB241D51 224A8EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000511E20: BF870224
	v_dot2acc_f32_f16 v33, v76, v11                            // 000000511E24: 0442174C
	v_dot2acc_f32_f16 v24, v76, v7                             // 000000511E28: 04300F4C
	.long 0xd72c0049                                           // 000000511E2C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000511E30: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000511E38: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000511E40: D6100047 02410747
	.long 0xd72c004b                                           // 000000511E48: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000511E4C: 020296FF 83DCD12D
	v_dot2acc_f32_f16 v33, v82, v12                            // 000000511E54: 04421952
	v_bfe_u32 v77, v72, 6, 16                                  // 000000511E58: D610004D 02410D48
	.long 0xd72c004a                                           // 000000511E60: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000511E64: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 000000511E6C: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000511E70: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000511E78: D6220049 03FD0149 00006400
	v_dot2acc_f32_f16 v32, v76, v3                             // 000000511E84: 0440074C
	v_bfe_u32 v78, v72, 3, 16                                  // 000000511E88: D610004E 02410748
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000511E90: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000511E9C: BF870234
	v_dual_dot2acc_f32_f16 v24, v82, v8 :: v_dual_and_b32 v73, 0xffff, v73// 000000511EA0: CB241152 184892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000511EAC: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000511EB8: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000511EC4: 30969690
	.long 0xd72c004d                                           // 000000511EC8: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 000000511ECC: 02029AFF 83DCD12D
	.long 0xd72c004e                                           // 000000511ED4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000511ED8: 02029CFF 83DCD12D
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000511EE0: D6560049 0525214A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000511EE8: BF870004
	v_and_or_b32 v80, 0xffff, v71, v75                         // 000000511EEC: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:96 offset1:120     // 000000511EF8: D8DC7860 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511F00: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v34, v76, v15                            // 000000511F0C: 04441F4C
	v_bfe_u32 v76, v72, 9, 16                                  // 000000511F10: D610004C 02411348
	v_pk_fma_f16 v83, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511F18: CC0E0053 0BFC0B50 0000C931
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000511F24: D622004D 03FD014D 00006400
	v_dual_dot2acc_f32_f16 v35, v81, v5 :: v_dual_and_b32 v72, 0xffff, v72// 000000511F30: CB240B51 234890FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000511F3C: BF870234
	.long 0xd72c004c                                           // 000000511F40: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000511F44: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v37, v81, v9                             // 000000511F4C: 044A1351
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000511F50: D622004E 03FD014E 00006400
	v_dot2acc_f32_f16 v35, v83, v6                             // 000000511F5C: 04460D53
	.long 0xd72c004f                                           // 000000511F60: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000511F64: 020290FF 83DCD12D
	ds_load_2addr_b32 v[71:72], v68 offset0:96 offset1:120     // 000000511F6C: D8DC7860 47000044
	v_dual_dot2acc_f32_f16 v37, v83, v10 :: v_dual_dot2acc_f32_f16 v38, v81, v13// 000000511F74: CB181553 25261B51
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000511F7C: D622004C 03FD014C 00006400
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000511F88: D6220049 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000511F94: BF870002
	v_and_b32_e32 v76, 0xffff, v76                             // 000000511F98: 369898FF 0000FFFF
	v_dot2acc_f32_f16 v32, v82, v4                             // 000000511FA0: 04400952
	ds_load_2addr_b32 v[79:80], v69 offset0:96 offset1:120     // 000000511FA4: D8DC7860 4F000045
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000511FAC: 30929290
	v_lshl_or_b32 v84, v77, 16, v76                            // 000000511FB0: D6560054 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:96 offset1:120     // 000000511FB8: D8DC7860 4C000046
	v_and_or_b32 v78, 0xffff, v78, v73                         // 000000511FC0: D657004E 05269CFF 0000FFFF
	v_pk_fma_f16 v84, v84, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511FCC: CC0E0054 0BFC0B54 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000511FD8: BF89FC27
	v_dual_dot2acc_f32_f16 v36, v81, v1 :: v_dual_mov_b32 v73, v71// 000000511FDC: CB100351 24480147
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000511FE4: BF870113
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000511FE8: CC0E0047 0BFC0B4E 0000C931
	v_dual_dot2acc_f32_f16 v35, v84, v7 :: v_dual_dot2acc_f32_f16 v36, v83, v2// 000000511FF4: CB180F54 23240553
	v_dot2acc_f32_f16 v37, v84, v11                            // 000000511FFC: 044A1754
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512000: BF870194
	.long 0xd73d0049                                           // 000000512004: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000512008: 0202933D
	v_dual_dot2acc_f32_f16 v35, v71, v8 :: v_dual_dot2acc_f32_f16 v36, v84, v3// 00000051200C: CB181147 23240754
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512014: BF870193
	v_dot2acc_f32_f16 v37, v71, v12                            // 000000512018: 044A1947
	v_bfe_u32 v74, v73, 9, 16                                  // 00000051201C: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 000000512024: BF89FC07
	v_mov_b32_e32 v78, v76                                     // 000000512028: 7E9C034C
	v_and_b32_e32 v76, 0xffff, v73                             // 00000051202C: 369892FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512034: BF870193
	.long 0xd72c004a                                           // 000000512038: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000051203C: 020294FF 83DCD12D
	.long 0xd73d004e                                           // 000000512044: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000512048: 02029D3E
	v_bfe_u32 v79, v73, 6, 16                                  // 00000051204C: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000512054: D6100049 02410749
	.long 0xd72c004c                                           // 00000051205C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000512060: 020298FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000512068: BF870003
	.long 0xd72c004f                                           // 00000051206C: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000512070: 02029EFF 83DCD12D
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000512078: D622004A 03FD014A 00006400
	v_bfe_u32 v81, v78, 9, 16                                  // 000000512084: D6100051 0241134E
	.long 0xd72c0049                                           // 00000051208C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000512090: 020292FF 83DCD12D
	v_bfe_u32 v85, v78, 3, 16                                  // 000000512098: D6100055 0241074E
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000005120A0: D622004C 03FD014C 00006400
	v_and_b32_e32 v74, 0xffff, v74                             // 0000005120AC: 369494FF 0000FFFF
	.long 0xd72c0051                                           // 0000005120B4: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000005120B8: 0202A2FF 83DCD12D
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000005120C0: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005120CC: BF8701A4
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000005120D0: 30989890
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005120D4: D6220049 03FD0149 00006400
	v_lshl_or_b32 v74, v79, 16, v74                            // 0000005120E0: D656004A 0529214F
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000005120E8: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005120F4: BF870193
	v_and_or_b32 v73, 0xffff, v73, v76                         // 0000005120F8: D6570049 053292FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512104: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v36, v71, v4                             // 000000512110: 04480947
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000512114: BF870214
	v_and_b32_e32 v76, 0xffff, v81                             // 000000512118: 3698A2FF 0000FFFF
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512120: CC0E0051 0BFC0B49 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000051212C: BF870244
	v_dot2acc_f32_f16 v39, v74, v5                             // 000000512130: 044E0B4A
	v_dot2acc_f32_f16 v34, v82, v16                            // 000000512134: 04442152
	v_bfe_u32 v82, v78, 6, 16                                  // 000000512138: D6100052 02410D4E
	v_dual_dot2acc_f32_f16 v41, v74, v9 :: v_dual_and_b32 v78, 0xffff, v78// 000000512140: CB24134A 294E9CFF 0000FFFF
	v_dual_dot2acc_f32_f16 v39, v81, v6 :: v_dual_dot2acc_f32_f16 v42, v74, v13// 00000051214C: CB180D51 272A1B4A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512154: BF870193
	.long 0xd72c0052                                           // 000000512158: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000051215C: 0202A4FF 83DCD12D
	.long 0xd72c004e                                           // 000000512164: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000512168: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000512170: BF870214
	v_dot2acc_f32_f16 v41, v81, v10                            // 000000512174: 04521551
	v_dot2acc_f32_f16 v42, v81, v14                            // 000000512178: 04541D51
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051217C: BF870214
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000512180: D622004F 03FD0152 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000051218C: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000512198: BF870112
	v_lshl_or_b32 v76, v79, 16, v76                            // 00000051219C: D656004C 0531214F
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000005121A4: 309C9C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005121A8: BF870092
	v_pk_fma_f16 v82, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005121AC: CC0E0052 0BFC0B4C 0000C931
	v_dual_dot2acc_f32_f16 v39, v82, v7 :: v_dual_dot2acc_f32_f16 v38, v83, v14// 0000005121B8: CB180F52 27261D53
	v_dot2acc_f32_f16 v41, v82, v11                            // 0000005121C0: 04521752
	.long 0xd72c0053                                           // 0000005121C4: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000005121C8: 0202AAFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005121D0: BF870113
	v_dot2acc_f32_f16 v38, v84, v15                            // 0000005121D4: 044C1F54
	v_sad_u8 v73, v83, 0, 0x6400                               // 0000005121D8: D6220049 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005121E4: BF870112
	v_dot2acc_f32_f16 v38, v71, v16                            // 0000005121E8: 044C2147
	v_and_or_b32 v73, 0xffff, v73, v78                         // 0000005121EC: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 0000005121F8: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005121FC: BF870122
	v_pk_fma_f16 v83, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512200: CC0E0053 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 00000051220C: 7E92034B
	v_dot2acc_f32_f16 v39, v83, v8                             // 000000512210: 044E1153
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000512214: BF870242
	.long 0xd73d0047                                           // 000000512218: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 00000051221C: 0202913D
	v_dot2acc_f32_f16 v40, v74, v1                             // 000000512220: 0450034A
	.long 0xd73d0048                                           // 000000512224: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 000000512228: 02029B3E
	v_dot2acc_f32_f16 v41, v83, v12                            // 00000051222C: 04521953
	v_bfe_u32 v74, v71, 9, 16                                  // 000000512230: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 000000512238: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000512240: BF870004
	v_bfe_u32 v76, v72, 9, 16                                  // 000000512244: D610004C 02411348
	v_bfe_u32 v77, v72, 6, 16                                  // 00000051224C: D610004D 02410D48
	v_bfe_u32 v78, v72, 3, 16                                  // 000000512254: D610004E 02410748
	.long 0xd72c0049                                           // 00000051225C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000512260: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 000000512268: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000512270: D6100047 02410747
	.long 0xd72c004b                                           // 000000512278: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000051227C: 020296FF 83DCD12D
	.long 0xd72c004c                                           // 000000512284: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000512288: 020298FF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000512290: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 000000512298: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000051229C: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 0000005122A4: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000005122A8: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005122B0: D6220049 03FD0149 00006400
	.long 0xd72c004d                                           // 0000005122BC: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000005122C0: 02029AFF 83DCD12D
	.long 0xd72c004f                                           // 0000005122C8: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000005122CC: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000005122D4: D622004B 03FD014B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000005122E0: BF870234
	v_dual_dot2acc_f32_f16 v40, v81, v2 :: v_dual_and_b32 v73, 0xffff, v73// 0000005122E4: CB240551 284892FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000005122F0: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 0000005122FC: D6220047 03FD0147 00006400
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000512308: 30969690
	v_sad_u8 v76, v76, 0, 0x6400                               // 00000051230C: D622004C 03FD014C 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000512318: D622004D 03FD014D 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000512324: D6560049 0525214A
	.long 0xd72c004e                                           // 00000051232C: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000512330: 02029CFF 83DCD12D
	v_and_or_b32 v80, 0xffff, v71, v75                         // 000000512338: D6570050 052E8EFF 0000FFFF
	ds_load_2addr_b32 v[71:72], v68 offset0:144 offset1:168    // 000000512344: D8DCA890 47000044
	v_and_b32_e32 v76, 0xffff, v76                             // 00000051234C: 369898FF 0000FFFF
	ds_load_2addr_b32 v[74:75], v67 offset0:144 offset1:168    // 000000512354: D8DCA890 4A000043
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000051235C: CC0E0051 0BFC0B49 0000C931
	v_sad_u8 v73, v79, 0, 0x6400                               // 000000512368: D6220049 03FD014F 00006400
	v_dot2acc_f32_f16 v40, v82, v3                             // 000000512374: 04500752
	v_lshl_or_b32 v85, v77, 16, v76                            // 000000512378: D6560055 0531214D
	ds_load_2addr_b32 v[76:77], v70 offset0:144 offset1:168    // 000000512380: D8DCA890 4C000046
	v_pk_fma_f16 v84, v80, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512388: CC0E0054 0BFC0B50 0000C931
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000512394: D622004E 03FD014E 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000005123A0: 30929290
	ds_load_2addr_b32 v[79:80], v69 offset0:144 offset1:168    // 0000005123A4: D8DCA890 4F000045
	v_dual_dot2acc_f32_f16 v43, v81, v5 :: v_dual_dot2acc_f32_f16 v40, v83, v4// 0000005123AC: CB180B51 2B280953
	v_dot2acc_f32_f16 v45, v81, v9                             // 0000005123B4: 045A1351
	v_and_or_b32 v78, 0xffff, v78, v73                         // 0000005123B8: D657004E 05269CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005123C4: BF870193
	v_dual_dot2acc_f32_f16 v46, v81, v13 :: v_dual_dot2acc_f32_f16 v43, v84, v6// 0000005123C8: CB181B51 2E2A0D54
	v_dot2acc_f32_f16 v45, v84, v10                            // 0000005123D0: 045A1554
	s_waitcnt lgkmcnt(3)                                       // 0000005123D4: BF89FC37
	v_mov_b32_e32 v73, v71                                     // 0000005123D8: 7E920347
	v_pk_fma_f16 v71, v78, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005123DC: CC0E0047 0BFC0B4E 0000C931
	v_dot2acc_f32_f16 v42, v82, v15                            // 0000005123E8: 04541F52
	v_pk_fma_f16 v82, v85, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000005123EC: CC0E0052 0BFC0B55 0000C931
	s_waitcnt lgkmcnt(2)                                       // 0000005123F8: BF89FC27
	.long 0xd73d0049                                           // 0000005123FC: D73D0049
	v_cndmask_b32_e32 v1, v61, v73, vcc_lo                     // 000000512400: 0202933D
	s_waitcnt lgkmcnt(1)                                       // 000000512404: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000512408: BF8701A2
	v_dual_mov_b32 v78, v76 :: v_dual_dot2acc_f32_f16 v43, v82, v7// 00000051240C: CA18014C 4E2A0F52
	v_dual_dot2acc_f32_f16 v44, v81, v1 :: v_dual_dot2acc_f32_f16 v45, v82, v11// 000000512414: CB180351 2C2C1752
	v_bfe_u32 v74, v73, 9, 16                                  // 00000051241C: D610004A 02411349
	s_waitcnt lgkmcnt(0)                                       // 000000512424: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000512428: BF870003
	.long 0xd73d004e                                           // 00000051242C: D73D004E
	v_cndmask_b32_e32 v1, v62, v78, vcc_lo                     // 000000512430: 02029D3E
	v_and_b32_e32 v76, 0xffff, v73                             // 000000512434: 369892FF 0000FFFF
	v_bfe_u32 v79, v73, 6, 16                                  // 00000051243C: D610004F 02410D49
	v_bfe_u32 v73, v73, 3, 16                                  // 000000512444: D6100049 02410749
	.long 0xd72c004a                                           // 00000051244C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000512450: 020294FF 83DCD12D
	v_dot2acc_f32_f16 v43, v71, v8                             // 000000512458: 04561147
	.long 0xd72c004c                                           // 00000051245C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000512460: 020298FF 83DCD12D
	.long 0xd72c004f                                           // 000000512468: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 00000051246C: 02029EFF 83DCD12D
	v_bfe_u32 v81, v78, 9, 16                                  // 000000512474: D6100051 0241134E
	.long 0xd72c0049                                           // 00000051247C: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000512480: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v45, v71, v12                            // 000000512488: 045A1947
	v_bfe_u32 v85, v78, 3, 16                                  // 00000051248C: D6100055 0241074E
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000512494: D622004A 03FD014A 00006400
	.long 0xd72c0051                                           // 0000005124A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000005124A4: 0202A2FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 0000005124AC: D622004C 03FD014C 00006400
	v_sad_u8 v79, v79, 0, 0x6400                               // 0000005124B8: D622004F 03FD014F 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005124C4: BF870224
	v_and_b32_e32 v74, 0xffff, v74                             // 0000005124C8: 369494FF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005124D0: D6220049 03FD0149 00006400
	v_lshlrev_b32_e32 v76, 16, v76                             // 0000005124DC: 30989890
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000005124E0: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005124EC: BF870194
	v_lshl_or_b32 v74, v79, 16, v74                            // 0000005124F0: D656004A 0529214F
	v_and_or_b32 v73, 0xffff, v73, v76                         // 0000005124F8: D6570049 053292FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512504: BF870193
	v_and_b32_e32 v76, 0xffff, v81                             // 000000512508: 3698A2FF 0000FFFF
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512510: CC0E004A 0BFC0B4A 0000C931
	v_dot2acc_f32_f16 v44, v84, v2                             // 00000051251C: 04580554
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512520: BF870194
	v_pk_fma_f16 v81, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512524: CC0E0051 0BFC0B49 0000C931
	v_dot2acc_f32_f16 v47, v74, v5                             // 000000512530: 045E0B4A
	v_dot2acc_f32_f16 v49, v74, v9                             // 000000512534: 0462134A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000512538: BF870224
	v_dot2acc_f32_f16 v44, v82, v3                             // 00000051253C: 04580752
	v_dot2acc_f32_f16 v48, v74, v1                             // 000000512540: 0460034A
	v_dual_dot2acc_f32_f16 v50, v74, v13 :: v_dual_dot2acc_f32_f16 v47, v81, v6// 000000512544: CB181B4A 322E0D51
	v_dot2acc_f32_f16 v42, v83, v16                            // 00000051254C: 04542153
	v_bfe_u32 v83, v78, 6, 16                                  // 000000512550: D6100053 02410D4E
	v_dual_dot2acc_f32_f16 v44, v71, v4 :: v_dual_dot2acc_f32_f16 v49, v81, v10// 000000512558: CB180947 2C301551
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000512560: BF870092
	.long 0xd72c0053                                           // 000000512564: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000512568: 0202A6FF 83DCD12D
	v_sad_u8 v79, v83, 0, 0x6400                               // 000000512570: D622004F 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000051257C: BF870091
	v_lshl_or_b32 v76, v79, 16, v76                            // 000000512580: D656004C 0531214F
	v_pk_fma_f16 v76, v76, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512588: CC0E004C 0BFC0B4C 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000512594: BF870241
	v_dual_dot2acc_f32_f16 v49, v76, v11 :: v_dual_and_b32 v78, 0xffff, v78// 000000512598: CB24174C 314E9CFF 0000FFFF
	v_dot2acc_f32_f16 v46, v84, v14                            // 0000005125A4: 045C1D54
	.long 0xd72c0054                                           // 0000005125A8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 0000005125AC: 0202AAFF 83DCD12D
	v_dot2acc_f32_f16 v47, v76, v7                             // 0000005125B4: 045E0F4C
	.long 0xd72c004e                                           // 0000005125B8: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000005125BC: 02029CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005125C4: BF870214
	v_dot2acc_f32_f16 v46, v82, v15                            // 0000005125C8: 045C1F52
	v_sad_u8 v73, v84, 0, 0x6400                               // 0000005125CC: D6220049 03FD0154 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005125D8: BF870212
	v_dot2acc_f32_f16 v46, v71, v16                            // 0000005125DC: 045C2147
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000005125E0: D622004E 03FD014E 00006400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005125EC: BF870091
	v_lshlrev_b32_e32 v78, 16, v78                             // 0000005125F0: 309C9C90
	v_and_or_b32 v73, 0xffff, v73, v78                         // 0000005125F4: D6570049 053A92FF 0000FFFF
	v_mov_b32_e32 v78, v80                                     // 000000512600: 7E9C0350
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000512604: BF870122
	v_pk_fma_f16 v79, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512608: CC0E004F 0BFC0B49 0000C931
	v_mov_b32_e32 v73, v75                                     // 000000512614: 7E92034B
	v_dot2acc_f32_f16 v47, v79, v8                             // 000000512618: 045E114F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000051261C: BF8701B2
	.long 0xd73d0047                                           // 000000512620: D73D0047
	v_cndmask_b32_e32 v1, v61, v72, vcc_lo                     // 000000512624: 0202913D
	.long 0xd73d0048                                           // 000000512628: D73D0048
	v_cndmask_b32_e32 v1, v62, v77, vcc_lo                     // 00000051262C: 02029B3E
	v_dot2acc_f32_f16 v49, v79, v12                            // 000000512630: 0462194F
	v_bfe_u32 v74, v71, 9, 16                                  // 000000512634: D610004A 02411347
	v_and_b32_e32 v75, 0xffff, v71                             // 00000051263C: 36968EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000512644: BF870004
	v_bfe_u32 v77, v72, 9, 16                                  // 000000512648: D610004D 02411348
	v_bfe_u32 v78, v72, 6, 16                                  // 000000512650: D610004E 02410D48
	v_bfe_u32 v80, v72, 3, 16                                  // 000000512658: D6100050 02410748
	.long 0xd72c0049                                           // 000000512660: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000512664: 020294FF 83DCD12D
	v_bfe_u32 v74, v71, 6, 16                                  // 00000051266C: D610004A 02410D47
	v_bfe_u32 v71, v71, 3, 16                                  // 000000512674: D6100047 02410747
	.long 0xd72c004b                                           // 00000051267C: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000512680: 020296FF 83DCD12D
	.long 0xd72c004d                                           // 000000512688: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 00000051268C: 02029AFF 83DCD12D
	v_and_b32_e32 v72, 0xffff, v72                             // 000000512694: 369090FF 0000FFFF
	.long 0xd72c004a                                           // 00000051269C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000005126A0: 020294FF 83DCD12D
	.long 0xd72c0047                                           // 0000005126A8: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 0000005126AC: 02028EFF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 0000005126B4: D6220049 03FD0149 00006400
	.long 0xd72c004e                                           // 0000005126C0: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 0000005126C4: 02029CFF 83DCD12D
	.long 0xd72c0048                                           // 0000005126CC: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000005126D0: 020290FF 83DCD12D
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000005126D8: D622004B 03FD014B 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000005126E4: D622004D 03FD014D 00006400
	v_and_b32_e32 v73, 0xffff, v73                             // 0000005126F0: 369292FF 0000FFFF
	v_sad_u8 v74, v74, 0, 0x6400                               // 0000005126F8: D622004A 03FD014A 00006400
	v_sad_u8 v71, v71, 0, 0x6400                               // 000000512704: D6220047 03FD0147 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000512710: BF870224
	v_and_b32_e32 v77, 0xffff, v77                             // 000000512714: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 00000051271C: D622004E 03FD014E 00006400
	v_lshl_or_b32 v73, v74, 16, v73                            // 000000512728: D6560049 0525214A
	v_lshlrev_b32_e32 v74, 16, v75                             // 000000512730: 30949690
	.long 0xd72c004b                                           // 000000512734: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000512738: 0202A0FF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000512740: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051274C: BF870214
	v_pk_fma_f16 v73, v73, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512750: CC0E0049 0BFC0B49 0000C931
	v_and_or_b32 v71, 0xffff, v71, v74                         // 00000051275C: D6570047 052A8EFF 0000FFFF
	v_lshl_or_b32 v74, v78, 16, v77                            // 000000512768: D656004A 0535214E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000512770: BF870193
	v_dual_dot2acc_f32_f16 v53, v73, v9 :: v_dual_lshlrev_b32 v72, 16, v72// 000000512774: CB221349 35489090
	v_pk_fma_f16 v71, v71, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000051277C: CC0E0047 0BFC0B47 0000C931
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000512788: D622004B 03FD014B 00006400
	v_dot2acc_f32_f16 v51, v73, v5                             // 000000512794: 04660B49
	v_pk_fma_f16 v74, v74, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000512798: CC0E004A 0BFC0B4A 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000005127A4: BF870244
	v_dual_dot2acc_f32_f16 v52, v73, v1 :: v_dual_dot2acc_f32_f16 v53, v71, v10// 0000005127A8: CB180349 34341547
	v_dot2acc_f32_f16 v48, v81, v2                             // 0000005127B0: 04600551
	v_and_or_b32 v5, 0xffff, v75, v72                          // 0000005127B4: D6570005 052296FF 0000FFFF
	v_dot2acc_f32_f16 v51, v71, v6                             // 0000005127C0: 04660D47
	v_dual_dot2acc_f32_f16 v23, v73, v13 :: v_dual_dot2acc_f32_f16 v52, v71, v2// 0000005127C4: CB181B49 17340547
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005127CC: BF870214
	v_dot2acc_f32_f16 v48, v76, v3                             // 0000005127D0: 0460074C
	v_pk_fma_f16 v1, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000005127D4: CC0E0001 0BFC0B05 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005127E0: BF870214
	v_dot2acc_f32_f16 v51, v74, v7                             // 0000005127E4: 04660F4A
	v_dual_dot2acc_f32_f16 v23, v71, v14 :: v_dual_add_nc_u32 v2, v64, v65// 0000005127E8: CB201D47 17028340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005127F0: BF870194
	v_dual_dot2acc_f32_f16 v48, v79, v4 :: v_dual_dot2acc_f32_f16 v53, v74, v11// 0000005127F4: CB18094F 3034174A
	v_dot2acc_f32_f16 v51, v1, v8                              // 0000005127FC: 04661101
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000512800: BF8701B3
	v_dual_dot2acc_f32_f16 v50, v81, v14 :: v_dual_dot2acc_f32_f16 v23, v74, v15// 000000512804: CB181D51 32161F4A
	v_dot2acc_f32_f16 v52, v74, v3                             // 00000051280C: 0468074A
	v_cmp_eq_u32_e32 vcc_lo, 1, v2                             // 000000512810: 7C940481
	v_dual_dot2acc_f32_f16 v53, v1, v12 :: v_dual_dot2acc_f32_f16 v50, v76, v15// 000000512814: CB181901 35321F4C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051281C: BF870214
	v_dot2acc_f32_f16 v23, v1, v16                             // 000000512820: 042E2101
	v_dot2acc_f32_f16 v52, v1, v4                              // 000000512824: 04680901
	s_or_b32 s4, vcc_lo, s4                                    // 000000512828: 8C04046A
	s_delay_alu instid0(VALU_DEP_3)                            // 00000051282C: BF870003
	v_dot2acc_f32_f16 v50, v79, v16                            // 000000512830: 0464214F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000512834: 917E047E
	s_cbranch_execz 27                                         // 000000512838: BFA5001B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ca8>
	s_mov_b32 s0, exec_lo                                      // 00000051283C: BE80007E
	s_waitcnt vmcnt(4)                                         // 000000512840: BF8913F7
	ds_store_2addr_b32 v66, v55, v56 offset1:32                // 000000512844: D8382000 00383742
	s_waitcnt vmcnt(2)                                         // 00000051284C: BF890BF7
	ds_store_2addr_b32 v66, v57, v58 offset0:64 offset1:96     // 000000512850: D8386040 003A3942
	s_waitcnt vmcnt(0)                                         // 000000512858: BF8903F7
	ds_store_2addr_b32 v66, v59, v60 offset0:128 offset1:160   // 00000051285C: D838A080 003C3B42
	.long 0xd4c1007e                                           // 000000512864: D4C1007E
	v_cndmask_b32_e32 v1, v65, v54, vcc_lo                     // 000000512868: 02026D41
	s_cbranch_execz 64473                                      // 00000051286C: BFA5FBD9 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd4>
	s_clause 0x5                                               // 000000512870: BF850005
	global_load_b32 v55, v[17:18], off                         // 000000512874: DC520000 377C0011
	global_load_b32 v56, v[17:18], off offset:128              // 00000051287C: DC520080 387C0011
	global_load_b32 v57, v[17:18], off offset:256              // 000000512884: DC520100 397C0011
	global_load_b32 v58, v[17:18], off offset:384              // 00000051288C: DC520180 3A7C0011
	global_load_b32 v59, v[17:18], off offset:512              // 000000512894: DC520200 3B7C0011
	global_load_b32 v60, v[17:18], off offset:640              // 00000051289C: DC520280 3C7C0011
	s_branch 64459                                             // 0000005128A4: BFA0FBCB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd4>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000005128A8: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005128AC: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005128B0: 8C7E017E
	v_dual_mov_b32 v1, v22 :: v_dual_mov_b32 v4, v27           // 0000005128B4: CA100116 0104011B
	v_dual_mov_b32 v2, v26 :: v_dual_mov_b32 v3, v25           // 0000005128BC: CA10011A 02020119
	v_dual_mov_b32 v5, v28 :: v_dual_mov_b32 v8, v30           // 0000005128C4: CA10011C 0508011E
	v_dual_mov_b32 v7, v29 :: v_dual_mov_b32 v6, v24           // 0000005128CC: CA10011D 07060118
	v_dual_mov_b32 v9, v31 :: v_dual_mov_b32 v10, v32          // 0000005128D4: CA10011F 090A0120
	v_dual_mov_b32 v11, v33 :: v_dual_mov_b32 v12, v34         // 0000005128DC: CA100121 0B0C0122
	v_dual_mov_b32 v13, v35 :: v_dual_mov_b32 v14, v36         // 0000005128E4: CA100123 0D0E0124
	v_dual_mov_b32 v15, v37 :: v_dual_mov_b32 v16, v38         // 0000005128EC: CA100125 0F100126
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v40         // 0000005128F4: CA100127 11120128
	s_waitcnt vmcnt(5)                                         // 0000005128FC: BF8917F7
	v_dual_mov_b32 v54, v41 :: v_dual_mov_b32 v55, v42         // 000000512900: CA100129 3636012A
	s_waitcnt vmcnt(3)                                         // 000000512908: BF890FF7
	v_dual_mov_b32 v56, v43 :: v_dual_mov_b32 v57, v44         // 00000051290C: CA10012B 3838012C
	s_waitcnt vmcnt(1)                                         // 000000512914: BF8907F7
	v_dual_mov_b32 v58, v45 :: v_dual_mov_b32 v59, v46         // 000000512918: CA10012D 3A3A012E
	s_waitcnt vmcnt(0)                                         // 000000512920: BF8903F7
	v_dual_mov_b32 v60, v47 :: v_dual_mov_b32 v61, v48         // 000000512924: CA10012F 3C3C0130
	v_dual_mov_b32 v62, v49 :: v_dual_mov_b32 v63, v50         // 00000051292C: CA100131 3E3E0132
	v_dual_mov_b32 v64, v51 :: v_dual_mov_b32 v65, v52         // 000000512934: CA100133 40400134
	v_dual_mov_b32 v66, v53 :: v_dual_mov_b32 v67, v23         // 00000051293C: CA100135 42420117
	s_mov_b32 s0, 0x76543210                                   // 000000512944: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000051294C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000512950: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000051295C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000512968: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000512974: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000512980: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000051298C: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000512998: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 0000005129A4: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000005129B0: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000005129BC: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 0000005129C8: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000005129D4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000005129E0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000005129EC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000005129F8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000512A04: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000512A10: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000512A1C: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v54, v54, s0, 0xfedcba98                 // 000000512A28: D65C0036 03FC0136 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 000000512A34: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000512A40: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000512A4C: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 000000512A58: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000512A64: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000512A70: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000512A7C: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 000000512A88: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000512A94: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000512AA0: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000512AAC: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 000000512AB8: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000512AC4: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000512AD0: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000512AD4: 02022A90
	s_barrier                                                  // 000000512AD8: BFBD0000
	buffer_gl0_inv                                             // 000000512ADC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000512AE4: BE812000
	s_cbranch_execz 68                                         // 000000512AE8: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ffc>
	v_lshl_or_b32 v20, v19, 11, v20                            // 000000512AEC: D6560014 04511713
	v_add_f32_e32 v5, v28, v5                                  // 000000512AF4: 060A0B1C
	v_dual_add_f32 v1, v22, v1 :: v_dual_add_f32 v6, v24, v6   // 000000512AF8: C9080316 01060D18
	v_dual_add_f32 v9, v31, v9 :: v_dual_add_f32 v2, v26, v2   // 000000512B00: C908131F 0902051A
	v_dual_add_f32 v7, v29, v7 :: v_dual_add_f32 v4, v27, v4   // 000000512B08: C9080F1D 0704091B
	v_dual_add_f32 v11, v33, v11 :: v_dual_add_f32 v8, v30, v8 // 000000512B10: C9081721 0B08111E
	v_dual_add_f32 v3, v25, v3 :: v_dual_add_nc_u32 v22, 0x400, v20// 000000512B18: C9200719 031628FF 00000400
	v_dual_add_f32 v13, v35, v13 :: v_dual_add_f32 v10, v32, v10// 000000512B24: C9081B23 0D0A1520
	v_dual_add_f32 v21, v23, v67 :: v_dual_add_f32 v52, v52, v65// 000000512B2C: C9088717 15348334
	v_dual_add_f32 v23, v53, v66 :: v_dual_add_f32 v50, v50, v63// 000000512B34: C9088535 17327F32
	v_dual_add_f32 v51, v51, v64 :: v_dual_add_f32 v48, v48, v61// 000000512B3C: C9088133 33307B30
	v_dual_add_f32 v49, v49, v62 :: v_dual_add_f32 v46, v46, v59// 000000512B44: C9087D31 312E772E
	v_dual_add_f32 v47, v47, v60 :: v_dual_add_f32 v44, v44, v57// 000000512B4C: C908792F 2F2C732C
	v_dual_add_f32 v45, v45, v58 :: v_dual_add_f32 v42, v42, v55// 000000512B54: C908752D 2D2A6F2A
	v_dual_add_f32 v43, v43, v56 :: v_dual_add_f32 v18, v40, v18// 000000512B5C: C908712B 2B122528
	v_dual_add_f32 v41, v41, v54 :: v_dual_add_f32 v16, v38, v16// 000000512B64: C9086D29 29102126
	v_dual_add_f32 v17, v39, v17 :: v_dual_add_f32 v14, v36, v14// 000000512B6C: C9082327 110E1D24
	v_dual_add_f32 v15, v37, v15 :: v_dual_add_f32 v12, v34, v12// 000000512B74: C9081F25 0F0C1922
	ds_store_2addr_b32 v20, v1, v5 offset1:16                  // 000000512B7C: D8381000 00050114
	ds_store_2addr_b32 v20, v2, v7 offset0:128 offset1:144     // 000000512B84: D8389080 00070214
	ds_store_2addr_b32 v22, v4, v8 offset1:16                  // 000000512B8C: D8381000 00080416
	ds_store_2addr_b32 v22, v3, v9 offset0:128 offset1:144     // 000000512B94: D8389080 00090316
	ds_store_2addr_b32 v20, v6, v13 offset0:32 offset1:48      // 000000512B9C: D8383020 000D0614
	ds_store_2addr_b32 v20, v10, v14 offset0:160 offset1:176   // 000000512BA4: D838B0A0 000E0A14
	ds_store_2addr_b32 v22, v11, v15 offset0:32 offset1:48     // 000000512BAC: D8383020 000F0B16
	ds_store_2addr_b32 v22, v12, v16 offset0:160 offset1:176   // 000000512BB4: D838B0A0 00100C16
	ds_store_2addr_b32 v20, v17, v43 offset0:64 offset1:80     // 000000512BBC: D8385040 002B1114
	ds_store_2addr_b32 v20, v18, v44 offset0:192 offset1:208   // 000000512BC4: D838D0C0 002C1214
	ds_store_2addr_b32 v22, v41, v45 offset0:64 offset1:80     // 000000512BCC: D8385040 002D2916
	ds_store_2addr_b32 v22, v42, v46 offset0:192 offset1:208   // 000000512BD4: D838D0C0 002E2A16
	ds_store_2addr_b32 v20, v47, v51 offset0:96 offset1:112    // 000000512BDC: D8387060 00332F14
	ds_store_2addr_b32 v20, v48, v52 offset0:224 offset1:240   // 000000512BE4: D838F0E0 00343014
	ds_store_2addr_b32 v22, v49, v23 offset0:96 offset1:112    // 000000512BEC: D8387060 00173116
	ds_store_2addr_b32 v22, v50, v21 offset0:224 offset1:240   // 000000512BF4: D838F0E0 00153216
	s_or_b32 exec_lo, exec_lo, s1                              // 000000512BFC: 8C7E017E
	.long 0xd44c0001                                           // 000000512C00: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000512C04: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000512C0C: BF89FC07
	s_barrier                                                  // 000000512C10: BFBD0000
	buffer_gl0_inv                                             // 000000512C14: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000512C1C: BE842001
	s_cbranch_execz 42                                         // 000000512C20: BFA5002A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20cc>
	v_mov_b32_e32 v1, v0                                       // 000000512C24: 7E020300
	s_mov_b32 s5, 0                                            // 000000512C28: BE850080
	s_nop 0                                                    // 000000512C2C: BF800000
	s_nop 0                                                    // 000000512C30: BF800000
	s_nop 0                                                    // 000000512C34: BF800000
	s_nop 0                                                    // 000000512C38: BF800000
	s_nop 0                                                    // 000000512C3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512C40: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000512C44: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000512C48: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000512C50: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000512C58: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000512C60: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000512C68: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 000000512C6C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000512C70: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000512C74: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000512C78: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 000000512C7C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000512C84: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000512C88: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000512C8C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000512C90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000512C94: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000512C98: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000512C9C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000512CA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000512CA4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000512CA8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000512CAC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000512CB4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 000000512CBC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000512CC4: 917E057E
	s_cbranch_execnz 65501                                     // 000000512CC8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2040>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000512CCC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 000000512CD0: BF048221
	s_mov_b32 s4, -1                                           // 000000512CD4: BE8400C1
	s_cbranch_scc1 212                                         // 000000512CD8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x242c>
	s_waitcnt lgkmcnt(0)                                       // 000000512CDC: BF89FC07
	s_barrier                                                  // 000000512CE0: BFBD0000
	buffer_gl0_inv                                             // 000000512CE4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 000000512CEC: BE862001
	s_cbranch_execz 71                                         // 000000512CF0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2210>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000512CF4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 000000512CF8: 860B9F0A
	s_ashr_i32 s27, s26, 31                                    // 000000512CFC: 861B9F1A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000512D00: 8484820A
	s_mov_b32 s7, 0                                            // 000000512D04: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 000000512D08: 38020204
	s_mul_i32 s4, s5, s26                                      // 000000512D0C: 96041A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000512D10: BF8700A1
	.long 0xd72c0003                                           // 000000512D14: D72C0003
	v_cndmask_b32_e32 v0, v1, v27, vcc_lo                      // 000000512D18: 02003701
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 000000512D1C: D6FE7C01 02003501
	v_add3_u32 v2, v2, v3, s4                                  // 000000512D24: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 000000512D2C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000512D30: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000512D38: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000512D3C: BF870122
	.long 0xd73c0001                                           // 000000512D40: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000512D44: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000512D48: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 000000512D4C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000512D50: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000512D54: BF870093
	.long 0xd7006a01                                           // 000000512D58: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000512D5C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000512D60: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[26:27], 3                             // 000000512D68: 8484831A
	.long 0xd7006a01                                           // 000000512D6C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000512D70: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000512D74: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000512D78: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000512D80: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000512D88: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000512D8C: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512D90: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000512D94: D5207C02 01AA0411
	s_nop 0                                                    // 000000512D9C: BF800000
	s_nop 0                                                    // 000000512DA0: BF800000
	s_nop 0                                                    // 000000512DA4: BF800000
	s_nop 0                                                    // 000000512DA8: BF800000
	s_nop 0                                                    // 000000512DAC: BF800000
	s_nop 0                                                    // 000000512DB0: BF800000
	s_nop 0                                                    // 000000512DB4: BF800000
	s_nop 0                                                    // 000000512DB8: BF800000
	s_nop 0                                                    // 000000512DBC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 000000512DC0: D8D84000 05000003
	.long 0xd7000804                                           // 000000512DC8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 000000512DCC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 000000512DD4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000512DD8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 000000512DE0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000512DE4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 000000512DE8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 000000512DEC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000512DF0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000512DF8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000512DFC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000512E00: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000512E08: 917E077E
	s_cbranch_execnz 65516                                     // 000000512E0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000512E10: 8C7E067E
	.long 0xd44a0004                                           // 000000512E14: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000512E18: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000512E1C: BC7C0000
	buffer_gl1_inv                                             // 000000512E20: E0B00000 00000000
	buffer_gl0_inv                                             // 000000512E28: E0AC0000 00000000
	s_barrier                                                  // 000000512E30: BFBD0000
	buffer_gl0_inv                                             // 000000512E34: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 000000512E3C: BE852004
	s_cbranch_execz 29                                         // 000000512E40: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x22b8>
	s_mov_b32 s7, exec_lo                                      // 000000512E44: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000512E48: BE86007E
	.long 0xd71f0001                                           // 000000512E4C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000512E50: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512E54: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000512E58: 7D940280
	s_cbranch_execz 9                                          // 000000512E5C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2284>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000512E60: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000512E64: BF8704B9
	s_add_u32 s8, s18, s8                                      // 000000512E68: 80080812
	s_addc_u32 s9, s19, s9                                     // 000000512E6C: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 000000512E70: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000512E74: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000512E7C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000512E84: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000512E88: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000512E8C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512E90: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000512E94: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000512E9C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000512EA0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000512EA4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000512EA8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:26880                           // 000000512EB0: D8346900 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000512EB8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000512EBC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000512EC0: BF89FC07
	s_barrier                                                  // 000000512EC4: BFBD0000
	buffer_gl0_inv                                             // 000000512EC8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:26880                            // 000000512ED0: D8D86900 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000512ED8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000512EDC: 7C940280
	s_cbranch_vccnz 422                                        // 000000512EE0: BFA401A6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x297c>
	buffer_gl1_inv                                             // 000000512EE4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000512EEC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000512EF4: BE852001
	s_cbranch_execz 65                                         // 000000512EF8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2400>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000512EFC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000512F00: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000512F04: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 000000512F0C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000512F10: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s26, 0                     // 000000512F14: D6FF7C01 02003501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000512F1C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000512F20: 30060682
	s_ashr_i32 s27, s26, 31                                    // 000000512F24: 861B9F1A
	s_mov_b32 s10, 0                                           // 000000512F28: BE8A0080
	s_lshl_b64 s[8:9], s[26:27], 4                             // 000000512F2C: 8488841A
	.long 0xd73c0001                                           // 000000512F30: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000512F34: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000512F38: BF870091
	.long 0xd7006a01                                           // 000000512F3C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000512F40: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000512F44: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[26:27], 3                             // 000000512F4C: 8486831A
	.long 0xd7006a01                                           // 000000512F50: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000512F54: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000512F58: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000512F5C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 000000512F64: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000512F68: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512F6C: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 000000512F70: D5207C02 01AA0411
	s_nop 0                                                    // 000000512F78: BF800000
	s_nop 0                                                    // 000000512F7C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000512F80: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000512F84: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 000000512F8C: 7E0C0280
	s_mov_b32 s1, s33                                          // 000000512F90: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 000000512F94: DC524000 077C0003
	.long 0xd7006a03                                           // 000000512F9C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 000000512FA0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000512FA4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000512FA8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 000000512FB0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000512FB4: BF068001
	s_waitcnt vmcnt(0)                                         // 000000512FB8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000512FBC: 060C0F06
	s_cbranch_scc0 65524                                       // 000000512FC0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2394>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000512FC4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000512FCC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000512FD4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000512FD8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000512FDC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 000000512FE0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 000000512FE8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 000000512FEC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 000000512FF0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000512FF8: 917E0A7E
	s_cbranch_execnz 65504                                     // 000000512FFC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2380>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000513000: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000513004: BE812004
	s_cbranch_execz 6                                          // 000000513008: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2424>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000051300C: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000513010: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000513014: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000513018: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000051301C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000513024: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000513028: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000051302C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000513030: 8B6A047E
	s_cbranch_vccz 337                                         // 000000513034: BFA30151 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x297c>
	v_cmp_gt_i32_e32 vcc_lo, s24, v19                          // 000000513038: 7C882618
	.long 0xd44c0001                                           // 00000051303C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000513040: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000513048: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000051304C: BC7C0000
	s_barrier                                                  // 000000513050: BFBD0000
	buffer_gl0_inv                                             // 000000513054: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000051305C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000513060: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000513064: BE832001
	s_cbranch_execz 324                                        // 000000513068: BFA50144 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x297c>
	v_and_b32_e32 v1, 15, v0                                   // 00000051306C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000513070: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000513074: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000513078: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000513080: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000513084: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000051308C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000513094: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000051309C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000005130A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000005130AC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 0000005130B0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 0000005130B4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 0000005130BC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000005130C0: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000005130C8: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000005130CC: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000005130D4: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 0000005130D8: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 0000005130E0: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005130E8: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 0000005130EC: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 0000005130F0: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 0000005130F4: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 0000005130F8: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000513100: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000513104: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 00000051310C: 08080F06
	.long 0xd44a0001                                           // 000000513110: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000513114: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000513118: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 00000051311C: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000513120: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000513128: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 00000051312C: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000513134: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000513138: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000513140: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000513144: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000051314C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000513154: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000051315C: 7E2402FA FF016103
	v_cndmask_b32_e64 v22, -v3, v3, vcc_lo                     // 000000513164: D5010016 21AA0703
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000051316C: 7E2802FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 000000513174: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000513178: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000513180: D5010008 21AA1108
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000513188: D5010015 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 000000513190: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000513194: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 00000051319C: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005131A0: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005131A8: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 0000005131B0: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005131B8: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005131C0: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 0000005131C8: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000005131D0: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 0000005131D4: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 0000005131D8: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005131E0: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 0000005131E4: 060A1D0A
	v_add_f32_e32 v13, v21, v20                                // 0000005131E8: 061A2915
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005131EC: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 0000005131F4: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005131FC: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000513204: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000051320C: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000513214: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 00000051321C: 06081904
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000513220: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000513228: D501000D 21AA1B0D
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000513230: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000513238: D5010005 21AA0B05
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000513240: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000513248: D5010004 20060904
	v_add_f32_e32 v8, v8, v9                                   // 000000513250: 06101308
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000513254: D5010003 21AA0703
	v_add_f32_e32 v11, v5, v11                                 // 00000051325C: 06161705
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000513260: 7E1C02FA FF016207
	v_add_f32_e32 v4, v4, v12                                  // 000000513268: 06081904
	v_add_f32_e32 v12, v22, v18                                // 00000051326C: 06182516
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000513270: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 000000513278: 06060D03
	s_delay_alu instid0(VALU_DEP_3)                            // 00000051327C: BF870003
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000513280: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 000000513288: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 000000513290: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 000000513294: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000513298: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005132A0: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 0000005132A8: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 0000005132AC: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005132B4: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005132BC: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 0000005132C4: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005132C8: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 0000005132D0: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 0000005132D8: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005132DC: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000005132E4: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005132EC: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005132F4: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005132F8: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 000000513300: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 000000513304: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000513308: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000513310: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000513318: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000513320: BF870224
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000513324: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 00000051332C: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 000000513334: 0622190D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000513338: BF870224
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 00000051333C: C908150E 0F0E2109
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000513344: 7E1002FA FF016807
	v_add_f32_e32 v16, v11, v18                                // 00000051334C: 0620250B
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000513350: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4)                            // 000000513358: BF870004
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000051335C: 7E1602FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000513364: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000051336C: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000513374: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 00000051337C: 8B7E007E
	s_cbranch_execz 126                                        // 000000513380: BFA5007E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x297c>
	v_lshl_or_b32 v20, s2, 7, v1                               // 000000513384: D6560014 04050E02
	v_and_b32_e32 v18, 8, v0                                   // 00000051338C: 36240088
	v_mad_i64_i32 v[0:1], null, s26, v19, 0                    // 000000513390: D6FF7C00 0202261A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000513398: BF870113
	v_ashrrev_i32_e32 v21, 31, v20                             // 00000051339C: 342A289F
	.long 0xd73c0000                                           // 0000005133A0: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000005133A4: 02020082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005133A8: BF870092
	.long 0xd73c0016                                           // 0000005133AC: D73C0016
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 0000005133B0: 02022881
	.long 0xd7006a16                                           // 0000005133B4: D7006A16
	v_cndmask_b32_e32 v1, s14, v22, vcc_lo                     // 0000005133B8: 02022C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005133BC: BF870001
	v_add_co_ci_u32_e64 v23, null, s15, v23, vcc_lo            // 0000005133C0: D5207C17 01AA2E0F
	v_cmp_eq_u32_e32 vcc_lo, 0, v18                            // 0000005133C8: 7C942480
	.long 0xd73c0012                                           // 0000005133CC: D73C0012
	v_cndmask_b32_e32 v1, 2, v20, vcc_lo                       // 0000005133D0: 02022882
	s_clause 0x7                                               // 0000005133D4: BF850007
	global_load_d16_b16 v24, v[22:23], off offset:32           // 0000005133D8: DC820020 187C0016
	global_load_d16_b16 v25, v[22:23], off                     // 0000005133E0: DC820000 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:96           // 0000005133E8: DC820060 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:64           // 0000005133F0: DC820040 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:160          // 0000005133F8: DC8200A0 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:128          // 000000513400: DC820080 1D7C0016
	global_load_d16_b16 v30, v[22:23], off offset:224          // 000000513408: DC8200E0 1E7C0016
	global_load_d16_b16 v22, v[22:23], off offset:192          // 000000513410: DC8200C0 167C0016
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000513418: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000513420: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000513428: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000513430: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000513438: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000513440: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000513444: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000051344C: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000513454: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051345C: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000513460: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 00000051346C: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000513474: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000513478: 02020014
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 00000051347C: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000513484: D5207C01 01AA0215
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 00000051348C: C9081910 0808150E
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000513494: C8C604FF 02040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005134A0: BF8700A4
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000005134A4: C8C60CFF 06060EFF 3DB504F3
	.long 0xd7006a00                                           // 0000005134B0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 0000005134B4: 02022500
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 0000005134B8: D5207C01 01AA2701
	v_dual_mul_f32 v4, 0x3db504f3, v4 :: v_dual_mul_f32 v9, 0x3db504f3, v9// 0000005134C0: C8C608FF 040812FF 3DB504F3
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000005134CC: 101010FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 0000005134D4: BF891FF7
	v_fma_mix_f32 v3, v24, v3, neg(0) op_sel_hi:[1,0,0]        // 0000005134D8: CC200003 8A020718
	s_waitcnt vmcnt(6)                                         // 0000005134E0: BF891BF7
	v_fma_mix_f32 v2, v25, v2, neg(0) op_sel_hi:[1,0,0]        // 0000005134E4: CC200002 8A020519
	s_waitcnt vmcnt(5)                                         // 0000005134EC: BF8917F7
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005134F0: CC200005 8A020B1A
	s_waitcnt vmcnt(4)                                         // 0000005134F8: BF8913F7
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 0000005134FC: CC200006 8A020D1B
	s_waitcnt vmcnt(3)                                         // 000000513504: BF890FF7
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000513508: CC200004 8A02091C
	s_waitcnt vmcnt(2)                                         // 000000513510: BF890BF7
	v_fma_mix_f32 v7, v29, v7, neg(0) op_sel_hi:[1,0,0]        // 000000513514: CC200007 8A020F1D
	s_waitcnt vmcnt(1)                                         // 00000051351C: BF8907F7
	v_fma_mix_f32 v8, v30, v8, neg(0) op_sel_hi:[1,0,0]        // 000000513520: CC200008 8A02111E
	s_waitcnt vmcnt(0)                                         // 000000513528: BF8903F7
	v_fma_mix_f32 v9, v22, v9, neg(0) op_sel_hi:[1,0,0]        // 00000051352C: CC200009 8A021316
	s_clause 0x7                                               // 000000513534: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000513538: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000513540: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000513548: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000513550: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000513558: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000513560: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000513568: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000513570: DC6A01C0 007C0800
	s_endpgm                                                   // 000000513578: BFB00000
	s_endpgm                                                   // 00000051357C: BFB00000
		...

