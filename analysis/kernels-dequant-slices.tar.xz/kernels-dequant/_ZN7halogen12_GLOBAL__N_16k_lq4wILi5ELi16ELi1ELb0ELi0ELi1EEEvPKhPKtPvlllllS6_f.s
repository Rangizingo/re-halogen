0000000000562900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000562900: F4100100 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 000000562908: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000056290C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000562910: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000562914: 300E0082
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000562918: 84808402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000056291C: 30043C82
	v_dual_mov_b32 v24, s1 :: v_dual_lshlrev_b32 v3, 2, v1     // 000000562920: CA220001 18020282
	v_or_b32_e32 v23, s0, v1                                   // 000000562928: 382E0200
	.long 0x7f0c3880                                           // 00000056292C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 000000562930: BF89FC07
	s_clause 0x1                                               // 000000562934: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 000000562938: DC520000 04040002
	global_load_b32 v3, v3, s[4:5]                             // 000000562940: DC520000 03040003
	.long 0xd4540000                                           // 000000562948: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000056294C: 02022E0C
	s_add_u32 s22, s4, s16                                     // 000000562950: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000562954: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000562958: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000056295C: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000562960: 85029B02
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 000000562964: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000056296C: D5010005 00000280
	s_add_u32 s2, s10, s2                                      // 000000562974: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000562978: 8203800B
	.long 0xd72c0008                                           // 00000056297C: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 000000562980: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 000000562984: D6FE7C00 02020412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000056298C: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000562990: BF870009
	s_cmpk_lt_i32 s20, 0x81                                    // 000000562994: B3940081
	.long 0xd4440002                                           // 000000562998: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000056299C: 02023C14
	s_cselect_b32 s1, -1, 0                                    // 0000005629A0: 980180C1
	s_cmpk_gt_i32 s20, 0x80                                    // 0000005629A4: B2940080
	s_waitcnt vmcnt(1)                                         // 0000005629A8: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000005629AC: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000005629B4: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000005629B8: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005629C0: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000005629C4: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000005629D0: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 0000005629D4: 02020A12
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000005629D8: D6550003 03FE1503 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 0000005629E4: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005629E8: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000005629EC: 8B6A127E
	.long 0x7e0c3984                                           // 0000005629F0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000005629F4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005629FC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 000000562A00: D6570006 041A06FF FFFF0000
	.long 0xd7000303                                           // 000000562A0C: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 000000562A10: 02020016
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 000000562A14: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 000000562A1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 000000562A24: BF89FC07
	s_barrier                                                  // 000000562A28: BFBD0000
	buffer_gl0_inv                                             // 000000562A2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 000000562A34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 000000562A38: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 000000562A40: BE832002
	s_cbranch_execz 10                                         // 000000562A44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 000000562A48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562A4C: BF870091
	.long 0xd7006a06                                           // 000000562A50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562A54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 000000562A58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 000000562A60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000562A68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 000000562A6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 000000562A70: 8C7E037E
	v_or_b32_e32 v6, 16, v30                                   // 000000562A74: 380C3C90
	s_mov_b32 s2, exec_lo                                      // 000000562A78: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562A7C: BF870001
	.long 0xd4c4007e                                           // 000000562A80: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562A84: 02020C14
	s_cbranch_execz 10                                         // 000000562A88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562A8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562A90: BF870091
	.long 0xd7006a08                                           // 000000562A94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562A98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 000000562A9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 000000562AA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 000000562AAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 000000562AB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562AB4: 8C7E027E
	v_or_b32_e32 v6, 32, v30                                   // 000000562AB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000562ABC: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 000000562AC4: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000562AC8: BF870002
	.long 0xd4c4007e                                           // 000000562ACC: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562AD0: 02020C14
	s_cbranch_execz 10                                         // 000000562AD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562AD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562ADC: BF870091
	.long 0xd7006a0b                                           // 000000562AE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562AE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000562AE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 000000562AF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 000000562AF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 000000562AFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562B00: 8C7E027E
	v_or_b32_e32 v6, 48, v30                                   // 000000562B04: 380C3CB0
	s_mov_b32 s2, exec_lo                                      // 000000562B08: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562B0C: BF870001
	.long 0xd4c4007e                                           // 000000562B10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562B14: 02020C14
	s_cbranch_execz 10                                         // 000000562B18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562B1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562B20: BF870091
	.long 0xd7006a0a                                           // 000000562B24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562B28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 000000562B2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 000000562B34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000562B3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 000000562B40: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562B44: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 000000562B48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 000000562B4C: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 000000562B54: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000562B58: BF870002
	.long 0xd4c4007e                                           // 000000562B5C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562B60: 02020C14
	s_cbranch_execz 10                                         // 000000562B64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562B68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562B6C: BF870091
	.long 0xd7006a0d                                           // 000000562B70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562B74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 000000562B78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 000000562B80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000562B88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 000000562B8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562B90: 8C7E027E
	v_or_b32_e32 v6, 0x50, v30                                 // 000000562B94: 380C3CFF 00000050
	s_mov_b32 s2, exec_lo                                      // 000000562B9C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562BA0: BF870001
	.long 0xd4c4007e                                           // 000000562BA4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562BA8: 02020C14
	s_cbranch_execz 10                                         // 000000562BAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562BB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562BB4: BF870091
	.long 0xd7006a0c                                           // 000000562BB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562BBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000562BC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 000000562BC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 000000562BD0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 000000562BD4: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562BD8: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 000000562BDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000562BE4: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 000000562BEC: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000562BF0: BF870002
	.long 0xd4c4007e                                           // 000000562BF4: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562BF8: 02020C14
	s_cbranch_execz 10                                         // 000000562BFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562C00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562C04: BF870091
	.long 0xd7006a0f                                           // 000000562C08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562C0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000562C10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 000000562C18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 000000562C20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 000000562C24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562C28: 8C7E027E
	v_or_b32_e32 v6, 0x70, v30                                 // 000000562C2C: 380C3CFF 00000070
	s_mov_b32 s2, exec_lo                                      // 000000562C34: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562C38: BF870001
	.long 0xd4c4007e                                           // 000000562C3C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000562C40: 02020C14
	s_cbranch_execz 10                                         // 000000562C44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 000000562C48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562C4C: BF870091
	.long 0xd7006a0e                                           // 000000562C50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 000000562C54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 000000562C58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 000000562C60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 000000562C68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 000000562C6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000562C70: 8C7E027E
	s_branch 9                                                 // 000000562C74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 000000562C78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562C7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 000000562C80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 000000562C84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 000000562C88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 000000562C8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 000000562C90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 000000562C94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 000000562C98: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 000000562C9C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000562CA0: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000562CA4: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000562CA8: CA100080 13140080
	s_add_u32 s14, s10, s14                                    // 000000562CB0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000562CB4: 820F800B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 000000562CB8: CA100080 1F160080
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000562CC0: 868E810E
	v_cndmask_b32_e64 v32, 0, 1, s18                           // 000000562CC4: D5010020 00490280
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 000000562CCC: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 000000562CD4: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 000000562CD8: 02001F02
	.long 0xd72c0005                                           // 000000562CDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 000000562CE0: 02001D05
	.long 0xd4440002                                           // 000000562CE4: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 000000562CE8: 02023C14
	v_mov_b32_e32 v41, 0                                       // 000000562CEC: 7E520280
	v_mov_b32_e32 v21, 0                                       // 000000562CF0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000562CF4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 000000562CF8: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 000000562D00: BE832002
	s_cbranch_execz 21                                         // 000000562D04: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 000000562D08: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562D10: BF870091
	.long 0xd7006a05                                           // 000000562D14: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 000000562D18: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 000000562D1C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000562D24: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 000000562D28: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 000000562D30: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 000000562D34: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000562D38: BF870091
	.long 0xd7006a02                                           // 000000562D3C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000562D40: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 000000562D44: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 000000562D4C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000562D54: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 000000562D58: 7E521702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000562D5C: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 000000562D60: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 000000562D68: CA100080 24240080
	s_and_saveexec_b32 s3, s2                                  // 000000562D70: BE832002
	s_cbranch_execz 507                                        // 000000562D74: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 000000562D78: CA220080 1B023C81
	.long 0xd7006a00                                           // 000000562D80: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000562D84: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000562D88: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000562D8C: D5207C01 01AA0211
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 000000562D94: CA22011E 271A3C85
	.long 0xd7006a00                                           // 000000562D9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 000000562DA0: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000562DA4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000562DA8: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x100                           // 000000562DB0: D6560026 03FD091E 00000100
	.long 0xd7006a00                                           // 000000562DBC: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000562DC0: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000562DC4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 000000562DC8: D5207C01 01AA0205
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 000000562DD0: CA10011B 25280129
	.long 0xd7006a1c                                           // 000000562DD8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 000000562DDC: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562DE0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 000000562DE4: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 000000562DEC: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 000000562DF0: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 000000562DF4: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 000000562DF8: 7E3E031B
	s_mul_i32 s2, s11, 6                                       // 000000562DFC: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000562E00: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000562E04: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000562E08: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000562E0C: 9611860A
	s_mov_b32 s16, 0                                           // 000000562E10: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000562E14: 8484810A
	s_branch 437                                               // 000000562E18: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xbf0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000562E1C: 8C7E0A7E
	v_cndmask_b32_e64 v51, v41, v7, s1                         // 000000562E20: D5010033 00060F29
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 000000562E28: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 000000562E30: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 000000562E38: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 000000562E44: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 000000562E4C: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 000000562E54: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 000000562E5C: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000562E64: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 000000562E68: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 000000562E70: 8B02027E
	v_add_nc_u32_e32 v38, 0x100, v38                           // 000000562E74: 4A4C4CFF 00000100
	s_or_b32 s16, s2, s16                                      // 000000562E7C: 8C101002
	ds_load_b32 v14, v8                                        // 000000562E80: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 000000562E88: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562E8C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562E90: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 000000562E98: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 000000562EA0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562EA4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 000000562EAC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 000000562EB4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562EB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562EBC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 000000562EC4: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 000000562ECC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000562ED4: 30101082
	ds_load_b32 v55, v8                                        // 000000562ED8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 000000562EE0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562EE4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562EE8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 000000562EF0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 000000562EF8: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562EFC: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 000000562F04: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 000000562F0C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562F10: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562F14: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 000000562F1C: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 000000562F24: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000562F2C: 30101082
	ds_load_b32 v59, v8                                        // 000000562F30: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 000000562F38: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562F3C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562F40: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 000000562F48: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 000000562F50: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562F54: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 000000562F5C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 000000562F64: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562F68: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562F6C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 000000562F74: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 000000562F7C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000562F84: 30101082
	ds_load_b32 v63, v8                                        // 000000562F88: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 000000562F90: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000562F94: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562F98: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 000000562FA0: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 000000562FA8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562FAC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 000000562FB4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 000000562FBC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000562FC0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 000000562FC4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 000000562FCC: D8D80000 42000008
	.long 0xd73c0008                                           // 000000562FD4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000562FD8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 000000562FDC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 000000562FE4: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 000000562FE8: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000562FEC: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 000000562FF0: D5207C0D 01AA1207
	s_clause 0x3                                               // 000000562FF8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 000000562FFC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 000000563004: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 00000056300C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 000000563014: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056301C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000563020: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 000000563028: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056302C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000563030: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 000000563038: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000056303C: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 000000563044: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563048: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000056304C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000563054: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000563058: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 000000563060: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563064: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000563068: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 000000563070: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000563074: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 00000056307C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563080: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000563084: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056308C: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000563090: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 000000563098: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056309C: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000005630A0: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000005630A8: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000005630AC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000005630B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005630B8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000005630BC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000005630C4: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000005630C8: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000005630D0: D7006A2D
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 0000005630D4: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 0000005630D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005630DC: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000005630E0: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s5, v13, vcc_lo             // 0000005630E8: D5207C2E 01AA1A05
	.long 0xd7006a31                                           // 0000005630F0: D7006A31
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000005630F4: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 0000005630F8: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000005630FC: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s15, v13, vcc_lo            // 000000563104: D5207C32 01AA1A0F
	.long 0xd7006a0c                                           // 00000056310C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 000000563110: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 000000563114: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000563118: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000056311C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 000000563124: D5207C0D 01AA1A12
	v_fmac_f32_e32 v37, v51, v8                                // 00000056312C: 564A1133
	s_clause 0x3                                               // 000000563130: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 000000563134: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 00000056313C: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 000000563144: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 00000056314C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 000000563154: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000563158: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563160: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000563164: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 00000056316C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563174: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000563178: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000563180: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000563184: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056318C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000563190: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000563198: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005631A0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000005631A4: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000005631AC: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000005631B0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005631B8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000005631BC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000005631C4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005631CC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000005631D0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000005631D8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000005631DC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005631E4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000005631E8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000005631F0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005631F8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000005631FC: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 000000563204: 56481133
	s_clause 0x3                                               // 000000563208: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 00000056320C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 000000563214: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 00000056321C: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 000000563224: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 00000056322C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000563230: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563238: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 00000056323C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000563244: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056324C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000563250: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000563258: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 00000056325C: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563264: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000563268: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 000000563270: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563278: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000056327C: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 000000563284: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000563288: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563290: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000563294: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000056329C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005632A4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000005632A8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000005632B0: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000005632B4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005632BC: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000005632C0: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000005632C8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005632D0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000005632D4: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000005632DC: 56461133
	s_clause 0x3                                               // 0000005632E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000005632E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000005632EC: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000005632F4: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000005632FC: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 000000563304: D7006A0C
	v_cndmask_b32_e32 v0, v49, v14, vcc_lo                     // 000000563308: 02001D31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056330C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s15, v50, vcc_lo            // 000000563310: D5207C0D 01AA640F
	.long 0xd7006a1c                                           // 000000563318: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 00000056331C: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 000000563320: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 000000563328: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000056332C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563334: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000563338: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000563340: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563348: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 00000056334C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 000000563354: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000563358: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563360: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000563364: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000056336C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563374: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 000000563378: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 000000563380: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 000000563384: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056338C: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 000000563390: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000563398: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005633A0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000005633A4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000005633AC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000005633B0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005633B8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000005633BC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000005633C4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005633CC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000005633D0: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 0000005633D8: 56441133
	s_clause 0x3                                               // 0000005633DC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000005633E0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000005633E8: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000005633F0: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000005633F8: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 000000563400: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 000000563404: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056340C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 000000563410: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 000000563418: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563420: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 000000563424: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 00000056342C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 000000563430: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 000000563438: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056343C: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 000000563440: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 000000563448: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 00000056344C: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 000000563454: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000563458: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 00000056345C: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 000000563464: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 000000563468: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 00000056346C: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 000000563474: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000563478: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000056347C: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 000000563484: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056348C: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 000000563490: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 000000563498: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000056349C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005634A4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000005634A8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000005634B0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005634B8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000005634BC: CC1A4008 1C228530
	v_fmac_f32_e32 v31, v51, v8                                // 0000005634C4: 563E1133
	v_mov_b32_e32 v14, v7                                      // 0000005634C8: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000005634CC: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000005634D4: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000005634DC: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000005634E4: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000005634E8: 917E107E
	s_cbranch_execz 28                                         // 0000005634EC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000005634F0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 16, v39  // 0000005634F4: CA200114 10264E90
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000005634FC: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 000000563504: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000563508: BF870003
	.long 0xd4430002                                           // 00000056350C: D4430002
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 000000563510: 02024E14
	s_mov_b32 s10, exec_lo                                     // 000000563514: BE8A007E
	.long 0xd4c4007e                                           // 000000563518: D4C4007E
	v_cndmask_b32_e32 v1, s20, v39, vcc_lo                     // 00000056351C: 02024E14
	s_cbranch_execz 65086                                      // 000000563520: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a00                                           // 000000563524: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 000000563528: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056352C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 000000563530: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 000000563538: 7C9A4081
	v_mov_b32_e32 v40, v41                                     // 00000056353C: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 000000563540: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 000000563548: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v0, v[28:29], off                      // 00000056354C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 000000563554: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 000000563558: 7E501700
	s_branch 65071                                             // 00000056355C: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000563560: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000563564: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000563568: 8C7E037E
	.long 0xd71f0000                                           // 00000056356C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000563570: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000563574: 3A020088
	v_xor_b32_e32 v6, 4, v0                                    // 000000563578: 3A0C0084
	v_xor_b32_e32 v11, 2, v0                                   // 00000056357C: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000563580: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000563584: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000563588: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000056358C: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 000000563590: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 000000563594: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000563598: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000056359C: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000005635A0: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 0000005635A4: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 0000005635AC: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 0000005635B0: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 0000005635B4: DACC0000 03002401
	ds_bpermute_b32 v4, v1, v35                                // 0000005635BC: DACC0000 04002301
	ds_bpermute_b32 v5, v1, v34                                // 0000005635C4: DACC0000 05002201
	ds_bpermute_b32 v1, v1, v31                                // 0000005635CC: DACC0000 01001F01
	ds_bpermute_b32 v7, v6, v2                                 // 0000005635D4: DACC0000 07000206
	s_waitcnt lgkmcnt(3)                                       // 0000005635DC: BF89FC37
	v_dual_add_f32 v3, v36, v3 :: v_dual_add_f32 v4, v35, v4   // 0000005635E0: C9080724 03040923
	s_waitcnt lgkmcnt(2)                                       // 0000005635E8: BF89FC27
	v_add_f32_e32 v5, v34, v5                                  // 0000005635EC: 060A0B22
	s_waitcnt lgkmcnt(0)                                       // 0000005635F0: BF89FC07
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v2, v2, v7    // 0000005635F4: C908031F 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 0000005635FC: DACC0000 08000306
	ds_bpermute_b32 v9, v6, v4                                 // 000000563604: DACC0000 09000406
	ds_bpermute_b32 v10, v6, v5                                // 00000056360C: DACC0000 0A000506
	ds_bpermute_b32 v6, v6, v1                                 // 000000563614: DACC0000 06000106
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 00000056361C: 02161700
	s_waitcnt lgkmcnt(2)                                       // 000000563620: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v4, v4, v9     // 000000563624: C9081103 03041304
	s_waitcnt lgkmcnt(0)                                       // 00000056362C: BF89FC07
	v_add_f32_e32 v8, v1, v6                                   // 000000563630: 06100D01
	v_xor_b32_e32 v6, 1, v0                                    // 000000563634: 3A0C0081
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000563638: 30161682
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056363C: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000563640: 7C980CA0
	ds_bpermute_b32 v1, v11, v2                                // 000000563644: DACC0000 0100020B
	ds_bpermute_b32 v9, v11, v4                                // 00000056364C: DACC0000 0900040B
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 000000563654: 02000D00
	v_add_f32_e32 v5, v5, v10                                  // 000000563658: 060A1505
	ds_bpermute_b32 v7, v11, v3                                // 00000056365C: DACC0000 0700030B
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 000000563664: 7C943C80
	v_lshlrev_b32_e32 v12, 2, v0                               // 000000563668: 30180082
	ds_bpermute_b32 v10, v11, v5                               // 00000056366C: DACC0000 0A00050B
	ds_bpermute_b32 v11, v11, v8                               // 000000563674: DACC0000 0B00080B
	s_and_b32 s0, vcc_lo, s0                                   // 00000056367C: 8B00006A
	s_waitcnt lgkmcnt(4)                                       // 000000563680: BF89FC47
	v_add_f32_e32 v6, v2, v1                                   // 000000563684: 060C0302
	s_waitcnt lgkmcnt(2)                                       // 000000563688: BF89FC27
	v_dual_add_f32 v0, v4, v9 :: v_dual_add_f32 v7, v3, v7     // 00000056368C: C9081304 00060F03
	s_waitcnt lgkmcnt(0)                                       // 000000563694: BF89FC07
	v_dual_add_f32 v1, v5, v10 :: v_dual_add_f32 v4, v8, v11   // 000000563698: C9081505 01041708
	ds_bpermute_b32 v8, v12, v6                                // 0000005636A0: DACC0000 0800060C
	ds_bpermute_b32 v9, v12, v7                                // 0000005636A8: DACC0000 0900070C
	ds_bpermute_b32 v2, v12, v0                                // 0000005636B0: DACC0000 0200000C
	ds_bpermute_b32 v3, v12, v1                                // 0000005636B8: DACC0000 0300010C
	ds_bpermute_b32 v5, v12, v4                                // 0000005636C0: DACC0000 0500040C
	s_and_saveexec_b32 s1, s0                                  // 0000005636C8: BE812000
	s_cbranch_execz 72                                         // 0000005636CC: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xef0>
	s_waitcnt lgkmcnt(3)                                       // 0000005636D0: BF89FC37
	v_dual_add_f32 v9, v7, v9 :: v_dual_add_f32 v8, v6, v8     // 0000005636D4: C9081307 09081106
	.long 0x7f143880                                           // 0000005636DC: 7F143880
	.long 0xd73c0006                                           // 0000005636E0: D73C0006
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000005636E4: 02022E81
	s_waitcnt lgkmcnt(1)                                       // 0000005636E8: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 0000005636EC: 06060701
	.long 0x7e143989                                           // 0000005636F0: 7E143989
	.long 0x7e163988                                           // 0000005636F4: 7E163988
	.long 0x7f16398a                                           // 0000005636F8: 7F16398A
	s_waitcnt lgkmcnt(0)                                       // 0000005636FC: BF89FC07
	v_add_f32_e32 v12, v4, v5                                  // 000000563700: 06180B04
	.long 0xd7006a04                                           // 000000563704: D7006A04
	v_cndmask_b32_e32 v1, s8, v6, vcc_lo                       // 000000563708: 02020C08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000056370C: BF8701B3
	v_dual_add_f32 v2, v0, v2 :: v_dual_and_b32 v11, 1, v11    // 000000563710: C9240500 020A1681
	v_add_co_ci_u32_e64 v5, null, s9, v7, vcc_lo               // 000000563718: D5207C05 01AA0E09
	.long 0x7f00398a                                           // 000000563720: 7F00398A
	.long 0x7e003982                                           // 000000563724: 7E003982
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000563728: 8480810C
	v_and_b32_e32 v13, 1, v10                                  // 00000056372C: 361A1481
	.long 0x7e143983                                           // 000000563730: 7E143983
	.long 0xd7006a06                                           // 000000563734: D7006A06
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000563738: 02000104
	v_and_b32_e32 v14, 1, v0                                   // 00000056373C: 361C0081
	v_mad_u64_u32 v[0:1], null, s12, 6, v[4:5]                 // 000000563740: D6FE7C00 04110C0C
	v_add_co_ci_u32_e64 v7, null, s1, v5, vcc_lo               // 000000563748: D5207C07 01AA0A01
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000563750: 8480820C
	v_add3_u32 v11, v8, v11, 0x7fff                            // 000000563754: D655000B 03FE1708 00007FFF
	.long 0xd7006a08                                           // 000000563760: D7006A08
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000563764: 02000104
	v_and_b32_e32 v10, 1, v10                                  // 000000563768: 36141481
	v_add3_u32 v13, v9, v13, 0x7fff                            // 00000056376C: D655000D 03FE1B09 00007FFF
	v_bfe_u32 v15, v12, 16, 1                                  // 000000563778: D610000F 0205210C
	v_add_co_ci_u32_e64 v9, null, s1, v5, vcc_lo               // 000000563780: D5207C09 01AA0A01
	v_add3_u32 v14, v2, v14, 0x7fff                            // 000000563788: D655000E 03FE1D02 00007FFF
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000563794: D6FE7C01 04050C0D
	.long 0xd7006a02                                           // 00000056379C: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000005637A0: 02000108
	v_add3_u32 v10, v3, v10, 0x7fff                            // 0000005637A4: D655000A 03FE1503 00007FFF
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000005637B0: D655000C 03FE1F0C 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 0000005637BC: D5207C03 01AA1201
	s_clause 0x4                                               // 0000005637C4: BF850004
	global_store_d16_hi_b16 v[4:5], v11, off                   // 0000005637C8: DC960000 007C0B04
	global_store_d16_hi_b16 v[6:7], v13, off                   // 0000005637D0: DC960000 007C0D06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 0000005637D8: DC960000 007C0E08
	global_store_d16_hi_b16 v[0:1], v10, off                   // 0000005637E0: DC960000 007C0A00
	global_store_d16_hi_b16 v[2:3], v12, off                   // 0000005637E8: DC960000 007C0C02
	s_endpgm                                                   // 0000005637F0: BFB00000
		...

