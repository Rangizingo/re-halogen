00000000008d0900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008D0900: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 0000008D0908: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008D0910: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008D0914: 86039F02
	v_mov_b32_e32 v5, 0                                        // 0000008D0918: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008D091C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 0000008D0920: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 0000008D0928: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 0000008D092C: 321E0085
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v16, 31, v0        // 0000008D0930: CA240080 1D10009F
	.long 0x7f263880                                           // 0000008D0938: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 0000008D093C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 0000008D0944: BF89FC07
	s_clause 0x1                                               // 0000008D0948: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 0000008D094C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 0000008D0954: DC520000 0D040002
	.long 0xd4510014                                           // 0000008D095C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008D0960: 02001802
	s_and_b32 s20, s20, exec_lo                                // 0000008D0964: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 0000008D0968: 98188003
	s_cselect_b32 s25, s2, 0                                   // 0000008D096C: 98198002
	s_add_u32 s14, s4, s14                                     // 0000008D0970: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008D0974: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 0000008D0978: 85149F0B
	v_mov_b32_e32 v1, s14                                      // 0000008D097C: 7E02020E
	s_add_u32 s20, s10, s20                                    // 0000008D0980: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000008D0984: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008D0988: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000008D098C: 86948114
	s_lshr_b32 s22, s22, 27                                    // 0000008D0990: 85169B16
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s15             // 0000008D0994: CA100080 0702000F
	s_add_u32 s22, s10, s22                                    // 0000008D099C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008D09A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000008D09A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008D09A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008D09AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000008D09B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000008D09B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008D09B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000008D09BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000008D09C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008D09C4: BF8704B9
	s_ashr_i32 s14, s23, 3                                     // 0000008D09C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000008D09CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000008D09D0: 82051105
	v_dual_mov_b32 v3, s4 :: v_dual_mov_b32 v4, s5             // 0000008D09D4: CA100004 03040005
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 0000008D09DC: D6FE7C09 04042819
	.long 0xd72c0012                                           // 0000008D09E4: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008D09E8: 02021E0E
	s_mul_i32 s4, s24, s20                                     // 0000008D09EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000008D09F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008D09F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008D09FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 0000008D0A00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008D0A08: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 0000008D0A0C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 0000008D0A18: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D0A24: BF870002
	.long 0x7e263982                                           // 0000008D0A28: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 0000008D0A2C: 4A041404
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 0000008D0A30: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 0000008D0A38: 4A06240E
	v_add_nc_u32_e32 v10, v18, v16                             // 0000008D0A3C: 4A142112
	s_mul_i32 s25, s25, s21                                    // 0000008D0A40: 96191519
	s_mul_i32 s4, s18, s24                                     // 0000008D0A44: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 0000008D0A48: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s22, v3                                 // 0000008D0A54: 22240616
	v_add_nc_u32_e32 v19, s25, v2                              // 0000008D0A58: 4A260419
	v_add_nc_u32_e32 v3, s19, v12                              // 0000008D0A5C: 4A061813
	ds_store_b32 v14, v1                                       // 0000008D0A60: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 0000008D0A68: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 0000008D0A6C: 4A280604
	s_waitcnt lgkmcnt(0)                                       // 0000008D0A70: BF89FC07
	s_barrier                                                  // 0000008D0A74: BFBD0000
	buffer_gl0_inv                                             // 0000008D0A78: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008D0A80: BE85206A
	s_cbranch_execz 21                                         // 0000008D0A84: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 0000008D0A88: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 0000008D0A8C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008D0A90: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D0A94: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008D0A98: 3408069F
	.long 0xd7000401                                           // 0000008D0A9C: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008D0AA0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0AA4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008D0AA8: D5207C02 00120514
	.long 0xd7000403                                           // 0000008D0AB0: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008D0AB4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008D0AB8: D5207C04 00120913
	s_clause 0x1                                               // 0000008D0AC0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D0AC4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000008D0ACC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000008D0AD4: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 0000008D0AD8: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D0ADC: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000008D0AE0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000008D0AE8: CA100080 18180080
	v_mov_b32_e32 v21, 0                                       // 0000008D0AF0: 7E2A0280
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008D0AF4: BE85206A
	s_cbranch_execz 519                                        // 0000008D0AF8: BFA50207 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xa18>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000008D0AFC: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000008D0B04: CA220080 150C1485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v28, v29           // 0000008D0B0C: CA100080 171C011D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D0B14: BF870003
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v26, 4, v1     // 0000008D0B18: CA220080 191A0284
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v27, 1, v1     // 0000008D0B20: CA220080 161A0281
	v_mov_b32_e32 v17, 0                                       // 0000008D0B28: 7E220280
	s_mul_i32 s4, s11, 6                                       // 0000008D0B2C: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000008D0B30: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000008D0B34: 848E820A
	s_add_i32 s16, s16, s4                                     // 0000008D0B38: 81100410
	s_mul_i32 s18, s10, 6                                      // 0000008D0B3C: 9612860A
	s_mov_b32 s17, 0                                           // 0000008D0B40: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008D0B44: 848A810A
	s_branch 467                                               // 0000008D0B48: BFA001D3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x998>
	s_or_b32 exec_lo, exec_lo, s19                             // 0000008D0B4C: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 0000008D0B50: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000008D0B58: 8B046A7E
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008D0B5C: 4A3434FF 00000200
	s_or_b32 s17, s4, s17                                      // 0000008D0B64: 8C111104
	v_add_nc_u32_e32 v27, 64, v27                              // 0000008D0B68: 4A3636C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008D0B6C: 301A1A82
	ds_load_b32 v46, v13                                       // 0000008D0B70: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 0000008D0B78: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D0B7C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008D0B80: 361A1AFF 000003FC
	ds_load_b32 v47, v13                                       // 0000008D0B88: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 0000008D0B90: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000008D0B94: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 0000008D0B98: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008D0BA0: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0BA4: 360A0AFF 000003FC
	ds_load_b32 v48, v13                                       // 0000008D0BAC: D8D80000 3000000D
	ds_load_b32 v49, v5                                        // 0000008D0BB4: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000008D0BBC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008D0BC4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008D0BC8: 300A0A82
	ds_load_b32 v50, v5                                        // 0000008D0BCC: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000008D0BD4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D0BD8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0BDC: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 0000008D0BE4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000008D0BEC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0BF0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 0000008D0BF8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000008D0C00: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D0C04: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0C08: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 0000008D0C10: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v7                                 // 0000008D0C18: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008D0C20: 300A0A82
	ds_load_b32 v54, v5                                        // 0000008D0C24: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 0000008D0C2C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D0C30: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0C34: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 0000008D0C3C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 0000008D0C44: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0C48: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 0000008D0C50: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 0000008D0C58: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D0C5C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0C60: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 0000008D0C68: D8D80000 39000005
	v_and_b32_e32 v5, 0xff, v8                                 // 0000008D0C70: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008D0C78: 300A0A82
	ds_load_b32 v58, v5                                        // 0000008D0C7C: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 0000008D0C84: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D0C88: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0C8C: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 0000008D0C94: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 0000008D0C9C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0CA0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008D0CA8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008D0CB0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D0CB4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008D0CB8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 0000008D0CC0: D8D80000 3D000005
	.long 0xd73c0005                                           // 0000008D0CC8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008D0CCC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008D0CD0: 4A1818FF 00000400
	.long 0xd7006a2a                                           // 0000008D0CD8: D7006A2A
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008D0CDC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D0CE0: BF870001
	v_add_co_ci_u32_e64 v43, null, s7, v6, vcc_lo              // 0000008D0CE4: D5207C2B 01AA0C07
	s_clause 0x3                                               // 0000008D0CEC: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000008D0CF0: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000008D0CF8: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 0000008D0D00: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000008D0D08: DC5E0030 267C002A
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008D0D10: BF890CF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D0D14: CC1A4005 1A025D05
	s_waitcnt lgkmcnt(14)                                      // 0000008D0D1C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0D20: BF8700A1
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D0D24: CC1A4005 1C165F06
	s_waitcnt lgkmcnt(13)                                      // 0000008D0D2C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D0D30: CC1A4005 1C166107
	s_waitcnt lgkmcnt(12)                                      // 0000008D0D38: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0D3C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D0D40: CC1A4005 1C166308
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008D0D48: BF8908B7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D0D4C: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(10)                                      // 0000008D0D54: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0D58: BF8700A1
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D0D5C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(9)                                       // 0000008D0D64: BF89FC97
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D0D68: CC1A4005 1C166920
	s_waitcnt lgkmcnt(8)                                       // 0000008D0D70: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0D74: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D0D78: CC1A4005 1C166B21
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008D0D80: BF890477
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D0D84: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(6)                                       // 0000008D0D8C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0D90: BF8700A1
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D0D94: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(5)                                       // 0000008D0D9C: BF89FC57
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D0DA0: CC1A4005 1C167124
	s_waitcnt lgkmcnt(4)                                       // 0000008D0DA8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0DAC: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D0DB0: CC1A4005 1C167325
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008D0DB8: BF890037
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D0DBC: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000008D0DC4: D7006A26
	v_cndmask_b32_e32 v0, v42, v10, vcc_lo                     // 0000008D0DC8: 0200152A
	s_waitcnt lgkmcnt(2)                                       // 0000008D0DCC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008D0DD0: BF8701C2
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D0DD4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s11, v43, vcc_lo            // 0000008D0DDC: D5207C27 01AA560B
	.long 0xd7006a2c                                           // 0000008D0DE4: D7006A2C
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 0000008D0DE8: 02001D2A
	s_waitcnt lgkmcnt(1)                                       // 0000008D0DEC: BF89FC17
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D0DF0: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v45, null, s15, v43, vcc_lo            // 0000008D0DF8: D5207C2D 01AA560F
	.long 0xd7006a2a                                           // 0000008D0E00: D7006A2A
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000008D0E04: 0200252A
	s_waitcnt lgkmcnt(0)                                       // 0000008D0E08: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D0E0C: BF870123
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D0E10: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v43, null, s16, v43, vcc_lo            // 0000008D0E18: D5207C2B 01AA5610
	v_fmac_f32_e32 v21, v29, v5                                // 0000008D0E20: 562A0B1D
	s_clause 0x3                                               // 0000008D0E24: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000008D0E28: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000008D0E30: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000008D0E38: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000008D0E40: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000008D0E48: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D0E4C: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0E54: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D0E58: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D0E60: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0E68: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D0E6C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 0000008D0E74: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D0E78: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0E80: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D0E84: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D0E8C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0E94: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D0E98: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008D0EA0: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D0EA4: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0EAC: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D0EB0: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D0EB8: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0EC0: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D0EC4: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008D0ECC: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D0ED0: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0ED8: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D0EDC: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D0EE4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0EEC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D0EF0: CC1A4005 1C167B29
	v_fmac_f32_e32 v25, v29, v5                                // 0000008D0EF8: 56320B1D
	s_clause 0x3                                               // 0000008D0EFC: BF850003
	global_load_b128 v[5:8], v[44:45], off                     // 0000008D0F00: DC5E0000 057C002C
	global_load_b128 v[30:33], v[44:45], off offset:16         // 0000008D0F08: DC5E0010 1E7C002C
	global_load_b128 v[34:37], v[44:45], off offset:32         // 0000008D0F10: DC5E0020 227C002C
	global_load_b128 v[38:41], v[44:45], off offset:48         // 0000008D0F18: DC5E0030 267C002C
	s_waitcnt vmcnt(3)                                         // 0000008D0F20: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D0F24: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0F2C: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D0F30: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D0F38: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0F40: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D0F44: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 0000008D0F4C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D0F50: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0F58: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D0F5C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D0F64: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0F6C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D0F70: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008D0F78: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D0F7C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0F84: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D0F88: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D0F90: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D0F98: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D0F9C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008D0FA4: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D0FA8: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0FB0: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D0FB4: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D0FBC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D0FC4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D0FC8: CC1A4005 1C167B29
	v_fmac_f32_e32 v24, v29, v5                                // 0000008D0FD0: 56300B1D
	s_clause 0x3                                               // 0000008D0FD4: BF850003
	global_load_b128 v[5:8], v[42:43], off                     // 0000008D0FD8: DC5E0000 057C002A
	global_load_b128 v[30:33], v[42:43], off offset:16         // 0000008D0FE0: DC5E0010 1E7C002A
	global_load_b128 v[34:37], v[42:43], off offset:32         // 0000008D0FE8: DC5E0020 227C002A
	global_load_b128 v[38:41], v[42:43], off offset:48         // 0000008D0FF0: DC5E0030 267C002A
	s_waitcnt vmcnt(3)                                         // 0000008D0FF8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D0FFC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1004: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D1008: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D1010: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1018: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D101C: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 0000008D1024: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D1028: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1030: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D1034: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D103C: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1044: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D1048: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008D1050: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D1054: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D105C: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D1060: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D1068: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1070: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D1074: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008D107C: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D1080: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000008D1088: D7006A26
	v_cndmask_b32_e32 v0, v44, v14, vcc_lo                     // 0000008D108C: 02001D2C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D1090: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D1094: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s15, v45, vcc_lo            // 0000008D109C: D5207C27 01AA5A0F
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D10A4: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D10AC: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D10B0: CC1A4005 1C167B29
	v_fmac_f32_e32 v23, v29, v5                                // 0000008D10B8: 562E0B1D
	s_clause 0x3                                               // 0000008D10BC: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000008D10C0: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000008D10C8: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000008D10D0: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000008D10D8: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000008D10E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D10E4: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D10EC: BF870091
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D10F0: CC1A4005 1C165F06
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D10F8: CC1A4005 1C166107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1100: BF8700A1
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D1104: CC1A4005 1C166308
	s_waitcnt vmcnt(2)                                         // 0000008D110C: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D1110: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1118: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D111C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D1124: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D112C: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D1130: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008D1138: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D113C: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1144: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D1148: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D1150: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1158: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D115C: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008D1164: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D1168: CC1A4005 1C167526
	.long 0xd7006a26                                           // 0000008D1170: D7006A26
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 0000008D1174: 02001D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D1178: BF870122
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D117C: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v39, null, s15, v43, vcc_lo            // 0000008D1184: D5207C27 01AA560F
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D118C: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1194: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D1198: CC1A4005 1C167B29
	v_fmac_f32_e32 v22, v29, v5                                // 0000008D11A0: 562C0B1D
	s_clause 0x3                                               // 0000008D11A4: BF850003
	global_load_b128 v[5:8], v[38:39], off                     // 0000008D11A8: DC5E0000 057C0026
	global_load_b128 v[30:33], v[38:39], off offset:16         // 0000008D11B0: DC5E0010 1E7C0026
	global_load_b128 v[34:37], v[38:39], off offset:32         // 0000008D11B8: DC5E0020 227C0026
	global_load_b128 v[38:41], v[38:39], off offset:48         // 0000008D11C0: DC5E0030 267C0026
	s_waitcnt vmcnt(3)                                         // 0000008D11C8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v46, 0                             // 0000008D11CC: CC1A4005 1A025D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D11D4: BF870121
	v_dot2_f32_bf16 v5, v6, v47, v5                            // 0000008D11D8: CC1A4005 1C165F06
	v_mov_b32_e32 v6, v2                                       // 0000008D11E0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v48, v5                            // 0000008D11E4: CC1A4005 1C166107
	v_mov_b32_e32 v7, v3                                       // 0000008D11EC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008D11F0: BF870132
	v_dot2_f32_bf16 v5, v8, v49, v5                            // 0000008D11F4: CC1A4005 1C166308
	v_mov_b32_e32 v8, v4                                       // 0000008D11FC: 7E100304
	s_waitcnt vmcnt(2)                                         // 0000008D1200: BF890BF7
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 0000008D1204: CC1A4005 1C16651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D120C: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 0000008D1210: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 0000008D1218: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D1220: BF8700A1
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000008D1224: CC1A4005 1C166B21
	s_waitcnt vmcnt(1)                                         // 0000008D122C: BF8907F7
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000008D1230: CC1A4005 1C166D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1238: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000008D123C: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008D1244: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D124C: BF8700A1
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008D1250: CC1A4005 1C167325
	s_waitcnt vmcnt(0)                                         // 0000008D1258: BF8903F7
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008D125C: CC1A4005 1C167526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1264: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008D1268: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008D1270: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D1278: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000008D127C: CC1A4005 1C167B29
	v_fmac_f32_e32 v17, v29, v5                                // 0000008D1284: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 0000008D1288: 7E0A0301
	v_mov_b32_e32 v29, v28                                     // 0000008D128C: 7E3A031C
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000008D1290: 917E117E
	s_cbranch_execz 31                                         // 0000008D1294: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xa14>
	s_waitcnt vmcnt(0)                                         // 0000008D1298: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 0000008D129C: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000008D12A4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000008D12AC: 7E080308
	s_mov_b32 s19, exec_lo                                     // 0000008D12B0: BE93007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D12B4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000008D12B8: 7C8C250A
	.long 0xd4c1007e                                           // 0000008D12BC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000008D12C0: 0202250A
	s_cbranch_execz 65057                                      // 0000008D12C4: BFA5FE21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	v_ashrrev_i32_e32 v2, 31, v27                              // 0000008D12C8: 3404369F
	v_ashrrev_i32_e32 v4, 31, v26                              // 0000008D12CC: 3408349F
	.long 0xd7000401                                           // 0000008D12D0: D7000401
	v_cndmask_b32_e32 v1, v11, v27, vcc_lo                     // 0000008D12D4: 0202370B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D12D8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008D12DC: D5207C02 00120514
	.long 0xd7000403                                           // 0000008D12E4: D7000403
	v_cndmask_b32_e32 v1, v9, v26, vcc_lo                      // 0000008D12E8: 02023509
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008D12EC: D5207C04 00120913
	s_clause 0x1                                               // 0000008D12F4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000008D12F8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008D1300: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008D1308: BF8907F7
	v_cvt_f32_f16_e32 v28, v13                                 // 0000008D130C: 7E38170D
	s_branch 65038                                             // 0000008D1310: BFA0FE0E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x24c>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008D1314: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D1318: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D131C: 8C7E057E
	.long 0xd71f0001                                           // 0000008D1320: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008D1324: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008D1328: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008D132C: 3A040290
	s_waitcnt vmcnt(0)                                         // 0000008D1330: BF8903F7
	v_xor_b32_e32 v8, 8, v1                                    // 0000008D1334: 3A100288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008D1338: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008D133C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008D1340: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008D1344: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D1348: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008D134C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 0000008D1350: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 0000008D1358: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 0000008D135C: 06060715
	ds_bpermute_b32 v4, v2, v25                                // 0000008D1360: DACC0000 04001902
	ds_bpermute_b32 v5, v2, v24                                // 0000008D1368: DACC0000 05001802
	ds_bpermute_b32 v6, v2, v23                                // 0000008D1370: DACC0000 06001702
	ds_bpermute_b32 v7, v2, v22                                // 0000008D1378: DACC0000 07001602
	ds_bpermute_b32 v2, v2, v17                                // 0000008D1380: DACC0000 02001102
	s_waitcnt lgkmcnt(3)                                       // 0000008D1388: BF89FC37
	v_dual_cndmask_b32 v8, v1, v8 :: v_dual_add_f32 v5, v24, v5// 0000008D138C: CA481101 08040B18
	s_waitcnt lgkmcnt(0)                                       // 0000008D1394: BF89FC07
	v_dual_add_f32 v7, v22, v7 :: v_dual_add_f32 v2, v17, v2   // 0000008D1398: C9080F16 07020511
	v_xor_b32_e32 v17, 4, v1                                   // 0000008D13A0: 3A220284
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D13A4: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000008D13A8: 7C9822A0
	v_dual_cndmask_b32 v17, v1, v17 :: v_dual_lshlrev_b32 v8, 2, v8// 0000008D13AC: CA622301 11081082
	ds_bpermute_b32 v9, v8, v3                                 // 0000008D13B4: DACC0000 09000308
	ds_bpermute_b32 v11, v8, v5                                // 0000008D13BC: DACC0000 0B000508
	v_add_f32_e32 v4, v25, v4                                  // 0000008D13C4: 06080919
	v_add_f32_e32 v6, v23, v6                                  // 0000008D13C8: 060C0D17
	ds_bpermute_b32 v13, v8, v7                                // 0000008D13CC: DACC0000 0D000708
	v_lshlrev_b32_e32 v17, 2, v17                              // 0000008D13D4: 30222282
	ds_bpermute_b32 v10, v8, v4                                // 0000008D13D8: DACC0000 0A000408
	s_waitcnt lgkmcnt(3)                                       // 0000008D13E0: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 0000008D13E4: 06061303
	s_waitcnt lgkmcnt(2)                                       // 0000008D13E8: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 0000008D13EC: 060A1705
	ds_bpermute_b32 v12, v8, v6                                // 0000008D13F0: DACC0000 0C000608
	ds_bpermute_b32 v8, v8, v2                                 // 0000008D13F8: DACC0000 08000208
	s_waitcnt lgkmcnt(2)                                       // 0000008D1400: BF89FC27
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v4, v4, v10   // 0000008D1404: C9081B07 07041504
	ds_bpermute_b32 v10, v17, v5                               // 0000008D140C: DACC0000 0A000511
	ds_bpermute_b32 v9, v17, v4                                // 0000008D1414: DACC0000 09000411
	s_waitcnt lgkmcnt(3)                                       // 0000008D141C: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 0000008D1420: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 0000008D1424: BF89FC27
	v_add_f32_e32 v2, v2, v8                                   // 0000008D1428: 06041102
	ds_bpermute_b32 v8, v17, v3                                // 0000008D142C: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v7                               // 0000008D1434: DACC0000 0C000711
	ds_bpermute_b32 v11, v17, v6                               // 0000008D143C: DACC0000 0B000611
	ds_bpermute_b32 v13, v17, v2                               // 0000008D1444: DACC0000 0D000211
	v_xor_b32_e32 v17, 2, v1                                   // 0000008D144C: 3A220282
	s_waitcnt lgkmcnt(4)                                       // 0000008D1450: BF89FC47
	v_add_f32_e32 v4, v4, v9                                   // 0000008D1454: 06081304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008D1458: BF870132
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000008D145C: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 0000008D1460: 02222301
	v_add_f32_e32 v5, v5, v10                                  // 0000008D1464: 060A1505
	v_lshlrev_b32_e32 v17, 2, v17                              // 0000008D1468: 30222282
	s_waitcnt lgkmcnt(3)                                       // 0000008D146C: BF89FC37
	v_add_f32_e32 v3, v3, v8                                   // 0000008D1470: 06061103
	s_waitcnt lgkmcnt(1)                                       // 0000008D1474: BF89FC17
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v6, v6, v11   // 0000008D1478: C9081907 07061706
	s_waitcnt lgkmcnt(0)                                       // 0000008D1480: BF89FC07
	v_add_f32_e32 v8, v2, v13                                  // 0000008D1484: 06101B02
	ds_bpermute_b32 v9, v17, v4                                // 0000008D1488: DACC0000 09000411
	ds_bpermute_b32 v2, v17, v3                                // 0000008D1490: DACC0000 02000311
	ds_bpermute_b32 v10, v17, v5                               // 0000008D1498: DACC0000 0A000511
	ds_bpermute_b32 v11, v17, v6                               // 0000008D14A0: DACC0000 0B000611
	ds_bpermute_b32 v12, v17, v7                               // 0000008D14A8: DACC0000 0C000711
	ds_bpermute_b32 v13, v17, v8                               // 0000008D14B0: DACC0000 0D000811
	v_xor_b32_e32 v17, 1, v1                                   // 0000008D14B8: 3A220281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D14BC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000008D14C0: 7C9822A0
	v_cndmask_b32_e32 v1, v1, v17, vcc_lo                      // 0000008D14C4: 02022301
	v_lshlrev_b32_e32 v17, 2, v1                               // 0000008D14C8: 30220282
	s_waitcnt lgkmcnt(4)                                       // 0000008D14CC: BF89FC47
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v4, v9     // 0000008D14D0: C9080503 01021304
	s_waitcnt lgkmcnt(2)                                       // 0000008D14D8: BF89FC27
	v_dual_add_f32 v4, v5, v10 :: v_dual_add_f32 v5, v6, v11   // 0000008D14DC: C9081505 04041706
	s_waitcnt lgkmcnt(1)                                       // 0000008D14E4: BF89FC17
	v_add_f32_e32 v3, v7, v12                                  // 0000008D14E8: 06061907
	s_waitcnt lgkmcnt(0)                                       // 0000008D14EC: BF89FC07
	v_add_f32_e32 v9, v8, v13                                  // 0000008D14F0: 06121B08
	ds_bpermute_b32 v6, v17, v1                                // 0000008D14F4: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 0000008D14FC: DACC0000 07000211
	ds_bpermute_b32 v10, v17, v4                               // 0000008D1504: DACC0000 0A000411
	ds_bpermute_b32 v11, v17, v5                               // 0000008D150C: DACC0000 0B000511
	ds_bpermute_b32 v8, v17, v3                                // 0000008D1514: DACC0000 08000311
	ds_bpermute_b32 v12, v17, v9                               // 0000008D151C: DACC0000 0C000911
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008D1524: 7D942080
	s_cbranch_execz 12                                         // 0000008D1528: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xc5c>
	s_waitcnt lgkmcnt(0)                                       // 0000008D152C: BF89FC07
	v_dual_add_f32 v9, v9, v12 :: v_dual_add_f32 v4, v4, v10   // 0000008D1530: C9081909 09041504
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v8, v3, v8    // 0000008D1538: C9081705 05081103
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v1, v1, v6     // 0000008D1540: C9080F02 02000D01
	v_mul_u32_u24_e32 v6, 24, v15                              // 0000008D1548: 160C1E98
	ds_store_2addr_b64 v6, v[1:2], v[4:5] offset0:128 offset1:129// 0000008D154C: D9388180 00040106
	ds_store_b64 v6, v[8:9] offset:1040                        // 0000008D1554: D9340410 00000806
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008D155C: 8C7E047E
	.long 0xd4510004                                           // 0000008D1560: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008D1564: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 6, v0                             // 0000008D1568: 7C980086
	s_waitcnt lgkmcnt(0)                                       // 0000008D156C: BF89FC07
	s_barrier                                                  // 0000008D1570: BFBD0000
	buffer_gl0_inv                                             // 0000008D1574: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008D157C: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008D1580: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008D1584: BE852004
	s_cbranch_execz 79                                         // 0000008D1588: BFA5004F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xdc8>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 0000008D158C: 4A0E1CFF 00000400
	s_lshr_b32 s4, s13, 31                                     // 0000008D1594: 85049F0D
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008D1598: F4040000 F8000040
	s_add_u32 s4, s12, s4                                      // 0000008D15A0: 8004040C
	s_addc_u32 s5, s13, 0                                      // 0000008D15A4: 8205800D
	ds_load_2addr_b32 v[1:2], v7 offset1:6                     // 0000008D15A8: D8DC0600 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:12 offset1:18         // 0000008D15B0: D8DC120C 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:24 offset1:30         // 0000008D15B8: D8DC1E18 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008D15C0: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008D15C4: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008D15C8: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008D15CC: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008D15D0: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008D15D4: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008D15DC: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008D15E0: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008D15E4: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008D15E8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D15EC: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008D15F0: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008D15F4: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008D15F8: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008D1600: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008D1604: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D160C: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008D1610: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008D1614: 06080B03
	ds_load_2addr_b32 v[7:8], v7 offset0:36 offset1:42         // 0000008D1618: D8DC2A24 07000007
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008D1620: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008D1628: 8B057E04
	s_cselect_b32 s8, s8, s0                                   // 0000008D162C: 98080008
	v_add_f32_e32 v0, v4, v6                                   // 0000008D1630: 06000D04
	s_cselect_b32 s5, s9, s1                                   // 0000008D1634: 98050109
	s_add_u32 s0, s2, 0xffffff00                               // 0000008D1638: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008D1640: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008D1644: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008D1648: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008D164C: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D1650: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008D1654: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008D1658: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008D165C: 06060F00
	.long 0xd73c0000                                           // 0000008D1660: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008D1664: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008D1668: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D166C: BF870092
	.long 0xd7006a00                                           // 0000008D1670: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008D1674: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008D1678: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008D1680: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008D1684: D6100003 02052102
	.long 0xd7006a00                                           // 0000008D168C: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008D1690: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008D1694: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008D1698: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008D16A0: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D16AC: BF870093
	.long 0xd7006a00                                           // 0000008D16B0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008D16B4: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008D16B8: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008D16C0: DC960000 007C0200
	s_endpgm                                                   // 0000008D16C8: BFB00000
		...

