000000000044f500 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 00000044F500: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 00000044F504: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000044F50C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 00000044F514: F4080500 F8000040
	s_mov_b32 s4, s3                                           // 00000044F51C: BE840003
	v_and_b32_e32 v42, 31, v0                                  // 00000044F520: 3654009F
	v_lshrrev_b32_e32 v40, 5, v0                               // 00000044F524: 32500085
	s_delay_alu instid0(VALU_DEP_2)                            // 00000044F528: BF870002
	v_lshlrev_b32_e32 v8, 3, v42                               // 00000044F52C: 30105483
	s_waitcnt lgkmcnt(0)                                       // 00000044F530: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 00000044F534: 86229F19
	s_mul_i32 s33, s27, s4                                     // 00000044F538: 9621041B
	s_lshr_b32 s3, s34, 25                                     // 00000044F53C: 85039922
	s_add_i32 s5, s33, s27                                     // 00000044F540: 81051B21
	s_add_i32 s3, s25, s3                                      // 00000044F544: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000044F548: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000044F54C: 86038703
	s_min_i32 s3, s3, s5                                       // 00000044F550: 89030503
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000044F554: BF8704B9
	s_sub_i32 s11, s3, s33                                     // 00000044F558: 818B2103
	s_mov_b32 s3, exec_lo                                      // 00000044F55C: BE83007E
	s_lshl_b32 s10, s11, 1                                     // 00000044F560: 840A810B
	.long 0xd4c3007e                                           // 00000044F564: D4C3007E
	v_cndmask_b32_e32 v1, s10, v40, vcc_lo                     // 00000044F568: 0202500A
	s_xor_b32 s3, exec_lo, s3                                  // 00000044F56C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v42                               // 00000044F570: 30105483
	s_or_saveexec_b32 s35, s3                                  // 00000044F574: BEA32203
	s_clause 0x1                                               // 00000044F578: BF850001
	s_load_b32 s27, s[0:1], 0x54                               // 00000044F57C: F40006C0 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 00000044F584: F4080700 F8000000
	v_lshlrev_b32_e32 v41, 2, v42                              // 00000044F58C: 30525482
	s_xor_b32 exec_lo, exec_lo, s35                            // 00000044F590: 8D7E237E
	s_cbranch_execz 501                                        // 00000044F594: BFA501F5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	s_add_i32 s36, s24, -1                                     // 00000044F598: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000044F59C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 00000044F5A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 00000044F5A4: 982580C1
	s_abs_i32 s38, s11                                         // 00000044F5A8: BEA6150B
	v_and_b32_e32 v3, 2, v0                                    // 00000044F5AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 00000044F5B0: BE806526
	v_dual_mov_b32 v9, v40 :: v_dual_and_b32 v4, 4, v0         // 00000044F5B4: CA240128 09040084
	v_and_b32_e32 v5, 8, v0                                    // 00000044F5BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044F5C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 00000044F5C4: 7E045600
	v_lshl_or_b32 v6, v40, 8, v8                               // 00000044F5C8: D6560006 04211128
	v_add_nc_u32_e32 v7, s33, v40                              // 00000044F5D0: 4A0E5021
	s_ashr_i32 s42, s11, 31                                    // 00000044F5D4: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 00000044F5D8: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 00000044F5DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 00000044F5E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v42, vcc_lo                      // 00000044F5E8: 02025490
	.long 0xd44a0001                                           // 00000044F5EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000044F5F0: 02020280
	.long 0xd44a0005                                           // 00000044F5F4: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000044F5F8: 02020880
	.long 0xd44a0006                                           // 00000044F5FC: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000044F600: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 00000044F604: 7E060502
	v_lshl_or_b32 v1, v7, 7, v41                               // 00000044F608: D6560001 04A50F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 00000044F610: 4E140C2C
	s_lshl_b32 s7, s11, 7                                      // 00000044F614: 8407870B
	s_mov_b32 s39, s25                                         // 00000044F618: BEA70019
	s_mul_f32 s8, s3, 0x4f7ffffe                               // 00000044F61C: A208FF03 4F7FFFFE
	.long 0xd44a0003                                           // 00000044F624: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000044F628: 02020680
	s_mov_b32 s40, 0                                           // 00000044F62C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 00000044F630: BEA900FF 76543210
	s_cvt_u32_f32 s8, s8                                       // 00000044F638: BE886708
	s_lshl_b32 s43, s11, 8                                     // 00000044F63C: 842B880B
	s_sub_i32 s44, 0, s7                                       // 00000044F640: 81AC0780
	s_mov_b32 s46, 0x3db504f3                                  // 00000044F644: BEAE00FF 3DB504F3
	s_mul_i32 s9, s9, s8                                       // 00000044F64C: 96090809
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000044F650: BF870499
	s_mul_hi_u32 s9, s8, s9                                    // 00000044F654: 96890908
	s_add_i32 s45, s8, s9                                      // 00000044F658: 812D0908
	s_branch 161                                               // 00000044F65C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F660: BF870091
	.long 0xd7006a02                                           // 00000044F664: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000044F668: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000044F66C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000044F674: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000044F67C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 00000044F684: 06061D10
	s_waitcnt vmcnt(0)                                         // 00000044F688: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000044F68C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 00000044F694: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 00000044F698: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000044F6A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 00000044F6A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 00000044F6AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044F6B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000044F6B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000044F6C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 00000044F6C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044F6CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000044F6D4: D5010007 20060F07
	.long 0xd72c0006                                           // 00000044F6DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 00000044F6E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044F6E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000044F6F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 00000044F6F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 00000044F6FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000044F700: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000044F708: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044F710: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 00000044F718: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000044F71C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044F724: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000044F72C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000044F730: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044F738: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000044F740: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 00000044F748: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000044F74C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000044F754: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000044F75C: 060A1905
	.long 0xd72c0007                                           // 00000044F760: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 00000044F764: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 00000044F768: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044F76C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 00000044F774: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000044F778: D5010004 20160904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044F780: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000044F788: D5010005 20160B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044F790: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000044F798: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000044F7A0: D5010002 20160502
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000044F7A8: D5010003 20160703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 00000044F7B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044F7B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 00000044F7BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000044F7C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044F7C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 00000044F7D0: D5010004 201A0904
	v_add_f32_e32 v3, v3, v13                                  // 00000044F7D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044F7DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 00000044F7E4: D5010005 201A0B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044F7EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 00000044F7F4: D5010002 201A0502
	v_add_f32_e32 v4, v4, v11                                  // 00000044F7FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000044F800: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 00000044F808: D5010003 201A0703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044F810: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 00000044F814: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 00000044F81C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000044F820: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044F828: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 00000044F82C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 00000044F834: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000044F838: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000044F83C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000044F848: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 00000044F850: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000044F854: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000044F85C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 00000044F864: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 00000044F870: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 00000044F87C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 00000044F880: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s10, v9                           // 00000044F88C: 7C86120A
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 00000044F890: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 00000044F898: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044F89C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 00000044F8A0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 00000044F8AC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 00000044F8B4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044F8BC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 00000044F8C0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 00000044F8C8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 00000044F8D0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 00000044F8D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 00000044F8DC: 917E287E
	s_cbranch_execz 289                                        // 00000044F8E0: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x868>
	.long 0xd72d0002                                           // 00000044F8E4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 00000044F8E8: 02005B09
	s_mov_b32 s7, -1                                           // 00000044F8EC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F8F0: BF870091
	.long 0xd72c0003                                           // 00000044F8F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 00000044F8F8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 00000044F8FC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000044F900: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 00000044F904: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000044F908: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000044F90C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044F914: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000044F918: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000044F91C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F920: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000044F924: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000044F928: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000044F92C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F930: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 00000044F934: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 00000044F938: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044F93C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 00000044F940: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 00000044F948: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000044F94C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F954: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000044F958: 340E0C9F
	.long 0xd73c0002                                           // 00000044F95C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000044F960: 02020C81
	s_cbranch_vccnz 211                                        // 00000044F964: BFA400D3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F968: BF870093
	.long 0xd7006a06                                           // 00000044F96C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000044F970: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000044F974: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 00000044F97C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044F980: BF870112
	.long 0xd73c0006                                           // 00000044F984: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000044F988: 02020C81
	.long 0x7f40399d                                           // 00000044F98C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 00000044F990: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044F994: BF870092
	.long 0xd7006a0d                                           // 00000044F998: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000044F99C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 00000044F9A0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 00000044F9A8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 00000044F9AC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044F9B0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 00000044F9B4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 00000044F9BC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 00000044F9C4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000044F9C8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 00000044F9CC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 00000044F9D4: D5207C10 01AA060D
	s_clause 0x1                                               // 00000044F9DC: BF850001
	global_load_b32 v17, v[15:16], off                         // 00000044F9E0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 00000044F9E8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 00000044F9F0: BF890FF7
	.long 0x7e20390d                                           // 00000044F9F4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 00000044F9F8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 00000044F9FC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000044FA04: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FA08: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000044FA0C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 00000044FA10: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000044FA18: BF870291
	v_exp_f32_e32 v20, v20                                     // 00000044FA1C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 00000044FA20: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FA2C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 00000044FA30: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 00000044FA38: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000044FA40: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 00000044FA44: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 00000044FA48: 30241C90
	v_div_scale_f32 v37, s8, v16, v20, v16                     // 00000044FA4C: D6FC0825 04422910
	v_rcp_f32_e32 v28, v24                                     // 00000044FA54: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FA58: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 00000044FA5C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 00000044FA60: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FA68: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 00000044FA6C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 00000044FA74: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 00000044FA7C: BF870003
	v_exp_f32_e32 v21, v21                                     // 00000044FA80: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 00000044FA84: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 00000044FA8C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 00000044FA94: 56383924
	v_rcp_f32_e32 v26, v23                                     // 00000044FA98: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000044FA9C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 00000044FAA0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FAAC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 00000044FAB0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 00000044FAB8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044FAC0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 00000044FAC4: 7E2C4B16
	v_div_scale_f32 v35, s7, v18, v21, v18                     // 00000044FAC8: D6FC0723 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 00000044FAD0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000044FAD4: BF870313
	v_rcp_f32_e32 v30, v25                                     // 00000044FAD8: 7E3C5519
	v_add_f32_e32 v22, 1.0, v22                                // 00000044FADC: 062C2CF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FAE0: BF870115
	v_fma_f32 v38, -v25, v30, 1.0                              // 00000044FAE4: D6130026 23CA3D19
	v_div_scale_f32 v27, null, v22, v22, v14                   // 00000044FAEC: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s9, v14, v22, v14                     // 00000044FAF4: D6FC0924 043A2D0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FAFC: BF870193
	v_fmac_f32_e32 v30, v38, v30                               // 00000044FB00: 563C3D26
	v_rcp_f32_e32 v31, v27                                     // 00000044FB04: 7E3E551B
	v_mul_f32_e32 v38, v33, v26                                // 00000044FB08: 104C3521
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000044FB0C: BF870291
	v_fma_f32 v44, -v23, v38, v33                              // 00000044FB10: D613002C 24864D17
	v_fma_f32 v34, -v27, v31, 1.0                              // 00000044FB18: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FB20: BF870091
	v_dual_fmac_f32 v38, v44, v26 :: v_dual_fmac_f32 v31, v34, v31// 00000044FB24: C800352C 261E3F22
	v_fma_f32 v23, -v23, v38, v33                              // 00000044FB2C: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FB34: BF870092
	v_mul_f32_e32 v45, v36, v31                                // 00000044FB38: 105A3F24
	v_fma_f32 v44, -v27, v45, v36                              // 00000044FB3C: D613002C 24925B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044FB44: BF870211
	v_fmac_f32_e32 v45, v44, v31                               // 00000044FB48: 565A3F2C
	v_div_fmas_f32 v23, v23, v26, v38                          // 00000044FB4C: D6370017 049A3517
	s_mov_b32 vcc_lo, s8                                       // 00000044FB54: BEEA0008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FB58: BF870191
	v_div_fixup_f32 v13, v23, v19, v13                         // 00000044FB5C: D627000D 04362717
	v_fma_f32 v23, -v27, v45, v36                              // 00000044FB64: D6130017 24925B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000044FB6C: BF870122
	v_mul_f32_e32 v13, v13, v39                                // 00000044FB70: 101A4F0D
	v_dual_mul_f32 v34, v37, v28 :: v_dual_mul_f32 v43, v35, v30// 00000044FB74: C8C63925 222A3D23
	.long 0x7e3a398d                                           // 00000044FB7C: 7E3A398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FB80: BF870192
	v_fma_f32 v46, -v24, v34, v37                              // 00000044FB84: D613002E 24964518
	v_fma_f32 v47, -v25, v43, v35                              // 00000044FB8C: D613002F 248E5719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FB94: BF870091
	v_dual_fmac_f32 v34, v46, v28 :: v_dual_fmac_f32 v43, v47, v30// 00000044FB98: C800392E 222A3D2F
	v_fma_f32 v24, -v24, v34, v37                              // 00000044FBA0: D6130018 24964518
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FBA8: BF870112
	v_fma_f32 v25, -v25, v43, v35                              // 00000044FBAC: D6130019 248E5719
	v_div_fmas_f32 v24, v24, v28, v34                          // 00000044FBB4: D6370018 048A3918
	s_mov_b32 vcc_lo, s7                                       // 00000044FBBC: BEEA0007
	s_mov_b32 s7, 0                                            // 00000044FBC0: BE870080
	s_delay_alu instid0(VALU_DEP_2)                            // 00000044FBC4: BF870002
	v_div_fmas_f32 v19, v25, v30, v43                          // 00000044FBC8: D6370013 04AE3D19
	s_mov_b32 vcc_lo, s9                                       // 00000044FBD0: BEEA0009
	v_div_fixup_f32 v16, v24, v20, v16                         // 00000044FBD4: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 00000044FBDC: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000044FBE0: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 00000044FBE8: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044FBF0: BF8700A4
	v_mul_f32_e32 v6, v16, v6                                  // 00000044FBF4: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v45                          // 00000044FBF8: D6370010 04B63F17
	v_div_fixup_f32 v14, v16, v22, v14                         // 00000044FC00: D627000E 043A2D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FC08: BF870091
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v16, 1, v29   // 00000044FC0C: C8E40F0E 07103A81
	v_add3_u32 v13, v13, v16, 0x7fff                           // 00000044FC14: D655000D 03FE210D 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FC20: BF870112
	v_bfe_u32 v16, v7, 16, 1                                   // 00000044FC24: D6100010 02052107
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000044FC2C: 361A1AFF FFFF0000
	.long 0x7e403986                                           // 00000044FC34: 7E403986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044FC38: BF8701A3
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000044FC3C: D6550007 03FE2107 00007FFF
	v_mul_f32_e32 v18, v18, v20                                // 00000044FC48: 10242912
	v_and_b32_e32 v20, 1, v32                                  // 00000044FC4C: 36284081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FC50: BF870112
	v_bfe_u32 v19, v18, 16, 1                                  // 00000044FC54: D6100013 02052112
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000044FC5C: D6550006 03FE2906 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FC68: BF870112
	v_add3_u32 v14, v18, v19, 0x7fff                           // 00000044FC6C: D655000E 03FE2712 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000044FC78: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000044FC80: BF8701B2
	v_and_b32_e32 v18, 0xffff0000, v14                         // 00000044FC84: 36241CFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 00000044FC8C: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000044FC90: CC20080E 8A021B11
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 00000044FC98: CC200010 8A020D11
	s_waitcnt vmcnt(0)                                         // 00000044FCA0: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 00000044FCA4: CC20000D 8A02250F
	v_and_b32_e32 v15, 0xffff0000, v7                          // 00000044FCAC: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000044FCB4: 916A077E
	s_cbranch_vccnz 65129                                      // 00000044FCB8: BFA4FE69 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044FCBC: BF8700A3
	.long 0xd73c0004                                           // 00000044FCC0: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000044FCC4: 02020881
	s_waitcnt lgkmcnt(0)                                       // 00000044FCC8: BF89FC07
	.long 0xd7006a04                                           // 00000044FCCC: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 00000044FCD0: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000044FCD4: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 00000044FCD8: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 00000044FCE0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000044FCE4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044FCE8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000044FCEC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000044FCF4: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000044FCF8: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 00000044FCFC: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 00000044FD04: DC560000 047C0004
	s_clause 0x1                                               // 00000044FD0C: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000044FD10: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000044FD18: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000044FD20: BF890BF7
	.long 0x7e0e3904                                           // 00000044FD24: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000044FD28: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000044FD30: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044FD34: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000044FD38: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000044FD3C: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000044FD40: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 00000044FD48: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 00000044FD4C: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 00000044FD54: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 00000044FD5C: 361E0AFF FFFF0000
	s_branch 65086                                             // 00000044FD64: BFA0FE3E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 00000044FD68: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000044FD6C: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 00000044FD70: 8C7E237E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000044FD74: 938AFF0B 0001001C
	v_mad_u32_u24 v10, v42, 24, 0x2f0                          // 00000044FD7C: D60B000A 03FD312A 000002F0
	s_lshr_b64 s[0:1], s[10:11], 29                            // 00000044FD88: 85809D0A
	s_lshr_b32 s1, s34, 28                                     // 00000044FD8C: 85019C22
	s_add_i32 s0, s0, 7                                        // 00000044FD90: 81008700
	s_add_i32 s1, s25, s1                                      // 00000044FD94: 81010119
	s_ashr_i32 s0, s0, 3                                       // 00000044FD98: 86008300
	v_lshrrev_b32_e32 v1, 5, v10                               // 00000044FD9C: 32021485
	.long 0xd72c0007                                           // 00000044FDA0: D72C0007
	v_cndmask_b32_e32 v1, s0, v40, vcc_lo                      // 00000044FDA4: 02025000
	s_ashr_i32 s1, s1, 4                                       // 00000044FDA8: 86018401
	s_lshl_b32 s3, s11, 3                                      // 00000044FDAC: 8403830B
	s_lshl_b32 s5, s33, 3                                      // 00000044FDB0: 84058321
	s_mul_hi_i32 s7, s1, s2                                    // 00000044FDB4: 97070201
	s_mul_i32 s1, s1, s2                                       // 00000044FDB8: 96010201
	s_ashr_i32 s6, s5, 31                                      // 00000044FDBC: 86069F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v42                            // 00000044FDC0: 7C945480
	v_add_nc_u32_e32 v2, s0, v7                                // 00000044FDC4: 4A040E00
	s_add_u32 s0, s1, s5                                       // 00000044FDC8: 80000501
	s_addc_u32 s1, s7, s6                                      // 00000044FDCC: 82010607
	s_mul_i32 s5, s0, 0x300                                    // 00000044FDD0: 9605FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 00000044FDD8: B8010300
	v_min_i32_e32 v43, s3, v2                                  // 00000044FDDC: 22560403
	v_subrev_nc_u32_e32 v2, 24, v1                             // 00000044FDE0: 4E040298
	v_add_nc_u32_e32 v1, 1, v7                                 // 00000044FDE4: 4A020E81
	s_mul_hi_u32 s3, s0, 0x300                                 // 00000044FDE8: 9683FF00 00000300
	v_add_nc_u32_e32 v11, 8, v10                               // 00000044FDF0: 4A161488
	s_add_i32 s3, s3, s1                                       // 00000044FDF4: 81030103
	v_cndmask_b32_e64 v14, v2, 23, vcc_lo                      // 00000044FDF8: D501000E 01A92F02
	.long 0xd4410000                                           // 00000044FE00: D4410000
	v_cndmask_b32_e32 v1, v1, v43, vcc_lo                      // 00000044FE04: 02025701
	s_waitcnt lgkmcnt(0)                                       // 00000044FE08: BF89FC07
	s_add_u32 s6, s28, s5                                      // 00000044FE0C: 8006051C
	s_addc_u32 s7, s29, s3                                     // 00000044FE10: 8207031D
	s_barrier                                                  // 00000044FE14: BFBD0000
	buffer_gl0_inv                                             // 00000044FE18: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000044FE20: BE812000
	s_cbranch_execz 123                                        // 00000044FE24: BFA5007B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb14>
	v_lshrrev_b32_e32 v2, 5, v11                               // 00000044FE28: 32041685
	.long 0xd4440000                                           // 00000044FE2C: D4440000
	v_cndmask_b32_e32 v1, 23, v14, vcc_lo                      // 00000044FE30: 02021C97
	v_mad_i64_i32 v[4:5], null, 0x300, v1, s[6:7]              // 00000044FE34: D6FF7C04 001A02FF 00000300
	v_mov_b32_e32 v15, 0                                       // 00000044FE40: 7E1E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000044FE44: BF870214
	v_subrev_nc_u32_e32 v2, 24, v2                             // 00000044FE48: 4E040498
	v_cndmask_b32_e64 v3, 0xe9, 1, s0                          // 00000044FE4C: D5010003 000102FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000044FE58: BF870193
	.long 0xd73c000c                                           // 00000044FE5C: D73C000C
	v_cndmask_b32_e32 v1, 2, v14, vcc_lo                       // 00000044FE60: 02021C82
	v_cndmask_b32_e64 v2, v2, 23, vcc_lo                       // 00000044FE64: D5010002 01A92F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044FE6C: BF8701A3
	v_add_nc_u32_e32 v6, v3, v14                               // 00000044FE70: 4A0C1D03
	v_mov_b32_e32 v3, v15                                      // 00000044FE74: 7E06030F
	.long 0xd4440000                                           // 00000044FE78: D4440000
	v_cndmask_b32_e32 v1, 23, v2, vcc_lo                       // 00000044FE7C: 02020497
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000044FE80: BF8701A3
	v_lshlrev_b32_e32 v1, 24, v6                               // 00000044FE84: 30020C98
	v_bfe_i32 v6, v6, 7, 1                                     // 00000044FE88: D6110006 02050F06
	v_cndmask_b32_e64 v9, 0xe9, 1, s0                          // 00000044FE90: D5010009 000102FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000044FE9C: BF8700A3
	v_ashrrev_i32_e32 v15, 22, v1                              // 00000044FEA0: 341E0296
	.long 0xd700000c                                           // 00000044FEA4: D700000C
	v_cndmask_b32_e32 v1, v4, v12, vcc_lo                      // 00000044FEA8: 02021904
	v_add_co_ci_u32_e64 v13, null, v5, v13, s0                 // 00000044FEAC: D5207C0D 00021B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000044FEB4: BF8700B4
	v_add_nc_u32_e32 v9, v9, v2                                // 00000044FEB8: 4A120509
	.long 0xd73c0001                                           // 00000044FEBC: D73C0001
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000044FEC0: 02020482
	.long 0xd700000f                                           // 00000044FEC4: D700000F
	v_cndmask_b32_e32 v1, v4, v15, vcc_lo                      // 00000044FEC8: 02021F04
	v_add_co_ci_u32_e64 v16, null, v5, v6, s0                  // 00000044FECC: D5207C10 00020D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000044FED4: BF8700B4
	v_lshlrev_b32_e32 v3, 24, v9                               // 00000044FED8: 30061298
	v_bfe_i32 v6, v9, 7, 1                                     // 00000044FEDC: D6110006 02050F09
	.long 0xd7000001                                           // 00000044FEE4: D7000001
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 00000044FEE8: 02020304
	v_add_co_ci_u32_e64 v2, null, v5, v2, s0                   // 00000044FEEC: D5207C02 00020505
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000044FEF4: BF870094
	v_ashrrev_i32_e32 v3, 22, v3                               // 00000044FEF8: 34060696
	.long 0xd7000003                                           // 00000044FEFC: D7000003
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 00000044FF00: 02020704
	s_delay_alu instid0(VALU_DEP_1)                            // 00000044FF04: BF870001
	v_add_co_ci_u32_e64 v4, null, v5, v6, s0                   // 00000044FF08: D5207C04 00020D05
	s_clause 0x1f                                              // 00000044FF10: BF85001F
	global_load_b32 v49, v[12:13], off                         // 00000044FF14: DC520000 317C000C
	global_load_b32 v48, v[12:13], off offset:96               // 00000044FF1C: DC520060 307C000C
	global_load_b32 v47, v[12:13], off offset:192              // 00000044FF24: DC5200C0 2F7C000C
	global_load_b32 v46, v[12:13], off offset:288              // 00000044FF2C: DC520120 2E7C000C
	global_load_b32 v45, v[12:13], off offset:384              // 00000044FF34: DC520180 2D7C000C
	global_load_b32 v44, v[12:13], off offset:480              // 00000044FF3C: DC5201E0 2C7C000C
	global_load_b32 v50, v[12:13], off offset:576              // 00000044FF44: DC520240 327C000C
	global_load_b32 v52, v[12:13], off offset:672              // 00000044FF4C: DC5202A0 347C000C
	global_load_b32 v61, v[15:16], off                         // 00000044FF54: DC520000 3D7C000F
	global_load_b32 v58, v[15:16], off offset:96               // 00000044FF5C: DC520060 3A7C000F
	global_load_b32 v56, v[15:16], off offset:192              // 00000044FF64: DC5200C0 387C000F
	global_load_b32 v54, v[15:16], off offset:288              // 00000044FF6C: DC520120 367C000F
	global_load_b32 v53, v[15:16], off offset:384              // 00000044FF74: DC520180 357C000F
	global_load_b32 v51, v[15:16], off offset:480              // 00000044FF7C: DC5201E0 337C000F
	global_load_b32 v66, v[15:16], off offset:576              // 00000044FF84: DC520240 427C000F
	global_load_b32 v64, v[15:16], off offset:672              // 00000044FF8C: DC5202A0 407C000F
	global_load_b32 v68, v[1:2], off                           // 00000044FF94: DC520000 447C0001
	global_load_b32 v65, v[1:2], off offset:96                 // 00000044FF9C: DC520060 417C0001
	global_load_b32 v62, v[1:2], off offset:192                // 00000044FFA4: DC5200C0 3E7C0001
	global_load_b32 v59, v[1:2], off offset:288                // 00000044FFAC: DC520120 3B7C0001
	global_load_b32 v57, v[1:2], off offset:384                // 00000044FFB4: DC520180 397C0001
	global_load_b32 v55, v[1:2], off offset:480                // 00000044FFBC: DC5201E0 377C0001
	global_load_b32 v73, v[1:2], off offset:576                // 00000044FFC4: DC520240 497C0001
	global_load_b32 v72, v[1:2], off offset:672                // 00000044FFCC: DC5202A0 487C0001
	global_load_b32 v71, v[3:4], off                           // 00000044FFD4: DC520000 477C0003
	global_load_b32 v70, v[3:4], off offset:96                 // 00000044FFDC: DC520060 467C0003
	global_load_b32 v69, v[3:4], off offset:192                // 00000044FFE4: DC5200C0 457C0003
	global_load_b32 v67, v[3:4], off offset:288                // 00000044FFEC: DC520120 437C0003
	global_load_b32 v63, v[3:4], off offset:384                // 00000044FFF4: DC520180 3F7C0003
	global_load_b32 v60, v[3:4], off offset:480                // 00000044FFFC: DC5201E0 3C7C0003
	global_load_b32 v75, v[3:4], off offset:576                // 000000450004: DC520240 4B7C0003
	global_load_b32 v74, v[3:4], off offset:672                // 00000045000C: DC5202A0 4A7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000450014: 8C7E017E
	.long 0xd4410000                                           // 000000450018: D4410000
	v_cndmask_b32_e32 v1, v7, v43, vcc_lo                      // 00000045001C: 02025707
	s_and_saveexec_b32 s3, s0                                  // 000000450020: BE832000
	s_cbranch_execz 121                                        // 000000450024: BFA50079 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd0c>
	v_lshrrev_b32_e32 v1, 5, v11                               // 000000450028: 32021685
	.long 0xd4440001                                           // 00000045002C: D4440001
	v_cndmask_b32_e32 v1, 23, v14, vcc_lo                      // 000000450030: 02021C97
	v_mov_b32_e32 v15, 0                                       // 000000450034: 7E1E0280
	v_mad_i64_i32 v[3:4], null, 0x300, v7, s[6:7]              // 000000450038: D6FF7C03 001A0EFF 00000300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000450044: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 000000450048: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 00000045004C: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000450058: BF870112
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000045005C: D5010001 01A92F01
	v_dual_mov_b32 v2, v15 :: v_dual_add_nc_u32 v9, v2, v14    // 000000450064: CA20010F 02081D02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045006C: BF870112
	.long 0xd4440001                                           // 000000450070: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 000000450074: 02020297
	v_lshlrev_b32_e32 v12, 24, v9                              // 000000450078: 30181298
	.long 0xd73c0005                                           // 00000045007C: D73C0005
	v_cndmask_b32_e32 v1, 2, v14, vcc_lo                       // 000000450080: 02021C82
	v_bfe_i32 v9, v9, 7, 1                                     // 000000450084: D6110009 02050F09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045008C: BF870214
	v_cndmask_b32_e64 v13, 0xe9, 1, s1                         // 000000450090: D501000D 000502FF 000000E9
	v_ashrrev_i32_e32 v15, 22, v12                             // 00000045009C: 341E1896
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004500A0: BF870194
	.long 0xd700010c                                           // 0000004500A4: D700010C
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004500A8: 02020B03
	v_add_nc_u32_e32 v17, v13, v1                              // 0000004500AC: 4A22030D
	.long 0xd73c0001                                           // 0000004500B0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000004500B4: 02020282
	v_add_co_ci_u32_e64 v13, null, v4, v6, s1                  // 0000004500B8: D5207C0D 00060D04
	.long 0xd700010f                                           // 0000004500C0: D700010F
	v_cndmask_b32_e32 v1, v3, v15, vcc_lo                      // 0000004500C4: 02021F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004500C8: BF870244
	v_lshlrev_b32_e32 v5, 24, v17                              // 0000004500CC: 300A2298
	v_bfe_i32 v6, v17, 7, 1                                    // 0000004500D0: D6110006 02050F11
	v_add_co_ci_u32_e64 v16, null, v4, v9, s1                  // 0000004500D8: D5207C10 00061304
	.long 0xd700014c                                           // 0000004500E0: D700014C
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 0000004500E4: 02020303
	v_ashrrev_i32_e32 v5, 22, v5                               // 0000004500E8: 340A0A96
	v_add_co_ci_u32_e64 v77, null, v4, v2, s1                  // 0000004500EC: D5207C4D 00060504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004500F4: BF870092
	.long 0xd700014e                                           // 0000004500F8: D700014E
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004500FC: 02020B03
	v_add_co_ci_u32_e64 v79, null, v4, v6, s1                  // 000000450100: D5207C4F 00060D04
	s_clause 0x1f                                              // 000000450108: BF85001F
	global_load_b32 v2, v[12:13], off                          // 00000045010C: DC520000 027C000C
	global_load_b32 v6, v[12:13], off offset:96                // 000000450114: DC520060 067C000C
	global_load_b32 v35, v[12:13], off offset:192              // 00000045011C: DC5200C0 237C000C
	global_load_b32 v31, v[12:13], off offset:288              // 000000450124: DC520120 1F7C000C
	global_load_b32 v27, v[12:13], off offset:384              // 00000045012C: DC520180 1B7C000C
	global_load_b32 v19, v[12:13], off offset:480              // 000000450134: DC5201E0 137C000C
	global_load_b32 v23, v[12:13], off offset:576              // 00000045013C: DC520240 177C000C
	global_load_b32 v13, v[12:13], off offset:672              // 000000450144: DC5202A0 0D7C000C
	global_load_b32 v1, v[15:16], off                          // 00000045014C: DC520000 017C000F
	global_load_b32 v5, v[15:16], off offset:96                // 000000450154: DC520060 057C000F
	global_load_b32 v34, v[15:16], off offset:192              // 00000045015C: DC5200C0 227C000F
	global_load_b32 v30, v[15:16], off offset:288              // 000000450164: DC520120 1E7C000F
	global_load_b32 v26, v[15:16], off offset:384              // 00000045016C: DC520180 1A7C000F
	global_load_b32 v18, v[15:16], off offset:480              // 000000450174: DC5201E0 127C000F
	global_load_b32 v22, v[15:16], off offset:576              // 00000045017C: DC520240 167C000F
	global_load_b32 v12, v[15:16], off offset:672              // 000000450184: DC5202A0 0C7C000F
	global_load_b32 v4, v[76:77], off                          // 00000045018C: DC520000 047C004C
	global_load_b32 v39, v[76:77], off offset:96               // 000000450194: DC520060 277C004C
	global_load_b32 v37, v[76:77], off offset:192              // 00000045019C: DC5200C0 257C004C
	global_load_b32 v33, v[76:77], off offset:288              // 0000004501A4: DC520120 217C004C
	global_load_b32 v29, v[76:77], off offset:384              // 0000004501AC: DC520180 1D7C004C
	global_load_b32 v21, v[76:77], off offset:480              // 0000004501B4: DC5201E0 157C004C
	global_load_b32 v25, v[76:77], off offset:576              // 0000004501BC: DC520240 197C004C
	global_load_b32 v17, v[76:77], off offset:672              // 0000004501C4: DC5202A0 117C004C
	global_load_b32 v3, v[78:79], off                          // 0000004501CC: DC520000 037C004E
	global_load_b32 v38, v[78:79], off offset:96               // 0000004501D4: DC520060 267C004E
	global_load_b32 v36, v[78:79], off offset:192              // 0000004501DC: DC5200C0 247C004E
	global_load_b32 v32, v[78:79], off offset:288              // 0000004501E4: DC520120 207C004E
	global_load_b32 v28, v[78:79], off offset:384              // 0000004501EC: DC520180 1C7C004E
	global_load_b32 v20, v[78:79], off offset:480              // 0000004501F4: DC5201E0 147C004E
	global_load_b32 v24, v[78:79], off offset:576              // 0000004501FC: DC520240 187C004E
	global_load_b32 v16, v[78:79], off offset:672              // 000000450204: DC5202A0 107C004E
	s_or_b32 exec_lo, exec_lo, s3                              // 00000045020C: 8C7E037E
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v76, 0              // 000000450210: CA100080 094C0080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v78, 0             // 000000450218: CA100080 4D4E0080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v82, 0             // 000000450220: CA100080 4F520080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v80, 0             // 000000450228: CA100080 51500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0             // 000000450230: CA100080 54520080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v85, 0             // 000000450238: CA100080 56540080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v89, 0             // 000000450240: CA100080 58580080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v90, 0             // 000000450248: CA100080 575A0080
	s_ashr_i32 s3, s2, 31                                      // 000000450250: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 000000450254: BE812000
	s_cbranch_execz 1142                                       // 000000450258: BFA50476 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f34>
	v_lshrrev_b32_e32 v9, 5, v11                               // 00000045025C: 32121685
	v_or_b32_e32 v76, 4, v8                                    // 000000450260: 38981084
	v_dual_mov_b32 v78, 23 :: v_dual_and_b32 v79, 16, v0       // 000000450264: CA240097 4E4E0090
	.long 0xd7030050                                           // 00000045026C: D7030050
	v_cndmask_b32_e32 v0, v14, v129, vcc_lo                    // 000000450270: 0201030E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000450274: BF870234
	v_subrev_nc_u32_e32 v8, 24, v9                             // 000000450278: 4E101298
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v10, 0x7e0, v10     // 00000045027C: CA240080 090A14FF 000007E0
	v_add_nc_u32_e32 v92, 2, v7                                // 000000450288: 4AB80E82
	.long 0xd762004d                                           // 00000045028C: D762004D
	v_cndmask_b32_e32 v1, 0xff, v80, vcc_lo                    // 000000450290: 0202A0FF 000000FF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000450298: BF870004
	v_cndmask_b32_e64 v8, v8, 23, vcc_lo                       // 00000045029C: D5010008 01A92F08
	v_lshl_or_b32 v94, v7, 5, v79                              // 0000004502A4: D656005E 053D0B07
	v_mul_i32_i24_e32 v11, 0xffffffe8, v42                     // 0000004502AC: 121654FF FFFFFFE8
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000004502B4: 341E1C9F
	.long 0xd7044007                                           // 0000004502B8: D7044007
	v_cndmask_b32_e32 v1, v14, v78, vcc_lo                     // 0000004502BC: 02029D0E
	.long 0xd7034050                                           // 0000004502C0: D7034050
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 0000004502C4: 02010308
	v_cmp_gt_u16_e32 vcc_lo, 24, v77                           // 0000004502C8: 7C789A98
	v_mad_u32_u24 v82, v76, 3, 0x2f0                           // 0000004502CC: D60B0052 03FD074C 000002F0
	v_add3_u32 v93, v11, v10, 0xfffffd34                       // 0000004502D8: D655005D 03FE150B FFFFFD34
	.long 0xd73c000a                                           // 0000004502E4: D73C000A
	v_cndmask_b32_e32 v1, 2, v14, vcc_lo                       // 0000004502E8: 02021C82
	.long 0xd7621007                                           // 0000004502EC: D7621007
	v_cndmask_b32_e32 v1, 0xff, v80, vcc_lo                    // 0000004502F0: 0202A0FF 000000FF
	v_mul_i32_i24_e32 v83, -3, v76                             // 0000004502F8: 12A698C3
	v_dual_mov_b32 v76, v9 :: v_dual_and_b32 v15, 0x7e0, v82   // 0000004502FC: CA240109 4C0EA4FF 000007E0
	v_sub_nc_u32_e32 v91, 0, v43                               // 000000450308: 4CB65680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045030C: BF870004
	.long 0xd43d0000                                           // 000000450310: D43D0000
	v_cndmask_b32_e32 v1, 24, v7, vcc_lo                       // 000000450314: 02020E98
	v_cndmask_b16 v7, v7, v80, vcc_lo                          // 000000450318: D65D0807 01AAA107
	v_mov_b32_e32 v78, v9                                      // 000000450320: 7E9C0309
	v_add3_u32 v95, v83, v15, 0xfffffd34                       // 000000450324: D655005F 03FE1F53 FFFFFD34
	v_mov_b32_e32 v77, v9                                      // 000000450330: 7E9A0309
	v_cndmask_b16 v14, 0, v80, s0                              // 000000450334: D65D100E 0002A080
	v_mov_b32_e32 v79, v9                                      // 00000045033C: 7E9E0309
	v_and_b32_e32 v7, 0xff, v7                                 // 000000450340: 360E0EFF 000000FF
	v_mov_b32_e32 v81, v9                                      // 000000450348: 7EA20309
	v_mov_b32_e32 v80, v9                                      // 00000045034C: 7EA00309
	v_and_b32_e32 v84, 0xff, v14                               // 000000450350: 36A81CFF 000000FF
	.long 0xd73c000e                                           // 000000450358: D73C000E
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 00000045035C: 02021082
	v_mov_b32_e32 v82, v9                                      // 000000450360: 7EA40309
	v_lshlrev_b32_e32 v96, 2, v7                               // 000000450364: 30C00E82
	s_delay_alu instid0(VALU_DEP_4)                            // 000000450368: BF870004
	v_dual_mov_b32 v86, v9 :: v_dual_lshlrev_b32 v97, 2, v84   // 00000045036C: CA220109 5660A882
	v_mov_b32_e32 v84, v9                                      // 000000450374: 7EA80309
	v_mov_b32_e32 v83, v9                                      // 000000450378: 7EA60309
	v_mov_b32_e32 v85, v9                                      // 00000045037C: 7EAA0309
	v_mov_b32_e32 v88, v9                                      // 000000450380: 7EB00309
	v_mov_b32_e32 v89, v9                                      // 000000450384: 7EB20309
	v_mov_b32_e32 v87, v9                                      // 000000450388: 7EAE0309
	v_mov_b32_e32 v90, v9                                      // 00000045038C: 7EB40309
	s_mov_b32 s0, 0                                            // 000000450390: BE800080
	s_movk_i32 s5, 0x1eee                                      // 000000450394: B0051EEE
	s_branch 959                                               // 000000450398: BFA003BF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1d98>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000045039C: 8C7E087E
	.long 0xd73d0007                                           // 0000004503A0: D73D0007
	v_cndmask_b32_e32 v1, v93, v1, vcc_lo                      // 0000004503A4: 0202035D
	.long 0xd73d0082                                           // 0000004503A8: D73D0082
	v_cndmask_b32_e32 v1, v95, v3, vcc_lo                      // 0000004503AC: 0202075F
	ds_load_b128 v[1:4], v94                                   // 0000004503B0: DBFC0000 0100005E
	.long 0xd73d0026                                           // 0000004503B8: D73D0026
	v_cndmask_b32_e32 v1, v95, v38, vcc_lo                     // 0000004503BC: 02024D5F
	.long 0xd73d0022                                           // 0000004503C0: D73D0022
	v_cndmask_b32_e32 v1, v93, v34, vcc_lo                     // 0000004503C4: 0202455D
	.long 0xd73d0023                                           // 0000004503C8: D73D0023
	v_cndmask_b32_e32 v1, v95, v36, vcc_lo                     // 0000004503CC: 0202495F
	v_bfe_u32 v8, v7, 9, 16                                    // 0000004503D0: D6100008 02411307
	v_bfe_u32 v131, v7, 6, 16                                  // 0000004503D8: D6100083 02410D07
	v_bfe_u32 v133, v130, 9, 16                                // 0000004503E0: D6100085 02411382
	v_bfe_u32 v134, v130, 6, 16                                // 0000004503E8: D6100086 02410D82
	v_bfe_u32 v132, v7, 3, 16                                  // 0000004503F0: D6100084 02410707
	.long 0xd72c0008                                           // 0000004503F8: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 0000004503FC: 020210FF 83DCD12D
	.long 0xd72c0083                                           // 000000450404: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000450408: 020306FF 83DCD12D
	.long 0xd72c0085                                           // 000000450410: D72C0085
	v_cndmask_b32_e32 v1, 0x83dcd12d, v133, vcc_lo             // 000000450414: 02030AFF 83DCD12D
	.long 0xd72c0086                                           // 00000045041C: D72C0086
	v_cndmask_b32_e32 v1, 0x83dcd12d, v134, vcc_lo             // 000000450420: 02030CFF 83DCD12D
	v_bfe_u32 v135, v130, 3, 16                                // 000000450428: D6100087 02410782
	.long 0xd72c0084                                           // 000000450430: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 000000450434: 020308FF 83DCD12D
	v_bfe_u32 v138, v38, 6, 16                                 // 00000045043C: D610008A 02410D26
	v_bfe_u32 v37, v34, 6, 16                                  // 000000450444: D6100025 02410D22
	v_sad_u8 v8, v8, 0, 0x6400                                 // 00000045044C: D6220008 03FD0108 00006400
	v_sad_u8 v131, v131, 0, 0x6400                             // 000000450458: D6220083 03FD0183 00006400
	v_sad_u8 v133, v133, 0, 0x6400                             // 000000450464: D6220085 03FD0185 00006400
	v_sad_u8 v134, v134, 0, 0x6400                             // 000000450470: D6220086 03FD0186 00006400
	.long 0xd72c0087                                           // 00000045047C: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 000000450480: 02030EFF 83DCD12D
	v_and_b32_e32 v8, 0xffff, v8                               // 000000450488: 361010FF 0000FFFF
	v_sad_u8 v132, v132, 0, 0x6400                             // 000000450490: D6220084 03FD0184 00006400
	v_and_b32_e32 v133, 0xffff, v133                           // 00000045049C: 370B0AFF 0000FFFF
	.long 0xd72c008a                                           // 0000004504A4: D72C008A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v138, vcc_lo             // 0000004504A8: 020314FF 83DCD12D
	v_bfe_u32 v139, v38, 3, 16                                 // 0000004504B0: D610008B 02410726
	v_lshl_or_b32 v136, v131, 16, v8                           // 0000004504B8: D6560088 04212183
	.long 0xd72c0025                                           // 0000004504C0: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 0000004504C4: 02024AFF 83DCD12D
	v_lshl_or_b32 v133, v134, 16, v133                         // 0000004504CC: D6560085 06152186
	v_sad_u8 v135, v135, 0, 0x6400                             // 0000004504D4: D6220087 03FD0187 00006400
	.long 0xd73d001e                                           // 0000004504E0: D73D001E
	v_cndmask_b32_e32 v1, v93, v30, vcc_lo                     // 0000004504E4: 02023D5D
	v_pk_fma_f16 v134, v136, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004504E8: CC0E0086 0BFC0B88 0000C931
	v_and_b32_e32 v7, 0xffff, v7                               // 0000004504F4: 360E0EFF 0000FFFF
	v_and_b32_e32 v130, 0xffff, v130                           // 0000004504FC: 370504FF 0000FFFF
	v_pk_fma_f16 v133, v133, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000450504: CC0E0085 0BFC0B85 0000C931
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000450510: D6220025 03FD0125 00006400
	.long 0xd73d001a                                           // 00000045051C: D73D001A
	v_cndmask_b32_e32 v1, v93, v26, vcc_lo                     // 000000450520: 0202355D
	.long 0xd72c0007                                           // 000000450524: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 000000450528: 02020EFF 83DCD12D
	.long 0xd72c0082                                           // 000000450530: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000450534: 020304FF 83DCD12D
	.long 0xd73d001b                                           // 00000045053C: D73D001B
	v_cndmask_b32_e32 v1, v95, v28, vcc_lo                     // 000000450540: 0202395F
	.long 0xd73d0012                                           // 000000450544: D73D0012
	v_cndmask_b32_e32 v1, v93, v18, vcc_lo                     // 000000450548: 0202255D
	.long 0xd73d000c                                           // 00000045054C: D73D000C
	v_cndmask_b32_e32 v1, v93, v12, vcc_lo                     // 000000450550: 0202195D
	v_bfe_u32 v29, v26, 6, 16                                  // 000000450554: D610001D 02410D1A
	.long 0xd73d0010                                           // 00000045055C: D73D0010
	v_cndmask_b32_e32 v1, v95, v16, vcc_lo                     // 000000450560: 0202215F
	v_add_nc_u32_e32 v92, 1, v92                               // 000000450564: 4AB8B881
	v_sad_u8 v7, v7, 0, 0x6400                                 // 000000450568: D6220007 03FD0107 00006400
	v_sad_u8 v130, v130, 0, 0x6400                             // 000000450574: D6220082 03FD0182 00006400
	.long 0xd72c001d                                           // 000000450580: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000450584: 02023AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045058C: BF870193
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000450590: 300E0E90
	v_lshlrev_b32_e32 v137, 16, v130                           // 000000450594: 31130490
	.long 0xd73d0082                                           // 000000450598: D73D0082
	v_cndmask_b32_e32 v1, v93, v5, vcc_lo                      // 00000045059C: 02020B5D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004505A0: BF870214
	v_sad_u8 v29, v29, 0, 0x6400                               // 0000004505A4: D622001D 03FD011D 00006400
	v_and_or_b32 v132, 0xffff, v132, v7                        // 0000004505B0: D6570084 041F08FF 0000FFFF
	ds_load_b128 v[5:8], v94 offset:5120                       // 0000004505BC: DBFC1400 0500005E
	s_waitcnt lgkmcnt(1)                                       // 0000004505C4: BF89FC17
	v_dot2acc_f32_f16 v90, v134, v1                            // 0000004505C8: 04B40386
	v_add_nc_u32_e32 v94, 32, v94                              // 0000004505CC: 4ABCBCA0
	v_pk_fma_f16 v132, v132, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004505D0: CC0E0084 0BFC0B84 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004505DC: BF870091
	v_dot2acc_f32_f16 v90, v132, v2                            // 0000004505E0: 04B40584
	v_dot2acc_f32_f16 v90, v133, v3                            // 0000004505E4: 04B40785
	v_and_or_b32 v131, 0xffff, v135, v137                      // 0000004505E8: D6570083 06270EFF 0000FFFF
	v_bfe_u32 v135, v130, 9, 16                                // 0000004505F4: D6100087 02411382
	v_bfe_u32 v137, v38, 9, 16                                 // 0000004505FC: D6100089 02411326
	s_waitcnt lgkmcnt(0)                                       // 000000450604: BF89FC07
	v_dot2acc_f32_f16 v87, v134, v5                            // 000000450608: 04AE0B86
	s_delay_alu instid0(VALU_DEP_3)                            // 00000045060C: BF870003
	.long 0xd72c0027                                           // 000000450610: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 000000450614: 02030EFF 83DCD12D
	v_bfe_u32 v135, v130, 6, 16                                // 00000045061C: D6100087 02410D82
	.long 0xd72c0089                                           // 000000450624: D72C0089
	v_cndmask_b32_e32 v1, 0x83dcd12d, v137, vcc_lo             // 000000450628: 020312FF 83DCD12D
	v_pk_fma_f16 v131, v131, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000450630: CC0E0083 0BFC0B83 0000C931
	v_dot2acc_f32_f16 v87, v132, v6                            // 00000045063C: 04AE0D84
	v_and_b32_e32 v136, 0xffff, v130                           // 000000450640: 371104FF 0000FFFF
	v_bfe_u32 v130, v130, 3, 16                                // 000000450648: D6100082 02410782
	.long 0xd72c0087                                           // 000000450650: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v135, vcc_lo             // 000000450654: 02030EFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000045065C: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v87, v133, v7                            // 000000450668: 04AE0F85
	.long 0xd72c0088                                           // 00000045066C: D72C0088
	v_cndmask_b32_e32 v1, 0x83dcd12d, v136, vcc_lo             // 000000450670: 020310FF 83DCD12D
	.long 0xd72c0082                                           // 000000450678: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 00000045067C: 020304FF 83DCD12D
	v_sad_u8 v137, v137, 0, 0x6400                             // 000000450684: D6220089 03FD0189 00006400
	v_dot2acc_f32_f16 v90, v131, v4                            // 000000450690: 04B40983
	v_dot2acc_f32_f16 v87, v131, v8                            // 000000450694: 04AE1183
	v_sad_u8 v135, v135, 0, 0x6400                             // 000000450698: D6220087 03FD0187 00006400
	v_bfe_u32 v131, v35, 6, 16                                 // 0000004506A4: D6100083 02410D23
	v_sad_u8 v136, v136, 0, 0x6400                             // 0000004506AC: D6220088 03FD0188 00006400
	v_sad_u8 v130, v130, 0, 0x6400                             // 0000004506B8: D6220082 03FD0182 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004506C4: BF870193
	.long 0xd72c0083                                           // 0000004506C8: D72C0083
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000004506CC: 020306FF 83DCD12D
	v_lshlrev_b32_e32 v136, 16, v136                           // 0000004506D4: 31111090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004506D8: BF870241
	v_and_or_b32 v130, 0xffff, v130, v136                      // 0000004506DC: D6570082 062304FF 0000FFFF
	v_and_b32_e32 v136, 0xffff, v137                           // 0000004506E8: 371112FF 0000FFFF
	v_sad_u8 v137, v138, 0, 0x6400                             // 0000004506F0: D6220089 03FD018A 00006400
	v_sad_u8 v131, v131, 0, 0x6400                             // 0000004506FC: D6220083 03FD0183 00006400
	v_pk_fma_f16 v130, v130, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000450708: CC0E0082 0BFC0B82 0000C931
	v_and_b32_e32 v39, 0xffff, v39                             // 000000450714: 364E4EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045071C: BF870114
	v_lshl_or_b32 v134, v137, 16, v136                         // 000000450720: D6560086 06212189
	v_lshl_or_b32 v39, v135, 16, v39                           // 000000450728: D6560027 049D2187
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000450730: BF8701A2
	v_pk_fma_f16 v132, v134, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000450734: CC0E0084 0BFC0B86 0000C931
	.long 0xd72c0087                                           // 000000450740: D72C0087
	v_cndmask_b32_e32 v1, 0x83dcd12d, v139, vcc_lo             // 000000450744: 020316FF 83DCD12D
	v_pk_fma_f16 v39, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000045074C: CC0E0027 0BFC0B27 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000450758: BF870241
	v_dot2acc_f32_f16 v88, v39, v5                             // 00000045075C: 04B00B27
	v_dot2acc_f32_f16 v89, v39, v1                             // 000000450760: 04B20327
	v_bfe_u32 v39, v34, 9, 16                                  // 000000450764: D6100027 02411322
	v_sad_u8 v135, v135, 0, 0x6400                             // 00000045076C: D6220087 03FD0187 00006400
	v_dot2acc_f32_f16 v88, v130, v6                            // 000000450778: 04B00D82
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045077C: BF870214
	v_dot2acc_f32_f16 v89, v130, v2                            // 000000450780: 04B20582
	.long 0xd72c0024                                           // 000000450784: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000450788: 02024EFF 83DCD12D
	v_and_b32_e32 v39, 0xffff, v34                             // 000000450790: 364E44FF 0000FFFF
	v_bfe_u32 v34, v34, 3, 16                                  // 000000450798: D6100022 02410722
	v_dot2acc_f32_f16 v88, v132, v7                            // 0000004507A0: 04B00F84
	v_dual_dot2acc_f32_f16 v89, v132, v3 :: v_dual_and_b32 v38, 0xffff, v38// 0000004507A4: CB240784 59264CFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004507B0: BF870214
	.long 0xd72c0027                                           // 0000004507B4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000004507B8: 02024EFF 83DCD12D
	.long 0xd72c0022                                           // 0000004507C0: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 0000004507C4: 020244FF 83DCD12D
	v_bfe_u32 v130, v35, 9, 16                                 // 0000004507CC: D6100082 02411323
	v_sad_u8 v36, v36, 0, 0x6400                               // 0000004507D4: D6220024 03FD0124 00006400
	.long 0xd72c0026                                           // 0000004507E0: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 0000004507E4: 02024CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004507EC: BF870253
	.long 0xd72c0082                                           // 0000004507F0: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000004507F4: 020304FF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 0000004507FC: D6220027 03FD0127 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000450808: D6220022 03FD0122 00006400
	v_and_b32_e32 v36, 0xffff, v36                             // 000000450814: 364848FF 0000FFFF
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000045081C: D6220026 03FD0126 00006400
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000450828: 304E4E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045082C: BF8701A3
	v_lshl_or_b32 v36, v37, 16, v36                            // 000000450830: D6560024 04912125
	v_sad_u8 v130, v130, 0, 0x6400                             // 000000450838: D6220082 03FD0182 00006400
	v_and_or_b32 v34, 0xffff, v34, v39                         // 000000450844: D6570022 049E44FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000450850: BF870112
	v_and_b32_e32 v130, 0xffff, v130                           // 000000450854: 370504FF 0000FFFF
	v_pk_fma_f16 v34, v34, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000045085C: CC0E0022 0BFC0B22 0000C931
	v_and_b32_e32 v132, 0xffff, v35                            // 000000450868: 370846FF 0000FFFF
	v_bfe_u32 v35, v35, 3, 16                                  // 000000450870: D6100023 02410723
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000450878: BF870194
	v_lshl_or_b32 v39, v131, 16, v130                          // 00000045087C: D6560027 06092183
	.long 0xd72c0084                                           // 000000450884: D72C0084
	v_cndmask_b32_e32 v1, 0x83dcd12d, v132, vcc_lo             // 000000450888: 020308FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000450890: BF870113
	.long 0xd72c0023                                           // 000000450894: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000450898: 020246FF 83DCD12D
	v_sad_u8 v132, v132, 0, 0x6400                             // 0000004508A0: D6220084 03FD0184 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004508AC: BF870112
	v_sad_u8 v35, v35, 0, 0x6400                               // 0000004508B0: D6220023 03FD0123 00006400
	v_lshlrev_b32_e32 v37, 16, v132                            // 0000004508BC: 304B0890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004508C0: BF870251
	v_and_or_b32 v31, 0xffff, v35, v37                         // 0000004508C4: D657001F 049646FF 0000FFFF
	v_pk_fma_f16 v35, v36, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004508D0: CC0E0023 0BFC0B24 0000C931
	v_lshlrev_b32_e32 v38, 16, v38                             // 0000004508DC: 304C4C90
	v_bfe_u32 v37, v30, 9, 16                                  // 0000004508E0: D6100025 0241131E
	v_pk_fma_f16 v36, v39, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004508E8: CC0E0024 0BFC0B27 0000C931
	v_dot2acc_f32_f16 v85, v35, v1                             // 0000004508F4: 04AA0323
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004508F8: BF8701A4
	v_and_or_b32 v38, 0xffff, v135, v38                        // 0000004508FC: D6570026 049B0EFF 0000FFFF
	v_dot2acc_f32_f16 v83, v35, v5                             // 000000450908: 04A60B23
	v_dot2acc_f32_f16 v85, v34, v2                             // 00000045090C: 04AA0522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000450910: BF870113
	v_pk_fma_f16 v38, v38, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450914: CC0E0026 0BFC0B26 0000C931
	v_dot2acc_f32_f16 v85, v36, v3                             // 000000450920: 04AA0724
	s_delay_alu instid0(VALU_DEP_2)                            // 000000450924: BF870002
	v_dot2acc_f32_f16 v89, v38, v4                             // 000000450928: 04B20926
	v_dot2acc_f32_f16 v88, v38, v8                             // 00000045092C: 04B01126
	v_pk_fma_f16 v38, v31, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450930: CC0E0026 0BFC0B1F 0000C931
	.long 0xd73d001f                                           // 00000045093C: D73D001F
	v_cndmask_b32_e32 v1, v95, v32, vcc_lo                     // 000000450940: 0202415F
	.long 0xd72c0020                                           // 000000450944: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000450948: 02024AFF 83DCD12D
	v_bfe_u32 v33, v30, 6, 16                                  // 000000450950: D6100021 02410D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000450958: BF870214
	v_dot2acc_f32_f16 v85, v38, v4                             // 00000045095C: 04AA0926
	v_bfe_u32 v130, v31, 6, 16                                 // 000000450960: D6100082 02410D1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000450968: BF870233
	.long 0xd72c0021                                           // 00000045096C: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000450970: 020242FF 83DCD12D
	v_bfe_u32 v131, v31, 3, 16                                 // 000000450978: D6100083 0241071F
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000450980: D6220020 03FD0120 00006400
	.long 0xd72c0082                                           // 00000045098C: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000450990: 020304FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000450998: BF8700A2
	v_and_b32_e32 v32, 0xffff, v32                             // 00000045099C: 364040FF 0000FFFF
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000004509A4: D6220021 03FD0121 00006400
	v_lshl_or_b32 v32, v33, 16, v32                            // 0000004509B0: D6560020 04812121
	.long 0xd72c0021                                           // 0000004509B8: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000004509BC: 020306FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004509C4: BF870232
	v_pk_fma_f16 v32, v32, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004509C8: CC0E0020 0BFC0B20 0000C931
	v_and_b32_e32 v39, 0xffff, v30                             // 0000004509D4: 364E3CFF 0000FFFF
	v_bfe_u32 v30, v30, 3, 16                                  // 0000004509DC: D610001E 0241071E
	v_sad_u8 v33, v33, 0, 0x6400                               // 0000004509E4: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004509F0: BF870214
	v_dot2acc_f32_f16 v84, v32, v5                             // 0000004509F4: 04A80B20
	.long 0xd72c0025                                           // 0000004509F8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 0000004509FC: 02024EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000450A04: BF8701C4
	.long 0xd72c001e                                           // 000000450A08: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000450A0C: 02023CFF 83DCD12D
	v_bfe_u32 v39, v31, 9, 16                                  // 000000450A14: D6100027 0241131F
	v_dot2acc_f32_f16 v86, v32, v1                             // 000000450A1C: 04AC0320
	v_bfe_u32 v32, v27, 9, 16                                  // 000000450A20: D6100020 0241131B
	.long 0xd72c0027                                           // 000000450A28: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000450A2C: 02024EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000450A34: D6220025 03FD0125 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000450A40: D622001E 03FD011E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000450A4C: BF870194
	.long 0xd72c0020                                           // 000000450A50: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000450A54: 020240FF 83DCD12D
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000450A5C: 304A4A90
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000450A60: D6220027 03FD0127 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000450A6C: BF870212
	v_and_or_b32 v30, 0xffff, v30, v37                         // 000000450A70: D657001E 04963CFF 0000FFFF
	v_sad_u8 v32, v32, 0, 0x6400                               // 000000450A7C: D6220020 03FD0120 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000450A88: BF870002
	v_pk_fma_f16 v30, v30, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450A8C: CC0E001E 0BFC0B1E 0000C931
	v_and_b32_e32 v31, 0xffff, v31                             // 000000450A98: 363E3EFF 0000FFFF
	v_and_b32_e32 v37, 0xffff, v39                             // 000000450AA0: 364A4EFF 0000FFFF
	v_sad_u8 v39, v130, 0, 0x6400                              // 000000450AA8: D6220027 03FD0182 00006400
	v_and_b32_e32 v32, 0xffff, v32                             // 000000450AB4: 364040FF 0000FFFF
	v_dot2acc_f32_f16 v86, v30, v2                             // 000000450ABC: 04AC051E
	.long 0xd72c001f                                           // 000000450AC0: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000450AC4: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v84, v30, v6                             // 000000450ACC: 04A80D1E
	v_lshl_or_b32 v35, v39, 16, v37                            // 000000450AD0: D6560023 04952127
	v_bfe_u32 v30, v26, 9, 16                                  // 000000450AD8: D610001E 0241131A
	v_mov_b32_e32 v37, v62                                     // 000000450AE0: 7E4A033E
	s_waitcnt vmcnt(13)                                        // 000000450AE4: BF8937F7
	v_dual_mov_b32 v62, v114 :: v_dual_mov_b32 v39, v65        // 000000450AE8: CA100172 3E260141
	v_mov_b32_e32 v65, v116                                    // 000000450AF0: 7E820374
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000450AF4: D622001F 03FD011F 00006400
	.long 0xd72c001c                                           // 000000450B00: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000450B04: 02023CFF 83DCD12D
	v_and_b32_e32 v30, 0xffff, v26                             // 000000450B0C: 363C34FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 000000450B14: D610001A 0241071A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000450B1C: BF870194
	v_lshlrev_b32_e32 v31, 16, v31                             // 000000450B20: 303E3E90
	.long 0xd72c001e                                           // 000000450B24: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 000000450B28: 02023CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000450B30: BF870223
	.long 0xd72c001a                                           // 000000450B34: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000450B38: 020234FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 000000450B40: D622001C 03FD011C 00006400
	v_and_or_b32 v31, 0xffff, v33, v31                         // 000000450B4C: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v27, 6, 16                                  // 000000450B58: D6100021 02410D1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000450B60: BF870193
	v_and_b32_e32 v28, 0xffff, v28                             // 000000450B64: 363838FF 0000FFFF
	v_pk_fma_f16 v31, v31, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450B6C: CC0E001F 0BFC0B1F 0000C931
	v_dot2acc_f32_f16 v83, v34, v6                             // 000000450B78: 04A60D22
	v_pk_fma_f16 v34, v35, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450B7C: CC0E0022 0BFC0B23 0000C931
	.long 0xd72c0021                                           // 000000450B88: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000450B8C: 020242FF 83DCD12D
	v_sad_u8 v30, v30, 0, 0x6400                               // 000000450B94: D622001E 03FD011E 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 000000450BA0: D622001A 03FD011A 00006400
	v_lshl_or_b32 v28, v29, 16, v28                            // 000000450BAC: D656001C 0471211D
	v_dot2acc_f32_f16 v86, v34, v3                             // 000000450BB4: 04AC0722
	v_dot2acc_f32_f16 v84, v34, v7                             // 000000450BB8: 04A80F22
	v_and_b32_e32 v34, 0xffff, v27                             // 000000450BBC: 364436FF 0000FFFF
	v_bfe_u32 v27, v27, 3, 16                                  // 000000450BC4: D610001B 0241071B
	v_lshlrev_b32_e32 v30, 16, v30                             // 000000450BCC: 303C3C90
	v_dual_dot2acc_f32_f16 v86, v31, v4 :: v_dual_dot2acc_f32_f16 v83, v36, v7// 000000450BD0: CB18091F 56520F24
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000450BD8: BF870214
	.long 0xd72c0022                                           // 000000450BDC: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 000000450BE0: 020244FF 83DCD12D
	.long 0xd72c001b                                           // 000000450BE8: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 000000450BEC: 020236FF 83DCD12D
	v_sad_u8 v33, v33, 0, 0x6400                               // 000000450BF4: D6220021 03FD0121 00006400
	v_and_or_b32 v26, 0xffff, v26, v30                         // 000000450C00: D657001A 047A34FF 0000FFFF
	v_dual_dot2acc_f32_f16 v83, v38, v8 :: v_dual_mov_b32 v36, v69// 000000450C0C: CB101126 53240145
	v_mov_b32_e32 v38, v70                                     // 000000450C14: 7E4C0346
	s_delay_alu instid0(VALU_DEP_4)                            // 000000450C18: BF870004
	v_lshl_or_b32 v30, v33, 16, v32                            // 000000450C1C: D656001E 04812121
	v_sad_u8 v34, v34, 0, 0x6400                               // 000000450C24: D6220022 03FD0122 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 000000450C30: D622001B 03FD011B 00006400
	v_pk_fma_f16 v26, v26, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450C3C: CC0E001A 0BFC0B1A 0000C931
	s_waitcnt vmcnt(5)                                         // 000000450C48: BF8917F7
	v_dual_mov_b32 v70, v120 :: v_dual_mov_b32 v69, v119       // 000000450C4C: CA100178 46440177
	v_dual_dot2acc_f32_f16 v84, v31, v8 :: v_dual_lshlrev_b32 v29, 16, v34// 000000450C54: CB22111F 541C4490
	v_dual_mov_b32 v34, v56 :: v_dual_and_b32 v31, 0xffff, v18 // 000000450C5C: CA240138 221E24FF 0000FFFF
	v_mov_b32_e32 v56, v108                                    // 000000450C68: 7E70036C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000450C6C: BF870003
	v_and_or_b32 v19, 0xffff, v27, v29                         // 000000450C70: D6570013 047636FF 0000FFFF
	v_pk_fma_f16 v27, v28, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450C7C: CC0E001B 0BFC0B1C 0000C931
	v_pk_fma_f16 v28, v30, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450C88: CC0E001C 0BFC0B1E 0000C931
	v_bfe_u32 v29, v18, 9, 16                                  // 000000450C94: D610001D 02411312
	v_mov_b32_e32 v35, v47                                     // 000000450C9C: 7E46032F
	v_pk_fma_f16 v30, v19, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450CA0: CC0E001E 0BFC0B13 0000C931
	.long 0xd73d0013                                           // 000000450CAC: D73D0013
	v_cndmask_b32_e32 v1, v95, v20, vcc_lo                     // 000000450CB0: 0202295F
	v_bfe_u32 v21, v18, 6, 16                                  // 000000450CB4: D6100015 02410D12
	.long 0xd72c0014                                           // 000000450CBC: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 000000450CC0: 02023AFF 83DCD12D
	v_bfe_u32 v18, v18, 3, 16                                  // 000000450CC8: D6100012 02410712
	.long 0xd72c001d                                           // 000000450CD0: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000450CD4: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v80, v27, v1                             // 000000450CDC: 04A0031B
	v_bfe_u32 v31, v19, 9, 16                                  // 000000450CE0: D610001F 02411313
	v_bfe_u32 v32, v19, 6, 16                                  // 000000450CE8: D6100020 02410D13
	.long 0xd72c0012                                           // 000000450CF0: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000450CF4: 020224FF 83DCD12D
	v_bfe_u32 v33, v19, 3, 16                                  // 000000450CFC: D6100021 02410713
	v_dual_dot2acc_f32_f16 v80, v26, v2 :: v_dual_and_b32 v19, 0xffff, v19// 000000450D04: CB24051A 501226FF 0000FFFF
	.long 0xd72c001f                                           // 000000450D10: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 000000450D14: 02023EFF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 000000450D1C: D622001D 03FD011D 00006400
	.long 0xd72c0020                                           // 000000450D28: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 000000450D2C: 020240FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000450D34: BF870224
	.long 0xd72c0013                                           // 000000450D38: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000450D3C: 020226FF 83DCD12D
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000450D44: D6220012 03FD0112 00006400
	v_dual_dot2acc_f32_f16 v80, v28, v3 :: v_dual_lshlrev_b32 v29, 16, v29// 000000450D50: CB22071C 501C3A90
	.long 0xd72c0015                                           // 000000450D58: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000450D5C: 02022AFF 83DCD12D
	v_sad_u8 v31, v31, 0, 0x6400                               // 000000450D64: D622001F 03FD011F 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000450D70: D6220014 03FD0114 00006400
	v_dot2acc_f32_f16 v82, v27, v5                             // 000000450D7C: 04A40B1B
	v_and_or_b32 v18, 0xffff, v18, v29                         // 000000450D80: D6570012 047624FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000450D8C: D6220013 03FD0113 00006400
	v_and_b32_e32 v29, 0xffff, v31                             // 000000450D98: 363A3EFF 0000FFFF
	v_sad_u8 v31, v32, 0, 0x6400                               // 000000450DA0: D622001F 03FD0120 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000450DAC: D6220015 03FD0115 00006400
	v_pk_fma_f16 v27, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450DB8: CC0E001B 0BFC0B12 0000C931
	v_dual_dot2acc_f32_f16 v82, v26, v6 :: v_dual_lshlrev_b32 v19, 16, v19// 000000450DC4: CB220D1A 52122690
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000450DCC: BF8701B4
	v_lshl_or_b32 v18, v31, 16, v29                            // 000000450DD0: D6560012 0475211F
	v_dual_dot2acc_f32_f16 v80, v30, v4 :: v_dual_mov_b32 v29, v57// 000000450DD8: CB10091E 501C0139
	v_dual_mov_b32 v32, v67 :: v_dual_mov_b32 v31, v46         // 000000450DE0: CA100143 201E012E
	v_pk_fma_f16 v26, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450DE8: CC0E001A 0BFC0B12 0000C931
	v_dual_mov_b32 v57, v109 :: v_dual_and_b32 v20, 0xffff, v20// 000000450DF4: CA24016D 391428FF 0000FFFF
	s_waitcnt vmcnt(4)                                         // 000000450E00: BF8913F7
	v_dual_mov_b32 v67, v117 :: v_dual_mov_b32 v46, v100       // 000000450E04: CA100175 432E0164
	v_mov_b32_e32 v47, v101                                    // 000000450E0C: 7E5E0365
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000450E10: BF870243
	v_lshl_or_b32 v20, v21, 16, v20                            // 000000450E14: D6560014 04512115
	.long 0xd72c0015                                           // 000000450E1C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 000000450E20: 020242FF 83DCD12D
	v_mov_b32_e32 v33, v59                                     // 000000450E28: 7E42033B
	v_mov_b32_e32 v59, v111                                    // 000000450E2C: 7E76036F
	v_pk_fma_f16 v20, v20, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450E30: CC0E0014 0BFC0B14 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000450E3C: BF870114
	v_sad_u8 v21, v21, 0, 0x6400                               // 000000450E40: D6220015 03FD0115 00006400
	v_dot2acc_f32_f16 v81, v20, v1                             // 000000450E4C: 04A20314
	v_dot2acc_f32_f16 v79, v20, v5                             // 000000450E50: 049E0B14
	v_dot2acc_f32_f16 v82, v28, v7                             // 000000450E54: 04A40F1C
	v_mov_b32_e32 v28, v63                                     // 000000450E58: 7E38033F
	v_and_or_b32 v21, 0xffff, v21, v19                         // 000000450E5C: D6570015 044E2AFF 0000FFFF
	.long 0xd73d0012                                           // 000000450E68: D73D0012
	v_cndmask_b32_e32 v1, v93, v22, vcc_lo                     // 000000450E6C: 02022D5D
	v_dot2acc_f32_f16 v81, v27, v2                             // 000000450E70: 04A2051B
	.long 0xd73d0013                                           // 000000450E74: D73D0013
	v_cndmask_b32_e32 v1, v95, v24, vcc_lo                     // 000000450E78: 0202315F
	v_dot2acc_f32_f16 v79, v27, v6                             // 000000450E7C: 049E0D1B
	v_pk_fma_f16 v21, v21, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450E80: CC0E0015 0BFC0B15 0000C931
	v_mov_b32_e32 v27, v45                                     // 000000450E8C: 7E36032D
	v_bfe_u32 v22, v18, 9, 16                                  // 000000450E90: D6100016 02411312
	v_dot2acc_f32_f16 v81, v26, v3                             // 000000450E98: 04A2071A
	v_bfe_u32 v23, v18, 3, 16                                  // 000000450E9C: D6100017 02410712
	v_bfe_u32 v24, v19, 9, 16                                  // 000000450EA4: D6100018 02411313
	v_bfe_u32 v25, v19, 6, 16                                  // 000000450EAC: D6100019 02410D13
	.long 0xd72c0014                                           // 000000450EB4: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000450EB8: 02022CFF 83DCD12D
	v_bfe_u32 v22, v18, 6, 16                                  // 000000450EC0: D6100016 02410D12
	v_dual_dot2acc_f32_f16 v81, v21, v4 :: v_dual_and_b32 v18, 0xffff, v18// 000000450EC8: CB240915 511224FF 0000FFFF
	.long 0xd72c0017                                           // 000000450ED4: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 000000450ED8: 02022EFF 83DCD12D
	.long 0xd72c0018                                           // 000000450EE0: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000450EE4: 020230FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000450EEC: BF870004
	.long 0xd72c0016                                           // 000000450EF0: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 000000450EF4: 02022CFF 83DCD12D
	.long 0xd72c0019                                           // 000000450EFC: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 000000450F00: 020232FF 83DCD12D
	v_sad_u8 v20, v20, 0, 0x6400                               // 000000450F08: D6220014 03FD0114 00006400
	.long 0xd72c0012                                           // 000000450F14: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 000000450F18: 020224FF 83DCD12D
	v_dot2acc_f32_f16 v79, v26, v7                             // 000000450F20: 049E0F1A
	s_waitcnt vmcnt(3)                                         // 000000450F24: BF890FF7
	v_mov_b32_e32 v63, v115                                    // 000000450F28: 7E7E0373
	v_dual_mov_b32 v45, v99 :: v_dual_and_b32 v20, 0xffff, v20 // 000000450F2C: CA240163 2D1428FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000450F38: D6220016 03FD0116 00006400
	v_dual_dot2acc_f32_f16 v79, v21, v8 :: v_dual_and_b32 v26, 0xffff, v19// 000000450F44: CB241115 4F1A26FF 0000FFFF
	v_sad_u8 v18, v18, 0, 0x6400                               // 000000450F50: D6220012 03FD0112 00006400
	v_bfe_u32 v21, v12, 9, 16                                  // 000000450F5C: D6100015 0241130C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000450F64: BF870004
	v_lshl_or_b32 v20, v22, 16, v20                            // 000000450F68: D6560014 04512116
	v_sad_u8 v22, v23, 0, 0x6400                               // 000000450F70: D6220016 03FD0117 00006400
	v_bfe_u32 v19, v19, 3, 16                                  // 000000450F7C: D6100013 02410713
	.long 0xd72c001a                                           // 000000450F84: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 000000450F88: 020234FF 83DCD12D
	.long 0xd72c0011                                           // 000000450F90: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000450F94: 02022AFF 83DCD12D
	v_pk_fma_f16 v20, v20, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000450F9C: CC0E0014 0BFC0B14 0000C931
	v_lshlrev_b32_e32 v18, 16, v18                             // 000000450FA8: 30242490
	v_bfe_u32 v21, v12, 6, 16                                  // 000000450FAC: D6100015 02410D0C
	v_sad_u8 v24, v24, 0, 0x6400                               // 000000450FB4: D6220018 03FD0118 00006400
	.long 0xd72c0013                                           // 000000450FC0: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 000000450FC4: 020226FF 83DCD12D
	v_dot2acc_f32_f16 v77, v20, v5                             // 000000450FCC: 049A0B14
	v_and_or_b32 v18, 0xffff, v22, v18                         // 000000450FD0: D6570012 044A2CFF 0000FFFF
	.long 0xd72c0015                                           // 000000450FDC: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 000000450FE0: 02022AFF 83DCD12D
	v_sad_u8 v17, v17, 0, 0x6400                               // 000000450FE8: D6220011 03FD0111 00006400
	v_sad_u8 v23, v26, 0, 0x6400                               // 000000450FF4: D6220017 03FD011A 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 000000451000: D6220019 03FD0119 00006400
	v_pk_fma_f16 v18, v18, s5, 0xc931 op_sel_hi:[1,0,0]        // 00000045100C: CC0E0012 0BFC0B12 0000C931
	v_dot2acc_f32_f16 v78, v20, v1                             // 000000451018: 049C0314
	v_dual_dot2acc_f32_f16 v82, v30, v8 :: v_dual_and_b32 v17, 0xffff, v17// 00000045101C: CB24111E 521022FF 0000FFFF
	v_lshlrev_b32_e32 v23, 16, v23                             // 000000451028: 302E2E90
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000045102C: D6220015 03FD0115 00006400
	v_dot2acc_f32_f16 v77, v18, v6                             // 000000451038: 049A0D12
	v_dot2acc_f32_f16 v78, v18, v2                             // 00000045103C: 049C0512
	v_sad_u8 v19, v19, 0, 0x6400                               // 000000451040: D6220013 03FD0113 00006400
	v_mov_b32_e32 v18, v51                                     // 00000045104C: 7E240333
	v_lshl_or_b32 v17, v21, 16, v17                            // 000000451050: D6560011 04452115
	v_mov_b32_e32 v26, v53                                     // 000000451058: 7E340335
	v_mov_b32_e32 v30, v54                                     // 00000045105C: 7E3C0336
	v_and_or_b32 v13, 0xffff, v19, v23                         // 000000451060: D657000D 045E26FF 0000FFFF
	v_bfe_u32 v23, v16, 9, 16                                  // 00000045106C: D6100017 02411310
	v_pk_fma_f16 v17, v17, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000451074: CC0E0011 0BFC0B11 0000C931
	v_dual_mov_b32 v51, v104 :: v_dual_and_b32 v24, 0xffff, v24// 000000451080: CA240168 331830FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045108C: BF870214
	v_pk_fma_f16 v13, v13, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000451090: CC0E000D 0BFC0B0D 0000C931
	.long 0xd72c0017                                           // 00000045109C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 0000004510A0: 02022EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004510A8: BF870214
	v_dot2acc_f32_f16 v9, v17, v5                              // 0000004510AC: 04120B11
	v_lshl_or_b32 v22, v25, 16, v24                            // 0000004510B0: D6560016 04612119
	v_bfe_u32 v24, v16, 6, 16                                  // 0000004510B8: D6100018 02410D10
	v_bfe_u32 v25, v16, 3, 16                                  // 0000004510C0: D6100019 02410710
	v_dual_mov_b32 v53, v105 :: v_dual_mov_b32 v54, v106       // 0000004510C8: CA100169 3536016A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004510D0: BF870004
	v_pk_fma_f16 v19, v22, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004510D4: CC0E0013 0BFC0B16 0000C931
	v_and_b32_e32 v22, 0xffff, v12                             // 0000004510E0: 362C18FF 0000FFFF
	v_bfe_u32 v12, v12, 3, 16                                  // 0000004510E8: D610000C 0241070C
	v_and_b32_e32 v16, 0xffff, v16                             // 0000004510F0: 362020FF 0000FFFF
	.long 0xd72c0015                                           // 0000004510F8: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 0000004510FC: 020232FF 83DCD12D
	v_dot2acc_f32_f16 v77, v19, v7                             // 000000451104: 049A0F13
	.long 0xd72c0016                                           // 000000451108: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000045110C: 02022CFF 83DCD12D
	.long 0xd72c000c                                           // 000000451114: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 000000451118: 020218FF 83DCD12D
	.long 0xd72c0010                                           // 000000451120: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 000000451124: 020220FF 83DCD12D
	.long 0xd72c0018                                           // 00000045112C: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 000000451130: 020230FF 83DCD12D
	v_sad_u8 v23, v23, 0, 0x6400                               // 000000451138: D6220017 03FD0117 00006400
	v_dual_dot2acc_f32_f16 v78, v19, v3 :: v_dual_dot2acc_f32_f16 v77, v13, v8// 000000451144: CB180713 4E4C110D
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000045114C: D6220015 03FD0115 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 000000451158: D6220016 03FD0116 00006400
	v_sad_u8 v12, v12, 0, 0x6400                               // 000000451164: D622000C 03FD010C 00006400
	v_sad_u8 v16, v16, 0, 0x6400                               // 000000451170: D6220010 03FD0110 00006400
	v_dual_mov_b32 v19, v44 :: v_dual_dot2acc_f32_f16 v76, v17, v1// 00000045117C: CA18012C 134C0311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000451184: BF870224
	v_lshlrev_b32_e32 v22, 16, v22                             // 000000451188: 302C2C90
	v_dot2acc_f32_f16 v78, v13, v4                             // 00000045118C: 049C090D
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000451190: 30202090
	v_dual_mov_b32 v44, v98 :: v_dual_mov_b32 v25, v127        // 000000451194: CA100162 2C18017F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000045119C: BF870224
	v_and_or_b32 v12, 0xffff, v12, v22                         // 0000004511A0: D657000C 045A18FF 0000FFFF
	v_mov_b32_e32 v13, v125                                    // 0000004511AC: 7E1A037D
	v_and_or_b32 v5, 0xffff, v21, v16                          // 0000004511B0: D6570005 04422AFF 0000FFFF
	v_mov_b32_e32 v21, v55                                     // 0000004511BC: 7E2A0337
	v_mov_b32_e32 v55, v107                                    // 0000004511C0: 7E6E036B
	v_pk_fma_f16 v12, v12, s5, 0xc931 op_sel_hi:[1,0,0]        // 0000004511C4: CC0E000C 0BFC0B0C 0000C931
	v_dual_mov_b32 v17, v123 :: v_dual_mov_b32 v16, v122       // 0000004511D0: CA10017B 1110017A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004511D8: BF870002
	v_dot2acc_f32_f16 v76, v12, v2                             // 0000004511DC: 0498050C
	v_pk_fma_f16 v2, v5, s5, 0xc931 op_sel_hi:[1,0,0]          // 0000004511E0: CC0E0002 0BFC0B05 0000C931
	v_and_b32_e32 v22, 0xffff, v23                             // 0000004511EC: 362C2EFF 0000FFFF
	v_sad_u8 v23, v24, 0, 0x6400                               // 0000004511F4: D6220017 03FD0118 00006400
	v_dot2acc_f32_f16 v9, v12, v6                              // 000000451200: 04120D0C
	v_dual_mov_b32 v5, v58 :: v_dual_mov_b32 v6, v48           // 000000451204: CA10013A 05060130
	v_mov_b32_e32 v58, v110                                    // 00000045120C: 7E74036E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000451210: BF870244
	v_lshl_or_b32 v20, v23, 16, v22                            // 000000451214: D6560014 04592117
	v_dual_mov_b32 v48, v102 :: v_dual_mov_b32 v23, v129       // 00000045121C: CA100166 30160181
	v_mov_b32_e32 v22, v128                                    // 000000451224: 7E2C0380
	v_mov_b32_e32 v24, v126                                    // 000000451228: 7E30037E
	v_pk_fma_f16 v1, v20, s5, 0xc931 op_sel_hi:[1,0,0]         // 00000045122C: CC0E0001 0BFC0B14 0000C931
	v_mov_b32_e32 v20, v60                                     // 000000451238: 7E28033C
	s_waitcnt vmcnt(2)                                         // 00000045123C: BF890BF7
	v_mov_b32_e32 v60, v112                                    // 000000451240: 7E780370
	v_mov_b32_e32 v12, v124                                    // 000000451244: 7E18037C
	v_dot2acc_f32_f16 v76, v1, v3                              // 000000451248: 04980701
	v_dot2acc_f32_f16 v9, v1, v7                               // 00000045124C: 04120F01
	v_add_nc_u32_e32 v1, v91, v92                              // 000000451250: 4A02B95B
	v_mov_b32_e32 v3, v71                                      // 000000451254: 7E060347
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000451258: BF870214
	v_dual_mov_b32 v71, v121 :: v_dual_dot2acc_f32_f16 v76, v2, v4// 00000045125C: CA180179 474C0902
	v_dot2acc_f32_f16 v9, v2, v8                               // 000000451264: 04121102
	s_delay_alu instid0(VALU_DEP_4)                            // 000000451268: BF870004
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 00000045126C: 7C940282
	v_dual_mov_b32 v4, v68 :: v_dual_mov_b32 v1, v61           // 000000451270: CA100144 0400013D
	v_mov_b32_e32 v2, v49                                      // 000000451278: 7E040331
	v_dual_mov_b32 v68, v118 :: v_dual_mov_b32 v61, v113       // 00000045127C: CA100176 443C0171
	v_mov_b32_e32 v49, v103                                    // 000000451284: 7E620367
	s_or_b32 s0, vcc_lo, s0                                    // 000000451288: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045128C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 000000451290: 917E007E
	s_cbranch_execz 102                                        // 000000451294: BFA50066 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f30>
	s_waitcnt vmcnt(1)                                         // 000000451298: BF8907F7
	v_dual_mov_b32 v129, v50 :: v_dual_mov_b32 v126, v75       // 00000045129C: CA100132 817E014B
	v_dual_mov_b32 v128, v66 :: v_dual_mov_b32 v127, v73       // 0000004512A4: CA100142 807E0149
	s_waitcnt vmcnt(0)                                         // 0000004512AC: BF8903F7
	v_dual_mov_b32 v125, v52 :: v_dual_mov_b32 v122, v74       // 0000004512B0: CA100134 7D7A014A
	v_mov_b32_e32 v124, v64                                    // 0000004512B8: 7EF80340
	v_mov_b32_e32 v123, v72                                    // 0000004512BC: 7EF60348
	s_mov_b32 s8, exec_lo                                      // 0000004512C0: BE88007E
	.long 0xd4c1007e                                           // 0000004512C4: D4C1007E
	v_cndmask_b32_e32 v1, v92, v43, vcc_lo                     // 0000004512C8: 0202575C
	s_cbranch_execz 64563                                      // 0000004512CC: BFA5FC33 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe9c>
	v_mad_i64_i32 v[7:8], null, 0x300, v92, s[6:7]             // 0000004512D0: D6FF7C07 001AB8FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004512DC: BF870091
	.long 0xd7006a48                                           // 0000004512E0: D7006A48
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000004512E4: 02021507
	v_add_co_ci_u32_e64 v73, null, v8, v11, vcc_lo             // 0000004512E8: D5207C49 01AA1708
	.long 0xd7006a4a                                           // 0000004512F0: D7006A4A
	v_cndmask_b32_e32 v1, v7, v96, vcc_lo                      // 0000004512F4: 0202C107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004512F8: BF8700A1
	v_add_co_ci_u32_e64 v75, null, 0, v8, vcc_lo               // 0000004512FC: D5207C4B 01AA1080
	.long 0xd7006a77                                           // 000000451304: D7006A77
	v_cndmask_b32_e32 v1, v7, v14, vcc_lo                      // 000000451308: 02021D07
	v_add_co_ci_u32_e64 v120, null, v8, v15, vcc_lo            // 00000045130C: D5207C78 01AA1F08
	.long 0xd7006a07                                           // 000000451314: D7006A07
	v_cndmask_b32_e32 v1, v7, v97, vcc_lo                      // 000000451318: 0202C307
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045131C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 000000451320: D5207C08 01AA1080
	s_clause 0x1f                                              // 000000451328: BF85001F
	global_load_b32 v103, v[72:73], off                        // 00000045132C: DC520000 677C0048
	global_load_b32 v102, v[72:73], off offset:96              // 000000451334: DC520060 667C0048
	global_load_b32 v101, v[72:73], off offset:192             // 00000045133C: DC5200C0 657C0048
	global_load_b32 v100, v[72:73], off offset:288             // 000000451344: DC520120 647C0048
	global_load_b32 v99, v[72:73], off offset:384              // 00000045134C: DC520180 637C0048
	global_load_b32 v98, v[72:73], off offset:480              // 000000451354: DC5201E0 627C0048
	global_load_b32 v50, v[72:73], off offset:576              // 00000045135C: DC520240 327C0048
	global_load_b32 v52, v[72:73], off offset:672              // 000000451364: DC5202A0 347C0048
	global_load_b32 v113, v[74:75], off                        // 00000045136C: DC520000 717C004A
	global_load_b32 v110, v[74:75], off offset:96              // 000000451374: DC520060 6E7C004A
	global_load_b32 v108, v[74:75], off offset:192             // 00000045137C: DC5200C0 6C7C004A
	global_load_b32 v106, v[74:75], off offset:288             // 000000451384: DC520120 6A7C004A
	global_load_b32 v105, v[74:75], off offset:384             // 00000045138C: DC520180 697C004A
	global_load_b32 v104, v[74:75], off offset:480             // 000000451394: DC5201E0 687C004A
	global_load_b32 v66, v[74:75], off offset:576              // 00000045139C: DC520240 427C004A
	global_load_b32 v64, v[74:75], off offset:672              // 0000004513A4: DC5202A0 407C004A
	global_load_b32 v118, v[119:120], off                      // 0000004513AC: DC520000 767C0077
	global_load_b32 v116, v[119:120], off offset:96            // 0000004513B4: DC520060 747C0077
	global_load_b32 v114, v[119:120], off offset:192           // 0000004513BC: DC5200C0 727C0077
	global_load_b32 v111, v[119:120], off offset:288           // 0000004513C4: DC520120 6F7C0077
	global_load_b32 v109, v[119:120], off offset:384           // 0000004513CC: DC520180 6D7C0077
	global_load_b32 v107, v[119:120], off offset:480           // 0000004513D4: DC5201E0 6B7C0077
	global_load_b32 v73, v[119:120], off offset:576            // 0000004513DC: DC520240 497C0077
	global_load_b32 v72, v[119:120], off offset:672            // 0000004513E4: DC5202A0 487C0077
	global_load_b32 v121, v[7:8], off                          // 0000004513EC: DC520000 797C0007
	global_load_b32 v120, v[7:8], off offset:96                // 0000004513F4: DC520060 787C0007
	global_load_b32 v119, v[7:8], off offset:192               // 0000004513FC: DC5200C0 777C0007
	global_load_b32 v117, v[7:8], off offset:288               // 000000451404: DC520120 757C0007
	global_load_b32 v115, v[7:8], off offset:384               // 00000045140C: DC520180 737C0007
	global_load_b32 v112, v[7:8], off offset:480               // 000000451414: DC5201E0 707C0007
	global_load_b32 v75, v[7:8], off offset:576                // 00000045141C: DC520240 4B7C0007
	global_load_b32 v74, v[7:8], off offset:672                // 000000451424: DC5202A0 4A7C0007
	s_branch 64475                                             // 00000045142C: BFA0FBDB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xe9c>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000451430: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000451434: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000451438: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 00000045143C: BF895FF7
	v_dual_mov_b32 v1, v90 :: v_dual_mov_b32 v2, v87           // 000000451440: CA10015A 01020157
	s_waitcnt vmcnt(7)                                         // 000000451448: BF891FF7
	v_dual_mov_b32 v3, v89 :: v_dual_mov_b32 v6, v88           // 00000045144C: CA100159 03060158
	v_dual_mov_b32 v4, v85 :: v_dual_mov_b32 v5, v83           // 000000451454: CA100155 04040153
	v_dual_mov_b32 v8, v86 :: v_dual_mov_b32 v7, v80           // 00000045145C: CA100156 08060150
	v_dual_mov_b32 v10, v84 :: v_dual_mov_b32 v11, v82         // 000000451464: CA100154 0A0A0152
	v_dual_mov_b32 v12, v81 :: v_dual_mov_b32 v13, v79         // 00000045146C: CA100151 0C0C014F
	v_dual_mov_b32 v14, v78 :: v_dual_mov_b32 v15, v77         // 000000451474: CA10014E 0E0E014D
	s_waitcnt vmcnt(0)                                         // 00000045147C: BF8903F7
	v_dual_mov_b32 v16, v76 :: v_dual_mov_b32 v17, v9          // 000000451480: CA10014C 10100109
	s_mov_b32 s0, 0x76543210                                   // 000000451488: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000451490: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000451494: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000004514A0: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000004514AC: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000004514B8: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000004514C4: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000004514D0: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 0000004514DC: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000004514E8: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 0000004514F4: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000451500: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000045150C: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000451518: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000451524: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 000000451530: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000045153C: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 000000451548: D65C0011 03FC0111 FEDCBA98
	.long 0xd44c0000                                           // 000000451554: D44C0000
	v_cndmask_b32_e32 v1, 16, v42, vcc_lo                      // 000000451558: 02025490
	s_barrier                                                  // 00000045155C: BFBD0000
	buffer_gl0_inv                                             // 000000451560: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000451568: BE812000
	s_cbranch_execz 34                                         // 00000045156C: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20f8>
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v16, v76, v16 // 000000451570: C9082309 0910214C
	v_dual_add_f32 v8, v86, v8 :: v_dual_add_f32 v3, v89, v3   // 000000451578: C9081156 08020759
	v_dual_add_f32 v6, v88, v6 :: v_dual_add_f32 v1, v90, v1   // 000000451580: C9080D58 0600035A
	v_lshl_or_b32 v17, v40, 10, v41                            // 000000451588: D6560011 04A51528
	v_dual_add_f32 v2, v87, v2 :: v_dual_add_f32 v7, v80, v7   // 000000451590: C9080557 02060F50
	v_dual_add_f32 v4, v85, v4 :: v_dual_add_f32 v5, v83, v5   // 000000451598: C9080955 04040B53
	v_dual_add_f32 v11, v82, v11 :: v_dual_add_f32 v10, v84, v10// 0000004515A0: C9081752 0B0A1554
	v_dual_add_f32 v13, v79, v13 :: v_dual_add_f32 v12, v81, v12// 0000004515A8: C9081B4F 0D0C1951
	v_dual_add_f32 v15, v77, v15 :: v_dual_add_f32 v14, v78, v14// 0000004515B0: C9081F4D 0F0E1D4E
	ds_store_2addr_b32 v17, v1, v3 offset1:16                  // 0000004515B8: D8381000 00030111
	ds_store_2addr_b32 v17, v2, v6 offset0:128 offset1:144     // 0000004515C0: D8389080 00060211
	ds_store_2addr_b32 v17, v4, v8 offset0:32 offset1:48       // 0000004515C8: D8383020 00080411
	ds_store_2addr_b32 v17, v5, v10 offset0:160 offset1:176    // 0000004515D0: D838B0A0 000A0511
	ds_store_2addr_b32 v17, v7, v12 offset0:64 offset1:80      // 0000004515D8: D8385040 000C0711
	ds_store_2addr_b32 v17, v11, v13 offset0:192 offset1:208   // 0000004515E0: D838D0C0 000D0B11
	ds_store_2addr_b32 v17, v14, v16 offset0:96 offset1:112    // 0000004515E8: D8387060 00100E11
	ds_store_2addr_b32 v17, v15, v9 offset0:224 offset1:240    // 0000004515F0: D838F0E0 00090F11
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004515F8: 8C7E017E
	.long 0xd44c0001                                           // 0000004515FC: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 000000451600: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000451608: BF89FC07
	s_barrier                                                  // 00000045160C: BFBD0000
	buffer_gl0_inv                                             // 000000451610: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000451618: BE852001
	s_cbranch_execnz 9                                         // 00000045161C: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2144>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000451620: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 000000451624: BF04821B
	s_mov_b32 s5, -1                                           // 000000451628: BE8500C1
	s_cbranch_scc0 35                                          // 00000045162C: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21bc>
	s_and_b32 vcc_lo, exec_lo, s5                              // 000000451630: 8B6A057E
	s_cbranch_vccnz 198                                        // 000000451634: BFA400C6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2450>
	s_nop 0                                                    // 000000451638: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000045163C: BFB60003
	s_endpgm                                                   // 000000451640: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 000000451644: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 000000451648: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 000000451650: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 000000451658: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000451660: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000451664: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000451668: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000045166C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000451670: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 000000451674: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 000000451678: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 000000451680: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000451684: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451688: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000045168C: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 000000451690: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000451694: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451698: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000045169C: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000004516A0: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 0000004516A4: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004516AC: 8C7E057E
	s_cmp_lt_i32 s27, 2                                        // 0000004516B0: BF04821B
	s_mov_b32 s5, -1                                           // 0000004516B4: BE8500C1
	s_cbranch_scc1 65501                                       // 0000004516B8: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2130>
	s_waitcnt lgkmcnt(0)                                       // 0000004516BC: BF89FC07
	s_barrier                                                  // 0000004516C0: BFBD0000
	buffer_gl0_inv                                             // 0000004516C4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 0000004516CC: BE852001
	s_cbranch_execz 41                                         // 0000004516D0: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2278>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004516D4: 32020087
	s_ashr_i32 s6, s26, 31                                     // 0000004516D8: 86069F1A
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000004516DC: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004516E0: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 0000004516E4: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 0000004516EC: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 0000004516F0: D8D82000 04000004
	s_mul_i32 s4, s4, s26                                      // 0000004516F8: 96041A04
	.long 0xd72c0003                                           // 0000004516FC: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000451700: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 000000451704: D6FE7C01 02003501
	s_lshl_b32 s6, s2, 7                                       // 00000045170C: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000451710: BF870499
	s_ashr_i32 s7, s6, 31                                      // 000000451714: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000451718: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 00000045171C: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000451724: 360600FF 0000007F
	s_add_u32 s4, s16, s6                                      // 00000045172C: 80040610
	s_addc_u32 s6, s17, s7                                     // 000000451730: 82060711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000451734: BF870112
	.long 0xd73c0001                                           // 000000451738: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000045173C: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000451740: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451744: BF870092
	.long 0xd7006a01                                           // 000000451748: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000045174C: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 000000451750: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451758: BF870092
	.long 0xd7006a01                                           // 00000045175C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000451760: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000451764: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 00000045176C: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 000000451770: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 000000451778: 8C7E057E
	.long 0xd44a0004                                           // 00000045177C: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000451780: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 000000451784: BC7C0000
	buffer_gl1_inv                                             // 000000451788: E0B00000 00000000
	buffer_gl0_inv                                             // 000000451790: E0AC0000 00000000
	s_barrier                                                  // 000000451798: BFBD0000
	buffer_gl0_inv                                             // 00000045179C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000004517A4: BE852004
	s_cbranch_execz 29                                         // 0000004517A8: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2320>
	s_mov_b32 s7, exec_lo                                      // 0000004517AC: BE87007E
	s_mov_b32 s6, exec_lo                                      // 0000004517B0: BE86007E
	.long 0xd71f0001                                           // 0000004517B4: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 0000004517B8: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004517BC: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000004517C0: 7D940280
	s_cbranch_execz 9                                          // 0000004517C4: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x22ec>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000004517C8: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000004517CC: BF8704B9
	s_add_u32 s8, s18, s8                                      // 0000004517D0: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000004517D4: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 0000004517D8: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 0000004517DC: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 0000004517E4: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004517EC: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 0000004517F0: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 0000004517F4: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004517F8: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000004517FC: CA200080 02000206
	s_add_i32 s6, s27, -1                                      // 000000451804: 8106C11B
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000451808: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000045180C: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000451810: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 000000451818: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000451820: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000451824: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000451828: BF89FC07
	s_barrier                                                  // 00000045182C: BFBD0000
	buffer_gl0_inv                                             // 000000451830: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 000000451838: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000451840: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000451844: 7C940280
	s_cbranch_vccnz 64                                         // 000000451848: BFA40040 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x244c>
	buffer_gl1_inv                                             // 00000045184C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000451854: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000045185C: BE852001
	s_cbranch_execz 46                                         // 000000451860: BFA5002E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x241c>
	v_and_b32_e32 v2, 0x7f, v0                                 // 000000451864: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 00000045186C: 84068702
	s_ashr_i32 s1, s26, 31                                     // 000000451870: 86019F1A
	s_ashr_i32 s7, s6, 31                                      // 000000451874: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000451878: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 00000045187C: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000451884: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000451888: BF8700A9
	s_add_u32 s6, s16, s6                                      // 00000045188C: 80060610
	s_addc_u32 s7, s17, s7                                     // 000000451890: 82070711
	.long 0xd7000603                                           // 000000451894: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 000000451898: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045189C: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 0000004518A0: D5207C04 00190007
	s_nop 0                                                    // 0000004518A8: BF800000
	s_nop 0                                                    // 0000004518AC: BF800000
	s_nop 0                                                    // 0000004518B0: BF800000
	s_nop 0                                                    // 0000004518B4: BF800000
	s_nop 0                                                    // 0000004518B8: BF800000
	s_nop 0                                                    // 0000004518BC: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s26, 0                     // 0000004518C0: D6FE7C05 02003501
	s_add_i32 s27, s27, -1                                     // 0000004518C8: 811BC11B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000004518CC: BF870139
	s_cmp_eq_u32 s27, 0                                        // 0000004518D0: BF06801B
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 0000004518D4: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 0000004518DC: 4A020282
	.long 0xd73c0005                                           // 0000004518E0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 0000004518E4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004518E8: BF870091
	.long 0xd7006a05                                           // 0000004518EC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000004518F0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 0000004518F4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 0000004518FC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000451904: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 000000451908: 06040B02
	s_cbranch_scc0 65516                                       // 00000045190C: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23c0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000451910: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 000000451914: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000045191C: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000451920: BE812004
	s_cbranch_execz 6                                          // 000000451924: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2440>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000451928: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000045192C: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000451930: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000451934: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 000000451938: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000451940: 8C7E017E
	s_cbranch_execz 65340                                      // 000000451944: BFA5FF3C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2138>
	s_branch 1                                                 // 000000451948: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2450>
	s_branch 65338                                             // 00000045194C: BFA0FF3A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2138>
	v_cmp_gt_i32_e32 vcc_lo, s24, v40                          // 000000451950: 7C885018
	.long 0xd44c0001                                           // 000000451954: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000451958: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000045195C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000451960: BC7C0000
	s_barrier                                                  // 000000451964: BFBD0000
	buffer_gl0_inv                                             // 000000451968: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000451970: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000451974: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000451978: BE832001
	s_cbranch_execz 65326                                      // 00000045197C: BFA5FF2E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2138>
	v_and_b32_e32 v1, 15, v0                                   // 000000451980: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451984: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000451988: 30040282
	v_lshl_or_b32 v2, v40, 9, v2                               // 00000045198C: D6560002 04091328
	s_delay_alu instid0(VALU_DEP_1)                            // 000000451994: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 000000451998: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004519A0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004519A8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004519B0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004519B8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004519C0: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004519C4: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004519C8: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004519CC: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004519D4: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 0000004519D8: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 0000004519E0: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 0000004519E4: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 0000004519EC: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 0000004519F0: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 0000004519F8: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000451A00: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000451A04: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000451A08: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000451A10: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000451A18: 7C941480
	.long 0xd44a0001                                           // 000000451A1C: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000451A20: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000451A24: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000451A2C: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000451A30: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000451A34: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000451A38: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000451A3C: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000451A44: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000451A48: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000451A4C: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451A50: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000451A58: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451A60: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000451A68: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451A70: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000451A78: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451A80: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000451A88: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451A90: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000451A98: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451AA0: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000451AA8: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451AB0: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 000000451AB8: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 000000451AC0: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000451AC8: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000451ACC: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000451AD4: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000451ADC: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000451AE4: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451AE8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000451AF0: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000451AF8: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451AFC: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000451B04: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451B0C: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000451B14: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451B18: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000451B20: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000451B28: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000451B2C: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 000000451B34: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451B38: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000451B40: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451B44: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000451B4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000451B54: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000451B5C: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451B60: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000451B68: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000451B70: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451B74: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000451B7C: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000451B84: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451B88: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000451B90: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000451B98: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000451B9C: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000451BA0: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451BA8: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 000000451BB0: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451BB4: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000451BBC: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000451BC4: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 000000451BC8: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451BCC: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000451BD4: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 000000451BDC: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451BE0: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451BE8: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451BF0: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 000000451BF8: 06081504
	v_add_f32_e32 v10, v19, v18                                // 000000451BFC: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000451C00: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000451C04: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000451C0C: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 000000451C14: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000451C18: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451C1C: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000451C24: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000451C2C: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451C30: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000451C38: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000451C40: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000451C48: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 000000451C50: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451C54: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000451C5C: BF870214
	v_add_f32_e32 v15, v10, v15                                // 000000451C60: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 000000451C64: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451C68: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451C70: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000451C78: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451C7C: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000451C84: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 000000451C8C: 8B7E007E
	s_cbranch_execz 65129                                      // 000000451C90: BFA5FE69 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2138>
	v_lshl_or_b32 v18, s2, 7, v1                               // 000000451C94: D6560012 04050E02
	.long 0x7f2c3880                                           // 000000451C9C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000451CA0: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000451CA4: 3426249F
	.long 0x7f2e3996                                           // 000000451CA8: 7F2E3996
	.long 0x7f303996                                           // 000000451CAC: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000451CB0: BF870093
	.long 0xd73c0012                                           // 000000451CB4: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000451CB8: 02022481
	.long 0xd7006a14                                           // 000000451CBC: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 000000451CC0: 0202240E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000451CC4: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 000000451CC8: D5207C15 01AA260F
	s_clause 0x7                                               // 000000451CD0: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 000000451CD4: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000451CDC: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 000000451CE4: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 000000451CEC: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 000000451CF4: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 000000451CFC: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 000000451D04: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 000000451D0C: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000451D14: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v40, 0                    // 000000451D18: D6FF7C00 0202501A
	s_waitcnt vmcnt(0)                                         // 000000451D20: BF8903F7
	.long 0x7f283996                                           // 000000451D24: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000451D28: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000451D2C: 7C942A80
	.long 0x7f2a3996                                           // 000000451D30: 7F2A3996
	.long 0xd73c0000                                           // 000000451D34: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000451D38: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000451D3C: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000451D44: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000451D4C: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000451D54: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000451D5C: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000451D64: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000451D68: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000451D70: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000451D78: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000451D80: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000451D84: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000451D90: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000451D98: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000451DA4: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000451DA8: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000451DB0: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000451DB8: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000451DBC: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000451DC8: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000451DD4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000451DD8: 02020014
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000451DDC: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000451DE0: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000451DE8: D5207C01 01AA0215
	.long 0xd7006a00                                           // 000000451DF0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000451DF4: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 000000451DF8: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000451DFC: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000451E04: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000451E0C: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000451E14: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 000000451E1C: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000451E24: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 000000451E2C: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000451E30: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000451E38: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000451E40: CC200008 8A02111C
	.long 0x7e2a3985                                           // 000000451E48: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 000000451E4C: 36142C81
	.long 0x7e2c3984                                           // 000000451E50: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000451E54: CC200009 8A021314
	.long 0x7e283982                                           // 000000451E5C: 7E283982
	.long 0x7e2e3986                                           // 000000451E60: 7E2E3986
	.long 0x7e303988                                           // 000000451E64: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 000000451E68: 36162C81
	.long 0x7e2c3987                                           // 000000451E6C: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 000000451E70: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 000000451E74: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 000000451E78: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 000000451E7C: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 000000451E80: 361E2C81
	.long 0x7e2c3989                                           // 000000451E84: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000451E88: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000451E94: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000451EA0: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000451EAC: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 000000451EB8: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 000000451EBC: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000451EC8: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000451ED4: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000451EE0: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000451EE4: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 000000451EF0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000451EF4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 000000451EFC: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 000000451F04: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 000000451F0C: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 000000451F14: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 000000451F1C: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 000000451F24: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 000000451F2C: DC9600E0 007C0900
	s_nop 0                                                    // 000000451F34: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000451F38: BFB60003
	s_endpgm                                                   // 000000451F3C: BFB00000
		...

