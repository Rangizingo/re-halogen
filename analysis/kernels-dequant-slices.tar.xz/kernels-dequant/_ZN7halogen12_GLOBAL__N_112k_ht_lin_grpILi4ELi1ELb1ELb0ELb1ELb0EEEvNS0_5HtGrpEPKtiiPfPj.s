0000000000413800 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj>:
; _ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj():
	s_clause 0x1                                               // 000000413800: BF850001
	s_load_b64 s[4:5], s[0:1], 0x130                           // 000000413804: F4040100 F8000130
	s_load_b128 s[16:19], s[0:1], 0x198                        // 00000041380C: F4080400 F8000198
	s_waitcnt lgkmcnt(0)                                       // 000000413814: BF89FC07
	s_cmp_eq_u64 s[4:5], 0                                     // 000000413818: BF108004
	s_cbranch_scc1 244                                         // 00000041381C: BFA200F4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f0>
	s_load_b32 s6, s[0:1], 0x138                               // 000000413820: F4000180 F8000138
	s_waitcnt lgkmcnt(0)                                       // 000000413828: BF89FC07
	s_cmp_lt_i32 s2, s6                                        // 00000041382C: BF040602
	s_cselect_b32 s3, -1, 0                                    // 000000413830: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000413834: BF030602
	s_cbranch_scc0 233                                         // 000000413838: BFA100E9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3e0>
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000041383C: 32020085
	s_sub_i32 s6, s2, s6                                       // 000000413840: 81860602
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000413844: BF870481
	v_lshl_or_b32 v1, s6, 3, v1                                // 000000413848: D6560001 04050606
	s_mul_i32 s6, s18, 20                                      // 000000413850: 96069412
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000413854: BF870481
	v_cmp_gt_i32_e32 vcc_lo, s6, v1                            // 000000413858: 7C880206
	s_and_saveexec_b32 s6, vcc_lo                              // 00000041385C: BE86206A
	s_cbranch_execz 222                                        // 000000413860: BFA500DE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3dc>
	.long 0xd72e0002                                           // 000000413864: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v1, vcc_lo               // 000000413868: 020202FF 66666667
	v_and_b32_e32 v9, 31, v0                                   // 000000413870: 3612009F
	s_load_b64 s[8:9], s[0:1], 0x128                           // 000000413874: F4040200 F8000128
	s_mov_b32 s7, 0x76543210                                   // 00000041387C: BE8700FF 76543210
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000413884: BF8700A2
	v_lshrrev_b32_e32 v3, 31, v2                               // 000000413888: 3206049F
	v_ashrrev_i32_e32 v2, 3, v2                                // 00000041388C: 34040483
	v_add_nc_u32_e32 v8, v2, v3                                // 000000413890: 4A100702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000413894: BF870121
	.long 0xd72c0002                                           // 000000413898: D72C0002
	v_cndmask_b32_e32 v1, 0xffffffec, v8, vcc_lo               // 00000041389C: 020210FF FFFFFFEC
	v_mad_i64_i32 v[4:5], null, 0x1400, v8, s[16:17]           // 0000004138A4: D6FF7C04 004210FF 00001400
	v_add_lshl_u32 v1, v2, v1, 7                               // 0000004138B0: D6470001 021E0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004138B8: BF870091
	v_lshl_or_b32 v2, v9, 2, v1                                // 0000004138BC: D6560002 04050509
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004138C4: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004138C8: BF870091
	.long 0xd73c0002                                           // 0000004138CC: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 0000004138D0: 02020481
	.long 0xd7006a04                                           // 0000004138D4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004138D8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004138DC: BF8700B1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004138E0: D5207C05 01AA0705
	s_waitcnt lgkmcnt(0)                                       // 0000004138E8: BF89FC07
	.long 0xd7006a02                                           // 0000004138EC: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000004138F0: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 0000004138F4: D5207C03 01AA0609
	global_load_b64 v[4:5], v[4:5], off                        // 0000004138FC: DC560000 047C0004
	s_mov_b32 s8, 0x3db504f3                                   // 000000413904: BE8800FF 3DB504F3
	global_load_b64 v[6:7], v[2:3], off                        // 00000041390C: DC560000 067C0002
	s_waitcnt vmcnt(1)                                         // 000000413914: BF8907F7
	.long 0x7e043904                                           // 000000413918: 7E043904
	v_and_b32_e32 v3, 0xffff0000, v4                           // 00000041391C: 360608FF FFFF0000
	.long 0x7e083905                                           // 000000413924: 7E083905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000413928: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000413930: BF870004
	v_lshlrev_b32_e32 v14, 16, v2                              // 000000413934: 301C0490
	s_waitcnt vmcnt(0)                                         // 000000413938: BF8903F7
	v_fma_mix_f32 v3, v6, v3, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000041393C: CC200803 8A020706
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000413944: 30080890
	v_fma_mix_f32 v5, v7, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000413948: CC200805 8A020B07
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000413950: 3404029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000413954: BF870224
	v_fma_mix_f32 v15, v6, v14, v3 op_sel_hi:[1,0,0]           // 000000413958: CC20000F 0C0E1D06
	v_fma_mix_f32 v6, v6, v14, -v3 op_sel_hi:[1,0,0]           // 000000413960: CC200006 8C0E1D06
	v_fma_mix_f32 v14, v7, v4, v5 op_sel_hi:[1,0,0]            // 000000413968: CC20000E 0C160907
	v_fma_mix_f32 v5, v7, v4, -v5 op_sel_hi:[1,0,0]            // 000000413970: CC200005 8C160907
	v_and_b32_e32 v10, 1, v0                                   // 000000413978: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000041397C: 36160082
	v_and_b32_e32 v13, 8, v0                                   // 000000413980: 361A0088
	.long 0xd73c0001                                           // 000000413984: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000413988: 02020281
	v_add_f32_e32 v16, v6, v5                                  // 00000041398C: 06200B06
	v_sub_f32_e32 v5, v6, v5                                   // 000000413990: 080A0B06
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000413994: 7C941480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413998: BF870193
	v_mov_b32_dpp v10, v16 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041399C: 7E1402FA FF016110
	v_mov_b32_dpp v17, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004139A4: 7E2202FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004139AC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000004139B4: BF8701D1
	v_add_f32_e32 v5, v5, v17                                  // 0000004139B8: 060A2305
	v_mad_i64_i32 v[3:4], null, 0x1400, v8, s[4:5]             // 0000004139BC: D6FF7C03 001210FF 00001400
	v_add_f32_e32 v8, v15, v14                                 // 0000004139C8: 06101D0F
	v_sub_f32_e32 v14, v15, v14                                // 0000004139CC: 081C1D0F
	v_cndmask_b32_e64 v15, -v16, v16, vcc_lo                   // 0000004139D0: D501000F 21AA2110
	v_mov_b32_dpp v6, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004139D8: 7E0C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004139E0: D5010008 21AA1108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004139E8: BF870234
	v_mov_b32_dpp v16, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004139EC: 7E2002FA FF01610E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000004139F4: D501000E 21AA1D0E
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 0000004139FC: 7C941680
	v_dual_add_f32 v6, v8, v6 :: v_dual_lshlrev_b32 v7, 3, v9  // 000000413A00: C9220D08 06061283
	v_add_f32_e32 v8, v15, v10                                 // 000000413A08: 0610150F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000413A0C: BF870004
	v_add_f32_e32 v10, v14, v16                                // 000000413A10: 0614210E
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000413A14: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000413A1C: D5010005 21AA0B05
	v_mov_b32_dpp v11, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000413A24: 7E1602FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000413A2C: D5010006 21AA0D06
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000413A34: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000413A3C: D501000A 21AA150A
	v_add_f32_e32 v5, v5, v16                                  // 000000413A44: 060A2105
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000413A48: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000413A50: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000413A58: 060C1706
	v_add_f32_e32 v10, v10, v15                                // 000000413A5C: 06141F0A
	v_mov_b32_dpp v15, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000413A60: 7E1E02FA FF016405
	v_and_b32_e32 v12, 4, v0                                   // 000000413A68: 36180084
	v_add_f32_e32 v8, v8, v14                                  // 000000413A6C: 06101D08
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000413A70: 7E1602FA FF016406
	v_mov_b32_dpp v14, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000413A78: 7E1C02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000413A80: BF8701C4
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 000000413A84: 7C941880
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000413A88: D5010006 21AA0D06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000413A90: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000413A98: D501000A 21AA150A
	v_add_f32_e32 v6, v6, v11                                  // 000000413AA0: 060C1706
	s_delay_alu instid0(VALU_DEP_3)                            // 000000413AA4: BF870003
	v_add_f32_e32 v5, v5, v15                                  // 000000413AA8: 060A1F05
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000413AAC: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000413AB4: D5010008 21AA1108
	v_cmp_eq_u32_e32 vcc_lo, 0, v13                            // 000000413ABC: 7C941A80
	v_add_f32_e32 v10, v10, v14                                // 000000413AC0: 06141D0A
	v_mov_b32_dpp v11, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000413AC4: 7E1602FA FF016806
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000413ACC: 7E1C02FA FF016805
	v_add_f32_e32 v8, v8, v12                                  // 000000413AD4: 06101908
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000413AD8: D5010006 21AA0D06
	v_mov_b32_dpp v13, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000413AE0: 7E1A02FA FF01680A
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000413AE8: D5010005 21AA0B05
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000413AF0: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000413AF8: 7E1802FA FF016808
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000413B00: D5010008 21AA1108
	v_add_f32_e32 v6, v6, v11                                  // 000000413B08: 060C1706
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 000000413B0C: 7C981290
	v_add_f32_e32 v5, v5, v14                                  // 000000413B10: 060A1D05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000413B14: BF870214
	v_dual_add_f32 v9, v10, v13 :: v_dual_add_f32 v8, v8, v12  // 000000413B18: C9081B0A 09081908
	v_mov_b32_e32 v10, v6                                      // 000000413B20: 7E140306
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000413B24: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000413B2C: BF870214
	v_mov_b32_e32 v13, v5                                      // 000000413B30: 7E1A0305
	v_mov_b32_e32 v12, v9                                      // 000000413B34: 7E180309
	v_cndmask_b32_e64 v11, -v8, v8, vcc_lo                     // 000000413B38: D501000B 21AA1108
	v_permlanex16_b32 v8, v8, s7, 0xfedcba98                   // 000000413B40: D65C0008 03FC0F08 FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000413B4C: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000413B54: D5010009 21AA1309
	v_permlanex16_b32 v10, v10, s7, 0xfedcba98                 // 000000413B5C: D65C000A 03FC0F0A FEDCBA98
	v_permlanex16_b32 v12, v12, s7, 0xfedcba98                 // 000000413B68: D65C000C 03FC0F0C FEDCBA98
	v_permlanex16_b32 v13, v13, s7, 0xfedcba98                 // 000000413B74: D65C000D 03FC0F0D FEDCBA98
	.long 0xd7006a01                                           // 000000413B80: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000413B84: 02020303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000413B88: BF8700D1
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 000000413B8C: D5207C02 01AA0504
	v_dual_add_f32 v3, v11, v8 :: v_dual_add_f32 v4, v6, v10   // 000000413B94: C908110B 03041506
	v_add_f32_e32 v6, v9, v12                                  // 000000413B9C: 060C1909
	v_add_f32_e32 v5, v5, v13                                  // 000000413BA0: 060A1B05
	.long 0xd7006a01                                           // 000000413BA4: D7006A01
	v_cndmask_b32_e32 v1, v1, v7, vcc_lo                       // 000000413BA8: 02020F01
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000413BAC: D5207C02 01AA0480
	v_fma_mixhi_f16 v3, v3, s8, 0                              // 000000413BB4: CC220003 02001103
	v_fma_mixlo_f16 v3, v4, s8, 0                              // 000000413BBC: CC210003 02001104
	v_fma_mixhi_f16 v4, v5, s8, 0                              // 000000413BC4: CC220004 02001105
	v_fma_mixlo_f16 v4, v6, s8, 0                              // 000000413BCC: CC210004 02001106
	global_store_b64 v[1:2], v[3:4], off                       // 000000413BD4: DC6E0000 007C0301
	s_or_b32 exec_lo, exec_lo, s6                              // 000000413BDC: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413BE0: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 000000413BE4: 8B6A037E
	s_cbranch_vccnz 2                                          // 000000413BE8: BFA40002 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3f4>
	s_endpgm                                                   // 000000413BEC: BFB00000
	s_cbranch_execz 65534                                      // 000000413BF0: BFA5FFFE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_clause 0x3                                               // 000000413BF4: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000413BF8: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x7c                                // 000000413C00: F4000100 F800007C
	s_load_b32 s5, s[0:1], 0xc4                                // 000000413C08: F4000140 F80000C4
	s_load_b32 s6, s[0:1], 0x10c                               // 000000413C10: F4000180 F800010C
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000413C18: 320E0085
	v_and_b32_e32 v8, 31, v0                                   // 000000413C1C: 3610009F
	s_mov_b32 s33, 0                                           // 000000413C20: BEA10080
	s_waitcnt lgkmcnt(0)                                       // 000000413C24: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000413C28: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000413C2C: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000413C30: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000413C34: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413C38: BF870009
	s_and_b32 s4, s7, s4                                       // 000000413C3C: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000413C40: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000413C44: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000413C4C: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000413C50: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000413C54: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413C58: BF870009
	s_and_b32 s4, s7, s5                                       // 000000413C5C: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000413C60: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000413C64: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000413C68: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000413C6C: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000413C70: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000413C74: BF8704D9
	s_and_b32 s3, s3, s6                                       // 000000413C78: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000413C7C: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000413C80: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000413C84: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000413C88: 98030483
	s_mulk_i32 s3, 0x48                                        // 000000413C8C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413C90: BF870009
	s_add_u32 s4, s0, s3                                       // 000000413C94: 80040300
	s_addc_u32 s5, s1, 0                                       // 000000413C98: 82058001
	s_clause 0x3                                               // 000000413C9C: BF850003
	s_load_b32 s28, s[4:5], 0x38                               // 000000413CA0: F4000702 F8000038
	s_load_b64 s[30:31], s[4:5], 0x40                          // 000000413CA8: F4040782 F8000040
	s_load_b128 s[20:23], s[4:5], 0x28                         // 000000413CB0: F4080502 F8000028
	s_load_b64 s[24:25], s[4:5], 0x20                          // 000000413CB8: F4040602 F8000020
	s_waitcnt lgkmcnt(0)                                       // 000000413CC0: BF89FC07
	s_abs_i32 s3, s21                                          // 000000413CC4: BE831515
	s_sub_i32 s2, s2, s23                                      // 000000413CC8: 81821702
	s_cvt_f32_u32 s6, s3                                       // 000000413CCC: BE866503
	s_sub_i32 s7, 0, s3                                        // 000000413CD0: 81870380
	s_abs_i32 s8, s2                                           // 000000413CD4: BE881502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000413CD8: BF870299
	v_rcp_iflag_f32_e32 v1, s6                                 // 000000413CDC: 7E025606
	v_readfirstlane_b32 s6, v1                                 // 000000413CE0: 7E0C0501
	s_mul_f32 s6, s6, 0x4f7ffffe                               // 000000413CE4: A206FF06 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000413CEC: BF87059B
	s_cvt_u32_f32 s6, s6                                       // 000000413CF0: BE866706
	s_mul_i32 s7, s7, s6                                       // 000000413CF4: 96070607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000413CF8: BF870499
	s_mul_hi_u32 s7, s6, s7                                    // 000000413CFC: 96870706
	s_add_i32 s6, s6, s7                                       // 000000413D00: 81060706
	s_xor_b32 s7, s2, s21                                      // 000000413D04: 8D071502
	s_mul_hi_u32 s6, s8, s6                                    // 000000413D08: 96860608
	s_ashr_i32 s7, s7, 31                                      // 000000413D0C: 86079F07
	s_mul_i32 s9, s6, s3                                       // 000000413D10: 96090306
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413D14: BF870009
	s_sub_i32 s8, s8, s9                                       // 000000413D18: 81880908
	s_add_i32 s9, s6, 1                                        // 000000413D1C: 81098106
	s_sub_i32 s10, s8, s3                                      // 000000413D20: 818A0308
	s_cmp_ge_u32 s8, s3                                        // 000000413D24: BF090308
	s_cselect_b32 s6, s9, s6                                   // 000000413D28: 98060609
	s_cselect_b32 s8, s10, s8                                  // 000000413D2C: 9808080A
	s_add_i32 s9, s6, 1                                        // 000000413D30: 81098106
	s_cmp_ge_u32 s8, s3                                        // 000000413D34: BF090308
	s_cselect_b32 s3, s9, s6                                   // 000000413D38: 98030609
	s_load_b256 s[8:15], s[4:5], null                          // 000000413D3C: F40C0202 F8000000
	s_xor_b32 s3, s3, s7                                       // 000000413D44: 8D030703
	s_ashr_i32 s27, s19, 31                                    // 000000413D48: 861B9F13
	s_sub_i32 s26, s3, s7                                      // 000000413D4C: 819A0703
	s_lshr_b32 s4, s27, 25                                     // 000000413D50: 8504991B
	s_mul_i32 s3, s26, s21                                     // 000000413D54: 9603151A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000413D58: BF870009
	s_sub_i32 s23, s2, s3                                      // 000000413D5C: 81970302
	s_add_i32 s2, s19, s4                                      // 000000413D60: 81020413
	s_mul_i32 s29, s22, s23                                    // 000000413D64: 961D1716
	s_ashr_i32 s2, s2, 7                                       // 000000413D68: 86028702
	s_add_i32 s3, s29, s22                                     // 000000413D6C: 8103161D
	s_mov_b32 s22, exec_lo                                     // 000000413D70: BE96007E
	s_min_i32 s2, s2, s3                                       // 000000413D74: 89020302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000413D78: BF870499
	s_sub_i32 s7, s2, s29                                      // 000000413D7C: 81871D02
	.long 0xd4c4007e                                           // 000000413D80: D4C4007E
	v_cndmask_b32_e32 v1, s7, v7, vcc_lo                       // 000000413D84: 02020E07
	s_cbranch_execz 289                                        // 000000413D88: BFA50121 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xa10>
	s_abs_i32 s34, s7                                          // 000000413D8C: BEA21507
	v_lshlrev_b32_e32 v9, 3, v8                                // 000000413D90: 30121083
	s_cvt_f32_u32 s2, s34                                      // 000000413D94: BE826522
	v_lshlrev_b32_e32 v10, 7, v7                               // 000000413D98: 30140E87
	v_and_b32_e32 v3, 2, v0                                    // 000000413D9C: 36060082
	v_and_b32_e32 v5, 8, v0                                    // 000000413DA0: 360A0088
	v_rcp_iflag_f32_e32 v1, s2                                 // 000000413DA4: 7E025602
	s_sub_i32 s2, 0, s34                                       // 000000413DA8: 81822280
	s_ashr_i32 s37, s7, 31                                     // 000000413DAC: 86259F07
	.long 0xd44a0003                                           // 000000413DB0: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000413DB4: 02020680
	s_mul_i32 s39, s37, 0x1400                                 // 000000413DB8: 9627FF25 00001400
	.long 0xd44a0005                                           // 000000413DC0: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000413DC4: 02020A80
	s_lshl_b32 s6, s7, 7                                       // 000000413DC8: 84068707
	s_add_i32 s35, s18, -1                                     // 000000413DCC: 8123C112
	s_mov_b32 s36, s19                                         // 000000413DD0: BEA40013
	s_lshl_b32 s38, s7, 8                                      // 000000413DD4: 84268807
	v_dual_mul_f32 v1, 0x4f7ffffe, v1 :: v_dual_and_b32 v2, 1, v0// 000000413DD8: C8E402FF 01020081 4F7FFFFE
	s_mov_b32 s40, 0x76543210                                  // 000000413DE4: BEA800FF 76543210
	s_mov_b32 s41, 0x3db504f3                                  // 000000413DEC: BEA900FF 3DB504F3
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 000000413DF4: 7C981090
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000413DF8: BF870122
	v_cvt_u32_f32_e32 v4, v1                                   // 000000413DFC: 7E080F01
	v_and_b32_e32 v1, 4, v0                                    // 000000413E00: 36020084
	.long 0xd72c0006                                           // 000000413E04: D72C0006
	v_cndmask_b32_e32 v1, s2, v4, vcc_lo                       // 000000413E08: 02020802
	.long 0xd44a0002                                           // 000000413E0C: D44A0002
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 000000413E10: 02020480
	v_lshl_or_b32 v2, v7, 8, v9                                // 000000413E14: D6560002 04251107
	v_lshl_add_u32 v9, s29, 7, v10                             // 000000413E1C: D6460009 04290E1D
	.long 0xd44a0004                                           // 000000413E24: D44A0004
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000413E28: 02020280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000413E2C: BF870223
	v_subrev_nc_u32_e32 v2, s39, v2                            // 000000413E30: 4E040427
	.long 0xd72d0006                                           // 000000413E34: D72D0006
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000413E38: 02020D04
	v_lshl_or_b32 v1, v8, 2, v9                                // 000000413E3C: D6560001 04250508
	s_sub_i32 s39, 0, s6                                       // 000000413E44: 81A70680
	s_delay_alu instid0(VALU_DEP_2)                            // 000000413E48: BF870002
	v_dual_mov_b32 v4, v7 :: v_dual_add_nc_u32 v3, v4, v6      // 000000413E4C: CA200107 04020D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413E54: BF870091
	.long 0xd72d0005                                           // 000000413E58: D72D0005
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 000000413E5C: 02020704
	.long 0xd72c0006                                           // 000000413E60: D72C0006
	v_cndmask_b32_e32 v0, v5, v34, vcc_lo                      // 000000413E64: 02004505
	v_add_nc_u32_e32 v9, 1, v5                                 // 000000413E68: 4A120A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413E6C: BF870092
	v_sub_nc_u32_e32 v6, v4, v6                                // 000000413E70: 4C0C0D04
	v_subrev_nc_u32_e32 v10, s34, v6                           // 000000413E74: 4E140C22
	.long 0xd44b0006                                           // 000000413E78: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 000000413E7C: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413E80: BF870191
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 000000413E84: D5010005 001A1305
	v_cndmask_b32_e64 v6, v6, v10, s6                          // 000000413E8C: D5010006 001A1506
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000413E94: BF870112
	v_add_nc_u32_e32 v9, 1, v5                                 // 000000413E98: 4A120A81
	.long 0xd44b0006                                           // 000000413E9C: D44B0006
	v_cndmask_b32_e32 v1, s34, v6, vcc_lo                      // 000000413EA0: 02020C22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413EA4: BF870091
	v_cndmask_b32_e64 v5, v5, v9, s6                           // 000000413EA8: D5010005 001A1305
	v_xor_b32_e32 v11, s37, v5                                 // 000000413EB0: 3A160A25
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000413EB4: BF870121
	v_subrev_nc_u32_e32 v12, s37, v11                          // 000000413EB8: 4E181625
	.long 0xd72c000b                                           // 000000413EBC: D72C000B
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000413EC0: 020216FF 00001400
	v_min_i32_e32 v9, s35, v12                                 // 000000413EC8: 22121823
	v_mad_u64_u32 v[5:6], null, s39, v12, v[1:2]               // 000000413ECC: D6FE7C05 04061827
	.long 0xd72c000c                                           // 000000413ED4: D72C000C
	v_cndmask_b32_e32 v1, s38, v12, vcc_lo                     // 000000413ED8: 02021826
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413EDC: BF870193
	v_mad_i64_i32 v[9:10], null, v9, s36, 0                    // 000000413EE0: D6FF7C09 02004909
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000413EE8: 340C0A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413EEC: BF870193
	v_sub_nc_u32_e32 v11, v11, v12                             // 000000413EF0: 4C16190B
	.long 0xd73c0009                                           // 000000413EF4: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000413EF8: 02021281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000413EFC: BF870193
	.long 0xd73c0005                                           // 000000413F00: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000413F04: 02020A81
	v_add_nc_u32_e32 v11, v2, v11                              // 000000413F08: 4A161702
	v_add_nc_u32_e32 v2, 0x800, v2                             // 000000413F0C: 4A0404FF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413F14: BF870094
	.long 0xd700060d                                           // 000000413F18: D700060D
	v_cndmask_b32_e32 v1, s16, v9, vcc_lo                      // 000000413F1C: 02021210
	v_add_co_ci_u32_e64 v14, null, s17, v10, s6                // 000000413F20: D5207C0E 001A1411
	s_waitcnt lgkmcnt(0)                                       // 000000413F28: BF89FC07
	.long 0xd7000609                                           // 000000413F2C: D7000609
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000413F30: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000413F34: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s11, v6, s6                 // 000000413F38: D5207C0A 001A0C0B
	.long 0xd7000605                                           // 000000413F40: D7000605
	v_cndmask_b32_e32 v1, v13, v5, vcc_lo                      // 000000413F44: 02020B0D
	v_add_co_ci_u32_e64 v6, null, v14, v6, s6                  // 000000413F48: D5207C06 001A0D0E
	global_load_b64 v[5:6], v[5:6], off                        // 000000413F50: DC560000 057C0005
	global_load_b64 v[9:10], v[9:10], off                      // 000000413F58: DC560000 097C0009
	s_waitcnt vmcnt(1)                                         // 000000413F60: BF8907F7
	.long 0x7e1a3905                                           // 000000413F64: 7E1A3905
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000413F68: 360A0AFF FFFF0000
	.long 0x7e1c3906                                           // 000000413F70: 7E1C3906
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000413F74: BF8701A3
	v_lshlrev_b32_e32 v13, 16, v13                             // 000000413F78: 301A1A90
	s_waitcnt vmcnt(0)                                         // 000000413F7C: BF8903F7
	v_fma_mix_f32 v5, v9, v5, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000413F80: CC200805 8A020B09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000413F88: BF870113
	v_lshlrev_b32_e32 v14, 16, v14                             // 000000413F8C: 301C1C90
	v_fma_mix_f32 v16, v9, v13, v5 op_sel_hi:[1,0,0]           // 000000413F90: CC200010 0C161B09
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000413F98: 360C0CFF FFFF0000
	v_fma_mix_f32 v5, v9, v13, -v5 op_sel_hi:[1,0,0]           // 000000413FA0: CC200005 8C161B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000413FA8: BF870092
	v_fma_mix_f32 v6, v10, v6, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000413FAC: CC200806 8A020D0A
	v_fma_mix_f32 v15, v10, v14, v6 op_sel_hi:[1,0,0]          // 000000413FB4: CC20000F 0C1A1D0A
	v_fma_mix_f32 v6, v10, v14, -v6 op_sel_hi:[1,0,0]          // 000000413FBC: CC200006 8C1A1D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000413FC4: BF870112
	v_dual_add_f32 v9, v16, v15 :: v_dual_add_nc_u32 v4, 8, v4 // 000000413FC8: C9201F10 09040888
	v_dual_add_f32 v10, v6, v5 :: v_dual_sub_f32 v5, v5, v6    // 000000413FD0: C90A0B06 0A040D05
	v_sub_f32_e32 v13, v16, v15                                // 000000413FD8: 081A1F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000413FDC: BF870213
	.long 0xd4430006                                           // 000000413FE0: D4430006
	v_cndmask_b32_e32 v1, s7, v4, vcc_lo                       // 000000413FE4: 02020807
	v_mov_b32_dpp v6, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000413FE8: 7E0C02FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000413FF0: D5010009 200A1309
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000413FF8: 7E2002FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, s2                          // 000000414000: D5010005 200A0B05
	v_mov_b32_dpp v15, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000414008: 7E1E02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, s2                       // 000000414010: D501000D 200A1B0D
	v_dual_add_f32 v6, v9, v6 :: v_dual_add_nc_u32 v1, 0x400, v1// 000000414018: C9200D09 060002FF 00000400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000414024: BF8701C4
	v_add_f32_e32 v5, v5, v16                                  // 000000414028: 060A2105
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000041402C: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000414034: D501000A 200A150A
	s_or_b32 s33, s6, s33                                      // 00000041403C: 8C212106
	v_mov_b32_dpp v16, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000414040: 7E2002FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000414048: D5010005 200E0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414050: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 000000414054: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000414058: 7E2002FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000414060: D5010005 20120B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414068: BF870091
	v_add_f32_e32 v5, v5, v16                                  // 00000041406C: 060A2105
	v_mov_b32_dpp v16, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000414070: 7E2002FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000414078: D5010005 20160B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000414080: BF870241
	v_add_f32_e32 v5, v5, v16                                  // 000000414084: 060A2105
	v_dual_add_f32 v9, v10, v14 :: v_dual_add_f32 v10, v13, v15// 000000414088: C9081D0A 090A1F0D
	v_mov_b32_dpp v13, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000414090: 7E1A02FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s3                          // 000000414098: D5010006 200E0D06
	v_mov_b32_e32 v16, v5                                      // 0000004140A0: 7E200305
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004140A4: BF870004
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004140A8: 7E1C02FA FF016209
	v_mov_b32_dpp v15, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004140B0: 7E1E02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000004140B8: D501000A 200E150A
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000004140C0: D5010009 200E1309
	v_add_f32_e32 v6, v6, v13                                  // 0000004140C8: 060C1B06
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004140CC: D5010005 21AA0B05
	v_permlanex16_b32 v16, v16, s40, 0xfedcba98                // 0000004140D4: D65C0010 03FC5110 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004140E0: BF870214
	v_dual_add_f32 v10, v10, v15 :: v_dual_add_f32 v9, v9, v14 // 0000004140E4: C9081F0A 0A081D09
	v_mov_b32_dpp v13, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000004140EC: 7E1A02FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s4                          // 0000004140F4: D5010006 20120D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004140FC: BF870214
	v_add_f32_e32 v12, v5, v16                                 // 000000414100: 06182105
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000414104: 7E1E02FA FF01640A
	v_cndmask_b32_e64 v10, -v10, v10, s4                       // 00000041410C: D501000A 2012150A
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000414114: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s4                          // 00000041411C: D5010009 20121309
	v_add_f32_e32 v6, v6, v13                                  // 000000414124: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000414128: BF870114
	v_add_f32_e32 v10, v10, v15                                // 00000041412C: 06141F0A
	v_mov_b32_dpp v13, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000414130: 7E1A02FA FF016806
	v_cndmask_b32_e64 v6, -v6, v6, s5                          // 000000414138: D5010006 20160D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000414140: BF8701A3
	v_mov_b32_dpp v15, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000414144: 7E1E02FA FF01680A
	v_cndmask_b32_e64 v10, -v10, v10, s5                       // 00000041414C: D501000A 2016150A
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v6, v6, v13   // 000000414154: C9081D09 09061B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041415C: BF870112
	v_add_f32_e32 v10, v10, v15                                // 000000414160: 06141F0A
	v_mov_b32_dpp v14, v9 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000414164: 7E1C02FA FF016809
	v_cndmask_b32_e64 v9, -v9, v9, s5                          // 00000041416C: D5010009 20161309
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000414174: BF870123
	v_mov_b32_e32 v15, v10                                     // 000000414178: 7E1E030A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000041417C: D501000A 21AA150A
	v_permlanex16_b32 v15, v15, s40, 0xfedcba98                // 000000414184: D65C000F 03FC510F FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414190: BF870091
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v15 // 000000414194: C9081D09 090A1F0A
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v14, v9           // 00000041419C: CA100106 0D0E0109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 0000004141A4: D5010009 21AA1309
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000004141AC: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004141B4: BF870213
	v_permlanex16_b32 v13, v13, s40, 0xfedcba98                // 0000004141B8: D65C000D 03FC510D FEDCBA98
	v_permlanex16_b32 v14, v14, s40, 0xfedcba98                // 0000004141C4: D65C000E 03FC510E FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004141D0: BF870091
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v9, v9, v14   // 0000004141D4: C9081B06 06081D09
	v_fma_mixlo_f16 v5, v6, s41, 0                             // 0000004141DC: CC210005 02005306
	s_delay_alu instid0(VALU_DEP_2)                            // 0000004141E4: BF870002
	v_fma_mixhi_f16 v5, v9, s41, 0                             // 0000004141E8: CC220005 02005309
	v_fma_mixhi_f16 v6, v12, s41, 0                            // 0000004141F0: CC220006 0200530C
	v_fma_mixlo_f16 v6, v10, s41, 0                            // 0000004141F8: CC210006 0200530A
	ds_store_b64 v11, v[5:6]                                   // 000000414200: D9340000 0000050B
	s_and_not1_b32 exec_lo, exec_lo, s33                       // 000000414208: 917E217E
	s_cbranch_execnz 65297                                     // 00000041420C: BFA6FF11 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x654>
	s_or_b32 exec_lo, exec_lo, s22                             // 000000414210: 8C7E167E
	s_bfe_i32 s6, s7, 0x1001c                                  // 000000414214: 9386FF07 0001001C
	s_lshl_b32 s4, s7, 3                                       // 00000041421C: 84048307
	s_lshr_b64 s[2:3], s[6:7], 29                              // 000000414220: 85829D06
	s_lshr_b32 s3, s27, 28                                     // 000000414224: 85039C1B
	s_add_i32 s2, s2, 7                                        // 000000414228: 81028702
	s_add_i32 s3, s19, s3                                      // 00000041422C: 81030313
	s_ashr_i32 s2, s2, 3                                       // 000000414230: 86028302
	s_ashr_i32 s3, s3, 4                                       // 000000414234: 86038403
	.long 0xd72c0001                                           // 000000414238: D72C0001
	v_cndmask_b32_e32 v1, s2, v7, vcc_lo                       // 00000041423C: 02020E02
	s_lshl_b32 s5, s29, 3                                      // 000000414240: 8405831D
	s_mul_hi_i32 s7, s26, s3                                   // 000000414244: 9707031A
	s_ashr_i32 s6, s5, 31                                      // 000000414248: 86069F05
	v_lshlrev_b32_e32 v9, 2, v8                                // 00000041424C: 30121082
	s_waitcnt lgkmcnt(0)                                       // 000000414250: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000414254: BC7C0000
	s_barrier                                                  // 000000414258: BFBD0000
	buffer_gl0_inv                                             // 00000041425C: E0AC0000 00000000
	v_add_nc_u32_e32 v3, s2, v1                                // 000000414264: 4A060202
	s_mul_i32 s2, s26, s3                                      // 000000414268: 9602031A
	v_add_nc_u32_e32 v2, 1, v1                                 // 00000041426C: 4A040281
	s_add_u32 s2, s2, s5                                       // 000000414270: 80020502
	s_addc_u32 s3, s7, s6                                      // 000000414274: 82030607
	v_min_i32_e32 v10, s4, v3                                  // 000000414278: 22140604
	s_lshl_b64 s[4:5], s[2:3], 10                              // 00000041427C: 84848A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000414280: BF8700A9
	s_add_u32 s3, s8, s4                                       // 000000414284: 80030408
	s_addc_u32 s4, s9, s5                                      // 000000414288: 82040509
	v_cmp_lt_i32_e32 vcc_lo, v2, v10                           // 00000041428C: 7C821502
	s_and_saveexec_b32 s2, vcc_lo                              // 000000414290: BE82206A
	s_cbranch_execz 91                                         // 000000414294: BFA5005B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xc04>
	.long 0xd7010503                                           // 000000414298: D7010503
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 00000041429C: 02010308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004142A0: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s5                           // 0000004142A4: D5010004 00153F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000004142AC: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 0000004142B0: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004142B4: BF8701B2
	.long 0xd73c0002                                           // 0000004142B8: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 0000004142BC: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 0000004142C0: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 0000004142CC: 7E0A0280
	.long 0xd7006a0c                                           // 0000004142D0: D7006A0C
	v_cndmask_b32_e32 v1, s3, v2, vcc_lo                       // 0000004142D4: 02020403
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004142D8: BF870211
	v_add_co_ci_u32_e64 v13, null, s4, v3, vcc_lo              // 0000004142DC: D5207C0D 01AA0604
	v_add_nc_u32_e32 v6, v6, v4                                // 0000004142E4: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004142E8: BF870114
	.long 0xd73c0004                                           // 0000004142EC: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 0000004142F0: 02020882
	v_lshlrev_b32_e32 v11, 24, v6                              // 0000004142F4: 30160C98
	v_bfe_i32 v6, v6, 7, 1                                     // 0000004142F8: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414300: BF870093
	.long 0xd7006a02                                           // 000000414304: D7006A02
	v_cndmask_b32_e32 v1, v12, v4, vcc_lo                      // 000000414308: 0202090C
	v_add_co_ci_u32_e64 v3, null, v13, v5, vcc_lo              // 00000041430C: D5207C03 01AA0B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414314: BF870094
	v_ashrrev_i32_e32 v11, 22, v11                             // 000000414318: 34161696
	.long 0xd7006a04                                           // 00000041431C: D7006A04
	v_cndmask_b32_e32 v1, v12, v11, vcc_lo                     // 000000414320: 0202170C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000414324: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v13, v6, vcc_lo              // 000000414328: D5207C05 01AA0D0D
	.long 0xd7006a23                                           // 000000414330: D7006A23
	v_cndmask_b32_e32 v1, v12, v9, vcc_lo                      // 000000414334: 0202130C
	v_add_co_ci_u32_e64 v36, null, 0, v13, vcc_lo              // 000000414338: D5207C24 01AA1A80
	s_clause 0x17                                              // 000000414340: BF850017
	global_load_b32 v11, v[2:3], off                           // 000000414344: DC520000 0B7C0002
	global_load_b32 v18, v[2:3], off offset:128                // 00000041434C: DC520080 127C0002
	global_load_b32 v17, v[2:3], off offset:256                // 000000414354: DC520100 117C0002
	global_load_b32 v16, v[2:3], off offset:384                // 00000041435C: DC520180 107C0002
	global_load_b32 v15, v[2:3], off offset:512                // 000000414364: DC520200 0F7C0002
	global_load_b32 v14, v[2:3], off offset:640                // 00000041436C: DC520280 0E7C0002
	global_load_b32 v13, v[2:3], off offset:768                // 000000414374: DC520300 0D7C0002
	global_load_b32 v12, v[2:3], off offset:896                // 00000041437C: DC520380 0C7C0002
	global_load_b32 v30, v[4:5], off                           // 000000414384: DC520000 1E7C0004
	global_load_b32 v28, v[4:5], off offset:128                // 00000041438C: DC520080 1C7C0004
	global_load_b32 v26, v[4:5], off offset:256                // 000000414394: DC520100 1A7C0004
	global_load_b32 v24, v[4:5], off offset:384                // 00000041439C: DC520180 187C0004
	global_load_b32 v22, v[4:5], off offset:512                // 0000004143A4: DC520200 167C0004
	global_load_b32 v21, v[4:5], off offset:640                // 0000004143AC: DC520280 157C0004
	global_load_b32 v20, v[4:5], off offset:768                // 0000004143B4: DC520300 147C0004
	global_load_b32 v19, v[4:5], off offset:896                // 0000004143BC: DC520380 137C0004
	global_load_b32 v34, v[35:36], off                         // 0000004143C4: DC520000 227C0023
	global_load_b32 v33, v[35:36], off offset:128              // 0000004143CC: DC520080 217C0023
	global_load_b32 v32, v[35:36], off offset:256              // 0000004143D4: DC520100 207C0023
	global_load_b32 v31, v[35:36], off offset:384              // 0000004143DC: DC520180 1F7C0023
	global_load_b32 v29, v[35:36], off offset:512              // 0000004143E4: DC520200 1D7C0023
	global_load_b32 v27, v[35:36], off offset:640              // 0000004143EC: DC520280 1B7C0023
	global_load_b32 v25, v[35:36], off offset:768              // 0000004143F4: DC520300 197C0023
	global_load_b32 v23, v[35:36], off offset:896              // 0000004143FC: DC520380 177C0023
	s_or_b32 exec_lo, exec_lo, s2                              // 000000414404: 8C7E027E
	v_cmp_lt_i32_e32 vcc_lo, v1, v10                           // 000000414408: 7C821501
	s_and_saveexec_b32 s5, vcc_lo                              // 00000041440C: BE85206A
	s_cbranch_execz 93                                         // 000000414410: BFA5005D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xd88>
	.long 0xd7010202                                           // 000000414414: D7010202
	v_cndmask_b32_e32 v0, v8, v129, vcc_lo                     // 000000414418: 02010308
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000041441C: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s2                           // 000000414420: D5010003 00093F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000414428: 3404029F
	.long 0xd44c0002                                           // 00000041442C: D44C0002
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 000000414430: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414434: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s2                          // 000000414438: D5010005 000902FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v35, v5, v3      // 000000414444: CA200080 04220705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041444C: BF870114
	.long 0xd73c0005                                           // 000000414450: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000414454: 0202028A
	.long 0xd73c0002                                           // 000000414458: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000041445C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000414460: BF870223
	v_lshlrev_b32_e32 v4, 24, v35                              // 000000414464: 30084698
	v_bfe_i32 v36, v35, 7, 1                                   // 000000414468: D6110024 02050F23
	.long 0xd7000225                                           // 000000414470: D7000225
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 000000414474: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414478: BF870211
	v_add_co_ci_u32_e64 v6, null, s4, v6, s2                   // 00000041447C: D5207C06 000A0C04
	v_ashrrev_i32_e32 v35, 22, v4                              // 000000414484: 34460896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414488: BF870093
	.long 0xd7000204                                           // 00000041448C: D7000204
	v_cndmask_b32_e32 v1, v37, v2, vcc_lo                      // 000000414490: 02020525
	v_add_co_ci_u32_e64 v5, null, v6, v3, s2                   // 000000414494: D5207C05 000A0706
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041449C: BF870093
	.long 0xd7000223                                           // 0000004144A0: D7000223
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000004144A4: 02024725
	v_add_co_ci_u32_e64 v36, null, v6, v36, s2                 // 0000004144A8: D5207C24 000A4906
	.long 0xd7000225                                           // 0000004144B0: D7000225
	v_cndmask_b32_e32 v1, v37, v9, vcc_lo                      // 0000004144B4: 02021325
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004144B8: BF870001
	v_add_co_ci_u32_e64 v38, null, 0, v6, s2                   // 0000004144BC: D5207C26 000A0C80
	s_clause 0x17                                              // 0000004144C4: BF850017
	global_load_b32 v2, v[4:5], off                            // 0000004144C8: DC520000 027C0004
	global_load_b32 v81, v[4:5], off offset:128                // 0000004144D0: DC520080 517C0004
	global_load_b32 v78, v[4:5], off offset:256                // 0000004144D8: DC520100 4E7C0004
	global_load_b32 v75, v[4:5], off offset:384                // 0000004144E0: DC520180 4B7C0004
	global_load_b32 v72, v[4:5], off offset:512                // 0000004144E8: DC520200 487C0004
	global_load_b32 v69, v[4:5], off offset:640                // 0000004144F0: DC520280 457C0004
	global_load_b32 v51, v[4:5], off offset:768                // 0000004144F8: DC520300 337C0004
	global_load_b32 v44, v[4:5], off offset:896                // 000000414500: DC520380 2C7C0004
	global_load_b32 v3, v[35:36], off                          // 000000414508: DC520000 037C0023
	global_load_b32 v82, v[35:36], off offset:128              // 000000414510: DC520080 527C0023
	global_load_b32 v79, v[35:36], off offset:256              // 000000414518: DC520100 4F7C0023
	global_load_b32 v76, v[35:36], off offset:384              // 000000414520: DC520180 4C7C0023
	global_load_b32 v73, v[35:36], off offset:512              // 000000414528: DC520200 497C0023
	global_load_b32 v70, v[35:36], off offset:640              // 000000414530: DC520280 467C0023
	global_load_b32 v52, v[35:36], off offset:768              // 000000414538: DC520300 347C0023
	global_load_b32 v45, v[35:36], off offset:896              // 000000414540: DC520380 2D7C0023
	global_load_b32 v83, v[37:38], off                         // 000000414548: DC520000 537C0025
	global_load_b32 v80, v[37:38], off offset:128              // 000000414550: DC520080 507C0025
	global_load_b32 v77, v[37:38], off offset:256              // 000000414558: DC520100 4D7C0025
	global_load_b32 v74, v[37:38], off offset:384              // 000000414560: DC520180 4A7C0025
	global_load_b32 v71, v[37:38], off offset:512              // 000000414568: DC520200 477C0025
	global_load_b32 v68, v[37:38], off offset:640              // 000000414570: DC520280 447C0025
	global_load_b32 v50, v[37:38], off offset:768              // 000000414578: DC520300 327C0025
	global_load_b32 v43, v[37:38], off offset:896              // 000000414580: DC520380 2B7C0025
	s_or_b32 exec_lo, exec_lo, s5                              // 000000414588: 8C7E057E
	v_dual_mov_b32 v35, 0 :: v_dual_mov_b32 v36, 0             // 00000041458C: CA100080 23240080
	v_dual_mov_b32 v37, 0 :: v_dual_mov_b32 v38, 0             // 000000414594: CA100080 25260080
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v40, 0             // 00000041459C: CA100080 27280080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 0000004145A4: CA100080 292A0080
	s_ashr_i32 s27, s26, 31                                    // 0000004145AC: 861B9F1A
	s_and_saveexec_b32 s2, vcc_lo                              // 0000004145B0: BE82206A
	s_cbranch_execz 959                                        // 0000004145B4: BFA503BF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1cb4>
	v_dual_mov_b32 v35, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 0000004145B8: CA200080 230400C1
	v_dual_mov_b32 v37, 0 :: v_dual_and_b32 v6, 16, v0         // 0000004145C0: CA240080 25060090
	v_sub_nc_u32_e32 v46, 0, v10                               // 0000004145C8: 4C5C1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004145CC: BF870243
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v4, 31, v4         // 0000004145D0: CA240080 2704089F
	v_dual_mov_b32 v36, 0 :: v_dual_add_nc_u32 v5, 2, v1       // 0000004145D8: CA200080 24040282
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v47, 2, v8     // 0000004145E0: CA220080 262E1082
	v_lshl_or_b32 v48, v1, 5, v6                               // 0000004145E8: D6560030 04190B01
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v49, 2, v4     // 0000004145F0: CA220080 28300882
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 0000004145F8: CA100080 292A0080
	s_mov_b32 s5, 0                                            // 000000414600: BE850080
	s_movk_i32 s6, 0x1eee                                      // 000000414604: B0061EEE
	s_branch 881                                               // 000000414608: BFA00371 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1bd0>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000041460C: 8C7E077E
	s_waitcnt vmcnt(15)                                        // 000000414610: BF893FF7
	v_alignbit_b32 v84, v2, v3, 16                             // 000000414614: D6160054 02420702
	s_waitcnt vmcnt(14)                                        // 00000041461C: BF893BF7
	v_alignbit_b32 v81, v81, v82, 16                           // 000000414620: D6160051 0242A551
	ds_load_b128 v[1:4], v48                                   // 000000414628: DBFC0000 01000030
	s_waitcnt vmcnt(7)                                         // 000000414630: BF891FF7
	v_bfe_u32 v85, v83, 12, 16                                 // 000000414634: D6100055 02411953
	v_bfe_u32 v86, v83, 8, 16                                  // 00000041463C: D6100056 02411153
	v_bfe_u32 v88, v84, 12, 16                                 // 000000414644: D6100058 02411954
	v_bfe_u32 v82, v84, 8, 16                                  // 00000041464C: D6100052 02411154
	v_bfe_u32 v87, v83, 4, 16                                  // 000000414654: D6100057 02410953
	.long 0xd72c0055                                           // 00000041465C: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000414660: 0202AAFF 83DCD12D
	.long 0xd72c0056                                           // 000000414668: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000041466C: 0202ACFF 83DCD12D
	.long 0xd72c0058                                           // 000000414674: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 000000414678: 0202B0FF 83DCD12D
	.long 0xd72c0052                                           // 000000414680: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000414684: 0202A4FF 83DCD12D
	.long 0xd72c0057                                           // 00000041468C: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000414690: 0202AEFF 83DCD12D
	s_waitcnt vmcnt(6)                                         // 000000414698: BF891BF7
	v_bfe_u32 v90, v80, 12, 16                                 // 00000041469C: D610005A 02411950
	v_bfe_u32 v91, v81, 12, 16                                 // 0000004146A4: D610005B 02411951
	v_alignbit_b32 v78, v78, v79, 16                           // 0000004146AC: D616004E 02429F4E
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000004146B4: D6220055 03FD0155 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 0000004146C0: D6220056 03FD0156 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000004146CC: D6220058 03FD0158 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000004146D8: D6220052 03FD0152 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000004146E4: D6220057 03FD0157 00006400
	v_and_b32_e32 v85, 0xffff, v85                             // 0000004146F0: 36AAAAFF 0000FFFF
	v_alignbit_b32 v75, v75, v76, 16                           // 0000004146F8: D616004B 0242994B
	v_and_b32_e32 v88, 0xffff, v88                             // 000000414700: 36B0B0FF 0000FFFF
	v_alignbit_b32 v72, v72, v73, 16                           // 000000414708: D6160048 02429348
	v_alignbit_b32 v69, v69, v70, 16                           // 000000414710: D6160045 02428D45
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000414718: D6560055 05552156
	.long 0xd72c0056                                           // 000000414720: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 000000414724: 0202B6FF 83DCD12D
	v_lshl_or_b32 v82, v82, 16, v88                            // 00000041472C: D6560052 05612152
	v_bfe_u32 v88, v80, 4, 16                                  // 000000414734: D6100058 02410950
	v_alignbit_b32 v51, v51, v52, 16                           // 00000041473C: D6160033 02426933
	v_pk_fma_f16 v85, v85, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414744: CC0E0055 0BFC0D55 0000C931
	v_alignbit_b32 v44, v44, v45, 16                           // 000000414750: D616002C 02425B2C
	v_pk_fma_f16 v82, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414758: CC0E0052 0BFC0D52 0000C931
	v_and_b32_e32 v83, 0xffff, v83                             // 000000414764: 36A6A6FF 0000FFFF
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000041476C: D6220056 03FD0156 00006400
	v_add_nc_u32_e32 v5, 1, v5                                 // 000000414778: 4A0A0A81
	v_add_nc_u32_e32 v48, 32, v48                              // 00000041477C: 4A6060A0
	s_waitcnt lgkmcnt(0)                                       // 000000414780: BF89FC07
	v_dual_dot2acc_f32_f16 v42, v82, v1 :: v_dual_and_b32 v89, 0xffff, v84// 000000414784: CB240352 2A58A8FF 0000FFFF
	v_bfe_u32 v84, v84, 4, 16                                  // 000000414790: D6100054 02410954
	.long 0xd72c0053                                           // 000000414798: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000041479C: 0202A6FF 83DCD12D
	v_bfe_u32 v82, v80, 8, 16                                  // 0000004147A4: D6100052 02411150
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004147AC: BF870214
	.long 0xd72c0059                                           // 0000004147B0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 0000004147B4: 0202B2FF 83DCD12D
	.long 0xd72c0054                                           // 0000004147BC: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004147C0: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004147C8: BF870223
	.long 0xd72c0052                                           // 0000004147CC: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 0000004147D0: 0202A4FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 0000004147D8: D6220053 03FD0153 00006400
	v_sad_u8 v89, v89, 0, 0x6400                               // 0000004147E4: D6220059 03FD0159 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004147F0: BF870194
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000004147F4: D6220054 03FD0154 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 000000414800: 30A6A690
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000414804: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000414810: BF870194
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000414814: 30B2B290
	v_and_or_b32 v83, 0xffff, v87, v83                         // 000000414818: D6570053 054EAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000414824: BF870112
	v_and_or_b32 v84, 0xffff, v84, v89                         // 000000414828: D6570054 0566A8FF 0000FFFF
	v_pk_fma_f16 v83, v83, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414834: CC0E0053 0BFC0D53 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000414840: BF870092
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414844: CC0E0054 0BFC0D54 0000C931
	v_dot2acc_f32_f16 v42, v84, v2                             // 000000414850: 04540554
	v_bfe_u32 v84, v81, 8, 16                                  // 000000414854: D6100054 02411151
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041485C: BF8701A2
	v_dual_dot2acc_f32_f16 v42, v85, v3 :: v_dual_and_b32 v87, 0xffff, v81// 000000414860: CB240755 2A56A2FF 0000FFFF
	v_bfe_u32 v81, v81, 4, 16                                  // 00000041486C: D6100051 02410951
	.long 0xd72c0054                                           // 000000414874: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 000000414878: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414880: BF870213
	v_dot2acc_f32_f16 v42, v83, v4                             // 000000414884: 04540953
	.long 0xd72c0055                                           // 000000414888: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000041488C: 0202AEFF 83DCD12D
	.long 0xd72c0057                                           // 000000414894: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 000000414898: 0202B4FF 83DCD12D
	.long 0xd72c0051                                           // 0000004148A0: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 0000004148A4: 0202A2FF 83DCD12D
	s_waitcnt vmcnt(3)                                         // 0000004148AC: BF890FF7
	v_bfe_u32 v83, v71, 4, 16                                  // 0000004148B0: D6100053 02410947
	v_sad_u8 v84, v84, 0, 0x6400                               // 0000004148B8: D6220054 03FD0154 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 0000004148C4: D6220055 03FD0155 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 0000004148D0: D6220057 03FD0157 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004148DC: D6220051 03FD0151 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004148E8: BF870193
	v_lshlrev_b32_e32 v85, 16, v85                             // 0000004148EC: 30AAAA90
	v_and_b32_e32 v87, 0xffff, v87                             // 0000004148F0: 36AEAEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004148F8: BF870112
	v_and_or_b32 v81, 0xffff, v81, v85                         // 0000004148FC: D6570051 0556A2FF 0000FFFF
	v_lshl_or_b32 v79, v82, 16, v87                            // 000000414908: D656004F 055D2152
	v_bfe_u32 v85, v78, 12, 16                                 // 000000414910: D6100055 0241194E
	v_bfe_u32 v87, v77, 8, 16                                  // 000000414918: D6100057 0241114D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414920: BF870214
	v_pk_fma_f16 v81, v81, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414924: CC0E0051 0BFC0D51 0000C931
	v_pk_fma_f16 v79, v79, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414930: CC0E004F 0BFC0D4F 0000C931
	v_and_b32_e32 v86, 0xffff, v86                             // 00000041493C: 36ACACFF 0000FFFF
	.long 0xd72c0055                                           // 000000414944: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 000000414948: 0202AAFF 83DCD12D
	.long 0xd72c0057                                           // 000000414950: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 000000414954: 0202AEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041495C: BF870243
	v_lshl_or_b32 v84, v84, 16, v86                            // 000000414960: D6560054 05592154
	.long 0xd72c0056                                           // 000000414968: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000041496C: 0202B0FF 83DCD12D
	v_and_b32_e32 v88, 0xffff, v77                             // 000000414974: 36B09AFF 0000FFFF
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000041497C: D6220055 03FD0155 00006400
	v_pk_fma_f16 v84, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414988: CC0E0054 0BFC0D54 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000414994: BF8701A3
	.long 0xd72c0058                                           // 000000414998: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000041499C: 0202B0FF 83DCD12D
	v_sad_u8 v82, v86, 0, 0x6400                               // 0000004149A4: D6220052 03FD0156 00006400
	v_dual_dot2acc_f32_f16 v41, v84, v1 :: v_dual_and_b32 v80, 0xffff, v80// 0000004149B0: CB240354 2950A0FF 0000FFFF
	v_bfe_u32 v84, v77, 12, 16                                 // 0000004149BC: D6100054 0241194D
	v_and_b32_e32 v85, 0xffff, v85                             // 0000004149C4: 36AAAAFF 0000FFFF
	v_bfe_u32 v77, v77, 4, 16                                  // 0000004149CC: D610004D 0241094D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000004149D4: BF870234
	v_dot2acc_f32_f16 v41, v81, v2                             // 0000004149D8: 04520551
	.long 0xd72c0050                                           // 0000004149DC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 0000004149E0: 0202A0FF 83DCD12D
	.long 0xd72c0054                                           // 0000004149E8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 0000004149EC: 0202A8FF 83DCD12D
	.long 0xd72c004d                                           // 0000004149F4: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v77, vcc_lo              // 0000004149F8: 02029AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414A00: BF870214
	v_dot2acc_f32_f16 v41, v79, v3                             // 000000414A04: 0452074F
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000414A08: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414A14: BF870214
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000414A18: D6220054 03FD0154 00006400
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000414A24: D622004D 03FD014D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000414A30: BF870193
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000414A34: 30A0A090
	v_and_b32_e32 v84, 0xffff, v84                             // 000000414A38: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000414A40: BF870122
	v_and_or_b32 v80, 0xffff, v82, v80                         // 000000414A44: D6570050 0542A4FF 0000FFFF
	v_bfe_u32 v82, v78, 8, 16                                  // 000000414A50: D6100052 0241114E
	v_pk_fma_f16 v80, v80, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414A58: CC0E0050 0BFC0D50 0000C931
	v_and_b32_e32 v86, 0xffff, v78                             // 000000414A64: 36AC9CFF 0000FFFF
	v_bfe_u32 v78, v78, 4, 16                                  // 000000414A6C: D610004E 0241094E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414A74: BF870214
	.long 0xd72c0052                                           // 000000414A78: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000414A7C: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v41, v80, v4                             // 000000414A84: 04520950
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414A88: BF870214
	.long 0xd72c0056                                           // 000000414A8C: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 000000414A90: 0202ACFF 83DCD12D
	.long 0xd72c004e                                           // 000000414A98: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000414A9C: 02029CFF 83DCD12D
	v_bfe_u32 v80, v74, 12, 16                                 // 000000414AA4: D6100050 0241194A
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000414AAC: D6220052 03FD0152 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000414AB8: BF870232
	.long 0xd72c0050                                           // 000000414ABC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000414AC0: 0202A0FF 83DCD12D
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000414AC8: D6220056 03FD0156 00006400
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000414AD4: D622004E 03FD014E 00006400
	v_lshl_or_b32 v82, v82, 16, v85                            // 000000414AE0: D6560052 05552152
	v_sad_u8 v85, v87, 0, 0x6400                               // 000000414AE8: D6220055 03FD0157 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000414AF4: BF870194
	v_lshlrev_b32_e32 v86, 16, v86                             // 000000414AF8: 30ACAC90
	v_pk_fma_f16 v81, v82, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414AFC: CC0E0051 0BFC0D52 0000C931
	v_sad_u8 v82, v88, 0, 0x6400                               // 000000414B08: D6220052 03FD0158 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000414B14: BF870214
	v_lshl_or_b32 v84, v85, 16, v84                            // 000000414B18: D6560054 05512155
	v_and_or_b32 v78, 0xffff, v78, v86                         // 000000414B20: D657004E 055A9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000414B2C: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v40, v81, v1                             // 000000414B38: 04500351
	v_lshlrev_b32_e32 v76, 16, v82                             // 000000414B3C: 3098A490
	v_pk_fma_f16 v79, v84, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414B40: CC0E004F 0BFC0D54 0000C931
	v_pk_fma_f16 v78, v78, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414B4C: CC0E004E 0BFC0D4E 0000C931
	v_bfe_u32 v81, v75, 12, 16                                 // 000000414B58: D6100051 0241194B
	v_and_b32_e32 v82, 0xffff, v74                             // 000000414B60: 36A494FF 0000FFFF
	v_and_or_b32 v76, 0xffff, v77, v76                         // 000000414B68: D657004C 05329AFF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 000000414B74: 36A0A0FF 0000FFFF
	v_dot2acc_f32_f16 v40, v78, v2                             // 000000414B7C: 0450054E
	.long 0xd72c004d                                           // 000000414B80: D72C004D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000414B84: 0202A2FF 83DCD12D
	v_bfe_u32 v78, v75, 8, 16                                  // 000000414B8C: D610004E 0241114B
	v_pk_fma_f16 v76, v76, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414B94: CC0E004C 0BFC0D4C 0000C931
	v_bfe_u32 v81, v74, 8, 16                                  // 000000414BA0: D6100051 0241114A
	v_dot2acc_f32_f16 v40, v79, v3                             // 000000414BA8: 0450074F
	v_bfe_u32 v79, v75, 4, 16                                  // 000000414BAC: D610004F 0241094B
	v_and_b32_e32 v75, 0xffff, v75                             // 000000414BB4: 369696FF 0000FFFF
	.long 0xd72c004e                                           // 000000414BBC: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000414BC0: 02029CFF 83DCD12D
	v_sad_u8 v77, v77, 0, 0x6400                               // 000000414BC8: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v40, v76, v4                             // 000000414BD4: 0450094C
	v_bfe_u32 v74, v74, 4, 16                                  // 000000414BD8: D610004A 0241094A
	.long 0xd72c004b                                           // 000000414BE0: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000414BE4: 020296FF 83DCD12D
	.long 0xd72c004f                                           // 000000414BEC: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000414BF0: 02029EFF 83DCD12D
	.long 0xd72c0052                                           // 000000414BF8: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000414BFC: 0202A4FF 83DCD12D
	v_and_b32_e32 v77, 0xffff, v77                             // 000000414C04: 369A9AFF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000414C0C: D622004E 03FD014E 00006400
	.long 0xd72c0051                                           // 000000414C18: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000414C1C: 0202A2FF 83DCD12D
	.long 0xd72c004a                                           // 000000414C24: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000414C28: 020294FF 83DCD12D
	s_waitcnt vmcnt(2)                                         // 000000414C30: BF890BF7
	v_bfe_u32 v76, v68, 4, 16                                  // 000000414C34: D610004C 02410944
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000414C3C: D622004B 03FD014B 00006400
	v_lshl_or_b32 v77, v78, 16, v77                            // 000000414C48: D656004D 0535214E
	v_sad_u8 v78, v79, 0, 0x6400                               // 000000414C50: D622004E 03FD014F 00006400
	v_sad_u8 v79, v82, 0, 0x6400                               // 000000414C5C: D622004F 03FD0152 00006400
	v_bfe_u32 v82, v71, 8, 16                                  // 000000414C68: D6100052 02411147
	v_lshlrev_b32_e32 v75, 16, v75                             // 000000414C70: 30969690
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000414C74: D6220051 03FD0151 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000414C80: D622004A 03FD014A 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 000000414C8C: 309E9E90
	v_pk_fma_f16 v77, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414C90: CC0E004D 0BFC0D4D 0000C931
	v_and_or_b32 v73, 0xffff, v78, v75                         // 000000414C9C: D6570049 052E9CFF 0000FFFF
	v_bfe_u32 v78, v72, 12, 16                                 // 000000414CA8: D610004E 02411948
	v_lshl_or_b32 v75, v81, 16, v80                            // 000000414CB0: D656004B 05412151
	v_and_or_b32 v74, 0xffff, v74, v79                         // 000000414CB8: D657004A 053E94FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v72                             // 000000414CC4: 369E90FF 0000FFFF
	v_bfe_u32 v80, v72, 8, 16                                  // 000000414CCC: D6100050 02411148
	.long 0xd72c004e                                           // 000000414CD4: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v78, vcc_lo              // 000000414CD8: 02029CFF 83DCD12D
	v_bfe_u32 v72, v72, 4, 16                                  // 000000414CE0: D6100048 02410948
	v_bfe_u32 v81, v71, 12, 16                                 // 000000414CE8: D6100051 02411947
	.long 0xd72c004f                                           // 000000414CF0: D72C004F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v79, vcc_lo              // 000000414CF4: 02029EFF 83DCD12D
	.long 0xd72c0050                                           // 000000414CFC: D72C0050
	v_cndmask_b32_e32 v1, 0x83dcd12d, v80, vcc_lo              // 000000414D00: 0202A0FF 83DCD12D
	.long 0xd72c0052                                           // 000000414D08: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 000000414D0C: 0202A4FF 83DCD12D
	.long 0xd72c0048                                           // 000000414D14: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000414D18: 020290FF 83DCD12D
	.long 0xd72c0051                                           // 000000414D20: D72C0051
	v_cndmask_b32_e32 v1, 0x83dcd12d, v81, vcc_lo              // 000000414D24: 0202A2FF 83DCD12D
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000414D2C: D622004E 03FD014E 00006400
	v_pk_fma_f16 v73, v73, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414D38: CC0E0049 0BFC0D49 0000C931
	v_dot2acc_f32_f16 v39, v77, v1                             // 000000414D44: 044E034D
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000414D48: D622004F 03FD014F 00006400
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000414D54: D6220050 03FD0150 00006400
	v_and_b32_e32 v78, 0xffff, v78                             // 000000414D60: 369C9CFF 0000FFFF
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000414D68: D6220048 03FD0148 00006400
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000414D74: D6220051 03FD0151 00006400
	v_lshlrev_b32_e32 v79, 16, v79                             // 000000414D80: 309E9E90
	v_pk_fma_f16 v75, v75, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414D84: CC0E004B 0BFC0D4B 0000C931
	v_lshl_or_b32 v77, v80, 16, v78                            // 000000414D90: D656004D 05392150
	v_sad_u8 v80, v82, 0, 0x6400                               // 000000414D98: D6220050 03FD0152 00006400
	v_dot2acc_f32_f16 v39, v73, v2                             // 000000414DA4: 044E0549
	v_and_or_b32 v72, 0xffff, v72, v79                         // 000000414DA8: D6570048 053E90FF 0000FFFF
	v_and_b32_e32 v79, 0xffff, v81                             // 000000414DB4: 369EA2FF 0000FFFF
	v_pk_fma_f16 v73, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414DBC: CC0E0049 0BFC0D4D 0000C931
	v_pk_fma_f16 v74, v74, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414DC8: CC0E004A 0BFC0D4A 0000C931
	v_dot2acc_f32_f16 v39, v75, v3                             // 000000414DD4: 044E074B
	v_pk_fma_f16 v72, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414DD8: CC0E0048 0BFC0D48 0000C931
	v_lshl_or_b32 v77, v80, 16, v79                            // 000000414DE4: D656004D 053D2150
	v_dot2acc_f32_f16 v38, v73, v1                             // 000000414DEC: 044C0349
	v_bfe_u32 v75, v68, 8, 16                                  // 000000414DF0: D610004B 02411144
	v_dot2acc_f32_f16 v39, v74, v4                             // 000000414DF8: 044E094A
	v_bfe_u32 v74, v68, 12, 16                                 // 000000414DFC: D610004A 02411944
	v_pk_fma_f16 v70, v77, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414E04: CC0E0046 0BFC0D4D 0000C931
	v_dot2acc_f32_f16 v38, v72, v2                             // 000000414E10: 044C0548
	v_bfe_u32 v72, v69, 12, 16                                 // 000000414E14: D6100048 02411945
	v_and_b32_e32 v68, 0xffff, v68                             // 000000414E1C: 368888FF 0000FFFF
	v_and_b32_e32 v73, 0xffff, v69                             // 000000414E24: 36928AFF 0000FFFF
	.long 0xd72c004c                                           // 000000414E2C: D72C004C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000414E30: 020298FF 83DCD12D
	v_dot2acc_f32_f16 v38, v70, v3                             // 000000414E38: 044C0746
	v_bfe_u32 v70, v69, 8, 16                                  // 000000414E3C: D6100046 02411145
	.long 0xd72c0048                                           // 000000414E44: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000414E48: 020290FF 83DCD12D
	.long 0xd72c0044                                           // 000000414E50: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000414E54: 020288FF 83DCD12D
	v_bfe_u32 v69, v69, 4, 16                                  // 000000414E5C: D6100045 02410945
	.long 0xd72c0049                                           // 000000414E64: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000414E68: 020292FF 83DCD12D
	.long 0xd72c0046                                           // 000000414E70: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000414E74: 02028CFF 83DCD12D
	.long 0xd72c004a                                           // 000000414E7C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000414E80: 020294FF 83DCD12D
	v_sad_u8 v76, v76, 0, 0x6400                               // 000000414E88: D622004C 03FD014C 00006400
	.long 0xd72c0045                                           // 000000414E94: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v69, vcc_lo              // 000000414E98: 02028AFF 83DCD12D
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000414EA0: D6220048 03FD0148 00006400
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000414EAC: D6220044 03FD0144 00006400
	.long 0xd72c004b                                           // 000000414EB8: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000414EBC: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000414EC4: D6220049 03FD0149 00006400
	v_sad_u8 v70, v70, 0, 0x6400                               // 000000414ED0: D6220046 03FD0146 00006400
	v_and_b32_e32 v72, 0xffff, v72                             // 000000414EDC: 369090FF 0000FFFF
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000414EE4: 30888890
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000414EE8: D622004A 03FD014A 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000414EF4: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000414F00: 30929290
	v_lshl_or_b32 v70, v70, 16, v72                            // 000000414F04: D6560046 05212146
	v_and_or_b32 v52, 0xffff, v76, v68                         // 000000414F0C: D6570034 051298FF 0000FFFF
	v_sad_u8 v75, v75, 0, 0x6400                               // 000000414F18: D622004B 03FD014B 00006400
	.long 0xd72c004e                                           // 000000414F24: D72C004E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 000000414F28: 0202A6FF 83DCD12D
	v_and_or_b32 v69, 0xffff, v69, v73                         // 000000414F30: D6570045 05268AFF 0000FFFF
	v_pk_fma_f16 v68, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414F3C: CC0E0044 0BFC0D46 0000C931
	v_pk_fma_f16 v52, v52, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414F48: CC0E0034 0BFC0D34 0000C931
	v_and_b32_e32 v74, 0xffff, v74                             // 000000414F54: 369494FF 0000FFFF
	s_waitcnt vmcnt(1)                                         // 000000414F5C: BF8907F7
	v_bfe_u32 v73, v50, 12, 16                                 // 000000414F60: D6100049 02411932
	v_pk_fma_f16 v69, v69, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414F68: CC0E0045 0BFC0D45 0000C931
	v_dual_dot2acc_f32_f16 v37, v68, v1 :: v_dual_and_b32 v68, 0xffff, v51// 000000414F74: CB240344 254466FF 0000FFFF
	v_lshl_or_b32 v72, v75, 16, v74                            // 000000414F80: D6560048 0529214B
	v_bfe_u32 v74, v51, 8, 16                                  // 000000414F88: D610004A 02411133
	.long 0xd72c0049                                           // 000000414F90: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 000000414F94: 020292FF 83DCD12D
	v_bfe_u32 v75, v50, 8, 16                                  // 000000414F9C: D610004B 02411132
	.long 0xd72c0044                                           // 000000414FA4: D72C0044
	v_cndmask_b32_e32 v1, 0x83dcd12d, v68, vcc_lo              // 000000414FA8: 020288FF 83DCD12D
	v_pk_fma_f16 v70, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000414FB0: CC0E0046 0BFC0D48 0000C931
	v_bfe_u32 v72, v51, 12, 16                                 // 000000414FBC: D6100048 02411933
	v_bfe_u32 v51, v51, 4, 16                                  // 000000414FC4: D6100033 02410933
	v_dot2acc_f32_f16 v37, v69, v2                             // 000000414FCC: 044A0545
	.long 0xd72c0045                                           // 000000414FD0: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000414FD4: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000414FDC: D6220049 03FD0149 00006400
	.long 0xd72c0048                                           // 000000414FE8: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 000000414FEC: 020290FF 83DCD12D
	.long 0xd72c0033                                           // 000000414FF4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000414FF8: 020266FF 83DCD12D
	v_sad_u8 v68, v68, 0, 0x6400                               // 000000415000: D6220044 03FD0144 00006400
	.long 0xd72c004a                                           // 00000041500C: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 000000415010: 020294FF 83DCD12D
	v_and_b32_e32 v73, 0xffff, v73                             // 000000415018: 369292FF 0000FFFF
	v_dot2acc_f32_f16 v37, v70, v3                             // 000000415020: 044A0746
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000415024: D6220045 03FD0145 00006400
	v_lshlrev_b32_e32 v68, 16, v68                             // 000000415030: 30888890
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000415034: D6220048 03FD0148 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 000000415040: D6220033 03FD0133 00006400
	v_bfe_u32 v70, v44, 12, 16                                 // 00000041504C: D6100046 0241192C
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000415054: D622004A 03FD014A 00006400
	v_bfe_u32 v75, v50, 4, 16                                  // 000000415060: D610004B 02410932
	v_and_b32_e32 v72, 0xffff, v72                             // 000000415068: 369090FF 0000FFFF
	v_and_or_b32 v51, 0xffff, v51, v68                         // 000000415070: D6570033 051266FF 0000FFFF
	v_lshl_or_b32 v68, v69, 16, v73                            // 00000041507C: D6560044 05252145
	.long 0xd72c0046                                           // 000000415084: D72C0046
	v_cndmask_b32_e32 v1, 0x83dcd12d, v70, vcc_lo              // 000000415088: 02028CFF 83DCD12D
	v_bfe_u32 v73, v44, 8, 16                                  // 000000415090: D6100049 0241112C
	v_and_b32_e32 v50, 0xffff, v50                             // 000000415098: 366464FF 0000FFFF
	v_lshl_or_b32 v72, v74, 16, v72                            // 0000004150A0: D6560048 0521214A
	s_waitcnt vmcnt(0)                                         // 0000004150A8: BF8903F7
	v_bfe_u32 v74, v43, 12, 16                                 // 0000004150AC: D610004A 0241192B
	.long 0xd72c0045                                           // 0000004150B4: D72C0045
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 0000004150B8: 020296FF 83DCD12D
	.long 0xd72c0049                                           // 0000004150C0: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 0000004150C4: 020292FF 83DCD12D
	.long 0xd72c002d                                           // 0000004150CC: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 0000004150D0: 020264FF 83DCD12D
	v_sad_u8 v70, v70, 0, 0x6400                               // 0000004150D8: D6220046 03FD0146 00006400
	v_bfe_u32 v75, v43, 8, 16                                  // 0000004150E4: D610004B 0241112B
	.long 0xd72c004a                                           // 0000004150EC: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 0000004150F0: 020294FF 83DCD12D
	v_pk_fma_f16 v50, v72, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004150F8: CC0E0032 0BFC0D48 0000C931
	v_pk_fma_f16 v51, v51, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000415104: CC0E0033 0BFC0D33 0000C931
	v_and_b32_e32 v70, 0xffff, v70                             // 000000415110: 368C8CFF 0000FFFF
	v_sad_u8 v73, v73, 0, 0x6400                               // 000000415118: D6220049 03FD0149 00006400
	.long 0xd72c004b                                           // 000000415124: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 000000415128: 020296FF 83DCD12D
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000415130: D622002D 03FD012D 00006400
	v_sad_u8 v69, v69, 0, 0x6400                               // 00000041513C: D6220045 03FD0145 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 000000415148: D622004A 03FD014A 00006400
	v_lshl_or_b32 v70, v73, 16, v70                            // 000000415154: D6560046 05192149
	v_dot2acc_f32_f16 v36, v50, v1                             // 00000041515C: 04480332
	v_lshlrev_b32_e32 v45, 16, v45                             // 000000415160: 305A5A90
	v_pk_fma_f16 v68, v68, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000415164: CC0E0044 0BFC0D44 0000C931
	v_and_b32_e32 v73, 0xffff, v74                             // 000000415170: 369294FF 0000FFFF
	v_sad_u8 v74, v75, 0, 0x6400                               // 000000415178: D622004A 03FD014B 00006400
	v_pk_fma_f16 v50, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000415184: CC0E0032 0BFC0D46 0000C931
	v_dot2acc_f32_f16 v36, v51, v2                             // 000000415190: 04480533
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000415194: D622004E 03FD014E 00006400
	v_and_b32_e32 v72, 0xffff, v44                             // 0000004151A0: 369058FF 0000FFFF
	v_lshl_or_b32 v70, v74, 16, v73                            // 0000004151A8: D6560046 0525214A
	v_dual_dot2acc_f32_f16 v35, v50, v1 :: v_dual_mov_b32 v74, v31// 0000004151B0: CB100332 234A011F
	v_and_or_b32 v1, 0xffff, v69, v45                          // 0000004151B8: D6570001 04B68AFF 0000FFFF
	v_dot2acc_f32_f16 v36, v68, v3                             // 0000004151C4: 04480744
	v_mov_b32_e32 v50, v25                                     // 0000004151C8: 7E640319
	v_bfe_u32 v44, v44, 4, 16                                  // 0000004151CC: D610002C 0241092C
	v_bfe_u32 v76, v43, 4, 16                                  // 0000004151D4: D610004C 0241092B
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 0000004151DC: CC0E0001 0BFC0D01 0000C931
	v_and_b32_e32 v71, 0xffff, v71                             // 0000004151E8: 368E8EFF 0000FFFF
	v_and_b32_e32 v43, 0xffff, v43                             // 0000004151F0: 365656FF 0000FFFF
	.long 0xd72c002c                                           // 0000004151F8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 0000004151FC: 020258FF 83DCD12D
	v_pk_fma_f16 v45, v70, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000415204: CC0E002D 0BFC0D46 0000C931
	v_dot2acc_f32_f16 v36, v1, v4                              // 000000415210: 04480901
	.long 0xd72c0047                                           // 000000415214: D72C0047
	v_cndmask_b32_e32 v1, 0x83dcd12d, v71, vcc_lo              // 000000415218: 02028EFF 83DCD12D
	.long 0xd72c002b                                           // 000000415220: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000415224: 020256FF 83DCD12D
	v_dual_mov_b32 v80, v33 :: v_dual_dot2acc_f32_f16 v37, v52, v4// 00000041522C: CA180121 50240934
	v_mov_b32_e32 v52, v20                                     // 000000415234: 7E680314
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000415238: D622002C 03FD012C 00006400
	v_dual_mov_b32 v51, v13 :: v_dual_mov_b32 v68, v27         // 000000415244: CA10010D 3344011B
	v_sad_u8 v71, v71, 0, 0x6400                               // 00000041524C: D6220047 03FD0147 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000415258: D622002B 03FD012B 00006400
	v_dual_mov_b32 v70, v21 :: v_dual_mov_b32 v69, v14         // 000000415264: CA100115 4644010E
	v_mov_b32_e32 v73, v22                                     // 00000041526C: 7E920316
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000415270: BF870214
	v_lshlrev_b32_e32 v71, 16, v71                             // 000000415274: 308E8E90
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000415278: 30565690
	v_mov_b32_e32 v77, v32                                     // 00000041527C: 7E9A0320
	v_mov_b32_e32 v79, v26                                     // 000000415280: 7E9E031A
	v_dual_mov_b32 v81, v18 :: v_dual_mov_b32 v20, v61         // 000000415284: CA100112 5114013D
	v_and_or_b32 v71, 0xffff, v78, v71                         // 00000041528C: D6570047 051E9CFF 0000FFFF
	v_dual_mov_b32 v75, v16 :: v_dual_mov_b32 v78, v17         // 000000415298: CA100110 4B4E0111
	v_dual_mov_b32 v83, v34 :: v_dual_mov_b32 v22, v63         // 0000004152A0: CA100122 5316013F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004152A8: BF870243
	v_pk_fma_f16 v71, v71, s6, 0xc931 op_sel_hi:[1,0,0]        // 0000004152AC: CC0E0047 0BFC0D47 0000C931
	v_dual_mov_b32 v25, v61 :: v_dual_mov_b32 v16, v56         // 0000004152B8: CA10013D 19100138
	v_mov_b32_e32 v13, v53                                     // 0000004152C0: 7E1A0335
	v_dual_mov_b32 v27, v62 :: v_dual_mov_b32 v32, v65         // 0000004152C4: CA10013E 1B200141
	v_dual_dot2acc_f32_f16 v38, v71, v4 :: v_dual_mov_b32 v71, v29// 0000004152CC: CB100947 2646011D
	.long 0xd72c0048                                           // 0000004152D4: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v72, vcc_lo              // 0000004152D8: 020290FF 83DCD12D
	v_dual_mov_b32 v21, v62 :: v_dual_mov_b32 v26, v65         // 0000004152E0: CA10013E 151A0141
	v_dual_mov_b32 v29, v63 :: v_dual_mov_b32 v18, v60         // 0000004152E8: CA10013F 1D12013C
	v_dual_mov_b32 v31, v64 :: v_dual_mov_b32 v34, v67         // 0000004152F0: CA100140 1F220143
	v_mov_b32_e32 v82, v28                                     // 0000004152F8: 7EA4031C
	v_sad_u8 v72, v72, 0, 0x6400                               // 0000004152FC: D6220048 03FD0148 00006400
	v_dual_mov_b32 v14, v54 :: v_dual_mov_b32 v17, v57         // 000000415308: CA100136 0E100139
	v_mov_b32_e32 v33, v66                                     // 000000415310: 7E420342
	v_mov_b32_e32 v28, v66                                     // 000000415314: 7E380342
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415318: BF870094
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000041531C: 30909090
	v_and_or_b32 v44, 0xffff, v44, v72                         // 000000415320: D657002C 052258FF 0000FFFF
	.long 0xd72c0048                                           // 00000041532C: D72C0048
	v_cndmask_b32_e32 v1, 0x83dcd12d, v76, vcc_lo              // 000000415330: 020298FF 83DCD12D
	v_mov_b32_e32 v76, v24                                     // 000000415338: 7E980318
	v_mov_b32_e32 v24, v64                                     // 00000041533C: 7E300340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000415340: BF870214
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 000000415344: CC0E002C 0BFC0D2C 0000C931
	v_sad_u8 v72, v72, 0, 0x6400                               // 000000415350: D6220048 03FD0148 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000041535C: BF870232
	v_dot2acc_f32_f16 v35, v44, v2                             // 000000415360: 0446052C
	v_mov_b32_e32 v44, v12                                     // 000000415364: 7E58030C
	v_mov_b32_e32 v12, v6                                      // 000000415368: 7E180306
	v_and_or_b32 v43, 0xffff, v72, v43                         // 00000041536C: D657002B 04AE90FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000415378: BF870004
	v_dot2acc_f32_f16 v35, v45, v3                             // 00000041537C: 0446072D
	v_add_nc_u32_e32 v3, v46, v5                               // 000000415380: 4A060B2E
	v_mov_b32_e32 v45, v19                                     // 000000415384: 7E5A0313
	v_mov_b32_e32 v72, v15                                     // 000000415388: 7E90030F
	v_pk_fma_f16 v2, v43, s6, 0xc931 op_sel_hi:[1,0,0]         // 00000041538C: CC0E0002 0BFC0D2B 0000C931
	v_mov_b32_e32 v43, v23                                     // 000000415398: 7E560317
	v_cmp_eq_u32_e32 vcc_lo, 2, v3                             // 00000041539C: 7C940682
	v_mov_b32_e32 v3, v30                                      // 0000004153A0: 7E06031E
	v_mov_b32_e32 v23, v59                                     // 0000004153A4: 7E2E033B
	v_dual_dot2acc_f32_f16 v35, v2, v4 :: v_dual_mov_b32 v2, v11// 0000004153A8: CB100902 2302010B
	v_mov_b32_e32 v19, v59                                     // 0000004153B0: 7E26033B
	v_mov_b32_e32 v15, v55                                     // 0000004153B4: 7E1E0337
	v_dual_mov_b32 v30, v67 :: v_dual_mov_b32 v11, v58         // 0000004153B8: CA100143 1E0A013A
	s_or_b32 s5, vcc_lo, s5                                    // 0000004153C0: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004153C4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000004153C8: 917E057E
	s_cbranch_execz 56                                         // 0000004153CC: BFA50038 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1cb0>
	s_mov_b32 s7, exec_lo                                      // 0000004153D0: BE87007E
	.long 0xd4c1007e                                           // 0000004153D4: D4C1007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000004153D8: 02021505
	s_cbranch_execz 64651                                      // 0000004153DC: BFA5FC8B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe0c>
	v_ashrrev_i32_e32 v6, 31, v5                               // 0000004153E0: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004153E4: BF870091
	.long 0xd73c0035                                           // 0000004153E8: D73C0035
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 0000004153EC: 02020A8A
	.long 0xd7006a01                                           // 0000004153F0: D7006A01
	v_cndmask_b32_e32 v1, s3, v53, vcc_lo                      // 0000004153F4: 02026A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004153F8: BF870111
	v_add_co_ci_u32_e64 v4, null, s4, v54, vcc_lo              // 0000004153FC: D5207C04 01AA6C04
	.long 0xd7006a3d                                           // 000000415404: D7006A3D
	v_cndmask_b32_e32 v1, v1, v49, vcc_lo                      // 000000415408: 02026301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041540C: BF8700A1
	v_add_co_ci_u32_e64 v62, null, 0, v4, vcc_lo               // 000000415410: D5207C3E 01AA0880
	.long 0xd7006a54                                           // 000000415418: D7006A54
	v_cndmask_b32_e32 v1, v1, v47, vcc_lo                      // 00000041541C: 02025F01
	v_add_co_ci_u32_e64 v85, null, 0, v4, vcc_lo               // 000000415420: D5207C55 01AA0880
	s_clause 0xf                                               // 000000415428: BF85000F
	global_load_b32 v58, v[61:62], off                         // 00000041542C: DC520000 3A7C003D
	global_load_b32 v60, v[61:62], off offset:128              // 000000415434: DC520080 3C7C003D
	global_load_b32 v57, v[61:62], off offset:256              // 00000041543C: DC520100 397C003D
	global_load_b32 v56, v[61:62], off offset:384              // 000000415444: DC520180 387C003D
	global_load_b32 v55, v[61:62], off offset:512              // 00000041544C: DC520200 377C003D
	global_load_b32 v54, v[61:62], off offset:640              // 000000415454: DC520280 367C003D
	global_load_b32 v53, v[61:62], off offset:768              // 00000041545C: DC520300 357C003D
	global_load_b32 v6, v[61:62], off offset:896               // 000000415464: DC520380 067C003D
	global_load_b32 v67, v[84:85], off                         // 00000041546C: DC520000 437C0054
	global_load_b32 v66, v[84:85], off offset:128              // 000000415474: DC520080 427C0054
	global_load_b32 v65, v[84:85], off offset:256              // 00000041547C: DC520100 417C0054
	global_load_b32 v64, v[84:85], off offset:384              // 000000415484: DC520180 407C0054
	global_load_b32 v63, v[84:85], off offset:512              // 00000041548C: DC520200 3F7C0054
	global_load_b32 v62, v[84:85], off offset:640              // 000000415494: DC520280 3E7C0054
	global_load_b32 v61, v[84:85], off offset:768              // 00000041549C: DC520300 3D7C0054
	global_load_b32 v59, v[84:85], off offset:896              // 0000004154A4: DC520380 3B7C0054
	s_branch 64599                                             // 0000004154AC: BFA0FC57 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0xe0c>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000004154B0: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004154B4: BF870009
	s_or_b32 exec_lo, exec_lo, s2                              // 0000004154B8: 8C7E027E
	s_waitcnt vmcnt(23)                                        // 0000004154BC: BF895FF7
	v_dual_mov_b32 v1, v42 :: v_dual_mov_b32 v2, v41           // 0000004154C0: CA10012A 01020129
	s_waitcnt vmcnt(15)                                        // 0000004154C8: BF893FF7
	v_dual_mov_b32 v3, v40 :: v_dual_mov_b32 v10, v39          // 0000004154CC: CA100128 030A0127
	v_dual_mov_b32 v4, v38 :: v_dual_mov_b32 v5, v37           // 0000004154D4: CA100126 04040125
	v_dual_mov_b32 v6, v36 :: v_dual_mov_b32 v11, v35          // 0000004154DC: CA100124 060A0123
	s_mov_b32 s2, 0x76543210                                   // 0000004154E4: BE8200FF 76543210
	s_waitcnt vmcnt(0)                                         // 0000004154EC: BF8903F7
	v_permlanex16_b32 v1, v1, s2, 0xfedcba98                   // 0000004154F0: D65C0001 03FC0501 FEDCBA98
	v_permlanex16_b32 v2, v2, s2, 0xfedcba98                   // 0000004154FC: D65C0002 03FC0502 FEDCBA98
	v_permlanex16_b32 v3, v3, s2, 0xfedcba98                   // 000000415508: D65C0003 03FC0503 FEDCBA98
	v_permlanex16_b32 v10, v10, s2, 0xfedcba98                 // 000000415514: D65C000A 03FC050A FEDCBA98
	v_permlanex16_b32 v4, v4, s2, 0xfedcba98                   // 000000415520: D65C0004 03FC0504 FEDCBA98
	v_permlanex16_b32 v5, v5, s2, 0xfedcba98                   // 00000041552C: D65C0005 03FC0505 FEDCBA98
	v_permlanex16_b32 v6, v6, s2, 0xfedcba98                   // 000000415538: D65C0006 03FC0506 FEDCBA98
	v_permlanex16_b32 v11, v11, s2, 0xfedcba98                 // 000000415544: D65C000B 03FC050B FEDCBA98
	.long 0xd44c0002                                           // 000000415550: D44C0002
	v_cndmask_b32_e32 v1, 16, v8, vcc_lo                       // 000000415554: 02021090
	s_barrier                                                  // 000000415558: BFBD0000
	buffer_gl0_inv                                             // 00000041555C: E0AC0000 00000000
	s_and_saveexec_b32 s3, s2                                  // 000000415564: BE832002
	s_cbranch_execz 18                                         // 000000415568: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1db4>
	v_dual_add_f32 v8, v35, v11 :: v_dual_add_f32 v1, v42, v1  // 00000041556C: C9081723 0800032A
	v_dual_add_f32 v2, v41, v2 :: v_dual_add_f32 v3, v40, v3   // 000000415574: C9080529 02020728
	v_lshl_or_b32 v9, v7, 9, v9                                // 00000041557C: D6560009 04251307
	v_dual_add_f32 v10, v39, v10 :: v_dual_add_f32 v5, v37, v5 // 000000415584: C9081527 0A040B25
	v_add_f32_e32 v4, v38, v4                                  // 00000041558C: 06080926
	v_add_f32_e32 v6, v36, v6                                  // 000000415590: 060C0D24
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000415594: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 00000041559C: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 0000004155A4: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 0000004155AC: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s3                              // 0000004155B4: 8C7E037E
	.long 0xd44c0003                                           // 0000004155B8: D44C0003
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000004155BC: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 0000004155C4: BF89FC07
	s_barrier                                                  // 0000004155C8: BFBD0000
	buffer_gl0_inv                                             // 0000004155CC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 0000004155D4: BE842003
	s_cbranch_execnz 7                                         // 0000004155D8: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1df8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000004155DC: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 0000004155E0: BF048215
	s_mov_b32 s4, -1                                           // 0000004155E4: BE8400C1
	s_cbranch_scc0 33                                          // 0000004155E8: BFA10021 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1e70>
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000004155EC: 8B6A047E
	s_cbranch_vccz 63870                                       // 0000004155F0: BFA3F97E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 164                                               // 0000004155F4: BFA000A4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2088>
	v_lshlrev_b32_e32 v8, 2, v0                                // 0000004155F8: 30100082
	ds_load_2addr_stride64_b32 v[1:2], v8 offset1:2            // 0000004155FC: D8E00200 01000008
	ds_load_2addr_stride64_b32 v[3:4], v8 offset0:4 offset1:6  // 000000415604: D8E00604 03000008
	s_waitcnt lgkmcnt(1)                                       // 00000041560C: BF89FC17
	v_add_f32_e32 v1, 0, v1                                    // 000000415610: 06020280
	ds_load_2addr_stride64_b32 v[5:6], v8 offset0:8 offset1:10 // 000000415614: D8E00A08 05000008
	v_add_f32_e32 v1, v1, v2                                   // 00000041561C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000415620: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000415624: BF8700C1
	v_add_f32_e32 v3, v1, v3                                   // 000000415628: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v8 offset0:12 offset1:14// 00000041562C: D8E00E0C 01000008
	v_add_f32_e32 v3, v3, v4                                   // 000000415634: 06060903
	s_waitcnt lgkmcnt(1)                                       // 000000415638: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 00000041563C: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000415640: BF8700A1
	v_add_f32_e32 v3, v3, v6                                   // 000000415644: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 000000415648: BF89FC07
	v_add_f32_e32 v1, v3, v1                                   // 00000041564C: 06020303
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415650: BF870001
	v_add_f32_e32 v1, v1, v2                                   // 000000415654: 06020501
	ds_store_b32 v8, v1 offset:4096                            // 000000415658: D8341000 00000108
	s_or_b32 exec_lo, exec_lo, s4                              // 000000415660: 8C7E047E
	s_cmp_lt_i32 s21, 2                                        // 000000415664: BF048215
	s_mov_b32 s4, -1                                           // 000000415668: BE8400C1
	s_cbranch_scc1 65503                                       // 00000041566C: BFA2FFDF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1dec>
	s_load_b128 s[4:7], s[0:1], 0x1a8                          // 000000415670: F4080100 F80001A8
	s_lshl_b64 s[8:9], s[30:31], 2                             // 000000415678: 8488821E
	s_waitcnt lgkmcnt(0)                                       // 00000041567C: BF89FC07
	s_barrier                                                  // 000000415680: BFBD0000
	buffer_gl0_inv                                             // 000000415684: E0AC0000 00000000
	s_add_u32 s1, s4, s8                                       // 00000041568C: 80010804
	s_addc_u32 s4, s5, s9                                      // 000000415690: 82040905
	s_and_saveexec_b32 s0, s3                                  // 000000415694: BE802003
	s_cbranch_execz 17                                         // 000000415698: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1ee0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000041569C: 30020082
	s_mul_hi_i32 s9, s23, s20                                  // 0000004156A0: 97091417
	s_mul_i32 s8, s23, s20                                     // 0000004156A4: 96081417
	s_lshl_b32 s10, s26, 7                                     // 0000004156A8: 840A871A
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000004156AC: 84888208
	ds_load_b32 v2, v1 offset:4096                             // 0000004156B0: D8D81000 02000001
	s_ashr_i32 s11, s10, 31                                    // 0000004156B8: 860B9F0A
	s_add_u32 s5, s1, s8                                       // 0000004156BC: 80050801
	s_addc_u32 s16, s4, s9                                     // 0000004156C0: 82100904
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000004156C4: 8488820A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004156C8: BF870009
	s_add_u32 s8, s5, s8                                       // 0000004156CC: 80080805
	s_addc_u32 s9, s16, s9                                     // 0000004156D0: 82090910
	s_waitcnt lgkmcnt(0)                                       // 0000004156D4: BF89FC07
	global_store_b32 v1, v2, s[8:9]                            // 0000004156D8: DC6A0000 00080201
	s_or_b32 exec_lo, exec_lo, s0                              // 0000004156E0: 8C7E007E
	s_ashr_i32 s29, s28, 31                                    // 0000004156E4: 861D9F1C
	.long 0xd44a0000                                           // 0000004156E8: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004156EC: 02020080
	s_lshl_b64 s[8:9], s[28:29], 2                             // 0000004156F0: 8488821C
	s_waitcnt_vscnt null, 0x0                                  // 0000004156F4: BC7C0000
	buffer_gl1_inv                                             // 0000004156F8: E0B00000 00000000
	buffer_gl0_inv                                             // 000000415700: E0AC0000 00000000
	s_add_u32 s6, s6, s8                                       // 000000415708: 80060806
	s_addc_u32 s7, s7, s9                                      // 00000041570C: 82070907
	s_barrier                                                  // 000000415710: BFBD0000
	buffer_gl0_inv                                             // 000000415714: E0AC0000 00000000
	s_and_saveexec_b32 s5, s0                                  // 00000041571C: BE852000
	s_cbranch_execz 29                                         // 000000415720: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f98>
	s_mov_b32 s9, exec_lo                                      // 000000415724: BE89007E
	s_mov_b32 s8, exec_lo                                      // 000000415728: BE88007E
	.long 0xd71f0001                                           // 00000041572C: D71F0001
	v_cndmask_b32_e32 v0, s9, v128, vcc_lo                     // 000000415730: 02010009
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415734: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000415738: 7D940280
	s_cbranch_execz 9                                          // 00000041573C: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x1f64>
	s_lshl_b64 s[10:11], s[26:27], 2                           // 000000415740: 848A821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000415744: BF8704B9
	s_add_u32 s10, s6, s10                                     // 000000415748: 800A0A06
	s_addc_u32 s11, s7, s11                                    // 00000041574C: 820B0B07
	s_bcnt1_i32_b32 s9, s9                                     // 000000415750: BE891809
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s9              // 000000415754: CA100080 02020009
	global_atomic_add_u32 v2, v2, v3, s[10:11] glc             // 00000041575C: DCD64000 020A0302
	s_or_b32 exec_lo, exec_lo, s8                              // 000000415764: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 000000415768: BF8903F7
	v_readfirstlane_b32 s8, v2                                 // 00000041576C: 7E100502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415770: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s8, v1       // 000000415774: CA200080 02000208
	s_add_i32 s8, s21, -1                                      // 00000041577C: 8108C115
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000415780: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s8, v1                            // 000000415784: 7C940208
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000415788: D5010001 01A90280
	ds_store_b32 v2, v1 offset:5120                            // 000000415790: D8341400 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000415798: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000041579C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000004157A0: BF89FC07
	s_barrier                                                  // 0000004157A4: BFBD0000
	buffer_gl0_inv                                             // 0000004157A8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:5120                             // 0000004157B0: D8D81400 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000004157B8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000004157BC: 7C940280
	s_cbranch_vccnz 48                                         // 0000004157C0: BFA40030 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2084>
	buffer_gl1_inv                                             // 0000004157C4: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004157CC: E0AC0000 00000000
	s_and_saveexec_b32 s8, s3                                  // 0000004157D4: BE882003
	s_cbranch_execz 30                                         // 0000004157D8: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2054>
	s_lshl_b32 s10, s26, 7                                     // 0000004157DC: 840A871A
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v3, 2, v0       // 0000004157E0: CA220080 04020082
	s_ashr_i32 s11, s10, 31                                    // 0000004157E8: 860B9F0A
	s_ashr_i32 s5, s20, 31                                     // 0000004157EC: 86059F14
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000004157F0: 848A820A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000004157F4: BF8700B9
	s_add_u32 s1, s1, s10                                      // 0000004157F8: 80010A01
	s_addc_u32 s3, s4, s11                                     // 0000004157FC: 82030B04
	.long 0xd7000101                                           // 000000415800: D7000101
	v_cndmask_b32_e32 v1, s1, v3, vcc_lo                       // 000000415804: 02020601
	v_add_co_ci_u32_e64 v2, null, s3, 0, s1                    // 000000415808: D5207C02 00050003
	s_mov_b32 s4, s20                                          // 000000415810: BE840014
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000415814: BF870009
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000415818: 84848204
	global_load_b32 v5, v[1:2], off glc                        // 00000041581C: DC524000 057C0001
	.long 0xd7006a01                                           // 000000415824: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 000000415828: 02000901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000041582C: BF8704A1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000415830: D5207C02 01AA0405
	s_add_i32 s21, s21, -1                                     // 000000415838: 8115C115
	s_cmp_eq_u32 s21, 0                                        // 00000041583C: BF068015
	s_waitcnt vmcnt(0)                                         // 000000415840: BF8903F7
	v_add_f32_e32 v4, v4, v5                                   // 000000415844: 06080B04
	s_cbranch_scc0 65524                                       // 000000415848: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x201c>
	ds_store_b32 v3, v4 offset:4096                            // 00000041584C: D8341000 00000403
	s_or_b32 exec_lo, exec_lo, s8                              // 000000415854: 8C7E087E
	s_and_saveexec_b32 s1, s0                                  // 000000415858: BE812000
	s_cbranch_execz 6                                          // 00000041585C: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2078>
	s_lshl_b64 s[4:5], s[26:27], 2                             // 000000415860: 8484821A
	v_mov_b32_e32 v1, 0                                        // 000000415864: 7E020280
	s_add_u32 s4, s6, s4                                       // 000000415868: 80040406
	s_addc_u32 s5, s7, s5                                      // 00000041586C: 82050507
	global_store_b32 v1, v1, s[4:5]                            // 000000415870: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000415878: 8C7E017E
	s_cbranch_execz 63707                                      // 00000041587C: BFA5F8DB <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 1                                                 // 000000415880: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2088>
	s_branch 63705                                             // 000000415884: BFA0F8D9 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_cmp_eq_u32_e32 vcc_lo, 0, v7                             // 000000415888: 7C940E80
	s_cmp_gt_i32 s18, 0                                        // 00000041588C: BF028012
	s_waitcnt lgkmcnt(0)                                       // 000000415890: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000415894: BC7C0000
	s_cselect_b32 s0, -1, 0                                    // 000000415898: 980080C1
	s_barrier                                                  // 00000041589C: BFBD0000
	s_and_b32 s0, vcc_lo, s0                                   // 0000004158A0: 8B00006A
	buffer_gl0_inv                                             // 0000004158A4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000004158AC: BE812000
	s_cbranch_execz 63694                                      // 0000004158B0: BFA5F8CE <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_and_b32_e32 v1, 15, v0                                   // 0000004158B4: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004158B8: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000004158BC: 30040282
	v_add_nc_u32_e32 v8, 0x1000, v2                            // 0000004158C0: 4A1004FF 00001000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000004158C8: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000004158D0: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000004158D8: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000004158E0: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000004158E8: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 0000004158EC: 36160082
	s_waitcnt lgkmcnt(3)                                       // 0000004158F0: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 0000004158F4: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 0000004158FC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000415900: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000415908: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000041590C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000415914: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000415918: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000415920: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000415928: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000041592C: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000415930: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000415938: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000415940: 7C941480
	.long 0xd44a0000                                           // 000000415944: D44A0000
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 000000415948: 02021680
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000041594C: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000415954: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000415958: 08101D09
	.long 0xd44a0001                                           // 00000041595C: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000415960: 02021880
	s_delay_alu instid0(VALU_DEP_4)                            // 000000415964: BF870004
	v_add_f32_e32 v9, v13, v4                                  // 000000415968: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000041596C: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000415974: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000415978: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000041597C: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000415980: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000415988: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000415990: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000415998: D5010009 21AA1309
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004159A0: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000004159A8: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004159B0: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000004159B8: D5010008 21AA1108
	v_add_f32_e32 v6, v7, v6                                   // 0000004159C0: 060C0D07
	v_add_f32_e32 v7, v9, v10                                  // 0000004159C4: 060E1509
	v_add_f32_e32 v5, v5, v15                                  // 0000004159C8: 060A1F05
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004159CC: 7E1C02FA FF01610D
	v_add_f32_e32 v8, v8, v16                                  // 0000004159D4: 06102108
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004159D8: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, s0                          // 0000004159E0: D5010006 20020D06
	v_mov_b32_dpp v11, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004159E8: 7E1602FA FF016207
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000004159F0: D5010007 20020F07
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000004159F8: D501000D 21AA1B0D
	v_mov_b32_dpp v22, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000415A00: 7E2C02FA FF016104
	v_add_f32_e32 v6, v6, v10                                  // 000000415A08: 060C1506
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000415A0C: D5010004 21AA0904
	v_add_f32_e32 v7, v7, v11                                  // 000000415A14: 060E1707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000415A18: BF8701A3
	v_mov_b32_dpp v10, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415A1C: 7E1402FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000415A24: D5010006 20060D06
	v_mov_b32_dpp v11, v7 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415A2C: 7E1602FA FF016407
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000415A34: D5010007 20060F07
	v_add_f32_e32 v9, v13, v14                                 // 000000415A3C: 06121D0D
	v_add_f32_e32 v4, v4, v22                                  // 000000415A40: 06082D04
	v_add_f32_e32 v20, v6, v10                                 // 000000415A44: 06281506
	v_cndmask_b32_e64 v6, -v8, v8, s0                          // 000000415A48: D5010006 20021108
	v_add_f32_e32 v10, v7, v11                                 // 000000415A50: 06141707
	v_mov_b32_dpp v13, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415A54: 7E1A02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000415A5C: D5010009 20021309
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415A64: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000415A6C: D5010005 20020B05
	v_mov_b32_dpp v19, v10 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415A74: 7E2602FA FF01680A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000415A7C: BF870004
	v_add_f32_e32 v9, v9, v13                                  // 000000415A80: 06121B09
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415A84: 7E1A02FA FF016208
	v_mov_b32_dpp v8, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000415A8C: 7E1002FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000415A94: D5010003 21AA0703
	v_add_f32_e32 v5, v5, v14                                  // 000000415A9C: 060A1D05
	v_mov_b32_dpp v12, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415AA0: 7E1802FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000415AA8: D5010009 20061309
	v_add_f32_e32 v6, v6, v13                                  // 000000415AB0: 060C1B06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000415AB4: BF870224
	v_mov_b32_dpp v7, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415AB8: 7E0E02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s1                          // 000000415AC0: D5010005 20060B05
	v_add_f32_e32 v17, v9, v12                                 // 000000415AC8: 06221909
	v_mov_b32_dpp v9, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000415ACC: 7E1202FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000415AD4: D5010002 21AA0502
	v_add_f32_e32 v3, v3, v8                                   // 000000415ADC: 06061103
	v_mov_b32_dpp v8, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415AE0: 7E1002FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000415AE8: D5010004 20020904
	v_mov_b32_dpp v21, v20 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415AF0: 7E2A02FA FF016814
	v_add_f32_e32 v2, v2, v9                                   // 000000415AF8: 06041302
	v_mov_b32_dpp v9, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415AFC: 7E1202FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000415B04: D5010003 20020703
	v_add_f32_e32 v4, v4, v8                                   // 000000415B0C: 06081104
	v_mov_b32_dpp v8, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415B10: 7E1002FA FF016406
	v_mov_b32_dpp v11, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000415B18: 7E1602FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000415B20: D5010002 20020502
	v_add_f32_e32 v3, v3, v9                                   // 000000415B28: 06061303
	v_mov_b32_dpp v9, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415B2C: 7E1202FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000415B34: D5010004 20060904
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000415B3C: D5010006 20060D06
	v_add_f32_e32 v2, v2, v11                                  // 000000415B44: 06041702
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415B48: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000415B50: D5010003 20060703
	v_add_f32_e32 v11, v4, v9                                  // 000000415B58: 06161304
	v_add_f32_e32 v15, v5, v7                                  // 000000415B5C: 061E0F05
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000415B60: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000415B68: D5010002 20060502
	v_add_f32_e32 v13, v6, v8                                  // 000000415B70: 061A1106
	v_add_f32_e32 v8, v3, v12                                  // 000000415B74: 06101903
	v_mov_b32_dpp v18, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415B78: 7E2402FA FF016811
	v_mov_b32_dpp v16, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415B80: 7E2002FA FF01680F
	v_add_f32_e32 v6, v2, v14                                  // 000000415B88: 060C1D02
	v_mov_b32_dpp v14, v13 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415B8C: 7E1C02FA FF01680D
	v_mov_b32_dpp v12, v11 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415B94: 7E1802FA FF01680B
	v_mov_b32_dpp v9, v8 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415B9C: 7E1202FA FF016808
	s_delay_alu instid0(VALU_DEP_4)                            // 000000415BA4: BF870004
	v_mov_b32_dpp v7, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000415BA8: 7E0E02FA FF016806
	s_and_b32 exec_lo, exec_lo, s2                             // 000000415BB0: 8B7E027E
	s_cbranch_execz 63501                                      // 000000415BB4: BFA5F80D <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	v_lshl_or_b32 v3, s26, 7, v1                               // 000000415BB8: D6560003 04050E1A
	v_and_b32_e32 v0, 8, v0                                    // 000000415BC0: 36000088
	s_cmp_lg_u64 s[24:25], 0                                   // 000000415BC4: BF118018
	s_mov_b32 s2, 0                                            // 000000415BC8: BE820080
	s_cselect_b32 s1, -1, 0                                    // 000000415BCC: 980180C1
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000415BD0: 3408069F
	.long 0xd44a0000                                           // 000000415BD4: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000415BD8: 02020080
	s_cmp_eq_u64 s[24:25], 0                                   // 000000415BDC: BF108018
	.long 0xd73c0001                                           // 000000415BE0: D73C0001
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000415BE4: 02020681
	v_cndmask_b32_e64 v0, -v20, v20, s0                        // 000000415BE8: D5010000 20022914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415BF0: BF870191
	v_add_f32_e32 v0, v0, v21                                  // 000000415BF4: 06002B00
	.long 0xd7006a04                                           // 000000415BF8: D7006A04
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 000000415BFC: 0202020C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415C00: BF870191
	v_add_co_ci_u32_e64 v5, null, s13, v2, vcc_lo              // 000000415C04: D5207C05 01AA040D
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000415C0C: 100000FF 3DB504F3
	global_load_d16_b16 v22, v[4:5], off                       // 000000415C14: DC820000 167C0004
	s_waitcnt vmcnt(0)                                         // 000000415C1C: BF8903F7
	v_fma_mix_f32 v20, v22, v0, neg(0) op_sel_hi:[1,0,0]       // 000000415C20: CC200014 8A020116
	v_ashrrev_i32_e32 v0, 31, v3                               // 000000415C28: 3400069F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415C2C: BF870092
	v_bfe_u32 v21, v20, 16, 1                                  // 000000415C30: D6100015 02052114
	v_add3_u32 v20, v20, v21, 0x7fff                           // 000000415C38: D6550014 03FE2B14 00007FFF
	s_cbranch_scc1 537                                         // 000000415C44: BFA20219 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cac>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000415C48: BF870123
	v_lshrrev_b32_e32 v21, 23, v0                              // 000000415C4C: 322A0097
	v_dual_mov_b32 v26, s14 :: v_dual_mov_b32 v23, s15         // 000000415C50: CA10000E 1A16000F
	v_add_nc_u32_e32 v21, v3, v21                              // 000000415C58: 4A2A2B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000415C5C: BF870121
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 000000415C60: 362C2AFF FFFFFE00
	v_ashrrev_i32_e32 v21, 9, v21                              // 000000415C68: 342A2A89
	v_sub_nc_u32_e32 v22, v3, v22                              // 000000415C6C: 4C2C2D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000415C70: BF870221
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 000000415C74: 7C882CFF 00000100
	v_add_nc_u32_e32 v24, 0xffffff00, v22                      // 000000415C7C: 4A302CFF FFFFFF00
	v_dual_cndmask_b32 v26, s24, v26 :: v_dual_lshlrev_b32 v21, 8, v21// 000000415C84: CA623418 1A142A88
	v_cndmask_b32_e32 v25, s25, v23, vcc_lo                    // 000000415C8C: 02322E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415C90: BF870193
	v_cndmask_b32_e32 v23, v24, v22, vcc_lo                    // 000000415C94: 022E2D18
	v_ashrrev_i32_e32 v22, 31, v21                             // 000000415C98: 342C2A9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000415C9C: BF870112
	v_ashrrev_i32_e32 v24, 31, v23                             // 000000415CA0: 34302E9F
	.long 0xd73c0015                                           // 000000415CA4: D73C0015
	v_cndmask_b32_e32 v1, 1, v21, vcc_lo                       // 000000415CA8: 02022A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000415CAC: BF870112
	.long 0xd73c0017                                           // 000000415CB0: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 000000415CB4: 02022E81
	.long 0xd7006a15                                           // 000000415CB8: D7006A15
	v_cndmask_b32_e32 v1, v26, v21, vcc_lo                     // 000000415CBC: 02022B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000415CC0: BF870111
	v_add_co_ci_u32_e64 v22, null, v25, v22, vcc_lo            // 000000415CC4: D5207C16 01AA2D19
	.long 0xd7006a15                                           // 000000415CCC: D7006A15
	v_cndmask_b32_e32 v1, v21, v23, vcc_lo                     // 000000415CD0: 02022F15
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415CD4: BF870001
	v_add_co_ci_u32_e64 v22, null, v22, v24, vcc_lo            // 000000415CD8: D5207C16 01AA3116
	global_store_d16_hi_b16 v[21:22], v20, off                 // 000000415CE0: DC960000 007C1415
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 000000415CE8: 916A027E
	s_cbranch_vccnz 7                                          // 000000415CEC: BFA40007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x250c>
	.long 0xd7006a15                                           // 000000415CF0: D7006A15
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000415CF4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415CF8: BF870001
	v_add_co_ci_u32_e64 v22, null, s15, v2, vcc_lo             // 000000415CFC: D5207C16 01AA040F
	global_store_d16_hi_b16 v[21:22], v20, off                 // 000000415D04: DC960000 007C1415
	global_load_d16_b16 v20, v[4:5], off offset:32             // 000000415D0C: DC820020 147C0004
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000415D14: D501000A 2002150A
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000415D1C: 916A017E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415D20: BF870091
	v_add_f32_e32 v10, v10, v19                                // 000000415D24: 0614270A
	v_mul_f32_e32 v10, 0x3db504f3, v10                         // 000000415D28: 101414FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000415D30: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000415D34: BF870121
	v_fma_mix_f32 v19, v20, v10, neg(0) op_sel_hi:[1,0,0]      // 000000415D38: CC200013 8A021514
	v_cndmask_b32_e64 v10, 0, 1, s1                            // 000000415D40: D501000A 00050280
	v_bfe_u32 v20, v19, 16, 1                                  // 000000415D48: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415D50: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000415D54: D6550013 03FE2913 00007FFF
	s_cbranch_vccnz 467                                        // 000000415D60: BFA401D3 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cb0>
	v_or_b32_e32 v20, 16, v3                                   // 000000415D64: 38280690
	v_lshrrev_b32_e32 v21, 23, v0                              // 000000415D68: 322A0097
	v_mov_b32_e32 v25, s14                                     // 000000415D6C: 7E32020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415D70: BF870092
	v_add_nc_u32_e32 v21, v20, v21                             // 000000415D74: 4A2A2B14
	v_and_b32_e32 v22, 0xfffffe00, v21                         // 000000415D78: 362C2AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415D80: BF870091
	v_sub_nc_u32_e32 v22, v20, v22                             // 000000415D84: 4C2C2D14
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v22                        // 000000415D88: 7C882CFF 00000100
	v_add_nc_u32_e32 v23, 0xffffff00, v22                      // 000000415D90: 4A2E2CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000415D98: BF8701B1
	v_dual_cndmask_b32 v25, s24, v25 :: v_dual_cndmask_b32 v22, v23, v22// 000000415D9C: CA523218 19162D17
	v_ashrrev_i32_e32 v20, 9, v21                              // 000000415DA4: 34282A89
	v_mov_b32_e32 v21, s15                                     // 000000415DA8: 7E2A020F
	v_ashrrev_i32_e32 v23, 31, v22                             // 000000415DAC: 342E2C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415DB0: BF870193
	v_lshlrev_b32_e32 v20, 8, v20                              // 000000415DB4: 30282888
	v_cndmask_b32_e32 v24, s25, v21, vcc_lo                    // 000000415DB8: 02302A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415DBC: BF870193
	.long 0xd73c0016                                           // 000000415DC0: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 000000415DC4: 02022C81
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000415DC8: 342A289F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415DCC: BF870091
	.long 0xd73c0014                                           // 000000415DD0: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000415DD4: 02022881
	.long 0xd7006a14                                           // 000000415DD8: D7006A14
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 000000415DDC: 02022919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000415DE0: BF870111
	v_add_co_ci_u32_e64 v21, null, v24, v21, vcc_lo            // 000000415DE4: D5207C15 01AA2B18
	.long 0xd7006a14                                           // 000000415DEC: D7006A14
	v_cndmask_b32_e32 v1, v20, v22, vcc_lo                     // 000000415DF0: 02022D14
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415DF4: BF870001
	v_add_co_ci_u32_e64 v21, null, v21, v23, vcc_lo            // 000000415DF8: D5207C15 01AA2F15
	global_store_d16_hi_b16 v[20:21], v19, off                 // 000000415E00: DC960000 007C1314
	s_cbranch_execnz 7                                         // 000000415E08: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2628>
	.long 0xd7006a14                                           // 000000415E0C: D7006A14
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000415E10: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415E14: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v2, vcc_lo             // 000000415E18: D5207C15 01AA040F
	global_store_d16_hi_b16 v[20:21], v19, off offset:32       // 000000415E20: DC960020 007C1314
	global_load_d16_b16 v19, v[4:5], off offset:64             // 000000415E28: DC820040 137C0004
	v_cndmask_b32_e64 v17, -v17, v17, s0                       // 000000415E30: D5010011 20022311
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 000000415E38: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000415E3C: BF8700A2
	v_add_f32_e32 v17, v17, v18                                // 000000415E40: 06222511
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000415E44: 8B6A6A7E
	v_mul_f32_e32 v17, 0x3db504f3, v17                         // 000000415E48: 102222FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000415E50: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415E54: BF870091
	v_fma_mix_f32 v17, v19, v17, neg(0) op_sel_hi:[1,0,0]      // 000000415E58: CC200011 8A022313
	v_bfe_u32 v18, v17, 16, 1                                  // 000000415E60: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415E68: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000415E6C: D6550011 03FE2511 00007FFF
	s_cbranch_vccnz 398                                        // 000000415E78: BFA4018E <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cb4>
	v_or_b32_e32 v18, 32, v3                                   // 000000415E7C: 382406A0
	v_lshrrev_b32_e32 v19, 23, v0                              // 000000415E80: 32260097
	v_mov_b32_e32 v23, s14                                     // 000000415E84: 7E2E020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415E88: BF870092
	v_add_nc_u32_e32 v19, v18, v19                             // 000000415E8C: 4A262712
	v_and_b32_e32 v20, 0xfffffe00, v19                         // 000000415E90: 362826FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415E98: BF870091
	v_sub_nc_u32_e32 v20, v18, v20                             // 000000415E9C: 4C282912
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v20                        // 000000415EA0: 7C8828FF 00000100
	v_add_nc_u32_e32 v21, 0xffffff00, v20                      // 000000415EA8: 4A2A28FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000415EB0: BF8701B1
	v_dual_cndmask_b32 v23, s24, v23 :: v_dual_cndmask_b32 v20, v21, v20// 000000415EB4: CA522E18 17142915
	v_ashrrev_i32_e32 v18, 9, v19                              // 000000415EBC: 34242689
	v_mov_b32_e32 v19, s15                                     // 000000415EC0: 7E26020F
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000415EC4: 342A289F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415EC8: BF870193
	v_lshlrev_b32_e32 v18, 8, v18                              // 000000415ECC: 30242488
	v_cndmask_b32_e32 v22, s25, v19, vcc_lo                    // 000000415ED0: 022C2619
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415ED4: BF870193
	.long 0xd73c0014                                           // 000000415ED8: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000415EDC: 02022881
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000415EE0: 3426249F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415EE4: BF870091
	.long 0xd73c0012                                           // 000000415EE8: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000415EEC: 02022481
	.long 0xd7006a12                                           // 000000415EF0: D7006A12
	v_cndmask_b32_e32 v1, v23, v18, vcc_lo                     // 000000415EF4: 02022517
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000415EF8: BF870111
	v_add_co_ci_u32_e64 v19, null, v22, v19, vcc_lo            // 000000415EFC: D5207C13 01AA2716
	.long 0xd7006a12                                           // 000000415F04: D7006A12
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 000000415F08: 02022912
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415F0C: BF870001
	v_add_co_ci_u32_e64 v19, null, v19, v21, vcc_lo            // 000000415F10: D5207C13 01AA2B13
	global_store_d16_hi_b16 v[18:19], v17, off                 // 000000415F18: DC960000 007C1112
	s_cbranch_execnz 7                                         // 000000415F20: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2740>
	.long 0xd7006a12                                           // 000000415F24: D7006A12
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000415F28: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415F2C: BF870001
	v_add_co_ci_u32_e64 v19, null, s15, v2, vcc_lo             // 000000415F30: D5207C13 01AA040F
	global_store_d16_hi_b16 v[18:19], v17, off offset:64       // 000000415F38: DC960040 007C1112
	global_load_d16_b16 v17, v[4:5], off offset:96             // 000000415F40: DC820060 117C0004
	v_cndmask_b32_e64 v15, -v15, v15, s0                       // 000000415F48: D501000F 20021F0F
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 000000415F50: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000415F54: BF8700A2
	v_add_f32_e32 v15, v15, v16                                // 000000415F58: 061E210F
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000415F5C: 8B6A6A7E
	v_mul_f32_e32 v15, 0x3db504f3, v15                         // 000000415F60: 101E1EFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000415F68: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415F6C: BF870091
	v_fma_mix_f32 v15, v17, v15, neg(0) op_sel_hi:[1,0,0]      // 000000415F70: CC20000F 8A021F11
	v_bfe_u32 v16, v15, 16, 1                                  // 000000415F78: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000415F80: BF870001
	v_add3_u32 v15, v15, v16, 0x7fff                           // 000000415F84: D655000F 03FE210F 00007FFF
	s_cbranch_vccnz 329                                        // 000000415F90: BFA40149 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cb8>
	v_or_b32_e32 v16, 48, v3                                   // 000000415F94: 382006B0
	v_lshrrev_b32_e32 v17, 23, v0                              // 000000415F98: 32220097
	v_mov_b32_e32 v21, s14                                     // 000000415F9C: 7E2A020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415FA0: BF870092
	v_add_nc_u32_e32 v17, v16, v17                             // 000000415FA4: 4A222310
	v_and_b32_e32 v18, 0xfffffe00, v17                         // 000000415FA8: 362422FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415FB0: BF870091
	v_sub_nc_u32_e32 v18, v16, v18                             // 000000415FB4: 4C242510
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v18                        // 000000415FB8: 7C8824FF 00000100
	v_add_nc_u32_e32 v19, 0xffffff00, v18                      // 000000415FC0: 4A2624FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000415FC8: BF8701B1
	v_dual_cndmask_b32 v21, s24, v21 :: v_dual_cndmask_b32 v18, v19, v18// 000000415FCC: CA522A18 15122513
	v_ashrrev_i32_e32 v16, 9, v17                              // 000000415FD4: 34202289
	v_mov_b32_e32 v17, s15                                     // 000000415FD8: 7E22020F
	v_ashrrev_i32_e32 v19, 31, v18                             // 000000415FDC: 3426249F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415FE0: BF870193
	v_lshlrev_b32_e32 v16, 8, v16                              // 000000415FE4: 30202088
	v_cndmask_b32_e32 v20, s25, v17, vcc_lo                    // 000000415FE8: 02282219
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000415FEC: BF870193
	.long 0xd73c0012                                           // 000000415FF0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 000000415FF4: 02022481
	v_ashrrev_i32_e32 v17, 31, v16                             // 000000415FF8: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000415FFC: BF870091
	.long 0xd73c0010                                           // 000000416000: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 000000416004: 02022081
	.long 0xd7006a10                                           // 000000416008: D7006A10
	v_cndmask_b32_e32 v1, v21, v16, vcc_lo                     // 00000041600C: 02022115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000416010: BF870111
	v_add_co_ci_u32_e64 v17, null, v20, v17, vcc_lo            // 000000416014: D5207C11 01AA2314
	.long 0xd7006a10                                           // 00000041601C: D7006A10
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 000000416020: 02022510
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416024: BF870001
	v_add_co_ci_u32_e64 v17, null, v17, v19, vcc_lo            // 000000416028: D5207C11 01AA2711
	global_store_d16_hi_b16 v[16:17], v15, off                 // 000000416030: DC960000 007C0F10
	s_cbranch_execnz 7                                         // 000000416038: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2858>
	.long 0xd7006a10                                           // 00000041603C: D7006A10
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000416040: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416044: BF870001
	v_add_co_ci_u32_e64 v17, null, s15, v2, vcc_lo             // 000000416048: D5207C11 01AA040F
	global_store_d16_hi_b16 v[16:17], v15, off offset:96       // 000000416050: DC960060 007C0F10
	global_load_d16_b16 v15, v[4:5], off offset:128            // 000000416058: DC820080 0F7C0004
	v_cndmask_b32_e64 v13, -v13, v13, s0                       // 000000416060: D501000D 20021B0D
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 000000416068: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000041606C: BF8700A2
	v_add_f32_e32 v13, v13, v14                                // 000000416070: 061A1D0D
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000416074: 8B6A6A7E
	v_mul_f32_e32 v13, 0x3db504f3, v13                         // 000000416078: 101A1AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000416080: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000416084: BF870091
	v_fma_mix_f32 v13, v15, v13, neg(0) op_sel_hi:[1,0,0]      // 000000416088: CC20000D 8A021B0F
	v_bfe_u32 v14, v13, 16, 1                                  // 000000416090: D610000E 0205210D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416098: BF870001
	v_add3_u32 v13, v13, v14, 0x7fff                           // 00000041609C: D655000D 03FE1D0D 00007FFF
	s_cbranch_vccnz 260                                        // 0000004160A8: BFA40104 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cbc>
	v_or_b32_e32 v14, 64, v3                                   // 0000004160AC: 381C06C0
	v_lshrrev_b32_e32 v15, 23, v0                              // 0000004160B0: 321E0097
	v_mov_b32_e32 v19, s14                                     // 0000004160B4: 7E26020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004160B8: BF870092
	v_add_nc_u32_e32 v15, v14, v15                             // 0000004160BC: 4A1E1F0E
	v_and_b32_e32 v16, 0xfffffe00, v15                         // 0000004160C0: 36201EFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004160C8: BF870091
	v_sub_nc_u32_e32 v16, v14, v16                             // 0000004160CC: 4C20210E
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v16                        // 0000004160D0: 7C8820FF 00000100
	v_add_nc_u32_e32 v17, 0xffffff00, v16                      // 0000004160D8: 4A2220FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004160E0: BF8701B1
	v_dual_cndmask_b32 v19, s24, v19 :: v_dual_cndmask_b32 v16, v17, v16// 0000004160E4: CA522618 13102111
	v_ashrrev_i32_e32 v14, 9, v15                              // 0000004160EC: 341C1E89
	v_mov_b32_e32 v15, s15                                     // 0000004160F0: 7E1E020F
	v_ashrrev_i32_e32 v17, 31, v16                             // 0000004160F4: 3422209F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000004160F8: BF870193
	v_lshlrev_b32_e32 v14, 8, v14                              // 0000004160FC: 301C1C88
	v_cndmask_b32_e32 v18, s25, v15, vcc_lo                    // 000000416100: 02241E19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000416104: BF870193
	.long 0xd73c0010                                           // 000000416108: D73C0010
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 00000041610C: 02022081
	v_ashrrev_i32_e32 v15, 31, v14                             // 000000416110: 341E1C9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000416114: BF870091
	.long 0xd73c000e                                           // 000000416118: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000041611C: 02021C81
	.long 0xd7006a0e                                           // 000000416120: D7006A0E
	v_cndmask_b32_e32 v1, v19, v14, vcc_lo                     // 000000416124: 02021D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000416128: BF870111
	v_add_co_ci_u32_e64 v15, null, v18, v15, vcc_lo            // 00000041612C: D5207C0F 01AA1F12
	.long 0xd7006a0e                                           // 000000416134: D7006A0E
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 000000416138: 0202210E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041613C: BF870001
	v_add_co_ci_u32_e64 v15, null, v15, v17, vcc_lo            // 000000416140: D5207C0F 01AA230F
	global_store_d16_hi_b16 v[14:15], v13, off                 // 000000416148: DC960000 007C0D0E
	s_cbranch_execnz 7                                         // 000000416150: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2970>
	.long 0xd7006a0e                                           // 000000416154: D7006A0E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000416158: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000041615C: BF870001
	v_add_co_ci_u32_e64 v15, null, s15, v2, vcc_lo             // 000000416160: D5207C0F 01AA040F
	global_store_d16_hi_b16 v[14:15], v13, off offset:128      // 000000416168: DC960080 007C0D0E
	global_load_d16_b16 v13, v[4:5], off offset:160            // 000000416170: DC8200A0 0D7C0004
	v_cndmask_b32_e64 v11, -v11, v11, s0                       // 000000416178: D501000B 2002170B
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 000000416180: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000416184: BF8700A2
	v_add_f32_e32 v11, v11, v12                                // 000000416188: 0616190B
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 00000041618C: 8B6A6A7E
	v_mul_f32_e32 v11, 0x3db504f3, v11                         // 000000416190: 101616FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 000000416198: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041619C: BF870091
	v_fma_mix_f32 v11, v13, v11, neg(0) op_sel_hi:[1,0,0]      // 0000004161A0: CC20000B 8A02170D
	v_bfe_u32 v12, v11, 16, 1                                  // 0000004161A8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004161B0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000004161B4: D655000B 03FE190B 00007FFF
	s_cbranch_vccnz 191                                        // 0000004161C0: BFA400BF <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cc0>
	v_or_b32_e32 v12, 0x50, v3                                 // 0000004161C4: 381806FF 00000050
	v_lshrrev_b32_e32 v13, 23, v0                              // 0000004161CC: 321A0097
	v_mov_b32_e32 v17, s14                                     // 0000004161D0: 7E22020E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004161D4: BF870092
	v_add_nc_u32_e32 v13, v12, v13                             // 0000004161D8: 4A1A1B0C
	v_and_b32_e32 v14, 0xfffffe00, v13                         // 0000004161DC: 361C1AFF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004161E4: BF870091
	v_sub_nc_u32_e32 v14, v12, v14                             // 0000004161E8: 4C1C1D0C
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v14                        // 0000004161EC: 7C881CFF 00000100
	v_add_nc_u32_e32 v15, 0xffffff00, v14                      // 0000004161F4: 4A1E1CFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004161FC: BF8701B1
	v_dual_cndmask_b32 v17, s24, v17 :: v_dual_cndmask_b32 v14, v15, v14// 000000416200: CA522218 110E1D0F
	v_ashrrev_i32_e32 v12, 9, v13                              // 000000416208: 34181A89
	v_mov_b32_e32 v13, s15                                     // 00000041620C: 7E1A020F
	v_ashrrev_i32_e32 v15, 31, v14                             // 000000416210: 341E1C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000416214: BF870193
	v_lshlrev_b32_e32 v12, 8, v12                              // 000000416218: 30181888
	v_cndmask_b32_e32 v16, s25, v13, vcc_lo                    // 00000041621C: 02201A19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000416220: BF870193
	.long 0xd73c000e                                           // 000000416224: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 000000416228: 02021C81
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000041622C: 341A189F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000416230: BF870091
	.long 0xd73c000c                                           // 000000416234: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000416238: 02021881
	.long 0xd7006a0c                                           // 00000041623C: D7006A0C
	v_cndmask_b32_e32 v1, v17, v12, vcc_lo                     // 000000416240: 02021911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000416244: BF870111
	v_add_co_ci_u32_e64 v13, null, v16, v13, vcc_lo            // 000000416248: D5207C0D 01AA1B10
	.long 0xd7006a0c                                           // 000000416250: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 000000416254: 02021D0C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416258: BF870001
	v_add_co_ci_u32_e64 v13, null, v13, v15, vcc_lo            // 00000041625C: D5207C0D 01AA1F0D
	global_store_d16_hi_b16 v[12:13], v11, off                 // 000000416264: DC960000 007C0B0C
	s_cbranch_execnz 7                                         // 00000041626C: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a8c>
	.long 0xd7006a0c                                           // 000000416270: D7006A0C
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000416274: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416278: BF870001
	v_add_co_ci_u32_e64 v13, null, s15, v2, vcc_lo             // 00000041627C: D5207C0D 01AA040F
	global_store_d16_hi_b16 v[12:13], v11, off offset:160      // 000000416284: DC9600A0 007C0B0C
	global_load_d16_b16 v11, v[4:5], off offset:192            // 00000041628C: DC8200C0 0B7C0004
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000416294: D5010008 20021108
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 00000041629C: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004162A0: BF8700A2
	v_add_f32_e32 v8, v8, v9                                   // 0000004162A4: 06101308
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004162A8: 8B6A6A7E
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000004162AC: 101010FF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004162B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004162B8: BF870091
	v_fma_mix_f32 v8, v11, v8, neg(0) op_sel_hi:[1,0,0]        // 0000004162BC: CC200008 8A02110B
	v_bfe_u32 v9, v8, 16, 1                                    // 0000004162C4: D6100009 02052108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004162CC: BF870001
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000004162D0: D6550008 03FE1308 00007FFF
	s_cbranch_vccnz 121                                        // 0000004162DC: BFA40079 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cc4>
	v_or_b32_e32 v9, 0x60, v3                                  // 0000004162E0: 381206FF 00000060
	v_lshrrev_b32_e32 v11, 23, v0                              // 0000004162E8: 32160097
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004162EC: BF870091
	v_add_nc_u32_e32 v11, v9, v11                              // 0000004162F0: 4A161709
	v_and_b32_e32 v12, 0xfffffe00, v11                         // 0000004162F4: 361816FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004162FC: BF8701B1
	v_sub_nc_u32_e32 v9, v9, v12                               // 000000416300: 4C121909
	v_mov_b32_e32 v12, s15                                     // 000000416304: 7E18020F
	v_ashrrev_i32_e32 v11, 9, v11                              // 000000416308: 34161689
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v9                         // 00000041630C: 7C8812FF 00000100
	v_add_nc_u32_e32 v13, 0xffffff00, v9                       // 000000416314: 4A1A12FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041631C: BF8701A3
	v_lshlrev_b32_e32 v11, 8, v11                              // 000000416320: 30161688
	v_cndmask_b32_e32 v15, s25, v12, vcc_lo                    // 000000416324: 021E1819
	v_cndmask_b32_e32 v13, v13, v9, vcc_lo                     // 000000416328: 021A130D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000041632C: BF8701A3
	v_ashrrev_i32_e32 v12, 31, v11                             // 000000416330: 3418169F
	v_mov_b32_e32 v9, s14                                      // 000000416334: 7E12020E
	v_ashrrev_i32_e32 v14, 31, v13                             // 000000416338: 341C1A9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000041633C: BF870193
	.long 0xd73c000b                                           // 000000416340: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000416344: 02021681
	v_cndmask_b32_e32 v9, s24, v9, vcc_lo                      // 000000416348: 02121218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041634C: BF870113
	.long 0xd73c000d                                           // 000000416350: D73C000D
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 000000416354: 02021A81
	.long 0xd7006a09                                           // 000000416358: D7006A09
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000041635C: 02021709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000416360: BF870111
	v_add_co_ci_u32_e64 v12, null, v15, v12, vcc_lo            // 000000416364: D5207C0C 01AA190F
	.long 0xd7006a0b                                           // 00000041636C: D7006A0B
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 000000416370: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416374: BF870001
	v_add_co_ci_u32_e64 v12, null, v12, v14, vcc_lo            // 000000416378: D5207C0C 01AA1D0C
	global_store_d16_hi_b16 v[11:12], v8, off                  // 000000416380: DC960000 007C080B
	s_cbranch_execnz 7                                         // 000000416388: BFA60007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2ba8>
	.long 0xd7006a0b                                           // 00000041638C: D7006A0B
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000416390: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416394: BF870001
	v_add_co_ci_u32_e64 v12, null, s15, v2, vcc_lo             // 000000416398: D5207C0C 01AA040F
	global_store_d16_hi_b16 v[11:12], v8, off offset:192       // 0000004163A0: DC9600C0 007C080B
	global_load_d16_b16 v4, v[4:5], off offset:224             // 0000004163A8: DC8200E0 047C0004
	v_cndmask_b32_e64 v5, -v6, v6, s0                          // 0000004163B0: D5010005 20020D06
	v_cmp_ne_u32_e32 vcc_lo, 1, v10                            // 0000004163B8: 7C9A1481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004163BC: BF8700A2
	v_add_f32_e32 v5, v5, v7                                   // 0000004163C0: 060A0F05
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000004163C4: 8B6A6A7E
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 0000004163C8: 100A0AFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000004163D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004163D4: BF870091
	v_fma_mix_f32 v4, v4, v5, neg(0) op_sel_hi:[1,0,0]         // 0000004163D8: CC200004 8A020B04
	v_bfe_u32 v5, v4, 16, 1                                    // 0000004163E0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004163E8: BF870001
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000004163EC: D6550004 03FE0B04 00007FFF
	s_cbranch_vccnz 51                                         // 0000004163F8: BFA40033 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cc8>
	v_or_b32_e32 v3, 0x70, v3                                  // 0000004163FC: 380606FF 00000070
	v_lshrrev_b32_e32 v0, 23, v0                               // 000000416404: 32000097
	v_mov_b32_e32 v6, s15                                      // 000000416408: 7E0C020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041640C: BF870092
	v_add_nc_u32_e32 v0, v3, v0                                // 000000416410: 4A000103
	v_and_b32_e32 v5, 0xfffffe00, v0                           // 000000416414: 360A00FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000041641C: BF870091
	v_sub_nc_u32_e32 v3, v3, v5                                // 000000416420: 4C060B03
	v_cmp_gt_i32_e32 vcc_lo, 0x100, v3                         // 000000416424: 7C8806FF 00000100
	v_add_nc_u32_e32 v7, 0xffffff00, v3                        // 00000041642C: 4A0E06FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000416434: BF8701B1
	v_cndmask_b32_e32 v7, v7, v3, vcc_lo                       // 000000416438: 020E0707
	v_mov_b32_e32 v3, s14                                      // 00000041643C: 7E06020E
	v_ashrrev_i32_e32 v0, 9, v0                                // 000000416440: 34000089
	v_ashrrev_i32_e32 v8, 31, v7                               // 000000416444: 34100E9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000416448: BF870193
	v_cndmask_b32_e32 v3, s24, v3, vcc_lo                      // 00000041644C: 02060618
	v_dual_cndmask_b32 v0, s25, v6 :: v_dual_lshlrev_b32 v5, 8, v0// 000000416450: CA620C19 00040088
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000416458: BF870113
	.long 0xd73c0007                                           // 00000041645C: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000416460: 02020E81
	v_ashrrev_i32_e32 v6, 31, v5                               // 000000416464: 340C0A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000416468: BF870091
	.long 0xd73c0005                                           // 00000041646C: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000416470: 02020A81
	.long 0xd7006a03                                           // 000000416474: D7006A03
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000416478: 02020B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000041647C: BF870111
	v_add_co_ci_u32_e64 v0, null, v0, v6, vcc_lo               // 000000416480: D5207C00 01AA0D00
	.long 0xd7006a05                                           // 000000416488: D7006A05
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000041648C: 02020F03
	s_delay_alu instid0(VALU_DEP_1)                            // 000000416490: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v8, vcc_lo               // 000000416494: D5207C06 01AA1100
	global_store_d16_hi_b16 v[5:6], v4, off                    // 00000041649C: DC960000 007C0405
	s_cbranch_execnz 62929                                     // 0000004164A4: BFA6F5D1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x3ec>
	s_branch 7                                                 // 0000004164A8: BFA00007 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2cc8>
	s_branch 65040                                             // 0000004164AC: BFA0FE10 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x24f0>
	s_branch 65110                                             // 0000004164B0: BFA0FE56 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x260c>
	s_branch 65179                                             // 0000004164B4: BFA0FE9B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2724>
	s_branch 65248                                             // 0000004164B8: BFA0FEE0 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x283c>
	s_branch 65317                                             // 0000004164BC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2954>
	s_branch 65387                                             // 0000004164C0: BFA0FF6B <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2a70>
	s_branch 65457                                             // 0000004164C4: BFA0FFB1 <_ZN7halogen12_GLOBAL__N_112k_ht_lin_grpILi4ELi1ELb1ELb0ELb1ELb0EEEvNS0_5HtGrpEPKtiiPfPj+0x2b8c>
	.long 0xd7006a00                                           // 0000004164C8: D7006A00
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000004164CC: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004164D0: BF870001
	v_add_co_ci_u32_e64 v1, null, s15, v2, vcc_lo              // 0000004164D4: D5207C01 01AA040F
	global_store_d16_hi_b16 v[0:1], v4, off offset:224         // 0000004164DC: DC9600E0 007C0400
	s_endpgm                                                   // 0000004164E4: BFB00000
		...

