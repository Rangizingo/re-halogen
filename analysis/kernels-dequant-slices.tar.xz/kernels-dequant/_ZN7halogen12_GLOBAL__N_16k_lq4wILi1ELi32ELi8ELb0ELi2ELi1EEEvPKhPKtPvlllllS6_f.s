00000000007f4a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007F4A00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007F4A08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007F4A0C: 32040082
	v_lshrrev_b32_e32 v21, 5, v0                               // 0000007F4A10: 322A0085
	v_and_b32_e32 v22, 31, v0                                  // 0000007F4A14: 362C009F
	.long 0x7f0a3880                                           // 0000007F4A18: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000007F4A1C: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007F4A20: BF89FC07
	.long 0xd4510000                                           // 0000007F4A24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007F4A28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 0000007F4A2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 0000007F4A30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 0000007F4A34: 98158002
	s_add_u32 s0, s4, s16                                      // 0000007F4A38: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000007F4A3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 0000007F4A40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007F4A44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 0000007F4A48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F4A4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 0000007F4A50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007F4A54: 30020282
	s_add_u32 s16, s10, s16                                    // 0000007F4A58: 8010100A
	s_clause 0x1                                               // 0000007F4A5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007F4A60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007F4A68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 0000007F4A70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 0000007F4A74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007F4A78: 85908510
	v_mov_b32_e32 v1, s0                                       // 0000007F4A7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 0000007F4A80: 81118710
	s_mul_i32 s1, s19, s21                                     // 0000007F4A84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 0000007F4A88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007F4A8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 0000007F4A90: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 0000007F4A94: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 0000007F4A9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 0000007F4AA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 0000007F4AA4: B3900801
	.long 0xd72c0001                                           // 0000007F4AA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v21, vcc_lo                      // 0000007F4AAC: 02022A00
	s_mul_i32 s17, s18, s20                                    // 0000007F4AB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007F4AB4: BF870141
	v_add_nc_u32_e32 v8, s0, v1                                // 0000007F4AB8: 4A100200
	v_add_nc_u32_e32 v23, v1, v22                              // 0000007F4ABC: 4A2E2D01
	s_cselect_b32 s0, -1, 0                                    // 0000007F4AC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 0000007F4AC4: B2900800
	v_min_i32_e32 v24, s16, v8                                 // 0000007F4AC8: 22301010
	s_cselect_b32 s16, -1, 0                                   // 0000007F4ACC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007F4AD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007F4AD4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 0000007F4AD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007F4ADC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007F4AE4: BF8903F7
	v_bfe_u32 v7, v4, 16, 1                                    // 0000007F4AE8: D6100007 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007F4AF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 0000007F4AFC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F4B00: BF870223
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000007F4B04: D6550004 03FE0F04 00007FFF
	.long 0xd4410001                                           // 0000007F4B10: D4410001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007F4B14: 02023117
	.long 0x7e0a3982                                           // 0000007F4B18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007F4B1C: BF870114
	v_add_nc_u32_e32 v25, s17, v3                              // 0000007F4B20: 4A320611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007F4B24: D6570001 041608FF FFFF0000
	ds_store_b32 v6, v1 offset:32                              // 0000007F4B30: D8340020 00000106
	s_waitcnt lgkmcnt(0)                                       // 0000007F4B38: BF89FC07
	s_barrier                                                  // 0000007F4B3C: BFBD0000
	buffer_gl0_inv                                             // 0000007F4B40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007F4B48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007F4B4C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 0000007F4B54: BE912001
	s_cbranch_execz 11                                         // 0000007F4B58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v23                               // 0000007F4B5C: 30022E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4B60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007F4B64: 3408029F
	.long 0xd7006a03                                           // 0000007F4B68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007F4B6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v25, v4, vcc_lo              // 0000007F4B70: D5207C04 01AA0919
	global_load_d16_b16 v1, v[3:4], off                        // 0000007F4B78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007F4B80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007F4B84: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007F4B88: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v23                               // 0000007F4B8C: 4A062EA0
	s_mov_b32 s1, exec_lo                                      // 0000007F4B90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4B94: BF870001
	.long 0xd4c1007e                                           // 0000007F4B98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 0000007F4B9C: 02023103
	s_cbranch_execz 11                                         // 0000007F4BA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007F4BA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4BA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007F4BAC: 3406049F
	.long 0xd7006a02                                           // 0000007F4BB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007F4BB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v25, v3, vcc_lo              // 0000007F4BB8: D5207C03 01AA0719
	global_load_d16_b16 v2, v[2:3], off                        // 0000007F4BC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007F4BC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007F4BCC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4BD0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v23      // 0000007F4BD4: CA200080 04042EC0
	v_mov_b32_e32 v3, 0                                        // 0000007F4BDC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 0000007F4BE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F4BE4: BF870002
	.long 0xd4c1007e                                           // 0000007F4BE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 0000007F4BEC: 02023105
	s_cbranch_execz 11                                         // 0000007F4BF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007F4BF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4BF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007F4BFC: 340C069F
	.long 0xd7006a05                                           // 0000007F4C00: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007F4C04: 02020711
	v_add_co_ci_u32_e64 v6, null, v25, v6, vcc_lo              // 0000007F4C08: D5207C06 01AA0D19
	global_load_d16_b16 v3, v[5:6], off                        // 0000007F4C10: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007F4C18: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007F4C1C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4C20: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v23                             // 0000007F4C24: 4A0A2EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 0000007F4C2C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4C30: BF870001
	.long 0xd4c1007e                                           // 0000007F4C34: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 0000007F4C38: 02023105
	s_cbranch_execz 11                                         // 0000007F4C3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007F4C40: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4C44: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007F4C48: 340A089F
	.long 0xd7006a04                                           // 0000007F4C4C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007F4C50: 02020911
	v_add_co_ci_u32_e64 v5, null, v25, v5, vcc_lo              // 0000007F4C54: D5207C05 01AA0B19
	global_load_d16_b16 v4, v[4:5], off                        // 0000007F4C5C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007F4C64: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007F4C68: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4C6C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v23    // 0000007F4C70: CA200080 06062EFF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007F4C7C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 0000007F4C80: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F4C84: BF870002
	.long 0xd4c1007e                                           // 0000007F4C88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 0000007F4C8C: 02023107
	s_cbranch_execz 11                                         // 0000007F4C90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007F4C94: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4C98: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007F4C9C: 34100A9F
	.long 0xd7006a07                                           // 0000007F4CA0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007F4CA4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v25, v8, vcc_lo              // 0000007F4CA8: D5207C08 01AA1119
	global_load_d16_b16 v5, v[7:8], off                        // 0000007F4CB0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007F4CB8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007F4CBC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4CC0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v23                             // 0000007F4CC4: 4A0E2EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 0000007F4CCC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4CD0: BF870001
	.long 0xd4c1007e                                           // 0000007F4CD4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 0000007F4CD8: 02023107
	s_cbranch_execz 11                                         // 0000007F4CDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007F4CE0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4CE4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007F4CE8: 340E0C9F
	.long 0xd7006a06                                           // 0000007F4CEC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007F4CF0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v25, v7, vcc_lo              // 0000007F4CF4: D5207C07 01AA0F19
	global_load_d16_b16 v6, v[6:7], off                        // 0000007F4CFC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007F4D04: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007F4D08: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4D0C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v23    // 0000007F4D10: CA200080 08082EFF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007F4D1C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 0000007F4D20: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F4D24: BF870002
	.long 0xd4c1007e                                           // 0000007F4D28: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007F4D2C: 02023109
	s_cbranch_execz 11                                         // 0000007F4D30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000007F4D34: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4D38: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000007F4D3C: 34140E9F
	.long 0xd7006a09                                           // 0000007F4D40: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007F4D44: 02020F11
	v_add_co_ci_u32_e64 v10, null, v25, v10, vcc_lo            // 0000007F4D48: D5207C0A 01AA1519
	global_load_d16_b16 v7, v[9:10], off                       // 0000007F4D50: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000007F4D58: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007F4D5C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4D60: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v23                             // 0000007F4D64: 4A122EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 0000007F4D6C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4D70: BF870001
	.long 0xd4c1007e                                           // 0000007F4D74: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007F4D78: 02023109
	s_cbranch_execz 11                                         // 0000007F4D7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000007F4D80: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4D84: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000007F4D88: 3412109F
	.long 0xd7006a08                                           // 0000007F4D8C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007F4D90: 02021111
	v_add_co_ci_u32_e64 v9, null, v25, v9, vcc_lo              // 0000007F4D94: D5207C09 01AA1319
	global_load_d16_b16 v8, v[8:9], off                        // 0000007F4D9C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000007F4DA4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007F4DA8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 0000007F4DAC: 8C7E017E
	s_branch 9                                                 // 0000007F4DB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000007F4DB4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4DB8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007F4DBC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007F4DC0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007F4DC4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007F4DC8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007F4DCC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007F4DD0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007F4DD4: 7E100301
	s_add_u32 s4, s4, s14                                      // 0000007F4DD8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007F4DDC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 0000007F4DE0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v26, 0            // 0000007F4DE4: CA100015 091A0080
	s_add_u32 s10, s10, s1                                     // 0000007F4DEC: 800A010A
	s_addc_u32 s11, s11, 0                                     // 0000007F4DF0: 820B800B
	.long 0xd4410001                                           // 0000007F4DF4: D4410001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007F4DF8: 02023117
	s_ashr_i64 s[10:11], s[10:11], 1                           // 0000007F4DFC: 868A810A
	v_cndmask_b32_e64 v27, 0, 1, s16                           // 0000007F4E00: D501001B 00410280
	v_mad_u64_u32 v[18:19], null, v9, s10, s[4:5]              // 0000007F4E08: D6FE7C12 00101509
	.long 0xd72c000b                                           // 0000007F4E10: D72C000B
	v_cndmask_b32_e32 v0, s21, v11, vcc_lo                     // 0000007F4E14: 02001615
	.long 0xd72c000c                                           // 0000007F4E18: D72C000C
	v_cndmask_b32_e32 v0, s20, v10, vcc_lo                     // 0000007F4E1C: 02001414
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000007F4E20: CA100080 090A0080
	v_mov_b32_e32 v29, 0                                       // 0000007F4E28: 7E3A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F4E2C: BF870003
	v_add3_u32 v28, v12, v19, v11                              // 0000007F4E30: D655001C 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 0000007F4E38: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 0000007F4E40: BE842001
	s_cbranch_execz 22                                         // 0000007F4E44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v23                               // 0000007F4E48: 30122E84
	v_mov_b32_e32 v29, 0                                       // 0000007F4E4C: 7E3A0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F4E50: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007F4E54: 3414129F
	.long 0xd7006a09                                           // 0000007F4E58: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007F4E5C: 02021312
	v_add_co_ci_u32_e64 v10, null, v28, v10, vcc_lo            // 0000007F4E60: D5207C0A 01AA151C
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007F4E68: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007F4E6C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007F4E74: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v23                              // 0000007F4E78: 301A2E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F4E7C: BF870091
	.long 0xd7006a0d                                           // 0000007F4E80: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007F4E84: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 0000007F4E88: D5207C0E 01AA3280
	global_load_d16_b16 v13, v[13:14], off                     // 0000007F4E90: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007F4E98: BF8903F7
	v_cvt_f32_f16_e32 v29, v13                                 // 0000007F4E9C: 7E3A170D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F4EA0: 8C7E047E
	s_and_saveexec_b32 s4, s1                                  // 0000007F4EA4: BE842001
	s_cbranch_execz 233                                        // 0000007F4EA8: BFA500E9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v13, 32, v23    // 0000007F4EAC: CA200080 1A0C2EA0
	v_dual_mov_b32 v32, v29 :: v_dual_lshlrev_b32 v19, 5, v23  // 0000007F4EB4: CA22011D 20122E85
	s_mov_b32 s5, 0                                            // 0000007F4EBC: BE850080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F4EC0: BF870002
	v_lshlrev_b32_e32 v30, 4, v13                              // 0000007F4EC4: 303C1A84
	v_lshlrev_b32_e32 v31, 1, v13                              // 0000007F4EC8: 303E1A81
	s_branch 188                                               // 0000007F4ECC: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007F4ED0: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007F4ED4: 3428269F
	v_lshrrev_b32_e32 v49, 6, v9                               // 0000007F4ED8: 32621286
	v_lshrrev_b32_e32 v50, 14, v9                              // 0000007F4EDC: 3264128E
	v_and_b32_e32 v51, 0xff, v10                               // 0000007F4EE0: 366614FF 000000FF
	v_lshrrev_b32_e32 v52, 6, v10                              // 0000007F4EE8: 32681486
	.long 0xd73c0021                                           // 0000007F4EEC: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007F4EF0: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007F4EF4: 362812FF 000000FF
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000007F4EFC: 366262FF 000003FC
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000007F4F04: 366464FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007F4F0C: 32121296
	v_lshrrev_b32_e32 v53, 14, v10                             // 0000007F4F10: 326A148E
	.long 0xd7006a2d                                           // 0000007F4F14: D7006A2D
	v_cndmask_b32_e32 v1, s6, v33, vcc_lo                      // 0000007F4F18: 02024206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F4F1C: BF870001
	v_add_co_ci_u32_e64 v46, null, s7, v34, vcc_lo             // 0000007F4F20: D5207C2E 01AA4407
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007F4F28: 30282882
	ds_load_b32 v49, v49 offset:32                             // 0000007F4F2C: D8D80020 31000031
	ds_load_b32 v50, v50 offset:32                             // 0000007F4F34: D8D80020 32000032
	s_clause 0x3                                               // 0000007F4F3C: BF850003
	global_load_b128 v[33:36], v[45:46], off                   // 0000007F4F40: DC5E0000 217C002D
	global_load_b128 v[37:40], v[45:46], off offset:16         // 0000007F4F48: DC5E0010 257C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 0000007F4F50: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007F4F58: DC5E0030 2D7C002D
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007F4F60: 32141496
	ds_load_b32 v20, v20 offset:32                             // 0000007F4F64: D8D80020 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007F4F6C: 361212FF 000003FC
	v_lshlrev_b32_e32 v51, 2, v51                              // 0000007F4F74: 30666682
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000007F4F78: 366868FF 000003FC
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000007F4F80: 366A6AFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007F4F88: 361414FF 000003FC
	ds_load_b32 v9, v9 offset:32                               // 0000007F4F90: D8D80020 09000009
	ds_load_b32 v51, v51 offset:32                             // 0000007F4F98: D8D80020 33000033
	ds_load_b32 v52, v52 offset:32                             // 0000007F4FA0: D8D80020 34000034
	ds_load_b32 v53, v53 offset:32                             // 0000007F4FA8: D8D80020 35000035
	ds_load_b32 v10, v10 offset:32                             // 0000007F4FB0: D8D80020 0A00000A
	v_add_nc_u32_e32 v30, 0x200, v30                           // 0000007F4FB8: 4A3C3CFF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 0000007F4FC0: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007F4FC4: BF870149
	s_or_b32 s5, s1, s5                                        // 0000007F4FC8: 8C050501
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007F4FCC: BF890C57
	v_dot2_f32_bf16 v20, v33, v20, 0                           // 0000007F4FD0: CC1A4014 1A022921
	v_and_b32_e32 v33, 0xff, v11                               // 0000007F4FD8: 364216FF 000000FF
	v_dot2_f32_bf16 v20, v34, v49, v20                         // 0000007F4FE0: CC1A4014 1C526322
	v_lshrrev_b32_e32 v34, 6, v11                              // 0000007F4FE8: 32441686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007F4FEC: BF8701A2
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 0000007F4FF0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 14, v11                             // 0000007F4FF8: 3246168E
	v_and_b32_e32 v34, 0x3fc, v34                              // 0000007F4FFC: 364444FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007F5004: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007F5008: BF89FC47
	v_dot2_f32_bf16 v9, v36, v9, v20                           // 0000007F500C: CC1A4009 1C521324
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007F5014: 364646FF 000003FC
	v_lshrrev_b32_e32 v36, 6, v12                              // 0000007F501C: 32481886
	ds_load_b32 v34, v34 offset:32                             // 0000007F5020: D8D80020 22000022
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 0000007F5028: BF890847
	v_dot2_f32_bf16 v9, v37, v51, v9                           // 0000007F502C: CC1A4009 1C266725
	ds_load_b32 v35, v35 offset:32                             // 0000007F5034: D8D80020 23000023
	v_lshrrev_b32_e32 v37, 14, v12                             // 0000007F503C: 324A188E
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007F5040: 364848FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007F5048: BF89FC47
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 0000007F504C: CC1A4009 1C266926
	v_cndmask_b32_e64 v38, v6, v7, s0                          // 0000007F5054: D5010026 00020F06
	v_and_b32_e32 v37, 0x3fc, v37                              // 0000007F505C: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007F5064: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F5068: BF870133
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 0000007F506C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v7, v8, s0                          // 0000007F5074: D5010027 00021107
	s_waitcnt lgkmcnt(2)                                       // 0000007F507C: BF89FC27
	v_dot2_f32_bf16 v9, v40, v10, v9                           // 0000007F5080: CC1A4009 1C261528
	v_mov_b32_e32 v40, v8                                      // 0000007F5088: 7E500308
	v_lshlrev_b32_e32 v20, 2, v33                              // 0000007F508C: 30284282
	v_and_b32_e32 v33, 0xff, v12                               // 0000007F5090: 364218FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007F5098: 32181896
	ds_load_b32 v20, v20 offset:32                             // 0000007F509C: D8D80020 14000014
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000007F50A4: 30424282
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 0000007F50A8: BF890407
	v_dot2_f32_bf16 v9, v41, v20, v9                           // 0000007F50AC: CC1A4009 1C262929
	v_cndmask_b32_e64 v20, v29, v1, s0                         // 0000007F50B4: D5010014 0002031D
	v_mov_b32_e32 v29, v32                                     // 0000007F50BC: 7E3A0320
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F50C0: BF870123
	v_dot2_f32_bf16 v9, v42, v34, v9                           // 0000007F50C4: CC1A4009 1C26452A
	v_cndmask_b32_e64 v34, v2, v3, s0                          // 0000007F50CC: D5010022 00020702
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 0000007F50D4: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v3, v4, s0                          // 0000007F50DC: D5010023 00020903
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007F50E4: 361616FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007F50EC: 361818FF 000003FC
	ds_load_b32 v10, v11 offset:32                             // 0000007F50F4: D8D80020 0A00000B
	ds_load_b32 v11, v33 offset:32                             // 0000007F50FC: D8D80020 0B000021
	ds_load_b32 v33, v36 offset:32                             // 0000007F5104: D8D80020 21000024
	ds_load_b32 v49, v37 offset:32                             // 0000007F510C: D8D80020 31000025
	ds_load_b32 v50, v12 offset:32                             // 0000007F5114: D8D80020 3200000C
	v_cndmask_b32_e64 v37, v5, v6, s0                          // 0000007F511C: D5010025 00020D05
	v_cndmask_b32_e64 v36, v4, v5, s0                          // 0000007F5124: D5010024 00020B04
	v_mov_b32_e32 v12, v16                                     // 0000007F512C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 0000007F5130: BF89FC47
	v_dot2_f32_bf16 v9, v44, v10, v9                           // 0000007F5134: CC1A4009 1C26152C
	v_mov_b32_e32 v10, v14                                     // 0000007F513C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007F5140: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007F5144: BF870132
	v_dot2_f32_bf16 v9, v45, v11, v9                           // 0000007F5148: CC1A4009 1C26172D
	v_mov_b32_e32 v11, v15                                     // 0000007F5150: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 0000007F5154: BF89FC27
	v_dot2_f32_bf16 v5, v46, v33, v9                           // 0000007F5158: CC1A4005 1C26432E
	v_cndmask_b32_e64 v33, v1, v2, s0                          // 0000007F5160: D5010021 00020501
	v_add_nc_u32_e32 v31, 64, v31                              // 0000007F5168: 4A3E3EC0
	v_mov_b32_e32 v9, v13                                      // 0000007F516C: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007F5170: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007F5178: BF89FC17
	v_dot2_f32_bf16 v1, v47, v49, v5                           // 0000007F517C: CC1A4001 1C16632F
	s_waitcnt lgkmcnt(0)                                       // 0000007F5184: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5188: BF870091
	v_dot2_f32_bf16 v1, v48, v50, v1                           // 0000007F518C: CC1A4001 1C066530
	v_dual_fmac_f32 v26, v20, v1 :: v_dual_mov_b32 v1, v33     // 0000007F5194: C8100314 1A000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007F519C: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007F51A4: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007F51AC: CA100126 06060127
	v_mov_b32_e32 v8, v40                                      // 0000007F51B4: 7E100328
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000007F51B8: 917E057E
	s_cbranch_execz 35                                         // 0000007F51BC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x84c>
	s_waitcnt vmcnt(0)                                         // 0000007F51C0: BF8903F7
	v_dual_mov_b32 v14, v10 :: v_dual_add_nc_u32 v23, 32, v23  // 0000007F51C4: CA20010A 0E162EA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, v12          // 0000007F51CC: CA100109 0D10010C
	v_mov_b32_e32 v15, v11                                     // 0000007F51D4: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F51D8: BF870003
	.long 0xd4460001                                           // 0000007F51DC: D4460001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007F51E0: 02023117
	s_mov_b32 s10, exec_lo                                     // 0000007F51E4: BE8A007E
	.long 0xd4c1007e                                           // 0000007F51E8: D4C1007E
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007F51EC: 02023117
	s_cbranch_execz 65335                                      // 0000007F51F0: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v14, 31, v30                             // 0000007F51F4: 341C3C9F
	.long 0xd7006a0d                                           // 0000007F51F8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 0000007F51FC: 02023D12
	v_mov_b32_e32 v32, v29                                     // 0000007F5200: 7E40031D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007F5204: BF870003
	v_add_co_ci_u32_e64 v14, null, v28, v14, vcc_lo            // 0000007F5208: D5207C0E 01AA1D1C
	v_cmp_ne_u32_e32 vcc_lo, 1, v27                            // 0000007F5210: 7C9A3681
	global_load_b128 v[13:16], v[13:14], off                   // 0000007F5214: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 0000007F521C: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v20, 31, v31                             // 0000007F5220: 34283E9F
	.long 0xd7006a20                                           // 0000007F5224: D7006A20
	v_cndmask_b32_e32 v1, v17, v31, vcc_lo                     // 0000007F5228: 02023F11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007F522C: BF870001
	v_add_co_ci_u32_e64 v33, null, v25, v20, vcc_lo            // 0000007F5230: D5207C21 01AA2919
	global_load_d16_b16 v20, v[32:33], off                     // 0000007F5238: DC820000 147C0020
	s_waitcnt vmcnt(0)                                         // 0000007F5240: BF8903F7
	v_cvt_f32_f16_e32 v32, v20                                 // 0000007F5244: 7E401714
	s_branch 65313                                             // 0000007F5248: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007F524C: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F5250: BF8700B9
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007F5254: 8C7E047E
	.long 0xd71f0001                                           // 0000007F5258: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007F525C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000007F5260: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007F5264: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007F5268: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007F526C: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007F5270: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007F5274: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007F5278: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007F527C: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007F5280: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F5284: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007F5288: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007F528C: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007F5290: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007F5294: 02080901
	ds_bpermute_b32 v2, v2, v26                                // 0000007F5298: DACC0000 02001A02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007F52A0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007F52A4: BF89FC07
	v_add_f32_e32 v2, v26, v2                                  // 0000007F52A8: 0604051A
	ds_bpermute_b32 v3, v3, v2                                 // 0000007F52AC: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000007F52B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007F52B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007F52BC: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000007F52C4: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F52C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F52CC: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007F52D0: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007F52D4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007F52D8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007F52DC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007F52E0: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000007F52E8: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007F52EC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007F52F0: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000007F52F4: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000007F52F8: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000007F5300: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000007F5304: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v22                                   // 0000007F530C: 7D942C80
	s_cbranch_execz 5                                          // 0000007F5310: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x928>
	v_lshlrev_b32_e32 v3, 2, v21                               // 0000007F5314: 30062A82
	s_waitcnt lgkmcnt(0)                                       // 0000007F5318: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007F531C: 06020501
	ds_store_b32 v3, v1                                        // 0000007F5320: D8340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 0000007F5328: 8C7E007E
	.long 0xd4510000                                           // 0000007F532C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007F5330: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000007F5334: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007F5338: BF890007
	s_barrier                                                  // 0000007F533C: BFBD0000
	buffer_gl0_inv                                             // 0000007F5340: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 0000007F5348: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007F534C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000007F5350: BE812000
	s_cbranch_execz 69                                         // 0000007F5354: BFA50045 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xa6c>
	v_mov_b32_e32 v8, 0                                        // 0000007F5358: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007F535C: 84808102
	ds_load_b128 v[0:3], v8                                    // 0000007F5360: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 0000007F5368: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 0000007F5370: 80000008
	s_addc_u32 s1, s9, s1                                      // 0000007F5374: 82010109
	s_waitcnt lgkmcnt(1)                                       // 0000007F5378: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 0000007F537C: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5380: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 0000007F5384: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 0000007F5388: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007F538C: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 0000007F5390: 06000700
	s_waitcnt lgkmcnt(0)                                       // 0000007F5394: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 0000007F5398: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F539C: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 0000007F53A0: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 0000007F53A4: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F53A8: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 0000007F53AC: 06000F00
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007F53B0: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F53B8: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000007F53BC: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000007F53C0: 4A0000FF 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F53C8: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007F53CC: 360000FF FFFF0000
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000007F53D4: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007F53DC: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000007F53E0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007F53E4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007F53E8: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 0000007F53EC: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 0000007F53F4: D6FC6A04 03CA00F2
	v_rcp_f32_e32 v2, v1                                       // 0000007F53FC: 7E045501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 0000007F5400: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000007F5408: BF870085
	v_fma_f32 v3, v1, v2, 1.0                                  // 0000007F540C: D6130003 03CA0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5414: BF870091
	v_fmac_f32_e32 v2, v3, v2                                  // 0000007F5418: 56040503
	v_mul_f32_e32 v3, v4, v2                                   // 0000007F541C: 10060504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5420: BF870091
	v_fma_f32 v5, v1, v3, v4                                   // 0000007F5424: D6130005 04120701
	v_fmac_f32_e32 v3, v5, v2                                  // 0000007F542C: 56060505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5430: BF870091
	v_fmac_f32_e32 v4, v1, v3                                  // 0000007F5434: 56080701
	v_div_fmas_f32 v1, v4, v2, v3                              // 0000007F5438: D6370001 040E0504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5440: BF870091
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 0000007F5444: D6270000 03CA0101
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007F544C: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007F5454: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000007F5458: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000007F545C: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v8, v0, s[0:1]                     // 0000007F5464: DC960000 00000008
	s_endpgm                                                   // 0000007F546C: BFB00000
		...

