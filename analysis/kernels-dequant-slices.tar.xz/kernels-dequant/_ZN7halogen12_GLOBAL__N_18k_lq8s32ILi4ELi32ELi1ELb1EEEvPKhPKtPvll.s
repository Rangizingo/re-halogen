000000000072ae00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000072AE00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000072AE04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000072AE0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000072AE14: 32020085
	s_mov_b32 s3, 0                                            // 00000072AE18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000072AE1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000072AE24: 84808302
	.long 0x7e2e3880                                           // 00000072AE28: 7E2E3880
	v_or_b32_e32 v9, s0, v1                                    // 00000072AE2C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 00000072AE30: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 00000072AE38: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 00000072AE3C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000072AE40: 86009F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000072AE44: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000072AE48: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 00000072AE4C: 85009C00
	s_add_u32 s2, s10, s0                                      // 00000072AE50: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000072AE54: 8203800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000072AE58: BF870009
	s_ashr_i64 s[2:3], s[2:3], 4                               // 00000072AE5C: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 00000072AE60: 02021280
	s_add_u32 s0, s10, s2                                      // 00000072AE64: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000072AE68: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 00000072AE70: 8201030B
	s_add_u32 s0, s0, 15                                       // 00000072AE74: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000072AE78: 82018001
	s_and_b32 s0, s0, -16                                      // 00000072AE7C: 8B00D000
	.long 0xd72c0004                                           // 00000072AE80: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000072AE84: 02000301
	.long 0xd72c0007                                           // 00000072AE88: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000072AE8C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 00000072AE90: D6FE7C05 02000101
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000072AE98: CA100080 01020080
	.long 0xd4440000                                           // 00000072AEA0: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000072AEA4: 02021E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000072AEA8: BF870213
	v_add3_u32 v6, v6, v4, v7                                  // 00000072AEAC: D6550006 041E0906
	.long 0xd7000111                                           // 00000072AEB4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 00000072AEB8: 02020A04
	v_mov_b32_e32 v4, 0                                        // 00000072AEBC: 7E080280
	s_delay_alu instid0(VALU_DEP_3)                            // 00000072AEC0: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 00000072AEC4: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 00000072AECC: BE832000
	s_cbranch_execz 21                                         // 00000072AED0: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x128>
	v_lshlrev_b32_e32 v1, 4, v15                               // 00000072AED4: 30021E84
	.long 0xd7000103                                           // 00000072AED8: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 00000072AEDC: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 00000072AEE0: 360E009E
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 00000072AEE4: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072AEEC: BF870094
	.long 0xd7000101                                           // 00000072AEF0: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 00000072AEF4: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 00000072AEF8: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072AF00: BF870094
	.long 0xd7000107                                           // 00000072AF04: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 00000072AF08: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 00000072AF0C: D5207C08 00060880
	s_clause 0x1                                               // 00000072AF14: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 00000072AF18: DC5E0000 017C0001
	global_load_d16_b16 v23, v[7:8], off                       // 00000072AF20: DC820000 177C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 00000072AF28: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000072AF2C: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 00000072AF34: 7E2A0280
	s_and_saveexec_b32 s3, s0                                  // 00000072AF38: BE832000
	s_cbranch_execz 386                                        // 00000072AF3C: BFA50182 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x748>
	v_and_or_b32 v0, v0, 30, 32                                // 00000072AF40: D6570000 02813D00
	.long 0xd7000005                                           // 00000072AF48: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000072AF4C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072AF50: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 00000072AF54: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 00000072AF5C: 7E180280
	.long 0xd7000000                                           // 00000072AF60: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000072AF64: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072AF68: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 00000072AF6C: D5207C05 00020C80
	v_dual_mov_b32 v22, v15 :: v_dual_mov_b32 v21, v12         // 00000072AF74: CA10010F 1614010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072AF7C: BF870093
	.long 0xd700000d                                           // 00000072AF80: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000072AF84: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 00000072AF88: D5207C0E 00020A05
	v_mov_b32_e32 v20, v12                                     // 00000072AF90: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000072AF94: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 00000072AF98: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 00000072AF9C: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 00000072AFA0: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000072AFA4: 848E820A
	s_add_i32 s16, s16, s1                                     // 00000072AFA8: 81100110
	s_mul_i32 s18, s10, 6                                      // 00000072AFAC: 9612860A
	s_mov_b32 s17, 0                                           // 00000072AFB0: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000072AFB4: 8484810A
	s_branch 325                                               // 00000072AFB8: BFA00145 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x6d0>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000072AFBC: 8C7E0A7E
	.long 0xd73c0019                                           // 00000072AFC0: D73C0019
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000072AFC4: 02021681
	v_bfe_i32 v57, v1, 0, 8                                    // 00000072AFC8: D6110039 02210101
	v_bfe_i32 v58, v1, 8, 8                                    // 00000072AFD0: D611003A 02211101
	v_bfe_i32 v59, v1, 16, 8                                   // 00000072AFD8: D611003B 02212101
	v_bfe_i32 v63, v3, 0, 8                                    // 00000072AFE0: D611003F 02210103
	v_bfe_i32 v64, v3, 8, 8                                    // 00000072AFE8: D6110040 02211103
	.long 0xd7000129                                           // 00000072AFF0: D7000129
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 00000072AFF4: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000072AFF8: BF8701A1
	v_add_co_ci_u32_e64 v42, null, s7, v26, s1                 // 00000072AFFC: D5207C2A 00063407
	v_bfe_i32 v65, v3, 16, 8                                   // 00000072B004: D6110041 02212103
	.long 0xd700012d                                           // 00000072B00C: D700012D
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 00000072B010: 02000929
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000072B014: BF8700A1
	v_add_co_ci_u32_e64 v46, null, s5, v42, s1                 // 00000072B018: D5207C2E 00065405
	.long 0xd7000131                                           // 00000072B020: D7000131
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 00000072B024: 02001D29
	v_add_co_ci_u32_e64 v50, null, s15, v42, s1                // 00000072B028: D5207C32 0006540F
	.long 0xd7000135                                           // 00000072B030: D7000135
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 00000072B034: 02002529
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072B038: BF870001
	v_add_co_ci_u32_e64 v54, null, s16, v42, s1                // 00000072B03C: D5207C36 00065410
	s_clause 0x7                                               // 00000072B044: BF850007
	global_load_b128 v[25:28], v[41:42], off                   // 00000072B048: DC5E0000 197C0029
	global_load_b128 v[29:32], v[45:46], off                   // 00000072B050: DC5E0000 1D7C002D
	global_load_b128 v[33:36], v[49:50], off                   // 00000072B058: DC5E0000 217C0031
	global_load_b128 v[37:40], v[53:54], off                   // 00000072B060: DC5E0000 257C0035
	global_load_b128 v[41:44], v[41:42], off offset:16         // 00000072B068: DC5E0010 297C0029
	global_load_b128 v[45:48], v[45:46], off offset:16         // 00000072B070: DC5E0010 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:16         // 00000072B078: DC5E0010 317C0031
	global_load_b128 v[53:56], v[53:54], off offset:16         // 00000072B080: DC5E0010 357C0035
	v_ashrrev_i32_e32 v66, 24, v3                              // 00000072B088: 34840698
	v_bfe_i32 v67, v4, 0, 8                                    // 00000072B08C: D6110043 02210104
	v_bfe_i32 v68, v4, 8, 8                                    // 00000072B094: D6110044 02211104
	v_bfe_i32 v69, v4, 16, 8                                   // 00000072B09C: D6110045 02212104
	v_ashrrev_i32_e32 v70, 24, v4                              // 00000072B0A4: 348C0898
	s_waitcnt vmcnt(9)                                         // 00000072B0A8: BF8927F7
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000072B0AC: CA100108 04020107
	v_cvt_f32_i32_e32 v7, v57                                  // 00000072B0B4: 7E0E0B39
	.long 0x7f2e3880                                           // 00000072B0B8: 7F2E3880
	v_ashrrev_i32_e32 v1, 24, v1                               // 00000072B0BC: 34020298
	v_bfe_i32 v60, v2, 0, 8                                    // 00000072B0C0: D611003C 02210102
	v_mov_b32_e32 v11, v24                                     // 00000072B0C8: 7E160318
	v_cvt_f32_i32_e32 v8, v58                                  // 00000072B0CC: 7E100B3A
	v_cvt_f32_i32_e32 v24, v59                                 // 00000072B0D0: 7E300B3B
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 00000072B0D4: CC200007 8A020F17
	v_bfe_i32 v61, v2, 8, 8                                    // 00000072B0DC: D611003D 02211102
	v_bfe_i32 v62, v2, 16, 8                                   // 00000072B0E4: D611003E 02212102
	v_ashrrev_i32_e32 v2, 24, v2                               // 00000072B0EC: 34040498
	v_cvt_f32_i32_e32 v1, v1                                   // 00000072B0F0: 7E020B01
	v_cvt_f32_i32_e32 v58, v60                                 // 00000072B0F4: 7E740B3C
	v_fma_mix_f32 v8, v23, v8, neg(0) op_sel_hi:[1,0,0]        // 00000072B0F8: CC200008 8A021117
	v_fma_mix_f32 v24, v23, v24, neg(0) op_sel_hi:[1,0,0]      // 00000072B100: CC200018 8A023117
	v_bfe_u32 v72, v7, 16, 1                                   // 00000072B108: D6100048 02052107
	v_cvt_f32_i32_e32 v59, v61                                 // 00000072B110: 7E760B3D
	v_cvt_f32_i32_e32 v60, v62                                 // 00000072B114: 7E780B3E
	v_cvt_f32_i32_e32 v2, v2                                   // 00000072B118: 7E040B02
	v_cvt_f32_i32_e32 v62, v63                                 // 00000072B11C: 7E7C0B3F
	v_cvt_f32_i32_e32 v63, v64                                 // 00000072B120: 7E7E0B40
	v_cvt_f32_i32_e32 v64, v65                                 // 00000072B124: 7E800B41
	v_cvt_f32_i32_e32 v66, v66                                 // 00000072B128: 7E840B42
	v_cvt_f32_i32_e32 v67, v67                                 // 00000072B12C: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 00000072B130: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 00000072B134: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 00000072B138: 7E8C0B46
	v_fma_mix_f32 v1, v23, v1, neg(0) op_sel_hi:[1,0,0]        // 00000072B13C: CC200001 8A020317
	v_fma_mix_f32 v58, v23, v58, neg(0) op_sel_hi:[1,0,0]      // 00000072B144: CC20003A 8A027517
	v_bfe_u32 v73, v8, 16, 1                                   // 00000072B14C: D6100049 02052108
	v_bfe_u32 v74, v24, 16, 1                                  // 00000072B154: D610004A 02052118
	v_add3_u32 v7, v7, v72, 0x7fff                             // 00000072B15C: D6550007 03FE9107 00007FFF
	v_fma_mix_f32 v59, v23, v59, neg(0) op_sel_hi:[1,0,0]      // 00000072B168: CC20003B 8A027717
	v_fma_mix_f32 v60, v23, v60, neg(0) op_sel_hi:[1,0,0]      // 00000072B170: CC20003C 8A027917
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000072B178: CC200002 8A020517
	v_fma_mix_f32 v62, v23, v62, neg(0) op_sel_hi:[1,0,0]      // 00000072B180: CC20003E 8A027D17
	v_fma_mix_f32 v63, v23, v63, neg(0) op_sel_hi:[1,0,0]      // 00000072B188: CC20003F 8A027F17
	v_fma_mix_f32 v64, v23, v64, neg(0) op_sel_hi:[1,0,0]      // 00000072B190: CC200040 8A028117
	v_fma_mix_f32 v66, v23, v66, neg(0) op_sel_hi:[1,0,0]      // 00000072B198: CC200042 8A028517
	v_fma_mix_f32 v67, v23, v67, neg(0) op_sel_hi:[1,0,0]      // 00000072B1A0: CC200043 8A028717
	v_fma_mix_f32 v68, v23, v68, neg(0) op_sel_hi:[1,0,0]      // 00000072B1A8: CC200044 8A028917
	v_fma_mix_f32 v69, v23, v69, neg(0) op_sel_hi:[1,0,0]      // 00000072B1B0: CC200045 8A028B17
	v_fma_mix_f32 v70, v23, v70, neg(0) op_sel_hi:[1,0,0]      // 00000072B1B8: CC200046 8A028D17
	v_bfe_u32 v75, v1, 16, 1                                   // 00000072B1C0: D610004B 02052101
	v_bfe_u32 v76, v58, 16, 1                                  // 00000072B1C8: D610004C 0205213A
	v_add3_u32 v8, v8, v73, 0x7fff                             // 00000072B1D0: D6550008 03FE9308 00007FFF
	v_add3_u32 v24, v24, v74, 0x7fff                           // 00000072B1DC: D6550018 03FE9518 00007FFF
	.long 0x7e2e3987                                           // 00000072B1E8: 7E2E3987
	.long 0x7f723997                                           // 00000072B1EC: 7F723997
	v_bfe_u32 v77, v59, 16, 1                                  // 00000072B1F0: D610004D 0205213B
	v_bfe_u32 v78, v60, 16, 1                                  // 00000072B1F8: D610004E 0205213C
	v_add3_u32 v1, v1, v75, 0x7fff                             // 00000072B200: D6550001 03FE9701 00007FFF
	v_add3_u32 v58, v58, v76, 0x7fff                           // 00000072B20C: D655003A 03FE993A 00007FFF
	.long 0x7e723998                                           // 00000072B218: 7E723998
	v_and_or_b32 v7, 0xffff0000, v8, v23                       // 00000072B21C: D6570007 045E10FF FFFF0000
	v_bfe_u32 v79, v2, 16, 1                                   // 00000072B228: D610004F 02052102
	v_bfe_u32 v80, v62, 16, 1                                  // 00000072B230: D6100050 0205213E
	v_add3_u32 v59, v59, v77, 0x7fff                           // 00000072B238: D655003B 03FE9B3B 00007FFF
	v_add3_u32 v60, v60, v78, 0x7fff                           // 00000072B244: D655003C 03FE9D3C 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v57                       // 00000072B250: D6570001 04E602FF FFFF0000
	.long 0x7e2e39ba                                           // 00000072B25C: 7E2E39BA
	.long 0x7f7a3997                                           // 00000072B260: 7F7A3997
	v_bfe_u32 v81, v63, 16, 1                                  // 00000072B264: D6100051 0205213F
	v_bfe_u32 v82, v64, 16, 1                                  // 00000072B26C: D6100052 02052140
	v_add3_u32 v2, v2, v79, 0x7fff                             // 00000072B274: D6550002 03FE9F02 00007FFF
	v_add3_u32 v62, v62, v80, 0x7fff                           // 00000072B280: D655003E 03FEA13E 00007FFF
	.long 0x7e7a39bc                                           // 00000072B28C: 7E7A39BC
	v_bfe_u32 v83, v66, 16, 1                                  // 00000072B290: D6100053 02052142
	v_bfe_u32 v84, v67, 16, 1                                  // 00000072B298: D6100054 02052143
	v_add3_u32 v63, v63, v81, 0x7fff                           // 00000072B2A0: D655003F 03FEA33F 00007FFF
	v_add3_u32 v64, v64, v82, 0x7fff                           // 00000072B2AC: D6550040 03FEA540 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v61                       // 00000072B2B8: D6570002 04F604FF FFFF0000
	.long 0x7f823997                                           // 00000072B2C4: 7F823997
	v_bfe_u32 v85, v68, 16, 1                                  // 00000072B2C8: D6100055 02052144
	v_bfe_u32 v86, v69, 16, 1                                  // 00000072B2D0: D6100056 02052145
	v_add3_u32 v66, v66, v83, 0x7fff                           // 00000072B2D8: D6550042 03FEA742 00007FFF
	v_add3_u32 v67, v67, v84, 0x7fff                           // 00000072B2E4: D6550043 03FEA943 00007FFF
	.long 0x7e8239c0                                           // 00000072B2F0: 7E8239C0
	v_bfe_u32 v87, v70, 16, 1                                  // 00000072B2F4: D6100057 02052146
	v_add3_u32 v68, v68, v85, 0x7fff                           // 00000072B2FC: D6550044 03FEAB44 00007FFF
	v_add3_u32 v69, v69, v86, 0x7fff                           // 00000072B308: D6550045 03FEAD45 00007FFF
	.long 0x7f8e3997                                           // 00000072B314: 7F8E3997
	v_and_or_b32 v8, 0xffff0000, v66, v65                      // 00000072B318: D6570008 050684FF FFFF0000
	v_add3_u32 v70, v70, v87, 0x7fff                           // 00000072B324: D6550046 03FEAF46 00007FFF
	s_and_b32 s1, exec_lo, s0                                  // 00000072B330: 8B01007E
	.long 0x7e8e39c5                                           // 00000072B334: 7E8E39C5
	.long 0xd700000d                                           // 00000072B338: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000072B33C: 0201410D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072B340: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000072B344: D5207C0E 00021C80
	s_or_b32 s17, s1, s17                                      // 00000072B34C: 8C111101
	s_waitcnt vmcnt(7)                                         // 00000072B350: BF891FF7
	v_dot2_f32_bf16 v24, v25, v7, 0                            // 00000072B354: CC1A4018 1A020F19
	s_waitcnt vmcnt(6)                                         // 00000072B35C: BF891BF7
	v_dot2_f32_bf16 v25, v29, v7, 0                            // 00000072B360: CC1A4019 1A020F1D
	s_waitcnt vmcnt(5)                                         // 00000072B368: BF8917F7
	v_dot2_f32_bf16 v29, v33, v7, 0                            // 00000072B36C: CC1A401D 1A020F21
	s_waitcnt vmcnt(4)                                         // 00000072B374: BF8913F7
	v_dot2_f32_bf16 v7, v37, v7, 0                             // 00000072B378: CC1A4007 1A020F25
	v_and_or_b32 v33, 0xffff0000, v59, v23                     // 00000072B380: D6570021 045E76FF FFFF0000
	v_dot2_f32_bf16 v24, v26, v1, v24                          // 00000072B38C: CC1A4018 1C62031A
	v_dot2_f32_bf16 v25, v30, v1, v25                          // 00000072B394: CC1A4019 1C66031E
	v_dot2_f32_bf16 v26, v34, v1, v29                          // 00000072B39C: CC1A401A 1C760322
	v_dot2_f32_bf16 v1, v38, v1, v7                            // 00000072B3A4: CC1A4001 1C1E0326
	.long 0x7e2e39be                                           // 00000072B3AC: 7E2E39BE
	v_dot2_f32_bf16 v7, v27, v33, v24                          // 00000072B3B0: CC1A4007 1C62431B
	v_dot2_f32_bf16 v24, v31, v33, v25                         // 00000072B3B8: CC1A4018 1C66431F
	v_dot2_f32_bf16 v25, v35, v33, v26                         // 00000072B3C0: CC1A4019 1C6A4323
	v_dot2_f32_bf16 v1, v39, v33, v1                           // 00000072B3C8: CC1A4001 1C064327
	v_and_or_b32 v26, 0xffff0000, v63, v23                     // 00000072B3D0: D657001A 045E7EFF FFFF0000
	v_dot2_f32_bf16 v7, v28, v2, v7                            // 00000072B3DC: CC1A4007 1C1E051C
	v_dot2_f32_bf16 v24, v32, v2, v24                          // 00000072B3E4: CC1A4018 1C620520
	v_dot2_f32_bf16 v25, v36, v2, v25                          // 00000072B3EC: CC1A4019 1C660524
	v_dot2_f32_bf16 v1, v40, v2, v1                            // 00000072B3F4: CC1A4001 1C060528
	.long 0x7e2e39c3                                           // 00000072B3FC: 7E2E39C3
	s_waitcnt vmcnt(3)                                         // 00000072B400: BF890FF7
	v_dot2_f32_bf16 v2, v41, v26, v7                           // 00000072B404: CC1A4002 1C1E3529
	s_waitcnt vmcnt(2)                                         // 00000072B40C: BF890BF7
	v_dot2_f32_bf16 v7, v45, v26, v24                          // 00000072B410: CC1A4007 1C62352D
	s_waitcnt vmcnt(1)                                         // 00000072B418: BF8907F7
	v_dot2_f32_bf16 v24, v49, v26, v25                         // 00000072B41C: CC1A4018 1C663531
	s_waitcnt vmcnt(0)                                         // 00000072B424: BF8903F7
	v_dot2_f32_bf16 v1, v53, v26, v1                           // 00000072B428: CC1A4001 1C063535
	v_and_or_b32 v23, 0xffff0000, v68, v23                     // 00000072B430: D6570017 045E88FF FFFF0000
	v_dot2_f32_bf16 v2, v42, v8, v2                            // 00000072B43C: CC1A4002 1C0A112A
	v_dot2_f32_bf16 v7, v46, v8, v7                            // 00000072B444: CC1A4007 1C1E112E
	v_dot2_f32_bf16 v24, v50, v8, v24                          // 00000072B44C: CC1A4018 1C621132
	v_dot2_f32_bf16 v1, v54, v8, v1                            // 00000072B454: CC1A4001 1C061136
	v_and_or_b32 v8, 0xffff0000, v70, v71                      // 00000072B45C: D6570008 051E8CFF FFFF0000
	v_dot2_f32_bf16 v25, v43, v23, v2                          // 00000072B468: CC1A4019 1C0A2F2B
	v_dot2_f32_bf16 v7, v47, v23, v7                           // 00000072B470: CC1A4007 1C1E2F2F
	v_dot2_f32_bf16 v24, v51, v23, v24                         // 00000072B478: CC1A4018 1C622F33
	v_dot2_f32_bf16 v1, v55, v23, v1                           // 00000072B480: CC1A4001 1C062F37
	v_mov_b32_e32 v2, v6                                       // 00000072B488: 7E040306
	v_dot2_f32_bf16 v6, v44, v8, v25                           // 00000072B48C: CC1A4006 1C66112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 00000072B494: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v23, v52, v8, v24                          // 00000072B49C: CC1A4017 1C621134
	v_dot2_f32_bf16 v8, v56, v8, v1                            // 00000072B4A4: CC1A4008 1C061138
	v_mov_b32_e32 v1, v5                                       // 00000072B4AC: 7E020305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000072B4B0: BF870194
	v_dual_add_f32 v21, v21, v6 :: v_dual_add_f32 v20, v20, v7 // 00000072B4B4: C9080D15 15140F14
	v_dual_add_f32 v19, v19, v23 :: v_dual_add_f32 v16, v16, v8// 00000072B4BC: C9082F13 13101110
	.long 0x7e2e3900                                           // 00000072B4C4: 7E2E3900
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000072B4C8: 917E117E
	s_cbranch_execz 29                                         // 00000072B4CC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x744>
	v_add_nc_u32_e32 v22, 32, v22                              // 00000072B4D0: 4A2C2CA0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000072B4D4: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000072B4DC: BF8704A2
	.long 0xd4430000                                           // 00000072B4E0: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 00000072B4E4: 02022C02
	s_and_saveexec_b32 s1, s0                                  // 00000072B4E8: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 00000072B4EC: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 00000072B4F0: 4A3016FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 00000072B4F8: BE8A2201
	s_waitcnt vmcnt(0)                                         // 00000072B4FC: BF8903F7
	.long 0x7e003917                                           // 00000072B500: 7E003917
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 00000072B504: CA100101 05060102
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v8, v4             // 00000072B50C: CA100103 07080104
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000072B514: 8D7E0A7E
	s_cbranch_execz 65192                                      // 00000072B518: BFA5FEA8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x1bc>
	.long 0xd7000105                                           // 00000072B51C: D7000105
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 00000072B520: 02023111
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072B524: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 00000072B528: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 00000072B530: DC5E0000 057C0005
	global_load_d16_b16 v0, v[13:14], off                      // 00000072B538: DC820000 007C000D
	s_branch 65182                                             // 00000072B540: BFA0FE9E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x1bc>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000072B544: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000072B548: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000072B54C: 8C7E037E
	.long 0xd71f0000                                           // 00000072B550: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000072B554: 020100C1
	s_waitcnt vmcnt(1)                                         // 00000072B558: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 00000072B55C: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 00000072B560: 3A0A0088
	v_xor_b32_e32 v11, 4, v0                                   // 00000072B564: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072B568: BF870093
	.long 0xd44c0000                                           // 00000072B56C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000072B570: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 00000072B574: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000072B57C: BF870114
	.long 0xd44c0000                                           // 00000072B580: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000072B584: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000072B588: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072B58C: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 00000072B590: D5010005 00020B00
	.long 0xd44c0000                                           // 00000072B598: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000072B59C: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 00000072B5A0: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000072B5A8: D501000B 00021700
	s_waitcnt lgkmcnt(0)                                       // 00000072B5B0: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 00000072B5B4: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 00000072B5B8: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 00000072B5C0: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v16                                // 00000072B5C8: DACC0000 01001001
	s_waitcnt lgkmcnt(2)                                       // 00000072B5D0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 00000072B5D4: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 00000072B5DC: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 00000072B5E4: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 00000072B5E8: 06060714
	s_waitcnt lgkmcnt(1)                                       // 00000072B5EC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 00000072B5F0: 06020310
	ds_bpermute_b32 v8, v5, v4                                 // 00000072B5F4: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 00000072B5FC: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 00000072B600: C9220D02 020A1682
	ds_bpermute_b32 v7, v5, v3                                 // 00000072B608: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 00000072B610: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 00000072B618: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v1, v1, v5     // 00000072B61C: C9081104 04000B01
	ds_bpermute_b32 v5, v11, v2                                // 00000072B624: DACC0000 0500020B
	v_add_f32_e32 v3, v3, v7                                   // 00000072B62C: 06060F03
	ds_bpermute_b32 v7, v11, v4                                // 00000072B630: DACC0000 0700040B
	ds_bpermute_b32 v8, v11, v1                                // 00000072B638: DACC0000 0800010B
	s_waitcnt lgkmcnt(2)                                       // 00000072B640: BF89FC27
	v_add_f32_e32 v2, v2, v5                                   // 00000072B644: 06040B02
	ds_bpermute_b32 v6, v11, v3                                // 00000072B648: DACC0000 0600030B
	v_xor_b32_e32 v11, 2, v0                                   // 00000072B650: 3A160082
	s_waitcnt lgkmcnt(2)                                       // 00000072B654: BF89FC27
	v_add_f32_e32 v5, v4, v7                                   // 00000072B658: 060A0F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072B65C: BF870092
	.long 0xd44c0000                                           // 00000072B660: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000072B664: 020216A0
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000072B668: D501000B 00021700
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072B670: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 00000072B674: 30161682
	s_waitcnt lgkmcnt(0)                                       // 00000072B678: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 00000072B67C: 06060D03
	ds_bpermute_b32 v4, v11, v2                                // 00000072B680: DACC0000 0400020B
	ds_bpermute_b32 v7, v11, v5                                // 00000072B688: DACC0000 0700050B
	ds_bpermute_b32 v6, v11, v3                                // 00000072B690: DACC0000 0600030B
	s_waitcnt lgkmcnt(1)                                       // 00000072B698: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v5, v5, v7     // 00000072B69C: C9080902 02040F05
	s_waitcnt lgkmcnt(0)                                       // 00000072B6A4: BF89FC07
	v_dual_add_f32 v4, v3, v6 :: v_dual_add_f32 v1, v1, v8     // 00000072B6A8: C9080D03 04001101
	ds_bpermute_b32 v8, v11, v1                                // 00000072B6B0: DACC0000 0800010B
	v_xor_b32_e32 v11, 1, v0                                   // 00000072B6B8: 3A160081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000072B6BC: BF870091
	.long 0xd44c0000                                           // 00000072B6C0: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000072B6C4: 020216A0
	v_cndmask_b32_e64 v0, v0, v11, s0                          // 00000072B6C8: D5010000 00021700
	.long 0xd44a0000                                           // 00000072B6D0: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000072B6D4: 02021E80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000072B6D8: BF870002
	v_lshlrev_b32_e32 v11, 2, v0                               // 00000072B6DC: 30160082
	s_and_b32 s0, s0, vcc_lo                                   // 00000072B6E0: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 00000072B6E4: BF89FC07
	v_add_f32_e32 v0, v1, v8                                   // 00000072B6E8: 06001101
	ds_bpermute_b32 v3, v11, v2                                // 00000072B6EC: DACC0000 0300020B
	ds_bpermute_b32 v6, v11, v4                                // 00000072B6F4: DACC0000 0600040B
	ds_bpermute_b32 v7, v11, v5                                // 00000072B6FC: DACC0000 0700050B
	ds_bpermute_b32 v1, v11, v0                                // 00000072B704: DACC0000 0100000B
	s_and_saveexec_b32 s1, s0                                  // 00000072B70C: BE812000
	s_cbranch_execz 38                                         // 00000072B710: BFA50026 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb1EEEvPKhPKtPvll+0x9ac>
	.long 0xd73c0008                                           // 00000072B714: D73C0008
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000072B718: 02021282
	s_waitcnt lgkmcnt(1)                                       // 00000072B71C: BF89FC17
	v_dual_add_f32 v10, v5, v7 :: v_dual_add_f32 v11, v4, v6   // 00000072B720: C9080F05 0A0A0D04
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000072B728: 8480820C
	v_add_f32_e32 v12, v2, v3                                  // 00000072B72C: 06180702
	s_lshl_b64 s[2:3], s[12:13], 3                             // 00000072B730: 8482830C
	.long 0xd7006a08                                           // 00000072B734: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 00000072B738: 02021008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000072B73C: BF8701B1
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 00000072B740: D5207C09 01AA1209
	s_waitcnt lgkmcnt(0)                                       // 00000072B748: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 00000072B74C: 06000300
	.long 0xd7006a02                                           // 00000072B750: D7006A02
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000072B754: 02000108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000072B758: BF870123
	v_mad_u64_u32 v[4:5], null, s12, 12, v[8:9]                // 00000072B75C: D6FE7C04 0421180C
	v_add_co_ci_u32_e64 v3, null, s1, v9, vcc_lo               // 00000072B764: D5207C03 01AA1201
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 00000072B76C: D6FE7C05 0415180D
	.long 0xd7006a06                                           // 00000072B774: D7006A06
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 00000072B778: 02000508
	s_delay_alu instid0(VALU_DEP_1)                            // 00000072B77C: BF870001
	v_add_co_ci_u32_e64 v7, null, s3, v9, vcc_lo               // 00000072B780: D5207C07 01AA1203
	s_clause 0x3                                               // 00000072B788: BF850003
	global_store_b32 v[8:9], v12, off                          // 00000072B78C: DC6A0000 007C0C08
	global_store_b32 v[2:3], v11, off                          // 00000072B794: DC6A0000 007C0B02
	global_store_b32 v[6:7], v10, off                          // 00000072B79C: DC6A0000 007C0A06
	global_store_b32 v[4:5], v0, off                           // 00000072B7A4: DC6A0000 007C0004
	s_endpgm                                                   // 00000072B7AC: BFB00000
		...

