00000000007c2e00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007C2E00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000007C2E08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C2E10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007C2E14: 86039F02
	v_lshrrev_b32_e32 v15, 5, v0                               // 0000007C2E18: 321E0085
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C2E1C: BF870003
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C2E20: 30020282
	.long 0x7f283880                                           // 0000007C2E24: 7F283880
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v2, 60, v2         // 0000007C2E28: CA240080 110204BC
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000007C2E30: CA100080 04020080
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000007C2E38: 301C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007C2E3C: BF89FC07
	s_clause 0x1                                               // 0000007C2E40: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 0000007C2E44: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 0000007C2E4C: DC520000 0D040002
	.long 0xd4510014                                           // 0000007C2E54: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007C2E58: 02001802
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000007C2E5C: CA100080 01020080
	s_and_b32 s20, s20, exec_lo                                // 0000007C2E64: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 0000007C2E68: 98188003
	s_cselect_b32 s25, s2, 0                                   // 0000007C2E6C: 98198002
	s_add_u32 s14, s4, s14                                     // 0000007C2E70: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007C2E74: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 0000007C2E78: 85149F0B
	v_dual_mov_b32 v5, s14 :: v_dual_and_b32 v16, 31, v0       // 0000007C2E7C: CA24000E 0510009F
	s_add_u32 s20, s10, s20                                    // 0000007C2E84: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000007C2E88: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000007C2E8C: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000007C2E90: 86948114
	s_lshr_b32 s22, s22, 27                                    // 0000007C2E94: 85169B16
	v_mov_b32_e32 v6, s15                                      // 0000007C2E98: 7E0C020F
	s_add_u32 s22, s10, s22                                    // 0000007C2E9C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000007C2EA0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000007C2EA4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000007C2EA8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007C2EAC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000007C2EB0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000007C2EB4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007C2EB8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000007C2EBC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000007C2EC0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C2EC4: BF870009
	s_ashr_i32 s14, s23, 3                                     // 0000007C2EC8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000007C2ECC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000007C2ED0: 82051105
	.long 0xd72c0013                                           // 0000007C2ED4: D72C0013
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000007C2ED8: 02021E0E
	v_dual_mov_b32 v8, s5 :: v_dual_mov_b32 v7, s4             // 0000007C2EDC: CA100005 08060004
	v_mad_u64_u32 v[9:10], null, s25, s20, v[5:6]              // 0000007C2EE4: D6FE7C09 04142819
	s_mul_i32 s4, s24, s20                                     // 0000007C2EEC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000007C2EF0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000007C2EF4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000007C2EFC: BF8903F7
	v_bfe_u32 v5, v13, 16, 1                                   // 0000007C2F00: D6100005 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007C2F08: BF870232
	v_add3_u32 v6, v11, v12, 0x7fff                            // 0000007C2F0C: D6550006 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s25, v[7:8]             // 0000007C2F18: D6FE7C0B 041C3212
	v_add_nc_u32_e32 v7, s14, v19                              // 0000007C2F20: 4A0E260E
	v_add3_u32 v5, v13, v5, 0x7fff                             // 0000007C2F24: D6550005 03FE0B0D 00007FFF
	s_mul_i32 s25, s25, s21                                    // 0000007C2F30: 96191519
	.long 0x7e283986                                           // 0000007C2F34: 7E283986
	v_add_nc_u32_e32 v6, s4, v10                               // 0000007C2F38: 4A0C1404
	v_add_nc_u32_e32 v10, v19, v16                             // 0000007C2F3C: 4A142113
	v_min_i32_e32 v19, s22, v7                                 // 0000007C2F40: 22260E16
	v_add_nc_u32_e32 v7, s19, v12                              // 0000007C2F44: 4A0E1813
	s_mul_i32 s4, s18, s24                                     // 0000007C2F48: 96041812
	v_and_or_b32 v5, 0xffff0000, v5, v20                       // 0000007C2F4C: D6570005 04520AFF FFFF0000
	v_add_nc_u32_e32 v20, s25, v6                              // 0000007C2F58: 4A280C19
	v_cmp_lt_i32_e32 vcc_lo, v10, v19                          // 0000007C2F5C: 7C82270A
	v_add_nc_u32_e32 v21, s4, v7                               // 0000007C2F60: 4A2A0E04
	ds_store_b32 v14, v5                                       // 0000007C2F64: D8340000 0000050E
	s_waitcnt lgkmcnt(0)                                       // 0000007C2F6C: BF89FC07
	s_barrier                                                  // 0000007C2F70: BFBD0000
	buffer_gl0_inv                                             // 0000007C2F74: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000007C2F7C: BE85206A
	s_cbranch_execz 21                                         // 0000007C2F80: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 0000007C2F84: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 0000007C2F88: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C2F8C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007C2F90: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007C2F94: 3408069F
	.long 0xd7000401                                           // 0000007C2F98: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007C2F9C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2FA0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s4                  // 0000007C2FA4: D5207C02 00120515
	.long 0xd7000403                                           // 0000007C2FAC: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007C2FB0: 02020709
	v_add_co_ci_u32_e64 v4, null, v20, v4, s4                  // 0000007C2FB4: D5207C04 00120914
	s_clause 0x1                                               // 0000007C2FBC: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000007C2FC0: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007C2FC8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007C2FD0: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000007C2FD4: 7E241705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C2FD8: 8C7E057E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000007C2FDC: CA100080 17160080
	s_and_saveexec_b32 s5, vcc_lo                              // 0000007C2FE4: BE85206A
	s_cbranch_execz 314                                        // 0000007C2FE8: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6d4>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v10     // 0000007C2FEC: CA200080 160414A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000007C2FF4: CA220080 170C1485
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000007C2FFC: 848E820A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C3000: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 0000007C3004: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 0000007C300C: CA220112 1A180A81
	s_mov_b32 s16, 0                                           // 0000007C3014: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007C3018: 848A810A
	s_branch 269                                               // 0000007C301C: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x654>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007C3020: 8C7E117E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007C3024: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 0000007C3028: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 0000007C302C: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 0000007C3030: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 0000007C3038: 329C0486
	.long 0xd73c001b                                           // 0000007C303C: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007C3040: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000007C3044: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 0000007C304C: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000007C3054: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007C305C: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 0000007C3060: 329E048E
	.long 0xd700043f                                           // 0000007C3064: D700043F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000007C3068: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C306C: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s4                 // 0000007C3070: D5207C40 00123807
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000007C3078: 301A1A82
	.long 0xd7000443                                           // 0000007C307C: D7000443
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 0000007C3080: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C3084: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s4                // 0000007C3088: D5207C44 0012800B
	.long 0xd7000447                                           // 0000007C3090: D7000447
	v_cndmask_b32_e32 v0, v63, v14, vcc_lo                     // 0000007C3094: 02001D3F
	v_add_co_ci_u32_e64 v72, null, s15, v64, s4                // 0000007C3098: D5207C48 0012800F
	s_clause 0xb                                               // 0000007C30A0: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 0000007C30A4: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 0000007C30AC: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 0000007C30B4: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 0000007C30BC: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 0000007C30C4: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 0000007C30CC: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 0000007C30D4: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 0000007C30DC: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 0000007C30E4: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000007C30EC: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 0000007C30F4: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 0000007C30FC: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 0000007C3104: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 0000007C310C: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000007C3114: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007C311C: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007C3120: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 0000007C3128: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 0000007C312C: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000007C3134: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007C313C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007C3144: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 0000007C314C: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 0000007C3154: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 0000007C315C: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 0000007C3164: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 0000007C316C: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 0000007C3174: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 0000007C3178: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007C317C: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 0000007C3180: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 0000007C3188: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000007C318C: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 0000007C3194: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007C3198: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007C31A0: 4A1818FF 00000400
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000007C31A8: 8B046A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C31AC: BF870009
	s_or_b32 s16, s4, s16                                      // 0000007C31B0: 8C101004
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000007C31B4: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 0000007C31B8: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 0000007C31C0: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000007C31C4: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 0000007C31CC: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 0000007C31D0: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 0000007C31D8: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007C31DC: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000007C31E0: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 0000007C31E4: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 0000007C31EC: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 0000007C31F4: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 0000007C31FC: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 0000007C3200: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C3208: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 0000007C320C: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 0000007C3214: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 0000007C321C: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 0000007C3224: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 0000007C322C: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 0000007C3234: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 0000007C3238: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 0000007C3240: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 0000007C3248: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 0000007C3250: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 0000007C3258: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007C3260: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 0000007C3264: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 0000007C326C: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 0000007C3270: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 0000007C3278: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 0000007C327C: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 0000007C3284: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 0000007C3288: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000007C3290: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 0000007C3294: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 0000007C329C: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 0000007C32A4: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 0000007C32AC: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007C32B4: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007C32BC: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 0000007C32C0: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 0000007C32C8: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 0000007C32D0: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 0000007C32D8: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C32DC: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 0000007C32E0: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 0000007C32E8: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C32F0: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 0000007C32F4: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 0000007C32FC: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 0000007C3304: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 0000007C330C: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 0000007C3314: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 0000007C331C: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 0000007C3324: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 0000007C3328: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 0000007C3330: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 0000007C3334: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 0000007C333C: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 0000007C3340: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 0000007C3348: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 0000007C334C: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 0000007C3354: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C335C: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 0000007C3360: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 0000007C3368: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C3370: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 0000007C3374: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 0000007C337C: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 0000007C3384: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C3388: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 0000007C338C: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 0000007C3394: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C339C: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000007C33A0: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007C33A8: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 0000007C33AC: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 0000007C33B4: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 0000007C33B8: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 0000007C33C0: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 0000007C33C4: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 0000007C33CC: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 0000007C33D0: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 0000007C33D8: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C33E0: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 0000007C33E4: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 0000007C33EC: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000007C33F0: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 0000007C33F4: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 0000007C33FC: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 0000007C3404: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000007C340C: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 0000007C3414: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 0000007C3418: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 0000007C3420: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 0000007C3428: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C3430: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 0000007C3434: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 0000007C343C: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C3440: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 0000007C3444: 56221112
	v_mov_b32_e32 v18, v26                                     // 0000007C3448: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007C344C: 917E107E
	s_cbranch_execz 31                                         // 0000007C3450: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x6d0>
	s_waitcnt vmcnt(0)                                         // 0000007C3454: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v10, 32, v10    // 0000007C3458: CA200101 050A14A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000007C3460: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000007C3468: 7E100304
	s_mov_b32 s17, exec_lo                                     // 0000007C346C: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C3470: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v19                          // 0000007C3474: 7C8C270A
	.long 0xd4c1007e                                           // 0000007C3478: D4C1007E
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 0000007C347C: 0202270A
	s_cbranch_execz 65255                                      // 0000007C3480: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x220>
	v_ashrrev_i32_e32 v6, 31, v25                              // 0000007C3484: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 0000007C3488: 3410309F
	.long 0xd7000405                                           // 0000007C348C: D7000405
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000007C3490: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C3494: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s4                  // 0000007C3498: D5207C06 00120D15
	.long 0xd7000407                                           // 0000007C34A0: D7000407
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007C34A4: 02023109
	v_add_co_ci_u32_e64 v8, null, v20, v8, s4                  // 0000007C34A8: D5207C08 00121114
	s_clause 0x1                                               // 0000007C34B0: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000007C34B4: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000007C34BC: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000007C34C4: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 0000007C34C8: 7E34170D
	s_branch 65236                                             // 0000007C34CC: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x220>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007C34D0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007C34D4: BF8700C9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C34D8: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 0000007C34DC: BF8903F7
	.long 0xd71f0001                                           // 0000007C34E0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C34E4: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007C34E8: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007C34EC: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000007C34F0: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000007C34F4: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C34F8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007C34FC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007C3500: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C3504: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000007C3508: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C350C: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C3510: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007C3514: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007C3518: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000007C351C: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000007C3524: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 0000007C3528: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 0000007C352C: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 0000007C3534: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 0000007C353C: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C3544: 02101101
	s_waitcnt lgkmcnt(2)                                       // 0000007C3548: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 0000007C354C: 06080917
	s_waitcnt lgkmcnt(0)                                       // 0000007C3550: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000007C3554: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000007C3558: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 0000007C3560: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007C3564: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 0000007C3568: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 0000007C3570: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000007C3574: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C3578: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 0000007C3580: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000007C3584: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 0000007C3588: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C358C: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C3594: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000007C359C: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C35A0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C35A4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C35A8: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000007C35AC: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000007C35B0: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000007C35B8: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000007C35BC: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C35C0: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C35C8: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C35D0: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000007C35D8: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C35DC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C35E0: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000007C35E4: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000007C35E8: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000007C35EC: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000007C35F0: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000007C35F4: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000007C35F8: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000007C3600: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000007C3608: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000007C3610: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 0000007C3618: 7D942080
	s_cbranch_execz 12                                         // 0000007C361C: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x850>
	v_mul_u32_u24_e32 v7, 12, v15                              // 0000007C3620: 160E1E8C
	s_waitcnt lgkmcnt(0)                                       // 0000007C3624: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 0000007C3628: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 0000007C3630: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C3634: BF870003
	v_or_b32_e32 v4, 0x400, v7                                 // 0000007C3638: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000007C3640: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 0000007C3648: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C3650: 8C7E047E
	.long 0xd4510004                                           // 0000007C3654: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007C3658: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 0000007C365C: 7C980083
	s_waitcnt lgkmcnt(0)                                       // 0000007C3660: BF89FC07
	s_barrier                                                  // 0000007C3664: BFBD0000
	buffer_gl0_inv                                             // 0000007C3668: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007C3670: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C3674: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007C3678: BE852004
	s_cbranch_execz 89                                         // 0000007C367C: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x9e4>
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C3680: F4000000 F8000048
	v_add_nc_u32_e32 v7, 0x400, v14                            // 0000007C3688: 4A0E1CFF 00000400
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 0000007C3690: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 0000007C3698: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 0000007C36A0: D8DC0F0C 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007C36A8: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007C36AC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C36B0: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007C36B4: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:18 offset1:21         // 0000007C36B8: D8DC1512 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007C36C0: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007C36C4: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C36C8: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007C36CC: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007C36D0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007C36D4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C36D8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007C36DC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007C36E0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C36E4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007C36E8: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007C36F0: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C36FC: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C3700: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007C3708: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007C370C: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C3710: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007C3714: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007C371C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C3720: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007C3724: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007C3728: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007C3730: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C3738: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007C373C: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007C3740: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C3748: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007C374C: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000007C3750: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 0000007C3758: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C375C: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007C3760: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007C3768: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C376C: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007C3770: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000007C3778: D6FE7C02 040A000D
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007C3780: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C3788: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007C378C: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007C3794: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007C3798: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C379C: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007C37A0: D6100002 02052103
	.long 0xd7006a00                                           // 0000007C37A8: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007C37AC: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C37B0: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007C37B4: D5207C01 01AA0209
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007C37BC: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C37C8: BF870093
	.long 0xd7006a00                                           // 0000007C37CC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007C37D0: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007C37D4: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007C37DC: DC960000 007C0200
	s_endpgm                                                   // 0000007C37E4: BFB00000
		...

