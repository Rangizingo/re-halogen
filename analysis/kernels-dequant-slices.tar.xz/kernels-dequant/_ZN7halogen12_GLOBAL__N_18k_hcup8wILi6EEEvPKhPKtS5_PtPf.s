00000000003d8100 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003D8100: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003D8108: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003D810C: D6100002 02090900
	s_lshl_b32 s2, s2, 2                                       // 0000003D8114: 84028202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v11, 15, v0        // 0000003D8118: CA240080 0C0A008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D8120: BF870193
	v_or_b32_e32 v1, s2, v1                                    // 0000003D8124: 38020202
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003D8128: 160404FF 00000A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D8130: BF870223
	v_lshlrev_b32_e32 v15, 4, v11                              // 0000003D8134: 301E1684
	v_or_b32_e32 v14, 16, v11                                  // 0000003D8138: 381C1690
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003D813C: 3406029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8140: BF870094
	.long 0xd7006a01                                           // 0000003D8144: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000003D8148: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000003D814C: D5207C02 01AA0680
	v_and_b32_e32 v3, 12, v0                                   // 0000003D8154: 3606008C
	s_waitcnt lgkmcnt(0)                                       // 0000003D8158: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003D815C: BF8700D3
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 0000003D8160: D6FE7C09 001202FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003D816C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003D8174: BE80007E
	v_mad_i32_i24 v10, 0x154, v2, v10                          // 0000003D8178: D60A000A 042A04FF 00000154
	.long 0xd7006a01                                           // 0000003D8184: D7006A01
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                      // 0000003D8188: 02021F09
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 0000003D818C: D5207C02 01AA1480
	.long 0xd7006a03                                           // 0000003D8194: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000003D8198: 02020709
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D819C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 0000003D81A0: D5207C04 01AA1480
	s_clause 0x1                                               // 0000003D81A8: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000003D81AC: DC5E0000 057C0001
	global_load_b32 v13, v[3:4], off offset:320                // 0000003D81B4: DC520140 0D7C0003
	v_cmpx_gt_u32_e32 20, v14                                  // 0000003D81BC: 7D981C94
	s_cbranch_execz 5                                          // 0000003D81C0: BFA50005 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf+0xd8>
	s_clause 0x1                                               // 0000003D81C4: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 0000003D81C8: DC5E0100 017C0001
	global_load_b32 v12, v[9:10], off offset:336               // 0000003D81D0: DC520150 0C7C0009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D81D8: 8C7E007E
	v_lshlrev_b32_e32 v15, 1, v15                              // 0000003D81DC: 301E1E81
	s_waitcnt vmcnt(1)                                         // 0000003D81E0: BF8907F7
	v_cvt_f32_ubyte0_e32 v10, v5                               // 0000003D81E4: 7E142305
	v_cvt_f32_ubyte1_e32 v64, v5                               // 0000003D81E8: 7E802505
	v_cvt_f32_ubyte2_e32 v65, v5                               // 0000003D81EC: 7E822705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003D81F0: 7E0A2905
	s_clause 0xb                                               // 0000003D81F4: BF85000B
	global_load_b128 v[16:19], v15, s[6:7]                     // 0000003D81F8: DC5E0000 1006000F
	global_load_b128 v[20:23], v15, s[6:7] offset:640          // 0000003D8200: DC5E0280 1406000F
	global_load_b128 v[24:27], v15, s[6:7] offset:1280         // 0000003D8208: DC5E0500 1806000F
	global_load_b128 v[28:31], v15, s[6:7] offset:1920         // 0000003D8210: DC5E0780 1C06000F
	global_load_b128 v[32:35], v15, s[6:7] offset:2560         // 0000003D8218: DC5E0A00 2006000F
	global_load_b128 v[36:39], v15, s[6:7] offset:3200         // 0000003D8220: DC5E0C80 2406000F
	global_load_b128 v[40:43], v15, s[6:7] offset:16           // 0000003D8228: DC5E0010 2806000F
	global_load_b128 v[44:47], v15, s[6:7] offset:656          // 0000003D8230: DC5E0290 2C06000F
	global_load_b128 v[48:51], v15, s[6:7] offset:1296         // 0000003D8238: DC5E0510 3006000F
	global_load_b128 v[52:55], v15, s[6:7] offset:1936         // 0000003D8240: DC5E0790 3406000F
	global_load_b128 v[56:59], v15, s[6:7] offset:2576         // 0000003D8248: DC5E0A10 3806000F
	global_load_b128 v[60:63], v15, s[6:7] offset:3216         // 0000003D8250: DC5E0C90 3C06000F
	v_cvt_f32_ubyte0_e32 v66, v6                               // 0000003D8258: 7E842306
	v_cvt_f32_ubyte1_e32 v67, v6                               // 0000003D825C: 7E862506
	v_cvt_f32_ubyte2_e32 v68, v6                               // 0000003D8260: 7E882706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003D8264: 7E0C2906
	v_cvt_f32_ubyte0_e32 v69, v7                               // 0000003D8268: 7E8A2307
	v_cvt_f32_ubyte1_e32 v70, v7                               // 0000003D826C: 7E8C2507
	v_cvt_f32_ubyte2_e32 v71, v7                               // 0000003D8270: 7E8E2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003D8274: 7E0E2907
	v_cvt_f32_ubyte0_e32 v72, v8                               // 0000003D8278: 7E902308
	v_cvt_f32_ubyte1_e32 v73, v8                               // 0000003D827C: 7E922508
	v_cvt_f32_ubyte2_e32 v74, v8                               // 0000003D8280: 7E942708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 0000003D8284: 7E102908
	s_waitcnt vmcnt(12)                                        // 0000003D8288: BF8933F7
	v_fma_mix_f32 v10, v10, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D828C: CC20600A 14361B0A
	v_fma_mix_f32 v64, v64, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D8294: CC206040 14361B40
	v_fma_mix_f32 v65, v65, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D829C: CC206041 14361B41
	v_fma_mix_f32 v5, v5, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82A4: CC206005 14361B05
	v_fma_mix_f32 v66, v66, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82AC: CC206042 14361B42
	v_fma_mix_f32 v67, v67, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82B4: CC206043 14361B43
	v_fma_mix_f32 v68, v68, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82BC: CC206044 14361B44
	v_fma_mix_f32 v6, v6, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82C4: CC206006 14361B06
	v_fma_mix_f32 v69, v69, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82CC: CC206045 14361B45
	v_fma_mix_f32 v70, v70, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82D4: CC206046 14361B46
	v_fma_mix_f32 v71, v71, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82DC: CC206047 14361B47
	v_fma_mix_f32 v7, v7, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82E4: CC206007 14361B07
	v_fma_mix_f32 v72, v72, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82EC: CC206048 14361B48
	v_fma_mix_f32 v73, v73, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82F4: CC206049 14361B49
	v_fma_mix_f32 v74, v74, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D82FC: CC20604A 14361B4A
	v_fma_mix_f32 v8, v8, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D8304: CC206008 14361B08
	v_bfe_u32 v13, v10, 16, 1                                  // 0000003D830C: D610000D 0205210A
	v_bfe_u32 v79, v64, 16, 1                                  // 0000003D8314: D610004F 02052140
	v_bfe_u32 v80, v65, 16, 1                                  // 0000003D831C: D6100050 02052141
	.long 0x7f123880                                           // 0000003D8324: 7F123880
	v_bfe_u32 v81, v5, 16, 1                                   // 0000003D8328: D6100051 02052105
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000003D8330: D655000A 03FE1B0A 00007FFF
	v_bfe_u32 v82, v66, 16, 1                                  // 0000003D833C: D6100052 02052142
	v_add3_u32 v13, v64, v79, 0x7fff                           // 0000003D8344: D655000D 03FE9F40 00007FFF
	v_add3_u32 v64, v65, v80, 0x7fff                           // 0000003D8350: D6550040 03FEA141 00007FFF
	.long 0x7f963989                                           // 0000003D835C: 7F963989
	.long 0x7e12398a                                           // 0000003D8360: 7E12398A
	v_bfe_u32 v83, v67, 16, 1                                  // 0000003D8364: D6100053 02052143
	v_bfe_u32 v84, v68, 16, 1                                  // 0000003D836C: D6100054 02052144
	v_add3_u32 v5, v5, v81, 0x7fff                             // 0000003D8374: D6550005 03FEA305 00007FFF
	v_add3_u32 v65, v66, v82, 0x7fff                           // 0000003D8380: D6550041 03FEA542 00007FFF
	v_and_or_b32 v13, 0xffff0000, v13, v9                      // 0000003D838C: D657000D 04261AFF FFFF0000
	.long 0x7e9639c0                                           // 0000003D8398: 7E9639C0
	v_bfe_u32 v85, v6, 16, 1                                   // 0000003D839C: D6100055 02052106
	v_bfe_u32 v86, v69, 16, 1                                  // 0000003D83A4: D6100056 02052145
	v_add3_u32 v66, v67, v83, 0x7fff                           // 0000003D83AC: D6550042 03FEA743 00007FFF
	v_add3_u32 v67, v68, v84, 0x7fff                           // 0000003D83B8: D6550043 03FEA944 00007FFF
	.long 0x7e1239c1                                           // 0000003D83C4: 7E1239C1
	v_and_or_b32 v5, 0xffff0000, v5, v75                       // 0000003D83C8: D6570005 052E0AFF FFFF0000
	.long 0x7f983989                                           // 0000003D83D4: 7F983989
	v_bfe_u32 v87, v70, 16, 1                                  // 0000003D83D8: D6100057 02052146
	v_bfe_u32 v88, v71, 16, 1                                  // 0000003D83E0: D6100058 02052147
	v_add3_u32 v6, v6, v85, 0x7fff                             // 0000003D83E8: D6550006 03FEAB06 00007FFF
	v_add3_u32 v10, v69, v86, 0x7fff                           // 0000003D83F4: D655000A 03FEAD45 00007FFF
	v_and_or_b32 v66, 0xffff0000, v66, v9                      // 0000003D8400: D6570042 042684FF FFFF0000
	.long 0x7e9839c3                                           // 0000003D840C: 7E9839C3
	v_bfe_u32 v89, v7, 16, 1                                   // 0000003D8410: D6100059 02052107
	v_bfe_u32 v90, v72, 16, 1                                  // 0000003D8418: D610005A 02052148
	v_add3_u32 v68, v70, v87, 0x7fff                           // 0000003D8420: D6550044 03FEAF46 00007FFF
	v_add3_u32 v69, v71, v88, 0x7fff                           // 0000003D842C: D6550045 03FEB147 00007FFF
	.long 0x7e12398a                                           // 0000003D8438: 7E12398A
	v_and_or_b32 v6, 0xffff0000, v6, v76                       // 0000003D843C: D6570006 05320CFF FFFF0000
	.long 0x7f9a3989                                           // 0000003D8448: 7F9A3989
	v_bfe_u32 v91, v73, 16, 1                                  // 0000003D844C: D610005B 02052149
	v_bfe_u32 v92, v74, 16, 1                                  // 0000003D8454: D610005C 0205214A
	v_add3_u32 v7, v7, v89, 0x7fff                             // 0000003D845C: D6550007 03FEB307 00007FFF
	v_add3_u32 v65, v72, v90, 0x7fff                           // 0000003D8468: D6550041 03FEB548 00007FFF
	.long 0x7e9a39c5                                           // 0000003D8474: 7E9A39C5
	v_and_or_b32 v10, 0xffff0000, v68, v9                      // 0000003D8478: D657000A 042688FF FFFF0000
	v_bfe_u32 v93, v8, 16, 1                                   // 0000003D8484: D610005D 02052108
	v_add3_u32 v70, v73, v91, 0x7fff                           // 0000003D848C: D6550046 03FEB749 00007FFF
	v_add3_u32 v71, v74, v92, 0x7fff                           // 0000003D8498: D6550047 03FEB94A 00007FFF
	.long 0x7e1239c1                                           // 0000003D84A4: 7E1239C1
	v_and_or_b32 v7, 0xffff0000, v7, v77                       // 0000003D84A8: D6570007 05360EFF FFFF0000
	.long 0x7f9c3989                                           // 0000003D84B4: 7F9C3989
	v_add3_u32 v8, v8, v93, 0x7fff                             // 0000003D84B8: D6550008 03FEBB08 00007FFF
	.long 0x7e9c39c7                                           // 0000003D84C4: 7E9C39C7
	v_and_or_b32 v64, 0xffff0000, v70, v9                      // 0000003D84C8: D6570040 04268CFF FFFF0000
	s_mov_b32 s0, exec_lo                                      // 0000003D84D4: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D84D8: BF870002
	v_and_or_b32 v8, 0xffff0000, v8, v78                       // 0000003D84DC: D6570008 053A10FF FFFF0000
	s_waitcnt vmcnt(11)                                        // 0000003D84E8: BF892FF7
	v_dot2_f32_bf16 v16, v16, v13, 0                           // 0000003D84EC: CC1A4010 1A021B10
	s_waitcnt vmcnt(10)                                        // 0000003D84F4: BF892BF7
	v_dot2_f32_bf16 v20, v20, v13, 0                           // 0000003D84F8: CC1A4014 1A021B14
	s_waitcnt vmcnt(9)                                         // 0000003D8500: BF8927F7
	v_dot2_f32_bf16 v24, v24, v13, 0                           // 0000003D8504: CC1A4018 1A021B18
	s_waitcnt vmcnt(8)                                         // 0000003D850C: BF8923F7
	v_dot2_f32_bf16 v28, v28, v13, 0                           // 0000003D8510: CC1A401C 1A021B1C
	s_waitcnt vmcnt(7)                                         // 0000003D8518: BF891FF7
	v_dot2_f32_bf16 v32, v32, v13, 0                           // 0000003D851C: CC1A4020 1A021B20
	s_waitcnt vmcnt(6)                                         // 0000003D8524: BF891BF7
	v_dot2_f32_bf16 v13, v36, v13, 0                           // 0000003D8528: CC1A400D 1A021B24
	v_dot2_f32_bf16 v16, v17, v5, v16                          // 0000003D8530: CC1A4010 1C420B11
	v_dot2_f32_bf16 v17, v21, v5, v20                          // 0000003D8538: CC1A4011 1C520B15
	v_dot2_f32_bf16 v20, v25, v5, v24                          // 0000003D8540: CC1A4014 1C620B19
	v_dot2_f32_bf16 v21, v29, v5, v28                          // 0000003D8548: CC1A4015 1C720B1D
	v_dot2_f32_bf16 v24, v33, v5, v32                          // 0000003D8550: CC1A4018 1C820B21
	v_dot2_f32_bf16 v5, v37, v5, v13                           // 0000003D8558: CC1A4005 1C360B25
	v_dot2_f32_bf16 v13, v18, v66, v16                         // 0000003D8560: CC1A400D 1C428512
	v_dot2_f32_bf16 v16, v22, v66, v17                         // 0000003D8568: CC1A4010 1C468516
	v_dot2_f32_bf16 v17, v26, v66, v20                         // 0000003D8570: CC1A4011 1C52851A
	v_dot2_f32_bf16 v18, v30, v66, v21                         // 0000003D8578: CC1A4012 1C56851E
	v_dot2_f32_bf16 v20, v34, v66, v24                         // 0000003D8580: CC1A4014 1C628522
	v_dot2_f32_bf16 v5, v38, v66, v5                           // 0000003D8588: CC1A4005 1C168526
	v_dot2_f32_bf16 v13, v19, v6, v13                          // 0000003D8590: CC1A400D 1C360D13
	v_dot2_f32_bf16 v16, v23, v6, v16                          // 0000003D8598: CC1A4010 1C420D17
	v_dot2_f32_bf16 v17, v27, v6, v17                          // 0000003D85A0: CC1A4011 1C460D1B
	v_dot2_f32_bf16 v18, v31, v6, v18                          // 0000003D85A8: CC1A4012 1C4A0D1F
	v_dot2_f32_bf16 v19, v35, v6, v20                          // 0000003D85B0: CC1A4013 1C520D23
	v_dot2_f32_bf16 v5, v39, v6, v5                            // 0000003D85B8: CC1A4005 1C160D27
	s_waitcnt vmcnt(5)                                         // 0000003D85C0: BF8917F7
	v_dot2_f32_bf16 v6, v40, v10, v13                          // 0000003D85C4: CC1A4006 1C361528
	s_waitcnt vmcnt(4)                                         // 0000003D85CC: BF8913F7
	v_dot2_f32_bf16 v13, v44, v10, v16                         // 0000003D85D0: CC1A400D 1C42152C
	s_waitcnt vmcnt(3)                                         // 0000003D85D8: BF890FF7
	v_dot2_f32_bf16 v16, v48, v10, v17                         // 0000003D85DC: CC1A4010 1C461530
	s_waitcnt vmcnt(2)                                         // 0000003D85E4: BF890BF7
	v_dot2_f32_bf16 v17, v52, v10, v18                         // 0000003D85E8: CC1A4011 1C4A1534
	s_waitcnt vmcnt(1)                                         // 0000003D85F0: BF8907F7
	v_dot2_f32_bf16 v18, v56, v10, v19                         // 0000003D85F4: CC1A4012 1C4E1538
	s_waitcnt vmcnt(0)                                         // 0000003D85FC: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v5                           // 0000003D8600: CC1A4005 1C16153C
	v_dot2_f32_bf16 v6, v41, v7, v6                            // 0000003D8608: CC1A4006 1C1A0F29
	v_dot2_f32_bf16 v10, v45, v7, v13                          // 0000003D8610: CC1A400A 1C360F2D
	v_dot2_f32_bf16 v13, v49, v7, v16                          // 0000003D8618: CC1A400D 1C420F31
	v_dot2_f32_bf16 v16, v53, v7, v17                          // 0000003D8620: CC1A4010 1C460F35
	v_dot2_f32_bf16 v17, v57, v7, v18                          // 0000003D8628: CC1A4011 1C4A0F39
	v_dot2_f32_bf16 v5, v61, v7, v5                            // 0000003D8630: CC1A4005 1C160F3D
	v_dot2_f32_bf16 v6, v42, v64, v6                           // 0000003D8638: CC1A4006 1C1A812A
	v_dot2_f32_bf16 v7, v46, v64, v10                          // 0000003D8640: CC1A4007 1C2A812E
	v_dot2_f32_bf16 v10, v50, v64, v13                         // 0000003D8648: CC1A400A 1C368132
	v_dot2_f32_bf16 v13, v54, v64, v16                         // 0000003D8650: CC1A400D 1C428136
	v_dot2_f32_bf16 v16, v58, v64, v17                         // 0000003D8658: CC1A4010 1C46813A
	v_dot2_f32_bf16 v5, v62, v64, v5                           // 0000003D8660: CC1A4005 1C16813E
	v_dot2_f32_bf16 v6, v43, v8, v6                            // 0000003D8668: CC1A4006 1C1A112B
	v_dot2_f32_bf16 v7, v47, v8, v7                            // 0000003D8670: CC1A4007 1C1E112F
	v_dot2_f32_bf16 v17, v51, v8, v10                          // 0000003D8678: CC1A4011 1C2A1133
	v_dot2_f32_bf16 v18, v55, v8, v13                          // 0000003D8680: CC1A4012 1C361137
	v_dot2_f32_bf16 v16, v59, v8, v16                          // 0000003D8688: CC1A4010 1C42113B
	v_dot2_f32_bf16 v19, v63, v8, v5                           // 0000003D8690: CC1A4013 1C16113F
	v_dual_add_f32 v10, 0, v6 :: v_dual_add_f32 v13, 0, v7     // 0000003D8698: C9080C80 0A0C0E80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D86A0: BF870194
	v_dual_add_f32 v8, 0, v18 :: v_dual_add_f32 v7, 0, v17     // 0000003D86A4: C9082480 08062280
	v_dual_add_f32 v6, 0, v19 :: v_dual_add_f32 v5, 0, v16     // 0000003D86AC: C9082680 06042080
	v_cmpx_gt_u32_e32 20, v14                                  // 0000003D86B4: 7D981C94
	s_cbranch_execz 310                                        // 0000003D86B8: BFA50136 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf+0xa94>
	.long 0xd700013a                                           // 0000003D86BC: D700013A
	v_cndmask_b32_e32 v1, s6, v15, vcc_lo                      // 0000003D86C0: 02021E06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D86C4: BF870001
	v_add_co_ci_u32_e64 v59, null, s7, 0, s1                   // 0000003D86C8: D5207C3B 00050007
	v_cvt_f32_ubyte0_e32 v62, v1                               // 0000003D86D0: 7E7C2301
	v_cvt_f32_ubyte1_e32 v63, v1                               // 0000003D86D4: 7E7E2501
	v_cvt_f32_ubyte2_e32 v64, v1                               // 0000003D86D8: 7E802701
	s_clause 0xb                                               // 0000003D86DC: BF85000B
	global_load_b128 v[14:17], v[58:59], off offset:512        // 0000003D86E0: DC5E0200 0E7C003A
	global_load_b128 v[18:21], v[58:59], off offset:1152       // 0000003D86E8: DC5E0480 127C003A
	global_load_b128 v[22:25], v[58:59], off offset:1792       // 0000003D86F0: DC5E0700 167C003A
	global_load_b128 v[26:29], v[58:59], off offset:2432       // 0000003D86F8: DC5E0980 1A7C003A
	global_load_b128 v[30:33], v[58:59], off offset:3072       // 0000003D8700: DC5E0C00 1E7C003A
	global_load_b128 v[34:37], v[58:59], off offset:3712       // 0000003D8708: DC5E0E80 227C003A
	global_load_b128 v[38:41], v[58:59], off offset:528        // 0000003D8710: DC5E0210 267C003A
	global_load_b128 v[42:45], v[58:59], off offset:1168       // 0000003D8718: DC5E0490 2A7C003A
	global_load_b128 v[46:49], v[58:59], off offset:1808       // 0000003D8720: DC5E0710 2E7C003A
	global_load_b128 v[50:53], v[58:59], off offset:2448       // 0000003D8728: DC5E0990 327C003A
	global_load_b128 v[54:57], v[58:59], off offset:3088       // 0000003D8730: DC5E0C10 367C003A
	global_load_b128 v[58:61], v[58:59], off offset:3728       // 0000003D8738: DC5E0E90 3A7C003A
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003D8740: 7E022901
	v_cvt_f32_ubyte0_e32 v66, v2                               // 0000003D8744: 7E842302
	v_cvt_f32_ubyte1_e32 v67, v2                               // 0000003D8748: 7E862502
	v_cvt_f32_ubyte2_e32 v68, v2                               // 0000003D874C: 7E882702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003D8750: 7E042902
	v_cvt_f32_ubyte0_e32 v70, v3                               // 0000003D8754: 7E8C2303
	v_cvt_f32_ubyte1_e32 v71, v3                               // 0000003D8758: 7E8E2503
	v_cvt_f32_ubyte2_e32 v72, v3                               // 0000003D875C: 7E902703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003D8760: 7E062903
	v_cvt_f32_ubyte0_e32 v74, v4                               // 0000003D8764: 7E942304
	v_cvt_f32_ubyte1_e32 v75, v4                               // 0000003D8768: 7E962504
	v_cvt_f32_ubyte2_e32 v76, v4                               // 0000003D876C: 7E982704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003D8770: 7E082904
	v_fma_mix_f32 v62, v62, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D8774: CC20603E 1432193E
	v_fma_mix_f32 v63, v63, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D877C: CC20603F 1432193F
	v_fma_mix_f32 v64, v64, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D8784: CC206040 14321940
	v_fma_mix_f32 v1, v1, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D878C: CC206001 14321901
	v_fma_mix_f32 v66, v66, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D8794: CC206042 14321942
	v_fma_mix_f32 v67, v67, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D879C: CC206043 14321943
	v_fma_mix_f32 v68, v68, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87A4: CC206044 14321944
	v_fma_mix_f32 v2, v2, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87AC: CC206002 14321902
	v_fma_mix_f32 v70, v70, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87B4: CC206046 14321946
	v_fma_mix_f32 v71, v71, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87BC: CC206047 14321947
	v_fma_mix_f32 v72, v72, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87C4: CC206048 14321948
	v_fma_mix_f32 v3, v3, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87CC: CC206003 14321903
	v_fma_mix_f32 v74, v74, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87D4: CC20604A 1432194A
	v_fma_mix_f32 v75, v75, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87DC: CC20604B 1432194B
	v_fma_mix_f32 v76, v76, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87E4: CC20604C 1432194C
	v_fma_mix_f32 v4, v4, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D87EC: CC206004 14321904
	v_bfe_u32 v12, v62, 16, 1                                  // 0000003D87F4: D610000C 0205213E
	v_bfe_u32 v78, v63, 16, 1                                  // 0000003D87FC: D610004E 0205213F
	v_bfe_u32 v79, v64, 16, 1                                  // 0000003D8804: D610004F 02052140
	v_bfe_u32 v80, v1, 16, 1                                   // 0000003D880C: D6100050 02052101
	v_bfe_u32 v81, v66, 16, 1                                  // 0000003D8814: D6100051 02052142
	v_add3_u32 v12, v62, v12, 0x7fff                           // 0000003D881C: D655000C 03FE193E 00007FFF
	v_add3_u32 v62, v63, v78, 0x7fff                           // 0000003D8828: D655003E 03FE9D3F 00007FFF
	v_add3_u32 v63, v64, v79, 0x7fff                           // 0000003D8834: D655003F 03FE9F40 00007FFF
	.long 0x7f823989                                           // 0000003D8840: 7F823989
	v_bfe_u32 v82, v67, 16, 1                                  // 0000003D8844: D6100052 02052143
	.long 0x7e12398c                                           // 0000003D884C: 7E12398C
	v_bfe_u32 v83, v68, 16, 1                                  // 0000003D8850: D6100053 02052144
	v_add3_u32 v1, v1, v80, 0x7fff                             // 0000003D8858: D6550001 03FEA101 00007FFF
	v_add3_u32 v64, v66, v81, 0x7fff                           // 0000003D8864: D6550040 03FEA342 00007FFF
	.long 0x7e8239bf                                           // 0000003D8870: 7E8239BF
	v_and_or_b32 v62, 0xffff0000, v62, v9                      // 0000003D8874: D657003E 04267CFF FFFF0000
	v_bfe_u32 v84, v2, 16, 1                                   // 0000003D8880: D6100054 02052102
	v_bfe_u32 v85, v70, 16, 1                                  // 0000003D8888: D6100055 02052146
	v_add3_u32 v66, v67, v82, 0x7fff                           // 0000003D8890: D6550042 03FEA543 00007FFF
	v_add3_u32 v67, v68, v83, 0x7fff                           // 0000003D889C: D6550043 03FEA744 00007FFF
	.long 0x7e1239c0                                           // 0000003D88A8: 7E1239C0
	v_and_or_b32 v1, 0xffff0000, v1, v65                       // 0000003D88AC: D6570001 050602FF FFFF0000
	.long 0x7f8a3989                                           // 0000003D88B8: 7F8A3989
	v_bfe_u32 v86, v71, 16, 1                                  // 0000003D88BC: D6100056 02052147
	v_bfe_u32 v87, v72, 16, 1                                  // 0000003D88C4: D6100057 02052148
	v_add3_u32 v2, v2, v84, 0x7fff                             // 0000003D88CC: D6550002 03FEA902 00007FFF
	v_add3_u32 v12, v70, v85, 0x7fff                           // 0000003D88D8: D655000C 03FEAB46 00007FFF
	v_and_or_b32 v66, 0xffff0000, v66, v9                      // 0000003D88E4: D6570042 042684FF FFFF0000
	.long 0x7e8a39c3                                           // 0000003D88F0: 7E8A39C3
	v_bfe_u32 v88, v3, 16, 1                                   // 0000003D88F4: D6100058 02052103
	v_bfe_u32 v89, v74, 16, 1                                  // 0000003D88FC: D6100059 0205214A
	v_add3_u32 v68, v71, v86, 0x7fff                           // 0000003D8904: D6550044 03FEAD47 00007FFF
	v_add3_u32 v70, v72, v87, 0x7fff                           // 0000003D8910: D6550046 03FEAF48 00007FFF
	.long 0x7e12398c                                           // 0000003D891C: 7E12398C
	v_and_or_b32 v2, 0xffff0000, v2, v69                       // 0000003D8920: D6570002 051604FF FFFF0000
	.long 0x7f923989                                           // 0000003D892C: 7F923989
	v_bfe_u32 v90, v75, 16, 1                                  // 0000003D8930: D610005A 0205214B
	v_bfe_u32 v91, v76, 16, 1                                  // 0000003D8938: D610005B 0205214C
	v_add3_u32 v3, v3, v88, 0x7fff                             // 0000003D8940: D6550003 03FEB103 00007FFF
	v_add3_u32 v64, v74, v89, 0x7fff                           // 0000003D894C: D6550040 03FEB34A 00007FFF
	.long 0x7e9239c6                                           // 0000003D8958: 7E9239C6
	v_and_or_b32 v12, 0xffff0000, v68, v9                      // 0000003D895C: D657000C 042688FF FFFF0000
	v_bfe_u32 v92, v4, 16, 1                                   // 0000003D8968: D610005C 02052104
	v_add3_u32 v71, v75, v90, 0x7fff                           // 0000003D8970: D6550047 03FEB54B 00007FFF
	v_add3_u32 v72, v76, v91, 0x7fff                           // 0000003D897C: D6550048 03FEB74C 00007FFF
	.long 0x7e1239c0                                           // 0000003D8988: 7E1239C0
	v_and_or_b32 v3, 0xffff0000, v3, v73                       // 0000003D898C: D6570003 052606FF FFFF0000
	.long 0x7f9a3989                                           // 0000003D8998: 7F9A3989
	v_add3_u32 v4, v4, v92, 0x7fff                             // 0000003D899C: D6550004 03FEB904 00007FFF
	.long 0x7e9a39c8                                           // 0000003D89A8: 7E9A39C8
	v_and_or_b32 v9, 0xffff0000, v71, v9                       // 0000003D89AC: D6570009 04268EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D89B8: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v77                       // 0000003D89BC: D6570004 053608FF FFFF0000
	s_waitcnt vmcnt(11)                                        // 0000003D89C8: BF892FF7
	v_dot2_f32_bf16 v14, v14, v62, 0                           // 0000003D89CC: CC1A400E 1A027D0E
	s_waitcnt vmcnt(10)                                        // 0000003D89D4: BF892BF7
	v_dot2_f32_bf16 v18, v18, v62, 0                           // 0000003D89D8: CC1A4012 1A027D12
	s_waitcnt vmcnt(9)                                         // 0000003D89E0: BF8927F7
	v_dot2_f32_bf16 v22, v22, v62, 0                           // 0000003D89E4: CC1A4016 1A027D16
	s_waitcnt vmcnt(8)                                         // 0000003D89EC: BF8923F7
	v_dot2_f32_bf16 v26, v26, v62, 0                           // 0000003D89F0: CC1A401A 1A027D1A
	s_waitcnt vmcnt(7)                                         // 0000003D89F8: BF891FF7
	v_dot2_f32_bf16 v30, v30, v62, 0                           // 0000003D89FC: CC1A401E 1A027D1E
	s_waitcnt vmcnt(6)                                         // 0000003D8A04: BF891BF7
	v_dot2_f32_bf16 v34, v34, v62, 0                           // 0000003D8A08: CC1A4022 1A027D22
	v_dot2_f32_bf16 v14, v15, v1, v14                          // 0000003D8A10: CC1A400E 1C3A030F
	v_dot2_f32_bf16 v15, v19, v1, v18                          // 0000003D8A18: CC1A400F 1C4A0313
	v_dot2_f32_bf16 v18, v23, v1, v22                          // 0000003D8A20: CC1A4012 1C5A0317
	v_dot2_f32_bf16 v19, v27, v1, v26                          // 0000003D8A28: CC1A4013 1C6A031B
	v_dot2_f32_bf16 v22, v31, v1, v30                          // 0000003D8A30: CC1A4016 1C7A031F
	v_dot2_f32_bf16 v1, v35, v1, v34                           // 0000003D8A38: CC1A4001 1C8A0323
	v_dot2_f32_bf16 v14, v16, v66, v14                         // 0000003D8A40: CC1A400E 1C3A8510
	v_dot2_f32_bf16 v15, v20, v66, v15                         // 0000003D8A48: CC1A400F 1C3E8514
	v_dot2_f32_bf16 v16, v24, v66, v18                         // 0000003D8A50: CC1A4010 1C4A8518
	v_dot2_f32_bf16 v18, v28, v66, v19                         // 0000003D8A58: CC1A4012 1C4E851C
	v_dot2_f32_bf16 v19, v32, v66, v22                         // 0000003D8A60: CC1A4013 1C5A8520
	v_dot2_f32_bf16 v1, v36, v66, v1                           // 0000003D8A68: CC1A4001 1C068524
	v_dot2_f32_bf16 v14, v17, v2, v14                          // 0000003D8A70: CC1A400E 1C3A0511
	v_dot2_f32_bf16 v15, v21, v2, v15                          // 0000003D8A78: CC1A400F 1C3E0515
	v_dot2_f32_bf16 v16, v25, v2, v16                          // 0000003D8A80: CC1A4010 1C420519
	v_dot2_f32_bf16 v17, v29, v2, v18                          // 0000003D8A88: CC1A4011 1C4A051D
	v_dot2_f32_bf16 v18, v33, v2, v19                          // 0000003D8A90: CC1A4012 1C4E0521
	v_dot2_f32_bf16 v1, v37, v2, v1                            // 0000003D8A98: CC1A4001 1C060525
	s_waitcnt vmcnt(5)                                         // 0000003D8AA0: BF8917F7
	v_dot2_f32_bf16 v2, v38, v12, v14                          // 0000003D8AA4: CC1A4002 1C3A1926
	s_waitcnt vmcnt(4)                                         // 0000003D8AAC: BF8913F7
	v_dot2_f32_bf16 v14, v42, v12, v15                         // 0000003D8AB0: CC1A400E 1C3E192A
	s_waitcnt vmcnt(3)                                         // 0000003D8AB8: BF890FF7
	v_dot2_f32_bf16 v15, v46, v12, v16                         // 0000003D8ABC: CC1A400F 1C42192E
	s_waitcnt vmcnt(2)                                         // 0000003D8AC4: BF890BF7
	v_dot2_f32_bf16 v16, v50, v12, v17                         // 0000003D8AC8: CC1A4010 1C461932
	s_waitcnt vmcnt(1)                                         // 0000003D8AD0: BF8907F7
	v_dot2_f32_bf16 v17, v54, v12, v18                         // 0000003D8AD4: CC1A4011 1C4A1936
	s_waitcnt vmcnt(0)                                         // 0000003D8ADC: BF8903F7
	v_dot2_f32_bf16 v1, v58, v12, v1                           // 0000003D8AE0: CC1A4001 1C06193A
	v_dot2_f32_bf16 v2, v39, v3, v2                            // 0000003D8AE8: CC1A4002 1C0A0727
	v_dot2_f32_bf16 v12, v43, v3, v14                          // 0000003D8AF0: CC1A400C 1C3A072B
	v_dot2_f32_bf16 v14, v47, v3, v15                          // 0000003D8AF8: CC1A400E 1C3E072F
	v_dot2_f32_bf16 v15, v51, v3, v16                          // 0000003D8B00: CC1A400F 1C420733
	v_dot2_f32_bf16 v16, v55, v3, v17                          // 0000003D8B08: CC1A4010 1C460737
	v_dot2_f32_bf16 v1, v59, v3, v1                            // 0000003D8B10: CC1A4001 1C06073B
	v_dot2_f32_bf16 v2, v40, v9, v2                            // 0000003D8B18: CC1A4002 1C0A1328
	v_dot2_f32_bf16 v3, v44, v9, v12                           // 0000003D8B20: CC1A4003 1C32132C
	v_dot2_f32_bf16 v12, v48, v9, v14                          // 0000003D8B28: CC1A400C 1C3A1330
	v_dot2_f32_bf16 v14, v52, v9, v15                          // 0000003D8B30: CC1A400E 1C3E1334
	v_dot2_f32_bf16 v15, v56, v9, v16                          // 0000003D8B38: CC1A400F 1C421338
	v_dot2_f32_bf16 v1, v60, v9, v1                            // 0000003D8B40: CC1A4001 1C06133C
	v_dot2_f32_bf16 v2, v41, v4, v2                            // 0000003D8B48: CC1A4002 1C0A0929
	v_dot2_f32_bf16 v3, v45, v4, v3                            // 0000003D8B50: CC1A4003 1C0E092D
	v_dot2_f32_bf16 v9, v49, v4, v12                           // 0000003D8B58: CC1A4009 1C320931
	v_dot2_f32_bf16 v12, v53, v4, v14                          // 0000003D8B60: CC1A400C 1C3A0935
	v_dot2_f32_bf16 v14, v57, v4, v15                          // 0000003D8B68: CC1A400E 1C3E0939
	v_dot2_f32_bf16 v1, v61, v4, v1                            // 0000003D8B70: CC1A4001 1C06093D
	v_dual_add_f32 v10, v10, v2 :: v_dual_add_f32 v13, v13, v3 // 0000003D8B78: C908050A 0A0C070D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D8B80: BF870194
	v_dual_add_f32 v7, v7, v9 :: v_dual_add_f32 v8, v8, v12    // 0000003D8B84: C9081307 07081908
	v_dual_add_f32 v5, v5, v14 :: v_dual_add_f32 v6, v6, v1    // 0000003D8B8C: C9081D05 05060306
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D8B94: 8C7E007E
	.long 0xd71f0001                                           // 0000003D8B98: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003D8B9C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003D8BA0: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D8BA4: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003D8BA8: 3A040288
	v_xor_b32_e32 v15, 4, v1                                   // 0000003D8BAC: 3A1E0284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003D8BB0: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003D8BB4: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D8BB8: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000003D8BBC: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000003D8BC0: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000003D8BC4: 301E1E82
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D8BC8: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003D8BCC: 30040482
	ds_bpermute_b32 v3, v2, v13                                // 0000003D8BD0: DACC0000 03000D02
	s_waitcnt lgkmcnt(0)                                       // 0000003D8BD8: BF89FC07
	v_add_f32_e32 v3, v13, v3                                  // 0000003D8BDC: 0606070D
	ds_bpermute_b32 v4, v2, v10                                // 0000003D8BE0: DACC0000 04000A02
	ds_bpermute_b32 v9, v2, v8                                 // 0000003D8BE8: DACC0000 09000802
	ds_bpermute_b32 v12, v2, v7                                // 0000003D8BF0: DACC0000 0C000702
	ds_bpermute_b32 v14, v2, v6                                // 0000003D8BF8: DACC0000 0E000602
	ds_bpermute_b32 v2, v2, v5                                 // 0000003D8C00: DACC0000 02000502
	s_waitcnt lgkmcnt(4)                                       // 0000003D8C08: BF89FC47
	v_add_f32_e32 v4, v10, v4                                  // 0000003D8C0C: 0608090A
	s_waitcnt lgkmcnt(2)                                       // 0000003D8C10: BF89FC27
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v7, v7, v12    // 0000003D8C14: C9081308 08061907
	s_waitcnt lgkmcnt(1)                                       // 0000003D8C1C: BF89FC17
	v_add_f32_e32 v6, v6, v14                                  // 0000003D8C20: 060C1D06
	s_waitcnt lgkmcnt(0)                                       // 0000003D8C24: BF89FC07
	v_add_f32_e32 v2, v5, v2                                   // 0000003D8C28: 06040505
	ds_bpermute_b32 v5, v15, v3                                // 0000003D8C2C: DACC0000 0500030F
	ds_bpermute_b32 v9, v15, v4                                // 0000003D8C34: DACC0000 0900040F
	ds_bpermute_b32 v10, v15, v8                               // 0000003D8C3C: DACC0000 0A00080F
	ds_bpermute_b32 v12, v15, v7                               // 0000003D8C44: DACC0000 0C00070F
	ds_bpermute_b32 v13, v15, v6                               // 0000003D8C4C: DACC0000 0D00060F
	ds_bpermute_b32 v14, v15, v2                               // 0000003D8C54: DACC0000 0E00020F
	v_xor_b32_e32 v15, 2, v1                                   // 0000003D8C5C: 3A1E0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D8C60: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000003D8C64: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000003D8C68: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000003D8C6C: 301E1E82
	s_waitcnt lgkmcnt(5)                                       // 0000003D8C70: BF89FC57
	v_add_f32_e32 v3, v3, v5                                   // 0000003D8C74: 06060B03
	s_waitcnt lgkmcnt(2)                                       // 0000003D8C78: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v12    // 0000003D8C7C: C9081304 04061907
	s_waitcnt lgkmcnt(1)                                       // 0000003D8C84: BF89FC17
	v_dual_add_f32 v5, v8, v10 :: v_dual_add_f32 v8, v6, v13   // 0000003D8C88: C9081508 05081B06
	s_waitcnt lgkmcnt(0)                                       // 0000003D8C90: BF89FC07
	v_add_f32_e32 v2, v2, v14                                  // 0000003D8C94: 06041D02
	ds_bpermute_b32 v6, v15, v3                                // 0000003D8C98: DACC0000 0600030F
	ds_bpermute_b32 v9, v15, v4                                // 0000003D8CA0: DACC0000 0900040F
	ds_bpermute_b32 v12, v15, v5                               // 0000003D8CA8: DACC0000 0C00050F
	ds_bpermute_b32 v13, v15, v7                               // 0000003D8CB0: DACC0000 0D00070F
	ds_bpermute_b32 v14, v15, v8                               // 0000003D8CB8: DACC0000 0E00080F
	ds_bpermute_b32 v15, v15, v2                               // 0000003D8CC0: DACC0000 0F00020F
	v_xor_b32_e32 v10, 1, v1                                   // 0000003D8CC8: 3A140281
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D8CCC: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000003D8CD0: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 0000003D8CD4: 02021501
	s_waitcnt lgkmcnt(4)                                       // 0000003D8CD8: BF89FC47
	v_dual_add_f32 v10, v3, v6 :: v_dual_add_f32 v9, v4, v9    // 0000003D8CDC: C9080D03 0A081304
	s_waitcnt lgkmcnt(2)                                       // 0000003D8CE4: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v7, v13   // 0000003D8CE8: C9081905 05061B07
	s_waitcnt lgkmcnt(1)                                       // 0000003D8CF0: BF89FC17
	v_dual_add_f32 v1, v8, v14 :: v_dual_lshlrev_b32 v16, 2, v1// 0000003D8CF4: C9221D08 01100282
	s_waitcnt lgkmcnt(0)                                       // 0000003D8CFC: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 0000003D8D00: 06041F02
	ds_bpermute_b32 v12, v16, v9                               // 0000003D8D04: DACC0000 0C000910
	ds_bpermute_b32 v13, v16, v10                              // 0000003D8D0C: DACC0000 0D000A10
	ds_bpermute_b32 v8, v16, v6                                // 0000003D8D14: DACC0000 08000610
	ds_bpermute_b32 v7, v16, v5                                // 0000003D8D1C: DACC0000 07000510
	ds_bpermute_b32 v4, v16, v2                                // 0000003D8D24: DACC0000 04000210
	ds_bpermute_b32 v3, v16, v1                                // 0000003D8D2C: DACC0000 03000110
	v_cmpx_eq_u32_e32 0, v11                                   // 0000003D8D34: 7D941680
	s_cbranch_execz 54                                         // 0000003D8D38: BFA50036 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf+0xd14>
	s_waitcnt lgkmcnt(4)                                       // 0000003D8D3C: BF89FC47
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v9, v9, v12 // 0000003D8D40: C9081B0A 0A081909
	v_lshrrev_b32_e32 v11, 4, v0                               // 0000003D8D48: 32160084
	.long 0x7f183880                                           // 0000003D8D4C: 7F183880
	s_waitcnt lgkmcnt(2)                                       // 0000003D8D50: BF89FC27
	v_dual_add_f32 v6, v6, v8 :: v_dual_add_f32 v5, v5, v7     // 0000003D8D54: C9081106 06040F05
	.long 0x7e18398a                                           // 0000003D8D5C: 7E18398A
	s_waitcnt lgkmcnt(0)                                       // 0000003D8D60: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v1, v3     // 0000003D8D64: C9080902 02000701
	v_mul_u32_u24_e32 v7, 12, v11                              // 0000003D8D6C: 160E168C
	.long 0x7e103989                                           // 0000003D8D70: 7E103989
	.long 0x7f10398c                                           // 0000003D8D74: 7F10398C
	v_and_b32_e32 v11, 1, v12                                  // 0000003D8D78: 36161881
	.long 0x7e183985                                           // 0000003D8D7C: 7E183985
	.long 0x7e083986                                           // 0000003D8D80: 7E083986
	.long 0x7f08398c                                           // 0000003D8D84: 7F08398C
	.long 0x7e063982                                           // 0000003D8D88: 7E063982
	.long 0x7f06398c                                           // 0000003D8D8C: 7F06398C
	v_and_b32_e32 v8, 1, v8                                    // 0000003D8D90: 36101081
	v_and_b32_e32 v13, 1, v12                                  // 0000003D8D94: 361A1881
	v_and_b32_e32 v4, 1, v4                                    // 0000003D8D98: 36080881
	.long 0x7e183981                                           // 0000003D8D9C: 7E183981
	v_and_b32_e32 v3, 1, v3                                    // 0000003D8DA0: 36060681
	v_add3_u32 v8, v9, v8, 0x7fff                              // 0000003D8DA4: D6550008 03FE1109 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D8DB0: BF870214
	v_add3_u32 v4, v6, v4, 0x7fff                              // 0000003D8DB4: D6550004 03FE0906 00007FFF
	v_and_b32_e32 v9, 1, v12                                   // 0000003D8DC0: 36121881
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D8DC4: BF870004
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000003D8DC8: D6550002 03FE0702 00007FFF
	v_add3_u32 v6, v10, v11, 0x7fff                            // 0000003D8DD4: D6550006 03FE170A 00007FFF
	v_add3_u32 v3, v5, v13, 0x7fff                             // 0000003D8DE0: D6550003 03FE1B05 00007FFF
	.long 0x7e063984                                           // 0000003D8DEC: 7E063984
	.long 0x7e0c3988                                           // 0000003D8DF0: 7E0C3988
	v_add3_u32 v1, v1, v9, 0x7fff                              // 0000003D8DF4: D6550001 03FE1301 00007FFF
	.long 0x7e023982                                           // 0000003D8E00: 7E023982
	ds_store_2addr_b32 v7, v6, v3 offset1:1                    // 0000003D8E04: D8380100 00030607
	ds_store_b32 v7, v1 offset:8                               // 0000003D8E0C: D8340008 00000107
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D8E14: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000003D8E18: BF89FC07
	s_barrier                                                  // 0000003D8E1C: BFBD0000
	buffer_gl0_inv                                             // 0000003D8E20: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003D8E28: BE80007E
	v_cmpx_gt_u32_e32 24, v0                                   // 0000003D8E2C: 7D980098
	s_cbranch_execz 260                                        // 0000003D8E30: BFA50104 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf+0x1144>
	.long 0xd7054000                                           // 0000003D8E34: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000003D8E38: 020200FF 000000AB
	.long 0x7f143880                                           // 0000003D8E40: 7F143880
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003D8E44: BF108004
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8E48: BF870092
	.long 0xd739100a                                           // 0000003D8E4C: D739100A
	v_cndmask_b32_e32 v1, 10, v0, vcc_lo                       // 0000003D8E50: 0202008A
	.long 0xd7054000                                           // 0000003D8E54: D7054000
	v_cndmask_b32_e32 v0, v10, v134, vcc_lo                    // 0000003D8E58: 02010D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D8E5C: BF870121
	.long 0xd7041001                                           // 0000003D8E60: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003D8E64: 02020100
	v_add_nc_u32_e32 v0, s2, v10                               // 0000003D8E68: 4A001402
	v_and_b32_e32 v11, 0xff, v1                                // 0000003D8E6C: 361602FF 000000FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D8E74: BF870112
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000003D8E78: 3402009F
	v_mad_u64_u32 v[2:3], null, 0x5000, v11, s[8:9]            // 0000003D8E7C: D6FE7C02 002216FF 00005000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8E88: BF870092
	.long 0xd73c0004                                           // 0000003D8E8C: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003D8E90: 02020081
	.long 0xd7006a02                                           // 0000003D8E94: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000003D8E98: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D8E9C: BF870111
	v_add_co_ci_u32_e64 v3, null, v3, v5, vcc_lo               // 0000003D8EA0: D5207C03 01AA0B03
	.long 0xd7006a04                                           // 0000003D8EA8: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000003D8EAC: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D8EB4: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000003D8EB8: D5207C05 01AA0680
	.long 0xd7006a06                                           // 0000003D8EC0: D7006A06
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000003D8EC4: 020204FF 00003000
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000003D8ECC: D5207C07 01AA0680
	.long 0xd7006a08                                           // 0000003D8ED4: D7006A08
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000003D8ED8: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D8EE0: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v3, vcc_lo                // 0000003D8EE4: D5207C09 01AA0680
	s_clause 0x3                                               // 0000003D8EEC: BF850003
	global_load_u16 v4, v[4:5], off offset:2048                // 0000003D8EF0: DC4A0800 047C0004
	global_load_u16 v5, v[6:7], off offset:3072                // 0000003D8EF8: DC4A0C00 057C0006
	global_load_u16 v2, v[2:3], off                            // 0000003D8F00: DC4A0000 027C0002
	global_load_u16 v3, v[8:9], off offset:1024                // 0000003D8F08: DC4A0400 037C0008
	v_mul_u32_u24_e32 v6, 48, v10                              // 0000003D8F10: 160C14B0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D8F14: BF870001
	v_lshl_add_u32 v6, v11, 1, v6                              // 0000003D8F18: D6460006 0419030B
	ds_load_u16 v7, v6                                         // 0000003D8F20: D8F00000 07000006
	ds_load_u16 v8, v6 offset:12                               // 0000003D8F28: D8F0000C 08000006
	ds_load_u16 v9, v6 offset:24                               // 0000003D8F30: D8F00018 09000006
	ds_load_u16 v6, v6 offset:36                               // 0000003D8F38: D8F00024 06000006
	s_waitcnt lgkmcnt(0)                                       // 0000003D8F40: BF89FC07
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003D8F44: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8F48: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003D8F4C: C8E20CFF 06081290 BFB8AA3B
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_lshlrev_b32 v8, 16, v8// 0000003D8F58: C8E212FF 09081090 BFB8AA3B
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003D8F64: 300E0E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D8F68: BF870113
	v_exp_f32_e32 v6, v6                                       // 0000003D8F6C: 7E0C4B06
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003D8F70: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D8F78: BF870113
	v_exp_f32_e32 v9, v9                                       // 0000003D8F7C: 7E124B09
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000003D8F80: 100E0EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8F88: BF870092
	v_exp_f32_e32 v8, v8                                       // 0000003D8F8C: 7E104B08
	v_exp_f32_e32 v7, v7                                       // 0000003D8F90: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D8F94: BF870097
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_add_f32 v9, 1.0, v9   // 0000003D8F98: C9080CF2 060812F2
	v_div_scale_f32 v14, null, v6, v6, 1.0                     // 0000003D8FA0: D6FC7C0E 03CA0D06
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D8FA8: BF870196
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003D8FAC: 061010F2
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003D8FB0: D6FC7C0D 03CA1309
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000003D8FB8: BF870005
	v_add_f32_e32 v7, 1.0, v7                                  // 0000003D8FBC: 060E0EF2
	v_div_scale_f32 v24, s1, 1.0, v9, 1.0                      // 0000003D8FC0: D6FC0118 03CA12F2
	v_rcp_f32_e32 v18, v14                                     // 0000003D8FC8: 7E24550E
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 0000003D8FCC: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v17, v13                                     // 0000003D8FD4: 7E22550D
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 0000003D8FD8: D6FC7C0A 03CA0F07
	v_div_scale_f32 v19, vcc_lo, 1.0, v7, 1.0                  // 0000003D8FE0: D6FC6A13 03CA0EF2
	v_div_scale_f32 v20, s0, 1.0, v8, 1.0                      // 0000003D8FE8: D6FC0014 03CA10F2
	v_rcp_f32_e32 v16, v12                                     // 0000003D8FF0: 7E20550C
	v_mad_u64_u32 v[0:1], null, 0xa00, v11, v[0:1]             // 0000003D8FF4: D6FE7C00 040216FF 00000A00
	v_rcp_f32_e32 v15, v10                                     // 0000003D9000: 7E1E550A
	v_fma_f32 v25, -v14, v18, 1.0                              // 0000003D9004: D6130019 23CA250E
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D900C: BF870117
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003D9010: D6130017 23CA230D
	v_fmac_f32_e32 v18, v25, v18                               // 0000003D9018: 56242519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D901C: BF870196
	v_fma_f32 v22, -v12, v16, 1.0                              // 0000003D9020: D6130016 23CA210C
	v_fmac_f32_e32 v17, v23, v17                               // 0000003D9028: 56222317
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D902C: BF870095
	v_fma_f32 v21, -v10, v15, 1.0                              // 0000003D9030: D6130015 23CA1F0A
	v_dual_fmac_f32 v16, v22, v16 :: v_dual_fmac_f32 v15, v21, v15// 0000003D9038: C8002116 100E1F15
	v_div_scale_f32 v21, s2, 1.0, v6, 1.0                      // 0000003D9040: D6FC0215 03CA0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D9048: BF870194
	v_mul_f32_e32 v25, v24, v17                                // 0000003D904C: 10322318
	v_dual_mul_f32 v23, v20, v16 :: v_dual_mul_f32 v22, v19, v15// 0000003D9050: C8C62114 17161F13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D9058: BF870193
	v_mul_f32_e32 v26, v21, v18                                // 0000003D905C: 10342515
	v_fma_f32 v29, -v13, v25, v24                              // 0000003D9060: D613001D 2462330D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9068: BF870213
	v_fma_f32 v28, -v12, v23, v20                              // 0000003D906C: D613001C 24522F0C
	v_fma_f32 v27, -v10, v22, v19                              // 0000003D9074: D613001B 244E2D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D907C: BF870214
	v_fma_f32 v30, -v14, v26, v21                              // 0000003D9080: D613001E 2456350E
	v_fmac_f32_e32 v25, v29, v17                               // 0000003D9088: 5632231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D908C: BF870193
	v_dual_fmac_f32 v23, v28, v16 :: v_dual_fmac_f32 v22, v27, v15// 0000003D9090: C800211C 17161F1B
	v_fmac_f32_e32 v26, v30, v18                               // 0000003D9098: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D909C: BF870193
	v_fma_f32 v13, -v13, v25, v24                              // 0000003D90A0: D613000D 2462330D
	v_fma_f32 v12, -v12, v23, v20                              // 0000003D90A8: D613000C 24522F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D90B0: BF870214
	v_fma_f32 v10, -v10, v22, v19                              // 0000003D90B4: D613000A 244E2D0A
	v_fma_f32 v14, -v14, v26, v21                              // 0000003D90BC: D613000E 2456350E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003D90C4: BF870142
	v_div_fmas_f32 v10, v10, v15, v22                          // 0000003D90C8: D637000A 045A1F0A
	s_mov_b32 vcc_lo, s0                                       // 0000003D90D0: BEEA0000
	v_div_fmas_f32 v12, v12, v16, v23                          // 0000003D90D4: D637000C 045E210C
	s_mov_b32 vcc_lo, s1                                       // 0000003D90DC: BEEA0001
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000003D90E0: D6270007 03CA0F0A
	v_div_fmas_f32 v10, v13, v17, v25                          // 0000003D90E8: D637000A 0466230D
	s_mov_b32 vcc_lo, s2                                       // 0000003D90F0: BEEA0002
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 0000003D90F4: D6270008 03CA110C
	v_div_fmas_f32 v13, v14, v18, v26                          // 0000003D90FC: D637000D 046A250E
	v_bfe_u32 v12, v7, 16, 1                                   // 0000003D9104: D610000C 02052107
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003D910C: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9114: BF870214
	v_bfe_u32 v10, v8, 16, 1                                   // 0000003D9118: D610000A 02052108
	v_div_fixup_f32 v6, v13, v6, 1.0                           // 0000003D9120: D6270006 03CA0D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9128: BF870214
	v_add3_u32 v7, v7, v12, 0x7fff                             // 0000003D912C: D6550007 03FE1907 00007FFF
	v_bfe_u32 v12, v9, 16, 1                                   // 0000003D9138: D610000C 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9140: BF870214
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000003D9144: D6550008 03FE1508 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000003D9150: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D9158: BF870193
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003D915C: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003D9168: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003D9170: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000003D9174: D6550006 03FE1506 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003D9180: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003D9184: 30080890
	s_waitcnt vmcnt(2)                                         // 0000003D9188: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003D918C: 300A0A90
	s_waitcnt vmcnt(1)                                         // 0000003D9190: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000003D9194: 30040490
	s_waitcnt vmcnt(0)                                         // 0000003D9198: BF8903F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000003D919C: 30060690
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003D91A0: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D91A8: BF870091
	v_fma_f32 v2, v2, v7, 0                                    // 0000003D91AC: D6130002 02020F02
	v_dual_fmac_f32 v2, v3, v8 :: v_dual_and_b32 v3, 0xffff0000, v6// 0000003D91B4: C8241103 02020CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v9                           // 0000003D91C0: 360E12FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D91C8: BF870091
	v_fmac_f32_e32 v2, v4, v7                                  // 0000003D91CC: 56040F04
	v_fmac_f32_e32 v2, v5, v3                                  // 0000003D91D0: 56040705
	.long 0xd73c0003                                           // 0000003D91D4: D73C0003
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003D91D8: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003D91DC: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 0000003D91E0: 100404FF 3E800000
	.long 0xd7006a03                                           // 0000003D91E8: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003D91EC: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D91F0: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003D91F4: D5207C04 01AA080B
	v_bfe_u32 v5, v2, 16, 1                                    // 0000003D91FC: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D9204: BF870001
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000003D9208: D6550005 03FE0B02 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000003D9214: DC960000 007C0503
	s_cbranch_scc1 9                                           // 0000003D921C: BFA20009 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi6EEEvPKhPKtS5_PtPf+0x1144>
	.long 0xd73c0000                                           // 0000003D9220: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003D9224: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D9228: BF870091
	.long 0xd7006a00                                           // 0000003D922C: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003D9230: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000003D9234: D5207C01 01AA0205
	global_store_b32 v[0:1], v2, off                           // 0000003D923C: DC6A0000 007C0200
	s_endpgm                                                   // 0000003D9244: BFB00000
		...

