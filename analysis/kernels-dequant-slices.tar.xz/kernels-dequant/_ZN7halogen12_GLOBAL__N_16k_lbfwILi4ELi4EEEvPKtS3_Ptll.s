00000000002d9200 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002D9200: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002D9208: 32020085
	s_mov_b32 s3, 0                                            // 0000002D920C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002D9210: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002D9214: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002D9218: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002D921C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002D9220: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002D9224: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002D9228: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D922C: BF870001
	.long 0xd4d4007e                                           // 0000002D9230: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002D9234: 02020208
	s_cbranch_execz 455                                        // 0000002D9238: BFA501C7 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll+0x758>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002D923C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002D9244: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002D9248: BF89FC07
	.long 0xd451000a                                           // 0000002D924C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002D9250: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002D9254: 8B6A0A7E
	s_cbranch_vccnz 284                                        // 0000002D9258: BFA4011C <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll+0x4cc>
	.long 0xd72c0007                                           // 0000002D925C: D72C0007
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002D9260: 02020207
	.long 0xd72c0008                                           // 0000002D9264: D72C0008
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002D9268: 02020406
	v_mad_u64_u32 v[4:5], null, s6, v1, 0                      // 0000002D926C: D6FE7C04 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002D9274: 848A8106
	s_mul_i32 s12, s7, 6                                       // 0000002D9278: 960C8607
	s_mul_hi_u32 s13, s6, 6                                    // 0000002D927C: 968D8606
	s_mul_i32 s14, s6, 6                                       // 0000002D9280: 960E8606
	s_add_u32 s10, s2, s10                                     // 0000002D9284: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002D9288: 820B0B03
	s_add_i32 s13, s13, s12                                    // 0000002D928C: 810D0C0D
	v_add3_u32 v5, v5, v8, v7                                  // 0000002D9290: D6550005 041E1105
	s_add_u32 s12, s2, s14                                     // 0000002D9298: 800C0E02
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000002D929C: CA220080 06020084
	s_addc_u32 s13, s3, s13                                    // 0000002D92A4: 820D0D03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002D92A8: BF8701B2
	.long 0xd73c0004                                           // 0000002D92AC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002D92B0: 02020881
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000002D92B4: CA100080 09080080
	v_mov_b32_e32 v7, 0                                        // 0000002D92BC: 7E0E0280
	.long 0xd7006a04                                           // 0000002D92C0: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002D92C4: 02020800
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002D92C8: BF8704A1
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000002D92CC: D5207C05 01AA0A01
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002D92D4: 84808206
	s_add_u32 s14, s2, s0                                      // 0000002D92D8: 800E0002
	s_addc_u32 s15, s3, s1                                     // 0000002D92DC: 820F0103
	s_mov_b64 s[0:1], 0                                        // 0000002D92E0: BE800180
	.long 0xd700104a                                           // 0000002D92E4: D700104A
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002D92E8: 02020602
	.long 0xd7006a46                                           // 0000002D92EC: D7006A46
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002D92F0: 02020704
	v_add_co_ci_u32_e64 v75, null, s3, 0, s16                  // 0000002D92F4: D5207C4B 00410003
	.long 0xd700104e                                           // 0000002D92FC: D700104E
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002D9300: 0202060A
	v_add_co_ci_u32_e64 v71, null, 0, v5, vcc_lo               // 0000002D9304: D5207C47 01AA0A80
	v_add_co_ci_u32_e64 v79, null, s11, 0, s16                 // 0000002D930C: D5207C4F 0041000B
	.long 0xd7001052                                           // 0000002D9314: D7001052
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000002D9318: 0202060E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D931C: BF8700A1
	v_add_co_ci_u32_e64 v83, null, s15, 0, s16                 // 0000002D9320: D5207C53 0041000F
	.long 0xd7001056                                           // 0000002D9328: D7001056
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000002D932C: 0202060C
	v_add_co_ci_u32_e64 v87, null, s13, 0, s16                 // 0000002D9330: D5207C57 0041000D
	global_load_b128 v[10:13], v[70:71], off                   // 0000002D9338: DC5E0000 0A7C0046
	global_load_b128 v[14:17], v[74:75], off                   // 0000002D9340: DC5E0000 0E7C004A
	global_load_b128 v[18:21], v[78:79], off                   // 0000002D9348: DC5E0000 127C004E
	global_load_b128 v[22:25], v[82:83], off                   // 0000002D9350: DC5E0000 167C0052
	global_load_b128 v[26:29], v[86:87], off                   // 0000002D9358: DC5E0000 1A7C0056
	global_load_b128 v[30:33], v[70:71], off offset:512        // 0000002D9360: DC5E0200 1E7C0046
	global_load_b128 v[34:37], v[74:75], off offset:512        // 0000002D9368: DC5E0200 227C004A
	global_load_b128 v[38:41], v[78:79], off offset:512        // 0000002D9370: DC5E0200 267C004E
	global_load_b128 v[42:45], v[82:83], off offset:512        // 0000002D9378: DC5E0200 2A7C0052
	global_load_b128 v[46:49], v[86:87], off offset:512        // 0000002D9380: DC5E0200 2E7C0056
	global_load_b128 v[50:53], v[70:71], off offset:1024       // 0000002D9388: DC5E0400 327C0046
	global_load_b128 v[54:57], v[74:75], off offset:1024       // 0000002D9390: DC5E0400 367C004A
	global_load_b128 v[58:61], v[78:79], off offset:1024       // 0000002D9398: DC5E0400 3A7C004E
	global_load_b128 v[62:65], v[82:83], off offset:1024       // 0000002D93A0: DC5E0400 3E7C0052
	global_load_b128 v[66:69], v[86:87], off offset:1024       // 0000002D93A8: DC5E0400 427C0056
	global_load_b128 v[70:73], v[70:71], off offset:1536       // 0000002D93B0: DC5E0600 467C0046
	global_load_b128 v[74:77], v[74:75], off offset:1536       // 0000002D93B8: DC5E0600 4A7C004A
	global_load_b128 v[78:81], v[78:79], off offset:1536       // 0000002D93C0: DC5E0600 4E7C004E
	global_load_b128 v[82:85], v[82:83], off offset:1536       // 0000002D93C8: DC5E0600 527C0052
	global_load_b128 v[86:89], v[86:87], off offset:1536       // 0000002D93D0: DC5E0600 567C0056
	s_add_u32 s0, s0, 0x400                                    // 0000002D93D8: 8000FF00 00000400
	s_addc_u32 s1, s1, 0                                       // 0000002D93E0: 82018001
	s_add_u32 s10, s10, 0x800                                  // 0000002D93E4: 800AFF0A 00000800
	s_addc_u32 s11, s11, 0                                     // 0000002D93EC: 820B800B
	.long 0xd4560010                                           // 0000002D93F0: D4560010
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002D93F4: 02000C00
	.long 0xd7006a04                                           // 0000002D93F8: D7006A04
	v_cndmask_b32_e32 v1, 0x800, v4, vcc_lo                    // 0000002D93FC: 020208FF 00000800
	s_add_u32 s12, s12, 0x800                                  // 0000002D9404: 800CFF0C 00000800
	s_addc_u32 s13, s13, 0                                     // 0000002D940C: 820D800D
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002D9410: D5207C05 01AA0A80
	s_add_u32 s2, s2, 0x800                                    // 0000002D9418: 8002FF02 00000800
	s_addc_u32 s3, s3, 0                                       // 0000002D9420: 82038003
	s_add_u32 s14, s14, 0x800                                  // 0000002D9424: 800EFF0E 00000800
	s_addc_u32 s15, s15, 0                                     // 0000002D942C: 820F800F
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000002D9430: 8B6A107E
	s_waitcnt vmcnt(18)                                        // 0000002D9434: BF894BF7
	v_dot2_f32_bf16 v6, v14, v10, v6                           // 0000002D9438: CC1A4006 1C1A150E
	s_waitcnt vmcnt(17)                                        // 0000002D9440: BF8947F7
	v_dot2_f32_bf16 v9, v18, v10, v9                           // 0000002D9444: CC1A4009 1C261512
	s_waitcnt vmcnt(16)                                        // 0000002D944C: BF8943F7
	v_dot2_f32_bf16 v8, v22, v10, v8                           // 0000002D9450: CC1A4008 1C221516
	s_waitcnt vmcnt(15)                                        // 0000002D9458: BF893FF7
	v_dot2_f32_bf16 v7, v26, v10, v7                           // 0000002D945C: CC1A4007 1C1E151A
	v_dot2_f32_bf16 v6, v15, v11, v6                           // 0000002D9464: CC1A4006 1C1A170F
	v_dot2_f32_bf16 v9, v19, v11, v9                           // 0000002D946C: CC1A4009 1C261713
	v_dot2_f32_bf16 v8, v23, v11, v8                           // 0000002D9474: CC1A4008 1C221717
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D947C: BF870214
	v_dot2_f32_bf16 v7, v27, v11, v7                           // 0000002D9480: CC1A4007 1C1E171B
	v_dot2_f32_bf16 v6, v16, v12, v6                           // 0000002D9488: CC1A4006 1C1A1910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9490: BF870214
	v_dot2_f32_bf16 v9, v20, v12, v9                           // 0000002D9494: CC1A4009 1C261914
	v_dot2_f32_bf16 v8, v24, v12, v8                           // 0000002D949C: CC1A4008 1C221918
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D94A4: BF870214
	v_dot2_f32_bf16 v7, v28, v12, v7                           // 0000002D94A8: CC1A4007 1C1E191C
	v_dot2_f32_bf16 v6, v17, v13, v6                           // 0000002D94B0: CC1A4006 1C1A1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D94B8: BF870214
	v_dot2_f32_bf16 v9, v21, v13, v9                           // 0000002D94BC: CC1A4009 1C261B15
	v_dot2_f32_bf16 v8, v25, v13, v8                           // 0000002D94C4: CC1A4008 1C221B19
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D94CC: BF870004
	v_dot2_f32_bf16 v7, v29, v13, v7                           // 0000002D94D0: CC1A4007 1C1E1B1D
	s_waitcnt vmcnt(13)                                        // 0000002D94D8: BF8937F7
	v_dot2_f32_bf16 v6, v34, v30, v6                           // 0000002D94DC: CC1A4006 1C1A3D22
	s_waitcnt vmcnt(12)                                        // 0000002D94E4: BF8933F7
	v_dot2_f32_bf16 v9, v38, v30, v9                           // 0000002D94E8: CC1A4009 1C263D26
	s_waitcnt vmcnt(11)                                        // 0000002D94F0: BF892FF7
	v_dot2_f32_bf16 v8, v42, v30, v8                           // 0000002D94F4: CC1A4008 1C223D2A
	s_waitcnt vmcnt(10)                                        // 0000002D94FC: BF892BF7
	v_dot2_f32_bf16 v7, v46, v30, v7                           // 0000002D9500: CC1A4007 1C1E3D2E
	v_dot2_f32_bf16 v6, v35, v31, v6                           // 0000002D9508: CC1A4006 1C1A3F23
	v_dot2_f32_bf16 v9, v39, v31, v9                           // 0000002D9510: CC1A4009 1C263F27
	v_dot2_f32_bf16 v8, v43, v31, v8                           // 0000002D9518: CC1A4008 1C223F2B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9520: BF870214
	v_dot2_f32_bf16 v7, v47, v31, v7                           // 0000002D9524: CC1A4007 1C1E3F2F
	v_dot2_f32_bf16 v6, v36, v32, v6                           // 0000002D952C: CC1A4006 1C1A4124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9534: BF870214
	v_dot2_f32_bf16 v9, v40, v32, v9                           // 0000002D9538: CC1A4009 1C264128
	v_dot2_f32_bf16 v8, v44, v32, v8                           // 0000002D9540: CC1A4008 1C22412C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9548: BF870214
	v_dot2_f32_bf16 v7, v48, v32, v7                           // 0000002D954C: CC1A4007 1C1E4130
	v_dot2_f32_bf16 v6, v37, v33, v6                           // 0000002D9554: CC1A4006 1C1A4325
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D955C: BF870214
	v_dot2_f32_bf16 v9, v41, v33, v9                           // 0000002D9560: CC1A4009 1C264329
	v_dot2_f32_bf16 v8, v45, v33, v8                           // 0000002D9568: CC1A4008 1C22432D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9570: BF870004
	v_dot2_f32_bf16 v7, v49, v33, v7                           // 0000002D9574: CC1A4007 1C1E4331
	s_waitcnt vmcnt(8)                                         // 0000002D957C: BF8923F7
	v_dot2_f32_bf16 v6, v54, v50, v6                           // 0000002D9580: CC1A4006 1C1A6536
	s_waitcnt vmcnt(7)                                         // 0000002D9588: BF891FF7
	v_dot2_f32_bf16 v9, v58, v50, v9                           // 0000002D958C: CC1A4009 1C26653A
	s_waitcnt vmcnt(6)                                         // 0000002D9594: BF891BF7
	v_dot2_f32_bf16 v8, v62, v50, v8                           // 0000002D9598: CC1A4008 1C22653E
	s_waitcnt vmcnt(5)                                         // 0000002D95A0: BF8917F7
	v_dot2_f32_bf16 v7, v66, v50, v7                           // 0000002D95A4: CC1A4007 1C1E6542
	v_dot2_f32_bf16 v6, v55, v51, v6                           // 0000002D95AC: CC1A4006 1C1A6737
	v_dot2_f32_bf16 v9, v59, v51, v9                           // 0000002D95B4: CC1A4009 1C26673B
	v_dot2_f32_bf16 v8, v63, v51, v8                           // 0000002D95BC: CC1A4008 1C22673F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D95C4: BF870214
	v_dot2_f32_bf16 v7, v67, v51, v7                           // 0000002D95C8: CC1A4007 1C1E6743
	v_dot2_f32_bf16 v6, v56, v52, v6                           // 0000002D95D0: CC1A4006 1C1A6938
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D95D8: BF870214
	v_dot2_f32_bf16 v9, v60, v52, v9                           // 0000002D95DC: CC1A4009 1C26693C
	v_dot2_f32_bf16 v8, v64, v52, v8                           // 0000002D95E4: CC1A4008 1C226940
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D95EC: BF870214
	v_dot2_f32_bf16 v7, v68, v52, v7                           // 0000002D95F0: CC1A4007 1C1E6944
	v_dot2_f32_bf16 v6, v57, v53, v6                           // 0000002D95F8: CC1A4006 1C1A6B39
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9600: BF870214
	v_dot2_f32_bf16 v9, v61, v53, v9                           // 0000002D9604: CC1A4009 1C266B3D
	v_dot2_f32_bf16 v8, v65, v53, v8                           // 0000002D960C: CC1A4008 1C226B41
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D9614: BF870004
	v_dot2_f32_bf16 v7, v69, v53, v7                           // 0000002D9618: CC1A4007 1C1E6B45
	s_waitcnt vmcnt(3)                                         // 0000002D9620: BF890FF7
	v_dot2_f32_bf16 v6, v74, v70, v6                           // 0000002D9624: CC1A4006 1C1A8D4A
	s_waitcnt vmcnt(2)                                         // 0000002D962C: BF890BF7
	v_dot2_f32_bf16 v9, v78, v70, v9                           // 0000002D9630: CC1A4009 1C268D4E
	s_waitcnt vmcnt(1)                                         // 0000002D9638: BF8907F7
	v_dot2_f32_bf16 v8, v82, v70, v8                           // 0000002D963C: CC1A4008 1C228D52
	s_waitcnt vmcnt(0)                                         // 0000002D9644: BF8903F7
	v_dot2_f32_bf16 v7, v86, v70, v7                           // 0000002D9648: CC1A4007 1C1E8D56
	v_dot2_f32_bf16 v6, v75, v71, v6                           // 0000002D9650: CC1A4006 1C1A8F4B
	v_dot2_f32_bf16 v9, v79, v71, v9                           // 0000002D9658: CC1A4009 1C268F4F
	v_dot2_f32_bf16 v8, v83, v71, v8                           // 0000002D9660: CC1A4008 1C228F53
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9668: BF870214
	v_dot2_f32_bf16 v7, v87, v71, v7                           // 0000002D966C: CC1A4007 1C1E8F57
	v_dot2_f32_bf16 v6, v76, v72, v6                           // 0000002D9674: CC1A4006 1C1A914C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D967C: BF870214
	v_dot2_f32_bf16 v9, v80, v72, v9                           // 0000002D9680: CC1A4009 1C269150
	v_dot2_f32_bf16 v8, v84, v72, v8                           // 0000002D9688: CC1A4008 1C229154
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D9690: BF870214
	v_dot2_f32_bf16 v7, v88, v72, v7                           // 0000002D9694: CC1A4007 1C1E9158
	v_dot2_f32_bf16 v6, v77, v73, v6                           // 0000002D969C: CC1A4006 1C1A934D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D96A4: BF870214
	v_dot2_f32_bf16 v9, v81, v73, v9                           // 0000002D96A8: CC1A4009 1C269351
	v_dot2_f32_bf16 v8, v85, v73, v8                           // 0000002D96B0: CC1A4008 1C229355
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002D96B8: BF870004
	v_dot2_f32_bf16 v7, v89, v73, v7                           // 0000002D96BC: CC1A4007 1C1E9359
	s_cbranch_vccz 65287                                       // 0000002D96C4: BFA3FF07 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll+0xe4>
	s_branch 4                                                 // 0000002D96C8: BFA00004 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll+0x4dc>
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v8, 0               // 0000002D96CC: CA100080 07080080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v6, 0               // 0000002D96D4: CA100080 09060080
	.long 0xd71f0003                                           // 0000002D96DC: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002D96E0: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D96E4: BF870121
	v_xor_b32_e32 v4, 16, v3                                   // 0000002D96E8: 3A080690
	v_xor_b32_e32 v12, 8, v3                                   // 0000002D96EC: 3A180688
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002D96F0: 7C9808A0
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo                       // 0000002D96F4: 02080903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D96F8: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D96FC: 7C9818A0
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002D9700: 30080882
	ds_bpermute_b32 v11, v4, v8                                // 0000002D9704: DACC0000 0B000804
	ds_bpermute_b32 v5, v4, v6                                 // 0000002D970C: DACC0000 05000604
	ds_bpermute_b32 v10, v4, v9                                // 0000002D9714: DACC0000 0A000904
	ds_bpermute_b32 v4, v4, v7                                 // 0000002D971C: DACC0000 04000704
	s_waitcnt lgkmcnt(3)                                       // 0000002D9724: BF89FC37
	v_add_f32_e32 v8, v8, v11                                  // 0000002D9728: 06101708
	s_waitcnt lgkmcnt(2)                                       // 0000002D972C: BF89FC27
	v_dual_cndmask_b32 v12, v3, v12 :: v_dual_add_f32 v5, v6, v5// 0000002D9730: CA481903 0C040B06
	s_waitcnt lgkmcnt(1)                                       // 0000002D9738: BF89FC17
	v_add_f32_e32 v6, v9, v10                                  // 0000002D973C: 060C1509
	s_waitcnt lgkmcnt(0)                                       // 0000002D9740: BF89FC07
	v_add_f32_e32 v4, v7, v4                                   // 0000002D9744: 06080907
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002D9748: 30181882
	ds_bpermute_b32 v7, v12, v5                                // 0000002D974C: DACC0000 0700050C
	ds_bpermute_b32 v9, v12, v6                                // 0000002D9754: DACC0000 0900060C
	ds_bpermute_b32 v10, v12, v8                               // 0000002D975C: DACC0000 0A00080C
	ds_bpermute_b32 v11, v12, v4                               // 0000002D9764: DACC0000 0B00040C
	v_xor_b32_e32 v12, 4, v3                                   // 0000002D976C: 3A180684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002D9770: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D9774: 7C9818A0
	v_cndmask_b32_e32 v12, v3, v12, vcc_lo                     // 0000002D9778: 02181903
	s_waitcnt lgkmcnt(3)                                       // 0000002D977C: BF89FC37
	v_dual_add_f32 v5, v5, v7 :: v_dual_lshlrev_b32 v12, 2, v12// 0000002D9780: C9220F05 050C1882
	s_waitcnt lgkmcnt(1)                                       // 0000002D9788: BF89FC17
	v_add_f32_e32 v7, v8, v10                                  // 0000002D978C: 060E1508
	s_waitcnt lgkmcnt(0)                                       // 0000002D9790: BF89FC07
	v_add_f32_e32 v4, v4, v11                                  // 0000002D9794: 06081704
	ds_bpermute_b32 v8, v12, v5                                // 0000002D9798: DACC0000 0800050C
	v_add_f32_e32 v6, v6, v9                                   // 0000002D97A0: 060C1306
	ds_bpermute_b32 v10, v12, v7                               // 0000002D97A4: DACC0000 0A00070C
	ds_bpermute_b32 v11, v12, v4                               // 0000002D97AC: DACC0000 0B00040C
	s_waitcnt lgkmcnt(2)                                       // 0000002D97B4: BF89FC27
	v_add_f32_e32 v5, v5, v8                                   // 0000002D97B8: 060A1105
	ds_bpermute_b32 v9, v12, v6                                // 0000002D97BC: DACC0000 0900060C
	v_xor_b32_e32 v12, 2, v3                                   // 0000002D97C4: 3A180682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D97C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002D97CC: 7C9818A0
	v_cndmask_b32_e32 v12, v3, v12, vcc_lo                     // 0000002D97D0: 02181903
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000002D97D4: 30181882
	s_waitcnt lgkmcnt(0)                                       // 0000002D97D8: BF89FC07
	v_dual_add_f32 v6, v6, v9 :: v_dual_add_f32 v9, v7, v10    // 0000002D97DC: C9081306 06081507
	v_add_f32_e32 v10, v4, v11                                 // 0000002D97E4: 06141704
	ds_bpermute_b32 v4, v12, v5                                // 0000002D97E8: DACC0000 0400050C
	v_xor_b32_e32 v7, 1, v3                                    // 0000002D97F0: 3A0E0681
	ds_bpermute_b32 v8, v12, v6                                // 0000002D97F4: DACC0000 0800060C
	ds_bpermute_b32 v11, v12, v9                               // 0000002D97FC: DACC0000 0B00090C
	ds_bpermute_b32 v12, v12, v10                              // 0000002D9804: DACC0000 0C000A0C
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002D980C: 7C980EA0
	v_cndmask_b32_e32 v3, v3, v7, vcc_lo                       // 0000002D9810: 02060F03
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002D9814: 7C940080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002D9818: BF870002
	v_lshlrev_b32_e32 v13, 2, v3                               // 0000002D981C: 301A0682
	s_waitcnt lgkmcnt(3)                                       // 0000002D9820: BF89FC37
	v_add_f32_e32 v7, v5, v4                                   // 0000002D9824: 060E0905
	s_waitcnt lgkmcnt(2)                                       // 0000002D9828: BF89FC27
	v_add_f32_e32 v8, v6, v8                                   // 0000002D982C: 06101106
	s_waitcnt lgkmcnt(0)                                       // 0000002D9830: BF89FC07
	v_dual_add_f32 v4, v9, v11 :: v_dual_add_f32 v3, v10, v12  // 0000002D9834: C9081709 0402190A
	ds_bpermute_b32 v9, v13, v7                                // 0000002D983C: DACC0000 0900070D
	ds_bpermute_b32 v10, v13, v8                               // 0000002D9844: DACC0000 0A00080D
	ds_bpermute_b32 v5, v13, v4                                // 0000002D984C: DACC0000 0500040D
	ds_bpermute_b32 v6, v13, v3                                // 0000002D9854: DACC0000 0600030D
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002D985C: 8B7E6A7E
	s_cbranch_execz 61                                         // 0000002D9860: BFA5003D <_ZN7halogen12_GLOBAL__N_16k_lbfwILi4ELi4EEEvPKtS3_Ptll+0x758>
	s_waitcnt lgkmcnt(2)                                       // 0000002D9864: BF89FC27
	v_dual_add_f32 v8, v8, v10 :: v_dual_add_f32 v7, v7, v9    // 0000002D9868: C9081508 08061307
	.long 0xd73c0000                                           // 0000002D9870: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002D9874: 02020281
	.long 0x7f123880                                           // 0000002D9878: 7F123880
	s_waitcnt lgkmcnt(0)                                       // 0000002D987C: BF89FC07
	v_dual_add_f32 v11, v4, v5 :: v_dual_add_f32 v12, v3, v6   // 0000002D9880: C9080B04 0B0C0D03
	.long 0x7e123988                                           // 0000002D9888: 7E123988
	.long 0x7e143987                                           // 0000002D988C: 7E143987
	.long 0xd7006a03                                           // 0000002D9890: D7006A03
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002D9894: 02020004
	.long 0x7f143989                                           // 0000002D9898: 7F143989
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 0000002D989C: D5207C04 01AA0205
	v_and_b32_e32 v2, 1, v9                                    // 0000002D98A4: 36041281
	.long 0x7e12398c                                           // 0000002D98A8: 7E12398C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D98AC: BF870214
	v_and_b32_e32 v5, 1, v10                                   // 0000002D98B0: 360A1481
	v_mad_u64_u32 v[0:1], null, s8, 6, v[3:4]                  // 0000002D98B4: D6FE7C00 040D0C08
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002D98BC: 84808108
	v_add3_u32 v10, v8, v2, 0x7fff                             // 0000002D98C0: D655000A 03FE0508 00007FFF
	.long 0x7e04398b                                           // 0000002D98CC: 7E04398B
	.long 0x7f043989                                           // 0000002D98D0: 7F043989
	v_add3_u32 v13, v7, v5, 0x7fff                             // 0000002D98D4: D655000D 03FE0B07 00007FFF
	.long 0xd7006a05                                           // 0000002D98E0: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002D98E4: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D98E8: BF870211
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000002D98EC: D5207C06 01AA0801
	v_and_b32_e32 v14, 1, v2                                   // 0000002D98F4: 361C0481
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002D98F8: 84808208
	v_and_b32_e32 v9, 1, v9                                    // 0000002D98FC: 36121281
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002D9900: D6FE7C01 04050C09
	.long 0xd7006a07                                           // 0000002D9908: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000002D990C: 02000103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D9910: BF870001
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 0000002D9914: D5207C08 01AA0801
	v_add3_u32 v2, v11, v14, 0x7fff                            // 0000002D991C: D6550002 03FE1D0B 00007FFF
	v_add3_u32 v9, v12, v9, 0x7fff                             // 0000002D9928: D6550009 03FE130C 00007FFF
	s_clause 0x3                                               // 0000002D9934: BF850003
	global_store_d16_hi_b16 v[3:4], v13, off                   // 0000002D9938: DC960000 007C0D03
	global_store_d16_hi_b16 v[5:6], v10, off                   // 0000002D9940: DC960000 007C0A05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000002D9948: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002D9950: DC960000 007C0900
	s_endpgm                                                   // 0000002D9958: BFB00000
		...

