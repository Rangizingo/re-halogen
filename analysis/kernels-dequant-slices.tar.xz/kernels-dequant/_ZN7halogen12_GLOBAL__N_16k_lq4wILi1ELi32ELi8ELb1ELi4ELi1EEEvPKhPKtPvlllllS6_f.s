0000000000f7f900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F7F900: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000F7F908: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F7F90C: 32040082
	v_lshrrev_b32_e32 v21, 5, v0                               // 000000F7F910: 322A0085
	v_and_b32_e32 v22, 31, v0                                  // 000000F7F914: 362C009F
	.long 0x7f0a3880                                           // 000000F7F918: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 000000F7F91C: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 000000F7F920: BF89FC07
	.long 0xd4510000                                           // 000000F7F924: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F7F928: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000F7F92C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000F7F930: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000F7F934: 98158002
	s_add_u32 s0, s4, s16                                      // 000000F7F938: 80001004
	s_addc_u32 s1, s5, s17                                     // 000000F7F93C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000F7F940: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000F7F944: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000F7F948: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F7F94C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000F7F950: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F7F954: 30020282
	s_add_u32 s16, s10, s16                                    // 000000F7F958: 8010100A
	s_clause 0x1                                               // 000000F7F95C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000F7F960: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000F7F968: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000F7F970: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000F7F974: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000F7F978: 85908510
	v_mov_b32_e32 v1, s0                                       // 000000F7F97C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000F7F980: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000F7F984: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000F7F988: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000F7F98C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000F7F990: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 000000F7F994: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 000000F7F99C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 000000F7F9A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 000000F7F9A4: B3900801
	.long 0xd72c0001                                           // 000000F7F9A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v21, vcc_lo                      // 000000F7F9AC: 02022A00
	s_mul_i32 s17, s18, s20                                    // 000000F7F9B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F7F9B4: BF870141
	v_add_nc_u32_e32 v8, s0, v1                                // 000000F7F9B8: 4A100200
	v_add_nc_u32_e32 v23, v1, v22                              // 000000F7F9BC: 4A2E2D01
	s_cselect_b32 s0, -1, 0                                    // 000000F7F9C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 000000F7F9C4: B2900800
	v_min_i32_e32 v24, s16, v8                                 // 000000F7F9C8: 22301010
	s_cselect_b32 s16, -1, 0                                   // 000000F7F9CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F7F9D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 000000F7F9D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 000000F7F9D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 000000F7F9DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 000000F7F9E4: BF8903F7
	v_bfe_u32 v7, v4, 16, 1                                    // 000000F7F9E8: D6100007 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000F7F9F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 000000F7F9FC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F7FA00: BF870223
	v_add3_u32 v4, v4, v7, 0x7fff                              // 000000F7FA04: D6550004 03FE0F04 00007FFF
	.long 0xd4410001                                           // 000000F7FA10: D4410001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 000000F7FA14: 02023117
	.long 0x7e0a3982                                           // 000000F7FA18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F7FA1C: BF870114
	v_add_nc_u32_e32 v25, s17, v3                              // 000000F7FA20: 4A320611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000F7FA24: D6570001 041608FF FFFF0000
	ds_store_b32 v6, v1 offset:32                              // 000000F7FA30: D8340020 00000106
	s_waitcnt lgkmcnt(0)                                       // 000000F7FA38: BF89FC07
	s_barrier                                                  // 000000F7FA3C: BFBD0000
	buffer_gl0_inv                                             // 000000F7FA40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000F7FA48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000F7FA4C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 000000F7FA54: BE912001
	s_cbranch_execz 11                                         // 000000F7FA58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v23                               // 000000F7FA5C: 30022E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FA60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 000000F7FA64: 3408029F
	.long 0xd7006a03                                           // 000000F7FA68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 000000F7FA6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v25, v4, vcc_lo              // 000000F7FA70: D5207C04 01AA0919
	global_load_d16_b16 v1, v[3:4], off                        // 000000F7FA78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 000000F7FA80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F7FA84: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000F7FA88: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v23                               // 000000F7FA8C: 4A062EA0
	s_mov_b32 s1, exec_lo                                      // 000000F7FA90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FA94: BF870001
	.long 0xd4c1007e                                           // 000000F7FA98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 000000F7FA9C: 02023103
	s_cbranch_execz 11                                         // 000000F7FAA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 000000F7FAA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FAA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000F7FAAC: 3406049F
	.long 0xd7006a02                                           // 000000F7FAB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 000000F7FAB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v25, v3, vcc_lo              // 000000F7FAB8: D5207C03 01AA0719
	global_load_d16_b16 v2, v[2:3], off                        // 000000F7FAC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 000000F7FAC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F7FACC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FAD0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v23      // 000000F7FAD4: CA200080 04042EC0
	v_mov_b32_e32 v3, 0                                        // 000000F7FADC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 000000F7FAE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F7FAE4: BF870002
	.long 0xd4c1007e                                           // 000000F7FAE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 000000F7FAEC: 02023105
	s_cbranch_execz 11                                         // 000000F7FAF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 000000F7FAF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FAF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 000000F7FAFC: 340C069F
	.long 0xd7006a05                                           // 000000F7FB00: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000F7FB04: 02020711
	v_add_co_ci_u32_e64 v6, null, v25, v6, vcc_lo              // 000000F7FB08: D5207C06 01AA0D19
	global_load_d16_b16 v3, v[5:6], off                        // 000000F7FB10: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 000000F7FB18: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F7FB1C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FB20: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v23                             // 000000F7FB24: 4A0A2EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000F7FB2C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FB30: BF870001
	.long 0xd4c1007e                                           // 000000F7FB34: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 000000F7FB38: 02023105
	s_cbranch_execz 11                                         // 000000F7FB3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 000000F7FB40: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FB44: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 000000F7FB48: 340A089F
	.long 0xd7006a04                                           // 000000F7FB4C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 000000F7FB50: 02020911
	v_add_co_ci_u32_e64 v5, null, v25, v5, vcc_lo              // 000000F7FB54: D5207C05 01AA0B19
	global_load_d16_b16 v4, v[4:5], off                        // 000000F7FB5C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 000000F7FB64: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F7FB68: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FB6C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v23    // 000000F7FB70: CA200080 06062EFF 00000080
	v_mov_b32_e32 v5, 0                                        // 000000F7FB7C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 000000F7FB80: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F7FB84: BF870002
	.long 0xd4c1007e                                           // 000000F7FB88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 000000F7FB8C: 02023107
	s_cbranch_execz 11                                         // 000000F7FB90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 000000F7FB94: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FB98: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 000000F7FB9C: 34100A9F
	.long 0xd7006a07                                           // 000000F7FBA0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 000000F7FBA4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v25, v8, vcc_lo              // 000000F7FBA8: D5207C08 01AA1119
	global_load_d16_b16 v5, v[7:8], off                        // 000000F7FBB0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 000000F7FBB8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F7FBBC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FBC0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v23                             // 000000F7FBC4: 4A0E2EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000F7FBCC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FBD0: BF870001
	.long 0xd4c1007e                                           // 000000F7FBD4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 000000F7FBD8: 02023107
	s_cbranch_execz 11                                         // 000000F7FBDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 000000F7FBE0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FBE4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000F7FBE8: 340E0C9F
	.long 0xd7006a06                                           // 000000F7FBEC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 000000F7FBF0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v25, v7, vcc_lo              // 000000F7FBF4: D5207C07 01AA0F19
	global_load_d16_b16 v6, v[6:7], off                        // 000000F7FBFC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 000000F7FC04: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F7FC08: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FC0C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v23    // 000000F7FC10: CA200080 08082EFF 000000C0
	v_mov_b32_e32 v7, 0                                        // 000000F7FC1C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 000000F7FC20: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F7FC24: BF870002
	.long 0xd4c1007e                                           // 000000F7FC28: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 000000F7FC2C: 02023109
	s_cbranch_execz 11                                         // 000000F7FC30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 000000F7FC34: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FC38: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 000000F7FC3C: 34140E9F
	.long 0xd7006a09                                           // 000000F7FC40: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 000000F7FC44: 02020F11
	v_add_co_ci_u32_e64 v10, null, v25, v10, vcc_lo            // 000000F7FC48: D5207C0A 01AA1519
	global_load_d16_b16 v7, v[9:10], off                       // 000000F7FC50: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 000000F7FC58: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F7FC5C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FC60: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v23                             // 000000F7FC64: 4A122EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000F7FC6C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FC70: BF870001
	.long 0xd4c1007e                                           // 000000F7FC74: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 000000F7FC78: 02023109
	s_cbranch_execz 11                                         // 000000F7FC7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 000000F7FC80: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FC84: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 000000F7FC88: 3412109F
	.long 0xd7006a08                                           // 000000F7FC8C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 000000F7FC90: 02021111
	v_add_co_ci_u32_e64 v9, null, v25, v9, vcc_lo              // 000000F7FC94: D5207C09 01AA1319
	global_load_d16_b16 v8, v[8:9], off                        // 000000F7FC9C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 000000F7FCA4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 000000F7FCA8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 000000F7FCAC: 8C7E017E
	s_branch 9                                                 // 000000F7FCB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 000000F7FCB4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FCB8: BF870001
	v_mov_b32_e32 v2, v1                                       // 000000F7FCBC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 000000F7FCC0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 000000F7FCC4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 000000F7FCC8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 000000F7FCCC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 000000F7FCD0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 000000F7FCD4: 7E100301
	s_add_u32 s4, s4, s14                                      // 000000F7FCD8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000F7FCDC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000F7FCE0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v26, 0            // 000000F7FCE4: CA100015 091A0080
	s_add_u32 s10, s10, s1                                     // 000000F7FCEC: 800A010A
	s_addc_u32 s11, s11, 0                                     // 000000F7FCF0: 820B800B
	.long 0xd4410001                                           // 000000F7FCF4: D4410001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 000000F7FCF8: 02023117
	s_ashr_i64 s[10:11], s[10:11], 1                           // 000000F7FCFC: 868A810A
	v_cndmask_b32_e64 v27, 0, 1, s16                           // 000000F7FD00: D501001B 00410280
	v_mad_u64_u32 v[18:19], null, v9, s10, s[4:5]              // 000000F7FD08: D6FE7C12 00101509
	.long 0xd72c000b                                           // 000000F7FD10: D72C000B
	v_cndmask_b32_e32 v0, s21, v11, vcc_lo                     // 000000F7FD14: 02001615
	.long 0xd72c000c                                           // 000000F7FD18: D72C000C
	v_cndmask_b32_e32 v0, s20, v10, vcc_lo                     // 000000F7FD1C: 02001414
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 000000F7FD20: CA100080 090A0080
	v_mov_b32_e32 v29, 0                                       // 000000F7FD28: 7E3A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F7FD2C: BF870003
	v_add3_u32 v28, v12, v19, v11                              // 000000F7FD30: D655001C 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 000000F7FD38: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 000000F7FD40: BE842001
	s_cbranch_execz 22                                         // 000000F7FD44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v23                               // 000000F7FD48: 30122E84
	v_mov_b32_e32 v29, 0                                       // 000000F7FD4C: 7E3A0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F7FD50: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 000000F7FD54: 3414129F
	.long 0xd7006a09                                           // 000000F7FD58: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 000000F7FD5C: 02021312
	v_add_co_ci_u32_e64 v10, null, v28, v10, vcc_lo            // 000000F7FD60: D5207C0A 01AA151C
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000F7FD68: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 000000F7FD6C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 000000F7FD74: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v23                              // 000000F7FD78: 301A2E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F7FD7C: BF870091
	.long 0xd7006a0d                                           // 000000F7FD80: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 000000F7FD84: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 000000F7FD88: D5207C0E 01AA3280
	global_load_d16_b16 v13, v[13:14], off                     // 000000F7FD90: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 000000F7FD98: BF8903F7
	v_cvt_f32_f16_e32 v29, v13                                 // 000000F7FD9C: 7E3A170D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F7FDA0: 8C7E047E
	s_and_saveexec_b32 s4, s1                                  // 000000F7FDA4: BE842001
	s_cbranch_execz 233                                        // 000000F7FDA8: BFA500E9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v13, 32, v23    // 000000F7FDAC: CA200080 1A0C2EA0
	v_dual_mov_b32 v32, v29 :: v_dual_lshlrev_b32 v19, 5, v23  // 000000F7FDB4: CA22011D 20122E85
	s_mov_b32 s5, 0                                            // 000000F7FDBC: BE850080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F7FDC0: BF870002
	v_lshlrev_b32_e32 v30, 4, v13                              // 000000F7FDC4: 303C1A84
	v_lshlrev_b32_e32 v31, 1, v13                              // 000000F7FDC8: 303E1A81
	s_branch 188                                               // 000000F7FDCC: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F7FDD0: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 000000F7FDD4: 3428269F
	v_lshrrev_b32_e32 v49, 6, v9                               // 000000F7FDD8: 32621286
	v_lshrrev_b32_e32 v50, 14, v9                              // 000000F7FDDC: 3264128E
	v_and_b32_e32 v51, 0xff, v10                               // 000000F7FDE0: 366614FF 000000FF
	v_lshrrev_b32_e32 v52, 6, v10                              // 000000F7FDE8: 32681486
	.long 0xd73c0021                                           // 000000F7FDEC: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F7FDF0: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 000000F7FDF4: 362812FF 000000FF
	v_and_b32_e32 v49, 0x3fc, v49                              // 000000F7FDFC: 366262FF 000003FC
	v_and_b32_e32 v50, 0x3fc, v50                              // 000000F7FE04: 366464FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 000000F7FE0C: 32121296
	v_lshrrev_b32_e32 v53, 14, v10                             // 000000F7FE10: 326A148E
	.long 0xd7006a2d                                           // 000000F7FE14: D7006A2D
	v_cndmask_b32_e32 v1, s6, v33, vcc_lo                      // 000000F7FE18: 02024206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F7FE1C: BF870001
	v_add_co_ci_u32_e64 v46, null, s7, v34, vcc_lo             // 000000F7FE20: D5207C2E 01AA4407
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000F7FE28: 30282882
	ds_load_b32 v49, v49 offset:32                             // 000000F7FE2C: D8D80020 31000031
	ds_load_b32 v50, v50 offset:32                             // 000000F7FE34: D8D80020 32000032
	s_clause 0x3                                               // 000000F7FE3C: BF850003
	global_load_b128 v[33:36], v[45:46], off                   // 000000F7FE40: DC5E0000 217C002D
	global_load_b128 v[37:40], v[45:46], off offset:16         // 000000F7FE48: DC5E0010 257C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 000000F7FE50: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000F7FE58: DC5E0030 2D7C002D
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000F7FE60: 32141496
	ds_load_b32 v20, v20 offset:32                             // 000000F7FE64: D8D80020 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 000000F7FE6C: 361212FF 000003FC
	v_lshlrev_b32_e32 v51, 2, v51                              // 000000F7FE74: 30666682
	v_and_b32_e32 v52, 0x3fc, v52                              // 000000F7FE78: 366868FF 000003FC
	v_and_b32_e32 v53, 0x3fc, v53                              // 000000F7FE80: 366A6AFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000F7FE88: 361414FF 000003FC
	ds_load_b32 v9, v9 offset:32                               // 000000F7FE90: D8D80020 09000009
	ds_load_b32 v51, v51 offset:32                             // 000000F7FE98: D8D80020 33000033
	ds_load_b32 v52, v52 offset:32                             // 000000F7FEA0: D8D80020 34000034
	ds_load_b32 v53, v53 offset:32                             // 000000F7FEA8: D8D80020 35000035
	ds_load_b32 v10, v10 offset:32                             // 000000F7FEB0: D8D80020 0A00000A
	v_add_nc_u32_e32 v30, 0x200, v30                           // 000000F7FEB8: 4A3C3CFF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 000000F7FEC0: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F7FEC4: BF870149
	s_or_b32 s5, s1, s5                                        // 000000F7FEC8: 8C050501
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 000000F7FECC: BF890C57
	v_dot2_f32_bf16 v20, v33, v20, 0                           // 000000F7FED0: CC1A4014 1A022921
	v_and_b32_e32 v33, 0xff, v11                               // 000000F7FED8: 364216FF 000000FF
	v_dot2_f32_bf16 v20, v34, v49, v20                         // 000000F7FEE0: CC1A4014 1C526322
	v_lshrrev_b32_e32 v34, 6, v11                              // 000000F7FEE8: 32441686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F7FEEC: BF8701A2
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 000000F7FEF0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 14, v11                             // 000000F7FEF8: 3246168E
	v_and_b32_e32 v34, 0x3fc, v34                              // 000000F7FEFC: 364444FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 000000F7FF04: 32161696
	s_waitcnt lgkmcnt(4)                                       // 000000F7FF08: BF89FC47
	v_dot2_f32_bf16 v9, v36, v9, v20                           // 000000F7FF0C: CC1A4009 1C521324
	v_and_b32_e32 v35, 0x3fc, v35                              // 000000F7FF14: 364646FF 000003FC
	v_lshrrev_b32_e32 v36, 6, v12                              // 000000F7FF1C: 32481886
	ds_load_b32 v34, v34 offset:32                             // 000000F7FF20: D8D80020 22000022
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 000000F7FF28: BF890847
	v_dot2_f32_bf16 v9, v37, v51, v9                           // 000000F7FF2C: CC1A4009 1C266725
	ds_load_b32 v35, v35 offset:32                             // 000000F7FF34: D8D80020 23000023
	v_lshrrev_b32_e32 v37, 14, v12                             // 000000F7FF3C: 324A188E
	v_and_b32_e32 v36, 0x3fc, v36                              // 000000F7FF40: 364848FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000F7FF48: BF89FC47
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 000000F7FF4C: CC1A4009 1C266926
	v_cndmask_b32_e64 v38, v6, v7, s0                          // 000000F7FF54: D5010026 00020F06
	v_and_b32_e32 v37, 0x3fc, v37                              // 000000F7FF5C: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000F7FF64: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F7FF68: BF870133
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 000000F7FF6C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v7, v8, s0                          // 000000F7FF74: D5010027 00021107
	s_waitcnt lgkmcnt(2)                                       // 000000F7FF7C: BF89FC27
	v_dot2_f32_bf16 v9, v40, v10, v9                           // 000000F7FF80: CC1A4009 1C261528
	v_mov_b32_e32 v40, v8                                      // 000000F7FF88: 7E500308
	v_lshlrev_b32_e32 v20, 2, v33                              // 000000F7FF8C: 30284282
	v_and_b32_e32 v33, 0xff, v12                               // 000000F7FF90: 364218FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 000000F7FF98: 32181896
	ds_load_b32 v20, v20 offset:32                             // 000000F7FF9C: D8D80020 14000014
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000F7FFA4: 30424282
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 000000F7FFA8: BF890407
	v_dot2_f32_bf16 v9, v41, v20, v9                           // 000000F7FFAC: CC1A4009 1C262929
	v_cndmask_b32_e64 v20, v29, v1, s0                         // 000000F7FFB4: D5010014 0002031D
	v_mov_b32_e32 v29, v32                                     // 000000F7FFBC: 7E3A0320
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F7FFC0: BF870123
	v_dot2_f32_bf16 v9, v42, v34, v9                           // 000000F7FFC4: CC1A4009 1C26452A
	v_cndmask_b32_e64 v34, v2, v3, s0                          // 000000F7FFCC: D5010022 00020702
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 000000F7FFD4: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v3, v4, s0                          // 000000F7FFDC: D5010023 00020903
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000F7FFE4: 361616FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 000000F7FFEC: 361818FF 000003FC
	ds_load_b32 v10, v11 offset:32                             // 000000F7FFF4: D8D80020 0A00000B
	ds_load_b32 v11, v33 offset:32                             // 000000F7FFFC: D8D80020 0B000021
	ds_load_b32 v33, v36 offset:32                             // 000000F80004: D8D80020 21000024
	ds_load_b32 v49, v37 offset:32                             // 000000F8000C: D8D80020 31000025
	ds_load_b32 v50, v12 offset:32                             // 000000F80014: D8D80020 3200000C
	v_cndmask_b32_e64 v37, v5, v6, s0                          // 000000F8001C: D5010025 00020D05
	v_cndmask_b32_e64 v36, v4, v5, s0                          // 000000F80024: D5010024 00020B04
	v_mov_b32_e32 v12, v16                                     // 000000F8002C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 000000F80030: BF89FC47
	v_dot2_f32_bf16 v9, v44, v10, v9                           // 000000F80034: CC1A4009 1C26152C
	v_mov_b32_e32 v10, v14                                     // 000000F8003C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F80040: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F80044: BF870132
	v_dot2_f32_bf16 v9, v45, v11, v9                           // 000000F80048: CC1A4009 1C26172D
	v_mov_b32_e32 v11, v15                                     // 000000F80050: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 000000F80054: BF89FC27
	v_dot2_f32_bf16 v5, v46, v33, v9                           // 000000F80058: CC1A4005 1C26432E
	v_cndmask_b32_e64 v33, v1, v2, s0                          // 000000F80060: D5010021 00020501
	v_add_nc_u32_e32 v31, 64, v31                              // 000000F80068: 4A3E3EC0
	v_mov_b32_e32 v9, v13                                      // 000000F8006C: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000F80070: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 000000F80078: BF89FC17
	v_dot2_f32_bf16 v1, v47, v49, v5                           // 000000F8007C: CC1A4001 1C16632F
	s_waitcnt lgkmcnt(0)                                       // 000000F80084: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F80088: BF870091
	v_dot2_f32_bf16 v1, v48, v50, v1                           // 000000F8008C: CC1A4001 1C066530
	v_dual_fmac_f32 v26, v20, v1 :: v_dual_mov_b32 v1, v33     // 000000F80094: C8100314 1A000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 000000F8009C: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 000000F800A4: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 000000F800AC: CA100126 06060127
	v_mov_b32_e32 v8, v40                                      // 000000F800B4: 7E100328
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000F800B8: 917E057E
	s_cbranch_execz 35                                         // 000000F800BC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x84c>
	s_waitcnt vmcnt(0)                                         // 000000F800C0: BF8903F7
	v_dual_mov_b32 v14, v10 :: v_dual_add_nc_u32 v23, 32, v23  // 000000F800C4: CA20010A 0E162EA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, v12          // 000000F800CC: CA100109 0D10010C
	v_mov_b32_e32 v15, v11                                     // 000000F800D4: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F800D8: BF870003
	.long 0xd4460001                                           // 000000F800DC: D4460001
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 000000F800E0: 02023117
	s_mov_b32 s10, exec_lo                                     // 000000F800E4: BE8A007E
	.long 0xd4c1007e                                           // 000000F800E8: D4C1007E
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 000000F800EC: 02023117
	s_cbranch_execz 65335                                      // 000000F800F0: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v14, 31, v30                             // 000000F800F4: 341C3C9F
	.long 0xd7006a0d                                           // 000000F800F8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 000000F800FC: 02023D12
	v_mov_b32_e32 v32, v29                                     // 000000F80100: 7E40031D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F80104: BF870003
	v_add_co_ci_u32_e64 v14, null, v28, v14, vcc_lo            // 000000F80108: D5207C0E 01AA1D1C
	v_cmp_ne_u32_e32 vcc_lo, 1, v27                            // 000000F80110: 7C9A3681
	global_load_b128 v[13:16], v[13:14], off                   // 000000F80114: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 000000F8011C: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v20, 31, v31                             // 000000F80120: 34283E9F
	.long 0xd7006a20                                           // 000000F80124: D7006A20
	v_cndmask_b32_e32 v1, v17, v31, vcc_lo                     // 000000F80128: 02023F11
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8012C: BF870001
	v_add_co_ci_u32_e64 v33, null, v25, v20, vcc_lo            // 000000F80130: D5207C21 01AA2919
	global_load_d16_b16 v20, v[32:33], off                     // 000000F80138: DC820000 147C0020
	s_waitcnt vmcnt(0)                                         // 000000F80140: BF8903F7
	v_cvt_f32_f16_e32 v32, v20                                 // 000000F80144: 7E401714
	s_branch 65313                                             // 000000F80148: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000F8014C: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F80150: BF8700B9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000F80154: 8C7E047E
	.long 0xd71f0001                                           // 000000F80158: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F8015C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000F80160: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000F80164: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 000000F80168: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 000000F8016C: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F80170: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000F80174: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000F80178: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000F8017C: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000F80180: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000F80184: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F80188: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000F8018C: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000F80190: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000F80194: 02080901
	ds_bpermute_b32 v2, v2, v26                                // 000000F80198: DACC0000 02001A02
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000F801A0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000F801A4: BF89FC07
	v_add_f32_e32 v2, v26, v2                                  // 000000F801A8: 0604051A
	ds_bpermute_b32 v3, v3, v2                                 // 000000F801AC: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000F801B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000F801B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000F801BC: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000F801C4: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F801C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000F801CC: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000F801D0: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000F801D4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000F801D8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000F801DC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000F801E0: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000F801E8: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F801EC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000F801F0: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000F801F4: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000F801F8: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000F80200: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000F80204: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v22                                   // 000000F8020C: 7D942C80
	s_cbranch_execz 5                                          // 000000F80210: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x928>
	v_lshlrev_b32_e32 v3, 2, v21                               // 000000F80214: 30062A82
	s_waitcnt lgkmcnt(0)                                       // 000000F80218: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000F8021C: 06020501
	ds_store_b32 v3, v1                                        // 000000F80220: D8340000 00000103
	s_or_b32 exec_lo, exec_lo, s0                              // 000000F80228: 8C7E007E
	.long 0xd4510000                                           // 000000F8022C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000F80230: 02001802
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000F80234: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000F80238: BF890007
	s_barrier                                                  // 000000F8023C: BFBD0000
	buffer_gl0_inv                                             // 000000F80240: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000F80248: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F8024C: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000F80250: BE812000
	s_cbranch_execz 54                                         // 000000F80254: BFA50036 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xa30>
	v_mov_b32_e32 v8, 0                                        // 000000F80258: 7E100280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000F8025C: 84808202
	ds_load_b128 v[0:3], v8                                    // 000000F80260: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 000000F80268: DBFC0010 04000008
	s_add_u32 s0, s8, s0                                       // 000000F80270: 80000008
	s_addc_u32 s1, s9, s1                                      // 000000F80274: 82010109
	s_waitcnt lgkmcnt(1)                                       // 000000F80278: BF89FC17
	v_add_f32_e32 v0, 0, v0                                    // 000000F8027C: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F80280: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 000000F80284: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 000000F80288: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F8028C: BF8700A1
	v_add_f32_e32 v0, v0, v3                                   // 000000F80290: 06000700
	s_waitcnt lgkmcnt(0)                                       // 000000F80294: BF89FC07
	v_add_f32_e32 v0, v0, v4                                   // 000000F80298: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8029C: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 000000F802A0: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 000000F802A4: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F802A8: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 000000F802AC: 06000F00
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000F802B0: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000F802B8: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000F802BC: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000F802C0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F802C4: BF870121
	v_div_scale_f32 v1, null, v0, v0, 1.0                      // 000000F802C8: D6FC7C01 03CA0100
	v_div_scale_f32 v4, vcc_lo, 1.0, v0, 1.0                   // 000000F802D0: D6FC6A04 03CA00F2
	v_rcp_f32_e32 v2, v1                                       // 000000F802D8: 7E045501
	v_xor_b32_e32 v1, 0x80000000, v1                           // 000000F802DC: 3A0202FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000F802E4: BF870085
	v_fma_f32 v3, v1, v2, 1.0                                  // 000000F802E8: D6130003 03CA0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F802F0: BF870091
	v_fmac_f32_e32 v2, v3, v2                                  // 000000F802F4: 56040503
	v_mul_f32_e32 v3, v4, v2                                   // 000000F802F8: 10060504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F802FC: BF870091
	v_fma_f32 v5, v1, v3, v4                                   // 000000F80300: D6130005 04120701
	v_fmac_f32_e32 v3, v5, v2                                  // 000000F80308: 56060505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F8030C: BF870091
	v_fmac_f32_e32 v4, v1, v3                                  // 000000F80310: 56080701
	v_div_fmas_f32 v1, v4, v2, v3                              // 000000F80314: D6370001 040E0504
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F8031C: BF870001
	v_div_fixup_f32 v0, v1, v0, 1.0                            // 000000F80320: D6270000 03CA0101
	global_store_b32 v8, v0, s[0:1]                            // 000000F80328: DC6A0000 00000008
	s_endpgm                                                   // 000000F80330: BFB00000
		...

