000000000054dd00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000054DD00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000054DD08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000054DD0C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 00000054DD10: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 00000054DD14: 362E009F
	.long 0x7f0a3880                                           // 00000054DD18: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 00000054DD1C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 00000054DD20: BF89FC07
	.long 0xd4510000                                           // 00000054DD24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054DD28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 00000054DD2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 00000054DD30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 00000054DD34: 98158002
	s_add_u32 s0, s4, s16                                      // 00000054DD38: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000054DD3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 00000054DD40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 00000054DD44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 00000054DD48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054DD4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 00000054DD50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000054DD54: 30020282
	s_add_u32 s16, s10, s16                                    // 00000054DD58: 8010100A
	s_clause 0x1                                               // 00000054DD5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000054DD60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000054DD68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 00000054DD70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 00000054DD74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000054DD78: 85908510
	v_mov_b32_e32 v1, s0                                       // 00000054DD7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 00000054DD80: 81118710
	s_mul_i32 s1, s19, s21                                     // 00000054DD84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 00000054DD88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000054DD8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 00000054DD90: 85009D16
	v_mad_u64_u32 v[17:18], null, s18, s21, v[1:2]             // 00000054DD94: D6FE7C11 04042A12
	s_add_i32 s17, s17, s0                                     // 00000054DD9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 00000054DDA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 00000054DDA4: B3900801
	.long 0xd72c0001                                           // 00000054DDA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v22, vcc_lo                      // 00000054DDAC: 02022C00
	s_mul_i32 s17, s18, s20                                    // 00000054DDB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000054DDB4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 00000054DDB8: 4A0E0200
	v_add_nc_u32_e32 v24, v1, v23                              // 00000054DDBC: 4A302F01
	s_cselect_b32 s0, -1, 0                                    // 00000054DDC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 00000054DDC4: B2900800
	v_min_i32_e32 v25, s16, v7                                 // 00000054DDC8: 22320E10
	s_cselect_b32 s16, -1, 0                                   // 00000054DDCC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000054DDD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000054DDD4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 00000054DDD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 00000054DDDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 00000054DDE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 00000054DDE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000054DDF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v18                               // 00000054DDFC: 4A062401
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054DE00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 00000054DE04: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 00000054DE10: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054DE14: 02023318
	.long 0x7e0a3982                                           // 00000054DE18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054DE1C: BF870114
	v_add_nc_u32_e32 v26, s17, v3                              // 00000054DE20: 4A340611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 00000054DE24: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 00000054DE30: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 00000054DE38: BF89FC07
	s_barrier                                                  // 00000054DE3C: BFBD0000
	buffer_gl0_inv                                             // 00000054DE40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000054DE48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 00000054DE4C: CA100080 02000080
	s_and_saveexec_b32 s17, s1                                 // 00000054DE54: BE912001
	s_cbranch_execz 11                                         // 00000054DE58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 00000054DE5C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DE60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 00000054DE64: 3408029F
	.long 0xd7006a03                                           // 00000054DE68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 00000054DE6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 00000054DE70: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 00000054DE78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 00000054DE80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 00000054DE84: 7E021701
	s_or_b32 exec_lo, exec_lo, s17                             // 00000054DE88: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v24                               // 00000054DE8C: 4A0630A0
	s_mov_b32 s1, exec_lo                                      // 00000054DE90: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054DE94: BF870001
	.long 0xd4c1007e                                           // 00000054DE98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 00000054DE9C: 02023303
	s_cbranch_execz 11                                         // 00000054DEA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 00000054DEA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DEA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000054DEAC: 3406049F
	.long 0xd7006a02                                           // 00000054DEB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 00000054DEB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 00000054DEB8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 00000054DEC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000054DEC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 00000054DECC: 7E041702
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054DED0: 8C7E017E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 00000054DED4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 00000054DEDC: 7E060280
	s_mov_b32 s1, exec_lo                                      // 00000054DEE0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054DEE4: BF870002
	.long 0xd4c1007e                                           // 00000054DEE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000054DEEC: 02023305
	s_cbranch_execz 11                                         // 00000054DEF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 00000054DEF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DEF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 00000054DEFC: 340C069F
	.long 0xd7006a05                                           // 00000054DF00: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 00000054DF04: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 00000054DF08: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 00000054DF10: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 00000054DF18: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 00000054DF1C: 7E061703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054DF20: 8C7E017E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 00000054DF24: 4A0A30FF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000054DF2C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054DF30: BF870001
	.long 0xd4c1007e                                           // 00000054DF34: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 00000054DF38: 02023305
	s_cbranch_execz 11                                         // 00000054DF3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 00000054DF40: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DF44: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 00000054DF48: 340A089F
	.long 0xd7006a04                                           // 00000054DF4C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 00000054DF50: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 00000054DF54: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 00000054DF5C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 00000054DF64: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 00000054DF68: 7E081704
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054DF6C: 8C7E017E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 00000054DF70: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 00000054DF7C: 7E0A0280
	s_mov_b32 s1, exec_lo                                      // 00000054DF80: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054DF84: BF870002
	.long 0xd4c1007e                                           // 00000054DF88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000054DF8C: 02023307
	s_cbranch_execz 11                                         // 00000054DF90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 00000054DF94: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DF98: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 00000054DF9C: 34100A9F
	.long 0xd7006a07                                           // 00000054DFA0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 00000054DFA4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 00000054DFA8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 00000054DFB0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 00000054DFB8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 00000054DFBC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054DFC0: 8C7E017E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 00000054DFC4: 4A0E30FF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000054DFCC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054DFD0: BF870001
	.long 0xd4c1007e                                           // 00000054DFD4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 00000054DFD8: 02023307
	s_cbranch_execz 11                                         // 00000054DFDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 00000054DFE0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054DFE4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000054DFE8: 340E0C9F
	.long 0xd7006a06                                           // 00000054DFEC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 00000054DFF0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 00000054DFF4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 00000054DFFC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000054E004: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000054E008: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054E00C: 8C7E017E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 00000054E010: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 00000054E01C: 7E0E0280
	s_mov_b32 s1, exec_lo                                      // 00000054E020: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054E024: BF870002
	.long 0xd4c1007e                                           // 00000054E028: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 00000054E02C: 02023309
	s_cbranch_execz 11                                         // 00000054E030: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 00000054E034: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054E038: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 00000054E03C: 34140E9F
	.long 0xd7006a09                                           // 00000054E040: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000054E044: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 00000054E048: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 00000054E050: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 00000054E058: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 00000054E05C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054E060: 8C7E017E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 00000054E064: 4A1230FF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000054E06C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E070: BF870001
	.long 0xd4c1007e                                           // 00000054E074: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 00000054E078: 02023309
	s_cbranch_execz 11                                         // 00000054E07C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 00000054E080: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054E084: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 00000054E088: 3412109F
	.long 0xd7006a08                                           // 00000054E08C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 00000054E090: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 00000054E094: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 00000054E09C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 00000054E0A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 00000054E0A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s1                              // 00000054E0AC: 8C7E017E
	s_branch 9                                                 // 00000054E0B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 00000054E0B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E0B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 00000054E0BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 00000054E0C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 00000054E0C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 00000054E0C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 00000054E0CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000054E0D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 00000054E0D4: 7E100301
	s_add_u32 s4, s4, s14                                      // 00000054E0D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000054E0DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000054E0E0: 85019F0B
	v_dual_mov_b32 v9, s21 :: v_dual_mov_b32 v10, 0            // 00000054E0E4: CA100015 090A0080
	s_add_u32 s14, s10, s1                                     // 00000054E0EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000054E0F0: 820F800B
	.long 0xd4410001                                           // 00000054E0F4: D4410001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054E0F8: 02023318
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000054E0FC: 868E810E
	v_mov_b32_e32 v27, 0                                       // 00000054E100: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[4:5]              // 00000054E104: D6FE7C12 00101D09
	.long 0xd72c000b                                           // 00000054E10C: D72C000B
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 00000054E110: 02001E15
	.long 0xd72c000c                                           // 00000054E114: D72C000C
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 00000054E118: 02001C14
	v_mov_b32_e32 v9, 0                                        // 00000054E11C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s16                           // 00000054E120: D501001C 00410280
	v_mov_b32_e32 v31, 0                                       // 00000054E128: 7E3E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000054E12C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 00000054E130: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 00000054E138: CA100080 0B0C0080
	s_and_saveexec_b32 s4, s1                                  // 00000054E140: BE842001
	s_cbranch_execz 22                                         // 00000054E144: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 00000054E148: 30123084
	v_mov_b32_e32 v31, 0                                       // 00000054E14C: 7E3E0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054E150: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000054E154: 3414129F
	.long 0xd7006a09                                           // 00000054E158: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 00000054E15C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 00000054E160: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000054E168: 916A107E
	global_load_b128 v[9:12], v[9:10], off                     // 00000054E16C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 00000054E174: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 00000054E178: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054E17C: BF870091
	.long 0xd7006a0d                                           // 00000054E180: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 00000054E184: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 00000054E188: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 00000054E190: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 00000054E198: BF8903F7
	v_cvt_f32_f16_e32 v31, v13                                 // 00000054E19C: 7E3E170D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000054E1A0: 8C7E047E
	v_mov_b32_e32 v30, 0                                       // 00000054E1A4: 7E3C0280
	s_and_saveexec_b32 s14, s1                                 // 00000054E1A8: BE8E2001
	s_cbranch_execz 290                                        // 00000054E1AC: BFA50122 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 00000054E1B0: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v31 :: v_dual_lshlrev_b32 v19, 5, v24  // 00000054E1B8: CA22011F 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054E1C0: BF870002
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 00000054E1C4: CA220080 1B201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 00000054E1CC: 30421A81
	s_mov_b32 s15, 0                                           // 00000054E1D0: BE8F0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000054E1D4: 8484810A
	s_branch 243                                               // 00000054E1D8: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x8a8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000054E1DC: 8C7E0A7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000054E1E0: 3428269F
	v_lshrrev_b32_e32 v67, 6, v9                               // 00000054E1E4: 32861286
	v_lshrrev_b32_e32 v68, 14, v9                              // 00000054E1E8: 3288128E
	v_and_b32_e32 v69, 0xff, v10                               // 00000054E1EC: 368A14FF 000000FF
	v_lshrrev_b32_e32 v70, 6, v10                              // 00000054E1F4: 328C1486
	.long 0xd73c0023                                           // 00000054E1F8: D73C0023
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000054E1FC: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 00000054E200: 362812FF 000000FF
	v_and_b32_e32 v67, 0x3fc, v67                              // 00000054E208: 368686FF 000003FC
	v_and_b32_e32 v68, 0x3fc, v68                              // 00000054E210: 368888FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 00000054E218: 32121296
	v_lshrrev_b32_e32 v71, 14, v10                             // 00000054E21C: 328E148E
	.long 0xd7006a3b                                           // 00000054E220: D7006A3B
	v_cndmask_b32_e32 v1, s6, v35, vcc_lo                      // 00000054E224: 02024606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000054E228: BF8701A1
	v_add_co_ci_u32_e64 v60, null, s7, v36, vcc_lo             // 00000054E22C: D5207C3C 01AA4807
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000054E234: 30282882
	.long 0xd7006a3f                                           // 00000054E238: D7006A3F
	v_cndmask_b32_e32 v0, v59, v4, vcc_lo                      // 00000054E23C: 0200093B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E240: BF870001
	v_add_co_ci_u32_e64 v64, null, s5, v60, vcc_lo             // 00000054E244: D5207C40 01AA7805
	ds_load_b32 v20, v20                                       // 00000054E24C: D8D80000 14000014
	ds_load_b32 v67, v67                                       // 00000054E254: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 00000054E25C: D8D80000 44000044
	s_clause 0x7                                               // 00000054E264: BF850007
	global_load_b128 v[35:38], v[59:60], off                   // 00000054E268: DC5E0000 237C003B
	global_load_b128 v[39:42], v[63:64], off                   // 00000054E270: DC5E0000 277C003F
	global_load_b128 v[43:46], v[59:60], off offset:16         // 00000054E278: DC5E0010 2B7C003B
	global_load_b128 v[47:50], v[63:64], off offset:16         // 00000054E280: DC5E0010 2F7C003F
	global_load_b128 v[51:54], v[59:60], off offset:32         // 00000054E288: DC5E0020 337C003B
	global_load_b128 v[55:58], v[63:64], off offset:32         // 00000054E290: DC5E0020 377C003F
	global_load_b128 v[59:62], v[59:60], off offset:48         // 00000054E298: DC5E0030 3B7C003B
	global_load_b128 v[63:66], v[63:64], off offset:48         // 00000054E2A0: DC5E0030 3F7C003F
	v_lshrrev_b32_e32 v10, 22, v10                             // 00000054E2A8: 32141496
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000054E2AC: 361212FF 000003FC
	v_lshlrev_b32_e32 v69, 2, v69                              // 00000054E2B4: 308A8A82
	v_and_b32_e32 v70, 0x3fc, v70                              // 00000054E2B8: 368C8CFF 000003FC
	v_and_b32_e32 v71, 0x3fc, v71                              // 00000054E2C0: 368E8EFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 00000054E2C8: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 00000054E2D0: D8D80000 09000009
	ds_load_b32 v69, v69                                       // 00000054E2D8: D8D80000 45000045
	ds_load_b32 v70, v70                                       // 00000054E2E0: D8D80000 46000046
	ds_load_b32 v71, v71                                       // 00000054E2E8: D8D80000 47000047
	ds_load_b32 v10, v10                                       // 00000054E2F0: D8D80000 0A00000A
	v_add_nc_u32_e32 v32, 0x200, v32                           // 00000054E2F8: 4A4040FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 00000054E300: 8B01017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054E304: BF870009
	s_or_b32 s15, s1, s15                                      // 00000054E308: 8C0F0F01
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 00000054E30C: BF891C77
	v_dot2_f32_bf16 v35, v35, v20, 0                           // 00000054E310: CC1A4023 1A022923
	s_waitcnt vmcnt(6)                                         // 00000054E318: BF891BF7
	v_dot2_f32_bf16 v20, v39, v20, 0                           // 00000054E31C: CC1A4014 1A022927
	v_and_b32_e32 v39, 0xff, v11                               // 00000054E324: 364E16FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 00000054E32C: BF89FC67
	v_dot2_f32_bf16 v35, v36, v67, v35                         // 00000054E330: CC1A4023 1C8E8724
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054E338: BF870003
	v_dot2_f32_bf16 v20, v40, v67, v20                         // 00000054E33C: CC1A4014 1C528728
	v_lshrrev_b32_e32 v36, 6, v11                              // 00000054E344: 32481686
	v_lshrrev_b32_e32 v40, 14, v11                             // 00000054E348: 3250168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 00000054E34C: 32161696
	s_waitcnt lgkmcnt(5)                                       // 00000054E350: BF89FC57
	v_dot2_f32_bf16 v35, v37, v68, v35                         // 00000054E354: CC1A4023 1C8E8925
	v_dot2_f32_bf16 v20, v41, v68, v20                         // 00000054E35C: CC1A4014 1C528929
	v_and_b32_e32 v36, 0x3fc, v36                              // 00000054E364: 364848FF 000003FC
	v_lshrrev_b32_e32 v41, 6, v12                              // 00000054E36C: 32521886
	v_and_b32_e32 v37, 0xff, v12                               // 00000054E370: 364A18FF 000000FF
	s_waitcnt lgkmcnt(4)                                       // 00000054E378: BF89FC47
	v_dot2_f32_bf16 v35, v38, v9, v35                          // 00000054E37C: CC1A4023 1C8E1326
	v_dot2_f32_bf16 v9, v42, v9, v20                           // 00000054E384: CC1A4009 1C52132A
	v_lshlrev_b32_e32 v20, 2, v39                              // 00000054E38C: 30284E82
	v_and_b32_e32 v38, 0x3fc, v40                              // 00000054E390: 364C50FF 000003FC
	v_lshrrev_b32_e32 v67, 14, v12                             // 00000054E398: 3286188E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 00000054E39C: BF891437
	v_dot2_f32_bf16 v35, v43, v69, v35                         // 00000054E3A0: CC1A4023 1C8E8B2B
	s_waitcnt vmcnt(4)                                         // 00000054E3A8: BF8913F7
	v_dot2_f32_bf16 v9, v47, v69, v9                           // 00000054E3AC: CC1A4009 1C268B2F
	ds_load_b32 v20, v20                                       // 00000054E3B4: D8D80000 14000014
	ds_load_b32 v36, v36                                       // 00000054E3BC: D8D80000 24000024
	ds_load_b32 v38, v38                                       // 00000054E3C4: D8D80000 26000026
	s_waitcnt lgkmcnt(5)                                       // 00000054E3CC: BF89FC57
	v_dot2_f32_bf16 v35, v44, v70, v35                         // 00000054E3D0: CC1A4023 1C8E8D2C
	v_dot2_f32_bf16 v9, v48, v70, v9                           // 00000054E3D8: CC1A4009 1C268D30
	v_lshrrev_b32_e32 v12, 22, v12                             // 00000054E3E0: 32181896
	v_and_b32_e32 v39, 0x3fc, v41                              // 00000054E3E4: 364E52FF 000003FC
	v_cndmask_b32_e64 v41, v7, v8, s0                          // 00000054E3EC: D5010029 00021107
	s_waitcnt lgkmcnt(4)                                       // 00000054E3F4: BF89FC47
	v_dot2_f32_bf16 v35, v45, v71, v35                         // 00000054E3F8: CC1A4023 1C8E8F2D
	v_dot2_f32_bf16 v9, v49, v71, v9                           // 00000054E400: CC1A4009 1C268F31
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000054E408: 361616FF 000003FC
	v_lshlrev_b32_e32 v37, 2, v37                              // 00000054E410: 304A4A82
	v_and_b32_e32 v40, 0x3fc, v67                              // 00000054E414: 365086FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 00000054E41C: BF89FC37
	v_dot2_f32_bf16 v35, v46, v10, v35                         // 00000054E420: CC1A4023 1C8E152E
	v_dot2_f32_bf16 v9, v50, v10, v9                           // 00000054E428: CC1A4009 1C261532
	v_and_b32_e32 v12, 0x3fc, v12                              // 00000054E430: 361818FF 000003FC
	ds_load_b32 v10, v11                                       // 00000054E438: D8D80000 0A00000B
	ds_load_b32 v11, v37                                       // 00000054E440: D8D80000 0B000025
	ds_load_b32 v42, v39                                       // 00000054E448: D8D80000 2A000027
	ds_load_b32 v43, v40                                       // 00000054E450: D8D80000 2B000028
	ds_load_b32 v44, v12                                       // 00000054E458: D8D80000 2C00000C
	v_cndmask_b32_e64 v40, v6, v7, s0                          // 00000054E460: D5010028 00020F06
	v_cndmask_b32_e64 v39, v5, v6, s0                          // 00000054E468: D5010027 00020D05
	v_cndmask_b32_e64 v37, v3, v4, s0                          // 00000054E470: D5010025 00020903
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 00000054E478: BF890C77
	v_dot2_f32_bf16 v12, v51, v20, v35                         // 00000054E47C: CC1A400C 1C8E2933
	s_waitcnt vmcnt(2)                                         // 00000054E484: BF890BF7
	v_dot2_f32_bf16 v9, v55, v20, v9                           // 00000054E488: CC1A4009 1C262937
	v_cndmask_b32_e64 v20, v31, v1, s0                         // 00000054E490: D5010014 0002031F
	v_cndmask_b32_e64 v35, v1, v2, s0                          // 00000054E498: D5010023 00020501
	v_mov_b32_e32 v31, v34                                     // 00000054E4A0: 7E3E0322
	s_waitcnt lgkmcnt(6)                                       // 00000054E4A4: BF89FC67
	v_dot2_f32_bf16 v12, v52, v36, v12                         // 00000054E4A8: CC1A400C 1C324934
	v_dot2_f32_bf16 v9, v56, v36, v9                           // 00000054E4B0: CC1A4009 1C264938
	v_cndmask_b32_e64 v36, v2, v3, s0                          // 00000054E4B8: D5010024 00020702
	s_waitcnt lgkmcnt(5)                                       // 00000054E4C0: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054E4C4: BF870193
	v_dot2_f32_bf16 v12, v53, v38, v12                         // 00000054E4C8: CC1A400C 1C324D35
	v_dot2_f32_bf16 v9, v57, v38, v9                           // 00000054E4D0: CC1A4009 1C264D39
	v_cndmask_b32_e64 v38, v4, v5, s0                          // 00000054E4D8: D5010026 00020B04
	s_waitcnt lgkmcnt(4)                                       // 00000054E4E0: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054E4E4: BF870193
	v_dot2_f32_bf16 v12, v54, v10, v12                         // 00000054E4E8: CC1A400C 1C321536
	v_dot2_f32_bf16 v9, v58, v10, v9                           // 00000054E4F0: CC1A4009 1C26153A
	v_mov_b32_e32 v10, v14                                     // 00000054E4F8: 7E14030E
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 00000054E4FC: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054E500: BF870003
	v_dot2_f32_bf16 v5, v59, v11, v12                          // 00000054E504: CC1A4005 1C32173B
	s_waitcnt vmcnt(0)                                         // 00000054E50C: BF8903F7
	v_dot2_f32_bf16 v6, v63, v11, v9                           // 00000054E510: CC1A4006 1C26173F
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v11, v15         // 00000054E518: CA100110 0C0A010F
	v_mov_b32_e32 v9, v13                                      // 00000054E520: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 00000054E524: BF89FC27
	v_dot2_f32_bf16 v1, v60, v42, v5                           // 00000054E528: CC1A4001 1C16553C
	v_dot2_f32_bf16 v2, v64, v42, v6                           // 00000054E530: CC1A4002 1C1A5540
	v_dual_mov_b32 v42, v8 :: v_dual_add_nc_u32 v33, 64, v33   // 00000054E538: CA200108 2A2042C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 00000054E540: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 00000054E548: BF89FC17
	v_dot2_f32_bf16 v1, v61, v43, v1                           // 00000054E54C: CC1A4001 1C06573D
	v_dot2_f32_bf16 v2, v65, v43, v2                           // 00000054E554: CC1A4002 1C0A5741
	s_waitcnt lgkmcnt(0)                                       // 00000054E55C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054E560: BF870112
	v_dot2_f32_bf16 v1, v62, v44, v1                           // 00000054E564: CC1A4001 1C06593E
	v_dot2_f32_bf16 v2, v66, v44, v2                           // 00000054E56C: CC1A4002 1C0A5942
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054E574: BF870112
	v_fmac_f32_e32 v30, v20, v1                                // 00000054E578: 563C0314
	v_fmac_f32_e32 v27, v20, v2                                // 00000054E57C: 56360514
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 00000054E580: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 00000054E588: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 00000054E590: CA100127 05060128
	v_dual_mov_b32 v7, v41 :: v_dual_mov_b32 v8, v42           // 00000054E598: CA100129 0708012A
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000054E5A0: 917E0F7E
	s_cbranch_execz 35                                         // 00000054E5A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 00000054E5A8: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 00000054E5AC: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 00000054E5B4: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 00000054E5BC: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054E5C0: BF870003
	.long 0xd4460001                                           // 00000054E5C4: D4460001
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054E5C8: 02023318
	s_mov_b32 s10, exec_lo                                     // 00000054E5CC: BE8A007E
	.long 0xd4c1007e                                           // 00000054E5D0: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000054E5D4: 02023318
	s_cbranch_execz 65280                                      // 00000054E5D8: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v14, 31, v32                             // 00000054E5DC: 341C409F
	.long 0xd7006a0d                                           // 00000054E5E0: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 00000054E5E4: 02024112
	v_mov_b32_e32 v34, v31                                     // 00000054E5E8: 7E44031F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000054E5EC: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 00000054E5F0: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 00000054E5F8: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 00000054E5FC: DC5E0000 0D7C000D
	s_cbranch_vccnz 65269                                      // 00000054E604: BFA4FEF5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	v_ashrrev_i32_e32 v20, 31, v33                             // 00000054E608: 3428429F
	.long 0xd7006a22                                           // 00000054E60C: D7006A22
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 00000054E610: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E614: BF870001
	v_add_co_ci_u32_e64 v35, null, v26, v20, vcc_lo            // 00000054E618: D5207C23 01AA291A
	global_load_d16_b16 v20, v[34:35], off                     // 00000054E620: DC820000 147C0022
	s_waitcnt vmcnt(0)                                         // 00000054E628: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 00000054E62C: 7E441714
	s_branch 65258                                             // 00000054E630: BFA0FEEA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4dc>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000054E634: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054E638: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000054E63C: 8C7E0E7E
	.long 0xd71f0001                                           // 00000054E640: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000054E644: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000054E648: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000054E64C: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000054E650: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 00000054E654: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000054E658: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000054E65C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000054E660: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000054E664: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000054E668: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000054E66C: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000054E670: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054E674: 7C980CA0
	ds_bpermute_b32 v3, v2, v30                                // 00000054E678: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 00000054E680: BF89FC07
	v_dual_add_f32 v3, v30, v3 :: v_dual_lshlrev_b32 v4, 2, v4 // 00000054E684: C922071E 03040882
	ds_bpermute_b32 v5, v4, v3                                 // 00000054E68C: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000054E694: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000054E698: 06060B03
	ds_bpermute_b32 v2, v2, v27                                // 00000054E69C: DACC0000 02001B02
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054E6A4: 020C0D01
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E6A8: BF870001
	v_lshlrev_b32_e32 v6, 2, v6                                // 00000054E6AC: 300C0C82
	s_waitcnt lgkmcnt(0)                                       // 00000054E6B0: BF89FC07
	v_add_f32_e32 v2, v27, v2                                  // 00000054E6B4: 0604051B
	ds_bpermute_b32 v4, v4, v2                                 // 00000054E6B8: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000054E6C0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000054E6C4: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 00000054E6C8: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000054E6D0: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 00000054E6D8: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054E6DC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054E6E0: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000054E6E4: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 00000054E6E8: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 00000054E6EC: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 00000054E6F4: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000054E6F8: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 00000054E6FC: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000054E704: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 00000054E70C: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000054E710: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000054E714: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000054E718: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 00000054E71C: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 00000054E720: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 00000054E728: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000054E72C: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 00000054E730: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 00000054E738: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v23                                   // 00000054E740: 7D942E80
	s_cbranch_execz 6                                          // 00000054E744: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xa60>
	s_waitcnt lgkmcnt(0)                                       // 00000054E748: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v22 // 00000054E74C: C9220902 02042C83
	v_add_f32_e32 v1, v1, v3                                   // 00000054E754: 06020701
	ds_store_b64 v5, v[1:2] offset:1024                        // 00000054E758: D9340400 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 00000054E760: 8C7E007E
	.long 0xd4510000                                           // 00000054E764: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000054E768: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 00000054E76C: 7C980082
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000054E770: BF890007
	s_barrier                                                  // 00000054E774: BFBD0000
	buffer_gl0_inv                                             // 00000054E778: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000054E780: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000054E784: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000054E788: BE812000
	s_cbranch_execz 51                                         // 00000054E78C: BFA50033 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xb5c>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 00000054E790: 4A0E2AFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000054E798: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 00000054E79C: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 00000054E7A4: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 00000054E7AC: D8DC0A08 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000054E7B4: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000054E7B8: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000054E7BC: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000054E7C0: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000054E7C4: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 00000054E7C8: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000054E7CC: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 00000054E7D0: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000054E7D4: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 00000054E7DC: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000054E7E0: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000054E7E4: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 00000054E7E8: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:12 offset1:14         // 00000054E7EC: D8DC0E0C 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000054E7F4: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 00000054E7FC: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 00000054E800: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000054E804: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000054E808: BF870113
	.long 0xd73c0000                                           // 00000054E80C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000054E810: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000054E814: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000054E81C: BF870092
	.long 0xd7006a00                                           // 00000054E820: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000054E824: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000054E828: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000054E830: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000054E834: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000054E840: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000054E844: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000054E848: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000054E84C: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000054E854: DC960000 007C0200
	s_endpgm                                                   // 00000054E85C: BFB00000
		...

