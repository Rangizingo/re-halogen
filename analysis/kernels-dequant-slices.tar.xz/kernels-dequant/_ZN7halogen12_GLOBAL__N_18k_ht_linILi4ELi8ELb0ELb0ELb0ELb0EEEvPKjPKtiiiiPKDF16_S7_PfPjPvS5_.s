0000000000497900 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000497900: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000497904: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000049790C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000497914: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000049791C: F4000840 F8000054
	v_lshrrev_b32_e32 v35, 5, v0                               // 000000497924: 32460085
	v_and_b32_e32 v36, 31, v0                                  // 000000497928: 3648009F
	s_mov_b32 s10, s3                                          // 00000049792C: BE8A0003
	s_waitcnt lgkmcnt(0)                                       // 000000497930: BF89FC07
	s_ashr_i32 s11, s17, 31                                    // 000000497934: 860B9F11
	s_mul_i32 s34, s19, s3                                     // 000000497938: 96220313
	s_lshr_b32 s0, s11, 25                                     // 00000049793C: 8500990B
	s_add_i32 s1, s34, s19                                     // 000000497940: 81011322
	s_add_i32 s0, s17, s0                                      // 000000497944: 81000011
	s_mov_b32 s19, exec_lo                                     // 000000497948: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 00000049794C: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000497950: BF870499
	s_min_i32 s0, s0, s1                                       // 000000497954: 89000100
	s_sub_i32 s1, s0, s34                                      // 000000497958: 81812200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000049795C: BF870499
	s_lshl_b32 s9, s1, 3                                       // 000000497960: 84098301
	.long 0xd4c4007e                                           // 000000497964: D4C4007E
	v_cndmask_b32_e32 v1, s9, v35, vcc_lo                      // 000000497968: 02024609
	s_cbranch_execz 504                                        // 00000049796C: BFA501F8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x850>
	s_add_i32 s35, s16, -1                                     // 000000497970: 8123C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000497974: BF11801E
	v_and_b32_e32 v2, 1, v0                                    // 000000497978: 36040081
	s_cselect_b32 s36, -1, 0                                   // 00000049797C: 982480C1
	s_abs_i32 s37, s1                                          // 000000497980: BEA51501
	v_lshlrev_b32_e32 v7, 3, v36                               // 000000497984: 300E4883
	s_cvt_f32_u32 s0, s37                                      // 000000497988: BE806525
	v_dual_mov_b32 v8, v35 :: v_dual_lshlrev_b32 v1, 2, v36    // 00000049798C: CA220123 08004882
	v_and_b32_e32 v4, 2, v0                                    // 000000497994: 36080082
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000497998: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 00000049799C: 7E065600
	v_and_b32_e32 v5, 4, v0                                    // 0000004979A0: 360A0084
	v_and_b32_e32 v6, 8, v0                                    // 0000004979A4: 360C0088
	v_add_nc_u32_e32 v9, s34, v35                              // 0000004979A8: 4A124622
	s_ashr_i32 s40, s1, 31                                     // 0000004979AC: 86289F01
	s_lshl_b32 s41, s1, 8                                      // 0000004979B0: 84298801
	s_lshl_b32 s6, s1, 7                                       // 0000004979B4: 84068701
	.long 0xd44a0001                                           // 0000004979B8: D44A0001
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004979BC: 02020480
	v_lshl_or_b32 v2, v35, 8, v7                               // 0000004979C0: D6560002 041D1123
	s_sub_i32 s8, 0, s37                                       // 0000004979C8: 81882580
	v_readfirstlane_b32 s4, v3                                 // 0000004979CC: 7E080503
	s_mul_i32 s43, s40, 0x1400                                 // 0000004979D0: 962BFF28 00001400
	.long 0xd44c0000                                           // 0000004979D8: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 0000004979DC: 02024890
	.long 0xd44a0003                                           // 0000004979E0: D44A0003
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004979E4: 02020880
	.long 0xd44a0005                                           // 0000004979E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000004979EC: 02020C80
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 0000004979F0: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 0000004979F8: D44A0004
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004979FC: 02020A80
	v_lshl_or_b32 v1, v9, 7, v1                                // 000000497A00: D6560001 04050F09
	v_subrev_nc_u32_e32 v9, s43, v2                            // 000000497A08: 4E12042B
	s_cvt_u32_f32 s7, s7                                       // 000000497A0C: BE876707
	s_sub_i32 s42, 0, s6                                       // 000000497A10: 81AA0680
	s_mov_b32 s38, s17                                         // 000000497A14: BEA60011
	s_mov_b32 s39, 0                                           // 000000497A18: BEA70080
	s_mul_i32 s8, s8, s7                                       // 000000497A1C: 96080708
	s_mov_b32 s44, 0x76543210                                  // 000000497A20: BEAC00FF 76543210
	s_mul_hi_u32 s6, s7, s8                                    // 000000497A28: 96860807
	s_mov_b32 s45, 0x3db504f3                                  // 000000497A2C: BEAD00FF 3DB504F3
	s_add_i32 s43, s7, s6                                      // 000000497A34: 812B0607
	s_branch 164                                               // 000000497A38: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3cc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497A3C: BF870091
	.long 0xd7006a02                                           // 000000497A40: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000497A44: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000497A48: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 000000497A50: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000497A54: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000497A5C: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000497A64: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000497A68: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 000000497A70: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000497A78: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000497A7C: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 000000497A80: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000497A84: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000497A88: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000497A8C: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497A90: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000497A94: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000497A9C: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000497AA4: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000497AAC: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000497AB4: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 000000497AB8: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000497ABC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 000000497AC4: D5010007 20060F07
	.long 0xd72c0006                                           // 000000497ACC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 000000497AD0: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 000000497AD8: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000497ADC: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 000000497AE4: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 000000497AEC: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 000000497AF0: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000497AF4: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000497AFC: D5010003 20060703
	.long 0xd72c0007                                           // 000000497B04: D72C0007
	v_cndmask_b32_e32 v1, s41, v10, vcc_lo                     // 000000497B08: 02021429
	v_add_f32_e32 v2, v2, v13                                  // 000000497B0C: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000497B10: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000497B18: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000497B20: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000497B24: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000497B28: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000497B30: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000497B38: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000497B3C: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000497B44: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000497B4C: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000497B54: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000497B5C: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000497B60: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000497B68: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000497B6C: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000497B74: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000497B78: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000497B80: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000497B88: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000497B90: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000497B98: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000497BA0: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000497BA8: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000497BAC: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000497BB0: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000497BB4: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000497BB8: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000497BBC: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000497BC4: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000497BCC: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000497BD0: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000497BD8: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000497BE0: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000497BE4: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000497BEC: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000497BF4: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000497BFC: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s9, v8                            // 000000497C00: 7C861009
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000497C04: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000497C08: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000497C10: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000497C18: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000497C1C: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000497C20: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000497C28: D5010004 20020904
	v_permlanex16_b32 v11, v11, s44, 0xfedcba98                // 000000497C30: D65C000B 03FC590B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000497C3C: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000497C40: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000497C48: D5010003 20020703
	v_permlanex16_b32 v10, v10, s44, 0xfedcba98                // 000000497C50: D65C000A 03FC590A FEDCBA98
	v_permlanex16_b32 v13, v13, s44, 0xfedcba98                // 000000497C5C: D65C000D 03FC590D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000497C68: 060A1705
	v_permlanex16_b32 v12, v12, s44, 0xfedcba98                // 000000497C6C: D65C000C 03FC590C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000497C78: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000497C7C: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000497C88: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000497C8C: BF870214
	v_fma_mixhi_f16 v2, v5, s45, 0                             // 000000497C90: CC220002 02005B05
	v_add_f32_e32 v10, v3, v12                                 // 000000497C98: 06141903
	s_or_b32 s39, vcc_lo, s39                                  // 000000497C9C: 8C27276A
	v_fma_mixlo_f16 v2, v4, s45, 0                             // 000000497CA0: CC210002 02005B04
	v_fma_mixhi_f16 v3, v7, s45, 0                             // 000000497CA8: CC220003 02005B07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000497CB0: BF870003
	v_fma_mixlo_f16 v3, v10, s45, 0                            // 000000497CB4: CC210003 02005B0A
	ds_store_b64 v6, v[2:3]                                    // 000000497CBC: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s39                       // 000000497CC4: 917E277E
	s_cbranch_execz 289                                        // 000000497CC8: BFA50121 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x850>
	.long 0xd72d0002                                           // 000000497CCC: D72D0002
	v_cndmask_b32_e32 v0, v8, v43, vcc_lo                      // 000000497CD0: 02005708
	s_mov_b32 s6, -1                                           // 000000497CD4: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497CD8: BF870091
	.long 0xd72c0003                                           // 000000497CDC: D72C0003
	v_cndmask_b32_e32 v0, v2, v37, vcc_lo                      // 000000497CE0: 02004B02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000497CE4: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000497CE8: BF870121
	v_subrev_nc_u32_e32 v5, s37, v3                            // 000000497CEC: 4E0A0625
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000497CF0: 7C960625
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000497CF4: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497CFC: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000497D00: 02040902
	v_cmp_le_u32_e32 vcc_lo, s37, v3                           // 000000497D04: 7C960625
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497D08: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000497D0C: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000497D10: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s36                        // 000000497D14: 916A247E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497D18: BF870091
	v_xor_b32_e32 v11, s40, v2                                 // 000000497D1C: 3A160428
	v_subrev_nc_u32_e32 v10, s40, v11                          // 000000497D20: 4E141628
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000497D24: BF8700A1
	v_mad_u64_u32 v[6:7], null, s42, v10, v[1:2]               // 000000497D28: D6FE7C06 0406142A
	v_min_i32_e32 v2, s35, v10                                 // 000000497D30: 22041423
	v_mad_i64_i32 v[4:5], null, v2, s38, 0                     // 000000497D34: D6FF7C04 02004D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497D3C: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000497D40: 340E0C9F
	.long 0xd73c0002                                           // 000000497D44: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000497D48: 02020C81
	s_cbranch_vccnz 212                                        // 000000497D4C: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7a0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497D50: BF870093
	.long 0xd7006a06                                           // 000000497D54: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000497D58: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000497D5C: D5207C07 01AA0F05
	.long 0x7f383880                                           // 000000497D64: 7F383880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497D68: BF870112
	.long 0xd73c0006                                           // 000000497D6C: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000497D70: 02020C81
	.long 0x7f3e399c                                           // 000000497D74: 7F3E399C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497D78: BF870092
	.long 0xd7006a0c                                           // 000000497D7C: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000497D80: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000497D84: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000497D8C: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000497D90: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000497D94: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000497D98: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 000000497DA0: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000497DA8: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000497DAC: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000497DB0: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 000000497DB8: D5207C0F 01AA0615
	s_clause 0x1                                               // 000000497DC0: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000497DC4: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000497DCC: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000497DD4: BF890FF7
	.long 0x7e1e390c                                           // 000000497DD8: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000497DDC: BF890BF7
	v_and_b32_e32 v40, 0xffff0000, v6                          // 000000497DE0: 36500CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000497DE8: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000497DEC: BF870093
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000497DF0: 301E1E90
	v_mul_f32_e32 v19, 0xbfb8aa3b, v15                         // 000000497DF4: 10261EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000497DFC: BF870291
	v_exp_f32_e32 v19, v19                                     // 000000497E00: 7E264B13
	v_dual_add_f32 v19, 1.0, v19 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000497E04: C92426F2 130C18FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497E10: BF870111
	v_mul_f32_e32 v18, 0xbfb8aa3b, v12                         // 000000497E14: 102418FF BFB8AA3B
	v_div_scale_f32 v23, null, v19, v19, v15                   // 000000497E1C: D6FC7C17 043E2713
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000497E24: BF8701B2
	v_exp_f32_e32 v18, v18                                     // 000000497E28: 7E244B12
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000497E2C: 30221A90
	v_div_scale_f32 v38, s7, v15, v19, v15                     // 000000497E30: D6FC0726 043E270F
	v_rcp_f32_e32 v27, v23                                     // 000000497E38: 7E365517
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497E3C: BF870196
	v_add_f32_e32 v18, 1.0, v18                                // 000000497E40: 062424F2
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 000000497E44: 102822FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497E4C: BF870195
	v_fma_f32 v37, -v23, v27, 1.0                              // 000000497E50: D6130025 23CA3717
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000497E58: D6FC7C16 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000497E60: BF8701B3
	v_exp_f32_e32 v20, v20                                     // 000000497E64: 7E284B14
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000497E68: 361A1AFF FFFF0000
	v_div_scale_f32 v32, vcc_lo, v12, v18, v12                 // 000000497E70: D6FC6A20 0432250C
	v_rcp_f32_e32 v25, v22                                     // 000000497E78: 7E325516
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 000000497E7C: BF870106
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_mul_f32 v21, 0xbfb8aa3b, v13// 000000497E80: C90628F2 14141AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497E8C: BF870115
	v_fma_f32 v33, -v22, v25, 1.0                              // 000000497E90: D6130021 23CA3316
	v_div_scale_f32 v24, null, v20, v20, v17                   // 000000497E98: D6FC7C18 04462914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000497EA0: BF8701A3
	v_exp_f32_e32 v21, v21                                     // 000000497EA4: 7E2A4B15
	v_div_scale_f32 v34, s6, v17, v20, v17                     // 000000497EA8: D6FC0622 04462911
	v_fmac_f32_e32 v25, v33, v25                               // 000000497EB0: 56323321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000497EB4: BF870313
	v_rcp_f32_e32 v29, v24                                     // 000000497EB8: 7E3A5518
	v_add_f32_e32 v21, 1.0, v21                                // 000000497EBC: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497EC0: BF870115
	v_fma_f32 v39, -v24, v29, 1.0                              // 000000497EC4: D6130027 23CA3B18
	v_div_scale_f32 v26, null, v21, v21, v13                   // 000000497ECC: D6FC7C1A 04362B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000497ED4: BF8701A2
	v_fmac_f32_e32 v29, v39, v29                               // 000000497ED8: 563A3B27
	v_mul_f32_e32 v39, v32, v25                                // 000000497EDC: 104E3320
	v_rcp_f32_e32 v30, v26                                     // 000000497EE0: 7E3C551A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497EE4: BF870112
	v_mul_f32_e32 v41, v34, v29                                // 000000497EE8: 10523B22
	v_fma_f32 v42, -v22, v39, v32                              // 000000497EEC: D613002A 24824F16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497EF4: BF870112
	v_fma_f32 v45, -v24, v41, v34                              // 000000497EF8: D613002D 248A5318
	v_fmac_f32_e32 v39, v42, v25                               // 000000497F00: 564E332A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497F04: BF870195
	v_fma_f32 v33, -v26, v30, 1.0                              // 000000497F08: D6130021 23CA3D1A
	v_fmac_f32_e32 v41, v45, v29                               // 000000497F10: 56523B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497F14: BF870193
	v_fma_f32 v22, -v22, v39, v32                              // 000000497F18: D6130016 24824F16
	v_fmac_f32_e32 v30, v33, v30                               // 000000497F20: 563C3D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497F24: BF870193
	v_fma_f32 v24, -v24, v41, v34                              // 000000497F28: D6130018 248A5318
	v_div_fmas_f32 v22, v22, v25, v39                          // 000000497F30: D6370016 049E3316
	s_mov_b32 vcc_lo, s7                                       // 000000497F38: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000497F3C: BF870131
	v_div_fixup_f32 v12, v22, v18, v12                         // 000000497F40: D627000C 04322516
	v_fmac_f32_e32 v27, v37, v27                               // 000000497F48: 56363725
	v_div_scale_f32 v37, s8, v13, v21, v13                     // 000000497F4C: D6FC0825 04362B0D
	v_dual_mul_f32 v12, v12, v40 :: v_dual_mul_f32 v33, v38, v27// 000000497F54: C8C6510C 0C203726
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497F5C: BF870112
	v_mul_f32_e32 v43, v37, v30                                // 000000497F60: 10563D25
	.long 0x7e38398c                                           // 000000497F64: 7E38398C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497F68: BF870193
	v_fma_f32 v44, -v23, v33, v38                              // 000000497F6C: D613002C 249A4317
	v_fma_f32 v42, -v26, v43, v37                              // 000000497F74: D613002A 2496571A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497F7C: BF870112
	v_fmac_f32_e32 v33, v44, v27                               // 000000497F80: 5642372C
	v_fmac_f32_e32 v43, v42, v30                               // 000000497F84: 56563D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000497F88: BF870112
	v_fma_f32 v23, -v23, v33, v38                              // 000000497F8C: D6130017 249A4317
	v_fma_f32 v22, -v26, v43, v37                              // 000000497F94: D6130016 2496571A
	s_delay_alu instid0(VALU_DEP_2)                            // 000000497F9C: BF870002
	v_div_fmas_f32 v23, v23, v27, v33                          // 000000497FA0: D6370017 04863717
	s_mov_b32 vcc_lo, s6                                       // 000000497FA8: BEEA0006
	s_mov_b32 s6, 0                                            // 000000497FAC: BE860080
	v_div_fmas_f32 v18, v24, v29, v41                          // 000000497FB0: D6370012 04A63B18
	s_mov_b32 vcc_lo, s8                                       // 000000497FB8: BEEA0008
	v_div_fixup_f32 v15, v23, v19, v15                         // 000000497FBC: D627000F 043E2717
	v_lshlrev_b32_e32 v19, 16, v7                              // 000000497FC4: 30260E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000497FC8: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v20, v17                         // 000000497FD0: D6270011 04462912
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000497FD8: BF8701A4
	v_mul_f32_e32 v6, v15, v6                                  // 000000497FDC: 100C0D0F
	v_div_fmas_f32 v15, v22, v30, v43                          // 000000497FE0: D637000F 04AE3D16
	v_mul_f32_e32 v17, v17, v19                                // 000000497FE8: 10222711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000497FEC: BF870193
	.long 0x7e3e3986                                           // 000000497FF0: 7E3E3986
	v_div_fixup_f32 v13, v15, v21, v13                         // 000000497FF4: D627000D 04362B0F
	v_and_b32_e32 v15, 1, v28                                  // 000000497FFC: 361E3881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498000: BF870214
	v_bfe_u32 v18, v17, 16, 1                                  // 000000498004: D6100012 02052111
	v_and_b32_e32 v19, 1, v31                                  // 00000049800C: 36263E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498010: BF870214
	v_mul_f32_e32 v7, v13, v7                                  // 000000498014: 100E0F0D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000498018: D655000C 03FE1F0C 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498024: BF870214
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000498028: D655000D 03FE2511 00007FFF
	v_add3_u32 v6, v6, v19, 0x7fff                             // 000000498034: D6550006 03FE2706 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498040: BF870214
	v_bfe_u32 v15, v7, 16, 1                                   // 000000498044: D610000F 02052107
	v_and_b32_e32 v12, 0xffff0000, v12                         // 00000049804C: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498054: BF870214
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000498058: 36221AFF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000498060: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 000000498068: BF870004
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000049806C: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000498078: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000049807C: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000498084: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000498088: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000498090: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000498098: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 0000004980A0: 916A067E
	s_cbranch_vccnz 65125                                      // 0000004980A4: BFA4FE65 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004980A8: BF870093
	.long 0xd73c0004                                           // 0000004980AC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000004980B0: 02020881
	.long 0xd7006a04                                           // 0000004980B4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 0000004980B8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004980BC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 0000004980C0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 0000004980C8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 0000004980CC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004980D0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 0000004980D4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 0000004980DC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000004980E0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 0000004980E4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 0000004980EC: DC560000 047C0004
	s_clause 0x1                                               // 0000004980F4: BF850001
	global_load_b32 v14, v[6:7], off                           // 0000004980F8: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000498100: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000498108: BF890BF7
	.long 0x7e0e3904                                           // 00000049810C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000498110: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000498118: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049811C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000498120: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000498124: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000498128: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000498130: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 000000498134: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 00000049813C: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 000000498144: 361C0AFF FFFF0000
	s_branch 65083                                             // 00000049814C: BFA0FE3B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x13c>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000498150: 8C7E137E
	s_ashr_i32 s0, s9, 31                                      // 000000498154: 86009F09
	s_lshr_b32 s3, s11, 28                                     // 000000498158: 85039C0B
	s_lshr_b32 s0, s0, 29                                      // 00000049815C: 85009D00
	s_lshl_b32 s1, s34, 3                                      // 000000498160: 84018322
	s_add_i32 s0, s0, s9                                       // 000000498164: 81000900
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v103, 0            // 000000498168: CA100080 28660080
	s_add_i32 s0, s0, 7                                        // 000000498170: 81008700
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v105, 0           // 000000498174: CA100080 66680080
	s_ashr_i32 s0, s0, 3                                       // 00000049817C: 86008300
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v107, 0           // 000000498180: CA100080 686A0080
	.long 0xd72c0001                                           // 000000498188: D72C0001
	v_cndmask_b32_e32 v1, s0, v35, vcc_lo                      // 00000049818C: 02024600
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v109, 0           // 000000498190: CA100080 6A6C0080
	v_mov_b32_e32 v108, 0                                      // 000000498198: 7ED80280
	s_waitcnt lgkmcnt(0)                                       // 00000049819C: BF89FC07
	s_barrier                                                  // 0000004981A0: BFBD0000
	buffer_gl0_inv                                             // 0000004981A4: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 0000004981AC: 4A040200
	s_add_i32 s0, s17, s3                                      // 0000004981B0: 81000311
	s_ashr_i32 s3, s1, 31                                      // 0000004981B4: 86039F01
	s_ashr_i32 s0, s0, 4                                       // 0000004981B8: 86008400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004981BC: BF870001
	v_min_i32_e32 v101, s9, v2                                 // 0000004981C0: 22CA0409
	s_mul_i32 s4, s0, s2                                       // 0000004981C4: 96040200
	s_mul_hi_i32 s5, s0, s2                                    // 0000004981C8: 97050200
	s_add_u32 s0, s4, s1                                       // 0000004981CC: 80000104
	s_addc_u32 s1, s5, s3                                      // 0000004981D0: 82010305
	v_cmp_lt_i32_e32 vcc_lo, v1, v101                          // 0000004981D4: 7C82CB01
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000004981D8: 84848A00
	s_and_saveexec_b32 s1, vcc_lo                              // 0000004981DC: BE81206A
	s_cbranch_execz 34                                         // 0000004981E0: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x96c>
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004981E4: 3404029F
	s_add_u32 s0, s12, s4                                      // 0000004981E8: 8000040C
	v_lshlrev_b32_e32 v4, 2, v36                               // 0000004981EC: 30084882
	s_addc_u32 s3, s13, s5                                     // 0000004981F0: 8203050D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004981F4: BF870092
	.long 0xd73c0002                                           // 0000004981F8: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000004981FC: 0202028A
	.long 0xd7000002                                           // 000000498200: D7000002
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000498204: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000498208: BF870111
	v_add_co_ci_u32_e64 v3, null, s3, v3, s0                   // 00000049820C: D5207C03 00020603
	.long 0xd7000002                                           // 000000498214: D7000002
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000498218: 02020902
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049821C: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, s0                    // 000000498220: D5207C03 00020680
	s_clause 0x7                                               // 000000498228: BF850007
	global_load_b32 v102, v[2:3], off                          // 00000049822C: DC520000 667C0002
	global_load_b32 v103, v[2:3], off offset:128               // 000000498234: DC520080 677C0002
	global_load_b32 v104, v[2:3], off offset:256               // 00000049823C: DC520100 687C0002
	global_load_b32 v105, v[2:3], off offset:384               // 000000498244: DC520180 697C0002
	global_load_b32 v106, v[2:3], off offset:512               // 00000049824C: DC520200 6A7C0002
	global_load_b32 v107, v[2:3], off offset:640               // 000000498254: DC520280 6B7C0002
	global_load_b32 v108, v[2:3], off offset:768               // 00000049825C: DC520300 6C7C0002
	global_load_b32 v109, v[2:3], off offset:896               // 000000498264: DC520380 6D7C0002
	s_or_b32 exec_lo, exec_lo, s1                              // 00000049826C: 8C7E017E
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v99, 0            // 000000498270: CA100080 64620080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v97, 0             // 000000498278: CA100080 62600080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v95, 0             // 000000498280: CA100080 605E0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v93, 0             // 000000498288: CA100080 5E5C0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v91, 0             // 000000498290: CA100080 5C5A0080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v89, 0             // 000000498298: CA100080 5A580080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v87, 0             // 0000004982A0: CA100080 58560080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v85, 0             // 0000004982A8: CA100080 56540080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v83, 0             // 0000004982B0: CA100080 54520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v81, 0             // 0000004982B8: CA100080 52500080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v79, 0             // 0000004982C0: CA100080 504E0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v77, 0             // 0000004982C8: CA100080 4E4C0080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v75, 0             // 0000004982D0: CA100080 4C4A0080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v73, 0             // 0000004982D8: CA100080 4A480080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v71, 0             // 0000004982E0: CA100080 48460080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v69, 0             // 0000004982E8: CA100080 46440080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v67, 0             // 0000004982F0: CA100080 44420080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v65, 0             // 0000004982F8: CA100080 42400080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v63, 0             // 000000498300: CA100080 403E0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v61, 0             // 000000498308: CA100080 3E3C0080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v59, 0             // 000000498310: CA100080 3C3A0080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v57, 0             // 000000498318: CA100080 3A380080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v55, 0             // 000000498320: CA100080 38360080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v53, 0             // 000000498328: CA100080 36340080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 000000498330: CA100080 34320080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v49, 0             // 000000498338: CA100080 32300080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v47, 0             // 000000498340: CA100080 302E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v45, 0             // 000000498348: CA100080 2E2C0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v43, 0             // 000000498350: CA100080 2C2A0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v41, 0             // 000000498358: CA100080 2A280080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000498360: CA100080 26260080
	v_mov_b32_e32 v37, 0                                       // 000000498368: 7E4A0280
	s_ashr_i32 s3, s2, 31                                      // 00000049836C: 86039F02
	s_and_saveexec_b32 s1, vcc_lo                              // 000000498370: BE81206A
	s_cbranch_execz 1312                                       // 000000498374: BFA50520 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ef8>
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v4, 5, v36     // 000000498378: CA220080 25044885
	v_cmp_ne_u32_e32 vcc_lo, 0, v36                            // 000000498380: 7C9A4880
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000498384: 3404029F
	v_dual_mov_b32 v39, 0 :: v_dual_and_b32 v8, 16, v0         // 000000498388: CA240080 27080090
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000498390: BF8701A4
	v_add_nc_u32_e32 v5, 0x3f0, v4                             // 000000498394: 4A0A08FF 000003F0
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v7, 2, v36     // 00000049839C: CA220080 26064882
	v_lshl_or_b32 v110, v1, 5, v8                              // 0000004983A4: D656006E 04210B01
	v_mul_u32_u24_e32 v6, 0x420, v35                           // 0000004983AC: 160C46FF 00000420
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004983B4: BF870214
	v_lshrrev_b32_e32 v3, 5, v5                                // 0000004983B8: 32060A85
	v_mad_u32_u24 v9, 0x420, v35, v7                           // 0000004983BC: D60B0009 041E46FF 00000420
	v_sub_nc_u32_e32 v112, 0, v101                             // 0000004983C8: 4CE0CA80
	v_dual_mov_b32 v48, 0 :: v_dual_add_nc_u32 v113, 1, v1     // 0000004983CC: CA200080 30700281
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004983D4: BF870244
	v_subrev_nc_u32_e32 v10, 32, v3                            // 0000004983D8: 4E1406A0
	.long 0xd73c0002                                           // 0000004983DC: D73C0002
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000004983E0: 0202028A
	v_dual_mov_b32 v43, 0 :: v_dual_add_nc_u32 v114, 0xa000, v9// 0000004983E4: CA200080 2B7212FF 0000A000
	v_mov_b32_e32 v42, 0                                       // 0000004983F0: 7E540280
	v_dual_cndmask_b32 v8, 31, v10 :: v_dual_and_b32 v5, 0x7e0, v5// 0000004983F4: CA64149F 08040AFF 000007E0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000498400: BF870094
	.long 0xd7006a02                                           // 000000498404: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000498408: 02020404
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000049840C: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498414: BF870213
	v_sub_nc_u32_e32 v4, v5, v4                                // 000000498418: 4C080905
	v_dual_mov_b32 v44, 0 :: v_dual_add_nc_u32 v5, 1, v8       // 00000049841C: CA200080 2C041081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000498424: BF870094
	.long 0xd7006a02                                           // 000000498428: D7006A02
	v_cndmask_b32_e32 v1, v2, v7, vcc_lo                       // 00000049842C: 02020F02
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000498430: D5207C03 01AA0680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498438: BF870214
	v_dual_mov_b32 v46, 0 :: v_dual_add_nc_u32 v111, 0xfffffc30, v4// 00000049843C: CA200080 2E6E08FF FFFFFC30
	v_dual_mov_b32 v41, 0 :: v_dual_and_b32 v4, 31, v5         // 000000498448: CA240080 29040A9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000498450: BF870094
	.long 0xd7006a02                                           // 000000498454: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000498458: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000049845C: D5207C03 01AA060D
	v_lshl_add_u32 v5, v8, 2, v6                               // 000000498464: D6460005 04190508
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049846C: BF870214
	v_lshl_add_u32 v4, v4, 2, v6                               // 000000498470: D6460004 04190504
	.long 0xd7006a21                                           // 000000498478: D7006A21
	v_cndmask_b32_e32 v1, 0x400, v2, vcc_lo                    // 00000049847C: 020204FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498484: BF870211
	v_add_co_ci_u32_e64 v34, null, 0, v3, vcc_lo               // 000000498488: D5207C22 01AA0680
	v_dual_mov_b32 v50, 0 :: v_dual_add_nc_u32 v115, 0xa000, v5// 000000498490: CA200080 32720AFF 0000A000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049849C: BF870004
	v_dual_mov_b32 v45, 0 :: v_dual_add_nc_u32 v116, 0xa000, v4// 0000004984A0: CA200080 2D7408FF 0000A000
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v52, 0             // 0000004984AC: CA100080 2F340080
	v_dual_mov_b32 v49, 0 :: v_dual_mov_b32 v54, 0             // 0000004984B4: CA100080 31360080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v56, 0             // 0000004984BC: CA100080 33380080
	v_dual_mov_b32 v53, 0 :: v_dual_mov_b32 v58, 0             // 0000004984C4: CA100080 353A0080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v60, 0             // 0000004984CC: CA100080 373C0080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v62, 0             // 0000004984D4: CA100080 393E0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v64, 0             // 0000004984DC: CA100080 3B400080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v66, 0             // 0000004984E4: CA100080 3D420080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v68, 0             // 0000004984EC: CA100080 3F440080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v70, 0             // 0000004984F4: CA100080 41460080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v72, 0             // 0000004984FC: CA100080 43480080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v74, 0             // 000000498504: CA100080 454A0080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v76, 0             // 00000049850C: CA100080 474C0080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v78, 0             // 000000498514: CA100080 494E0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v80, 0             // 00000049851C: CA100080 4B500080
	v_dual_mov_b32 v77, 0 :: v_dual_mov_b32 v82, 0             // 000000498524: CA100080 4D520080
	v_dual_mov_b32 v79, 0 :: v_dual_mov_b32 v84, 0             // 00000049852C: CA100080 4F540080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v86, 0             // 000000498534: CA100080 51560080
	v_dual_mov_b32 v83, 0 :: v_dual_mov_b32 v88, 0             // 00000049853C: CA100080 53580080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v90, 0             // 000000498544: CA100080 555A0080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v92, 0             // 00000049854C: CA100080 575C0080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v94, 0             // 000000498554: CA100080 595E0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v96, 0             // 00000049855C: CA100080 5B600080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v98, 0             // 000000498564: CA100080 5D620080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v100, 0            // 00000049856C: CA100080 5F640080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v40, 0             // 000000498574: CA100080 61280080
	v_mov_b32_e32 v99, 0                                       // 00000049857C: 7EC60280
	s_mov_b32 s4, 0                                            // 000000498580: BE840080
	s_movk_i32 s5, 0x1eee                                      // 000000498584: B0051EEE
	s_branch 1144                                              // 000000498588: BFA00478 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e6c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000049858C: 8C7E007E
	ds_load_2addr_b32 v[117:118], v116 offset1:32              // 000000498590: D8DC2000 75000074
	ds_load_2addr_b32 v[122:123], v114 offset1:32              // 000000498598: D8DC2000 7A000072
	ds_load_2addr_b32 v[120:121], v115 offset1:32              // 0000004985A0: D8DC2000 78000073
	ds_load_b128 v[21:24], v110 offset:5120                    // 0000004985A8: DBFC1400 1500006E
	ds_load_b128 v[25:28], v110 offset:10240                   // 0000004985B0: DBFC2800 1900006E
	ds_load_b128 v[17:20], v110 offset:15360                   // 0000004985B8: DBFC3C00 1100006E
	ds_load_b128 v[9:12], v110 offset:20480                    // 0000004985C0: DBFC5000 0900006E
	ds_load_b128 v[1:4], v110 offset:25600                     // 0000004985C8: DBFC6400 0100006E
	ds_load_b128 v[5:8], v110 offset:30720                     // 0000004985D0: DBFC7800 0500006E
	ds_load_b128 v[29:32], v110                                // 0000004985D8: DBFC0000 1D00006E
	ds_load_b128 v[13:16], v110 offset:35840                   // 0000004985E0: DBFC8C00 0D00006E
	.long 0xd7000021                                           // 0000004985E8: D7000021
	v_cndmask_b32_e32 v1, 0x400, v33, vcc_lo                   // 0000004985EC: 020242FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004985F4: BF870001
	v_add_co_ci_u32_e64 v34, null, 0, v34, s0                  // 0000004985F8: D5207C22 00024480
	s_waitcnt lgkmcnt(10)                                      // 000000498600: BF89FCA7
	v_dual_mov_b32 v119, v117 :: v_dual_add_nc_u32 v110, 32, v110// 000000498604: CA200175 776EDCA0
	s_waitcnt lgkmcnt(9)                                       // 00000049860C: BF89FC97
	v_bfe_u32 v117, v122, 12, 16                               // 000000498610: D6100075 0241197A
	v_bfe_u32 v126, v122, 8, 16                                // 000000498618: D610007E 0241117A
	s_waitcnt lgkmcnt(8)                                       // 000000498620: BF89FC87
	.long 0xd73d007c                                           // 000000498624: D73D007C
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000498628: 0202EF6F
	v_mov_b32_e32 v119, v121                                   // 00000049862C: 7EEE0379
	.long 0xd72c0079                                           // 000000498630: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000498634: 0202EAFF 83DCD12D
	.long 0xd72c007d                                           // 00000049863C: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000498640: 0202FCFF 83DCD12D
	v_bfe_u32 v120, v122, 4, 16                                // 000000498648: D6100078 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000498650: 36F4F4FF 0000FFFF
	v_bfe_u32 v117, v124, 12, 16                               // 000000498658: D6100075 0241197C
	v_bfe_u32 v126, v124, 8, 16                                // 000000498660: D610007E 0241117C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498668: BF870214
	.long 0xd72c0078                                           // 00000049866C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000498670: 0202F0FF 83DCD12D
	.long 0xd72c007a                                           // 000000498678: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 00000049867C: 0202F4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000498684: BF870004
	.long 0xd72c0080                                           // 000000498688: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000049868C: 0202EAFF 83DCD12D
	.long 0xd73d0075                                           // 000000498694: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 000000498698: 0202ED6F
	.long 0xd72c0077                                           // 00000049869C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004986A0: 0202FCFF 83DCD12D
	v_bfe_u32 v118, v124, 4, 16                                // 0000004986A8: D6100076 0241097C
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000004986B0: D6220079 03FD0179 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000004986BC: D622007D 03FD017D 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 0000004986C8: D6220078 03FD0178 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000004986D4: D622007A 03FD017A 00006400
	v_sad_u8 v126, v128, 0, 0x6400                             // 0000004986E0: D622007E 03FD0180 00006400
	.long 0xd72c0076                                           // 0000004986EC: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000004986F0: 0202ECFF 83DCD12D
	v_sad_u8 v119, v119, 0, 0x6400                             // 0000004986F8: D6220077 03FD0177 00006400
	v_bfe_u32 v128, v123, 4, 16                                // 000000498704: D6100080 0241097B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049870C: BF870214
	v_and_b32_e32 v126, 0xffff, v126                           // 000000498710: 36FCFCFF 0000FFFF
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000498718: D6220076 03FD0176 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000498724: BF870122
	v_lshl_or_b32 v119, v119, 16, v126                         // 000000498728: D6560077 05F92177
	v_bfe_u32 v126, v117, 12, 16                               // 000000498730: D610007E 02411975
	v_pk_fma_f16 v119, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498738: CC0E0077 0BFC0B77 0000C931
	v_and_b32_e32 v127, 0xffff, v124                           // 000000498744: 36FEF8FF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000049874C: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000498750: BF8701A2
	v_dual_dot2acc_f32_f16 v37, v119, v29 :: v_dual_lshlrev_b32 v122, 16, v122// 000000498754: CB223B77 257AF490
	v_dot2acc_f32_f16 v38, v119, v25                           // 00000049875C: 044C3377
	.long 0xd72c007c                                           // 000000498760: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 000000498764: 0202FEFF 83DCD12D
	v_and_b32_e32 v121, 0xffff, v121                           // 00000049876C: 36F2F2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000498774: BF870234
	v_and_or_b32 v120, 0xffff, v120, v122                      // 000000498778: D6570078 05EAF0FF 0000FFFF
	v_dot2acc_f32_f16 v39, v119, v21                           // 000000498784: 044E2B77
	v_bfe_u32 v127, v123, 8, 16                                // 000000498788: D610007F 0241117B
	v_lshl_or_b32 v121, v125, 16, v121                         // 000000498790: D6560079 05E5217D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000498798: BF870224
	v_pk_fma_f16 v125, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000049879C: CC0E007D 0BFC0B78 0000C931
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000004987A8: D622007C 03FD017C 00006400
	.long 0xd72c007f                                           // 0000004987B4: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000004987B8: 0202FEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004987C0: BF870092
	v_lshlrev_b32_e32 v124, 16, v124                           // 0000004987C4: 30F8F890
	v_and_or_b32 v118, 0xffff, v118, v124                      // 0000004987C8: D6570076 05F2ECFF 0000FFFF
	v_pk_fma_f16 v124, v121, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004987D4: CC0E007C 0BFC0B79 0000C931
	v_bfe_u32 v121, v117, 8, 16                                // 0000004987E0: D6100079 02411175
	s_delay_alu instid0(VALU_DEP_3)                            // 0000004987E8: BF870003
	v_pk_fma_f16 v120, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004987EC: CC0E0078 0BFC0B76 0000C931
	.long 0xd72c0076                                           // 0000004987F8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004987FC: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v42, v119, v9                            // 000000498804: 04541377
	v_and_b32_e32 v122, 0xffff, v117                           // 000000498808: 36F4EAFF 0000FFFF
	v_bfe_u32 v117, v117, 4, 16                                // 000000498810: D6100075 02410975
	v_dot2acc_f32_f16 v39, v120, v22                           // 000000498818: 044E2D78
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049881C: BF870234
	v_dual_dot2acc_f32_f16 v41, v119, v17 :: v_dual_dot2acc_f32_f16 v42, v120, v10// 000000498820: CB182377 292A1578
	v_dot2acc_f32_f16 v37, v120, v30                           // 000000498828: 044A3D78
	v_sad_u8 v118, v118, 0, 0x6400                             // 00000049882C: D6220076 03FD0176 00006400
	v_dot2acc_f32_f16 v39, v124, v23                           // 000000498838: 044E2F7C
	.long 0xd72c007a                                           // 00000049883C: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000498840: 0202F4FF 83DCD12D
	v_bfe_u32 v126, v123, 12, 16                               // 000000498848: D610007E 0241197B
	.long 0xd72c0079                                           // 000000498850: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000498854: 0202F2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v44, v119, v5 :: v_dual_dot2acc_f32_f16 v41, v120, v18// 00000049885C: CB180B77 2C282578
	v_dual_dot2acc_f32_f16 v43, v119, v1 :: v_dual_dot2acc_f32_f16 v38, v120, v26// 000000498864: CB180377 2B263578
	v_and_b32_e32 v118, 0xffff, v118                           // 00000049886C: 36ECECFF 0000FFFF
	v_dual_dot2acc_f32_f16 v42, v124, v11 :: v_dual_dot2acc_f32_f16 v39, v125, v24// 000000498874: CB18177C 2A26317D
	v_dot2acc_f32_f16 v37, v124, v31                           // 00000049887C: 044A3F7C
	.long 0xd72c0075                                           // 000000498880: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000498884: 0202EAFF 83DCD12D
	.long 0xd72c007e                                           // 00000049888C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000498890: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v44, v120, v6                            // 000000498898: 04580D78
	v_dot2acc_f32_f16 v42, v125, v12                           // 00000049889C: 0454197D
	v_dual_dot2acc_f32_f16 v38, v124, v27 :: v_dual_dot2acc_f32_f16 v37, v125, v32// 0000004988A0: CB18377C 2624417D
	v_dot2acc_f32_f16 v43, v120, v2                            // 0000004988A8: 04560578
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000004988AC: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v41, v124, v19                           // 0000004988B8: 0452277C
	v_sad_u8 v121, v121, 0, 0x6400                             // 0000004988BC: D6220079 03FD0179 00006400
	v_dot2acc_f32_f16 v38, v125, v28                           // 0000004988C8: 044C397D
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000004988CC: D6220075 03FD0175 00006400
	v_lshlrev_b32_e32 v122, 16, v122                           // 0000004988D8: 30F4F490
	v_dual_dot2acc_f32_f16 v44, v124, v7 :: v_dual_dot2acc_f32_f16 v41, v125, v20// 0000004988DC: CB180F7C 2C28297D
	v_dot2acc_f32_f16 v43, v124, v3                            // 0000004988E4: 0456077C
	v_sad_u8 v126, v126, 0, 0x6400                             // 0000004988E8: D622007E 03FD017E 00006400
	v_lshl_or_b32 v118, v121, 16, v118                         // 0000004988F4: D6560076 05D92179
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004988FC: BF870224
	v_dot2acc_f32_f16 v44, v125, v8                            // 000000498900: 0458117D
	v_and_or_b32 v117, 0xffff, v117, v122                      // 000000498904: D6570075 05EAEAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v43, v125, v4 :: v_dual_and_b32 v122, 0xffff, v126// 000000498910: CB24097D 2B7AFCFF 0000FFFF
	v_sad_u8 v126, v127, 0, 0x6400                             // 00000049891C: D622007E 03FD017F 00006400
	v_pk_fma_f16 v127, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498928: CC0E007F 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000498934: 36F6F6FF 0000FFFF
	.long 0xd72c0079                                           // 00000049893C: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 000000498940: 020300FF 83DCD12D
	v_pk_fma_f16 v128, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498948: CC0E0080 0BFC0B75 0000C931
	v_lshl_or_b32 v122, v126, 16, v122                         // 000000498954: D656007A 05E9217E
	v_dot2acc_f32_f16 v46, v127, v29                           // 00000049895C: 045C3B7F
	.long 0xd72c007b                                           // 000000498960: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000498964: 0202F6FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000049896C: BF89FC07
	v_dot2acc_f32_f16 v45, v119, v13                           // 000000498970: 045A1B77
	ds_load_2addr_b32 v[117:118], v116 offset0:64 offset1:96   // 000000498974: D8DC6040 75000074
	v_pk_fma_f16 v126, v122, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000049897C: CC0E007E 0BFC0B7A 0000C931
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000498988: D6220079 03FD0179 00006400
	v_dual_dot2acc_f32_f16 v46, v128, v30 :: v_dual_dot2acc_f32_f16 v47, v127, v21// 000000498994: CB183D80 2E2E2B7F
	v_dual_dot2acc_f32_f16 v45, v120, v14 :: v_dual_dot2acc_f32_f16 v50, v127, v9// 00000049899C: CB181D78 2D32137F
	v_sad_u8 v119, v123, 0, 0x6400                             // 0000004989A4: D6220077 03FD017B 00006400
	v_dot2acc_f32_f16 v48, v127, v25                           // 0000004989B0: 0460337F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004989B4: BF870214
	v_dot2acc_f32_f16 v46, v126, v31                           // 0000004989B8: 045C3F7E
	v_dual_dot2acc_f32_f16 v45, v124, v15 :: v_dual_dot2acc_f32_f16 v52, v127, v5// 0000004989BC: CB181F7C 2D340B7F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004989C4: BF870214
	v_lshlrev_b32_e32 v119, 16, v119                           // 0000004989C8: 30EEEE90
	v_dual_dot2acc_f32_f16 v49, v127, v17 :: v_dual_dot2acc_f32_f16 v48, v128, v26// 0000004989CC: CB18237F 31303580
	v_dot2acc_f32_f16 v47, v128, v22                           // 0000004989D4: 045E2D80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004989D8: BF870214
	v_dual_dot2acc_f32_f16 v45, v125, v16 :: v_dual_dot2acc_f32_f16 v50, v128, v10// 0000004989DC: CB18217D 2D321580
	v_and_or_b32 v119, 0xffff, v121, v119                      // 0000004989E4: D6570077 05DEF2FF 0000FFFF
	ds_load_2addr_b32 v[120:121], v115 offset0:64 offset1:96   // 0000004989F0: D8DC6040 78000073
	v_dot2acc_f32_f16 v48, v126, v27                           // 0000004989F8: 0460377E
	ds_load_2addr_b32 v[122:123], v114 offset0:64 offset1:96   // 0000004989FC: D8DC6040 7A000072
	v_dot2acc_f32_f16 v50, v126, v11                           // 000000498A04: 0464177E
	v_pk_fma_f16 v124, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498A08: CC0E007C 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v47, v126, v23                           // 000000498A14: 045E2F7E
	s_waitcnt lgkmcnt(2)                                       // 000000498A18: BF89FC27
	v_mov_b32_e32 v119, v117                                   // 000000498A1C: 7EEE0375
	v_dual_dot2acc_f32_f16 v51, v127, v1 :: v_dual_dot2acc_f32_f16 v52, v128, v6// 000000498A20: CB18037F 33340D80
	v_dot2acc_f32_f16 v46, v124, v32                           // 000000498A28: 045C417C
	v_dot2acc_f32_f16 v47, v124, v24                           // 000000498A2C: 045E317C
	v_dot2acc_f32_f16 v50, v124, v12                           // 000000498A30: 0464197C
	v_dot2acc_f32_f16 v48, v124, v28                           // 000000498A34: 0460397C
	v_dual_dot2acc_f32_f16 v52, v126, v7 :: v_dual_dot2acc_f32_f16 v53, v127, v13// 000000498A38: CB180F7E 34341B7F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000498A40: BF870001
	v_dot2acc_f32_f16 v52, v124, v8                            // 000000498A44: 0468117C
	s_waitcnt lgkmcnt(1)                                       // 000000498A48: BF89FC17
	.long 0xd73d0077                                           // 000000498A4C: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000498A50: 0202EF6F
	v_dot2acc_f32_f16 v49, v128, v18                           // 000000498A54: 04622580
	s_waitcnt lgkmcnt(0)                                       // 000000498A58: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 000000498A5C: D6100081 0241197A
	v_bfe_u32 v130, v122, 8, 16                                // 000000498A64: D6100082 0241117A
	v_bfe_u32 v131, v122, 4, 16                                // 000000498A6C: D6100083 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000498A74: 36F4F4FF 0000FFFF
	v_and_b32_e32 v120, 0xffff, v119                           // 000000498A7C: 36F0EEFF 0000FFFF
	v_bfe_u32 v117, v119, 12, 16                               // 000000498A84: D6100075 02411977
	v_bfe_u32 v125, v119, 8, 16                                // 000000498A8C: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000498A94: D6100077 02410977
	.long 0xd72c0081                                           // 000000498A9C: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000498AA0: 020302FF 83DCD12D
	.long 0xd72c0078                                           // 000000498AA8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000498AAC: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 000000498AB4: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000498AB8: 0202EAFF 83DCD12D
	.long 0xd72c007d                                           // 000000498AC0: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000498AC4: 0202FAFF 83DCD12D
	.long 0xd72c0077                                           // 000000498ACC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000498AD0: 0202EEFF 83DCD12D
	.long 0xd72c0082                                           // 000000498AD8: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000498ADC: 020304FF 83DCD12D
	.long 0xd72c007a                                           // 000000498AE4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000498AE8: 0202F4FF 83DCD12D
	v_dot2acc_f32_f16 v49, v126, v19                           // 000000498AF0: 0462277E
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000498AF4: D6220081 03FD0181 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000498B00: D6220078 03FD0178 00006400
	v_dot2acc_f32_f16 v51, v128, v2                            // 000000498B0C: 04660580
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000498B10: D6220075 03FD0175 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000498B1C: D622007D 03FD017D 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000498B28: D6220077 03FD0177 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498B34: BF870214
	v_dual_dot2acc_f32_f16 v51, v126, v3 :: v_dual_lshlrev_b32 v120, 16, v120// 000000498B38: CB22077E 3378F090
	v_and_b32_e32 v117, 0xffff, v117                           // 000000498B40: 36EAEAFF 0000FFFF
	v_dot2acc_f32_f16 v49, v124, v20                           // 000000498B48: 0462297C
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000498B4C: D622007A 03FD017A 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000498B58: BF870004
	v_and_or_b32 v119, 0xffff, v119, v120                      // 000000498B5C: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 000000498B68: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000498B6C: 020306FF 83DCD12D
	v_lshl_or_b32 v117, v125, 16, v117                         // 000000498B74: D6560075 05D5217D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000498B7C: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000498B84: D6220081 03FD0182 00006400
	v_dot2acc_f32_f16 v51, v124, v4                            // 000000498B90: 0466097C
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498B94: CC0E0082 0BFC0B77 0000C931
	v_pk_fma_f16 v127, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498BA0: CC0E007F 0BFC0B75 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000498BAC: BF870234
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000498BB0: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000498BB8: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000498BC4: 30F0F490
	v_dot2acc_f32_f16 v54, v127, v29                           // 000000498BC8: 046C3B7F
	v_dot2acc_f32_f16 v56, v127, v25                           // 000000498BCC: 0470337F
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498BD0: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v60, v127, v5                            // 000000498BDC: 04780B7F
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000498BE0: D6570075 05E2EEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v54, v130, v30 :: v_dual_mov_b32 v119, v121// 000000498BEC: CB103D82 36760179
	v_dual_dot2acc_f32_f16 v57, v127, v17 :: v_dual_dot2acc_f32_f16 v56, v130, v26// 000000498BF4: CB18237F 39383582
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000498BFC: BF870193
	v_pk_fma_f16 v125, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498C00: CC0E007D 0BFC0B75 0000C931
	v_dual_dot2acc_f32_f16 v54, v122, v31 :: v_dual_dot2acc_f32_f16 v55, v127, v21// 000000498C0C: CB183F7A 36362B7F
	v_dot2acc_f32_f16 v53, v128, v14                           // 000000498C14: 046A1D80
	v_dot2acc_f32_f16 v60, v130, v6                            // 000000498C18: 04780D82
	.long 0xd73d0075                                           // 000000498C1C: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 000000498C20: 0202ED6F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498C24: BF870214
	v_dual_dot2acc_f32_f16 v54, v125, v32 :: v_dual_dot2acc_f32_f16 v55, v130, v22// 000000498C28: CB18417D 36362D82
	v_dual_dot2acc_f32_f16 v53, v126, v15 :: v_dual_dot2acc_f32_f16 v58, v127, v9// 000000498C30: CB181F7E 353A137F
	v_dot2acc_f32_f16 v56, v122, v27                           // 000000498C38: 0470377A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498C3C: BF870214
	v_bfe_u32 v118, v117, 12, 16                               // 000000498C40: D6100076 02411975
	v_dot2acc_f32_f16 v55, v122, v23                           // 000000498C48: 046E2F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000498C4C: BF870214
	v_dot2acc_f32_f16 v53, v124, v16                           // 000000498C50: 046A217C
	v_dual_dot2acc_f32_f16 v57, v130, v18 :: v_dual_dot2acc_f32_f16 v56, v125, v28// 000000498C54: CB182582 3938397D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000498C5C: BF8701B3
	v_dual_dot2acc_f32_f16 v58, v130, v10 :: v_dual_dot2acc_f32_f16 v55, v125, v24// 000000498C60: CB181582 3A36317D
	.long 0xd72c0076                                           // 000000498C68: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000498C6C: 0202ECFF 83DCD12D
	v_bfe_u32 v120, v117, 8, 16                                // 000000498C74: D6100078 02411175
	v_dual_dot2acc_f32_f16 v59, v127, v1 :: v_dual_dot2acc_f32_f16 v58, v122, v11// 000000498C7C: CB18037F 3B3A177A
	v_dot2acc_f32_f16 v57, v122, v19                           // 000000498C84: 0472277A
	v_bfe_u32 v121, v123, 12, 16                               // 000000498C88: D6100079 0241197B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000498C90: BF870004
	.long 0xd72c0078                                           // 000000498C94: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000498C98: 0202F0FF 83DCD12D
	v_dot2acc_f32_f16 v60, v122, v7                            // 000000498CA0: 04780F7A
	v_dual_dot2acc_f32_f16 v59, v130, v2 :: v_dual_dot2acc_f32_f16 v58, v125, v12// 000000498CA4: CB180582 3B3A197D
	v_dot2acc_f32_f16 v57, v125, v20                           // 000000498CAC: 0472297D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000498CB0: D6220076 03FD0176 00006400
	v_bfe_u32 v124, v123, 8, 16                                // 000000498CBC: D610007C 0241117B
	.long 0xd72c0079                                           // 000000498CC4: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 000000498CC8: 0202F2FF 83DCD12D
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000498CD0: D6220078 03FD0178 00006400
	v_dual_dot2acc_f32_f16 v60, v125, v8 :: v_dual_dot2acc_f32_f16 v59, v122, v3// 000000498CDC: CB18117D 3C3A077A
	v_and_b32_e32 v118, 0xffff, v118                           // 000000498CE4: 36ECECFF 0000FFFF
	.long 0xd72c007c                                           // 000000498CEC: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000498CF0: 0202F8FF 83DCD12D
	v_bfe_u32 v126, v123, 4, 16                                // 000000498CF8: D610007E 0241097B
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000498D00: D6220079 03FD0179 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000498D0C: BF870114
	v_lshl_or_b32 v118, v120, 16, v118                         // 000000498D10: D6560076 05D92178
	v_dual_dot2acc_f32_f16 v59, v125, v4 :: v_dual_and_b32 v120, 0xffff, v121// 000000498D18: CB24097D 3B78F2FF 0000FFFF
	v_sad_u8 v121, v124, 0, 0x6400                             // 000000498D24: D6220079 03FD017C 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000498D30: BF8701A3
	v_pk_fma_f16 v124, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498D34: CC0E007C 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 000000498D40: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000498D48: D6560078 05E12179
	s_delay_alu instid0(VALU_DEP_3)                            // 000000498D50: BF870003
	v_dot2acc_f32_f16 v62, v124, v29                           // 000000498D54: 047C3B7C
	v_and_b32_e32 v119, 0xffff, v117                           // 000000498D58: 36EEEAFF 0000FFFF
	v_bfe_u32 v117, v117, 4, 16                                // 000000498D60: D6100075 02410975
	.long 0xd72c007b                                           // 000000498D68: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000498D6C: 0202F6FF 83DCD12D
	v_dot2acc_f32_f16 v64, v124, v25                           // 000000498D74: 0480337C
	v_dot2acc_f32_f16 v66, v124, v9                            // 000000498D78: 0484137C
	.long 0xd72c0077                                           // 000000498D7C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000498D80: 0202EEFF 83DCD12D
	.long 0xd72c0075                                           // 000000498D88: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000498D8C: 0202EAFF 83DCD12D
	v_dot2acc_f32_f16 v68, v124, v5                            // 000000498D94: 04880B7C
	v_dot2acc_f32_f16 v69, v124, v13                           // 000000498D98: 048A1B7C
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000498D9C: D622007B 03FD017B 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000498DA8: D6220077 03FD0177 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000498DB4: D6220075 03FD0175 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000498DC0: BF870092
	v_lshlrev_b32_e32 v119, 16, v119                           // 000000498DC4: 30EEEE90
	v_and_or_b32 v117, 0xffff, v117, v119                      // 000000498DC8: D6570075 05DEEAFF 0000FFFF
	.long 0xd72c0077                                           // 000000498DD4: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000498DD8: 0202FCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2)                            // 000000498DE0: BF870002
	v_pk_fma_f16 v126, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498DE4: CC0E007E 0BFC0B75 0000C931
	v_lshlrev_b32_e32 v121, 16, v123                           // 000000498DF0: 30F2F690
	ds_load_2addr_b32 v[117:118], v116 offset0:128 offset1:160 // 000000498DF4: D8DCA080 75000074
	v_dot2acc_f32_f16 v67, v124, v1                            // 000000498DFC: 0486037C
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000498E00: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v64, v126, v26                           // 000000498E0C: 0480357E
	v_dot2acc_f32_f16 v62, v126, v30                           // 000000498E10: 047C3D7E
	v_dot2acc_f32_f16 v66, v126, v10                           // 000000498E14: 0484157E
	v_dot2acc_f32_f16 v68, v126, v6                            // 000000498E18: 04880D7E
	v_and_or_b32 v119, 0xffff, v119, v121                      // 000000498E1C: D6570077 05E6EEFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1)                            // 000000498E28: BF870001
	v_pk_fma_f16 v128, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498E2C: CC0E0080 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v61, v127, v13                           // 000000498E38: 047A1B7F
	v_pk_fma_f16 v127, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498E3C: CC0E007F 0BFC0B78 0000C931
	v_dot2acc_f32_f16 v63, v124, v21                           // 000000498E48: 047E2B7C
	ds_load_2addr_b32 v[120:121], v115 offset0:128 offset1:160 // 000000498E4C: D8DCA080 78000073
	v_dual_dot2acc_f32_f16 v65, v124, v17 :: v_dual_dot2acc_f32_f16 v66, v127, v11// 000000498E54: CB18237C 4142177F
	v_dual_dot2acc_f32_f16 v62, v127, v31 :: v_dual_dot2acc_f32_f16 v63, v126, v22// 000000498E5C: CB183F7F 3E3E2D7E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000498E64: BF870192
	v_dual_dot2acc_f32_f16 v64, v127, v27 :: v_dual_dot2acc_f32_f16 v65, v126, v18// 000000498E68: CB18377F 4040257E
	v_dot2acc_f32_f16 v66, v128, v12                           // 000000498E70: 04841980
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000498E74: BF870193
	v_dual_dot2acc_f32_f16 v62, v128, v32 :: v_dual_dot2acc_f32_f16 v61, v130, v14// 000000498E78: CB184180 3E3C1D82
	v_dual_dot2acc_f32_f16 v63, v127, v23 :: v_dual_dot2acc_f32_f16 v64, v128, v28// 000000498E80: CB182F7F 3F403980
	v_dot2acc_f32_f16 v68, v127, v7                            // 000000498E88: 04880F7F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000498E8C: BF870003
	v_dot2acc_f32_f16 v61, v122, v15                           // 000000498E90: 047A1F7A
	ds_load_2addr_b32 v[122:123], v114 offset0:128 offset1:160 // 000000498E94: D8DCA080 7A000072
	s_waitcnt lgkmcnt(2)                                       // 000000498E9C: BF89FC27
	v_dual_mov_b32 v119, v117 :: v_dual_dot2acc_f32_f16 v68, v128, v8// 000000498EA0: CA180175 77441180
	v_dot2acc_f32_f16 v61, v125, v16                           // 000000498EA8: 047A217D
	s_waitcnt lgkmcnt(0)                                       // 000000498EAC: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 000000498EB0: D6100081 0241197A
	v_bfe_u32 v130, v122, 8, 16                                // 000000498EB8: D6100082 0241117A
	v_bfe_u32 v131, v122, 4, 16                                // 000000498EC0: D6100083 0241097A
	v_and_b32_e32 v122, 0xffff, v122                           // 000000498EC8: 36F4F4FF 0000FFFF
	.long 0xd73d0077                                           // 000000498ED0: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 000000498ED4: 0202EF6F
	v_dot2acc_f32_f16 v63, v128, v24                           // 000000498ED8: 047E3180
	.long 0xd72c0081                                           // 000000498EDC: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000498EE0: 020302FF 83DCD12D
	.long 0xd72c0082                                           // 000000498EE8: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 000000498EEC: 020304FF 83DCD12D
	.long 0xd72c007a                                           // 000000498EF4: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 000000498EF8: 0202F4FF 83DCD12D
	v_bfe_u32 v117, v119, 12, 16                               // 000000498F00: D6100075 02411977
	v_and_b32_e32 v120, 0xffff, v119                           // 000000498F08: 36F0EEFF 0000FFFF
	v_bfe_u32 v125, v119, 8, 16                                // 000000498F10: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000498F18: D6100077 02410977
	v_sad_u8 v129, v129, 0, 0x6400                             // 000000498F20: D6220081 03FD0181 00006400
	.long 0xd72c0075                                           // 000000498F2C: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000498F30: 0202EAFF 83DCD12D
	.long 0xd72c0078                                           // 000000498F38: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000498F3C: 0202F0FF 83DCD12D
	.long 0xd72c007d                                           // 000000498F44: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000498F48: 0202FAFF 83DCD12D
	.long 0xd72c0077                                           // 000000498F50: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000498F54: 0202EEFF 83DCD12D
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000498F5C: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v65, v127, v19                           // 000000498F68: 0482277F
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000498F6C: D6220075 03FD0175 00006400
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000498F78: D6220078 03FD0178 00006400
	v_sad_u8 v125, v125, 0, 0x6400                             // 000000498F84: D622007D 03FD017D 00006400
	v_dot2acc_f32_f16 v67, v126, v2                            // 000000498F90: 0486057E
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000498F94: D6220077 03FD0177 00006400
	v_and_b32_e32 v117, 0xffff, v117                           // 000000498FA0: 36EAEAFF 0000FFFF
	v_lshlrev_b32_e32 v120, 16, v120                           // 000000498FA8: 30F0F090
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000498FAC: BF870112
	v_lshl_or_b32 v117, v125, 16, v117                         // 000000498FB0: D6560075 05D5217D
	v_and_or_b32 v119, 0xffff, v119, v120                      // 000000498FB8: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 000000498FC4: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 000000498FC8: 020306FF 83DCD12D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000498FD0: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000498FD8: D6220081 03FD0182 00006400
	v_pk_fma_f16 v124, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498FE4: CC0E007C 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v67, v127, v3                            // 000000498FF0: 0486077F
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000498FF4: CC0E0082 0BFC0B77 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000499000: BF870004
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000499004: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 00000049900C: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000499018: 30F0F490
	v_dot2acc_f32_f16 v70, v124, v29                           // 00000049901C: 048C3B7C
	v_dot2acc_f32_f16 v67, v128, v4                            // 000000499020: 04860980
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499024: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v72, v124, v25                           // 000000499030: 0490337C
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000499034: D6570075 05E2EEFF 0000FFFF
	v_dual_dot2acc_f32_f16 v70, v130, v30 :: v_dual_dot2acc_f32_f16 v71, v124, v21// 000000499040: CB183D82 46462B7C
	v_dot2acc_f32_f16 v74, v124, v9                            // 000000499048: 0494137C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049904C: BF870214
	v_dot2acc_f32_f16 v72, v130, v26                           // 000000499050: 04903582
	v_pk_fma_f16 v125, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499054: CC0E007D 0BFC0B75 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000499060: BF870224
	v_dot2acc_f32_f16 v70, v122, v31                           // 000000499064: 048C3F7A
	v_dual_dot2acc_f32_f16 v71, v130, v22 :: v_dual_dot2acc_f32_f16 v76, v124, v5// 000000499068: CB182D82 474C0B7C
	v_dual_dot2acc_f32_f16 v73, v124, v17 :: v_dual_dot2acc_f32_f16 v72, v122, v27// 000000499070: CB18237C 4948377A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000499078: BF870193
	v_dual_dot2acc_f32_f16 v70, v125, v32 :: v_dual_dot2acc_f32_f16 v69, v126, v14// 00000049907C: CB18417D 46441D7E
	v_dot2acc_f32_f16 v71, v122, v23                           // 000000499084: 048E2F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000499088: BF870224
	v_dual_dot2acc_f32_f16 v76, v130, v6 :: v_dual_mov_b32 v119, v121// 00000049908C: CB100D82 4C760179
	v_bfe_u32 v121, v123, 12, 16                               // 000000499094: D6100079 0241197B
	v_dual_dot2acc_f32_f16 v69, v127, v15 :: v_dual_dot2acc_f32_f16 v74, v130, v10// 00000049909C: CB181F7F 454A1582
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004990A4: BF870213
	v_dual_dot2acc_f32_f16 v71, v125, v24 :: v_dual_dot2acc_f32_f16 v76, v122, v7// 0000004990A8: CB18317D 474C0F7A
	.long 0xd73d0075                                           // 0000004990B0: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 0000004990B4: 0202ED6F
	v_dual_dot2acc_f32_f16 v73, v130, v18 :: v_dual_dot2acc_f32_f16 v72, v125, v28// 0000004990B8: CB182582 4948397D
	v_bfe_u32 v126, v123, 8, 16                                // 0000004990C0: D610007E 0241117B
	.long 0xd72c0079                                           // 0000004990C8: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004990CC: 0202F2FF 83DCD12D
	v_dual_dot2acc_f32_f16 v69, v128, v16 :: v_dual_dot2acc_f32_f16 v74, v122, v11// 0000004990D4: CB182180 454A177A
	v_bfe_u32 v118, v117, 12, 16                               // 0000004990DC: D6100076 02411975
	v_and_b32_e32 v119, 0xffff, v117                           // 0000004990E4: 36EEEAFF 0000FFFF
	v_bfe_u32 v120, v117, 8, 16                                // 0000004990EC: D6100078 02411175
	v_bfe_u32 v117, v117, 4, 16                                // 0000004990F4: D6100075 02410975
	v_dual_dot2acc_f32_f16 v75, v124, v1 :: v_dual_dot2acc_f32_f16 v74, v125, v12// 0000004990FC: CB18037C 4B4A197D
	.long 0xd72c0076                                           // 000000499104: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 000000499108: 0202ECFF 83DCD12D
	.long 0xd72c0077                                           // 000000499110: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000499114: 0202EEFF 83DCD12D
	.long 0xd72c0078                                           // 00000049911C: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000499120: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 000000499128: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 00000049912C: 0202EAFF 83DCD12D
	.long 0xd72c007e                                           // 000000499134: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 000000499138: 0202FCFF 83DCD12D
	v_dual_dot2acc_f32_f16 v75, v130, v2 :: v_dual_dot2acc_f32_f16 v76, v125, v8// 000000499140: CB180582 4B4C117D
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000499148: D6220079 03FD0179 00006400
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000499154: D6220076 03FD0176 00006400
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000499160: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v73, v122, v19                           // 00000049916C: 0492277A
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000499170: D6220078 03FD0178 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 00000049917C: D6220075 03FD0175 00006400
	v_and_b32_e32 v118, 0xffff, v118                           // 000000499188: 36ECECFF 0000FFFF
	v_lshlrev_b32_e32 v119, 16, v119                           // 000000499190: 30EEEE90
	v_dot2acc_f32_f16 v65, v128, v20                           // 000000499194: 04822980
	v_dot2acc_f32_f16 v75, v122, v3                            // 000000499198: 0496077A
	v_bfe_u32 v127, v123, 4, 16                                // 00000049919C: D610007F 0241097B
	v_lshl_or_b32 v118, v120, 16, v118                         // 0000004991A4: D6560076 05D92178
	v_and_or_b32 v117, 0xffff, v117, v119                      // 0000004991AC: D6570075 05DEEAFF 0000FFFF
	v_and_b32_e32 v120, 0xffff, v121                           // 0000004991B8: 36F0F2FF 0000FFFF
	v_sad_u8 v121, v126, 0, 0x6400                             // 0000004991C0: D6220079 03FD017E 00006400
	.long 0xd72c0077                                           // 0000004991CC: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 0000004991D0: 0202FEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004991D8: BF870004
	v_pk_fma_f16 v126, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004991DC: CC0E007E 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v77, v124, v13                           // 0000004991E8: 049A1B7C
	v_pk_fma_f16 v124, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004991EC: CC0E007C 0BFC0B76 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 0000004991F8: 36F6F6FF 0000FFFF
	v_lshl_or_b32 v120, v121, 16, v120                         // 000000499200: D6560078 05E12179
	ds_load_2addr_b32 v[117:118], v116 offset0:192 offset1:224 // 000000499208: D8DCE0C0 75000074
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000499210: D6220077 03FD0177 00006400
	v_dot2acc_f32_f16 v80, v124, v25                           // 00000049921C: 04A0337C
	.long 0xd72c007b                                           // 000000499220: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 000000499224: 0202F6FF 83DCD12D
	v_pk_fma_f16 v127, v120, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000049922C: CC0E007F 0BFC0B78 0000C931
	v_dot2acc_f32_f16 v82, v124, v9                            // 000000499238: 04A4137C
	v_dot2acc_f32_f16 v84, v124, v5                            // 00000049923C: 04A80B7C
	v_dot2acc_f32_f16 v80, v126, v26                           // 000000499240: 04A0357E
	v_dot2acc_f32_f16 v77, v130, v14                           // 000000499244: 049A1D82
	v_dual_dot2acc_f32_f16 v73, v125, v20 :: v_dual_dot2acc_f32_f16 v78, v124, v29// 000000499248: CB18297D 494E3B7C
	v_sad_u8 v123, v123, 0, 0x6400                             // 000000499250: D622007B 03FD017B 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049925C: BF8701A4
	v_dot2acc_f32_f16 v80, v127, v27                           // 000000499260: 04A0377F
	v_dual_dot2acc_f32_f16 v84, v126, v6 :: v_dual_dot2acc_f32_f16 v75, v125, v4// 000000499264: CB180D7E 544A097D
	v_dual_dot2acc_f32_f16 v78, v126, v30 :: v_dual_lshlrev_b32 v121, 16, v123// 00000049926C: CB223D7E 4E78F690
	v_dual_dot2acc_f32_f16 v79, v124, v21 :: v_dual_dot2acc_f32_f16 v82, v126, v10// 000000499274: CB182B7C 4F52157E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049927C: BF870193
	v_dot2acc_f32_f16 v84, v127, v7                            // 000000499280: 04A80F7F
	v_dot2acc_f32_f16 v78, v127, v31                           // 000000499284: 049C3F7F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000499288: BF870004
	v_and_or_b32 v119, 0xffff, v119, v121                      // 00000049928C: D6570077 05E6EEFF 0000FFFF
	ds_load_2addr_b32 v[120:121], v115 offset0:192 offset1:224 // 000000499298: D8DCE0C0 78000073
	v_dual_dot2acc_f32_f16 v79, v126, v22 :: v_dual_dot2acc_f32_f16 v82, v127, v11// 0000004992A0: CB182D7E 4F52177F
	v_pk_fma_f16 v128, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004992A8: CC0E0080 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v77, v122, v15                           // 0000004992B4: 049A1F7A
	ds_load_2addr_b32 v[122:123], v114 offset0:192 offset1:224 // 0000004992B8: D8DCE0C0 7A000072
	s_waitcnt lgkmcnt(2)                                       // 0000004992C0: BF89FC27
	v_mov_b32_e32 v119, v117                                   // 0000004992C4: 7EEE0375
	v_dot2acc_f32_f16 v83, v124, v1                            // 0000004992C8: 04A6037C
	v_dot2acc_f32_f16 v80, v128, v28                           // 0000004992CC: 04A03980
	v_dot2acc_f32_f16 v77, v125, v16                           // 0000004992D0: 049A217D
	v_dual_dot2acc_f32_f16 v79, v127, v23 :: v_dual_dot2acc_f32_f16 v82, v128, v12// 0000004992D4: CB182F7F 4F521980
	v_dot2acc_f32_f16 v78, v128, v32                           // 0000004992DC: 049C4180
	v_dot2acc_f32_f16 v84, v128, v8                            // 0000004992E0: 04A81180
	s_waitcnt lgkmcnt(1)                                       // 0000004992E4: BF89FC17
	.long 0xd73d0077                                           // 0000004992E8: D73D0077
	v_cndmask_b32_e32 v1, v111, v119, vcc_lo                   // 0000004992EC: 0202EF6F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004992F0: BF870001
	v_dual_dot2acc_f32_f16 v81, v124, v17 :: v_dual_and_b32 v120, 0xffff, v119// 0000004992F4: CB24237C 5178EEFF 0000FFFF
	v_bfe_u32 v117, v119, 12, 16                               // 000000499300: D6100075 02411977
	v_bfe_u32 v125, v119, 8, 16                                // 000000499308: D610007D 02411177
	v_bfe_u32 v119, v119, 4, 16                                // 000000499310: D6100077 02410977
	s_waitcnt lgkmcnt(0)                                       // 000000499318: BF89FC07
	v_bfe_u32 v129, v122, 12, 16                               // 00000049931C: D6100081 0241197A
	.long 0xd72c0078                                           // 000000499324: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v120, vcc_lo             // 000000499328: 0202F0FF 83DCD12D
	.long 0xd72c0075                                           // 000000499330: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000499334: 0202EAFF 83DCD12D
	v_bfe_u32 v130, v122, 8, 16                                // 00000049933C: D6100082 0241117A
	.long 0xd72c0077                                           // 000000499344: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000499348: 0202EEFF 83DCD12D
	.long 0xd72c007d                                           // 000000499350: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 000000499354: 0202FAFF 83DCD12D
	v_bfe_u32 v131, v122, 4, 16                                // 00000049935C: D6100083 0241097A
	.long 0xd72c0081                                           // 000000499364: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 000000499368: 020302FF 83DCD12D
	v_and_b32_e32 v122, 0xffff, v122                           // 000000499370: 36F4F4FF 0000FFFF
	v_sad_u8 v120, v120, 0, 0x6400                             // 000000499378: D6220078 03FD0178 00006400
	v_sad_u8 v117, v117, 0, 0x6400                             // 000000499384: D6220075 03FD0175 00006400
	v_dot2acc_f32_f16 v81, v126, v18                           // 000000499390: 04A2257E
	v_sad_u8 v119, v119, 0, 0x6400                             // 000000499394: D6220077 03FD0177 00006400
	.long 0xd72c0082                                           // 0000004993A0: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 0000004993A4: 020304FF 83DCD12D
	v_lshlrev_b32_e32 v120, 16, v120                           // 0000004993AC: 30F0F090
	.long 0xd72c007a                                           // 0000004993B0: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v122, vcc_lo             // 0000004993B4: 0202F4FF 83DCD12D
	v_and_b32_e32 v117, 0xffff, v117                           // 0000004993BC: 36EAEAFF 0000FFFF
	v_sad_u8 v125, v125, 0, 0x6400                             // 0000004993C4: D622007D 03FD017D 00006400
	v_sad_u8 v129, v129, 0, 0x6400                             // 0000004993D0: D6220081 03FD0181 00006400
	v_and_or_b32 v119, 0xffff, v119, v120                      // 0000004993DC: D6570077 05E2EEFF 0000FFFF
	.long 0xd72c0078                                           // 0000004993E8: D72C0078
	v_cndmask_b32_e32 v1, 0x83dcd12d, v131, vcc_lo             // 0000004993EC: 020306FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004993F4: BF870214
	v_lshl_or_b32 v117, v125, 16, v117                         // 0000004993F8: D6560075 05D5217D
	v_and_b32_e32 v125, 0xffff, v129                           // 000000499400: 36FB02FF 0000FFFF
	v_sad_u8 v129, v130, 0, 0x6400                             // 000000499408: D6220081 03FD0182 00006400
	v_sad_u8 v122, v122, 0, 0x6400                             // 000000499414: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v81, v127, v19                           // 000000499420: 04A2277F
	v_pk_fma_f16 v130, v119, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499424: CC0E0082 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v85, v124, v13                           // 000000499430: 04AA1B7C
	v_pk_fma_f16 v124, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499434: CC0E007C 0BFC0B75 0000C931
	v_lshl_or_b32 v117, v129, 16, v125                         // 000000499440: D6560075 05F52181
	v_sad_u8 v119, v120, 0, 0x6400                             // 000000499448: D6220077 03FD0178 00006400
	v_lshlrev_b32_e32 v120, 16, v122                           // 000000499454: 30F0F490
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000499458: BF870214
	v_dual_dot2acc_f32_f16 v83, v126, v2 :: v_dual_dot2acc_f32_f16 v86, v124, v29// 00000049945C: CB18057E 53563B7C
	v_pk_fma_f16 v122, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499464: CC0E007A 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v88, v124, v25                           // 000000499470: 04B0337C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000499474: BF870234
	v_and_or_b32 v117, 0xffff, v119, v120                      // 000000499478: D6570075 05E2EEFF 0000FFFF
	v_mov_b32_e32 v119, v121                                   // 000000499484: 7EEE0379
	v_dual_dot2acc_f32_f16 v83, v127, v3 :: v_dual_dot2acc_f32_f16 v90, v124, v9// 000000499488: CB18077F 535A137C
	v_dot2acc_f32_f16 v88, v130, v26                           // 000000499490: 04B03582
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000499494: BF870214
	v_pk_fma_f16 v120, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 000000499498: CC0E0078 0BFC0B75 0000C931
	.long 0xd73d0075                                           // 0000004994A4: D73D0075
	v_cndmask_b32_e32 v1, v111, v118, vcc_lo                   // 0000004994A8: 0202ED6F
	v_dot2acc_f32_f16 v85, v126, v14                           // 0000004994AC: 04AA1D7E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004994B0: BF870004
	v_dual_dot2acc_f32_f16 v87, v124, v21 :: v_dual_dot2acc_f32_f16 v88, v122, v27// 0000004994B4: CB182B7C 5758377A
	v_dot2acc_f32_f16 v92, v124, v5                            // 0000004994BC: 04B80B7C
	v_dot2acc_f32_f16 v89, v124, v17                           // 0000004994C0: 04B2237C
	v_bfe_u32 v118, v117, 12, 16                               // 0000004994C4: D6100076 02411975
	v_bfe_u32 v121, v117, 8, 16                                // 0000004994CC: D6100079 02411175
	v_dot2acc_f32_f16 v85, v127, v15                           // 0000004994D4: 04AA1F7F
	v_dual_dot2acc_f32_f16 v90, v130, v10 :: v_dual_and_b32 v119, 0xffff, v117// 0000004994D8: CB241582 5A76EAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004994E4: BF870214
	.long 0xd72c0076                                           // 0000004994E8: D72C0076
	v_cndmask_b32_e32 v1, 0x83dcd12d, v118, vcc_lo             // 0000004994EC: 0202ECFF 83DCD12D
	.long 0xd72c0079                                           // 0000004994F4: D72C0079
	v_cndmask_b32_e32 v1, 0x83dcd12d, v121, vcc_lo             // 0000004994F8: 0202F2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000499500: BF870214
	v_dot2acc_f32_f16 v85, v128, v16                           // 000000499504: 04AA2180
	v_dual_dot2acc_f32_f16 v91, v124, v1 :: v_dual_dot2acc_f32_f16 v90, v122, v11// 000000499508: CB18037C 5B5A177A
	v_dot2acc_f32_f16 v93, v124, v13                           // 000000499510: 04BA1B7C
	v_bfe_u32 v117, v117, 4, 16                                // 000000499514: D6100075 02410975
	.long 0xd72c0077                                           // 00000049951C: D72C0077
	v_cndmask_b32_e32 v1, 0x83dcd12d, v119, vcc_lo             // 000000499520: 0202EEFF 83DCD12D
	v_sad_u8 v118, v118, 0, 0x6400                             // 000000499528: D6220076 03FD0176 00006400
	v_sad_u8 v121, v121, 0, 0x6400                             // 000000499534: D6220079 03FD0179 00006400
	v_bfe_u32 v124, v123, 12, 16                               // 000000499540: D610007C 0241197B
	v_bfe_u32 v125, v123, 8, 16                                // 000000499548: D610007D 0241117B
	.long 0xd72c0075                                           // 000000499550: D72C0075
	v_cndmask_b32_e32 v1, 0x83dcd12d, v117, vcc_lo             // 000000499554: 0202EAFF 83DCD12D
	v_and_b32_e32 v118, 0xffff, v118                           // 00000049955C: 36ECECFF 0000FFFF
	v_bfe_u32 v126, v123, 4, 16                                // 000000499564: D610007E 0241097B
	.long 0xd72c007c                                           // 00000049956C: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 000000499570: 0202F8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v87, v130, v22 :: v_dual_dot2acc_f32_f16 v88, v120, v28// 000000499578: CB182D82 57583978
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000499580: BF870234
	v_lshl_or_b32 v118, v121, 16, v118                         // 000000499584: D6560076 05D92179
	v_sad_u8 v119, v119, 0, 0x6400                             // 00000049958C: D6220077 03FD0177 00006400
	.long 0xd72c007d                                           // 000000499598: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000049959C: 0202FAFF 83DCD12D
	v_dual_dot2acc_f32_f16 v87, v122, v23 :: v_dual_dot2acc_f32_f16 v90, v120, v12// 0000004995A4: CB182F7A 575A1978
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000004995AC: BF8701B4
	v_pk_fma_f16 v118, v118, s5, 0xc931 op_sel_hi:[1,0,0]      // 0000004995B0: CC0E0076 0BFC0B76 0000C931
	v_dual_dot2acc_f32_f16 v92, v130, v6 :: v_dual_and_b32 v123, 0xffff, v123// 0000004995BC: CB240D82 5C7AF6FF 0000FFFF
	v_sad_u8 v117, v117, 0, 0x6400                             // 0000004995C8: D6220075 03FD0175 00006400
	v_dual_dot2acc_f32_f16 v98, v118, v9 :: v_dual_lshlrev_b32 v119, 16, v119// 0000004995D4: CB221376 6276EE90
	v_dot2acc_f32_f16 v94, v118, v29                           // 0000004995DC: 04BC3B76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000004995E0: BF870254
	.long 0xd72c007b                                           // 0000004995E4: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 0000004995E8: 0202F6FF 83DCD12D
	v_sad_u8 v124, v124, 0, 0x6400                             // 0000004995F0: D622007C 03FD017C 00006400
	v_dual_dot2acc_f32_f16 v87, v120, v24 :: v_dual_dot2acc_f32_f16 v92, v122, v7// 0000004995FC: CB183178 575C0F7A
	v_dot2acc_f32_f16 v89, v130, v18                           // 000000499604: 04B22582
	v_and_or_b32 v117, 0xffff, v117, v119                      // 000000499608: D6570075 05DEEAFF 0000FFFF
	v_dual_dot2acc_f32_f16 v100, v118, v5 :: v_dual_and_b32 v119, 0xffff, v124// 000000499614: CB240B76 6476F8FF 0000FFFF
	v_sad_u8 v121, v123, 0, 0x6400                             // 000000499620: D6220079 03FD017B 00006400
	v_sad_u8 v123, v125, 0, 0x6400                             // 00000049962C: D622007B 03FD017D 00006400
	v_dot2acc_f32_f16 v92, v120, v8                            // 000000499638: 04B81178
	v_pk_fma_f16 v117, v117, s5, 0xc931 op_sel_hi:[1,0,0]      // 00000049963C: CC0E0075 0BFC0B75 0000C931
	v_dot2acc_f32_f16 v89, v122, v19                           // 000000499648: 04B2277A
	v_dual_dot2acc_f32_f16 v79, v128, v24 :: v_dual_dot2acc_f32_f16 v86, v130, v30// 00000049964C: CB183180 4F563D82
	v_lshl_or_b32 v119, v123, 16, v119                         // 000000499654: D6560077 05DD217B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049965C: BF870234
	v_dual_dot2acc_f32_f16 v98, v117, v10 :: v_dual_lshlrev_b32 v121, 16, v121// 000000499660: CB221575 6278F290
	v_dot2acc_f32_f16 v96, v118, v25                           // 000000499668: 04C03376
	v_dual_dot2acc_f32_f16 v94, v117, v30 :: v_dual_dot2acc_f32_f16 v89, v120, v20// 00000049966C: CB183D75 5E582978
	v_pk_fma_f16 v25, v119, s5, 0xc931 op_sel_hi:[1,0,0]       // 000000499674: CC0E0019 0BFC0B77 0000C931
	v_dot2acc_f32_f16 v91, v130, v2                            // 000000499680: 04B60582
	v_dot2acc_f32_f16 v93, v130, v14                           // 000000499684: 04BA1D82
	v_dual_dot2acc_f32_f16 v83, v128, v4 :: v_dual_dot2acc_f32_f16 v86, v122, v31// 000000499688: CB180980 53563F7A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000499690: BF870214
	v_dot2acc_f32_f16 v94, v25, v31                            // 000000499694: 04BC3F19
	v_dual_dot2acc_f32_f16 v91, v122, v3 :: v_dual_dot2acc_f32_f16 v96, v117, v26// 000000499698: CB18077A 5B603575
	v_dot2acc_f32_f16 v98, v25, v11                            // 0000004996A0: 04C41719
	v_dual_dot2acc_f32_f16 v93, v122, v15 :: v_dual_dot2acc_f32_f16 v100, v117, v6// 0000004996A4: CB181F7A 5D640D75
	.long 0xd72c007a                                           // 0000004996AC: D72C007A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 0000004996B0: 0202FCFF 83DCD12D
	v_dot2acc_f32_f16 v40, v118, v13                           // 0000004996B8: 04501B76
	v_dot2acc_f32_f16 v95, v118, v21                           // 0000004996BC: 04BE2B76
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000004996C0: BF870224
	v_dot2acc_f32_f16 v93, v120, v16                           // 0000004996C4: 04BA2178
	v_dual_dot2acc_f32_f16 v97, v118, v17 :: v_dual_dot2acc_f32_f16 v100, v25, v7// 0000004996C8: CB182376 61640F19
	v_dual_dot2acc_f32_f16 v40, v117, v14 :: v_dual_dot2acc_f32_f16 v99, v118, v1// 0000004996D0: CB181D75 28620376
	v_sad_u8 v122, v122, 0, 0x6400                             // 0000004996D8: D622007A 03FD017A 00006400
	v_dot2acc_f32_f16 v95, v117, v22                           // 0000004996E4: 04BE2D75
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004996E8: BF870214
	v_dot2acc_f32_f16 v97, v117, v18                           // 0000004996EC: 04C22575
	v_dot2acc_f32_f16 v40, v25, v15                            // 0000004996F0: 04501F19
	v_dot2acc_f32_f16 v99, v117, v2                            // 0000004996F4: 04C60575
	v_and_or_b32 v21, 0xffff, v122, v121                       // 0000004996F8: D6570015 05E6F4FF 0000FFFF
	v_dot2acc_f32_f16 v81, v128, v20                           // 000000499704: 04A22980
	v_dual_dot2acc_f32_f16 v91, v120, v4 :: v_dual_dot2acc_f32_f16 v96, v25, v27// 000000499708: CB180978 5B603719
	v_dot2acc_f32_f16 v95, v25, v23                            // 000000499710: 04BE2F19
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000499714: BF8701C4
	v_pk_fma_f16 v21, v21, s5, 0xc931 op_sel_hi:[1,0,0]        // 000000499718: CC0E0015 0BFC0B15 0000C931
	v_add_nc_u32_e32 v113, 1, v113                             // 000000499724: 4AE2E281
	v_dot2acc_f32_f16 v97, v25, v19                            // 000000499728: 04C22719
	v_dual_dot2acc_f32_f16 v99, v25, v3 :: v_dual_dot2acc_f32_f16 v86, v120, v32// 00000049972C: CB180719 63564178
	v_dual_dot2acc_f32_f16 v98, v21, v12 :: v_dual_add_nc_u32 v1, v112, v113// 000000499734: CB201915 6200E370
	v_dot2acc_f32_f16 v100, v21, v8                            // 00000049973C: 04C81115
	v_dot2acc_f32_f16 v94, v21, v32                            // 000000499740: 04BC4115
	v_dot2acc_f32_f16 v95, v21, v24                            // 000000499744: 04BE3115
	v_dot2acc_f32_f16 v96, v21, v28                            // 000000499748: 04C03915
	v_cmp_eq_u32_e32 vcc_lo, 1, v1                             // 00000049974C: 7C940281
	v_dot2acc_f32_f16 v97, v21, v20                            // 000000499750: 04C22915
	v_dot2acc_f32_f16 v99, v21, v4                             // 000000499754: 04C60915
	v_dot2acc_f32_f16 v40, v21, v16                            // 000000499758: 04502115
	s_or_b32 s4, vcc_lo, s4                                    // 00000049975C: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000499760: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000499764: 917E047E
	s_cbranch_execz 34                                         // 000000499768: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ef4>
	s_mov_b32 s0, exec_lo                                      // 00000049976C: BE80007E
	s_waitcnt vmcnt(6)                                         // 000000499770: BF891BF7
	ds_store_2addr_b32 v114, v102, v103 offset1:32             // 000000499774: D8382000 00676672
	s_waitcnt vmcnt(4)                                         // 00000049977C: BF8913F7
	ds_store_2addr_b32 v114, v104, v105 offset0:64 offset1:96  // 000000499780: D8386040 00696872
	s_waitcnt vmcnt(2)                                         // 000000499788: BF890BF7
	ds_store_2addr_b32 v114, v106, v107 offset0:128 offset1:160// 00000049978C: D838A080 006B6A72
	s_waitcnt vmcnt(0)                                         // 000000499794: BF8903F7
	ds_store_2addr_b32 v114, v108, v109 offset0:192 offset1:224// 000000499798: D838E0C0 006D6C72
	.long 0xd4c1007e                                           // 0000004997A0: D4C1007E
	v_cndmask_b32_e32 v1, v113, v101, vcc_lo                   // 0000004997A4: 0202CB71
	s_cbranch_execz 64376                                      // 0000004997A8: BFA5FB78 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	s_clause 0x7                                               // 0000004997AC: BF850007
	global_load_b32 v102, v[33:34], off                        // 0000004997B0: DC520000 667C0021
	global_load_b32 v103, v[33:34], off offset:128             // 0000004997B8: DC520080 677C0021
	global_load_b32 v104, v[33:34], off offset:256             // 0000004997C0: DC520100 687C0021
	global_load_b32 v105, v[33:34], off offset:384             // 0000004997C8: DC520180 697C0021
	global_load_b32 v106, v[33:34], off offset:512             // 0000004997D0: DC520200 6A7C0021
	global_load_b32 v107, v[33:34], off offset:640             // 0000004997D8: DC520280 6B7C0021
	global_load_b32 v108, v[33:34], off offset:768             // 0000004997E0: DC520300 6C7C0021
	global_load_b32 v109, v[33:34], off offset:896             // 0000004997E8: DC520380 6D7C0021
	s_branch 64358                                             // 0000004997F0: BFA0FB66 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc8c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000004997F4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004997F8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004997FC: 8C7E017E
	v_dual_mov_b32 v1, v37 :: v_dual_mov_b32 v2, v39           // 000000499800: CA100125 01020127
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v41           // 000000499808: CA100126 03040129
	v_dual_mov_b32 v5, v42 :: v_dual_mov_b32 v6, v43           // 000000499810: CA10012A 0506012B
	v_dual_mov_b32 v7, v44 :: v_dual_mov_b32 v8, v45           // 000000499818: CA10012C 0708012D
	v_dual_mov_b32 v9, v46 :: v_dual_mov_b32 v10, v47          // 000000499820: CA10012E 090A012F
	v_dual_mov_b32 v11, v48 :: v_dual_mov_b32 v12, v49         // 000000499828: CA100130 0B0C0131
	v_dual_mov_b32 v13, v50 :: v_dual_mov_b32 v14, v51         // 000000499830: CA100132 0D0E0133
	v_dual_mov_b32 v15, v52 :: v_dual_mov_b32 v16, v53         // 000000499838: CA100134 0F100135
	v_dual_mov_b32 v17, v54 :: v_dual_mov_b32 v18, v55         // 000000499840: CA100136 11120137
	v_dual_mov_b32 v19, v56 :: v_dual_mov_b32 v20, v57         // 000000499848: CA100138 13140139
	v_dual_mov_b32 v21, v58 :: v_dual_mov_b32 v22, v59         // 000000499850: CA10013A 1516013B
	v_dual_mov_b32 v23, v60 :: v_dual_mov_b32 v24, v61         // 000000499858: CA10013C 1718013D
	v_dual_mov_b32 v25, v62 :: v_dual_mov_b32 v26, v63         // 000000499860: CA10013E 191A013F
	v_dual_mov_b32 v27, v64 :: v_dual_mov_b32 v28, v65         // 000000499868: CA100140 1B1C0141
	v_dual_mov_b32 v29, v66 :: v_dual_mov_b32 v30, v67         // 000000499870: CA100142 1D1E0143
	v_dual_mov_b32 v31, v68 :: v_dual_mov_b32 v32, v69         // 000000499878: CA100144 1F200145
	v_dual_mov_b32 v33, v70 :: v_dual_mov_b32 v34, v71         // 000000499880: CA100146 21220147
	s_waitcnt vmcnt(7)                                         // 000000499888: BF891FF7
	v_dual_mov_b32 v101, v72 :: v_dual_mov_b32 v102, v73       // 00000049988C: CA100148 65660149
	s_waitcnt vmcnt(5)                                         // 000000499894: BF8917F7
	v_dual_mov_b32 v103, v74 :: v_dual_mov_b32 v104, v75       // 000000499898: CA10014A 6768014B
	s_waitcnt vmcnt(3)                                         // 0000004998A0: BF890FF7
	v_dual_mov_b32 v105, v76 :: v_dual_mov_b32 v106, v77       // 0000004998A4: CA10014C 696A014D
	s_waitcnt vmcnt(1)                                         // 0000004998AC: BF8907F7
	v_dual_mov_b32 v107, v78 :: v_dual_mov_b32 v108, v79       // 0000004998B0: CA10014E 6B6C014F
	s_waitcnt vmcnt(0)                                         // 0000004998B8: BF8903F7
	v_dual_mov_b32 v109, v80 :: v_dual_mov_b32 v110, v81       // 0000004998BC: CA100150 6D6E0151
	v_dual_mov_b32 v111, v82 :: v_dual_mov_b32 v112, v83       // 0000004998C4: CA100152 6F700153
	v_dual_mov_b32 v113, v84 :: v_dual_mov_b32 v114, v85       // 0000004998CC: CA100154 71720155
	v_dual_mov_b32 v115, v86 :: v_dual_mov_b32 v116, v87       // 0000004998D4: CA100156 73740157
	v_dual_mov_b32 v117, v88 :: v_dual_mov_b32 v118, v89       // 0000004998DC: CA100158 75760159
	v_dual_mov_b32 v119, v90 :: v_dual_mov_b32 v120, v91       // 0000004998E4: CA10015A 7778015B
	v_dual_mov_b32 v121, v92 :: v_dual_mov_b32 v122, v93       // 0000004998EC: CA10015C 797A015D
	v_dual_mov_b32 v123, v94 :: v_dual_mov_b32 v124, v95       // 0000004998F4: CA10015E 7B7C015F
	v_dual_mov_b32 v125, v96 :: v_dual_mov_b32 v126, v97       // 0000004998FC: CA100160 7D7E0161
	v_dual_mov_b32 v127, v98 :: v_dual_mov_b32 v128, v99       // 000000499904: CA100162 7F800163
	v_mov_b32_e32 v129, v100                                   // 00000049990C: 7F020364
	v_mov_b32_e32 v130, v40                                    // 000000499910: 7F040328
	s_mov_b32 s0, 0x76543210                                   // 000000499914: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049991C: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000499920: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000049992C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000499938: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000499944: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000499950: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000049995C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000499968: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 000000499974: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000499980: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000049998C: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000499998: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 0000004999A4: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000004999B0: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000004999BC: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000004999C8: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000004999D4: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000004999E0: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000004999EC: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 0000004999F8: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 000000499A04: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000499A10: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000499A1C: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000499A28: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 000000499A34: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000499A40: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000499A4C: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 000000499A58: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 000000499A64: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 000000499A70: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 000000499A7C: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 000000499A88: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 000000499A94: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 000000499AA0: D65C0021 03FC0121 FEDCBA98
	v_permlanex16_b32 v34, v34, s0, 0xfedcba98                 // 000000499AAC: D65C0022 03FC0122 FEDCBA98
	v_permlanex16_b32 v101, v101, s0, 0xfedcba98               // 000000499AB8: D65C0065 03FC0165 FEDCBA98
	v_permlanex16_b32 v102, v102, s0, 0xfedcba98               // 000000499AC4: D65C0066 03FC0166 FEDCBA98
	v_permlanex16_b32 v103, v103, s0, 0xfedcba98               // 000000499AD0: D65C0067 03FC0167 FEDCBA98
	v_permlanex16_b32 v104, v104, s0, 0xfedcba98               // 000000499ADC: D65C0068 03FC0168 FEDCBA98
	v_permlanex16_b32 v105, v105, s0, 0xfedcba98               // 000000499AE8: D65C0069 03FC0169 FEDCBA98
	v_permlanex16_b32 v106, v106, s0, 0xfedcba98               // 000000499AF4: D65C006A 03FC016A FEDCBA98
	v_permlanex16_b32 v107, v107, s0, 0xfedcba98               // 000000499B00: D65C006B 03FC016B FEDCBA98
	v_permlanex16_b32 v108, v108, s0, 0xfedcba98               // 000000499B0C: D65C006C 03FC016C FEDCBA98
	v_permlanex16_b32 v109, v109, s0, 0xfedcba98               // 000000499B18: D65C006D 03FC016D FEDCBA98
	v_permlanex16_b32 v110, v110, s0, 0xfedcba98               // 000000499B24: D65C006E 03FC016E FEDCBA98
	v_permlanex16_b32 v111, v111, s0, 0xfedcba98               // 000000499B30: D65C006F 03FC016F FEDCBA98
	v_permlanex16_b32 v112, v112, s0, 0xfedcba98               // 000000499B3C: D65C0070 03FC0170 FEDCBA98
	v_permlanex16_b32 v113, v113, s0, 0xfedcba98               // 000000499B48: D65C0071 03FC0171 FEDCBA98
	v_permlanex16_b32 v114, v114, s0, 0xfedcba98               // 000000499B54: D65C0072 03FC0172 FEDCBA98
	v_permlanex16_b32 v115, v115, s0, 0xfedcba98               // 000000499B60: D65C0073 03FC0173 FEDCBA98
	v_permlanex16_b32 v116, v116, s0, 0xfedcba98               // 000000499B6C: D65C0074 03FC0174 FEDCBA98
	v_permlanex16_b32 v117, v117, s0, 0xfedcba98               // 000000499B78: D65C0075 03FC0175 FEDCBA98
	v_permlanex16_b32 v118, v118, s0, 0xfedcba98               // 000000499B84: D65C0076 03FC0176 FEDCBA98
	v_permlanex16_b32 v119, v119, s0, 0xfedcba98               // 000000499B90: D65C0077 03FC0177 FEDCBA98
	v_permlanex16_b32 v120, v120, s0, 0xfedcba98               // 000000499B9C: D65C0078 03FC0178 FEDCBA98
	v_permlanex16_b32 v121, v121, s0, 0xfedcba98               // 000000499BA8: D65C0079 03FC0179 FEDCBA98
	v_permlanex16_b32 v122, v122, s0, 0xfedcba98               // 000000499BB4: D65C007A 03FC017A FEDCBA98
	v_permlanex16_b32 v123, v123, s0, 0xfedcba98               // 000000499BC0: D65C007B 03FC017B FEDCBA98
	v_permlanex16_b32 v124, v124, s0, 0xfedcba98               // 000000499BCC: D65C007C 03FC017C FEDCBA98
	v_permlanex16_b32 v125, v125, s0, 0xfedcba98               // 000000499BD8: D65C007D 03FC017D FEDCBA98
	v_permlanex16_b32 v126, v126, s0, 0xfedcba98               // 000000499BE4: D65C007E 03FC017E FEDCBA98
	v_permlanex16_b32 v127, v127, s0, 0xfedcba98               // 000000499BF0: D65C007F 03FC017F FEDCBA98
	v_permlanex16_b32 v128, v128, s0, 0xfedcba98               // 000000499BFC: D65C0080 03FC0180 FEDCBA98
	v_permlanex16_b32 v129, v129, s0, 0xfedcba98               // 000000499C08: D65C0081 03FC0181 FEDCBA98
	v_permlanex16_b32 v130, v130, s0, 0xfedcba98               // 000000499C14: D65C0082 03FC0182 FEDCBA98
	.long 0xd44c0000                                           // 000000499C20: D44C0000
	v_cndmask_b32_e32 v1, 16, v36, vcc_lo                      // 000000499C24: 02024890
	s_barrier                                                  // 000000499C28: BFBD0000
	buffer_gl0_inv                                             // 000000499C2C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000499C34: BE812000
	s_cbranch_execz 138                                        // 000000499C38: BFA5008A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2564>
	v_dual_add_f32 v7, v44, v7 :: v_dual_lshlrev_b32 v36, 2, v36// 000000499C3C: C9220F2C 07244882
	v_dual_add_f32 v74, v74, v103 :: v_dual_add_f32 v1, v37, v1// 000000499C44: C908CF4A 4A000325
	v_dual_add_f32 v10, v47, v10 :: v_dual_add_f32 v9, v46, v9 // 000000499C4C: C908152F 0A08132E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000499C54: BF870243
	v_lshl_or_b32 v36, v35, 12, v36                            // 000000499C58: D6560024 04911923
	v_add_f32_e32 v2, v39, v2                                  // 000000499C60: 06040527
	v_dual_add_f32 v72, v72, v101 :: v_dual_add_f32 v3, v38, v3// 000000499C64: C908CB48 48020726
	v_dual_add_f32 v12, v49, v12 :: v_dual_add_f32 v11, v48, v11// 000000499C6C: C9081931 0C0A1730
	v_dual_add_f32 v6, v43, v6 :: v_dual_add_nc_u32 v37, 0x400, v36// 000000499C74: C9200D2B 062448FF 00000400
	v_add_f32_e32 v4, v41, v4                                  // 000000499C80: 06080929
	v_dual_add_f32 v14, v51, v14 :: v_dual_add_f32 v13, v50, v13// 000000499C84: C9081D33 0E0C1B32
	v_dual_add_f32 v8, v45, v8 :: v_dual_add_f32 v5, v42, v5   // 000000499C8C: C908112D 08040B2A
	ds_store_2addr_b32 v36, v1, v9 offset1:16                  // 000000499C94: D8381000 00090124
	v_add_nc_u32_e32 v1, 0x800, v36                            // 000000499C9C: 4A0248FF 00000800
	v_dual_add_f32 v16, v53, v16 :: v_dual_add_f32 v15, v52, v15// 000000499CA4: C9082135 100E1F34
	ds_store_2addr_b32 v36, v2, v10 offset0:128 offset1:144    // 000000499CAC: D8389080 000A0224
	v_add_nc_u32_e32 v2, 0xc00, v36                            // 000000499CB4: 4A0448FF 00000C00
	v_dual_add_f32 v40, v40, v130 :: v_dual_add_f32 v99, v99, v128// 000000499CBC: C9090528 28630163
	v_dual_add_f32 v100, v100, v129 :: v_dual_add_f32 v97, v97, v126// 000000499CC4: C9090364 6460FD61
	v_dual_add_f32 v98, v98, v127 :: v_dual_add_f32 v95, v95, v124// 000000499CCC: C908FF62 625EF95F
	v_dual_add_f32 v96, v96, v125 :: v_dual_add_f32 v93, v93, v122// 000000499CD4: C908FB60 605CF55D
	v_dual_add_f32 v94, v94, v123 :: v_dual_add_f32 v91, v91, v120// 000000499CDC: C908F75E 5E5AF15B
	v_dual_add_f32 v92, v92, v121 :: v_dual_add_f32 v89, v89, v118// 000000499CE4: C908F35C 5C58ED59
	v_dual_add_f32 v90, v90, v119 :: v_dual_add_f32 v87, v87, v116// 000000499CEC: C908EF5A 5A56E957
	v_dual_add_f32 v88, v88, v117 :: v_dual_add_f32 v85, v85, v114// 000000499CF4: C908EB58 5854E555
	v_dual_add_f32 v86, v86, v115 :: v_dual_add_f32 v83, v83, v112// 000000499CFC: C908E756 5652E153
	v_dual_add_f32 v84, v84, v113 :: v_dual_add_f32 v81, v81, v110// 000000499D04: C908E354 5450DD51
	v_dual_add_f32 v82, v82, v111 :: v_dual_add_f32 v79, v79, v108// 000000499D0C: C908DF52 524ED94F
	v_dual_add_f32 v80, v80, v109 :: v_dual_add_f32 v77, v77, v106// 000000499D14: C908DB50 504CD54D
	v_dual_add_f32 v78, v78, v107 :: v_dual_add_f32 v75, v75, v104// 000000499D1C: C908D74E 4E4AD14B
	v_dual_add_f32 v76, v76, v105 :: v_dual_add_f32 v73, v73, v102// 000000499D24: C908D34C 4C48CD49
	v_dual_add_f32 v34, v71, v34 :: v_dual_add_f32 v33, v70, v33// 000000499D2C: C9084547 22204346
	v_dual_add_f32 v32, v69, v32 :: v_dual_add_f32 v31, v68, v31// 000000499D34: C9084145 201E3F44
	v_dual_add_f32 v30, v67, v30 :: v_dual_add_f32 v29, v66, v29// 000000499D3C: C9083D43 1E1C3B42
	v_dual_add_f32 v28, v65, v28 :: v_dual_add_f32 v27, v64, v27// 000000499D44: C9083941 1C1A3740
	v_dual_add_f32 v26, v63, v26 :: v_dual_add_f32 v25, v62, v25// 000000499D4C: C908353F 1A18333E
	v_dual_add_f32 v24, v61, v24 :: v_dual_add_f32 v23, v60, v23// 000000499D54: C908313D 18162F3C
	v_dual_add_f32 v22, v59, v22 :: v_dual_add_f32 v21, v58, v21// 000000499D5C: C9082D3B 16142B3A
	v_dual_add_f32 v20, v57, v20 :: v_dual_add_f32 v19, v56, v19// 000000499D64: C9082939 14122738
	v_dual_add_f32 v18, v55, v18 :: v_dual_add_f32 v17, v54, v17// 000000499D6C: C9082537 12102336
	ds_store_2addr_b32 v37, v3, v11 offset1:16                 // 000000499D74: D8381000 000B0325
	ds_store_2addr_b32 v37, v4, v12 offset0:128 offset1:144    // 000000499D7C: D8389080 000C0425
	ds_store_2addr_b32 v1, v5, v13 offset1:16                  // 000000499D84: D8381000 000D0501
	ds_store_2addr_b32 v1, v6, v14 offset0:128 offset1:144     // 000000499D8C: D8389080 000E0601
	ds_store_2addr_b32 v2, v7, v15 offset1:16                  // 000000499D94: D8381000 000F0702
	ds_store_2addr_b32 v2, v8, v16 offset0:128 offset1:144     // 000000499D9C: D8389080 00100802
	ds_store_2addr_b32 v36, v17, v25 offset0:32 offset1:48     // 000000499DA4: D8383020 00191124
	ds_store_2addr_b32 v36, v18, v26 offset0:160 offset1:176   // 000000499DAC: D838B0A0 001A1224
	ds_store_2addr_b32 v37, v19, v27 offset0:32 offset1:48     // 000000499DB4: D8383020 001B1325
	ds_store_2addr_b32 v37, v20, v28 offset0:160 offset1:176   // 000000499DBC: D838B0A0 001C1425
	ds_store_2addr_b32 v1, v21, v29 offset0:32 offset1:48      // 000000499DC4: D8383020 001D1501
	ds_store_2addr_b32 v1, v22, v30 offset0:160 offset1:176    // 000000499DCC: D838B0A0 001E1601
	ds_store_2addr_b32 v2, v23, v31 offset0:32 offset1:48      // 000000499DD4: D8383020 001F1702
	ds_store_2addr_b32 v2, v24, v32 offset0:160 offset1:176    // 000000499DDC: D838B0A0 00201802
	ds_store_2addr_b32 v36, v33, v78 offset0:64 offset1:80     // 000000499DE4: D8385040 004E2124
	ds_store_2addr_b32 v36, v34, v79 offset0:192 offset1:208   // 000000499DEC: D838D0C0 004F2224
	ds_store_2addr_b32 v37, v72, v80 offset0:64 offset1:80     // 000000499DF4: D8385040 00504825
	ds_store_2addr_b32 v37, v73, v81 offset0:192 offset1:208   // 000000499DFC: D838D0C0 00514925
	ds_store_2addr_b32 v1, v74, v82 offset0:64 offset1:80      // 000000499E04: D8385040 00524A01
	ds_store_2addr_b32 v1, v75, v83 offset0:192 offset1:208    // 000000499E0C: D838D0C0 00534B01
	ds_store_2addr_b32 v2, v76, v84 offset0:64 offset1:80      // 000000499E14: D8385040 00544C02
	ds_store_2addr_b32 v2, v77, v85 offset0:192 offset1:208    // 000000499E1C: D838D0C0 00554D02
	ds_store_2addr_b32 v36, v86, v94 offset0:96 offset1:112    // 000000499E24: D8387060 005E5624
	ds_store_2addr_b32 v36, v87, v95 offset0:224 offset1:240   // 000000499E2C: D838F0E0 005F5724
	ds_store_2addr_b32 v37, v88, v96 offset0:96 offset1:112    // 000000499E34: D8387060 00605825
	ds_store_2addr_b32 v37, v89, v97 offset0:224 offset1:240   // 000000499E3C: D838F0E0 00615925
	ds_store_2addr_b32 v1, v90, v98 offset0:96 offset1:112     // 000000499E44: D8387060 00625A01
	ds_store_2addr_b32 v1, v91, v99 offset0:224 offset1:240    // 000000499E4C: D838F0E0 00635B01
	ds_store_2addr_b32 v2, v92, v100 offset0:96 offset1:112    // 000000499E54: D8387060 00645C02
	ds_store_2addr_b32 v2, v93, v40 offset0:224 offset1:240    // 000000499E5C: D838F0E0 00285D02
	s_or_b32 exec_lo, exec_lo, s1                              // 000000499E64: 8C7E017E
	v_mov_b32_e32 v1, v0                                       // 000000499E68: 7E020300
	s_mov_b32 s1, 0                                            // 000000499E6C: BE810080
	s_waitcnt lgkmcnt(0)                                       // 000000499E70: BF89FC07
	s_barrier                                                  // 000000499E74: BFBD0000
	buffer_gl0_inv                                             // 000000499E78: E0AC0000 00000000
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000499E80: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v1                         // 000000499E84: 7C9202FF 000002FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:16           // 000000499E8C: D8E01000 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:32 offset1:48// 000000499E94: D8E03020 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:64 offset1:80// 000000499E9C: D8E05040 06000008
	s_or_b32 s1, vcc_lo, s1                                    // 000000499EA4: 8C01016A
	s_waitcnt lgkmcnt(2)                                       // 000000499EA8: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000499EAC: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000499EB0: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000499EB4: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:96 offset1:112// 000000499EB8: D8E07060 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000499EC0: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000499EC4: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 000000499EC8: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000499ECC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000499ED0: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000499ED4: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 000000499ED8: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000499EDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000499EE0: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000499EE4: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 000000499EE8: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000499EF0: C9100702 02000104
	ds_store_b32 v8, v2 offset:32768                           // 000000499EF8: D8348000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000499F00: 917E017E
	s_cbranch_execnz 65502                                     // 000000499F04: BFA6FFDE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2580>
	s_or_b32 exec_lo, exec_lo, s1                              // 000000499F08: 8C7E017E
	s_cmp_lt_i32 s33, 2                                        // 000000499F0C: BF048221
	s_mov_b32 s1, -1                                           // 000000499F10: BE8100C1
	s_cbranch_scc1 197                                         // 000000499F14: BFA200C5 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x292c>
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v1, 0x7f, v0       // 000000499F18: CA240100 040000FF 0000007F
	s_lshl_b32 s4, s2, 7                                       // 000000499F24: 84048702
	s_ashr_i32 s11, s10, 31                                    // 000000499F28: 860B9F0A
	s_ashr_i32 s5, s4, 31                                      // 000000499F2C: 86059F04
	s_delay_alu instid0(VALU_DEP_1)                            // 000000499F30: BF870001
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000499F34: 30040282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000499F38: 84848204
	s_lshl_b64 s[6:7], s[10:11], 3                             // 000000499F3C: 8486830A
	s_ashr_i32 s19, s18, 31                                    // 000000499F40: 86139F12
	s_add_u32 s1, s24, s4                                      // 000000499F44: 80010418
	s_addc_u32 s8, s25, s5                                     // 000000499F48: 82080519
	.long 0xd7000102                                           // 000000499F4C: D7000102
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 000000499F50: 02020401
	s_delay_alu instid0(VALU_DEP_1)                            // 000000499F54: BF870001
	v_add_co_ci_u32_e64 v3, null, s8, 0, s1                    // 000000499F58: D5207C03 00050008
	s_mov_b32 s8, 0                                            // 000000499F60: BE880080
	s_waitcnt lgkmcnt(0)                                       // 000000499F64: BF89FC07
	s_barrier                                                  // 000000499F68: BFBD0000
	buffer_gl0_inv                                             // 000000499F6C: E0AC0000 00000000
	s_nop 0                                                    // 000000499F74: BF800000
	s_nop 0                                                    // 000000499F78: BF800000
	s_nop 0                                                    // 000000499F7C: BF800000
	v_lshrrev_b32_e32 v5, 7, v4                                // 000000499F80: 320A0887
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v4                         // 000000499F84: 7C9208FF 000002FF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000499F8C: BF870092
	.long 0xd7000105                                           // 000000499F90: D7000105
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000499F94: 02020A06
	v_add_co_ci_u32_e64 v6, null, s7, 0, s1                    // 000000499F98: D5207C06 00050007
	s_or_b32 s8, vcc_lo, s8                                    // 000000499FA0: 8C08086A
	.long 0xd72c0009                                           // 000000499FA4: D72C0009
	v_cndmask_b32_e32 v0, v5, v19, vcc_lo                      // 000000499FA8: 02002705
	.long 0xd72c0008                                           // 000000499FAC: D72C0008
	v_cndmask_b32_e32 v0, v6, v18, vcc_lo                      // 000000499FB0: 02002506
	v_mad_u64_u32 v[5:6], null, v5, s18, 0                     // 000000499FB4: D6FE7C05 02002505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000499FBC: BF8701B1
	v_add3_u32 v6, v6, v9, v8                                  // 000000499FC0: D6550006 04221306
	v_add_nc_u32_e32 v8, 0x100, v4                             // 000000499FC8: 4A1008FF 00000100
	v_lshlrev_b32_e32 v7, 2, v4                                // 000000499FD0: 300E0882
	.long 0xd73c0005                                           // 000000499FD4: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000499FD8: 02020A82
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000499FDC: BF8700B3
	v_mov_b32_e32 v4, v8                                       // 000000499FE0: 7E080308
	ds_load_b32 v7, v7 offset:32768                            // 000000499FE4: D8D88000 07000007
	.long 0xd7000105                                           // 000000499FEC: D7000105
	v_cndmask_b32_e32 v1, v2, v5, vcc_lo                       // 000000499FF0: 02020B02
	v_add_co_ci_u32_e64 v6, null, v3, v6, s1                   // 000000499FF4: D5207C06 00060D03
	s_waitcnt lgkmcnt(0)                                       // 000000499FFC: BF89FC07
	global_store_b32 v[5:6], v7, off                           // 00000049A000: DC6A0000 007C0705
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000049A008: 917E087E
	s_cbranch_execnz 65500                                     // 00000049A00C: BFA6FFDC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2680>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000049A010: 8C7E087E
	.long 0xd44a0001                                           // 00000049A014: D44A0001
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000049A018: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000049A01C: BC7C0000
	buffer_gl1_inv                                             // 00000049A020: E0B00000 00000000
	buffer_gl0_inv                                             // 00000049A028: E0AC0000 00000000
	s_barrier                                                  // 00000049A030: BFBD0000
	buffer_gl0_inv                                             // 00000049A034: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000049A03C: BE862001
	s_cbranch_execz 29                                         // 00000049A040: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x27b8>
	s_mov_b32 s8, exec_lo                                      // 00000049A044: BE88007E
	s_mov_b32 s7, exec_lo                                      // 00000049A048: BE87007E
	.long 0xd71f0002                                           // 00000049A04C: D71F0002
	v_cndmask_b32_e32 v0, s8, v128, vcc_lo                     // 00000049A050: 02010008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049A054: BF870001
	v_cmpx_eq_u32_e32 0, v2                                    // 00000049A058: 7D940480
	s_cbranch_execz 9                                          // 00000049A05C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2784>
	s_lshl_b64 s[10:11], s[2:3], 2                             // 00000049A060: 848A8202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000049A064: BF8704B9
	s_add_u32 s10, s26, s10                                    // 00000049A068: 800A0A1A
	s_addc_u32 s11, s27, s11                                   // 00000049A06C: 820B0B1B
	s_bcnt1_i32_b32 s8, s8                                     // 00000049A070: BE881808
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, s8              // 00000049A074: CA100080 03040008
	global_atomic_add_u32 v3, v3, v4, s[10:11] glc             // 00000049A07C: DCD64000 030A0403
	s_or_b32 exec_lo, exec_lo, s7                              // 00000049A084: 8C7E077E
	s_waitcnt vmcnt(0)                                         // 00000049A088: BF8903F7
	v_readfirstlane_b32 s7, v3                                 // 00000049A08C: 7E0E0503
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049A090: BF870001
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s7, v2       // 00000049A094: CA200080 03020407
	s_add_i32 s7, s33, -1                                      // 00000049A09C: 8107C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000049A0A0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s7, v2                            // 00000049A0A4: 7C940407
	v_cndmask_b32_e64 v2, 0, 1, vcc_lo                         // 00000049A0A8: D5010002 01A90280
	ds_store_b32 v3, v2 offset:49408                           // 00000049A0B0: D834C100 00000203
	s_or_b32 exec_lo, exec_lo, s6                              // 00000049A0B8: 8C7E067E
	v_mov_b32_e32 v2, 0                                        // 00000049A0BC: 7E040280
	s_waitcnt lgkmcnt(0)                                       // 00000049A0C0: BF89FC07
	s_barrier                                                  // 00000049A0C4: BFBD0000
	buffer_gl0_inv                                             // 00000049A0C8: E0AC0000 00000000
	s_mov_b32 s10, 0                                           // 00000049A0D0: BE8A0080
	ds_load_b32 v2, v2 offset:49408                            // 00000049A0D4: D8D8C100 02000002
	s_waitcnt lgkmcnt(0)                                       // 00000049A0DC: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v2                             // 00000049A0E0: 7C940480
	s_cbranch_vccnz 465                                        // 00000049A0E4: BFA401D1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2f2c>
	v_lshrrev_b32_e32 v2, 7, v0                                // 00000049A0E8: 32040087
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000049A0EC: 30020282
	v_mov_b32_e32 v5, v0                                       // 00000049A0F0: 7E0A0300
	s_lshl_b64 s[6:7], s[18:19], 3                             // 00000049A0F4: 84868312
	s_lshl_b64 s[8:9], s[18:19], 5                             // 00000049A0F8: 84888512
	v_mad_i64_i32 v[2:3], null, v2, s18, 0                     // 00000049A0FC: D6FF7C02 02002502
	buffer_gl1_inv                                             // 00000049A104: E0B00000 00000000
	buffer_gl0_inv                                             // 00000049A10C: E0AC0000 00000000
	.long 0xd73c0002                                           // 00000049A114: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000049A118: 02020482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049A11C: BF870091
	.long 0xd7006a02                                           // 00000049A120: D7006A02
	v_cndmask_b32_e32 v0, v2, v4, vcc_lo                       // 00000049A124: 02000902
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000049A128: D5207C03 01AA0605
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049A130: BF870092
	.long 0xd7006a01                                           // 00000049A134: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 00000049A138: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 00000049A13C: D5207C02 01AA0680
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049A144: BF870092
	.long 0xd7006a01                                           // 00000049A148: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 00000049A14C: 02020218
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 00000049A150: D5207C02 01AA0419
	s_nop 0                                                    // 00000049A158: BF800000
	s_nop 0                                                    // 00000049A15C: BF800000
	s_nop 0                                                    // 00000049A160: BF800000
	s_nop 0                                                    // 00000049A164: BF800000
	s_nop 0                                                    // 00000049A168: BF800000
	s_nop 0                                                    // 00000049A16C: BF800000
	s_nop 0                                                    // 00000049A170: BF800000
	s_nop 0                                                    // 00000049A174: BF800000
	s_nop 0                                                    // 00000049A178: BF800000
	s_nop 0                                                    // 00000049A17C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049A180: BF870191
	v_mov_b32_e32 v4, v2                                       // 00000049A184: 7E080302
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v3, v1              // 00000049A188: CA100080 06020101
	s_mov_b32 s4, s33                                          // 00000049A190: BE840021
	global_load_b32 v7, v[3:4], off glc                        // 00000049A194: DC524000 077C0003
	.long 0xd7006a03                                           // 00000049A19C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 00000049A1A0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000049A1A4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000049A1A8: D5207C04 01AA0809
	s_add_i32 s4, s4, -1                                       // 00000049A1B0: 8104C104
	s_cmp_eq_u32 s4, 0                                         // 00000049A1B4: BF068004
	s_waitcnt vmcnt(0)                                         // 00000049A1B8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000049A1BC: 060C0F06
	s_cbranch_scc0 65524                                       // 00000049A1C0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2894>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 00000049A1C4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0x2ff, v5                         // 00000049A1CC: 7C920AFF 000002FF
	.long 0xd7000401                                           // 00000049A1D4: D7000401
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000049A1D8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000049A1DC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s4                   // 00000049A1E0: D5207C02 00120407
	v_mov_b32_e32 v5, v4                                       // 00000049A1E8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000049A1EC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:32768                           // 00000049A1F0: D8348000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000049A1F8: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000049A1FC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2880>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000049A200: 8C7E0A7E
	s_and_saveexec_b32 s4, s1                                  // 00000049A204: BE842001
	s_cbranch_execz 6                                          // 00000049A208: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2924>
	s_lshl_b64 s[6:7], s[2:3], 2                               // 00000049A20C: 84868202
	v_mov_b32_e32 v1, 0                                        // 00000049A210: 7E020280
	s_add_u32 s6, s26, s6                                      // 00000049A214: 8006061A
	s_addc_u32 s7, s27, s7                                     // 00000049A218: 8207071B
	global_store_b32 v1, v1, s[6:7]                            // 00000049A21C: DC6A0000 00060101
	s_or_b32 exec_lo, exec_lo, s4                              // 00000049A224: 8C7E047E
	s_mov_b32 s1, -1                                           // 00000049A228: BE8100C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049A22C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 00000049A230: 8B6A017E
	s_cbranch_vccz 381                                         // 00000049A234: BFA3017D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2f2c>
	v_cmp_gt_i32_e32 vcc_lo, s16, v35                          // 00000049A238: 7C884610
	.long 0xd44c0001                                           // 00000049A23C: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000049A240: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000049A248: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000049A24C: BC7C0000
	s_barrier                                                  // 00000049A250: BFBD0000
	buffer_gl0_inv                                             // 00000049A254: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000049A25C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000049A260: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000049A264: BE832001
	s_cbranch_execz 368                                        // 00000049A268: BFA50170 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2f2c>
	v_and_b32_e32 v1, 15, v0                                   // 00000049A26C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049A270: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000049A274: 30040282
	v_lshl_or_b32 v2, v35, 9, v2                               // 00000049A278: D6560002 04091323
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049A280: BF870001
	v_add_nc_u32_e32 v8, 0x8000, v2                            // 00000049A284: 4A1004FF 00008000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000049A28C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000049A294: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000049A29C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000049A2A4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000049A2AC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000049A2B0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000049A2B4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000049A2B8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000049A2C0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000049A2C4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000049A2CC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000049A2D0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000049A2D8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000049A2DC: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000049A2E4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000049A2EC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000049A2F0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000049A2F4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000049A2FC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000049A304: 7C941480
	.long 0xd44a0001                                           // 00000049A308: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000049A30C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000049A310: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000049A318: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000049A31C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000049A320: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 00000049A324: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000049A328: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000049A330: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000049A334: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000049A338: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A33C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000049A344: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A34C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000049A354: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A35C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000049A364: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A36C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000049A374: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A37C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000049A384: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A38C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000049A394: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A39C: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 00000049A3A4: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 00000049A3AC: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000049A3B4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 00000049A3B8: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000049A3C0: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 00000049A3C8: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049A3D0: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A3D4: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000049A3DC: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 00000049A3E4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A3E8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000049A3F0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A3F8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 00000049A400: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A404: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000049A40C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 00000049A414: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000049A418: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 00000049A420: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A424: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000049A42C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A430: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000049A438: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000049A440: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 00000049A448: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A44C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000049A454: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000049A45C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A460: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000049A468: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 00000049A470: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A474: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000049A47C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 00000049A484: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 00000049A488: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000049A48C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A494: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 00000049A49C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A4A0: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000049A4A8: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000049A4B0: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 00000049A4B4: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A4B8: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000049A4C0: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 00000049A4C8: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A4CC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A4D4: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A4DC: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 00000049A4E4: 06081504
	v_add_f32_e32 v10, v19, v18                                // 00000049A4E8: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049A4EC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000049A4F0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000049A4F8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 00000049A500: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 00000049A504: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A508: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000049A510: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049A518: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A51C: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000049A524: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000049A52C: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000049A534: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 00000049A53C: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A540: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049A548: BF870214
	v_add_f32_e32 v15, v10, v15                                // 00000049A54C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 00000049A550: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A554: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A55C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049A564: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A568: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000049A570: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000049A578: 8B7E007E
	s_cbranch_execz 171                                        // 00000049A57C: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi8ELb0ELb0ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2f2c>
	v_lshl_or_b32 v18, s2, 7, v1                               // 00000049A580: D6560012 04050E02
	.long 0x7f2c3880                                           // 00000049A588: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049A58C: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000049A590: 3426249F
	.long 0x7f2e3996                                           // 00000049A594: 7F2E3996
	.long 0x7f303996                                           // 00000049A598: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049A59C: BF870093
	.long 0xd73c0012                                           // 00000049A5A0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000049A5A4: 02022481
	.long 0xd7006a14                                           // 00000049A5A8: D7006A14
	v_cndmask_b32_e32 v1, s22, v18, vcc_lo                     // 00000049A5AC: 02022416
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049A5B0: BF870001
	v_add_co_ci_u32_e64 v21, null, s23, v19, vcc_lo            // 00000049A5B4: D5207C15 01AA2617
	s_clause 0x7                                               // 00000049A5BC: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 00000049A5C0: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000049A5C8: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 00000049A5D0: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 00000049A5D8: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 00000049A5E0: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 00000049A5E8: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 00000049A5F0: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 00000049A5F8: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 00000049A600: 362A0088
	v_mad_i64_i32 v[0:1], null, s18, v35, 0                    // 00000049A604: D6FF7C00 02024612
	s_waitcnt vmcnt(0)                                         // 00000049A60C: BF8903F7
	.long 0x7f283996                                           // 00000049A610: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000049A614: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 00000049A618: 7C942A80
	.long 0x7f2a3996                                           // 00000049A61C: 7F2A3996
	.long 0xd73c0000                                           // 00000049A620: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000049A624: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000049A628: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000049A630: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000049A638: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000049A640: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000049A648: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 00000049A650: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 00000049A654: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000049A65C: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000049A664: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000049A66C: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 00000049A670: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 00000049A67C: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 00000049A684: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049A690: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 00000049A694: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 00000049A69C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049A6A4: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000049A6A8: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000049A6B4: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 00000049A6C0: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 00000049A6C4: 0202001C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049A6C8: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000049A6CC: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 00000049A6D4: D5207C01 01AA021D
	.long 0xd7006a00                                           // 00000049A6DC: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 00000049A6E0: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049A6E4: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 00000049A6E8: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000049A6F0: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000049A6F8: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000049A700: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000049A708: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 00000049A710: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 00000049A718: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000049A71C: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 00000049A724: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000049A72C: CC200008 8A02111C
	.long 0x7e2a3985                                           // 00000049A734: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 00000049A738: 36142C81
	.long 0x7e2c3984                                           // 00000049A73C: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000049A740: CC200009 8A021314
	.long 0x7e283982                                           // 00000049A748: 7E283982
	.long 0x7e2e3986                                           // 00000049A74C: 7E2E3986
	.long 0x7e303988                                           // 00000049A750: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 00000049A754: 36162C81
	.long 0x7e2c3987                                           // 00000049A758: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 00000049A75C: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 00000049A760: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 00000049A764: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000049A768: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 00000049A76C: 361E2C81
	.long 0x7e2c3989                                           // 00000049A770: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000049A774: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 00000049A780: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000049A78C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000049A798: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 00000049A7A4: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000049A7A8: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 00000049A7B4: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000049A7C0: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049A7CC: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000049A7D0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 00000049A7DC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000049A7E0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000049A7E8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 00000049A7F0: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 00000049A7F8: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000049A800: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000049A808: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000049A810: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000049A818: DC9600E0 007C0900
	s_nop 0                                                    // 00000049A820: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000049A824: BFB60003
	s_endpgm                                                   // 00000049A828: BFB00000
	s_nop 0                                                    // 00000049A82C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000049A830: BFB60003
	s_endpgm                                                   // 00000049A834: BFB00000
		...

