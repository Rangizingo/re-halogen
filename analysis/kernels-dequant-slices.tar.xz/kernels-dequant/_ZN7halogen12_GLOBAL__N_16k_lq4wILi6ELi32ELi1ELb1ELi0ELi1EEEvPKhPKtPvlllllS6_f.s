000000000075a800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000075A800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000075A808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000075A80C: 32040082
	s_lshl_b64 s[0:1], s[2:3], 3                               // 00000075A810: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000075A814: BF8701A9
	v_dual_mov_b32 v24, s1 :: v_dual_and_b32 v1, 15, v0        // 00000075A818: CA240001 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 00000075A820: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 00000075A824: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000075A828: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 00000075A82C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000075A830: 30020282
	.long 0x7f0c3880                                           // 00000075A834: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000075A838: BF89FC07
	s_clause 0x1                                               // 00000075A83C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000075A840: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000075A848: DC520000 04040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000075A850: 32020085
	s_add_u32 s22, s4, s16                                     // 00000075A854: 80161004
	s_addc_u32 s23, s5, s17                                    // 00000075A858: 82171105
	s_ashr_i32 s2, s11, 31                                     // 00000075A85C: 86029F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000075A860: BF8704A1
	v_or_b32_e32 v23, s0, v1                                   // 00000075A864: 382E0200
	s_lshr_b32 s2, s2, 27                                      // 00000075A868: 85029B02
	s_add_u32 s2, s10, s2                                      // 00000075A86C: 8002020A
	s_addc_u32 s3, s11, 0                                      // 00000075A870: 8203800B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000075A874: BF8704A1
	.long 0xd4540000                                           // 00000075A878: D4540000
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 00000075A87C: 02022E0C
	s_lshr_b64 s[20:21], s[2:3], 5                             // 00000075A880: 85948502
	s_cmpk_lt_i32 s20, 0x101                                   // 00000075A884: B3940101
	.long 0xd4440002                                           // 00000075A888: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000075A88C: 02023C14
	v_cndmask_b32_e64 v2, 0, v23, s0                           // 00000075A890: D5010002 00022E80
	v_cndmask_b32_e64 v5, 0, s1, s0                            // 00000075A898: D5010005 00000280
	s_cselect_b32 s1, -1, 0                                    // 00000075A8A0: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 00000075A8A4: B2940100
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075A8A8: BF870002
	.long 0xd72c0008                                           // 00000075A8AC: D72C0008
	v_cndmask_b32_e32 v1, s19, v2, vcc_lo                      // 00000075A8B0: 02020413
	v_mad_u64_u32 v[0:1], null, s18, v2, 0                     // 00000075A8B4: D6FE7C00 02020412
	s_waitcnt vmcnt(1)                                         // 00000075A8BC: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 00000075A8C0: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 00000075A8C8: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000075A8CC: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000075A8D4: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 00000075A8D8: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 00000075A8E4: D72C0009
	v_cndmask_b32_e32 v1, s18, v5, vcc_lo                      // 00000075A8E8: 02020A12
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000075A8EC: D6550004 03FE1504 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 00000075A8F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000075A8FC: BF870239
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000075A900: 8B6A127E
	.long 0x7e0c3983                                           // 00000075A904: 7E0C3983
	.long 0xd7000303                                           // 00000075A908: D7000303
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000075A90C: 02020016
	v_add3_u32 v1, v1, v9, v8                                  // 00000075A910: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000075A918: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 00000075A91C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s23, v1, s3                  // 00000075A928: D5207C04 000E0217
	ds_store_b32 v7, v6                                        // 00000075A930: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000075A938: BF89FC07
	s_barrier                                                  // 00000075A93C: BFBD0000
	buffer_gl0_inv                                             // 00000075A940: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 00000075A948: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000075A94C: CA100080 08060080
	s_and_saveexec_b32 s3, s2                                  // 00000075A954: BE832002
	s_cbranch_execz 10                                         // 00000075A958: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000075A95C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075A960: BF870091
	.long 0xd7006a06                                           // 00000075A964: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075A968: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000075A96C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000075A974: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000075A97C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000075A980: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s3                              // 00000075A984: 8C7E037E
	v_or_b32_e32 v6, 32, v30                                   // 00000075A988: 380C3CA0
	s_mov_b32 s2, exec_lo                                      // 00000075A98C: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075A990: BF870001
	.long 0xd4c4007e                                           // 00000075A994: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075A998: 02020C14
	s_cbranch_execz 10                                         // 00000075A99C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075A9A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075A9A4: BF870091
	.long 0xd7006a08                                           // 00000075A9A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075A9AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000075A9B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000075A9B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000075A9C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000075A9C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075A9C8: 8C7E027E
	v_or_b32_e32 v6, 64, v30                                   // 00000075A9CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000075A9D0: CA100080 0A080080
	s_mov_b32 s2, exec_lo                                      // 00000075A9D8: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075A9DC: BF870002
	.long 0xd4c4007e                                           // 00000075A9E0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075A9E4: 02020C14
	s_cbranch_execz 10                                         // 00000075A9E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075A9EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075A9F0: BF870091
	.long 0xd7006a0b                                           // 00000075A9F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075A9F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000075A9FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000075AA04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000075AA0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000075AA10: 7E121706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AA14: 8C7E027E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000075AA18: 380C3CFF 00000060
	s_mov_b32 s2, exec_lo                                      // 00000075AA20: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075AA24: BF870001
	.long 0xd4c4007e                                           // 00000075AA28: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075AA2C: 02020C14
	s_cbranch_execz 10                                         // 00000075AA30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075AA34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AA38: BF870091
	.long 0xd7006a0a                                           // 00000075AA3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075AA40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000075AA44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000075AA4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000075AA54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000075AA58: 7E141706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AA5C: 8C7E027E
	v_or_b32_e32 v6, 0x80, v30                                 // 00000075AA60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000075AA68: CA100080 0C0A0080
	s_mov_b32 s2, exec_lo                                      // 00000075AA70: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075AA74: BF870002
	.long 0xd4c4007e                                           // 00000075AA78: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075AA7C: 02020C14
	s_cbranch_execz 10                                         // 00000075AA80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075AA84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AA88: BF870091
	.long 0xd7006a0d                                           // 00000075AA8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075AA90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000075AA94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000075AA9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000075AAA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000075AAA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AAAC: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v30                                 // 00000075AAB0: 380C3CFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 00000075AAB8: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075AABC: BF870001
	.long 0xd4c4007e                                           // 00000075AAC0: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075AAC4: 02020C14
	s_cbranch_execz 10                                         // 00000075AAC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075AACC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AAD0: BF870091
	.long 0xd7006a0c                                           // 00000075AAD4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075AAD8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000075AADC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000075AAE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000075AAEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000075AAF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AAF4: 8C7E027E
	v_or_b32_e32 v6, 0xc0, v30                                 // 00000075AAF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000075AB00: CA100080 0E0C0080
	s_mov_b32 s2, exec_lo                                      // 00000075AB08: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075AB0C: BF870002
	.long 0xd4c4007e                                           // 00000075AB10: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075AB14: 02020C14
	s_cbranch_execz 10                                         // 00000075AB18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075AB1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AB20: BF870091
	.long 0xd7006a0f                                           // 00000075AB24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075AB28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000075AB2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000075AB34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000075AB3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000075AB40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AB44: 8C7E027E
	v_or_b32_e32 v6, 0xe0, v30                                 // 00000075AB48: 380C3CFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 00000075AB50: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075AB54: BF870001
	.long 0xd4c4007e                                           // 00000075AB58: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 00000075AB5C: 02020C14
	s_cbranch_execz 10                                         // 00000075AB60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000075AB64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AB68: BF870091
	.long 0xd7006a0e                                           // 00000075AB6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000075AB70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000075AB74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000075AB7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000075AB84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000075AB88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 00000075AB8C: 8C7E027E
	s_branch 9                                                 // 00000075AB90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 00000075AB94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075AB98: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000075AB9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000075ABA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000075ABA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000075ABA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000075ABAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000075ABB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000075ABB4: 7E1C0307
	s_add_u32 s2, s4, s14                                      // 00000075ABB8: 80020E04
	s_addc_u32 s3, s5, s15                                     // 00000075ABBC: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 00000075ABC0: 850E9F0B
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v32, 0             // 00000075ABC4: CA100080 13200080
	s_add_u32 s14, s10, s14                                    // 00000075ABCC: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000075ABD0: 820F800B
	v_cndmask_b32_e64 v31, 0, 1, s18                           // 00000075ABD4: D501001F 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000075ABDC: 868E810E
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v21, 0             // 00000075ABE0: CA100080 2A140080
	v_mad_u64_u32 v[25:26], null, v2, s14, s[2:3]              // 00000075ABE8: D6FE7C19 00081D02
	.long 0xd72c0002                                           // 00000075ABF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v15, vcc_lo                      // 00000075ABF4: 02001F02
	.long 0xd72c0005                                           // 00000075ABF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v14, vcc_lo                      // 00000075ABFC: 02001D05
	.long 0xd4440002                                           // 00000075AC00: D4440002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 00000075AC04: 02023C14
	v_mov_b32_e32 v20, 0                                       // 00000075AC08: 7E280280
	v_mov_b32_e32 v22, 0                                       // 00000075AC0C: 7E2C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000075AC10: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 00000075AC14: D6550021 040A3505
	s_and_saveexec_b32 s3, s2                                  // 00000075AC1C: BE832002
	s_cbranch_execz 21                                         // 00000075AC20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 4, v30                               // 00000075AC24: 30043C84
	v_mov_b32_e32 v42, 0                                       // 00000075AC28: 7E540280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AC2C: BF870092
	.long 0xd7006a05                                           // 00000075AC30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000075AC34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000075AC38: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000075AC40: 916A127E
	global_load_b128 v[19:22], v[5:6], off                     // 00000075AC44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000075AC4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000075AC50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075AC54: BF870091
	.long 0xd7006a02                                           // 00000075AC58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000075AC5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000075AC60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000075AC68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000075AC70: BF8903F7
	v_cvt_f32_f16_e32 v42, v2                                  // 00000075AC74: 7E541702
	s_or_b32 exec_lo, exec_lo, s3                              // 00000075AC78: 8C7E037E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000075AC7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000075AC84: CA100080 24240080
	v_mov_b32_e32 v38, 0                                       // 00000075AC8C: 7E4C0280
	s_and_saveexec_b32 s3, s2                                  // 00000075AC90: BE832002
	s_cbranch_execz 565                                        // 00000075AC94: BFA50235 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd6c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000075AC98: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000075ACA0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000075ACA4: 02020010
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000075ACA8: BF870191
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000075ACAC: D5207C01 01AA0211
	v_dual_mov_b32 v37, v27 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000075ACB4: CA22011B 251A3C85
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075ACBC: BF870093
	.long 0xd7006a00                                           // 00000075ACC0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000075ACC4: 02020500
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000075ACC8: D5207C01 01AA0280
	v_lshl_or_b32 v39, v30, 4, 0x200                           // 00000075ACD0: D6560027 03FD091E 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075ACDC: BF870093
	.long 0xd7006a00                                           // 00000075ACE0: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000075ACE4: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000075ACE8: D5207C01 01AA0205
	v_dual_mov_b32 v40, v30 :: v_dual_mov_b32 v35, v27         // 00000075ACF0: CA10011E 2822011B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075ACF8: BF870093
	.long 0xd7006a1c                                           // 00000075ACFC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 00000075AD00: 02018100
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000075AD04: D5207C1D 01AA0280
	v_dual_mov_b32 v38, v27 :: v_dual_mov_b32 v41, v42         // 00000075AD0C: CA10011B 2628012A
	v_mov_b32_e32 v36, v27                                     // 00000075AD14: 7E48031B
	v_mov_b32_e32 v34, v27                                     // 00000075AD18: 7E44031B
	v_mov_b32_e32 v32, v27                                     // 00000075AD1C: 7E40031B
	s_mul_i32 s2, s11, 6                                       // 00000075AD20: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 00000075AD24: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 00000075AD28: 848E820A
	s_add_i32 s18, s18, s2                                     // 00000075AD2C: 81120212
	s_mul_i32 s17, s10, 6                                      // 00000075AD30: 9611860A
	s_mov_b32 s16, 0                                           // 00000075AD34: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 00000075AD38: 8484810A
	s_branch 494                                               // 00000075AD3C: BFA001EE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xcf8>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000075AD40: 8C7E0A7E
	v_cndmask_b32_e64 v52, v42, v7, s1                         // 00000075AD44: D5010034 00060F2A
	v_cndmask_b32_e64 v1, v8, v9, s1                           // 00000075AD4C: D5010001 00061308
	v_cndmask_b32_e64 v0, v7, v8, s1                           // 00000075AD54: D5010000 00061107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000075AD5C: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s1                         // 00000075AD68: D5010006 00061D0D
	v_cndmask_b32_e64 v5, v12, v13, s1                         // 00000075AD70: D5010005 00061B0C
	v_cndmask_b32_e64 v4, v11, v12, s1                         // 00000075AD78: D5010004 0006190B
	v_cndmask_b32_e64 v3, v10, v11, s1                         // 00000075AD80: D5010003 0006170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000075AD88: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s1                          // 00000075AD8C: D5010002 00061509
	s_and_b32 s2, exec_lo, s2                                  // 00000075AD94: 8B02027E
	v_add_nc_u32_e32 v39, 0x200, v39                           // 00000075AD98: 4A4E4EFF 00000200
	s_or_b32 s16, s2, s16                                      // 00000075ADA0: 8C101002
	ds_load_b32 v14, v8                                        // 00000075ADA4: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000075ADAC: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075ADB0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075ADB4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 00000075ADBC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000075ADC4: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075ADC8: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000075ADD0: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000075ADD8: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075ADDC: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075ADE0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000075ADE8: D8D80000 37000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000075ADF0: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000075ADF8: 30101082
	ds_load_b32 v56, v8                                        // 00000075ADFC: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000075AE04: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075AE08: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE0C: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 00000075AE14: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000075AE1C: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE20: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000075AE28: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000075AE30: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075AE34: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE38: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000075AE40: D8D80000 3B000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000075AE48: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000075AE50: 30101082
	ds_load_b32 v60, v8                                        // 00000075AE54: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000075AE5C: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075AE60: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE64: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 00000075AE6C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000075AE74: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE78: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000075AE80: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000075AE88: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075AE8C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AE90: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000075AE98: D8D80000 3F000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000075AEA0: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000075AEA8: 30101082
	ds_load_b32 v64, v8                                        // 00000075AEAC: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000075AEB4: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075AEB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AEBC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 00000075AEC4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000075AECC: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AED0: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000075AED8: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000075AEE0: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000075AEE4: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000075AEE8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000075AEF0: D8D80000 43000008
	.long 0xd73c0008                                           // 00000075AEF8: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000075AEFC: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 00000075AF00: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 00000075AF08: D7006A0C
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000075AF0C: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075AF10: BF870001
	v_add_co_ci_u32_e64 v13, null, s7, v9, vcc_lo              // 00000075AF14: D5207C0D 01AA1207
	s_clause 0x3                                               // 00000075AF1C: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000075AF20: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000075AF28: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000075AF30: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000075AF38: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000075AF40: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075AF44: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000075AF4C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AF50: BF8700A1
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075AF54: CC1A4008 1C226B09
	s_waitcnt lgkmcnt(13)                                      // 00000075AF5C: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075AF60: CC1A4008 1C226D0A
	s_waitcnt lgkmcnt(12)                                      // 00000075AF68: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AF6C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075AF70: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000075AF78: BF8908B7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075AF7C: CC1A4008 1C227113
	s_waitcnt lgkmcnt(10)                                      // 00000075AF84: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AF88: BF8700A1
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075AF8C: CC1A4008 1C227314
	s_waitcnt lgkmcnt(9)                                       // 00000075AF94: BF89FC97
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075AF98: CC1A4008 1C227515
	s_waitcnt lgkmcnt(8)                                       // 00000075AFA0: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AFA4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075AFA8: CC1A4008 1C227716
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000075AFB0: BF890477
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075AFB4: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(6)                                       // 00000075AFBC: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AFC0: BF8700A1
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075AFC4: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(5)                                       // 00000075AFCC: BF89FC57
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075AFD0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(4)                                       // 00000075AFD8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075AFDC: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075AFE0: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000075AFE8: BF890037
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075AFEC: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 00000075AFF4: D7006A2E
	v_cndmask_b32_e32 v0, v12, v4, vcc_lo                      // 00000075AFF8: 0200090C
	s_waitcnt lgkmcnt(2)                                       // 00000075AFFC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000075B000: BF8701C2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B004: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s5, v13, vcc_lo             // 00000075B00C: D5207C2F 01AA1A05
	.long 0xd7006a32                                           // 00000075B014: D7006A32
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000075B018: 02001D0C
	s_waitcnt lgkmcnt(1)                                       // 00000075B01C: BF89FC17
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B020: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v51, null, s15, v13, vcc_lo            // 00000075B028: D5207C33 01AA1A0F
	.long 0xd7006a0c                                           // 00000075B030: D7006A0C
	v_cndmask_b32_e32 v0, v12, v17, vcc_lo                     // 00000075B034: 0200230C
	s_waitcnt lgkmcnt(0)                                       // 00000075B038: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075B03C: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B040: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v13, null, s18, v13, vcc_lo            // 00000075B048: D5207C0D 01AA1A12
	v_fmac_f32_e32 v38, v52, v8                                // 00000075B050: 564C1134
	s_clause 0x3                                               // 00000075B054: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000075B058: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 00000075B060: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000075B068: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000075B070: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000075B078: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075B07C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B084: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075B088: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075B090: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B098: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075B09C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000075B0A4: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075B0A8: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B0B0: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075B0B4: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075B0BC: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B0C4: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075B0C8: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000075B0D0: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075B0D4: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B0DC: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075B0E0: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075B0E8: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B0F0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075B0F4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000075B0FC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075B100: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B108: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B10C: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B114: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B11C: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B120: CC1A4008 1C228731
	v_fmac_f32_e32 v37, v52, v8                                // 00000075B128: 564A1134
	s_clause 0x3                                               // 00000075B12C: BF850003
	global_load_b128 v[8:11], v[50:51], off                    // 00000075B130: DC5E0000 087C0032
	global_load_b128 v[19:22], v[50:51], off offset:16         // 00000075B138: DC5E0010 137C0032
	global_load_b128 v[42:45], v[50:51], off offset:32         // 00000075B140: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[50:51], off offset:48         // 00000075B148: DC5E0030 2E7C0032
	s_waitcnt vmcnt(3)                                         // 00000075B150: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075B154: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B15C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075B160: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075B168: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B170: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075B174: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000075B17C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075B180: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B188: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075B18C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075B194: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B19C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075B1A0: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000075B1A8: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075B1AC: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B1B4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075B1B8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075B1C0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B1C8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075B1CC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000075B1D4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075B1D8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B1E0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B1E4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B1EC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B1F4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B1F8: CC1A4008 1C228731
	v_fmac_f32_e32 v36, v52, v8                                // 00000075B200: 56481134
	s_clause 0x3                                               // 00000075B204: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000075B208: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000075B210: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000075B218: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000075B220: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 00000075B228: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075B22C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B234: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075B238: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075B240: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B248: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075B24C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000075B254: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075B258: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B260: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075B264: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075B26C: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B274: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075B278: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000075B280: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075B284: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B28C: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075B290: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075B298: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B2A0: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075B2A4: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000075B2AC: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075B2B0: CC1A4008 1C22812E
	.long 0xd7006a2e                                           // 00000075B2B8: D7006A2E
	v_cndmask_b32_e32 v0, v50, v14, vcc_lo                     // 00000075B2BC: 02001D32
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000075B2C0: BF8701B2
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B2C4: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v47, null, s15, v51, vcc_lo            // 00000075B2CC: D5207C2F 01AA660F
	.long 0xd7006a0c                                           // 00000075B2D4: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 00000075B2D8: 02001D0C
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B2DC: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 00000075B2E4: D5207C0D 01AA1A0F
	.long 0xd7006a1c                                           // 00000075B2EC: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 00000075B2F0: 0201811C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075B2F4: BF870123
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B2F8: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000075B300: D5207C1D 01AA3A80
	v_fmac_f32_e32 v35, v52, v8                                // 00000075B308: 56461134
	s_clause 0x3                                               // 00000075B30C: BF850003
	global_load_b128 v[8:11], v[46:47], off                    // 00000075B310: DC5E0000 087C002E
	global_load_b128 v[19:22], v[46:47], off offset:16         // 00000075B318: DC5E0010 137C002E
	global_load_b128 v[42:45], v[46:47], off offset:32         // 00000075B320: DC5E0020 2A7C002E
	global_load_b128 v[46:49], v[46:47], off offset:48         // 00000075B328: DC5E0030 2E7C002E
	s_waitcnt vmcnt(3)                                         // 00000075B330: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075B334: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B33C: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075B340: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075B348: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B350: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075B354: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000075B35C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075B360: CC1A4008 1C227113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B368: BF870091
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075B36C: CC1A4008 1C227314
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075B374: CC1A4008 1C227515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B37C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075B380: CC1A4008 1C227716
	s_waitcnt vmcnt(1)                                         // 00000075B388: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075B38C: CC1A4008 1C22792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B394: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075B398: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075B3A0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B3A8: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075B3AC: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000075B3B4: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075B3B8: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B3C0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B3C4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B3CC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B3D4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B3D8: CC1A4008 1C228731
	v_fmac_f32_e32 v34, v52, v8                                // 00000075B3E0: 56441134
	s_clause 0x3                                               // 00000075B3E4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000075B3E8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000075B3F0: DC5E0010 137C000C
	global_load_b128 v[42:45], v[12:13], off offset:32         // 00000075B3F8: DC5E0020 2A7C000C
	global_load_b128 v[46:49], v[12:13], off offset:48         // 00000075B400: DC5E0030 2E7C000C
	s_waitcnt vmcnt(3)                                         // 00000075B408: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000075B40C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B414: BF870091
	v_dot2_f32_bf16 v8, v9, v53, v8                            // 00000075B418: CC1A4008 1C226B09
	v_dot2_f32_bf16 v8, v10, v54, v8                           // 00000075B420: CC1A4008 1C226D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B428: BF8700A1
	v_dot2_f32_bf16 v8, v11, v55, v8                           // 00000075B42C: CC1A4008 1C226F0B
	s_waitcnt vmcnt(2)                                         // 00000075B434: BF890BF7
	v_dot2_f32_bf16 v8, v19, v56, v8                           // 00000075B438: CC1A4008 1C227113
	v_mov_b32_e32 v19, v15                                     // 00000075B440: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075B444: BF870122
	v_dot2_f32_bf16 v8, v20, v57, v8                           // 00000075B448: CC1A4008 1C227314
	v_mov_b32_e32 v20, v16                                     // 00000075B450: 7E280310
	v_dot2_f32_bf16 v8, v21, v58, v8                           // 00000075B454: CC1A4008 1C227515
	v_mov_b32_e32 v21, v17                                     // 00000075B45C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000075B460: BF870132
	v_dot2_f32_bf16 v8, v22, v59, v8                           // 00000075B464: CC1A4008 1C227716
	v_mov_b32_e32 v22, v18                                     // 00000075B46C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000075B470: BF8907F7
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 00000075B474: CC1A4008 1C22792A
	v_mov_b32_e32 v42, v41                                     // 00000075B47C: 7E540329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B480: BF870092
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000075B484: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000075B48C: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B494: BF8700A1
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000075B498: CC1A4008 1C227F2D
	s_waitcnt vmcnt(0)                                         // 00000075B4A0: BF8903F7
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000075B4A4: CC1A4008 1C22812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B4AC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000075B4B0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000075B4B8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B4C0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000075B4C4: CC1A4008 1C228731
	v_fmac_f32_e32 v32, v52, v8                                // 00000075B4CC: 56401134
	v_mov_b32_e32 v14, v7                                      // 00000075B4D0: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 00000075B4D4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 00000075B4DC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 00000075B4E4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 00000075B4EC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000075B4F0: 917E107E
	s_cbranch_execz 28                                         // 00000075B4F4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xd68>
	s_waitcnt vmcnt(0)                                         // 00000075B4F8: BF8903F7
	v_dual_mov_b32 v15, v19 :: v_dual_add_nc_u32 v40, 32, v40  // 00000075B4FC: CA200113 0F2850A0
	v_dual_mov_b32 v16, v20 :: v_dual_mov_b32 v17, v21         // 00000075B504: CA100114 10100115
	v_mov_b32_e32 v18, v22                                     // 00000075B50C: 7E240316
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075B510: BF870003
	.long 0xd4430002                                           // 00000075B514: D4430002
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 00000075B518: 02025014
	s_mov_b32 s10, exec_lo                                     // 00000075B51C: BE8A007E
	.long 0xd4c4007e                                           // 00000075B520: D4C4007E
	v_cndmask_b32_e32 v1, s20, v40, vcc_lo                     // 00000075B524: 02025014
	s_cbranch_execz 65029                                      // 00000075B528: BFA5FE05 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	.long 0xd7006a00                                           // 00000075B52C: D7006A00
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 00000075B530: 02024F19
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075B534: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000075B538: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v31                            // 00000075B540: 7C9A3E81
	v_mov_b32_e32 v41, v42                                     // 00000075B544: 7E52032A
	global_load_b128 v[15:18], v[0:1], off                     // 00000075B548: DC5E0000 0F7C0000
	s_cbranch_vccnz 65019                                      // 00000075B550: BFA4FDFB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	global_load_d16_b16 v0, v[28:29], off                      // 00000075B554: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000075B55C: BF8903F7
	v_cvt_f32_f16_e32 v41, v0                                  // 00000075B560: 7E521700
	s_branch 65014                                             // 00000075B564: BFA0FDF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x540>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000075B568: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075B56C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000075B570: 8C7E037E
	.long 0xd71f0000                                           // 00000075B574: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000075B578: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000075B57C: 3A020090
	v_xor_b32_e32 v7, 8, v0                                    // 00000075B580: 3A0E0088
	v_xor_b32_e32 v13, 4, v0                                   // 00000075B584: 3A1A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000075B588: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000075B58C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000075B590: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000075B594: 7C980EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075B598: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000075B59C: 30020282
	ds_bpermute_b32 v4, v1, v36                                // 00000075B5A0: DACC0000 04002401
	s_waitcnt lgkmcnt(0)                                       // 00000075B5A8: BF89FC07
	v_add_f32_e32 v4, v36, v4                                  // 00000075B5AC: 06080924
	ds_bpermute_b32 v2, v1, v38                                // 00000075B5B0: DACC0000 02002601
	ds_bpermute_b32 v6, v1, v34                                // 00000075B5B8: DACC0000 06002201
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000075B5C0: 020E0F00
	ds_bpermute_b32 v3, v1, v37                                // 00000075B5C4: DACC0000 03002501
	ds_bpermute_b32 v5, v1, v35                                // 00000075B5CC: DACC0000 05002301
	ds_bpermute_b32 v1, v1, v32                                // 00000075B5D4: DACC0000 01002001
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000075B5DC: 7C981AA0
	s_waitcnt lgkmcnt(4)                                       // 00000075B5E0: BF89FC47
	v_add_f32_e32 v2, v38, v2                                  // 00000075B5E4: 06040526
	s_waitcnt lgkmcnt(3)                                       // 00000075B5E8: BF89FC37
	v_dual_add_f32 v6, v34, v6 :: v_dual_lshlrev_b32 v7, 2, v7 // 00000075B5EC: C9220D22 06060E82
	ds_bpermute_b32 v8, v7, v2                                 // 00000075B5F4: DACC0000 08000207
	s_waitcnt lgkmcnt(0)                                       // 00000075B5FC: BF89FC07
	v_add_f32_e32 v2, v2, v8                                   // 00000075B600: 06041102
	ds_bpermute_b32 v10, v7, v4                                // 00000075B604: DACC0000 0A000407
	ds_bpermute_b32 v12, v7, v6                                // 00000075B60C: DACC0000 0C000607
	v_add_f32_e32 v3, v37, v3                                  // 00000075B614: 06060725
	v_add_f32_e32 v5, v35, v5                                  // 00000075B618: 060A0B23
	v_add_f32_e32 v1, v32, v1                                  // 00000075B61C: 06020320
	s_waitcnt lgkmcnt(1)                                       // 00000075B620: BF89FC17
	v_add_f32_e32 v4, v4, v10                                  // 00000075B624: 06081504
	ds_bpermute_b32 v9, v7, v3                                 // 00000075B628: DACC0000 09000307
	s_waitcnt lgkmcnt(1)                                       // 00000075B630: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 00000075B634: 060C1906
	ds_bpermute_b32 v11, v7, v5                                // 00000075B638: DACC0000 0B000507
	ds_bpermute_b32 v7, v7, v1                                 // 00000075B640: DACC0000 07000107
	v_cndmask_b32_e32 v13, v0, v13, vcc_lo                     // 00000075B648: 021A1B00
	s_waitcnt lgkmcnt(2)                                       // 00000075B64C: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 00000075B650: 06061303
	s_waitcnt lgkmcnt(0)                                       // 00000075B654: BF89FC07
	v_add_f32_e32 v1, v1, v7                                   // 00000075B658: 06020F01
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000075B65C: 301A1A82
	ds_bpermute_b32 v7, v13, v2                                // 00000075B660: DACC0000 0700020D
	ds_bpermute_b32 v8, v13, v3                                // 00000075B668: DACC0000 0800030D
	ds_bpermute_b32 v12, v13, v1                               // 00000075B670: DACC0000 0C00010D
	s_waitcnt lgkmcnt(1)                                       // 00000075B678: BF89FC17
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v7, v3, v8     // 00000075B67C: C9080F02 02061103
	s_waitcnt lgkmcnt(0)                                       // 00000075B684: BF89FC07
	v_add_f32_e32 v8, v1, v12                                  // 00000075B688: 06101901
	ds_bpermute_b32 v9, v13, v4                                // 00000075B68C: DACC0000 0900040D
	v_add_f32_e32 v5, v5, v11                                  // 00000075B694: 060A1705
	ds_bpermute_b32 v11, v13, v6                               // 00000075B698: DACC0000 0B00060D
	v_xor_b32_e32 v3, 1, v0                                    // 00000075B6A0: 3A060081
	s_waitcnt lgkmcnt(1)                                       // 00000075B6A4: BF89FC17
	v_add_f32_e32 v4, v4, v9                                   // 00000075B6A8: 06081304
	ds_bpermute_b32 v10, v13, v5                               // 00000075B6AC: DACC0000 0A00050D
	v_xor_b32_e32 v13, 2, v0                                   // 00000075B6B4: 3A1A0082
	s_waitcnt lgkmcnt(1)                                       // 00000075B6B8: BF89FC17
	v_add_f32_e32 v6, v6, v11                                  // 00000075B6BC: 060C1706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000075B6C0: BF870152
	v_cmp_gt_u32_e32 vcc_lo, 32, v13                           // 00000075B6C4: 7C981AA0
	s_waitcnt lgkmcnt(0)                                       // 00000075B6C8: BF89FC07
	v_add_f32_e32 v5, v5, v10                                  // 00000075B6CC: 060A1505
	v_cndmask_b32_e32 v13, v0, v13, vcc_lo                     // 00000075B6D0: 021A1B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 00000075B6D4: 7C9806A0
	v_dual_cndmask_b32 v0, v0, v3 :: v_dual_lshlrev_b32 v13, 2, v13// 00000075B6D8: CA620700 000C1A82
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000075B6E0: 7C943C80
	ds_bpermute_b32 v1, v13, v2                                // 00000075B6E4: DACC0000 0100020D
	ds_bpermute_b32 v10, v13, v4                               // 00000075B6EC: DACC0000 0A00040D
	ds_bpermute_b32 v12, v13, v6                               // 00000075B6F4: DACC0000 0C00060D
	ds_bpermute_b32 v9, v13, v7                                // 00000075B6FC: DACC0000 0900070D
	v_lshlrev_b32_e32 v14, 2, v0                               // 00000075B704: 301C0082
	s_and_b32 s0, vcc_lo, s0                                   // 00000075B708: 8B00006A
	s_waitcnt lgkmcnt(3)                                       // 00000075B70C: BF89FC37
	v_add_f32_e32 v3, v2, v1                                   // 00000075B710: 06060302
	s_waitcnt lgkmcnt(1)                                       // 00000075B714: BF89FC17
	v_dual_add_f32 v1, v4, v10 :: v_dual_add_f32 v4, v6, v12   // 00000075B718: C9081504 01041906
	ds_bpermute_b32 v11, v13, v5                               // 00000075B720: DACC0000 0B00050D
	ds_bpermute_b32 v13, v13, v8                               // 00000075B728: DACC0000 0D00080D
	ds_bpermute_b32 v6, v14, v1                                // 00000075B730: DACC0000 0600010E
	ds_bpermute_b32 v10, v14, v4                               // 00000075B738: DACC0000 0A00040E
	s_waitcnt lgkmcnt(3)                                       // 00000075B740: BF89FC37
	v_add_f32_e32 v2, v5, v11                                  // 00000075B744: 06041705
	s_waitcnt lgkmcnt(2)                                       // 00000075B748: BF89FC27
	v_add_f32_e32 v8, v8, v13                                  // 00000075B74C: 06101B08
	v_add_f32_e32 v0, v7, v9                                   // 00000075B750: 06001307
	ds_bpermute_b32 v9, v14, v3                                // 00000075B754: DACC0000 0900030E
	ds_bpermute_b32 v7, v14, v2                                // 00000075B75C: DACC0000 0700020E
	ds_bpermute_b32 v11, v14, v8                               // 00000075B764: DACC0000 0B00080E
	ds_bpermute_b32 v5, v14, v0                                // 00000075B76C: DACC0000 0500000E
	s_and_saveexec_b32 s1, s0                                  // 00000075B774: BE812000
	s_cbranch_execz 53                                         // 00000075B778: BFA50035 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi6ELi32ELi1ELb1ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1050>
	.long 0xd73c000c                                           // 00000075B77C: D73C000C
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000075B780: 02022E82
	s_waitcnt lgkmcnt(1)                                       // 00000075B784: BF89FC17
	v_dual_add_f32 v11, v8, v11 :: v_dual_add_f32 v14, v1, v6  // 00000075B788: C9081708 0B0E0D01
	v_add_f32_e32 v3, v3, v9                                   // 00000075B790: 06061303
	s_waitcnt lgkmcnt(0)                                       // 00000075B794: BF89FC07
	v_add_f32_e32 v15, v0, v5                                  // 00000075B798: 061E0B00
	s_lshl_b64 s[0:1], s[12:13], 2                             // 00000075B79C: 8480820C
	.long 0xd7006a08                                           // 00000075B7A0: D7006A08
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 00000075B7A4: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000075B7A8: BF870121
	v_add_co_ci_u32_e64 v9, null, s9, v13, vcc_lo              // 00000075B7AC: D5207C09 01AA1A09
	v_dual_add_f32 v12, v4, v10 :: v_dual_add_f32 v13, v2, v7  // 00000075B7B4: C9081504 0C0C0F02
	v_mad_u64_u32 v[0:1], null, s12, 12, v[8:9]                // 00000075B7BC: D6FE7C00 0421180C
	global_store_b32 v[8:9], v3, off                           // 00000075B7C4: DC6A0000 007C0308
	.long 0xd7006a03                                           // 00000075B7CC: D7006A03
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000075B7D0: 02000108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000075B7D4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s1, v9, vcc_lo               // 00000075B7D8: D5207C04 01AA1201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000075B7E0: 8480830C
	.long 0xd7006a05                                           // 00000075B7E4: D7006A05
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 00000075B7E8: 02000108
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 00000075B7EC: D6FE7C01 0405180D
	v_add_co_ci_u32_e64 v6, null, s1, v9, vcc_lo               // 00000075B7F4: D5207C06 01AA1201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000075B7FC: BF870093
	.long 0xd7006a07                                           // 00000075B800: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 00000075B804: 02000105
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 00000075B808: D5207C08 01AA0C01
	.long 0xd7006a09                                           // 00000075B810: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000075B814: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075B818: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 00000075B81C: D5207C0A 01AA0201
	s_clause 0x4                                               // 00000075B824: BF850004
	global_store_b32 v[3:4], v15, off                          // 00000075B828: DC6A0000 007C0F03
	global_store_b32 v[5:6], v14, off                          // 00000075B830: DC6A0000 007C0E05
	global_store_b32 v[0:1], v13, off                          // 00000075B838: DC6A0000 007C0D00
	global_store_b32 v[7:8], v12, off                          // 00000075B840: DC6A0000 007C0C07
	global_store_b32 v[9:10], v11, off                         // 00000075B848: DC6A0000 007C0B09
	s_endpgm                                                   // 00000075B850: BFB00000
		...

