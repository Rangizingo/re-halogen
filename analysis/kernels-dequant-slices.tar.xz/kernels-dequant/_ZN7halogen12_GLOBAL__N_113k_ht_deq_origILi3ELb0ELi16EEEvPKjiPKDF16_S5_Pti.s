000000000049db00 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti>:
; _ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti():
	s_clause 0x2                                               // 00000049DB00: BF850002
	s_load_b32 s6, s[0:1], 0x28                                // 00000049DB04: F4000180 F8000028
	s_load_b32 s10, s[0:1], 0x8                                // 00000049DB0C: F4000280 F8000008
	s_load_b64 s[4:5], s[0:1], null                            // 00000049DB14: F4040100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 31, v0          // 00000049DB1C: CA240080 0400009F
	v_bfe_u32 v29, v0, 5, 3                                    // 00000049DB24: D610001D 020D0B00
	v_lshrrev_b32_e32 v3, 6, v0                                // 00000049DB2C: 32060086
	s_mov_b32 s9, 0                                            // 00000049DB30: BE890080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000049DB34: BF8701A3
	v_lshl_or_b32 v5, v1, 3, 4                                 // 00000049DB38: D6560005 02110701
	v_mad_u32_u24 v30, v1, 24, 0x2f0                           // 00000049DB40: D60B001E 03FD3101 000002F0
	v_dual_mov_b32 v8, v4 :: v_dual_and_b32 v31, 4, v3         // 00000049DB4C: CA240104 081E0684
	v_or_b32_e32 v32, 3, v3                                    // 00000049DB54: 38400683
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049DB58: BF870214
	v_mad_u32_u24 v28, v5, 3, 0x2f0                            // 00000049DB5C: D60B001C 03FD0705 000002F0
	v_lshrrev_b32_e32 v9, 5, v30                               // 00000049DB68: 32123C85
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 00000049DB6C: 7C9A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049DB70: BF870193
	v_lshrrev_b32_e32 v11, 5, v28                              // 00000049DB74: 32163885
	v_subrev_nc_u32_e32 v3, 24, v9                             // 00000049DB78: 4E061298
	s_waitcnt lgkmcnt(0)                                       // 00000049DB7C: BF89FC07
	s_cmp_eq_u32 s6, 0                                         // 00000049DB80: BF068006
	v_add_nc_u32_e32 v12, 0xe9, v9                             // 00000049DB84: 4A1812FF 000000E9
	s_cselect_b32 s8, s3, s2                                   // 00000049DB8C: 98080203
	s_cselect_b32 s11, s2, s3                                  // 00000049DB90: 980B0302
	v_lshl_or_b32 v6, s8, 3, v29                               // 00000049DB94: D6560006 04750608
	s_ashr_i32 s2, s10, 31                                     // 00000049DB9C: 86029F0A
	.long 0xd7030002                                           // 00000049DBA0: D7030002
	v_cndmask_b32_e32 v0, v11, v129, vcc_lo                    // 00000049DBA4: 0201030B
	s_lshr_b32 s2, s2, 28                                      // 00000049DBA8: 85029C02
	v_cndmask_b32_e32 v3, 23, v3, vcc_lo                       // 00000049DBAC: 02060697
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000049DBB0: 340E0C9F
	s_add_i32 s2, s10, s2                                      // 00000049DBB4: 8102020A
	.long 0xd7624002                                           // 00000049DBB8: D7624002
	v_cndmask_b32_e32 v1, 0xff, v2, vcc_lo                     // 00000049DBBC: 020204FF 000000FF
	s_ashr_i32 s2, s2, 4                                       // 00000049DBC4: 86028402
	v_cmp_lt_u32_e32 vcc_lo, 5, v5                             // 00000049DBC8: 7C920A85
	v_mad_i64_i32 v[6:7], null, s11, s2, v[6:7]                // 00000049DBCC: D6FF7C06 0418040B
	v_and_b32_e32 v28, 0x7e0, v28                              // 00000049DBD4: 363838FF 000007E0
	.long 0xd7055002                                           // 00000049DBDC: D7055002
	v_cndmask_b32_e32 v1, 0xab, v2, vcc_lo                     // 00000049DBE0: 020204FF 000000AB
	s_movk_i32 s2, 0x1eee                                      // 00000049DBE8: B0021EEE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049DBEC: BF870112
	v_mad_i32_i24 v5, v5, -3, v28                              // 00000049DBF0: D60A0005 04718705
	.long 0xd7395002                                           // 00000049DBF8: D7395002
	v_cndmask_b32_e32 v1, 12, v2, vcc_lo                       // 00000049DBFC: 0202048C
	.long 0xd73c0009                                           // 00000049DC00: D73C0009
	v_cndmask_b32_e32 v1, 3, v6, vcc_lo                        // 00000049DC04: 02020C83
	v_subrev_nc_u32_e32 v7, 24, v11                            // 00000049DC08: 4E0E1698
	v_and_b32_e32 v6, 0xff, v12                                // 00000049DC0C: 360C18FF 000000FF
	v_add_nc_u32_e32 v57, 0xfffffd37, v5                       // 00000049DC14: 4A720AFF FFFFFD37
	.long 0xd7054802                                           // 00000049DC1C: D7054802
	v_cndmask_b32_e32 v0, v2, v152, vcc_lo                     // 00000049DC20: 02013102
	v_add_nc_u32_e32 v55, 0xfffffd3d, v5                       // 00000049DC24: 4A6E0AFF FFFFFD3D
	v_or_b32_e32 v11, v9, v31                                  // 00000049DC2C: 38163F09
	v_or_b32_e32 v12, v9, v32                                  // 00000049DC30: 38184109
	.long 0xd72c000d                                           // 00000049DC34: D72C000D
	v_cndmask_b32_e32 v1, 0x60, v10, vcc_lo                    // 00000049DC38: 020214FF 00000060
	.long 0xd7041002                                           // 00000049DC40: D7041002
	v_cndmask_b32_e32 v1, v2, v2, vcc_lo                       // 00000049DC44: 02020502
	v_cndmask_b32_e32 v7, 23, v7, vcc_lo                       // 00000049DC48: 020E0E97
	v_mad_u64_u32 v[9:10], null, 0x60, v11, s[4:5]             // 00000049DC4C: D6FE7C09 001216FF 00000060
	v_mad_u64_u32 v[11:12], null, 0x60, v12, s[4:5]            // 00000049DC58: D6FE7C0B 001218FF 00000060
	v_add_nc_u32_e32 v56, 0xfffffd3a, v5                       // 00000049DC64: 4A700AFF FFFFFD3A
	v_and_b32_e32 v14, 0xff, v2                                // 00000049DC6C: 361C04FF 000000FF
	.long 0xd73c0002                                           // 00000049DC74: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000049DC78: 02020682
	v_lshlrev_b32_e32 v4, 2, v6                                // 00000049DC7C: 30080C82
	.long 0xd73c0006                                           // 00000049DC80: D73C0006
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000049DC84: 02020E82
	v_add_nc_u32_e32 v5, 0xfffffd34, v5                        // 00000049DC88: 4A0A0AFF FFFFFD34
	v_add_nc_u32_e32 v10, v13, v10                             // 00000049DC90: 4A14150D
	v_add_nc_u32_e32 v24, v13, v12                             // 00000049DC94: 4A30190D
	.long 0xd7006a0c                                           // 00000049DC98: D7006A0C
	v_cndmask_b32_e32 v1, v9, v2, vcc_lo                       // 00000049DC9C: 02020509
	v_lshlrev_b32_e32 v20, 2, v14                              // 00000049DCA0: 30281C82
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049DCA4: BF8700A4
	v_add_co_ci_u32_e64 v13, null, v10, v3, vcc_lo             // 00000049DCA8: D5207C0D 01AA070A
	.long 0xd7006a0e                                           // 00000049DCB0: D7006A0E
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 00000049DCB4: 02020909
	v_add_co_ci_u32_e64 v15, null, 0, v10, vcc_lo              // 00000049DCB8: D5207C0F 01AA1480
	.long 0xd7006a10                                           // 00000049DCC0: D7006A10
	v_cndmask_b32_e32 v1, v9, v6, vcc_lo                       // 00000049DCC4: 02020D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049DCC8: BF8700A1
	v_add_co_ci_u32_e64 v17, null, v10, v7, vcc_lo             // 00000049DCCC: D5207C11 01AA0F0A
	.long 0xd7006a08                                           // 00000049DCD4: D7006A08
	v_cndmask_b32_e32 v1, v9, v20, vcc_lo                      // 00000049DCD8: 02022909
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000049DCDC: D5207C09 01AA1480
	.long 0xd7006a02                                           // 00000049DCE4: D7006A02
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 00000049DCE8: 0202050B
	s_clause 0x7                                               // 00000049DCEC: BF850007
	global_load_b32 v19, v[12:13], off                         // 00000049DCF0: DC520000 137C000C
	global_load_b32 v18, v[14:15], off                         // 00000049DCF8: DC520000 127C000E
	global_load_b32 v21, v[16:17], off                         // 00000049DD00: DC520000 157C0010
	global_load_b32 v23, v[12:13], off offset:96               // 00000049DD08: DC520060 177C000C
	global_load_b32 v22, v[14:15], off offset:96               // 00000049DD10: DC520060 167C000E
	global_load_b32 v25, v[16:17], off offset:96               // 00000049DD18: DC520060 197C0010
	global_load_b32 v14, v[14:15], off offset:192              // 00000049DD20: DC5200C0 0E7C000E
	global_load_b32 v15, v[12:13], off offset:192              // 00000049DD28: DC5200C0 0F7C000C
	v_add_co_ci_u32_e64 v3, null, v24, v3, vcc_lo              // 00000049DD30: D5207C03 01AA0718
	.long 0xd7006a0c                                           // 00000049DD38: D7006A0C
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 00000049DD3C: 0202090B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049DD40: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v24, vcc_lo              // 00000049DD44: D5207C0D 01AA3080
	.long 0xd7006a06                                           // 00000049DD4C: D7006A06
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 00000049DD50: 02020D0B
	v_add_co_ci_u32_e64 v7, null, v24, v7, vcc_lo              // 00000049DD54: D5207C07 01AA0F18
	.long 0xd7006a0a                                           // 00000049DD5C: D7006A0A
	v_cndmask_b32_e32 v1, v11, v20, vcc_lo                     // 00000049DD60: 0202290B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049DD64: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v24, vcc_lo              // 00000049DD68: D5207C0B 01AA3080
	s_clause 0x7                                               // 00000049DD70: BF850007
	global_load_b32 v20, v[8:9], off                           // 00000049DD74: DC520000 147C0008
	global_load_b32 v24, v[8:9], off offset:96                 // 00000049DD7C: DC520060 187C0008
	global_load_b32 v8, v[8:9], off offset:192                 // 00000049DD84: DC5200C0 087C0008
	global_load_b32 v27, v[2:3], off                           // 00000049DD8C: DC520000 1B7C0002
	global_load_b32 v26, v[12:13], off                         // 00000049DD94: DC520000 1A7C000C
	global_load_b32 v7, v[6:7], off                            // 00000049DD9C: DC520000 077C0006
	global_load_b32 v6, v[10:11], off                          // 00000049DDA4: DC520000 067C000A
	global_load_b32 v9, v[16:17], off offset:192               // 00000049DDAC: DC5200C0 097C0010
	v_lshrrev_b32_e32 v2, 1, v0                                // 00000049DDB4: 32040081
	v_and_b32_e32 v10, 15, v0                                  // 00000049DDB8: 3614008F
	v_and_b32_e32 v13, 0x7e0, v30                              // 00000049DDBC: 361A3CFF 000007E0
	v_lshlrev_b32_e32 v16, 4, v31                              // 00000049DDC4: 30203E84
	v_lshrrev_b32_e32 v3, 5, v0                                // 00000049DDC8: 32060085
	v_and_b32_e32 v11, 8, v2                                   // 00000049DDCC: 36160488
	v_lshlrev_b32_e32 v12, 9, v10                              // 00000049DDD0: 30181489
	v_mad_i32_i24 v13, 0xffffffe8, v1, v13                     // 00000049DDD4: D60A000D 043602FF FFFFFFE8
	v_lshl_or_b32 v17, v32, 4, v10                             // 00000049DDE0: D6560011 04290920
	v_or3_b32 v16, v16, v10, 16                                // 00000049DDE8: D6580010 02421510
	v_lshl_or_b32 v11, v29, 4, v11                             // 00000049DDF0: D656000B 042D091D
	v_lshl_or_b32 v12, v31, 13, v12                            // 00000049DDF8: D656000C 04311B1F
	v_add_nc_u32_e32 v39, 0xfffffd3d, v13                      // 00000049DE00: 4A4E1AFF FFFFFD3D
	v_add_nc_u32_e32 v40, 0xfffffd3a, v13                      // 00000049DE08: 4A501AFF FFFFFD3A
	v_add_nc_u32_e32 v41, 0xfffffd37, v13                      // 00000049DE10: 4A521AFF FFFFFD37
	v_xor_b32_e32 v29, v11, v10                                // 00000049DE18: 3A3A150B
	v_or_b32_e32 v30, 1, v11                                   // 00000049DE1C: 383C1681
	v_or_b32_e32 v31, 2, v11                                   // 00000049DE20: 383E1682
	v_or_b32_e32 v32, 3, v11                                   // 00000049DE24: 38401683
	v_or_b32_e32 v33, 4, v11                                   // 00000049DE28: 38421684
	v_or_b32_e32 v34, 5, v11                                   // 00000049DE2C: 38441685
	v_or_b32_e32 v35, 6, v11                                   // 00000049DE30: 38461686
	v_or_b32_e32 v36, 7, v11                                   // 00000049DE34: 38481687
	v_add_nc_u32_e32 v42, 0xfffffd34, v13                      // 00000049DE38: 4A541AFF FFFFFD34
	v_lshlrev_b32_e32 v13, 2, v29                              // 00000049DE40: 301A3A82
	v_xor_b32_e32 v28, v30, v10                                // 00000049DE44: 3A38151E
	v_xor_b32_e32 v29, v31, v10                                // 00000049DE48: 3A3A151F
	v_and_b32_e32 v38, 31, v17                                 // 00000049DE4C: 364C229F
	v_xor_b32_e32 v43, v32, v10                                // 00000049DE50: 3A561520
	v_xor_b32_e32 v44, v33, v10                                // 00000049DE54: 3A581521
	v_xor_b32_e32 v45, v34, v10                                // 00000049DE58: 3A5A1522
	v_xor_b32_e32 v46, v35, v10                                // 00000049DE5C: 3A5C1523
	v_xor_b32_e32 v10, v36, v10                                // 00000049DE60: 3A141524
	v_and_b32_e32 v47, 31, v16                                 // 00000049DE64: 365E209F
	v_or_b32_e32 v37, 0x4000, v12                              // 00000049DE68: 384A18FF 00004000
	v_lshlrev_b32_e32 v28, 2, v28                              // 00000049DE70: 30383882
	v_lshlrev_b32_e32 v29, 2, v29                              // 00000049DE74: 303A3A82
	v_lshlrev_b32_e32 v16, 9, v16                              // 00000049DE78: 30202089
	v_xor_b32_e32 v48, v11, v38                                // 00000049DE7C: 3A604D0B
	v_xor_b32_e32 v49, v30, v38                                // 00000049DE80: 3A624D1E
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000049DE84: 30141482
	v_xor_b32_e32 v11, v11, v47                                // 00000049DE88: 3A165F0B
	v_xor_b32_e32 v30, v30, v47                                // 00000049DE8C: 3A3C5F1E
	v_lshlrev_b32_e32 v17, 9, v17                              // 00000049DE90: 30222289
	v_xor_b32_e32 v50, v31, v38                                // 00000049DE94: 3A644D1F
	v_xor_b32_e32 v51, v32, v38                                // 00000049DE98: 3A664D20
	v_xor_b32_e32 v52, v33, v38                                // 00000049DE9C: 3A684D21
	v_xor_b32_e32 v53, v34, v38                                // 00000049DEA0: 3A6A4D22
	v_xor_b32_e32 v54, v35, v38                                // 00000049DEA4: 3A6C4D23
	v_xor_b32_e32 v38, v36, v38                                // 00000049DEA8: 3A4C4D24
	v_lshlrev_b32_e32 v43, 2, v43                              // 00000049DEAC: 30565682
	v_lshlrev_b32_e32 v44, 2, v44                              // 00000049DEB0: 30585882
	v_lshlrev_b32_e32 v45, 2, v45                              // 00000049DEB4: 305A5A82
	v_lshlrev_b32_e32 v46, 2, v46                              // 00000049DEB8: 305C5C82
	v_xor_b32_e32 v31, v31, v47                                // 00000049DEBC: 3A3E5F1F
	v_xor_b32_e32 v32, v32, v47                                // 00000049DEC0: 3A405F20
	v_xor_b32_e32 v33, v33, v47                                // 00000049DEC4: 3A425F21
	v_xor_b32_e32 v34, v34, v47                                // 00000049DEC8: 3A445F22
	v_xor_b32_e32 v35, v35, v47                                // 00000049DECC: 3A465F23
	v_xor_b32_e32 v36, v36, v47                                // 00000049DED0: 3A485F24
	v_or_b32_e32 v60, v12, v28                                 // 00000049DED4: 3878390C
	v_or_b32_e32 v61, v12, v29                                 // 00000049DED8: 387A3B0C
	v_or_b32_e32 v75, v37, v28                                 // 00000049DEDC: 38963925
	v_or_b32_e32 v76, v37, v29                                 // 00000049DEE0: 38983B25
	v_or_b32_e32 v66, v12, v10                                 // 00000049DEE4: 3884150C
	v_lshl_or_b32 v67, v11, 2, v16                             // 00000049DEE8: D6560043 0441050B
	v_lshl_or_b32 v68, v30, 2, v16                             // 00000049DEF0: D6560044 0441051E
	v_or_b32_e32 v77, v37, v10                                 // 00000049DEF8: 389A1525
	v_or_b32_e32 v58, v12, v13                                 // 00000049DEFC: 38741B0C
	v_lshl_or_b32 v48, v48, 2, v17                             // 00000049DF00: D6560030 04450530
	v_lshl_or_b32 v49, v49, 2, v17                             // 00000049DF08: D6560031 04450531
	v_lshl_or_b32 v50, v50, 2, v17                             // 00000049DF10: D6560032 04450532
	v_lshl_or_b32 v51, v51, 2, v17                             // 00000049DF18: D6560033 04450533
	v_lshl_or_b32 v52, v52, 2, v17                             // 00000049DF20: D6560034 04450534
	v_lshl_or_b32 v53, v53, 2, v17                             // 00000049DF28: D6560035 04450535
	v_lshl_or_b32 v54, v54, 2, v17                             // 00000049DF30: D6560036 04450536
	v_lshl_or_b32 v59, v38, 2, v17                             // 00000049DF38: D656003B 04450526
	v_or_b32_e32 v62, v12, v43                                 // 00000049DF40: 387C570C
	v_or_b32_e32 v63, v12, v44                                 // 00000049DF44: 387E590C
	v_or_b32_e32 v64, v12, v45                                 // 00000049DF48: 38805B0C
	v_or_b32_e32 v65, v12, v46                                 // 00000049DF4C: 38825D0C
	v_lshl_or_b32 v69, v31, 2, v16                             // 00000049DF50: D6560045 0441051F
	v_lshl_or_b32 v70, v32, 2, v16                             // 00000049DF58: D6560046 04410520
	v_lshl_or_b32 v71, v33, 2, v16                             // 00000049DF60: D6560047 04410521
	v_lshl_or_b32 v72, v34, 2, v16                             // 00000049DF68: D6560048 04410522
	v_lshl_or_b32 v73, v35, 2, v16                             // 00000049DF70: D6560049 04410523
	v_lshl_or_b32 v74, v36, 2, v16                             // 00000049DF78: D656004A 04410524
	v_or_b32_e32 v47, v37, v13                                 // 00000049DF80: 385E1B25
	v_or_b32_e32 v43, v37, v43                                 // 00000049DF84: 38565725
	v_or_b32_e32 v44, v37, v44                                 // 00000049DF88: 38585925
	v_or_b32_e32 v45, v37, v45                                 // 00000049DF8C: 385A5B25
	v_or_b32_e32 v46, v37, v46                                 // 00000049DF90: 385C5D25
	v_cmp_gt_u32_e32 vcc_lo, 0x200, v0                         // 00000049DF94: 7C9800FF 00000200
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000049DF9C: 360400FF 0000007F
	v_lshlrev_b32_e32 v4, 3, v3                                // 00000049DFA4: 30080683
	s_waitcnt vmcnt(14)                                        // 00000049DFA8: BF893BF7
	.long 0xd73d000a                                           // 00000049DFAC: D73D000A
	v_cndmask_b32_e32 v1, v39, v18, vcc_lo                     // 00000049DFB0: 02022527
	.long 0xd73d000b                                           // 00000049DFB4: D73D000B
	v_cndmask_b32_e32 v1, v40, v18, vcc_lo                     // 00000049DFB8: 02022528
	.long 0xd73d0010                                           // 00000049DFBC: D73D0010
	v_cndmask_b32_e32 v1, v42, v18, vcc_lo                     // 00000049DFC0: 0202252A
	.long 0xd73d000c                                           // 00000049DFC4: D73D000C
	v_cndmask_b32_e32 v1, v41, v18, vcc_lo                     // 00000049DFC8: 02022529
	s_waitcnt vmcnt(7)                                         // 00000049DFCC: BF891FF7
	.long 0xd73d001c                                           // 00000049DFD0: D73D001C
	v_cndmask_b32_e32 v1, v57, v20, vcc_lo                     // 00000049DFD4: 02022939
	.long 0xd73d001d                                           // 00000049DFD8: D73D001D
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 00000049DFDC: 02022D28
	.long 0xd73d001e                                           // 00000049DFE0: D73D001E
	v_cndmask_b32_e32 v1, v41, v22, vcc_lo                     // 00000049DFE4: 02022D29
	.long 0xd73d0011                                           // 00000049DFE8: D73D0011
	v_cndmask_b32_e32 v1, v55, v20, vcc_lo                     // 00000049DFEC: 02022937
	s_waitcnt vmcnt(6)                                         // 00000049DFF0: BF891BF7
	.long 0xd73d001f                                           // 00000049DFF4: D73D001F
	v_cndmask_b32_e32 v1, v56, v24, vcc_lo                     // 00000049DFF8: 02023138
	.long 0xd73d0012                                           // 00000049DFFC: D73D0012
	v_cndmask_b32_e32 v1, v56, v20, vcc_lo                     // 00000049E000: 02022938
	.long 0xd73d0020                                           // 00000049E004: D73D0020
	v_cndmask_b32_e32 v1, v57, v24, vcc_lo                     // 00000049E008: 02023139
	.long 0xd73d0013                                           // 00000049E00C: D73D0013
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000049E010: 02022905
	.long 0xd73d0021                                           // 00000049E014: D73D0021
	v_cndmask_b32_e32 v1, v40, v14, vcc_lo                     // 00000049E018: 02021D28
	.long 0xd73d0014                                           // 00000049E01C: D73D0014
	v_cndmask_b32_e32 v1, v39, v22, vcc_lo                     // 00000049E020: 02022D27
	.long 0xd73d0022                                           // 00000049E024: D73D0022
	v_cndmask_b32_e32 v1, v41, v14, vcc_lo                     // 00000049E028: 02021D29
	.long 0xd73d0015                                           // 00000049E02C: D73D0015
	v_cndmask_b32_e32 v1, v42, v22, vcc_lo                     // 00000049E030: 02022D2A
	s_waitcnt vmcnt(0)                                         // 00000049E034: BF8903F7
	.long 0xd73d0023                                           // 00000049E038: D73D0023
	v_cndmask_b32_e32 v1, v56, v8, vcc_lo                      // 00000049E03C: 02021138
	.long 0xd73d0016                                           // 00000049E040: D73D0016
	v_cndmask_b32_e32 v1, v55, v24, vcc_lo                     // 00000049E044: 02023137
	.long 0xd73d0024                                           // 00000049E048: D73D0024
	v_cndmask_b32_e32 v1, v57, v8, vcc_lo                      // 00000049E04C: 02021139
	.long 0xd73d0017                                           // 00000049E050: D73D0017
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 00000049E054: 02023105
	.long 0xd73d0025                                           // 00000049E058: D73D0025
	v_cndmask_b32_e32 v1, v39, v26, vcc_lo                     // 00000049E05C: 02023527
	.long 0xd73d0018                                           // 00000049E060: D73D0018
	v_cndmask_b32_e32 v1, v39, v14, vcc_lo                     // 00000049E064: 02021D27
	.long 0xd73d0026                                           // 00000049E068: D73D0026
	v_cndmask_b32_e32 v1, v40, v26, vcc_lo                     // 00000049E06C: 02023528
	.long 0xd73d0027                                           // 00000049E070: D73D0027
	v_cndmask_b32_e32 v1, v41, v26, vcc_lo                     // 00000049E074: 02023529
	.long 0xd73d000d                                           // 00000049E078: D73D000D
	v_cndmask_b32_e32 v1, v42, v14, vcc_lo                     // 00000049E07C: 02021D2A
	.long 0xd73d0019                                           // 00000049E080: D73D0019
	v_cndmask_b32_e32 v1, v42, v26, vcc_lo                     // 00000049E084: 0202352A
	.long 0xd73d0028                                           // 00000049E088: D73D0028
	v_cndmask_b32_e32 v1, v56, v6, vcc_lo                      // 00000049E08C: 02020D38
	.long 0xd73d000e                                           // 00000049E090: D73D000E
	v_cndmask_b32_e32 v1, v55, v8, vcc_lo                      // 00000049E094: 02021137
	.long 0xd73d0008                                           // 00000049E098: D73D0008
	v_cndmask_b32_e32 v1, v5, v8, vcc_lo                       // 00000049E09C: 02021105
	.long 0xd73d001a                                           // 00000049E0A0: D73D001A
	v_cndmask_b32_e32 v1, v55, v6, vcc_lo                      // 00000049E0A4: 02020D37
	.long 0xd73d0029                                           // 00000049E0A8: D73D0029
	v_cndmask_b32_e32 v1, v57, v6, vcc_lo                      // 00000049E0AC: 02020D39
	.long 0xd73d0005                                           // 00000049E0B0: D73D0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000049E0B4: 02020D05
	v_and_b32_e32 v6, 0xffff, v10                              // 00000049E0B8: 360C14FF 0000FFFF
	v_and_b32_e32 v9, 0xffff, v12                              // 00000049E0C0: 361218FF 0000FFFF
	v_and_b32_e32 v7, 0xffff, v11                              // 00000049E0C8: 360E16FF 0000FFFF
	v_and_b32_e32 v11, 0xffff, v17                             // 00000049E0D0: 361622FF 0000FFFF
	v_and_b32_e32 v10, 0xffff, v16                             // 00000049E0D8: 361420FF 0000FFFF
	v_and_b32_e32 v12, 0xffff, v18                             // 00000049E0E0: 361824FF 0000FFFF
	v_and_b32_e32 v15, 0xffff, v28                             // 00000049E0E8: 361E38FF 0000FFFF
	v_and_b32_e32 v16, 0xffff, v19                             // 00000049E0F0: 362026FF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v20                             // 00000049E0F8: 362228FF 0000FFFF
	v_and_b32_e32 v18, 0xffff, v29                             // 00000049E100: 36243AFF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v30                             // 00000049E108: 36263CFF 0000FFFF
	v_and_b32_e32 v20, 0xffff, v21                             // 00000049E110: 36282AFF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v22                             // 00000049E118: 362A2CFF 0000FFFF
	v_and_b32_e32 v22, 0xffff, v31                             // 00000049E120: 362C3EFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v32                             // 00000049E128: 363640FF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v24                             // 00000049E130: 363030FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v34                             // 00000049E138: 363A44FF 0000FFFF
	v_and_b32_e32 v14, 0xffff, v14                             // 00000049E140: 361C1CFF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v36                             // 00000049E148: 363E48FF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v37                             // 00000049E150: 36404AFF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v39                             // 00000049E158: 36444EFF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 00000049E160: 363434FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v41                             // 00000049E168: 364852FF 0000FFFF
	.long 0xd72c0006                                           // 00000049E170: D72C0006
	v_cndmask_b32_e32 v1, 0x83dcd12d, v6, vcc_lo               // 00000049E174: 02020CFF 83DCD12D
	.long 0xd72c0009                                           // 00000049E17C: D72C0009
	v_cndmask_b32_e32 v1, 0x83dcd12d, v9, vcc_lo               // 00000049E180: 020212FF 83DCD12D
	.long 0xd72c000b                                           // 00000049E188: D72C000B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v11, vcc_lo              // 00000049E18C: 020216FF 83DCD12D
	v_and_b32_e32 v23, 0xffff, v23                             // 00000049E194: 362E2EFF 0000FFFF
	v_and_b32_e32 v28, 0xffff, v33                             // 00000049E19C: 363842FF 0000FFFF
	v_and_b32_e32 v13, 0xffff, v13                             // 00000049E1A4: 361A1AFF 0000FFFF
	v_and_b32_e32 v30, 0xffff, v35                             // 00000049E1AC: 363C46FF 0000FFFF
	v_and_b32_e32 v8, 0xffff, v8                               // 00000049E1B4: 361010FF 0000FFFF
	v_and_b32_e32 v33, 0xffff, v38                             // 00000049E1BC: 36424CFF 0000FFFF
	v_and_b32_e32 v25, 0xffff, v25                             // 00000049E1C4: 363232FF 0000FFFF
	v_and_b32_e32 v35, 0xffff, v40                             // 00000049E1CC: 364650FF 0000FFFF
	v_and_b32_e32 v5, 0xffff, v5                               // 00000049E1D4: 360A0AFF 0000FFFF
	.long 0xd72c0007                                           // 00000049E1DC: D72C0007
	v_cndmask_b32_e32 v1, 0x83dcd12d, v7, vcc_lo               // 00000049E1E0: 02020EFF 83DCD12D
	.long 0xd72c000f                                           // 00000049E1E8: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000049E1EC: 02021EFF 83DCD12D
	.long 0xd72c0011                                           // 00000049E1F4: D72C0011
	v_cndmask_b32_e32 v1, 0x83dcd12d, v17, vcc_lo              // 00000049E1F8: 020222FF 83DCD12D
	.long 0xd72c0013                                           // 00000049E200: D72C0013
	v_cndmask_b32_e32 v1, 0x83dcd12d, v19, vcc_lo              // 00000049E204: 020226FF 83DCD12D
	.long 0xd72c0015                                           // 00000049E20C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 00000049E210: 02022AFF 83DCD12D
	.long 0xd72c001b                                           // 00000049E218: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 00000049E21C: 020236FF 83DCD12D
	.long 0xd72c0018                                           // 00000049E224: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v24, vcc_lo              // 00000049E228: 020230FF 83DCD12D
	.long 0xd72c001d                                           // 00000049E230: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 00000049E234: 02023AFF 83DCD12D
	.long 0xd72c000e                                           // 00000049E23C: D72C000E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v14, vcc_lo              // 00000049E240: 02021CFF 83DCD12D
	.long 0xd72c001f                                           // 00000049E248: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000049E24C: 02023EFF 83DCD12D
	.long 0xd72c0020                                           // 00000049E254: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 00000049E258: 020240FF 83DCD12D
	.long 0xd72c0022                                           // 00000049E260: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000049E264: 020244FF 83DCD12D
	.long 0xd72c001a                                           // 00000049E26C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000049E270: 020234FF 83DCD12D
	.long 0xd72c0024                                           // 00000049E278: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000049E27C: 020248FF 83DCD12D
	.long 0xd72c000a                                           // 00000049E284: D72C000A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v10, vcc_lo              // 00000049E288: 020214FF 83DCD12D
	v_sad_u8 v6, v6, 0, 0x6400                                 // 00000049E290: D6220006 03FD0106 00006400
	.long 0xd72c000c                                           // 00000049E29C: D72C000C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v12, vcc_lo              // 00000049E2A0: 020218FF 83DCD12D
	.long 0xd72c0010                                           // 00000049E2A8: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 00000049E2AC: 020220FF 83DCD12D
	.long 0xd72c0012                                           // 00000049E2B4: D72C0012
	v_cndmask_b32_e32 v1, 0x83dcd12d, v18, vcc_lo              // 00000049E2B8: 020224FF 83DCD12D
	.long 0xd72c0014                                           // 00000049E2C0: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 00000049E2C4: 020228FF 83DCD12D
	.long 0xd72c0016                                           // 00000049E2CC: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000049E2D0: 02022CFF 83DCD12D
	.long 0xd72c0017                                           // 00000049E2D8: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000049E2DC: 02022EFF 83DCD12D
	.long 0xd72c001c                                           // 00000049E2E4: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000049E2E8: 020238FF 83DCD12D
	.long 0xd72c000d                                           // 00000049E2F0: D72C000D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v13, vcc_lo              // 00000049E2F4: 02021AFF 83DCD12D
	.long 0xd72c001e                                           // 00000049E2FC: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000049E300: 02023CFF 83DCD12D
	.long 0xd72c0008                                           // 00000049E308: D72C0008
	v_cndmask_b32_e32 v1, 0x83dcd12d, v8, vcc_lo               // 00000049E30C: 020210FF 83DCD12D
	.long 0xd72c0021                                           // 00000049E314: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000049E318: 020242FF 83DCD12D
	.long 0xd72c0019                                           // 00000049E320: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 00000049E324: 020232FF 83DCD12D
	.long 0xd72c0023                                           // 00000049E32C: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000049E330: 020246FF 83DCD12D
	.long 0xd72c0005                                           // 00000049E338: D72C0005
	v_cndmask_b32_e32 v1, 0x83dcd12d, v5, vcc_lo               // 00000049E33C: 02020AFF 83DCD12D
	v_sad_u8 v9, v9, 0, 0x6400                                 // 00000049E344: D6220009 03FD0109 00006400
	v_sad_u8 v11, v11, 0, 0x6400                               // 00000049E350: D622000B 03FD010B 00006400
	v_sad_u8 v7, v7, 0, 0x6400                                 // 00000049E35C: D6220007 03FD0107 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 00000049E368: D622000F 03FD010F 00006400
	v_sad_u8 v17, v17, 0, 0x6400                               // 00000049E374: D6220011 03FD0111 00006400
	v_sad_u8 v19, v19, 0, 0x6400                               // 00000049E380: D6220013 03FD0113 00006400
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000049E38C: D6220015 03FD0115 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000049E398: D622001B 03FD011B 00006400
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000049E3A4: D6220018 03FD0118 00006400
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000049E3B0: D622001D 03FD011D 00006400
	v_sad_u8 v14, v14, 0, 0x6400                               // 00000049E3BC: D622000E 03FD010E 00006400
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000049E3C8: D622001F 03FD011F 00006400
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000049E3D4: D6220020 03FD0120 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000049E3E0: D6220022 03FD0122 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000049E3EC: D622001A 03FD011A 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000049E3F8: D6220024 03FD0124 00006400
	v_and_b32_e32 v6, 0xffff, v6                               // 00000049E404: 360C0CFF 0000FFFF
	v_sad_u8 v10, v10, 0, 0x6400                               // 00000049E40C: D622000A 03FD010A 00006400
	v_and_b32_e32 v9, 0xffff, v9                               // 00000049E418: 361212FF 0000FFFF
	v_sad_u8 v12, v12, 0, 0x6400                               // 00000049E420: D622000C 03FD010C 00006400
	v_and_b32_e32 v11, 0xffff, v11                             // 00000049E42C: 361616FF 0000FFFF
	v_sad_u8 v16, v16, 0, 0x6400                               // 00000049E434: D6220010 03FD0110 00006400
	v_sad_u8 v18, v18, 0, 0x6400                               // 00000049E440: D6220012 03FD0112 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 00000049E44C: D6220014 03FD0114 00006400
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000049E458: D6220016 03FD0116 00006400
	v_sad_u8 v23, v23, 0, 0x6400                               // 00000049E464: D6220017 03FD0117 00006400
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000049E470: D622001C 03FD011C 00006400
	v_sad_u8 v13, v13, 0, 0x6400                               // 00000049E47C: D622000D 03FD010D 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000049E488: D622001E 03FD011E 00006400
	v_sad_u8 v8, v8, 0, 0x6400                                 // 00000049E494: D6220008 03FD0108 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000049E4A0: D6220021 03FD0121 00006400
	v_sad_u8 v25, v25, 0, 0x6400                               // 00000049E4AC: D6220019 03FD0119 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000049E4B8: D6220023 03FD0123 00006400
	v_sad_u8 v5, v5, 0, 0x6400                                 // 00000049E4C4: D6220005 03FD0105 00006400
	v_and_b32_e32 v15, 0xffff, v15                             // 00000049E4D0: 361E1EFF 0000FFFF
	v_and_b32_e32 v17, 0xffff, v17                             // 00000049E4D8: 362222FF 0000FFFF
	v_and_b32_e32 v19, 0xffff, v19                             // 00000049E4E0: 362626FF 0000FFFF
	v_and_b32_e32 v21, 0xffff, v21                             // 00000049E4E8: 362A2AFF 0000FFFF
	v_and_b32_e32 v27, 0xffff, v27                             // 00000049E4F0: 363636FF 0000FFFF
	v_and_b32_e32 v24, 0xffff, v24                             // 00000049E4F8: 363030FF 0000FFFF
	v_and_b32_e32 v29, 0xffff, v29                             // 00000049E500: 363A3AFF 0000FFFF
	v_and_b32_e32 v14, 0xffff, v14                             // 00000049E508: 361C1CFF 0000FFFF
	v_and_b32_e32 v31, 0xffff, v31                             // 00000049E510: 363E3EFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 00000049E518: 364040FF 0000FFFF
	v_and_b32_e32 v34, 0xffff, v34                             // 00000049E520: 364444FF 0000FFFF
	v_and_b32_e32 v26, 0xffff, v26                             // 00000049E528: 363434FF 0000FFFF
	v_and_b32_e32 v36, 0xffff, v36                             // 00000049E530: 364848FF 0000FFFF
	v_lshl_or_b32 v6, v7, 16, v6                               // 00000049E538: D6560006 04192107
	v_lshl_or_b32 v7, v10, 16, v9                              // 00000049E540: D6560007 0425210A
	v_lshl_or_b32 v9, v12, 16, v11                             // 00000049E548: D6560009 042D210C
	v_lshl_or_b32 v10, v16, 16, v15                            // 00000049E550: D656000A 043D2110
	v_lshl_or_b32 v11, v18, 16, v17                            // 00000049E558: D656000B 04452112
	v_lshl_or_b32 v12, v20, 16, v19                            // 00000049E560: D656000C 044D2114
	v_lshl_or_b32 v15, v22, 16, v21                            // 00000049E568: D656000F 04552116
	v_lshl_or_b32 v16, v23, 16, v27                            // 00000049E570: D6560010 046D2117
	v_lshl_or_b32 v17, v28, 16, v24                            // 00000049E578: D6560011 0461211C
	v_lshl_or_b32 v13, v13, 16, v29                            // 00000049E580: D656000D 0475210D
	v_lshl_or_b32 v14, v30, 16, v14                            // 00000049E588: D656000E 0439211E
	v_lshl_or_b32 v8, v8, 16, v31                              // 00000049E590: D6560008 047D2108
	v_lshl_or_b32 v18, v33, 16, v32                            // 00000049E598: D6560012 04812121
	v_lshl_or_b32 v19, v25, 16, v34                            // 00000049E5A0: D6560013 04892119
	v_lshl_or_b32 v20, v35, 16, v26                            // 00000049E5A8: D6560014 04692123
	v_lshl_or_b32 v5, v5, 16, v36                              // 00000049E5B0: D6560005 04912105
	v_pk_fma_f16 v6, v6, s2, 0xc931 op_sel_hi:[1,0,0]          // 00000049E5B8: CC0E0006 0BFC0506 0000C931
	v_pk_fma_f16 v7, v7, s2, 0xc931 op_sel_hi:[1,0,0]          // 00000049E5C4: CC0E0007 0BFC0507 0000C931
	v_pk_fma_f16 v9, v9, s2, 0xc931 op_sel_hi:[1,0,0]          // 00000049E5D0: CC0E0009 0BFC0509 0000C931
	v_pk_fma_f16 v10, v10, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E5DC: CC0E000A 0BFC050A 0000C931
	v_pk_fma_f16 v11, v11, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E5E8: CC0E000B 0BFC050B 0000C931
	v_pk_fma_f16 v12, v12, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E5F4: CC0E000C 0BFC050C 0000C931
	v_pk_fma_f16 v15, v15, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E600: CC0E000F 0BFC050F 0000C931
	v_pk_fma_f16 v16, v16, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E60C: CC0E0010 0BFC0510 0000C931
	v_pk_fma_f16 v17, v17, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E618: CC0E0011 0BFC0511 0000C931
	v_pk_fma_f16 v13, v13, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E624: CC0E000D 0BFC050D 0000C931
	v_pk_fma_f16 v14, v14, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E630: CC0E000E 0BFC050E 0000C931
	v_pk_fma_f16 v8, v8, s2, 0xc931 op_sel_hi:[1,0,0]          // 00000049E63C: CC0E0008 0BFC0508 0000C931
	v_pk_fma_f16 v18, v18, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E648: CC0E0012 0BFC0512 0000C931
	v_pk_fma_f16 v19, v19, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E654: CC0E0013 0BFC0513 0000C931
	v_pk_fma_f16 v20, v20, s2, 0xc931 op_sel_hi:[1,0,0]        // 00000049E660: CC0E0014 0BFC0514 0000C931
	v_pk_fma_f16 v5, v5, s2, 0xc931 op_sel_hi:[1,0,0]          // 00000049E66C: CC0E0005 0BFC0505 0000C931
	v_cvt_f32_f16_e32 v21, v134/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E678: 7E2A1786
	v_cvt_f32_f16_e32 v6, v6                                   // 00000049E67C: 7E0C1706
	v_cvt_f32_f16_e32 v22, v135/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E680: 7E2C1787
	v_cvt_f32_f16_e32 v7, v7                                   // 00000049E684: 7E0E1707
	v_cvt_f32_f16_e32 v23, v137/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E688: 7E2E1789
	v_cvt_f32_f16_e32 v9, v9                                   // 00000049E68C: 7E121709
	v_cvt_f32_f16_e32 v24, v138/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E690: 7E30178A
	v_cvt_f32_f16_e32 v10, v10                                 // 00000049E694: 7E14170A
	v_cvt_f32_f16_e32 v25, v139/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E698: 7E32178B
	v_cvt_f32_f16_e32 v11, v11                                 // 00000049E69C: 7E16170B
	v_cvt_f32_f16_e32 v26, v140/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6A0: 7E34178C
	v_cvt_f32_f16_e32 v12, v12                                 // 00000049E6A4: 7E18170C
	v_cvt_f32_f16_e32 v27, v143/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6A8: 7E36178F
	v_cvt_f32_f16_e32 v15, v15                                 // 00000049E6AC: 7E1E170F
	v_cvt_f32_f16_e32 v28, v144/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6B0: 7E381790
	v_cvt_f32_f16_e32 v16, v16                                 // 00000049E6B4: 7E201710
	v_cvt_f32_f16_e32 v29, v145/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6B8: 7E3A1791
	v_cvt_f32_f16_e32 v17, v17                                 // 00000049E6BC: 7E221711
	v_cvt_f32_f16_e32 v30, v141/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6C0: 7E3C178D
	v_cvt_f32_f16_e32 v13, v13                                 // 00000049E6C4: 7E1A170D
	v_cvt_f32_f16_e32 v31, v142/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6C8: 7E3E178E
	v_cvt_f32_f16_e32 v14, v14                                 // 00000049E6CC: 7E1C170E
	v_cvt_f32_f16_e32 v32, v136/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6D0: 7E401788
	v_cvt_f32_f16_e32 v8, v8                                   // 00000049E6D4: 7E101708
	v_cvt_f32_f16_e32 v33, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6D8: 7E421792
	v_cvt_f32_f16_e32 v18, v18                                 // 00000049E6DC: 7E241712
	v_cvt_f32_f16_e32 v34, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6E0: 7E441793
	v_cvt_f32_f16_e32 v19, v19                                 // 00000049E6E4: 7E261713
	v_cvt_f32_f16_e32 v35, v148/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6E8: 7E461794
	v_cvt_f32_f16_e32 v20, v20                                 // 00000049E6EC: 7E281714
	v_cvt_f32_f16_e32 v36, v133/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000049E6F0: 7E481785
	v_cvt_f32_f16_e32 v5, v5                                   // 00000049E6F4: 7E0A1705
	ds_store_b32 v58, v6                                       // 00000049E6F8: D8340000 0000063A
	ds_store_b32 v60, v21                                      // 00000049E700: D8340000 0000153C
	ds_store_b32 v61, v7                                       // 00000049E708: D8340000 0000073D
	ds_store_b32 v62, v22                                      // 00000049E710: D8340000 0000163E
	ds_store_b32 v63, v9                                       // 00000049E718: D8340000 0000093F
	ds_store_b32 v64, v23                                      // 00000049E720: D8340000 00001740
	ds_store_b32 v65, v10                                      // 00000049E728: D8340000 00000A41
	ds_store_b32 v66, v24                                      // 00000049E730: D8340000 00001842
	ds_store_b32 v67, v11                                      // 00000049E738: D8340000 00000B43
	ds_store_b32 v68, v25                                      // 00000049E740: D8340000 00001944
	ds_store_b32 v69, v12                                      // 00000049E748: D8340000 00000C45
	ds_store_b32 v70, v26                                      // 00000049E750: D8340000 00001A46
	ds_store_b32 v71, v15                                      // 00000049E758: D8340000 00000F47
	ds_store_b32 v72, v27                                      // 00000049E760: D8340000 00001B48
	ds_store_b32 v73, v16                                      // 00000049E768: D8340000 00001049
	ds_store_b32 v74, v28                                      // 00000049E770: D8340000 00001C4A
	ds_store_b32 v47, v17                                      // 00000049E778: D8340000 0000112F
	ds_store_b32 v75, v29                                      // 00000049E780: D8340000 00001D4B
	ds_store_b32 v76, v13                                      // 00000049E788: D8340000 00000D4C
	ds_store_b32 v43, v30                                      // 00000049E790: D8340000 00001E2B
	ds_store_b32 v44, v14                                      // 00000049E798: D8340000 00000E2C
	ds_store_b32 v45, v31                                      // 00000049E7A0: D8340000 00001F2D
	ds_store_b32 v46, v8                                       // 00000049E7A8: D8340000 0000082E
	ds_store_b32 v77, v32                                      // 00000049E7B0: D8340000 0000204D
	ds_store_b32 v48, v18                                      // 00000049E7B8: D8340000 00001230
	ds_store_b32 v49, v33                                      // 00000049E7C0: D8340000 00002131
	ds_store_b32 v50, v19                                      // 00000049E7C8: D8340000 00001332
	ds_store_b32 v51, v34                                      // 00000049E7D0: D8340000 00002233
	ds_store_b32 v52, v20                                      // 00000049E7D8: D8340000 00001434
	ds_store_b32 v53, v35                                      // 00000049E7E0: D8340000 00002335
	ds_store_b32 v54, v5                                       // 00000049E7E8: D8340000 00000536
	ds_store_b32 v59, v36                                      // 00000049E7F0: D8340000 0000243B
	s_waitcnt lgkmcnt(0)                                       // 00000049E7F8: BF89FC07
	s_barrier                                                  // 00000049E7FC: BFBD0000
	buffer_gl0_inv                                             // 00000049E800: E0AC0000 00000000
	s_and_saveexec_b32 s2, vcc_lo                              // 00000049E808: BE82206A
	s_cbranch_execz 437                                        // 00000049E80C: BFA501B5 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti+0x13e4>
	v_and_b32_e32 v6, 0x60, v0                                 // 00000049E810: 360C00FF 00000060
	v_and_or_b32 v5, 0x60, v4, v1                              // 00000049E818: D6570005 040608FF 00000060
	s_delay_alu instid0(VALU_DEP_2)                            // 00000049E824: BF870002
	v_or_b32_e32 v7, 1, v6                                     // 00000049E828: 380E0C81
	v_or_b32_e32 v8, 2, v6                                     // 00000049E82C: 38100C82
	v_or_b32_e32 v9, 3, v6                                     // 00000049E830: 38120C83
	v_or_b32_e32 v10, 4, v6                                    // 00000049E834: 38140C84
	v_lshlrev_b32_e32 v5, 9, v5                                // 00000049E838: 300A0A89
	v_or_b32_e32 v11, 5, v6                                    // 00000049E83C: 38160C85
	v_or_b32_e32 v13, 6, v6                                    // 00000049E840: 381A0C86
	v_or_b32_e32 v14, 7, v6                                    // 00000049E844: 381C0C87
	v_xor_b32_e32 v7, v7, v1                                   // 00000049E848: 3A0E0307
	v_xor_b32_e32 v8, v8, v1                                   // 00000049E84C: 3A100308
	v_xor_b32_e32 v9, v9, v1                                   // 00000049E850: 3A120309
	v_xor_b32_e32 v10, v10, v1                                 // 00000049E854: 3A14030A
	v_lshl_or_b32 v12, v2, 2, v5                               // 00000049E858: D656000C 04150502
	v_xor_b32_e32 v11, v11, v1                                 // 00000049E860: 3A16030B
	v_xor_b32_e32 v13, v13, v1                                 // 00000049E864: 3A1A030D
	v_xor_b32_e32 v14, v14, v1                                 // 00000049E868: 3A1C030E
	v_lshl_or_b32 v7, v7, 2, v5                                // 00000049E86C: D6560007 04150507
	v_lshl_or_b32 v8, v8, 2, v5                                // 00000049E874: D6560008 04150508
	v_lshl_or_b32 v9, v9, 2, v5                                // 00000049E87C: D6560009 04150509
	v_lshl_or_b32 v10, v10, 2, v5                              // 00000049E884: D656000A 0415050A
	v_lshl_or_b32 v11, v11, 2, v5                              // 00000049E88C: D656000B 0415050B
	v_lshl_or_b32 v13, v13, 2, v5                              // 00000049E894: D656000D 0415050D
	v_lshl_or_b32 v14, v14, 2, v5                              // 00000049E89C: D656000E 0415050E
	ds_load_b32 v19, v12                                       // 00000049E8A4: D8D80000 1300000C
	ds_load_b32 v20, v7                                        // 00000049E8AC: D8D80000 14000007
	ds_load_b32 v21, v8                                        // 00000049E8B4: D8D80000 15000008
	ds_load_b32 v22, v9                                        // 00000049E8BC: D8D80000 16000009
	ds_load_b32 v23, v10                                       // 00000049E8C4: D8D80000 1700000A
	ds_load_b32 v24, v11                                       // 00000049E8CC: D8D80000 1800000B
	ds_load_b32 v25, v13                                       // 00000049E8D4: D8D80000 1900000D
	ds_load_b32 v26, v14                                       // 00000049E8DC: D8D80000 1A00000E
	s_waitcnt lgkmcnt(6)                                       // 00000049E8E4: BF89FC67
	v_add_f32_e32 v69, v19, v20                                // 00000049E8E8: 068A2913
	s_waitcnt lgkmcnt(4)                                       // 00000049E8EC: BF89FC47
	v_dual_sub_f32 v19, v19, v20 :: v_dual_add_f32 v20, v21, v22// 00000049E8F0: C9482913 13142D15
	v_sub_f32_e32 v21, v21, v22                                // 00000049E8F8: 082A2D15
	v_or_b32_e32 v15, 8, v6                                    // 00000049E8FC: 381E0C88
	v_or_b32_e32 v31, 16, v6                                   // 00000049E900: 383E0C90
	v_or_b32_e32 v47, 24, v6                                   // 00000049E904: 385E0C98
	v_or_b32_e32 v16, 9, v6                                    // 00000049E908: 38200C89
	v_or_b32_e32 v32, 17, v6                                   // 00000049E90C: 38400C91
	v_or_b32_e32 v48, 25, v6                                   // 00000049E910: 38600C99
	v_or_b32_e32 v17, 10, v6                                   // 00000049E914: 38220C8A
	v_or_b32_e32 v33, 18, v6                                   // 00000049E918: 38420C92
	v_or_b32_e32 v49, 26, v6                                   // 00000049E91C: 38620C9A
	v_or_b32_e32 v18, 11, v6                                   // 00000049E920: 38240C8B
	v_or_b32_e32 v42, 19, v6                                   // 00000049E924: 38540C93
	v_or_b32_e32 v58, 27, v6                                   // 00000049E928: 38740C9B
	v_or_b32_e32 v27, 12, v6                                   // 00000049E92C: 38360C8C
	v_or_b32_e32 v43, 20, v6                                   // 00000049E930: 38560C94
	v_or_b32_e32 v59, 28, v6                                   // 00000049E934: 38760C9C
	v_xor_b32_e32 v15, v15, v1                                 // 00000049E938: 3A1E030F
	v_or_b32_e32 v28, 13, v6                                   // 00000049E93C: 38380C8D
	v_or_b32_e32 v29, 14, v6                                   // 00000049E940: 383A0C8E
	v_or_b32_e32 v30, 15, v6                                   // 00000049E944: 383C0C8F
	v_xor_b32_e32 v31, v31, v1                                 // 00000049E948: 3A3E031F
	v_or_b32_e32 v44, 21, v6                                   // 00000049E94C: 38580C95
	v_or_b32_e32 v45, 22, v6                                   // 00000049E950: 385A0C96
	v_or_b32_e32 v46, 23, v6                                   // 00000049E954: 385C0C97
	v_xor_b32_e32 v47, v47, v1                                 // 00000049E958: 3A5E032F
	v_or_b32_e32 v60, 29, v6                                   // 00000049E95C: 38780C9D
	v_or_b32_e32 v61, 30, v6                                   // 00000049E960: 387A0C9E
	v_or_b32_e32 v6, 31, v6                                    // 00000049E964: 380C0C9F
	v_xor_b32_e32 v16, v16, v1                                 // 00000049E968: 3A200310
	v_xor_b32_e32 v32, v32, v1                                 // 00000049E96C: 3A400320
	v_xor_b32_e32 v48, v48, v1                                 // 00000049E970: 3A600330
	v_xor_b32_e32 v17, v17, v1                                 // 00000049E974: 3A220311
	v_xor_b32_e32 v33, v33, v1                                 // 00000049E978: 3A420321
	v_xor_b32_e32 v49, v49, v1                                 // 00000049E97C: 3A620331
	v_xor_b32_e32 v18, v18, v1                                 // 00000049E980: 3A240312
	v_xor_b32_e32 v42, v42, v1                                 // 00000049E984: 3A54032A
	v_xor_b32_e32 v58, v58, v1                                 // 00000049E988: 3A74033A
	v_xor_b32_e32 v27, v27, v1                                 // 00000049E98C: 3A36031B
	v_xor_b32_e32 v43, v43, v1                                 // 00000049E990: 3A56032B
	v_xor_b32_e32 v59, v59, v1                                 // 00000049E994: 3A76033B
	v_lshl_or_b32 v15, v15, 2, v5                              // 00000049E998: D656000F 0415050F
	v_xor_b32_e32 v28, v28, v1                                 // 00000049E9A0: 3A38031C
	v_xor_b32_e32 v29, v29, v1                                 // 00000049E9A4: 3A3A031D
	v_xor_b32_e32 v30, v30, v1                                 // 00000049E9A8: 3A3C031E
	v_lshl_or_b32 v31, v31, 2, v5                              // 00000049E9AC: D656001F 0415051F
	v_xor_b32_e32 v44, v44, v1                                 // 00000049E9B4: 3A58032C
	v_xor_b32_e32 v45, v45, v1                                 // 00000049E9B8: 3A5A032D
	v_xor_b32_e32 v46, v46, v1                                 // 00000049E9BC: 3A5C032E
	v_lshl_or_b32 v47, v47, 2, v5                              // 00000049E9C0: D656002F 0415052F
	v_xor_b32_e32 v60, v60, v1                                 // 00000049E9C8: 3A78033C
	v_xor_b32_e32 v61, v61, v1                                 // 00000049E9CC: 3A7A033D
	v_xor_b32_e32 v6, v6, v1                                   // 00000049E9D0: 3A0C0306
	v_lshl_or_b32 v16, v16, 2, v5                              // 00000049E9D4: D6560010 04150510
	v_lshl_or_b32 v32, v32, 2, v5                              // 00000049E9DC: D6560020 04150520
	v_lshl_or_b32 v48, v48, 2, v5                              // 00000049E9E4: D6560030 04150530
	v_lshl_or_b32 v17, v17, 2, v5                              // 00000049E9EC: D6560011 04150511
	v_lshl_or_b32 v33, v33, 2, v5                              // 00000049E9F4: D6560021 04150521
	v_lshl_or_b32 v49, v49, 2, v5                              // 00000049E9FC: D6560031 04150531
	v_lshl_or_b32 v18, v18, 2, v5                              // 00000049EA04: D6560012 04150512
	v_lshl_or_b32 v42, v42, 2, v5                              // 00000049EA0C: D656002A 0415052A
	v_lshl_or_b32 v58, v58, 2, v5                              // 00000049EA14: D656003A 0415053A
	v_lshl_or_b32 v27, v27, 2, v5                              // 00000049EA1C: D656001B 0415051B
	v_lshl_or_b32 v43, v43, 2, v5                              // 00000049EA24: D656002B 0415052B
	v_lshl_or_b32 v59, v59, 2, v5                              // 00000049EA2C: D656003B 0415053B
	v_lshl_or_b32 v28, v28, 2, v5                              // 00000049EA34: D656001C 0415051C
	v_lshl_or_b32 v29, v29, 2, v5                              // 00000049EA3C: D656001D 0415051D
	v_lshl_or_b32 v30, v30, 2, v5                              // 00000049EA44: D656001E 0415051E
	ds_load_b32 v34, v15                                       // 00000049EA4C: D8D80000 2200000F
	ds_load_b32 v35, v16                                       // 00000049EA54: D8D80000 23000010
	ds_load_b32 v36, v17                                       // 00000049EA5C: D8D80000 24000011
	ds_load_b32 v37, v18                                       // 00000049EA64: D8D80000 25000012
	ds_load_b32 v38, v27                                       // 00000049EA6C: D8D80000 2600001B
	ds_load_b32 v39, v28                                       // 00000049EA74: D8D80000 2700001C
	ds_load_b32 v40, v29                                       // 00000049EA7C: D8D80000 2800001D
	ds_load_b32 v41, v30                                       // 00000049EA84: D8D80000 2900001E
	v_lshl_or_b32 v44, v44, 2, v5                              // 00000049EA8C: D656002C 0415052C
	v_lshl_or_b32 v45, v45, 2, v5                              // 00000049EA94: D656002D 0415052D
	v_lshl_or_b32 v46, v46, 2, v5                              // 00000049EA9C: D656002E 0415052E
	ds_load_b32 v50, v31                                       // 00000049EAA4: D8D80000 3200001F
	ds_load_b32 v51, v32                                       // 00000049EAAC: D8D80000 33000020
	ds_load_b32 v52, v33                                       // 00000049EAB4: D8D80000 34000021
	ds_load_b32 v53, v42                                       // 00000049EABC: D8D80000 3500002A
	ds_load_b32 v54, v43                                       // 00000049EAC4: D8D80000 3600002B
	ds_load_b32 v55, v44                                       // 00000049EACC: D8D80000 3700002C
	ds_load_b32 v56, v45                                       // 00000049EAD4: D8D80000 3800002D
	ds_load_b32 v57, v46                                       // 00000049EADC: D8D80000 3900002E
	v_lshl_or_b32 v60, v60, 2, v5                              // 00000049EAE4: D656003C 0415053C
	v_lshl_or_b32 v61, v61, 2, v5                              // 00000049EAEC: D656003D 0415053D
	v_lshl_or_b32 v5, v6, 2, v5                                // 00000049EAF4: D6560005 04150506
	ds_load_b32 v6, v47                                        // 00000049EAFC: D8D80000 0600002F
	ds_load_b32 v62, v48                                       // 00000049EB04: D8D80000 3E000030
	ds_load_b32 v63, v49                                       // 00000049EB0C: D8D80000 3F000031
	ds_load_b32 v64, v58                                       // 00000049EB14: D8D80000 4000003A
	ds_load_b32 v65, v59                                       // 00000049EB1C: D8D80000 4100003B
	ds_load_b32 v66, v60                                       // 00000049EB24: D8D80000 4200003C
	ds_load_b32 v67, v61                                       // 00000049EB2C: D8D80000 4300003D
	ds_load_b32 v68, v5                                        // 00000049EB34: D8D80000 44000005
	s_waitcnt lgkmcnt(26)                                      // 00000049EB3C: BF89FDA7
	v_add_f32_e32 v22, v23, v24                                // 00000049EB40: 062C3117
	s_waitcnt lgkmcnt(24)                                      // 00000049EB44: BF89FD87
	v_dual_sub_f32 v23, v23, v24 :: v_dual_add_f32 v24, v25, v26// 00000049EB48: C9483117 17183519
	s_waitcnt lgkmcnt(22)                                      // 00000049EB50: BF89FD67
	v_dual_sub_f32 v25, v25, v26 :: v_dual_add_f32 v26, v34, v35// 00000049EB54: C9483519 191A4722
	s_waitcnt lgkmcnt(20)                                      // 00000049EB5C: BF89FD47
	v_dual_sub_f32 v34, v34, v35 :: v_dual_add_f32 v35, v36, v37// 00000049EB60: C9484722 22224B24
	s_waitcnt lgkmcnt(18)                                      // 00000049EB68: BF89FD27
	v_dual_sub_f32 v36, v36, v37 :: v_dual_add_f32 v37, v38, v39// 00000049EB6C: C9484B24 24244F26
	s_waitcnt lgkmcnt(16)                                      // 00000049EB74: BF89FD07
	v_dual_sub_f32 v38, v38, v39 :: v_dual_add_f32 v39, v40, v41// 00000049EB78: C9484F26 26265328
	s_waitcnt lgkmcnt(14)                                      // 00000049EB80: BF89FCE7
	v_dual_sub_f32 v40, v40, v41 :: v_dual_add_f32 v41, v50, v51// 00000049EB84: C9485328 28286732
	s_waitcnt lgkmcnt(12)                                      // 00000049EB8C: BF89FCC7
	v_dual_sub_f32 v50, v50, v51 :: v_dual_add_f32 v51, v52, v53// 00000049EB90: C9486732 32326B34
	s_waitcnt lgkmcnt(10)                                      // 00000049EB98: BF89FCA7
	v_dual_sub_f32 v52, v52, v53 :: v_dual_add_f32 v53, v54, v55// 00000049EB9C: C9486B34 34346F36
	s_waitcnt lgkmcnt(8)                                       // 00000049EBA4: BF89FC87
	v_dual_sub_f32 v54, v54, v55 :: v_dual_add_f32 v55, v56, v57// 00000049EBA8: C9486F36 36367338
	s_waitcnt lgkmcnt(6)                                       // 00000049EBB0: BF89FC67
	v_dual_sub_f32 v56, v56, v57 :: v_dual_add_f32 v57, v6, v62// 00000049EBB4: C9487338 38387D06
	v_sub_f32_e32 v6, v6, v62                                  // 00000049EBBC: 080C7D06
	s_waitcnt lgkmcnt(4)                                       // 00000049EBC0: BF89FC47
	v_add_f32_e32 v62, v63, v64                                // 00000049EBC4: 067C813F
	s_waitcnt lgkmcnt(2)                                       // 00000049EBC8: BF89FC27
	v_dual_sub_f32 v63, v63, v64 :: v_dual_add_f32 v64, v65, v66// 00000049EBCC: C948813F 3F408541
	s_waitcnt lgkmcnt(0)                                       // 00000049EBD4: BF89FC07
	v_dual_sub_f32 v65, v65, v66 :: v_dual_add_f32 v66, v67, v68// 00000049EBD8: C9488541 41428943
	v_sub_f32_e32 v67, v67, v68                                // 00000049EBE0: 08868943
	v_add_f32_e32 v68, v69, v20                                // 00000049EBE4: 06882945
	v_dual_sub_f32 v20, v69, v20 :: v_dual_add_f32 v69, v19, v21// 00000049EBE8: C9482945 14442B13
	v_sub_f32_e32 v19, v19, v21                                // 00000049EBF0: 08262B13
	v_add_f32_e32 v21, v22, v24                                // 00000049EBF4: 062A3116
	v_sub_f32_e32 v22, v22, v24                                // 00000049EBF8: 082C3116
	v_add_f32_e32 v24, v23, v25                                // 00000049EBFC: 06303317
	v_sub_f32_e32 v23, v23, v25                                // 00000049EC00: 082E3317
	v_add_f32_e32 v25, v26, v35                                // 00000049EC04: 0632471A
	v_sub_f32_e32 v26, v26, v35                                // 00000049EC08: 0834471A
	v_add_f32_e32 v35, v34, v36                                // 00000049EC0C: 06464922
	v_sub_f32_e32 v34, v34, v36                                // 00000049EC10: 08444922
	v_add_f32_e32 v36, v37, v39                                // 00000049EC14: 06484F25
	v_sub_f32_e32 v37, v37, v39                                // 00000049EC18: 084A4F25
	v_add_f32_e32 v39, v38, v40                                // 00000049EC1C: 064E5126
	v_sub_f32_e32 v38, v38, v40                                // 00000049EC20: 084C5126
	v_add_f32_e32 v40, v41, v51                                // 00000049EC24: 06506729
	v_sub_f32_e32 v41, v41, v51                                // 00000049EC28: 08526729
	v_add_f32_e32 v51, v50, v52                                // 00000049EC2C: 06666932
	v_sub_f32_e32 v50, v50, v52                                // 00000049EC30: 08646932
	v_add_f32_e32 v52, v53, v55                                // 00000049EC34: 06686F35
	v_sub_f32_e32 v53, v53, v55                                // 00000049EC38: 086A6F35
	v_add_f32_e32 v55, v54, v56                                // 00000049EC3C: 066E7136
	v_sub_f32_e32 v54, v54, v56                                // 00000049EC40: 086C7136
	v_add_f32_e32 v56, v57, v62                                // 00000049EC44: 06707D39
	v_dual_sub_f32 v57, v57, v62 :: v_dual_add_f32 v62, v6, v63// 00000049EC48: C9487D39 393E7F06
	v_dual_sub_f32 v6, v6, v63 :: v_dual_add_f32 v63, v64, v66 // 00000049EC50: C9487F06 063E8540
	v_sub_f32_e32 v64, v64, v66                                // 00000049EC58: 08808540
	v_add_f32_e32 v66, v65, v67                                // 00000049EC5C: 06848741
	v_sub_f32_e32 v65, v65, v67                                // 00000049EC60: 08828741
	v_add_f32_e32 v67, v68, v21                                // 00000049EC64: 06862B44
	v_dual_sub_f32 v21, v68, v21 :: v_dual_add_f32 v68, v69, v24// 00000049EC68: C9482B44 15443145
	v_dual_sub_f32 v24, v69, v24 :: v_dual_add_f32 v69, v20, v22// 00000049EC70: C9483145 18442D14
	v_sub_f32_e32 v20, v20, v22                                // 00000049EC78: 08282D14
	v_add_f32_e32 v22, v19, v23                                // 00000049EC7C: 062C2F13
	v_sub_f32_e32 v19, v19, v23                                // 00000049EC80: 08262F13
	v_add_f32_e32 v23, v25, v36                                // 00000049EC84: 062E4919
	v_dual_sub_f32 v25, v25, v36 :: v_dual_add_f32 v36, v35, v39// 00000049EC88: C9484919 19244F23
	v_sub_f32_e32 v35, v35, v39                                // 00000049EC90: 08464F23
	v_add_f32_e32 v39, v26, v37                                // 00000049EC94: 064E4B1A
	v_sub_f32_e32 v26, v26, v37                                // 00000049EC98: 08344B1A
	v_add_f32_e32 v37, v34, v38                                // 00000049EC9C: 064A4D22
	v_sub_f32_e32 v34, v34, v38                                // 00000049ECA0: 08444D22
	v_add_f32_e32 v38, v40, v52                                // 00000049ECA4: 064C6928
	v_sub_f32_e32 v40, v40, v52                                // 00000049ECA8: 08506928
	v_add_f32_e32 v52, v51, v55                                // 00000049ECAC: 06686F33
	v_sub_f32_e32 v51, v51, v55                                // 00000049ECB0: 08666F33
	v_add_f32_e32 v55, v41, v53                                // 00000049ECB4: 066E6B29
	v_sub_f32_e32 v41, v41, v53                                // 00000049ECB8: 08526B29
	v_add_f32_e32 v53, v50, v54                                // 00000049ECBC: 066A6D32
	v_sub_f32_e32 v50, v50, v54                                // 00000049ECC0: 08646D32
	v_add_f32_e32 v54, v56, v63                                // 00000049ECC4: 066C7F38
	v_dual_sub_f32 v56, v56, v63 :: v_dual_add_f32 v63, v62, v66// 00000049ECC8: C9487F38 383E853E
	v_sub_f32_e32 v62, v62, v66                                // 00000049ECD0: 087C853E
	v_add_f32_e32 v66, v57, v64                                // 00000049ECD4: 06848139
	v_dual_sub_f32 v57, v57, v64 :: v_dual_add_f32 v64, v6, v65// 00000049ECD8: C9488139 39408306
	v_dual_sub_f32 v6, v6, v65 :: v_dual_add_f32 v65, v67, v23 // 00000049ECE0: C9488306 06402F43
	v_sub_f32_e32 v23, v67, v23                                // 00000049ECE8: 082E2F43
	v_add_f32_e32 v67, v68, v36                                // 00000049ECEC: 06864944
	v_sub_f32_e32 v36, v68, v36                                // 00000049ECF0: 08484944
	v_add_f32_e32 v68, v69, v39                                // 00000049ECF4: 06884F45
	v_sub_f32_e32 v39, v69, v39                                // 00000049ECF8: 084E4F45
	v_add_f32_e32 v69, v22, v37                                // 00000049ECFC: 068A4B16
	v_sub_f32_e32 v22, v22, v37                                // 00000049ED00: 082C4B16
	v_add_f32_e32 v37, v21, v25                                // 00000049ED04: 064A3315
	v_sub_f32_e32 v21, v21, v25                                // 00000049ED08: 082A3315
	v_add_f32_e32 v25, v24, v35                                // 00000049ED0C: 06324718
	v_sub_f32_e32 v24, v24, v35                                // 00000049ED10: 08304718
	v_add_f32_e32 v35, v20, v26                                // 00000049ED14: 06463514
	v_sub_f32_e32 v20, v20, v26                                // 00000049ED18: 08283514
	v_add_f32_e32 v26, v19, v34                                // 00000049ED1C: 06344513
	v_sub_f32_e32 v19, v19, v34                                // 00000049ED20: 08264513
	v_add_f32_e32 v34, v38, v54                                // 00000049ED24: 06446D26
	v_sub_f32_e32 v38, v38, v54                                // 00000049ED28: 084C6D26
	v_add_f32_e32 v54, v52, v63                                // 00000049ED2C: 066C7F34
	v_dual_sub_f32 v52, v52, v63 :: v_dual_add_f32 v63, v55, v66// 00000049ED30: C9487F34 343E8537
	v_dual_sub_f32 v55, v55, v66 :: v_dual_add_f32 v66, v53, v64// 00000049ED38: C9488537 37428135
	v_sub_f32_e32 v53, v53, v64                                // 00000049ED40: 086A8135
	v_add_f32_e32 v64, v40, v56                                // 00000049ED44: 06807128
	v_sub_f32_e32 v40, v40, v56                                // 00000049ED48: 08507128
	v_add_f32_e32 v56, v51, v62                                // 00000049ED4C: 06707D33
	v_dual_sub_f32 v51, v51, v62 :: v_dual_add_f32 v62, v41, v57// 00000049ED50: C9487D33 333E7329
	v_sub_f32_e32 v41, v41, v57                                // 00000049ED58: 08527329
	v_add_f32_e32 v57, v50, v6                                 // 00000049ED5C: 06720D32
	v_sub_f32_e32 v6, v50, v6                                  // 00000049ED60: 080C0D32
	v_add_f32_e32 v50, v65, v34                                // 00000049ED64: 06644541
	v_sub_f32_e32 v34, v65, v34                                // 00000049ED68: 08444541
	v_add_f32_e32 v65, v67, v54                                // 00000049ED6C: 06826D43
	v_dual_sub_f32 v54, v67, v54 :: v_dual_add_f32 v67, v68, v63// 00000049ED70: C9486D43 36427F44
	v_dual_sub_f32 v63, v68, v63 :: v_dual_add_f32 v68, v69, v66// 00000049ED78: C9487F44 3F448545
	v_sub_f32_e32 v66, v69, v66                                // 00000049ED80: 08848545
	v_add_f32_e32 v69, v37, v64                                // 00000049ED84: 068A8125
	v_sub_f32_e32 v37, v37, v64                                // 00000049ED88: 084A8125
	v_add_f32_e32 v64, v25, v56                                // 00000049ED8C: 06807119
	v_dual_sub_f32 v25, v25, v56 :: v_dual_add_f32 v56, v35, v62// 00000049ED90: C9487119 19387D23
	v_dual_sub_f32 v35, v35, v62 :: v_dual_add_f32 v62, v26, v57// 00000049ED98: C9487D23 233E731A
	v_dual_sub_f32 v26, v26, v57 :: v_dual_add_f32 v57, v23, v38// 00000049EDA0: C948731A 1A384D17
	v_dual_sub_f32 v23, v23, v38 :: v_dual_add_f32 v38, v36, v52// 00000049EDA8: C9484D17 17266924
	v_sub_f32_e32 v36, v36, v52                                // 00000049EDB0: 08486924
	v_add_f32_e32 v52, v39, v55                                // 00000049EDB4: 06686F27
	v_sub_f32_e32 v39, v39, v55                                // 00000049EDB8: 084E6F27
	v_add_f32_e32 v55, v22, v53                                // 00000049EDBC: 066E6B16
	v_dual_sub_f32 v22, v22, v53 :: v_dual_add_f32 v53, v21, v40// 00000049EDC0: C9486B16 16345115
	v_dual_sub_f32 v21, v21, v40 :: v_dual_add_f32 v40, v24, v51// 00000049EDC8: C9485115 15286718
	v_sub_f32_e32 v24, v24, v51                                // 00000049EDD0: 08306718
	v_add_f32_e32 v51, v20, v41                                // 00000049EDD4: 06665314
	v_dual_sub_f32 v20, v20, v41 :: v_dual_add_f32 v41, v19, v6// 00000049EDD8: C9485314 14280D13
	v_sub_f32_e32 v6, v19, v6                                  // 00000049EDE0: 080C0D13
	ds_store_b32 v12, v50                                      // 00000049EDE4: D8340000 0000320C
	ds_store_b32 v7, v65                                       // 00000049EDEC: D8340000 00004107
	ds_store_b32 v8, v67                                       // 00000049EDF4: D8340000 00004308
	ds_store_b32 v9, v68                                       // 00000049EDFC: D8340000 00004409
	ds_store_b32 v10, v69                                      // 00000049EE04: D8340000 0000450A
	ds_store_b32 v11, v64                                      // 00000049EE0C: D8340000 0000400B
	ds_store_b32 v13, v56                                      // 00000049EE14: D8340000 0000380D
	ds_store_b32 v14, v62                                      // 00000049EE1C: D8340000 00003E0E
	ds_store_b32 v15, v57                                      // 00000049EE24: D8340000 0000390F
	ds_store_b32 v16, v38                                      // 00000049EE2C: D8340000 00002610
	ds_store_b32 v17, v52                                      // 00000049EE34: D8340000 00003411
	ds_store_b32 v18, v55                                      // 00000049EE3C: D8340000 00003712
	ds_store_b32 v27, v53                                      // 00000049EE44: D8340000 0000351B
	ds_store_b32 v28, v40                                      // 00000049EE4C: D8340000 0000281C
	ds_store_b32 v29, v51                                      // 00000049EE54: D8340000 0000331D
	ds_store_b32 v30, v41                                      // 00000049EE5C: D8340000 0000291E
	ds_store_b32 v31, v34                                      // 00000049EE64: D8340000 0000221F
	ds_store_b32 v32, v54                                      // 00000049EE6C: D8340000 00003620
	ds_store_b32 v33, v63                                      // 00000049EE74: D8340000 00003F21
	ds_store_b32 v42, v66                                      // 00000049EE7C: D8340000 0000422A
	ds_store_b32 v43, v37                                      // 00000049EE84: D8340000 0000252B
	ds_store_b32 v44, v25                                      // 00000049EE8C: D8340000 0000192C
	ds_store_b32 v45, v35                                      // 00000049EE94: D8340000 0000232D
	ds_store_b32 v46, v26                                      // 00000049EE9C: D8340000 00001A2E
	ds_store_b32 v47, v23                                      // 00000049EEA4: D8340000 0000172F
	ds_store_b32 v48, v36                                      // 00000049EEAC: D8340000 00002430
	ds_store_b32 v49, v39                                      // 00000049EEB4: D8340000 00002731
	ds_store_b32 v58, v22                                      // 00000049EEBC: D8340000 0000163A
	ds_store_b32 v59, v21                                      // 00000049EEC4: D8340000 0000153B
	ds_store_b32 v60, v24                                      // 00000049EECC: D8340000 0000183C
	ds_store_b32 v61, v20                                      // 00000049EED4: D8340000 0000143D
	ds_store_b32 v5, v6                                        // 00000049EEDC: D8340000 00000605
	s_or_b32 exec_lo, exec_lo, s2                              // 00000049EEE4: 8C7E027E
	s_clause 0x1                                               // 00000049EEE8: BF850001
	s_load_b128 s[4:7], s[0:1], 0x10                           // 00000049EEEC: F4080100 F8000010
	s_load_b64 s[2:3], s[0:1], 0x20                            // 00000049EEF4: F4040080 F8000020
	v_lshrrev_b32_e32 v5, 7, v0                                // 00000049EEFC: 320A0087
	v_or_b32_e32 v6, -16, v3                                   // 00000049EF00: 380C06D0
	v_lshlrev_b32_e32 v7, 9, v0                                // 00000049EF04: 300E0089
	s_lshl_b32 s8, s8, 7                                       // 00000049EF08: 84088708
	s_waitcnt lgkmcnt(0)                                       // 00000049EF0C: BF89FC07
	s_barrier                                                  // 00000049EF10: BFBD0000
	v_mov_b32_e32 v8, v6                                       // 00000049EF14: 7E100306
	v_dual_mov_b32 v7, v5 :: v_dual_and_b32 v0, 0xfe00, v7     // 00000049EF18: CA240105 07000EFF 0000FE00
	buffer_gl0_inv                                             // 00000049EF24: E0AC0000 00000000
	v_add_nc_u32_e32 v9, s8, v7                                // 00000049EF2C: 4A120E08
	v_add_nc_u32_e32 v14, 64, v7                               // 00000049EF30: 4A1C0EC0
	v_add_nc_u32_e32 v15, 0x60, v7                             // 00000049EF34: 4A1E0EFF 00000060
	v_xor_b32_e32 v16, v7, v1                                  // 00000049EF3C: 3A200307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049EF40: BF870214
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000049EF44: 3414129F
	v_xor_b32_e32 v14, v14, v1                                 // 00000049EF48: 3A1C030E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049EF4C: BF870214
	v_xor_b32_e32 v15, v15, v1                                 // 00000049EF50: 3A1E030F
	v_lshl_add_u32 v16, v16, 2, v0                             // 00000049EF54: D6460010 04010510
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049EF5C: BF870214
	.long 0xd73c0009                                           // 00000049EF60: D73C0009
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 00000049EF64: 02021281
	v_lshl_add_u32 v14, v14, 2, v0                             // 00000049EF68: D646000E 0401050E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049EF70: BF870194
	v_lshl_add_u32 v15, v15, 2, v0                             // 00000049EF74: D646000F 0401050F
	.long 0xd7000009                                           // 00000049EF7C: D7000009
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 00000049EF80: 02021204
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049EF84: BF870001
	v_add_co_ci_u32_e64 v10, null, s5, v10, s0                 // 00000049EF88: D5207C0A 00021405
	s_clause 0x3                                               // 00000049EF90: BF850003
	global_load_d16_b16 v11, v[9:10], off                      // 00000049EF94: DC820000 0B7C0009
	global_load_d16_b16 v12, v[9:10], off offset:64            // 00000049EF9C: DC820040 0C7C0009
	global_load_d16_b16 v13, v[9:10], off offset:128           // 00000049EFA4: DC820080 0D7C0009
	global_load_d16_b16 v9, v[9:10], off offset:192            // 00000049EFAC: DC8200C0 097C0009
	v_add_nc_u32_e32 v10, 32, v7                               // 00000049EFB4: 4A140EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000049EFB8: BF870091
	v_xor_b32_e32 v10, v10, v1                                 // 00000049EFBC: 3A14030A
	v_lshl_add_u32 v10, v10, 2, v0                             // 00000049EFC0: D646000A 0401050A
	ds_load_b32 v17, v16                                       // 00000049EFC8: D8D80000 11000010
	ds_load_b32 v18, v10                                       // 00000049EFD0: D8D80000 1200000A
	ds_load_b32 v19, v14                                       // 00000049EFD8: D8D80000 1300000E
	ds_load_b32 v20, v15                                       // 00000049EFE0: D8D80000 1400000F
	s_waitcnt lgkmcnt(2)                                       // 00000049EFE8: BF89FC27
	v_add_f32_e32 v21, v17, v18                                // 00000049EFEC: 062A2511
	s_waitcnt lgkmcnt(0)                                       // 00000049EFF0: BF89FC07
	v_dual_sub_f32 v17, v17, v18 :: v_dual_add_f32 v18, v19, v20// 00000049EFF4: C9482511 11122913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000049EFFC: BF870121
	v_dual_sub_f32 v19, v19, v20 :: v_dual_add_f32 v20, v21, v18// 00000049F000: C9482913 13142515
	v_sub_f32_e32 v18, v21, v18                                // 00000049F008: 08242515
	v_add_f32_e32 v22, v17, v19                                // 00000049F00C: 062C2711
	v_dual_sub_f32 v17, v17, v19 :: v_dual_add_nc_u32 v8, 16, v8// 00000049F010: C9602711 11081090
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000049F018: BF870194
	v_mul_f32_e32 v19, 0x3db504f3, v20                         // 00000049F01C: 102628FF 3DB504F3
	v_dual_mul_f32 v20, 0x3db504f3, v22 :: v_dual_add_nc_u32 v7, 4, v7// 00000049F024: C8E02CFF 14060E84 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049F030: BF870213
	v_dual_mul_f32 v18, 0x3db504f3, v18 :: v_dual_mul_f32 v17, 0x3db504f3, v17// 00000049F034: C8C624FF 121022FF 3DB504F3
	.long 0xd4490000                                           // 00000049F040: D4490000
	v_cndmask_b32_e32 v1, 0x6f, v8, vcc_lo                     // 00000049F044: 020210FF 0000006F
	s_or_b32 s9, s0, s9                                        // 00000049F04C: 8C090900
	s_waitcnt vmcnt(3)                                         // 00000049F050: BF890FF7
	v_fma_mix_f32 v11, v11, v19, neg(0) op_sel_hi:[1,0,0]      // 00000049F054: CC20000B 8A02270B
	s_waitcnt vmcnt(2)                                         // 00000049F05C: BF890BF7
	v_fma_mix_f32 v12, v12, v20, neg(0) op_sel_hi:[1,0,0]      // 00000049F060: CC20000C 8A02290C
	s_waitcnt vmcnt(1)                                         // 00000049F068: BF8907F7
	v_fma_mix_f32 v13, v13, v18, neg(0) op_sel_hi:[1,0,0]      // 00000049F06C: CC20000D 8A02250D
	s_waitcnt vmcnt(0)                                         // 00000049F074: BF8903F7
	v_fma_mix_f32 v9, v9, v17, neg(0) op_sel_hi:[1,0,0]        // 00000049F078: CC200009 8A022309
	ds_store_b32 v16, v11                                      // 00000049F080: D8340000 00000B10
	ds_store_b32 v10, v12                                      // 00000049F088: D8340000 00000C0A
	ds_store_b32 v14, v13                                      // 00000049F090: D8340000 00000D0E
	ds_store_b32 v15, v9                                       // 00000049F098: D8340000 0000090F
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000049F0A0: 917E097E
	s_cbranch_execnz 65441                                     // 00000049F0A4: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti+0x142c>
	s_or_b32 exec_lo, exec_lo, s9                              // 00000049F0A8: 8C7E097E
	s_waitcnt lgkmcnt(0)                                       // 00000049F0AC: BF89FC07
	s_barrier                                                  // 00000049F0B0: BFBD0000
	buffer_gl0_inv                                             // 00000049F0B4: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000049F0BC: BE80206A
	s_cbranch_execz 406                                        // 00000049F0C0: BFA50196 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti+0x1c1c>
	v_lshlrev_b32_e32 v0, 14, v3                               // 00000049F0C4: 3000068E
	v_and_or_b32 v1, 0x60, v4, v1                              // 00000049F0C8: D6570001 040608FF 00000060
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049F0D4: BF870112
	v_and_b32_e32 v0, 0xc000, v0                               // 00000049F0D8: 360000FF 0000C000
	v_xor_b32_e32 v3, 1, v1                                    // 00000049F0E0: 3A060281
	v_xor_b32_e32 v4, 2, v1                                    // 00000049F0E4: 3A080282
	v_xor_b32_e32 v7, 3, v1                                    // 00000049F0E8: 3A0E0283
	v_xor_b32_e32 v8, 4, v1                                    // 00000049F0EC: 3A100284
	v_xor_b32_e32 v9, 5, v1                                    // 00000049F0F0: 3A120285
	v_lshl_or_b32 v10, v1, 2, v0                               // 00000049F0F4: D656000A 04010501
	v_xor_b32_e32 v11, 6, v1                                   // 00000049F0FC: 3A160286
	v_xor_b32_e32 v12, 7, v1                                   // 00000049F100: 3A180287
	v_lshl_or_b32 v3, v3, 2, v0                                // 00000049F104: D6560003 04010503
	v_lshl_or_b32 v4, v4, 2, v0                                // 00000049F10C: D6560004 04010504
	v_lshl_or_b32 v7, v7, 2, v0                                // 00000049F114: D6560007 04010507
	v_lshl_or_b32 v8, v8, 2, v0                                // 00000049F11C: D6560008 04010508
	v_lshl_or_b32 v9, v9, 2, v0                                // 00000049F124: D6560009 04010509
	v_lshl_or_b32 v11, v11, 2, v0                              // 00000049F12C: D656000B 0401050B
	v_lshl_or_b32 v12, v12, 2, v0                              // 00000049F134: D656000C 0401050C
	ds_load_b32 v16, v10                                       // 00000049F13C: D8D80000 1000000A
	ds_load_b32 v17, v3 offset:512                             // 00000049F144: D8D80200 11000003
	ds_load_b32 v18, v4 offset:1024                            // 00000049F14C: D8D80400 12000004
	ds_load_b32 v19, v7 offset:1536                            // 00000049F154: D8D80600 13000007
	ds_load_b32 v20, v8 offset:2048                            // 00000049F15C: D8D80800 14000008
	ds_load_b32 v21, v9 offset:2560                            // 00000049F164: D8D80A00 15000009
	ds_load_b32 v22, v11 offset:3072                           // 00000049F16C: D8D80C00 1600000B
	ds_load_b32 v23, v12 offset:3584                           // 00000049F174: D8D80E00 1700000C
	v_xor_b32_e32 v13, 8, v1                                   // 00000049F17C: 3A1A0288
	v_xor_b32_e32 v29, 16, v1                                  // 00000049F180: 3A3A0290
	v_xor_b32_e32 v45, 24, v1                                  // 00000049F184: 3A5A0298
	v_xor_b32_e32 v14, 9, v1                                   // 00000049F188: 3A1C0289
	v_xor_b32_e32 v30, 17, v1                                  // 00000049F18C: 3A3C0291
	v_xor_b32_e32 v46, 25, v1                                  // 00000049F190: 3A5C0299
	v_xor_b32_e32 v15, 10, v1                                  // 00000049F194: 3A1E028A
	v_xor_b32_e32 v31, 18, v1                                  // 00000049F198: 3A3E0292
	v_xor_b32_e32 v47, 26, v1                                  // 00000049F19C: 3A5E029A
	v_xor_b32_e32 v24, 11, v1                                  // 00000049F1A0: 3A30028B
	v_xor_b32_e32 v40, 19, v1                                  // 00000049F1A4: 3A500293
	v_xor_b32_e32 v56, 27, v1                                  // 00000049F1A8: 3A70029B
	v_xor_b32_e32 v25, 12, v1                                  // 00000049F1AC: 3A32028C
	v_xor_b32_e32 v41, 20, v1                                  // 00000049F1B0: 3A520294
	v_xor_b32_e32 v57, 28, v1                                  // 00000049F1B4: 3A72029C
	v_xor_b32_e32 v26, 13, v1                                  // 00000049F1B8: 3A34028D
	v_xor_b32_e32 v27, 14, v1                                  // 00000049F1BC: 3A36028E
	v_xor_b32_e32 v28, 15, v1                                  // 00000049F1C0: 3A38028F
	v_xor_b32_e32 v42, 21, v1                                  // 00000049F1C4: 3A540295
	v_xor_b32_e32 v43, 22, v1                                  // 00000049F1C8: 3A560296
	v_xor_b32_e32 v44, 23, v1                                  // 00000049F1CC: 3A580297
	v_xor_b32_e32 v58, 29, v1                                  // 00000049F1D0: 3A74029D
	v_xor_b32_e32 v59, 30, v1                                  // 00000049F1D4: 3A76029E
	v_xor_b32_e32 v1, 31, v1                                   // 00000049F1D8: 3A02029F
	s_waitcnt lgkmcnt(6)                                       // 00000049F1DC: BF89FC67
	v_add_f32_e32 v67, v16, v17                                // 00000049F1E0: 06862310
	s_waitcnt lgkmcnt(4)                                       // 00000049F1E4: BF89FC47
	v_dual_sub_f32 v16, v16, v17 :: v_dual_add_f32 v17, v18, v19// 00000049F1E8: C9482310 10102712
	v_lshl_or_b32 v13, v13, 2, v0                              // 00000049F1F0: D656000D 0401050D
	v_lshl_or_b32 v29, v29, 2, v0                              // 00000049F1F8: D656001D 0401051D
	v_lshl_or_b32 v45, v45, 2, v0                              // 00000049F200: D656002D 0401052D
	v_lshl_or_b32 v14, v14, 2, v0                              // 00000049F208: D656000E 0401050E
	v_lshl_or_b32 v30, v30, 2, v0                              // 00000049F210: D656001E 0401051E
	v_lshl_or_b32 v46, v46, 2, v0                              // 00000049F218: D656002E 0401052E
	v_lshl_or_b32 v15, v15, 2, v0                              // 00000049F220: D656000F 0401050F
	v_lshl_or_b32 v31, v31, 2, v0                              // 00000049F228: D656001F 0401051F
	v_lshl_or_b32 v47, v47, 2, v0                              // 00000049F230: D656002F 0401052F
	v_lshl_or_b32 v24, v24, 2, v0                              // 00000049F238: D6560018 04010518
	v_lshl_or_b32 v40, v40, 2, v0                              // 00000049F240: D6560028 04010528
	v_lshl_or_b32 v56, v56, 2, v0                              // 00000049F248: D6560038 04010538
	v_lshl_or_b32 v25, v25, 2, v0                              // 00000049F250: D6560019 04010519
	v_lshl_or_b32 v41, v41, 2, v0                              // 00000049F258: D6560029 04010529
	v_lshl_or_b32 v57, v57, 2, v0                              // 00000049F260: D6560039 04010539
	v_lshl_or_b32 v26, v26, 2, v0                              // 00000049F268: D656001A 0401051A
	v_lshl_or_b32 v27, v27, 2, v0                              // 00000049F270: D656001B 0401051B
	v_lshl_or_b32 v28, v28, 2, v0                              // 00000049F278: D656001C 0401051C
	ds_load_b32 v32, v13 offset:4096                           // 00000049F280: D8D81000 2000000D
	ds_load_b32 v33, v14 offset:4608                           // 00000049F288: D8D81200 2100000E
	ds_load_b32 v34, v15 offset:5120                           // 00000049F290: D8D81400 2200000F
	ds_load_b32 v35, v24 offset:5632                           // 00000049F298: D8D81600 23000018
	ds_load_b32 v36, v25 offset:6144                           // 00000049F2A0: D8D81800 24000019
	ds_load_b32 v37, v26 offset:6656                           // 00000049F2A8: D8D81A00 2500001A
	ds_load_b32 v38, v27 offset:7168                           // 00000049F2B0: D8D81C00 2600001B
	ds_load_b32 v39, v28 offset:7680                           // 00000049F2B8: D8D81E00 2700001C
	v_lshl_or_b32 v42, v42, 2, v0                              // 00000049F2C0: D656002A 0401052A
	v_lshl_or_b32 v43, v43, 2, v0                              // 00000049F2C8: D656002B 0401052B
	v_lshl_or_b32 v44, v44, 2, v0                              // 00000049F2D0: D656002C 0401052C
	ds_load_b32 v48, v29 offset:8192                           // 00000049F2D8: D8D82000 3000001D
	ds_load_b32 v49, v30 offset:8704                           // 00000049F2E0: D8D82200 3100001E
	ds_load_b32 v50, v31 offset:9216                           // 00000049F2E8: D8D82400 3200001F
	ds_load_b32 v51, v40 offset:9728                           // 00000049F2F0: D8D82600 33000028
	ds_load_b32 v52, v41 offset:10240                          // 00000049F2F8: D8D82800 34000029
	ds_load_b32 v53, v42 offset:10752                          // 00000049F300: D8D82A00 3500002A
	ds_load_b32 v54, v43 offset:11264                          // 00000049F308: D8D82C00 3600002B
	ds_load_b32 v55, v44 offset:11776                          // 00000049F310: D8D82E00 3700002C
	v_lshl_or_b32 v58, v58, 2, v0                              // 00000049F318: D656003A 0401053A
	v_lshl_or_b32 v59, v59, 2, v0                              // 00000049F320: D656003B 0401053B
	v_lshl_or_b32 v0, v1, 2, v0                                // 00000049F328: D6560000 04010501
	ds_load_b32 v1, v45 offset:12288                           // 00000049F330: D8D83000 0100002D
	ds_load_b32 v60, v46 offset:12800                          // 00000049F338: D8D83200 3C00002E
	ds_load_b32 v61, v47 offset:13312                          // 00000049F340: D8D83400 3D00002F
	ds_load_b32 v62, v56 offset:13824                          // 00000049F348: D8D83600 3E000038
	ds_load_b32 v63, v57 offset:14336                          // 00000049F350: D8D83800 3F000039
	ds_load_b32 v64, v58 offset:14848                          // 00000049F358: D8D83A00 4000003A
	ds_load_b32 v65, v59 offset:15360                          // 00000049F360: D8D83C00 4100003B
	ds_load_b32 v66, v0 offset:15872                           // 00000049F368: D8D83E00 42000000
	s_waitcnt lgkmcnt(26)                                      // 00000049F370: BF89FDA7
	v_dual_sub_f32 v18, v18, v19 :: v_dual_add_f32 v19, v20, v21// 00000049F374: C9482712 12122B14
	s_waitcnt lgkmcnt(24)                                      // 00000049F37C: BF89FD87
	v_dual_sub_f32 v20, v20, v21 :: v_dual_add_f32 v21, v22, v23// 00000049F380: C9482B14 14142F16
	s_waitcnt lgkmcnt(22)                                      // 00000049F388: BF89FD67
	v_dual_sub_f32 v22, v22, v23 :: v_dual_add_f32 v23, v32, v33// 00000049F38C: C9482F16 16164320
	s_waitcnt lgkmcnt(20)                                      // 00000049F394: BF89FD47
	v_dual_sub_f32 v32, v32, v33 :: v_dual_add_f32 v33, v34, v35// 00000049F398: C9484320 20204722
	s_waitcnt lgkmcnt(18)                                      // 00000049F3A0: BF89FD27
	v_dual_sub_f32 v34, v34, v35 :: v_dual_add_f32 v35, v36, v37// 00000049F3A4: C9484722 22224B24
	s_waitcnt lgkmcnt(16)                                      // 00000049F3AC: BF89FD07
	v_dual_sub_f32 v36, v36, v37 :: v_dual_add_f32 v37, v38, v39// 00000049F3B0: C9484B24 24244F26
	s_waitcnt lgkmcnt(14)                                      // 00000049F3B8: BF89FCE7
	v_dual_sub_f32 v38, v38, v39 :: v_dual_add_f32 v39, v48, v49// 00000049F3BC: C9484F26 26266330
	s_waitcnt lgkmcnt(12)                                      // 00000049F3C4: BF89FCC7
	v_dual_sub_f32 v48, v48, v49 :: v_dual_add_f32 v49, v50, v51// 00000049F3C8: C9486330 30306732
	s_waitcnt lgkmcnt(10)                                      // 00000049F3D0: BF89FCA7
	v_dual_sub_f32 v50, v50, v51 :: v_dual_add_f32 v51, v52, v53// 00000049F3D4: C9486732 32326B34
	s_waitcnt lgkmcnt(8)                                       // 00000049F3DC: BF89FC87
	v_dual_sub_f32 v52, v52, v53 :: v_dual_add_f32 v53, v54, v55// 00000049F3E0: C9486B34 34346F36
	s_waitcnt lgkmcnt(6)                                       // 00000049F3E8: BF89FC67
	v_dual_sub_f32 v54, v54, v55 :: v_dual_add_f32 v55, v1, v60// 00000049F3EC: C9486F36 36367901
	v_sub_f32_e32 v1, v1, v60                                  // 00000049F3F4: 08027901
	s_waitcnt lgkmcnt(4)                                       // 00000049F3F8: BF89FC47
	v_add_f32_e32 v60, v61, v62                                // 00000049F3FC: 06787D3D
	s_waitcnt lgkmcnt(2)                                       // 00000049F400: BF89FC27
	v_dual_sub_f32 v61, v61, v62 :: v_dual_add_f32 v62, v63, v64// 00000049F404: C9487D3D 3D3E813F
	s_waitcnt lgkmcnt(0)                                       // 00000049F40C: BF89FC07
	v_dual_sub_f32 v63, v63, v64 :: v_dual_add_f32 v64, v65, v66// 00000049F410: C948813F 3F408541
	v_dual_sub_f32 v65, v65, v66 :: v_dual_add_f32 v66, v67, v17// 00000049F418: C9488541 41422343
	v_sub_f32_e32 v17, v67, v17                                // 00000049F420: 08222343
	v_add_f32_e32 v67, v16, v18                                // 00000049F424: 06862510
	v_sub_f32_e32 v16, v16, v18                                // 00000049F428: 08202510
	v_add_f32_e32 v18, v19, v21                                // 00000049F42C: 06242B13
	v_sub_f32_e32 v19, v19, v21                                // 00000049F430: 08262B13
	v_add_f32_e32 v21, v20, v22                                // 00000049F434: 062A2D14
	v_sub_f32_e32 v20, v20, v22                                // 00000049F438: 08282D14
	v_add_f32_e32 v22, v23, v33                                // 00000049F43C: 062C4317
	v_sub_f32_e32 v23, v23, v33                                // 00000049F440: 082E4317
	v_add_f32_e32 v33, v32, v34                                // 00000049F444: 06424520
	v_sub_f32_e32 v32, v32, v34                                // 00000049F448: 08404520
	v_add_f32_e32 v34, v35, v37                                // 00000049F44C: 06444B23
	v_sub_f32_e32 v35, v35, v37                                // 00000049F450: 08464B23
	v_add_f32_e32 v37, v36, v38                                // 00000049F454: 064A4D24
	v_sub_f32_e32 v36, v36, v38                                // 00000049F458: 08484D24
	v_add_f32_e32 v38, v39, v49                                // 00000049F45C: 064C6327
	v_sub_f32_e32 v39, v39, v49                                // 00000049F460: 084E6327
	v_add_f32_e32 v49, v48, v50                                // 00000049F464: 06626530
	v_sub_f32_e32 v48, v48, v50                                // 00000049F468: 08606530
	v_add_f32_e32 v50, v51, v53                                // 00000049F46C: 06646B33
	v_sub_f32_e32 v51, v51, v53                                // 00000049F470: 08666B33
	v_add_f32_e32 v53, v52, v54                                // 00000049F474: 066A6D34
	v_sub_f32_e32 v52, v52, v54                                // 00000049F478: 08686D34
	v_add_f32_e32 v54, v55, v60                                // 00000049F47C: 066C7937
	v_dual_sub_f32 v55, v55, v60 :: v_dual_add_f32 v60, v1, v61// 00000049F480: C9487937 373C7B01
	v_sub_f32_e32 v1, v1, v61                                  // 00000049F488: 08027B01
	v_add_f32_e32 v61, v62, v64                                // 00000049F48C: 067A813E
	v_sub_f32_e32 v62, v62, v64                                // 00000049F490: 087C813E
	v_add_f32_e32 v64, v63, v65                                // 00000049F494: 0680833F
	v_sub_f32_e32 v63, v63, v65                                // 00000049F498: 087E833F
	v_add_f32_e32 v65, v66, v18                                // 00000049F49C: 06822542
	v_sub_f32_e32 v18, v66, v18                                // 00000049F4A0: 08242542
	v_add_f32_e32 v66, v67, v21                                // 00000049F4A4: 06842B43
	v_sub_f32_e32 v21, v67, v21                                // 00000049F4A8: 082A2B43
	v_add_f32_e32 v67, v17, v19                                // 00000049F4AC: 06862711
	v_sub_f32_e32 v17, v17, v19                                // 00000049F4B0: 08222711
	v_add_f32_e32 v19, v16, v20                                // 00000049F4B4: 06262910
	v_sub_f32_e32 v16, v16, v20                                // 00000049F4B8: 08202910
	v_add_f32_e32 v20, v22, v34                                // 00000049F4BC: 06284516
	v_sub_f32_e32 v22, v22, v34                                // 00000049F4C0: 082C4516
	v_add_f32_e32 v34, v33, v37                                // 00000049F4C4: 06444B21
	v_sub_f32_e32 v33, v33, v37                                // 00000049F4C8: 08424B21
	v_add_f32_e32 v37, v23, v35                                // 00000049F4CC: 064A4717
	v_sub_f32_e32 v23, v23, v35                                // 00000049F4D0: 082E4717
	v_add_f32_e32 v35, v32, v36                                // 00000049F4D4: 06464920
	v_sub_f32_e32 v32, v32, v36                                // 00000049F4D8: 08404920
	v_add_f32_e32 v36, v38, v50                                // 00000049F4DC: 06486526
	v_sub_f32_e32 v38, v38, v50                                // 00000049F4E0: 084C6526
	v_add_f32_e32 v50, v49, v53                                // 00000049F4E4: 06646B31
	v_sub_f32_e32 v49, v49, v53                                // 00000049F4E8: 08626B31
	v_add_f32_e32 v53, v39, v51                                // 00000049F4EC: 066A6727
	v_sub_f32_e32 v39, v39, v51                                // 00000049F4F0: 084E6727
	v_add_f32_e32 v51, v48, v52                                // 00000049F4F4: 06666930
	v_sub_f32_e32 v48, v48, v52                                // 00000049F4F8: 08606930
	v_add_f32_e32 v52, v54, v61                                // 00000049F4FC: 06687B36
	v_dual_sub_f32 v54, v54, v61 :: v_dual_add_f32 v61, v60, v64// 00000049F500: C9487B36 363C813C
	v_sub_f32_e32 v60, v60, v64                                // 00000049F508: 0878813C
	v_add_f32_e32 v64, v55, v62                                // 00000049F50C: 06807D37
	v_dual_sub_f32 v55, v55, v62 :: v_dual_add_f32 v62, v1, v63// 00000049F510: C9487D37 373E7F01
	v_sub_f32_e32 v1, v1, v63                                  // 00000049F518: 08027F01
	v_add_f32_e32 v63, v65, v20                                // 00000049F51C: 067E2941
	v_dual_sub_f32 v20, v65, v20 :: v_dual_add_f32 v65, v66, v34// 00000049F520: C9482941 14404542
	v_sub_f32_e32 v34, v66, v34                                // 00000049F528: 08444542
	v_add_f32_e32 v66, v67, v37                                // 00000049F52C: 06844B43
	v_sub_f32_e32 v37, v67, v37                                // 00000049F530: 084A4B43
	v_add_f32_e32 v67, v19, v35                                // 00000049F534: 06864713
	v_sub_f32_e32 v19, v19, v35                                // 00000049F538: 08264713
	v_add_f32_e32 v35, v18, v22                                // 00000049F53C: 06462D12
	v_sub_f32_e32 v18, v18, v22                                // 00000049F540: 08242D12
	v_add_f32_e32 v22, v21, v33                                // 00000049F544: 062C4315
	v_sub_f32_e32 v21, v21, v33                                // 00000049F548: 082A4315
	v_add_f32_e32 v33, v17, v23                                // 00000049F54C: 06422F11
	v_sub_f32_e32 v17, v17, v23                                // 00000049F550: 08222F11
	v_add_f32_e32 v23, v16, v32                                // 00000049F554: 062E4110
	v_sub_f32_e32 v16, v16, v32                                // 00000049F558: 08204110
	v_add_f32_e32 v32, v36, v52                                // 00000049F55C: 06406924
	v_sub_f32_e32 v36, v36, v52                                // 00000049F560: 08486924
	v_add_f32_e32 v52, v50, v61                                // 00000049F564: 06687B32
	v_dual_sub_f32 v50, v50, v61 :: v_dual_add_f32 v61, v53, v64// 00000049F568: C9487B32 323C8135
	v_dual_sub_f32 v53, v53, v64 :: v_dual_add_f32 v64, v51, v62// 00000049F570: C9488135 35407D33
	v_sub_f32_e32 v51, v51, v62                                // 00000049F578: 08667D33
	v_add_f32_e32 v62, v38, v54                                // 00000049F57C: 067C6D26
	v_sub_f32_e32 v38, v38, v54                                // 00000049F580: 084C6D26
	v_add_f32_e32 v54, v49, v60                                // 00000049F584: 066C7931
	v_dual_sub_f32 v49, v49, v60 :: v_dual_add_f32 v60, v39, v55// 00000049F588: C9487931 313C6F27
	v_sub_f32_e32 v39, v39, v55                                // 00000049F590: 084E6F27
	v_add_f32_e32 v55, v48, v1                                 // 00000049F594: 066E0330
	v_dual_sub_f32 v1, v48, v1 :: v_dual_add_f32 v48, v63, v32 // 00000049F598: C9480330 0130413F
	v_sub_f32_e32 v32, v63, v32                                // 00000049F5A0: 0840413F
	v_add_f32_e32 v63, v65, v52                                // 00000049F5A4: 067E6941
	v_dual_sub_f32 v52, v65, v52 :: v_dual_add_f32 v65, v66, v61// 00000049F5A8: C9486941 34407B42
	v_dual_sub_f32 v61, v66, v61 :: v_dual_add_f32 v66, v67, v64// 00000049F5B0: C9487B42 3D428143
	v_sub_f32_e32 v64, v67, v64                                // 00000049F5B8: 08808143
	v_add_f32_e32 v67, v35, v62                                // 00000049F5BC: 06867D23
	v_sub_f32_e32 v35, v35, v62                                // 00000049F5C0: 08467D23
	v_add_f32_e32 v62, v22, v54                                // 00000049F5C4: 067C6D16
	v_sub_f32_e32 v22, v22, v54                                // 00000049F5C8: 082C6D16
	v_add_f32_e32 v54, v33, v60                                // 00000049F5CC: 066C7921
	v_dual_sub_f32 v33, v33, v60 :: v_dual_add_f32 v60, v23, v55// 00000049F5D0: C9487921 213C6F17
	v_sub_f32_e32 v23, v23, v55                                // 00000049F5D8: 082E6F17
	v_add_f32_e32 v55, v20, v36                                // 00000049F5DC: 066E4914
	v_sub_f32_e32 v20, v20, v36                                // 00000049F5E0: 08284914
	v_add_f32_e32 v36, v34, v50                                // 00000049F5E4: 06486522
	v_sub_f32_e32 v34, v34, v50                                // 00000049F5E8: 08446522
	v_add_f32_e32 v50, v37, v53                                // 00000049F5EC: 06646B25
	v_sub_f32_e32 v37, v37, v53                                // 00000049F5F0: 084A6B25
	v_add_f32_e32 v53, v19, v51                                // 00000049F5F4: 066A6713
	v_sub_f32_e32 v19, v19, v51                                // 00000049F5F8: 08266713
	v_add_f32_e32 v51, v18, v38                                // 00000049F5FC: 06664D12
	v_sub_f32_e32 v18, v18, v38                                // 00000049F600: 08244D12
	v_add_f32_e32 v38, v21, v49                                // 00000049F604: 064C6315
	v_sub_f32_e32 v21, v21, v49                                // 00000049F608: 082A6315
	v_add_f32_e32 v49, v17, v39                                // 00000049F60C: 06624F11
	v_sub_f32_e32 v17, v17, v39                                // 00000049F610: 08224F11
	v_add_f32_e32 v39, v16, v1                                 // 00000049F614: 064E0310
	v_sub_f32_e32 v1, v16, v1                                  // 00000049F618: 08020310
	ds_store_b32 v10, v48                                      // 00000049F61C: D8340000 0000300A
	ds_store_b32 v3, v63 offset:512                            // 00000049F624: D8340200 00003F03
	ds_store_b32 v4, v65 offset:1024                           // 00000049F62C: D8340400 00004104
	ds_store_b32 v7, v66 offset:1536                           // 00000049F634: D8340600 00004207
	ds_store_b32 v8, v67 offset:2048                           // 00000049F63C: D8340800 00004308
	ds_store_b32 v9, v62 offset:2560                           // 00000049F644: D8340A00 00003E09
	ds_store_b32 v11, v54 offset:3072                          // 00000049F64C: D8340C00 0000360B
	ds_store_b32 v12, v60 offset:3584                          // 00000049F654: D8340E00 00003C0C
	ds_store_b32 v13, v55 offset:4096                          // 00000049F65C: D8341000 0000370D
	ds_store_b32 v14, v36 offset:4608                          // 00000049F664: D8341200 0000240E
	ds_store_b32 v15, v50 offset:5120                          // 00000049F66C: D8341400 0000320F
	ds_store_b32 v24, v53 offset:5632                          // 00000049F674: D8341600 00003518
	ds_store_b32 v25, v51 offset:6144                          // 00000049F67C: D8341800 00003319
	ds_store_b32 v26, v38 offset:6656                          // 00000049F684: D8341A00 0000261A
	ds_store_b32 v27, v49 offset:7168                          // 00000049F68C: D8341C00 0000311B
	ds_store_b32 v28, v39 offset:7680                          // 00000049F694: D8341E00 0000271C
	ds_store_b32 v29, v32 offset:8192                          // 00000049F69C: D8342000 0000201D
	ds_store_b32 v30, v52 offset:8704                          // 00000049F6A4: D8342200 0000341E
	ds_store_b32 v31, v61 offset:9216                          // 00000049F6AC: D8342400 00003D1F
	ds_store_b32 v40, v64 offset:9728                          // 00000049F6B4: D8342600 00004028
	ds_store_b32 v41, v35 offset:10240                         // 00000049F6BC: D8342800 00002329
	ds_store_b32 v42, v22 offset:10752                         // 00000049F6C4: D8342A00 0000162A
	ds_store_b32 v43, v33 offset:11264                         // 00000049F6CC: D8342C00 0000212B
	ds_store_b32 v44, v23 offset:11776                         // 00000049F6D4: D8342E00 0000172C
	ds_store_b32 v45, v20 offset:12288                         // 00000049F6DC: D8343000 0000142D
	ds_store_b32 v46, v34 offset:12800                         // 00000049F6E4: D8343200 0000222E
	ds_store_b32 v47, v37 offset:13312                         // 00000049F6EC: D8343400 0000252F
	ds_store_b32 v56, v19 offset:13824                         // 00000049F6F4: D8343600 00001338
	ds_store_b32 v57, v18 offset:14336                         // 00000049F6FC: D8343800 00001239
	ds_store_b32 v58, v21 offset:14848                         // 00000049F704: D8343A00 0000153A
	ds_store_b32 v59, v17 offset:15360                         // 00000049F70C: D8343C00 0000113B
	ds_store_b32 v0, v1 offset:15872                           // 00000049F714: D8343E00 00000100
	s_or_b32 exec_lo, exec_lo, s0                              // 00000049F71C: 8C7E007E
	s_ashr_i32 s9, s8, 31                                      // 00000049F720: 86099F08
	v_lshlrev_b32_e32 v0, 1, v2                                // 00000049F724: 30000481
	s_lshl_b64 s[0:1], s[8:9], 1                               // 00000049F728: 84808108
	v_lshlrev_b32_e32 v7, 9, v5                                // 00000049F72C: 300E0A89
	s_add_u32 s0, s2, s0                                       // 00000049F730: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000049F734: 82010103
	.long 0xd7000003                                           // 00000049F738: D7000003
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000049F73C: 02020000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049F740: BF870001
	v_add_co_ci_u32_e64 v4, null, s1, 0, s0                    // 00000049F744: D5207C04 00010001
	v_lshl_or_b32 v0, s11, 7, v5                               // 00000049F74C: D6560000 04150E0B
	s_mov_b32 s1, 0                                            // 00000049F754: BE810080
	s_waitcnt lgkmcnt(0)                                       // 00000049F758: BF89FC07
	s_barrier                                                  // 00000049F75C: BFBD0000
	buffer_gl0_inv                                             // 00000049F760: E0AC0000 00000000
	v_ashrrev_i32_e32 v1, 31, v0                               // 00000049F768: 3402009F
	v_xor_b32_e32 v10, v2, v5                                  // 00000049F76C: 3A140B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000049F770: BF870112
	.long 0xd73c0008                                           // 00000049F774: D73C0008
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000049F778: 02020081
	v_lshl_add_u32 v18, v10, 2, v7                             // 00000049F77C: D6460012 041D050A
	ds_load_2addr_stride64_b32 v[16:17], v18 offset1:64        // 00000049F784: D8E04000 10000012
	ds_load_2addr_stride64_b32 v[18:19], v18 offset0:128 offset1:192// 00000049F78C: D8E0C080 12000012
	.long 0xd7006a08                                           // 00000049F794: D7006A08
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000049F798: 02021006
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049F79C: BF870001
	v_add_co_ci_u32_e64 v9, null, s7, v9, vcc_lo               // 00000049F7A0: D5207C09 01AA1207
	v_add_nc_u32_e32 v11, 32, v0                               // 00000049F7A8: 4A1600A0
	v_add_nc_u32_e32 v12, 64, v0                               // 00000049F7AC: 4A1800C0
	s_clause 0x3                                               // 00000049F7B0: BF850003
	global_load_d16_b16 v1, v[8:9], off                        // 00000049F7B4: DC820000 017C0008
	global_load_d16_b16 v20, v[8:9], off offset:64             // 00000049F7BC: DC820040 147C0008
	global_load_d16_b16 v21, v[8:9], off offset:128            // 00000049F7C4: DC820080 157C0008
	global_load_d16_b16 v22, v[8:9], off offset:192            // 00000049F7CC: DC8200C0 167C0008
	v_add_nc_u32_e32 v14, 0x60, v0                             // 00000049F7D4: 4A1C00FF 00000060
	v_add_nc_u32_e32 v5, 4, v5                                 // 00000049F7DC: 4A0A0A84
	v_mad_i64_i32 v[8:9], null, v0, s10, 0                     // 00000049F7E0: D6FF7C08 02001500
	s_delay_alu instid0(VALU_DEP_1)                            // 00000049F7E8: BF870001
	.long 0xd73c0008                                           // 00000049F7EC: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000049F7F0: 02021081
	s_waitcnt lgkmcnt(1)                                       // 00000049F7F4: BF89FC17
	v_add_f32_e32 v23, v16, v17                                // 00000049F7F8: 062E2310
	s_waitcnt lgkmcnt(0)                                       // 00000049F7FC: BF89FC07
	v_dual_sub_f32 v16, v16, v17 :: v_dual_add_f32 v17, v18, v19// 00000049F800: C9482310 10102712
	v_sub_f32_e32 v18, v18, v19                                // 00000049F808: 08242712
	v_add_nc_u32_e32 v6, 16, v6                                // 00000049F80C: 4A0C0C90
	v_add_nc_u32_e32 v7, 0x800, v7                             // 00000049F810: 4A0E0EFF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049F818: BF870214
	v_dual_add_f32 v19, v23, v17 :: v_dual_add_nc_u32 v0, 4, v0// 00000049F81C: C9202317 13000084
	v_dual_add_f32 v24, v16, v18 :: v_dual_sub_f32 v17, v23, v17// 00000049F824: C90A2510 18102317
	v_mad_i64_i32 v[10:11], null, v11, s10, 0                  // 00000049F82C: D6FF7C0A 0200150B
	v_sub_f32_e32 v16, v16, v18                                // 00000049F834: 08202510
	v_mad_i64_i32 v[12:13], null, v12, s10, 0                  // 00000049F838: D6FF7C0C 0200150C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049F840: BF870004
	v_dual_mul_f32 v18, 0x3db504f3, v19 :: v_dual_mul_f32 v17, 0x3db504f3, v17// 00000049F844: C8C626FF 121022FF 3DB504F3
	v_mul_f32_e32 v19, 0x3db504f3, v24                         // 00000049F850: 102630FF 3DB504F3
	v_mad_i64_i32 v[14:15], null, v14, s10, 0                  // 00000049F858: D6FF7C0E 0200150E
	v_mul_f32_e32 v16, 0x3db504f3, v16                         // 00000049F860: 102020FF 3DB504F3
	.long 0xd73c000a                                           // 00000049F868: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 00000049F86C: 02021481
	.long 0xd7000008                                           // 00000049F870: D7000008
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 00000049F874: 02021103
	.long 0xd73c000c                                           // 00000049F878: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000049F87C: 02021881
	v_add_co_ci_u32_e64 v9, null, v4, v9, s0                   // 00000049F880: D5207C09 00021304
	.long 0xd73c000e                                           // 00000049F888: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 00000049F88C: 02021C81
	.long 0xd700000a                                           // 00000049F890: D700000A
	v_cndmask_b32_e32 v1, v3, v10, vcc_lo                      // 00000049F894: 02021503
	v_cmp_lt_u32_e32 vcc_lo, 0x6f, v6                          // 00000049F898: 7C920CFF 0000006F
	v_add_co_ci_u32_e64 v11, null, v4, v11, s0                 // 00000049F8A0: D5207C0B 00021704
	.long 0xd700000c                                           // 00000049F8A8: D700000C
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000049F8AC: 02021903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000049F8B0: BF8700A1
	v_add_co_ci_u32_e64 v13, null, v4, v13, s0                 // 00000049F8B4: D5207C0D 00021B04
	.long 0xd700000e                                           // 00000049F8BC: D700000E
	v_cndmask_b32_e32 v1, v3, v14, vcc_lo                      // 00000049F8C0: 02021D03
	v_add_co_ci_u32_e64 v15, null, v4, v15, s0                 // 00000049F8C4: D5207C0F 00021F04
	s_or_b32 s1, vcc_lo, s1                                    // 00000049F8CC: 8C01016A
	s_waitcnt vmcnt(3)                                         // 00000049F8D0: BF890FF7
	v_fma_mix_f32 v1, v1, v18, neg(0) op_sel_hi:[1,0,0]        // 00000049F8D4: CC200001 8A022501
	s_waitcnt vmcnt(2)                                         // 00000049F8DC: BF890BF7
	v_fma_mix_f32 v18, v20, v19, neg(0) op_sel_hi:[1,0,0]      // 00000049F8E0: CC200012 8A022714
	s_waitcnt vmcnt(1)                                         // 00000049F8E8: BF8907F7
	v_fma_mix_f32 v17, v21, v17, neg(0) op_sel_hi:[1,0,0]      // 00000049F8EC: CC200011 8A022315
	s_waitcnt vmcnt(0)                                         // 00000049F8F4: BF8903F7
	v_fma_mix_f32 v16, v22, v16, neg(0) op_sel_hi:[1,0,0]      // 00000049F8F8: CC200010 8A022116
	v_bfe_u32 v19, v1, 16, 1                                   // 00000049F900: D6100013 02052101
	v_bfe_u32 v20, v18, 16, 1                                  // 00000049F908: D6100014 02052112
	v_bfe_u32 v21, v17, 16, 1                                  // 00000049F910: D6100015 02052111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049F918: BF870214
	v_bfe_u32 v22, v16, 16, 1                                  // 00000049F91C: D6100016 02052110
	v_add3_u32 v1, v1, v19, 0x7fff                             // 00000049F924: D6550001 03FE2701 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000049F930: BF870214
	v_add3_u32 v18, v18, v20, 0x7fff                           // 00000049F934: D6550012 03FE2912 00007FFF
	v_add3_u32 v17, v17, v21, 0x7fff                           // 00000049F940: D6550011 03FE2B11 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000049F94C: BF870004
	v_add3_u32 v16, v16, v22, 0x7fff                           // 00000049F950: D6550010 03FE2D10 00007FFF
	s_clause 0x3                                               // 00000049F95C: BF850003
	global_store_d16_hi_b16 v[8:9], v1, off                    // 00000049F960: DC960000 007C0108
	global_store_d16_hi_b16 v[10:11], v18, off                 // 00000049F968: DC960000 007C120A
	global_store_d16_hi_b16 v[12:13], v17, off                 // 00000049F970: DC960000 007C110C
	global_store_d16_hi_b16 v[14:15], v16, off                 // 00000049F978: DC960000 007C100E
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000049F980: 917E017E
	s_cbranch_execnz 65400                                     // 00000049F984: BFA6FF78 <_ZN7halogen12_GLOBAL__N_113k_ht_deq_origILi3ELb0ELi16EEEvPKjiPKDF16_S5_Pti+0x1c68>
	s_endpgm                                                   // 00000049F988: BFB00000
		...

