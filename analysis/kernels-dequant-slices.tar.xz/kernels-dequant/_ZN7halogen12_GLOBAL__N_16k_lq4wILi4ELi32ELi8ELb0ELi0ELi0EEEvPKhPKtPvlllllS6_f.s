0000000000559700 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000559700: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000559708: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000559710: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000559714: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000559718: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000055971C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000559720: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000559728: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000055972C: 321E0085
	v_dual_mov_b32 v21, 0 :: v_dual_and_b32 v16, 31, v0        // 000000559730: CA240080 1510009F
	.long 0x7f263880                                           // 000000559738: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000055973C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000559744: BF89FC07
	s_clause 0x1                                               // 000000559748: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000055974C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000559754: DC520000 0D040002
	.long 0xd4510000                                           // 00000055975C: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000559760: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 000000559764: 8B007E00
	s_cselect_b32 s22, s3, 0                                   // 000000559768: 98168003
	s_cselect_b32 s23, s2, 0                                   // 00000055976C: 98178002
	s_add_u32 s0, s4, s14                                      // 000000559770: 80000E04
	s_addc_u32 s1, s5, s15                                     // 000000559774: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 000000559778: 850E9F0B
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s1              // 00000055977C: CA100080 07020001
	s_add_u32 s14, s10, s14                                    // 000000559784: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000559788: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000055978C: 86149F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000559790: 868E810E
	s_lshr_b32 s20, s20, 27                                    // 000000559794: 85149B14
	v_mov_b32_e32 v1, s0                                       // 000000559798: 7E020200
	s_add_u32 s20, s10, s20                                    // 00000055979C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000005597A0: 8215800B
	s_mul_i32 s19, s19, s23                                    // 0000005597A4: 96131713
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000005597A8: 85948514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005597AC: BF870499
	s_add_i32 s21, s20, 7                                      // 0000005597B0: 81158714
	s_ashr_i32 s24, s21, 31                                    // 0000005597B4: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005597B8: BF870499
	s_lshr_b32 s24, s24, 29                                    // 0000005597BC: 85189D18
	s_add_i32 s21, s21, s24                                    // 0000005597C0: 81151815
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005597C4: BF870009
	s_ashr_i32 s21, s21, 3                                     // 0000005597C8: 86158315
	s_add_u32 s0, s4, s16                                      // 0000005597CC: 80001004
	s_addc_u32 s1, s5, s17                                     // 0000005597D0: 82011105
	.long 0xd72c0012                                           // 0000005597D4: D72C0012
	v_cndmask_b32_e32 v1, s21, v15, vcc_lo                     // 0000005597D8: 02021E15
	v_mov_b32_e32 v4, s1                                       // 0000005597DC: 7E080201
	v_mad_u64_u32 v[9:10], null, s23, s14, v[1:2]              // 0000005597E0: D6FE7C09 04041C17
	v_mov_b32_e32 v3, s0                                       // 0000005597E8: 7E060200
	s_mul_i32 s0, s22, s14                                     // 0000005597EC: 96000E16
	s_waitcnt vmcnt(1)                                         // 0000005597F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000005597F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000005597FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000559800: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000559808: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 00000055980C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000559818: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000559824: BF870002
	.long 0x7e263982                                           // 000000559828: 7E263982
	v_add_nc_u32_e32 v2, s0, v10                               // 00000055982C: 4A041400
	v_mad_u64_u32 v[11:12], null, s18, s23, v[3:4]             // 000000559830: D6FE7C0B 040C2E12
	v_add_nc_u32_e32 v3, s21, v18                              // 000000559838: 4A062415
	v_add_nc_u32_e32 v10, v18, v16                             // 00000055983C: 4A142112
	s_mul_i32 s23, s23, s15                                    // 000000559840: 96170F17
	s_mul_i32 s0, s18, s22                                     // 000000559844: 96001612
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000559848: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s20, v3                                 // 000000559854: 22240614
	v_add_nc_u32_e32 v19, s23, v2                              // 000000559858: 4A260417
	v_add_nc_u32_e32 v3, s19, v12                              // 00000055985C: 4A061813
	ds_store_b32 v14, v1                                       // 000000559860: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000559868: 7C82250A
	v_add_nc_u32_e32 v20, s0, v3                               // 00000055986C: 4A280600
	s_waitcnt lgkmcnt(0)                                       // 000000559870: BF89FC07
	s_barrier                                                  // 000000559874: BFBD0000
	buffer_gl0_inv                                             // 000000559878: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 000000559880: BE81206A
	s_cbranch_execz 21                                         // 000000559884: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000559888: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 00000055988C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000559890: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000559894: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000559898: 3408069F
	.long 0xd7000001                                           // 00000055989C: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000005598A0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005598A4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000005598A8: D5207C02 00020514
	.long 0xd7000003                                           // 0000005598B0: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000005598B4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 0000005598B8: D5207C04 00020913
	s_clause 0x1                                               // 0000005598C0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 0000005598C4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 0000005598CC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 0000005598D4: BF8907F7
	v_cvt_f32_f16_e32 v21, v1                                  // 0000005598D8: 7E2A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005598DC: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 0000005598E0: CA100080 17180080
	v_mov_b32_e32 v22, 0                                       // 0000005598E8: 7E2C0280
	s_and_saveexec_b32 s1, vcc_lo                              // 0000005598EC: BE81206A
	s_cbranch_execz 401                                        // 0000005598F0: BFA50191 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x838>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 0000005598F4: CA200080 160014A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000005598FC: CA220080 170C1485
	v_mov_b32_e32 v27, v21                                     // 000000559904: 7E360315
	s_delay_alu instid0(VALU_DEP_3)                            // 000000559908: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 00000055990C: CA220080 18180284
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000559914: CA220080 111A0281
	s_mul_i32 s0, s11, 6                                       // 00000055991C: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 000000559920: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000559924: 8484820A
	s_add_i32 s14, s14, s0                                     // 000000559928: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000055992C: 9610860A
	s_mov_b32 s15, 0                                           // 000000559930: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000559934: 848A810A
	s_branch 351                                               // 000000559938: BFA0015F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x7b8>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000055993C: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 000000559940: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 000000559948: 8B006A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 00000055994C: 4A3232FF 00000200
	s_or_b32 s15, s0, s15                                      // 000000559954: 8C0F0F00
	v_add_nc_u32_e32 v26, 64, v26                              // 000000559958: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000055995C: 301A1A82
	ds_load_b32 v42, v13                                       // 000000559960: D8D80000 2A00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000559968: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000055996C: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000559970: 361A1AFF 000003FC
	ds_load_b32 v43, v13                                       // 000000559978: D8D80000 2B00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000559980: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000559984: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000559988: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000559990: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559994: 360A0AFF 000003FC
	ds_load_b32 v44, v13                                       // 00000055999C: D8D80000 2C00000D
	ds_load_b32 v45, v5                                        // 0000005599A4: D8D80000 2D000005
	v_and_b32_e32 v5, 0xff, v6                                 // 0000005599AC: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000005599B4: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000005599B8: 300A0A82
	ds_load_b32 v46, v5                                        // 0000005599BC: D8D80000 2E000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 0000005599C4: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005599C8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005599CC: 360A0AFF 000003FC
	ds_load_b32 v47, v5                                        // 0000005599D4: D8D80000 2F000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 0000005599DC: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005599E0: 360A0AFF 000003FC
	ds_load_b32 v48, v5                                        // 0000005599E8: D8D80000 30000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 0000005599F0: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005599F4: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000005599F8: 360A0AFF 000003FC
	ds_load_b32 v49, v5                                        // 000000559A00: D8D80000 31000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000559A08: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000559A10: 300A0A82
	ds_load_b32 v50, v5                                        // 000000559A14: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000559A1C: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000559A20: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559A24: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000559A2C: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000559A34: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559A38: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000559A40: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000559A48: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000559A4C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559A50: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000559A58: D8D80000 35000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000559A60: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000559A68: 300A0A82
	ds_load_b32 v54, v5                                        // 000000559A6C: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000559A74: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000559A78: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559A7C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000559A84: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000559A8C: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559A90: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000559A98: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000559AA0: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000559AA4: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000559AA8: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000559AB0: D8D80000 39000005
	.long 0xd73c0005                                           // 000000559AB8: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000559ABC: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000559AC0: 4A1818FF 00000400
	.long 0xd7006a28                                           // 000000559AC8: D7006A28
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000559ACC: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000559AD0: BF870001
	v_add_co_ci_u32_e64 v41, null, s7, v6, vcc_lo              // 000000559AD4: D5207C29 01AA0C07
	s_clause 0x3                                               // 000000559ADC: BF850003
	global_load_b128 v[5:8], v[40:41], off                     // 000000559AE0: DC5E0000 057C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000559AE8: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000559AF0: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000559AF8: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000559B00: BF890CF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000559B04: CC1A4005 1A025505
	s_waitcnt lgkmcnt(14)                                      // 000000559B0C: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B10: BF8700A1
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000559B14: CC1A4005 1C165706
	s_waitcnt lgkmcnt(13)                                      // 000000559B1C: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000559B20: CC1A4005 1C165907
	s_waitcnt lgkmcnt(12)                                      // 000000559B28: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B2C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000559B30: CC1A4005 1C165B08
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000559B38: BF8908B7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000559B3C: CC1A4005 1C165D1C
	s_waitcnt lgkmcnt(10)                                      // 000000559B44: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B48: BF8700A1
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000559B4C: CC1A4005 1C165F1D
	s_waitcnt lgkmcnt(9)                                       // 000000559B54: BF89FC97
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000559B58: CC1A4005 1C16611E
	s_waitcnt lgkmcnt(8)                                       // 000000559B60: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B64: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000559B68: CC1A4005 1C16631F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000559B70: BF890477
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000559B74: CC1A4005 1C166520
	s_waitcnt lgkmcnt(6)                                       // 000000559B7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B80: BF8700A1
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000559B84: CC1A4005 1C166721
	s_waitcnt lgkmcnt(5)                                       // 000000559B8C: BF89FC57
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000559B90: CC1A4005 1C166922
	s_waitcnt lgkmcnt(4)                                       // 000000559B98: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559B9C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000559BA0: CC1A4005 1C166B23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000559BA8: BF890037
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000559BAC: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000559BB4: D7006A24
	v_cndmask_b32_e32 v0, v40, v10, vcc_lo                     // 000000559BB8: 02001528
	s_waitcnt lgkmcnt(2)                                       // 000000559BBC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000559BC0: BF870132
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000559BC4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s11, v41, vcc_lo            // 000000559BCC: D5207C25 01AA520B
	s_waitcnt lgkmcnt(1)                                       // 000000559BD4: BF89FC17
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000559BD8: CC1A4005 1C167126
	s_waitcnt lgkmcnt(0)                                       // 000000559BE0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559BE4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000559BE8: CC1A4005 1C167327
	v_fmac_f32_e32 v22, v21, v5                                // 000000559BF0: 562C0B15
	s_clause 0x3                                               // 000000559BF4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000559BF8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000559C00: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000559C08: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000559C10: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000559C18: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000559C1C: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559C24: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000559C28: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000559C30: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559C38: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000559C3C: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000559C44: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000559C48: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559C50: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000559C54: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000559C5C: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559C64: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000559C68: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000559C70: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000559C74: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559C7C: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000559C80: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000559C88: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559C90: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000559C94: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000559C9C: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000559CA0: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000559CA8: D7006A24
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000559CAC: 02000928
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000559CB0: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000559CB4: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s5, v41, vcc_lo             // 000000559CBC: D5207C25 01AA5205
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000559CC4: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559CCC: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000559CD0: CC1A4005 1C167327
	v_fmac_f32_e32 v24, v21, v5                                // 000000559CD8: 56300B15
	s_clause 0x3                                               // 000000559CDC: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000559CE0: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000559CE8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000559CF0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000559CF8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000559D00: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000559D04: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559D0C: BF870091
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000559D10: CC1A4005 1C165706
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000559D18: CC1A4005 1C165907
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559D20: BF8700A1
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000559D24: CC1A4005 1C165B08
	s_waitcnt vmcnt(2)                                         // 000000559D2C: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000559D30: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559D38: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000559D3C: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000559D44: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559D4C: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000559D50: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000559D58: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000559D5C: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559D64: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000559D68: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000559D70: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559D78: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000559D7C: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000559D84: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000559D88: CC1A4005 1C166D24
	.long 0xd7006a24                                           // 000000559D90: D7006A24
	v_cndmask_b32_e32 v0, v40, v16, vcc_lo                     // 000000559D94: 02002128
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000559D98: BF870122
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000559D9C: CC1A4005 1C166F25
	v_add_co_ci_u32_e64 v37, null, s14, v41, vcc_lo            // 000000559DA4: D5207C25 01AA520E
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000559DAC: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559DB4: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000559DB8: CC1A4005 1C167327
	v_fmac_f32_e32 v23, v21, v5                                // 000000559DC0: 562E0B15
	s_clause 0x3                                               // 000000559DC4: BF850003
	global_load_b128 v[5:8], v[36:37], off                     // 000000559DC8: DC5E0000 057C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000559DD0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000559DD8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000559DE0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000559DE8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v42, 0                             // 000000559DEC: CC1A4005 1A025505
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000559DF4: BF870121
	v_dot2_f32_bf16 v5, v6, v43, v5                            // 000000559DF8: CC1A4005 1C165706
	v_mov_b32_e32 v6, v2                                       // 000000559E00: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v44, v5                            // 000000559E04: CC1A4005 1C165907
	v_mov_b32_e32 v7, v3                                       // 000000559E0C: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000559E10: BF870132
	v_dot2_f32_bf16 v5, v8, v45, v5                            // 000000559E14: CC1A4005 1C165B08
	v_mov_b32_e32 v8, v4                                       // 000000559E1C: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000559E20: BF890BF7
	v_dot2_f32_bf16 v5, v28, v46, v5                           // 000000559E24: CC1A4005 1C165D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559E2C: BF870091
	v_dot2_f32_bf16 v5, v29, v47, v5                           // 000000559E30: CC1A4005 1C165F1D
	v_dot2_f32_bf16 v5, v30, v48, v5                           // 000000559E38: CC1A4005 1C16611E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559E40: BF8700A1
	v_dot2_f32_bf16 v5, v31, v49, v5                           // 000000559E44: CC1A4005 1C16631F
	s_waitcnt vmcnt(1)                                         // 000000559E4C: BF8907F7
	v_dot2_f32_bf16 v5, v32, v50, v5                           // 000000559E50: CC1A4005 1C166520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559E58: BF870091
	v_dot2_f32_bf16 v5, v33, v51, v5                           // 000000559E5C: CC1A4005 1C166721
	v_dot2_f32_bf16 v5, v34, v52, v5                           // 000000559E64: CC1A4005 1C166922
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559E6C: BF8700A1
	v_dot2_f32_bf16 v5, v35, v53, v5                           // 000000559E70: CC1A4005 1C166B23
	s_waitcnt vmcnt(0)                                         // 000000559E78: BF8903F7
	v_dot2_f32_bf16 v5, v36, v54, v5                           // 000000559E7C: CC1A4005 1C166D24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559E84: BF870091
	v_dot2_f32_bf16 v5, v37, v55, v5                           // 000000559E88: CC1A4005 1C166F25
	v_dot2_f32_bf16 v5, v38, v56, v5                           // 000000559E90: CC1A4005 1C167126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000559E98: BF870091
	v_dot2_f32_bf16 v5, v39, v57, v5                           // 000000559E9C: CC1A4005 1C167327
	v_fmac_f32_e32 v17, v21, v5                                // 000000559EA4: 56220B15
	v_mov_b32_e32 v5, v1                                       // 000000559EA8: 7E0A0301
	v_mov_b32_e32 v21, v27                                     // 000000559EAC: 7E2A031B
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000559EB0: 917E0F7E
	s_cbranch_execz 31                                         // 000000559EB4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x834>
	s_waitcnt vmcnt(0)                                         // 000000559EB8: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 000000559EBC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000559EC4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000559ECC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 000000559ED0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000559ED4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 000000559ED8: 7C8C250A
	.long 0xd4c1007e                                           // 000000559EDC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 000000559EE0: 0202250A
	s_cbranch_execz 65173                                      // 000000559EE4: BFA5FE95 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	v_ashrrev_i32_e32 v2, 31, v26                              // 000000559EE8: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 000000559EEC: 3408329F
	.long 0xd7000001                                           // 000000559EF0: D7000001
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 000000559EF4: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000559EF8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 000000559EFC: D5207C02 00020514
	.long 0xd7000003                                           // 000000559F04: D7000003
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000559F08: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s0                  // 000000559F0C: D5207C04 00020913
	s_clause 0x1                                               // 000000559F14: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000559F18: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000559F20: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000559F28: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000559F2C: 7E36170D
	s_branch 65154                                             // 000000559F30: BFA0FE82 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x23c>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000559F34: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000559F38: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000559F3C: 8C7E017E
	.long 0xd71f0001                                           // 000000559F40: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000559F44: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000559F48: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000559F4C: 3A040290
	s_waitcnt vmcnt(0)                                         // 000000559F50: BF8903F7
	v_xor_b32_e32 v6, 8, v1                                    // 000000559F54: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000559F58: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000559F5C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000559F60: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000559F64: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000559F68: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000559F6C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000559F70: 30040482
	ds_bpermute_b32 v5, v2, v23                                // 000000559F74: DACC0000 05001702
	s_waitcnt lgkmcnt(0)                                       // 000000559F7C: BF89FC07
	v_add_f32_e32 v5, v23, v5                                  // 000000559F80: 060A0B17
	ds_bpermute_b32 v3, v2, v22                                // 000000559F84: DACC0000 03001602
	ds_bpermute_b32 v4, v2, v24                                // 000000559F8C: DACC0000 04001802
	ds_bpermute_b32 v2, v2, v17                                // 000000559F94: DACC0000 02001102
	s_waitcnt lgkmcnt(2)                                       // 000000559F9C: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000559FA0: C9120716 03060D01
	s_waitcnt lgkmcnt(0)                                       // 000000559FA8: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000559FAC: 06040511
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000559FB0: 7C9814A0
	s_delay_alu instid0(VALU_DEP_3)                            // 000000559FB4: BF870003
	v_lshlrev_b32_e32 v6, 2, v6                                // 000000559FB8: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000559FBC: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 000000559FC0: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 000000559FC8: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 000000559FCC: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 000000559FD0: DACC0000 07000306
	s_waitcnt lgkmcnt(0)                                       // 000000559FD8: BF89FC07
	v_dual_add_f32 v3, v3, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 000000559FDC: C9220F03 030A1482
	v_add_f32_e32 v4, v24, v4                                  // 000000559FE4: 06080918
	ds_bpermute_b32 v8, v6, v4                                 // 000000559FE8: DACC0000 08000406
	ds_bpermute_b32 v6, v6, v2                                 // 000000559FF0: DACC0000 06000206
	s_waitcnt lgkmcnt(0)                                       // 000000559FF8: BF89FC07
	v_add_f32_e32 v2, v2, v6                                   // 000000559FFC: 06040D02
	ds_bpermute_b32 v6, v10, v3                                // 00000055A000: DACC0000 0600030A
	s_waitcnt lgkmcnt(0)                                       // 00000055A008: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v8     // 00000055A00C: C9080D03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 00000055A014: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 00000055A01C: BF89FC07
	v_add_f32_e32 v5, v5, v8                                   // 00000055A020: 060A1105
	ds_bpermute_b32 v7, v10, v4                                // 00000055A024: DACC0000 0700040A
	ds_bpermute_b32 v9, v10, v2                                // 00000055A02C: DACC0000 0900020A
	v_xor_b32_e32 v10, 2, v1                                   // 00000055A034: 3A140282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A038: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055A03C: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000055A040: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 00000055A044: 30141482
	s_waitcnt lgkmcnt(0)                                       // 00000055A048: BF89FC07
	v_add_f32_e32 v6, v2, v9                                   // 00000055A04C: 060C1302
	ds_bpermute_b32 v2, v10, v3                                // 00000055A050: DACC0000 0200030A
	v_add_f32_e32 v4, v4, v7                                   // 00000055A058: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 00000055A05C: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000055A064: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 00000055A06C: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000055A074: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000055A078: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000055A07C: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 00000055A080: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000055A084: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 00000055A088: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 00000055A090: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000055A094: 06061105
	s_waitcnt lgkmcnt(0)                                       // 00000055A098: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 00000055A09C: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000055A0A4: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 00000055A0AC: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 00000055A0B4: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 00000055A0BC: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v16                                   // 00000055A0C4: 7D942080
	s_cbranch_execz 9                                          // 00000055A0C8: BFA50009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x9f0>
	s_waitcnt lgkmcnt(1)                                       // 00000055A0CC: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_add_f32 v7, v3, v7     // 00000055A0D0: C9081105 08060F03
	s_waitcnt lgkmcnt(0)                                       // 00000055A0D8: BF89FC07
	v_dual_add_f32 v6, v2, v6 :: v_dual_add_f32 v5, v1, v4     // 00000055A0DC: C9080D02 06040901
	v_lshlrev_b32_e32 v1, 4, v15                               // 00000055A0E4: 30021E84
	ds_store_b128 v1, v[5:8] offset:1024                       // 00000055A0E8: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s0                              // 00000055A0F0: 8C7E007E
	.long 0xd4510000                                           // 00000055A0F4: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000055A0F8: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 4, v0                             // 00000055A0FC: 7C980084
	s_waitcnt lgkmcnt(0)                                       // 00000055A100: BF89FC07
	s_barrier                                                  // 00000055A104: BFBD0000
	buffer_gl0_inv                                             // 00000055A108: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000055A110: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000055A114: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000055A118: BE812000
	s_cbranch_execz 52                                         // 00000055A11C: BFA50034 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi8ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xaf0>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 00000055A120: 4A0E1CFF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000055A128: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:4                     // 00000055A12C: D8DC0400 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:8 offset1:12          // 00000055A134: D8DC0C08 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:16 offset1:20         // 00000055A13C: D8DC1410 05000007
	ds_load_2addr_b32 v[7:8], v7 offset0:24 offset1:28         // 00000055A144: D8DC1C18 07000007
	s_waitcnt lgkmcnt(3)                                       // 00000055A14C: BF89FC37
	v_add_f32_e32 v1, 0, v1                                    // 00000055A150: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000055A154: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000055A158: 06020501
	s_waitcnt lgkmcnt(2)                                       // 00000055A15C: BF89FC27
	v_add_f32_e32 v1, v1, v3                                   // 00000055A160: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000055A164: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 00000055A168: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000055A16C: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(1)                                       // 00000055A174: BF89FC17
	v_add_f32_e32 v3, v3, v5                                   // 00000055A178: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000055A17C: BF870191
	v_add_f32_e32 v4, v3, v6                                   // 00000055A180: 06080D03
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000055A184: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 00000055A18C: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055A190: BF870092
	v_add_f32_e32 v0, v4, v7                                   // 00000055A194: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000055A198: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000055A19C: BF870113
	.long 0xd73c0000                                           // 00000055A1A0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000055A1A4: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000055A1A8: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000055A1B0: BF870092
	.long 0xd7006a00                                           // 00000055A1B4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000055A1B8: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000055A1BC: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000055A1C4: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000055A1C8: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000055A1D4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000055A1D8: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000055A1DC: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000055A1E0: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000055A1E8: DC960000 007C0200
	s_endpgm                                                   // 00000055A1F0: BFB00000
		...

