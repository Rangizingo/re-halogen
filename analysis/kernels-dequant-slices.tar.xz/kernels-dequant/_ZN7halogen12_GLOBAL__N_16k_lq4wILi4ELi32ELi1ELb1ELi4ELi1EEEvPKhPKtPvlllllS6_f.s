0000000000f94400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000F94400: F4100100 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 000000F94408: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000F9440C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000F94410: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 000000F94414: 32060085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000F94418: 84808302
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F9441C: 30020282
	v_dual_mov_b32 v17, s1 :: v_dual_and_b32 v2, 60, v2        // 000000F94420: CA240001 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F94428: BF870003
	v_or_b32_e32 v16, s0, v3                                   // 000000F9442C: 38200600
	.long 0x7f063880                                           // 000000F94430: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 000000F94434: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F94438: 30000082
	s_waitcnt lgkmcnt(0)                                       // 000000F9443C: BF89FC07
	s_clause 0x1                                               // 000000F94440: BF850001
	global_load_b32 v1, v1, s[4:5]                             // 000000F94444: DC520000 01040001
	global_load_b32 v2, v2, s[4:5]                             // 000000F9444C: DC520000 02040002
	.long 0xd4540000                                           // 000000F94454: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 000000F94458: 0202200C
	s_add_u32 s22, s4, s16                                     // 000000F9445C: 80161004
	s_addc_u32 s23, s5, s17                                    // 000000F94460: 82171105
	s_ashr_i32 s2, s11, 31                                     // 000000F94464: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000F94468: BF870159
	s_lshr_b32 s2, s2, 27                                      // 000000F9446C: 85029B02
	v_cndmask_b32_e64 v10, 0, v16, s0                          // 000000F94470: D501000A 00022080
	v_cndmask_b32_e64 v12, 0, s1, s0                           // 000000F94478: D501000C 00000280
	s_add_u32 s2, s10, s2                                      // 000000F94480: 8002020A
	s_addc_u32 s3, s11, 0                                      // 000000F94484: 8203800B
	.long 0xd72c0004                                           // 000000F94488: D72C0004
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000F9448C: 02021413
	v_mad_u64_u32 v[8:9], null, s18, v10, 0                    // 000000F94490: D6FE7C08 02021412
	s_lshr_b64 s[20:21], s[2:3], 5                             // 000000F94498: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000F9449C: BF870009
	s_cmpk_lt_i32 s20, 0x101                                   // 000000F944A0: B3940101
	.long 0xd4440002                                           // 000000F944A4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000F944A8: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 000000F944AC: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 000000F944B0: B2940100
	.long 0xd700030b                                           // 000000F944B4: D700030B
	v_cndmask_b32_e32 v1, s22, v8, vcc_lo                      // 000000F944B8: 02021016
	s_waitcnt vmcnt(1)                                         // 000000F944BC: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 000000F944C0: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 000000F944C8: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 000000F944CC: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F944D4: BF8701A2
	v_add3_u32 v1, v1, v5, 0x7fff                              // 000000F944D8: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 000000F944E4: D72C0005
	v_cndmask_b32_e32 v1, s18, v12, vcc_lo                     // 000000F944E8: 02021812
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000F944EC: D6550002 03FE0D02 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 000000F944F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F944FC: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 000000F94500: 8B6A127E
	.long 0x7e063981                                           // 000000F94504: 7E063981
	v_add3_u32 v9, v9, v5, v4                                  // 000000F94508: D6550009 04120B09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F94510: BF870112
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 000000F94514: D6570001 040E04FF FFFF0000
	v_add_co_ci_u32_e64 v20, null, s23, v9, s3                 // 000000F94520: D5207C14 000E1217
	ds_store_b32 v0, v1                                        // 000000F94528: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 000000F94530: BF89FC07
	s_barrier                                                  // 000000F94534: BFBD0000
	buffer_gl0_inv                                             // 000000F94538: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 000000F94540: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000F94544: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 000000F9454C: BE832002
	s_cbranch_execz 10                                         // 000000F94550: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x17c>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000F94554: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94558: BF870091
	.long 0xd7006a02                                           // 000000F9455C: D7006A02
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 000000F94560: 0202010B
	v_add_co_ci_u32_e64 v3, null, 0, v20, vcc_lo               // 000000F94564: D5207C03 01AA2880
	global_load_d16_b16 v0, v[2:3], off                        // 000000F9456C: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000F94574: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000F94578: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F9457C: 8C7E037E
	v_or_b32_e32 v2, 32, v23                                   // 000000F94580: 38042EA0
	s_mov_b32 s2, exec_lo                                      // 000000F94584: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F94588: BF870001
	.long 0xd4c4007e                                           // 000000F9458C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000F94590: 02020414
	s_cbranch_execz 10                                         // 000000F94594: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x1c0>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000F94598: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9459C: BF870091
	.long 0xd7006a01                                           // 000000F945A0: D7006A01
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000F945A4: 0202030B
	v_add_co_ci_u32_e64 v2, null, 0, v20, vcc_lo               // 000000F945A8: D5207C02 01AA2880
	global_load_d16_b16 v1, v[1:2], off                        // 000000F945B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000F945B8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 000000F945BC: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F945C0: 8C7E027E
	v_or_b32_e32 v4, 64, v23                                   // 000000F945C4: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 000000F945C8: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 000000F945D0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F945D4: BF870002
	.long 0xd4c4007e                                           // 000000F945D8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000F945DC: 02020814
	s_cbranch_execz 10                                         // 000000F945E0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x20c>
	v_lshlrev_b32_e32 v2, 1, v4                                // 000000F945E4: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F945E8: BF870091
	.long 0xd7006a04                                           // 000000F945EC: D7006A04
	v_cndmask_b32_e32 v1, v11, v2, vcc_lo                      // 000000F945F0: 0202050B
	v_add_co_ci_u32_e64 v5, null, 0, v20, vcc_lo               // 000000F945F4: D5207C05 01AA2880
	global_load_d16_b16 v2, v[4:5], off                        // 000000F945FC: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000F94604: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000F94608: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F9460C: 8C7E027E
	v_or_b32_e32 v4, 0x60, v23                                 // 000000F94610: 38082EFF 00000060
	s_mov_b32 s2, exec_lo                                      // 000000F94618: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F9461C: BF870001
	.long 0xd4c4007e                                           // 000000F94620: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 000000F94624: 02020814
	s_cbranch_execz 10                                         // 000000F94628: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x254>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000F9462C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94630: BF870091
	.long 0xd7006a03                                           // 000000F94634: D7006A03
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 000000F94638: 0202070B
	v_add_co_ci_u32_e64 v4, null, 0, v20, vcc_lo               // 000000F9463C: D5207C04 01AA2880
	global_load_d16_b16 v3, v[3:4], off                        // 000000F94644: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000F9464C: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000F94650: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F94654: 8C7E027E
	v_or_b32_e32 v6, 0x80, v23                                 // 000000F94658: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000F94660: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 000000F94668: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F9466C: BF870002
	.long 0xd4c4007e                                           // 000000F94670: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000F94674: 02020C14
	s_cbranch_execz 10                                         // 000000F94678: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2a4>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000F9467C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94680: BF870091
	.long 0xd7006a06                                           // 000000F94684: D7006A06
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 000000F94688: 0202090B
	v_add_co_ci_u32_e64 v7, null, 0, v20, vcc_lo               // 000000F9468C: D5207C07 01AA2880
	global_load_d16_b16 v4, v[6:7], off                        // 000000F94694: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000F9469C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000F946A0: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F946A4: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v23                                 // 000000F946A8: 380C2EFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 000000F946B0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F946B4: BF870001
	.long 0xd4c4007e                                           // 000000F946B8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 000000F946BC: 02020C14
	s_cbranch_execz 10                                         // 000000F946C0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x2ec>
	v_lshlrev_b32_e32 v5, 1, v6                                // 000000F946C4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F946C8: BF870091
	.long 0xd7006a05                                           // 000000F946CC: D7006A05
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000F946D0: 02020B0B
	v_add_co_ci_u32_e64 v6, null, 0, v20, vcc_lo               // 000000F946D4: D5207C06 01AA2880
	global_load_d16_b16 v5, v[5:6], off                        // 000000F946DC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 000000F946E4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 000000F946E8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F946EC: 8C7E027E
	v_or_b32_e32 v13, 0xc0, v23                                // 000000F946F0: 381A2EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 000000F946F8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 000000F94700: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F94704: BF870002
	.long 0xd4c4007e                                           // 000000F94708: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 000000F9470C: 02021A14
	s_cbranch_execz 10                                         // 000000F94710: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x33c>
	v_lshlrev_b32_e32 v6, 1, v13                               // 000000F94714: 300C1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94718: BF870091
	.long 0xd7006a0d                                           // 000000F9471C: D7006A0D
	v_cndmask_b32_e32 v1, v11, v6, vcc_lo                      // 000000F94720: 02020D0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000F94724: D5207C0E 01AA2880
	global_load_d16_b16 v6, v[13:14], off                      // 000000F9472C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 000000F94734: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 000000F94738: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F9473C: 8C7E027E
	v_or_b32_e32 v13, 0xe0, v23                                // 000000F94740: 381A2EFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 000000F94748: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F9474C: BF870001
	.long 0xd4c4007e                                           // 000000F94750: D4C4007E
	v_cndmask_b32_e32 v1, s20, v13, vcc_lo                     // 000000F94754: 02021A14
	s_cbranch_execz 10                                         // 000000F94758: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x384>
	v_lshlrev_b32_e32 v7, 1, v13                               // 000000F9475C: 300E1A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94760: BF870091
	.long 0xd7006a0d                                           // 000000F94764: D7006A0D
	v_cndmask_b32_e32 v1, v11, v7, vcc_lo                      // 000000F94768: 02020F0B
	v_add_co_ci_u32_e64 v14, null, 0, v20, vcc_lo              // 000000F9476C: D5207C0E 01AA2880
	global_load_d16_b16 v7, v[13:14], off                      // 000000F94774: DC820000 077C000D
	s_waitcnt vmcnt(0)                                         // 000000F9477C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000F94780: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 000000F94784: 8C7E027E
	s_branch 9                                                 // 000000F94788: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x3b0>
	v_mov_b32_e32 v0, 0                                        // 000000F9478C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F94790: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000F94794: 7E020300
	v_mov_b32_e32 v2, v0                                       // 000000F94798: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000F9479C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000F947A0: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000F947A4: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 000000F947A8: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 000000F947AC: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 000000F947B0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000F947B4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000F947B8: 850E9F0B
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v13, 0             // 000000F947BC: CA100080 1A0C0080
	s_add_u32 s14, s10, s14                                    // 000000F947C4: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000F947C8: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 000000F947CC: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000F947D4: 868E810E
	v_mov_b32_e32 v33, 0                                       // 000000F947D8: 7E420280
	v_mad_u64_u32 v[18:19], null, v10, s14, s[2:3]             // 000000F947DC: D6FE7C12 00081D0A
	.long 0xd72c000a                                           // 000000F947E4: D72C000A
	v_cndmask_b32_e32 v0, v10, v15, vcc_lo                     // 000000F947E8: 02001F0A
	.long 0xd72c000f                                           // 000000F947EC: D72C000F
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 000000F947F0: 02001D0C
	.long 0xd4440002                                           // 000000F947F4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 000000F947F8: 02022E14
	v_mov_b32_e32 v12, 0                                       // 000000F947FC: 7E180280
	v_mov_b32_e32 v14, 0                                       // 000000F94800: 7E1C0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F94804: BF870004
	v_add3_u32 v25, v15, v19, v10                              // 000000F94808: D6550019 042A270F
	v_mov_b32_e32 v15, 0                                       // 000000F94810: 7E1E0280
	s_and_saveexec_b32 s3, s2                                  // 000000F94814: BE832002
	s_cbranch_execz 21                                         // 000000F94818: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v10, 4, v23    // 000000F9481C: CA220080 210A2E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94824: BF870091
	.long 0xd7006a0c                                           // 000000F94828: D7006A0C
	v_cndmask_b32_e32 v1, v18, v10, vcc_lo                     // 000000F9482C: 02021512
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000F94830: D5207C0D 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 000000F94838: 916A127E
	global_load_b128 v[12:15], v[12:13], off                   // 000000F9483C: DC5E0000 0C7C000C
	s_cbranch_vccnz 10                                         // 000000F94844: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_lshlrev_b32_e32 v10, 1, v23                              // 000000F94848: 30142E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F9484C: BF870091
	.long 0xd7006a0a                                           // 000000F94850: D7006A0A
	v_cndmask_b32_e32 v1, v11, v10, vcc_lo                     // 000000F94854: 0202150B
	v_add_co_ci_u32_e64 v11, null, 0, v20, vcc_lo              // 000000F94858: D5207C0B 01AA2880
	global_load_d16_b16 v10, v[10:11], off                     // 000000F94860: DC820000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 000000F94868: BF8903F7
	v_cvt_f32_f16_e32 v33, v10                                 // 000000F9486C: 7E42170A
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F94870: 8C7E037E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 000000F94874: CA100080 1B1C0080
	v_mov_b32_e32 v29, 0                                       // 000000F9487C: 7E3A0280
	s_and_saveexec_b32 s3, s2                                  // 000000F94880: BE832002
	s_cbranch_execz 447                                        // 000000F94884: BFA501BF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb84>
	v_dual_mov_b32 v31, v23 :: v_dual_lshlrev_b32 v10, 1, v23  // 000000F94888: CA220117 1F0A2E81
	.long 0xd7006a08                                           // 000000F94890: D7006A08
	v_cndmask_b32_e32 v1, s16, v8, vcc_lo                      // 000000F94894: 02021010
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F94898: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s17, v9, vcc_lo              // 000000F9489C: D5207C09 01AA1211
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000F948A4: CA220080 14122E85
	.long 0xd7006a08                                           // 000000F948AC: D7006A08
	v_cndmask_b32_e32 v1, v8, v10, vcc_lo                      // 000000F948B0: 02021508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F948B4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, vcc_lo                // 000000F948B8: D5207C09 01AA1280
	v_lshl_or_b32 v30, v23, 4, 0x200                           // 000000F948C0: D656001E 03FD0917 00000200
	.long 0xd7006a08                                           // 000000F948CC: D7006A08
	v_cndmask_b32_e32 v1, s4, v8, vcc_lo                       // 000000F948D0: 02021004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F948D4: BF8701A1
	v_add_co_ci_u32_e64 v9, null, s5, v9, vcc_lo               // 000000F948D8: D5207C09 01AA1205
	v_dual_mov_b32 v29, v20 :: v_dual_mov_b32 v32, v33         // 000000F948E0: CA100114 1D200121
	.long 0xd7006a15                                           // 000000F948E8: D7006A15
	v_cndmask_b32_e32 v0, v8, v192, vcc_lo                     // 000000F948EC: 02018108
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F948F0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v9, vcc_lo               // 000000F948F4: D5207C16 01AA1280
	v_mov_b32_e32 v28, v20                                     // 000000F948FC: 7E380314
	v_mov_b32_e32 v27, v20                                     // 000000F94900: 7E360314
	v_mov_b32_e32 v26, v20                                     // 000000F94904: 7E340314
	s_mul_i32 s2, s11, 6                                       // 000000F94908: 9602860B
	s_mul_hi_u32 s18, s10, 6                                   // 000000F9490C: 9692860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000F94910: 848E820A
	s_add_i32 s18, s18, s2                                     // 000000F94914: 81120212
	s_mul_i32 s17, s10, 6                                      // 000000F94918: 9611860A
	s_mov_b32 s16, 0                                           // 000000F9491C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000F94920: 8484810A
	s_branch 378                                               // 000000F94924: BFA0017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb10>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000F94928: 8C7E0A7E
	v_cndmask_b32_e64 v33, v33, v0, s1                         // 000000F9492C: D5010021 00060121
	v_cndmask_b32_e64 v34, v0, v1, s1                          // 000000F94934: D5010022 00060300
	v_dual_mov_b32 v41, v7 :: v_dual_and_b32 v0, 0xff, v12     // 000000F9493C: CA240107 290018FF 000000FF
	v_cndmask_b32_e64 v40, v6, v7, s1                          // 000000F94948: D5010028 00060F06
	v_cndmask_b32_e64 v39, v5, v6, s1                          // 000000F94950: D5010027 00060D05
	v_cndmask_b32_e64 v38, v4, v5, s1                          // 000000F94958: D5010026 00060B04
	v_cndmask_b32_e64 v37, v3, v4, s1                          // 000000F94960: D5010025 00060903
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F94968: 30000082
	v_cndmask_b32_e64 v36, v2, v3, s1                          // 000000F9496C: D5010024 00060702
	v_cndmask_b32_e64 v35, v1, v2, s1                          // 000000F94974: D5010023 00060501
	s_and_b32 s2, exec_lo, s2                                  // 000000F9497C: 8B02027E
	v_add_nc_u32_e32 v30, 0x200, v30                           // 000000F94980: 4A3C3CFF 00000200
	ds_load_b32 v48, v0                                        // 000000F94988: D8D80000 30000000
	v_lshrrev_b32_e32 v0, 6, v12                               // 000000F94990: 32001886
	s_or_b32 s16, s2, s16                                      // 000000F94994: 8C101002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F94998: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F9499C: 360000FF 000003FC
	ds_load_b32 v49, v0                                        // 000000F949A4: D8D80000 31000000
	v_lshrrev_b32_e32 v0, 14, v12                              // 000000F949AC: 3200188E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F949B0: 360000FF 000003FC
	ds_load_b32 v50, v0                                        // 000000F949B8: D8D80000 32000000
	v_lshrrev_b32_e32 v0, 22, v12                              // 000000F949C0: 32001896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F949C4: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F949C8: 360000FF 000003FC
	ds_load_b32 v51, v0                                        // 000000F949D0: D8D80000 33000000
	v_and_b32_e32 v0, 0xff, v13                                // 000000F949D8: 36001AFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F949E0: 30000082
	ds_load_b32 v52, v0                                        // 000000F949E4: D8D80000 34000000
	v_lshrrev_b32_e32 v0, 6, v13                               // 000000F949EC: 32001A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F949F0: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F949F4: 360000FF 000003FC
	ds_load_b32 v53, v0                                        // 000000F949FC: D8D80000 35000000
	v_lshrrev_b32_e32 v0, 14, v13                              // 000000F94A04: 32001A8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94A08: 360000FF 000003FC
	ds_load_b32 v54, v0                                        // 000000F94A10: D8D80000 36000000
	v_lshrrev_b32_e32 v0, 22, v13                              // 000000F94A18: 32001A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F94A1C: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94A20: 360000FF 000003FC
	ds_load_b32 v55, v0                                        // 000000F94A28: D8D80000 37000000
	v_and_b32_e32 v0, 0xff, v14                                // 000000F94A30: 36001CFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F94A38: 30000082
	ds_load_b32 v56, v0                                        // 000000F94A3C: D8D80000 38000000
	v_lshrrev_b32_e32 v0, 6, v14                               // 000000F94A44: 32001C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F94A48: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94A4C: 360000FF 000003FC
	ds_load_b32 v57, v0                                        // 000000F94A54: D8D80000 39000000
	v_lshrrev_b32_e32 v0, 14, v14                              // 000000F94A5C: 32001C8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94A60: 360000FF 000003FC
	ds_load_b32 v58, v0                                        // 000000F94A68: D8D80000 3A000000
	v_lshrrev_b32_e32 v0, 22, v14                              // 000000F94A70: 32001C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F94A74: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94A78: 360000FF 000003FC
	ds_load_b32 v59, v0                                        // 000000F94A80: D8D80000 3B000000
	v_and_b32_e32 v0, 0xff, v15                                // 000000F94A88: 36001EFF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000F94A90: 30000082
	ds_load_b32 v60, v0                                        // 000000F94A94: D8D80000 3C000000
	v_lshrrev_b32_e32 v0, 6, v15                               // 000000F94A9C: 32001E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F94AA0: BF8700B1
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94AA4: 360000FF 000003FC
	ds_load_b32 v61, v0                                        // 000000F94AAC: D8D80000 3D000000
	v_lshrrev_b32_e32 v0, 14, v15                              // 000000F94AB4: 32001E8E
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94AB8: 360000FF 000003FC
	ds_load_b32 v62, v0                                        // 000000F94AC0: D8D80000 3E000000
	v_lshrrev_b32_e32 v0, 22, v15                              // 000000F94AC8: 32001E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F94ACC: BF870141
	v_and_b32_e32 v0, 0x3fc, v0                                // 000000F94AD0: 360000FF 000003FC
	ds_load_b32 v63, v0                                        // 000000F94AD8: D8D80000 3F000000
	.long 0xd73c0000                                           // 000000F94AE0: D73C0000
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000F94AE4: 02022681
	v_add_nc_u32_e32 v19, 0x400, v19                           // 000000F94AE8: 4A2626FF 00000400
	.long 0xd7006a2e                                           // 000000F94AF0: D7006A2E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000F94AF4: 02020006
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F94AF8: BF870001
	v_add_co_ci_u32_e64 v47, null, s7, v1, vcc_lo              // 000000F94AFC: D5207C2F 01AA0207
	s_clause 0x3                                               // 000000F94B04: BF850003
	global_load_b128 v[0:3], v[46:47], off                     // 000000F94B08: DC5E0000 007C002E
	global_load_b128 v[4:7], v[46:47], off offset:16           // 000000F94B10: DC5E0010 047C002E
	global_load_b128 v[12:15], v[46:47], off offset:32         // 000000F94B18: DC5E0020 0C7C002E
	global_load_b128 v[42:45], v[46:47], off offset:48         // 000000F94B20: DC5E0030 2A7C002E
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000F94B28: BF890CF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F94B2C: CC1A4000 1A026100
	s_waitcnt lgkmcnt(14)                                      // 000000F94B34: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94B38: BF8700A1
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F94B3C: CC1A4000 1C026301
	s_waitcnt lgkmcnt(13)                                      // 000000F94B44: BF89FCD7
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F94B48: CC1A4000 1C026502
	s_waitcnt lgkmcnt(12)                                      // 000000F94B50: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94B54: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F94B58: CC1A4000 1C026703
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000F94B60: BF8908B7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F94B64: CC1A4000 1C026904
	s_waitcnt lgkmcnt(10)                                      // 000000F94B6C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94B70: BF8700A1
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F94B74: CC1A4000 1C026B05
	s_waitcnt lgkmcnt(9)                                       // 000000F94B7C: BF89FC97
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F94B80: CC1A4000 1C026D06
	s_waitcnt lgkmcnt(8)                                       // 000000F94B88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94B8C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F94B90: CC1A4000 1C026F07
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000F94B98: BF890477
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F94B9C: CC1A4000 1C02710C
	s_waitcnt lgkmcnt(6)                                       // 000000F94BA4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94BA8: BF8700A1
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F94BAC: CC1A4000 1C02730D
	s_waitcnt lgkmcnt(5)                                       // 000000F94BB4: BF89FC57
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F94BB8: CC1A4000 1C02750E
	s_waitcnt lgkmcnt(4)                                       // 000000F94BC0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94BC4: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F94BC8: CC1A4000 1C02770F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000F94BD0: BF890037
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F94BD4: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F94BDC: D7006A2A
	v_cndmask_b32_e32 v0, v46, v4, vcc_lo                      // 000000F94BE0: 0200092E
	s_waitcnt lgkmcnt(2)                                       // 000000F94BE4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F94BE8: BF870132
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F94BEC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s5, v47, vcc_lo             // 000000F94BF4: D5207C2B 01AA5E05
	s_waitcnt lgkmcnt(1)                                       // 000000F94BFC: BF89FC17
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F94C00: CC1A4000 1C027D2C
	s_waitcnt lgkmcnt(0)                                       // 000000F94C08: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94C0C: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F94C10: CC1A4000 1C027F2D
	v_fmac_f32_e32 v29, v33, v0                                // 000000F94C18: 563A0121
	s_clause 0x3                                               // 000000F94C1C: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F94C20: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F94C28: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F94C30: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F94C38: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F94C40: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F94C44: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94C4C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F94C50: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F94C58: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94C60: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F94C64: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F94C6C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F94C70: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94C78: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F94C7C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F94C84: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94C8C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F94C90: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F94C98: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F94C9C: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94CA4: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F94CA8: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F94CB0: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94CB8: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F94CBC: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000F94CC4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F94CC8: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F94CD0: D7006A2A
	v_cndmask_b32_e32 v0, v46, v14, vcc_lo                     // 000000F94CD4: 02001D2E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F94CD8: BF870122
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F94CDC: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s15, v47, vcc_lo            // 000000F94CE4: D5207C2B 01AA5E0F
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F94CEC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94CF4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F94CF8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v28, v33, v0                                // 000000F94D00: 56380121
	s_clause 0x3                                               // 000000F94D04: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F94D08: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F94D10: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F94D18: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F94D20: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F94D28: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F94D2C: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94D34: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F94D38: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F94D40: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94D48: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F94D4C: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F94D54: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F94D58: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94D60: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F94D64: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F94D6C: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94D74: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F94D78: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F94D80: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F94D84: CC1A4000 1C02710C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94D8C: BF870091
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F94D90: CC1A4000 1C02730D
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F94D98: CC1A4000 1C02750E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94DA0: BF8700A1
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F94DA4: CC1A4000 1C02770F
	s_waitcnt vmcnt(0)                                         // 000000F94DAC: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F94DB0: CC1A4000 1C02792A
	.long 0xd7006a2a                                           // 000000F94DB8: D7006A2A
	v_cndmask_b32_e32 v0, v46, v17, vcc_lo                     // 000000F94DBC: 0200232E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000F94DC0: BF8701B2
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F94DC4: CC1A4000 1C027B2B
	v_add_co_ci_u32_e64 v43, null, s18, v47, vcc_lo            // 000000F94DCC: D5207C2B 01AA5E12
	.long 0xd7006a15                                           // 000000F94DD4: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 000000F94DD8: 02018115
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F94DDC: CC1A4000 1C027D2C
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000F94DE4: D5207C16 01AA2C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94DEC: BF870092
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F94DF0: CC1A4000 1C027F2D
	v_fmac_f32_e32 v27, v33, v0                                // 000000F94DF8: 56360121
	s_clause 0x3                                               // 000000F94DFC: BF850003
	global_load_b128 v[0:3], v[42:43], off                     // 000000F94E00: DC5E0000 007C002A
	global_load_b128 v[4:7], v[42:43], off offset:16           // 000000F94E08: DC5E0010 047C002A
	global_load_b128 v[12:15], v[42:43], off offset:32         // 000000F94E10: DC5E0020 0C7C002A
	global_load_b128 v[42:45], v[42:43], off offset:48         // 000000F94E18: DC5E0030 2A7C002A
	s_waitcnt vmcnt(3)                                         // 000000F94E20: BF890FF7
	v_dot2_f32_bf16 v0, v0, v48, 0                             // 000000F94E24: CC1A4000 1A026100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94E2C: BF870091
	v_dot2_f32_bf16 v0, v1, v49, v0                            // 000000F94E30: CC1A4000 1C026301
	v_dot2_f32_bf16 v0, v2, v50, v0                            // 000000F94E38: CC1A4000 1C026502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94E40: BF8700A1
	v_dot2_f32_bf16 v0, v3, v51, v0                            // 000000F94E44: CC1A4000 1C026703
	s_waitcnt vmcnt(2)                                         // 000000F94E4C: BF890BF7
	v_dot2_f32_bf16 v0, v4, v52, v0                            // 000000F94E50: CC1A4000 1C026904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94E58: BF870091
	v_dot2_f32_bf16 v0, v5, v53, v0                            // 000000F94E5C: CC1A4000 1C026B05
	v_dot2_f32_bf16 v0, v6, v54, v0                            // 000000F94E64: CC1A4000 1C026D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94E6C: BF8700A1
	v_dot2_f32_bf16 v0, v7, v55, v0                            // 000000F94E70: CC1A4000 1C026F07
	s_waitcnt vmcnt(1)                                         // 000000F94E78: BF8907F7
	v_dot2_f32_bf16 v0, v12, v56, v0                           // 000000F94E7C: CC1A4000 1C02710C
	v_mov_b32_e32 v12, v8                                      // 000000F94E84: 7E180308
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000F94E88: BF870122
	v_dot2_f32_bf16 v0, v13, v57, v0                           // 000000F94E8C: CC1A4000 1C02730D
	v_mov_b32_e32 v13, v9                                      // 000000F94E94: 7E1A0309
	v_dot2_f32_bf16 v0, v14, v58, v0                           // 000000F94E98: CC1A4000 1C02750E
	v_mov_b32_e32 v14, v10                                     // 000000F94EA0: 7E1C030A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000F94EA4: BF870132
	v_dot2_f32_bf16 v0, v15, v59, v0                           // 000000F94EA8: CC1A4000 1C02770F
	v_mov_b32_e32 v15, v11                                     // 000000F94EB0: 7E1E030B
	s_waitcnt vmcnt(0)                                         // 000000F94EB4: BF8903F7
	v_dot2_f32_bf16 v0, v42, v60, v0                           // 000000F94EB8: CC1A4000 1C02792A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94EC0: BF870091
	v_dot2_f32_bf16 v0, v43, v61, v0                           // 000000F94EC4: CC1A4000 1C027B2B
	v_dot2_f32_bf16 v0, v44, v62, v0                           // 000000F94ECC: CC1A4000 1C027D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000F94ED4: BF870091
	v_dot2_f32_bf16 v0, v45, v63, v0                           // 000000F94ED8: CC1A4000 1C027F2D
	v_fmac_f32_e32 v26, v33, v0                                // 000000F94EE0: 56340121
	v_dual_mov_b32 v0, v34 :: v_dual_mov_b32 v33, v32          // 000000F94EE4: CA100122 00200120
	v_dual_mov_b32 v1, v35 :: v_dual_mov_b32 v2, v36           // 000000F94EEC: CA100123 01020124
	v_dual_mov_b32 v3, v37 :: v_dual_mov_b32 v4, v38           // 000000F94EF4: CA100125 03040126
	v_dual_mov_b32 v5, v39 :: v_dual_mov_b32 v6, v40           // 000000F94EFC: CA100127 05060128
	v_mov_b32_e32 v7, v41                                      // 000000F94F04: 7E0E0329
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000F94F08: 917E107E
	s_cbranch_execz 28                                         // 000000F94F0C: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xb80>
	s_waitcnt vmcnt(0)                                         // 000000F94F10: BF8903F7
	v_dual_mov_b32 v8, v12 :: v_dual_add_nc_u32 v31, 32, v31   // 000000F94F14: CA20010C 081E3EA0
	v_dual_mov_b32 v9, v13 :: v_dual_mov_b32 v10, v14          // 000000F94F1C: CA10010D 090A010E
	v_mov_b32_e32 v11, v15                                     // 000000F94F24: 7E16030F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000F94F28: BF870003
	.long 0xd4430002                                           // 000000F94F2C: D4430002
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 000000F94F30: 02023E14
	s_mov_b32 s10, exec_lo                                     // 000000F94F34: BE8A007E
	.long 0xd4c4007e                                           // 000000F94F38: D4C4007E
	v_cndmask_b32_e32 v1, s20, v31, vcc_lo                     // 000000F94F3C: 02023E14
	s_cbranch_execz 65145                                      // 000000F94F40: BFA5FE79 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	.long 0xd7006a08                                           // 000000F94F44: D7006A08
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 000000F94F48: 02023D12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000F94F4C: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000F94F50: D5207C09 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 000000F94F58: 7C9A3081
	v_mov_b32_e32 v32, v33                                     // 000000F94F5C: 7E400321
	global_load_b128 v[8:11], v[8:9], off                      // 000000F94F60: DC5E0000 087C0008
	s_cbranch_vccnz 65135                                      // 000000F94F68: BFA4FE6F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	global_load_d16_b16 v32, v[21:22], off                     // 000000F94F6C: DC820000 207C0015
	s_waitcnt vmcnt(0)                                         // 000000F94F74: BF8903F7
	v_cvt_f32_f16_e32 v32, v32                                 // 000000F94F78: 7E401720
	s_branch 65130                                             // 000000F94F7C: BFA0FE6A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000F94F80: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000F94F84: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000F94F88: 8C7E037E
	.long 0xd71f0000                                           // 000000F94F8C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000F94F90: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000F94F94: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 000000F94F98: 3A0A0088
	v_xor_b32_e32 v9, 4, v0                                    // 000000F94F9C: 3A120084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F94FA0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000F94FA4: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000F94FA8: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000F94FAC: 7C980AA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F94FB0: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000F94FB4: 30020282
	ds_bpermute_b32 v4, v1, v27                                // 000000F94FB8: DACC0000 04001B01
	s_waitcnt lgkmcnt(0)                                       // 000000F94FC0: BF89FC07
	v_add_f32_e32 v4, v27, v4                                  // 000000F94FC4: 0608091B
	ds_bpermute_b32 v2, v1, v29                                // 000000F94FC8: DACC0000 02001D01
	ds_bpermute_b32 v3, v1, v28                                // 000000F94FD0: DACC0000 03001C01
	ds_bpermute_b32 v1, v1, v26                                // 000000F94FD8: DACC0000 01001A01
	s_waitcnt lgkmcnt(2)                                       // 000000F94FE0: BF89FC27
	v_dual_add_f32 v2, v29, v2 :: v_dual_cndmask_b32 v5, v0, v5// 000000F94FE4: C912051D 02040B00
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000F94FEC: 7C9812A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F94FF0: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000F94FF4: 300A0A82
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 000000F94FF8: 02121300
	ds_bpermute_b32 v8, v5, v4                                 // 000000F94FFC: DACC0000 08000405
	s_waitcnt lgkmcnt(0)                                       // 000000F95004: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_lshlrev_b32 v9, 2, v9  // 000000F95008: C9221104 04081282
	ds_bpermute_b32 v6, v5, v2                                 // 000000F95010: DACC0000 06000205
	v_add_f32_e32 v1, v26, v1                                  // 000000F95018: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 000000F9501C: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v28, v3    // 000000F95020: C9080D02 0202071C
	ds_bpermute_b32 v7, v5, v3                                 // 000000F95028: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 000000F95030: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 000000F95038: BF89FC07
	v_add_f32_e32 v1, v1, v5                                   // 000000F9503C: 06020B01
	ds_bpermute_b32 v5, v9, v2                                 // 000000F95040: DACC0000 05000209
	ds_bpermute_b32 v8, v9, v1                                 // 000000F95048: DACC0000 08000109
	s_waitcnt lgkmcnt(1)                                       // 000000F95050: BF89FC17
	v_dual_add_f32 v2, v2, v5 :: v_dual_add_f32 v3, v3, v7     // 000000F95054: C9080B02 02020F03
	ds_bpermute_b32 v7, v9, v4                                 // 000000F9505C: DACC0000 07000409
	s_waitcnt lgkmcnt(1)                                       // 000000F95064: BF89FC17
	v_add_f32_e32 v5, v1, v8                                   // 000000F95068: 060A1101
	ds_bpermute_b32 v6, v9, v3                                 // 000000F9506C: DACC0000 06000309
	v_xor_b32_e32 v9, 2, v0                                    // 000000F95074: 3A120082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000F95078: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000F9507C: 7C9812A0
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 000000F95080: 02121300
	s_waitcnt lgkmcnt(1)                                       // 000000F95084: BF89FC17
	v_dual_add_f32 v4, v4, v7 :: v_dual_lshlrev_b32 v9, 2, v9  // 000000F95088: C9220F04 04081282
	ds_bpermute_b32 v1, v9, v2                                 // 000000F95090: DACC0000 01000209
	s_waitcnt lgkmcnt(1)                                       // 000000F95098: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 000000F9509C: 06060D03
	ds_bpermute_b32 v7, v9, v4                                 // 000000F950A0: DACC0000 07000409
	ds_bpermute_b32 v8, v9, v5                                 // 000000F950A8: DACC0000 08000509
	ds_bpermute_b32 v6, v9, v3                                 // 000000F950B0: DACC0000 06000309
	v_xor_b32_e32 v9, 1, v0                                    // 000000F950B8: 3A120081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000F950BC: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000F950C0: 7C9812A0
	v_cndmask_b32_e32 v0, v0, v9, vcc_lo                       // 000000F950C4: 02001300
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000F950C8: 7C942E80
	s_waitcnt lgkmcnt(3)                                       // 000000F950CC: BF89FC37
	v_dual_add_f32 v0, v2, v1 :: v_dual_lshlrev_b32 v9, 2, v0  // 000000F950D0: C9220302 00080082
	s_waitcnt lgkmcnt(2)                                       // 000000F950D8: BF89FC27
	v_add_f32_e32 v2, v4, v7                                   // 000000F950DC: 06040F04
	s_and_b32 s0, vcc_lo, s0                                   // 000000F950E0: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 000000F950E4: BF89FC07
	v_add_f32_e32 v1, v3, v6                                   // 000000F950E8: 06020D03
	v_add_f32_e32 v3, v5, v8                                   // 000000F950EC: 06061105
	ds_bpermute_b32 v4, v9, v0                                 // 000000F950F0: DACC0000 04000009
	ds_bpermute_b32 v6, v9, v2                                 // 000000F950F8: DACC0000 06000209
	ds_bpermute_b32 v5, v9, v1                                 // 000000F95100: DACC0000 05000109
	ds_bpermute_b32 v7, v9, v3                                 // 000000F95108: DACC0000 07000309
	s_and_saveexec_b32 s1, s0                                  // 000000F95110: BE812000
	s_cbranch_execz 138                                        // 000000F95114: BFA5008A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi32ELi1ELb1ELi4ELi1EEEvPKhPKtPvlllllS6_f+0xf40>
	s_waitcnt lgkmcnt(1)                                       // 000000F95118: BF89FC17
	v_dual_add_f32 v0, v0, v4 :: v_dual_add_f32 v1, v1, v5     // 000000F9511C: C9080900 00000B01
	s_waitcnt lgkmcnt(0)                                       // 000000F95124: BF89FC07
	v_dual_add_f32 v2, v2, v6 :: v_dual_add_f32 v3, v3, v7     // 000000F95128: C9080D02 02020F03
	s_lshl_b64 s[4:5], s[12:13], 2                             // 000000F95130: 8484820C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F95134: BF870112
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000F95138: C8C600FF 000002FF BFB8AA3B
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 000000F95144: C8C604FF 020206FF BFB8AA3B
	s_lshl_b64 s[6:7], s[12:13], 3                             // 000000F95150: 8486830C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000F95154: BF870112
	v_exp_f32_e32 v0, v0                                       // 000000F95158: 7E004B00
	v_exp_f32_e32 v1, v1                                       // 000000F9515C: 7E024B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000F95160: BF8703A1
	v_exp_f32_e32 v2, v2                                       // 000000F95164: 7E044B02
	v_exp_f32_e32 v3, v3                                       // 000000F95168: 7E064B03
	v_dual_add_f32 v7, 1.0, v0 :: v_dual_add_f32 v8, 1.0, v1   // 000000F9516C: C90800F2 070802F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F95174: BF8701A5
	v_dual_add_f32 v9, 1.0, v2 :: v_dual_add_f32 v10, 1.0, v3  // 000000F95178: C90804F2 090A06F2
	.long 0xd73c0000                                           // 000000F95180: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000F95184: 02022082
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000F95188: D6FC7C0B 03CA0F07
	s_waitcnt vmcnt(0)                                         // 000000F95190: BF8903F7
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000F95194: D6FC7C0C 03CA1108
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000F9519C: D6FC7C0D 03CA1309
	v_div_scale_f32 v14, null, v10, v10, 1.0                   // 000000F951A4: D6FC7C0E 03CA150A
	v_div_scale_f32 v16, vcc_lo, 1.0, v7, 1.0                  // 000000F951AC: D6FC6A10 03CA0EF2
	v_rcp_f32_e32 v15, v11                                     // 000000F951B4: 7E1E550B
	v_rcp_f32_e32 v18, v12                                     // 000000F951B8: 7E24550C
	v_rcp_f32_e32 v19, v13                                     // 000000F951BC: 7E26550D
	v_rcp_f32_e32 v20, v14                                     // 000000F951C0: 7E28550E
	v_div_scale_f32 v17, s0, 1.0, v8, 1.0                      // 000000F951C4: D6FC0011 03CA10F2
	v_div_scale_f32 v21, s1, 1.0, v9, 1.0                      // 000000F951CC: D6FC0115 03CA12F2
	v_div_scale_f32 v22, s2, 1.0, v10, 1.0                     // 000000F951D4: D6FC0216 03CA14F2
	v_fma_f32 v2, -v11, v15, 1.0                               // 000000F951DC: D6130002 23CA1F0B
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000F951E4: BF870317
	v_fma_f32 v3, -v12, v18, 1.0                               // 000000F951E8: D6130003 23CA250C
	v_fma_f32 v4, -v13, v19, 1.0                               // 000000F951F0: D6130004 23CA270D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F951F8: BF870195
	v_fma_f32 v5, -v14, v20, 1.0                               // 000000F951FC: D6130005 23CA290E
	v_dual_fmac_f32 v15, v2, v15 :: v_dual_fmac_f32 v18, v3, v18// 000000F95204: C8001F02 0F122503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000F9520C: BF8701A2
	v_dual_fmac_f32 v19, v4, v19 :: v_dual_fmac_f32 v20, v5, v20// 000000F95210: C8002704 13142905
	.long 0xd7000303                                           // 000000F95218: D7000303
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000F9521C: 02020008
	v_dual_mul_f32 v23, v16, v15 :: v_dual_mul_f32 v24, v17, v18// 000000F95220: C8C61F10 17182511
	v_add_co_ci_u32_e64 v4, null, s9, v1, s3                   // 000000F95228: D5207C04 000E0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000F95230: BF870194
	v_dual_mul_f32 v25, v21, v19 :: v_dual_mul_f32 v26, v22, v20// 000000F95234: C8C62715 191A2916
	v_fma_f32 v2, -v11, v23, v16                               // 000000F9523C: D6130002 24422F0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000F95244: BF870223
	v_mad_u64_u32 v[0:1], null, s12, 12, v[3:4]                // 000000F95248: D6FE7C00 040D180C
	v_fma_f32 v27, -v12, v24, v17                              // 000000F95250: D613001B 2446310C
	v_fma_f32 v28, -v13, v25, v21                              // 000000F95258: D613001C 2456330D
	v_fma_f32 v29, -v14, v26, v22                              // 000000F95260: D613001D 245A350E
	v_fmac_f32_e32 v23, v2, v15                                // 000000F95268: 562E1F02
	.long 0xd7000305                                           // 000000F9526C: D7000305
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 000000F95270: 02000903
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000F95274: BF870214
	v_dual_fmac_f32 v24, v27, v18 :: v_dual_fmac_f32 v25, v28, v19// 000000F95278: C800251B 1818271C
	v_fmac_f32_e32 v26, v29, v20                               // 000000F95280: 5634291D
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000F95284: D6FE7C01 0405180D
	v_fma_f32 v2, -v11, v23, v16                               // 000000F9528C: D6130002 24422F0B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F95294: BF870004
	v_fma_f32 v11, -v12, v24, v17                              // 000000F95298: D613000B 2446310C
	v_fma_f32 v12, -v13, v25, v21                              // 000000F952A0: D613000C 2456330D
	v_fma_f32 v13, -v14, v26, v22                              // 000000F952A8: D613000D 245A350E
	v_add_co_ci_u32_e64 v6, null, s5, v4, s3                   // 000000F952B0: D5207C06 000E0805
	v_div_fmas_f32 v2, v2, v15, v23                            // 000000F952B8: D6370002 045E1F02
	s_mov_b32 vcc_lo, s0                                       // 000000F952C0: BEEA0000
	v_div_fmas_f32 v11, v11, v18, v24                          // 000000F952C4: D637000B 0462250B
	s_mov_b32 vcc_lo, s1                                       // 000000F952CC: BEEA0001
	s_delay_alu instid0(VALU_DEP_2)                            // 000000F952D0: BF870002
	v_div_fixup_f32 v2, v2, v7, 1.0                            // 000000F952D4: D6270002 03CA0F02
	v_div_fmas_f32 v12, v12, v19, v25                          // 000000F952DC: D637000C 0466270C
	s_mov_b32 vcc_lo, s2                                       // 000000F952E4: BEEA0002
	v_div_fixup_f32 v11, v11, v8, 1.0                          // 000000F952E8: D627000B 03CA110B
	v_div_fmas_f32 v13, v13, v20, v26                          // 000000F952F0: D637000D 046A290D
	.long 0xd7006a07                                           // 000000F952F8: D7006A07
	v_cndmask_b32_e32 v0, v3, v6, vcc_lo                       // 000000F952FC: 02000D03
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 000000F95300: D6270009 03CA130C
	v_add_co_ci_u32_e64 v8, null, s7, v4, vcc_lo               // 000000F95308: D5207C08 01AA0807
	s_delay_alu instid0(VALU_DEP_4)                            // 000000F95310: BF870004
	v_div_fixup_f32 v10, v13, v10, 1.0                         // 000000F95314: D627000A 03CA150D
	s_clause 0x3                                               // 000000F9531C: BF850003
	global_store_b32 v[3:4], v2, off                           // 000000F95320: DC6A0000 007C0203
	global_store_b32 v[5:6], v11, off                          // 000000F95328: DC6A0000 007C0B05
	global_store_b32 v[7:8], v9, off                           // 000000F95330: DC6A0000 007C0907
	global_store_b32 v[0:1], v10, off                          // 000000F95338: DC6A0000 007C0A00
	s_endpgm                                                   // 000000F95340: BFB00000
		...

