00000000007ec800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007EC800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007EC808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007EC80C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007EC810: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000007EC814: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 0000007EC818: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 0000007EC81C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000007EC824: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 0000007EC828: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007EC82C: 30020282
	.long 0x7f0a3880                                           // 0000007EC830: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000007EC834: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007EC838: BF89FC07
	s_clause 0x1                                               // 0000007EC83C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007EC840: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007EC848: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000007EC850: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000007EC854: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000007EC858: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000007EC85C: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000007EC860: 85109B10
	v_or_b32_e32 v1, s20, v28                                  // 0000007EC864: 38023814
	s_add_u32 s16, s10, s16                                    // 0000007EC868: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007EC86C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EC870: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007EC874: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007EC878: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007EC87C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007EC880: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000007EC884: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000007EC888: 81111611
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000007EC88C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 0000007EC890: 86118111
	v_cndmask_b32_e64 v2, 0, s21, vcc_lo                       // 0000007EC894: D5010002 01A82A80
	.long 0xd72c0007                                           // 0000007EC89C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 0000007EC8A0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007EC8A4: B3900201
	.long 0xd72c0009                                           // 0000007EC8A8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000007EC8AC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[2:3]              // 0000007EC8B0: D6FE7C18 000A0212
	s_cselect_b32 s2, -1, 0                                    // 0000007EC8B8: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007EC8BC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 0000007EC8C0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 0000007EC8C4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007EC8C8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 0000007EC8CC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 0000007EC8D0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007EC8D4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007EC8D8: BF870151
	.long 0xd4410003                                           // 0000007EC8DC: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007EC8E0: 0202411F
	s_waitcnt vmcnt(1)                                         // 0000007EC8E4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 0000007EC8E8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 0000007EC8F0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000007EC8F4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000007EC8FC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 0000007EC908: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 0000007EC90C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EC910: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000007EC914: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 0000007EC920: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EC924: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 0000007EC928: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 0000007EC930: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 0000007EC93C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 0000007EC944: BF89FC07
	s_barrier                                                  // 0000007EC948: BFBD0000
	buffer_gl0_inv                                             // 0000007EC94C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007EC954: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000007EC958: CA100080 09080080
	s_and_saveexec_b32 s17, s3                                 // 0000007EC960: BE912003
	s_cbranch_execz 11                                         // 0000007EC964: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 0000007EC968: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EC96C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007EC970: 3408069F
	.long 0xd7006a03                                           // 0000007EC974: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007EC978: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007EC97C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007EC984: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007EC98C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 0000007EC990: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007EC994: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 0000007EC998: 4A063EA0
	s_mov_b32 s3, exec_lo                                      // 0000007EC99C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EC9A0: BF870001
	.long 0xd4c1007e                                           // 0000007EC9A4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007EC9A8: 02024103
	s_cbranch_execz 11                                         // 0000007EC9AC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007EC9B0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007EC9B4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007EC9B8: 3408069F
	.long 0xd7006a03                                           // 0000007EC9BC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007EC9C0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007EC9C4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007EC9CC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007EC9D4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 0000007EC9D8: 7E121703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007EC9DC: 8C7E037E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 0000007EC9E0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 0000007EC9E8: 7E160280
	s_mov_b32 s3, exec_lo                                      // 0000007EC9EC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007EC9F0: BF870002
	.long 0xd4c1007e                                           // 0000007EC9F4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007EC9F8: 02024103
	s_cbranch_execz 11                                         // 0000007EC9FC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECA00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECA04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECA08: 3408069F
	.long 0xd7006a03                                           // 0000007ECA0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECA10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECA14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECA1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECA24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 0000007ECA28: 7E141703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECA2C: 8C7E037E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 0000007ECA30: 4A063EFF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000007ECA38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ECA3C: BF870001
	.long 0xd4c1007e                                           // 0000007ECA40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007ECA44: 02024103
	s_cbranch_execz 11                                         // 0000007ECA48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECA4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECA50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECA54: 3408069F
	.long 0xd7006a03                                           // 0000007ECA58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECA5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECA60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECA68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECA70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 0000007ECA74: 7E161703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECA78: 8C7E037E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 0000007ECA7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000007ECA88: 7E1A0280
	s_mov_b32 s3, exec_lo                                      // 0000007ECA8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007ECA90: BF870002
	.long 0xd4c1007e                                           // 0000007ECA94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007ECA98: 02024103
	s_cbranch_execz 11                                         // 0000007ECA9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECAA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECAA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECAA8: 3408069F
	.long 0xd7006a03                                           // 0000007ECAAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECAB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECAB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECABC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECAC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 0000007ECAC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECACC: 8C7E037E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 0000007ECAD0: 4A063EFF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000007ECAD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ECADC: BF870001
	.long 0xd4c1007e                                           // 0000007ECAE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007ECAE4: 02024103
	s_cbranch_execz 11                                         // 0000007ECAE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECAEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECAF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECAF4: 3408069F
	.long 0xd7006a03                                           // 0000007ECAF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECAFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECB00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECB08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECB10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 0000007ECB14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECB18: 8C7E037E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 0000007ECB1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000007ECB28: 7E1E0280
	s_mov_b32 s3, exec_lo                                      // 0000007ECB2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007ECB30: BF870002
	.long 0xd4c1007e                                           // 0000007ECB34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007ECB38: 02024103
	s_cbranch_execz 11                                         // 0000007ECB3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECB40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECB44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECB48: 3408069F
	.long 0xd7006a03                                           // 0000007ECB4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECB50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECB54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECB5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECB64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 0000007ECB68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECB6C: 8C7E037E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 0000007ECB70: 4A063EFF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000007ECB78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ECB7C: BF870001
	.long 0xd4c1007e                                           // 0000007ECB80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007ECB84: 02024103
	s_cbranch_execz 11                                         // 0000007ECB88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007ECB8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECB90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007ECB94: 3408069F
	.long 0xd7006a03                                           // 0000007ECB98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007ECB9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007ECBA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007ECBA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007ECBB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 0000007ECBB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007ECBB8: 8C7E037E
	s_branch 9                                                 // 0000007ECBBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 0000007ECBC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ECBC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000007ECBC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000007ECBCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000007ECBD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000007ECBD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000007ECBD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000007ECBDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000007ECBE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 0000007ECBE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007ECBE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000007ECBEC: 85039F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 0000007ECBF0: CA100080 141A0080
	s_add_u32 s14, s10, s3                                     // 0000007ECBF8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 0000007ECBFC: 820F800B
	.long 0xd4410003                                           // 0000007ECC00: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007ECC04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007ECC08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 0000007ECC0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 0000007ECC14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 0000007ECC1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000007ECC20: 02001F01
	.long 0xd72c0002                                           // 0000007ECC24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000007ECC28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 0000007ECC2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000007ECC34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007ECC3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 0000007ECC40: D6550024 04063502
	s_and_saveexec_b32 s4, s3                                  // 0000007ECC48: BE842003
	s_cbranch_execz 22                                         // 0000007ECC4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000007ECC50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000007ECC54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECC58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007ECC5C: 3404029F
	.long 0xd7006a01                                           // 0000007ECC60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000007ECC64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007ECC68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007ECC70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 0000007ECC74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000007ECC7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000007ECC80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ECC84: BF870091
	.long 0xd7006a01                                           // 0000007ECC88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007ECC8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000007ECC90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000007ECC98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007ECCA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000007ECCA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007ECCA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007ECCAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000007ECCB4: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 0000007ECCBC: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 0000007ECCC4: 7E4A0280
	s_and_saveexec_b32 s14, s3                                 // 0000007ECCC8: BE8E2003
	s_cbranch_execz 666                                        // 0000007ECCCC: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf38>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000007ECCD0: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000007ECCD8: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 0000007ECCE0: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007ECCE8: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 0000007ECCEC: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 0000007ECCF4: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 0000007ECCFC: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 0000007ECD04: 7E5C031B
	s_mul_i32 s3, s11, 6                                       // 0000007ECD08: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000007ECD0C: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007ECD10: 8484820A
	s_add_i32 s15, s15, s3                                     // 0000007ECD14: 810F030F
	s_mul_i32 s17, s10, 6                                      // 0000007ECD18: 9611860A
	s_mov_b32 s16, 0                                           // 0000007ECD1C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007ECD20: 848A810A
	s_branch 608                                               // 0000007ECD24: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xea8>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007ECD28: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s2                         // 0000007ECD2C: D501002F 000A111B
	v_cndmask_b32_e64 v4, v11, v12, s2                         // 0000007ECD34: D5010004 000A190B
	v_cndmask_b32_e64 v3, v10, v11, s2                         // 0000007ECD3C: D5010003 000A170A
	v_cndmask_b32_e64 v2, v9, v10, s2                          // 0000007ECD44: D5010002 000A1509
	v_cndmask_b32_e64 v1, v8, v9, s2                           // 0000007ECD4C: D5010001 000A1308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000007ECD54: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 0000007ECD60: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 0000007ECD64: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s2                         // 0000007ECD68: D5010007 000A1F0E
	v_cndmask_b32_e64 v6, v13, v14, s2                         // 0000007ECD70: D5010006 000A1D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007ECD78: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007ECD7C: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECD84: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s2                         // 0000007ECD8C: D5010005 000A1B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000007ECD94: 3436349F
	ds_load_b32 v9, v9                                         // 0000007ECD98: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 0000007ECDA0: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 0000007ECDA8: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 0000007ECDB0: 32162896
	s_and_b32 s3, exec_lo, s3                                  // 0000007ECDB4: 8B03037E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 0000007ECDB8: 4A5858FF 00000200
	s_or_b32 s16, s3, s16                                      // 0000007ECDC0: 8C101003
	v_add_nc_u32_e32 v45, 64, v45                              // 0000007ECDC4: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECDC8: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 0000007ECDD0: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 0000007ECDD8: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECDE0: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007ECDE4: 30161682
	ds_load_b32 v61, v11                                       // 0000007ECDE8: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 0000007ECDF0: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECDF4: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 0000007ECDFC: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 0000007ECE04: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECE08: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECE0C: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 0000007ECE14: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 0000007ECE1C: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECE20: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 0000007ECE28: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 0000007ECE30: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECE38: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007ECE3C: 30161682
	ds_load_b32 v65, v11                                       // 0000007ECE40: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 0000007ECE48: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECE4C: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 0000007ECE54: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 0000007ECE5C: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECE60: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECE64: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 0000007ECE6C: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 0000007ECE74: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECE78: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 0000007ECE80: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 0000007ECE88: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECE90: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007ECE94: 30161682
	ds_load_b32 v69, v11                                       // 0000007ECE98: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 0000007ECEA0: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECEA4: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 0000007ECEAC: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 0000007ECEB4: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ECEB8: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECEBC: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 0000007ECEC4: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 0000007ECECC: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007ECED0: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 0000007ECED8: D8D80000 4800000B
	.long 0xd73c000b                                           // 0000007ECEE0: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007ECEE4: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000007ECEE8: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ECEF4: BF870092
	.long 0xd7006a38                                           // 0000007ECEF8: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000007ECEFC: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 0000007ECF00: D5207C39 01AA1807
	s_clause 0x3                                               // 0000007ECF08: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007ECF0C: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007ECF14: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007ECF1C: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007ECF24: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007ECF2C: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ECF30: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 0000007ECF38: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECF3C: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ECF40: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 0000007ECF48: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ECF4C: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 0000007ECF54: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECF58: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ECF5C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007ECF64: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ECF68: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 0000007ECF70: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECF74: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ECF78: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 0000007ECF80: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ECF84: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 0000007ECF8C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECF90: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ECF94: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007ECF9C: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ECFA0: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 0000007ECFA8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECFAC: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ECFB0: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 0000007ECFB8: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ECFBC: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 0000007ECFC4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ECFC8: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ECFCC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007ECFD4: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ECFD8: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007ECFE0: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 0000007ECFE4: 02001538
	s_waitcnt lgkmcnt(2)                                       // 0000007ECFE8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007ECFEC: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ECFF0: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 0000007ECFF8: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 0000007ED000: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000007ED004: 02000938
	s_waitcnt lgkmcnt(1)                                       // 0000007ED008: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED00C: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 0000007ED014: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 0000007ED01C: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 0000007ED020: 02002338
	s_waitcnt lgkmcnt(0)                                       // 0000007ED024: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007ED028: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED02C: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 0000007ED034: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 0000007ED03C: 564A172F
	s_clause 0x3                                               // 0000007ED040: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007ED044: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007ED04C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007ED054: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007ED05C: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007ED064: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED068: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED070: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED074: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED07C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED084: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED088: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED090: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED094: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED09C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED0A0: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED0A8: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED0B0: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED0B4: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED0BC: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED0C0: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED0C8: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED0CC: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED0D4: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED0DC: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED0E0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED0E8: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED0EC: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED0F4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED0F8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED100: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED108: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED10C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 0000007ED114: 5656172F
	s_clause 0x3                                               // 0000007ED118: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000007ED11C: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000007ED124: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000007ED12C: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000007ED134: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 0000007ED13C: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 0000007ED140: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ED144: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 0000007ED148: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 0000007ED150: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED154: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED15C: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED164: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED168: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED170: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED178: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED17C: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED180: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED188: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED190: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED194: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED19C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED1A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED1A8: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED1AC: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED1B4: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED1BC: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED1C0: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED1C8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED1D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED1D4: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED1D8: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED1E0: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED1E8: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED1EC: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED1F4: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ED1FC: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 0000007ED200: 5654172F
	s_clause 0x3                                               // 0000007ED204: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007ED208: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007ED210: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007ED218: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007ED220: DC5E0030 347C0038
	.long 0xd7006a38                                           // 0000007ED228: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000007ED22C: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ED230: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 0000007ED234: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 0000007ED23C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED240: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED248: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED250: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED254: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED25C: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED264: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED268: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED26C: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED274: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED27C: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED280: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED288: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED290: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED294: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED298: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED2A0: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED2A8: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED2AC: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED2B4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED2BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED2C0: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED2C4: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED2CC: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED2D4: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED2D8: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED2E0: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ED2E8: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000007ED2EC: 5652172F
	s_clause 0x3                                               // 0000007ED2F0: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000007ED2F4: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000007ED2FC: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000007ED304: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 0000007ED30C: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 0000007ED314: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED318: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED320: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED324: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED32C: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED334: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED338: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED340: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED344: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED34C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED350: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED358: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED360: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED364: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED36C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED370: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED378: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED37C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED384: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED38C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED390: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED398: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED39C: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED3A4: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED3A8: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED3B0: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED3B8: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED3BC: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000007ED3C4: 5650172F
	s_clause 0x3                                               // 0000007ED3C8: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000007ED3CC: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000007ED3D4: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007ED3DC: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000007ED3E4: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000007ED3EC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED3F0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED3F8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED3FC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED404: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED40C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED410: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED418: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED41C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED424: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED428: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED430: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED438: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED43C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED444: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED448: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED450: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED454: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED45C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED464: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED468: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED470: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED474: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007ED47C: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 0000007ED480: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007ED484: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED488: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 0000007ED490: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED498: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED4A0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED4A4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000007ED4AC: 564E172F
	s_clause 0x3                                               // 0000007ED4B0: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007ED4B4: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007ED4BC: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007ED4C4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007ED4CC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007ED4D4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000007ED4D8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED4E0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000007ED4E4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000007ED4EC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED4F4: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000007ED4F8: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000007ED500: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000007ED504: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED50C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 0000007ED510: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000007ED518: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED520: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000007ED524: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000007ED52C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000007ED530: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED538: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000007ED53C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000007ED544: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED54C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000007ED550: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000007ED558: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000007ED55C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 0000007ED564: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000007ED568: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007ED56C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000007ED570: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 0000007ED578: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000007ED580: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED588: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000007ED58C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 0000007ED594: 564C172F
	s_clause 0x3                                               // 0000007ED598: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000007ED59C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000007ED5A4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000007ED5AC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000007ED5B4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000007ED5BC: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 0000007ED5C0: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED5C8: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 0000007ED5CC: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 0000007ED5D4: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED5DC: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 0000007ED5E0: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 0000007ED5E8: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 0000007ED5EC: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 0000007ED5F4: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007ED5F8: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 0000007ED5FC: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 0000007ED604: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 0000007ED608: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 0000007ED610: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007ED614: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 0000007ED618: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 0000007ED620: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000007ED624: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 0000007ED628: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED630: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 0000007ED634: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 0000007ED63C: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED644: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 0000007ED648: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 0000007ED650: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 0000007ED654: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED65C: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 0000007ED660: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 0000007ED668: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007ED670: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 0000007ED674: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 0000007ED67C: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000007ED684: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007ED68C: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007ED694: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000007ED69C: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007ED6A0: 917E107E
	s_cbranch_execz 35                                         // 0000007ED6A4: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xf34>
	s_waitcnt vmcnt(0)                                         // 0000007ED6A8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000007ED6AC: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000007ED6B4: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000007ED6BC: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007ED6C0: BF870003
	.long 0xd4460003                                           // 0000007ED6C4: D4460003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007ED6C8: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000007ED6CC: BE92007E
	.long 0xd4c1007e                                           // 0000007ED6D0: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007ED6D4: 0202411F
	s_cbranch_execz 64915                                      // 0000007ED6D8: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000007ED6DC: 3404589F
	.long 0xd7006a01                                           // 0000007ED6E0: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 0000007ED6E4: 02025919
	v_mov_b32_e32 v46, v27                                     // 0000007ED6E8: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007ED6EC: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007ED6F0: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000007ED6F8: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000007ED6FC: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 0000007ED704: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	v_ashrrev_i32_e32 v2, 31, v45                              // 0000007ED708: 34045A9F
	.long 0xd7006a01                                           // 0000007ED70C: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 0000007ED710: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007ED714: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007ED718: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007ED720: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007ED728: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 0000007ED72C: 7E5C1701
	s_branch 64893                                             // 0000007ED730: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x528>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007ED734: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ED738: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007ED73C: 8C7E0E7E
	.long 0xd71f0001                                           // 0000007ED740: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007ED744: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007ED748: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007ED74C: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 0000007ED750: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 0000007ED754: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007ED758: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007ED75C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007ED760: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007ED764: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007ED768: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007ED76C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000007ED770: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000007ED778: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000007ED77C: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 0000007ED780: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 0000007ED788: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 0000007ED790: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000007ED798: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 0000007ED79C: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 0000007ED7A4: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 0000007ED7AC: DACC0000 08002702
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007ED7B4: 7C9824A0
	ds_bpermute_b32 v2, v2, v34                                // 0000007ED7B8: DACC0000 02002202
	s_waitcnt lgkmcnt(6)                                       // 0000007ED7C0: BF89FC67
	v_dual_cndmask_b32 v18, v1, v18 :: v_dual_add_f32 v5, v42, v5// 0000007ED7C4: CA482501 12040B2A
	s_waitcnt lgkmcnt(5)                                       // 0000007ED7CC: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007ED7D0: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000007ED7D8: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 0000007ED7DC: 06121326
	ds_bpermute_b32 v13, v10, v5                               // 0000007ED7E0: DACC0000 0D00050A
	s_waitcnt lgkmcnt(4)                                       // 0000007ED7E8: BF89FC47
	v_add_f32_e32 v4, v43, v4                                  // 0000007ED7EC: 0608092B
	ds_bpermute_b32 v11, v10, v3                               // 0000007ED7F0: DACC0000 0B00030A
	ds_bpermute_b32 v17, v10, v9                               // 0000007ED7F8: DACC0000 1100090A
	s_waitcnt lgkmcnt(5)                                       // 0000007ED800: BF89FC57
	v_add_f32_e32 v6, v41, v6                                  // 0000007ED804: 060C0D29
	s_waitcnt lgkmcnt(4)                                       // 0000007ED808: BF89FC47
	v_add_f32_e32 v8, v39, v8                                  // 0000007ED80C: 06101127
	ds_bpermute_b32 v15, v10, v7                               // 0000007ED810: DACC0000 0F00070A
	s_waitcnt lgkmcnt(3)                                       // 0000007ED818: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v5, v5, v13   // 0000007ED81C: C9080522 02041B05
	ds_bpermute_b32 v12, v10, v4                               // 0000007ED824: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 0000007ED82C: BF89FC37
	v_dual_add_f32 v3, v3, v11 :: v_dual_lshlrev_b32 v18, 2, v18// 0000007ED830: C9221703 03122482
	ds_bpermute_b32 v14, v10, v6                               // 0000007ED838: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 0000007ED840: BF89FC37
	v_add_f32_e32 v9, v9, v17                                  // 0000007ED844: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 0000007ED848: DACC0000 1000080A
	s_waitcnt lgkmcnt(3)                                       // 0000007ED850: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 0000007ED854: 060E1F07
	ds_bpermute_b32 v10, v10, v2                               // 0000007ED858: DACC0000 0A00020A
	s_waitcnt lgkmcnt(3)                                       // 0000007ED860: BF89FC37
	v_add_f32_e32 v4, v4, v12                                  // 0000007ED864: 06081904
	ds_bpermute_b32 v12, v18, v5                               // 0000007ED868: DACC0000 0C000512
	s_waitcnt lgkmcnt(2)                                       // 0000007ED870: BF89FC27
	v_add_f32_e32 v8, v8, v16                                  // 0000007ED874: 06102108
	s_waitcnt lgkmcnt(0)                                       // 0000007ED878: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 0000007ED87C: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 0000007ED880: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 0000007ED888: 060C1D06
	ds_bpermute_b32 v14, v18, v7                               // 0000007ED88C: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 0000007ED894: BF89FC17
	v_add_f32_e32 v9, v9, v16                                  // 0000007ED898: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 0000007ED89C: DACC0000 0D000612
	s_waitcnt lgkmcnt(1)                                       // 0000007ED8A4: BF89FC17
	v_add_f32_e32 v7, v7, v14                                  // 0000007ED8A8: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 0000007ED8AC: DACC0000 0F000812
	s_waitcnt lgkmcnt(0)                                       // 0000007ED8B4: BF89FC07
	v_add_f32_e32 v8, v8, v15                                  // 0000007ED8B8: 06101F08
	v_add_f32_e32 v2, v2, v10                                  // 0000007ED8BC: 06041502
	ds_bpermute_b32 v10, v18, v3                               // 0000007ED8C0: DACC0000 0A000312
	ds_bpermute_b32 v17, v18, v2                               // 0000007ED8C8: DACC0000 11000212
	s_waitcnt lgkmcnt(1)                                       // 0000007ED8D0: BF89FC17
	v_add_f32_e32 v3, v3, v10                                  // 0000007ED8D4: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 0000007ED8D8: DACC0000 0B000412
	v_xor_b32_e32 v18, 2, v1                                   // 0000007ED8E0: 3A240282
	s_waitcnt lgkmcnt(1)                                       // 0000007ED8E4: BF89FC17
	v_add_f32_e32 v10, v2, v17                                 // 0000007ED8E8: 06142302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007ED8EC: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007ED8F0: 7C9824A0
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000007ED8F4: 02242501
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007ED8F8: 30242482
	s_waitcnt lgkmcnt(0)                                       // 0000007ED8FC: BF89FC07
	v_add_f32_e32 v4, v4, v11                                  // 0000007ED900: 06081704
	ds_bpermute_b32 v2, v18, v3                                // 0000007ED904: DACC0000 02000312
	v_add_f32_e32 v6, v6, v13                                  // 0000007ED90C: 060C1B06
	ds_bpermute_b32 v12, v18, v5                               // 0000007ED910: DACC0000 0C000512
	ds_bpermute_b32 v14, v18, v7                               // 0000007ED918: DACC0000 0E000712
	ds_bpermute_b32 v11, v18, v4                               // 0000007ED920: DACC0000 0B000412
	ds_bpermute_b32 v15, v18, v8                               // 0000007ED928: DACC0000 0F000812
	ds_bpermute_b32 v13, v18, v6                               // 0000007ED930: DACC0000 0D000612
	ds_bpermute_b32 v16, v18, v9                               // 0000007ED938: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v10                              // 0000007ED940: DACC0000 11000A12
	v_xor_b32_e32 v18, 1, v1                                   // 0000007ED948: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007ED94C: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000007ED950: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 0000007ED954: 02022501
	s_waitcnt lgkmcnt(7)                                       // 0000007ED958: BF89FC77
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 0000007ED95C: C9220503 01120282
	s_waitcnt lgkmcnt(4)                                       // 0000007ED964: BF89FC47
	v_add_f32_e32 v2, v4, v11                                  // 0000007ED968: 06041704
	s_waitcnt lgkmcnt(2)                                       // 0000007ED96C: BF89FC27
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 0000007ED970: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 0000007ED978: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 0000007ED97C: BF89FC17
	v_dual_add_f32 v11, v8, v15 :: v_dual_add_f32 v12, v9, v16 // 0000007ED980: C9081F08 0B0C2109
	s_waitcnt lgkmcnt(0)                                       // 0000007ED988: BF89FC07
	v_add_f32_e32 v13, v10, v17                                // 0000007ED98C: 061A230A
	ds_bpermute_b32 v6, v18, v1                                // 0000007ED990: DACC0000 06000112
	ds_bpermute_b32 v7, v18, v2                                // 0000007ED998: DACC0000 07000212
	ds_bpermute_b32 v9, v18, v4                                // 0000007ED9A0: DACC0000 09000412
	ds_bpermute_b32 v10, v18, v5                               // 0000007ED9A8: DACC0000 0A000512
	ds_bpermute_b32 v8, v18, v3                                // 0000007ED9B0: DACC0000 08000312
	ds_bpermute_b32 v14, v18, v11                              // 0000007ED9B8: DACC0000 0E000B12
	ds_bpermute_b32 v15, v18, v12                              // 0000007ED9C0: DACC0000 0F000C12
	ds_bpermute_b32 v16, v18, v13                              // 0000007ED9C8: DACC0000 10000D12
	v_cmpx_eq_u32_e32 0, v30                                   // 0000007ED9D0: 7D943C80
	s_cbranch_execz 17                                         // 0000007ED9D4: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 0000007ED9D8: BF89FC27
	v_dual_add_f32 v11, v11, v14 :: v_dual_lshlrev_b32 v18, 5, v29// 0000007ED9DC: C9221D0B 0B123A85
	s_waitcnt lgkmcnt(0)                                       // 0000007ED9E4: BF89FC07
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v15// 0000007ED9E8: C908210D 0D0C1F0C
	v_dual_add_f32 v17, v5, v10 :: v_dual_add_f32 v16, v4, v9  // 0000007ED9F0: C9081505 11101304
	v_dual_add_f32 v15, v2, v7 :: v_dual_add_f32 v14, v1, v6   // 0000007ED9F8: C9080F02 0F0E0D01
	v_lshl_or_b32 v1, v28, 6, v18                              // 0000007EDA00: D6560001 04490D1C
	v_add_f32_e32 v10, v3, v8                                  // 0000007EDA08: 06141103
	ds_store_b128 v1, v[14:17] offset:1024                     // 0000007EDA0C: DB7C0400 00000E01
	ds_store_b128 v1, v[10:13] offset:1040                     // 0000007EDA14: DB7C0410 00000A01
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007EDA1C: 8C7E027E
	v_lshrrev_b32_e32 v3, 3, v0                                // 0000007EDA20: 32060083
	v_mov_b32_e32 v2, s21                                      // 0000007EDA24: 7E040215
	.long 0xd44c0002                                           // 0000007EDA28: D44C0002
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 0000007EDA2C: 020200A0
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007EDA30: BF890007
	s_barrier                                                  // 0000007EDA34: BFBD0000
	v_or_b32_e32 v1, s20, v3                                   // 0000007EDA38: 38020614
	buffer_gl0_inv                                             // 0000007EDA3C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007EDA44: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007EDA48: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007EDA4C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007EDA50: BE832002
	s_cbranch_execz 80                                         // 0000007EDA54: BFA50050 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1398>
	v_and_b32_e32 v0, 7, v0                                    // 0000007EDA58: 36000087
	s_load_b32 s0, s[0:1], 0x48                                // 0000007EDA5C: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDA64: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 0000007EDA68: 30080082
	v_lshl_or_b32 v3, v3, 6, v4                                // 0000007EDA6C: D6560003 04110D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007EDA74: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007EDA78: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:8                     // 0000007EDA80: D8DC0800 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007EDA88: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007EDA8C: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 0000007EDA90: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDA94: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007EDA98: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007EDAA0: D6550003 03FE0903 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDAAC: BF870091
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007EDAB0: 360606FF FFFF0000
	v_mul_f32_e32 v6, s0, v3                                   // 0000007EDAB8: 100C0600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDABC: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 0000007EDAC0: 10060CFF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 0000007EDAC8: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDACC: BF870095
	v_add_f32_e32 v7, 1.0, v3                                  // 0000007EDAD0: 060E06F2
	v_div_scale_f32 v5, null, v7, v7, v6                       // 0000007EDAD4: D6FC7C05 041A0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007EDADC: BF870291
	v_rcp_f32_e32 v8, v5                                       // 0000007EDAE0: 7E105505
	v_fma_f32 v3, -v5, v8, 1.0                                 // 0000007EDAE4: D6130003 23CA1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007EDAEC: BF870131
	v_fmac_f32_e32 v8, v3, v8                                  // 0000007EDAF0: 56101103
	v_div_scale_f32 v9, vcc_lo, v6, v7, v6                     // 0000007EDAF4: D6FC6A09 041A0F06
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000007EDAFC: D6FE7C03 0202000C
	v_mul_f32_e32 v10, v9, v8                                  // 0000007EDB04: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EDB08: BF870091
	v_fma_f32 v11, -v5, v10, v9                                // 0000007EDB0C: D613000B 24261505
	v_fmac_f32_e32 v10, v11, v8                                // 0000007EDB14: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EDB18: BF870121
	v_fma_f32 v9, -v5, v10, v9                                 // 0000007EDB1C: D6130009 24261505
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000007EDB24: D6FE7C04 0412000D
	v_div_fmas_f32 v0, v9, v8, v10                             // 0000007EDB2C: D6370000 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EDB34: BF870112
	.long 0xd73c0003                                           // 0000007EDB38: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007EDB3C: 02020681
	v_div_fixup_f32 v5, v0, v7, v6                             // 0000007EDB40: D6270005 041A0F00
	.long 0xd73c0000                                           // 0000007EDB48: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007EDB4C: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EDB50: BF870193
	.long 0xd7006a03                                           // 0000007EDB54: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007EDB58: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007EDB5C: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007EDB64: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EDB6C: BF870193
	.long 0xd7006a00                                           // 0000007EDB70: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007EDB74: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007EDB78: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007EDB84: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007EDB88: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007EDB90: DC960000 007C0200
	s_endpgm                                                   // 0000007EDB98: BFB00000
		...

