00000000007e7800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007E7800: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007E7808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007E780C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007E7810: 84828302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E7814: BF8701A9
	v_dual_mov_b32 v24, s3 :: v_dual_and_b32 v1, 15, v0        // 0000007E7818: CA240003 1800008F
	v_and_b32_e32 v30, 31, v0                                  // 0000007E7820: 363C009F
	v_and_b32_e32 v2, 60, v2                                   // 0000007E7824: 360404BC
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000007E7828: 300E0082
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007E782C: BF870004
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007E7830: 30020282
	.long 0x7f0c3880                                           // 0000007E7834: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 0000007E7838: BF89FC07
	s_clause 0x1                                               // 0000007E783C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007E7840: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007E7848: DC520000 04080002
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000007E7850: 32020085
	s_add_u32 s24, s8, s20                                     // 0000007E7854: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000007E7858: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000007E785C: 86049F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007E7860: BF8704A1
	v_or_b32_e32 v23, s2, v1                                   // 0000007E7864: 382E0202
	s_lshr_b32 s4, s4, 27                                      // 0000007E7868: 85049B04
	s_add_u32 s4, s14, s4                                      // 0000007E786C: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007E7870: 8205800F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007E7874: BF8704A1
	.long 0xd4540002                                           // 0000007E7878: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 0000007E787C: 02022E10
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007E7880: 85868504
	s_cmpk_lt_i32 s6, 0x101                                    // 0000007E7884: B3860101
	.long 0xd4440004                                           // 0000007E7888: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007E788C: 02023C06
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 0000007E7890: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 0000007E7898: D5010005 00080680
	s_cselect_b32 s3, -1, 0                                    // 0000007E78A0: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000007E78A4: B2860100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007E78A8: BF8704B2
	.long 0xd72c0008                                           // 0000007E78AC: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000007E78B0: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000007E78B4: D6FE7C00 02020416
	s_cselect_b32 s7, -1, 0                                    // 0000007E78BC: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007E78C0: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007E78C4: BF8907F7
	v_bfe_u32 v9, v3, 16, 1                                    // 0000007E78C8: D6100009 02052103
	s_waitcnt vmcnt(0)                                         // 0000007E78D0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000007E78D4: D610000A 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E78DC: BF8701A2
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000007E78E0: D6550003 03FE1303 00007FFF
	.long 0xd72c0009                                           // 0000007E78EC: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000007E78F0: 02020A16
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000007E78F4: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007E7900: BF870223
	.long 0x7e0c3983                                           // 0000007E7904: 7E0C3983
	.long 0xd7000503                                           // 0000007E7908: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 0000007E790C: 02020018
	v_add3_u32 v1, v1, v9, v8                                  // 0000007E7910: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E7918: BF870113
	v_and_or_b32 v6, 0xffff0000, v4, v6                        // 0000007E791C: D6570006 041A08FF FFFF0000
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 0000007E7928: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 0000007E7930: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 0000007E7938: BF89FC07
	s_barrier                                                  // 0000007E793C: BFBD0000
	buffer_gl0_inv                                             // 0000007E7940: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007E7948: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x394>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000007E794C: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 0000007E7954: BE852004
	s_cbranch_execz 10                                         // 0000007E7958: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x184>
	v_lshlrev_b32_e32 v6, 1, v30                               // 0000007E795C: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7960: BF870091
	.long 0xd7006a06                                           // 0000007E7964: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7968: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000007E796C: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 0000007E7974: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007E797C: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 0000007E7980: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007E7984: 8C7E057E
	v_or_b32_e32 v6, 32, v30                                   // 0000007E7988: 380C3CA0
	s_mov_b32 s4, exec_lo                                      // 0000007E798C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7990: BF870001
	.long 0xd4c4007e                                           // 0000007E7994: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7998: 02020C06
	s_cbranch_execz 10                                         // 0000007E799C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1c8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E79A0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E79A4: BF870091
	.long 0xd7006a08                                           // 0000007E79A8: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E79AC: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000007E79B0: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000007E79B8: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000007E79C0: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000007E79C4: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E79C8: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000007E79CC: 380C3CC0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000007E79D0: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000007E79D8: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E79DC: BF870002
	.long 0xd4c4007e                                           // 0000007E79E0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E79E4: 02020C06
	s_cbranch_execz 10                                         // 0000007E79E8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x214>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E79EC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E79F0: BF870091
	.long 0xd7006a0b                                           // 0000007E79F4: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E79F8: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000007E79FC: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000007E7A04: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000007E7A0C: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000007E7A10: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7A14: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000007E7A18: 380C3CFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000007E7A20: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7A24: BF870001
	.long 0xd4c4007e                                           // 0000007E7A28: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7A2C: 02020C06
	s_cbranch_execz 10                                         // 0000007E7A30: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x25c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E7A34: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7A38: BF870091
	.long 0xd7006a0a                                           // 0000007E7A3C: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7A40: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 0000007E7A44: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 0000007E7A4C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007E7A54: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 0000007E7A58: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7A5C: 8C7E047E
	v_or_b32_e32 v6, 0x80, v30                                 // 0000007E7A60: 380C3CFF 00000080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000007E7A68: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 0000007E7A70: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E7A74: BF870002
	.long 0xd4c4007e                                           // 0000007E7A78: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7A7C: 02020C06
	s_cbranch_execz 10                                         // 0000007E7A80: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2ac>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E7A84: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7A88: BF870091
	.long 0xd7006a0d                                           // 0000007E7A8C: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7A90: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 0000007E7A94: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 0000007E7A9C: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000007E7AA4: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000007E7AA8: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7AAC: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v30                                 // 0000007E7AB0: 380C3CFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000007E7AB8: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7ABC: BF870001
	.long 0xd4c4007e                                           // 0000007E7AC0: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7AC4: 02020C06
	s_cbranch_execz 10                                         // 0000007E7AC8: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2f4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E7ACC: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7AD0: BF870091
	.long 0xd7006a0c                                           // 0000007E7AD4: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7AD8: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000007E7ADC: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000007E7AE4: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000007E7AEC: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000007E7AF0: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7AF4: 8C7E047E
	v_or_b32_e32 v6, 0xc0, v30                                 // 0000007E7AF8: 380C3CFF 000000C0
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000007E7B00: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 0000007E7B08: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E7B0C: BF870002
	.long 0xd4c4007e                                           // 0000007E7B10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7B14: 02020C06
	s_cbranch_execz 10                                         // 0000007E7B18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x344>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E7B1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7B20: BF870091
	.long 0xd7006a0f                                           // 0000007E7B24: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7B28: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 0000007E7B2C: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 0000007E7B34: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 0000007E7B3C: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 0000007E7B40: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7B44: 8C7E047E
	v_or_b32_e32 v6, 0xe0, v30                                 // 0000007E7B48: 380C3CFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000007E7B50: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7B54: BF870001
	.long 0xd4c4007e                                           // 0000007E7B58: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007E7B5C: 02020C06
	s_cbranch_execz 10                                         // 0000007E7B60: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000007E7B64: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7B68: BF870091
	.long 0xd7006a0e                                           // 0000007E7B6C: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000007E7B70: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 0000007E7B74: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 0000007E7B7C: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 0000007E7B84: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 0000007E7B88: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E7B8C: 8C7E047E
	s_branch 9                                                 // 0000007E7B90: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_mov_b32_e32 v7, 0                                        // 0000007E7B94: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7B98: BF870001
	v_mov_b32_e32 v8, v7                                       // 0000007E7B9C: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000007E7BA0: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000007E7BA4: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000007E7BA8: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000007E7BAC: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000007E7BB0: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000007E7BB4: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000007E7BB8: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007E7BBC: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000007E7BC0: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007E7BC4: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 0000007E7BCC: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000007E7BD0: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 0000007E7BD4: CA100080 1F160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007E7BDC: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 0000007E7BE0: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000007E7BE8: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000007E7BF0: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000007E7BF4: 02002702
	.long 0xd72c0005                                           // 0000007E7BF8: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000007E7BFC: 02002505
	.long 0xd4440004                                           // 0000007E7C00: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007E7C04: 02023C06
	v_mov_b32_e32 v43, 0                                       // 0000007E7C08: 7E560280
	v_mov_b32_e32 v21, 0                                       // 0000007E7C0C: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007E7C10: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 0000007E7C14: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 0000007E7C1C: BE852004
	s_cbranch_execz 21                                         // 0000007E7C20: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 0000007E7C24: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7C2C: BF870091
	.long 0xd7006a05                                           // 0000007E7C30: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 0000007E7C34: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 0000007E7C38: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007E7C40: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 0000007E7C44: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 0000007E7C4C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x478>
	v_lshlrev_b32_e32 v2, 1, v30                               // 0000007E7C50: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E7C54: BF870091
	.long 0xd7006a02                                           // 0000007E7C58: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000007E7C5C: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000007E7C60: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 0000007E7C68: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007E7C70: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 0000007E7C74: 7E561702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007E7C78: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000007E7C7C: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 0000007E7C84: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007E7C8C: CA100080 26260080
	s_and_saveexec_b32 s5, s4                                  // 0000007E7C94: BE852004
	s_cbranch_execz 627                                        // 0000007E7C98: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xe68>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000007E7C9C: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000007E7CA4: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000007E7CA8: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E7CAC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000007E7CB0: D5207C01 01AA0215
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000007E7CB8: CA22011E 291A3C85
	.long 0xd7006a00                                           // 0000007E7CC0: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000007E7CC4: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E7CC8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000007E7CCC: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x200                           // 0000007E7CD4: D6560028 03FD091E 00000200
	.long 0xd7006a00                                           // 0000007E7CE0: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007E7CE4: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E7CE8: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007E7CEC: D5207C01 01AA0209
	v_mov_b32_e32 v39, v27                                     // 0000007E7CF4: 7E4E031B
	.long 0xd7006a1c                                           // 0000007E7CF8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v192, vcc_lo                     // 0000007E7CFC: 02018100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7D00: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000007E7D04: D5207C1D 01AA0280
	v_mov_b32_e32 v38, v27                                     // 0000007E7D0C: 7E4C031B
	v_mov_b32_e32 v37, v27                                     // 0000007E7D10: 7E4A031B
	v_mov_b32_e32 v36, v27                                     // 0000007E7D14: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 0000007E7D18: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 0000007E7D1C: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 0000007E7D20: 7E3E031B
	v_mov_b32_e32 v42, v43                                     // 0000007E7D24: 7E54032B
	s_mul_i32 s4, s15, 6                                       // 0000007E7D28: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000007E7D2C: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000007E7D30: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000007E7D34: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000007E7D38: 9615860E
	s_mov_b32 s20, 0                                           // 0000007E7D3C: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007E7D40: 8488810E
	s_branch 555                                               // 0000007E7D44: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xdf4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007E7D48: 8C7E0E7E
	v_cndmask_b32_e64 v53, v43, v7, s3                         // 0000007E7D4C: D5010035 000E0F2B
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 0000007E7D54: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 0000007E7D5C: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 0000007E7D64: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 0000007E7D70: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 0000007E7D78: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 0000007E7D80: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 0000007E7D88: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007E7D90: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 0000007E7D94: D5010002 000E1509
	v_add_nc_u32_e32 v40, 0x200, v40                           // 0000007E7D9C: 4A5050FF 00000200
	s_and_b32 s4, exec_lo, s4                                  // 0000007E7DA4: 8B04047E
	ds_load_b32 v14, v8                                        // 0000007E7DA8: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000007E7DB0: 32102686
	s_or_b32 s20, s4, s20                                      // 0000007E7DB4: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7DB8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7DBC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000007E7DC4: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000007E7DCC: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7DD0: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 0000007E7DD8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000007E7DE0: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7DE4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7DE8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000007E7DF0: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000007E7DF8: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007E7E00: 30101082
	ds_load_b32 v57, v8                                        // 0000007E7E04: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000007E7E0C: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7E10: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E14: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 0000007E7E1C: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000007E7E24: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E28: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 0000007E7E30: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 0000007E7E38: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7E3C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E40: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 0000007E7E48: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 0000007E7E50: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007E7E58: 30101082
	ds_load_b32 v61, v8                                        // 0000007E7E5C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 0000007E7E64: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7E68: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E6C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 0000007E7E74: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 0000007E7E7C: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E80: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 0000007E7E88: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 0000007E7E90: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7E94: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7E98: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000007E7EA0: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000007E7EA8: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007E7EB0: 30101082
	ds_load_b32 v65, v8                                        // 0000007E7EB4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000007E7EBC: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E7EC0: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7EC4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000007E7ECC: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000007E7ED4: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7ED8: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 0000007E7EE0: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000007E7EE8: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007E7EEC: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007E7EF0: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 0000007E7EF8: D8D80000 44000008
	.long 0xd73c0008                                           // 0000007E7F00: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007E7F04: 02023481
	v_add_nc_u32_e32 v26, 0x400, v26                           // 0000007E7F08: 4A3434FF 00000400
	.long 0xd7006a0c                                           // 0000007E7F10: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000007E7F14: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E7F18: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000007E7F1C: D5207C0D 01AA120B
	s_clause 0x3                                               // 0000007E7F24: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007E7F28: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007E7F30: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000007E7F38: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000007E7F40: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007E7F48: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E7F4C: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 0000007E7F54: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7F58: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E7F5C: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 0000007E7F64: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E7F68: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 0000007E7F70: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7F74: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E7F78: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007E7F80: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E7F84: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 0000007E7F8C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7F90: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E7F94: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 0000007E7F9C: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E7FA0: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 0000007E7FA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7FAC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E7FB0: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007E7FB8: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E7FBC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 0000007E7FC4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7FC8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E7FCC: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 0000007E7FD4: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E7FD8: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 0000007E7FE0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E7FE4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E7FE8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007E7FF0: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E7FF4: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 0000007E7FFC: D7006A2F
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000007E8000: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000007E8004: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007E8008: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E800C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s9, v13, vcc_lo             // 0000007E8014: D5207C30 01AA1A09
	.long 0xd7006a33                                           // 0000007E801C: D7006A33
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007E8020: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 0000007E8024: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E8028: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s19, v13, vcc_lo            // 0000007E8030: D5207C34 01AA1A13
	.long 0xd7006a0c                                           // 0000007E8038: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 0000007E803C: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000007E8040: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E8044: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E8048: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 0000007E8050: D5207C0D 01AA1A07
	v_fmac_f32_e32 v39, v53, v8                                // 0000007E8058: 564E1135
	s_clause 0x3                                               // 0000007E805C: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 0000007E8060: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 0000007E8068: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 0000007E8070: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 0000007E8078: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 0000007E8080: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E8084: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E808C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E8090: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E8098: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E80A0: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E80A4: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E80AC: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E80B0: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E80B8: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E80BC: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E80C4: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E80CC: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E80D0: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000007E80D8: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E80DC: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E80E4: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E80E8: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E80F0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E80F8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E80FC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E8104: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E8108: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8110: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E8114: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E811C: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8124: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E8128: CC1A4008 1C228932
	v_fmac_f32_e32 v38, v53, v8                                // 0000007E8130: 564C1135
	s_clause 0x3                                               // 0000007E8134: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 0000007E8138: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 0000007E8140: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000007E8148: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 0000007E8150: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 0000007E8158: D7006A33
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 0000007E815C: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E8160: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s19, v52, vcc_lo            // 0000007E8164: D5207C34 01AA6813
	s_waitcnt vmcnt(3)                                         // 0000007E816C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E8170: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E8178: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8180: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E8184: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E818C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E8194: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8198: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E819C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E81A4: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E81AC: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E81B0: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E81B8: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000007E81C0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E81C4: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E81C8: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E81D0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E81D8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E81DC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E81E4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E81EC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E81F0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E81F4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E81FC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8204: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E8208: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E8210: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E8218: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 0000007E821C: 564A1135
	s_clause 0x3                                               // 0000007E8220: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007E8224: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007E822C: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000007E8234: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000007E823C: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 0000007E8244: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000007E8248: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E824C: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 0000007E8250: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 0000007E8258: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E825C: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E8264: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E826C: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E8270: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E8278: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E8280: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8284: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E8288: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E8290: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8298: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E829C: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E82A4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000007E82AC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E82B0: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E82B4: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E82BC: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E82C4: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E82C8: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E82D0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E82D8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E82DC: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E82E0: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E82E8: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E82F0: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E82F4: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E82FC: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E8304: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 0000007E8308: 56481135
	s_clause 0x3                                               // 0000007E830C: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 0000007E8310: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 0000007E8318: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 0000007E8320: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 0000007E8328: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 0000007E8330: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E8334: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E833C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E8340: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E8348: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8350: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E8354: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E835C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E8360: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8368: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E836C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E8374: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E837C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E8380: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000007E8388: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E838C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8394: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E8398: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E83A0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E83A8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E83AC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E83B4: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E83B8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E83C0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E83C4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E83CC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E83D4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E83D8: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 0000007E83E0: 56461135
	s_clause 0x3                                               // 0000007E83E4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007E83E8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007E83F0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000007E83F8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000007E8400: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 0000007E8408: D7006A0C
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 0000007E840C: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8410: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v52, vcc_lo            // 0000007E8414: D5207C0D 01AA6813
	.long 0xd7006a1c                                           // 0000007E841C: D7006A1C
	v_cndmask_b32_e32 v0, v28, v192, vcc_lo                    // 0000007E8420: 0201811C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000007E8424: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 0000007E842C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E8430: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8438: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E843C: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E8444: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E844C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E8450: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E8458: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E845C: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8464: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E8468: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E8470: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8478: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E847C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 0000007E8484: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E8488: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8490: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E8494: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E849C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E84A4: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E84A8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E84B0: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E84B4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E84BC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E84C0: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E84C8: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E84D0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E84D4: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 0000007E84DC: 56441135
	s_clause 0x3                                               // 0000007E84E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000007E84E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000007E84EC: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 0000007E84F4: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 0000007E84FC: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 0000007E8504: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000007E8508: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8510: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 0000007E8514: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 0000007E851C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8524: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 0000007E8528: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 0000007E8530: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 0000007E8534: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 0000007E853C: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E8540: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 0000007E8544: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 0000007E854C: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 0000007E8550: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 0000007E8558: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E855C: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 0000007E8560: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 0000007E8568: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 0000007E856C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000007E8570: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 0000007E8578: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E857C: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000007E8580: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000007E8588: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8590: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000007E8594: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 0000007E859C: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000007E85A0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E85A8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000007E85AC: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 0000007E85B4: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E85BC: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 0000007E85C0: CC1A4008 1C228932
	v_dual_fmac_f32 v31, v53, v8 :: v_dual_mov_b32 v14, v7     // 0000007E85C8: C8101135 1F0E0107
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000007E85D0: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000007E85D8: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000007E85E0: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000007E85E8: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000007E85EC: 917E147E
	s_cbranch_execz 28                                         // 0000007E85F0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xe64>
	s_waitcnt vmcnt(0)                                         // 0000007E85F4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 32, v41  // 0000007E85F8: CA200114 102852A0
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000007E8600: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 0000007E8608: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E860C: BF870003
	.long 0xd4430004                                           // 0000007E8610: D4430004
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 0000007E8614: 02025206
	s_mov_b32 s14, exec_lo                                     // 0000007E8618: BE8E007E
	.long 0xd4c4007e                                           // 0000007E861C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 0000007E8620: 02025206
	s_cbranch_execz 64968                                      // 0000007E8624: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	.long 0xd7006a00                                           // 0000007E8628: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 0000007E862C: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E8630: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 0000007E8634: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 0000007E863C: 7C9A4081
	v_mov_b32_e32 v42, v43                                     // 0000007E8640: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 0000007E8644: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 0000007E864C: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	global_load_d16_b16 v0, v[28:29], off                      // 0000007E8650: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 0000007E8658: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 0000007E865C: 7E541700
	s_branch 64953                                             // 0000007E8660: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x548>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000007E8664: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8668: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007E866C: 8C7E057E
	.long 0xd71f0000                                           // 0000007E8670: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007E8674: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007E8678: 3A020090
	v_xor_b32_e32 v8, 8, v0                                    // 0000007E867C: 3A100088
	v_xor_b32_e32 v15, 4, v0                                   // 0000007E8680: 3A1E0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007E8684: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007E8688: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007E868C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007E8690: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 0000007E8694: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000007E8698: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E869C: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007E86A0: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007E86A4: 30020282
	ds_bpermute_b32 v2, v1, v39                                // 0000007E86A8: DACC0000 02002701
	s_waitcnt lgkmcnt(0)                                       // 0000007E86B0: BF89FC07
	v_add_f32_e32 v2, v39, v2                                  // 0000007E86B4: 06040527
	ds_bpermute_b32 v3, v1, v38                                // 0000007E86B8: DACC0000 03002601
	ds_bpermute_b32 v4, v1, v31                                // 0000007E86C0: DACC0000 04001F01
	ds_bpermute_b32 v6, v1, v36                                // 0000007E86C8: DACC0000 06002401
	ds_bpermute_b32 v5, v1, v37                                // 0000007E86D0: DACC0000 05002501
	ds_bpermute_b32 v7, v1, v35                                // 0000007E86D8: DACC0000 07002301
	ds_bpermute_b32 v1, v1, v34                                // 0000007E86E0: DACC0000 01002201
	ds_bpermute_b32 v11, v8, v2                                // 0000007E86E8: DACC0000 0B000208
	s_waitcnt lgkmcnt(5)                                       // 0000007E86F0: BF89FC57
	v_dual_add_f32 v3, v38, v3 :: v_dual_add_f32 v4, v31, v4   // 0000007E86F4: C9080726 0304091F
	s_waitcnt lgkmcnt(3)                                       // 0000007E86FC: BF89FC37
	v_dual_add_f32 v6, v36, v6 :: v_dual_add_f32 v5, v37, v5   // 0000007E8700: C9080D24 06040B25
	s_waitcnt lgkmcnt(2)                                       // 0000007E8708: BF89FC27
	v_add_f32_e32 v7, v35, v7                                  // 0000007E870C: 060E0F23
	ds_bpermute_b32 v10, v8, v3                                // 0000007E8710: DACC0000 0A000308
	ds_bpermute_b32 v9, v8, v4                                 // 0000007E8718: DACC0000 09000408
	ds_bpermute_b32 v12, v8, v6                                // 0000007E8720: DACC0000 0C000608
	v_cndmask_b32_e32 v15, v0, v15, vcc_lo                     // 0000007E8728: 021E1F00
	ds_bpermute_b32 v13, v8, v5                                // 0000007E872C: DACC0000 0D000508
	s_waitcnt lgkmcnt(3)                                       // 0000007E8734: BF89FC37
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v10   // 0000007E8738: C9081702 02021503
	s_waitcnt lgkmcnt(2)                                       // 0000007E8740: BF89FC27
	v_add_f32_e32 v4, v4, v9                                   // 0000007E8744: 06081304
	v_add_f32_e32 v1, v34, v1                                  // 0000007E8748: 06020322
	s_waitcnt lgkmcnt(1)                                       // 0000007E874C: BF89FC17
	v_dual_add_f32 v6, v6, v12 :: v_dual_lshlrev_b32 v15, 2, v15// 0000007E8750: C9221906 060E1E82
	ds_bpermute_b32 v14, v8, v1                                // 0000007E8758: DACC0000 0E000108
	ds_bpermute_b32 v8, v8, v7                                 // 0000007E8760: DACC0000 08000708
	ds_bpermute_b32 v10, v15, v2                               // 0000007E8768: DACC0000 0A00020F
	s_waitcnt lgkmcnt(3)                                       // 0000007E8770: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 0000007E8774: 060A1B05
	ds_bpermute_b32 v11, v15, v6                               // 0000007E8778: DACC0000 0B00060F
	ds_bpermute_b32 v9, v15, v3                                // 0000007E8780: DACC0000 0900030F
	s_waitcnt lgkmcnt(2)                                       // 0000007E8788: BF89FC27
	v_add_f32_e32 v2, v2, v10                                  // 0000007E878C: 06041502
	v_xor_b32_e32 v10, 1, v0                                   // 0000007E8790: 3A140081
	v_add_f32_e32 v7, v7, v8                                   // 0000007E8794: 060E1107
	ds_bpermute_b32 v8, v15, v4                                // 0000007E8798: DACC0000 0800040F
	ds_bpermute_b32 v12, v15, v5                               // 0000007E87A0: DACC0000 0C00050F
	s_waitcnt lgkmcnt(1)                                       // 0000007E87A8: BF89FC17
	v_dual_add_f32 v8, v4, v8 :: v_dual_add_f32 v1, v1, v14    // 0000007E87AC: C9081104 08001D01
	v_add_f32_e32 v4, v6, v11                                  // 0000007E87B4: 06081706
	ds_bpermute_b32 v14, v15, v7                               // 0000007E87B8: DACC0000 0E00070F
	s_waitcnt lgkmcnt(1)                                       // 0000007E87C0: BF89FC17
	v_add_f32_e32 v5, v5, v12                                  // 0000007E87C4: 060A1905
	ds_bpermute_b32 v13, v15, v1                               // 0000007E87C8: DACC0000 0D00010F
	v_xor_b32_e32 v15, 2, v0                                   // 0000007E87D0: 3A1E0082
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E87D4: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000007E87D8: 7C981EA0
	s_waitcnt lgkmcnt(0)                                       // 0000007E87DC: BF89FC07
	v_add_f32_e32 v1, v1, v13                                  // 0000007E87E0: 06021B01
	v_add_f32_e32 v3, v3, v9                                   // 0000007E87E4: 06061303
	v_cndmask_b32_e32 v15, v0, v15, vcc_lo                     // 0000007E87E8: 021E1F00
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000007E87EC: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E87F0: BF870002
	v_dual_cndmask_b32 v0, v0, v10 :: v_dual_lshlrev_b32 v15, 2, v15// 0000007E87F4: CA621500 000E1E82
	v_add_f32_e32 v9, v7, v14                                  // 0000007E87FC: 06121D07
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 0000007E8800: 7C943C80
	ds_bpermute_b32 v6, v15, v3                                // 0000007E8804: DACC0000 0600030F
	ds_bpermute_b32 v12, v15, v4                               // 0000007E880C: DACC0000 0C00040F
	v_lshlrev_b32_e32 v17, 2, v0                               // 0000007E8814: 30220082
	s_and_b32 s2, vcc_lo, s2                                   // 0000007E8818: 8B02026A
	s_waitcnt lgkmcnt(1)                                       // 0000007E881C: BF89FC17
	v_add_f32_e32 v10, v3, v6                                  // 0000007E8820: 06140D03
	s_waitcnt lgkmcnt(0)                                       // 0000007E8824: BF89FC07
	v_add_f32_e32 v6, v4, v12                                  // 0000007E8828: 060C1904
	ds_bpermute_b32 v7, v15, v2                                // 0000007E882C: DACC0000 0700020F
	ds_bpermute_b32 v13, v15, v5                               // 0000007E8834: DACC0000 0D00050F
	ds_bpermute_b32 v14, v15, v1                               // 0000007E883C: DACC0000 0E00010F
	ds_bpermute_b32 v16, v15, v9                               // 0000007E8844: DACC0000 1000090F
	ds_bpermute_b32 v15, v15, v8                               // 0000007E884C: DACC0000 0F00080F
	ds_bpermute_b32 v12, v17, v10                              // 0000007E8854: DACC0000 0C000A11
	s_waitcnt lgkmcnt(5)                                       // 0000007E885C: BF89FC57
	v_add_f32_e32 v11, v2, v7                                  // 0000007E8860: 06160F02
	s_waitcnt lgkmcnt(4)                                       // 0000007E8864: BF89FC47
	v_add_f32_e32 v7, v5, v13                                  // 0000007E8868: 060E1B05
	s_waitcnt lgkmcnt(3)                                       // 0000007E886C: BF89FC37
	v_add_f32_e32 v0, v1, v14                                  // 0000007E8870: 06001D01
	s_waitcnt lgkmcnt(1)                                       // 0000007E8874: BF89FC17
	v_dual_add_f32 v4, v9, v16 :: v_dual_add_f32 v1, v8, v15   // 0000007E8878: C9082109 04001F08
	ds_bpermute_b32 v13, v17, v11                              // 0000007E8880: DACC0000 0D000B11
	ds_bpermute_b32 v9, v17, v7                                // 0000007E8888: DACC0000 09000711
	ds_bpermute_b32 v8, v17, v6                                // 0000007E8890: DACC0000 08000611
	ds_bpermute_b32 v5, v17, v4                                // 0000007E8898: DACC0000 05000411
	ds_bpermute_b32 v2, v17, v0                                // 0000007E88A0: DACC0000 02000011
	ds_bpermute_b32 v3, v17, v1                                // 0000007E88A8: DACC0000 03000111
	s_and_saveexec_b32 s3, s2                                  // 0000007E88B0: BE832002
	s_cbranch_execz 375                                        // 0000007E88B4: BFA50177 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1694>
	s_waitcnt lgkmcnt(5)                                       // 0000007E88B8: BF89FC57
	v_dual_add_f32 v11, v11, v13 :: v_dual_add_f32 v10, v10, v12// 0000007E88BC: C9081B0B 0B0A190A
	.long 0x7f1e3880                                           // 0000007E88C4: 7F1E3880
	s_load_b32 s1, s[0:1], 0x48                                // 0000007E88C8: F4000040 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007E88D0: BF89FC07
	v_add_f32_e32 v6, v6, v8                                   // 0000007E88D4: 060C1106
	.long 0x7e18398b                                           // 0000007E88D8: 7E18398B
	.long 0x7e1e398a                                           // 0000007E88DC: 7E1E398A
	.long 0x7f18398f                                           // 0000007E88E0: 7F18398F
	.long 0x7f10398f                                           // 0000007E88E4: 7F10398F
	v_add_f32_e32 v4, v4, v5                                   // 0000007E88E8: 06080B04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E88EC: BF870214
	v_dual_add_f32 v0, v0, v2 :: v_dual_and_b32 v13, 1, v15    // 0000007E88F0: C9240500 000C1E81
	v_and_b32_e32 v12, 1, v12                                  // 0000007E88F8: 36181881
	s_lshl_b64 s[4:5], s[16:17], 2                             // 0000007E88FC: 84848210
	.long 0x7f40398f                                           // 0000007E8900: 7F40398F
	.long 0x7f3e398f                                           // 0000007E8904: 7F3E398F
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000007E8908: D655000A 03FE1B0A 00007FFF
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000007E8914: D655000B 03FE190B 00007FFF
	v_add_f32_e32 v7, v7, v9                                   // 0000007E8920: 060E1307
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8924: BF870193
	v_dual_add_f32 v1, v1, v3 :: v_dual_and_b32 v10, 0xffff0000, v10// 0000007E8928: C9240701 010A14FF FFFF0000
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000007E8934: 361616FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E893C: BF870193
	.long 0x7e103987                                           // 0000007E8940: 7E103987
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007E8944: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E894C: BF870214
	v_mul_f32_e32 v10, s1, v10                                 // 0000007E8950: 10141401
	v_mul_f32_e32 v16, s1, v11                                 // 0000007E8954: 10201601
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E8958: BF870214
	v_and_b32_e32 v8, 1, v8                                    // 0000007E895C: 36101081
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007E8960: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E896C: BF870193
	v_dual_mul_f32 v12, 0xbfb8aa3b, v10 :: v_dual_mul_f32 v11, 0xbfb8aa3b, v16// 0000007E8970: C8C614FF 0C0A20FF BFB8AA3B
	v_add3_u32 v7, v7, v8, 0x7fff                              // 0000007E897C: D6550007 03FE1107 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8988: BF870193
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007E898C: 360202FF FFFF0000
	v_exp_f32_e32 v12, v12                                     // 0000007E8994: 7E184B0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8998: BF870113
	v_exp_f32_e32 v11, v11                                     // 0000007E899C: 7E164B0B
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000007E89A0: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E89A8: BF870292
	v_mul_f32_e32 v29, s1, v1                                  // 0000007E89AC: 103A0201
	v_add_f32_e32 v17, 1.0, v11                                // 0000007E89B0: 062216F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E89B4: BF870116
	v_add_f32_e32 v11, 1.0, v12                                // 0000007E89B8: 061618F2
	v_div_scale_f32 v12, null, v17, v17, v16                   // 0000007E89BC: D6FC7C0C 04422311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E89C4: BF8701B2
	v_div_scale_f32 v13, null, v11, v11, v10                   // 0000007E89C8: D6FC7C0D 042A170B
	s_waitcnt vmcnt(0)                                         // 0000007E89D0: BF8903F7
	v_div_scale_f32 v21, vcc_lo, v16, v17, v16                 // 0000007E89D4: D6FC6A15 04422310
	v_rcp_f32_e32 v14, v12                                     // 0000007E89DC: 7E1C550C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E89E0: BF870312
	v_rcp_f32_e32 v18, v13                                     // 0000007E89E4: 7E24550D
	v_fma_f32 v19, -v12, v14, 1.0                              // 0000007E89E8: D6130013 23CA1D0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E89F0: BF870115
	v_fma_f32 v20, -v13, v18, 1.0                              // 0000007E89F4: D6130014 23CA250D
	v_fmac_f32_e32 v14, v19, v14                               // 0000007E89FC: 561C1D13
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E8A00: BF8701A2
	v_fmac_f32_e32 v18, v20, v18                               // 0000007E8A04: 56242514
	v_div_scale_f32 v19, s0, v10, v11, v10                     // 0000007E8A08: D6FC0013 042A170A
	v_mul_f32_e32 v20, v21, v14                                // 0000007E8A10: 10281D15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8A14: BF870112
	v_mul_f32_e32 v22, v19, v18                                // 0000007E8A18: 102C2513
	v_fma_f32 v25, -v12, v20, v21                              // 0000007E8A1C: D6130019 2456290C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8A24: BF870091
	v_fmac_f32_e32 v20, v25, v14                               // 0000007E8A28: 56281D19
	v_fma_f32 v12, -v12, v20, v21                              // 0000007E8A2C: D613000C 2456290C
	v_mul_f32_e32 v21, s1, v7                                  // 0000007E8A34: 102A0E01
	v_fma_f32 v26, -v13, v22, v19                              // 0000007E8A38: D613001A 244E2D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8A40: BF870091
	v_dual_mul_f32 v7, 0xbfb8aa3b, v21 :: v_dual_fmac_f32 v22, v26, v18// 0000007E8A44: C8C02AFF 0716251A BFB8AA3B
	v_exp_f32_e32 v7, v7                                       // 0000007E8A50: 7E0E4B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E8A54: BF870131
	v_fma_f32 v13, -v13, v22, v19                              // 0000007E8A58: D613000D 244E2D0D
	v_div_fmas_f32 v19, v12, v14, v20                          // 0000007E8A60: D6370013 04521D0C
	s_mov_b32 vcc_lo, s0                                       // 0000007E8A68: BEEA0000
	v_div_fmas_f32 v12, v13, v18, v22                          // 0000007E8A6C: D637000C 045A250D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E8A74: BF870292
	v_div_fixup_f32 v16, v19, v17, v16                         // 0000007E8A78: D6270010 04422313
	v_add_f32_e32 v22, 1.0, v7                                 // 0000007E8A80: 062C0EF2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8A84: BF870113
	v_div_fixup_f32 v18, v12, v11, v10                         // 0000007E8A88: D6270012 042A170C
	v_div_scale_f32 v14, vcc_lo, v21, v22, v21                 // 0000007E8A90: D6FC6A0E 04562D15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8A98: BF870092
	.long 0x7e1e3992                                           // 0000007E8A9C: 7E1E3992
	v_and_b32_e32 v20, 1, v15                                  // 0000007E8AA0: 36281E81
	.long 0x7e1e3986                                           // 0000007E8AA4: 7E1E3986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8AA8: BF870091
	v_and_b32_e32 v9, 1, v15                                   // 0000007E8AAC: 36121E81
	v_add3_u32 v6, v6, v9, 0x7fff                              // 0000007E8AB0: D6550006 03FE1306 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8ABC: BF870091
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000007E8AC0: 360C0CFF FFFF0000
	v_mul_f32_e32 v6, s1, v6                                   // 0000007E8AC8: 100C0C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8ACC: BF870091
	v_mul_f32_e32 v8, 0xbfb8aa3b, v6                           // 0000007E8AD0: 10100CFF BFB8AA3B
	v_exp_f32_e32 v8, v8                                       // 0000007E8AD8: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E8ADC: BF870125
	v_add_f32_e32 v7, 1.0, v8                                  // 0000007E8AE0: 060E10F2
	v_div_scale_f32 v8, null, v22, v22, v21                    // 0000007E8AE4: D6FC7C08 04562D16
	v_div_scale_f32 v9, null, v7, v7, v6                       // 0000007E8AEC: D6FC7C09 041A0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8AF4: BF870092
	v_rcp_f32_e32 v10, v8                                      // 0000007E8AF8: 7E145508
	v_rcp_f32_e32 v11, v9                                      // 0000007E8AFC: 7E165509
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E8B00: BF870296
	v_fma_f32 v12, -v8, v10, 1.0                               // 0000007E8B04: D613000C 23CA1508
	v_fma_f32 v13, -v9, v11, 1.0                               // 0000007E8B0C: D613000D 23CA1709
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E8B14: BF8701A2
	v_fmac_f32_e32 v10, v12, v10                               // 0000007E8B18: 5614150C
	v_div_scale_f32 v12, s0, v6, v7, v6                        // 0000007E8B1C: D6FC000C 041A0F06
	v_fmac_f32_e32 v11, v13, v11                               // 0000007E8B24: 5616170D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E8B28: BF8701A3
	v_mul_f32_e32 v13, v14, v10                                // 0000007E8B2C: 101A150E
	v_add3_u32 v18, v18, v20, 0x7fff                           // 0000007E8B30: D6550012 03FE2912 00007FFF
	v_mul_f32_e32 v25, v12, v11                                // 0000007E8B3C: 1032170C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8B40: BF870113
	v_fma_f32 v26, -v8, v13, v14                               // 0000007E8B44: D613001A 243A1B08
	v_fma_f32 v27, -v9, v25, v12                               // 0000007E8B4C: D613001B 24323309
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8B54: BF870112
	v_fmac_f32_e32 v13, v26, v10                               // 0000007E8B58: 561A151A
	v_fmac_f32_e32 v25, v27, v11                               // 0000007E8B5C: 5632171B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8B60: BF870112
	v_fma_f32 v8, -v8, v13, v14                                // 0000007E8B64: D6130008 243A1B08
	v_fma_f32 v5, -v9, v25, v12                                // 0000007E8B6C: D6130005 24323309
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E8B74: BF870002
	v_div_fmas_f32 v26, v8, v10, v13                           // 0000007E8B78: D637001A 04361508
	s_mov_b32 vcc_lo, s0                                       // 0000007E8B80: BEEA0000
	.long 0x7e103984                                           // 0000007E8B84: 7E103984
	.long 0x7f10398f                                           // 0000007E8B88: 7F10398F
	v_div_fmas_f32 v5, v5, v11, v25                            // 0000007E8B8C: D6370005 04661705
	v_div_fixup_f32 v17, v26, v22, v21                         // 0000007E8B94: D6270011 04562D1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8B9C: BF870193
	v_and_b32_e32 v3, 1, v8                                    // 0000007E8BA0: 36061081
	v_div_fixup_f32 v25, v5, v7, v6                            // 0000007E8BA4: D6270019 041A0F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8BAC: BF870193
	.long 0x7e3e3991                                           // 0000007E8BB0: 7E3E3991
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000007E8BB4: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8BC0: BF870193
	.long 0x7e1e3999                                           // 0000007E8BC4: 7E1E3999
	v_and_b32_e32 v26, 1, v31                                  // 0000007E8BC8: 36343E81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8BCC: BF870193
	v_and_b32_e32 v2, 0xffff0000, v3                           // 0000007E8BD0: 360406FF FFFF0000
	v_and_b32_e32 v27, 1, v15                                  // 0000007E8BD8: 36361E81
	.long 0x7e1e3980                                           // 0000007E8BDC: 7E1E3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8BE0: BF870114
	v_add3_u32 v17, v17, v26, 0x7fff                           // 0000007E8BE4: D6550011 03FE3511 00007FFF
	v_and_b32_e32 v3, 1, v15                                   // 0000007E8BF0: 36061E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8BF4: BF870091
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007E8BF8: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007E8C04: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8C0C: BF870091
	v_mul_f32_e32 v30, s1, v0                                  // 0000007E8C10: 103C0001
	v_mul_f32_e32 v4, 0xbfb8aa3b, v30                          // 0000007E8C14: 10083CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007E8C1C: BF8700C1
	v_exp_f32_e32 v5, v4                                       // 0000007E8C20: 7E0A4B04
	v_mul_f32_e32 v28, s1, v2                                  // 0000007E8C24: 10380401
	s_lshl_b64 s[0:1], s[16:17], 1                             // 0000007E8C28: 84808110
	v_mul_f32_e32 v2, 0xbfb8aa3b, v29                          // 0000007E8C2C: 10043AFF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000007E8C34: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8C38: BF8700A6
	v_add_f32_e32 v37, 1.0, v5                                 // 0000007E8C3C: 064A0AF2
	v_mul_f32_e32 v1, 0xbfb8aa3b, v28                          // 0000007E8C40: 100238FF BFB8AA3B
	v_exp_f32_e32 v3, v1                                       // 0000007E8C48: 7E064B01
	.long 0xd73c0000                                           // 0000007E8C4C: D73C0000
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000007E8C50: 02022E81
	.long 0x7f2e398f                                           // 0000007E8C54: 7F2E398F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E8C58: BF870126
	v_add_f32_e32 v33, 1.0, v2                                 // 0000007E8C5C: 064204F2
	.long 0x7e2e3990                                           // 0000007E8C60: 7E2E3990
	v_div_scale_f32 v35, null, v33, v33, v29                   // 0000007E8C64: D6FC7C23 04764321
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E8C6C: BF870292
	v_and_b32_e32 v23, 1, v23                                  // 0000007E8C70: 362E2E81
	v_add_f32_e32 v24, 1.0, v3                                 // 0000007E8C74: 063006F2
	.long 0xd7006a03                                           // 0000007E8C78: D7006A03
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007E8C7C: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E8C80: BF870191
	v_add_co_ci_u32_e64 v4, null, s13, v1, vcc_lo              // 0000007E8C84: D5207C04 01AA020D
	v_div_scale_f32 v34, null, v24, v24, v28                   // 0000007E8C8C: D6FC7C22 04723118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8C94: BF870093
	.long 0xd7006a05                                           // 0000007E8C98: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000007E8C9C: 02000103
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000007E8CA0: D5207C06 01AA0801
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E8CA8: BF8700A3
	v_rcp_f32_e32 v36, v34                                     // 0000007E8CAC: 7E485522
	.long 0xd7006a07                                           // 0000007E8CB0: D7006A07
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000007E8CB4: 02000903
	v_add_co_ci_u32_e64 v8, null, s5, v4, vcc_lo               // 0000007E8CB8: D5207C08 01AA0805
	v_div_scale_f32 v39, null, v37, v37, v30                   // 0000007E8CC0: D6FC7C27 047A4B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8CC8: BF870093
	.long 0xd7006a09                                           // 0000007E8CCC: D7006A09
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 0000007E8CD0: 02000907
	v_add_co_ci_u32_e64 v10, null, s5, v8, vcc_lo              // 0000007E8CD4: D5207C0A 01AA1005
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000007E8CDC: BF870005
	v_fma_f32 v2, -v34, v36, 1.0                               // 0000007E8CE0: D6130002 23CA4922
	v_div_scale_f32 v41, vcc_lo, v28, v24, v28                 // 0000007E8CE8: D6FC6A29 0472311C
	v_rcp_f32_e32 v40, v39                                     // 0000007E8CF0: 7E505527
	v_mad_u64_u32 v[0:1], null, s16, 6, v[3:4]                 // 0000007E8CF4: D6FE7C00 040D0C10
	v_rcp_f32_e32 v38, v35                                     // 0000007E8CFC: 7E4C5523
	v_fmac_f32_e32 v36, v2, v36                                // 0000007E8D00: 56484902
	v_div_scale_f32 v44, s1, v30, v37, v30                     // 0000007E8D04: D6FC012C 047A4B1E
	v_div_scale_f32 v42, s0, v29, v33, v29                     // 0000007E8D0C: D6FC002A 0476431D
	v_add3_u32 v16, v16, v23, 0x7fff                           // 0000007E8D14: D6550010 03FE2F10 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000007E8D20: BF870324
	v_mul_f32_e32 v43, v41, v36                                // 0000007E8D24: 10564929
	v_mad_u64_u32 v[1:2], null, s17, 6, v[1:2]                 // 0000007E8D28: D6FE7C01 04050C11
	v_fma_f32 v2, -v39, v40, 1.0                               // 0000007E8D30: D6130002 23CA5127
	global_store_d16_hi_b16 v[3:4], v16, off                   // 0000007E8D38: DC960000 007C1003
	v_fma_f32 v11, -v35, v38, 1.0                              // 0000007E8D40: D613000B 23CA4D23
	v_fma_f32 v45, -v34, v43, v41                              // 0000007E8D48: D613002D 24A65722
	global_store_d16_hi_b16 v[5:6], v18, off                   // 0000007E8D50: DC960000 007C1205
	v_fmac_f32_e32 v40, v2, v40                                // 0000007E8D58: 56505102
	v_add3_u32 v5, v25, v27, 0x7fff                            // 0000007E8D5C: D6550005 03FE3719 00007FFF
	v_fmac_f32_e32 v43, v45, v36                               // 0000007E8D68: 5656492D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8D6C: BF870113
	v_mul_f32_e32 v46, v44, v40                                // 0000007E8D70: 105C512C
	v_fma_f32 v19, -v34, v43, v41                              // 0000007E8D74: D6130013 24A65722
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8D7C: BF870112
	v_fma_f32 v47, -v39, v46, v44                              // 0000007E8D80: D613002F 24B25D27
	v_div_fmas_f32 v19, v19, v36, v43                          // 0000007E8D88: D6370013 04AE4913
	s_mov_b32 vcc_lo, s1                                       // 0000007E8D90: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8D94: BF870112
	v_fmac_f32_e32 v46, v47, v40                               // 0000007E8D98: 565C512F
	v_div_fixup_f32 v19, v19, v24, v28                         // 0000007E8D9C: D6270013 04723113
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8DA4: BF870112
	v_fma_f32 v21, -v39, v46, v44                              // 0000007E8DA8: D6130015 24B25D27
	.long 0x7e403993                                           // 0000007E8DB0: 7E403993
	v_fmac_f32_e32 v38, v11, v38                               // 0000007E8DB4: 564C4D0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E8DB8: BF8701B3
	v_div_fmas_f32 v21, v21, v40, v46                          // 0000007E8DBC: D6370015 04BA5115
	s_mov_b32 vcc_lo, s0                                       // 0000007E8DC4: BEEA0000
	.long 0xd700020b                                           // 0000007E8DC8: D700020B
	v_cndmask_b32_e32 v0, v9, v4, vcc_lo                       // 0000007E8DCC: 02000909
	v_dual_mul_f32 v2, v42, v38 :: v_dual_and_b32 v3, 1, v32   // 0000007E8DD0: C8E44D2A 02024081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007E8DD8: BF870233
	v_div_fixup_f32 v21, v21, v37, v30                         // 0000007E8DDC: D6270015 047A4B15
	v_add_co_ci_u32_e64 v12, null, s5, v10, s2                 // 0000007E8DE4: D5207C0C 000A1405
	.long 0xd700020d                                           // 0000007E8DEC: D700020D
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000007E8DF0: 02000900
	v_fma_f32 v48, -v35, v2, v42                               // 0000007E8DF4: D6130030 24AA0523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007E8DFC: BF870234
	.long 0x7e1e3995                                           // 0000007E8E00: 7E1E3995
	v_add3_u32 v3, v19, v3, 0x7fff                             // 0000007E8E04: D6550003 03FE0713 00007FFF
	v_add_co_ci_u32_e64 v14, null, s5, v1, s2                  // 0000007E8E10: D5207C0E 000A0205
	v_fmac_f32_e32 v2, v48, v38                                // 0000007E8E18: 56044D30
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8E1C: BF870114
	v_and_b32_e32 v4, 1, v15                                   // 0000007E8E20: 36081E81
	v_fma_f32 v22, -v35, v2, v42                               // 0000007E8E24: D6130016 24AA0523
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E8E2C: BF870112
	v_add3_u32 v4, v21, v4, 0x7fff                             // 0000007E8E30: D6550004 03FE0915 00007FFF
	v_div_fmas_f32 v2, v22, v38, v2                            // 0000007E8E3C: D6370002 040A4D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E8E44: BF870091
	v_div_fixup_f32 v2, v2, v33, v29                           // 0000007E8E48: D6270002 04764302
	v_bfe_u32 v15, v2, 16, 1                                   // 0000007E8E50: D610000F 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E8E58: BF870001
	v_add3_u32 v2, v2, v15, 0x7fff                             // 0000007E8E5C: D6550002 03FE1F02 00007FFF
	s_clause 0x4                                               // 0000007E8E68: BF850004
	global_store_d16_hi_b16 v[7:8], v17, off                   // 0000007E8E6C: DC960000 007C1107
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007E8E74: DC960000 007C0500
	global_store_d16_hi_b16 v[9:10], v3, off                   // 0000007E8E7C: DC960000 007C0309
	global_store_d16_hi_b16 v[13:14], v4, off                  // 0000007E8E84: DC960000 007C040D
	global_store_d16_hi_b16 v[11:12], v2, off                  // 0000007E8E8C: DC960000 007C020B
	s_endpgm                                                   // 0000007E8E94: BFB00000
		...

