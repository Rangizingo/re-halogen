00000000002f3400 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll():
	s_clause 0x1                                               // 0000002F3400: BF850001
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000002F3404: F4040300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 0000002F340C: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002F3414: 32020085
	s_mov_b32 s3, 0                                            // 0000002F3418: BE830080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v4, 0              // 0000002F341C: CA100080 0F040080
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000002F3424: 84808302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002F3428: BF8701B9
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v14, 31, v0        // 0000002F342C: CA240001 090E009F
	v_or_b32_e32 v8, s0, v1                                    // 0000002F3434: 38100200
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 0000002F3438: CA100080 05060080
	v_lshlrev_b32_e32 v10, 4, v14                              // 0000002F3440: 30141C84
	v_mov_b32_e32 v28, 0                                       // 0000002F3444: 7E380280
	s_waitcnt lgkmcnt(0)                                       // 0000002F3448: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000002F344C: 7CA8100C
	s_ashr_i32 s0, s11, 31                                     // 0000002F3450: 86009F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002F3454: BF870499
	s_lshr_b32 s0, s0, 28                                      // 0000002F3458: 85009C00
	s_add_u32 s2, s10, s0                                      // 0000002F345C: 8002000A
	s_addc_u32 s3, s11, 0                                      // 0000002F3460: 8203800B
	v_cndmask_b32_e32 v3, 0, v8, vcc_lo                        // 0000002F3464: 02061080
	v_cndmask_b32_e64 v1, 0, s1, vcc_lo                        // 0000002F3468: D5010001 01A80280
	s_ashr_i64 s[2:3], s[2:3], 4                               // 0000002F3470: 86828402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3474: BF8700A9
	s_add_u32 s0, s2, s10                                      // 0000002F3478: 80000A02
	s_addc_u32 s1, s3, s11                                     // 0000002F347C: 82010B03
	.long 0xd72c0007                                           // 0000002F3480: D72C0007
	v_cndmask_b32_e32 v0, v1, v0, vcc_lo                       // 0000002F3484: 02000101
	v_mad_u64_u32 v[1:2], null, v3, s0, 0                      // 0000002F3488: D6FE7C01 02000103
	.long 0xd72c0003                                           // 0000002F3490: D72C0003
	v_cndmask_b32_e32 v0, v3, v1, vcc_lo                       // 0000002F3494: 02000303
	.long 0xd4440000                                           // 0000002F3498: D4440000
	v_cndmask_b32_e32 v1, s2, v14, vcc_lo                      // 0000002F349C: 02021C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F34A0: BF870193
	.long 0xd7000111                                           // 0000002F34A4: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000002F34A8: 02020204
	v_add3_u32 v2, v2, v3, v7                                  // 0000002F34AC: D6550002 041E0702
	v_mov_b32_e32 v7, 0                                        // 0000002F34B4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F34B8: BF870002
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 0000002F34BC: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000002F34C4: BE832000
	s_cbranch_execz 21                                         // 0000002F34C8: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x120>
	v_lshlrev_b32_e32 v3, 4, v14                               // 0000002F34CC: 30061C84
	.long 0xd7000105                                           // 0000002F34D0: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000002F34D4: 02001511
	v_and_b32_e32 v7, 28, v0                                   // 0000002F34D8: 360E009C
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 0000002F34DC: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F34E4: BF870094
	.long 0xd7000103                                           // 0000002F34E8: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000002F34EC: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 0000002F34F0: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F34F8: BF870094
	.long 0xd700010b                                           // 0000002F34FC: D700010B
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002F3500: 02020F05
	v_add_co_ci_u32_e64 v12, null, 0, v6, s1                   // 0000002F3504: D5207C0C 00060C80
	s_clause 0x1                                               // 0000002F350C: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 0000002F3510: DC5E0000 047C0003
	global_load_b32 v28, v[11:12], off                         // 0000002F3518: DC520000 1C7C000B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002F3520: 8C7E037E
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v19, 0             // 0000002F3524: CA100080 10120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000002F352C: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000002F3534: CA100080 16160080
	v_mov_b32_e32 v24, 0                                       // 0000002F353C: 7E300280
	s_and_saveexec_b32 s3, s0                                  // 0000002F3540: BE832000
	s_cbranch_execz 536                                        // 0000002F3544: BFA50218 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x9a8>
	v_and_or_b32 v0, v0, 28, 32                                // 0000002F3548: D6570000 02813900
	.long 0xd7000001                                           // 0000002F3550: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000002F3554: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F3558: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 0000002F355C: D5207C02 0002040B
	v_mov_b32_e32 v11, 0                                       // 0000002F3564: 7E160280
	.long 0xd7000000                                           // 0000002F3568: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000002F356C: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F3570: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 0000002F3574: D5207C01 00020480
	v_dual_mov_b32 v25, v14 :: v_dual_mov_b32 v24, v11         // 0000002F357C: CA10010E 1918010B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3584: BF870093
	.long 0xd700000c                                           // 0000002F3588: D700000C
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002F358C: 02020004
	v_add_co_ci_u32_e64 v13, null, s5, v1, s0                  // 0000002F3590: D5207C0D 00020205
	v_mov_b32_e32 v23, v11                                     // 0000002F3598: 7E2E030B
	v_mov_b32_e32 v21, v11                                     // 0000002F359C: 7E2A030B
	v_mov_b32_e32 v22, v11                                     // 0000002F35A0: 7E2C030B
	v_mov_b32_e32 v19, v11                                     // 0000002F35A4: 7E26030B
	v_mov_b32_e32 v20, v11                                     // 0000002F35A8: 7E28030B
	v_mov_b32_e32 v16, v11                                     // 0000002F35AC: 7E20030B
	v_mov_b32_e32 v15, v11                                     // 0000002F35B0: 7E1E030B
	s_mul_i32 s1, s11, 6                                       // 0000002F35B4: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000002F35B8: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000002F35BC: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000002F35C0: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000002F35C4: 9612860A
	s_mov_b32 s17, 0                                           // 0000002F35C8: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000002F35CC: 8484810A
	s_branch 471                                               // 0000002F35D0: BFA001D7 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x930>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000002F35D4: 8C7E0A7E
	v_cvt_f32_ubyte0_e32 v29, v4                               // 0000002F35D8: 7E3A2304
	s_and_b32 s0, exec_lo, s0                                  // 0000002F35DC: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F35E0: BF870099
	s_or_b32 s17, s0, s17                                      // 0000002F35E4: 8C111100
	v_fma_mix_f32 v29, v29, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F35E8: CC20601D 1472391D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F35F0: BF870091
	v_bfe_u32 v30, v29, 16, 1                                  // 0000002F35F4: D610001E 0205211D
	v_add3_u32 v29, v29, v30, 0x7fff                           // 0000002F35FC: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 0000002F3608: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F360C: BF8700A2
	.long 0x7e3c399d                                           // 0000002F3610: 7E3C399D
	v_cvt_f32_ubyte1_e32 v29, v4                               // 0000002F3614: 7E3A2504
	v_fma_mix_f32 v29, v29, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3618: CC20601D 1472391D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3620: BF870091
	v_bfe_u32 v31, v29, 16, 1                                  // 0000002F3624: D610001F 0205211D
	v_add3_u32 v29, v29, v31, 0x7fff                           // 0000002F362C: D655001D 03FE3F1D 00007FFF
	v_cvt_f32_ubyte2_e32 v31, v4                               // 0000002F3638: 7E3E2704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000002F363C: 7E082904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F3640: BF870193
	v_and_or_b32 v36, 0xffff0000, v29, v30                     // 0000002F3644: D6570024 047A3AFF FFFF0000
	v_fma_mix_f32 v31, v31, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3650: CC20601F 1472391F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F3658: BF870113
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F365C: CC206004 14723904
	v_bfe_u32 v32, v31, 16, 1                                  // 0000002F3664: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F366C: BF870191
	v_add3_u32 v31, v31, v32, 0x7fff                           // 0000002F3670: D655001F 03FE411F 00007FFF
	v_bfe_u32 v32, v4, 16, 1                                   // 0000002F367C: D6100020 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F3684: BF8701A2
	.long 0x7e3e399f                                           // 0000002F3688: 7E3E399F
	.long 0x7f3e399e                                           // 0000002F368C: 7F3E399E
	v_add3_u32 v4, v4, v32, 0x7fff                             // 0000002F3690: D6550004 03FE4104 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F369C: BF8700A1
	v_and_or_b32 v37, 0xffff0000, v4, v31                      // 0000002F36A0: D6570025 047E08FF FFFF0000
	v_cvt_f32_ubyte0_e32 v4, v5                                // 0000002F36AC: 7E082305
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F36B0: CC206004 14723904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F36B8: BF870091
	v_bfe_u32 v29, v4, 16, 1                                   // 0000002F36BC: D610001D 02052104
	v_add3_u32 v4, v4, v29, 0x7fff                             // 0000002F36C4: D6550004 03FE3B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F36D0: BF8700A1
	.long 0x7e3c3984                                           // 0000002F36D4: 7E3C3984
	v_cvt_f32_ubyte1_e32 v4, v5                                // 0000002F36D8: 7E082505
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F36DC: CC206004 14723904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F36E4: BF870091
	v_bfe_u32 v29, v4, 16, 1                                   // 0000002F36E8: D610001D 02052104
	v_add3_u32 v4, v4, v29, 0x7fff                             // 0000002F36F0: D6550004 03FE3B04 00007FFF
	v_cvt_f32_ubyte2_e32 v29, v5                               // 0000002F36FC: 7E3A2705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000002F3700: 7E0A2905
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F3704: BF870193
	v_and_or_b32 v38, 0xffff0000, v4, v30                      // 0000002F3708: D6570026 047A08FF FFFF0000
	v_fma_mix_f32 v29, v29, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3714: CC20601D 1472391D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F371C: BF8701A3
	v_fma_mix_f32 v5, v5, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3720: CC206005 14723905
	v_cvt_f32_ubyte0_e32 v4, v6                                // 0000002F3728: 7E082306
	v_bfe_u32 v31, v29, 16, 1                                  // 0000002F372C: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F3734: BF870112
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3738: CC206004 14723904
	v_add3_u32 v29, v29, v31, 0x7fff                           // 0000002F3740: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v5, 16, 1                                   // 0000002F374C: D610001F 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F3754: BF8701A2
	.long 0x7e3a399d                                           // 0000002F3758: 7E3A399D
	.long 0x7f3a399e                                           // 0000002F375C: 7F3A399E
	v_add3_u32 v5, v5, v31, 0x7fff                             // 0000002F3760: D6550005 03FE3F05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F376C: BF8700A1
	v_and_or_b32 v39, 0xffff0000, v5, v29                      // 0000002F3770: D6570027 04760AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F377C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002F3784: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3790: BF8700A1
	.long 0x7e3c3984                                           // 0000002F3794: 7E3C3984
	v_cvt_f32_ubyte1_e32 v4, v6                                // 0000002F3798: 7E082506
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F379C: CC206004 14723904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F37A4: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F37A8: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002F37B0: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v6                                // 0000002F37BC: 7E0A2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000002F37C0: 7E0C2906
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F37C4: BF870193
	v_and_or_b32 v40, 0xffff0000, v4, v30                      // 0000002F37C8: D6570028 047A08FF FFFF0000
	v_fma_mix_f32 v5, v5, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F37D4: CC206005 14723905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F37DC: BF8701A3
	v_fma_mix_f32 v6, v6, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F37E0: CC206006 14723906
	v_cvt_f32_ubyte0_e32 v4, v7                                // 0000002F37E8: 7E082307
	v_bfe_u32 v29, v5, 16, 1                                   // 0000002F37EC: D610001D 02052105
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F37F4: BF870112
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F37F8: CC206004 14723904
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000002F3800: D6550005 03FE3B05 00007FFF
	v_bfe_u32 v29, v6, 16, 1                                   // 0000002F380C: D610001D 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002F3814: BF8701A2
	.long 0x7e0a3985                                           // 0000002F3818: 7E0A3985
	.long 0x7f0a399e                                           // 0000002F381C: 7F0A399E
	v_add3_u32 v6, v6, v29, 0x7fff                             // 0000002F3820: D6550006 03FE3B06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F382C: BF8700A1
	v_and_or_b32 v41, 0xffff0000, v6, v5                       // 0000002F3830: D6570029 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F383C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002F3844: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3850: BF8700A1
	.long 0x7e3c3984                                           // 0000002F3854: 7E3C3984
	v_cvt_f32_ubyte1_e32 v4, v7                                // 0000002F3858: 7E082507
	v_fma_mix_f32 v4, v4, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F385C: CC206004 14723904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3864: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000002F3868: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000002F3870: D6550004 03FE0B04 00007FFF
	v_cvt_f32_ubyte2_e32 v5, v7                                // 0000002F387C: 7E0A2707
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F3880: BF870112
	v_and_or_b32 v42, 0xffff0000, v4, v30                      // 0000002F3884: D657002A 047A08FF FFFF0000
	v_fma_mix_f32 v5, v5, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F3890: CC206005 14723905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3898: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002F389C: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000002F38A4: D6550005 03FE0D05 00007FFF
	v_cvt_f32_ubyte3_e32 v6, v7                                // 0000002F38B0: 7E0C2907
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F38B4: BF870112
	.long 0x7e0a3985                                           // 0000002F38B8: 7E0A3985
	v_fma_mix_f32 v6, v6, v28, v28 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000002F38BC: CC206006 14723906
	.long 0x7f0a399e                                           // 0000002F38C4: 7F0A399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F38C8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000002F38CC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000002F38D4: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002F38E0: BF870131
	v_and_or_b32 v43, 0xffff0000, v6, v5                       // 0000002F38E4: D657002B 04160CFF FFFF0000
	.long 0xd73c0004                                           // 0000002F38F0: D73C0004
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 0000002F38F4: 02021481
	v_mov_b32_e32 v10, v27                                     // 0000002F38F8: 7E14031B
	.long 0xd7000020                                           // 0000002F38FC: D7000020
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000002F3900: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F3904: BF870001
	v_add_co_ci_u32_e64 v33, null, s7, v5, s0                  // 0000002F3908: D5207C21 00020A07
	s_clause 0x1                                               // 0000002F3910: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000002F3914: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000002F391C: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 0000002F3924: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3928: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3930: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3934: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F393C: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3944: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3948: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3950: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3954: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000002F395C: D700001C
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 0000002F3960: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002F3964: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3968: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s5, v33, s0                 // 0000002F3970: D5207C1D 00024205
	.long 0xd7000022                                           // 0000002F3978: D7000022
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 0000002F397C: 02001D20
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3980: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v35, null, s15, v33, s0                // 0000002F3988: D5207C23 0002420F
	.long 0xd7000020                                           // 0000002F3990: D7000020
	v_cndmask_b32_e32 v0, v32, v18, vcc_lo                     // 0000002F3994: 02002520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F3998: BF870123
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F399C: CC1A4004 1C12571F
	v_add_co_ci_u32_e64 v33, null, s16, v33, s0                // 0000002F39A4: D5207C21 00024210
	v_add_f32_e32 v23, v23, v4                                 // 0000002F39AC: 062E0917
	s_clause 0x1                                               // 0000002F39B0: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 0000002F39B4: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000002F39BC: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 0000002F39C4: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F39C8: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F39D0: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F39D4: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F39DC: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F39E4: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F39E8: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F39F0: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F39F4: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F39FC: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3A00: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3A08: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3A10: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3A14: CC1A4004 1C12571F
	v_add_f32_e32 v24, v24, v4                                 // 0000002F3A1C: 06300918
	s_clause 0x1                                               // 0000002F3A20: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000002F3A24: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000002F3A2C: DC5E0010 1C7C0022
	.long 0xd7000022                                           // 0000002F3A34: D7000022
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 0000002F3A38: 02001D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002F3A3C: BF8700B1
	v_add_co_ci_u32_e64 v35, null, s15, v35, s0                // 0000002F3A40: D5207C23 0002460F
	s_waitcnt vmcnt(1)                                         // 0000002F3A48: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3A4C: CC1A4004 1A024904
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3A54: CC1A4004 1C124B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3A5C: BF870091
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3A60: CC1A4004 1C124D06
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3A68: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3A70: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3A74: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3A78: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3A80: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3A88: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3A8C: CC1A4004 1C12551E
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3A94: CC1A4004 1C12571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002F3A9C: BF8700D1
	v_add_f32_e32 v21, v21, v4                                 // 0000002F3AA0: 062A0915
	s_clause 0x1                                               // 0000002F3AA4: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000002F3AA8: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000002F3AB0: DC5E0010 1C7C0020
	.long 0xd7000020                                           // 0000002F3AB8: D7000020
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 0000002F3ABC: 02001D20
	v_add_co_ci_u32_e64 v33, null, s15, v33, s0                // 0000002F3AC0: D5207C21 0002420F
	s_waitcnt vmcnt(1)                                         // 0000002F3AC8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3ACC: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3AD4: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3AD8: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3AE0: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3AE8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3AEC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3AF4: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3AF8: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3B00: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3B04: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3B0C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3B14: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3B18: CC1A4004 1C12571F
	v_add_f32_e32 v22, v22, v4                                 // 0000002F3B20: 062C0916
	s_clause 0x1                                               // 0000002F3B24: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000002F3B28: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000002F3B30: DC5E0010 1C7C0022
	s_waitcnt vmcnt(1)                                         // 0000002F3B38: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3B3C: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3B44: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3B48: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3B50: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3B58: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3B5C: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3B64: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3B68: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3B70: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3B74: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3B7C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3B84: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3B88: CC1A4004 1C12571F
	v_add_f32_e32 v19, v19, v4                                 // 0000002F3B90: 06260913
	s_clause 0x1                                               // 0000002F3B94: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000002F3B98: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000002F3BA0: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 0000002F3BA8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3BAC: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3BB4: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3BB8: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3BC0: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3BC8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3BCC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3BD4: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3BD8: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000002F3BE0: D700001C
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 0000002F3BE4: 02001D22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F3BE8: BF870122
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3BEC: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v35, s0                // 0000002F3BF4: D5207C1D 0002460F
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3BFC: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3C04: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3C08: CC1A4004 1C12571F
	v_add_f32_e32 v20, v20, v4                                 // 0000002F3C10: 06280914
	s_clause 0x1                                               // 0000002F3C14: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 0000002F3C18: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000002F3C20: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 0000002F3C28: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3C2C: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3C34: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3C38: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3C40: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3C48: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3C4C: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000002F3C54: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3C58: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000002F3C60: D700001C
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 0000002F3C64: 02001D20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002F3C68: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3C6C: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v33, s0                // 0000002F3C74: D5207C1D 0002420F
	.long 0xd700000c                                           // 0000002F3C7C: D700000C
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000002F3C80: 0201410C
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3C84: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v13, null, 0, v13, s0                  // 0000002F3C8C: D5207C0D 00021A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3C94: BF870092
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3C98: CC1A4004 1C12571F
	v_add_f32_e32 v16, v16, v4                                 // 0000002F3CA0: 06200910
	s_clause 0x1                                               // 0000002F3CA4: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 0000002F3CA8: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000002F3CB0: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 0000002F3CB8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000002F3CBC: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F3CC4: BF870121
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000002F3CC8: CC1A4004 1C124B05
	v_mov_b32_e32 v5, v1                                       // 0000002F3CD0: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000002F3CD4: CC1A4004 1C124D06
	v_mov_b32_e32 v6, v2                                       // 0000002F3CDC: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002F3CE0: BF870132
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000002F3CE4: CC1A4004 1C124F07
	v_mov_b32_e32 v7, v3                                       // 0000002F3CEC: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 0000002F3CF0: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000002F3CF4: CC1A4004 1C12511C
	v_mov_b32_e32 v28, v26                                     // 0000002F3CFC: 7E38031A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3D00: BF870092
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000002F3D04: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000002F3D0C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3D14: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000002F3D18: CC1A4004 1C12571F
	v_dual_add_f32 v15, v15, v4 :: v_dual_mov_b32 v4, v0       // 0000002F3D20: C910090F 0F040100
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000002F3D28: 917E117E
	s_cbranch_execz 29                                         // 0000002F3D2C: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x9a4>
	v_add_nc_u32_e32 v25, 32, v25                              // 0000002F3D30: 4A3232A0
	v_add_nc_u32_e32 v27, 0x200, v10                           // 0000002F3D34: 4A3614FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000002F3D3C: BF8704A2
	.long 0xd4430000                                           // 0000002F3D40: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 0000002F3D44: 02023202
	s_and_saveexec_b32 s1, s0                                  // 0000002F3D48: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000002F3D4C: 8D01017E
	v_add_nc_u32_e32 v27, 0x200, v10                           // 0000002F3D50: 4A3614FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000002F3D58: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000002F3D5C: BF8903F7
	v_dual_mov_b32 v26, v28 :: v_dual_mov_b32 v1, v5           // 0000002F3D60: CA10011C 1A000105
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 0000002F3D68: CA100104 00020107
	v_mov_b32_e32 v2, v6                                       // 0000002F3D70: 7E040306
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000002F3D74: 8D7E0A7E
	s_cbranch_execz 65046                                      // 0000002F3D78: BFA5FE16 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x1d4>
	.long 0xd7000100                                           // 0000002F3D7C: D7000100
	v_cndmask_b32_e32 v1, v17, v27, vcc_lo                     // 0000002F3D80: 02023711
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F3D84: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 0000002F3D88: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 0000002F3D90: DC5E0000 007C0000
	global_load_b32 v26, v[12:13], off                         // 0000002F3D98: DC520000 1A7C000C
	s_branch 65036                                             // 0000002F3DA0: BFA0FE0C <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0x1d4>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000002F3DA4: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002F3DA8: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002F3DAC: 8C7E037E
	.long 0xd71f0000                                           // 0000002F3DB0: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002F3DB4: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000002F3DB8: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 0000002F3DBC: 3A160088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002F3DC0: BF870092
	.long 0xd44c0000                                           // 0000002F3DC4: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000002F3DC8: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000002F3DCC: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002F3DD4: BF870113
	.long 0xd44c0000                                           // 0000002F3DD8: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000002F3DDC: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000002F3DE0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002F3DE4: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 0000002F3DE8: D501000B 00021700
	ds_bpermute_b32 v2, v1, v24                                // 0000002F3DF0: DACC0000 02001801
	s_waitcnt lgkmcnt(0)                                       // 0000002F3DF8: BF89FC07
	v_add_f32_e32 v2, v24, v2                                  // 0000002F3DFC: 06040518
	s_waitcnt vmcnt(1)                                         // 0000002F3E00: BF8907F7
	ds_bpermute_b32 v4, v1, v22                                // 0000002F3E04: DACC0000 04001601
	ds_bpermute_b32 v3, v1, v23                                // 0000002F3E0C: DACC0000 03001701
	ds_bpermute_b32 v6, v1, v20                                // 0000002F3E14: DACC0000 06001401
	ds_bpermute_b32 v5, v1, v21                                // 0000002F3E1C: DACC0000 05001501
	ds_bpermute_b32 v7, v1, v19                                // 0000002F3E24: DACC0000 07001301
	ds_bpermute_b32 v10, v1, v15                               // 0000002F3E2C: DACC0000 0A000F01
	ds_bpermute_b32 v1, v1, v16                                // 0000002F3E34: DACC0000 01001001
	s_waitcnt lgkmcnt(6)                                       // 0000002F3E3C: BF89FC67
	v_dual_add_f32 v4, v22, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 0000002F3E40: C9220916 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 0000002F3E48: DACC0000 0C00020B
	s_waitcnt lgkmcnt(5)                                       // 0000002F3E50: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_add_f32 v6, v20, v6   // 0000002F3E54: C9080717 03060D14
	v_xor_b32_e32 v20, 4, v0                                   // 0000002F3E5C: 3A280084
	s_waitcnt lgkmcnt(2)                                       // 0000002F3E60: BF89FC27
	v_dual_add_f32 v5, v21, v5 :: v_dual_add_f32 v10, v15, v10 // 0000002F3E64: C9080B15 050A150F
	s_waitcnt lgkmcnt(1)                                       // 0000002F3E6C: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 0000002F3E70: 06020310
	ds_bpermute_b32 v13, v11, v3                               // 0000002F3E74: DACC0000 0D00030B
	.long 0xd44c0000                                           // 0000002F3E7C: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000002F3E80: 020228A0
	ds_bpermute_b32 v15, v11, v4                               // 0000002F3E84: DACC0000 0F00040B
	ds_bpermute_b32 v16, v11, v5                               // 0000002F3E8C: DACC0000 1000050B
	ds_bpermute_b32 v17, v11, v6                               // 0000002F3E94: DACC0000 1100060B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000002F3E9C: D5010014 00022900
	v_add_f32_e32 v7, v19, v7                                  // 0000002F3EA4: 060E0F13
	ds_bpermute_b32 v19, v11, v10                              // 0000002F3EA8: DACC0000 13000A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000002F3EB0: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 0000002F3EB4: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 0000002F3EBC: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 0000002F3EC0: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 0000002F3EC4: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 0000002F3ECC: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v15   // 0000002F3ED0: C9081B03 03041F04
	s_waitcnt lgkmcnt(3)                                       // 0000002F3ED8: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 0000002F3EDC: C9082105 05062306
	ds_bpermute_b32 v12, v20, v3                               // 0000002F3EE4: DACC0000 0C000314
	ds_bpermute_b32 v13, v20, v4                               // 0000002F3EEC: DACC0000 0D000414
	s_waitcnt lgkmcnt(4)                                       // 0000002F3EF4: BF89FC47
	v_add_f32_e32 v10, v10, v19                                // 0000002F3EF8: 0614270A
	ds_bpermute_b32 v15, v20, v5                               // 0000002F3EFC: DACC0000 0F000514
	ds_bpermute_b32 v16, v20, v6                               // 0000002F3F04: DACC0000 10000614
	s_waitcnt lgkmcnt(5)                                       // 0000002F3F0C: BF89FC57
	v_add_f32_e32 v7, v7, v18                                  // 0000002F3F10: 060E2507
	ds_bpermute_b32 v18, v20, v10                              // 0000002F3F14: DACC0000 12000A14
	s_waitcnt lgkmcnt(5)                                       // 0000002F3F1C: BF89FC57
	v_add_f32_e32 v1, v1, v11                                  // 0000002F3F20: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 0000002F3F24: DACC0000 0B000214
	ds_bpermute_b32 v17, v20, v7                               // 0000002F3F2C: DACC0000 11000714
	ds_bpermute_b32 v19, v20, v1                               // 0000002F3F34: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 0000002F3F3C: 3A280082
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F3F40: BF870001
	.long 0xd44c0000                                           // 0000002F3F44: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000002F3F48: 020228A0
	s_waitcnt lgkmcnt(6)                                       // 0000002F3F4C: BF89FC67
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_f32 v4, v4, v13   // 0000002F3F50: C9081903 03041B04
	s_waitcnt lgkmcnt(5)                                       // 0000002F3F58: BF89FC57
	v_add_f32_e32 v5, v5, v15                                  // 0000002F3F5C: 060A1F05
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000002F3F60: D5010014 00022900
	s_waitcnt lgkmcnt(4)                                       // 0000002F3F68: BF89FC47
	v_add_f32_e32 v6, v6, v16                                  // 0000002F3F6C: 060C2106
	v_xor_b32_e32 v15, 1, v0                                   // 0000002F3F70: 3A1E0081
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F3F74: BF870003
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000002F3F78: 30282882
	s_waitcnt lgkmcnt(1)                                       // 0000002F3F7C: BF89FC17
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v7, v7, v17   // 0000002F3F80: C9081702 02062307
	s_waitcnt lgkmcnt(0)                                       // 0000002F3F88: BF89FC07
	v_dual_add_f32 v12, v10, v18 :: v_dual_add_f32 v1, v1, v19 // 0000002F3F8C: C908250A 0C002701
	ds_bpermute_b32 v11, v20, v3                               // 0000002F3F94: DACC0000 0B000314
	ds_bpermute_b32 v10, v20, v2                               // 0000002F3F9C: DACC0000 0A000214
	ds_bpermute_b32 v13, v20, v4                               // 0000002F3FA4: DACC0000 0D000414
	ds_bpermute_b32 v17, v20, v5                               // 0000002F3FAC: DACC0000 11000514
	ds_bpermute_b32 v18, v20, v6                               // 0000002F3FB4: DACC0000 12000614
	ds_bpermute_b32 v19, v20, v7                               // 0000002F3FBC: DACC0000 13000714
	ds_bpermute_b32 v21, v20, v12                              // 0000002F3FC4: DACC0000 15000C14
	ds_bpermute_b32 v20, v20, v1                               // 0000002F3FCC: DACC0000 14000114
	.long 0xd44c0000                                           // 0000002F3FD4: D44C0000
	v_cndmask_b32_e32 v1, 32, v15, vcc_lo                      // 0000002F3FD8: 02021EA0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002F3FDC: BF870121
	v_cndmask_b32_e64 v0, v0, v15, s0                          // 0000002F3FE0: D5010000 00021F00
	.long 0xd44a0000                                           // 0000002F3FE8: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000002F3FEC: 02021C80
	v_lshlrev_b32_e32 v22, 2, v0                               // 0000002F3FF0: 302C0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000002F3FF4: 8B006A00
	s_waitcnt lgkmcnt(6)                                       // 0000002F3FF8: BF89FC67
	v_dual_add_f32 v16, v3, v11 :: v_dual_add_f32 v15, v2, v10 // 0000002F3FFC: C9081703 100E1502
	s_waitcnt lgkmcnt(5)                                       // 0000002F4004: BF89FC57
	v_add_f32_e32 v10, v4, v13                                 // 0000002F4008: 06141B04
	s_waitcnt lgkmcnt(3)                                       // 0000002F400C: BF89FC37
	v_dual_add_f32 v11, v5, v17 :: v_dual_add_f32 v4, v6, v18  // 0000002F4010: C9082305 0B042506
	s_waitcnt lgkmcnt(1)                                       // 0000002F4018: BF89FC17
	v_dual_add_f32 v5, v7, v19 :: v_dual_add_f32 v0, v12, v21  // 0000002F401C: C9082707 05002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000002F4024: BF89FC07
	v_add_f32_e32 v1, v1, v20                                  // 0000002F4028: 06022901
	ds_bpermute_b32 v17, v22, v16                              // 0000002F402C: DACC0000 11001016
	ds_bpermute_b32 v18, v22, v15                              // 0000002F4034: DACC0000 12000F16
	ds_bpermute_b32 v13, v22, v11                              // 0000002F403C: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v10                              // 0000002F4044: DACC0000 0C000A16
	ds_bpermute_b32 v6, v22, v5                                // 0000002F404C: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 0000002F4054: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 0000002F405C: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 0000002F4064: DACC0000 03000016
	s_and_saveexec_b32 s1, s0                                  // 0000002F406C: BE812000
	s_cbranch_execz 120                                        // 0000002F4070: BFA50078 <_ZN7halogen12_GLOBAL__N_16k_lq8wILi8ELi32ELi1EEEvPKhPKtPtll+0xe54>
	s_waitcnt lgkmcnt(6)                                       // 0000002F4074: BF89FC67
	v_dual_add_f32 v14, v15, v18 :: v_dual_add_f32 v15, v16, v17// 0000002F4078: C908250F 0E0E2310
	.long 0x7f203880                                           // 0000002F4080: 7F203880
	.long 0xd73c0008                                           // 0000002F4084: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000002F4088: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000002F408C: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002F4090: BF870003
	.long 0x7e20398e                                           // 0000002F4094: 7E20398E
	.long 0x7e22398f                                           // 0000002F4098: 7E22398F
	.long 0x7f223990                                           // 0000002F409C: 7F223990
	s_waitcnt lgkmcnt(5)                                       // 0000002F40A0: BF89FC57
	v_add_f32_e32 v13, v11, v13                                // 0000002F40A4: 061A1B0B
	.long 0xd7006a08                                           // 0000002F40A8: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 0000002F40AC: 02021008
	v_and_b32_e32 v18, 1, v16                                  // 0000002F40B0: 36242081
	s_waitcnt lgkmcnt(4)                                       // 0000002F40B4: BF89FC47
	v_dual_add_f32 v12, v10, v12 :: v_dual_and_b32 v17, 1, v17 // 0000002F40B8: C924190A 0C102281
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 0000002F40C0: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002F40C8: BF870223
	v_add3_u32 v18, v14, v18, 0x7fff                           // 0000002F40CC: D6550012 03FE250E 00007FFF
	.long 0xd7006a0e                                           // 0000002F40D8: D7006A0E
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002F40DC: 02000108
	v_add3_u32 v17, v15, v17, 0x7fff                           // 0000002F40E0: D6550011 03FE230F 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002F40EC: BF870004
	v_add_co_ci_u32_e64 v15, null, s1, v9, vcc_lo              // 0000002F40F0: D5207C0F 01AA1201
	s_clause 0x1                                               // 0000002F40F8: BF850001
	global_store_d16_hi_b16 v[8:9], v17, off                   // 0000002F40FC: DC960000 007C1108
	global_store_d16_hi_b16 v[14:15], v18, off                 // 0000002F4104: DC960000 007C120E
	.long 0x7e1c398d                                           // 0000002F410C: 7E1C398D
	.long 0x7f1c3990                                           // 0000002F4110: 7F1C3990
	.long 0x7e20398c                                           // 0000002F4114: 7E20398C
	s_waitcnt lgkmcnt(3)                                       // 0000002F4118: BF89FC37
	v_add_f32_e32 v15, v5, v6                                  // 0000002F411C: 061E0D05
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000002F4120: 8480820C
	s_waitcnt lgkmcnt(2)                                       // 0000002F4124: BF89FC27
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v14, 1, v14    // 0000002F4128: C9240F04 070E1C81
	v_mad_u64_u32 v[4:5], null, s12, 6, v[8:9]                 // 0000002F4130: D6FE7C04 04210C0C
	.long 0xd7006a0a                                           // 0000002F4138: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000002F413C: 02000108
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F4140: BF870001
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 0000002F4144: D5207C0B 01AA1201
	v_and_b32_e32 v6, 1, v16                                   // 0000002F414C: 360C2081
	v_add3_u32 v8, v13, v14, 0x7fff                            // 0000002F4150: D6550008 03FE1D0D 00007FFF
	.long 0x7e12398f                                           // 0000002F415C: 7E12398F
	.long 0x7f123990                                           // 0000002F4160: 7F123990
	.long 0x7e203987                                           // 0000002F4164: 7E203987
	v_add3_u32 v12, v12, v6, 0x7fff                            // 0000002F4168: D655000C 03FE0D0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v8, off                  // 0000002F4174: DC960000 007C080A
	v_mad_u64_u32 v[5:6], null, s13, 6, v[5:6]                 // 0000002F417C: D6FE7C05 04150C0D
	s_waitcnt lgkmcnt(0)                                       // 0000002F4184: BF89FC07
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v8, 1, v9     // 0000002F4188: C9240700 0D081281
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v6, 1, v16     // 0000002F4190: C9240501 09062081
	.long 0xd7006a00                                           // 0000002F4198: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 0000002F419C: 0200010A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002F41A0: BF870193
	.long 0x7e20398d                                           // 0000002F41A4: 7E20398D
	v_add3_u32 v10, v7, v6, 0x7fff                             // 0000002F41A8: D655000A 03FE0D07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002F41B4: BF870004
	.long 0x7e0c3989                                           // 0000002F41B8: 7E0C3989
	.long 0x7f0c3990                                           // 0000002F41BC: 7F0C3990
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 0000002F41C0: D5207C01 01AA1601
	v_add3_u32 v11, v15, v8, 0x7fff                            // 0000002F41C8: D655000B 03FE110F 00007FFF
	.long 0xd7006a02                                           // 0000002F41D4: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000002F41D8: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 0000002F41DC: 36102081
	v_and_b32_e32 v14, 1, v6                                   // 0000002F41E0: 361C0C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 0000002F41E4: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 0000002F41EC: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002F41F0: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002F41F4: BF870001
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 0000002F41F8: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 0000002F4200: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 0000002F420C: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000002F4210: 02000102
	v_add3_u32 v14, v9, v14, 0x7fff                            // 0000002F4214: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000002F4220: D5207C09 01AA0601
	s_clause 0x4                                               // 0000002F4228: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 0000002F422C: DC960000 007C0C04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000002F4234: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000002F423C: DC960000 007C0A02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 0000002F4244: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 0000002F424C: DC960000 007C0D08
	s_endpgm                                                   // 0000002F4254: BFB00000
		...

