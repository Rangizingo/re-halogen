00000000003d9300 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf():
	s_load_b256 s[4:11], s[0:1], null                          // 0000003D9300: F40C0100 F8000000
	v_lshrrev_b32_e32 v1, 6, v0                                // 0000003D9308: 32020086
	v_bfe_u32 v2, v0, 4, 2                                     // 0000003D930C: D6100002 02090900
	s_lshl_b32 s2, s2, 2                                       // 0000003D9314: 84028202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v11, 15, v0        // 0000003D9318: CA240080 0C0A008F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003D9320: BF870193
	v_or_b32_e32 v1, s2, v1                                    // 0000003D9324: 38020202
	v_mul_u32_u24_e32 v2, 0xa00, v2                            // 0000003D9328: 160404FF 00000A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003D9330: BF870223
	v_lshlrev_b32_e32 v14, 4, v11                              // 0000003D9334: 301C1684
	v_or_b32_e32 v15, 16, v11                                  // 0000003D9338: 381E1690
	v_ashrrev_i32_e32 v3, 31, v1                               // 0000003D933C: 3406029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003D9340: BF870094
	.long 0xd7006a01                                           // 0000003D9344: D7006A01
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000003D9348: 02020302
	v_add_co_ci_u32_e64 v2, null, 0, v3, vcc_lo                // 0000003D934C: D5207C02 01AA0680
	v_and_b32_e32 v3, 12, v0                                   // 0000003D9354: 3606008C
	s_waitcnt lgkmcnt(0)                                       // 0000003D9358: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000003D935C: BF8700D3
	v_mad_u64_u32 v[9:10], null, 0x154, v1, s[4:5]             // 0000003D9360: D6FE7C09 001202FF 00000154
	s_load_b64 s[4:5], s[0:1], 0x20                            // 0000003D936C: F4040100 F8000020
	s_mov_b32 s0, exec_lo                                      // 0000003D9374: BE80007E
	v_mad_i32_i24 v10, 0x154, v2, v10                          // 0000003D9378: D60A000A 042A04FF 00000154
	.long 0xd7006a01                                           // 0000003D9384: D7006A01
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 0000003D9388: 02021D09
	v_add_co_ci_u32_e64 v2, null, 0, v10, vcc_lo               // 0000003D938C: D5207C02 01AA1480
	.long 0xd7006a03                                           // 0000003D9394: D7006A03
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000003D9398: 02020709
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D939C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v10, vcc_lo               // 0000003D93A0: D5207C04 01AA1480
	s_clause 0x1                                               // 0000003D93A8: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 0000003D93AC: DC5E0000 057C0001
	global_load_b32 v13, v[3:4], off offset:320                // 0000003D93B4: DC520140 0D7C0003
	v_cmpx_gt_u32_e32 20, v15                                  // 0000003D93BC: 7D981E94
	s_cbranch_execz 5                                          // 0000003D93C0: BFA50005 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf+0xd8>
	s_clause 0x1                                               // 0000003D93C4: BF850001
	global_load_b128 v[1:4], v[1:2], off offset:256            // 0000003D93C8: DC5E0100 017C0001
	global_load_b32 v12, v[9:10], off offset:336               // 0000003D93D0: DC520150 0C7C0009
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D93D8: 8C7E007E
	v_lshlrev_b32_e32 v16, 1, v14                              // 0000003D93DC: 30201C81
	s_waitcnt vmcnt(1)                                         // 0000003D93E0: BF8907F7
	v_cvt_f32_ubyte0_e32 v10, v5                               // 0000003D93E4: 7E142305
	v_cvt_f32_ubyte1_e32 v14, v5                               // 0000003D93E8: 7E1C2505
	v_cvt_f32_ubyte2_e32 v73, v5                               // 0000003D93EC: 7E922705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 0000003D93F0: 7E0A2905
	s_clause 0xd                                               // 0000003D93F4: BF85000D
	global_load_b128 v[17:20], v16, s[6:7]                     // 0000003D93F8: DC5E0000 11060010
	global_load_b128 v[21:24], v16, s[6:7] offset:640          // 0000003D9400: DC5E0280 15060010
	global_load_b128 v[25:28], v16, s[6:7] offset:1280         // 0000003D9408: DC5E0500 19060010
	global_load_b128 v[29:32], v16, s[6:7] offset:1920         // 0000003D9410: DC5E0780 1D060010
	global_load_b128 v[33:36], v16, s[6:7] offset:2560         // 0000003D9418: DC5E0A00 21060010
	global_load_b128 v[37:40], v16, s[6:7] offset:3200         // 0000003D9420: DC5E0C80 25060010
	global_load_b128 v[41:44], v16, s[6:7] offset:3840         // 0000003D9428: DC5E0F00 29060010
	global_load_b128 v[45:48], v16, s[6:7] offset:16           // 0000003D9430: DC5E0010 2D060010
	global_load_b128 v[49:52], v16, s[6:7] offset:656          // 0000003D9438: DC5E0290 31060010
	global_load_b128 v[53:56], v16, s[6:7] offset:1296         // 0000003D9440: DC5E0510 35060010
	global_load_b128 v[57:60], v16, s[6:7] offset:1936         // 0000003D9448: DC5E0790 39060010
	global_load_b128 v[61:64], v16, s[6:7] offset:2576         // 0000003D9450: DC5E0A10 3D060010
	global_load_b128 v[65:68], v16, s[6:7] offset:3216         // 0000003D9458: DC5E0C90 41060010
	global_load_b128 v[69:72], v16, s[6:7] offset:3856         // 0000003D9460: DC5E0F10 45060010
	v_cvt_f32_ubyte0_e32 v74, v6                               // 0000003D9468: 7E942306
	v_cvt_f32_ubyte1_e32 v75, v6                               // 0000003D946C: 7E962506
	v_cvt_f32_ubyte2_e32 v76, v6                               // 0000003D9470: 7E982706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003D9474: 7E0C2906
	v_cvt_f32_ubyte0_e32 v77, v7                               // 0000003D9478: 7E9A2307
	v_cvt_f32_ubyte1_e32 v78, v7                               // 0000003D947C: 7E9C2507
	v_cvt_f32_ubyte2_e32 v79, v7                               // 0000003D9480: 7E9E2707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003D9484: 7E0E2907
	v_cvt_f32_ubyte0_e32 v80, v8                               // 0000003D9488: 7EA02308
	v_cvt_f32_ubyte1_e32 v81, v8                               // 0000003D948C: 7EA22508
	v_cvt_f32_ubyte2_e32 v82, v8                               // 0000003D9490: 7EA42708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 0000003D9494: 7E102908
	s_waitcnt vmcnt(14)                                        // 0000003D9498: BF893BF7
	v_fma_mix_f32 v10, v10, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D949C: CC20600A 14361B0A
	v_fma_mix_f32 v14, v14, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94A4: CC20600E 14361B0E
	v_fma_mix_f32 v73, v73, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94AC: CC206049 14361B49
	v_fma_mix_f32 v5, v5, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94B4: CC206005 14361B05
	v_fma_mix_f32 v74, v74, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94BC: CC20604A 14361B4A
	v_fma_mix_f32 v75, v75, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94C4: CC20604B 14361B4B
	v_fma_mix_f32 v76, v76, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94CC: CC20604C 14361B4C
	v_fma_mix_f32 v6, v6, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94D4: CC206006 14361B06
	v_fma_mix_f32 v77, v77, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94DC: CC20604D 14361B4D
	v_fma_mix_f32 v78, v78, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94E4: CC20604E 14361B4E
	v_fma_mix_f32 v79, v79, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94EC: CC20604F 14361B4F
	v_fma_mix_f32 v7, v7, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94F4: CC206007 14361B07
	v_fma_mix_f32 v80, v80, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D94FC: CC206050 14361B50
	v_fma_mix_f32 v81, v81, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9504: CC206051 14361B51
	v_fma_mix_f32 v82, v82, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D950C: CC206052 14361B52
	v_fma_mix_f32 v8, v8, v13, v13 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9514: CC206008 14361B08
	v_bfe_u32 v13, v10, 16, 1                                  // 0000003D951C: D610000D 0205210A
	v_bfe_u32 v87, v14, 16, 1                                  // 0000003D9524: D6100057 0205210E
	v_bfe_u32 v88, v73, 16, 1                                  // 0000003D952C: D6100058 02052149
	.long 0x7f123880                                           // 0000003D9534: 7F123880
	v_bfe_u32 v89, v5, 16, 1                                   // 0000003D9538: D6100059 02052105
	v_add3_u32 v10, v10, v13, 0x7fff                           // 0000003D9540: D655000A 03FE1B0A 00007FFF
	v_bfe_u32 v90, v74, 16, 1                                  // 0000003D954C: D610005A 0205214A
	v_add3_u32 v14, v14, v87, 0x7fff                           // 0000003D9554: D655000E 03FEAF0E 00007FFF
	v_add3_u32 v73, v73, v88, 0x7fff                           // 0000003D9560: D6550049 03FEB149 00007FFF
	.long 0x7fa63989                                           // 0000003D956C: 7FA63989
	.long 0x7e12398a                                           // 0000003D9570: 7E12398A
	v_bfe_u32 v91, v75, 16, 1                                  // 0000003D9574: D610005B 0205214B
	v_bfe_u32 v92, v76, 16, 1                                  // 0000003D957C: D610005C 0205214C
	v_add3_u32 v5, v5, v89, 0x7fff                             // 0000003D9584: D6550005 03FEB305 00007FFF
	v_add3_u32 v74, v74, v90, 0x7fff                           // 0000003D9590: D655004A 03FEB54A 00007FFF
	v_and_or_b32 v14, 0xffff0000, v14, v9                      // 0000003D959C: D657000E 04261CFF FFFF0000
	.long 0x7ea639c9                                           // 0000003D95A8: 7EA639C9
	v_bfe_u32 v93, v6, 16, 1                                   // 0000003D95AC: D610005D 02052106
	v_bfe_u32 v94, v77, 16, 1                                  // 0000003D95B4: D610005E 0205214D
	v_add3_u32 v75, v75, v91, 0x7fff                           // 0000003D95BC: D655004B 03FEB74B 00007FFF
	v_add3_u32 v76, v76, v92, 0x7fff                           // 0000003D95C8: D655004C 03FEB94C 00007FFF
	.long 0x7e1239ca                                           // 0000003D95D4: 7E1239CA
	v_and_or_b32 v5, 0xffff0000, v5, v83                       // 0000003D95D8: D6570005 054E0AFF FFFF0000
	.long 0x7fa83989                                           // 0000003D95E4: 7FA83989
	v_bfe_u32 v95, v78, 16, 1                                  // 0000003D95E8: D610005F 0205214E
	v_bfe_u32 v96, v79, 16, 1                                  // 0000003D95F0: D6100060 0205214F
	v_add3_u32 v6, v6, v93, 0x7fff                             // 0000003D95F8: D6550006 03FEBB06 00007FFF
	v_add3_u32 v10, v77, v94, 0x7fff                           // 0000003D9604: D655000A 03FEBD4D 00007FFF
	v_and_or_b32 v75, 0xffff0000, v75, v9                      // 0000003D9610: D657004B 042696FF FFFF0000
	.long 0x7ea839cc                                           // 0000003D961C: 7EA839CC
	v_bfe_u32 v97, v7, 16, 1                                   // 0000003D9620: D6100061 02052107
	v_bfe_u32 v98, v80, 16, 1                                  // 0000003D9628: D6100062 02052150
	v_add3_u32 v77, v78, v95, 0x7fff                           // 0000003D9630: D655004D 03FEBF4E 00007FFF
	v_add3_u32 v78, v79, v96, 0x7fff                           // 0000003D963C: D655004E 03FEC14F 00007FFF
	.long 0x7e12398a                                           // 0000003D9648: 7E12398A
	v_and_or_b32 v6, 0xffff0000, v6, v84                       // 0000003D964C: D6570006 05520CFF FFFF0000
	.long 0x7faa3989                                           // 0000003D9658: 7FAA3989
	v_bfe_u32 v13, v81, 16, 1                                  // 0000003D965C: D610000D 02052151
	v_bfe_u32 v87, v82, 16, 1                                  // 0000003D9664: D6100057 02052152
	v_add3_u32 v7, v7, v97, 0x7fff                             // 0000003D966C: D6550007 03FEC307 00007FFF
	v_add3_u32 v74, v80, v98, 0x7fff                           // 0000003D9678: D655004A 03FEC550 00007FFF
	.long 0x7eaa39ce                                           // 0000003D9684: 7EAA39CE
	v_and_or_b32 v10, 0xffff0000, v77, v9                      // 0000003D9688: D657000A 04269AFF FFFF0000
	v_bfe_u32 v88, v8, 16, 1                                   // 0000003D9694: D6100058 02052108
	v_add3_u32 v13, v81, v13, 0x7fff                           // 0000003D969C: D655000D 03FE1B51 00007FFF
	v_add3_u32 v79, v82, v87, 0x7fff                           // 0000003D96A8: D655004F 03FEAF52 00007FFF
	.long 0x7e1239ca                                           // 0000003D96B4: 7E1239CA
	v_and_or_b32 v7, 0xffff0000, v7, v85                       // 0000003D96B8: D6570007 05560EFF FFFF0000
	.long 0x7fac3989                                           // 0000003D96C4: 7FAC3989
	v_add3_u32 v8, v8, v88, 0x7fff                             // 0000003D96C8: D6550008 03FEB108 00007FFF
	.long 0x7eac39cf                                           // 0000003D96D4: 7EAC39CF
	v_and_or_b32 v13, 0xffff0000, v13, v9                      // 0000003D96D8: D657000D 04261AFF FFFF0000
	s_mov_b32 s0, exec_lo                                      // 0000003D96E4: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D96E8: BF870002
	v_and_or_b32 v8, 0xffff0000, v8, v86                       // 0000003D96EC: D6570008 055A10FF FFFF0000
	s_waitcnt vmcnt(13)                                        // 0000003D96F8: BF8937F7
	v_dot2_f32_bf16 v17, v17, v14, 0                           // 0000003D96FC: CC1A4011 1A021D11
	s_waitcnt vmcnt(12)                                        // 0000003D9704: BF8933F7
	v_dot2_f32_bf16 v21, v21, v14, 0                           // 0000003D9708: CC1A4015 1A021D15
	s_waitcnt vmcnt(11)                                        // 0000003D9710: BF892FF7
	v_dot2_f32_bf16 v25, v25, v14, 0                           // 0000003D9714: CC1A4019 1A021D19
	s_waitcnt vmcnt(10)                                        // 0000003D971C: BF892BF7
	v_dot2_f32_bf16 v29, v29, v14, 0                           // 0000003D9720: CC1A401D 1A021D1D
	s_waitcnt vmcnt(9)                                         // 0000003D9728: BF8927F7
	v_dot2_f32_bf16 v33, v33, v14, 0                           // 0000003D972C: CC1A4021 1A021D21
	s_waitcnt vmcnt(8)                                         // 0000003D9734: BF8923F7
	v_dot2_f32_bf16 v37, v37, v14, 0                           // 0000003D9738: CC1A4025 1A021D25
	s_waitcnt vmcnt(7)                                         // 0000003D9740: BF891FF7
	v_dot2_f32_bf16 v14, v41, v14, 0                           // 0000003D9744: CC1A400E 1A021D29
	v_dot2_f32_bf16 v17, v18, v5, v17                          // 0000003D974C: CC1A4011 1C460B12
	v_dot2_f32_bf16 v18, v22, v5, v21                          // 0000003D9754: CC1A4012 1C560B16
	v_dot2_f32_bf16 v21, v26, v5, v25                          // 0000003D975C: CC1A4015 1C660B1A
	v_dot2_f32_bf16 v22, v30, v5, v29                          // 0000003D9764: CC1A4016 1C760B1E
	v_dot2_f32_bf16 v25, v34, v5, v33                          // 0000003D976C: CC1A4019 1C860B22
	v_dot2_f32_bf16 v26, v38, v5, v37                          // 0000003D9774: CC1A401A 1C960B26
	v_dot2_f32_bf16 v5, v42, v5, v14                           // 0000003D977C: CC1A4005 1C3A0B2A
	v_dot2_f32_bf16 v14, v19, v75, v17                         // 0000003D9784: CC1A400E 1C469713
	v_dot2_f32_bf16 v17, v23, v75, v18                         // 0000003D978C: CC1A4011 1C4A9717
	v_dot2_f32_bf16 v18, v27, v75, v21                         // 0000003D9794: CC1A4012 1C56971B
	v_dot2_f32_bf16 v19, v31, v75, v22                         // 0000003D979C: CC1A4013 1C5A971F
	v_dot2_f32_bf16 v21, v35, v75, v25                         // 0000003D97A4: CC1A4015 1C669723
	v_dot2_f32_bf16 v22, v39, v75, v26                         // 0000003D97AC: CC1A4016 1C6A9727
	v_dot2_f32_bf16 v5, v43, v75, v5                           // 0000003D97B4: CC1A4005 1C16972B
	v_dot2_f32_bf16 v14, v20, v6, v14                          // 0000003D97BC: CC1A400E 1C3A0D14
	v_dot2_f32_bf16 v17, v24, v6, v17                          // 0000003D97C4: CC1A4011 1C460D18
	v_dot2_f32_bf16 v18, v28, v6, v18                          // 0000003D97CC: CC1A4012 1C4A0D1C
	v_dot2_f32_bf16 v19, v32, v6, v19                          // 0000003D97D4: CC1A4013 1C4E0D20
	v_dot2_f32_bf16 v20, v36, v6, v21                          // 0000003D97DC: CC1A4014 1C560D24
	v_dot2_f32_bf16 v21, v40, v6, v22                          // 0000003D97E4: CC1A4015 1C5A0D28
	v_dot2_f32_bf16 v5, v44, v6, v5                            // 0000003D97EC: CC1A4005 1C160D2C
	s_waitcnt vmcnt(6)                                         // 0000003D97F4: BF891BF7
	v_dot2_f32_bf16 v6, v45, v10, v14                          // 0000003D97F8: CC1A4006 1C3A152D
	s_waitcnt vmcnt(5)                                         // 0000003D9800: BF8917F7
	v_dot2_f32_bf16 v14, v49, v10, v17                         // 0000003D9804: CC1A400E 1C461531
	s_waitcnt vmcnt(4)                                         // 0000003D980C: BF8913F7
	v_dot2_f32_bf16 v17, v53, v10, v18                         // 0000003D9810: CC1A4011 1C4A1535
	s_waitcnt vmcnt(3)                                         // 0000003D9818: BF890FF7
	v_dot2_f32_bf16 v18, v57, v10, v19                         // 0000003D981C: CC1A4012 1C4E1539
	s_waitcnt vmcnt(2)                                         // 0000003D9824: BF890BF7
	v_dot2_f32_bf16 v19, v61, v10, v20                         // 0000003D9828: CC1A4013 1C52153D
	s_waitcnt vmcnt(1)                                         // 0000003D9830: BF8907F7
	v_dot2_f32_bf16 v20, v65, v10, v21                         // 0000003D9834: CC1A4014 1C561541
	s_waitcnt vmcnt(0)                                         // 0000003D983C: BF8903F7
	v_dot2_f32_bf16 v5, v69, v10, v5                           // 0000003D9840: CC1A4005 1C161545
	v_dot2_f32_bf16 v6, v46, v7, v6                            // 0000003D9848: CC1A4006 1C1A0F2E
	v_dot2_f32_bf16 v10, v50, v7, v14                          // 0000003D9850: CC1A400A 1C3A0F32
	v_dot2_f32_bf16 v14, v54, v7, v17                          // 0000003D9858: CC1A400E 1C460F36
	v_dot2_f32_bf16 v17, v58, v7, v18                          // 0000003D9860: CC1A4011 1C4A0F3A
	v_dot2_f32_bf16 v18, v62, v7, v19                          // 0000003D9868: CC1A4012 1C4E0F3E
	v_dot2_f32_bf16 v19, v66, v7, v20                          // 0000003D9870: CC1A4013 1C520F42
	v_dot2_f32_bf16 v5, v70, v7, v5                            // 0000003D9878: CC1A4005 1C160F46
	v_dot2_f32_bf16 v6, v47, v13, v6                           // 0000003D9880: CC1A4006 1C1A1B2F
	v_dot2_f32_bf16 v7, v51, v13, v10                          // 0000003D9888: CC1A4007 1C2A1B33
	v_dot2_f32_bf16 v10, v55, v13, v14                         // 0000003D9890: CC1A400A 1C3A1B37
	v_dot2_f32_bf16 v14, v59, v13, v17                         // 0000003D9898: CC1A400E 1C461B3B
	v_dot2_f32_bf16 v17, v63, v13, v18                         // 0000003D98A0: CC1A4011 1C4A1B3F
	v_dot2_f32_bf16 v18, v67, v13, v19                         // 0000003D98A8: CC1A4012 1C4E1B43
	v_dot2_f32_bf16 v5, v71, v13, v5                           // 0000003D98B0: CC1A4005 1C161B47
	v_dot2_f32_bf16 v6, v48, v8, v6                            // 0000003D98B8: CC1A4006 1C1A1130
	v_dot2_f32_bf16 v7, v52, v8, v7                            // 0000003D98C0: CC1A4007 1C1E1134
	v_dot2_f32_bf16 v19, v56, v8, v10                          // 0000003D98C8: CC1A4013 1C2A1138
	v_dot2_f32_bf16 v14, v60, v8, v14                          // 0000003D98D0: CC1A400E 1C3A113C
	v_dot2_f32_bf16 v17, v64, v8, v17                          // 0000003D98D8: CC1A4011 1C461140
	v_dot2_f32_bf16 v18, v68, v8, v18                          // 0000003D98E0: CC1A4012 1C4A1144
	v_dot2_f32_bf16 v20, v72, v8, v5                           // 0000003D98E8: CC1A4014 1C161148
	v_dual_add_f32 v10, 0, v6 :: v_dual_add_f32 v13, 0, v7     // 0000003D98F0: C9080C80 0A0C0E80
	v_dual_add_f32 v7, 0, v19 :: v_dual_add_f32 v8, 0, v14     // 0000003D98F8: C9082680 07081C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9900: BF870214
	v_dual_add_f32 v5, 0, v17 :: v_dual_add_f32 v6, 0, v18     // 0000003D9904: C9082280 05062480
	v_add_f32_e32 v14, 0, v20                                  // 0000003D990C: 061C2880
	v_cmpx_gt_u32_e32 20, v15                                  // 0000003D9910: 7D981E94
	s_cbranch_execz 339                                        // 0000003D9914: BFA50153 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf+0xb64>
	.long 0xd700013f                                           // 0000003D9918: D700013F
	v_cndmask_b32_e32 v1, s6, v16, vcc_lo                      // 0000003D991C: 02022006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003D9920: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, 0, s1                   // 0000003D9924: D5207C40 00050007
	v_cvt_f32_ubyte0_e32 v71, v1                               // 0000003D992C: 7E8E2301
	.long 0xd7006a43                                           // 0000003D9930: D7006A43
	v_cndmask_b32_e32 v1, 0x200, v63, vcc_lo                   // 0000003D9934: 02027EFF 00000200
	s_clause 0x5                                               // 0000003D993C: BF850005
	global_load_b128 v[15:18], v[63:64], off offset:512        // 0000003D9940: DC5E0200 0F7C003F
	global_load_b128 v[19:22], v[63:64], off offset:1152       // 0000003D9948: DC5E0480 137C003F
	global_load_b128 v[23:26], v[63:64], off offset:1792       // 0000003D9950: DC5E0700 177C003F
	global_load_b128 v[27:30], v[63:64], off offset:2432       // 0000003D9958: DC5E0980 1B7C003F
	global_load_b128 v[31:34], v[63:64], off offset:3072       // 0000003D9960: DC5E0C00 1F7C003F
	global_load_b128 v[35:38], v[63:64], off offset:3712       // 0000003D9968: DC5E0E80 237C003F
	v_add_co_ci_u32_e64 v68, null, 0, v64, vcc_lo              // 0000003D9970: D5207C44 01AA8080
	v_cvt_f32_ubyte1_e32 v72, v1                               // 0000003D9978: 7E902501
	v_cvt_f32_ubyte2_e32 v73, v1                               // 0000003D997C: 7E922701
	s_clause 0x7                                               // 0000003D9980: BF850007
	global_load_b128 v[39:42], v[67:68], off offset:3840       // 0000003D9984: DC5E0F00 277C0043
	global_load_b128 v[43:46], v[63:64], off offset:528        // 0000003D998C: DC5E0210 2B7C003F
	global_load_b128 v[47:50], v[63:64], off offset:1168       // 0000003D9994: DC5E0490 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:1808       // 0000003D999C: DC5E0710 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:2448       // 0000003D99A4: DC5E0990 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:3088       // 0000003D99AC: DC5E0C10 3B7C003F
	global_load_b128 v[63:66], v[63:64], off offset:3728       // 0000003D99B4: DC5E0E90 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:3856       // 0000003D99BC: DC5E0F10 437C0043
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003D99C4: 7E022901
	v_cvt_f32_ubyte0_e32 v75, v2                               // 0000003D99C8: 7E962302
	v_cvt_f32_ubyte1_e32 v76, v2                               // 0000003D99CC: 7E982502
	v_cvt_f32_ubyte2_e32 v77, v2                               // 0000003D99D0: 7E9A2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 0000003D99D4: 7E042902
	v_cvt_f32_ubyte0_e32 v78, v3                               // 0000003D99D8: 7E9C2303
	v_cvt_f32_ubyte1_e32 v79, v3                               // 0000003D99DC: 7E9E2503
	v_cvt_f32_ubyte2_e32 v80, v3                               // 0000003D99E0: 7EA02703
	v_cvt_f32_ubyte3_e32 v3, v3                                // 0000003D99E4: 7E062903
	v_cvt_f32_ubyte0_e32 v81, v4                               // 0000003D99E8: 7EA22304
	v_cvt_f32_ubyte1_e32 v82, v4                               // 0000003D99EC: 7EA42504
	v_cvt_f32_ubyte2_e32 v83, v4                               // 0000003D99F0: 7EA62704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 0000003D99F4: 7E082904
	v_fma_mix_f32 v71, v71, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D99F8: CC206047 14321947
	v_fma_mix_f32 v72, v72, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A00: CC206048 14321948
	v_fma_mix_f32 v73, v73, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A08: CC206049 14321949
	v_fma_mix_f32 v1, v1, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A10: CC206001 14321901
	v_fma_mix_f32 v75, v75, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A18: CC20604B 1432194B
	v_fma_mix_f32 v76, v76, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A20: CC20604C 1432194C
	v_fma_mix_f32 v77, v77, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A28: CC20604D 1432194D
	v_fma_mix_f32 v2, v2, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A30: CC206002 14321902
	v_fma_mix_f32 v78, v78, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A38: CC20604E 1432194E
	v_fma_mix_f32 v79, v79, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A40: CC20604F 1432194F
	v_fma_mix_f32 v80, v80, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A48: CC206050 14321950
	v_fma_mix_f32 v3, v3, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A50: CC206003 14321903
	v_fma_mix_f32 v81, v81, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A58: CC206051 14321951
	v_fma_mix_f32 v82, v82, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A60: CC206052 14321952
	v_fma_mix_f32 v83, v83, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A68: CC206053 14321953
	v_fma_mix_f32 v4, v4, v12, v12 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003D9A70: CC206004 14321904
	v_bfe_u32 v12, v71, 16, 1                                  // 0000003D9A78: D610000C 02052147
	v_bfe_u32 v87, v72, 16, 1                                  // 0000003D9A80: D6100057 02052148
	v_bfe_u32 v88, v73, 16, 1                                  // 0000003D9A88: D6100058 02052149
	v_bfe_u32 v89, v1, 16, 1                                   // 0000003D9A90: D6100059 02052101
	.long 0x7f943989                                           // 0000003D9A98: 7F943989
	v_add3_u32 v12, v71, v12, 0x7fff                           // 0000003D9A9C: D655000C 03FE1947 00007FFF
	v_add3_u32 v71, v72, v87, 0x7fff                           // 0000003D9AA8: D6550047 03FEAF48 00007FFF
	v_add3_u32 v72, v73, v88, 0x7fff                           // 0000003D9AB4: D6550048 03FEB149 00007FFF
	v_bfe_u32 v90, v75, 16, 1                                  // 0000003D9AC0: D610005A 0205214B
	v_add3_u32 v1, v1, v89, 0x7fff                             // 0000003D9AC8: D6550001 03FEB301 00007FFF
	.long 0x7e12398c                                           // 0000003D9AD4: 7E12398C
	v_bfe_u32 v91, v76, 16, 1                                  // 0000003D9AD8: D610005B 0205214C
	.long 0x7e9439c8                                           // 0000003D9AE0: 7E9439C8
	v_bfe_u32 v92, v77, 16, 1                                  // 0000003D9AE4: D610005C 0205214D
	v_add3_u32 v73, v75, v90, 0x7fff                           // 0000003D9AEC: D6550049 03FEB54B 00007FFF
	v_and_or_b32 v71, 0xffff0000, v71, v9                      // 0000003D9AF8: D6570047 04268EFF FFFF0000
	v_bfe_u32 v93, v2, 16, 1                                   // 0000003D9B04: D610005D 02052102
	v_and_or_b32 v1, 0xffff0000, v1, v74                       // 0000003D9B0C: D6570001 052A02FF FFFF0000
	v_bfe_u32 v94, v78, 16, 1                                  // 0000003D9B18: D610005E 0205214E
	v_add3_u32 v75, v76, v91, 0x7fff                           // 0000003D9B20: D655004B 03FEB74C 00007FFF
	v_add3_u32 v76, v77, v92, 0x7fff                           // 0000003D9B2C: D655004C 03FEB94D 00007FFF
	.long 0x7e1239c9                                           // 0000003D9B38: 7E1239C9
	.long 0x7fa83989                                           // 0000003D9B3C: 7FA83989
	v_bfe_u32 v95, v79, 16, 1                                  // 0000003D9B40: D610005F 0205214F
	v_bfe_u32 v96, v80, 16, 1                                  // 0000003D9B48: D6100060 02052150
	v_add3_u32 v2, v2, v93, 0x7fff                             // 0000003D9B50: D6550002 03FEBB02 00007FFF
	v_add3_u32 v12, v78, v94, 0x7fff                           // 0000003D9B5C: D655000C 03FEBD4E 00007FFF
	v_and_or_b32 v75, 0xffff0000, v75, v9                      // 0000003D9B68: D657004B 042696FF FFFF0000
	.long 0x7ea839cc                                           // 0000003D9B74: 7EA839CC
	v_bfe_u32 v97, v3, 16, 1                                   // 0000003D9B78: D6100061 02052103
	v_bfe_u32 v98, v81, 16, 1                                  // 0000003D9B80: D6100062 02052151
	v_add3_u32 v77, v79, v95, 0x7fff                           // 0000003D9B88: D655004D 03FEBF4F 00007FFF
	v_add3_u32 v78, v80, v96, 0x7fff                           // 0000003D9B94: D655004E 03FEC150 00007FFF
	.long 0x7e12398c                                           // 0000003D9BA0: 7E12398C
	v_and_or_b32 v2, 0xffff0000, v2, v84                       // 0000003D9BA4: D6570002 055204FF FFFF0000
	.long 0x7faa3989                                           // 0000003D9BB0: 7FAA3989
	v_bfe_u32 v99, v82, 16, 1                                  // 0000003D9BB4: D6100063 02052152
	v_bfe_u32 v100, v83, 16, 1                                 // 0000003D9BBC: D6100064 02052153
	v_add3_u32 v3, v3, v97, 0x7fff                             // 0000003D9BC4: D6550003 03FEC303 00007FFF
	v_add3_u32 v73, v81, v98, 0x7fff                           // 0000003D9BD0: D6550049 03FEC551 00007FFF
	.long 0x7eaa39ce                                           // 0000003D9BDC: 7EAA39CE
	v_and_or_b32 v12, 0xffff0000, v77, v9                      // 0000003D9BE0: D657000C 04269AFF FFFF0000
	v_bfe_u32 v101, v4, 16, 1                                  // 0000003D9BEC: D6100065 02052104
	v_add3_u32 v79, v82, v99, 0x7fff                           // 0000003D9BF4: D655004F 03FEC752 00007FFF
	v_add3_u32 v80, v83, v100, 0x7fff                          // 0000003D9C00: D6550050 03FEC953 00007FFF
	.long 0x7e1239c9                                           // 0000003D9C0C: 7E1239C9
	v_and_or_b32 v3, 0xffff0000, v3, v85                       // 0000003D9C10: D6570003 055606FF FFFF0000
	.long 0x7fac3989                                           // 0000003D9C1C: 7FAC3989
	v_add3_u32 v4, v4, v101, 0x7fff                            // 0000003D9C20: D6550004 03FECB04 00007FFF
	.long 0x7eac39d0                                           // 0000003D9C2C: 7EAC39D0
	v_and_or_b32 v9, 0xffff0000, v79, v9                       // 0000003D9C30: D6570009 04269EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003D9C3C: BF870002
	v_and_or_b32 v4, 0xffff0000, v4, v86                       // 0000003D9C40: D6570004 055A08FF FFFF0000
	s_waitcnt vmcnt(13)                                        // 0000003D9C4C: BF8937F7
	v_dot2_f32_bf16 v15, v15, v71, 0                           // 0000003D9C50: CC1A400F 1A028F0F
	s_waitcnt vmcnt(12)                                        // 0000003D9C58: BF8933F7
	v_dot2_f32_bf16 v19, v19, v71, 0                           // 0000003D9C5C: CC1A4013 1A028F13
	s_waitcnt vmcnt(11)                                        // 0000003D9C64: BF892FF7
	v_dot2_f32_bf16 v23, v23, v71, 0                           // 0000003D9C68: CC1A4017 1A028F17
	s_waitcnt vmcnt(10)                                        // 0000003D9C70: BF892BF7
	v_dot2_f32_bf16 v27, v27, v71, 0                           // 0000003D9C74: CC1A401B 1A028F1B
	s_waitcnt vmcnt(9)                                         // 0000003D9C7C: BF8927F7
	v_dot2_f32_bf16 v31, v31, v71, 0                           // 0000003D9C80: CC1A401F 1A028F1F
	s_waitcnt vmcnt(8)                                         // 0000003D9C88: BF8923F7
	v_dot2_f32_bf16 v35, v35, v71, 0                           // 0000003D9C8C: CC1A4023 1A028F23
	v_dot2_f32_bf16 v15, v16, v1, v15                          // 0000003D9C94: CC1A400F 1C3E0310
	v_dot2_f32_bf16 v16, v20, v1, v19                          // 0000003D9C9C: CC1A4010 1C4E0314
	v_dot2_f32_bf16 v20, v28, v1, v27                          // 0000003D9CA4: CC1A4014 1C6E031C
	s_waitcnt vmcnt(7)                                         // 0000003D9CAC: BF891FF7
	v_dot2_f32_bf16 v27, v39, v71, 0                           // 0000003D9CB0: CC1A401B 1A028F27
	v_dot2_f32_bf16 v19, v24, v1, v23                          // 0000003D9CB8: CC1A4013 1C5E0318
	v_dot2_f32_bf16 v23, v32, v1, v31                          // 0000003D9CC0: CC1A4017 1C7E0320
	v_dot2_f32_bf16 v24, v36, v1, v35                          // 0000003D9CC8: CC1A4018 1C8E0324
	v_dot2_f32_bf16 v15, v17, v75, v15                         // 0000003D9CD0: CC1A400F 1C3E9711
	v_dot2_f32_bf16 v1, v40, v1, v27                           // 0000003D9CD8: CC1A4001 1C6E0328
	v_dot2_f32_bf16 v16, v21, v75, v16                         // 0000003D9CE0: CC1A4010 1C429715
	v_dot2_f32_bf16 v17, v25, v75, v19                         // 0000003D9CE8: CC1A4011 1C4E9719
	v_dot2_f32_bf16 v19, v29, v75, v20                         // 0000003D9CF0: CC1A4013 1C52971D
	v_dot2_f32_bf16 v20, v33, v75, v23                         // 0000003D9CF8: CC1A4014 1C5E9721
	v_dot2_f32_bf16 v21, v37, v75, v24                         // 0000003D9D00: CC1A4015 1C629725
	v_dot2_f32_bf16 v1, v41, v75, v1                           // 0000003D9D08: CC1A4001 1C069729
	v_dot2_f32_bf16 v15, v18, v2, v15                          // 0000003D9D10: CC1A400F 1C3E0512
	v_dot2_f32_bf16 v16, v22, v2, v16                          // 0000003D9D18: CC1A4010 1C420516
	v_dot2_f32_bf16 v17, v26, v2, v17                          // 0000003D9D20: CC1A4011 1C46051A
	v_dot2_f32_bf16 v18, v30, v2, v19                          // 0000003D9D28: CC1A4012 1C4E051E
	v_dot2_f32_bf16 v19, v34, v2, v20                          // 0000003D9D30: CC1A4013 1C520522
	v_dot2_f32_bf16 v20, v38, v2, v21                          // 0000003D9D38: CC1A4014 1C560526
	v_dot2_f32_bf16 v1, v42, v2, v1                            // 0000003D9D40: CC1A4001 1C06052A
	s_waitcnt vmcnt(6)                                         // 0000003D9D48: BF891BF7
	v_dot2_f32_bf16 v15, v43, v12, v15                         // 0000003D9D4C: CC1A400F 1C3E192B
	s_waitcnt vmcnt(5)                                         // 0000003D9D54: BF8917F7
	v_dot2_f32_bf16 v16, v47, v12, v16                         // 0000003D9D58: CC1A4010 1C42192F
	s_waitcnt vmcnt(4)                                         // 0000003D9D60: BF8913F7
	v_dot2_f32_bf16 v17, v51, v12, v17                         // 0000003D9D64: CC1A4011 1C461933
	s_waitcnt vmcnt(3)                                         // 0000003D9D6C: BF890FF7
	v_dot2_f32_bf16 v18, v55, v12, v18                         // 0000003D9D70: CC1A4012 1C4A1937
	s_waitcnt vmcnt(2)                                         // 0000003D9D78: BF890BF7
	v_dot2_f32_bf16 v19, v59, v12, v19                         // 0000003D9D7C: CC1A4013 1C4E193B
	s_waitcnt vmcnt(1)                                         // 0000003D9D84: BF8907F7
	v_dot2_f32_bf16 v20, v63, v12, v20                         // 0000003D9D88: CC1A4014 1C52193F
	s_waitcnt vmcnt(0)                                         // 0000003D9D90: BF8903F7
	v_dot2_f32_bf16 v1, v67, v12, v1                           // 0000003D9D94: CC1A4001 1C061943
	v_dot2_f32_bf16 v2, v44, v3, v15                           // 0000003D9D9C: CC1A4002 1C3E072C
	v_dot2_f32_bf16 v15, v48, v3, v16                          // 0000003D9DA4: CC1A400F 1C420730
	v_dot2_f32_bf16 v16, v52, v3, v17                          // 0000003D9DAC: CC1A4010 1C460734
	v_dot2_f32_bf16 v17, v56, v3, v18                          // 0000003D9DB4: CC1A4011 1C4A0738
	v_dot2_f32_bf16 v18, v60, v3, v19                          // 0000003D9DBC: CC1A4012 1C4E073C
	v_dot2_f32_bf16 v19, v64, v3, v20                          // 0000003D9DC4: CC1A4013 1C520740
	v_dot2_f32_bf16 v1, v68, v3, v1                            // 0000003D9DCC: CC1A4001 1C060744
	v_dot2_f32_bf16 v2, v45, v9, v2                            // 0000003D9DD4: CC1A4002 1C0A132D
	v_dot2_f32_bf16 v12, v49, v9, v15                          // 0000003D9DDC: CC1A400C 1C3E1331
	v_dot2_f32_bf16 v15, v53, v9, v16                          // 0000003D9DE4: CC1A400F 1C421335
	v_dot2_f32_bf16 v16, v57, v9, v17                          // 0000003D9DEC: CC1A4010 1C461339
	v_dot2_f32_bf16 v17, v61, v9, v18                          // 0000003D9DF4: CC1A4011 1C4A133D
	v_dot2_f32_bf16 v18, v65, v9, v19                          // 0000003D9DFC: CC1A4012 1C4E1341
	v_dot2_f32_bf16 v1, v69, v9, v1                            // 0000003D9E04: CC1A4001 1C061345
	v_dot2_f32_bf16 v2, v46, v4, v2                            // 0000003D9E0C: CC1A4002 1C0A092E
	v_dot2_f32_bf16 v3, v50, v4, v12                           // 0000003D9E14: CC1A4003 1C320932
	v_dot2_f32_bf16 v12, v54, v4, v15                          // 0000003D9E1C: CC1A400C 1C3E0936
	v_dot2_f32_bf16 v15, v58, v4, v16                          // 0000003D9E24: CC1A400F 1C42093A
	v_dot2_f32_bf16 v9, v62, v4, v17                           // 0000003D9E2C: CC1A4009 1C46093E
	v_dot2_f32_bf16 v16, v66, v4, v18                          // 0000003D9E34: CC1A4010 1C4A0942
	v_dot2_f32_bf16 v1, v70, v4, v1                            // 0000003D9E3C: CC1A4001 1C060946
	v_dual_add_f32 v10, v10, v2 :: v_dual_add_f32 v13, v13, v3 // 0000003D9E44: C908050A 0A0C070D
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v8, v15   // 0000003D9E4C: C9081907 07081F08
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003D9E54: BF870214
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v6, v16    // 0000003D9E58: C9081305 05062106
	v_add_f32_e32 v14, v14, v1                                 // 0000003D9E60: 061C030E
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003D9E64: 8C7E007E
	.long 0xd71f0001                                           // 0000003D9E68: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003D9E6C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000003D9E70: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003D9E74: BF870121
	v_xor_b32_e32 v2, 8, v1                                    // 0000003D9E78: 3A040288
	v_xor_b32_e32 v17, 4, v1                                   // 0000003D9E7C: 3A220284
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000003D9E80: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000003D9E84: 02040501
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003D9E88: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000003D9E8C: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 0000003D9E90: 02222301
	v_lshlrev_b32_e32 v17, 2, v17                              // 0000003D9E94: 30222282
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003D9E98: BF870004
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000003D9E9C: 30040482
	ds_bpermute_b32 v3, v2, v14                                // 0000003D9EA0: DACC0000 03000E02
	s_waitcnt lgkmcnt(0)                                       // 0000003D9EA8: BF89FC07
	v_add_f32_e32 v3, v14, v3                                  // 0000003D9EAC: 0606070E
	ds_bpermute_b32 v4, v2, v13                                // 0000003D9EB0: DACC0000 04000D02
	ds_bpermute_b32 v9, v2, v10                                // 0000003D9EB8: DACC0000 09000A02
	ds_bpermute_b32 v12, v2, v8                                // 0000003D9EC0: DACC0000 0C000802
	ds_bpermute_b32 v15, v2, v7                                // 0000003D9EC8: DACC0000 0F000702
	ds_bpermute_b32 v16, v2, v6                                // 0000003D9ED0: DACC0000 10000602
	ds_bpermute_b32 v2, v2, v5                                 // 0000003D9ED8: DACC0000 02000502
	s_waitcnt lgkmcnt(4)                                       // 0000003D9EE0: BF89FC47
	v_dual_add_f32 v4, v13, v4 :: v_dual_add_f32 v9, v10, v9   // 0000003D9EE4: C908090D 0408130A
	s_waitcnt lgkmcnt(2)                                       // 0000003D9EEC: BF89FC27
	v_dual_add_f32 v8, v8, v12 :: v_dual_add_f32 v7, v7, v15   // 0000003D9EF0: C9081908 08061F07
	s_waitcnt lgkmcnt(1)                                       // 0000003D9EF8: BF89FC17
	v_add_f32_e32 v6, v6, v16                                  // 0000003D9EFC: 060C2106
	s_waitcnt lgkmcnt(0)                                       // 0000003D9F00: BF89FC07
	v_add_f32_e32 v2, v5, v2                                   // 0000003D9F04: 06040505
	ds_bpermute_b32 v5, v17, v3                                // 0000003D9F08: DACC0000 05000311
	ds_bpermute_b32 v10, v17, v4                               // 0000003D9F10: DACC0000 0A000411
	ds_bpermute_b32 v12, v17, v9                               // 0000003D9F18: DACC0000 0C000911
	ds_bpermute_b32 v13, v17, v8                               // 0000003D9F20: DACC0000 0D000811
	ds_bpermute_b32 v14, v17, v7                               // 0000003D9F28: DACC0000 0E000711
	ds_bpermute_b32 v15, v17, v6                               // 0000003D9F30: DACC0000 0F000611
	ds_bpermute_b32 v16, v17, v2                               // 0000003D9F38: DACC0000 10000211
	v_xor_b32_e32 v17, 2, v1                                   // 0000003D9F40: 3A220282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003D9F44: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v17                           // 0000003D9F48: 7C9822A0
	v_cndmask_b32_e32 v17, v1, v17, vcc_lo                     // 0000003D9F4C: 02222301
	s_waitcnt lgkmcnt(5)                                       // 0000003D9F50: BF89FC57
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v10    // 0000003D9F54: C9080B03 03041504
	v_lshlrev_b32_e32 v17, 2, v17                              // 0000003D9F5C: 30222282
	s_waitcnt lgkmcnt(3)                                       // 0000003D9F60: BF89FC37
	v_dual_add_f32 v5, v9, v12 :: v_dual_add_f32 v8, v8, v13   // 0000003D9F64: C9081909 05081B08
	s_waitcnt lgkmcnt(0)                                       // 0000003D9F6C: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v16   // 0000003D9F70: C9081D07 07022102
	v_add_f32_e32 v12, v6, v15                                 // 0000003D9F78: 06181F06
	ds_bpermute_b32 v6, v17, v4                                // 0000003D9F7C: DACC0000 06000411
	ds_bpermute_b32 v10, v17, v5                               // 0000003D9F84: DACC0000 0A000511
	ds_bpermute_b32 v13, v17, v8                               // 0000003D9F8C: DACC0000 0D000811
	ds_bpermute_b32 v14, v17, v7                               // 0000003D9F94: DACC0000 0E000711
	ds_bpermute_b32 v15, v17, v12                              // 0000003D9F9C: DACC0000 0F000C11
	ds_bpermute_b32 v16, v17, v2                               // 0000003D9FA4: DACC0000 10000211
	ds_bpermute_b32 v17, v17, v3                               // 0000003D9FAC: DACC0000 11000311
	v_xor_b32_e32 v9, 1, v1                                    // 0000003D9FB4: 3A120281
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003D9FB8: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000003D9FBC: 7C9812A0
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000003D9FC0: 02021301
	s_waitcnt lgkmcnt(6)                                       // 0000003D9FC4: BF89FC67
	v_add_f32_e32 v9, v4, v6                                   // 0000003D9FC8: 06120D04
	s_waitcnt lgkmcnt(4)                                       // 0000003D9FCC: BF89FC47
	v_dual_add_f32 v10, v5, v10 :: v_dual_add_f32 v5, v8, v13  // 0000003D9FD0: C9081505 0A041B08
	s_waitcnt lgkmcnt(3)                                       // 0000003D9FD8: BF89FC37
	v_add_f32_e32 v6, v7, v14                                  // 0000003D9FDC: 060C1D07
	s_waitcnt lgkmcnt(2)                                       // 0000003D9FE0: BF89FC27
	v_dual_add_f32 v1, v12, v15 :: v_dual_lshlrev_b32 v18, 2, v1// 0000003D9FE4: C9221F0C 01120282
	s_waitcnt lgkmcnt(1)                                       // 0000003D9FEC: BF89FC17
	v_add_f32_e32 v2, v2, v16                                  // 0000003D9FF0: 06042102
	s_waitcnt lgkmcnt(0)                                       // 0000003D9FF4: BF89FC07
	v_add_f32_e32 v12, v3, v17                                 // 0000003D9FF8: 06182303
	ds_bpermute_b32 v13, v18, v10                              // 0000003D9FFC: DACC0000 0D000A12
	ds_bpermute_b32 v14, v18, v9                               // 0000003DA004: DACC0000 0E000912
	ds_bpermute_b32 v7, v18, v6                                // 0000003DA00C: DACC0000 07000612
	ds_bpermute_b32 v8, v18, v5                                // 0000003DA014: DACC0000 08000512
	ds_bpermute_b32 v4, v18, v2                                // 0000003DA01C: DACC0000 04000212
	ds_bpermute_b32 v3, v18, v1                                // 0000003DA024: DACC0000 03000112
	ds_bpermute_b32 v15, v18, v12                              // 0000003DA02C: DACC0000 0F000C12
	v_cmpx_eq_u32_e32 0, v11                                   // 0000003DA034: 7D941680
	s_cbranch_execz 59                                         // 0000003DA038: BFA5003B <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf+0xe28>
	s_waitcnt lgkmcnt(5)                                       // 0000003DA03C: BF89FC57
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v10, v10, v13 // 0000003DA040: C9081D09 090A1B0A
	.long 0x7f1a3880                                           // 0000003DA048: 7F1A3880
	s_waitcnt lgkmcnt(1)                                       // 0000003DA04C: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v3, v1, v3     // 0000003DA050: C9080902 02020701
	s_waitcnt lgkmcnt(0)                                       // 0000003DA058: BF89FC07
	v_dual_add_f32 v12, v12, v15 :: v_dual_add_f32 v5, v5, v8  // 0000003DA05C: C9081F0C 0C041105
	.long 0x7e1a3989                                           // 0000003DA064: 7E1A3989
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003DA068: BF870003
	.long 0x7e023982                                           // 0000003DA06C: 7E023982
	.long 0x7f02398d                                           // 0000003DA070: 7F02398D
	v_add_f32_e32 v6, v6, v7                                   // 0000003DA074: 060C0F06
	.long 0x7e1c398a                                           // 0000003DA078: 7E1C398A
	.long 0x7f1c398d                                           // 0000003DA07C: 7F1C398D
	v_and_b32_e32 v4, 1, v13                                   // 0000003DA080: 36081A81
	.long 0x7e1a3985                                           // 0000003DA084: 7E1A3985
	.long 0x7f0e398d                                           // 0000003DA088: 7F0E398D
	v_and_b32_e32 v15, 1, v1                                   // 0000003DA08C: 361E0281
	.long 0x7e0e3986                                           // 0000003DA090: 7E0E3986
	v_and_b32_e32 v8, 1, v14                                   // 0000003DA094: 36101C81
	v_and_b32_e32 v14, 1, v13                                  // 0000003DA098: 361C1A81
	.long 0x7e1a3983                                           // 0000003DA09C: 7E1A3983
	v_add3_u32 v1, v9, v4, 0x7fff                              // 0000003DA0A0: D6550001 03FE0909 00007FFF
	v_and_b32_e32 v7, 1, v7                                    // 0000003DA0AC: 360E0E81
	v_lshrrev_b32_e32 v11, 4, v0                               // 0000003DA0B0: 32160084
	v_add3_u32 v8, v10, v8, 0x7fff                             // 0000003DA0B4: D6550008 03FE110A 00007FFF
	v_and_b32_e32 v4, 1, v13                                   // 0000003DA0C0: 36081A81
	v_add3_u32 v9, v2, v15, 0x7fff                             // 0000003DA0C4: D6550009 03FE1F02 00007FFF
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000003DA0D0: D6550006 03FE0F06 00007FFF
	v_add3_u32 v2, v5, v14, 0x7fff                             // 0000003DA0DC: D6550002 03FE1D05 00007FFF
	v_bfe_u32 v5, v12, 16, 1                                   // 0000003DA0E8: D6100005 0205210C
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000003DA0F0: D6550003 03FE0903 00007FFF
	v_mul_u32_u24_e32 v11, 14, v11                             // 0000003DA0FC: 1616168E
	.long 0x7e063989                                           // 0000003DA100: 7E063989
	.long 0x7e043986                                           // 0000003DA104: 7E043986
	.long 0x7e023988                                           // 0000003DA108: 7E023988
	v_add3_u32 v4, v12, v5, 0x7fff                             // 0000003DA10C: D6550004 03FE0B0C 00007FFF
	ds_store_b96 v11, v[1:3]                                   // 0000003DA118: DB780000 0000010B
	ds_store_b16_d16_hi v11, v4 offset:12                      // 0000003DA120: DA84000C 0000040B
	s_or_b32 exec_lo, exec_lo, s0                              // 0000003DA128: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000003DA12C: BF89FC07
	s_barrier                                                  // 0000003DA130: BFBD0000
	buffer_gl0_inv                                             // 0000003DA134: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003DA13C: BE80007E
	v_cmpx_gt_u32_e32 28, v0                                   // 0000003DA140: 7D98009C
	s_cbranch_execz 272                                        // 0000003DA144: BFA50110 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf+0x1288>
	.long 0xd7054000                                           // 0000003DA148: D7054000
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000003DA14C: 02014B00
	.long 0x7f143880                                           // 0000003DA150: 7F143880
	s_cmp_eq_u64 s[4:5], 0                                     // 0000003DA154: BF108004
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA158: BF870092
	.long 0xd7395000                                           // 0000003DA15C: D7395000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000003DA160: 02020088
	.long 0xd7041001                                           // 0000003DA164: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003DA168: 02020100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA16C: BF870091
	.long 0xd7390001                                           // 0000003DA170: D7390001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003DA174: 02020281
	.long 0xd7620001                                           // 0000003DA178: D7620001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000003DA17C: 020202FF 0000007F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA184: BF870091
	.long 0xd7035000                                           // 0000003DA188: D7035000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000003DA18C: 02020101
	.long 0xd739100a                                           // 0000003DA190: D739100A
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003DA194: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA198: BF870091
	.long 0xd7054000                                           // 0000003DA19C: D7054000
	v_cndmask_b32_e32 v0, v10, v135, vcc_lo                    // 0000003DA1A0: 02010F0A
	.long 0xd7041001                                           // 0000003DA1A4: D7041001
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000003DA1A8: 02020100
	v_add_nc_u32_e32 v0, s2, v10                               // 0000003DA1AC: 4A001402
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA1B0: BF870112
	v_and_b32_e32 v11, 0xff, v1                                // 0000003DA1B4: 361602FF 000000FF
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000003DA1BC: 3402009F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA1C0: BF870112
	v_mad_u64_u32 v[2:3], null, 0x5000, v11, s[8:9]            // 0000003DA1C4: D6FE7C02 002216FF 00005000
	.long 0xd73c0004                                           // 0000003DA1D0: D73C0004
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003DA1D4: 02020081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA1D8: BF870091
	.long 0xd7006a02                                           // 0000003DA1DC: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000003DA1E0: 02020902
	v_add_co_ci_u32_e64 v3, null, v3, v5, vcc_lo               // 0000003DA1E4: D5207C03 01AA0B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA1EC: BF870092
	.long 0xd7006a04                                           // 0000003DA1F0: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000003DA1F4: 020204FF 00002000
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000003DA1FC: D5207C05 01AA0680
	.long 0xd7006a06                                           // 0000003DA204: D7006A06
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000003DA208: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003DA210: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000003DA214: D5207C07 01AA0680
	.long 0xd7006a08                                           // 0000003DA21C: D7006A08
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000003DA220: 020204FF 00001000
	v_add_co_ci_u32_e64 v9, null, 0, v3, vcc_lo                // 0000003DA228: D5207C09 01AA0680
	s_clause 0x3                                               // 0000003DA230: BF850003
	global_load_u16 v4, v[4:5], off offset:2048                // 0000003DA234: DC4A0800 047C0004
	global_load_u16 v5, v[6:7], off offset:3072                // 0000003DA23C: DC4A0C00 057C0006
	global_load_u16 v2, v[2:3], off                            // 0000003DA244: DC4A0000 027C0002
	global_load_u16 v3, v[8:9], off offset:1024                // 0000003DA24C: DC4A0400 037C0008
	v_mul_u32_u24_e32 v6, 56, v10                              // 0000003DA254: 160C14B8
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DA258: BF870001
	v_lshl_add_u32 v6, v11, 1, v6                              // 0000003DA25C: D6460006 0419030B
	ds_load_u16 v7, v6                                         // 0000003DA264: D8F00000 07000006
	ds_load_u16 v8, v6 offset:14                               // 0000003DA26C: D8F0000E 08000006
	ds_load_u16 v9, v6 offset:28                               // 0000003DA274: D8F0001C 09000006
	ds_load_u16 v6, v6 offset:42                               // 0000003DA27C: D8F0002A 06000006
	s_waitcnt lgkmcnt(0)                                       // 0000003DA284: BF89FC07
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000003DA288: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA28C: BF870091
	v_dual_mul_f32 v6, 0xbfb8aa3b, v6 :: v_dual_lshlrev_b32 v9, 16, v9// 0000003DA290: C8E20CFF 06081290 BFB8AA3B
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_lshlrev_b32 v8, 16, v8// 0000003DA29C: C8E212FF 09081090 BFB8AA3B
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000003DA2A8: 300E0E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA2AC: BF870113
	v_exp_f32_e32 v6, v6                                       // 0000003DA2B0: 7E0C4B06
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000003DA2B4: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA2BC: BF870113
	v_exp_f32_e32 v9, v9                                       // 0000003DA2C0: 7E124B09
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 0000003DA2C4: 100E0EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA2CC: BF870092
	v_exp_f32_e32 v8, v8                                       // 0000003DA2D0: 7E104B08
	v_exp_f32_e32 v7, v7                                       // 0000003DA2D4: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA2D8: BF870097
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_add_f32 v9, 1.0, v9   // 0000003DA2DC: C9080CF2 060812F2
	v_div_scale_f32 v14, null, v6, v6, 1.0                     // 0000003DA2E4: D6FC7C0E 03CA0D06
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA2EC: BF870196
	v_add_f32_e32 v8, 1.0, v8                                  // 0000003DA2F0: 061010F2
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 0000003DA2F4: D6FC7C0D 03CA1309
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000003DA2FC: BF870005
	v_add_f32_e32 v7, 1.0, v7                                  // 0000003DA300: 060E0EF2
	v_div_scale_f32 v24, s1, 1.0, v9, 1.0                      // 0000003DA304: D6FC0118 03CA12F2
	v_rcp_f32_e32 v18, v14                                     // 0000003DA30C: 7E24550E
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 0000003DA310: D6FC7C0C 03CA1108
	v_rcp_f32_e32 v17, v13                                     // 0000003DA318: 7E22550D
	v_div_scale_f32 v10, null, v7, v7, 1.0                     // 0000003DA31C: D6FC7C0A 03CA0F07
	v_div_scale_f32 v19, vcc_lo, 1.0, v7, 1.0                  // 0000003DA324: D6FC6A13 03CA0EF2
	v_div_scale_f32 v20, s0, 1.0, v8, 1.0                      // 0000003DA32C: D6FC0014 03CA10F2
	v_rcp_f32_e32 v16, v12                                     // 0000003DA334: 7E20550C
	v_mad_u64_u32 v[0:1], null, 0xa00, v11, v[0:1]             // 0000003DA338: D6FE7C00 040216FF 00000A00
	v_rcp_f32_e32 v15, v10                                     // 0000003DA344: 7E1E550A
	v_fma_f32 v25, -v14, v18, 1.0                              // 0000003DA348: D6130019 23CA250E
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA350: BF870117
	v_fma_f32 v23, -v13, v17, 1.0                              // 0000003DA354: D6130017 23CA230D
	v_fmac_f32_e32 v18, v25, v18                               // 0000003DA35C: 56242519
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA360: BF870196
	v_fma_f32 v22, -v12, v16, 1.0                              // 0000003DA364: D6130016 23CA210C
	v_fmac_f32_e32 v17, v23, v17                               // 0000003DA36C: 56222317
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA370: BF870095
	v_fma_f32 v21, -v10, v15, 1.0                              // 0000003DA374: D6130015 23CA1F0A
	v_dual_fmac_f32 v16, v22, v16 :: v_dual_fmac_f32 v15, v21, v15// 0000003DA37C: C8002116 100E1F15
	v_div_scale_f32 v21, s2, 1.0, v6, 1.0                      // 0000003DA384: D6FC0215 03CA0CF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA38C: BF870194
	v_mul_f32_e32 v25, v24, v17                                // 0000003DA390: 10322318
	v_dual_mul_f32 v23, v20, v16 :: v_dual_mul_f32 v22, v19, v15// 0000003DA394: C8C62114 17161F13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA39C: BF870193
	v_mul_f32_e32 v26, v21, v18                                // 0000003DA3A0: 10342515
	v_fma_f32 v29, -v13, v25, v24                              // 0000003DA3A4: D613001D 2462330D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA3AC: BF870213
	v_fma_f32 v28, -v12, v23, v20                              // 0000003DA3B0: D613001C 24522F0C
	v_fma_f32 v27, -v10, v22, v19                              // 0000003DA3B8: D613001B 244E2D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA3C0: BF870214
	v_fma_f32 v30, -v14, v26, v21                              // 0000003DA3C4: D613001E 2456350E
	v_fmac_f32_e32 v25, v29, v17                               // 0000003DA3CC: 5632231D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA3D0: BF870193
	v_dual_fmac_f32 v23, v28, v16 :: v_dual_fmac_f32 v22, v27, v15// 0000003DA3D4: C800211C 17161F1B
	v_fmac_f32_e32 v26, v30, v18                               // 0000003DA3DC: 5634251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA3E0: BF870193
	v_fma_f32 v13, -v13, v25, v24                              // 0000003DA3E4: D613000D 2462330D
	v_fma_f32 v12, -v12, v23, v20                              // 0000003DA3EC: D613000C 24522F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA3F4: BF870214
	v_fma_f32 v10, -v10, v22, v19                              // 0000003DA3F8: D613000A 244E2D0A
	v_fma_f32 v14, -v14, v26, v21                              // 0000003DA400: D613000E 2456350E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003DA408: BF870142
	v_div_fmas_f32 v10, v10, v15, v22                          // 0000003DA40C: D637000A 045A1F0A
	s_mov_b32 vcc_lo, s0                                       // 0000003DA414: BEEA0000
	v_div_fmas_f32 v12, v12, v16, v23                          // 0000003DA418: D637000C 045E210C
	s_mov_b32 vcc_lo, s1                                       // 0000003DA420: BEEA0001
	v_div_fixup_f32 v7, v10, v7, 1.0                           // 0000003DA424: D6270007 03CA0F0A
	v_div_fmas_f32 v10, v13, v17, v25                          // 0000003DA42C: D637000A 0466230D
	s_mov_b32 vcc_lo, s2                                       // 0000003DA434: BEEA0002
	v_div_fixup_f32 v8, v12, v8, 1.0                           // 0000003DA438: D6270008 03CA110C
	v_div_fmas_f32 v13, v14, v18, v26                          // 0000003DA440: D637000D 046A250E
	v_bfe_u32 v12, v7, 16, 1                                   // 0000003DA448: D610000C 02052107
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003DA450: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA458: BF870214
	v_bfe_u32 v10, v8, 16, 1                                   // 0000003DA45C: D610000A 02052108
	v_div_fixup_f32 v6, v13, v6, 1.0                           // 0000003DA464: D6270006 03CA0D0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA46C: BF870214
	v_add3_u32 v7, v7, v12, 0x7fff                             // 0000003DA470: D6550007 03FE1907 00007FFF
	v_bfe_u32 v12, v9, 16, 1                                   // 0000003DA47C: D610000C 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003DA484: BF870214
	v_add3_u32 v8, v8, v10, 0x7fff                             // 0000003DA488: D6550008 03FE1508 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000003DA494: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA49C: BF870193
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003DA4A0: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003DA4AC: 361010FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003DA4B4: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000003DA4B8: D6550006 03FE1506 00007FFF
	s_waitcnt vmcnt(3)                                         // 0000003DA4C4: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000003DA4C8: 30080890
	s_waitcnt vmcnt(2)                                         // 0000003DA4CC: BF890BF7
	v_lshlrev_b32_e32 v5, 16, v5                               // 0000003DA4D0: 300A0A90
	s_waitcnt vmcnt(1)                                         // 0000003DA4D4: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000003DA4D8: 30040490
	s_waitcnt vmcnt(0)                                         // 0000003DA4DC: BF8903F7
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000003DA4E0: 30060690
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003DA4E4: 360E0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA4EC: BF870091
	v_fma_f32 v2, v2, v7, 0                                    // 0000003DA4F0: D6130002 02020F02
	v_dual_fmac_f32 v2, v3, v8 :: v_dual_and_b32 v3, 0xffff0000, v6// 0000003DA4F8: C8241103 02020CFF FFFF0000
	v_and_b32_e32 v7, 0xffff0000, v9                           // 0000003DA504: 360E12FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA50C: BF870091
	v_fmac_f32_e32 v2, v4, v7                                  // 0000003DA510: 56040F04
	v_fmac_f32_e32 v2, v5, v3                                  // 0000003DA514: 56040705
	.long 0xd73c0003                                           // 0000003DA518: D73C0003
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000003DA51C: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003DA520: BF870112
	v_mul_f32_e32 v2, 0x3e800000, v2                           // 0000003DA524: 100404FF 3E800000
	.long 0xd7006a03                                           // 0000003DA52C: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000003DA530: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003DA534: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 0000003DA538: D5207C04 01AA080B
	v_bfe_u32 v5, v2, 16, 1                                    // 0000003DA540: D6100005 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003DA548: BF870001
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000003DA54C: D6550005 03FE0B02 00007FFF
	global_store_d16_hi_b16 v[3:4], v5, off                    // 0000003DA558: DC960000 007C0503
	s_cbranch_scc1 9                                           // 0000003DA560: BFA20009 <_ZN7halogen12_GLOBAL__N_18k_hcup8wILi7EEEvPKhPKtS5_PtPf+0x1288>
	.long 0xd73c0000                                           // 0000003DA564: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 0000003DA568: 02020082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003DA56C: BF870091
	.long 0xd7006a00                                           // 0000003DA570: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000003DA574: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000003DA578: D5207C01 01AA0205
	global_store_b32 v[0:1], v2, off                           // 0000003DA580: DC6A0000 007C0200
	s_nop 0                                                    // 0000003DA588: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003DA58C: BFB60003
	s_endpgm                                                   // 0000003DA590: BFB00000
		...

