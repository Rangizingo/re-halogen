000000000047a300 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 00000047A300: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 00000047A304: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000047A30C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 00000047A314: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000047A31C: F4000840 F8000054
	v_and_b32_e32 v13, 31, v0                                  // 00000047A324: 361A009F
	v_lshrrev_b32_e32 v11, 5, v0                               // 00000047A328: 32160085
	s_mov_b32 s4, s3                                           // 00000047A32C: BE840003
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047A330: BF870002
	v_lshlrev_b32_e32 v12, 2, v13                              // 00000047A334: 30181A82
	s_waitcnt lgkmcnt(0)                                       // 00000047A338: BF89FC07
	s_ashr_i32 s34, s17, 31                                    // 00000047A33C: 86229F11
	s_mul_i32 s35, s19, s3                                     // 00000047A340: 96230313
	s_lshr_b32 s0, s34, 25                                     // 00000047A344: 85009922
	s_add_i32 s1, s35, s19                                     // 00000047A348: 81011323
	s_add_i32 s0, s17, s0                                      // 00000047A34C: 81000011
	s_mov_b32 s19, exec_lo                                     // 00000047A350: BE93007E
	s_ashr_i32 s0, s0, 7                                       // 00000047A354: 86008700
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047A358: BF870499
	s_min_i32 s0, s0, s1                                       // 00000047A35C: 89000100
	s_sub_i32 s11, s0, s35                                     // 00000047A360: 818B2300
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047A364: BF870499
	s_lshl_b32 s10, s11, 1                                     // 00000047A368: 840A810B
	.long 0xd4c4007e                                           // 00000047A36C: D4C4007E
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 00000047A370: 0202160A
	s_cbranch_execz 506                                        // 00000047A374: BFA501FA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	s_add_i32 s36, s16, -1                                     // 00000047A378: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 00000047A37C: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 00000047A380: 36040082
	s_cselect_b32 s37, -1, 0                                   // 00000047A384: 982580C1
	s_abs_i32 s38, s11                                         // 00000047A388: BEA6150B
	v_lshlrev_b32_e32 v6, 3, v13                               // 00000047A38C: 300C1A83
	s_cvt_f32_u32 s0, s38                                      // 00000047A390: BE806526
	v_dual_mov_b32 v8, v11 :: v_dual_and_b32 v1, 1, v0         // 00000047A394: CA24010B 08000081
	v_and_b32_e32 v4, 4, v0                                    // 00000047A39C: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047A3A0: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 00000047A3A4: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 00000047A3A8: 360A0088
	v_add_nc_u32_e32 v7, s35, v11                              // 00000047A3AC: 4A0E1623
	.long 0xd44a0003                                           // 00000047A3B0: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000047A3B4: 02020480
	v_lshl_or_b32 v2, v11, 8, v6                               // 00000047A3B8: D6560002 0419110B
	s_ashr_i32 s42, s11, 31                                    // 00000047A3C0: 862A9F0B
	s_sub_i32 s9, 0, s38                                       // 00000047A3C4: 81892680
	s_mul_i32 s44, s42, 0x1400                                 // 00000047A3C8: 962CFF2A 00001400
	.long 0xd44c0000                                           // 00000047A3D0: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 00000047A3D4: 02021A90
	.long 0xd44a0001                                           // 00000047A3D8: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000047A3DC: 02020280
	v_readfirstlane_b32 s5, v3                                 // 00000047A3E0: 7E0A0503
	.long 0xd44a0006                                           // 00000047A3E4: D44A0006
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000047A3E8: 02020A80
	v_lshl_or_b32 v1, v7, 7, v12                               // 00000047A3EC: D6560001 04310F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 00000047A3F4: 4E12042C
	s_lshl_b32 s7, s11, 7                                      // 00000047A3F8: 8407870B
	s_mul_f32 s8, s5, 0x4f7ffffe                               // 00000047A3FC: A208FF05 4F7FFFFE
	.long 0xd44a0005                                           // 00000047A404: D44A0005
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000047A408: 02020880
	s_mov_b32 s39, s17                                         // 00000047A40C: BEA70011
	s_mov_b32 s40, 0                                           // 00000047A410: BEA80080
	s_cvt_u32_f32 s8, s8                                       // 00000047A414: BE886708
	s_mov_b32 s41, 0x76543210                                  // 00000047A418: BEA900FF 76543210
	s_lshl_b32 s43, s11, 8                                     // 00000047A420: 842B880B
	s_sub_i32 s44, 0, s7                                       // 00000047A424: 81AC0780
	s_mul_i32 s9, s9, s8                                       // 00000047A428: 96090809
	s_mov_b32 s46, 0x3db504f3                                  // 00000047A42C: BEAE00FF 3DB504F3
	s_mul_hi_u32 s9, s8, s9                                    // 00000047A434: 96890908
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047A438: BF870009
	s_add_i32 s45, s8, s9                                      // 00000047A43C: 812D0908
	s_branch 168                                               // 00000047A440: BFA000A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A444: BF870091
	.long 0xd7006a02                                           // 00000047A448: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047A44C: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 00000047A450: D5207C03 01AA0615
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000047A458: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000047A460: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 00000047A468: BF8903F7
	v_fma_mix_f32 v5, v17, v2, v15 op_sel_hi:[0,1,0]           // 00000047A46C: CC200005 143E0511
	v_sub_f32_e32 v4, v18, v16                                 // 00000047A474: 08082112
	v_fma_mix_f32 v2, -v17, v2, v15 op_sel_hi:[0,1,0]          // 00000047A478: CC200002 343E0511
	v_add_f32_e32 v3, v18, v16                                 // 00000047A480: 06062112
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047A484: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000047A488: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 00000047A48C: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 00000047A490: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047A494: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A498: BF870193
	v_mov_b32_dpp v16, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047A49C: 7E2002FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047A4A4: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000047A4AC: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000047A4B4: D5010002 20060502
	v_mov_b32_dpp v15, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047A4BC: 7E1E02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000047A4C4: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000047A4CC: BF870144
	v_add_f32_e32 v4, v6, v4                                   // 00000047A4D0: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047A4D4: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000047A4DC: D5010007 20060F07
	.long 0xd72c0006                                           // 00000047A4E4: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v14, vcc_lo                  // 00000047A4E8: 02021CFF 00001400
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v7, v5    // 00000047A4F0: C9082102 02040B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047A4F8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000047A500: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000047A508: BF8701C3
	v_mov_b32_dpp v16, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047A50C: 7E2002FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000047A514: D5010002 200E0502
	v_mov_b32_dpp v14, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047A51C: 7E1C02FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000047A524: D5010005 200E0B05
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 00000047A52C: C9081F03 03022102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A534: BF870112
	v_add_f32_e32 v5, v5, v14                                  // 00000047A538: 060A1D05
	v_mov_b32_dpp v15, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047A53C: 7E1E02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000047A544: D5010003 200E0703
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047A54C: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047A550: 7E2002FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000047A558: D5010002 20160502
	v_mov_b32_dpp v14, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047A560: 7E1C02FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000047A568: D5010005 20160B05
	v_add_f32_e32 v4, v4, v7                                   // 00000047A570: 06080F04
	.long 0xd72c0007                                           // 00000047A574: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 00000047A578: 0202142B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A57C: BF870193
	v_add_f32_e32 v5, v5, v14                                  // 00000047A580: 060A1D05
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047A584: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000047A58C: D5010004 20160904
	v_add_f32_e32 v3, v3, v15                                  // 00000047A594: 06061F03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047A598: BF870224
	v_mov_b32_dpp v14, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047A59C: 7E1C02FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s6                          // 00000047A5A4: D5010005 201A0B05
	v_add_f32_e32 v4, v4, v10                                  // 00000047A5AC: 06081504
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047A5B0: BF870254
	v_mov_b32_dpp v15, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047A5B4: 7E1E02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000047A5BC: D5010003 20160703
	v_add_nc_u32_e32 v8, 8, v8                                 // 00000047A5C4: 4A101088
	v_dual_add_f32 v2, v2, v16 :: v_dual_add_f32 v5, v5, v14   // 00000047A5C8: C9082102 02041D05
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047A5D0: 7E1402FA FF016804
	v_add_f32_e32 v3, v3, v15                                  // 00000047A5D8: 06061F03
	v_cndmask_b32_e64 v4, -v4, v4, s6                          // 00000047A5DC: D5010004 201A0904
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047A5E4: BF870004
	v_mov_b32_dpp v16, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047A5E8: 7E2002FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s6                          // 00000047A5F0: D5010002 201A0502
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000047A5F8: 4C0C0F06
	v_mov_b32_dpp v15, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047A5FC: 7E1E02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s6                          // 00000047A604: D5010003 201A0703
	v_add_f32_e32 v4, v4, v10                                  // 00000047A60C: 06081504
	v_cmp_le_i32_e32 vcc_lo, s10, v8                           // 00000047A610: 7C86100A
	v_add_nc_u32_e32 v6, v9, v6                                // 00000047A614: 4A0C0D09
	v_add_nc_u32_e32 v9, 0x800, v9                             // 00000047A618: 4A1212FF 00000800
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v2, v2, v16   // 00000047A620: C9081F03 03022102
	s_or_b32 s40, vcc_lo, s40                                  // 00000047A628: 8C28286A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047A62C: BF8701B1
	v_dual_mov_b32 v15, v3 :: v_dual_mov_b32 v16, v2           // 00000047A630: CA100103 0F100102
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000047A638: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000047A640: D5010003 20020703
	v_permlanex16_b32 v15, v15, s41, 0xfedcba98                // 00000047A648: D65C000F 03FC530F FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047A654: BF8701B4
	v_permlanex16_b32 v16, v16, s41, 0xfedcba98                // 00000047A658: D65C0010 03FC5310 FEDCBA98
	v_mov_b32_e32 v14, v5                                      // 00000047A664: 7E1C0305
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000047A668: D5010005 20020B05
	v_add_f32_e32 v7, v2, v16                                  // 00000047A670: 060E2102
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047A674: BF8701B3
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 00000047A678: D65C000E 03FC530E FEDCBA98
	v_mov_b32_e32 v10, v4                                      // 00000047A684: 7E140304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000047A688: D5010004 20020904
	v_add_f32_e32 v5, v5, v14                                  // 00000047A690: 060A1D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A694: BF870113
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 00000047A698: D65C000A 03FC530A FEDCBA98
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 00000047A6A4: CC220002 02005D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047A6AC: BF8701B2
	v_add_f32_e32 v4, v4, v10                                  // 00000047A6B0: 06081504
	v_add_f32_e32 v10, v3, v15                                 // 00000047A6B4: 06141F03
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 00000047A6B8: CC220003 02005D07
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 00000047A6C0: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047A6C8: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 00000047A6CC: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 00000047A6D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 00000047A6DC: 917E287E
	s_cbranch_execz 287                                        // 00000047A6E0: BFA5011F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x860>
	.long 0xd72d0002                                           // 00000047A6E4: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 00000047A6E8: 02005B08
	s_mov_b32 s7, -1                                           // 00000047A6EC: BE8700C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A6F0: BF870091
	.long 0xd72c0003                                           // 00000047A6F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 00000047A6F8: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 00000047A6FC: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047A700: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 00000047A704: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000047A708: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000047A70C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A714: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000047A718: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000047A71C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A720: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000047A724: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000047A728: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000047A72C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A730: BF870091
	v_xor_b32_e32 v14, s42, v2                                 // 00000047A734: 3A1C042A
	v_subrev_nc_u32_e32 v10, s42, v14                          // 00000047A738: 4E141C2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047A73C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 00000047A740: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 00000047A748: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000047A74C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A754: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000047A758: 340E0C9F
	.long 0xd73c0002                                           // 00000047A75C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000047A760: 02020C81
	s_cbranch_vccnz 210                                        // 00000047A764: BFA400D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b0>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A768: BF870093
	.long 0xd7006a06                                           // 00000047A76C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000047A770: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000047A774: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 00000047A77C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A780: BF870112
	.long 0xd73c0006                                           // 00000047A784: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000047A788: 02020C81
	.long 0x7f44399f                                           // 00000047A78C: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A790: BF870092
	.long 0xd7006a0f                                           // 00000047A794: D7006A0F
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 00000047A798: 02020C0E
	v_add_co_ci_u32_e64 v16, null, s15, v7, vcc_lo             // 00000047A79C: D5207C10 01AA0E0F
	.long 0xd7006a06                                           // 00000047A7A4: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000047A7A8: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047A7AC: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 00000047A7B0: D5207C07 01AA0E1F
	global_load_b64 v[15:16], v[15:16], off                    // 00000047A7B8: DC560000 0F7C000F
	.long 0xd7006a11                                           // 00000047A7C0: D7006A11
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047A7C4: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 00000047A7C8: DC560000 067C0006
	v_add_co_ci_u32_e64 v18, null, s21, v3, vcc_lo             // 00000047A7D0: D5207C12 01AA0615
	s_clause 0x1                                               // 00000047A7D8: BF850001
	global_load_b32 v19, v[17:18], off                         // 00000047A7DC: DC520000 137C0011
	global_load_d16_b16 v17, v[17:18], off offset:4            // 00000047A7E4: DC820004 117C0011
	s_waitcnt vmcnt(3)                                         // 00000047A7EC: BF890FF7
	.long 0x7e24390f                                           // 00000047A7F0: 7E24390F
	s_waitcnt vmcnt(2)                                         // 00000047A7F4: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 00000047A7F8: 36520CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000047A800: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047A804: BF870093
	v_lshlrev_b32_e32 v18, 16, v18                             // 00000047A808: 30242490
	v_mul_f32_e32 v22, 0xbfb8aa3b, v18                         // 00000047A80C: 102C24FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000047A814: BF870291
	v_exp_f32_e32 v22, v22                                     // 00000047A818: 7E2C4B16
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_and_b32 v15, 0xffff0000, v15// 00000047A81C: C9242CF2 160E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A828: BF870111
	v_mul_f32_e32 v21, 0xbfb8aa3b, v15                         // 00000047A82C: 102A1EFF BFB8AA3B
	v_div_scale_f32 v26, null, v22, v22, v18                   // 00000047A834: D6FC7C1A 044A2D16
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047A83C: BF8701B2
	v_exp_f32_e32 v21, v21                                     // 00000047A840: 7E2A4B15
	v_lshlrev_b32_e32 v20, 16, v16                             // 00000047A844: 30282090
	v_div_scale_f32 v39, s8, v18, v22, v18                     // 00000047A848: D6FC0827 044A2D12
	v_rcp_f32_e32 v30, v26                                     // 00000047A850: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A854: BF870196
	v_add_f32_e32 v21, 1.0, v21                                // 00000047A858: 062A2AF2
	v_mul_f32_e32 v23, 0xbfb8aa3b, v20                         // 00000047A85C: 102E28FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A864: BF870195
	v_fma_f32 v38, -v26, v30, 1.0                              // 00000047A868: D6130026 23CA3D1A
	v_div_scale_f32 v25, null, v21, v21, v15                   // 00000047A870: D6FC7C19 043E2B15
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047A878: BF870003
	v_exp_f32_e32 v23, v23                                     // 00000047A87C: 7E2E4B17
	v_and_b32_e32 v16, 0xffff0000, v16                         // 00000047A880: 362020FF FFFF0000
	v_div_scale_f32 v35, vcc_lo, v15, v21, v15                 // 00000047A888: D6FC6A23 043E2B0F
	v_fmac_f32_e32 v30, v38, v30                               // 00000047A890: 563C3D26
	v_rcp_f32_e32 v28, v25                                     // 00000047A894: 7E385519
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000047A898: BF870186
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_mul_f32 v24, 0xbfb8aa3b, v16// 00000047A89C: C9062EF2 171820FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A8A8: BF870115
	v_fma_f32 v36, -v25, v28, 1.0                              // 00000047A8AC: D6130024 23CA3919
	v_div_scale_f32 v27, null, v23, v23, v20                   // 00000047A8B4: D6FC7C1B 04522F17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047A8BC: BF8701A3
	v_exp_f32_e32 v24, v24                                     // 00000047A8C0: 7E304B18
	v_div_scale_f32 v37, s7, v20, v23, v20                     // 00000047A8C4: D6FC0725 04522F14
	v_fmac_f32_e32 v28, v36, v28                               // 00000047A8CC: 56383924
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000047A8D0: BF870313
	v_rcp_f32_e32 v32, v27                                     // 00000047A8D4: 7E40551B
	v_add_f32_e32 v24, 1.0, v24                                // 00000047A8D8: 063030F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A8DC: BF870115
	v_fma_f32 v40, -v27, v32, 1.0                              // 00000047A8E0: D6130028 23CA411B
	v_div_scale_f32 v29, null, v24, v24, v16                   // 00000047A8E8: D6FC7C1D 04423118
	v_div_scale_f32 v38, s9, v16, v24, v16                     // 00000047A8F0: D6FC0926 04423110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A8F8: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 00000047A8FC: 56404128
	v_rcp_f32_e32 v33, v29                                     // 00000047A900: 7E42551D
	v_mul_f32_e32 v40, v35, v28                                // 00000047A904: 10503923
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A908: BF870112
	v_mul_f32_e32 v42, v37, v32                                // 00000047A90C: 10544125
	v_fma_f32 v43, -v25, v40, v35                              // 00000047A910: D613002B 248E5119
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000047A918: BF870292
	v_fma_f32 v46, -v27, v42, v37                              // 00000047A91C: D613002E 2496551B
	v_fma_f32 v36, -v29, v33, 1.0                              // 00000047A924: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047A92C: BF870113
	v_fmac_f32_e32 v40, v43, v28                               // 00000047A930: 5650392B
	v_dual_fmac_f32 v42, v46, v32 :: v_dual_fmac_f32 v33, v36, v33// 00000047A934: C800412E 2A204324
	v_mul_f32_e32 v36, v39, v30                                // 00000047A93C: 10483D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A940: BF870193
	v_fma_f32 v25, -v25, v40, v35                              // 00000047A944: D6130019 248E5119
	v_fma_f32 v27, -v27, v42, v37                              // 00000047A94C: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047A954: BF870214
	v_mul_f32_e32 v44, v38, v33                                // 00000047A958: 10584326
	v_fma_f32 v45, -v26, v36, v39                              // 00000047A95C: D613002D 249E491A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047A964: BF8701A4
	v_div_fmas_f32 v25, v25, v28, v40                          // 00000047A968: D6370019 04A23919
	s_mov_b32 vcc_lo, s8                                       // 00000047A970: BEEA0008
	v_fma_f32 v43, -v29, v44, v38                              // 00000047A974: D613002B 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A97C: BF870193
	v_fmac_f32_e32 v36, v45, v30                               // 00000047A980: 56483D2D
	v_div_fixup_f32 v15, v25, v21, v15                         // 00000047A984: D627000F 043E2B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A98C: BF870193
	v_fmac_f32_e32 v44, v43, v33                               // 00000047A990: 5658432B
	v_fma_f32 v26, -v26, v36, v39                              // 00000047A994: D613001A 249E491A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A99C: BF870193
	v_mul_f32_e32 v15, v15, v41                                // 00000047A9A0: 101E530F
	v_fma_f32 v25, -v29, v44, v38                              // 00000047A9A4: D6130019 249A591D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047A9AC: BF8701A3
	v_div_fmas_f32 v26, v26, v30, v36                          // 00000047A9B0: D637001A 04923D1A
	s_mov_b32 vcc_lo, s7                                       // 00000047A9B8: BEEA0007
	.long 0x7e3e398f                                           // 00000047A9BC: 7E3E398F
	v_div_fmas_f32 v21, v27, v32, v42                          // 00000047A9C0: D6370015 04AA411B
	s_mov_b32 vcc_lo, s9                                       // 00000047A9C8: BEEA0009
	v_div_fixup_f32 v18, v26, v22, v18                         // 00000047A9CC: D6270012 044A2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 00000047A9D4: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000047A9D8: 360E0EFF FFFF0000
	v_div_fixup_f32 v20, v21, v23, v20                         // 00000047A9E0: D6270014 04522F15
	s_mov_b32 s7, 0                                            // 00000047A9E8: BE870080
	v_mul_f32_e32 v6, v18, v6                                  // 00000047A9EC: 100C0D12
	v_div_fmas_f32 v18, v25, v33, v44                          // 00000047A9F0: D6370012 04B24319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047A9F8: BF870193
	v_mul_f32_e32 v20, v20, v22                                // 00000047A9FC: 10282D14
	.long 0x7e443986                                           // 00000047AA00: 7E443986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047AA04: BF870223
	v_div_fixup_f32 v16, v18, v24, v16                         // 00000047AA08: D6270010 04423112
	v_and_b32_e32 v18, 1, v31                                  // 00000047AA10: 36243E81
	v_bfe_u32 v21, v20, 16, 1                                  // 00000047AA14: D6100015 02052114
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047AA1C: BF870193
	v_dual_mul_f32 v7, v16, v7 :: v_dual_and_b32 v22, 1, v34   // 00000047AA20: C8E40F10 07164481
	v_add3_u32 v15, v15, v18, 0x7fff                           // 00000047AA28: D655000F 03FE250F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047AA34: BF870193
	v_add3_u32 v16, v20, v21, 0x7fff                           // 00000047AA38: D6550010 03FE2B14 00007FFF
	v_add3_u32 v6, v6, v22, 0x7fff                             // 00000047AA44: D6550006 03FE2D06 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047AA50: BF870214
	v_bfe_u32 v18, v7, 16, 1                                   // 00000047AA54: D6100012 02052107
	v_and_b32_e32 v15, 0xffff0000, v15                         // 00000047AA5C: 361E1EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047AA64: BF870214
	v_and_b32_e32 v20, 0xffff0000, v16                         // 00000047AA68: 362820FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000047AA70: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047AA78: BF870004
	v_add3_u32 v7, v7, v18, 0x7fff                             // 00000047AA7C: D6550007 03FE2507 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000047AA88: BF8907F7
	v_fma_mix_f32 v16, v19, v15, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000047AA8C: CC200810 8A021F13
	s_waitcnt vmcnt(0)                                         // 00000047AA94: BF8903F7
	v_fma_mix_f32 v15, v17, v20, neg(0) op_sel_hi:[1,0,0]      // 00000047AA98: CC20000F 8A022911
	v_fma_mix_f32 v18, v19, v6, neg(0) op_sel_hi:[1,0,0]       // 00000047AAA0: CC200012 8A020D13
	v_and_b32_e32 v17, 0xffff0000, v7                          // 00000047AAA8: 36220EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000047AAB0: 916A077E
	s_cbranch_vccnz 65123                                      // 00000047AAB4: BFA4FE63 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047AAB8: BF870093
	.long 0xd73c0004                                           // 00000047AABC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000047AAC0: 02020881
	.long 0xd7006a04                                           // 00000047AAC4: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 00000047AAC8: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047AACC: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 00000047AAD0: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 00000047AAD8: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000047AADC: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047AAE0: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000047AAE4: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000047AAEC: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000047AAF0: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 00000047AAF4: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 00000047AAFC: DC560000 047C0004
	s_clause 0x1                                               // 00000047AB04: BF850001
	global_load_b32 v17, v[6:7], off                           // 00000047AB08: DC520000 117C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000047AB10: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000047AB18: BF890BF7
	.long 0x7e0e3904                                           // 00000047AB1C: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000047AB20: 360808FF FFFF0000
	v_lshlrev_b32_e32 v15, 16, v5                              // 00000047AB28: 301E0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047AB2C: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000047AB30: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000047AB34: BF8907F7
	v_fma_mix_f32 v16, v17, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000047AB38: CC200810 8A020911
	s_waitcnt vmcnt(0)                                         // 00000047AB40: BF8903F7
	v_fma_mix_f32 v15, v6, v15, neg(0) op_sel_hi:[1,0,0]       // 00000047AB44: CC20000F 8A021F06
	v_fma_mix_f32 v18, v17, v7, neg(0) op_sel_hi:[1,0,0]       // 00000047AB4C: CC200012 8A020F11
	v_and_b32_e32 v17, 0xffff0000, v5                          // 00000047AB54: 36220AFF FFFF0000
	s_branch 65081                                             // 00000047AB5C: BFA0FE39 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x144>
	s_or_b32 exec_lo, exec_lo, s19                             // 00000047AB60: 8C7E137E
	s_bfe_i32 s10, s11, 0x1001c                                // 00000047AB64: 938AFF0B 0001001C
	s_lshr_b32 s3, s34, 28                                     // 00000047AB6C: 85039C22
	s_lshr_b64 s[0:1], s[10:11], 29                            // 00000047AB70: 85809D0A
	s_add_i32 s3, s17, s3                                      // 00000047AB74: 81030311
	s_add_i32 s0, s0, 7                                        // 00000047AB78: 81008700
	s_lshl_b32 s1, s11, 3                                      // 00000047AB7C: 8401830B
	s_ashr_i32 s0, s0, 3                                       // 00000047AB80: 86008300
	s_lshl_b32 s5, s35, 3                                      // 00000047AB84: 84058323
	.long 0xd72c0001                                           // 00000047AB88: D72C0001
	v_cndmask_b32_e32 v1, s0, v11, vcc_lo                      // 00000047AB8C: 02021600
	s_waitcnt lgkmcnt(0)                                       // 00000047AB90: BF89FC07
	s_barrier                                                  // 00000047AB94: BFBD0000
	buffer_gl0_inv                                             // 00000047AB98: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 00000047ABA0: 4A040200
	s_ashr_i32 s0, s3, 4                                       // 00000047ABA4: 86008403
	s_ashr_i32 s3, s5, 31                                      // 00000047ABA8: 86039F05
	s_mul_hi_i32 s6, s0, s2                                    // 00000047ABAC: 97060200
	s_mul_i32 s0, s0, s2                                       // 00000047ABB0: 96000200
	v_min_i32_e32 v14, s1, v2                                  // 00000047ABB4: 221C0401
	v_add_nc_u32_e32 v2, 1, v1                                 // 00000047ABB8: 4A040281
	s_add_u32 s0, s0, s5                                       // 00000047ABBC: 80000500
	s_addc_u32 s1, s6, s3                                      // 00000047ABC0: 82010306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047ABC4: BF870099
	s_lshl_b64 s[6:7], s[0:1], 10                              // 00000047ABC8: 84868A00
	v_cmp_lt_i32_e32 vcc_lo, v2, v14                           // 00000047ABCC: 7C821D02
	s_add_u32 s1, s12, s6                                      // 00000047ABD0: 8001060C
	s_addc_u32 s5, s13, s7                                     // 00000047ABD4: 8205070D
	s_and_saveexec_b32 s0, vcc_lo                              // 00000047ABD8: BE80206A
	s_cbranch_execz 91                                         // 00000047ABDC: BFA5005B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa4c>
	.long 0xd7010303                                           // 00000047ABE0: D7010303
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 00000047ABE4: 0201030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047ABE8: BF870121
	v_cndmask_b32_e64 v4, v3, 31, s3                           // 00000047ABEC: D5010004 000D3F03
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000047ABF4: 3406049F
	v_cmp_gt_u32_e32 vcc_lo, 31, v4                            // 00000047ABF8: 7C98089F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047ABFC: BF8701B2
	.long 0xd73c0002                                           // 00000047AC00: D73C0002
	v_cndmask_b32_e32 v1, 10, v2, vcc_lo                       // 00000047AC04: 0202048A
	v_cndmask_b32_e64 v6, 0xe1, 1, vcc_lo                      // 00000047AC08: D5010006 01A902FF 000000E1
	v_mov_b32_e32 v5, 0                                        // 00000047AC14: 7E0A0280
	.long 0xd7006a08                                           // 00000047AC18: D7006A08
	v_cndmask_b32_e32 v1, s1, v2, vcc_lo                       // 00000047AC1C: 02020401
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047AC20: BF870211
	v_add_co_ci_u32_e64 v9, null, s5, v3, vcc_lo               // 00000047AC24: D5207C09 01AA0605
	v_add_nc_u32_e32 v6, v6, v4                                // 00000047AC2C: 4A0C0906
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047AC30: BF870114
	.long 0xd73c0004                                           // 00000047AC34: D73C0004
	v_cndmask_b32_e32 v1, 2, v4, vcc_lo                        // 00000047AC38: 02020882
	v_lshlrev_b32_e32 v7, 24, v6                               // 00000047AC3C: 300E0C98
	v_bfe_i32 v6, v6, 7, 1                                     // 00000047AC40: D6110006 02050F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047AC48: BF870093
	.long 0xd7006a02                                           // 00000047AC4C: D7006A02
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 00000047AC50: 02020908
	v_add_co_ci_u32_e64 v3, null, v9, v5, vcc_lo               // 00000047AC54: D5207C03 01AA0B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047AC5C: BF870094
	v_ashrrev_i32_e32 v7, 22, v7                               // 00000047AC60: 340E0E96
	.long 0xd7006a04                                           // 00000047AC64: D7006A04
	v_cndmask_b32_e32 v1, v8, v7, vcc_lo                       // 00000047AC68: 02020F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047AC6C: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v9, v6, vcc_lo               // 00000047AC70: D5207C05 01AA0D09
	.long 0xd7006a06                                           // 00000047AC78: D7006A06
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000047AC7C: 02021908
	v_add_co_ci_u32_e64 v7, null, 0, v9, vcc_lo                // 00000047AC80: D5207C07 01AA1280
	s_clause 0x17                                              // 00000047AC88: BF850017
	global_load_b32 v15, v[2:3], off                           // 00000047AC8C: DC520000 0F7C0002
	global_load_b32 v20, v[2:3], off offset:128                // 00000047AC94: DC520080 147C0002
	global_load_b32 v19, v[2:3], off offset:256                // 00000047AC9C: DC520100 137C0002
	global_load_b32 v18, v[2:3], off offset:384                // 00000047ACA4: DC520180 127C0002
	global_load_b32 v17, v[2:3], off offset:512                // 00000047ACAC: DC520200 117C0002
	global_load_b32 v16, v[2:3], off offset:640                // 00000047ACB4: DC520280 107C0002
	global_load_b32 v10, v[2:3], off offset:768                // 00000047ACBC: DC520300 0A7C0002
	global_load_b32 v29, v[2:3], off offset:896                // 00000047ACC4: DC520380 1D7C0002
	global_load_b32 v28, v[4:5], off                           // 00000047ACCC: DC520000 1C7C0004
	global_load_b32 v26, v[4:5], off offset:128                // 00000047ACD4: DC520080 1A7C0004
	global_load_b32 v24, v[4:5], off offset:256                // 00000047ACDC: DC520100 187C0004
	global_load_b32 v23, v[4:5], off offset:384                // 00000047ACE4: DC520180 177C0004
	global_load_b32 v22, v[4:5], off offset:512                // 00000047ACEC: DC520200 167C0004
	global_load_b32 v21, v[4:5], off offset:640                // 00000047ACF4: DC520280 157C0004
	global_load_b32 v37, v[4:5], off offset:768                // 00000047ACFC: DC520300 257C0004
	global_load_b32 v36, v[4:5], off offset:896                // 00000047AD04: DC520380 247C0004
	global_load_b32 v35, v[6:7], off                           // 00000047AD0C: DC520000 237C0006
	global_load_b32 v32, v[6:7], off offset:128                // 00000047AD14: DC520080 207C0006
	global_load_b32 v31, v[6:7], off offset:256                // 00000047AD1C: DC520100 1F7C0006
	global_load_b32 v30, v[6:7], off offset:384                // 00000047AD24: DC520180 1E7C0006
	global_load_b32 v27, v[6:7], off offset:512                // 00000047AD2C: DC520200 1B7C0006
	global_load_b32 v25, v[6:7], off offset:640                // 00000047AD34: DC520280 197C0006
	global_load_b32 v34, v[6:7], off offset:768                // 00000047AD3C: DC520300 227C0006
	global_load_b32 v33, v[6:7], off offset:896                // 00000047AD44: DC520380 217C0006
	s_or_b32 exec_lo, exec_lo, s0                              // 00000047AD4C: 8C7E007E
	v_cmp_lt_i32_e32 vcc_lo, v1, v14                           // 00000047AD50: 7C821D01
	s_and_saveexec_b32 s3, vcc_lo                              // 00000047AD54: BE83206A
	s_cbranch_execz 93                                         // 00000047AD58: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xbd0>
	.long 0xd7010002                                           // 00000047AD5C: D7010002
	v_cndmask_b32_e32 v0, v13, v129, vcc_lo                    // 00000047AD60: 0201030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047AD64: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 00000047AD68: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000047AD70: 3404029F
	.long 0xd44c0000                                           // 00000047AD74: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 00000047AD78: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047AD7C: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 00000047AD80: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 00000047AD8C: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047AD94: BF870114
	.long 0xd73c0005                                           // 00000047AD98: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000047AD9C: 0202028A
	.long 0xd73c0002                                           // 00000047ADA0: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000047ADA4: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047ADA8: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 00000047ADAC: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 00000047ADB0: D6110007 02050F07
	.long 0xd7000008                                           // 00000047ADB8: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 00000047ADBC: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047ADC0: BF870211
	v_add_co_ci_u32_e64 v9, null, s5, v6, s0                   // 00000047ADC4: D5207C09 00020C05
	v_ashrrev_i32_e32 v6, 22, v4                               // 00000047ADCC: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047ADD0: BF870093
	.long 0xd7000004                                           // 00000047ADD4: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 00000047ADD8: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 00000047ADDC: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047ADE4: BF870093
	.long 0xd7000006                                           // 00000047ADE8: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 00000047ADEC: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 00000047ADF0: D5207C07 00020F09
	.long 0xd7000008                                           // 00000047ADF8: D7000008
	v_cndmask_b32_e32 v1, v8, v12, vcc_lo                      // 00000047ADFC: 02021908
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047AE00: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 00000047AE04: D5207C09 00021280
	s_clause 0x17                                              // 00000047AE0C: BF850017
	global_load_b32 v2, v[4:5], off                            // 00000047AE10: DC520000 027C0004
	global_load_b32 v96, v[4:5], off offset:128                // 00000047AE18: DC520080 607C0004
	global_load_b32 v92, v[4:5], off offset:256                // 00000047AE20: DC520100 5C7C0004
	global_load_b32 v89, v[4:5], off offset:384                // 00000047AE28: DC520180 597C0004
	global_load_b32 v86, v[4:5], off offset:512                // 00000047AE30: DC520200 567C0004
	global_load_b32 v82, v[4:5], off offset:640                // 00000047AE38: DC520280 527C0004
	global_load_b32 v75, v[4:5], off offset:768                // 00000047AE40: DC520300 4B7C0004
	global_load_b32 v59, v[4:5], off offset:896                // 00000047AE48: DC520380 3B7C0004
	global_load_b32 v3, v[6:7], off                            // 00000047AE50: DC520000 037C0006
	global_load_b32 v97, v[6:7], off offset:128                // 00000047AE58: DC520080 617C0006
	global_load_b32 v93, v[6:7], off offset:256                // 00000047AE60: DC520100 5D7C0006
	global_load_b32 v90, v[6:7], off offset:384                // 00000047AE68: DC520180 5A7C0006
	global_load_b32 v87, v[6:7], off offset:512                // 00000047AE70: DC520200 577C0006
	global_load_b32 v84, v[6:7], off offset:640                // 00000047AE78: DC520280 547C0006
	global_load_b32 v83, v[6:7], off offset:768                // 00000047AE80: DC520300 537C0006
	global_load_b32 v60, v[6:7], off offset:896                // 00000047AE88: DC520380 3C7C0006
	global_load_b32 v95, v[8:9], off                           // 00000047AE90: DC520000 5F7C0008
	global_load_b32 v94, v[8:9], off offset:128                // 00000047AE98: DC520080 5E7C0008
	global_load_b32 v91, v[8:9], off offset:256                // 00000047AEA0: DC520100 5B7C0008
	global_load_b32 v88, v[8:9], off offset:384                // 00000047AEA8: DC520180 587C0008
	global_load_b32 v85, v[8:9], off offset:512                // 00000047AEB0: DC520200 557C0008
	global_load_b32 v73, v[8:9], off offset:640                // 00000047AEB8: DC520280 497C0008
	global_load_b32 v74, v[8:9], off offset:768                // 00000047AEC0: DC520300 4A7C0008
	global_load_b32 v58, v[8:9], off offset:896                // 00000047AEC8: DC520380 3A7C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 00000047AED0: 8C7E037E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000047AED4: CA100080 26260080
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v42, 0             // 00000047AEDC: CA100080 292A0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v47, 0             // 00000047AEE4: CA100080 2C2E0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v49, 0             // 00000047AEEC: CA100080 2E300080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v43, 0             // 00000047AEF4: CA100080 282A0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v45, 0             // 00000047AEFC: CA100080 302C0080
	v_dual_mov_b32 v51, 0 :: v_dual_mov_b32 v52, 0             // 00000047AF04: CA100080 33340080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v53, 0             // 00000047AF0C: CA100080 32340080
	s_ashr_i32 s3, s2, 31                                      // 00000047AF14: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 00000047AF18: BE80206A
	s_cbranch_execz 1034                                       // 00000047AF1C: BFA5040A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c48>
	v_dual_mov_b32 v39, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 00000047AF20: CA200080 270400C1
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v5, 16, v0         // 00000047AF28: CA240080 2A040090
	v_dual_mov_b32 v38, 0 :: v_dual_add_nc_u32 v9, 2, v1       // 00000047AF30: CA200080 26080282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047AF38: BF870243
	v_dual_mov_b32 v41, 0 :: v_dual_and_b32 v4, 31, v4         // 00000047AF3C: CA240080 2904089F
	v_sub_nc_u32_e32 v54, 0, v14                               // 00000047AF44: 4C6C1C80
	v_dual_mov_b32 v44, 0 :: v_dual_lshlrev_b32 v55, 2, v13    // 00000047AF48: CA220080 2C361A82
	v_lshl_or_b32 v56, v1, 5, v5                               // 00000047AF50: D6560038 04150B01
	v_dual_mov_b32 v46, 0 :: v_dual_lshlrev_b32 v57, 2, v4     // 00000047AF58: CA220080 2E380882
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v40, 0             // 00000047AF60: CA100080 2F280080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0             // 00000047AF68: CA100080 30300080
	v_dual_mov_b32 v43, 0 :: v_dual_mov_b32 v52, 0             // 00000047AF70: CA100080 2B340080
	v_dual_mov_b32 v45, 0 :: v_dual_mov_b32 v50, 0             // 00000047AF78: CA100080 2D320080
	v_mov_b32_e32 v51, 0                                       // 00000047AF80: 7E660280
	v_mov_b32_e32 v53, 0                                       // 00000047AF84: 7E6A0280
	s_mov_b32 s6, 0                                            // 00000047AF88: BE860080
	s_movk_i32 s7, 0x1eee                                      // 00000047AF8C: B0071EEE
	s_branch 936                                               // 00000047AF90: BFA003A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b34>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000047AF94: 8C7E087E
	v_alignbit_b32 v98, v2, v3, 16                             // 00000047AF98: D6160062 02420702
	v_alignbit_b32 v96, v96, v97, 16                           // 00000047AFA0: D6160060 0242C360
	ds_load_b128 v[1:4], v56                                   // 00000047AFA8: DBFC0000 01000038
	ds_load_b128 v[5:8], v56 offset:5120                       // 00000047AFB0: DBFC1400 05000038
	v_bfe_u32 v99, v95, 12, 16                                 // 00000047AFB8: D6100063 0241195F
	v_bfe_u32 v101, v95, 8, 16                                 // 00000047AFC0: D6100065 0241115F
	v_bfe_u32 v100, v98, 12, 16                                // 00000047AFC8: D6100064 02411962
	v_bfe_u32 v97, v98, 8, 16                                  // 00000047AFD0: D6100061 02411162
	v_bfe_u32 v103, v95, 4, 16                                 // 00000047AFD8: D6100067 0241095F
	.long 0xd72c0063                                           // 00000047AFE0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 00000047AFE4: 0202C6FF 83DCD12D
	.long 0xd72c0065                                           // 00000047AFEC: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 00000047AFF0: 0202CAFF 83DCD12D
	.long 0xd72c0064                                           // 00000047AFF8: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000047AFFC: 0202C8FF 83DCD12D
	.long 0xd72c0061                                           // 00000047B004: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000047B008: 0202C2FF 83DCD12D
	.long 0xd72c0067                                           // 00000047B010: D72C0067
	v_cndmask_b32_e32 v1, 0x83dcd12d, v103, vcc_lo             // 00000047B014: 0202CEFF 83DCD12D
	v_alignbit_b32 v92, v92, v93, 16                           // 00000047B01C: D616005C 0242BB5C
	v_alignbit_b32 v89, v89, v90, 16                           // 00000047B024: D6160059 0242B559
	v_alignbit_b32 v86, v86, v87, 16                           // 00000047B02C: D6160056 0242AF56
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000047B034: D6220063 03FD0163 00006400
	v_alignbit_b32 v82, v82, v84, 16                           // 00000047B040: D6160052 0242A952
	v_sad_u8 v100, v100, 0, 0x6400                             // 00000047B048: D6220064 03FD0164 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000047B054: D6220061 03FD0161 00006400
	v_alignbit_b32 v75, v75, v83, 16                           // 00000047B060: D616004B 0242A74B
	v_alignbit_b32 v59, v59, v60, 16                           // 00000047B068: D616003B 0242793B
	v_add_nc_u32_e32 v56, 32, v56                              // 00000047B070: 4A7070A0
	v_and_b32_e32 v100, 0xffff, v100                           // 00000047B074: 36C8C8FF 0000FFFF
	v_add_nc_u32_e32 v9, 1, v9                                 // 00000047B07C: 4A121281
	v_bfe_u32 v83, v75, 4, 16                                  // 00000047B080: D6100053 0241094B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000047B088: BF870233
	v_lshl_or_b32 v97, v97, 16, v100                           // 00000047B08C: D6560061 05912161
	v_sad_u8 v100, v101, 0, 0x6400                             // 00000047B094: D6220064 03FD0165 00006400
	v_sad_u8 v101, v103, 0, 0x6400                             // 00000047B0A0: D6220065 03FD0167 00006400
	.long 0xd72c0053                                           // 00000047B0AC: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000047B0B0: 0202A6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000047B0B8: BF8701C4
	v_pk_fma_f16 v97, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B0BC: CC0E0061 0BFC0F61 0000C931
	v_and_b32_e32 v102, 0xffff, v98                            // 00000047B0C8: 36CCC4FF 0000FFFF
	v_bfe_u32 v98, v98, 4, 16                                  // 00000047B0D0: D6100062 02410962
	s_waitcnt lgkmcnt(0)                                       // 00000047B0D8: BF89FC07
	v_dual_dot2acc_f32_f16 v50, v97, v5 :: v_dual_and_b32 v95, 0xffff, v95// 00000047B0DC: CB240B61 325EBEFF 0000FFFF
	v_dot2acc_f32_f16 v53, v97, v1                             // 00000047B0E8: 046A0361
	.long 0xd72c0066                                           // 00000047B0EC: D72C0066
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 00000047B0F0: 0202CCFF 83DCD12D
	v_and_b32_e32 v99, 0xffff, v99                             // 00000047B0F8: 36C6C6FF 0000FFFF
	.long 0xd72c0062                                           // 00000047B100: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000047B104: 0202C4FF 83DCD12D
	v_bfe_u32 v97, v96, 12, 16                                 // 00000047B10C: D6100061 02411960
	.long 0xd72c005f                                           // 00000047B114: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 00000047B118: 0202BEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047B120: BF870004
	v_lshl_or_b32 v99, v100, 16, v99                           // 00000047B124: D6560063 058D2164
	v_bfe_u32 v100, v96, 4, 16                                 // 00000047B12C: D6100064 02410960
	v_sad_u8 v102, v102, 0, 0x6400                             // 00000047B134: D6220066 03FD0166 00006400
	.long 0xd72c0061                                           // 00000047B140: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000047B144: 0202C2FF 83DCD12D
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000047B14C: D6220062 03FD0162 00006400
	v_pk_fma_f16 v99, v99, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B158: CC0E0063 0BFC0F63 0000C931
	.long 0xd72c0064                                           // 00000047B164: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000047B168: 0202C8FF 83DCD12D
	v_lshlrev_b32_e32 v102, 16, v102                           // 00000047B170: 30CCCC90
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000047B174: D622005F 03FD015F 00006400
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000047B180: D6220061 03FD0161 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047B18C: BF8701A3
	v_and_or_b32 v98, 0xffff, v98, v102                        // 00000047B190: D6570062 059AC4FF 0000FFFF
	v_bfe_u32 v102, v91, 4, 16                                 // 00000047B19C: D6100066 0241095B
	v_and_b32_e32 v97, 0xffff, v97                             // 00000047B1A4: 36C2C2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047B1AC: BF870093
	v_pk_fma_f16 v98, v98, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B1B0: CC0E0062 0BFC0F62 0000C931
	v_dot2acc_f32_f16 v53, v98, v2                             // 00000047B1BC: 046A0562
	v_dot2acc_f32_f16 v50, v98, v6                             // 00000047B1C0: 04640D62
	v_bfe_u32 v98, v94, 12, 16                                 // 00000047B1C4: D6100062 0241195E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B1CC: BF870193
	v_dot2acc_f32_f16 v53, v99, v3                             // 00000047B1D0: 046A0763
	v_dot2acc_f32_f16 v50, v99, v7                             // 00000047B1D4: 04640F63
	v_bfe_u32 v99, v96, 8, 16                                  // 00000047B1D8: D6100063 02411160
	v_and_b32_e32 v96, 0xffff, v96                             // 00000047B1E0: 36C0C0FF 0000FFFF
	.long 0xd72c0062                                           // 00000047B1E8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000047B1EC: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B1F4: BF870193
	.long 0xd72c0063                                           // 00000047B1F8: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 00000047B1FC: 0202C6FF 83DCD12D
	.long 0xd72c0060                                           // 00000047B204: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 00000047B208: 0202C0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B210: BF870193
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000047B214: D6220062 03FD0162 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000047B220: D6220063 03FD0163 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B22C: BF870193
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000047B230: D6220060 03FD0160 00006400
	v_and_b32_e32 v98, 0xffff, v98                             // 00000047B23C: 36C4C4FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047B244: BF870223
	v_lshl_or_b32 v97, v99, 16, v97                            // 00000047B248: D6560061 05852163
	v_sad_u8 v99, v100, 0, 0x6400                              // 00000047B250: D6220063 03FD0164 00006400
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000047B25C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047B260: BF870211
	v_and_or_b32 v93, 0xffff, v99, v96                         // 00000047B264: D657005D 0582C6FF 0000FFFF
	v_pk_fma_f16 v96, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B270: CC0E0060 0BFC0F61 0000C931
	v_lshlrev_b32_e32 v95, 16, v95                             // 00000047B27C: 30BEBE90
	v_bfe_u32 v97, v92, 12, 16                                 // 00000047B280: D6100061 0241195C
	v_bfe_u32 v99, v92, 8, 16                                  // 00000047B288: D6100063 0241115C
	v_pk_fma_f16 v93, v93, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B290: CC0E005D 0BFC0F5D 0000C931
	v_dot2acc_f32_f16 v52, v96, v1                             // 00000047B29C: 04680360
	v_and_or_b32 v95, 0xffff, v101, v95                        // 00000047B2A0: D657005F 057ECAFF 0000FFFF
	v_and_b32_e32 v101, 0xffff, v94                            // 00000047B2AC: 36CABCFF 0000FFFF
	.long 0xd72c0061                                           // 00000047B2B4: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000047B2B8: 0202C2FF 83DCD12D
	.long 0xd72c0063                                           // 00000047B2C0: D72C0063
	v_cndmask_b32_e32 v1, 0x83dcd12d, v99, vcc_lo              // 00000047B2C4: 0202C6FF 83DCD12D
	v_dot2acc_f32_f16 v52, v93, v2                             // 00000047B2CC: 0468055D
	v_pk_fma_f16 v95, v95, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B2D0: CC0E005F 0BFC0F5F 0000C931
	.long 0xd72c0065                                           // 00000047B2DC: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 00000047B2E0: 0202CAFF 83DCD12D
	v_dot2acc_f32_f16 v51, v96, v5                             // 00000047B2E8: 04660B60
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047B2EC: BF870003
	v_dot2acc_f32_f16 v53, v95, v4                             // 00000047B2F0: 046A095F
	v_dot2acc_f32_f16 v50, v95, v8                             // 00000047B2F4: 0464115F
	v_bfe_u32 v95, v94, 8, 16                                  // 00000047B2F8: D610005F 0241115E
	v_sad_u8 v97, v97, 0, 0x6400                               // 00000047B300: D6220061 03FD0161 00006400
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000047B30C: D6220063 03FD0163 00006400
	v_bfe_u32 v94, v94, 4, 16                                  // 00000047B318: D610005E 0241095E
	v_sad_u8 v100, v101, 0, 0x6400                             // 00000047B320: D6220064 03FD0165 00006400
	.long 0xd72c005f                                           // 00000047B32C: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 00000047B330: 0202BEFF 83DCD12D
	v_bfe_u32 v101, v91, 8, 16                                 // 00000047B338: D6100065 0241115B
	v_dot2acc_f32_f16 v51, v93, v6                             // 00000047B340: 04660D5D
	.long 0xd72c005e                                           // 00000047B344: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000047B348: 0202BCFF 83DCD12D
	v_lshlrev_b32_e32 v100, 16, v100                           // 00000047B350: 30C8C890
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047B354: BF870224
	.long 0xd72c0065                                           // 00000047B358: D72C0065
	v_cndmask_b32_e32 v1, 0x83dcd12d, v101, vcc_lo             // 00000047B35C: 0202CAFF 83DCD12D
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000047B364: D622005F 03FD015F 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 00000047B370: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047B37C: BF870112
	v_lshl_or_b32 v95, v95, 16, v98                            // 00000047B380: D656005F 0589215F
	v_and_or_b32 v94, 0xffff, v94, v100                        // 00000047B388: D657005E 0592BCFF 0000FFFF
	v_bfe_u32 v100, v91, 12, 16                                // 00000047B394: D6100064 0241195B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047B39C: BF870003
	v_pk_fma_f16 v95, v95, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B3A0: CC0E005F 0BFC0F5F 0000C931
	v_and_b32_e32 v97, 0xffff, v97                             // 00000047B3AC: 36C2C2FF 0000FFFF
	v_and_b32_e32 v91, 0xffff, v91                             // 00000047B3B4: 36B6B6FF 0000FFFF
	v_pk_fma_f16 v94, v94, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B3BC: CC0E005E 0BFC0F5E 0000C931
	.long 0xd72c0064                                           // 00000047B3C8: D72C0064
	v_cndmask_b32_e32 v1, 0x83dcd12d, v100, vcc_lo             // 00000047B3CC: 0202C8FF 83DCD12D
	v_dot2acc_f32_f16 v52, v95, v3                             // 00000047B3D4: 0468075F
	v_lshl_or_b32 v97, v99, 16, v97                            // 00000047B3D8: D6560061 05852163
	.long 0xd72c005b                                           // 00000047B3E0: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000047B3E4: 0202B6FF 83DCD12D
	v_dot2acc_f32_f16 v51, v95, v7                             // 00000047B3EC: 04660F5F
	v_bfe_u32 v95, v89, 8, 16                                  // 00000047B3F0: D610005F 02411159
	v_dot2acc_f32_f16 v52, v94, v4                             // 00000047B3F8: 0468095E
	v_pk_fma_f16 v96, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B3FC: CC0E0060 0BFC0F61 0000C931
	v_and_b32_e32 v98, 0xffff, v92                             // 00000047B408: 36C4B8FF 0000FFFF
	v_bfe_u32 v92, v92, 4, 16                                  // 00000047B410: D610005C 0241095C
	.long 0xd72c005f                                           // 00000047B418: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 00000047B41C: 0202BEFF 83DCD12D
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000047B424: D622005B 03FD015B 00006400
	v_dot2acc_f32_f16 v45, v96, v1                             // 00000047B430: 045A0360
	.long 0xd72c0062                                           // 00000047B434: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000047B438: 0202C4FF 83DCD12D
	.long 0xd72c005c                                           // 00000047B440: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000047B444: 0202B8FF 83DCD12D
	v_sad_u8 v100, v100, 0, 0x6400                             // 00000047B44C: D6220064 03FD0164 00006400
	v_lshlrev_b32_e32 v91, 16, v91                             // 00000047B458: 30B6B690
	v_dot2acc_f32_f16 v43, v96, v5                             // 00000047B45C: 04560B60
	v_sad_u8 v95, v95, 0, 0x6400                               // 00000047B460: D622005F 03FD015F 00006400
	v_bfe_u32 v96, v88, 12, 16                                 // 00000047B46C: D6100060 02411958
	v_dot2acc_f32_f16 v51, v94, v8                             // 00000047B474: 0466115E
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000047B478: D6220062 03FD0162 00006400
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000047B484: D622005C 03FD015C 00006400
	v_and_b32_e32 v94, 0xffff, v89                             // 00000047B490: 36BCB2FF 0000FFFF
	.long 0xd72c0060                                           // 00000047B498: D72C0060
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 00000047B49C: 0202C0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B4A4: BF870194
	v_lshlrev_b32_e32 v98, 16, v98                             // 00000047B4A8: 30C4C490
	.long 0xd72c005e                                           // 00000047B4AC: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000047B4B0: 0202BCFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047B4B8: BF8701B2
	v_and_or_b32 v92, 0xffff, v92, v98                         // 00000047B4BC: D657005C 058AB8FF 0000FFFF
	.long 0xd72c0062                                           // 00000047B4C8: D72C0062
	v_cndmask_b32_e32 v1, 0x83dcd12d, v102, vcc_lo             // 00000047B4CC: 0202CCFF 83DCD12D
	v_sad_u8 v96, v96, 0, 0x6400                               // 00000047B4D4: D6220060 03FD0160 00006400
	v_pk_fma_f16 v92, v92, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B4E0: CC0E005C 0BFC0F5C 0000C931
	v_sad_u8 v94, v94, 0, 0x6400                               // 00000047B4EC: D622005E 03FD015E 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B4F8: BF870194
	v_sad_u8 v98, v98, 0, 0x6400                               // 00000047B4FC: D6220062 03FD0162 00006400
	v_dot2acc_f32_f16 v45, v92, v2                             // 00000047B508: 045A055C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B50C: BF870193
	v_lshlrev_b32_e32 v94, 16, v94                             // 00000047B510: 30BCBC90
	v_and_or_b32 v91, 0xffff, v98, v91                         // 00000047B514: D657005B 056EC4FF 0000FFFF
	v_bfe_u32 v98, v88, 4, 16                                  // 00000047B520: D6100062 02410958
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000047B528: BF870132
	v_pk_fma_f16 v90, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B52C: CC0E005A 0BFC0F5B 0000C931
	v_bfe_u32 v91, v89, 12, 16                                 // 00000047B538: D610005B 02411959
	v_bfe_u32 v89, v89, 4, 16                                  // 00000047B540: D6100059 02410959
	.long 0xd72c005b                                           // 00000047B548: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000047B54C: 0202B6FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047B554: BF870112
	.long 0xd72c0059                                           // 00000047B558: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000047B55C: 0202B2FF 83DCD12D
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000047B564: D622005B 03FD015B 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047B570: BF870112
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000047B574: D6220059 03FD0159 00006400
	v_and_b32_e32 v91, 0xffff, v91                             // 00000047B580: 36B6B6FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000047B588: BF870232
	v_and_or_b32 v89, 0xffff, v89, v94                         // 00000047B58C: D6570059 057AB2FF 0000FFFF
	v_and_b32_e32 v94, 0xffff, v96                             // 00000047B598: 36BCC0FF 0000FFFF
	v_bfe_u32 v96, v85, 4, 16                                  // 00000047B5A0: D6100060 02410955
	v_lshl_or_b32 v91, v95, 16, v91                            // 00000047B5A8: D656005B 056D215F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047B5B0: BF870114
	v_pk_fma_f16 v89, v89, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B5B4: CC0E0059 0BFC0F59 0000C931
	v_pk_fma_f16 v91, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B5C0: CC0E005B 0BFC0F5B 0000C931
	v_and_b32_e32 v99, 0xffff, v100                            // 00000047B5CC: 36C6C8FF 0000FFFF
	v_sad_u8 v100, v101, 0, 0x6400                             // 00000047B5D4: D6220064 03FD0165 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047B5E0: BF8701A3
	v_dot2acc_f32_f16 v48, v91, v5                             // 00000047B5E4: 04600B5B
	v_dot2acc_f32_f16 v49, v91, v1                             // 00000047B5E8: 0462035B
	v_lshl_or_b32 v97, v100, 16, v99                           // 00000047B5EC: D6560061 058D2164
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047B5F4: BF870113
	v_dot2acc_f32_f16 v48, v89, v6                             // 00000047B5F8: 04600D59
	v_pk_fma_f16 v93, v97, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B5FC: CC0E005D 0BFC0F61 0000C931
	v_bfe_u32 v97, v88, 8, 16                                  // 00000047B608: D6100061 02411158
	v_dual_dot2acc_f32_f16 v43, v92, v6 :: v_dual_and_b32 v88, 0xffff, v88// 00000047B610: CB240D5C 2B58B0FF 0000FFFF
	.long 0xd72c005c                                           // 00000047B61C: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v98, vcc_lo              // 00000047B620: 0202C4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047B628: BF870214
	v_dot2acc_f32_f16 v45, v93, v3                             // 00000047B62C: 045A075D
	.long 0xd72c0061                                           // 00000047B630: D72C0061
	v_cndmask_b32_e32 v1, 0x83dcd12d, v97, vcc_lo              // 00000047B634: 0202C2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B63C: BF870194
	.long 0xd72c0058                                           // 00000047B640: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000047B644: 0202B0FF 83DCD12D
	v_dot2acc_f32_f16 v45, v90, v4                             // 00000047B64C: 045A095A
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000047B650: D622005C 03FD015C 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047B65C: BF870214
	v_sad_u8 v95, v97, 0, 0x6400                               // 00000047B660: D622005F 03FD0161 00006400
	v_sad_u8 v88, v88, 0, 0x6400                               // 00000047B66C: D6220058 03FD0158 00006400
	v_dual_mov_b32 v97, v26 :: v_dual_mov_b32 v26, v65         // 00000047B678: CA10011A 611A0141
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B680: BF870193
	v_lshl_or_b32 v94, v95, 16, v94                            // 00000047B684: D656005E 0579215F
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000047B68C: 30B0B090
	v_bfe_u32 v95, v85, 8, 16                                  // 00000047B690: D610005F 02411155
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047B698: BF870002
	v_and_or_b32 v87, 0xffff, v92, v88                         // 00000047B69C: D6570057 0562B8FF 0000FFFF
	v_bfe_u32 v92, v86, 12, 16                                 // 00000047B6A8: D610005C 02411956
	v_pk_fma_f16 v88, v94, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B6B0: CC0E0058 0BFC0F5E 0000C931
	v_bfe_u32 v94, v85, 12, 16                                 // 00000047B6BC: D610005E 02411955
	v_dot2acc_f32_f16 v49, v89, v2                             // 00000047B6C4: 04620559
	v_pk_fma_f16 v87, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B6C8: CC0E0057 0BFC0F57 0000C931
	.long 0xd72c005c                                           // 00000047B6D4: D72C005C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000047B6D8: 0202B8FF 83DCD12D
	v_dot2acc_f32_f16 v48, v88, v7                             // 00000047B6E0: 04600F58
	.long 0xd72c005e                                           // 00000047B6E4: D72C005E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v94, vcc_lo              // 00000047B6E8: 0202BCFF 83DCD12D
	.long 0xd72c005f                                           // 00000047B6F0: D72C005F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v95, vcc_lo              // 00000047B6F4: 0202BEFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047B6FC: BF870253
	v_dot2acc_f32_f16 v48, v87, v8                             // 00000047B700: 04601157
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000047B704: D622005C 03FD015C 00006400
	v_dot2acc_f32_f16 v43, v93, v7                             // 00000047B710: 04560F5D
	v_bfe_u32 v93, v86, 8, 16                                  // 00000047B714: D610005D 02411156
	v_sad_u8 v94, v94, 0, 0x6400                               // 00000047B71C: D622005E 03FD015E 00006400
	v_dual_dot2acc_f32_f16 v49, v88, v3 :: v_dual_and_b32 v92, 0xffff, v92// 00000047B728: CB240758 315CB8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000047B734: BF870244
	v_dual_dot2acc_f32_f16 v43, v90, v8 :: v_dual_and_b32 v90, 0xffff, v86// 00000047B738: CB24115A 2B5AACFF 0000FFFF
	v_bfe_u32 v86, v86, 4, 16                                  // 00000047B744: D6100056 02410956
	.long 0xd72c005d                                           // 00000047B74C: D72C005D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v93, vcc_lo              // 00000047B750: 0202BAFF 83DCD12D
	v_bfe_u32 v88, v82, 12, 16                                 // 00000047B758: D6100058 02411952
	.long 0xd72c005a                                           // 00000047B760: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000047B764: 0202B4FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047B76C: BF870214
	.long 0xd72c0056                                           // 00000047B770: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000047B774: 0202ACFF 83DCD12D
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000047B77C: D622005D 03FD015D 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047B788: BF870193
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000047B78C: D622005A 03FD015A 00006400
	v_sad_u8 v86, v86, 0, 0x6400                               // 00000047B798: D6220056 03FD0156 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047B7A4: BF870223
	v_lshl_or_b32 v91, v93, 16, v92                            // 00000047B7A8: D656005B 0571215D
	v_dual_dot2acc_f32_f16 v49, v87, v4 :: v_dual_and_b32 v92, 0xffff, v94// 00000047B7B0: CB240957 315CBCFF 0000FFFF
	v_lshlrev_b32_e32 v90, 16, v90                             // 00000047B7BC: 30B4B490
	.long 0xd72c0057                                           // 00000047B7C0: D72C0057
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000047B7C4: 0202B0FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047B7CC: BF870004
	v_pk_fma_f16 v89, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B7D0: CC0E0059 0BFC0F5B 0000C931
	v_bfe_u32 v88, v82, 8, 16                                  // 00000047B7DC: D6100058 02411152
	v_sad_u8 v93, v95, 0, 0x6400                               // 00000047B7E4: D622005D 03FD015F 00006400
	v_and_or_b32 v86, 0xffff, v86, v90                         // 00000047B7F0: D6570056 056AACFF 0000FFFF
	.long 0xd72c005a                                           // 00000047B7FC: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v96, vcc_lo              // 00000047B800: 0202C0FF 83DCD12D
	v_dot2acc_f32_f16 v40, v89, v1                             // 00000047B808: 04500359
	.long 0xd72c0058                                           // 00000047B80C: D72C0058
	v_cndmask_b32_e32 v1, 0x83dcd12d, v88, vcc_lo              // 00000047B810: 0202B0FF 83DCD12D
	v_lshl_or_b32 v91, v93, 16, v92                            // 00000047B818: D656005B 0571215D
	v_pk_fma_f16 v86, v86, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B820: CC0E0056 0BFC0F56 0000C931
	v_and_b32_e32 v85, 0xffff, v85                             // 00000047B82C: 36AAAAFF 0000FFFF
	v_sad_u8 v87, v87, 0, 0x6400                               // 00000047B834: D6220057 03FD0157 00006400
	v_dot2acc_f32_f16 v47, v89, v5                             // 00000047B840: 045E0B59
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000047B844: D622005A 03FD015A 00006400
	v_dot2acc_f32_f16 v40, v86, v2                             // 00000047B850: 04500556
	.long 0xd72c0055                                           // 00000047B854: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000047B858: 0202AAFF 83DCD12D
	v_pk_fma_f16 v84, v91, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B860: CC0E0054 0BFC0F5B 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 00000047B86C: 36AEAEFF 0000FFFF
	v_sad_u8 v88, v88, 0, 0x6400                               // 00000047B874: D6220058 03FD0158 00006400
	v_bfe_u32 v91, v73, 8, 16                                  // 00000047B880: D610005B 02411149
	v_bfe_u32 v92, v73, 4, 16                                  // 00000047B888: D610005C 02410949
	v_dot2acc_f32_f16 v40, v84, v3                             // 00000047B890: 04500754
	v_mov_b32_e32 v94, v32                                     // 00000047B894: 7EBC0320
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000047B898: D6220055 03FD0155 00006400
	v_lshl_or_b32 v87, v88, 16, v87                            // 00000047B8A4: D6560057 055D2158
	.long 0xd72c005b                                           // 00000047B8AC: D72C005B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v91, vcc_lo              // 00000047B8B0: 0202B6FF 83DCD12D
	v_dual_mov_b32 v96, v20 :: v_dual_mov_b32 v95, v35         // 00000047B8B8: CA100114 605E0123
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000047B8C0: BF8701C4
	v_dual_mov_b32 v32, v65 :: v_dual_lshlrev_b32 v85, 16, v85 // 00000047B8C4: CA220141 2054AA90
	s_waitcnt vmcnt(6)                                         // 00000047B8CC: BF891BF7
	v_dual_mov_b32 v20, v71 :: v_dual_mov_b32 v35, v66         // 00000047B8D0: CA100147 14220142
	v_mov_b32_e32 v93, v24                                     // 00000047B8D8: 7EBA0318
	v_and_or_b32 v85, 0xffff, v90, v85                         // 00000047B8DC: D6570055 0556B4FF 0000FFFF
	v_bfe_u32 v90, v73, 12, 16                                 // 00000047B8E8: D610005A 02411949
	v_sad_u8 v91, v91, 0, 0x6400                               // 00000047B8F0: D622005B 03FD015B 00006400
	v_mov_b32_e32 v24, v64                                     // 00000047B8FC: 7E300340
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000047B900: BF870254
	v_pk_fma_f16 v85, v85, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B904: CC0E0055 0BFC0F55 0000C931
	v_dot2acc_f32_f16 v47, v86, v6                             // 00000047B910: 045E0D56
	v_pk_fma_f16 v86, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047B914: CC0E0056 0BFC0F57 0000C931
	v_and_b32_e32 v89, 0xffff, v82                             // 00000047B920: 36B2A4FF 0000FFFF
	v_bfe_u32 v82, v82, 4, 16                                  // 00000047B928: D6100052 02410952
	v_dual_dot2acc_f32_f16 v40, v85, v4 :: v_dual_dot2acc_f32_f16 v47, v84, v7// 00000047B930: CB180955 282E0F54
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047B938: BF870214
	v_dot2acc_f32_f16 v46, v86, v1                             // 00000047B93C: 045C0356
	.long 0xd72c0059                                           // 00000047B940: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v89, vcc_lo              // 00000047B944: 0202B2FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047B94C: BF870004
	.long 0xd72c0052                                           // 00000047B950: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000047B954: 0202A4FF 83DCD12D
	.long 0xd72c005a                                           // 00000047B95C: D72C005A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v90, vcc_lo              // 00000047B960: 0202B4FF 83DCD12D
	v_dual_dot2acc_f32_f16 v44, v86, v5 :: v_dual_dot2acc_f32_f16 v47, v85, v8// 00000047B968: CB180B56 2C2E1155
	v_bfe_u32 v84, v74, 12, 16                                 // 00000047B970: D6100054 0241194A
	v_bfe_u32 v85, v74, 8, 16                                  // 00000047B978: D6100055 0241114A
	v_sad_u8 v89, v89, 0, 0x6400                               // 00000047B980: D6220059 03FD0159 00006400
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000047B98C: D6220052 03FD0152 00006400
	v_sad_u8 v90, v90, 0, 0x6400                               // 00000047B998: D622005A 03FD015A 00006400
	.long 0xd72c0054                                           // 00000047B9A4: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000047B9A8: 0202A8FF 83DCD12D
	.long 0xd72c0055                                           // 00000047B9B0: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000047B9B4: 0202AAFF 83DCD12D
	v_lshlrev_b32_e32 v88, 16, v89                             // 00000047B9BC: 30B0B290
	.long 0xd72c0059                                           // 00000047B9C0: D72C0059
	v_cndmask_b32_e32 v1, 0x83dcd12d, v92, vcc_lo              // 00000047B9C4: 0202B8FF 83DCD12D
	v_and_b32_e32 v90, 0xffff, v90                             // 00000047B9CC: 36B4B4FF 0000FFFF
	s_waitcnt vmcnt(5)                                         // 00000047B9D4: BF8917F7
	v_dual_mov_b32 v92, v19 :: v_dual_mov_b32 v19, v70         // 00000047B9D8: CA100113 5C120146
	v_and_or_b32 v82, 0xffff, v82, v88                         // 00000047B9E0: D6570052 0562A4FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000047B9EC: D6220054 03FD0154 00006400
	v_lshl_or_b32 v87, v91, 16, v90                            // 00000047B9F8: D6560057 0569215B
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000047BA00: D6220055 03FD0155 00006400
	v_sad_u8 v88, v89, 0, 0x6400                               // 00000047BA0C: D6220058 03FD0159 00006400
	v_pk_fma_f16 v82, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BA18: CC0E0052 0BFC0F52 0000C931
	v_and_b32_e32 v73, 0xffff, v73                             // 00000047BA24: 369292FF 0000FFFF
	v_pk_fma_f16 v86, v87, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BA2C: CC0E0056 0BFC0F57 0000C931
	v_bfe_u32 v87, v58, 4, 16                                  // 00000047BA38: D6100057 0241093A
	v_mov_b32_e32 v90, v23                                     // 00000047BA40: 7EB40317
	v_dot2acc_f32_f16 v46, v82, v2                             // 00000047BA44: 045C0552
	.long 0xd72c0049                                           // 00000047BA48: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000047BA4C: 020292FF 83DCD12D
	v_dot2acc_f32_f16 v44, v82, v6                             // 00000047BA54: 04580D52
	v_bfe_u32 v82, v75, 12, 16                                 // 00000047BA58: D6100052 0241194B
	v_mov_b32_e32 v89, v18                                     // 00000047BA60: 7EB20312
	v_dual_dot2acc_f32_f16 v46, v86, v3 :: v_dual_mov_b32 v91, v31// 00000047BA64: CB100756 2E5A011F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047BA6C: BF870214
	v_dot2acc_f32_f16 v44, v86, v7                             // 00000047BA70: 04580F56
	.long 0xd72c0052                                           // 00000047BA74: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000047BA78: 0202A4FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047BA80: D6220049 03FD0149 00006400
	s_waitcnt vmcnt(4)                                         // 00000047BA8C: BF8913F7
	v_dual_mov_b32 v23, v63 :: v_dual_mov_b32 v18, v69         // 00000047BA90: CA10013F 17120145
	v_mov_b32_e32 v31, v64                                     // 00000047BA98: 7E3E0340
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000047BA9C: BF870123
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000047BAA0: 30929290
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000047BAA4: D6220052 03FD0152 00006400
	v_and_or_b32 v73, 0xffff, v88, v73                         // 00000047BAB0: D6570049 0526B0FF 0000FFFF
	v_mov_b32_e32 v88, v30                                     // 00000047BABC: 7EB0031E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047BAC0: BF870223
	v_and_b32_e32 v82, 0xffff, v82                             // 00000047BAC4: 36A4A4FF 0000FFFF
	v_mov_b32_e32 v30, v63                                     // 00000047BACC: 7E3C033F
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BAD0: CC0E0049 0BFC0F49 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000047BADC: BF870141
	v_dot2acc_f32_f16 v46, v73, v4                             // 00000047BAE0: 045C0949
	v_dot2acc_f32_f16 v44, v73, v8                             // 00000047BAE4: 04581149
	v_bfe_u32 v73, v75, 8, 16                                  // 00000047BAE8: D6100049 0241114B
	v_and_b32_e32 v75, 0xffff, v75                             // 00000047BAF0: 369696FF 0000FFFF
	.long 0xd72c0049                                           // 00000047BAF8: D72C0049
	v_cndmask_b32_e32 v1, 0x83dcd12d, v73, vcc_lo              // 00000047BAFC: 020292FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047BB04: BF870112
	.long 0xd72c004b                                           // 00000047BB08: D72C004B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v75, vcc_lo              // 00000047BB0C: 020296FF 83DCD12D
	v_sad_u8 v73, v73, 0, 0x6400                               // 00000047BB14: D6220049 03FD0149 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047BB20: BF870112
	v_sad_u8 v75, v75, 0, 0x6400                               // 00000047BB24: D622004B 03FD014B 00006400
	v_lshl_or_b32 v73, v73, 16, v82                            // 00000047BB30: D6560049 05492149
	v_sad_u8 v82, v83, 0, 0x6400                               // 00000047BB38: D6220052 03FD0153 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000047BB44: BF870193
	v_lshlrev_b32_e32 v75, 16, v75                             // 00000047BB48: 30969690
	v_pk_fma_f16 v73, v73, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BB4C: CC0E0049 0BFC0F49 0000C931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047BB58: BF8701A2
	v_and_or_b32 v75, 0xffff, v82, v75                         // 00000047BB5C: D657004B 052EA4FF 0000FFFF
	v_bfe_u32 v82, v59, 12, 16                                 // 00000047BB68: D6100052 0241193B
	v_dot2acc_f32_f16 v41, v73, v5                             // 00000047BB70: 04520B49
	v_dot2acc_f32_f16 v42, v73, v1                             // 00000047BB74: 04540349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047BB78: BF8701B4
	v_pk_fma_f16 v75, v75, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BB7C: CC0E004B 0BFC0F4B 0000C931
	v_and_b32_e32 v84, 0xffff, v84                             // 00000047BB88: 36A8A8FF 0000FFFF
	.long 0xd72c0052                                           // 00000047BB90: D72C0052
	v_cndmask_b32_e32 v1, 0x83dcd12d, v82, vcc_lo              // 00000047BB94: 0202A4FF 83DCD12D
	v_dot2acc_f32_f16 v41, v75, v6                             // 00000047BB9C: 04520D4B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000047BBA0: BF870003
	v_lshl_or_b32 v60, v85, 16, v84                            // 00000047BBA4: D656003C 05512155
	v_bfe_u32 v84, v59, 8, 16                                  // 00000047BBAC: D6100054 0241113B
	v_dot2acc_f32_f16 v42, v75, v2                             // 00000047BBB4: 0454054B
	v_bfe_u32 v85, v58, 12, 16                                 // 00000047BBB8: D6100055 0241193A
	v_sad_u8 v82, v82, 0, 0x6400                               // 00000047BBC0: D6220052 03FD0152 00006400
	v_pk_fma_f16 v60, v60, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BBCC: CC0E003C 0BFC0F3C 0000C931
	v_and_b32_e32 v86, 0xffff, v74                             // 00000047BBD8: 36AC94FF 0000FFFF
	v_bfe_u32 v74, v74, 4, 16                                  // 00000047BBE0: D610004A 0241094A
	.long 0xd72c0054                                           // 00000047BBE8: D72C0054
	v_cndmask_b32_e32 v1, 0x83dcd12d, v84, vcc_lo              // 00000047BBEC: 0202A8FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047BBF4: BF870214
	v_dual_dot2acc_f32_f16 v41, v60, v7 :: v_dual_and_b32 v82, 0xffff, v82// 00000047BBF8: CB240F3C 2952A4FF 0000FFFF
	.long 0xd72c0056                                           // 00000047BC04: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000047BC08: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047BC10: BF870004
	.long 0xd72c004a                                           // 00000047BC14: D72C004A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v74, vcc_lo              // 00000047BC18: 020294FF 83DCD12D
	.long 0xd72c0055                                           // 00000047BC20: D72C0055
	v_cndmask_b32_e32 v1, 0x83dcd12d, v85, vcc_lo              // 00000047BC24: 0202AAFF 83DCD12D
	v_mov_b32_e32 v75, v81                                     // 00000047BC2C: 7E960351
	v_sad_u8 v84, v84, 0, 0x6400                               // 00000047BC30: D6220054 03FD0154 00006400
	v_sad_u8 v83, v86, 0, 0x6400                               // 00000047BC3C: D6220053 03FD0156 00006400
	v_sad_u8 v74, v74, 0, 0x6400                               // 00000047BC48: D622004A 03FD014A 00006400
	v_bfe_u32 v86, v58, 8, 16                                  // 00000047BC54: D6100056 0241113A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000047BC5C: BF870234
	v_lshl_or_b32 v82, v84, 16, v82                            // 00000047BC60: D6560052 05492154
	v_sad_u8 v85, v85, 0, 0x6400                               // 00000047BC68: D6220055 03FD0155 00006400
	v_lshlrev_b32_e32 v83, 16, v83                             // 00000047BC74: 30A6A690
	.long 0xd72c0056                                           // 00000047BC78: D72C0056
	v_cndmask_b32_e32 v1, 0x83dcd12d, v86, vcc_lo              // 00000047BC7C: 0202ACFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047BC84: BF870214
	v_pk_fma_f16 v73, v82, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BC88: CC0E0049 0BFC0F52 0000C931
	v_and_b32_e32 v84, 0xffff, v85                             // 00000047BC94: 36A8AAFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047BC9C: BF870004
	v_and_or_b32 v74, 0xffff, v74, v83                         // 00000047BCA0: D657004A 054E94FF 0000FFFF
	v_and_b32_e32 v83, 0xffff, v59                             // 00000047BCAC: 36A676FF 0000FFFF
	v_bfe_u32 v59, v59, 4, 16                                  // 00000047BCB4: D610003B 0241093B
	v_dot2acc_f32_f16 v38, v73, v5                             // 00000047BCBC: 044C0B49
	v_dot2acc_f32_f16 v39, v73, v1                             // 00000047BCC0: 044E0349
	v_pk_fma_f16 v74, v74, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BCC4: CC0E004A 0BFC0F4A 0000C931
	.long 0xd72c0053                                           // 00000047BCD0: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v83, vcc_lo              // 00000047BCD4: 0202A6FF 83DCD12D
	.long 0xd72c003b                                           // 00000047BCDC: D72C003B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v59, vcc_lo              // 00000047BCE0: 020276FF 83DCD12D
	v_and_b32_e32 v58, 0xffff, v58                             // 00000047BCE8: 367474FF 0000FFFF
	v_sad_u8 v85, v86, 0, 0x6400                               // 00000047BCF0: D6220055 03FD0156 00006400
	v_dot2acc_f32_f16 v41, v74, v8                             // 00000047BCFC: 0452114A
	v_mov_b32_e32 v73, v25                                     // 00000047BD00: 7E920319
	v_mov_b32_e32 v86, v17                                     // 00000047BD04: 7EAC0311
	.long 0xd72c003a                                           // 00000047BD08: D72C003A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v58, vcc_lo              // 00000047BD0C: 020274FF 83DCD12D
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000047BD14: D6220053 03FD0153 00006400
	v_sad_u8 v59, v59, 0, 0x6400                               // 00000047BD20: D622003B 03FD013B 00006400
	v_lshl_or_b32 v82, v85, 16, v84                            // 00000047BD2C: D6560052 05512155
	v_dual_mov_b32 v85, v27 :: v_dual_mov_b32 v84, v21         // 00000047BD34: CA10011B 55540115
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047BD3C: BF870004
	v_lshlrev_b32_e32 v83, 16, v83                             // 00000047BD40: 30A6A690
	v_mov_b32_e32 v25, v61                                     // 00000047BD44: 7E32033D
	v_sad_u8 v58, v58, 0, 0x6400                               // 00000047BD48: D622003A 03FD013A 00006400
	v_pk_fma_f16 v1, v82, s7, 0xc931 op_sel_hi:[1,0,0]         // 00000047BD54: CC0E0001 0BFC0F52 0000C931
	v_mov_b32_e32 v82, v16                                     // 00000047BD60: 7EA40310
	v_and_or_b32 v59, 0xffff, v59, v83                         // 00000047BD64: D657003B 054E76FF 0000FFFF
	.long 0xd72c0053                                           // 00000047BD70: D72C0053
	v_cndmask_b32_e32 v1, 0x83dcd12d, v87, vcc_lo              // 00000047BD74: 0202AEFF 83DCD12D
	v_dual_mov_b32 v87, v22 :: v_dual_lshlrev_b32 v58, 16, v58 // 00000047BD7C: CA220116 573A7490
	v_mov_b32_e32 v21, v61                                     // 00000047BD84: 7E2A033D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047BD88: BF870004
	v_pk_fma_f16 v59, v59, s7, 0xc931 op_sel_hi:[1,0,0]        // 00000047BD8C: CC0E003B 0BFC0F3B 0000C931
	v_dot2acc_f32_f16 v42, v60, v3                             // 00000047BD98: 0454073C
	s_waitcnt vmcnt(2)                                         // 00000047BD9C: BF890BF7
	v_dual_mov_b32 v16, v67 :: v_dual_mov_b32 v27, v62         // 00000047BDA0: CA100143 101A013E
	v_sad_u8 v83, v83, 0, 0x6400                               // 00000047BDA8: D6220053 03FD0153 00006400
	v_dot2acc_f32_f16 v39, v59, v2                             // 00000047BDB4: 044E053B
	v_dot2acc_f32_f16 v38, v59, v6                             // 00000047BDB8: 044C0D3B
	v_dot2acc_f32_f16 v42, v74, v4                             // 00000047BDBC: 0454094A
	v_mov_b32_e32 v22, v62                                     // 00000047BDC0: 7E2C033E
	v_and_or_b32 v5, 0xffff, v83, v58                          // 00000047BDC4: D6570005 04EAA6FF 0000FFFF
	v_dot2acc_f32_f16 v39, v1, v3                              // 00000047BDD0: 044E0701
	v_dual_dot2acc_f32_f16 v38, v1, v7 :: v_dual_add_nc_u32 v1, v54, v9// 00000047BDD4: CB200F01 26001336
	v_mov_b32_e32 v3, v28                                      // 00000047BDDC: 7E06031C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047BDE0: BF870224
	v_pk_fma_f16 v2, v5, s7, 0xc931 op_sel_hi:[1,0,0]          // 00000047BDE4: CC0E0002 0BFC0F05 0000C931
	v_dual_mov_b32 v17, v68 :: v_dual_mov_b32 v28, v66         // 00000047BDF0: CA100144 111C0142
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 00000047BDF8: 7C940282
	v_mov_b32_e32 v83, v80                                     // 00000047BDFC: 7EA60350
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047BE00: BF870004
	v_dot2acc_f32_f16 v39, v2, v4                              // 00000047BE04: 044E0902
	v_dot2acc_f32_f16 v38, v2, v8                              // 00000047BE08: 044C1102
	v_dual_mov_b32 v2, v15 :: v_dual_mov_b32 v15, v72          // 00000047BE0C: CA10010F 020E0148
	v_dual_mov_b32 v74, v79 :: v_dual_mov_b32 v59, v78         // 00000047BE14: CA10014F 4A3A014E
	v_mov_b32_e32 v60, v77                                     // 00000047BE1C: 7E78034D
	v_mov_b32_e32 v58, v76                                     // 00000047BE20: 7E74034C
	s_or_b32 s6, vcc_lo, s6                                    // 00000047BE24: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047BE28: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000047BE2C: 917E067E
	s_cbranch_execz 68                                         // 00000047BE30: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c44>
	s_waitcnt vmcnt(1)                                         // 00000047BE34: BF8907F7
	v_dual_mov_b32 v81, v10 :: v_dual_mov_b32 v80, v37         // 00000047BE38: CA10010A 51500125
	s_waitcnt vmcnt(0)                                         // 00000047BE40: BF8903F7
	v_dual_mov_b32 v79, v34 :: v_dual_mov_b32 v78, v29         // 00000047BE44: CA100122 4F4E011D
	s_waitcnt vmcnt(0)                                         // 00000047BE4C: BF8903F7
	v_dual_mov_b32 v77, v36 :: v_dual_mov_b32 v76, v33         // 00000047BE50: CA100124 4D4C0121
	s_mov_b32 s8, exec_lo                                      // 00000047BE58: BE88007E
	.long 0xd4c1007e                                           // 00000047BE5C: D4C1007E
	v_cndmask_b32_e32 v1, v9, v14, vcc_lo                      // 00000047BE60: 02021D09
	s_cbranch_execz 64587                                      // 00000047BE64: BFA5FC4B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc94>
	v_ashrrev_i32_e32 v10, 31, v9                              // 00000047BE68: 3414129F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047BE6C: BF870091
	.long 0xd73c0004                                           // 00000047BE70: D73C0004
	v_cndmask_b32_e32 v1, 10, v9, vcc_lo                       // 00000047BE74: 0202128A
	.long 0xd7006a01                                           // 00000047BE78: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 00000047BE7C: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047BE80: BF870111
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 00000047BE84: D5207C07 01AA0A05
	.long 0xd7006a04                                           // 00000047BE8C: D7006A04
	v_cndmask_b32_e32 v1, v1, v55, vcc_lo                      // 00000047BE90: 02026F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047BE94: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 00000047BE98: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 00000047BEA0: D7006A06
	v_cndmask_b32_e32 v1, v1, v57, vcc_lo                      // 00000047BEA4: 02027301
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 00000047BEA8: D5207C07 01AA0E80
	s_clause 0xf                                               // 00000047BEB0: BF85000F
	global_load_b32 v66, v[4:5], off                           // 00000047BEB4: DC520000 427C0004
	global_load_b32 v65, v[4:5], off offset:128                // 00000047BEBC: DC520080 417C0004
	global_load_b32 v64, v[4:5], off offset:256                // 00000047BEC4: DC520100 407C0004
	global_load_b32 v63, v[4:5], off offset:384                // 00000047BECC: DC520180 3F7C0004
	global_load_b32 v62, v[4:5], off offset:512                // 00000047BED4: DC520200 3E7C0004
	global_load_b32 v61, v[4:5], off offset:640                // 00000047BEDC: DC520280 3D7C0004
	global_load_b32 v34, v[4:5], off offset:768                // 00000047BEE4: DC520300 227C0004
	global_load_b32 v33, v[4:5], off offset:896                // 00000047BEEC: DC520380 217C0004
	global_load_b32 v72, v[6:7], off                           // 00000047BEF4: DC520000 487C0006
	global_load_b32 v71, v[6:7], off offset:128                // 00000047BEFC: DC520080 477C0006
	global_load_b32 v70, v[6:7], off offset:256                // 00000047BF04: DC520100 467C0006
	global_load_b32 v69, v[6:7], off offset:384                // 00000047BF0C: DC520180 457C0006
	global_load_b32 v68, v[6:7], off offset:512                // 00000047BF14: DC520200 447C0006
	global_load_b32 v67, v[6:7], off offset:640                // 00000047BF1C: DC520280 437C0006
	global_load_b32 v10, v[6:7], off offset:768                // 00000047BF24: DC520300 0A7C0006
	global_load_b32 v29, v[6:7], off offset:896                // 00000047BF2C: DC520380 1D7C0006
	s_waitcnt vmcnt(8)                                         // 00000047BF34: BF8923F7
	v_dual_mov_b32 v37, v34 :: v_dual_mov_b32 v36, v33         // 00000047BF38: CA100122 25240121
	s_branch 64532                                             // 00000047BF40: BFA0FC14 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xc94>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000047BF44: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047BF48: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 00000047BF4C: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000047BF50: BF895FF7
	v_dual_mov_b32 v1, v53 :: v_dual_mov_b32 v2, v50           // 00000047BF54: CA100135 01020132
	s_waitcnt vmcnt(15)                                        // 00000047BF5C: BF893FF7
	v_dual_mov_b32 v3, v52 :: v_dual_mov_b32 v6, v51           // 00000047BF60: CA100134 03060133
	v_dual_mov_b32 v4, v45 :: v_dual_mov_b32 v5, v43           // 00000047BF68: CA10012D 0404012B
	v_dual_mov_b32 v8, v49 :: v_dual_mov_b32 v9, v48           // 00000047BF70: CA100131 08080130
	s_waitcnt vmcnt(1)                                         // 00000047BF78: BF8907F7
	v_dual_mov_b32 v7, v40 :: v_dual_mov_b32 v10, v47          // 00000047BF7C: CA100128 070A012F
	v_dual_mov_b32 v14, v46 :: v_dual_mov_b32 v15, v44         // 00000047BF84: CA10012E 0E0E012C
	v_dual_mov_b32 v16, v42 :: v_dual_mov_b32 v17, v41         // 00000047BF8C: CA10012A 10100129
	v_dual_mov_b32 v18, v39 :: v_dual_mov_b32 v19, v38         // 00000047BF94: CA100127 12120126
	s_mov_b32 s0, 0x76543210                                   // 00000047BF9C: BE8000FF 76543210
	s_waitcnt vmcnt(0)                                         // 00000047BFA4: BF8903F7
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000047BFA8: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000047BFB4: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000047BFC0: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000047BFCC: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000047BFD8: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000047BFE4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000047BFF0: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000047BFFC: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000047C008: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000047C014: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000047C020: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000047C02C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000047C038: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 00000047C044: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000047C050: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000047C05C: D65C0013 03FC0113 FEDCBA98
	.long 0xd44c0000                                           // 00000047C068: D44C0000
	v_cndmask_b32_e32 v1, 16, v13, vcc_lo                      // 00000047C06C: 02021A90
	s_barrier                                                  // 00000047C070: BFBD0000
	buffer_gl0_inv                                             // 00000047C074: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000047C07C: BE812000
	s_cbranch_execz 34                                         // 00000047C080: BFA50022 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e0c>
	v_dual_add_f32 v8, v49, v8 :: v_dual_add_f32 v3, v52, v3   // 00000047C084: C9081131 08020734
	v_dual_add_f32 v6, v51, v6 :: v_dual_add_f32 v1, v53, v1   // 00000047C08C: C9080D33 06000335
	v_lshl_or_b32 v12, v11, 10, v12                            // 00000047C094: D656000C 0431150B
	v_dual_add_f32 v2, v50, v2 :: v_dual_add_f32 v5, v43, v5   // 00000047C09C: C9080532 02040B2B
	v_dual_add_f32 v4, v45, v4 :: v_dual_add_f32 v7, v40, v7   // 00000047C0A4: C908092D 04060F28
	v_dual_add_f32 v10, v47, v10 :: v_dual_add_f32 v9, v48, v9 // 00000047C0AC: C908152F 0A081330
	v_dual_add_f32 v15, v44, v15 :: v_dual_add_f32 v14, v46, v14// 00000047C0B4: C9081F2C 0F0E1D2E
	v_dual_add_f32 v13, v38, v19 :: v_dual_add_f32 v18, v39, v18// 00000047C0BC: C9082726 0D122527
	v_dual_add_f32 v17, v41, v17 :: v_dual_add_f32 v16, v42, v16// 00000047C0C4: C9082329 1110212A
	ds_store_2addr_b32 v12, v1, v3 offset1:16                  // 00000047C0CC: D8381000 0003010C
	ds_store_2addr_b32 v12, v2, v6 offset0:128 offset1:144     // 00000047C0D4: D8389080 0006020C
	ds_store_2addr_b32 v12, v4, v8 offset0:32 offset1:48       // 00000047C0DC: D8383020 0008040C
	ds_store_2addr_b32 v12, v5, v9 offset0:160 offset1:176     // 00000047C0E4: D838B0A0 0009050C
	ds_store_2addr_b32 v12, v7, v14 offset0:64 offset1:80      // 00000047C0EC: D8385040 000E070C
	ds_store_2addr_b32 v12, v10, v15 offset0:192 offset1:208   // 00000047C0F4: D838D0C0 000F0A0C
	ds_store_2addr_b32 v12, v16, v18 offset0:96 offset1:112    // 00000047C0FC: D8387060 0012100C
	ds_store_2addr_b32 v12, v17, v13 offset0:224 offset1:240   // 00000047C104: D838F0E0 000D110C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000047C10C: 8C7E017E
	.long 0xd44c0001                                           // 00000047C110: D44C0001
	v_cndmask_b32_e32 v1, 0x100, v0, vcc_lo                    // 00000047C114: 020200FF 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000047C11C: BF89FC07
	s_barrier                                                  // 00000047C120: BFBD0000
	buffer_gl0_inv                                             // 00000047C124: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047C12C: BE852001
	s_cbranch_execnz 9                                         // 00000047C130: BFA60009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e58>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047C134: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000047C138: BF048221
	s_mov_b32 s5, -1                                           // 00000047C13C: BE8500C1
	s_cbranch_scc0 35                                          // 00000047C140: BFA10023 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ed0>
	s_and_b32 vcc_lo, exec_lo, s5                              // 00000047C144: 8B6A057E
	s_cbranch_vccnz 193                                        // 00000047C148: BFA400C1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2150>
	s_nop 0                                                    // 00000047C14C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000047C150: BFB60003
	s_endpgm                                                   // 00000047C154: BFB00000
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000047C158: 300E0082
	ds_load_2addr_stride64_b32 v[1:2], v7 offset1:4            // 00000047C15C: D8E00400 01000007
	ds_load_2addr_stride64_b32 v[3:4], v7 offset0:8 offset1:12 // 00000047C164: D8E00C08 03000007
	ds_load_2addr_stride64_b32 v[5:6], v7 offset0:16 offset1:20// 00000047C16C: D8E01410 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000047C174: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000047C178: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047C17C: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000047C180: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000047C184: BF89FC17
	v_add_f32_e32 v3, v1, v3                                   // 00000047C188: 06060701
	ds_load_2addr_stride64_b32 v[1:2], v7 offset0:24 offset1:28// 00000047C18C: D8E01C18 01000007
	v_add_f32_e32 v3, v3, v4                                   // 00000047C194: 06060903
	s_waitcnt lgkmcnt(1)                                       // 00000047C198: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C19C: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000047C1A0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000047C1A4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000047C1A8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C1AC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000047C1B0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000047C1B4: 06020501
	ds_store_b32 v7, v1 offset:8192                            // 00000047C1B8: D8342000 00000107
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047C1C0: 8C7E057E
	s_cmp_lt_i32 s33, 2                                        // 00000047C1C4: BF048221
	s_mov_b32 s5, -1                                           // 00000047C1C8: BE8500C1
	s_cbranch_scc1 65501                                       // 00000047C1CC: BFA2FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e44>
	s_waitcnt lgkmcnt(0)                                       // 00000047C1D0: BF89FC07
	s_barrier                                                  // 00000047C1D4: BFBD0000
	buffer_gl0_inv                                             // 00000047C1D8: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047C1E0: BE852001
	s_cbranch_execz 41                                         // 00000047C1E4: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1f8c>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000047C1E8: 32020087
	s_ashr_i32 s6, s18, 31                                     // 00000047C1EC: 86069F12
	v_lshlrev_b32_e32 v4, 2, v0                                // 00000047C1F0: 30080082
	s_delay_alu instid0(VALU_DEP_2)                            // 00000047C1F4: BF870002
	v_lshl_or_b32 v1, s4, 1, v1                                // 00000047C1F8: D6560001 04050204
	s_ashr_i32 s4, s4, 31                                      // 00000047C200: 86049F04
	ds_load_b32 v4, v4 offset:8192                             // 00000047C204: D8D82000 04000004
	s_mul_i32 s4, s4, s18                                      // 00000047C20C: 96041204
	.long 0xd72c0003                                           // 00000047C210: D72C0003
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000047C214: 02000D01
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 00000047C218: D6FE7C01 02002501
	s_lshl_b32 s6, s2, 7                                       // 00000047C220: 84068702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000047C224: BF870499
	s_ashr_i32 s7, s6, 31                                      // 00000047C228: 86079F06
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000047C22C: 84868206
	v_add3_u32 v2, v2, v3, s4                                  // 00000047C230: D6550002 00120702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000047C238: 360600FF 0000007F
	s_add_u32 s4, s24, s6                                      // 00000047C240: 80040618
	s_addc_u32 s6, s25, s7                                     // 00000047C244: 82060719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047C248: BF870112
	.long 0xd73c0001                                           // 00000047C24C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000047C250: 02020282
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000047C254: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C258: BF870092
	.long 0xd7006a01                                           // 00000047C25C: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000047C260: 02020204
	v_add_co_ci_u32_e64 v2, null, s6, v2, vcc_lo               // 00000047C264: D5207C02 01AA0406
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C26C: BF870092
	.long 0xd7006a01                                           // 00000047C270: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000047C274: 02020701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000047C278: D5207C02 01AA0480
	s_waitcnt lgkmcnt(0)                                       // 00000047C280: BF89FC07
	global_store_b32 v[1:2], v4, off                           // 00000047C284: DC6A0000 007C0401
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047C28C: 8C7E057E
	.long 0xd44a0004                                           // 00000047C290: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000047C294: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000047C298: BC7C0000
	buffer_gl1_inv                                             // 00000047C29C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000047C2A4: E0AC0000 00000000
	s_barrier                                                  // 00000047C2AC: BFBD0000
	buffer_gl0_inv                                             // 00000047C2B0: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000047C2B8: BE852004
	s_cbranch_execz 29                                         // 00000047C2BC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2034>
	s_mov_b32 s7, exec_lo                                      // 00000047C2C0: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000047C2C4: BE86007E
	.long 0xd71f0001                                           // 00000047C2C8: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000047C2CC: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C2D0: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000047C2D4: 7D940280
	s_cbranch_execz 9                                          // 00000047C2D8: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2000>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000047C2DC: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000047C2E0: BF8704B9
	s_add_u32 s8, s26, s8                                      // 00000047C2E4: 8008081A
	s_addc_u32 s9, s27, s9                                     // 00000047C2E8: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 00000047C2EC: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000047C2F0: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000047C2F8: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000047C300: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000047C304: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000047C308: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C30C: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000047C310: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000047C318: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000047C31C: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000047C320: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000047C324: D5010001 01A90280
	ds_store_b32 v2, v1 offset:10240                           // 00000047C32C: D8342800 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047C334: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000047C338: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000047C33C: BF89FC07
	s_barrier                                                  // 00000047C340: BFBD0000
	buffer_gl0_inv                                             // 00000047C344: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:10240                            // 00000047C34C: D8D82800 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000047C354: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000047C358: 7C940280
	s_cbranch_vccnz 59                                         // 00000047C35C: BFA4003B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x214c>
	buffer_gl1_inv                                             // 00000047C360: E0B00000 00000000
	buffer_gl0_inv                                             // 00000047C368: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000047C370: BE852001
	s_cbranch_execz 41                                         // 00000047C374: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x211c>
	v_and_b32_e32 v2, 0x7f, v0                                 // 00000047C378: 360400FF 0000007F
	s_lshl_b32 s6, s2, 7                                       // 00000047C380: 84068702
	s_ashr_i32 s1, s18, 31                                     // 00000047C384: 86019F12
	s_ashr_i32 s7, s6, 31                                      // 00000047C388: 86079F06
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000047C38C: 32020087
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 2, v2       // 00000047C390: CA220080 02020482
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000047C398: 84868206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047C39C: BF8700A9
	s_add_u32 s6, s24, s6                                      // 00000047C3A0: 80060618
	s_addc_u32 s7, s25, s7                                     // 00000047C3A4: 82070719
	.long 0xd7000603                                           // 00000047C3A8: D7000603
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000047C3AC: 02020606
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C3B0: BF870001
	v_add_co_ci_u32_e64 v4, null, s7, 0, s6                    // 00000047C3B4: D5207C04 00190007
	s_nop 0                                                    // 00000047C3BC: BF800000
	v_mad_u64_u32 v[5:6], null, v1, s18, 0                     // 00000047C3C0: D6FE7C05 02002501
	s_add_i32 s33, s33, -1                                     // 00000047C3C8: 8121C121
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000047C3CC: BF870139
	s_cmp_eq_u32 s33, 0                                        // 00000047C3D0: BF068021
	v_mad_u64_u32 v[6:7], null, v1, s1, v[6:7]                 // 00000047C3D4: D6FE7C06 04180301
	v_add_nc_u32_e32 v1, 2, v1                                 // 00000047C3DC: 4A020282
	.long 0xd73c0005                                           // 00000047C3E0: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000047C3E4: 02020A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C3E8: BF870091
	.long 0xd7006a05                                           // 00000047C3EC: D7006A05
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 00000047C3F0: 02020B03
	v_add_co_ci_u32_e64 v6, null, v4, v6, vcc_lo               // 00000047C3F4: D5207C06 01AA0D04
	global_load_b32 v5, v[5:6], off glc                        // 00000047C3FC: DC524000 057C0005
	s_waitcnt vmcnt(0)                                         // 00000047C404: BF8903F7
	v_add_f32_e32 v2, v2, v5                                   // 00000047C408: 06040B02
	s_cbranch_scc0 65516                                       // 00000047C40C: BFA1FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x20c0>
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000047C410: 30020082
	ds_store_b32 v1, v2 offset:8192                            // 00000047C414: D8342000 00000201
	s_or_b32 exec_lo, exec_lo, s5                              // 00000047C41C: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000047C420: BE812004
	s_cbranch_execz 6                                          // 00000047C424: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2140>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000047C428: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000047C42C: 7E020280
	s_add_u32 s4, s26, s4                                      // 00000047C430: 8004041A
	s_addc_u32 s5, s27, s5                                     // 00000047C434: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 00000047C438: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000047C440: 8C7E017E
	s_cbranch_execz 65345                                      // 00000047C444: BFA5FF41 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	s_branch 1                                                 // 00000047C448: BFA00001 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2150>
	s_branch 65343                                             // 00000047C44C: BFA0FF3F <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_cmp_gt_i32_e32 vcc_lo, s16, v11                          // 00000047C450: 7C881610
	.long 0xd44c0001                                           // 00000047C454: D44C0001
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000047C458: 020200C0
	s_waitcnt lgkmcnt(0)                                       // 00000047C45C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000047C460: BC7C0000
	s_barrier                                                  // 00000047C464: BFBD0000
	buffer_gl0_inv                                             // 00000047C468: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000047C470: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000047C474: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000047C478: BE832001
	s_cbranch_execz 65331                                      // 00000047C47C: BFA5FF33 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_and_b32_e32 v1, 15, v0                                   // 00000047C480: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C484: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000047C488: 30040282
	v_lshl_or_b32 v2, v11, 9, v2                               // 00000047C48C: D6560002 0409130B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C494: BF870001
	v_add_nc_u32_e32 v8, 0x2000, v2                            // 00000047C498: 4A1004FF 00002000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000047C4A0: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000047C4A8: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000047C4B0: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000047C4B8: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000047C4C0: 36140081
	s_waitcnt lgkmcnt(3)                                       // 00000047C4C4: BF89FC37
	v_dual_add_f32 v14, v2, v3 :: v_dual_and_b32 v13, 4, v0    // 00000047C4C8: C9240702 0E0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000047C4D0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000047C4D4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000047C4DC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000047C4E0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000047C4E8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000047C4EC: C9480F06 06061308
	v_sub_f32_e32 v8, v8, v9                                   // 00000047C4F4: 08101308
	v_dual_add_f32 v9, v14, v3 :: v_dual_and_b32 v12, 2, v0    // 00000047C4F8: C924070E 090C0082
	v_sub_f32_e32 v3, v14, v3                                  // 00000047C500: 0806070E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000047C504: BF8701B4
	v_dual_add_f32 v14, v2, v4 :: v_dual_add_f32 v15, v5, v7   // 00000047C508: C9080902 0E0E0F05
	v_sub_f32_e32 v2, v2, v4                                   // 00000047C510: 08040902
	v_dual_add_f32 v4, v6, v8 :: v_dual_sub_f32 v5, v5, v7     // 00000047C514: C90A1106 04040F05
	v_dual_sub_f32 v6, v6, v8 :: v_dual_add_f32 v7, v9, v15    // 00000047C51C: C9481106 06061F09
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000047C524: BF870222
	v_dual_sub_f32 v8, v9, v15 :: v_dual_add_f32 v9, v14, v4   // 00000047C528: C9481F09 0808090E
	v_sub_f32_e32 v4, v14, v4                                  // 00000047C530: 0808090E
	v_add_f32_e32 v14, v3, v5                                  // 00000047C534: 061C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000047C538: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000047C53C: 060A0D02
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000047C540: 7C941480
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C544: 7E1402FA FF016109
	v_mov_b32_dpp v18, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C54C: 7E2402FA FF016104
	v_mov_b32_dpp v15, v14 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C554: 7E1E02FA FF01610E
	v_mov_b32_dpp v16, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C55C: 7E2002FA FF016105
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000047C564: D5010009 21AA1309
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000047C56C: D5010005 21AA0B05
	v_sub_f32_e32 v2, v2, v6                                   // 00000047C574: 08040D02
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000047C578: D5010004 21AA0904
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000047C580: D501000E 21AA1D0E
	v_mov_b32_dpp v17, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C588: 7E2202FA FF016108
	v_add_f32_e32 v5, v5, v16                                  // 00000047C590: 060A2105
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C594: 7E2A02FA FF016102
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 00000047C59C: D5010016 21AA0502
	v_add_f32_e32 v2, v9, v10                                  // 00000047C5A4: 06041509
	v_add_f32_e32 v9, v4, v18                                  // 00000047C5A8: 06122504
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C5AC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000047C5B4: D5010007 21AA0F07
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000047C5BC: D5010008 21AA1108
	v_mov_b32_dpp v19, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000047C5C4: 7E2602FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 00000047C5CC: D5010014 21AA0703
	v_cmp_eq_u32_e32 vcc_lo, 0, v12                            // 00000047C5D4: 7C941880
	v_add_f32_e32 v3, v7, v6                                   // 00000047C5D8: 06060D07
	.long 0xd44a0001                                           // 00000047C5DC: D44A0001
	v_cndmask_b32_e32 v1, 0, v13, vcc_lo                       // 00000047C5E0: 02021A80
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C5E4: 7E1802FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000047C5EC: D5010005 21AA0B05
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047C5F4: BF8700A4
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C5F8: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000047C600: D5010003 21AA0703
	v_add_f32_e32 v3, v3, v4                                   // 00000047C608: 06060903
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C60C: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000047C614: D5010002 21AA0502
	v_add_f32_e32 v4, v5, v12                                  // 00000047C61C: 06081905
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000047C620: BF8700A4
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C624: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000047C62C: D5010003 20060703
	v_dual_add_f32 v2, v2, v7 :: v_dual_add_f32 v3, v3, v5     // 00000047C634: C9080F02 02020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C63C: BF870001
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000047C640: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C648: 7E0402FA FF016402
	v_add_f32_e32 v6, v14, v15                                 // 00000047C650: 060C1F0E
	v_add_f32_e32 v14, v22, v21                                // 00000047C654: 061C2B16
	v_mov_b32_dpp v15, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C658: 7E1E02FA FF016209
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000047C660: D5010009 21AA1309
	v_add_f32_e32 v7, v7, v2                                   // 00000047C668: 060E0507
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C66C: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000047C674: D5010006 21AA0D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000047C67C: BF870234
	v_dual_add_f32 v8, v8, v17 :: v_dual_add_f32 v9, v9, v15   // 00000047C680: C9082308 08081F09
	v_mov_b32_dpp v16, v14 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C688: 7E2002FA FF01620E
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000047C690: D501000E 21AA1D0E
	v_add_f32_e32 v6, v6, v10                                  // 00000047C698: 060C1506
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C69C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000047C6A4: D5010004 20060904
	v_mov_b32_dpp v13, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C6AC: 7E1A02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000047C6B4: D5010008 21AA1108
	v_mov_b32_dpp v12, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C6BC: 7E1802FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000047C6C4: D5010006 20060D06
	v_add_f32_e32 v4, v4, v10                                  // 00000047C6CC: 06081504
	v_add_f32_e32 v10, v20, v19                                // 00000047C6D0: 06142714
	v_add_f32_e32 v8, v8, v13                                  // 00000047C6D4: 06101B08
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C6D8: 7E0402FA FF016803
	v_add_f32_e32 v6, v6, v12                                  // 00000047C6E0: 060C1906
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C6E4: 7E0A02FA FF016807
	v_mov_b32_dpp v13, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000047C6EC: 7E1A02FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000047C6F4: D501000A 21AA150A
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C6FC: 7E1802FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s1                         // 00000047C704: D501000F 20061108
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C70C: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047C714: BF870004
	v_add_f32_e32 v10, v10, v13                                // 00000047C718: 06141B0A
	v_add_f32_e32 v13, v14, v16                                // 00000047C71C: 061A210E
	v_mov_b32_dpp v14, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C720: 7E1C02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000047C728: D5010009 20061309
	v_add_f32_e32 v15, v15, v12                                // 00000047C730: 061E190F
	v_mov_b32_dpp v16, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C734: 7E2002FA FF01640A
	v_mov_b32_dpp v18, v13 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000047C73C: 7E2402FA FF01640D
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000047C744: D501000A 2006150A
	v_cndmask_b32_e64 v13, -v13, v13, s1                       // 00000047C74C: D501000D 20061B0D
	v_add_f32_e32 v17, v9, v14                                 // 00000047C754: 06221D09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C758: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047C760: BF870214
	v_add_f32_e32 v16, v10, v16                                // 00000047C764: 0620210A
	v_add_f32_e32 v18, v13, v18                                // 00000047C768: 0624250D
	v_mov_b32_dpp v10, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C76C: 7E1402FA FF01680F
	v_mov_b32_dpp v12, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C774: 7E1802FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047C77C: BF870214
	v_mov_b32_dpp v13, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C780: 7E1A02FA FF016810
	v_mov_b32_dpp v14, v18 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000047C788: 7E1C02FA FF016812
	s_and_b32 exec_lo, exec_lo, s0                             // 00000047C790: 8B7E007E
	s_cbranch_execz 65133                                      // 00000047C794: BFA5FE6D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi2ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1e4c>
	v_lshl_or_b32 v19, s2, 7, v1                               // 00000047C798: D6560013 04050E02
	.long 0x7f2e3880                                           // 00000047C7A0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000047C7A4: BF870112
	v_ashrrev_i32_e32 v20, 31, v19                             // 00000047C7A8: 3428269F
	.long 0x7f303997                                           // 00000047C7AC: 7F303997
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C7B0: BF870092
	.long 0xd73c0013                                           // 00000047C7B4: D73C0013
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 00000047C7B8: 02022681
	.long 0xd7006a15                                           // 00000047C7BC: D7006A15
	v_cndmask_b32_e32 v1, s22, v19, vcc_lo                     // 00000047C7C0: 02022616
	s_delay_alu instid0(VALU_DEP_1)                            // 00000047C7C4: BF870001
	v_add_co_ci_u32_e64 v22, null, s23, v20, vcc_lo            // 00000047C7C8: D5207C16 01AA2817
	s_clause 0x7                                               // 00000047C7D0: BF850007
	global_load_d16_b16 v23, v[21:22], off offset:32           // 00000047C7D4: DC820020 177C0015
	global_load_d16_b16 v24, v[21:22], off                     // 00000047C7DC: DC820000 187C0015
	global_load_d16_b16 v25, v[21:22], off offset:64           // 00000047C7E4: DC820040 197C0015
	global_load_d16_b16 v26, v[21:22], off offset:96           // 00000047C7EC: DC820060 1A7C0015
	global_load_d16_b16 v27, v[21:22], off offset:128          // 00000047C7F4: DC820080 1B7C0015
	global_load_d16_b16 v28, v[21:22], off offset:160          // 00000047C7FC: DC8200A0 1C7C0015
	global_load_d16_b16 v29, v[21:22], off offset:192          // 00000047C804: DC8200C0 1D7C0015
	global_load_d16_b16 v21, v[21:22], off offset:224          // 00000047C80C: DC8200E0 157C0015
	v_and_b32_e32 v22, 8, v0                                   // 00000047C814: 362C0088
	v_mad_i64_i32 v[0:1], null, s18, v11, 0                    // 00000047C818: D6FF7C00 02021612
	s_waitcnt vmcnt(7)                                         // 00000047C820: BF891FF7
	.long 0x7f163997                                           // 00000047C824: 7F163997
	s_waitcnt vmcnt(0)                                         // 00000047C828: BF8903F7
	.long 0x7f2a3997                                           // 00000047C82C: 7F2A3997
	v_cmp_eq_u32_e32 vcc_lo, 0, v22                            // 00000047C830: 7C942C80
	.long 0x7f2c3997                                           // 00000047C834: 7F2C3997
	.long 0xd73c0000                                           // 00000047C838: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000047C83C: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000047C840: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000047C848: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000047C850: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000047C858: D5010006 21AA0D06
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 00000047C860: D5010010 21AA2110
	v_add_f32_e32 v5, v7, v5                                   // 00000047C868: 060A0B07
	v_cndmask_b32_e64 v7, -v17, v17, vcc_lo                    // 00000047C86C: D5010007 21AA2311
	v_cndmask_b32_e64 v17, -v18, v18, vcc_lo                   // 00000047C874: D5010011 21AA2512
	v_add_f32_e32 v2, v3, v2                                   // 00000047C87C: 06040503
	v_add_f32_e32 v4, v4, v9                                   // 00000047C880: 06081304
	v_mul_f32_e32 v3, 0x3db504f3, v5                           // 00000047C884: 10060AFF 3DB504F3
	v_add_f32_e32 v5, v6, v8                                   // 00000047C88C: 060A1106
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000047C890: D501000F 21AA1F0F
	v_dual_add_f32 v7, v7, v12 :: v_dual_add_f32 v8, v16, v13  // 00000047C898: C9081907 07081B10
	v_dual_add_f32 v9, v17, v14 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 00000047C8A0: C9061D11 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000047C8AC: BF870212
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000047C8B0: C8C604FF 02060EFF 3DB504F3
	v_dual_add_f32 v6, v15, v10 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000047C8BC: C906150F 06040AFF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000047C8C8: BF8701A3
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000047C8CC: 101212FF 3DB504F3
	.long 0xd7006a00                                           // 00000047C8D4: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 00000047C8D8: 0202001C
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000047C8DC: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 00000047C8E4: D5207C01 01AA021D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000047C8EC: BF870093
	.long 0xd7006a00                                           // 00000047C8F0: D7006A00
	v_cndmask_b32_e32 v1, v0, v19, vcc_lo                      // 00000047C8F4: 02022700
	v_add_co_ci_u32_e64 v1, null, v1, v20, vcc_lo              // 00000047C8F8: D5207C01 01AA2901
	v_fma_mix_f32 v3, v23, v3, neg(0) op_sel_hi:[1,0,0]        // 00000047C900: CC200003 8A020717
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 00000047C908: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 00000047C910: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000047C918: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 00000047C920: CC200006 8A020D1B
	.long 0x7e2e3983                                           // 00000047C928: 7E2E3983
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 00000047C92C: CC200007 8A020F1C
	.long 0x7e163982                                           // 00000047C934: 7E163982
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 00000047C938: 101010FF 3DB504F3
	v_fma_mix_f32 v9, v21, v9, neg(0) op_sel_hi:[1,0,0]        // 00000047C940: CC200009 8A021315
	v_and_b32_e32 v10, 1, v23                                  // 00000047C948: 36142E81
	.long 0x7e2e3984                                           // 00000047C94C: 7E2E3984
	v_and_b32_e32 v11, 1, v11                                  // 00000047C950: 36161681
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 00000047C954: CC200008 8A02111D
	.long 0x7e2a3985                                           // 00000047C95C: 7E2A3985
	.long 0x7e2c3986                                           // 00000047C960: 7E2C3986
	v_and_b32_e32 v12, 1, v23                                  // 00000047C964: 36182E81
	.long 0x7e2e3987                                           // 00000047C968: 7E2E3987
	.long 0x7e303988                                           // 00000047C96C: 7E303988
	v_and_b32_e32 v13, 1, v21                                  // 00000047C970: 361A2A81
	v_and_b32_e32 v14, 1, v22                                  // 00000047C974: 361C2C81
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000047C978: D6550003 03FE1503 00007FFF
	v_and_b32_e32 v15, 1, v23                                  // 00000047C984: 361E2E81
	.long 0x7e2e3989                                           // 00000047C988: 7E2E3989
	v_and_b32_e32 v16, 1, v24                                  // 00000047C98C: 36203081
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000047C990: D6550002 03FE1702 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000047C99C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000047C9A8: D6550004 03FE1904 00007FFF
	v_and_b32_e32 v10, 1, v23                                  // 00000047C9B4: 36142E81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000047C9B8: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 00000047C9C4: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000047C9D0: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000047C9DC: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000047C9E0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 00000047C9EC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000047C9F0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000047C9F8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 00000047CA00: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 00000047CA08: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000047CA10: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000047CA18: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000047CA20: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000047CA28: DC9600E0 007C0900
	s_nop 0                                                    // 00000047CA30: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000047CA34: BFB60003
	s_endpgm                                                   // 00000047CA38: BFB00000
		...

