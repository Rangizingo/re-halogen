0000000000737b00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000737B00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000737B04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 000000737B0C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000737B14: 32020085
	s_mov_b32 s3, 0                                            // 000000737B18: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 000000737B1C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000737B24: 84808302
	.long 0x7e383880                                           // 000000737B28: 7E383880
	v_or_b32_e32 v9, s0, v1                                    // 000000737B2C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000737B30: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000737B34: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 000000737B3C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000737B44: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000737B48: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000737B4C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000737B50: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000737B54: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000737B58: 8002000A
	s_addc_u32 s3, s11, 0                                      // 000000737B5C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000737B60: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000737B64: 02021280
	s_add_u32 s0, s10, s2                                      // 000000737B68: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 000000737B6C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000737B74: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000737B78: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000737B7C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000737B80: 8B00D000
	.long 0xd72c0003                                           // 000000737B84: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000737B88: 02000301
	.long 0xd72c0007                                           // 000000737B8C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000737B90: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000737B94: D6FE7C01 02000101
	.long 0xd4440000                                           // 000000737B9C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000737BA0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737BA4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 000000737BA8: D6550002 041E0702
	.long 0xd7000111                                           // 000000737BB0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000737BB4: 02020204
	v_mov_b32_e32 v7, 0                                        // 000000737BB8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000737BBC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 000000737BC0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 000000737BC8: BE832000
	s_cbranch_execz 21                                         // 000000737BCC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 000000737BD0: 30061E84
	.long 0xd7000105                                           // 000000737BD4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 000000737BD8: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 000000737BDC: 360E009E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 000000737BE0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737BE8: BF870094
	.long 0xd7000103                                           // 000000737BEC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 000000737BF0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 000000737BF4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737BFC: BF870094
	.long 0xd700010c                                           // 000000737C00: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000737C04: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000737C08: D5207C0D 00060C80
	s_clause 0x1                                               // 000000737C10: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000737C14: DC5E0000 047C0003
	global_load_d16_b16 v28, v[12:13], off                     // 000000737C1C: DC820000 1C7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000737C24: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000737C28: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000737C30: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000737C38: CA100080 17180080
	v_mov_b32_e32 v25, 0                                       // 000000737C40: 7E320280
	s_and_saveexec_b32 s3, s0                                  // 000000737C44: BE832000
	s_cbranch_execz 572                                        // 000000737C48: BFA5023C <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0xa3c>
	v_and_or_b32 v0, v0, 30, 32                                // 000000737C4C: D6570000 02813D00
	.long 0xd7000001                                           // 000000737C54: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000737C58: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000737C5C: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 000000737C60: D5207C02 0002040B
	v_mov_b32_e32 v12, 0                                       // 000000737C68: 7E180280
	.long 0xd7000000                                           // 000000737C6C: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000737C70: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737C74: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000737C78: D5207C01 00020480
	v_dual_mov_b32 v26, v15 :: v_dual_mov_b32 v25, v12         // 000000737C80: CA10010F 1A18010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737C88: BF870093
	.long 0xd700000d                                           // 000000737C8C: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000737C90: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 000000737C94: D5207C0E 00020205
	v_mov_b32_e32 v24, v12                                     // 000000737C9C: 7E30030C
	v_mov_b32_e32 v23, v12                                     // 000000737CA0: 7E2E030C
	v_mov_b32_e32 v22, v12                                     // 000000737CA4: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000737CA8: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000737CAC: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000737CB0: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000737CB4: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 000000737CB8: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000737CBC: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000737CC0: 848E820A
	s_add_i32 s16, s16, s1                                     // 000000737CC4: 81100110
	s_mul_i32 s18, s10, 6                                      // 000000737CC8: 9612860A
	s_mov_b32 s17, 0                                           // 000000737CCC: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000737CD0: 8484810A
	s_branch 507                                               // 000000737CD4: BFA001FB <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0x9c4>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000737CD8: 8C7E0A7E
	v_bfe_i32 v29, v4, 0, 8                                    // 000000737CDC: D611001D 02210104
	s_and_b32 s0, exec_lo, s0                                  // 000000737CE4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737CE8: BF870099
	s_or_b32 s17, s0, s17                                      // 000000737CEC: 8C111100
	v_cvt_f32_i32_e32 v29, v29                                 // 000000737CF0: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737CF4: BF870091
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 000000737CF8: CC20001D 8A023B1C
	v_bfe_u32 v30, v29, 16, 1                                  // 000000737D00: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000737D08: BF870121
	v_add3_u32 v29, v29, v30, 0x7fff                           // 000000737D0C: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 000000737D18: 7F3C3880
	.long 0x7e3c399d                                           // 000000737D1C: 7E3C399D
	v_bfe_i32 v29, v4, 8, 8                                    // 000000737D20: D611001D 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737D28: BF870091
	v_cvt_f32_i32_e32 v29, v29                                 // 000000737D2C: 7E3A0B1D
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 000000737D30: CC20001D 8A023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737D38: BF870091
	v_bfe_u32 v31, v29, 16, 1                                  // 000000737D3C: D610001F 0205211D
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000737D44: D655001D 03FE3F1D 00007FFF
	v_bfe_i32 v31, v4, 16, 8                                   // 000000737D50: D611001F 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000737D58: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737D5C: BF870193
	v_and_or_b32 v36, 0xffff0000, v29, v30                     // 000000737D60: D6570024 047A3AFF FFFF0000
	v_cvt_f32_i32_e32 v31, v31                                 // 000000737D6C: 7E3E0B1F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000737D70: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737D74: 7E080B04
	v_fma_mix_f32 v31, v28, v31, neg(0) op_sel_hi:[1,0,0]      // 000000737D78: CC20001F 8A023F1C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000737D80: BF870112
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737D84: CC200004 8A02091C
	v_bfe_u32 v32, v31, 16, 1                                  // 000000737D8C: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737D94: BF870191
	v_add3_u32 v31, v31, v32, 0x7fff                           // 000000737D98: D655001F 03FE411F 00007FFF
	v_bfe_u32 v32, v4, 16, 1                                   // 000000737DA4: D6100020 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000737DAC: BF8701A2
	.long 0x7e3e399f                                           // 000000737DB0: 7E3E399F
	.long 0x7f3e399e                                           // 000000737DB4: 7F3E399E
	v_add3_u32 v4, v4, v32, 0x7fff                             // 000000737DB8: D6550004 03FE4104 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000737DC4: BF8700A1
	v_and_or_b32 v37, 0xffff0000, v4, v31                      // 000000737DC8: D6570025 047E08FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 000000737DD4: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737DDC: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737DE0: BF870091
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737DE4: CC200004 8A02091C
	v_bfe_u32 v29, v4, 16, 1                                   // 000000737DEC: D610001D 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737DF4: BF870091
	v_add3_u32 v4, v4, v29, 0x7fff                             // 000000737DF8: D6550004 03FE3B04 00007FFF
	.long 0x7e3c3984                                           // 000000737E04: 7E3C3984
	v_bfe_i32 v4, v5, 8, 8                                     // 000000737E08: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737E10: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737E14: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737E18: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737E20: BF870091
	v_bfe_u32 v29, v4, 16, 1                                   // 000000737E24: D610001D 02052104
	v_add3_u32 v4, v4, v29, 0x7fff                             // 000000737E2C: D6550004 03FE3B04 00007FFF
	v_bfe_i32 v29, v5, 16, 8                                   // 000000737E38: D611001D 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000737E40: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737E44: BF870193
	v_and_or_b32 v38, 0xffff0000, v4, v30                      // 000000737E48: D6570026 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v29, v29                                 // 000000737E54: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000737E58: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 000000737E5C: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000737E60: D6110004 02210106
	v_fma_mix_f32 v29, v28, v29, neg(0) op_sel_hi:[1,0,0]      // 000000737E68: CC20001D 8A023B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737E70: BF870193
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000737E74: CC200005 8A020B1C
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737E7C: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000737E80: BF870113
	v_bfe_u32 v31, v29, 16, 1                                  // 000000737E84: D610001F 0205211D
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737E8C: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000737E94: BF870122
	v_add3_u32 v29, v29, v31, 0x7fff                           // 000000737E98: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v5, 16, 1                                   // 000000737EA4: D610001F 02052105
	.long 0x7e3a399d                                           // 000000737EAC: 7E3A399D
	.long 0x7f3a399e                                           // 000000737EB0: 7F3A399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737EB4: BF870093
	v_add3_u32 v5, v5, v31, 0x7fff                             // 000000737EB8: D6550005 03FE3F05 00007FFF
	v_and_or_b32 v39, 0xffff0000, v5, v29                      // 000000737EC4: D6570027 04760AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 000000737ED0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737ED8: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000737EDC: D6550004 03FE0B04 00007FFF
	.long 0x7e3c3984                                           // 000000737EE8: 7E3C3984
	v_bfe_i32 v4, v6, 8, 8                                     // 000000737EEC: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737EF4: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737EF8: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737EFC: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737F04: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000737F08: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000737F10: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 000000737F1C: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000737F24: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737F28: BF870193
	v_and_or_b32 v40, 0xffff0000, v4, v30                      // 000000737F2C: D6570028 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000737F38: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000737F3C: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000737F40: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 000000737F44: D6110004 02210107
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000737F4C: CC200005 8A020B1C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000737F54: BF870193
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000737F58: CC200006 8A020D1C
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737F60: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000737F64: BF870113
	v_bfe_u32 v29, v5, 16, 1                                   // 000000737F68: D610001D 02052105
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737F70: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000737F78: BF870122
	v_add3_u32 v5, v5, v29, 0x7fff                             // 000000737F7C: D6550005 03FE3B05 00007FFF
	v_bfe_u32 v29, v6, 16, 1                                   // 000000737F88: D610001D 02052106
	.long 0x7e0a3985                                           // 000000737F90: 7E0A3985
	.long 0x7f0a399e                                           // 000000737F94: 7F0A399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737F98: BF870093
	v_add3_u32 v6, v6, v29, 0x7fff                             // 000000737F9C: D6550006 03FE3B06 00007FFF
	v_and_or_b32 v41, 0xffff0000, v6, v5                       // 000000737FA8: D6570029 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 000000737FB4: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737FBC: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000737FC0: D6550004 03FE0B04 00007FFF
	.long 0x7e3c3984                                           // 000000737FCC: 7E3C3984
	v_bfe_i32 v4, v7, 8, 8                                     // 000000737FD0: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737FD8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000737FDC: 7E080B04
	v_fma_mix_f32 v4, v28, v4, neg(0) op_sel_hi:[1,0,0]        // 000000737FE0: CC200004 8A02091C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000737FE8: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 000000737FEC: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000737FF4: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 000000738000: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000738008: BF870112
	v_and_or_b32 v42, 0xffff0000, v4, v30                      // 00000073800C: D657002A 047A08FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000738018: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073801C: BF870091
	v_fma_mix_f32 v5, v28, v5, neg(0) op_sel_hi:[1,0,0]        // 000000738020: CC200005 8A020B1C
	v_bfe_u32 v6, v5, 16, 1                                    // 000000738028: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000738030: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000738034: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000738040: 340C0E98
	.long 0x7e0a3985                                           // 000000738044: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000738048: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000073804C: 7E0C0B06
	.long 0x7f0a399e                                           // 000000738050: 7F0A399E
	v_fma_mix_f32 v6, v28, v6, neg(0) op_sel_hi:[1,0,0]        // 000000738054: CC200006 8A020D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073805C: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000738060: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000738068: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000738074: BF870131
	v_and_or_b32 v43, 0xffff0000, v6, v5                       // 000000738078: D657002B 04160CFF FFFF0000
	.long 0xd73c0004                                           // 000000738084: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000738088: 02021681
	v_mov_b32_e32 v11, v27                                     // 00000073808C: 7E16031B
	.long 0xd7000020                                           // 000000738090: D7000020
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000738094: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000738098: BF870001
	v_add_co_ci_u32_e64 v33, null, s7, v5, s0                  // 00000073809C: D5207C21 00020A07
	s_clause 0x1                                               // 0000007380A4: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000007380A8: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 0000007380B0: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 0000007380B8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000007380BC: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007380C4: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000007380C8: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000007380D0: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007380D8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000007380DC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000007380E4: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007380E8: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000007380F0: D700001C
	v_cndmask_b32_e32 v0, v32, v4, vcc_lo                      // 0000007380F4: 02000920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007380F8: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 0000007380FC: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s5, v33, s0                 // 000000738104: D5207C1D 00024205
	.long 0xd7000022                                           // 00000073810C: D7000022
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000738110: 02001D20
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000738114: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v35, null, s15, v33, s0                // 00000073811C: D5207C23 0002420F
	.long 0xd7000020                                           // 000000738124: D7000020
	v_cndmask_b32_e32 v0, v32, v18, vcc_lo                     // 000000738128: 02002520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073812C: BF870123
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000738130: CC1A4004 1C12571F
	v_add_co_ci_u32_e64 v33, null, s16, v33, s0                // 000000738138: D5207C21 00024210
	v_add_f32_e32 v25, v25, v4                                 // 000000738140: 06320919
	s_clause 0x1                                               // 000000738144: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 000000738148: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000738150: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 000000738158: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 00000073815C: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738164: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 000000738168: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000738170: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000738178: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 00000073817C: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000738184: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000738188: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738190: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738194: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 00000073819C: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007381A4: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000007381A8: CC1A4004 1C12571F
	v_add_f32_e32 v24, v24, v4                                 // 0000007381B0: 06300918
	s_clause 0x1                                               // 0000007381B4: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000007381B8: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000007381C0: DC5E0010 1C7C0022
	.long 0xd7000022                                           // 0000007381C8: D7000022
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 0000007381CC: 02001D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007381D0: BF8700B1
	v_add_co_ci_u32_e64 v35, null, s15, v35, s0                // 0000007381D4: D5207C23 0002460F
	s_waitcnt vmcnt(1)                                         // 0000007381DC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000007381E0: CC1A4004 1A024904
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000007381E8: CC1A4004 1C124B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007381F0: BF870091
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000007381F4: CC1A4004 1C124D06
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000007381FC: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000738204: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738208: BF870091
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073820C: CC1A4004 1C12511C
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738214: CC1A4004 1C12531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073821C: BF870091
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000738220: CC1A4004 1C12551E
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 000000738228: CC1A4004 1C12571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000738230: BF8700D1
	v_add_f32_e32 v23, v23, v4                                 // 000000738234: 062E0917
	s_clause 0x1                                               // 000000738238: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 00000073823C: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000738244: DC5E0010 1C7C0020
	.long 0xd7000020                                           // 00000073824C: D7000020
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000738250: 02001D20
	v_add_co_ci_u32_e64 v33, null, s15, v33, s0                // 000000738254: D5207C21 0002420F
	s_waitcnt vmcnt(1)                                         // 00000073825C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000738260: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738268: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 00000073826C: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000738274: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000073827C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000738280: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000738288: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073828C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738294: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738298: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000007382A0: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007382A8: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000007382AC: CC1A4004 1C12571F
	v_add_f32_e32 v22, v22, v4                                 // 0000007382B4: 062C0916
	s_clause 0x1                                               // 0000007382B8: BF850001
	global_load_b128 v[4:7], v[34:35], off                     // 0000007382BC: DC5E0000 047C0022
	global_load_b128 v[28:31], v[34:35], off offset:16         // 0000007382C4: DC5E0010 1C7C0022
	s_waitcnt vmcnt(1)                                         // 0000007382CC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000007382D0: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007382D8: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000007382DC: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000007382E4: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007382EC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000007382F0: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000007382F8: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007382FC: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738304: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738308: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000738310: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738318: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 00000073831C: CC1A4004 1C12571F
	v_add_f32_e32 v21, v21, v4                                 // 000000738324: 062A0915
	s_clause 0x1                                               // 000000738328: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 00000073832C: DC5E0000 047C0020
	global_load_b128 v[28:31], v[32:33], off offset:16         // 000000738334: DC5E0010 1C7C0020
	s_waitcnt vmcnt(1)                                         // 00000073833C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000738340: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738348: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 00000073834C: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000738354: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000073835C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000738360: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 000000738368: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073836C: CC1A4004 1C12511C
	.long 0xd700001c                                           // 000000738374: D700001C
	v_cndmask_b32_e32 v0, v34, v14, vcc_lo                     // 000000738378: 02001D22
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073837C: BF870122
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738380: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v35, s0                // 000000738388: D5207C1D 0002460F
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000738390: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738398: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 00000073839C: CC1A4004 1C12571F
	v_add_f32_e32 v20, v20, v4                                 // 0000007383A4: 06280914
	s_clause 0x1                                               // 0000007383A8: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 0000007383AC: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 0000007383B4: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 0000007383BC: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 0000007383C0: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007383C8: BF870091
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 0000007383CC: CC1A4004 1C124B05
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 0000007383D4: CC1A4004 1C124D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007383DC: BF8700A1
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 0000007383E0: CC1A4004 1C124F07
	s_waitcnt vmcnt(0)                                         // 0000007383E8: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007383EC: CC1A4004 1C12511C
	.long 0xd700001c                                           // 0000007383F4: D700001C
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 0000007383F8: 02001D20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007383FC: BF8701B2
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738400: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v29, null, s15, v33, s0                // 000000738408: D5207C1D 0002420F
	.long 0xd700000d                                           // 000000738410: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000738414: 0201410D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 000000738418: CC1A4004 1C12551E
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000738420: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738428: BF870092
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 00000073842C: CC1A4004 1C12571F
	v_add_f32_e32 v19, v19, v4                                 // 000000738434: 06260913
	s_clause 0x1                                               // 000000738438: BF850001
	global_load_b128 v[4:7], v[28:29], off                     // 00000073843C: DC5E0000 047C001C
	global_load_b128 v[28:31], v[28:29], off offset:16         // 000000738444: DC5E0010 1C7C001C
	s_waitcnt vmcnt(1)                                         // 00000073844C: BF8907F7
	v_dot2_f32_bf16 v4, v4, v36, 0                             // 000000738450: CC1A4004 1A024904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000738458: BF870121
	v_dot2_f32_bf16 v4, v5, v37, v4                            // 00000073845C: CC1A4004 1C124B05
	v_mov_b32_e32 v5, v1                                       // 000000738464: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v38, v4                            // 000000738468: CC1A4004 1C124D06
	v_mov_b32_e32 v6, v2                                       // 000000738470: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000738474: BF870132
	v_dot2_f32_bf16 v4, v7, v39, v4                            // 000000738478: CC1A4004 1C124F07
	v_mov_b32_e32 v7, v3                                       // 000000738480: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000738484: BF8903F7
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000738488: CC1A4004 1C12511C
	.long 0x7e383908                                           // 000000738490: 7E383908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738494: BF870092
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000738498: CC1A4004 1C12531D
	v_dot2_f32_bf16 v4, v30, v42, v4                           // 0000007384A0: CC1A4004 1C12551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007384A8: BF870091
	v_dot2_f32_bf16 v4, v31, v43, v4                           // 0000007384AC: CC1A4004 1C12571F
	v_add_f32_e32 v16, v16, v4                                 // 0000007384B4: 06200910
	v_mov_b32_e32 v4, v0                                       // 0000007384B8: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000007384BC: 917E117E
	s_cbranch_execz 29                                         // 0000007384C0: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0xa38>
	v_add_nc_u32_e32 v26, 32, v26                              // 0000007384C4: 4A3434A0
	v_add_nc_u32_e32 v27, 0x200, v11                           // 0000007384C8: 4A3616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007384D0: BF8704A2
	.long 0xd4430000                                           // 0000007384D4: D4430000
	v_cndmask_b32_e32 v1, s2, v26, vcc_lo                      // 0000007384D8: 02023402
	s_and_saveexec_b32 s1, s0                                  // 0000007384DC: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000007384E0: 8D01017E
	v_add_nc_u32_e32 v27, 0x200, v11                           // 0000007384E4: 4A3616FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000007384EC: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000007384F0: BF8903F7
	.long 0x7e10391c                                           // 0000007384F4: 7E10391C
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 0000007384F8: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000738500: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000738508: 8D7E0A7E
	s_cbranch_execz 65010                                      // 00000073850C: BFA5FDF2 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0x1d8>
	.long 0xd7000100                                           // 000000738510: D7000100
	v_cndmask_b32_e32 v1, v17, v27, vcc_lo                     // 000000738514: 02023711
	s_delay_alu instid0(VALU_DEP_1)                            // 000000738518: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 00000073851C: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 000000738524: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 00000073852C: DC820000 087C000D
	s_branch 65000                                             // 000000738534: BFA0FDE8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0x1d8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000738538: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000073853C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000738540: 8C7E037E
	.long 0xd71f0000                                           // 000000738544: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000738548: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 00000073854C: 3A020090
	v_xor_b32_e32 v11, 8, v0                                   // 000000738550: 3A160088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738554: BF870092
	.long 0xd44c0000                                           // 000000738558: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 00000073855C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000738560: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000738568: BF870113
	.long 0xd44c0000                                           // 00000073856C: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000738570: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000738574: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000738578: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 00000073857C: D501000B 00021700
	ds_bpermute_b32 v2, v1, v25                                // 000000738584: DACC0000 02001901
	s_waitcnt lgkmcnt(0)                                       // 00000073858C: BF89FC07
	v_add_f32_e32 v2, v25, v2                                  // 000000738590: 06040519
	s_waitcnt vmcnt(1)                                         // 000000738594: BF8907F7
	ds_bpermute_b32 v4, v1, v23                                // 000000738598: DACC0000 04001701
	ds_bpermute_b32 v7, v1, v20                                // 0000007385A0: DACC0000 07001401
	ds_bpermute_b32 v3, v1, v24                                // 0000007385A8: DACC0000 03001801
	ds_bpermute_b32 v5, v1, v22                                // 0000007385B0: DACC0000 05001601
	ds_bpermute_b32 v6, v1, v21                                // 0000007385B8: DACC0000 06001501
	ds_bpermute_b32 v8, v1, v19                                // 0000007385C0: DACC0000 08001301
	ds_bpermute_b32 v1, v1, v16                                // 0000007385C8: DACC0000 01001001
	s_waitcnt lgkmcnt(6)                                       // 0000007385D0: BF89FC67
	v_dual_add_f32 v4, v23, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 0000007385D4: C9220917 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 0000007385DC: DACC0000 0C00020B
	s_waitcnt lgkmcnt(6)                                       // 0000007385E4: BF89FC67
	v_add_f32_e32 v7, v20, v7                                  // 0000007385E8: 060E0F14
	v_xor_b32_e32 v20, 4, v0                                   // 0000007385EC: 3A280084
	s_waitcnt lgkmcnt(3)                                       // 0000007385F0: BF89FC37
	v_dual_add_f32 v3, v24, v3 :: v_dual_add_f32 v6, v21, v6   // 0000007385F4: C9080718 03060D15
	s_waitcnt lgkmcnt(2)                                       // 0000007385FC: BF89FC27
	v_dual_add_f32 v5, v22, v5 :: v_dual_add_f32 v8, v19, v8   // 000000738600: C9080B16 05081113
	.long 0xd44c0000                                           // 000000738608: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 00000073860C: 020228A0
	s_waitcnt lgkmcnt(1)                                       // 000000738610: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000738614: 06020310
	ds_bpermute_b32 v13, v11, v3                               // 000000738618: DACC0000 0D00030B
	ds_bpermute_b32 v14, v11, v4                               // 000000738620: DACC0000 0E00040B
	ds_bpermute_b32 v16, v11, v5                               // 000000738628: DACC0000 1000050B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000738630: D5010014 00022900
	ds_bpermute_b32 v17, v11, v6                               // 000000738638: DACC0000 1100060B
	ds_bpermute_b32 v19, v11, v8                               // 000000738640: DACC0000 1300080B
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000738648: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 00000073864C: DACC0000 1200070B
	s_waitcnt lgkmcnt(6)                                       // 000000738654: BF89FC67
	v_add_f32_e32 v2, v2, v12                                  // 000000738658: 06041902
	ds_bpermute_b32 v11, v11, v1                               // 00000073865C: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 000000738664: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 000000738668: C9081B03 03041D04
	s_waitcnt lgkmcnt(3)                                       // 000000738670: BF89FC37
	v_dual_add_f32 v5, v5, v16 :: v_dual_add_f32 v6, v6, v17   // 000000738674: C9082105 05062306
	s_waitcnt lgkmcnt(2)                                       // 00000073867C: BF89FC27
	v_add_f32_e32 v8, v8, v19                                  // 000000738680: 06102708
	ds_bpermute_b32 v12, v20, v3                               // 000000738684: DACC0000 0C000314
	ds_bpermute_b32 v13, v20, v4                               // 00000073868C: DACC0000 0D000414
	ds_bpermute_b32 v14, v20, v5                               // 000000738694: DACC0000 0E000514
	s_waitcnt lgkmcnt(4)                                       // 00000073869C: BF89FC47
	v_add_f32_e32 v7, v7, v18                                  // 0000007386A0: 060E2507
	ds_bpermute_b32 v16, v20, v6                               // 0000007386A4: DACC0000 10000614
	ds_bpermute_b32 v18, v20, v8                               // 0000007386AC: DACC0000 12000814
	s_waitcnt lgkmcnt(5)                                       // 0000007386B4: BF89FC57
	v_add_f32_e32 v1, v1, v11                                  // 0000007386B8: 06021701
	ds_bpermute_b32 v11, v20, v2                               // 0000007386BC: DACC0000 0B000214
	ds_bpermute_b32 v17, v20, v7                               // 0000007386C4: DACC0000 11000714
	ds_bpermute_b32 v19, v20, v1                               // 0000007386CC: DACC0000 13000114
	v_xor_b32_e32 v20, 2, v0                                   // 0000007386D4: 3A280082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007386D8: BF870131
	.long 0xd44c0000                                           // 0000007386DC: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 0000007386E0: 020228A0
	s_waitcnt lgkmcnt(7)                                       // 0000007386E4: BF89FC77
	v_add_f32_e32 v3, v3, v12                                  // 0000007386E8: 06061903
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 0000007386EC: D5010014 00022900
	s_waitcnt lgkmcnt(5)                                       // 0000007386F4: BF89FC57
	v_add_f32_e32 v12, v5, v14                                 // 0000007386F8: 06181D05
	s_waitcnt lgkmcnt(3)                                       // 0000007386FC: BF89FC37
	v_add_f32_e32 v8, v8, v18                                  // 000000738700: 06102508
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000738704: 30282882
	s_waitcnt lgkmcnt(2)                                       // 000000738708: BF89FC27
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v11, v4, v13  // 00000073870C: C9081702 020A1B04
	v_add_f32_e32 v13, v6, v16                                 // 000000738714: 061A2106
	s_waitcnt lgkmcnt(0)                                       // 000000738718: BF89FC07
	v_dual_add_f32 v7, v7, v17 :: v_dual_add_f32 v16, v1, v19  // 00000073871C: C9082307 07102701
	ds_bpermute_b32 v1, v20, v2                                // 000000738724: DACC0000 01000214
	ds_bpermute_b32 v5, v20, v3                                // 00000073872C: DACC0000 05000314
	ds_bpermute_b32 v6, v20, v11                               // 000000738734: DACC0000 06000B14
	ds_bpermute_b32 v14, v20, v12                              // 00000073873C: DACC0000 0E000C14
	ds_bpermute_b32 v17, v20, v13                              // 000000738744: DACC0000 11000D14
	ds_bpermute_b32 v18, v20, v7                               // 00000073874C: DACC0000 12000714
	ds_bpermute_b32 v19, v20, v8                               // 000000738754: DACC0000 13000814
	ds_bpermute_b32 v20, v20, v16                              // 00000073875C: DACC0000 14001014
	v_xor_b32_e32 v4, 1, v0                                    // 000000738764: 3A080081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000738768: BF870091
	.long 0xd44c0000                                           // 00000073876C: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 000000738770: 020208A0
	v_cndmask_b32_e64 v0, v0, v4, s0                           // 000000738774: D5010000 00020900
	.long 0xd44a0000                                           // 00000073877C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000738780: 02021E80
	s_waitcnt lgkmcnt(7)                                       // 000000738784: BF89FC77
	v_add_f32_e32 v4, v2, v1                                   // 000000738788: 06080302
	s_waitcnt lgkmcnt(6)                                       // 00000073878C: BF89FC67
	v_add_f32_e32 v5, v3, v5                                   // 000000738790: 060A0B03
	s_waitcnt lgkmcnt(5)                                       // 000000738794: BF89FC57
	v_dual_add_f32 v6, v11, v6 :: v_dual_lshlrev_b32 v21, 2, v0// 000000738798: C9220D0B 06140082
	s_waitcnt lgkmcnt(3)                                       // 0000007387A0: BF89FC37
	v_dual_add_f32 v0, v12, v14 :: v_dual_add_f32 v1, v13, v17 // 0000007387A4: C9081D0C 0000230D
	s_waitcnt lgkmcnt(1)                                       // 0000007387AC: BF89FC17
	v_dual_add_f32 v7, v7, v18 :: v_dual_add_f32 v14, v8, v19  // 0000007387B0: C9082507 070E2708
	s_waitcnt lgkmcnt(0)                                       // 0000007387B8: BF89FC07
	v_add_f32_e32 v16, v16, v20                                // 0000007387BC: 06202910
	ds_bpermute_b32 v8, v21, v4                                // 0000007387C0: DACC0000 08000415
	ds_bpermute_b32 v11, v21, v5                               // 0000007387C8: DACC0000 0B000515
	ds_bpermute_b32 v12, v21, v6                               // 0000007387D0: DACC0000 0C000615
	ds_bpermute_b32 v2, v21, v0                                // 0000007387D8: DACC0000 02000015
	ds_bpermute_b32 v3, v21, v1                                // 0000007387E0: DACC0000 03000115
	ds_bpermute_b32 v13, v21, v7                               // 0000007387E8: DACC0000 0D000715
	ds_bpermute_b32 v17, v21, v14                              // 0000007387F0: DACC0000 11000E15
	ds_bpermute_b32 v18, v21, v16                              // 0000007387F8: DACC0000 12001015
	s_and_b32 s0, s0, vcc_lo                                   // 000000738800: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000738804: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000738808: BE812000
	s_cbranch_execz 69                                         // 00000073880C: BFA50045 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi8ELi32ELi1ELb1EEEvPKhPKtPvll+0xe24>
	.long 0xd73c0009                                           // 000000738810: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000738814: 02021282
	s_waitcnt lgkmcnt(2)                                       // 000000738818: BF89FC27
	v_dual_add_f32 v13, v7, v13 :: v_dual_add_f32 v12, v6, v12 // 00000073881C: C9081B07 0D0C1906
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000738824: 8480820C
	s_waitcnt lgkmcnt(0)                                       // 000000738828: BF89FC07
	v_dual_add_f32 v15, v16, v18 :: v_dual_add_f32 v14, v14, v17// 00000073882C: C9082510 0F0E230E
	.long 0xd7006a06                                           // 000000738834: D7006A06
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000738838: 02021208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073883C: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s9, v10, vcc_lo              // 000000738840: D5207C07 01AA1409
	v_dual_add_f32 v16, v5, v11 :: v_dual_add_f32 v17, v4, v8  // 000000738848: C9081705 10101104
	.long 0xd7006a08                                           // 000000738850: D7006A08
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 000000738854: 02000106
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000738858: BF8700D3
	v_mad_u64_u32 v[4:5], null, s12, 12, v[6:7]                // 00000073885C: D6FE7C04 0419180C
	v_add_co_ci_u32_e64 v9, null, s1, v7, vcc_lo               // 000000738864: D5207C09 01AA0E01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 00000073886C: 8480830C
	v_dual_add_f32 v18, v1, v3 :: v_dual_add_f32 v19, v0, v2   // 000000738870: C9080701 12120500
	.long 0xd7006a0a                                           // 000000738878: D7006A0A
	v_cndmask_b32_e32 v0, v6, v0, vcc_lo                       // 00000073887C: 02000106
	v_add_co_ci_u32_e64 v11, null, s1, v7, vcc_lo              // 000000738880: D5207C0B 01AA0E01
	s_clause 0x2                                               // 000000738888: BF850002
	global_store_b32 v[6:7], v17, off                          // 00000073888C: DC6A0000 007C1106
	global_store_b32 v[8:9], v16, off                          // 000000738894: DC6A0000 007C1008
	global_store_b32 v[10:11], v12, off                        // 00000073889C: DC6A0000 007C0C0A
	v_mad_u64_u32 v[5:6], null, s13, 12, v[5:6]                // 0000007388A4: D6FE7C05 0415180D
	.long 0xd7006a00                                           // 0000007388AC: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 0000007388B0: 0200010A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007388B4: BF8700A1
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 0000007388B8: D5207C01 01AA1601
	.long 0xd7006a02                                           // 0000007388C0: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 0000007388C4: 02000104
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 0000007388C8: D5207C03 01AA0A01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007388D0: BF870094
	.long 0xd7006a06                                           // 0000007388D4: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007388D8: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 0000007388DC: D5207C07 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007388E4: BF870094
	.long 0xd7006a08                                           // 0000007388E8: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000007388EC: 02000102
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 0000007388F0: D5207C09 01AA0601
	s_clause 0x4                                               // 0000007388F8: BF850004
	global_store_b32 v[4:5], v19, off                          // 0000007388FC: DC6A0000 007C1304
	global_store_b32 v[0:1], v18, off                          // 000000738904: DC6A0000 007C1200
	global_store_b32 v[2:3], v13, off                          // 00000073890C: DC6A0000 007C0D02
	global_store_b32 v[6:7], v14, off                          // 000000738914: DC6A0000 007C0E06
	global_store_b32 v[8:9], v15, off                          // 00000073891C: DC6A0000 007C0F08
	s_endpgm                                                   // 000000738924: BFB00000
		...

