00000000002c7800 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 0000002C7800: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 0000002C7804: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 0000002C780C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 0000002C7814: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 0000002C781C: F4000180 F8000118
	v_dual_mov_b32 v21, 0 :: v_dual_and_b32 v18, 15, v0        // 0000002C7824: CA240080 1512008F
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000002C782C: 32040084
	v_lshlrev_b32_e32 v17, 2, v0                               // 0000002C7830: 30220082
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C7834: BF870002
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000002C7838: 30060482
	s_waitcnt lgkmcnt(0)                                       // 0000002C783C: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000002C7840: BF028103
	s_cselect_b32 s7, -1, 0                                    // 0000002C7844: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 0000002C7848: BF030402
	s_cselect_b32 s4, -1, 0                                    // 0000002C784C: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C7850: BF870009
	s_and_b32 s4, s7, s4                                       // 0000002C7854: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 0000002C7858: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000002C785C: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 0000002C7864: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 0000002C7868: BF030502
	s_cselect_b32 s5, -1, 0                                    // 0000002C786C: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C7870: BF870009
	s_and_b32 s4, s7, s5                                       // 0000002C7874: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 0000002C7878: BF028303
	v_readfirstlane_b32 s5, v1                                 // 0000002C787C: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 0000002C7880: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 0000002C7884: BF030602
	v_lshlrev_b32_e32 v1, 2, v18                               // 0000002C7888: 30022482
	s_cselect_b32 s6, -1, 0                                    // 0000002C788C: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000002C7890: BF8704D9
	s_and_b32 s3, s3, s6                                       // 0000002C7894: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 0000002C7898: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 0000002C789C: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 0000002C78A0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 0000002C78A4: 98030483
	s_mulk_i32 s3, 0x48                                        // 0000002C78A8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C78AC: BF870009
	s_add_u32 s16, s0, s3                                      // 0000002C78B0: 80100300
	s_addc_u32 s17, s1, 0                                      // 0000002C78B4: 82118001
	s_clause 0x1                                               // 0000002C78B8: BF850001
	s_load_b256 s[4:11], s[16:17], 0x18                        // 0000002C78BC: F40C0108 F8000018
	s_load_b64 s[18:19], s[16:17], null                        // 0000002C78C4: F4040488 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000002C78CC: BF89FC07
	.long 0xd4540003                                           // 0000002C78D0: D4540003
	v_cndmask_b32_e32 v0, s10, v136, vcc_lo                    // 0000002C78D4: 0201100A
	s_and_b32 s12, s3, exec_lo                                 // 0000002C78D8: 8B0C7E03
	s_load_b128 s[12:15], s[0:1], 0x128                        // 0000002C78DC: F4080300 F8000128
	s_clause 0x1                                               // 0000002C78E4: BF850001
	global_load_b32 v1, v1, s[18:19]                           // 0000002C78E8: DC520000 01120001
	global_load_b32 v3, v3, s[18:19]                           // 0000002C78F0: DC520000 03120003
	s_cselect_b32 s24, 1, 16                                   // 0000002C78F8: 98189081
	s_cselect_b32 s0, 0, 4                                     // 0000002C78FC: 98008480
	s_add_i32 s25, s24, -1                                     // 0000002C7900: 8119C118
	v_lshrrev_b32_e32 v19, s0, v2                              // 0000002C7904: 32260400
	v_and_b32_e32 v20, s25, v2                                 // 0000002C7908: 36280419
	s_waitcnt vmcnt(1)                                         // 0000002C790C: BF8907F7
	v_bfe_u32 v4, v1, 16, 1                                    // 0000002C7910: D6100004 02052101
	s_waitcnt vmcnt(0)                                         // 0000002C7918: BF8903F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002C791C: D6100005 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C7924: BF8701A2
	v_add3_u32 v1, v1, v4, 0x7fff                              // 0000002C7928: D6550001 03FE0901 00007FFF
	.long 0x7f083880                                           // 0000002C7934: 7F083880
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002C7938: D6550003 03FE0B03 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C7944: BF870093
	.long 0x7e083981                                           // 0000002C7948: 7E083981
	v_and_or_b32 v1, 0xffff0000, v3, v4                        // 0000002C794C: D6570001 041206FF FFFF0000
	ds_store_b32 v17, v1                                       // 0000002C7958: D8340000 00000111
	v_cvt_f32_ubyte0_e32 v1, s24                               // 0000002C7960: 7E022218
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C7964: BF870291
	v_rcp_iflag_f32_e32 v1, v1                                 // 0000002C7968: 7E025701
	v_readfirstlane_b32 s1, v1                                 // 0000002C796C: 7E020501
	v_mov_b32_e32 v1, 0                                        // 0000002C7970: 7E020280
	s_mul_f32 s22, s1, 0x4f7ffffe                              // 0000002C7974: A216FF01 4F7FFFFE
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000002C797C: BF87000B
	s_cvt_u32_f32 s26, s22                                     // 0000002C7980: BE9A6716
	s_waitcnt lgkmcnt(0)                                       // 0000002C7984: BF89FC07
	s_barrier                                                  // 0000002C7988: BFBD0000
	buffer_gl0_inv                                             // 0000002C798C: E0AC0000 00000000
	s_load_b32 s20, s[16:17], 0x40                             // 0000002C7994: F4000508 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002C799C: BF89FC07
	s_sub_i32 s0, s2, s20                                      // 0000002C79A0: 81801402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C79A4: BF870009
	s_ashr_i32 s1, s0, 31                                      // 0000002C79A8: 86019F00
	s_and_b32 s3, s3, exec_lo                                  // 0000002C79AC: 8B037E03
	s_cselect_b32 s3, 4, 0                                     // 0000002C79B0: 98038084
	s_lshr_b32 s20, s15, 31                                    // 0000002C79B4: 85149F0F
	s_lshl_b64 s[0:1], s[0:1], s3                              // 0000002C79B8: 84800300
	s_add_u32 s20, s14, s20                                    // 0000002C79BC: 8014140E
	s_addc_u32 s21, s15, 0                                     // 0000002C79C0: 8215800F
	s_ashr_i32 s3, s15, 31                                     // 0000002C79C4: 86039F0F
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000002C79C8: 86948114
	s_lshr_b32 s3, s3, 27                                      // 0000002C79CC: 85039B03
	.long 0xd7000009                                           // 0000002C79D0: D7000009
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 0000002C79D4: 02022600
	s_add_u32 s22, s14, s3                                     // 0000002C79D8: 8016030E
	s_addc_u32 s23, s15, 0                                     // 0000002C79DC: 8217800F
	s_sub_i32 s3, 0, s24                                       // 0000002C79E0: 81831880
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000002C79E4: 85968516
	s_mul_i32 s3, s3, s26                                      // 0000002C79E8: 96031A03
	s_add_i32 s23, s25, s22                                    // 0000002C79EC: 81171619
	s_mul_hi_u32 s3, s26, s3                                   // 0000002C79F0: 9683031A
	s_abs_i32 s27, s23                                         // 0000002C79F4: BE9B1517
	s_add_i32 s26, s26, s3                                     // 0000002C79F8: 811A031A
	v_add_co_ci_u32_e64 v10, null, s1, 0, s0                   // 0000002C79FC: D5207C0A 00010001
	s_mul_hi_u32 s3, s27, s26                                  // 0000002C7A04: 96831A1B
	s_ashr_i32 s1, s23, 31                                     // 0000002C7A08: 86019F17
	s_mul_i32 s0, s3, s24                                      // 0000002C7A0C: 96001803
	s_add_i32 s26, s3, 1                                       // 0000002C7A10: 811A8103
	s_sub_i32 s23, s27, s0                                     // 0000002C7A14: 8197001B
	.long 0xd4540000                                           // 0000002C7A18: D4540000
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000002C7A1C: 0202120A
	s_sub_i32 s27, s23, s24                                    // 0000002C7A20: 819B1817
	s_cmp_ge_u32 s23, s24                                      // 0000002C7A24: BF091817
	s_cselect_b32 s3, s26, s3                                  // 0000002C7A28: 9803031A
	s_cselect_b32 s23, s27, s23                                // 0000002C7A2C: 9817171B
	s_add_i32 s26, s3, 1                                       // 0000002C7A30: 811A8103
	s_cmp_ge_u32 s23, s24                                      // 0000002C7A34: BF091817
	v_cndmask_b32_e64 v3, 0, v10, s0                           // 0000002C7A38: D5010003 00021480
	s_cselect_b32 s3, s26, s3                                  // 0000002C7A40: 9803031A
	v_cndmask_b32_e64 v2, 0, v9, s0                            // 0000002C7A44: D5010002 00021280
	s_xor_b32 s3, s3, s1                                       // 0000002C7A4C: 8D030103
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C7A50: BF870009
	s_sub_i32 s1, s3, s1                                       // 0000002C7A54: 81810103
	s_add_u32 s4, s18, s4                                      // 0000002C7A58: 80040412
	.long 0xd72c0005                                           // 0000002C7A5C: D72C0005
	v_cndmask_b32_e32 v1, s1, v20, vcc_lo                      // 0000002C7A60: 02022801
	s_addc_u32 s5, s19, s5                                     // 0000002C7A64: 82050513
	s_add_u32 s6, s18, s6                                      // 0000002C7A68: 80060612
	.long 0xd72c0004                                           // 0000002C7A6C: D72C0004
	v_cndmask_b32_e32 v0, v3, v20, vcc_lo                      // 0000002C7A70: 02002903
	.long 0xd72c0006                                           // 0000002C7A74: D72C0006
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000002C7A78: 02001103
	s_addc_u32 s7, s19, s7                                     // 0000002C7A7C: 82070713
	.long 0xd72c0007                                           // 0000002C7A80: D72C0007
	v_cndmask_b32_e32 v0, v2, v21, vcc_lo                      // 0000002C7A84: 02002B02
	.long 0xd72c0008                                           // 0000002C7A88: D72C0008
	v_cndmask_b32_e32 v0, v2, v9, vcc_lo                       // 0000002C7A8C: 02001302
	v_add_nc_u32_e32 v3, s1, v5                                // 0000002C7A90: 4A060A01
	v_mad_u64_u32 v[11:12], null, v2, s20, s[4:5]              // 0000002C7A94: D6FE7C0B 00102902
	v_mad_u64_u32 v[13:14], null, v2, s8, s[6:7]               // 0000002C7A9C: D6FE7C0D 00181102
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v22, v5, v18    // 0000002C7AA4: CA200080 19162505
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002C7AAC: BF870004
	v_min_i32_e32 v23, s22, v3                                 // 0000002C7AB0: 222E0616
	.long 0xd4510003                                           // 0000002C7AB4: D4510003
	v_cndmask_b32_e32 v0, s10, v137, vcc_lo                    // 0000002C7AB8: 0201120A
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000002C7ABC: CA100080 02020080
	v_add3_u32 v12, v4, v12, v7                                // 0000002C7AC4: D655000C 041E1904
	v_add3_u32 v24, v6, v14, v8                                // 0000002C7ACC: D6550018 04221D06
	v_cmp_lt_i32_e32 vcc_lo, v22, v23                          // 0000002C7AD4: 7C822F16
	v_mov_b32_e32 v4, 0                                        // 0000002C7AD8: 7E080280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000002C7ADC: BE84206A
	s_cbranch_execz 21                                         // 0000002C7AE0: BFA50015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x338>
	v_lshlrev_b32_e32 v1, 1, v22                               // 0000002C7AE4: 30022C81
	v_lshlrev_b32_e32 v3, 4, v22                               // 0000002C7AE8: 30062C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C7AEC: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000002C7AF0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000002C7AF4: 3408069F
	.long 0xd7000101                                           // 0000002C7AF8: D7000101
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000002C7AFC: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C7B00: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v24, v2, s1                  // 0000002C7B04: D5207C02 00060518
	.long 0xd7000103                                           // 0000002C7B0C: D7000103
	v_cndmask_b32_e32 v1, v11, v3, vcc_lo                      // 0000002C7B10: 0202070B
	v_add_co_ci_u32_e64 v4, null, v12, v4, s1                  // 0000002C7B14: D5207C04 0006090C
	s_clause 0x1                                               // 0000002C7B1C: BF850001
	global_load_d16_b16 v6, v[1:2], off                        // 0000002C7B20: DC820000 067C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000002C7B28: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000002C7B30: BF8907F7
	v_cvt_f32_f16_e32 v25, v6                                  // 0000002C7B34: 7E321706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000002C7B38: 8C7E047E
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v28, 0             // 0000002C7B3C: CA100080 1B1C0080
	v_dual_mov_b32 v29, 0 :: v_dual_mov_b32 v30, 0             // 0000002C7B44: CA100080 1D1E0080
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, 0             // 0000002C7B4C: CA100080 1F200080
	v_mov_b32_e32 v26, 0                                       // 0000002C7B54: 7E340280
	s_and_saveexec_b32 s8, vcc_lo                              // 0000002C7B58: BE88206A
	s_cbranch_execz 571                                        // 0000002C7B5C: BFA5023B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc4c>
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v6, 5, v18     // 0000002C7B60: CA220080 1F062485
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v7, 16, v22     // 0000002C7B68: CA200080 1A062C90
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 0000002C7B70: CA100080 1E1A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C7B78: BF870193
	v_lshl_add_u32 v14, v5, 5, v6                              // 0000002C7B7C: D646000E 04190B05
	v_dual_mov_b32 v32, 0 :: v_dual_lshlrev_b32 v33, 4, v7     // 0000002C7B84: CA220080 20200E84
	v_dual_mov_b32 v29, 0 :: v_dual_lshlrev_b32 v34, 1, v7     // 0000002C7B8C: CA220080 1D220E81
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v21, 0             // 0000002C7B94: CA100080 1C140080
	v_mov_b32_e32 v35, v25                                     // 0000002C7B9C: 7E460319
	s_mul_i32 s1, s15, 6                                       // 0000002C7BA0: 9601860F
	s_mul_hi_u32 s6, s14, 6                                    // 0000002C7BA4: 9686860E
	s_lshl_b64 s[4:5], s[14:15], 2                             // 0000002C7BA8: 8484820E
	s_add_i32 s9, s6, s1                                       // 0000002C7BAC: 81090106
	s_mul_i32 s19, s14, 6                                      // 0000002C7BB0: 9613860E
	s_mov_b32 s18, 0                                           // 0000002C7BB4: BE920080
	s_lshl_b64 s[6:7], s[14:15], 1                             // 0000002C7BB8: 8486810E
	s_branch 515                                               // 0000002C7BBC: BFA00203 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xbcc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000002C7BC0: 8C7E0E7E
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000002C7BC4: 341E1C9F
	v_and_b32_e32 v110, 0xff, v1                               // 0000002C7BC8: 36DC02FF 000000FF
	v_lshrrev_b32_e32 v111, 6, v1                              // 0000002C7BD0: 32DE0286
	v_lshrrev_b32_e32 v112, 14, v1                             // 0000002C7BD4: 32E0028E
	v_lshrrev_b32_e32 v113, 22, v1                             // 0000002C7BD8: 32E20296
	.long 0xd73c000f                                           // 0000002C7BDC: D73C000F
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000002C7BE0: 02021C81
	s_waitcnt vmcnt(0)                                         // 0000002C7BE4: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_and_b32 v114, 0xff, v2     // 0000002C7BE8: CA240105 017204FF 000000FF
	v_lshrrev_b32_e32 v115, 6, v2                              // 0000002C7BF4: 32E60486
	v_lshrrev_b32_e32 v116, 14, v2                             // 0000002C7BF8: 32E8048E
	v_lshrrev_b32_e32 v117, 22, v2                             // 0000002C7BFC: 32EA0496
	.long 0xd700010f                                           // 0000002C7C00: D700010F
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000002C7C04: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C7C08: BF8701A1
	v_add_co_ci_u32_e64 v16, null, s13, v16, s1                // 0000002C7C0C: D5207C10 0006200D
	v_and_b32_e32 v118, 0xff, v3                               // 0000002C7C14: 36EC06FF 000000FF
	.long 0xd7000160                                           // 0000002C7C1C: D7000160
	v_cndmask_b32_e32 v0, v15, v6, vcc_lo                      // 0000002C7C20: 02000D0F
	global_load_b128 v[36:39], v[15:16], off                   // 0000002C7C24: DC5E0000 247C000F
	v_add_co_ci_u32_e64 v97, null, s7, v16, s1                 // 0000002C7C2C: D5207C61 00062007
	.long 0xd7000162                                           // 0000002C7C34: D7000162
	v_cndmask_b32_e32 v0, v15, v4, vcc_lo                      // 0000002C7C38: 0200090F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C7C3C: BF8700A1
	v_add_co_ci_u32_e64 v99, null, s5, v16, s1                 // 0000002C7C40: D5207C63 00062005
	.long 0xd7000164                                           // 0000002C7C48: D7000164
	v_cndmask_b32_e32 v0, v15, v19, vcc_lo                     // 0000002C7C4C: 0200270F
	v_add_co_ci_u32_e64 v101, null, s9, v16, s1                // 0000002C7C50: D5207C65 00062009
	s_clause 0x2                                               // 0000002C7C58: BF850002
	global_load_b128 v[40:43], v[96:97], off                   // 0000002C7C5C: DC5E0000 287C0060
	global_load_b128 v[44:47], v[98:99], off                   // 0000002C7C64: DC5E0000 2C7C0062
	global_load_b128 v[48:51], v[100:101], off                 // 0000002C7C6C: DC5E0000 307C0064
	.long 0xd7000166                                           // 0000002C7C74: D7000166
	v_cndmask_b32_e32 v0, v98, v4, vcc_lo                      // 0000002C7C78: 02000962
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C7C7C: BF8700A1
	v_add_co_ci_u32_e64 v103, null, s5, v99, s1                // 0000002C7C80: D5207C67 0006C605
	.long 0xd7000168                                           // 0000002C7C88: D7000168
	v_cndmask_b32_e32 v0, v100, v4, vcc_lo                     // 0000002C7C8C: 02000964
	v_add_co_ci_u32_e64 v105, null, s5, v101, s1               // 0000002C7C90: D5207C69 0006CA05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C7C98: BF870094
	.long 0xd700016a                                           // 0000002C7C9C: D700016A
	v_cndmask_b32_e32 v0, v102, v4, vcc_lo                     // 0000002C7CA0: 02000966
	v_add_co_ci_u32_e64 v107, null, s5, v103, s1               // 0000002C7CA4: D5207C6B 0006CE05
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C7CAC: BF870094
	.long 0xd700016c                                           // 0000002C7CB0: D700016C
	v_cndmask_b32_e32 v0, v104, v4, vcc_lo                     // 0000002C7CB4: 02000968
	v_add_co_ci_u32_e64 v109, null, s5, v105, s1               // 0000002C7CB8: D5207C6D 0006D205
	s_clause 0x7                                               // 0000002C7CC0: BF850007
	global_load_b128 v[52:55], v[102:103], off                 // 0000002C7CC4: DC5E0000 347C0066
	global_load_b128 v[56:59], v[104:105], off                 // 0000002C7CCC: DC5E0000 387C0068
	global_load_b128 v[60:63], v[106:107], off                 // 0000002C7CD4: DC5E0000 3C7C006A
	global_load_b128 v[64:67], v[108:109], off                 // 0000002C7CDC: DC5E0000 407C006C
	global_load_b128 v[68:71], v[15:16], off offset:16         // 0000002C7CE4: DC5E0010 447C000F
	global_load_b128 v[72:75], v[96:97], off offset:16         // 0000002C7CEC: DC5E0010 487C0060
	global_load_b128 v[76:79], v[98:99], off offset:16         // 0000002C7CF4: DC5E0010 4C7C0062
	global_load_b128 v[80:83], v[100:101], off offset:16       // 0000002C7CFC: DC5E0010 507C0064
	v_lshrrev_b32_e32 v119, 6, v3                              // 0000002C7D04: 32EE0686
	v_lshrrev_b32_e32 v120, 14, v3                             // 0000002C7D08: 32F0068E
	v_lshrrev_b32_e32 v121, 22, v3                             // 0000002C7D0C: 32F20696
	v_and_b32_e32 v122, 0xff, v4                               // 0000002C7D10: 36F408FF 000000FF
	v_lshrrev_b32_e32 v123, 6, v4                              // 0000002C7D18: 32F60886
	v_lshrrev_b32_e32 v124, 14, v4                             // 0000002C7D1C: 32F8088E
	v_lshrrev_b32_e32 v125, 22, v4                             // 0000002C7D20: 32FA0896
	v_dual_mov_b32 v4, v8 :: v_dual_and_b32 v111, 0x3fc, v111  // 0000002C7D24: CA240108 046EDEFF 000003FC
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000002C7D30: CA100107 03020106
	v_and_b32_e32 v113, 0x3fc, v113                            // 0000002C7D38: 36E2E2FF 000003FC
	s_clause 0x3                                               // 0000002C7D40: BF850003
	global_load_b128 v[5:8], v[102:103], off offset:16         // 0000002C7D44: DC5E0010 057C0066
	global_load_b128 v[84:87], v[104:105], off offset:16       // 0000002C7D4C: DC5E0010 547C0068
	global_load_b128 v[88:91], v[106:107], off offset:16       // 0000002C7D54: DC5E0010 587C006A
	global_load_b128 v[92:95], v[108:109], off offset:16       // 0000002C7D5C: DC5E0010 5C7C006C
	v_lshlrev_b32_e32 v110, 2, v110                            // 0000002C7D64: 30DCDC82
	v_and_b32_e32 v112, 0x3fc, v112                            // 0000002C7D68: 36E0E0FF 000003FC
	ds_load_b32 v111, v111                                     // 0000002C7D70: D8D80000 6F00006F
	v_lshlrev_b32_e32 v114, 2, v114                            // 0000002C7D78: 30E4E482
	v_and_b32_e32 v115, 0x3fc, v115                            // 0000002C7D7C: 36E6E6FF 000003FC
	ds_load_b32 v110, v110                                     // 0000002C7D84: D8D80000 6E00006E
	ds_load_b32 v112, v112                                     // 0000002C7D8C: D8D80000 70000070
	v_and_b32_e32 v116, 0x3fc, v116                            // 0000002C7D94: 36E8E8FF 000003FC
	v_and_b32_e32 v117, 0x3fc, v117                            // 0000002C7D9C: 36EAEAFF 000003FC
	ds_load_b32 v113, v113                                     // 0000002C7DA4: D8D80000 71000071
	ds_load_b32 v114, v114                                     // 0000002C7DAC: D8D80000 72000072
	ds_load_b32 v115, v115                                     // 0000002C7DB4: D8D80000 73000073
	ds_load_b32 v116, v116                                     // 0000002C7DBC: D8D80000 74000074
	ds_load_b32 v117, v117                                     // 0000002C7DC4: D8D80000 75000075
	v_add_nc_u32_e32 v34, 32, v34                              // 0000002C7DCC: 4A4444A0
	v_add_nc_u32_e32 v14, 0x200, v14                           // 0000002C7DD0: 4A1C1CFF 00000200
	s_and_b32 s1, exec_lo, vcc_lo                              // 0000002C7DD8: 8B016A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C7DDC: BF8700B9
	s_or_b32 s18, s1, s18                                      // 0000002C7DE0: 8C121201
	s_waitcnt vmcnt(15) lgkmcnt(6)                             // 0000002C7DE4: BF893C67
	v_dot2_f32_bf16 v36, v36, v110, 0                          // 0000002C7DE8: CC1A4024 1A02DD24
	v_dot2_f32_bf16 v36, v37, v111, v36                        // 0000002C7DF0: CC1A4024 1C92DF25
	s_waitcnt vmcnt(14)                                        // 0000002C7DF8: BF893BF7
	v_dot2_f32_bf16 v37, v40, v110, 0                          // 0000002C7DFC: CC1A4025 1A02DD28
	s_waitcnt lgkmcnt(5)                                       // 0000002C7E04: BF89FC57
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C7E08: BF870002
	v_dot2_f32_bf16 v36, v38, v112, v36                        // 0000002C7E0C: CC1A4024 1C92E126
	s_waitcnt vmcnt(12)                                        // 0000002C7E14: BF8933F7
	v_dot2_f32_bf16 v38, v48, v110, 0                          // 0000002C7E18: CC1A4026 1A02DD30
	v_dot2_f32_bf16 v37, v41, v111, v37                        // 0000002C7E20: CC1A4025 1C96DF29
	s_waitcnt lgkmcnt(4)                                       // 0000002C7E28: BF89FC47
	v_dot2_f32_bf16 v126, v39, v113, v36                       // 0000002C7E2C: CC1A407E 1C92E327
	v_dot2_f32_bf16 v36, v44, v110, 0                          // 0000002C7E34: CC1A4024 1A02DD2C
	v_dot2_f32_bf16 v40, v49, v111, v38                        // 0000002C7E3C: CC1A4028 1C9ADF31
	v_dot2_f32_bf16 v37, v42, v112, v37                        // 0000002C7E44: CC1A4025 1C96E12A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C7E4C: BF870193
	v_dot2_f32_bf16 v36, v45, v111, v36                        // 0000002C7E50: CC1A4024 1C92DF2D
	v_dot2_f32_bf16 v45, v50, v112, v40                        // 0000002C7E58: CC1A402D 1CA2E132
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C7E60: BF870193
	v_dot2_f32_bf16 v127, v43, v113, v37                       // 0000002C7E64: CC1A407F 1C96E32B
	v_dot2_f32_bf16 v41, v46, v112, v36                        // 0000002C7E6C: CC1A4029 1C92E12E
	s_waitcnt vmcnt(10)                                        // 0000002C7E74: BF892BF7
	v_dot2_f32_bf16 v46, v56, v110, 0                          // 0000002C7E78: CC1A402E 1A02DD38
	v_dot2_f32_bf16 v44, v52, v110, 0                          // 0000002C7E80: CC1A402C 1A02DD34
	v_dot2_f32_bf16 v129, v51, v113, v45                       // 0000002C7E88: CC1A4081 1CB6E333
	s_waitcnt vmcnt(9)                                         // 0000002C7E90: BF8927F7
	v_dot2_f32_bf16 v45, v60, v110, 0                          // 0000002C7E94: CC1A402D 1A02DD3C
	v_dot2_f32_bf16 v128, v47, v113, v41                       // 0000002C7E9C: CC1A4080 1CA6E32F
	s_waitcnt vmcnt(8)                                         // 0000002C7EA4: BF8923F7
	v_dot2_f32_bf16 v47, v64, v110, 0                          // 0000002C7EA8: CC1A402F 1A02DD40
	s_waitcnt vmcnt(7) lgkmcnt(3)                              // 0000002C7EB0: BF891C37
	v_dot2_f32_bf16 v52, v68, v114, v126                       // 0000002C7EB4: CC1A4034 1DFAE544
	global_load_b128 v[36:39], v[15:16], off offset:32         // 0000002C7EBC: DC5E0020 247C000F
	v_dot2_f32_bf16 v44, v53, v111, v44                        // 0000002C7EC4: CC1A402C 1CB2DF35
	v_dot2_f32_bf16 v48, v57, v111, v46                        // 0000002C7ECC: CC1A4030 1CBADF39
	v_dot2_f32_bf16 v53, v61, v111, v45                        // 0000002C7ED4: CC1A4035 1CB6DF3D
	v_dot2_f32_bf16 v56, v65, v111, v47                        // 0000002C7EDC: CC1A4038 1CBEDF41
	s_waitcnt lgkmcnt(2)                                       // 0000002C7EE4: BF89FC27
	v_dot2_f32_bf16 v57, v69, v115, v52                        // 0000002C7EE8: CC1A4039 1CD2E745
	v_dot2_f32_bf16 v49, v54, v112, v44                        // 0000002C7EF0: CC1A4031 1CB2E136
	v_dot2_f32_bf16 v54, v58, v112, v48                        // 0000002C7EF8: CC1A4036 1CC2E13A
	v_dot2_f32_bf16 v58, v62, v112, v53                        // 0000002C7F00: CC1A403A 1CD6E13E
	v_dot2_f32_bf16 v60, v66, v112, v56                        // 0000002C7F08: CC1A403C 1CE2E142
	s_waitcnt lgkmcnt(1)                                       // 0000002C7F10: BF89FC17
	v_dot2_f32_bf16 v64, v70, v116, v57                        // 0000002C7F14: CC1A4040 1CE6E946
	s_waitcnt vmcnt(7)                                         // 0000002C7F1C: BF891FF7
	v_dot2_f32_bf16 v68, v72, v114, v127                       // 0000002C7F20: CC1A4044 1DFEE548
	s_clause 0x1                                               // 0000002C7F28: BF850001
	global_load_b128 v[40:43], v[96:97], off offset:32         // 0000002C7F2C: DC5E0020 287C0060
	global_load_b128 v[44:47], v[98:99], off offset:32         // 0000002C7F34: DC5E0020 2C7C0062
	v_dot2_f32_bf16 v110, v55, v113, v49                       // 0000002C7F3C: CC1A406E 1CC6E337
	global_load_b128 v[48:51], v[100:101], off offset:32       // 0000002C7F44: DC5E0020 307C0064
	v_dot2_f32_bf16 v111, v59, v113, v54                       // 0000002C7F4C: CC1A406F 1CDAE33B
	global_load_b128 v[52:55], v[102:103], off offset:32       // 0000002C7F54: DC5E0020 347C0066
	v_dot2_f32_bf16 v112, v63, v113, v58                       // 0000002C7F5C: CC1A4070 1CEAE33F
	global_load_b128 v[56:59], v[104:105], off offset:32       // 0000002C7F64: DC5E0020 387C0068
	v_dot2_f32_bf16 v113, v67, v113, v60                       // 0000002C7F6C: CC1A4071 1CF2E343
	global_load_b128 v[60:63], v[106:107], off offset:32       // 0000002C7F74: DC5E0020 3C7C006A
	s_waitcnt lgkmcnt(0)                                       // 0000002C7F7C: BF89FC07
	v_dot2_f32_bf16 v126, v71, v117, v64                       // 0000002C7F80: CC1A407E 1D02EB47
	global_load_b128 v[64:67], v[108:109], off offset:32       // 0000002C7F88: DC5E0020 407C006C
	s_waitcnt vmcnt(13)                                        // 0000002C7F90: BF8937F7
	v_dot2_f32_bf16 v69, v76, v114, v128                       // 0000002C7F94: CC1A4045 1E02E54C
	v_dot2_f32_bf16 v68, v73, v115, v68                        // 0000002C7F9C: CC1A4044 1D12E749
	s_waitcnt vmcnt(11)                                        // 0000002C7FA4: BF892FF7
	v_dot2_f32_bf16 v5, v5, v114, v110                         // 0000002C7FA8: CC1A4005 1DBAE505
	s_waitcnt vmcnt(10)                                        // 0000002C7FB0: BF892BF7
	v_dot2_f32_bf16 v84, v84, v114, v111                       // 0000002C7FB4: CC1A4054 1DBEE554
	global_load_b128 v[108:111], v[108:109], off offset:48     // 0000002C7FBC: DC5E0030 6C7C006C
	v_dot2_f32_bf16 v72, v77, v115, v69                        // 0000002C7FC4: CC1A4048 1D16E74D
	v_dot2_f32_bf16 v73, v74, v116, v68                        // 0000002C7FCC: CC1A4049 1D12E94A
	global_load_b128 v[68:71], v[15:16], off offset:48         // 0000002C7FD4: DC5E0030 447C000F
	v_dot2_f32_bf16 v15, v80, v114, v129                       // 0000002C7FDC: CC1A400F 1E06E550
	s_waitcnt vmcnt(11)                                        // 0000002C7FE4: BF892FF7
	v_dot2_f32_bf16 v88, v88, v114, v112                       // 0000002C7FE8: CC1A4058 1DC2E558
	v_dot2_f32_bf16 v16, v78, v116, v72                        // 0000002C7FF0: CC1A4010 1D22E94E
	v_dot2_f32_bf16 v127, v75, v117, v73                       // 0000002C7FF8: CC1A407F 1D26EB4B
	s_clause 0x1                                               // 0000002C8000: BF850001
	global_load_b128 v[72:75], v[96:97], off offset:48         // 0000002C8004: DC5E0030 487C0060
	global_load_b128 v[96:99], v[98:99], off offset:48         // 0000002C800C: DC5E0030 607C0062
	v_dot2_f32_bf16 v15, v81, v115, v15                        // 0000002C8014: CC1A400F 1C3EE751
	v_dot2_f32_bf16 v5, v6, v115, v5                           // 0000002C801C: CC1A4005 1C16E706
	v_dot2_f32_bf16 v16, v79, v117, v16                        // 0000002C8024: CC1A4010 1C42EB4F
	s_clause 0x1                                               // 0000002C802C: BF850001
	global_load_b128 v[76:79], v[100:101], off offset:48       // 0000002C8030: DC5E0030 4C7C0064
	global_load_b128 v[100:103], v[102:103], off offset:48     // 0000002C8038: DC5E0030 647C0066
	v_dot2_f32_bf16 v15, v82, v116, v15                        // 0000002C8040: CC1A400F 1C3EE952
	v_dot2_f32_bf16 v6, v85, v115, v84                         // 0000002C8048: CC1A4006 1D52E755
	v_dot2_f32_bf16 v84, v89, v115, v88                        // 0000002C8050: CC1A4054 1D62E759
	v_lshlrev_b32_e32 v88, 2, v118                             // 0000002C8058: 30B0EC82
	v_and_b32_e32 v89, 0x3fc, v119                             // 0000002C805C: 36B2EEFF 000003FC
	v_dot2_f32_bf16 v15, v83, v117, v15                        // 0000002C8064: CC1A400F 1C3EEB53
	s_clause 0x1                                               // 0000002C806C: BF850001
	global_load_b128 v[80:83], v[104:105], off offset:48       // 0000002C8070: DC5E0030 507C0068
	global_load_b128 v[104:107], v[106:107], off offset:48     // 0000002C8078: DC5E0030 687C006A
	ds_load_b32 v88, v88                                       // 0000002C8080: D8D80000 58000058
	ds_load_b32 v89, v89                                       // 0000002C8088: D8D80000 59000059
	s_waitcnt vmcnt(16)                                        // 0000002C8090: BF8943F7
	v_dot2_f32_bf16 v92, v92, v114, v113                       // 0000002C8094: CC1A405C 1DC6E55C
	v_dot2_f32_bf16 v5, v7, v116, v5                           // 0000002C809C: CC1A4005 1C16E907
	v_lshlrev_b32_e32 v112, 2, v122                            // 0000002C80A4: 30E0F482
	v_dot2_f32_bf16 v6, v86, v116, v6                          // 0000002C80A8: CC1A4006 1C1AE956
	v_and_b32_e32 v113, 0x3fc, v123                            // 0000002C80B0: 36E2F6FF 000003FC
	v_dot2_f32_bf16 v85, v93, v115, v92                        // 0000002C80B8: CC1A4055 1D72E75D
	v_and_b32_e32 v92, 0x3fc, v120                             // 0000002C80C0: 36B8F0FF 000003FC
	v_and_b32_e32 v93, 0x3fc, v121                             // 0000002C80C8: 36BAF2FF 000003FC
	v_dot2_f32_bf16 v5, v8, v117, v5                           // 0000002C80D0: CC1A4005 1C16EB08
	v_dot2_f32_bf16 v8, v90, v116, v84                         // 0000002C80D8: CC1A4008 1D52E95A
	v_dot2_f32_bf16 v84, v94, v116, v85                        // 0000002C80E0: CC1A4054 1D56E95E
	ds_load_b32 v92, v92                                       // 0000002C80E8: D8D80000 5C00005C
	v_and_b32_e32 v114, 0x3fc, v124                            // 0000002C80F0: 36E4F8FF 000003FC
	v_and_b32_e32 v115, 0x3fc, v125                            // 0000002C80F8: 36E6FAFF 000003FC
	ds_load_b32 v7, v93                                        // 0000002C8100: D8D80000 0700005D
	ds_load_b32 v93, v112                                      // 0000002C8108: D8D80000 5D000070
	ds_load_b32 v112, v113                                     // 0000002C8110: D8D80000 70000071
	ds_load_b32 v113, v114                                     // 0000002C8118: D8D80000 71000072
	ds_load_b32 v114, v115                                     // 0000002C8120: D8D80000 72000073
	v_dot2_f32_bf16 v6, v87, v117, v6                          // 0000002C8128: CC1A4006 1C1AEB57
	v_dot2_f32_bf16 v8, v91, v117, v8                          // 0000002C8130: CC1A4008 1C22EB5B
	s_waitcnt vmcnt(15) lgkmcnt(7)                             // 0000002C8138: BF893C77
	v_dot2_f32_bf16 v36, v36, v88, v126                        // 0000002C813C: CC1A4024 1DFAB124
	s_waitcnt lgkmcnt(6)                                       // 0000002C8144: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002C8148: BF870131
	v_dot2_f32_bf16 v36, v37, v89, v36                         // 0000002C814C: CC1A4024 1C92B325
	v_dot2_f32_bf16 v37, v95, v117, v84                        // 0000002C8154: CC1A4025 1D52EB5F
	s_waitcnt lgkmcnt(5)                                       // 0000002C815C: BF89FC57
	v_dot2_f32_bf16 v36, v38, v92, v36                         // 0000002C8160: CC1A4024 1C92B926
	s_waitcnt vmcnt(14)                                        // 0000002C8168: BF893BF7
	v_dot2_f32_bf16 v40, v40, v88, v127                        // 0000002C816C: CC1A4028 1DFEB128
	s_waitcnt vmcnt(13)                                        // 0000002C8174: BF8937F7
	v_dot2_f32_bf16 v16, v44, v88, v16                         // 0000002C8178: CC1A4010 1C42B12C
	s_waitcnt vmcnt(12)                                        // 0000002C8180: BF8933F7
	v_dot2_f32_bf16 v15, v48, v88, v15                         // 0000002C8184: CC1A400F 1C3EB130
	s_waitcnt lgkmcnt(4)                                       // 0000002C818C: BF89FC47
	v_dot2_f32_bf16 v36, v39, v7, v36                          // 0000002C8190: CC1A4024 1C920F27
	s_waitcnt vmcnt(11)                                        // 0000002C8198: BF892FF7
	v_dot2_f32_bf16 v5, v52, v88, v5                           // 0000002C819C: CC1A4005 1C16B134
	v_dot2_f32_bf16 v40, v41, v89, v40                         // 0000002C81A4: CC1A4028 1CA2B329
	s_waitcnt vmcnt(10)                                        // 0000002C81AC: BF892BF7
	v_dot2_f32_bf16 v6, v56, v88, v6                           // 0000002C81B0: CC1A4006 1C1AB138
	v_dot2_f32_bf16 v16, v45, v89, v16                         // 0000002C81B8: CC1A4010 1C42B32D
	s_waitcnt vmcnt(9)                                         // 0000002C81C0: BF8927F7
	v_dot2_f32_bf16 v8, v60, v88, v8                           // 0000002C81C4: CC1A4008 1C22B13C
	v_dot2_f32_bf16 v15, v49, v89, v15                         // 0000002C81CC: CC1A400F 1C3EB331
	s_waitcnt vmcnt(8)                                         // 0000002C81D4: BF8923F7
	v_dot2_f32_bf16 v37, v64, v88, v37                         // 0000002C81D8: CC1A4025 1C96B140
	v_dot2_f32_bf16 v5, v53, v89, v5                           // 0000002C81E0: CC1A4005 1C16B335
	v_dot2_f32_bf16 v6, v57, v89, v6                           // 0000002C81E8: CC1A4006 1C1AB339
	v_dot2_f32_bf16 v8, v61, v89, v8                           // 0000002C81F0: CC1A4008 1C22B33D
	v_dot2_f32_bf16 v38, v42, v92, v40                         // 0000002C81F8: CC1A4026 1CA2B92A
	v_dot2_f32_bf16 v37, v65, v89, v37                         // 0000002C8200: CC1A4025 1C96B341
	v_dot2_f32_bf16 v16, v46, v92, v16                         // 0000002C8208: CC1A4010 1C42B92E
	v_dot2_f32_bf16 v15, v50, v92, v15                         // 0000002C8210: CC1A400F 1C3EB932
	v_dot2_f32_bf16 v5, v54, v92, v5                           // 0000002C8218: CC1A4005 1C16B936
	v_dot2_f32_bf16 v6, v58, v92, v6                           // 0000002C8220: CC1A4006 1C1AB93A
	v_dot2_f32_bf16 v8, v62, v92, v8                           // 0000002C8228: CC1A4008 1C22B93E
	v_dot2_f32_bf16 v37, v66, v92, v37                         // 0000002C8230: CC1A4025 1C96B942
	v_dot2_f32_bf16 v38, v43, v7, v38                          // 0000002C8238: CC1A4026 1C9A0F2B
	v_dot2_f32_bf16 v16, v47, v7, v16                          // 0000002C8240: CC1A4010 1C420F2F
	s_waitcnt vmcnt(6) lgkmcnt(3)                              // 0000002C8248: BF891837
	v_dot2_f32_bf16 v36, v68, v93, v36                         // 0000002C824C: CC1A4024 1C92BB44
	v_dot2_f32_bf16 v15, v51, v7, v15                          // 0000002C8254: CC1A400F 1C3E0F33
	v_dot2_f32_bf16 v5, v55, v7, v5                            // 0000002C825C: CC1A4005 1C160F37
	v_dot2_f32_bf16 v6, v59, v7, v6                            // 0000002C8264: CC1A4006 1C1A0F3B
	v_dot2_f32_bf16 v8, v63, v7, v8                            // 0000002C826C: CC1A4008 1C220F3F
	v_dot2_f32_bf16 v7, v67, v7, v37                           // 0000002C8274: CC1A4007 1C960F43
	s_waitcnt lgkmcnt(2)                                       // 0000002C827C: BF89FC27
	v_dot2_f32_bf16 v36, v69, v112, v36                        // 0000002C8280: CC1A4024 1C92E145
	s_waitcnt vmcnt(5)                                         // 0000002C8288: BF8917F7
	v_dot2_f32_bf16 v38, v72, v93, v38                         // 0000002C828C: CC1A4026 1C9ABB48
	s_waitcnt vmcnt(4)                                         // 0000002C8294: BF8913F7
	v_dot2_f32_bf16 v16, v96, v93, v16                         // 0000002C8298: CC1A4010 1C42BB60
	s_waitcnt vmcnt(3)                                         // 0000002C82A0: BF890FF7
	v_dot2_f32_bf16 v15, v76, v93, v15                         // 0000002C82A4: CC1A400F 1C3EBB4C
	s_waitcnt vmcnt(2)                                         // 0000002C82AC: BF890BF7
	v_dot2_f32_bf16 v5, v100, v93, v5                          // 0000002C82B0: CC1A4005 1C16BB64
	s_waitcnt vmcnt(1)                                         // 0000002C82B8: BF8907F7
	v_dot2_f32_bf16 v6, v80, v93, v6                           // 0000002C82BC: CC1A4006 1C1ABB50
	s_waitcnt vmcnt(0)                                         // 0000002C82C4: BF8903F7
	v_dot2_f32_bf16 v8, v104, v93, v8                          // 0000002C82C8: CC1A4008 1C22BB68
	v_dot2_f32_bf16 v7, v108, v93, v7                          // 0000002C82D0: CC1A4007 1C1EBB6C
	s_waitcnt lgkmcnt(1)                                       // 0000002C82D8: BF89FC17
	v_dot2_f32_bf16 v36, v70, v113, v36                        // 0000002C82DC: CC1A4024 1C92E346
	v_dot2_f32_bf16 v38, v73, v112, v38                        // 0000002C82E4: CC1A4026 1C9AE149
	v_dot2_f32_bf16 v16, v97, v112, v16                        // 0000002C82EC: CC1A4010 1C42E161
	v_dot2_f32_bf16 v15, v77, v112, v15                        // 0000002C82F4: CC1A400F 1C3EE14D
	v_dot2_f32_bf16 v5, v101, v112, v5                         // 0000002C82FC: CC1A4005 1C16E165
	v_dot2_f32_bf16 v6, v81, v112, v6                          // 0000002C8304: CC1A4006 1C1AE151
	v_dot2_f32_bf16 v8, v105, v112, v8                         // 0000002C830C: CC1A4008 1C22E169
	v_dot2_f32_bf16 v7, v109, v112, v7                         // 0000002C8314: CC1A4007 1C1EE16D
	s_waitcnt lgkmcnt(0)                                       // 0000002C831C: BF89FC07
	v_dot2_f32_bf16 v36, v71, v114, v36                        // 0000002C8320: CC1A4024 1C92E547
	v_dot2_f32_bf16 v37, v74, v113, v38                        // 0000002C8328: CC1A4025 1C9AE34A
	v_dot2_f32_bf16 v16, v98, v113, v16                        // 0000002C8330: CC1A4010 1C42E362
	v_dot2_f32_bf16 v15, v78, v113, v15                        // 0000002C8338: CC1A400F 1C3EE34E
	v_dot2_f32_bf16 v5, v102, v113, v5                         // 0000002C8340: CC1A4005 1C16E366
	v_dot2_f32_bf16 v6, v82, v113, v6                          // 0000002C8348: CC1A4006 1C1AE352
	v_dot2_f32_bf16 v8, v106, v113, v8                         // 0000002C8350: CC1A4008 1C22E36A
	v_dot2_f32_bf16 v7, v110, v113, v7                         // 0000002C8358: CC1A4007 1C1EE36E
	v_fmac_f32_e32 v26, v25, v36                               // 0000002C8360: 56344919
	v_dot2_f32_bf16 v36, v75, v114, v37                        // 0000002C8364: CC1A4024 1C96E54B
	v_dot2_f32_bf16 v16, v99, v114, v16                        // 0000002C836C: CC1A4010 1C42E563
	v_dot2_f32_bf16 v15, v79, v114, v15                        // 0000002C8374: CC1A400F 1C3EE54F
	v_dot2_f32_bf16 v5, v103, v114, v5                         // 0000002C837C: CC1A4005 1C16E567
	v_dot2_f32_bf16 v6, v83, v114, v6                          // 0000002C8384: CC1A4006 1C1AE553
	v_dot2_f32_bf16 v8, v107, v114, v8                         // 0000002C838C: CC1A4008 1C22E56B
	v_dot2_f32_bf16 v7, v111, v114, v7                         // 0000002C8394: CC1A4007 1C1EE56F
	v_dual_fmac_f32 v30, v25, v15 :: v_dual_add_nc_u32 v33, 0x100, v33// 0000002C839C: C8201F19 1E2042FF 00000100
	v_fmac_f32_e32 v32, v25, v36                               // 0000002C83A8: 56404919
	v_fmac_f32_e32 v31, v25, v16                               // 0000002C83AC: 563E2119
	v_fmac_f32_e32 v29, v25, v5                                // 0000002C83B0: 563A0B19
	v_fmac_f32_e32 v28, v25, v6                                // 0000002C83B4: 56380D19
	v_fmac_f32_e32 v27, v25, v8                                // 0000002C83B8: 56361119
	v_fmac_f32_e32 v21, v25, v7                                // 0000002C83BC: 562A0F19
	v_mov_b32_e32 v25, v35                                     // 0000002C83C0: 7E320323
	s_and_not1_b32 exec_lo, exec_lo, s18                       // 0000002C83C4: 917E127E
	s_cbranch_execz 31                                         // 0000002C83C8: BFA5001F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xc48>
	s_waitcnt vmcnt(0)                                         // 0000002C83CC: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v22, 16, v22    // 0000002C83D0: CA200101 05162C90
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000002C83D8: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000002C83E0: 7E100304
	s_mov_b32 s14, exec_lo                                     // 0000002C83E4: BE8E007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002C83E8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v22, v23                          // 0000002C83EC: 7C8C2F16
	.long 0xd4c1007e                                           // 0000002C83F0: D4C1007E
	v_cndmask_b32_e32 v1, v22, v23, vcc_lo                     // 0000002C83F4: 02022F16
	s_cbranch_execz 65009                                      // 0000002C83F8: BFA5FDF1 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3c0>
	v_ashrrev_i32_e32 v6, 31, v34                              // 0000002C83FC: 340C449F
	v_ashrrev_i32_e32 v8, 31, v33                              // 0000002C8400: 3410429F
	.long 0xd7000105                                           // 0000002C8404: D7000105
	v_cndmask_b32_e32 v1, v13, v34, vcc_lo                     // 0000002C8408: 0202450D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C840C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v24, v6, s1                  // 0000002C8410: D5207C06 00060D18
	.long 0xd7000107                                           // 0000002C8418: D7000107
	v_cndmask_b32_e32 v1, v11, v33, vcc_lo                     // 0000002C841C: 0202430B
	v_add_co_ci_u32_e64 v8, null, v12, v8, s1                  // 0000002C8420: D5207C08 0006110C
	s_clause 0x1                                               // 0000002C8428: BF850001
	global_load_d16_b16 v15, v[5:6], off                       // 0000002C842C: DC820000 0F7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000002C8434: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000002C843C: BF8907F7
	v_cvt_f32_f16_e32 v35, v15                                 // 0000002C8440: 7E46170F
	s_branch 64990                                             // 0000002C8444: BFA0FDDE <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3c0>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000002C8448: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000002C844C: BF870149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002C8450: 8C7E087E
	s_waitcnt vmcnt(0)                                         // 0000002C8454: BF8903F7
	.long 0xd71f0001                                           // 0000002C8458: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002C845C: 020100C1
	.long 0xd44a0001                                           // 0000002C8460: D44A0001
	v_cndmask_b32_e32 v1, 0, v18, vcc_lo                       // 0000002C8464: 02022480
	v_xor_b32_e32 v2, 8, v1                                    // 0000002C8468: 3A040288
	v_xor_b32_e32 v12, 4, v1                                   // 0000002C846C: 3A180284
	v_xor_b32_e32 v24, 2, v1                                   // 0000002C8470: 3A300282
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002C8474: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000002C8478: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000002C847C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 0000002C8480: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C8484: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000002C8488: 30040482
	ds_bpermute_b32 v5, v2, v31                                // 0000002C848C: DACC0000 05001F02
	s_waitcnt lgkmcnt(0)                                       // 0000002C8494: BF89FC07
	v_add_f32_e32 v5, v31, v5                                  // 0000002C8498: 060A0B1F
	ds_bpermute_b32 v3, v2, v26                                // 0000002C849C: DACC0000 03001A02
	ds_bpermute_b32 v7, v2, v29                                // 0000002C84A4: DACC0000 07001D02
	ds_bpermute_b32 v11, v2, v27                               // 0000002C84AC: DACC0000 0B001B02
	ds_bpermute_b32 v4, v2, v32                                // 0000002C84B4: DACC0000 04002002
	ds_bpermute_b32 v6, v2, v30                                // 0000002C84BC: DACC0000 06001E02
	ds_bpermute_b32 v8, v2, v28                                // 0000002C84C4: DACC0000 08001C02
	ds_bpermute_b32 v2, v2, v21                                // 0000002C84CC: DACC0000 02001502
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000002C84D4: 02181901
	v_cmp_gt_u32_e32 vcc_lo, 32, v24                           // 0000002C84D8: 7C9830A0
	s_waitcnt lgkmcnt(6)                                       // 0000002C84DC: BF89FC67
	v_dual_cndmask_b32 v24, v1, v24 :: v_dual_add_f32 v3, v26, v3// 0000002C84E0: CA483101 1802071A
	s_waitcnt lgkmcnt(5)                                       // 0000002C84E8: BF89FC57
	v_add_f32_e32 v7, v29, v7                                  // 0000002C84EC: 060E0F1D
	s_waitcnt lgkmcnt(4)                                       // 0000002C84F0: BF89FC47
	v_dual_add_f32 v11, v27, v11 :: v_dual_lshlrev_b32 v12, 2, v12// 0000002C84F4: C922171B 0B0C1882
	ds_bpermute_b32 v13, v12, v3                               // 0000002C84FC: DACC0000 0D00030C
	ds_bpermute_b32 v15, v12, v5                               // 0000002C8504: DACC0000 0F00050C
	ds_bpermute_b32 v23, v12, v11                              // 0000002C850C: DACC0000 17000B0C
	s_waitcnt lgkmcnt(3)                                       // 0000002C8514: BF89FC37
	v_add_f32_e32 v2, v21, v2                                  // 0000002C8518: 06040515
	ds_bpermute_b32 v21, v12, v7                               // 0000002C851C: DACC0000 1500070C
	v_add_f32_e32 v4, v32, v4                                  // 0000002C8524: 06080920
	v_add_f32_e32 v6, v30, v6                                  // 0000002C8528: 060C0D1E
	s_waitcnt lgkmcnt(3)                                       // 0000002C852C: BF89FC37
	v_dual_add_f32 v8, v28, v8 :: v_dual_add_f32 v3, v3, v13   // 0000002C8530: C908111C 08021B03
	ds_bpermute_b32 v14, v12, v4                               // 0000002C8538: DACC0000 0E00040C
	s_waitcnt lgkmcnt(3)                                       // 0000002C8540: BF89FC37
	v_add_f32_e32 v5, v5, v15                                  // 0000002C8544: 060A1F05
	ds_bpermute_b32 v16, v12, v6                               // 0000002C8548: DACC0000 1000060C
	s_waitcnt lgkmcnt(2)                                       // 0000002C8550: BF89FC27
	v_add_f32_e32 v7, v7, v21                                  // 0000002C8554: 060E2B07
	ds_bpermute_b32 v22, v12, v8                               // 0000002C8558: DACC0000 1600080C
	v_add_f32_e32 v11, v11, v23                                // 0000002C8560: 06162F0B
	ds_bpermute_b32 v12, v12, v2                               // 0000002C8564: DACC0000 0C00020C
	s_waitcnt lgkmcnt(3)                                       // 0000002C856C: BF89FC37
	v_add_f32_e32 v4, v4, v14                                  // 0000002C8570: 06081D04
	s_waitcnt lgkmcnt(1)                                       // 0000002C8574: BF89FC17
	v_add_f32_e32 v8, v8, v22                                  // 0000002C8578: 06102D08
	v_add_f32_e32 v6, v6, v16                                  // 0000002C857C: 060C2106
	v_lshlrev_b32_e32 v24, 2, v24                              // 0000002C8580: 30303082
	ds_bpermute_b32 v13, v24, v4                               // 0000002C8584: DACC0000 0D000418
	ds_bpermute_b32 v15, v24, v6                               // 0000002C858C: DACC0000 0F000618
	s_waitcnt lgkmcnt(0)                                       // 0000002C8594: BF89FC07
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v13, v6, v15  // 0000002C8598: C9081B04 040C1F06
	ds_bpermute_b32 v22, v24, v11                              // 0000002C85A0: DACC0000 16000B18
	v_add_f32_e32 v2, v2, v12                                  // 0000002C85A8: 06041902
	ds_bpermute_b32 v12, v24, v3                               // 0000002C85AC: DACC0000 0C000318
	ds_bpermute_b32 v14, v24, v5                               // 0000002C85B4: DACC0000 0E000518
	ds_bpermute_b32 v16, v24, v7                               // 0000002C85BC: DACC0000 10000718
	s_waitcnt lgkmcnt(3)                                       // 0000002C85C4: BF89FC37
	v_add_f32_e32 v11, v11, v22                                // 0000002C85C8: 06162D0B
	ds_bpermute_b32 v23, v24, v2                               // 0000002C85CC: DACC0000 17000218
	s_waitcnt lgkmcnt(3)                                       // 0000002C85D4: BF89FC37
	v_add_f32_e32 v3, v3, v12                                  // 0000002C85D8: 06061903
	ds_bpermute_b32 v21, v24, v8                               // 0000002C85DC: DACC0000 15000818
	v_xor_b32_e32 v24, 1, v1                                   // 0000002C85E4: 3A300281
	s_waitcnt lgkmcnt(3)                                       // 0000002C85E8: BF89FC37
	v_add_f32_e32 v12, v5, v14                                 // 0000002C85EC: 06181D05
	s_waitcnt lgkmcnt(2)                                       // 0000002C85F0: BF89FC27
	v_add_f32_e32 v14, v7, v16                                 // 0000002C85F4: 061C2107
	v_cmp_gt_u32_e32 vcc_lo, 32, v24                           // 0000002C85F8: 7C9830A0
	v_cndmask_b32_e32 v1, v1, v24, vcc_lo                      // 0000002C85FC: 02023101
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002C8600: 8B6A037E
	s_mov_b32 s3, -1                                           // 0000002C8604: BE8300C1
	s_waitcnt lgkmcnt(1)                                       // 0000002C8608: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C860C: BF870001
	v_dual_add_f32 v16, v2, v23 :: v_dual_lshlrev_b32 v1, 2, v1// 0000002C8610: C9222F02 10000282
	s_waitcnt lgkmcnt(0)                                       // 0000002C8618: BF89FC07
	v_add_f32_e32 v15, v8, v21                                 // 0000002C861C: 061E2B08
	ds_bpermute_b32 v2, v1, v3                                 // 0000002C8620: DACC0000 02000301
	ds_bpermute_b32 v7, v1, v12                                // 0000002C8628: DACC0000 07000C01
	ds_bpermute_b32 v8, v1, v13                                // 0000002C8630: DACC0000 08000D01
	ds_bpermute_b32 v21, v1, v14                               // 0000002C8638: DACC0000 15000E01
	ds_bpermute_b32 v22, v1, v15                               // 0000002C8640: DACC0000 16000F01
	ds_bpermute_b32 v23, v1, v11                               // 0000002C8648: DACC0000 17000B01
	ds_bpermute_b32 v24, v1, v16                               // 0000002C8650: DACC0000 18001001
	s_waitcnt lgkmcnt(6)                                       // 0000002C8658: BF89FC67
	v_add_f32_e32 v5, v3, v2                                   // 0000002C865C: 060A0503
	ds_bpermute_b32 v6, v1, v4                                 // 0000002C8660: DACC0000 06000401
	s_waitcnt lgkmcnt(4)                                       // 0000002C8668: BF89FC47
	v_dual_add_f32 v8, v13, v8 :: v_dual_add_f32 v1, v14, v21  // 0000002C866C: C908110D 08002B0E
	s_waitcnt lgkmcnt(3)                                       // 0000002C8674: BF89FC37
	v_dual_add_f32 v7, v12, v7 :: v_dual_add_f32 v2, v15, v22  // 0000002C8678: C9080F0C 07022D0F
	s_waitcnt lgkmcnt(0)                                       // 0000002C8680: BF89FC07
	v_dual_add_f32 v3, v11, v23 :: v_dual_add_f32 v6, v4, v6   // 0000002C8684: C9082F0B 03060D04
	v_add_f32_e32 v4, v16, v24                                 // 0000002C868C: 06083110
	s_cbranch_vccz 428                                         // 0000002C8690: BFA301AC <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1544>
	s_and_saveexec_b32 s3, s1                                  // 0000002C8694: BE832001
	s_cbranch_execz 8                                          // 0000002C8698: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0xebc>
	v_lshlrev_b32_e32 v11, 5, v20                              // 0000002C869C: 30162885
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C86A0: BF870001
	v_lshl_or_b32 v11, v19, 9, v11                             // 0000002C86A4: D656000B 042D1313
	ds_store_b128 v11, v[5:8] offset:1024                      // 0000002C86AC: DB7C0400 0000050B
	ds_store_b128 v11, v[1:4] offset:1040                      // 0000002C86B4: DB7C0410 0000010B
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002C86BC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C86C0: BF870009
	s_mov_b32 s8, exec_lo                                      // 0000002C86C4: BE88007E
	s_waitcnt lgkmcnt(0)                                       // 0000002C86C8: BF89FC07
	s_barrier                                                  // 0000002C86CC: BFBD0000
	buffer_gl0_inv                                             // 0000002C86D0: E0AC0000 00000000
	v_cmpx_gt_u32_e32 8, v0                                    // 0000002C86D8: 7D980088
	s_cbranch_execz 407                                        // 0000002C86DC: BFA50197 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x153c>
	s_load_b32 s3, s[16:17], 0x40                              // 0000002C86E0: F40000C8 F8000040
	s_waitcnt lgkmcnt(0)                                       // 0000002C86E8: BF89FC07
	s_sub_i32 s2, s2, s3                                       // 0000002C86EC: 81820302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000002C86F0: BF870499
	s_ashr_i32 s3, s2, 31                                      // 0000002C86F4: 86039F02
	.long 0xd4530004                                           // 0000002C86F8: D4530004
	v_cndmask_b32_e32 v0, s10, v2, vcc_lo                      // 0000002C86FC: 0200040A
	s_and_b32 vcc_lo, exec_lo, s4                              // 0000002C8700: 8B6A047E
	s_cbranch_vccnz 397                                        // 0000002C8704: BFA4018D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x153c>
	v_add_nc_u32_e32 v17, 0x400, v17                           // 0000002C8708: 4A2222FF 00000400
	s_clause 0x1                                               // 0000002C8710: BF850001
	s_load_b64 s[6:7], s[16:17], 0x38                          // 0000002C8714: F4040188 F8000038
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002C871C: F4040108 F8000008
	s_mov_b32 s9, 0                                            // 0000002C8724: BE890080
	s_mov_b32 s13, -1                                          // 0000002C8728: BE8D00C1
	s_mov_b32 s12, 0                                           // 0000002C872C: BE8C0080
	ds_load_2addr_b32 v[11:12], v17 offset1:8                  // 0000002C8730: D8DC0800 0B000011
	ds_load_2addr_b32 v[13:14], v17 offset0:16 offset1:24      // 0000002C8738: D8DC1810 0D000011
	ds_load_2addr_b32 v[15:16], v17 offset0:32 offset1:40      // 0000002C8740: D8DC2820 0F000011
	s_waitcnt lgkmcnt(0)                                       // 0000002C8748: BF89FC07
	s_cmp_lt_i32 s7, 3                                         // 0000002C874C: BF048307
	v_add_f32_e32 v11, 0, v11                                  // 0000002C8750: 06161680
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C8754: BF8700B1
	v_add_f32_e32 v18, v11, v12                                // 0000002C8758: 0624190B
	ds_load_2addr_b32 v[11:12], v17 offset0:48 offset1:56      // 0000002C875C: D8DC3830 0B000011
	v_add_f32_e32 v13, v18, v13                                // 0000002C8764: 061A1B12
	v_add_f32_e32 v18, v13, v14                                // 0000002C8768: 06241D0D
	ds_load_2addr_b32 v[13:14], v17 offset0:64 offset1:72      // 0000002C876C: D8DC4840 0D000011
	v_add_f32_e32 v15, v18, v15                                // 0000002C8774: 061E1F12
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002C8778: BF8700C1
	v_add_f32_e32 v18, v15, v16                                // 0000002C877C: 0624210F
	ds_load_2addr_b32 v[15:16], v17 offset0:80 offset1:88      // 0000002C8780: D8DC5850 0F000011
	s_waitcnt lgkmcnt(2)                                       // 0000002C8788: BF89FC27
	v_add_f32_e32 v11, v18, v11                                // 0000002C878C: 06161712
	v_add_f32_e32 v11, v11, v12                                // 0000002C8790: 0616190B
	s_waitcnt lgkmcnt(1)                                       // 0000002C8794: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000002C8798: BF8700C1
	v_add_f32_e32 v13, v11, v13                                // 0000002C879C: 061A1B0B
	ds_load_2addr_b32 v[11:12], v17 offset0:96 offset1:104     // 0000002C87A0: D8DC6860 0B000011
	v_add_f32_e32 v13, v13, v14                                // 0000002C87A8: 061A1D0D
	s_waitcnt lgkmcnt(1)                                       // 0000002C87AC: BF89FC17
	v_add_f32_e32 v15, v13, v15                                // 0000002C87B0: 061E1F0D
	ds_load_2addr_b32 v[13:14], v17 offset0:112 offset1:120    // 0000002C87B4: D8DC7870 0D000011
	v_add_f32_e32 v15, v15, v16                                // 0000002C87BC: 061E210F
	s_waitcnt lgkmcnt(1)                                       // 0000002C87C0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C87C4: BF870091
	v_add_f32_e32 v11, v15, v11                                // 0000002C87C8: 0616170F
	v_add_f32_e32 v11, v11, v12                                // 0000002C87CC: 0616190B
	s_waitcnt lgkmcnt(0)                                       // 0000002C87D0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C87D4: BF870091
	v_add_f32_e32 v11, v11, v13                                // 0000002C87D8: 06161B0B
	v_add_f32_e32 v11, v11, v14                                // 0000002C87DC: 06161D0B
	s_cbranch_scc1 178                                         // 0000002C87E0: BFA200B2 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12ac>
	s_cmp_gt_i32 s7, 3                                         // 0000002C87E4: BF028307
	s_cbranch_scc0 112                                         // 0000002C87E8: BFA10070 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11ac>
	s_cmp_gt_i32 s7, 4                                         // 0000002C87EC: BF028407
	s_cbranch_scc0 58                                          // 0000002C87F0: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10dc>
	s_cmp_eq_u32 s7, 5                                         // 0000002C87F4: BF068507
	s_mov_b32 s12, -1                                          // 0000002C87F8: BE8C00C1
	s_cbranch_scc0 54                                          // 0000002C87FC: BFA10036 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x10d8>
	s_ashr_i32 s14, s2, 31                                     // 0000002C8800: 860E9F02
	s_load_b64 s[12:13], s[16:17], 0x10                        // 0000002C8804: F4040308 F8000010
	s_lshr_b32 s14, s14, 23                                    // 0000002C880C: 850E970E
	s_lshr_b32 s15, s10, 31                                    // 0000002C8810: 850F9F0A
	s_add_i32 s14, s2, s14                                     // 0000002C8814: 810E0E02
	s_add_i32 s18, s10, s15                                    // 0000002C8818: 81120F0A
	s_ashr_i32 s14, s14, 9                                     // 0000002C881C: 860E890E
	s_ashr_i32 s18, s18, 1                                     // 0000002C8820: 86128112
	s_ashr_i32 s15, s14, 31                                    // 0000002C8824: 860F9F0E
	v_mad_i64_i32 v[12:13], null, s18, v0, 0                   // 0000002C8828: D6FF7C0C 02020012
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000002C8830: 848E890E
	v_bfe_u32 v14, v11, 16, 1                                  // 0000002C8834: D610000E 0205210B
	s_sub_u32 s18, s2, s14                                     // 0000002C883C: 80920E02
	s_subb_u32 s19, s3, s15                                    // 0000002C8840: 82930F03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8844: BF870119
	.long 0xd4540014                                           // 0000002C8848: D4540014
	v_cndmask_b32_e32 v0, 0x100, v18, vcc_lo                   // 0000002C884C: 020024FF 00000100
	v_add3_u32 v14, v11, v14, 0x7fff                           // 0000002C8854: D655000E 03FE1D0B 00007FFF
	.long 0xd73c000c                                           // 0000002C8860: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000002C8864: 02021881
	s_and_b32 s21, s20, exec_lo                                // 0000002C8868: 8B157E14
	s_waitcnt lgkmcnt(0)                                       // 0000002C886C: BF89FC07
	s_cselect_b32 s12, s4, s12                                 // 0000002C8870: 980C0C04
	s_cselect_b32 s21, s5, s13                                 // 0000002C8874: 98150D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8878: BF870091
	.long 0xd7006a0c                                           // 0000002C887C: D7006A0C
	v_cndmask_b32_e32 v1, s12, v12, vcc_lo                     // 0000002C8880: 0202180C
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000002C8884: D5207C0D 01AA1A15
	s_add_u32 s22, s18, 0xffffff00                             // 0000002C888C: 8016FF12 FFFFFF00
	s_addc_u32 s13, s19, -1                                    // 0000002C8894: 820DC113
	s_and_b32 s20, s20, exec_lo                                // 0000002C8898: 8B147E14
	.long 0xd7006a0c                                           // 0000002C889C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000002C88A0: 02001D0C
	s_cselect_b32 s13, s19, s13                                // 0000002C88A4: 980D0D13
	s_cselect_b32 s12, s18, s22                                // 0000002C88A8: 980C1612
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 0000002C88AC: D5207C0D 01AA1A0F
	s_lshl_b64 s[12:13], s[12:13], 1                           // 0000002C88B4: 848C810C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C88B8: BF870099
	.long 0xd7006a0c                                           // 0000002C88BC: D7006A0C
	v_cndmask_b32_e32 v0, v12, v12, vcc_lo                     // 0000002C88C0: 0200190C
	v_add_co_ci_u32_e64 v13, null, s13, v13, vcc_lo            // 0000002C88C4: D5207C0D 01AA1A0D
	s_mov_b32 s12, 0                                           // 0000002C88CC: BE8C0080
	global_store_d16_hi_b16 v[12:13], v14, off                 // 0000002C88D0: DC960000 007C0E0C
	s_mov_b32 s13, 0                                           // 0000002C88D8: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C88DC: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002C88E0: 8B6A0D7E
	s_cbranch_vccz 48                                          // 0000002C88E4: BFA30030 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x11a8>
	v_mul_f32_e32 v12, 0xbfb8aa3b, v11                         // 0000002C88E8: 101816FF BFB8AA3B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002C88F0: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C88F4: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002C88F8: 7E184B0C
	v_add_f32_e32 v15, 1.0, v12                                // 0000002C88FC: 061E18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C8900: BF870121
	v_div_scale_f32 v16, null, v15, v15, 1.0                   // 0000002C8904: D6FC7C10 03CA1F0F
	v_div_scale_f32 v18, vcc_lo, 1.0, v15, 1.0                 // 0000002C890C: D6FC6A12 03CA1EF2
	v_rcp_f32_e32 v17, v16                                     // 0000002C8914: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8918: BF870095
	v_fma_f32 v12, -v16, v17, 1.0                              // 0000002C891C: D613000C 23CA2310
	v_fmac_f32_e32 v17, v12, v17                               // 0000002C8924: 5622230C
	v_mad_u64_u32 v[12:13], null, s10, v0, 0                   // 0000002C8928: D6FE7C0C 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8930: BF870112
	v_mul_f32_e32 v19, v18, v17                                // 0000002C8934: 10262312
	v_mad_u64_u32 v[13:14], null, s11, v0, v[13:14]            // 0000002C8938: D6FE7C0D 0436000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8940: BF870092
	v_fma_f32 v20, -v16, v19, v18                              // 0000002C8944: D6130014 244A2710
	v_fmac_f32_e32 v19, v20, v17                               // 0000002C894C: 56262314
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8950: BF870113
	.long 0xd73c000c                                           // 0000002C8954: D73C000C
	v_cndmask_b32_e32 v1, 2, v12, vcc_lo                       // 0000002C8958: 02021882
	v_fma_f32 v14, -v16, v19, v18                              // 0000002C895C: D613000E 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8964: BF870191
	v_div_fmas_f32 v14, v14, v17, v19                          // 0000002C8968: D637000E 044E230E
	.long 0xd7006a0c                                           // 0000002C8970: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000002C8974: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8978: BF870191
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000002C897C: D5207C0D 01AA1A05
	v_div_fixup_f32 v14, v14, v15, 1.0                         // 0000002C8984: D627000E 03CA1F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C898C: BF870093
	.long 0xd7006a0c                                           // 0000002C8990: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000002C8994: 02001D0C
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 0000002C8998: D5207C0D 01AA1A0F
	global_store_b32 v[12:13], v14, off                        // 0000002C89A0: DC6A0000 007C0E0C
	s_mov_b32 s13, 0                                           // 0000002C89A8: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C89AC: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002C89B0: 8B6A0D7E
	s_cbranch_vccz 60                                          // 0000002C89B4: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x12a8>
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002C89B8: D610000C 0205210B
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000002C89C0: 848E8202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C89C4: BF870091
	v_add3_u32 v12, v11, v12, 0x7fff                           // 0000002C89C8: D655000C 03FE190B 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002C89D4: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C89DC: BF870091
	v_mul_f32_e32 v12, s6, v12                                 // 0000002C89E0: 10181806
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002C89E4: 101818FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C89EC: BF870291
	v_exp_f32_e32 v12, v12                                     // 0000002C89F0: 7E184B0C
	v_add_f32_e32 v15, 1.0, v12                                // 0000002C89F4: 061E18F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C89F8: BF870121
	v_div_scale_f32 v16, null, v15, v15, 1.0                   // 0000002C89FC: D6FC7C10 03CA1F0F
	v_div_scale_f32 v18, vcc_lo, 1.0, v15, 1.0                 // 0000002C8A04: D6FC6A12 03CA1EF2
	v_rcp_f32_e32 v17, v16                                     // 0000002C8A0C: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8A10: BF870095
	v_fma_f32 v12, -v16, v17, 1.0                              // 0000002C8A14: D613000C 23CA2310
	v_fmac_f32_e32 v17, v12, v17                               // 0000002C8A1C: 5622230C
	v_mad_u64_u32 v[12:13], null, s10, v0, 0                   // 0000002C8A20: D6FE7C0C 0202000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8A28: BF870092
	v_mul_f32_e32 v19, v18, v17                                // 0000002C8A2C: 10262312
	v_fma_f32 v14, -v16, v19, v18                              // 0000002C8A30: D613000E 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002C8A38: BF870211
	v_fmac_f32_e32 v19, v14, v17                               // 0000002C8A3C: 5626230E
	v_mad_u64_u32 v[13:14], null, s11, v0, v[13:14]            // 0000002C8A40: D6FE7C0D 0436000B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8A48: BF870112
	v_fma_f32 v14, -v16, v19, v18                              // 0000002C8A4C: D613000E 244A2710
	.long 0xd73c000c                                           // 0000002C8A54: D73C000C
	v_cndmask_b32_e32 v1, 2, v12, vcc_lo                       // 0000002C8A58: 02021882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8A5C: BF870112
	v_div_fmas_f32 v14, v14, v17, v19                          // 0000002C8A60: D637000E 044E230E
	.long 0xd7006a0c                                           // 0000002C8A68: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000002C8A6C: 02021804
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002C8A70: BF870212
	v_div_fixup_f32 v14, v14, v15, 1.0                         // 0000002C8A74: D627000E 03CA1F0E
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000002C8A7C: D5207C0D 01AA1A05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8A84: BF870193
	.long 0xd7006a0c                                           // 0000002C8A88: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000002C8A8C: 02001D0C
	v_add_f32_e32 v14, v14, v14                                // 0000002C8A90: 061C1D0E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002C8A94: BF870003
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 0000002C8A98: D5207C0D 01AA1A0F
	global_store_b32 v[12:13], v14, off                        // 0000002C8AA0: DC6A0000 007C0E0C
	s_mov_b32 s13, 0                                           // 0000002C8AA8: BE8D0080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C8AAC: BF870009
	s_and_b32 vcc_lo, exec_lo, s13                             // 0000002C8AB0: 8B6A0D7E
	s_cbranch_vccz 72                                          // 0000002C8AB4: BFA30048 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13d8>
	s_cmp_gt_i32 s7, 1                                         // 0000002C8AB8: BF028107
	s_mov_b32 s9, -1                                           // 0000002C8ABC: BE8900C1
	s_cbranch_scc0 63                                          // 0000002C8AC0: BFA1003F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13c0>
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002C8AC4: D610000C 0205210B
	s_lshl_b64 s[14:15], s[2:3], 1                             // 0000002C8ACC: 848E8102
	s_mov_b32 s9, 0                                            // 0000002C8AD0: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8AD4: BF870091
	v_add3_u32 v12, v11, v12, 0x7fff                           // 0000002C8AD8: D655000C 03FE190B 00007FFF
	v_and_b32_e32 v12, 0xffff0000, v12                         // 0000002C8AE4: 361818FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8AEC: BF870091
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000002C8AF0: 101818FF BFB8AA3B
	v_exp_f32_e32 v12, v12                                     // 0000002C8AF8: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8AFC: BF870095
	v_add_f32_e32 v15, 1.0, v12                                // 0000002C8B00: 061E18F2
	v_div_scale_f32 v14, null, v15, v15, 1.0                   // 0000002C8B04: D6FC7C0E 03CA1F0F
	v_div_scale_f32 v17, vcc_lo, 1.0, v15, 1.0                 // 0000002C8B0C: D6FC6A11 03CA1EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C8B14: BF870292
	v_rcp_f32_e32 v16, v14                                     // 0000002C8B18: 7E20550E
	v_fma_f32 v12, -v14, v16, 1.0                              // 0000002C8B1C: D613000C 23CA210E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C8B24: BF870121
	v_fmac_f32_e32 v16, v12, v16                               // 0000002C8B28: 5620210C
	v_mad_u64_u32 v[12:13], null, s10, v0, 0                   // 0000002C8B2C: D6FE7C0C 0202000A
	v_mul_f32_e32 v18, v17, v16                                // 0000002C8B34: 10242111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8B38: BF870091
	v_fma_f32 v19, -v14, v18, v17                              // 0000002C8B3C: D6130013 2446250E
	v_fmac_f32_e32 v18, v19, v16                               // 0000002C8B44: 56242113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C8B48: BF870121
	v_fma_f32 v17, -v14, v18, v17                              // 0000002C8B4C: D6130011 2446250E
	v_mad_u64_u32 v[13:14], null, s11, v0, v[13:14]            // 0000002C8B54: D6FE7C0D 0436000B
	v_div_fmas_f32 v14, v17, v16, v18                          // 0000002C8B5C: D637000E 044A2111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8B64: BF870112
	.long 0xd73c000c                                           // 0000002C8B68: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000002C8B6C: 02021881
	v_div_fixup_f32 v14, v14, v15, 1.0                         // 0000002C8B70: D627000E 03CA1F0E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8B78: BF870112
	.long 0xd7006a0c                                           // 0000002C8B7C: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000002C8B80: 02021804
	v_bfe_u32 v15, v14, 16, 1                                  // 0000002C8B84: D610000F 0205210E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8B8C: BF870194
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000002C8B90: D5207C0D 01AA1A05
	.long 0xd7006a0c                                           // 0000002C8B98: D7006A0C
	v_cndmask_b32_e32 v0, v12, v14, vcc_lo                     // 0000002C8B9C: 02001D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8BA0: BF870193
	v_add3_u32 v14, v14, v15, 0x7fff                           // 0000002C8BA4: D655000E 03FE1F0E 00007FFF
	v_add_co_ci_u32_e64 v13, null, s15, v13, vcc_lo            // 0000002C8BB0: D5207C0D 01AA1A0F
	global_store_d16_hi_b16 v[12:13], v14, off                 // 0000002C8BB8: DC960000 007C0E0C
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002C8BC0: 916A097E
	s_mov_b32 s9, 0                                            // 0000002C8BC4: BE890080
	s_cbranch_vccnz 3                                          // 0000002C8BC8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x13d8>
	s_cmp_lg_u32 s7, 1                                         // 0000002C8BCC: BF078107
	s_mov_b32 s9, -1                                           // 0000002C8BD0: BE8900C1
	s_cselect_b32 s12, -1, 0                                   // 0000002C8BD4: 980C80C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C8BD8: BF8700A1
	v_bfe_u32 v12, v11, 16, 1                                  // 0000002C8BDC: D610000C 0205210B
	s_and_b32 vcc_lo, exec_lo, s12                             // 0000002C8BE4: 8B6A0C7E
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000002C8BE8: D655000B 03FE190B 00007FFF
	s_cbranch_vccz 21                                          // 0000002C8BF4: BFA30015 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x144c>
	v_mad_u64_u32 v[12:13], null, s10, v0, 0                   // 0000002C8BF8: D6FE7C0C 0202000A
	s_lshl_b64 s[12:13], s[2:3], 1                             // 0000002C8C00: 848C8102
	s_mov_b32 s9, 0                                            // 0000002C8C04: BE890080
	v_mad_u64_u32 v[13:14], null, s11, v0, v[13:14]            // 0000002C8C08: D6FE7C0D 0436000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8C10: BF870091
	.long 0xd73c000c                                           // 0000002C8C14: D73C000C
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000002C8C18: 02021881
	.long 0xd7006a0c                                           // 0000002C8C1C: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000002C8C20: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8C24: BF870111
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000002C8C28: D5207C0D 01AA1A05
	.long 0xd7006a0c                                           // 0000002C8C30: D7006A0C
	v_cndmask_b32_e32 v0, v12, v12, vcc_lo                     // 0000002C8C34: 0200190C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C8C38: BF870001
	v_add_co_ci_u32_e64 v13, null, s13, v13, vcc_lo            // 0000002C8C3C: D5207C0D 01AA1A0D
	global_store_d16_hi_b16 v[12:13], v11, off                 // 0000002C8C44: DC960000 007C0B0C
	s_and_not1_b32 vcc_lo, exec_lo, s9                         // 0000002C8C4C: 916A097E
	s_cbranch_vccnz 58                                         // 0000002C8C50: BFA4003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x153c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C8C54: BF8700A1
	v_and_b32_e32 v11, 0xffff0000, v11                         // 0000002C8C58: 361616FF FFFF0000
	s_lshl_b64 s[2:3], s[2:3], 1                               // 0000002C8C60: 84828102
	v_mul_f32_e32 v14, s6, v11                                 // 0000002C8C64: 101C1606
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8C68: BF870091
	v_mul_f32_e32 v11, 0xbfb8aa3b, v14                         // 0000002C8C6C: 10161CFF BFB8AA3B
	v_exp_f32_e32 v11, v11                                     // 0000002C8C74: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8C78: BF870095
	v_add_f32_e32 v15, 1.0, v11                                // 0000002C8C7C: 061E16F2
	v_div_scale_f32 v13, null, v15, v15, v14                   // 0000002C8C80: D6FC7C0D 043A1F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C8C88: BF870291
	v_rcp_f32_e32 v16, v13                                     // 0000002C8C8C: 7E20550D
	v_fma_f32 v11, -v13, v16, 1.0                              // 0000002C8C90: D613000B 23CA210D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002C8C98: BF870131
	v_fmac_f32_e32 v16, v11, v16                               // 0000002C8C9C: 5620210B
	v_div_scale_f32 v17, vcc_lo, v14, v15, v14                 // 0000002C8CA0: D6FC6A11 043A1F0E
	v_mad_u64_u32 v[11:12], null, s10, v0, 0                   // 0000002C8CA8: D6FE7C0B 0202000A
	v_mul_f32_e32 v18, v17, v16                                // 0000002C8CB0: 10242111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8CB4: BF870091
	v_fma_f32 v19, -v13, v18, v17                              // 0000002C8CB8: D6130013 2446250D
	v_fmac_f32_e32 v18, v19, v16                               // 0000002C8CC0: 56242113
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C8CC4: BF870121
	v_fma_f32 v17, -v13, v18, v17                              // 0000002C8CC8: D6130011 2446250D
	v_mad_u64_u32 v[12:13], null, s11, v0, v[12:13]            // 0000002C8CD0: D6FE7C0C 0432000B
	v_div_fmas_f32 v0, v17, v16, v18                           // 0000002C8CD8: D6370000 044A2111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8CE0: BF870112
	.long 0xd73c000b                                           // 0000002C8CE4: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002C8CE8: 02021681
	v_div_fixup_f32 v0, v0, v15, v14                           // 0000002C8CEC: D6270000 043A1F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C8CF4: BF870112
	.long 0xd7006a0b                                           // 0000002C8CF8: D7006A0B
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000002C8CFC: 02021604
	v_bfe_u32 v13, v0, 16, 1                                   // 0000002C8D00: D610000D 02052100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8D08: BF870194
	v_add_co_ci_u32_e64 v12, null, s5, v12, vcc_lo             // 0000002C8D0C: D5207C0C 01AA1805
	.long 0xd7006a0b                                           // 0000002C8D14: D7006A0B
	v_cndmask_b32_e32 v0, v11, v2, vcc_lo                      // 0000002C8D18: 0200050B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8D1C: BF870193
	v_add3_u32 v0, v0, v13, 0x7fff                             // 0000002C8D20: D6550000 03FE1B00 00007FFF
	v_add_co_ci_u32_e64 v12, null, s3, v12, vcc_lo             // 0000002C8D2C: D5207C0C 01AA1803
	global_store_d16_hi_b16 v[11:12], v0, off                  // 0000002C8D34: DC960000 007C000B
	s_or_b32 exec_lo, exec_lo, s8                              // 0000002C8D3C: 8C7E087E
	s_mov_b32 s3, 0                                            // 0000002C8D40: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C8D44: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000002C8D48: 8B6A037E
	s_cbranch_vccz 2145                                        // 0000002C8D4C: BFA30861 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x36d4>
	s_and_b32 s0, s1, s0                                       // 0000002C8D50: 8B000001
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C8D54: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000002C8D58: BE812000
	s_cbranch_execz 2141                                       // 0000002C8D5C: BFA5085D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x36d4>
	v_ashrrev_i32_e32 v0, 31, v10                              // 0000002C8D60: 3400149F
	s_clause 0x1                                               // 0000002C8D64: BF850001
	s_load_b64 s[4:5], s[16:17], 0x8                           // 0000002C8D68: F4040108 F8000008
	s_load_b64 s[2:3], s[16:17], 0x38                          // 0000002C8D70: F4040088 F8000038
	.long 0xd73c000b                                           // 0000002C8D78: D73C000B
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000002C8D7C: 02021281
	.long 0xd73c000d                                           // 0000002C8D80: D73C000D
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 0000002C8D84: 02021282
	s_mov_b32 s7, -1                                           // 0000002C8D88: BE8700C1
	v_lshrrev_b32_e32 v0, 23, v0                               // 0000002C8D8C: 32000097
	s_mov_b32 s1, 0                                            // 0000002C8D90: BE810080
	s_mov_b32 s6, 0                                            // 0000002C8D94: BE860080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8D98: BF870091
	.long 0xd7006a0f                                           // 0000002C8D9C: D7006A0F
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 0000002C8DA0: 02020109
	v_add_co_ci_u32_e64 v0, null, 0, v10, vcc_lo               // 0000002C8DA4: D5207C00 01AA1480
	.long 0xd7016a12                                           // 0000002C8DAC: D7016A12
	v_cndmask_b32_e32 v1, 0, v11, vcc_lo                       // 0000002C8DB0: 02021680
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C8DB4: BF870123
	v_and_b32_e32 v15, 0xfffffe00, v15                         // 0000002C8DB8: 361E1EFF FFFFFE00
	v_sub_co_ci_u32_e64 v19, null, 0, v12, vcc_lo              // 0000002C8DC0: D5217C13 01AA1880
	.long 0xd7016a10                                           // 0000002C8DC8: D7016A10
	v_cndmask_b32_e32 v1, v9, v15, vcc_lo                      // 0000002C8DCC: 02021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C8DD0: BF8700B1
	v_sub_co_ci_u32_e64 v17, null, v10, v0, vcc_lo             // 0000002C8DD4: D5217C11 01AA010A
	s_waitcnt lgkmcnt(0)                                       // 0000002C8DDC: BF89FC07
	.long 0xd7006a0b                                           // 0000002C8DE0: D7006A0B
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000002C8DE4: 02021A04
	v_add_co_ci_u32_e64 v12, null, s5, v14, vcc_lo             // 0000002C8DE8: D5207C0C 01AA1C05
	.long 0xd7006a0d                                           // 0000002C8DF0: D7006A0D
	v_cndmask_b32_e32 v1, 0xffffff00, v16, vcc_lo              // 0000002C8DF4: 020220FF FFFFFF00
	.long 0xd4540000                                           // 0000002C8DFC: D4540000
	v_cndmask_b32_e32 v1, 0x100, v16, vcc_lo                   // 0000002C8E00: 020220FF 00000100
	v_add_co_ci_u32_e64 v14, null, -1, v17, vcc_lo             // 0000002C8E08: D5207C0E 01AA22C1
	.long 0xd7006a09                                           // 0000002C8E10: D7006A09
	v_cndmask_b32_e32 v1, v11, v18, vcc_lo                     // 0000002C8E14: 0202250B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C8E18: BF870191
	v_add_co_ci_u32_e64 v10, null, v12, v19, vcc_lo            // 0000002C8E1C: D5207C0A 01AA270C
	v_cndmask_b32_e64 v14, v14, v17, s0                        // 0000002C8E24: D501000E 0002230E
	v_cndmask_b32_e64 v13, v13, v16, s0                        // 0000002C8E2C: D501000D 0002210D
	s_cmp_lt_i32 s3, 3                                         // 0000002C8E34: BF048303
	s_cbranch_scc1 118                                         // 0000002C8E38: BFA20076 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1814>
	s_cmp_gt_i32 s3, 3                                         // 0000002C8E3C: BF028303
	s_cbranch_scc0 70                                          // 0000002C8E40: BFA10046 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x175c>
	s_cmp_gt_i32 s3, 4                                         // 0000002C8E44: BF028403
	s_cbranch_scc0 34                                          // 0000002C8E48: BFA10022 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16d4>
	s_cmp_eq_u32 s3, 5                                         // 0000002C8E4C: BF068503
	s_mov_b32 s6, -1                                           // 0000002C8E50: BE8600C1
	s_cbranch_scc0 30                                          // 0000002C8E54: BFA1001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x16d0>
	s_load_b64 s[6:7], s[16:17], 0x10                          // 0000002C8E58: F4040188 F8000010
	v_dual_mov_b32 v16, s4 :: v_dual_mov_b32 v17, s5           // 0000002C8E60: CA100004 10100005
	v_bfe_u32 v19, v5, 16, 1                                   // 0000002C8E68: D6100013 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C8E70: BF8701A1
	v_add3_u32 v19, v5, v19, 0x7fff                            // 0000002C8E74: D6550013 03FE2705 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002C8E80: BF89FC07
	v_cndmask_b32_e64 v18, s6, v16, s0                         // 0000002C8E84: D5010012 00022006
	v_cndmask_b32_e64 v20, s7, v17, s0                         // 0000002C8E8C: D5010014 00022207
	.long 0xd73c0010                                           // 0000002C8E94: D73C0010
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002C8E98: 02021A81
	s_mov_b32 s6, 0                                            // 0000002C8E9C: BE860080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8EA0: BF870093
	.long 0xd7006a12                                           // 0000002C8EA4: D7006A12
	v_cndmask_b32_e32 v1, v18, v15, vcc_lo                     // 0000002C8EA8: 02021F12
	v_add_co_ci_u32_e64 v20, null, v20, v0, vcc_lo             // 0000002C8EAC: D5207C14 01AA0114
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8EB4: BF870092
	.long 0xd7006a10                                           // 0000002C8EB8: D7006A10
	v_cndmask_b32_e32 v1, v18, v16, vcc_lo                     // 0000002C8EBC: 02022112
	v_add_co_ci_u32_e64 v17, null, v20, v17, vcc_lo            // 0000002C8EC0: D5207C11 01AA2314
	global_store_d16_hi_b16 v[16:17], v19, off                 // 0000002C8EC8: DC960000 007C1310
	s_mov_b32 s7, 0                                            // 0000002C8ED0: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C8ED4: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002C8ED8: 8B6A077E
	s_cbranch_vccz 30                                          // 0000002C8EDC: BFA3001E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1758>
	v_mul_f32_e32 v16, 0xbfb8aa3b, v5                          // 0000002C8EE0: 10200AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C8EE8: BF870291
	v_exp_f32_e32 v16, v16                                     // 0000002C8EEC: 7E204B10
	v_add_f32_e32 v16, 1.0, v16                                // 0000002C8EF0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8EF4: BF870091
	v_div_scale_f32 v17, null, v16, v16, 1.0                   // 0000002C8EF8: D6FC7C11 03CA2110
	v_rcp_f32_e32 v18, v17                                     // 0000002C8F00: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F04: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000002C8F08: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000002C8F10: 56242513
	v_div_scale_f32 v19, vcc_lo, 1.0, v16, 1.0                 // 0000002C8F14: D6FC6A13 03CA20F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F1C: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000002C8F20: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000002C8F24: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F2C: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000002C8F30: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000002C8F34: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F3C: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000002C8F40: D6370011 04522511
	v_div_fixup_f32 v16, v17, v16, 1.0                         // 0000002C8F48: D6270010 03CA2111
	global_store_b32 v[11:12], v16, off                        // 0000002C8F50: DC6A0000 007C100B
	s_mov_b32 s7, 0                                            // 0000002C8F58: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C8F5C: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002C8F60: 8B6A077E
	s_cbranch_vccz 42                                          // 0000002C8F64: BFA3002A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1810>
	v_bfe_u32 v16, v5, 16, 1                                   // 0000002C8F68: D6100010 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F70: BF870091
	v_add3_u32 v16, v5, v16, 0x7fff                            // 0000002C8F74: D6550010 03FE2105 00007FFF
	v_and_b32_e32 v16, 0xffff0000, v16                         // 0000002C8F80: 362020FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8F88: BF870091
	v_mul_f32_e32 v16, s2, v16                                 // 0000002C8F8C: 10202002
	v_mul_f32_e32 v16, 0xbfb8aa3b, v16                         // 0000002C8F90: 102020FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C8F98: BF870291
	v_exp_f32_e32 v16, v16                                     // 0000002C8F9C: 7E204B10
	v_add_f32_e32 v16, 1.0, v16                                // 0000002C8FA0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8FA4: BF870091
	v_div_scale_f32 v17, null, v16, v16, 1.0                   // 0000002C8FA8: D6FC7C11 03CA2110
	v_rcp_f32_e32 v18, v17                                     // 0000002C8FB0: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8FB4: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000002C8FB8: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000002C8FC0: 56242513
	v_div_scale_f32 v19, vcc_lo, 1.0, v16, 1.0                 // 0000002C8FC4: D6FC6A13 03CA20F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8FCC: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000002C8FD0: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000002C8FD4: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8FDC: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000002C8FE0: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000002C8FE4: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C8FEC: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000002C8FF0: D6370011 04522511
	v_div_fixup_f32 v16, v17, v16, 1.0                         // 0000002C8FF8: D6270010 03CA2111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9000: BF870001
	v_add_f32_e32 v16, v16, v16                                // 0000002C9004: 06202110
	global_store_b32 v[11:12], v16, off                        // 0000002C9008: DC6A0000 007C100B
	s_mov_b32 s7, 0                                            // 0000002C9010: BE870080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9014: BF870009
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000002C9018: 8B6A077E
	s_cbranch_vccz 55                                          // 0000002C901C: BFA30037 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18fc>
	s_cmp_gt_i32 s3, 1                                         // 0000002C9020: BF028103
	s_mov_b32 s1, -1                                           // 0000002C9024: BE8100C1
	s_cbranch_scc0 46                                          // 0000002C9028: BFA1002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18e4>
	v_bfe_u32 v16, v5, 16, 1                                   // 0000002C902C: D6100010 02052105
	s_mov_b32 s1, 0                                            // 0000002C9034: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9038: BF870091
	v_add3_u32 v16, v5, v16, 0x7fff                            // 0000002C903C: D6550010 03FE2105 00007FFF
	v_and_b32_e32 v16, 0xffff0000, v16                         // 0000002C9048: 362020FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9050: BF870091
	v_mul_f32_e32 v16, 0xbfb8aa3b, v16                         // 0000002C9054: 102020FF BFB8AA3B
	v_exp_f32_e32 v16, v16                                     // 0000002C905C: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9060: BF870095
	v_add_f32_e32 v16, 1.0, v16                                // 0000002C9064: 062020F2
	v_div_scale_f32 v17, null, v16, v16, 1.0                   // 0000002C9068: D6FC7C11 03CA2110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9070: BF870291
	v_rcp_f32_e32 v18, v17                                     // 0000002C9074: 7E245511
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000002C9078: D6130013 23CA2511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9080: BF8700A1
	v_fmac_f32_e32 v18, v19, v18                               // 0000002C9084: 56242513
	v_div_scale_f32 v19, vcc_lo, 1.0, v16, 1.0                 // 0000002C9088: D6FC6A13 03CA20F2
	v_mul_f32_e32 v20, v19, v18                                // 0000002C9090: 10282513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9094: BF870091
	v_fma_f32 v21, -v17, v20, v19                              // 0000002C9098: D6130015 244E2911
	v_fmac_f32_e32 v20, v21, v18                               // 0000002C90A0: 56282515
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C90A4: BF870091
	v_fma_f32 v17, -v17, v20, v19                              // 0000002C90A8: D6130011 244E2911
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000002C90B0: D6370011 04522511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C90B8: BF870091
	v_div_fixup_f32 v16, v17, v16, 1.0                         // 0000002C90BC: D6270010 03CA2111
	v_bfe_u32 v17, v16, 16, 1                                  // 0000002C90C4: D6100011 02052110
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C90CC: BF870001
	v_add3_u32 v16, v16, v17, 0x7fff                           // 0000002C90D0: D6550010 03FE2310 00007FFF
	global_store_d16_hi_b16 v[9:10], v16, off                  // 0000002C90DC: DC960000 007C1009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C90E4: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C90E8: BE810080
	s_cbranch_vccnz 3                                          // 0000002C90EC: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x18fc>
	s_cmp_lg_u32 s3, 1                                         // 0000002C90F0: BF078103
	s_mov_b32 s1, -1                                           // 0000002C90F4: BE8100C1
	s_cselect_b32 s6, -1, 0                                    // 0000002C90F8: 980680C1
	v_bfe_u32 v16, v5, 16, 1                                   // 0000002C90FC: D6100010 02052105
	s_and_b32 vcc_lo, exec_lo, s6                              // 0000002C9104: 8B6A067E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9108: BF870001
	v_add3_u32 v5, v5, v16, 0x7fff                             // 0000002C910C: D6550005 03FE2105 00007FFF
	s_cbranch_vccz 3                                           // 0000002C9118: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1928>
	s_mov_b32 s1, 0                                            // 0000002C911C: BE810080
	global_store_d16_hi_b16 v[9:10], v5, off                   // 0000002C9120: DC960000 007C0509
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9128: 916A017E
	s_cbranch_vccnz 41                                         // 0000002C912C: BFA40029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x19d4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9130: BF870091
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9134: 360A0AFF FFFF0000
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C913C: 100A0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9140: BF870091
	v_mul_f32_e32 v16, 0xbfb8aa3b, v5                          // 0000002C9144: 10200AFF BFB8AA3B
	v_exp_f32_e32 v16, v16                                     // 0000002C914C: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9150: BF870095
	v_add_f32_e32 v16, 1.0, v16                                // 0000002C9154: 062020F2
	v_div_scale_f32 v17, null, v16, v16, v5                    // 0000002C9158: D6FC7C11 04162110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9160: BF870291
	v_rcp_f32_e32 v18, v17                                     // 0000002C9164: 7E245511
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000002C9168: D6130013 23CA2511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9170: BF8700A1
	v_fmac_f32_e32 v18, v19, v18                               // 0000002C9174: 56242513
	v_div_scale_f32 v19, vcc_lo, v5, v16, v5                   // 0000002C9178: D6FC6A13 04162105
	v_mul_f32_e32 v20, v19, v18                                // 0000002C9180: 10282513
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9184: BF870091
	v_fma_f32 v21, -v17, v20, v19                              // 0000002C9188: D6130015 244E2911
	v_fmac_f32_e32 v20, v21, v18                               // 0000002C9190: 56282515
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9194: BF870091
	v_fma_f32 v17, -v17, v20, v19                              // 0000002C9198: D6130011 244E2911
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000002C91A0: D6370011 04522511
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C91A8: BF870091
	v_div_fixup_f32 v5, v17, v16, v5                           // 0000002C91AC: D6270005 04162111
	v_bfe_u32 v16, v5, 16, 1                                   // 0000002C91B4: D6100010 02052105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C91BC: BF870001
	v_add3_u32 v5, v5, v16, 0x7fff                             // 0000002C91C0: D6550005 03FE2105 00007FFF
	global_store_d16_hi_b16 v[9:10], v5, off                   // 0000002C91CC: DC960000 007C0509
	s_lshr_b64 s[6:7], s[10:11], 1                             // 0000002C91D4: 8586810A
	s_mov_b32 s9, -1                                           // 0000002C91D8: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C91DC: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C91E0: BF048303
	s_mov_b32 s8, 0                                            // 0000002C91E4: BE880080
	s_cbranch_scc1 135                                         // 0000002C91E8: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c08>
	s_cmp_gt_i32 s3, 3                                         // 0000002C91EC: BF028303
	s_cbranch_scc0 82                                          // 0000002C91F0: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b3c>
	s_cmp_gt_i32 s3, 4                                         // 0000002C91F4: BF028403
	s_cbranch_scc0 40                                          // 0000002C91F8: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a9c>
	s_cmp_eq_u32 s3, 5                                         // 0000002C91FC: BF068503
	s_mov_b32 s8, -1                                           // 0000002C9200: BE8800C1
	s_cbranch_scc0 36                                          // 0000002C9204: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1a98>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C9208: F4040208 F8000010
	v_dual_mov_b32 v5, s4 :: v_dual_mov_b32 v16, s5            // 0000002C9210: CA100004 05100005
	v_bfe_u32 v18, v6, 16, 1                                   // 0000002C9218: D6100012 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C9220: BF8701A1
	v_add3_u32 v18, v6, v18, 0x7fff                            // 0000002C9224: D6550012 03FE2506 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002C9230: BF89FC07
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002C9234: D5010005 00020A08
	v_cndmask_b32_e64 v16, s9, v16, s0                         // 0000002C923C: D5010010 00022009
	s_lshl_b64 s[8:9], s[6:7], 1                               // 0000002C9244: 84888106
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002C9248: BF870482
	.long 0xd7006a05                                           // 0000002C924C: D7006A05
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002C9250: 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C9254: BF8701A1
	v_add_co_ci_u32_e64 v19, null, s9, v16, vcc_lo             // 0000002C9258: D5207C13 01AA2009
	.long 0xd73c0010                                           // 0000002C9260: D73C0010
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002C9264: 02021A81
	.long 0xd7006a05                                           // 0000002C9268: D7006A05
	v_cndmask_b32_e32 v1, v5, v15, vcc_lo                      // 0000002C926C: 02021F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C9270: BF8700B1
	v_add_co_ci_u32_e64 v19, null, v19, v0, vcc_lo             // 0000002C9274: D5207C13 01AA0113
	s_mov_b32 s8, 0                                            // 0000002C927C: BE880080
	.long 0xd7006a10                                           // 0000002C9280: D7006A10
	v_cndmask_b32_e32 v1, v5, v16, vcc_lo                      // 0000002C9284: 02022105
	v_add_co_ci_u32_e64 v17, null, v19, v17, vcc_lo            // 0000002C9288: D5207C11 01AA2313
	global_store_d16_hi_b16 v[16:17], v18, off                 // 0000002C9290: DC960000 007C1210
	s_mov_b32 s9, 0                                            // 0000002C9298: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C929C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C92A0: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002C92A4: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1b38>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v6                           // 0000002C92A8: 100A0CFF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002C92B0: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C92B4: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C92B8: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C92BC: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C92C0: BF870121
	v_div_scale_f32 v16, null, v5, v5, 1.0                     // 0000002C92C4: D6FC7C10 03CA0B05
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000002C92CC: D6FC6A13 03CA0AF2
	v_rcp_f32_e32 v17, v16                                     // 0000002C92D4: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C92D8: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000002C92DC: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 0000002C92E4: 56222312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C92E8: BF870091
	v_mul_f32_e32 v18, v19, v17                                // 0000002C92EC: 10242313
	v_fma_f32 v20, -v16, v18, v19                              // 0000002C92F0: D6130014 244E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C92F8: BF870091
	v_fmac_f32_e32 v18, v20, v17                               // 0000002C92FC: 56242314
	v_fma_f32 v16, -v16, v18, v19                              // 0000002C9300: D6130010 244E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9308: BF870091
	v_div_fmas_f32 v16, v16, v17, v18                          // 0000002C930C: D6370010 044A2310
	v_div_fixup_f32 v5, v16, v5, 1.0                           // 0000002C9314: D6270005 03CA0B10
	.long 0xd7006a10                                           // 0000002C931C: D7006A10
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002C9320: 0200190B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9324: BF870001
	v_add_co_ci_u32_e64 v17, null, s13, v12, vcc_lo            // 0000002C9328: D5207C11 01AA180D
	global_store_b32 v[16:17], v5, off                         // 0000002C9330: DC6A0000 007C0510
	s_mov_b32 s9, 0                                            // 0000002C9338: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C933C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9340: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002C9344: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1c04>
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002C9348: D6100005 02052106
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002C9350: 848C820A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9354: BF870091
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002C9358: D6550005 03FE0B06 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9364: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C936C: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C9370: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C9374: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C937C: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C9380: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C9384: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C9388: BF870121
	v_div_scale_f32 v16, null, v5, v5, 1.0                     // 0000002C938C: D6FC7C10 03CA0B05
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000002C9394: D6FC6A13 03CA0AF2
	v_rcp_f32_e32 v17, v16                                     // 0000002C939C: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C93A0: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000002C93A4: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 0000002C93AC: 56222312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C93B0: BF870091
	v_mul_f32_e32 v18, v19, v17                                // 0000002C93B4: 10242313
	v_fma_f32 v20, -v16, v18, v19                              // 0000002C93B8: D6130014 244E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C93C0: BF870091
	v_fmac_f32_e32 v18, v20, v17                               // 0000002C93C4: 56242314
	v_fma_f32 v16, -v16, v18, v19                              // 0000002C93C8: D6130010 244E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C93D0: BF870091
	v_div_fmas_f32 v16, v16, v17, v18                          // 0000002C93D4: D6370010 044A2310
	v_div_fixup_f32 v5, v16, v5, 1.0                           // 0000002C93DC: D6270005 03CA0B10
	.long 0xd7006a10                                           // 0000002C93E4: D7006A10
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002C93E8: 0200190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C93EC: BF870191
	v_add_co_ci_u32_e64 v17, null, s13, v12, vcc_lo            // 0000002C93F0: D5207C11 01AA180D
	v_add_f32_e32 v5, v5, v5                                   // 0000002C93F8: 060A0B05
	global_store_b32 v[16:17], v5, off                         // 0000002C93FC: DC6A0000 007C0510
	s_mov_b32 s9, 0                                            // 0000002C9404: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9408: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C940C: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002C9410: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d04>
	s_cmp_gt_i32 s3, 1                                         // 0000002C9414: BF028103
	s_mov_b32 s1, -1                                           // 0000002C9418: BE8100C1
	s_cbranch_scc0 51                                          // 0000002C941C: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1cec>
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002C9420: D6100005 02052106
	s_lshl_b64 s[12:13], s[10:11], 1                           // 0000002C9428: 848C810A
	s_mov_b32 s1, 0                                            // 0000002C942C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9430: BF870091
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002C9434: D6550005 03FE0B06 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9440: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9448: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C944C: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002C9454: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9458: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C945C: 060A0AF2
	v_div_scale_f32 v16, null, v5, v5, 1.0                     // 0000002C9460: D6FC7C10 03CA0B05
	v_div_scale_f32 v19, vcc_lo, 1.0, v5, 1.0                  // 0000002C9468: D6FC6A13 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9470: BF870292
	v_rcp_f32_e32 v17, v16                                     // 0000002C9474: 7E225510
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000002C9478: D6130012 23CA2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9480: BF870091
	v_fmac_f32_e32 v17, v18, v17                               // 0000002C9484: 56222312
	v_mul_f32_e32 v18, v19, v17                                // 0000002C9488: 10242313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C948C: BF870091
	v_fma_f32 v20, -v16, v18, v19                              // 0000002C9490: D6130014 244E2510
	v_fmac_f32_e32 v18, v20, v17                               // 0000002C9498: 56242314
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C949C: BF870091
	v_fma_f32 v16, -v16, v18, v19                              // 0000002C94A0: D6130010 244E2510
	v_div_fmas_f32 v16, v16, v17, v18                          // 0000002C94A8: D6370010 044A2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C94B0: BF870091
	v_div_fixup_f32 v5, v16, v5, 1.0                           // 0000002C94B4: D6270005 03CA0B10
	v_bfe_u32 v16, v5, 16, 1                                   // 0000002C94BC: D6100010 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C94C4: BF8700A1
	v_add3_u32 v5, v5, v16, 0x7fff                             // 0000002C94C8: D6550005 03FE2105 00007FFF
	.long 0xd7006a10                                           // 0000002C94D4: D7006A10
	v_cndmask_b32_e32 v0, v9, v12, vcc_lo                      // 0000002C94D8: 02001909
	v_add_co_ci_u32_e64 v17, null, s13, v10, vcc_lo            // 0000002C94DC: D5207C11 01AA140D
	global_store_d16_hi_b16 v[16:17], v5, off                  // 0000002C94E4: DC960000 007C0510
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C94EC: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C94F0: BE810080
	s_cbranch_vccnz 3                                          // 0000002C94F4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d04>
	s_cmp_lg_u32 s3, 1                                         // 0000002C94F8: BF078103
	s_mov_b32 s1, -1                                           // 0000002C94FC: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C9500: 980880C1
	v_bfe_u32 v5, v6, 16, 1                                    // 0000002C9504: D6100005 02052106
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C950C: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9510: BF870001
	v_add3_u32 v5, v6, v5, 0x7fff                              // 0000002C9514: D6550005 03FE0B06 00007FFF
	s_cbranch_vccz 9                                           // 0000002C9520: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1d48>
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002C9524: 8488810A
	s_mov_b32 s1, 0                                            // 0000002C9528: BE810080
	.long 0xd7006a10                                           // 0000002C952C: D7006A10
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002C9530: 02001109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9534: BF870001
	v_add_co_ci_u32_e64 v17, null, s9, v10, vcc_lo             // 0000002C9538: D5207C11 01AA1409
	global_store_d16_hi_b16 v[16:17], v5, off                  // 0000002C9540: DC960000 007C0510
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9548: 916A017E
	s_cbranch_vccnz 46                                         // 0000002C954C: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1e08>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9550: BF8700A1
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9554: 360A0AFF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 1                             // 0000002C955C: 8488810A
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C9560: 100A0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9564: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000002C9568: 100C0AFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000002C9570: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9574: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 0000002C9578: 060C0CF2
	v_div_scale_f32 v16, null, v6, v6, v5                      // 0000002C957C: D6FC7C10 04160D06
	v_div_scale_f32 v19, vcc_lo, v5, v6, v5                    // 0000002C9584: D6FC6A13 04160D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C958C: BF870292
	v_rcp_f32_e32 v17, v16                                     // 0000002C9590: 7E225510
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000002C9594: D6130012 23CA2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C959C: BF870091
	v_fmac_f32_e32 v17, v18, v17                               // 0000002C95A0: 56222312
	v_mul_f32_e32 v18, v19, v17                                // 0000002C95A4: 10242313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C95A8: BF870091
	v_fma_f32 v20, -v16, v18, v19                              // 0000002C95AC: D6130014 244E2510
	v_fmac_f32_e32 v18, v20, v17                               // 0000002C95B4: 56242314
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C95B8: BF870091
	v_fma_f32 v16, -v16, v18, v19                              // 0000002C95BC: D6130010 244E2510
	v_div_fmas_f32 v16, v16, v17, v18                          // 0000002C95C4: D6370010 044A2310
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C95CC: BF870091
	v_div_fixup_f32 v5, v16, v6, v5                            // 0000002C95D0: D6270005 04160D10
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002C95D8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C95E0: BF8700A1
	v_add3_u32 v16, v5, v6, 0x7fff                             // 0000002C95E4: D6550010 03FE0D05 00007FFF
	.long 0xd7006a05                                           // 0000002C95F0: D7006A05
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002C95F4: 02001109
	v_add_co_ci_u32_e64 v6, null, s9, v10, vcc_lo              // 0000002C95F8: D5207C06 01AA1409
	global_store_d16_hi_b16 v[5:6], v16, off                   // 0000002C9600: DC960000 007C1005
	s_mov_b32 s9, -1                                           // 0000002C9608: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C960C: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C9610: BF048303
	s_mov_b32 s8, 0                                            // 0000002C9614: BE880080
	s_cbranch_scc1 138                                         // 0000002C9618: BFA2008A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2044>
	s_cmp_gt_i32 s3, 3                                         // 0000002C961C: BF028303
	s_cbranch_scc0 85                                          // 0000002C9620: BFA10055 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f78>
	s_cmp_gt_i32 s3, 4                                         // 0000002C9624: BF028403
	s_cbranch_scc0 43                                          // 0000002C9628: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ed8>
	s_cmp_eq_u32 s3, 5                                         // 0000002C962C: BF068503
	s_mov_b32 s8, -1                                           // 0000002C9630: BE8800C1
	s_cbranch_scc0 39                                          // 0000002C9634: BFA10027 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1ed4>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C9638: F4040208 F8000010
	v_dual_mov_b32 v5, s4 :: v_dual_mov_b32 v6, s5             // 0000002C9640: CA100004 05060005
	s_and_b32 s13, s11, 0x7fffffff                             // 0000002C9648: 8B0DFF0B 7FFFFFFF
	s_and_b32 s12, s10, -2                                     // 0000002C9650: 8B0CC20A
	v_bfe_u32 v16, v7, 16, 1                                   // 0000002C9654: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C965C: BF870001
	v_add3_u32 v16, v7, v16, 0x7fff                            // 0000002C9660: D6550010 03FE2107 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002C966C: BF89FC07
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002C9670: D5010005 00020A08
	v_cndmask_b32_e64 v6, s9, v6, s0                           // 0000002C9678: D5010006 00020C09
	s_lshl_b64 s[8:9], s[12:13], 1                             // 0000002C9680: 8488810C
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002C9684: BF870482
	.long 0xd7006a11                                           // 0000002C9688: D7006A11
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002C968C: 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C9690: BF8701A1
	v_add_co_ci_u32_e64 v18, null, s9, v6, vcc_lo              // 0000002C9694: D5207C12 01AA0C09
	.long 0xd73c0005                                           // 0000002C969C: D73C0005
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002C96A0: 02021A81
	.long 0xd7006a11                                           // 0000002C96A4: D7006A11
	v_cndmask_b32_e32 v1, v17, v15, vcc_lo                     // 0000002C96A8: 02021F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C96AC: BF8700B1
	v_add_co_ci_u32_e64 v18, null, v18, v0, vcc_lo             // 0000002C96B0: D5207C12 01AA0112
	s_mov_b32 s8, 0                                            // 0000002C96B8: BE880080
	.long 0xd7006a05                                           // 0000002C96BC: D7006A05
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000002C96C0: 02020B11
	v_add_co_ci_u32_e64 v6, null, v18, v6, vcc_lo              // 0000002C96C4: D5207C06 01AA0D12
	global_store_d16_hi_b16 v[5:6], v16, off                   // 0000002C96CC: DC960000 007C1005
	s_mov_b32 s9, 0                                            // 0000002C96D4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C96D8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C96DC: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002C96E0: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x1f74>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v7                           // 0000002C96E4: 100A0EFF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002C96EC: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C96F0: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C96F4: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C96F8: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C96FC: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002C9700: D6FC7C06 03CA0B05
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 0000002C9708: D6FC6A12 03CA0AF2
	v_rcp_f32_e32 v16, v6                                      // 0000002C9710: 7E205506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9714: BF870095
	v_fma_f32 v17, -v6, v16, 1.0                               // 0000002C9718: D6130011 23CA2106
	v_fmac_f32_e32 v16, v17, v16                               // 0000002C9720: 56202111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9724: BF870091
	v_mul_f32_e32 v17, v18, v16                                // 0000002C9728: 10222112
	v_fma_f32 v19, -v6, v17, v18                               // 0000002C972C: D6130013 244A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9734: BF870091
	v_fmac_f32_e32 v17, v19, v16                               // 0000002C9738: 56222113
	v_fma_f32 v6, -v6, v17, v18                                // 0000002C973C: D6130006 244A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9744: BF870091
	v_div_fmas_f32 v6, v6, v16, v17                            // 0000002C9748: D6370006 04462106
	v_div_fixup_f32 v16, v6, v5, 1.0                           // 0000002C9750: D6270010 03CA0B06
	.long 0xd7006a05                                           // 0000002C9758: D7006A05
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002C975C: 0200190B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9760: BF870001
	v_add_co_ci_u32_e64 v6, null, s13, v12, vcc_lo             // 0000002C9764: D5207C06 01AA180D
	global_store_b32 v[5:6], v16, off                          // 0000002C976C: DC6A0000 007C1005
	s_mov_b32 s9, 0                                            // 0000002C9774: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9778: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C977C: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002C9780: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2040>
	v_bfe_u32 v5, v7, 16, 1                                    // 0000002C9784: D6100005 02052107
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002C978C: 848C830A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9790: BF870091
	v_add3_u32 v5, v7, v5, 0x7fff                              // 0000002C9794: D6550005 03FE0B07 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C97A0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C97A8: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C97AC: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C97B0: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C97B8: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C97BC: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C97C0: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C97C4: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002C97C8: D6FC7C06 03CA0B05
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 0000002C97D0: D6FC6A12 03CA0AF2
	v_rcp_f32_e32 v16, v6                                      // 0000002C97D8: 7E205506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C97DC: BF870095
	v_fma_f32 v17, -v6, v16, 1.0                               // 0000002C97E0: D6130011 23CA2106
	v_fmac_f32_e32 v16, v17, v16                               // 0000002C97E8: 56202111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C97EC: BF870091
	v_mul_f32_e32 v17, v18, v16                                // 0000002C97F0: 10222112
	v_fma_f32 v19, -v6, v17, v18                               // 0000002C97F4: D6130013 244A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C97FC: BF870091
	v_fmac_f32_e32 v17, v19, v16                               // 0000002C9800: 56222113
	v_fma_f32 v6, -v6, v17, v18                                // 0000002C9804: D6130006 244A2306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C980C: BF870091
	v_div_fmas_f32 v6, v6, v16, v17                            // 0000002C9810: D6370006 04462106
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002C9818: D6270005 03CA0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9820: BF8700A1
	v_add_f32_e32 v16, v5, v5                                  // 0000002C9824: 06200B05
	.long 0xd7006a05                                           // 0000002C9828: D7006A05
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002C982C: 0200190B
	v_add_co_ci_u32_e64 v6, null, s13, v12, vcc_lo             // 0000002C9830: D5207C06 01AA180D
	global_store_b32 v[5:6], v16, off                          // 0000002C9838: DC6A0000 007C1005
	s_mov_b32 s9, 0                                            // 0000002C9840: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9844: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9848: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002C984C: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2140>
	s_cmp_gt_i32 s3, 1                                         // 0000002C9850: BF028103
	s_mov_b32 s1, -1                                           // 0000002C9854: BE8100C1
	s_cbranch_scc0 51                                          // 0000002C9858: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2128>
	v_bfe_u32 v5, v7, 16, 1                                    // 0000002C985C: D6100005 02052107
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000002C9864: 848C820A
	s_mov_b32 s1, 0                                            // 0000002C9868: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C986C: BF870091
	v_add3_u32 v5, v7, v5, 0x7fff                              // 0000002C9870: D6550005 03FE0B07 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C987C: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9884: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C9888: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002C9890: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9894: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C9898: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002C989C: D6FC7C06 03CA0B05
	v_div_scale_f32 v18, vcc_lo, 1.0, v5, 1.0                  // 0000002C98A4: D6FC6A12 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C98AC: BF870292
	v_rcp_f32_e32 v16, v6                                      // 0000002C98B0: 7E205506
	v_fma_f32 v17, -v6, v16, 1.0                               // 0000002C98B4: D6130011 23CA2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C98BC: BF870091
	v_fmac_f32_e32 v16, v17, v16                               // 0000002C98C0: 56202111
	v_mul_f32_e32 v17, v18, v16                                // 0000002C98C4: 10222112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C98C8: BF870091
	v_fma_f32 v19, -v6, v17, v18                               // 0000002C98CC: D6130013 244A2306
	v_fmac_f32_e32 v17, v19, v16                               // 0000002C98D4: 56222113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C98D8: BF870091
	v_fma_f32 v6, -v6, v17, v18                                // 0000002C98DC: D6130006 244A2306
	v_div_fmas_f32 v6, v6, v16, v17                            // 0000002C98E4: D6370006 04462106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C98EC: BF870091
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002C98F0: D6270005 03CA0B06
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002C98F8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9900: BF8700A1
	v_add3_u32 v16, v5, v6, 0x7fff                             // 0000002C9904: D6550010 03FE0D05 00007FFF
	.long 0xd7006a05                                           // 0000002C9910: D7006A05
	v_cndmask_b32_e32 v0, v9, v12, vcc_lo                      // 0000002C9914: 02001909
	v_add_co_ci_u32_e64 v6, null, s13, v10, vcc_lo             // 0000002C9918: D5207C06 01AA140D
	global_store_d16_hi_b16 v[5:6], v16, off                   // 0000002C9920: DC960000 007C1005
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9928: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C992C: BE810080
	s_cbranch_vccnz 3                                          // 0000002C9930: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2140>
	s_cmp_lg_u32 s3, 1                                         // 0000002C9934: BF078103
	s_mov_b32 s1, -1                                           // 0000002C9938: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C993C: 980880C1
	v_bfe_u32 v5, v7, 16, 1                                    // 0000002C9940: D6100005 02052107
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C9948: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C994C: BF870001
	v_add3_u32 v5, v7, v5, 0x7fff                              // 0000002C9950: D6550005 03FE0B07 00007FFF
	s_cbranch_vccz 9                                           // 0000002C995C: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2184>
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002C9960: 8488820A
	s_mov_b32 s1, 0                                            // 0000002C9964: BE810080
	.long 0xd7006a06                                           // 0000002C9968: D7006A06
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002C996C: 02001109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9970: BF870001
	v_add_co_ci_u32_e64 v7, null, s9, v10, vcc_lo              // 0000002C9974: D5207C07 01AA1409
	global_store_d16_hi_b16 v[6:7], v5, off                    // 0000002C997C: DC960000 007C0506
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9984: 916A017E
	s_cbranch_vccnz 46                                         // 0000002C9988: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2244>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C998C: BF8700A1
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9990: 360A0AFF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 2                             // 0000002C9998: 8488820A
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C999C: 100A0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C99A0: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000002C99A4: 100C0AFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 0000002C99AC: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C99B0: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 0000002C99B4: 060C0CF2
	v_div_scale_f32 v7, null, v6, v6, v5                       // 0000002C99B8: D6FC7C07 04160D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C99C0: BF870291
	v_rcp_f32_e32 v16, v7                                      // 0000002C99C4: 7E205507
	v_fma_f32 v17, -v7, v16, 1.0                               // 0000002C99C8: D6130011 23CA2107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C99D0: BF8700A1
	v_fmac_f32_e32 v16, v17, v16                               // 0000002C99D4: 56202111
	v_div_scale_f32 v18, vcc_lo, v5, v6, v5                    // 0000002C99D8: D6FC6A12 04160D05
	v_mul_f32_e32 v17, v18, v16                                // 0000002C99E0: 10222112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C99E4: BF870091
	v_fma_f32 v19, -v7, v17, v18                               // 0000002C99E8: D6130013 244A2307
	v_fmac_f32_e32 v17, v19, v16                               // 0000002C99F0: 56222113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C99F4: BF870091
	v_fma_f32 v7, -v7, v17, v18                                // 0000002C99F8: D6130007 244A2307
	v_div_fmas_f32 v7, v7, v16, v17                            // 0000002C9A00: D6370007 04462107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9A08: BF870091
	v_div_fixup_f32 v5, v7, v6, v5                             // 0000002C9A0C: D6270005 04160D07
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002C9A14: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9A1C: BF8700A1
	v_add3_u32 v7, v5, v6, 0x7fff                              // 0000002C9A20: D6550007 03FE0D05 00007FFF
	.long 0xd7006a05                                           // 0000002C9A2C: D7006A05
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002C9A30: 02001109
	v_add_co_ci_u32_e64 v6, null, s9, v10, vcc_lo              // 0000002C9A34: D5207C06 01AA1409
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002C9A3C: DC960000 007C0705
	s_mov_b32 s9, -1                                           // 0000002C9A44: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C9A48: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C9A4C: BF048303
	s_mov_b32 s8, 0                                            // 0000002C9A50: BE880080
	s_cbranch_scc1 133                                         // 0000002C9A54: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x246c>
	s_cmp_gt_i32 s3, 3                                         // 0000002C9A58: BF028303
	s_cbranch_scc0 81                                          // 0000002C9A5C: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x23a4>
	s_cmp_gt_i32 s3, 4                                         // 0000002C9A60: BF028403
	s_cbranch_scc0 40                                          // 0000002C9A64: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2308>
	s_cmp_eq_u32 s3, 5                                         // 0000002C9A68: BF068503
	s_mov_b32 s8, -1                                           // 0000002C9A6C: BE8800C1
	s_cbranch_scc0 36                                          // 0000002C9A70: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2304>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C9A74: F4040208 F8000010
	v_mov_b32_e32 v5, s5                                       // 0000002C9A7C: 7E0A0205
	v_mov_b32_e32 v7, s4                                       // 0000002C9A80: 7E0E0204
	.long 0xd73c0010                                           // 0000002C9A84: D73C0010
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002C9A88: 02021A81
	s_waitcnt lgkmcnt(0)                                       // 0000002C9A8C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C9A90: BF870193
	v_cndmask_b32_e64 v6, s9, v5, s0                           // 0000002C9A94: D5010006 00020A09
	v_cndmask_b32_e64 v5, s8, v7, s0                           // 0000002C9A9C: D5010005 00020E08
	s_mov_b32 s8, 0                                            // 0000002C9AA4: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9AA8: BF870091
	v_mad_u64_u32 v[5:6], null, s6, 6, v[5:6]                  // 0000002C9AAC: D6FE7C05 04150C06
	v_mad_u64_u32 v[6:7], null, s7, 6, v[6:7]                  // 0000002C9AB4: D6FE7C06 04190C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9ABC: BF8700A2
	.long 0xd7006a05                                           // 0000002C9AC0: D7006A05
	v_cndmask_b32_e32 v1, v5, v15, vcc_lo                      // 0000002C9AC4: 02021F05
	v_bfe_u32 v7, v8, 16, 1                                    // 0000002C9AC8: D6100007 02052108
	v_add3_u32 v7, v8, v7, 0x7fff                              // 0000002C9AD0: D6550007 03FE0F08 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002C9ADC: BF870214
	v_add_co_ci_u32_e64 v6, null, v6, v0, vcc_lo               // 0000002C9AE0: D5207C06 01AA0106
	.long 0xd7006a05                                           // 0000002C9AE8: D7006A05
	v_cndmask_b32_e32 v1, v5, v16, vcc_lo                      // 0000002C9AEC: 02022105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9AF0: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v17, vcc_lo              // 0000002C9AF4: D5207C06 01AA2306
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002C9AFC: DC960000 007C0705
	s_mov_b32 s9, 0                                            // 0000002C9B04: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9B08: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9B0C: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002C9B10: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x23a0>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v8                           // 0000002C9B14: 100A10FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9B1C: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C9B20: 7E0A4B05
	v_add_f32_e32 v16, 1.0, v5                                 // 0000002C9B24: 06200AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C9B28: BF870121
	v_div_scale_f32 v7, null, v16, v16, 1.0                    // 0000002C9B2C: D6FC7C07 03CA2110
	v_div_scale_f32 v18, vcc_lo, 1.0, v16, 1.0                 // 0000002C9B34: D6FC6A12 03CA20F2
	v_rcp_f32_e32 v17, v7                                      // 0000002C9B3C: 7E225507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9B40: BF870095
	v_fma_f32 v5, -v7, v17, 1.0                                // 0000002C9B44: D6130005 23CA2307
	v_fmac_f32_e32 v17, v5, v17                                // 0000002C9B4C: 56222305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9B50: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000002C9B54: 10262312
	v_fma_f32 v5, -v7, v19, v18                                // 0000002C9B58: D6130005 244A2707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C9B60: BF870121
	v_fmac_f32_e32 v19, v5, v17                                // 0000002C9B64: 56262305
	v_mad_u64_u32 v[5:6], null, s10, 12, v[11:12]              // 0000002C9B68: D6FE7C05 042D180A
	v_fma_f32 v7, -v7, v19, v18                                // 0000002C9B70: D6130007 244A2707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002C9B78: BF870191
	v_div_fmas_f32 v17, v7, v17, v19                           // 0000002C9B7C: D6370011 044E2307
	v_mad_u64_u32 v[6:7], null, s11, 12, v[6:7]                // 0000002C9B84: D6FE7C06 0419180B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002C9B8C: BF870002
	v_div_fixup_f32 v7, v17, v16, 1.0                          // 0000002C9B90: D6270007 03CA2111
	global_store_b32 v[5:6], v7, off                           // 0000002C9B98: DC6A0000 007C0705
	s_mov_b32 s9, 0                                            // 0000002C9BA0: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9BA4: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9BA8: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002C9BAC: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2468>
	v_bfe_u32 v5, v8, 16, 1                                    // 0000002C9BB0: D6100005 02052108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9BB8: BF870091
	v_add3_u32 v5, v8, v5, 0x7fff                              // 0000002C9BBC: D6550005 03FE0B08 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9BC8: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9BD0: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C9BD4: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C9BD8: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9BE0: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C9BE4: 7E0A4B05
	v_add_f32_e32 v7, 1.0, v5                                  // 0000002C9BE8: 060E0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9BEC: BF870091
	v_div_scale_f32 v5, null, v7, v7, 1.0                      // 0000002C9BF0: D6FC7C05 03CA0F07
	v_rcp_f32_e32 v16, v5                                      // 0000002C9BF8: 7E205505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9BFC: BF870095
	v_fma_f32 v6, -v5, v16, 1.0                                // 0000002C9C00: D6130006 23CA2105
	v_fmac_f32_e32 v16, v6, v16                                // 0000002C9C08: 56202106
	v_div_scale_f32 v6, vcc_lo, 1.0, v7, 1.0                   // 0000002C9C0C: D6FC6A06 03CA0EF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9C14: BF870091
	v_mul_f32_e32 v17, v6, v16                                 // 0000002C9C18: 10222106
	v_fma_f32 v18, -v5, v17, v6                                // 0000002C9C1C: D6130012 241A2305
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9C24: BF870091
	v_fmac_f32_e32 v17, v18, v16                               // 0000002C9C28: 56222112
	v_fma_f32 v18, -v5, v17, v6                                // 0000002C9C2C: D6130012 241A2305
	v_mad_u64_u32 v[5:6], null, s10, 12, v[11:12]              // 0000002C9C34: D6FE7C05 042D180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9C3C: BF870092
	v_div_fmas_f32 v16, v18, v16, v17                          // 0000002C9C40: D6370010 04462112
	v_div_fixup_f32 v16, v16, v7, 1.0                          // 0000002C9C48: D6270010 03CA0F10
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C9C50: BF870113
	v_mad_u64_u32 v[6:7], null, s11, 12, v[6:7]                // 0000002C9C54: D6FE7C06 0419180B
	v_add_f32_e32 v7, v16, v16                                 // 0000002C9C5C: 060E2110
	global_store_b32 v[5:6], v7, off                           // 0000002C9C60: DC6A0000 007C0705
	s_mov_b32 s9, 0                                            // 0000002C9C68: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9C6C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9C70: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002C9C74: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2564>
	s_cmp_gt_i32 s3, 1                                         // 0000002C9C78: BF028103
	s_mov_b32 s1, -1                                           // 0000002C9C7C: BE8100C1
	s_cbranch_scc0 50                                          // 0000002C9C80: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x254c>
	v_bfe_u32 v5, v8, 16, 1                                    // 0000002C9C84: D6100005 02052108
	s_mov_b32 s1, 0                                            // 0000002C9C8C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9C90: BF870091
	v_add3_u32 v5, v8, v5, 0x7fff                              // 0000002C9C94: D6550005 03FE0B08 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9CA0: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9CA8: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C9CAC: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002C9CB4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9CB8: BF870095
	v_add_f32_e32 v7, 1.0, v5                                  // 0000002C9CBC: 060E0AF2
	v_div_scale_f32 v5, null, v7, v7, 1.0                      // 0000002C9CC0: D6FC7C05 03CA0F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9CC8: BF870291
	v_rcp_f32_e32 v6, v5                                       // 0000002C9CCC: 7E0C5505
	v_fma_f32 v16, -v5, v6, 1.0                                // 0000002C9CD0: D6130010 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9CD8: BF8700A1
	v_fmac_f32_e32 v6, v16, v6                                 // 0000002C9CDC: 560C0D10
	v_div_scale_f32 v16, vcc_lo, 1.0, v7, 1.0                  // 0000002C9CE0: D6FC6A10 03CA0EF2
	v_mul_f32_e32 v17, v16, v6                                 // 0000002C9CE8: 10220D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9CEC: BF870091
	v_fma_f32 v18, -v5, v17, v16                               // 0000002C9CF0: D6130012 24422305
	v_fmac_f32_e32 v17, v18, v6                                // 0000002C9CF8: 56220D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9CFC: BF870091
	v_fma_f32 v5, -v5, v17, v16                                // 0000002C9D00: D6130005 24422305
	v_div_fmas_f32 v16, v5, v6, v17                            // 0000002C9D08: D6370010 04460D05
	v_mad_u64_u32 v[5:6], null, s10, 6, v[9:10]                // 0000002C9D10: D6FE7C05 04250C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C9D18: BF870112
	v_div_fixup_f32 v16, v16, v7, 1.0                          // 0000002C9D1C: D6270010 03CA0F10
	v_mad_u64_u32 v[6:7], null, s11, 6, v[6:7]                 // 0000002C9D24: D6FE7C06 04190C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9D2C: BF870092
	v_bfe_u32 v17, v16, 16, 1                                  // 0000002C9D30: D6100011 02052110
	v_add3_u32 v7, v16, v17, 0x7fff                            // 0000002C9D38: D6550007 03FE2310 00007FFF
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002C9D44: DC960000 007C0705
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9D4C: 916A017E
	s_mov_b32 s1, 0                                            // 0000002C9D50: BE810080
	s_cbranch_vccnz 3                                          // 0000002C9D54: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2564>
	s_cmp_lg_u32 s3, 1                                         // 0000002C9D58: BF078103
	s_mov_b32 s1, -1                                           // 0000002C9D5C: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002C9D60: 980880C1
	v_bfe_u32 v5, v8, 16, 1                                    // 0000002C9D64: D6100005 02052108
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002C9D6C: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9D70: BF870001
	v_add3_u32 v5, v8, v5, 0x7fff                              // 0000002C9D74: D6550005 03FE0B08 00007FFF
	s_cbranch_vccz 7                                           // 0000002C9D80: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x25a0>
	v_mad_u64_u32 v[6:7], null, s10, 6, v[9:10]                // 0000002C9D84: D6FE7C06 04250C0A
	s_mov_b32 s1, 0                                            // 0000002C9D8C: BE810080
	v_mad_u64_u32 v[7:8], null, s11, 6, v[7:8]                 // 0000002C9D90: D6FE7C07 041D0C0B
	global_store_d16_hi_b16 v[6:7], v5, off                    // 0000002C9D98: DC960000 007C0506
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002C9DA0: 916A017E
	s_cbranch_vccnz 45                                         // 0000002C9DA4: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x265c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9DA8: BF870091
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9DAC: 360A0AFF FFFF0000
	v_mul_f32_e32 v7, s2, v5                                   // 0000002C9DB4: 100E0A02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9DB8: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v7                           // 0000002C9DBC: 100A0EFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002C9DC4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9DC8: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 0000002C9DCC: 06100AF2
	v_div_scale_f32 v5, null, v8, v8, v7                       // 0000002C9DD0: D6FC7C05 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9DD8: BF870291
	v_rcp_f32_e32 v6, v5                                       // 0000002C9DDC: 7E0C5505
	v_fma_f32 v16, -v5, v6, 1.0                                // 0000002C9DE0: D6130010 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002C9DE8: BF8700A1
	v_fmac_f32_e32 v6, v16, v6                                 // 0000002C9DEC: 560C0D10
	v_div_scale_f32 v16, vcc_lo, v7, v8, v7                    // 0000002C9DF0: D6FC6A10 041E1107
	v_mul_f32_e32 v17, v16, v6                                 // 0000002C9DF8: 10220D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9DFC: BF870091
	v_fma_f32 v18, -v5, v17, v16                               // 0000002C9E00: D6130012 24422305
	v_fmac_f32_e32 v17, v18, v6                                // 0000002C9E08: 56220D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9E0C: BF870091
	v_fma_f32 v5, -v5, v17, v16                                // 0000002C9E10: D6130005 24422305
	v_div_fmas_f32 v16, v5, v6, v17                            // 0000002C9E18: D6370010 04460D05
	v_mad_u64_u32 v[5:6], null, s10, 6, v[9:10]                // 0000002C9E20: D6FE7C05 04250C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002C9E28: BF870112
	v_div_fixup_f32 v8, v16, v8, v7                            // 0000002C9E2C: D6270008 041E1110
	v_mad_u64_u32 v[6:7], null, s11, 6, v[6:7]                 // 0000002C9E34: D6FE7C06 04190C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9E3C: BF870092
	v_bfe_u32 v16, v8, 16, 1                                   // 0000002C9E40: D6100010 02052108
	v_add3_u32 v7, v8, v16, 0x7fff                             // 0000002C9E48: D6550007 03FE2108 00007FFF
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002C9E54: DC960000 007C0705
	s_mov_b32 s9, -1                                           // 0000002C9E5C: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002C9E60: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002C9E64: BF048303
	s_mov_b32 s8, 0                                            // 0000002C9E68: BE880080
	s_cbranch_scc1 135                                         // 0000002C9E6C: BFA20087 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x288c>
	s_cmp_gt_i32 s3, 3                                         // 0000002C9E70: BF028303
	s_cbranch_scc0 82                                          // 0000002C9E74: BFA10052 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x27c0>
	s_cmp_gt_i32 s3, 4                                         // 0000002C9E78: BF028403
	s_cbranch_scc0 40                                          // 0000002C9E7C: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2720>
	s_cmp_eq_u32 s3, 5                                         // 0000002C9E80: BF068503
	s_mov_b32 s8, -1                                           // 0000002C9E84: BE8800C1
	s_cbranch_scc0 36                                          // 0000002C9E88: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x271c>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002C9E8C: F4040208 F8000010
	v_dual_mov_b32 v5, s4 :: v_dual_mov_b32 v6, s5             // 0000002C9E94: CA100004 05060005
	v_bfe_u32 v7, v1, 16, 1                                    // 0000002C9E9C: D6100007 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C9EA4: BF8701A1
	v_add3_u32 v7, v1, v7, 0x7fff                              // 0000002C9EA8: D6550007 03FE0F01 00007FFF
	s_waitcnt lgkmcnt(0)                                       // 0000002C9EB4: BF89FC07
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002C9EB8: D5010005 00020A08
	v_cndmask_b32_e64 v6, s9, v6, s0                           // 0000002C9EC0: D5010006 00020C09
	s_lshl_b64 s[8:9], s[6:7], 3                               // 0000002C9EC8: 84888306
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000002C9ECC: BF870482
	.long 0xd7006a08                                           // 0000002C9ED0: D7006A08
	v_cndmask_b32_e32 v0, v5, v8, vcc_lo                       // 0000002C9ED4: 02001105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002C9ED8: BF8701A1
	v_add_co_ci_u32_e64 v16, null, s9, v6, vcc_lo              // 0000002C9EDC: D5207C10 01AA0C09
	.long 0xd73c0005                                           // 0000002C9EE4: D73C0005
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002C9EE8: 02021A81
	.long 0xd7006a08                                           // 0000002C9EEC: D7006A08
	v_cndmask_b32_e32 v1, v8, v15, vcc_lo                      // 0000002C9EF0: 02021F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002C9EF4: BF8700B1
	v_add_co_ci_u32_e64 v16, null, v16, v0, vcc_lo             // 0000002C9EF8: D5207C10 01AA0110
	s_mov_b32 s8, 0                                            // 0000002C9F00: BE880080
	.long 0xd7006a05                                           // 0000002C9F04: D7006A05
	v_cndmask_b32_e32 v1, v8, v5, vcc_lo                       // 0000002C9F08: 02020B08
	v_add_co_ci_u32_e64 v6, null, v16, v6, vcc_lo              // 0000002C9F0C: D5207C06 01AA0D10
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002C9F14: DC960000 007C0705
	s_mov_b32 s9, 0                                            // 0000002C9F1C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9F20: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9F24: 8B6A097E
	s_cbranch_vccz 36                                          // 0000002C9F28: BFA30024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x27bc>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v1                           // 0000002C9F2C: 100A02FF BFB8AA3B
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002C9F34: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002C9F38: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002C9F3C: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002C9F40: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002C9F44: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002C9F48: D6FC7C06 03CA0B05
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002C9F50: D6FC6A10 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 0000002C9F58: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9F5C: BF870095
	v_fma_f32 v8, -v6, v7, 1.0                                 // 0000002C9F60: D6130008 23CA0F06
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002C9F68: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9F6C: BF870091
	v_mul_f32_e32 v8, v16, v7                                  // 0000002C9F70: 10100F10
	v_fma_f32 v17, -v6, v8, v16                                // 0000002C9F74: D6130011 24421106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9F7C: BF870091
	v_fmac_f32_e32 v8, v17, v7                                 // 0000002C9F80: 56100F11
	v_fma_f32 v6, -v6, v8, v16                                 // 0000002C9F84: D6130006 24421106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9F8C: BF870091
	v_div_fmas_f32 v6, v6, v7, v8                              // 0000002C9F90: D6370006 04220F06
	v_div_fixup_f32 v7, v6, v5, 1.0                            // 0000002C9F98: D6270007 03CA0B06
	.long 0xd7006a05                                           // 0000002C9FA0: D7006A05
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002C9FA4: 0200190B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002C9FA8: BF870001
	v_add_co_ci_u32_e64 v6, null, s13, v12, vcc_lo             // 0000002C9FAC: D5207C06 01AA180D
	global_store_b32 v[5:6], v7, off                           // 0000002C9FB4: DC6A0000 007C0705
	s_mov_b32 s9, 0                                            // 0000002C9FBC: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002C9FC0: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002C9FC4: 8B6A097E
	s_cbranch_vccz 47                                          // 0000002C9FC8: BFA3002F <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2888>
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002C9FCC: D6100005 02052101
	s_lshl_b64 s[12:13], s[10:11], 4                           // 0000002C9FD4: 848C840A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9FD8: BF870091
	v_add3_u32 v5, v1, v5, 0x7fff                              // 0000002C9FDC: D6550005 03FE0B01 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002C9FE8: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002C9FF0: BF870091
	v_mul_f32_e32 v5, s2, v5                                   // 0000002C9FF4: 100A0A02
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002C9FF8: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA000: BF870291
	v_exp_f32_e32 v5, v5                                       // 0000002CA004: 7E0A4B05
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002CA008: 060A0AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CA00C: BF870121
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002CA010: D6FC7C06 03CA0B05
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002CA018: D6FC6A10 03CA0AF2
	v_rcp_f32_e32 v7, v6                                       // 0000002CA020: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA024: BF870095
	v_fma_f32 v8, -v6, v7, 1.0                                 // 0000002CA028: D6130008 23CA0F06
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002CA030: 560E0F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA034: BF870091
	v_mul_f32_e32 v8, v16, v7                                  // 0000002CA038: 10100F10
	v_fma_f32 v17, -v6, v8, v16                                // 0000002CA03C: D6130011 24421106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA044: BF870091
	v_fmac_f32_e32 v8, v17, v7                                 // 0000002CA048: 56100F11
	v_fma_f32 v6, -v6, v8, v16                                 // 0000002CA04C: D6130006 24421106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA054: BF870091
	v_div_fmas_f32 v6, v6, v7, v8                              // 0000002CA058: D6370006 04220F06
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002CA060: D6270005 03CA0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA068: BF8700A1
	v_add_f32_e32 v7, v5, v5                                   // 0000002CA06C: 060E0B05
	.long 0xd7006a05                                           // 0000002CA070: D7006A05
	v_cndmask_b32_e32 v0, v11, v12, vcc_lo                     // 0000002CA074: 0200190B
	v_add_co_ci_u32_e64 v6, null, s13, v12, vcc_lo             // 0000002CA078: D5207C06 01AA180D
	global_store_b32 v[5:6], v7, off                           // 0000002CA080: DC6A0000 007C0705
	s_mov_b32 s9, 0                                            // 0000002CA088: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA08C: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA090: 8B6A097E
	s_cbranch_vccz 60                                          // 0000002CA094: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2988>
	s_cmp_gt_i32 s3, 1                                         // 0000002CA098: BF028103
	s_mov_b32 s1, -1                                           // 0000002CA09C: BE8100C1
	s_cbranch_scc0 51                                          // 0000002CA0A0: BFA10033 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2970>
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002CA0A4: D6100005 02052101
	s_lshl_b64 s[12:13], s[10:11], 3                           // 0000002CA0AC: 848C830A
	s_mov_b32 s1, 0                                            // 0000002CA0B0: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA0B4: BF870091
	v_add3_u32 v5, v1, v5, 0x7fff                              // 0000002CA0B8: D6550005 03FE0B01 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000002CA0C4: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA0CC: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 0000002CA0D0: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002CA0D8: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA0DC: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002CA0E0: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 0000002CA0E4: D6FC7C06 03CA0B05
	v_div_scale_f32 v16, vcc_lo, 1.0, v5, 1.0                  // 0000002CA0EC: D6FC6A10 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA0F4: BF870292
	v_rcp_f32_e32 v7, v6                                       // 0000002CA0F8: 7E0E5506
	v_fma_f32 v8, -v6, v7, 1.0                                 // 0000002CA0FC: D6130008 23CA0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA104: BF870091
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002CA108: 560E0F08
	v_mul_f32_e32 v8, v16, v7                                  // 0000002CA10C: 10100F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA110: BF870091
	v_fma_f32 v17, -v6, v8, v16                                // 0000002CA114: D6130011 24421106
	v_fmac_f32_e32 v8, v17, v7                                 // 0000002CA11C: 56100F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA120: BF870091
	v_fma_f32 v6, -v6, v8, v16                                 // 0000002CA124: D6130006 24421106
	v_div_fmas_f32 v6, v6, v7, v8                              // 0000002CA12C: D6370006 04220F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA134: BF870091
	v_div_fixup_f32 v5, v6, v5, 1.0                            // 0000002CA138: D6270005 03CA0B06
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002CA140: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA148: BF8700A1
	v_add3_u32 v7, v5, v6, 0x7fff                              // 0000002CA14C: D6550007 03FE0D05 00007FFF
	.long 0xd7006a05                                           // 0000002CA158: D7006A05
	v_cndmask_b32_e32 v0, v9, v12, vcc_lo                      // 0000002CA15C: 02001909
	v_add_co_ci_u32_e64 v6, null, s13, v10, vcc_lo             // 0000002CA160: D5207C06 01AA140D
	global_store_d16_hi_b16 v[5:6], v7, off                    // 0000002CA168: DC960000 007C0705
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CA170: 916A017E
	s_mov_b32 s1, 0                                            // 0000002CA174: BE810080
	s_cbranch_vccnz 3                                          // 0000002CA178: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2988>
	s_cmp_lg_u32 s3, 1                                         // 0000002CA17C: BF078103
	s_mov_b32 s1, -1                                           // 0000002CA180: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002CA184: 980880C1
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002CA188: D6100005 02052101
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002CA190: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CA194: BF870001
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000002CA198: D6550001 03FE0B01 00007FFF
	s_cbranch_vccz 9                                           // 0000002CA1A4: BFA30009 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x29cc>
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002CA1A8: 8488830A
	s_mov_b32 s1, 0                                            // 0000002CA1AC: BE810080
	.long 0xd7006a05                                           // 0000002CA1B0: D7006A05
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002CA1B4: 02001109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CA1B8: BF870001
	v_add_co_ci_u32_e64 v6, null, s9, v10, vcc_lo              // 0000002CA1BC: D5207C06 01AA1409
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA1C4: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CA1CC: 916A017E
	s_cbranch_vccnz 46                                         // 0000002CA1D0: BFA4002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2a8c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA1D4: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA1D8: 360202FF FFFF0000
	s_lshl_b64 s[8:9], s[10:11], 3                             // 0000002CA1E0: 8488830A
	v_mul_f32_e32 v1, s2, v1                                   // 0000002CA1E4: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA1E8: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v1                           // 0000002CA1EC: 100A02FF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 0000002CA1F4: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA1F8: BF870095
	v_add_f32_e32 v5, 1.0, v5                                  // 0000002CA1FC: 060A0AF2
	v_div_scale_f32 v6, null, v5, v5, v1                       // 0000002CA200: D6FC7C06 04060B05
	v_div_scale_f32 v16, vcc_lo, v1, v5, v1                    // 0000002CA208: D6FC6A10 04060B01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA210: BF870292
	v_rcp_f32_e32 v7, v6                                       // 0000002CA214: 7E0E5506
	v_fma_f32 v8, -v6, v7, 1.0                                 // 0000002CA218: D6130008 23CA0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA220: BF870091
	v_fmac_f32_e32 v7, v8, v7                                  // 0000002CA224: 560E0F08
	v_mul_f32_e32 v8, v16, v7                                  // 0000002CA228: 10100F10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA22C: BF870091
	v_fma_f32 v17, -v6, v8, v16                                // 0000002CA230: D6130011 24421106
	v_fmac_f32_e32 v8, v17, v7                                 // 0000002CA238: 56100F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA23C: BF870091
	v_fma_f32 v6, -v6, v8, v16                                 // 0000002CA240: D6130006 24421106
	v_div_fmas_f32 v6, v6, v7, v8                              // 0000002CA248: D6370006 04220F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA250: BF870091
	v_div_fixup_f32 v1, v6, v5, v1                             // 0000002CA254: D6270001 04060B06
	v_bfe_u32 v5, v1, 16, 1                                    // 0000002CA25C: D6100005 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA264: BF8700A1
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000002CA268: D6550001 03FE0B01 00007FFF
	.long 0xd7006a05                                           // 0000002CA274: D7006A05
	v_cndmask_b32_e32 v0, v9, v8, vcc_lo                       // 0000002CA278: 02001109
	v_add_co_ci_u32_e64 v6, null, s9, v10, vcc_lo              // 0000002CA27C: D5207C06 01AA1409
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA284: DC960000 007C0105
	s_mov_b32 s9, -1                                           // 0000002CA28C: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002CA290: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002CA294: BF048303
	s_mov_b32 s8, 0                                            // 0000002CA298: BE880080
	s_cbranch_scc1 133                                         // 0000002CA29C: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cb4>
	s_cmp_gt_i32 s3, 3                                         // 0000002CA2A0: BF028303
	s_cbranch_scc0 81                                          // 0000002CA2A4: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2bec>
	s_cmp_gt_i32 s3, 4                                         // 0000002CA2A8: BF028403
	s_cbranch_scc0 40                                          // 0000002CA2AC: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2b50>
	s_cmp_eq_u32 s3, 5                                         // 0000002CA2B0: BF068503
	s_mov_b32 s8, -1                                           // 0000002CA2B4: BE8800C1
	s_cbranch_scc0 36                                          // 0000002CA2B8: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2b4c>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002CA2BC: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002CA2C4: 7E020205
	v_mov_b32_e32 v5, s4                                       // 0000002CA2C8: 7E0A0204
	s_waitcnt lgkmcnt(0)                                       // 0000002CA2CC: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA2D0: BF870112
	v_cndmask_b32_e64 v6, s9, v1, s0                           // 0000002CA2D4: D5010006 00020209
	v_cndmask_b32_e64 v5, s8, v5, s0                           // 0000002CA2DC: D5010005 00020A08
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002CA2E4: D6100001 02052102
	s_mov_b32 s8, 0                                            // 0000002CA2EC: BE880080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA2F0: BF870112
	v_mad_u64_u32 v[5:6], null, s6, 10, v[5:6]                 // 0000002CA2F4: D6FE7C05 04151406
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002CA2FC: D6550001 03FE0302 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002CA308: BF870222
	v_mad_u64_u32 v[6:7], null, s7, 10, v[6:7]                 // 0000002CA30C: D6FE7C06 04191407
	.long 0xd73c0007                                           // 0000002CA314: D73C0007
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002CA318: 02021A81
	.long 0xd7006a05                                           // 0000002CA31C: D7006A05
	v_cndmask_b32_e32 v1, v5, v15, vcc_lo                      // 0000002CA320: 02021F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA324: BF870111
	v_add_co_ci_u32_e64 v6, null, v6, v0, vcc_lo               // 0000002CA328: D5207C06 01AA0106
	.long 0xd7006a05                                           // 0000002CA330: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000002CA334: 02020F05
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CA338: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000002CA33C: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA344: DC960000 007C0105
	s_mov_b32 s9, 0                                            // 0000002CA34C: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA350: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA354: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002CA358: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2be8>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v2                           // 0000002CA35C: 100204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA364: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002CA368: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA36C: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CA370: BF870121
	v_div_scale_f32 v7, null, v1, v1, 1.0                      // 0000002CA374: D6FC7C07 03CA0301
	v_div_scale_f32 v16, vcc_lo, 1.0, v1, 1.0                  // 0000002CA37C: D6FC6A10 03CA02F2
	v_rcp_f32_e32 v8, v7                                       // 0000002CA384: 7E105507
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA388: BF870095
	v_fma_f32 v5, -v7, v8, 1.0                                 // 0000002CA38C: D6130005 23CA1107
	v_fmac_f32_e32 v8, v5, v8                                  // 0000002CA394: 56101105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA398: BF870091
	v_mul_f32_e32 v17, v16, v8                                 // 0000002CA39C: 10221110
	v_fma_f32 v5, -v7, v17, v16                                // 0000002CA3A0: D6130005 24422307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CA3A8: BF870121
	v_fmac_f32_e32 v17, v5, v8                                 // 0000002CA3AC: 56221105
	v_mad_u64_u32 v[5:6], null, s10, 20, v[11:12]              // 0000002CA3B0: D6FE7C05 042D280A
	v_fma_f32 v7, -v7, v17, v16                                // 0000002CA3B8: D6130007 24422307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CA3C0: BF870191
	v_div_fmas_f32 v8, v7, v8, v17                             // 0000002CA3C4: D6370008 04461107
	v_mad_u64_u32 v[6:7], null, s11, 20, v[6:7]                // 0000002CA3CC: D6FE7C06 0419280B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CA3D4: BF870002
	v_div_fixup_f32 v1, v8, v1, 1.0                            // 0000002CA3D8: D6270001 03CA0308
	global_store_b32 v[5:6], v1, off                           // 0000002CA3E0: DC6A0000 007C0105
	s_mov_b32 s9, 0                                            // 0000002CA3E8: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA3EC: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA3F0: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002CA3F4: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2cb0>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002CA3F8: D6100001 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA400: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002CA404: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA410: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA418: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002CA41C: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002CA420: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA428: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002CA42C: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA430: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA434: BF870091
	v_div_scale_f32 v5, null, v1, v1, 1.0                      // 0000002CA438: D6FC7C05 03CA0301
	v_rcp_f32_e32 v7, v5                                       // 0000002CA440: 7E0E5505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA444: BF870095
	v_fma_f32 v6, -v5, v7, 1.0                                 // 0000002CA448: D6130006 23CA0F05
	v_fmac_f32_e32 v7, v6, v7                                  // 0000002CA450: 560E0F06
	v_div_scale_f32 v6, vcc_lo, 1.0, v1, 1.0                   // 0000002CA454: D6FC6A06 03CA02F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA45C: BF870091
	v_mul_f32_e32 v8, v6, v7                                   // 0000002CA460: 10100F06
	v_fma_f32 v16, -v5, v8, v6                                 // 0000002CA464: D6130010 241A1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA46C: BF870091
	v_fmac_f32_e32 v8, v16, v7                                 // 0000002CA470: 56100F10
	v_fma_f32 v16, -v5, v8, v6                                 // 0000002CA474: D6130010 241A1105
	v_mad_u64_u32 v[5:6], null, s10, 20, v[11:12]              // 0000002CA47C: D6FE7C05 042D280A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA484: BF870092
	v_div_fmas_f32 v7, v16, v7, v8                             // 0000002CA488: D6370007 04220F10
	v_div_fixup_f32 v1, v7, v1, 1.0                            // 0000002CA490: D6270001 03CA0307
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA498: BF870113
	v_mad_u64_u32 v[6:7], null, s11, 20, v[6:7]                // 0000002CA49C: D6FE7C06 0419280B
	v_add_f32_e32 v1, v1, v1                                   // 0000002CA4A4: 06020301
	global_store_b32 v[5:6], v1, off                           // 0000002CA4A8: DC6A0000 007C0105
	s_mov_b32 s9, 0                                            // 0000002CA4B0: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA4B4: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA4B8: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002CA4BC: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2dac>
	s_cmp_gt_i32 s3, 1                                         // 0000002CA4C0: BF028103
	s_mov_b32 s1, -1                                           // 0000002CA4C4: BE8100C1
	s_cbranch_scc0 50                                          // 0000002CA4C8: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2d94>
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002CA4CC: D6100001 02052102
	s_mov_b32 s1, 0                                            // 0000002CA4D4: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA4D8: BF870091
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002CA4DC: D6550001 03FE0302 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA4E8: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA4F0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002CA4F4: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002CA4FC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA500: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA504: 060202F2
	v_div_scale_f32 v5, null, v1, v1, 1.0                      // 0000002CA508: D6FC7C05 03CA0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA510: BF870291
	v_rcp_f32_e32 v6, v5                                       // 0000002CA514: 7E0C5505
	v_fma_f32 v7, -v5, v6, 1.0                                 // 0000002CA518: D6130007 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA520: BF8700A1
	v_fmac_f32_e32 v6, v7, v6                                  // 0000002CA524: 560C0D07
	v_div_scale_f32 v7, vcc_lo, 1.0, v1, 1.0                   // 0000002CA528: D6FC6A07 03CA02F2
	v_mul_f32_e32 v8, v7, v6                                   // 0000002CA530: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA534: BF870091
	v_fma_f32 v16, -v5, v8, v7                                 // 0000002CA538: D6130010 241E1105
	v_fmac_f32_e32 v8, v16, v6                                 // 0000002CA540: 56100D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA544: BF870091
	v_fma_f32 v5, -v5, v8, v7                                  // 0000002CA548: D6130005 241E1105
	v_div_fmas_f32 v7, v5, v6, v8                              // 0000002CA550: D6370007 04220D05
	v_mad_u64_u32 v[5:6], null, s10, 10, v[9:10]               // 0000002CA558: D6FE7C05 0425140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA560: BF870112
	v_div_fixup_f32 v1, v7, v1, 1.0                            // 0000002CA564: D6270001 03CA0307
	v_mad_u64_u32 v[6:7], null, s11, 10, v[6:7]                // 0000002CA56C: D6FE7C06 0419140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA574: BF870092
	v_bfe_u32 v8, v1, 16, 1                                    // 0000002CA578: D6100008 02052101
	v_add3_u32 v1, v1, v8, 0x7fff                              // 0000002CA580: D6550001 03FE1101 00007FFF
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA58C: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CA594: 916A017E
	s_mov_b32 s1, 0                                            // 0000002CA598: BE810080
	s_cbranch_vccnz 3                                          // 0000002CA59C: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2dac>
	s_cmp_lg_u32 s3, 1                                         // 0000002CA5A0: BF078103
	s_mov_b32 s1, -1                                           // 0000002CA5A4: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002CA5A8: 980880C1
	v_bfe_u32 v1, v2, 16, 1                                    // 0000002CA5AC: D6100001 02052102
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002CA5B4: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CA5B8: BF870001
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000002CA5BC: D6550001 03FE0302 00007FFF
	s_cbranch_vccz 7                                           // 0000002CA5C8: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2de8>
	v_mad_u64_u32 v[5:6], null, s10, 10, v[9:10]               // 0000002CA5CC: D6FE7C05 0425140A
	s_mov_b32 s1, 0                                            // 0000002CA5D4: BE810080
	v_mad_u64_u32 v[6:7], null, s11, 10, v[6:7]                // 0000002CA5D8: D6FE7C06 0419140B
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA5E0: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CA5E8: 916A017E
	s_cbranch_vccnz 45                                         // 0000002CA5EC: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2ea4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA5F0: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA5F4: 360202FF FFFF0000
	v_mul_f32_e32 v1, s2, v1                                   // 0000002CA5FC: 10020202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA600: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000002CA604: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000002CA60C: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA610: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000002CA614: 060404F2
	v_div_scale_f32 v5, null, v2, v2, v1                       // 0000002CA618: D6FC7C05 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA620: BF870291
	v_rcp_f32_e32 v6, v5                                       // 0000002CA624: 7E0C5505
	v_fma_f32 v7, -v5, v6, 1.0                                 // 0000002CA628: D6130007 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA630: BF8700A1
	v_fmac_f32_e32 v6, v7, v6                                  // 0000002CA634: 560C0D07
	v_div_scale_f32 v7, vcc_lo, v1, v2, v1                     // 0000002CA638: D6FC6A07 04060501
	v_mul_f32_e32 v8, v7, v6                                   // 0000002CA640: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA644: BF870091
	v_fma_f32 v16, -v5, v8, v7                                 // 0000002CA648: D6130010 241E1105
	v_fmac_f32_e32 v8, v16, v6                                 // 0000002CA650: 56100D10
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA654: BF870091
	v_fma_f32 v5, -v5, v8, v7                                  // 0000002CA658: D6130005 241E1105
	v_div_fmas_f32 v7, v5, v6, v8                              // 0000002CA660: D6370007 04220D05
	v_mad_u64_u32 v[5:6], null, s10, 10, v[9:10]               // 0000002CA668: D6FE7C05 0425140A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA670: BF870112
	v_div_fixup_f32 v1, v7, v2, v1                             // 0000002CA674: D6270001 04060507
	v_mad_u64_u32 v[6:7], null, s11, 10, v[6:7]                // 0000002CA67C: D6FE7C06 0419140B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA684: BF870092
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002CA688: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000002CA690: D6550001 03FE0501 00007FFF
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA69C: DC960000 007C0105
	s_mov_b32 s9, -1                                           // 0000002CA6A4: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002CA6A8: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002CA6AC: BF048303
	s_mov_b32 s8, 0                                            // 0000002CA6B0: BE880080
	s_cbranch_scc1 133                                         // 0000002CA6B4: BFA20085 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x30cc>
	s_cmp_gt_i32 s3, 3                                         // 0000002CA6B8: BF028303
	s_cbranch_scc0 81                                          // 0000002CA6BC: BFA10051 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3004>
	s_cmp_gt_i32 s3, 4                                         // 0000002CA6C0: BF028403
	s_cbranch_scc0 40                                          // 0000002CA6C4: BFA10028 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2f68>
	s_cmp_eq_u32 s3, 5                                         // 0000002CA6C8: BF068503
	s_mov_b32 s8, -1                                           // 0000002CA6CC: BE8800C1
	s_cbranch_scc0 36                                          // 0000002CA6D0: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x2f64>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002CA6D4: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002CA6DC: 7E020205
	v_mov_b32_e32 v5, s4                                       // 0000002CA6E0: 7E0A0204
	s_waitcnt lgkmcnt(0)                                       // 0000002CA6E4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA6E8: BF870112
	v_cndmask_b32_e64 v2, s9, v1, s0                           // 0000002CA6EC: D5010002 00020209
	v_cndmask_b32_e64 v1, s8, v5, s0                           // 0000002CA6F4: D5010001 00020A08
	s_mov_b32 s8, 0                                            // 0000002CA6FC: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA700: BF870091
	v_mad_u64_u32 v[1:2], null, s6, 12, v[1:2]                 // 0000002CA704: D6FE7C01 04051806
	v_mad_u64_u32 v[5:6], null, s7, 12, v[2:3]                 // 0000002CA70C: D6FE7C05 04091807
	.long 0xd73c0006                                           // 0000002CA714: D73C0006
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002CA718: 02021A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002CA71C: BF870223
	.long 0xd7006a01                                           // 0000002CA720: D7006A01
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 0000002CA724: 02021F01
	v_bfe_u32 v2, v3, 16, 1                                    // 0000002CA728: D6100002 02052103
	v_add_co_ci_u32_e64 v5, null, v5, v0, vcc_lo               // 0000002CA730: D5207C05 01AA0105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CA738: BF870193
	.long 0xd7006a01                                           // 0000002CA73C: D7006A01
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000002CA740: 02020D01
	v_add3_u32 v8, v3, v2, 0x7fff                              // 0000002CA744: D6550008 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002CA750: BF870003
	v_add_co_ci_u32_e64 v2, null, v5, v7, vcc_lo               // 0000002CA754: D5207C02 01AA0F05
	global_store_d16_hi_b16 v[1:2], v8, off                    // 0000002CA75C: DC960000 007C0801
	s_mov_b32 s9, 0                                            // 0000002CA764: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA768: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA76C: 8B6A097E
	s_cbranch_vccz 35                                          // 0000002CA770: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3000>
	v_mul_f32_e32 v1, 0xbfb8aa3b, v3                           // 0000002CA774: 100206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA77C: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002CA780: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA784: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CA788: BF870121
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002CA78C: D6FC7C02 03CA0301
	v_div_scale_f32 v8, vcc_lo, 1.0, v1, 1.0                   // 0000002CA794: D6FC6A08 03CA02F2
	v_rcp_f32_e32 v7, v2                                       // 0000002CA79C: 7E0E5502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA7A0: BF870095
	v_fma_f32 v5, -v2, v7, 1.0                                 // 0000002CA7A4: D6130005 23CA0F02
	v_fmac_f32_e32 v7, v5, v7                                  // 0000002CA7AC: 560E0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA7B0: BF870091
	v_mul_f32_e32 v16, v8, v7                                  // 0000002CA7B4: 10200F08
	v_fma_f32 v5, -v2, v16, v8                                 // 0000002CA7B8: D6130005 24222102
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CA7C0: BF870121
	v_fmac_f32_e32 v16, v5, v7                                 // 0000002CA7C4: 56200F05
	v_mad_u64_u32 v[5:6], null, s10, 24, v[11:12]              // 0000002CA7C8: D6FE7C05 042D300A
	v_fma_f32 v2, -v2, v16, v8                                 // 0000002CA7D0: D6130002 24222102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CA7D8: BF870191
	v_div_fmas_f32 v2, v2, v7, v16                             // 0000002CA7DC: D6370002 04420F02
	v_mad_u64_u32 v[6:7], null, s11, 24, v[6:7]                // 0000002CA7E4: D6FE7C06 0419300B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CA7EC: BF870002
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002CA7F0: D6270001 03CA0302
	global_store_b32 v[5:6], v1, off                           // 0000002CA7F8: DC6A0000 007C0105
	s_mov_b32 s9, 0                                            // 0000002CA800: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA804: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA808: 8B6A097E
	s_cbranch_vccz 46                                          // 0000002CA80C: BFA3002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x30c8>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002CA810: D6100001 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA818: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002CA81C: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA828: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA830: BF870091
	v_mul_f32_e32 v1, s2, v1                                   // 0000002CA834: 10020202
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002CA838: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA840: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002CA844: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA848: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA84C: BF870091
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002CA850: D6FC7C02 03CA0301
	v_rcp_f32_e32 v7, v2                                       // 0000002CA858: 7E0E5502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA85C: BF870095
	v_fma_f32 v5, -v2, v7, 1.0                                 // 0000002CA860: D6130005 23CA0F02
	v_fmac_f32_e32 v7, v5, v7                                  // 0000002CA868: 560E0F05
	v_div_scale_f32 v5, vcc_lo, 1.0, v1, 1.0                   // 0000002CA86C: D6FC6A05 03CA02F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA874: BF870091
	v_mul_f32_e32 v8, v5, v7                                   // 0000002CA878: 10100F05
	v_fma_f32 v6, -v2, v8, v5                                  // 0000002CA87C: D6130006 24161102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA884: BF870091
	v_fmac_f32_e32 v8, v6, v7                                  // 0000002CA888: 56100F06
	v_fma_f32 v2, -v2, v8, v5                                  // 0000002CA88C: D6130002 24161102
	v_mad_u64_u32 v[5:6], null, s10, 24, v[11:12]              // 0000002CA894: D6FE7C05 042D300A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA89C: BF870112
	v_div_fmas_f32 v2, v2, v7, v8                              // 0000002CA8A0: D6370002 04220F02
	v_mad_u64_u32 v[6:7], null, s11, 24, v[6:7]                // 0000002CA8A8: D6FE7C06 0419300B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA8B0: BF870092
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002CA8B4: D6270001 03CA0302
	v_add_f32_e32 v1, v1, v1                                   // 0000002CA8BC: 06020301
	global_store_b32 v[5:6], v1, off                           // 0000002CA8C0: DC6A0000 007C0105
	s_mov_b32 s9, 0                                            // 0000002CA8C8: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CA8CC: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CA8D0: 8B6A097E
	s_cbranch_vccz 59                                          // 0000002CA8D4: BFA3003B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x31c4>
	s_cmp_gt_i32 s3, 1                                         // 0000002CA8D8: BF028103
	s_mov_b32 s1, -1                                           // 0000002CA8DC: BE8100C1
	s_cbranch_scc0 50                                          // 0000002CA8E0: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x31ac>
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002CA8E4: D6100001 02052103
	s_mov_b32 s1, 0                                            // 0000002CA8EC: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA8F0: BF870091
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002CA8F4: D6550001 03FE0303 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CA900: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA908: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002CA90C: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002CA914: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA918: BF870095
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002CA91C: 060202F2
	v_div_scale_f32 v2, null, v1, v1, 1.0                      // 0000002CA920: D6FC7C02 03CA0301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CA928: BF870291
	v_rcp_f32_e32 v5, v2                                       // 0000002CA92C: 7E0A5502
	v_fma_f32 v6, -v2, v5, 1.0                                 // 0000002CA930: D6130006 23CA0B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CA938: BF8700A1
	v_fmac_f32_e32 v5, v6, v5                                  // 0000002CA93C: 560A0B06
	v_div_scale_f32 v6, vcc_lo, 1.0, v1, 1.0                   // 0000002CA940: D6FC6A06 03CA02F2
	v_mul_f32_e32 v7, v6, v5                                   // 0000002CA948: 100E0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA94C: BF870091
	v_fma_f32 v8, -v2, v7, v6                                  // 0000002CA950: D6130008 241A0F02
	v_fmac_f32_e32 v7, v8, v5                                  // 0000002CA958: 560E0B08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA95C: BF870091
	v_fma_f32 v2, -v2, v7, v6                                  // 0000002CA960: D6130002 241A0F02
	v_div_fmas_f32 v2, v2, v5, v7                              // 0000002CA968: D6370002 041E0B02
	v_mad_u64_u32 v[5:6], null, s10, 12, v[9:10]               // 0000002CA970: D6FE7C05 0425180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CA978: BF870112
	v_div_fixup_f32 v1, v2, v1, 1.0                            // 0000002CA97C: D6270001 03CA0302
	v_mad_u64_u32 v[6:7], null, s11, 12, v[6:7]                // 0000002CA984: D6FE7C06 0419180B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CA98C: BF870092
	v_bfe_u32 v2, v1, 16, 1                                    // 0000002CA990: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000002CA998: D6550001 03FE0501 00007FFF
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA9A4: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CA9AC: 916A017E
	s_mov_b32 s1, 0                                            // 0000002CA9B0: BE810080
	s_cbranch_vccnz 3                                          // 0000002CA9B4: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x31c4>
	s_cmp_lg_u32 s3, 1                                         // 0000002CA9B8: BF078103
	s_mov_b32 s1, -1                                           // 0000002CA9BC: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002CA9C0: 980880C1
	v_bfe_u32 v1, v3, 16, 1                                    // 0000002CA9C4: D6100001 02052103
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002CA9CC: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CA9D0: BF870001
	v_add3_u32 v1, v3, v1, 0x7fff                              // 0000002CA9D4: D6550001 03FE0303 00007FFF
	s_cbranch_vccz 7                                           // 0000002CA9E0: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3200>
	v_mad_u64_u32 v[5:6], null, s10, 12, v[9:10]               // 0000002CA9E4: D6FE7C05 0425180A
	s_mov_b32 s1, 0                                            // 0000002CA9EC: BE810080
	v_mad_u64_u32 v[6:7], null, s11, 12, v[6:7]                // 0000002CA9F0: D6FE7C06 0419180B
	global_store_d16_hi_b16 v[5:6], v1, off                    // 0000002CA9F8: DC960000 007C0105
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CAA00: 916A017E
	s_cbranch_vccnz 45                                         // 0000002CAA04: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x32bc>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA08: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002CAA0C: 360202FF FFFF0000
	v_mul_f32_e32 v3, s2, v1                                   // 0000002CAA14: 10060202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA18: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v3                           // 0000002CAA1C: 100206FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000002CAA24: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA28: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000002CAA2C: 060A02F2
	v_div_scale_f32 v1, null, v5, v5, v3                       // 0000002CAA30: D6FC7C01 040E0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CAA38: BF870291
	v_rcp_f32_e32 v2, v1                                       // 0000002CAA3C: 7E045501
	v_fma_f32 v6, -v1, v2, 1.0                                 // 0000002CAA40: D6130006 23CA0501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CAA48: BF8700A1
	v_fmac_f32_e32 v2, v6, v2                                  // 0000002CAA4C: 56040506
	v_div_scale_f32 v6, vcc_lo, v3, v5, v3                     // 0000002CAA50: D6FC6A06 040E0B03
	v_mul_f32_e32 v7, v6, v2                                   // 0000002CAA58: 100E0506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA5C: BF870091
	v_fma_f32 v8, -v1, v7, v6                                  // 0000002CAA60: D6130008 241A0F01
	v_fmac_f32_e32 v7, v8, v2                                  // 0000002CAA68: 560E0508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA6C: BF870091
	v_fma_f32 v1, -v1, v7, v6                                  // 0000002CAA70: D6130001 241A0F01
	v_div_fmas_f32 v6, v1, v2, v7                              // 0000002CAA78: D6370006 041E0501
	v_mad_u64_u32 v[1:2], null, s10, 12, v[9:10]               // 0000002CAA80: D6FE7C01 0425180A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CAA88: BF870112
	v_div_fixup_f32 v5, v6, v5, v3                             // 0000002CAA8C: D6270005 040E0B06
	v_mad_u64_u32 v[2:3], null, s11, 12, v[2:3]                // 0000002CAA94: D6FE7C02 0409180B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAA9C: BF870092
	v_bfe_u32 v6, v5, 16, 1                                    // 0000002CAAA0: D6100006 02052105
	v_add3_u32 v3, v5, v6, 0x7fff                              // 0000002CAAA8: D6550003 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off                    // 0000002CAAB4: DC960000 007C0301
	s_mov_b32 s9, -1                                           // 0000002CAABC: BE8900C1
	s_mov_b32 s1, 0                                            // 0000002CAAC0: BE810080
	s_cmp_lt_i32 s3, 3                                         // 0000002CAAC4: BF048303
	s_mov_b32 s8, 0                                            // 0000002CAAC8: BE880080
	s_cbranch_scc1 134                                         // 0000002CAACC: BFA20086 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x34e8>
	s_cmp_gt_i32 s3, 3                                         // 0000002CAAD0: BF028303
	s_cbranch_scc0 43                                          // 0000002CAAD4: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3384>
	s_cmp_gt_i32 s3, 4                                         // 0000002CAAD8: BF028403
	s_cbranch_scc0 43                                          // 0000002CAADC: BFA1002B <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x338c>
	s_cmp_eq_u32 s3, 5                                         // 0000002CAAE0: BF068503
	s_mov_b32 s8, -1                                           // 0000002CAAE4: BE8800C1
	s_cbranch_scc0 36                                          // 0000002CAAE8: BFA10024 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x337c>
	s_load_b64 s[8:9], s[16:17], 0x10                          // 0000002CAAEC: F4040208 F8000010
	v_mov_b32_e32 v1, s5                                       // 0000002CAAF4: 7E020205
	v_mov_b32_e32 v3, s4                                       // 0000002CAAF8: 7E060204
	.long 0xd73c0005                                           // 0000002CAAFC: D73C0005
	v_cndmask_b32_e32 v1, 1, v13, vcc_lo                       // 0000002CAB00: 02021A81
	s_waitcnt lgkmcnt(0)                                       // 0000002CAB04: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CAB08: BF870193
	v_cndmask_b32_e64 v2, s9, v1, s0                           // 0000002CAB0C: D5010002 00020209
	v_cndmask_b32_e64 v1, s8, v3, s0                           // 0000002CAB14: D5010001 00020608
	s_mov_b32 s8, 0                                            // 0000002CAB1C: BE880080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAB20: BF870091
	v_mad_u64_u32 v[1:2], null, s6, 14, v[1:2]                 // 0000002CAB24: D6FE7C01 04051C06
	v_mad_u64_u32 v[2:3], null, s7, 14, v[2:3]                 // 0000002CAB2C: D6FE7C02 04091C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CAB34: BF8700A2
	.long 0xd7006a01                                           // 0000002CAB38: D7006A01
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 0000002CAB3C: 02021F01
	v_bfe_u32 v3, v4, 16, 1                                    // 0000002CAB40: D6100003 02052104
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000002CAB48: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002CAB54: BF870214
	v_add_co_ci_u32_e64 v2, null, v2, v0, vcc_lo               // 0000002CAB58: D5207C02 01AA0102
	.long 0xd7006a00                                           // 0000002CAB60: D7006A00
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 0000002CAB64: 02020B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CAB68: BF870001
	v_add_co_ci_u32_e64 v1, null, v2, v6, vcc_lo               // 0000002CAB6C: D5207C01 01AA0D02
	global_store_d16_hi_b16 v[0:1], v3, off                    // 0000002CAB74: DC960000 007C0300
	s_mov_b32 s0, 0                                            // 0000002CAB7C: BE800080
	s_branch 3                                                 // 0000002CAB80: BFA00003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3390>
	s_cbranch_execnz 41                                        // 0000002CAB84: BFA60029 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x342c>
	s_branch 86                                                // 0000002CAB88: BFA00056 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x34e4>
	s_mov_b32 s0, -1                                           // 0000002CAB8C: BE8000C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CAB90: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000002CAB94: 8B6A007E
	s_cbranch_vccz 35                                          // 0000002CAB98: BFA30023 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3428>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 0000002CAB9C: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CABA4: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002CABA8: 7E004B00
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002CABAC: 060600F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CABB0: BF870121
	v_div_scale_f32 v2, null, v3, v3, 1.0                      // 0000002CABB4: D6FC7C02 03CA0703
	v_div_scale_f32 v6, vcc_lo, 1.0, v3, 1.0                   // 0000002CABBC: D6FC6A06 03CA06F2
	v_rcp_f32_e32 v5, v2                                       // 0000002CABC4: 7E0A5502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CABC8: BF870095
	v_fma_f32 v0, -v2, v5, 1.0                                 // 0000002CABCC: D6130000 23CA0B02
	v_fmac_f32_e32 v5, v0, v5                                  // 0000002CABD4: 560A0B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CABD8: BF870091
	v_mul_f32_e32 v7, v6, v5                                   // 0000002CABDC: 100E0B06
	v_fma_f32 v0, -v2, v7, v6                                  // 0000002CABE0: D6130000 241A0F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CABE8: BF870121
	v_fmac_f32_e32 v7, v0, v5                                  // 0000002CABEC: 560E0B00
	v_mad_u64_u32 v[0:1], null, s10, 28, v[11:12]              // 0000002CABF0: D6FE7C00 042D380A
	v_fma_f32 v2, -v2, v7, v6                                  // 0000002CABF8: D6130002 241A0F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CAC00: BF870191
	v_div_fmas_f32 v5, v2, v5, v7                              // 0000002CAC04: D6370005 041E0B02
	v_mad_u64_u32 v[1:2], null, s11, 28, v[1:2]                // 0000002CAC0C: D6FE7C01 0405380B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CAC14: BF870002
	v_div_fixup_f32 v2, v5, v3, 1.0                            // 0000002CAC18: D6270002 03CA0705
	global_store_b32 v[0:1], v2, off                           // 0000002CAC20: DC6A0000 007C0200
	s_branch 46                                                // 0000002CAC28: BFA0002E <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x34e4>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002CAC2C: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAC34: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002CAC38: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002CAC44: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAC4C: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000002CAC50: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002CAC54: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CAC5C: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000002CAC60: 7E004B00
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002CAC64: 060400F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAC68: BF870091
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002CAC6C: D6FC7C00 03CA0502
	v_rcp_f32_e32 v3, v0                                       // 0000002CAC74: 7E065500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAC78: BF870095
	v_fma_f32 v1, -v0, v3, 1.0                                 // 0000002CAC7C: D6130001 23CA0700
	v_fmac_f32_e32 v3, v1, v3                                  // 0000002CAC84: 56060701
	v_div_scale_f32 v1, vcc_lo, 1.0, v2, 1.0                   // 0000002CAC88: D6FC6A01 03CA04F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAC90: BF870091
	v_mul_f32_e32 v5, v1, v3                                   // 0000002CAC94: 100A0701
	v_fma_f32 v6, -v0, v5, v1                                  // 0000002CAC98: D6130006 24060B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CACA0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000002CACA4: 560A0706
	v_fma_f32 v6, -v0, v5, v1                                  // 0000002CACA8: D6130006 24060B00
	v_mad_u64_u32 v[0:1], null, s10, 28, v[11:12]              // 0000002CACB0: D6FE7C00 042D380A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CACB8: BF870092
	v_div_fmas_f32 v3, v6, v3, v5                              // 0000002CACBC: D6370003 04160706
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002CACC4: D6270003 03CA0503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CACCC: BF870113
	v_mad_u64_u32 v[1:2], null, s11, 28, v[1:2]                // 0000002CACD0: D6FE7C01 0405380B
	v_add_f32_e32 v2, v3, v3                                   // 0000002CACD8: 06040703
	global_store_b32 v[0:1], v2, off                           // 0000002CACDC: DC6A0000 007C0200
	s_mov_b32 s9, 0                                            // 0000002CACE4: BE890080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002CACE8: BF870009
	s_and_b32 vcc_lo, exec_lo, s9                              // 0000002CACEC: 8B6A097E
	s_cbranch_vccz 58                                          // 0000002CACF0: BFA3003A <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x35dc>
	s_cmp_gt_i32 s3, 1                                         // 0000002CACF4: BF028103
	s_mov_b32 s0, -1                                           // 0000002CACF8: BE8000C1
	s_cbranch_scc0 50                                          // 0000002CACFC: BFA10032 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x35c8>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002CAD00: D6100000 02052104
	s_mov_b32 s0, 0                                            // 0000002CAD08: BE800080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAD0C: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002CAD10: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002CAD1C: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAD24: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000002CAD28: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002CAD30: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAD34: BF870095
	v_add_f32_e32 v2, 1.0, v0                                  // 0000002CAD38: 060400F2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000002CAD3C: D6FC7C00 03CA0502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CAD44: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002CAD48: 7E025500
	v_fma_f32 v3, -v0, v1, 1.0                                 // 0000002CAD4C: D6130003 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CAD54: BF8700A1
	v_fmac_f32_e32 v1, v3, v1                                  // 0000002CAD58: 56020303
	v_div_scale_f32 v3, vcc_lo, 1.0, v2, 1.0                   // 0000002CAD5C: D6FC6A03 03CA04F2
	v_mul_f32_e32 v5, v3, v1                                   // 0000002CAD64: 100A0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAD68: BF870091
	v_fma_f32 v6, -v0, v5, v3                                  // 0000002CAD6C: D6130006 240E0B00
	v_fmac_f32_e32 v5, v6, v1                                  // 0000002CAD74: 560A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAD78: BF870091
	v_fma_f32 v0, -v0, v5, v3                                  // 0000002CAD7C: D6130000 240E0B00
	v_div_fmas_f32 v3, v0, v1, v5                              // 0000002CAD84: D6370003 04160300
	v_mad_u64_u32 v[0:1], null, s10, 14, v[9:10]               // 0000002CAD8C: D6FE7C00 04251C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CAD94: BF870112
	v_div_fixup_f32 v3, v3, v2, 1.0                            // 0000002CAD98: D6270003 03CA0503
	v_mad_u64_u32 v[1:2], null, s11, 14, v[1:2]                // 0000002CADA0: D6FE7C01 04051C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CADA8: BF870092
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002CADAC: D6100005 02052103
	v_add3_u32 v2, v3, v5, 0x7fff                              // 0000002CADB4: D6550002 03FE0B03 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002CADC0: DC960000 007C0200
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002CADC8: 916A007E
	s_cbranch_vccnz 3                                          // 0000002CADCC: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x35dc>
	s_cmp_lg_u32 s3, 1                                         // 0000002CADD0: BF078103
	s_mov_b32 s1, -1                                           // 0000002CADD4: BE8100C1
	s_cselect_b32 s8, -1, 0                                    // 0000002CADD8: 980880C1
	v_bfe_u32 v0, v4, 16, 1                                    // 0000002CADDC: D6100000 02052104
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000002CADE4: 8B6A087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CADE8: BF870001
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000002CADEC: D6550000 03FE0104 00007FFF
	s_cbranch_vccz 7                                           // 0000002CADF8: BFA30007 <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x3618>
	v_mad_u64_u32 v[1:2], null, s10, 14, v[9:10]               // 0000002CADFC: D6FE7C01 04251C0A
	s_mov_b32 s1, 0                                            // 0000002CAE04: BE810080
	v_mad_u64_u32 v[2:3], null, s11, 14, v[2:3]                // 0000002CAE08: D6FE7C02 04091C0B
	global_store_d16_hi_b16 v[1:2], v0, off                    // 0000002CAE10: DC960000 007C0001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000002CAE18: 916A017E
	s_cbranch_vccnz 45                                         // 0000002CAE1C: BFA4002D <_ZN7halogen12_GLOBAL__N_110k_lq4w_grpILi8ELi16ELi1ELi0EEEvNS0_5LqGrpEPKtl+0x36d4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAE20: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000002CAE24: 360000FF FFFF0000
	v_mul_f32_e32 v2, s2, v0                                   // 0000002CAE2C: 10040002
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAE30: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000002CAE34: 100004FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000002CAE3C: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAE40: BF870095
	v_add_f32_e32 v3, 1.0, v0                                  // 0000002CAE44: 060600F2
	v_div_scale_f32 v0, null, v3, v3, v2                       // 0000002CAE48: D6FC7C00 040A0703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002CAE50: BF870291
	v_rcp_f32_e32 v1, v0                                       // 0000002CAE54: 7E025500
	v_fma_f32 v4, -v0, v1, 1.0                                 // 0000002CAE58: D6130004 23CA0300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CAE60: BF8700A1
	v_fmac_f32_e32 v1, v4, v1                                  // 0000002CAE64: 56020304
	v_div_scale_f32 v4, vcc_lo, v2, v3, v2                     // 0000002CAE68: D6FC6A04 040A0702
	v_mul_f32_e32 v5, v4, v1                                   // 0000002CAE70: 100A0304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAE74: BF870091
	v_fma_f32 v6, -v0, v5, v4                                  // 0000002CAE78: D6130006 24120B00
	v_fmac_f32_e32 v5, v6, v1                                  // 0000002CAE80: 560A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAE84: BF870091
	v_fma_f32 v0, -v0, v5, v4                                  // 0000002CAE88: D6130000 24120B00
	v_div_fmas_f32 v4, v0, v1, v5                              // 0000002CAE90: D6370004 04160300
	v_mad_u64_u32 v[0:1], null, s10, 14, v[9:10]               // 0000002CAE98: D6FE7C00 04251C0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CAEA0: BF870112
	v_div_fixup_f32 v3, v4, v3, v2                             // 0000002CAEA4: D6270003 040A0704
	v_mad_u64_u32 v[1:2], null, s11, 14, v[1:2]                // 0000002CAEAC: D6FE7C01 04051C0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CAEB4: BF870092
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002CAEB8: D6100004 02052103
	v_add3_u32 v2, v3, v4, 0x7fff                              // 0000002CAEC0: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002CAECC: DC960000 007C0200
	s_nop 0                                                    // 0000002CAED4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002CAED8: BFB60003
	s_endpgm                                                   // 0000002CAEDC: BFB00000
		...

