00000000008cbc00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008CBC00: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 0000008CBC08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008CBC0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008CBC10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 0000008CBC14: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008CBC18: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 0000008CBC1C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000008CBC20: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 0000008CBC28: 382E0202
	.long 0x7f0c3880                                           // 0000008CBC2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 0000008CBC30: BF89FC07
	s_clause 0x1                                               // 0000008CBC34: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 0000008CBC38: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 0000008CBC40: DC520000 03080003
	.long 0xd4540002                                           // 0000008CBC48: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 0000008CBC4C: 02022E10
	s_add_u32 s24, s8, s20                                     // 0000008CBC50: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008CBC54: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008CBC58: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008CBC5C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008CBC60: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 0000008CBC64: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 0000008CBC6C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 0000008CBC74: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008CBC78: 8205800F
	.long 0xd72c0008                                           // 0000008CBC7C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 0000008CBC80: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 0000008CBC84: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008CBC8C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000008CBC90: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 0000008CBC94: B3860081
	.long 0xd4440004                                           // 0000008CBC98: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008CBC9C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 0000008CBCA0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000008CBCA4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 0000008CBCA8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008CBCAC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008CBCB0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 0000008CBCB4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 0000008CBCBC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 0000008CBCC0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CBCC8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 0000008CBCCC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 0000008CBCD8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000008CBCDC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000008CBCE0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008CBCEC: BF870193
	.long 0x7e0c3984                                           // 0000008CBCF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 0000008CBCF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CBCFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 0000008CBD00: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 0000008CBD0C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 0000008CBD10: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 0000008CBD14: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 0000008CBD1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 0000008CBD24: BF89FC07
	s_barrier                                                  // 0000008CBD28: BFBD0000
	buffer_gl0_inv                                             // 0000008CBD2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000008CBD34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 0000008CBD38: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 0000008CBD40: BE852004
	s_cbranch_execz 10                                         // 0000008CBD44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 0000008CBD48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBD4C: BF870091
	.long 0xd7006a06                                           // 0000008CBD50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBD54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000008CBD58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 0000008CBD60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000008CBD68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 0000008CBD6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008CBD70: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 0000008CBD74: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 0000008CBD78: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CBD7C: BF870001
	.long 0xd4c4007e                                           // 0000008CBD80: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBD84: 02020C06
	s_cbranch_execz 10                                         // 0000008CBD88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBD8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBD90: BF870091
	.long 0xd7006a08                                           // 0000008CBD94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBD98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 0000008CBD9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 0000008CBDA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 0000008CBDAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 0000008CBDB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBDB4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 0000008CBDB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000008CBDBC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 0000008CBDC4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CBDC8: BF870002
	.long 0xd4c4007e                                           // 0000008CBDCC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBDD0: 02020C06
	s_cbranch_execz 10                                         // 0000008CBDD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBDD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBDDC: BF870091
	.long 0xd7006a0b                                           // 0000008CBDE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBDE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 0000008CBDE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 0000008CBDF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 0000008CBDF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 0000008CBDFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBE00: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 0000008CBE04: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 0000008CBE08: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CBE0C: BF870001
	.long 0xd4c4007e                                           // 0000008CBE10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBE14: 02020C06
	s_cbranch_execz 10                                         // 0000008CBE18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBE1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBE20: BF870091
	.long 0xd7006a0a                                           // 0000008CBE24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBE28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 0000008CBE2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 0000008CBE34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008CBE3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 0000008CBE40: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBE44: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 0000008CBE48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 0000008CBE4C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 0000008CBE54: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CBE58: BF870002
	.long 0xd4c4007e                                           // 0000008CBE5C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBE60: 02020C06
	s_cbranch_execz 10                                         // 0000008CBE64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBE68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBE6C: BF870091
	.long 0xd7006a0d                                           // 0000008CBE70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBE74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 0000008CBE78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 0000008CBE80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 0000008CBE88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 0000008CBE8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBE90: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 0000008CBE94: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008CBE9C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CBEA0: BF870001
	.long 0xd4c4007e                                           // 0000008CBEA4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBEA8: 02020C06
	s_cbranch_execz 10                                         // 0000008CBEAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBEB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBEB4: BF870091
	.long 0xd7006a0c                                           // 0000008CBEB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBEBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 0000008CBEC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 0000008CBEC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 0000008CBED0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 0000008CBED4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBED8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 0000008CBEDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000008CBEE4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 0000008CBEEC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CBEF0: BF870002
	.long 0xd4c4007e                                           // 0000008CBEF4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBEF8: 02020C06
	s_cbranch_execz 10                                         // 0000008CBEFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBF00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBF04: BF870091
	.long 0xd7006a0f                                           // 0000008CBF08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBF0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 0000008CBF10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 0000008CBF18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 0000008CBF20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 0000008CBF24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBF28: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 0000008CBF2C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000008CBF34: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CBF38: BF870001
	.long 0xd4c4007e                                           // 0000008CBF3C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008CBF40: 02020C06
	s_cbranch_execz 10                                         // 0000008CBF44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 0000008CBF48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CBF4C: BF870091
	.long 0xd7006a0e                                           // 0000008CBF50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000008CBF54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 0000008CBF58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 0000008CBF60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 0000008CBF68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 0000008CBF6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008CBF70: 8C7E047E
	s_branch 9                                                 // 0000008CBF74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 0000008CBF78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CBF7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 0000008CBF80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 0000008CBF84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 0000008CBF88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 0000008CBF8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 0000008CBF90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 0000008CBF94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 0000008CBF98: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 0000008CBF9C: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008CBFA0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008CBFA4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008CBFA8: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 0000008CBFB0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008CBFB4: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 0000008CBFB8: CA100080 1F160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008CBFC0: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 0000008CBFC4: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 0000008CBFCC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 0000008CBFD4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 0000008CBFD8: 02002702
	.long 0xd72c0005                                           // 0000008CBFDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 0000008CBFE0: 02002505
	.long 0xd4440004                                           // 0000008CBFE4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008CBFE8: 02023C06
	v_mov_b32_e32 v41, 0                                       // 0000008CBFEC: 7E520280
	v_mov_b32_e32 v21, 0                                       // 0000008CBFF0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008CBFF4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 0000008CBFF8: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 0000008CC000: BE852004
	s_cbranch_execz 21                                         // 0000008CC004: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 0000008CC008: CA220080 29023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC010: BF870091
	.long 0xd7006a05                                           // 0000008CC014: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 0000008CC018: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 0000008CC01C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008CC024: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 0000008CC028: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 0000008CC030: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 0000008CC034: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC038: BF870091
	.long 0xd7006a02                                           // 0000008CC03C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000008CC040: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 0000008CC044: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 0000008CC04C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000008CC054: BF8903F7
	v_cvt_f32_f16_e32 v41, v2                                  // 0000008CC058: 7E521702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008CC05C: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 0000008CC060: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 0000008CC068: CA100080 24240080
	s_and_saveexec_b32 s5, s4                                  // 0000008CC070: BE852004
	s_cbranch_execz 507                                        // 0000008CC074: BFA501FB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xc64>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 0000008CC078: CA220080 1B023C81
	.long 0xd7006a00                                           // 0000008CC080: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 0000008CC084: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CC088: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 0000008CC08C: D5207C01 01AA0215
	v_dual_mov_b32 v39, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 0000008CC094: CA22011E 271A3C85
	.long 0xd7006a00                                           // 0000008CC09C: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008CC0A0: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CC0A4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000008CC0A8: D5207C01 01AA0280
	v_lshl_or_b32 v38, v30, 4, 0x100                           // 0000008CC0B0: D6560026 03FD091E 00000100
	.long 0xd7006a00                                           // 0000008CC0BC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008CC0C0: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CC0C4: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000008CC0C8: D5207C01 01AA0209
	v_dual_mov_b32 v37, v27 :: v_dual_mov_b32 v40, v41         // 0000008CC0D0: CA10011B 25280129
	.long 0xd7006a1c                                           // 0000008CC0D8: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 0000008CC0DC: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CC0E0: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 0000008CC0E4: D5207C1D 01AA0280
	v_mov_b32_e32 v36, v27                                     // 0000008CC0EC: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 0000008CC0F0: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 0000008CC0F4: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 0000008CC0F8: 7E3E031B
	s_mul_i32 s4, s15, 6                                       // 0000008CC0FC: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 0000008CC100: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 0000008CC104: 8492820E
	s_add_i32 s7, s7, s4                                       // 0000008CC108: 81070407
	s_mul_i32 s21, s14, 6                                      // 0000008CC10C: 9615860E
	s_mov_b32 s20, 0                                           // 0000008CC110: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008CC114: 8488810E
	s_branch 437                                               // 0000008CC118: BFA001B5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xbf0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008CC11C: 8C7E0E7E
	v_cndmask_b32_e64 v51, v41, v7, s3                         // 0000008CC120: D5010033 000E0F29
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 0000008CC128: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 0000008CC130: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 0000008CC138: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 0000008CC144: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 0000008CC14C: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 0000008CC154: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 0000008CC15C: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008CC164: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 0000008CC168: D5010002 000E1509
	s_and_b32 s4, exec_lo, s4                                  // 0000008CC170: 8B04047E
	v_add_nc_u32_e32 v38, 0x100, v38                           // 0000008CC174: 4A4C4CFF 00000100
	s_or_b32 s20, s4, s20                                      // 0000008CC17C: 8C141404
	ds_load_b32 v14, v8                                        // 0000008CC180: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 0000008CC188: 32102686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC18C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC190: 361010FF 000003FC
	ds_load_b32 v52, v8                                        // 0000008CC198: D8D80000 34000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 0000008CC1A0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC1A4: 361010FF 000003FC
	ds_load_b32 v53, v8                                        // 0000008CC1AC: D8D80000 35000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 0000008CC1B4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC1B8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC1BC: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 0000008CC1C4: D8D80000 36000008
	v_and_b32_e32 v8, 0xff, v20                                // 0000008CC1CC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008CC1D4: 30101082
	ds_load_b32 v55, v8                                        // 0000008CC1D8: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 0000008CC1E0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC1E4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC1E8: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 0000008CC1F0: D8D80000 38000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 0000008CC1F8: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC1FC: 361010FF 000003FC
	ds_load_b32 v57, v8                                        // 0000008CC204: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 0000008CC20C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC210: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC214: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 0000008CC21C: D8D80000 3A000008
	v_and_b32_e32 v8, 0xff, v21                                // 0000008CC224: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008CC22C: 30101082
	ds_load_b32 v59, v8                                        // 0000008CC230: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 0000008CC238: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC23C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC240: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 0000008CC248: D8D80000 3C000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 0000008CC250: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC254: 361010FF 000003FC
	ds_load_b32 v61, v8                                        // 0000008CC25C: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 0000008CC264: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC268: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC26C: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 0000008CC274: D8D80000 3E000008
	v_and_b32_e32 v8, 0xff, v22                                // 0000008CC27C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008CC284: 30101082
	ds_load_b32 v63, v8                                        // 0000008CC288: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 0000008CC290: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008CC294: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC298: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 0000008CC2A0: D8D80000 40000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 0000008CC2A8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC2AC: 361010FF 000003FC
	ds_load_b32 v65, v8                                        // 0000008CC2B4: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 0000008CC2BC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008CC2C0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008CC2C4: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 0000008CC2CC: D8D80000 42000008
	.long 0xd73c0008                                           // 0000008CC2D4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008CC2D8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 0000008CC2DC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 0000008CC2E4: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000008CC2E8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CC2EC: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 0000008CC2F0: D5207C0D 01AA120B
	s_clause 0x3                                               // 0000008CC2F8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008CC2FC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008CC304: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000008CC30C: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000008CC314: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008CC31C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008CC320: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 0000008CC328: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC32C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000008CC330: CC1A4008 1C226909
	s_waitcnt lgkmcnt(13)                                      // 0000008CC338: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000008CC33C: CC1A4008 1C226B0A
	s_waitcnt lgkmcnt(12)                                      // 0000008CC344: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC348: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000008CC34C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008CC354: BF8908B7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008CC358: CC1A4008 1C226F13
	s_waitcnt lgkmcnt(10)                                      // 0000008CC360: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC364: BF8700A1
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008CC368: CC1A4008 1C227114
	s_waitcnt lgkmcnt(9)                                       // 0000008CC370: BF89FC97
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008CC374: CC1A4008 1C227315
	s_waitcnt lgkmcnt(8)                                       // 0000008CC37C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC380: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008CC384: CC1A4008 1C227516
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008CC38C: BF890477
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008CC390: CC1A4008 1C227729
	s_waitcnt lgkmcnt(6)                                       // 0000008CC398: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC39C: BF8700A1
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008CC3A0: CC1A4008 1C22792A
	s_waitcnt lgkmcnt(5)                                       // 0000008CC3A8: BF89FC57
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008CC3AC: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(4)                                       // 0000008CC3B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC3B8: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008CC3BC: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008CC3C4: BF890037
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008CC3C8: CC1A4008 1C227F2D
	.long 0xd7006a2d                                           // 0000008CC3D0: D7006A2D
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 0000008CC3D4: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 0000008CC3D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008CC3DC: BF8701C2
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008CC3E0: CC1A4008 1C22812E
	v_add_co_ci_u32_e64 v46, null, s9, v13, vcc_lo             // 0000008CC3E8: D5207C2E 01AA1A09
	.long 0xd7006a31                                           // 0000008CC3F0: D7006A31
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 0000008CC3F4: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 0000008CC3F8: BF89FC17
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008CC3FC: CC1A4008 1C22832F
	v_add_co_ci_u32_e64 v50, null, s19, v13, vcc_lo            // 0000008CC404: D5207C32 01AA1A13
	.long 0xd7006a0c                                           // 0000008CC40C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 0000008CC410: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 0000008CC414: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008CC418: BF870123
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008CC41C: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 0000008CC424: D5207C0D 01AA1A07
	v_fmac_f32_e32 v37, v51, v8                                // 0000008CC42C: 564A1133
	s_clause 0x3                                               // 0000008CC430: BF850003
	global_load_b128 v[8:11], v[45:46], off                    // 0000008CC434: DC5E0000 087C002D
	global_load_b128 v[19:22], v[45:46], off offset:16         // 0000008CC43C: DC5E0010 137C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 0000008CC444: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000008CC44C: DC5E0030 2D7C002D
	s_waitcnt vmcnt(3)                                         // 0000008CC454: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008CC458: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC460: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000008CC464: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000008CC46C: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC474: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000008CC478: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000008CC480: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008CC484: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC48C: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008CC490: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008CC498: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC4A0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008CC4A4: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008CC4AC: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008CC4B0: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC4B8: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008CC4BC: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008CC4C4: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC4CC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008CC4D0: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008CC4D8: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008CC4DC: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC4E4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008CC4E8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008CC4F0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC4F8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008CC4FC: CC1A4008 1C228530
	v_fmac_f32_e32 v36, v51, v8                                // 0000008CC504: 56481133
	s_clause 0x3                                               // 0000008CC508: BF850003
	global_load_b128 v[8:11], v[49:50], off                    // 0000008CC50C: DC5E0000 087C0031
	global_load_b128 v[19:22], v[49:50], off offset:16         // 0000008CC514: DC5E0010 137C0031
	global_load_b128 v[41:44], v[49:50], off offset:32         // 0000008CC51C: DC5E0020 297C0031
	global_load_b128 v[45:48], v[49:50], off offset:48         // 0000008CC524: DC5E0030 2D7C0031
	s_waitcnt vmcnt(3)                                         // 0000008CC52C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008CC530: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC538: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000008CC53C: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000008CC544: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC54C: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000008CC550: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000008CC558: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008CC55C: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC564: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008CC568: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008CC570: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC578: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008CC57C: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008CC584: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008CC588: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC590: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008CC594: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008CC59C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC5A4: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008CC5A8: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008CC5B0: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008CC5B4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC5BC: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008CC5C0: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008CC5C8: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC5D0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008CC5D4: CC1A4008 1C228530
	v_fmac_f32_e32 v35, v51, v8                                // 0000008CC5DC: 56461133
	s_clause 0x3                                               // 0000008CC5E0: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008CC5E4: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008CC5EC: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000008CC5F4: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000008CC5FC: DC5E0030 2D7C000C
	.long 0xd7006a0c                                           // 0000008CC604: D7006A0C
	v_cndmask_b32_e32 v0, v49, v18, vcc_lo                     // 0000008CC608: 02002531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC60C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v50, vcc_lo            // 0000008CC610: D5207C0D 01AA6413
	.long 0xd7006a1c                                           // 0000008CC618: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 0000008CC61C: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 0000008CC620: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 0000008CC628: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008CC62C: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC634: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000008CC638: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000008CC640: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC648: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000008CC64C: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000008CC654: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008CC658: CC1A4008 1C226F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC660: BF870091
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008CC664: CC1A4008 1C227114
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008CC66C: CC1A4008 1C227315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC674: BF8700A1
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008CC678: CC1A4008 1C227516
	s_waitcnt vmcnt(1)                                         // 0000008CC680: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008CC684: CC1A4008 1C227729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC68C: BF870091
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008CC690: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008CC698: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC6A0: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008CC6A4: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008CC6AC: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008CC6B0: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC6B8: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008CC6BC: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008CC6C4: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC6CC: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008CC6D0: CC1A4008 1C228530
	v_fmac_f32_e32 v34, v51, v8                                // 0000008CC6D8: 56441133
	s_clause 0x3                                               // 0000008CC6DC: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 0000008CC6E0: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 0000008CC6E8: DC5E0010 137C000C
	global_load_b128 v[41:44], v[12:13], off offset:32         // 0000008CC6F0: DC5E0020 297C000C
	global_load_b128 v[45:48], v[12:13], off offset:48         // 0000008CC6F8: DC5E0030 2D7C000C
	s_waitcnt vmcnt(3)                                         // 0000008CC700: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 0000008CC704: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC70C: BF870091
	v_dot2_f32_bf16 v8, v9, v52, v8                            // 0000008CC710: CC1A4008 1C226909
	v_dot2_f32_bf16 v8, v10, v53, v8                           // 0000008CC718: CC1A4008 1C226B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC720: BF8700A1
	v_dot2_f32_bf16 v8, v11, v54, v8                           // 0000008CC724: CC1A4008 1C226D0B
	s_waitcnt vmcnt(2)                                         // 0000008CC72C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v55, v8                           // 0000008CC730: CC1A4008 1C226F13
	v_mov_b32_e32 v19, v15                                     // 0000008CC738: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008CC73C: BF870122
	v_dot2_f32_bf16 v8, v20, v56, v8                           // 0000008CC740: CC1A4008 1C227114
	v_mov_b32_e32 v20, v16                                     // 0000008CC748: 7E280310
	v_dot2_f32_bf16 v8, v21, v57, v8                           // 0000008CC74C: CC1A4008 1C227315
	v_mov_b32_e32 v21, v17                                     // 0000008CC754: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008CC758: BF870132
	v_dot2_f32_bf16 v8, v22, v58, v8                           // 0000008CC75C: CC1A4008 1C227516
	v_mov_b32_e32 v22, v18                                     // 0000008CC764: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 0000008CC768: BF8907F7
	v_dot2_f32_bf16 v8, v41, v59, v8                           // 0000008CC76C: CC1A4008 1C227729
	v_mov_b32_e32 v41, v40                                     // 0000008CC774: 7E520328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC778: BF870092
	v_dot2_f32_bf16 v8, v42, v60, v8                           // 0000008CC77C: CC1A4008 1C22792A
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 0000008CC784: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC78C: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 0000008CC790: CC1A4008 1C227D2C
	s_waitcnt vmcnt(0)                                         // 0000008CC798: BF8903F7
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 0000008CC79C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC7A4: BF870091
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 0000008CC7A8: CC1A4008 1C22812E
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 0000008CC7B0: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CC7B8: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 0000008CC7BC: CC1A4008 1C228530
	v_fmac_f32_e32 v31, v51, v8                                // 0000008CC7C4: 563E1133
	v_mov_b32_e32 v14, v7                                      // 0000008CC7C8: 7E1C0307
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 0000008CC7CC: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 0000008CC7D4: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 0000008CC7DC: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 0000008CC7E4: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008CC7E8: 917E147E
	s_cbranch_execz 28                                         // 0000008CC7EC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xc60>
	s_waitcnt vmcnt(0)                                         // 0000008CC7F0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v39, 16, v39  // 0000008CC7F4: CA200114 10264E90
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 0000008CC7FC: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 0000008CC804: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008CC808: BF870003
	.long 0xd4430004                                           // 0000008CC80C: D4430004
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 0000008CC810: 02024E06
	s_mov_b32 s14, exec_lo                                     // 0000008CC814: BE8E007E
	.long 0xd4c4007e                                           // 0000008CC818: D4C4007E
	v_cndmask_b32_e32 v1, s6, v39, vcc_lo                      // 0000008CC81C: 02024E06
	s_cbranch_execz 65086                                      // 0000008CC820: BFA5FE3E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	.long 0xd7006a00                                           // 0000008CC824: D7006A00
	v_cndmask_b32_e32 v1, v25, v38, vcc_lo                     // 0000008CC828: 02024D19
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008CC82C: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 0000008CC830: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 0000008CC838: 7C9A4081
	v_mov_b32_e32 v40, v41                                     // 0000008CC83C: 7E500329
	global_load_b128 v[15:18], v[0:1], off                     // 0000008CC840: DC5E0000 0F7C0000
	s_cbranch_vccnz 65076                                      // 0000008CC848: BFA4FE34 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	global_load_d16_b16 v0, v[28:29], off                      // 0000008CC84C: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 0000008CC854: BF8903F7
	v_cvt_f32_f16_e32 v40, v0                                  // 0000008CC858: 7E501700
	s_branch 65071                                             // 0000008CC85C: BFA0FE2F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x51c>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008CC860: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008CC864: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008CC868: 8C7E057E
	.long 0xd71f0000                                           // 0000008CC86C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008CC870: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000008CC874: 3A020088
	v_xor_b32_e32 v6, 4, v0                                    // 0000008CC878: 3A0C0084
	v_xor_b32_e32 v11, 2, v0                                   // 0000008CC87C: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008CC880: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008CC884: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008CC888: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000008CC88C: 7C980CA0
	v_cndmask_b32_e32 v6, v0, v6, vcc_lo                       // 0000008CC890: 020C0D00
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000008CC894: 7C9816A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CC898: BF870002
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000008CC89C: 300C0C82
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008CC8A0: 30020282
	ds_bpermute_b32 v2, v1, v37                                // 0000008CC8A4: DACC0000 02002501
	s_waitcnt lgkmcnt(0)                                       // 0000008CC8AC: BF89FC07
	v_add_f32_e32 v2, v37, v2                                  // 0000008CC8B0: 06040525
	ds_bpermute_b32 v3, v1, v36                                // 0000008CC8B4: DACC0000 03002401
	ds_bpermute_b32 v5, v1, v34                                // 0000008CC8BC: DACC0000 05002201
	ds_bpermute_b32 v4, v1, v35                                // 0000008CC8C4: DACC0000 04002301
	ds_bpermute_b32 v1, v1, v31                                // 0000008CC8CC: DACC0000 01001F01
	ds_bpermute_b32 v7, v6, v2                                 // 0000008CC8D4: DACC0000 07000206
	s_waitcnt lgkmcnt(4)                                       // 0000008CC8DC: BF89FC47
	v_add_f32_e32 v3, v36, v3                                  // 0000008CC8E0: 06060724
	s_waitcnt lgkmcnt(2)                                       // 0000008CC8E4: BF89FC27
	v_dual_add_f32 v5, v34, v5 :: v_dual_add_f32 v4, v35, v4   // 0000008CC8E8: C9080B22 05040923
	s_waitcnt lgkmcnt(0)                                       // 0000008CC8F0: BF89FC07
	v_dual_add_f32 v1, v31, v1 :: v_dual_add_f32 v2, v2, v7    // 0000008CC8F4: C908031F 01020F02
	ds_bpermute_b32 v8, v6, v3                                 // 0000008CC8FC: DACC0000 08000306
	ds_bpermute_b32 v10, v6, v5                                // 0000008CC904: DACC0000 0A000506
	ds_bpermute_b32 v9, v6, v4                                 // 0000008CC90C: DACC0000 09000406
	ds_bpermute_b32 v6, v6, v1                                 // 0000008CC914: DACC0000 06000106
	v_cndmask_b32_e32 v11, v0, v11, vcc_lo                     // 0000008CC91C: 02161700
	s_waitcnt lgkmcnt(2)                                       // 0000008CC920: BF89FC27
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v8, v5, v10    // 0000008CC924: C9081103 03081505
	v_xor_b32_e32 v5, 1, v0                                    // 0000008CC92C: 3A0A0081
	s_waitcnt lgkmcnt(0)                                       // 0000008CC930: BF89FC07
	v_dual_add_f32 v6, v1, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 0000008CC934: C9220D01 060A1682
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008CC93C: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008CC940: 7C980AA0
	ds_bpermute_b32 v1, v11, v2                                // 0000008CC944: DACC0000 0100020B
	ds_bpermute_b32 v10, v11, v8                               // 0000008CC94C: DACC0000 0A00080B
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000008CC954: 02000B00
	v_add_f32_e32 v7, v4, v9                                   // 0000008CC958: 060E1304
	ds_bpermute_b32 v4, v11, v3                                // 0000008CC95C: DACC0000 0400030B
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 0000008CC964: 7C943C80
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000008CC968: 30180082
	ds_bpermute_b32 v9, v11, v7                                // 0000008CC96C: DACC0000 0900070B
	ds_bpermute_b32 v11, v11, v6                               // 0000008CC974: DACC0000 0B00060B
	s_and_b32 s2, vcc_lo, s2                                   // 0000008CC97C: 8B02026A
	s_waitcnt lgkmcnt(4)                                       // 0000008CC980: BF89FC47
	v_add_f32_e32 v5, v2, v1                                   // 0000008CC984: 060A0302
	s_waitcnt lgkmcnt(2)                                       // 0000008CC988: BF89FC27
	v_dual_add_f32 v1, v8, v10 :: v_dual_add_f32 v4, v3, v4    // 0000008CC98C: C9081508 01040903
	ds_bpermute_b32 v3, v12, v1                                // 0000008CC994: DACC0000 0300010C
	s_waitcnt lgkmcnt(2)                                       // 0000008CC99C: BF89FC27
	v_add_f32_e32 v0, v7, v9                                   // 0000008CC9A0: 06001307
	s_waitcnt lgkmcnt(1)                                       // 0000008CC9A4: BF89FC17
	v_add_f32_e32 v8, v6, v11                                  // 0000008CC9A8: 06101706
	ds_bpermute_b32 v6, v12, v5                                // 0000008CC9AC: DACC0000 0600050C
	ds_bpermute_b32 v7, v12, v4                                // 0000008CC9B4: DACC0000 0700040C
	ds_bpermute_b32 v2, v12, v0                                // 0000008CC9BC: DACC0000 0200000C
	ds_bpermute_b32 v9, v12, v8                                // 0000008CC9C4: DACC0000 0900080C
	s_and_saveexec_b32 s3, s2                                  // 0000008CC9CC: BE832002
	s_cbranch_execz 112                                        // 0000008CC9D0: BFA50070 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi16ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xf94>
	v_ashrrev_i32_e32 v10, 31, v24                             // 0000008CC9D4: 3414309F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008CC9D8: F4040080 F8000040
	s_lshr_b32 s0, s17, 31                                     // 0000008CC9E0: 85009F11
	s_waitcnt lgkmcnt(0)                                       // 0000008CC9E4: BF89FC07
	v_dual_add_f32 v6, v5, v6 :: v_dual_add_f32 v7, v4, v7     // 0000008CC9E8: C9080D05 06060F04
	v_lshrrev_b32_e32 v10, 23, v10                             // 0000008CC9F0: 32141497
	s_add_u32 s4, s16, s0                                      // 0000008CC9F4: 80040010
	v_dual_mov_b32 v13, s13 :: v_dual_mov_b32 v14, s12         // 0000008CC9F8: CA10000D 0D0E000C
	.long 0x7f1e3880                                           // 0000008CCA00: 7F1E3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008CCA04: BF8701B3
	.long 0xd7006a0a                                           // 0000008CCA08: D7006A0A
	v_cndmask_b32_e32 v1, v23, v10, vcc_lo                     // 0000008CCA0C: 02021517
	v_add_f32_e32 v11, v8, v9                                  // 0000008CCA10: 06161308
	v_add_co_ci_u32_e64 v12, null, 0, v24, vcc_lo              // 0000008CCA14: D5207C0C 01AA3080
	v_and_b32_e32 v10, 0xfffffe00, v10                         // 0000008CCA1C: 361414FF FFFFFE00
	.long 0x7e1e3987                                           // 0000008CCA24: 7E1E3987
	v_dual_add_f32 v3, v1, v3 :: v_dual_add_f32 v2, v0, v2     // 0000008CCA28: C9080701 03020500
	.long 0x7f00398f                                           // 0000008CCA30: 7F00398F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CCA34: BF870094
	.long 0xd7016a08                                           // 0000008CCA38: D7016A08
	v_cndmask_b32_e32 v1, v23, v10, vcc_lo                     // 0000008CCA3C: 02021517
	v_sub_co_ci_u32_e64 v9, null, v24, v12, vcc_lo             // 0000008CCA40: D5217C09 01AA1918
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008CCA48: BF870194
	.long 0x7e003982                                           // 0000008CCA4C: 7E003982
	.long 0xd7000004                                           // 0000008CCA50: D7000004
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008CCA54: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008CCA5C: BF8704B3
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008CCA60: 7CA810FF 00000100
	v_add_co_ci_u32_e64 v5, null, -1, v9, s0                   // 0000008CCA68: D5207C05 000212C1
	s_addc_u32 s5, s17, 0                                      // 0000008CCA70: 82058011
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008CCA74: 86808104
	v_dual_cndmask_b32 v13, s3, v13 :: v_dual_cndmask_b32 v4, v4, v8// 0000008CCA78: CA521A03 0D041104
	v_cndmask_b32_e32 v5, v5, v9, vcc_lo                       // 0000008CCA80: 020A1305
	.long 0x7e103986                                           // 0000008CCA84: 7E103986
	.long 0x7f10398f                                           // 0000008CCA88: 7F10398F
	v_dual_cndmask_b32 v9, s2, v14 :: v_dual_and_b32 v14, 1, v15// 0000008CCA8C: CA641C02 090E1E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008CCA94: BF8701A4
	.long 0xd73c0004                                           // 0000008CCA98: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000008CCA9C: 02020881
	s_and_b32 s2, s4, -2                                       // 0000008CCAA0: 8B02C204
	v_and_b32_e32 v8, 1, v8                                    // 0000008CCAA4: 36101081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CCAA8: BF870093
	.long 0xd7006a09                                           // 0000008CCAAC: D7006A09
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 0000008CCAB0: 02021509
	v_add_co_ci_u32_e64 v10, null, v13, v12, vcc_lo            // 0000008CCAB4: D5207C0A 01AA190D
	.long 0x7e1e3983                                           // 0000008CCABC: 7E1E3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008CCAC0: BF870093
	.long 0xd7006a04                                           // 0000008CCAC4: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008CCAC8: 02020909
	v_add_co_ci_u32_e64 v5, null, v10, v5, vcc_lo              // 0000008CCACC: D5207C05 01AA0B0A
	v_add3_u32 v10, v7, v14, 0x7fff                            // 0000008CCAD4: D655000A 03FE1D07 00007FFF
	v_and_b32_e32 v14, 1, v0                                   // 0000008CCAE0: 361C0081
	v_add3_u32 v12, v6, v8, 0x7fff                             // 0000008CCAE4: D655000C 03FE1106 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008CCAF0: BF870004
	v_mad_u64_u32 v[0:1], null, s0, 6, v[4:5]                  // 0000008CCAF4: D6FE7C00 04110C00
	.long 0xd7006a06                                           // 0000008CCAFC: D7006A06
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008CCB00: 02000504
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008CCB04: 84828200
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 0000008CCB08: D5207C07 01AA0A05
	.long 0xd7006a08                                           // 0000008CCB10: D7006A08
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008CCB14: 02000504
	v_and_b32_e32 v13, 1, v15                                  // 0000008CCB18: 361A1E81
	v_bfe_u32 v15, v11, 16, 1                                  // 0000008CCB1C: D610000F 0205210B
	v_add_co_ci_u32_e64 v9, null, s3, v5, vcc_lo               // 0000008CCB24: D5207C09 01AA0A03
	v_add3_u32 v14, v2, v14, 0x7fff                            // 0000008CCB2C: D655000E 03FE1D02 00007FFF
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008CCB38: D6FE7C01 04050C01
	.long 0xd7006a02                                           // 0000008CCB40: D7006A02
	v_cndmask_b32_e32 v0, v8, v2, vcc_lo                       // 0000008CCB44: 02000508
	v_add3_u32 v13, v3, v13, 0x7fff                            // 0000008CCB48: D655000D 03FE1B03 00007FFF
	v_add3_u32 v11, v11, v15, 0x7fff                           // 0000008CCB54: D655000B 03FE1F0B 00007FFF
	v_add_co_ci_u32_e64 v3, null, s3, v9, vcc_lo               // 0000008CCB60: D5207C03 01AA1203
	s_clause 0x4                                               // 0000008CCB68: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 0000008CCB6C: DC960000 007C0C04
	global_store_d16_hi_b16 v[6:7], v10, off                   // 0000008CCB74: DC960000 007C0A06
	global_store_d16_hi_b16 v[8:9], v14, off                   // 0000008CCB7C: DC960000 007C0E08
	global_store_d16_hi_b16 v[0:1], v13, off                   // 0000008CCB84: DC960000 007C0D00
	global_store_d16_hi_b16 v[2:3], v11, off                   // 0000008CCB8C: DC960000 007C0B02
	s_endpgm                                                   // 0000008CCB94: BFB00000
		...

