00000000002db000 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002DB000: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002DB008: 32020085
	s_mov_b32 s3, 0                                            // 0000002DB00C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DB010: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002DB014: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002DB018: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002DB01C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002DB020: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002DB024: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002DB028: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DB02C: BF870001
	.long 0xd4d4007e                                           // 0000002DB030: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002DB034: 02020208
	s_cbranch_execz 614                                        // 0000002DB038: BFA50266 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll+0x9d4>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002DB03C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002DB044: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002DB048: BF89FC07
	.long 0xd451000a                                           // 0000002DB04C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002DB050: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002DB054: 8B6A0A7E
	s_cbranch_vccnz 384                                        // 0000002DB058: BFA40180 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll+0x65c>
	.long 0xd72c0006                                           // 0000002DB05C: D72C0006
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002DB060: 02020207
	.long 0xd72c0007                                           // 0000002DB064: D72C0007
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002DB068: 02020406
	v_mad_u64_u32 v[4:5], null, s6, v1, 0                      // 0000002DB06C: D6FE7C04 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002DB074: 848A8106
	s_mul_i32 s12, s7, 10                                      // 0000002DB078: 960C8A07
	s_mul_hi_u32 s13, s6, 10                                   // 0000002DB07C: 968D8A06
	s_mul_i32 s14, s6, 10                                      // 0000002DB080: 960E8A06
	s_add_u32 s10, s2, s10                                     // 0000002DB084: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002DB088: 820B0B03
	s_add_i32 s13, s13, s12                                    // 0000002DB08C: 810D0C0D
	v_add3_u32 v5, v5, v7, v6                                  // 0000002DB090: D6550005 041A0F05
	s_add_u32 s12, s2, s14                                     // 0000002DB098: 800C0E02
	s_addc_u32 s13, s3, s13                                    // 0000002DB09C: 820D0D03
	s_lshl_b64 s[14:15], s[6:7], 3                             // 0000002DB0A0: 848E8306
	s_mul_i32 s16, s6, 6                                       // 0000002DB0A4: 96108606
	.long 0xd73c0004                                           // 0000002DB0A8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002DB0AC: 02020881
	s_add_u32 s14, s2, s14                                     // 0000002DB0B0: 800E0E02
	s_addc_u32 s15, s3, s15                                    // 0000002DB0B4: 820F0F03
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000002DB0B8: CA220080 08020084
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 0000002DB0C0: CA100080 0B0A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DB0C8: BF870093
	.long 0xd7006a04                                           // 0000002DB0CC: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002DB0D0: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000002DB0D4: D5207C05 01AA0A01
	s_mul_i32 s0, s7, 6                                        // 0000002DB0DC: 96008607
	s_mul_hi_u32 s1, s6, 6                                     // 0000002DB0E0: 96818606
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v6, 0               // 0000002DB0E4: CA100080 09060080
	s_add_i32 s1, s1, s0                                       // 0000002DB0EC: 81010001
	s_add_u32 s16, s2, s16                                     // 0000002DB0F0: 80101002
	s_addc_u32 s17, s3, s1                                     // 0000002DB0F4: 82110103
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002DB0F8: 84808206
	v_mov_b32_e32 v7, 0                                        // 0000002DB0FC: 7E0E0280
	s_add_u32 s18, s2, s0                                      // 0000002DB100: 80120002
	s_addc_u32 s19, s3, s1                                     // 0000002DB104: 82130103
	s_mov_b64 s[0:1], 0                                        // 0000002DB108: BE800180
	.long 0xd7001452                                           // 0000002DB10C: D7001452
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002DB110: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DB114: BF8700A1
	v_add_co_ci_u32_e64 v83, null, s3, 0, s20                  // 0000002DB118: D5207C53 00510003
	.long 0xd7001454                                           // 0000002DB120: D7001454
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002DB124: 0202060A
	v_add_co_ci_u32_e64 v85, null, s11, 0, s20                 // 0000002DB128: D5207C55 0051000B
	.long 0xd7001456                                           // 0000002DB130: D7001456
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 0000002DB134: 02020612
	.long 0xd7006a50                                           // 0000002DB138: D7006A50
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002DB13C: 02020704
	v_add_co_ci_u32_e64 v87, null, s19, 0, s20                 // 0000002DB140: D5207C57 00510013
	.long 0xd7001458                                           // 0000002DB148: D7001458
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 0000002DB14C: 02020610
	v_add_co_ci_u32_e64 v81, null, 0, v5, vcc_lo               // 0000002DB150: D5207C51 01AA0A80
	v_add_co_ci_u32_e64 v89, null, s17, 0, s20                 // 0000002DB158: D5207C59 00510011
	.long 0xd700145a                                           // 0000002DB160: D700145A
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000002DB164: 0202060E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DB168: BF8700A1
	v_add_co_ci_u32_e64 v91, null, s15, 0, s20                 // 0000002DB16C: D5207C5B 0051000F
	.long 0xd700145c                                           // 0000002DB174: D700145C
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000002DB178: 0202060C
	v_add_co_ci_u32_e64 v93, null, s13, 0, s20                 // 0000002DB17C: D5207C5D 0051000D
	global_load_b128 v[12:15], v[80:81], off                   // 0000002DB184: DC5E0000 0C7C0050
	global_load_b128 v[16:19], v[82:83], off                   // 0000002DB18C: DC5E0000 107C0052
	global_load_b128 v[20:23], v[84:85], off                   // 0000002DB194: DC5E0000 147C0054
	global_load_b128 v[24:27], v[86:87], off                   // 0000002DB19C: DC5E0000 187C0056
	global_load_b128 v[28:31], v[88:89], off                   // 0000002DB1A4: DC5E0000 1C7C0058
	global_load_b128 v[32:35], v[90:91], off                   // 0000002DB1AC: DC5E0000 207C005A
	global_load_b128 v[36:39], v[92:93], off                   // 0000002DB1B4: DC5E0000 247C005C
	global_load_b128 v[40:43], v[80:81], off offset:512        // 0000002DB1BC: DC5E0200 287C0050
	global_load_b128 v[44:47], v[82:83], off offset:512        // 0000002DB1C4: DC5E0200 2C7C0052
	global_load_b128 v[48:51], v[84:85], off offset:512        // 0000002DB1CC: DC5E0200 307C0054
	global_load_b128 v[52:55], v[86:87], off offset:512        // 0000002DB1D4: DC5E0200 347C0056
	global_load_b128 v[56:59], v[88:89], off offset:512        // 0000002DB1DC: DC5E0200 387C0058
	global_load_b128 v[60:63], v[90:91], off offset:512        // 0000002DB1E4: DC5E0200 3C7C005A
	global_load_b128 v[64:67], v[92:93], off offset:512        // 0000002DB1EC: DC5E0200 407C005C
	global_load_b128 v[68:71], v[80:81], off offset:1024       // 0000002DB1F4: DC5E0400 447C0050
	global_load_b128 v[72:75], v[84:85], off offset:1024       // 0000002DB1FC: DC5E0400 487C0054
	global_load_b128 v[76:79], v[86:87], off offset:1024       // 0000002DB204: DC5E0400 4C7C0056
	s_add_u32 s0, s0, 0x400                                    // 0000002DB20C: 8000FF00 00000400
	s_addc_u32 s1, s1, 0                                       // 0000002DB214: 82018001
	s_add_u32 s10, s10, 0x800                                  // 0000002DB218: 800AFF0A 00000800
	s_addc_u32 s11, s11, 0                                     // 0000002DB220: 820B800B
	s_add_u32 s12, s12, 0x800                                  // 0000002DB224: 800CFF0C 00000800
	s_addc_u32 s13, s13, 0                                     // 0000002DB22C: 820D800D
	s_add_u32 s2, s2, 0x800                                    // 0000002DB230: 8002FF02 00000800
	.long 0xd4560014                                           // 0000002DB238: D4560014
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002DB23C: 02000C00
	s_addc_u32 s3, s3, 0                                       // 0000002DB240: 82038003
	.long 0xd7006a04                                           // 0000002DB244: D7006A04
	v_cndmask_b32_e32 v1, 0x800, v4, vcc_lo                    // 0000002DB248: 020208FF 00000800
	s_add_u32 s14, s14, 0x800                                  // 0000002DB250: 800EFF0E 00000800
	s_addc_u32 s15, s15, 0                                     // 0000002DB258: 820F800F
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002DB25C: D5207C05 01AA0A80
	s_add_u32 s16, s16, 0x800                                  // 0000002DB264: 8010FF10 00000800
	s_addc_u32 s17, s17, 0                                     // 0000002DB26C: 82118011
	s_add_u32 s18, s18, 0x800                                  // 0000002DB270: 8012FF12 00000800
	s_addc_u32 s19, s19, 0                                     // 0000002DB278: 82138013
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000002DB27C: 8B6A147E
	s_waitcnt vmcnt(15)                                        // 0000002DB280: BF893FF7
	v_dot2_f32_bf16 v8, v16, v12, v8                           // 0000002DB284: CC1A4008 1C221910
	s_waitcnt vmcnt(11)                                        // 0000002DB28C: BF892FF7
	v_dot2_f32_bf16 v7, v32, v12, v7                           // 0000002DB290: CC1A4007 1C1E1920
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DB298: BF8701B2
	v_dot2_f32_bf16 v8, v17, v13, v8                           // 0000002DB29C: CC1A4008 1C221B11
	s_waitcnt vmcnt(10)                                        // 0000002DB2A4: BF892BF7
	v_dot2_f32_bf16 v6, v36, v12, v6                           // 0000002DB2A8: CC1A4006 1C1A1924
	v_dot2_f32_bf16 v7, v33, v13, v7                           // 0000002DB2B0: CC1A4007 1C1E1B21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DB2B8: BF870193
	v_dot2_f32_bf16 v8, v18, v14, v8                           // 0000002DB2BC: CC1A4008 1C221D12
	v_dot2_f32_bf16 v6, v37, v13, v6                           // 0000002DB2C4: CC1A4006 1C1A1B25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DB2CC: BF870193
	v_dot2_f32_bf16 v7, v34, v14, v7                           // 0000002DB2D0: CC1A4007 1C1E1D22
	v_dot2_f32_bf16 v94, v19, v15, v8                          // 0000002DB2D8: CC1A405E 1C221F13
	v_dot2_f32_bf16 v8, v20, v12, v11                          // 0000002DB2E0: CC1A4008 1C2E1914
	global_load_b128 v[16:19], v[88:89], off offset:1024       // 0000002DB2E8: DC5E0400 107C0058
	v_dot2_f32_bf16 v6, v38, v14, v6                           // 0000002DB2F0: CC1A4006 1C1A1D26
	v_dot2_f32_bf16 v98, v35, v15, v7                          // 0000002DB2F8: CC1A4062 1C1E1F23
	v_dot2_f32_bf16 v8, v21, v13, v8                           // 0000002DB300: CC1A4008 1C221B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002DB308: BF8701A3
	v_dot2_f32_bf16 v6, v39, v15, v6                           // 0000002DB30C: CC1A4006 1C1A1F27
	s_waitcnt vmcnt(5)                                         // 0000002DB314: BF8917F7
	v_dot2_f32_bf16 v60, v60, v40, v98                         // 0000002DB318: CC1A403C 1D8A513C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002DB320: BF870133
	v_dot2_f32_bf16 v8, v22, v14, v8                           // 0000002DB324: CC1A4008 1C221D16
	s_waitcnt vmcnt(4)                                         // 0000002DB32C: BF8913F7
	v_dot2_f32_bf16 v6, v64, v40, v6                           // 0000002DB330: CC1A4006 1C1A5140
	v_dot2_f32_bf16 v95, v23, v15, v8                          // 0000002DB338: CC1A405F 1C221F17
	v_dot2_f32_bf16 v8, v24, v12, v10                          // 0000002DB340: CC1A4008 1C2A1918
	global_load_b128 v[20:23], v[90:91], off offset:1024       // 0000002DB348: DC5E0400 147C005A
	v_dot2_f32_bf16 v6, v65, v41, v6                           // 0000002DB350: CC1A4006 1C1A5341
	v_dot2_f32_bf16 v48, v48, v40, v95                         // 0000002DB358: CC1A4030 1D7E5130
	v_dot2_f32_bf16 v8, v25, v13, v8                           // 0000002DB360: CC1A4008 1C221B19
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DB368: BF870113
	v_dot2_f32_bf16 v6, v66, v42, v6                           // 0000002DB36C: CC1A4006 1C1A5542
	v_dot2_f32_bf16 v8, v26, v14, v8                           // 0000002DB374: CC1A4008 1C221D1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DB37C: BF870112
	v_dot2_f32_bf16 v6, v67, v43, v6                           // 0000002DB380: CC1A4006 1C1A5743
	v_dot2_f32_bf16 v96, v27, v15, v8                          // 0000002DB388: CC1A4060 1C221F1B
	v_dot2_f32_bf16 v8, v28, v12, v9                           // 0000002DB390: CC1A4008 1C26191C
	global_load_b128 v[24:27], v[92:93], off offset:1024       // 0000002DB398: DC5E0400 187C005C
	v_dot2_f32_bf16 v52, v52, v40, v96                         // 0000002DB3A0: CC1A4034 1D825134
	v_dot2_f32_bf16 v8, v29, v13, v8                           // 0000002DB3A8: CC1A4008 1C221B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DB3B0: BF870091
	v_dot2_f32_bf16 v8, v30, v14, v8                           // 0000002DB3B4: CC1A4008 1C221D1E
	v_dot2_f32_bf16 v97, v31, v15, v8                          // 0000002DB3BC: CC1A4061 1C221F1F
	s_clause 0x1                                               // 0000002DB3C4: BF850001
	global_load_b128 v[7:10], v[82:83], off offset:1024        // 0000002DB3C8: DC5E0400 077C0052
	global_load_b128 v[32:35], v[82:83], off offset:1536       // 0000002DB3D0: DC5E0600 207C0052
	v_dot2_f32_bf16 v15, v44, v40, v94                         // 0000002DB3D8: CC1A400F 1D7A512C
	global_load_b128 v[28:31], v[80:81], off offset:1536       // 0000002DB3E0: DC5E0600 1C7C0050
	global_load_b128 v[11:14], v[84:85], off offset:1536       // 0000002DB3E8: DC5E0600 0B7C0054
	global_load_b128 v[36:39], v[86:87], off offset:1536       // 0000002DB3F0: DC5E0600 247C0056
	global_load_b128 v[80:83], v[88:89], off offset:1536       // 0000002DB3F8: DC5E0600 507C0058
	global_load_b128 v[84:87], v[90:91], off offset:1536       // 0000002DB400: DC5E0600 547C005A
	v_dot2_f32_bf16 v56, v56, v40, v97                         // 0000002DB408: CC1A4038 1D865138
	v_dot2_f32_bf16 v40, v49, v41, v48                         // 0000002DB410: CC1A4028 1CC25331
	v_dot2_f32_bf16 v15, v45, v41, v15                         // 0000002DB418: CC1A400F 1C3E532D
	v_dot2_f32_bf16 v48, v53, v41, v52                         // 0000002DB420: CC1A4030 1CD25335
	v_dot2_f32_bf16 v52, v61, v41, v60                         // 0000002DB428: CC1A4034 1CF2533D
	v_dot2_f32_bf16 v49, v57, v41, v56                         // 0000002DB430: CC1A4031 1CE25339
	v_dot2_f32_bf16 v40, v50, v42, v40                         // 0000002DB438: CC1A4028 1CA25532
	v_dot2_f32_bf16 v15, v46, v42, v15                         // 0000002DB440: CC1A400F 1C3E552E
	v_dot2_f32_bf16 v41, v54, v42, v48                         // 0000002DB448: CC1A4029 1CC25536
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DB450: BF870224
	v_dot2_f32_bf16 v48, v58, v42, v49                         // 0000002DB454: CC1A4030 1CC6553A
	v_dot2_f32_bf16 v49, v62, v42, v52                         // 0000002DB45C: CC1A4031 1CD2553E
	v_dot2_f32_bf16 v15, v47, v43, v15                         // 0000002DB464: CC1A400F 1C3E572F
	global_load_b128 v[44:47], v[92:93], off offset:1536       // 0000002DB46C: DC5E0600 2C7C005C
	v_dot2_f32_bf16 v40, v51, v43, v40                         // 0000002DB474: CC1A4028 1CA25733
	v_dot2_f32_bf16 v41, v55, v43, v41                         // 0000002DB47C: CC1A4029 1CA65737
	v_dot2_f32_bf16 v42, v59, v43, v48                         // 0000002DB484: CC1A402A 1CC2573B
	v_dot2_f32_bf16 v48, v63, v43, v49                         // 0000002DB48C: CC1A4030 1CC6573F
	s_waitcnt vmcnt(10)                                        // 0000002DB494: BF892BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DB498: BF870092
	v_dot2_f32_bf16 v16, v16, v68, v42                         // 0000002DB49C: CC1A4010 1CAA8910
	v_dot2_f32_bf16 v16, v17, v69, v16                         // 0000002DB4A4: CC1A4010 1C428B11
	s_waitcnt vmcnt(9)                                         // 0000002DB4AC: BF8927F7
	v_dot2_f32_bf16 v20, v20, v68, v48                         // 0000002DB4B0: CC1A4014 1CC28914
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002DB4B8: BF8700B1
	v_dot2_f32_bf16 v17, v21, v69, v20                         // 0000002DB4BC: CC1A4011 1C528B15
	s_waitcnt vmcnt(8)                                         // 0000002DB4C4: BF8923F7
	v_dot2_f32_bf16 v6, v24, v68, v6                           // 0000002DB4C8: CC1A4006 1C1A8918
	v_dot2_f32_bf16 v6, v25, v69, v6                           // 0000002DB4D0: CC1A4006 1C1A8B19
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DB4D8: BF870001
	v_dot2_f32_bf16 v6, v26, v70, v6                           // 0000002DB4DC: CC1A4006 1C1A8D1A
	s_waitcnt vmcnt(7)                                         // 0000002DB4E4: BF891FF7
	v_dot2_f32_bf16 v7, v7, v68, v15                           // 0000002DB4E8: CC1A4007 1C3E8907
	v_dot2_f32_bf16 v15, v72, v68, v40                         // 0000002DB4F0: CC1A400F 1CA28948
	v_dot2_f32_bf16 v40, v76, v68, v41                         // 0000002DB4F8: CC1A4028 1CA6894C
	v_dot2_f32_bf16 v6, v27, v71, v6                           // 0000002DB500: CC1A4006 1C1A8F1B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DB508: BF870214
	v_dot2_f32_bf16 v7, v8, v69, v7                            // 0000002DB50C: CC1A4007 1C1E8B08
	v_dot2_f32_bf16 v8, v73, v69, v15                          // 0000002DB514: CC1A4008 1C3E8B49
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DB51C: BF870194
	v_dot2_f32_bf16 v15, v77, v69, v40                         // 0000002DB520: CC1A400F 1CA28B4D
	v_dot2_f32_bf16 v7, v9, v70, v7                            // 0000002DB528: CC1A4007 1C1E8D09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DB530: BF870193
	v_dot2_f32_bf16 v8, v74, v70, v8                           // 0000002DB534: CC1A4008 1C228D4A
	v_dot2_f32_bf16 v9, v78, v70, v15                          // 0000002DB53C: CC1A4009 1C3E8D4E
	v_dot2_f32_bf16 v15, v18, v70, v16                         // 0000002DB544: CC1A400F 1C428D12
	v_dot2_f32_bf16 v16, v22, v70, v17                         // 0000002DB54C: CC1A4010 1C468D16
	v_dot2_f32_bf16 v7, v10, v71, v7                           // 0000002DB554: CC1A4007 1C1E8F0A
	v_dot2_f32_bf16 v8, v75, v71, v8                           // 0000002DB55C: CC1A4008 1C228F4B
	v_dot2_f32_bf16 v9, v79, v71, v9                           // 0000002DB564: CC1A4009 1C268F4F
	v_dot2_f32_bf16 v10, v19, v71, v15                         // 0000002DB56C: CC1A400A 1C3E8F13
	v_dot2_f32_bf16 v15, v23, v71, v16                         // 0000002DB574: CC1A400F 1C428F17
	s_waitcnt vmcnt(5)                                         // 0000002DB57C: BF8917F7
	v_dot2_f32_bf16 v7, v32, v28, v7                           // 0000002DB580: CC1A4007 1C1E3920
	s_waitcnt vmcnt(4)                                         // 0000002DB588: BF8913F7
	v_dot2_f32_bf16 v8, v11, v28, v8                           // 0000002DB58C: CC1A4008 1C22390B
	s_waitcnt vmcnt(3)                                         // 0000002DB594: BF890FF7
	v_dot2_f32_bf16 v9, v36, v28, v9                           // 0000002DB598: CC1A4009 1C263924
	s_waitcnt vmcnt(2)                                         // 0000002DB5A0: BF890BF7
	v_dot2_f32_bf16 v10, v80, v28, v10                         // 0000002DB5A4: CC1A400A 1C2A3950
	s_waitcnt vmcnt(1)                                         // 0000002DB5AC: BF8907F7
	v_dot2_f32_bf16 v11, v84, v28, v15                         // 0000002DB5B0: CC1A400B 1C3E3954
	s_waitcnt vmcnt(0)                                         // 0000002DB5B8: BF8903F7
	v_dot2_f32_bf16 v6, v44, v28, v6                           // 0000002DB5BC: CC1A4006 1C1A392C
	v_dot2_f32_bf16 v7, v33, v29, v7                           // 0000002DB5C4: CC1A4007 1C1E3B21
	v_dot2_f32_bf16 v8, v12, v29, v8                           // 0000002DB5CC: CC1A4008 1C223B0C
	v_dot2_f32_bf16 v9, v37, v29, v9                           // 0000002DB5D4: CC1A4009 1C263B25
	v_dot2_f32_bf16 v10, v81, v29, v10                         // 0000002DB5DC: CC1A400A 1C2A3B51
	v_dot2_f32_bf16 v11, v85, v29, v11                         // 0000002DB5E4: CC1A400B 1C2E3B55
	v_dot2_f32_bf16 v6, v45, v29, v6                           // 0000002DB5EC: CC1A4006 1C1A3B2D
	v_dot2_f32_bf16 v7, v34, v30, v7                           // 0000002DB5F4: CC1A4007 1C1E3D22
	v_dot2_f32_bf16 v12, v13, v30, v8                          // 0000002DB5FC: CC1A400C 1C223D0D
	v_dot2_f32_bf16 v9, v38, v30, v9                           // 0000002DB604: CC1A4009 1C263D26
	v_dot2_f32_bf16 v13, v82, v30, v10                         // 0000002DB60C: CC1A400D 1C2A3D52
	v_dot2_f32_bf16 v15, v86, v30, v11                         // 0000002DB614: CC1A400F 1C2E3D56
	v_dot2_f32_bf16 v6, v46, v30, v6                           // 0000002DB61C: CC1A4006 1C1A3D2E
	v_dot2_f32_bf16 v8, v35, v31, v7                           // 0000002DB624: CC1A4008 1C1E3F23
	v_dot2_f32_bf16 v11, v14, v31, v12                         // 0000002DB62C: CC1A400B 1C323F0E
	v_dot2_f32_bf16 v10, v39, v31, v9                          // 0000002DB634: CC1A400A 1C263F27
	v_dot2_f32_bf16 v9, v83, v31, v13                          // 0000002DB63C: CC1A4009 1C363F53
	v_dot2_f32_bf16 v7, v87, v31, v15                          // 0000002DB644: CC1A4007 1C3E3F57
	v_dot2_f32_bf16 v6, v47, v31, v6                           // 0000002DB64C: CC1A4006 1C1A3F2F
	s_cbranch_vccz 65197                                       // 0000002DB654: BFA3FEAD <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll+0x10c>
	s_branch 6                                                 // 0000002DB658: BFA00006 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll+0x674>
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0               // 0000002DB65C: CA100080 06060080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000002DB664: CA100080 090A0080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v8, 0              // 0000002DB66C: CA100080 0B080080
	.long 0xd71f0003                                           // 0000002DB674: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DB678: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DB67C: BF870121
	v_xor_b32_e32 v4, 16, v3                                   // 0000002DB680: 3A080690
	v_xor_b32_e32 v16, 8, v3                                   // 0000002DB684: 3A200688
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DB688: 7C9808A0
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo                       // 0000002DB68C: 02080903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DB690: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DB694: 7C9820A0
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DB698: 30080882
	ds_bpermute_b32 v5, v4, v11                                // 0000002DB69C: DACC0000 05000B04
	s_waitcnt lgkmcnt(0)                                       // 0000002DB6A4: BF89FC07
	v_add_f32_e32 v5, v11, v5                                  // 0000002DB6A8: 060A0B0B
	ds_bpermute_b32 v12, v4, v8                                // 0000002DB6AC: DACC0000 0C000804
	ds_bpermute_b32 v14, v4, v10                               // 0000002DB6B4: DACC0000 0E000A04
	ds_bpermute_b32 v13, v4, v9                                // 0000002DB6BC: DACC0000 0D000904
	ds_bpermute_b32 v15, v4, v6                                // 0000002DB6C4: DACC0000 0F000604
	ds_bpermute_b32 v4, v4, v7                                 // 0000002DB6CC: DACC0000 04000704
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DB6D4: 02202103
	s_waitcnt lgkmcnt(3)                                       // 0000002DB6D8: BF89FC37
	v_add_f32_e32 v10, v10, v14                                // 0000002DB6DC: 06141D0A
	v_add_f32_e32 v8, v8, v12                                  // 0000002DB6E0: 06101908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DB6E4: BF870003
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DB6E8: 30202082
	s_waitcnt lgkmcnt(0)                                       // 0000002DB6EC: BF89FC07
	v_dual_add_f32 v4, v7, v4 :: v_dual_add_f32 v9, v9, v13    // 0000002DB6F0: C9080907 04081B09
	ds_bpermute_b32 v7, v16, v5                                // 0000002DB6F8: DACC0000 07000510
	ds_bpermute_b32 v11, v16, v8                               // 0000002DB700: DACC0000 0B000810
	s_waitcnt lgkmcnt(1)                                       // 0000002DB708: BF89FC17
	v_add_f32_e32 v5, v5, v7                                   // 0000002DB70C: 060A0F05
	v_add_f32_e32 v6, v6, v15                                  // 0000002DB710: 060C1F06
	s_waitcnt lgkmcnt(0)                                       // 0000002DB714: BF89FC07
	v_add_f32_e32 v7, v8, v11                                  // 0000002DB718: 060E1708
	ds_bpermute_b32 v12, v16, v9                               // 0000002DB71C: DACC0000 0C000910
	ds_bpermute_b32 v13, v16, v10                              // 0000002DB724: DACC0000 0D000A10
	ds_bpermute_b32 v15, v16, v4                               // 0000002DB72C: DACC0000 0F000410
	ds_bpermute_b32 v14, v16, v6                               // 0000002DB734: DACC0000 0E000610
	v_xor_b32_e32 v16, 4, v3                                   // 0000002DB73C: 3A200684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DB740: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DB744: 7C9820A0
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DB748: 02202103
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DB74C: 30202082
	s_waitcnt lgkmcnt(3)                                       // 0000002DB750: BF89FC37
	v_add_f32_e32 v8, v9, v12                                  // 0000002DB754: 06101909
	ds_bpermute_b32 v11, v16, v7                               // 0000002DB758: DACC0000 0B000710
	ds_bpermute_b32 v12, v16, v8                               // 0000002DB760: DACC0000 0C000810
	s_waitcnt lgkmcnt(1)                                       // 0000002DB768: BF89FC17
	v_add_f32_e32 v7, v7, v11                                  // 0000002DB76C: 060E1707
	v_add_f32_e32 v9, v10, v13                                 // 0000002DB770: 06121B0A
	ds_bpermute_b32 v10, v16, v5                               // 0000002DB774: DACC0000 0A000510
	v_xor_b32_e32 v11, 1, v3                                   // 0000002DB77C: 3A160681
	ds_bpermute_b32 v13, v16, v9                               // 0000002DB780: DACC0000 0D000910
	s_waitcnt lgkmcnt(1)                                       // 0000002DB788: BF89FC17
	v_add_f32_e32 v5, v5, v10                                  // 0000002DB78C: 060A1505
	s_waitcnt lgkmcnt(0)                                       // 0000002DB790: BF89FC07
	v_dual_add_f32 v6, v6, v14 :: v_dual_add_f32 v9, v9, v13   // 0000002DB794: C9081D06 06081B09
	v_add_f32_e32 v4, v4, v15                                  // 0000002DB79C: 06081F04
	ds_bpermute_b32 v14, v16, v6                               // 0000002DB7A0: DACC0000 0E000610
	ds_bpermute_b32 v15, v16, v4                               // 0000002DB7A8: DACC0000 0F000410
	v_xor_b32_e32 v16, 2, v3                                   // 0000002DB7B0: 3A200682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002DB7B4: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DB7B8: 7C9820A0
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DB7BC: 02202103
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000002DB7C0: 7C9816A0
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DB7C4: 30202082
	s_waitcnt lgkmcnt(1)                                       // 0000002DB7C8: BF89FC17
	v_dual_add_f32 v6, v6, v14 :: v_dual_cndmask_b32 v3, v3, v11// 0000002DB7CC: C9121D06 06021703
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002DB7D4: 7C940080
	ds_bpermute_b32 v10, v16, v5                               // 0000002DB7D8: DACC0000 0A000510
	ds_bpermute_b32 v14, v16, v9                               // 0000002DB7E0: DACC0000 0E000910
	v_lshlrev_b32_e32 v17, 2, v3                               // 0000002DB7E8: 30220682
	s_waitcnt lgkmcnt(1)                                       // 0000002DB7EC: BF89FC17
	v_dual_add_f32 v11, v5, v10 :: v_dual_add_f32 v4, v4, v15  // 0000002DB7F0: C9081505 0B041F04
	ds_bpermute_b32 v15, v16, v6                               // 0000002DB7F8: DACC0000 0F000610
	s_waitcnt lgkmcnt(0)                                       // 0000002DB800: BF89FC07
	v_dual_add_f32 v3, v6, v15 :: v_dual_add_f32 v8, v8, v12   // 0000002DB804: C9081F06 03081908
	ds_bpermute_b32 v12, v16, v7                               // 0000002DB80C: DACC0000 0C000710
	ds_bpermute_b32 v6, v17, v3                                // 0000002DB814: DACC0000 06000311
	ds_bpermute_b32 v13, v16, v8                               // 0000002DB81C: DACC0000 0D000810
	ds_bpermute_b32 v16, v16, v4                               // 0000002DB824: DACC0000 10000410
	s_waitcnt lgkmcnt(1)                                       // 0000002DB82C: BF89FC17
	v_dual_add_f32 v12, v7, v12 :: v_dual_add_f32 v7, v8, v13  // 0000002DB830: C9081907 0C061B08
	v_add_f32_e32 v8, v9, v14                                  // 0000002DB838: 06101D09
	s_waitcnt lgkmcnt(0)                                       // 0000002DB83C: BF89FC07
	v_add_f32_e32 v4, v4, v16                                  // 0000002DB840: 06082104
	ds_bpermute_b32 v14, v17, v12                              // 0000002DB844: DACC0000 0E000C11
	ds_bpermute_b32 v13, v17, v11                              // 0000002DB84C: DACC0000 0D000B11
	ds_bpermute_b32 v10, v17, v7                               // 0000002DB854: DACC0000 0A000711
	ds_bpermute_b32 v9, v17, v8                                // 0000002DB85C: DACC0000 09000811
	ds_bpermute_b32 v5, v17, v4                                // 0000002DB864: DACC0000 05000411
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002DB86C: 8B7E6A7E
	s_cbranch_execz 88                                         // 0000002DB870: BFA50058 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi4EEEvPKtS3_Ptll+0x9d4>
	s_waitcnt lgkmcnt(3)                                       // 0000002DB874: BF89FC37
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v13, v11, v13// 0000002DB878: C9081D0C 0C0C1B0B
	.long 0x7f1c3880                                           // 0000002DB880: 7F1C3880
	.long 0xd73c0000                                           // 0000002DB884: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002DB888: 02020281
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002DB88C: 84808108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002DB890: BF8700D3
	.long 0x7e16398c                                           // 0000002DB894: 7E16398C
	.long 0x7e1c398d                                           // 0000002DB898: 7E1C398D
	.long 0x7f16398e                                           // 0000002DB89C: 7F16398E
	v_add_f32_e32 v6, v3, v6                                   // 0000002DB8A0: 060C0D03
	.long 0xd7006a00                                           // 0000002DB8A4: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002DB8A8: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000002DB8AC: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DB8B4: BF870224
	v_and_b32_e32 v2, 1, v11                                   // 0000002DB8B8: 36041681
	v_and_b32_e32 v15, 1, v14                                  // 0000002DB8BC: 361E1C81
	.long 0xd7006a0b                                           // 0000002DB8C0: D7006A0B
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DB8C4: 02000100
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DB8C8: BF870003
	v_add3_u32 v2, v12, v2, 0x7fff                             // 0000002DB8CC: D6550002 03FE050C 00007FFF
	v_add_co_ci_u32_e64 v12, null, s1, v1, vcc_lo              // 0000002DB8D8: D5207C0C 01AA0201
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002DB8E0: 84808208
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002DB8E4: DC960000 007C0200
	s_waitcnt lgkmcnt(1)                                       // 0000002DB8EC: BF89FC17
	v_dual_add_f32 v2, v8, v9 :: v_dual_add_f32 v9, v7, v10    // 0000002DB8F0: C9081308 02081507
	.long 0xd7006a07                                           // 0000002DB8F8: D7006A07
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DB8FC: 02000100
	.long 0x7f14398e                                           // 0000002DB900: 7F14398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DB904: BF870213
	.long 0x7e143982                                           // 0000002DB908: 7E143982
	.long 0x7e1c3989                                           // 0000002DB90C: 7E1C3989
	s_waitcnt lgkmcnt(0)                                       // 0000002DB910: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002DB914: 06080B04
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 0000002DB918: D5207C08 01AA0201
	v_mad_u64_u32 v[0:1], null, s8, 6, v[0:1]                  // 0000002DB920: D6FE7C00 04010C08
	v_and_b32_e32 v5, 1, v10                                   // 0000002DB928: 360A1481
	v_and_b32_e32 v3, 1, v14                                   // 0000002DB92C: 36061C81
	.long 0x7e143984                                           // 0000002DB930: 7E143984
	.long 0x7e1c3986                                           // 0000002DB934: 7E1C3986
	v_add3_u32 v13, v13, v15, 0x7fff                           // 0000002DB938: D655000D 03FE1F0D 00007FFF
	v_add3_u32 v15, v2, v5, 0x7fff                             // 0000002DB944: D655000F 03FE0B02 00007FFF
	v_add3_u32 v9, v9, v3, 0x7fff                              // 0000002DB950: D6550009 03FE0709 00007FFF
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002DB95C: D6FE7C01 04050C09
	v_and_b32_e32 v10, 1, v10                                  // 0000002DB964: 36141481
	v_and_b32_e32 v5, 1, v14                                   // 0000002DB968: 360A1C81
	.long 0xd7006a02                                           // 0000002DB96C: D7006A02
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DB970: 02000107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DB974: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v8, vcc_lo               // 0000002DB978: D5207C03 01AA1001
	v_add3_u32 v10, v4, v10, 0x7fff                            // 0000002DB980: D655000A 03FE1504 00007FFF
	.long 0xd7006a04                                           // 0000002DB98C: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DB990: 02000100
	v_add3_u32 v6, v6, v5, 0x7fff                              // 0000002DB994: D6550006 03FE0B06 00007FFF
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000002DB9A0: D5207C05 01AA0201
	s_clause 0x4                                               // 0000002DB9A8: BF850004
	global_store_d16_hi_b16 v[11:12], v13, off                 // 0000002DB9AC: DC960000 007C0D0B
	global_store_d16_hi_b16 v[7:8], v15, off                   // 0000002DB9B4: DC960000 007C0F07
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002DB9BC: DC960000 007C0900
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000002DB9C4: DC960000 007C0A02
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000002DB9CC: DC960000 007C0604
	s_nop 0                                                    // 0000002DB9D4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000002DB9D8: BFB60003
	s_endpgm                                                   // 0000002DB9DC: BFB00000
		...

