00000000008c5a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008C5A00: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 0000008C5A08: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000008C5A0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000008C5A10: 86039F02
	.long 0x7f103880                                           // 0000008C5A14: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000008C5A18: 84828402
	v_mov_b32_e32 v17, 0                                       // 0000008C5A1C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000008C5A20: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 0000008C5A28: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 0000008C5A2C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 0000008C5A34: BF89FC07
	s_clause 0x1                                               // 0000008C5A38: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 0000008C5A3C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 0000008C5A44: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000008C5A4C: 7CA8120C
	s_add_u32 s14, s4, s14                                     // 0000008C5A50: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008C5A54: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000008C5A58: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 0000008C5A5C: 7E240280
	s_add_u32 s20, s10, s2                                     // 0000008C5A60: 8014020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000008C5A64: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000008C5A68: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000008C5A70: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008C5A74: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000008C5A78: 86828114
	.long 0xd72c000d                                           // 0000008C5A7C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000008C5A80: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000008C5A84: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000008C5A8C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000008C5A90: 0200070B
	.long 0xd72c0014                                           // 0000008C5A94: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000008C5A98: 0200050E
	.long 0xd72c000e                                           // 0000008C5A9C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000008C5AA0: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000008C5AA4: 85139B16
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000008C5AA8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C5AB0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000008C5AB4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000008C5ABC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000008C5AC0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000008C5AC8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000008C5ACC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000008C5AD4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000008C5AE0: D6FE7C0B 0038050B
	s_add_u32 s14, s10, s19                                    // 0000008C5AE8: 800E130A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000008C5AEC: D6550007 03FE2707 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000008C5AF8: 820F800B
	.long 0x7e103984                                           // 0000008C5AFC: 7E103984
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000008C5B00: 858E850E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 0000008C5B04: CA220080 04120082
	.long 0xd4440002                                           // 0000008C5B0C: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000008C5B10: 0202200E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C5B14: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000008C5B18: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 0000008C5B24: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000008C5B2C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000008C5B34: BF89FC07
	s_barrier                                                  // 0000008C5B38: BFBD0000
	buffer_gl0_inv                                             // 0000008C5B3C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000008C5B44: BE8F2002
	s_cbranch_execz 26                                         // 0000008C5B48: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s3, s4, s16                                      // 0000008C5B4C: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000008C5B50: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000008C5B54: 30022081
	.long 0xd7000302                                           // 0000008C5B58: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000008C5B5C: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C5B60: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000008C5B64: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000008C5B6C: 30082084
	.long 0xd7000301                                           // 0000008C5B70: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000008C5B74: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C5B78: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000008C5B7C: D5207C02 000E0680
	.long 0xd7000303                                           // 0000008C5B84: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000008C5B88: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C5B8C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000008C5B90: D5207C04 000E0080
	s_clause 0x1                                               // 0000008C5B98: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000008C5B9C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008C5BA4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008C5BAC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000008C5BB0: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C5BB4: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000008C5BB8: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 0000008C5BC0: 7E2A0280
	s_and_saveexec_b32 s15, s2                                 // 0000008C5BC4: BE8F2002
	s_cbranch_execz 382                                        // 0000008C5BC8: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_mul_i32 s2, s11, 6                                       // 0000008C5BCC: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000008C5BD0: 9683860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000008C5BD4: CA220080 0D0C2085
	s_add_i32 s20, s3, s2                                      // 0000008C5BDC: 81140203
	v_lshlrev_b32_e32 v7, 1, v16                               // 0000008C5BE0: 300E2081
	.long 0xd7000205                                           // 0000008C5BE4: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000008C5BE8: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C5BEC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000008C5BF0: D5207C06 000A0C11
	v_mov_b32_e32 v20, v13                                     // 0000008C5BF8: 7E28030D
	.long 0xd7000205                                           // 0000008C5BFC: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000008C5C00: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C5C04: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000008C5C08: D5207C06 000A0C80
	v_lshl_or_b32 v22, v16, 4, 0x100                           // 0000008C5C10: D6560016 03FD0910 00000100
	.long 0xd7000205                                           // 0000008C5C1C: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000008C5C20: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C5C24: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000008C5C28: D5207C06 000A0C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 0000008C5C30: CA100110 17180112
	.long 0xd700020e                                           // 0000008C5C38: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 0000008C5C3C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C5C40: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000008C5C44: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v13                                     // 0000008C5C4C: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 0000008C5C50: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000008C5C54: 7E22030D
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000008C5C58: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000008C5C5C: 9611860A
	s_mov_b32 s16, 0                                           // 0000008C5C60: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000008C5C64: 8484810A
	s_branch 316                                               // 0000008C5C68: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x75c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000008C5C6C: 8C7E0A7E
	.long 0xd73c0019                                           // 0000008C5C70: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008C5C74: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 0000008C5C78: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 0000008C5C80: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 0000008C5C84: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008C5C88: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 0000008C5C8C: 367804FF 000000FF
	.long 0xd7000349                                           // 0000008C5C94: D7000349
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000008C5C98: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C5C9C: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s3                 // 0000008C5CA0: D5207C4A 000E3407
	v_lshlrev_b32_e32 v57, 2, v57                              // 0000008C5CA8: 30727282
	.long 0xd700034d                                           // 0000008C5CAC: D700034D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 0000008C5CB0: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 0000008C5CB4: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s3                 // 0000008C5CBC: D5207C4E 000E9405
	.long 0xd700034f                                           // 0000008C5CC4: D700034F
	v_cndmask_b32_e32 v0, v73, v18, vcc_lo                     // 0000008C5CC8: 02002549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008C5CCC: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s19, v74, s3                // 0000008C5CD0: D5207C50 000E9413
	.long 0xd7000351                                           // 0000008C5CD8: D7000351
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 0000008C5CDC: 02002349
	v_add_co_ci_u32_e64 v82, null, s20, v74, s3                // 0000008C5CE0: D5207C52 000E9414
	s_clause 0x6                                               // 0000008C5CE8: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 0000008C5CEC: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 0000008C5CF4: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 0000008C5CFC: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 0000008C5D04: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 0000008C5D0C: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 0000008C5D14: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 0000008C5D1C: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000008C5D24: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 0000008C5D2C: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 0000008C5D34: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 0000008C5D38: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008C5D3C: 32040496
	ds_load_b32 v83, v58                                       // 0000008C5D40: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 0000008C5D48: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008C5D50: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 0000008C5D58: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 0000008C5D5C: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 0000008C5D64: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 0000008C5D6C: D8D80000 59000039
	s_clause 0x3                                               // 0000008C5D74: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 0000008C5D78: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 0000008C5D80: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 0000008C5D88: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 0000008C5D90: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008C5D98: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008C5DA0: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 0000008C5DA8: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 0000008C5DB0: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 0000008C5DB8: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 0000008C5DC0: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 0000008C5DC8: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 0000008C5DD0: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 0000008C5DD4: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008C5DD8: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 0000008C5DDC: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 0000008C5DE4: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 0000008C5DE8: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008C5DEC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008C5DF0: 360606FF 000003FC
	s_and_b32 s3, exec_lo, s2                                  // 0000008C5DF8: 8B03027E
	.long 0xd700020e                                           // 0000008C5DFC: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 0000008C5E00: 0201410E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C5E04: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008C5E08: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 0000008C5E10: 4A1818FF 00000200
	v_add_nc_u32_e32 v22, 0x100, v22                           // 0000008C5E18: 4A2C2CFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000008C5E20: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000008C5E28: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008C5E2C: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 0000008C5E30: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 0000008C5E38: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C5E3C: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 0000008C5E40: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 0000008C5E48: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 0000008C5E4C: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 0000008C5E54: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 0000008C5E58: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 0000008C5E60: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 0000008C5E64: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 0000008C5E6C: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 0000008C5E70: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000008C5E78: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 0000008C5E80: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 0000008C5E88: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 0000008C5E90: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 0000008C5E98: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 0000008C5E9C: CC1A4022 1C66031C
	s_clause 0x2                                               // 0000008C5EA4: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 0000008C5EA8: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 0000008C5EB0: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 0000008C5EB8: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 0000008C5EC0: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 0000008C5EC8: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 0000008C5ED0: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 0000008C5ED8: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 0000008C5EDC: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 0000008C5EE4: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 0000008C5EEC: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 0000008C5EF4: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 0000008C5EFC: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 0000008C5F04: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 0000008C5F08: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 0000008C5F10: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 0000008C5F14: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 0000008C5F1C: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 0000008C5F20: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 0000008C5F28: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 0000008C5F2C: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 0000008C5F34: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 0000008C5F3C: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 0000008C5F44: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 0000008C5F48: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 0000008C5F50: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 0000008C5F58: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 0000008C5F60: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 0000008C5F68: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 0000008C5F70: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 0000008C5F74: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 0000008C5F7C: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 0000008C5F84: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 0000008C5F8C: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 0000008C5F94: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 0000008C5F98: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 0000008C5F9C: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 0000008C5FA4: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 0000008C5FAC: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 0000008C5FB4: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 0000008C5FBC: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 0000008C5FC4: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 0000008C5FCC: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 0000008C5FD4: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 0000008C5FDC: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 0000008C5FE4: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 0000008C5FEC: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008C5FF4: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 0000008C5FF8: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 0000008C6000: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 0000008C6004: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 0000008C600C: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 0000008C6010: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 0000008C6018: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 0000008C601C: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 0000008C6024: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 0000008C6028: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 0000008C6030: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 0000008C6038: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 0000008C6040: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C6048: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 0000008C604C: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 0000008C6054: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008C605C: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 0000008C6060: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 0000008C6068: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 0000008C6070: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 0000008C6074: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 0000008C607C: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 0000008C6084: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 0000008C608C: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000008C6094: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 0000008C6098: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 0000008C60A0: 7E080308
	s_waitcnt vmcnt(2)                                         // 0000008C60A4: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 0000008C60A8: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 0000008C60B0: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 0000008C60B4: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 0000008C60BC: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 0000008C60C0: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 0000008C60C8: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 0000008C60CC: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 0000008C60D4: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 0000008C60D8: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 0000008C60E0: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 0000008C60E8: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 0000008C60F0: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 0000008C60F4: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 0000008C60FC: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 0000008C6100: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 0000008C6108: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 0000008C6110: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 0000008C6118: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 0000008C611C: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 0000008C6124: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 0000008C612C: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 0000008C6134: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 0000008C613C: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 0000008C6140: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 0000008C6144: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000008C6148: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 0000008C614C: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008C6154: 917E107E
	s_cbranch_execz 25                                         // 0000008C6158: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_waitcnt vmcnt(0)                                         // 0000008C615C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 16, v23    // 0000008C6160: CA200102 06162E90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008C6168: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008C6170: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C6174: BF870003
	.long 0xd4430002                                           // 0000008C6178: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008C617C: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 0000008C6180: BE8A007E
	.long 0xd4c4007e                                           // 0000008C6184: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000008C6188: 02022E0E
	s_cbranch_execz 65207                                      // 0000008C618C: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	.long 0xd7000305                                           // 0000008C6190: D7000305
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 0000008C6194: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C6198: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000008C619C: D5207C06 000E0080
	global_load_d16_b16 v24, v[14:15], off                     // 0000008C61A4: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000008C61AC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000008C61B4: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000008C61B8: 7E301718
	s_branch 65195                                             // 0000008C61BC: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008C61C0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008C61C4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008C61C8: 8C7E0F7E
	.long 0xd71f0000                                           // 0000008C61CC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008C61D0: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000008C61D4: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000008C61D8: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 0000008C61DC: 3A0A0084
	v_xor_b32_e32 v11, 2, v0                                   // 0000008C61E0: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C61E4: BF870093
	.long 0xd44c0002                                           // 0000008C61E8: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000008C61EC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000008C61F0: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008C61F8: BF870114
	.long 0xd44c0002                                           // 0000008C61FC: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008C6200: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008C6204: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008C6208: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000008C620C: D5010005 000A0B00
	.long 0xd44c0002                                           // 0000008C6214: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000008C6218: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 0000008C621C: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 0000008C6224: D501000B 000A1700
	s_waitcnt lgkmcnt(0)                                       // 0000008C622C: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000008C6230: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 0000008C6234: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 0000008C623C: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 0000008C6244: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 0000008C624C: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000008C6250: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 0000008C6258: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 0000008C6260: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 0000008C6264: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 0000008C6268: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 0000008C6270: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 0000008C6274: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 0000008C627C: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 0000008C6284: BF89FC17
	v_add_f32_e32 v6, v4, v8                                   // 0000008C6288: 060C1104
	ds_bpermute_b32 v5, v5, v1                                 // 0000008C628C: DACC0000 05000105
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000008C6294: 30161682
	ds_bpermute_b32 v8, v11, v6                                // 0000008C6298: DACC0000 0800060B
	s_waitcnt lgkmcnt(1)                                       // 0000008C62A0: BF89FC17
	v_add_f32_e32 v1, v1, v5                                   // 0000008C62A4: 06020B01
	v_xor_b32_e32 v5, 1, v0                                    // 0000008C62A8: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C62AC: BF870091
	.long 0xd44c0002                                           // 0000008C62B0: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000008C62B4: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000008C62B8: D5010000 000A0B00
	v_add_f32_e32 v3, v3, v7                                   // 0000008C62C0: 06060F03
	.long 0xd44a0002                                           // 0000008C62C4: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000008C62C8: 02022080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008C62CC: BF870003
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000008C62D0: 30180082
	s_waitcnt lgkmcnt(0)                                       // 0000008C62D4: BF89FC07
	v_add_f32_e32 v0, v6, v8                                   // 0000008C62D8: 06001106
	ds_bpermute_b32 v4, v11, v2                                // 0000008C62DC: DACC0000 0400020B
	ds_bpermute_b32 v7, v11, v3                                // 0000008C62E4: DACC0000 0700030B
	s_and_b32 s2, s2, vcc_lo                                   // 0000008C62EC: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 0000008C62F0: BF89FC07
	v_dual_add_f32 v5, v2, v4 :: v_dual_add_f32 v4, v3, v7     // 0000008C62F4: C9080902 05040F03
	ds_bpermute_b32 v11, v11, v1                               // 0000008C62FC: DACC0000 0B00010B
	ds_bpermute_b32 v2, v12, v0                                // 0000008C6304: DACC0000 0200000C
	ds_bpermute_b32 v6, v12, v5                                // 0000008C630C: DACC0000 0600050C
	ds_bpermute_b32 v7, v12, v4                                // 0000008C6314: DACC0000 0700040C
	s_waitcnt lgkmcnt(3)                                       // 0000008C631C: BF89FC37
	v_add_f32_e32 v1, v1, v11                                  // 0000008C6320: 06021701
	ds_bpermute_b32 v3, v12, v1                                // 0000008C6324: DACC0000 0300010C
	s_and_saveexec_b32 s3, s2                                  // 0000008C632C: BE832002
	s_cbranch_execz 100                                        // 0000008C6330: BFA50064 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xac4>
	v_ashrrev_i32_e32 v8, 31, v10                              // 0000008C6334: 3410149F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008C6338: F4040080 F8000040
	s_lshr_b32 s0, s13, 31                                     // 0000008C6340: 85009F0D
	s_waitcnt lgkmcnt(0)                                       // 0000008C6344: BF89FC07
	v_dual_mov_b32 v14, s8 :: v_dual_add_f32 v7, v4, v7        // 0000008C6348: CA080008 0E060F04
	v_lshrrev_b32_e32 v8, 23, v8                               // 0000008C6350: 32101097
	s_add_u32 s4, s12, s0                                      // 0000008C6354: 8004000C
	s_addc_u32 s5, s13, 0                                      // 0000008C6358: 8205800D
	v_mov_b32_e32 v13, s9                                      // 0000008C635C: 7E1A0209
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6360: BF870092
	.long 0xd7006a08                                           // 0000008C6364: D7006A08
	v_cndmask_b32_e32 v1, v9, v8, vcc_lo                       // 0000008C6368: 02021109
	v_add_co_ci_u32_e64 v11, null, 0, v10, vcc_lo              // 0000008C636C: D5207C0B 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6374: BF870092
	v_and_b32_e32 v12, 0xfffffe00, v8                          // 0000008C6378: 361810FF FFFFFE00
	.long 0xd7016a08                                           // 0000008C6380: D7016A08
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000008C6384: 02021909
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008C6388: BF8701A1
	v_sub_co_ci_u32_e64 v9, null, v10, v11, vcc_lo             // 0000008C638C: D5217C09 01AA170A
	.long 0x7f143880                                           // 0000008C6394: 7F143880
	.long 0xd7000004                                           // 0000008C6398: D7000004
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 0000008C639C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008C63A4: BF870153
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 0000008C63A8: 7CA810FF 00000100
	v_add_f32_e32 v6, v5, v6                                   // 0000008C63B0: 060C0D05
	v_add_co_ci_u32_e64 v5, null, -1, v9, s0                   // 0000008C63B4: D5207C05 000212C1
	.long 0x7e143987                                           // 0000008C63BC: 7E143987
	s_ashr_i64 s[0:1], s[4:5], 1                               // 0000008C63C0: 86808104
	v_dual_cndmask_b32 v4, v4, v8 :: v_dual_cndmask_b32 v5, v5, v9// 0000008C63C4: CA521104 04041305
	v_cndmask_b32_e32 v13, s3, v13, vcc_lo                     // 0000008C63CC: 021A1A03
	.long 0x7e103986                                           // 0000008C63D0: 7E103986
	.long 0x7f10398a                                           // 0000008C63D4: 7F10398A
	v_cndmask_b32_e32 v9, s2, v14, vcc_lo                      // 0000008C63D8: 02121C02
	.long 0xd73c0004                                           // 0000008C63DC: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000008C63E0: 02020881
	v_and_b32_e32 v14, 1, v10                                  // 0000008C63E4: 361C1481
	s_and_b32 s2, s4, -2                                       // 0000008C63E8: 8B02C204
	v_and_b32_e32 v8, 1, v8                                    // 0000008C63EC: 36101081
	.long 0xd7006a09                                           // 0000008C63F0: D7006A09
	v_cndmask_b32_e32 v1, v9, v12, vcc_lo                      // 0000008C63F4: 02021909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008C63F8: BF870191
	v_add_co_ci_u32_e64 v11, null, v13, v11, vcc_lo            // 0000008C63FC: D5207C0B 01AA170D
	v_add3_u32 v8, v6, v8, 0x7fff                              // 0000008C6404: D6550008 03FE1106 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008C6410: BF870093
	.long 0xd7006a04                                           // 0000008C6414: D7006A04
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000008C6418: 02020909
	v_add_co_ci_u32_e64 v5, null, v11, v5, vcc_lo              // 0000008C641C: D5207C05 01AA0B0B
	v_add_f32_e32 v11, v0, v2                                  // 0000008C6424: 06160500
	v_add_f32_e32 v9, v1, v3                                   // 0000008C6428: 06120701
	.long 0x7f04398a                                           // 0000008C642C: 7F04398A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008C6430: BF870004
	v_mad_u64_u32 v[0:1], null, s0, 6, v[4:5]                  // 0000008C6434: D6FE7C00 04110C00
	.long 0xd7006a06                                           // 0000008C643C: D7006A06
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C6440: 02000504
	.long 0x7e04398b                                           // 0000008C6444: 7E04398B
	.long 0x7e143989                                           // 0000008C6448: 7E143989
	s_lshl_b64 s[2:3], s[0:1], 2                               // 0000008C644C: 84828200
	v_add3_u32 v12, v7, v14, 0x7fff                            // 0000008C6450: D655000C 03FE1D07 00007FFF
	v_add_co_ci_u32_e64 v7, null, s5, v5, vcc_lo               // 0000008C645C: D5207C07 01AA0A05
	v_and_b32_e32 v13, 1, v2                                   // 0000008C6464: 361A0481
	v_and_b32_e32 v10, 1, v10                                  // 0000008C6468: 36141481
	v_mad_u64_u32 v[1:2], null, s1, 6, v[1:2]                  // 0000008C646C: D6FE7C01 04050C01
	.long 0xd7006a02                                           // 0000008C6474: D7006A02
	v_cndmask_b32_e32 v0, v4, v2, vcc_lo                       // 0000008C6478: 02000504
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008C647C: BF870001
	v_add_co_ci_u32_e64 v3, null, s3, v5, vcc_lo               // 0000008C6480: D5207C03 01AA0A03
	v_add3_u32 v11, v11, v13, 0x7fff                           // 0000008C6488: D655000B 03FE1B0B 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000008C6494: D6550009 03FE1509 00007FFF
	s_clause 0x3                                               // 0000008C64A0: BF850003
	global_store_d16_hi_b16 v[4:5], v8, off                    // 0000008C64A4: DC960000 007C0804
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000008C64AC: DC960000 007C0C06
	global_store_d16_hi_b16 v[2:3], v11, off                   // 0000008C64B4: DC960000 007C0B02
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000008C64BC: DC960000 007C0900
	s_endpgm                                                   // 0000008C64C4: BFB00000
		...

