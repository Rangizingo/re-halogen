00000000007e8f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007E8F00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 0000007E8F08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007E8F10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007E8F14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E8F18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 0000007E8F1C: CA220080 10000282
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000007E8F24: 84828302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000007E8F28: BF870482
	v_dual_mov_b32 v9, s3 :: v_dual_and_b32 v2, 60, v2         // 0000007E8F2C: CA240003 090204BC
	.long 0x7f183880                                           // 0000007E8F34: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 0000007E8F38: 361E009F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v6, 0              // 0000007E8F3C: CA100080 1B060080
	s_waitcnt lgkmcnt(0)                                       // 0000007E8F44: BF89FC07
	s_clause 0x1                                               // 0000007E8F48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007E8F4C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 0000007E8F54: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000007E8F5C: 32020085
	s_add_u32 s14, s4, s14                                     // 0000007E8F60: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007E8F64: 820F0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007E8F68: BF8704A1
	v_or_b32_e32 v8, s2, v1                                    // 0000007E8F6C: 38100202
	s_lshr_b32 s2, s11, 31                                     // 0000007E8F70: 85029F0B
	s_add_u32 s20, s10, s2                                     // 0000007E8F74: 8014020A
	s_addc_u32 s21, s11, 0                                     // 0000007E8F78: 8215800B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E8F7C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 0000007E8F80: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 0000007E8F84: 7E0A0280
	s_ashr_i32 s22, s11, 31                                    // 0000007E8F88: 86169F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 0000007E8F8C: 02141080
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007E8F90: D501000E 01A80680
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007E8F98: 86828114
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E8F9C: BF870002
	.long 0xd72c000d                                           // 0000007E8FA0: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 0000007E8FA4: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 0000007E8FA8: D6FE7C01 02021412
	.long 0xd72c0011                                           // 0000007E8FB0: D72C0011
	v_cndmask_b32_e32 v0, v10, v3, vcc_lo                      // 0000007E8FB4: 0200070A
	.long 0xd72c0013                                           // 0000007E8FB8: D72C0013
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007E8FBC: 0200050E
	s_lshr_b32 s19, s22, 27                                    // 0000007E8FC0: 85139B16
	s_waitcnt vmcnt(1)                                         // 0000007E8FC4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 0000007E8FC8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 0000007E8FD0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 0000007E8FD4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E8FDC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 0000007E8FE0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s2, s[14:15]            // 0000007E8FEC: D6FE7C0A 0038050A
	s_add_u32 s14, s10, s19                                    // 0000007E8FF4: 800E130A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 0000007E8FF8: D6550007 03FE2507 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000007E9004: 820F800B
	.long 0x7e183983                                           // 0000007E9008: 7E183983
	.long 0xd72c0003                                           // 0000007E900C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007E9010: 02021C12
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007E9014: 858E850E
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000007E9018: 301C0082
	.long 0xd4440002                                           // 0000007E901C: D4440002
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000007E9020: 02021E0E
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 0000007E9024: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 0000007E9030: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 0000007E9034: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 0000007E903C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 0000007E9044: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 0000007E904C: BF89FC07
	s_barrier                                                  // 0000007E9050: BFBD0000
	buffer_gl0_inv                                             // 0000007E9054: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007E905C: BE8F2002
	s_cbranch_execz 26                                         // 0000007E9060: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s3, s4, s16                                      // 0000007E9064: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007E9068: 82121105
	v_lshlrev_b32_e32 v2, 1, v15                               // 0000007E906C: 30041E81
	.long 0xd7000303                                           // 0000007E9070: D7000303
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 0000007E9074: 02020203
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9078: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s18, v0, s3                  // 0000007E907C: D5207C04 000E0012
	v_lshlrev_b32_e32 v5, 4, v15                               // 0000007E9084: 300A1E84
	.long 0xd7000302                                           // 0000007E9088: D7000302
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 0000007E908C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E9090: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 0000007E9094: D5207C03 000E0880
	.long 0xd7000304                                           // 0000007E909C: D7000304
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 0000007E90A0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E90A4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s3                   // 0000007E90A8: D5207C05 000E2280
	s_clause 0x1                                               // 0000007E90B0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000007E90B4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000007E90BC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000007E90C4: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 0000007E90C8: 7E361702
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007E90CC: 8C7E0F7E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000007E90D0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000007E90D8: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000007E90E0: CA100080 16160080
	s_and_saveexec_b32 s15, s2                                 // 0000007E90E8: BE8F2002
	s_cbranch_execz 597                                        // 0000007E90EC: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xb44>
	s_mul_i32 s2, s11, 6                                       // 0000007E90F0: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000007E90F4: 9683860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000007E90F8: CA22010F 19021E81
	s_add_i32 s20, s3, s2                                      // 0000007E9100: 81140203
	.long 0xd7000201                                           // 0000007E9104: D7000201
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000007E9108: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E910C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s2                  // 0000007E9110: D5207C00 000A0011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 0000007E9118: CA220080 0C0A1E85
	.long 0xd7000201                                           // 0000007E9120: D7000201
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000007E9124: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9128: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s2                    // 0000007E912C: D5207C00 000A0080
	v_lshl_or_b32 v24, v15, 4, 0x200                           // 0000007E9134: D6560018 03FD090F 00000200
	.long 0xd7000201                                           // 0000007E9140: D7000201
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000007E9144: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9148: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s2                   // 0000007E914C: D5207C00 000A0005
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 0000007E9154: CA10010C 171A011B
	.long 0xd700020d                                           // 0000007E915C: D700020D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 0000007E9160: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E9164: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s2                   // 0000007E9168: D5207C0E 000A0080
	v_mov_b32_e32 v22, v12                                     // 0000007E9170: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 0000007E9174: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 0000007E9178: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 0000007E917C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 0000007E9180: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 0000007E9184: 7E20030C
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000007E9188: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000007E918C: 9611860A
	s_mov_b32 s16, 0                                           // 0000007E9190: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007E9194: 8484810A
	s_branch 528                                               // 0000007E9198: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007E919C: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 0000007E91A0: 363808FF 000000FF
	s_and_b32 s2, exec_lo, s2                                  // 0000007E91A8: 8B02027E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000007E91AC: 4A3030FF 00000200
	s_or_b32 s16, s2, s16                                      // 0000007E91B4: 8C101002
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E91B8: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000007E91BC: 30383882
	ds_load_b32 v44, v28                                       // 0000007E91C0: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000007E91C8: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007E91CC: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 0000007E91D4: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 0000007E91DC: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007E91E0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E91E4: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007E91E8: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E91F0: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 0000007E91F8: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 0000007E9200: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000007E9208: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E9210: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E9214: 30080882
	ds_load_b32 v48, v4                                        // 0000007E9218: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 0000007E9220: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E9224: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 0000007E922C: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 0000007E9234: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E9238: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E923C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 0000007E9244: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 0000007E924C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E9250: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 0000007E9258: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 0000007E9260: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E9268: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E926C: 30080882
	ds_load_b32 v52, v4                                        // 0000007E9270: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 0000007E9278: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E927C: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 0000007E9284: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 0000007E928C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E9290: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E9294: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 0000007E929C: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000007E92A4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E92A8: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000007E92B0: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000007E92B8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E92C0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007E92C4: 30080882
	ds_load_b32 v56, v4                                        // 0000007E92C8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000007E92D0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E92D4: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000007E92DC: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000007E92E4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E92E8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E92EC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000007E92F4: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000007E92FC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007E9300: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 0000007E9308: D8D80000 3B000004
	.long 0xd73c0004                                           // 0000007E9310: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000007E9314: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 0000007E9318: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9320: BF870092
	.long 0xd7000228                                           // 0000007E9324: D7000228
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007E9328: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s2                  // 0000007E932C: D5207C29 000A0A07
	s_clause 0x3                                               // 0000007E9334: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 0000007E9338: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 0000007E9340: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 0000007E9348: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 0000007E9350: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007E9358: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E935C: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 0000007E9364: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9368: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E936C: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 0000007E9374: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E9378: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 0000007E9380: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9384: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E9388: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007E9390: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E9394: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 0000007E939C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E93A0: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E93A4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 0000007E93AC: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E93B0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 0000007E93B8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E93BC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E93C0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007E93C8: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E93CC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 0000007E93D4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E93D8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E93DC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 0000007E93E4: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E93E8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 0000007E93F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E93F4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E93F8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007E9400: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E9404: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E940C: D7000224
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 0000007E9410: 02000928
	s_waitcnt lgkmcnt(2)                                       // 0000007E9414: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007E9418: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E941C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s2                 // 0000007E9424: D5207C25 000A5205
	.long 0xd700022a                                           // 0000007E942C: D700022A
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000007E9430: 02002528
	s_waitcnt lgkmcnt(1)                                       // 0000007E9434: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E9438: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s19, v41, s2                // 0000007E9440: D5207C2B 000A5213
	.long 0xd7000228                                           // 0000007E9448: D7000228
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 0000007E944C: 02002328
	s_waitcnt lgkmcnt(0)                                       // 0000007E9450: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E9454: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E9458: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s20, v41, s2                // 0000007E9460: D5207C29 000A5214
	v_fmac_f32_e32 v23, v27, v4                                // 0000007E9468: 562E091B
	s_clause 0x3                                               // 0000007E946C: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E9470: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E9478: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E9480: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E9488: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E9490: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9494: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E949C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E94A0: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E94A8: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E94B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E94B4: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E94BC: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E94C0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E94C8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E94CC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E94D4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E94DC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E94E0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E94E8: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E94EC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E94F4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E94F8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E9500: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9508: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E950C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E9514: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E9518: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9520: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E9524: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E952C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9534: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E9538: CC1A4004 1C127727
	v_fmac_f32_e32 v22, v27, v4                                // 0000007E9540: 562C091B
	s_clause 0x3                                               // 0000007E9544: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 0000007E9548: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 0000007E9550: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 0000007E9558: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 0000007E9560: DC5E0030 247C002A
	.long 0xd700022a                                           // 0000007E9568: D700022A
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000007E956C: 0200252A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E9570: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s19, v43, s2                // 0000007E9574: D5207C2B 000A5613
	s_waitcnt vmcnt(3)                                         // 0000007E957C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9580: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E9588: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9590: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E9594: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E959C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E95A4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E95A8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E95AC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E95B4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E95BC: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E95C0: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E95C8: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E95D0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E95D4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E95D8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E95E0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E95E8: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E95EC: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E95F4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E95FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9600: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E9604: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E960C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9614: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E9618: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E9620: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E9628: BF870001
	v_fmac_f32_e32 v21, v27, v4                                // 0000007E962C: 562A091B
	s_clause 0x3                                               // 0000007E9630: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 0000007E9634: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 0000007E963C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 0000007E9644: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 0000007E964C: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 0000007E9654: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9658: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9660: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E9664: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E966C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9674: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E9678: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E9680: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E9684: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E968C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E9690: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E9698: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E96A0: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E96A4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E96AC: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E96B0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E96B8: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E96BC: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E96C4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E96CC: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E96D0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E96D8: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E96DC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E96E4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E96E8: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E96F0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E96F8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E96FC: CC1A4004 1C127727
	v_fmac_f32_e32 v20, v27, v4                                // 0000007E9704: 5628091B
	s_clause 0x3                                               // 0000007E9708: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 0000007E970C: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 0000007E9714: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 0000007E971C: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 0000007E9724: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 0000007E972C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9730: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9738: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E973C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E9744: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E974C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E9750: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E9758: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E975C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9764: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E9768: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E9770: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9778: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E977C: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E9784: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E9788: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9790: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E9794: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E979C: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E97A4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E97A8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E97B0: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E97B4: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E97BC: D7000224
	v_cndmask_b32_e32 v0, v40, v18, vcc_lo                     // 0000007E97C0: 02002528
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E97C4: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E97C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v41, s2                // 0000007E97D0: D5207C25 000A5213
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E97D8: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E97E0: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E97E4: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 0000007E97EC: 5626091B
	s_clause 0x3                                               // 0000007E97F0: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E97F4: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E97FC: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E9804: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E980C: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E9814: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9818: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9820: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E9824: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E982C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9834: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E9838: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007E9840: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E9844: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E984C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E9850: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E9858: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9860: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E9864: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E986C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E9870: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9878: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E987C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E9884: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E988C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E9890: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E9898: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E989C: CC1A4004 1C127124
	.long 0xd7000224                                           // 0000007E98A4: D7000224
	v_cndmask_b32_e32 v0, v42, v18, vcc_lo                     // 0000007E98A8: 0200252A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E98AC: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E98B0: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s19, v43, s2                // 0000007E98B8: D5207C25 000A5613
	.long 0xd700020d                                           // 0000007E98C0: D700020D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 0000007E98C4: 0201810D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E98C8: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s2                  // 0000007E98D0: D5207C0E 000A1C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E98D8: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E98DC: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 0000007E98E4: 5624091B
	s_clause 0x3                                               // 0000007E98E8: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007E98EC: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007E98F4: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007E98FC: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 0000007E9904: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 0000007E990C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 0000007E9910: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E9918: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007E991C: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 0000007E9924: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007E9928: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 0000007E9930: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E9934: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007E9938: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 0000007E9940: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 0000007E9944: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007E9948: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9950: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007E9954: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007E995C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9964: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007E9968: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007E9970: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007E9974: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E997C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007E9980: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007E9988: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9990: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007E9994: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007E999C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007E99A0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E99A8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007E99AC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007E99B4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E99BC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007E99C0: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 0000007E99C8: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 0000007E99CC: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007E99D4: 917E107E
	s_cbranch_execz 25                                         // 0000007E99D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	s_waitcnt vmcnt(0)                                         // 0000007E99DC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007E99E0: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 32, v25    // 0000007E99E4: CA200104 001832A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000007E99EC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000007E99F4: 7E060307
	.long 0xd4430002                                           // 0000007E99F8: D4430002
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 0000007E99FC: 0202320E
	s_mov_b32 s10, exec_lo                                     // 0000007E9A00: BE8A007E
	.long 0xd4c4007e                                           // 0000007E9A04: D4C4007E
	v_cndmask_b32_e32 v1, s14, v25, vcc_lo                     // 0000007E9A08: 0202320E
	s_cbranch_execz 64995                                      // 0000007E9A0C: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000300                                           // 0000007E9A10: D7000300
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 0000007E9A14: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E9A18: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s3                   // 0000007E9A1C: D5207C01 000E2280
	global_load_d16_b16 v26, v[13:14], off                     // 0000007E9A24: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 0000007E9A2C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 0000007E9A34: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 0000007E9A38: 7E34171A
	s_branch 64983                                             // 0000007E9A3C: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007E9A40: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9A44: BF8700A9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007E9A48: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007E9A4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007E9A50: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007E9A54: 3A020090
	v_xor_b32_e32 v10, 8, v0                                   // 0000007E9A58: 3A140088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9A5C: BF870092
	.long 0xd44c0002                                           // 0000007E9A60: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007E9A64: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007E9A68: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9A70: BF870113
	.long 0xd44c0002                                           // 0000007E9A74: D44C0002
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 0000007E9A78: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007E9A7C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E9A80: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s2                         // 0000007E9A84: D501000A 000A1500
	ds_bpermute_b32 v2, v1, v23                                // 0000007E9A8C: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 0000007E9A94: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 0000007E9A98: 06040517
	ds_bpermute_b32 v3, v1, v22                                // 0000007E9A9C: DACC0000 03001601
	s_waitcnt vmcnt(0)                                         // 0000007E9AA4: BF8903F7
	ds_bpermute_b32 v4, v1, v16                                // 0000007E9AA8: DACC0000 04001001
	ds_bpermute_b32 v5, v1, v21                                // 0000007E9AB0: DACC0000 05001501
	ds_bpermute_b32 v6, v1, v20                                // 0000007E9AB8: DACC0000 06001401
	ds_bpermute_b32 v7, v1, v19                                // 0000007E9AC0: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v18                                // 0000007E9AC8: DACC0000 01001201
	s_waitcnt lgkmcnt(5)                                       // 0000007E9AD0: BF89FC57
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v10, 2, v10// 0000007E9AD4: C9220716 030A1482
	s_waitcnt lgkmcnt(3)                                       // 0000007E9ADC: BF89FC37
	v_dual_add_f32 v4, v16, v4 :: v_dual_add_f32 v5, v21, v5   // 0000007E9AE0: C9080910 04040B15
	ds_bpermute_b32 v13, v10, v2                               // 0000007E9AE8: DACC0000 0D00020A
	s_waitcnt lgkmcnt(2)                                       // 0000007E9AF0: BF89FC27
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v7, v19, v7   // 0000007E9AF4: C9080D14 06060F13
	s_waitcnt lgkmcnt(1)                                       // 0000007E9AFC: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 0000007E9B00: 06020312
	ds_bpermute_b32 v11, v10, v4                               // 0000007E9B04: DACC0000 0B00040A
	ds_bpermute_b32 v12, v10, v3                               // 0000007E9B0C: DACC0000 0C00030A
	ds_bpermute_b32 v16, v10, v5                               // 0000007E9B14: DACC0000 1000050A
	v_xor_b32_e32 v18, 4, v0                                   // 0000007E9B1C: 3A240084
	ds_bpermute_b32 v14, v10, v6                               // 0000007E9B20: DACC0000 0E00060A
	.long 0xd44c0002                                           // 0000007E9B28: D44C0002
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 0000007E9B2C: 020224A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E9B30: BF870131
	v_cndmask_b32_e64 v18, v0, v18, s2                         // 0000007E9B34: D5010012 000A2500
	s_waitcnt lgkmcnt(4)                                       // 0000007E9B3C: BF89FC47
	v_add_f32_e32 v2, v2, v13                                  // 0000007E9B40: 06041B02
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007E9B44: 30242482
	ds_bpermute_b32 v17, v10, v1                               // 0000007E9B48: DACC0000 1100010A
	ds_bpermute_b32 v10, v10, v7                               // 0000007E9B50: DACC0000 0A00070A
	s_waitcnt lgkmcnt(4)                                       // 0000007E9B58: BF89FC47
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v12   // 0000007E9B5C: C9081704 04021903
	s_waitcnt lgkmcnt(3)                                       // 0000007E9B64: BF89FC37
	v_add_f32_e32 v5, v5, v16                                  // 0000007E9B68: 060A2105
	ds_bpermute_b32 v12, v18, v2                               // 0000007E9B6C: DACC0000 0C000212
	s_waitcnt lgkmcnt(3)                                       // 0000007E9B74: BF89FC37
	v_add_f32_e32 v6, v6, v14                                  // 0000007E9B78: 060C1D06
	ds_bpermute_b32 v11, v18, v3                               // 0000007E9B7C: DACC0000 0B000312
	ds_bpermute_b32 v14, v18, v5                               // 0000007E9B84: DACC0000 0E000512
	s_waitcnt lgkmcnt(4)                                       // 0000007E9B8C: BF89FC47
	v_add_f32_e32 v1, v1, v17                                  // 0000007E9B90: 06022301
	s_waitcnt lgkmcnt(3)                                       // 0000007E9B94: BF89FC37
	v_add_f32_e32 v7, v7, v10                                  // 0000007E9B98: 060E1507
	ds_bpermute_b32 v10, v18, v4                               // 0000007E9B9C: DACC0000 0A000412
	ds_bpermute_b32 v13, v18, v6                               // 0000007E9BA4: DACC0000 0D000612
	ds_bpermute_b32 v16, v18, v1                               // 0000007E9BAC: DACC0000 10000112
	s_waitcnt lgkmcnt(5)                                       // 0000007E9BB4: BF89FC57
	v_add_f32_e32 v2, v2, v12                                  // 0000007E9BB8: 06041902
	ds_bpermute_b32 v17, v18, v7                               // 0000007E9BBC: DACC0000 11000712
	v_xor_b32_e32 v18, 2, v0                                   // 0000007E9BC4: 3A240082
	v_xor_b32_e32 v12, 1, v0                                   // 0000007E9BC8: 3A180081
	s_waitcnt lgkmcnt(4)                                       // 0000007E9BCC: BF89FC47
	v_add_f32_e32 v5, v5, v14                                  // 0000007E9BD0: 060A1D05
	v_add_f32_e32 v3, v3, v11                                  // 0000007E9BD4: 06061703
	.long 0xd44c0002                                           // 0000007E9BD8: D44C0002
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 0000007E9BDC: 020224A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007E9BE0: BF8701C1
	v_cndmask_b32_e64 v18, v0, v18, s2                         // 0000007E9BE4: D5010012 000A2500
	.long 0xd44c0002                                           // 0000007E9BEC: D44C0002
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 0000007E9BF0: 020218A0
	s_waitcnt lgkmcnt(3)                                       // 0000007E9BF4: BF89FC37
	v_add_f32_e32 v10, v4, v10                                 // 0000007E9BF8: 06141504
	v_lshlrev_b32_e32 v18, 2, v18                              // 0000007E9BFC: 30242482
	s_waitcnt lgkmcnt(1)                                       // 0000007E9C00: BF89FC17
	v_dual_add_f32 v4, v6, v13 :: v_dual_add_f32 v1, v1, v16   // 0000007E9C04: C9081B06 04002101
	v_cndmask_b32_e64 v0, v0, v12, s2                          // 0000007E9C0C: D5010000 000A1900
	s_waitcnt lgkmcnt(0)                                       // 0000007E9C14: BF89FC07
	v_add_f32_e32 v11, v7, v17                                 // 0000007E9C18: 06162307
	ds_bpermute_b32 v6, v18, v3                                // 0000007E9C1C: DACC0000 06000312
	ds_bpermute_b32 v7, v18, v2                                // 0000007E9C24: DACC0000 07000212
	ds_bpermute_b32 v14, v18, v4                               // 0000007E9C2C: DACC0000 0E000412
	ds_bpermute_b32 v16, v18, v5                               // 0000007E9C34: DACC0000 10000512
	ds_bpermute_b32 v17, v18, v1                               // 0000007E9C3C: DACC0000 11000112
	v_lshlrev_b32_e32 v20, 2, v0                               // 0000007E9C44: 30280082
	ds_bpermute_b32 v19, v18, v11                              // 0000007E9C48: DACC0000 13000B12
	ds_bpermute_b32 v18, v18, v10                              // 0000007E9C50: DACC0000 12000A12
	.long 0xd44a0002                                           // 0000007E9C58: D44A0002
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 0000007E9C5C: 02021E80
	s_and_b32 s2, s2, vcc_lo                                   // 0000007E9C60: 8B026A02
	s_waitcnt lgkmcnt(5)                                       // 0000007E9C64: BF89FC57
	v_dual_add_f32 v12, v3, v6 :: v_dual_add_f32 v13, v2, v7   // 0000007E9C68: C9080D03 0C0C0F02
	s_waitcnt lgkmcnt(3)                                       // 0000007E9C70: BF89FC37
	v_dual_add_f32 v6, v4, v14 :: v_dual_add_f32 v7, v5, v16   // 0000007E9C74: C9081D04 06062105
	s_waitcnt lgkmcnt(2)                                       // 0000007E9C7C: BF89FC27
	v_add_f32_e32 v0, v1, v17                                  // 0000007E9C80: 06002301
	ds_bpermute_b32 v14, v20, v12                              // 0000007E9C84: DACC0000 0E000C14
	s_waitcnt lgkmcnt(1)                                       // 0000007E9C8C: BF89FC17
	v_dual_add_f32 v4, v11, v19 :: v_dual_add_f32 v1, v10, v18 // 0000007E9C90: C908270B 0400250A
	ds_bpermute_b32 v16, v20, v13                              // 0000007E9C98: DACC0000 10000D14
	ds_bpermute_b32 v11, v20, v7                               // 0000007E9CA0: DACC0000 0B000714
	ds_bpermute_b32 v10, v20, v6                               // 0000007E9CA8: DACC0000 0A000614
	ds_bpermute_b32 v5, v20, v4                                // 0000007E9CB0: DACC0000 05000414
	ds_bpermute_b32 v2, v20, v0                                // 0000007E9CB8: DACC0000 02000014
	ds_bpermute_b32 v3, v20, v1                                // 0000007E9CC0: DACC0000 03000114
	s_and_saveexec_b32 s3, s2                                  // 0000007E9CC8: BE832002
	s_cbranch_execz 378                                        // 0000007E9CCC: BFA5017A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x13b8>
	s_waitcnt lgkmcnt(5)                                       // 0000007E9CD0: BF89FC57
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v14// 0000007E9CD4: C908210D 0D0C1D0C
	.long 0x7f1e3880                                           // 0000007E9CDC: 7F1E3880
	s_load_b32 s1, s[0:1], 0x48                                // 0000007E9CE0: F4000040 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000007E9CE8: BF89FC07
	v_add_f32_e32 v6, v6, v10                                  // 0000007E9CEC: 060C1506
	.long 0x7e1c398d                                           // 0000007E9CF0: 7E1C398D
	.long 0x7e1e398c                                           // 0000007E9CF4: 7E1E398C
	.long 0x7f1c398f                                           // 0000007E9CF8: 7F1C398F
	.long 0x7f14398f                                           // 0000007E9CFC: 7F14398F
	v_add_f32_e32 v4, v4, v5                                   // 0000007E9D00: 06080B04
	v_add_f32_e32 v0, v0, v2                                   // 0000007E9D04: 06000500
	v_and_b32_e32 v16, 1, v15                                  // 0000007E9D08: 36201E81
	v_and_b32_e32 v14, 1, v14                                  // 0000007E9D0C: 361C1C81
	.long 0x7f3a398f                                           // 0000007E9D10: 7F3A398F
	.long 0x7f3e398f                                           // 0000007E9D14: 7F3E398F
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000007E9D18: 8484820C
	v_add3_u32 v12, v12, v16, 0x7fff                           // 0000007E9D1C: D655000C 03FE210C 00007FFF
	v_add3_u32 v13, v13, v14, 0x7fff                           // 0000007E9D28: D655000D 03FE1D0D 00007FFF
	.long 0x7f40398f                                           // 0000007E9D34: 7F40398F
	v_add_f32_e32 v7, v7, v11                                  // 0000007E9D38: 060E1707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9D3C: BF870214
	v_dual_add_f32 v1, v1, v3 :: v_dual_and_b32 v12, 0xffff0000, v12// 0000007E9D40: C9240701 010C18FF FFFF0000
	v_and_b32_e32 v13, 0xffff0000, v13                         // 0000007E9D4C: 361A1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E9D54: BF870193
	.long 0x7e143987                                           // 0000007E9D58: 7E143987
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007E9D5C: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9D64: BF870214
	v_mul_f32_e32 v12, s1, v12                                 // 0000007E9D68: 10181801
	v_mul_f32_e32 v16, s1, v13                                 // 0000007E9D6C: 10201A01
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9D70: BF870214
	v_and_b32_e32 v10, 1, v10                                  // 0000007E9D74: 36141481
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007E9D78: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9D84: BF870214
	v_mul_f32_e32 v14, 0xbfb8aa3b, v12                         // 0000007E9D88: 101C18FF BFB8AA3B
	v_mul_f32_e32 v13, 0xbfb8aa3b, v16                         // 0000007E9D90: 101A20FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9D98: BF870214
	v_add3_u32 v7, v7, v10, 0x7fff                             // 0000007E9D9C: D6550007 03FE1507 00007FFF
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007E9DA8: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E9DB0: BF870194
	v_exp_f32_e32 v14, v14                                     // 0000007E9DB4: 7E1C4B0E
	v_exp_f32_e32 v13, v13                                     // 0000007E9DB8: 7E1A4B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E9DBC: BF870292
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000007E9DC0: 360E0EFF FFFF0000
	v_add_f32_e32 v17, 1.0, v13                                // 0000007E9DC8: 06221AF2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9DCC: BF870116
	v_add_f32_e32 v13, 1.0, v14                                // 0000007E9DD0: 061A1CF2
	v_div_scale_f32 v14, null, v17, v17, v16                   // 0000007E9DD4: D6FC7C0E 04422311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9DDC: BF870112
	v_div_scale_f32 v18, null, v13, v13, v12                   // 0000007E9DE0: D6FC7C12 04321B0D
	v_rcp_f32_e32 v19, v14                                     // 0000007E9DE8: 7E26550E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007E9DEC: BF870311
	v_rcp_f32_e32 v20, v18                                     // 0000007E9DF0: 7E285512
	v_fma_f32 v21, -v14, v19, 1.0                              // 0000007E9DF4: D6130015 23CA270E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9DFC: BF870115
	v_fma_f32 v22, -v18, v20, 1.0                              // 0000007E9E00: D6130016 23CA2912
	v_fmac_f32_e32 v19, v21, v19                               // 0000007E9E08: 56262715
	v_div_scale_f32 v21, s0, v12, v13, v12                     // 0000007E9E0C: D6FC0015 04321B0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E9E14: BF870123
	v_fmac_f32_e32 v20, v22, v20                               // 0000007E9E18: 56282916
	v_div_scale_f32 v23, vcc_lo, v16, v17, v16                 // 0000007E9E1C: D6FC6A17 04422310
	v_mul_f32_e32 v24, v21, v20                                // 0000007E9E24: 10302915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9E28: BF870091
	v_fma_f32 v26, -v18, v24, v21                              // 0000007E9E2C: D613001A 24563112
	v_fmac_f32_e32 v24, v26, v20                               // 0000007E9E34: 5630291A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E9E38: BF8700A1
	v_fma_f32 v18, -v18, v24, v21                              // 0000007E9E3C: D6130012 24563112
	v_mul_f32_e32 v21, s1, v7                                  // 0000007E9E44: 102A0E01
	v_dual_mul_f32 v22, v23, v19 :: v_dual_mul_f32 v7, 0xbfb8aa3b, v21// 0000007E9E48: C8C62717 16062AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9E54: BF870111
	v_fma_f32 v25, -v14, v22, v23                              // 0000007E9E58: D6130019 245E2D0E
	v_exp_f32_e32 v7, v7                                       // 0000007E9E60: 7E0E4B07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9E64: BF870091
	v_fmac_f32_e32 v22, v25, v19                               // 0000007E9E68: 562C2719
	v_fma_f32 v14, -v14, v22, v23                              // 0000007E9E6C: D613000E 245E2D0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000007E9E74: BF8702A1
	v_div_fmas_f32 v19, v14, v19, v22                          // 0000007E9E78: D6370013 045A270E
	s_mov_b32 vcc_lo, s0                                       // 0000007E9E80: BEEA0000
	v_add_f32_e32 v22, 1.0, v7                                 // 0000007E9E84: 062C0EF2
	v_div_fmas_f32 v14, v18, v20, v24                          // 0000007E9E88: D637000E 04622912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E9E90: BF870193
	v_div_fixup_f32 v16, v19, v17, v16                         // 0000007E9E94: D6270010 04422313
	v_div_scale_f32 v24, vcc_lo, v21, v22, v21                 // 0000007E9E9C: D6FC6A18 04562D15
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E9EA4: BF870193
	v_div_fixup_f32 v18, v14, v13, v12                         // 0000007E9EA8: D6270012 04321B0E
	.long 0x7e3a3990                                           // 0000007E9EB0: 7E3A3990
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9EB4: BF870092
	.long 0x7e1e3992                                           // 0000007E9EB8: 7E1E3992
	v_and_b32_e32 v20, 1, v15                                  // 0000007E9EBC: 36281E81
	.long 0x7e1e3986                                           // 0000007E9EC0: 7E1E3986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9EC4: BF870091
	v_and_b32_e32 v11, 1, v15                                  // 0000007E9EC8: 36161E81
	v_add3_u32 v6, v6, v11, 0x7fff                             // 0000007E9ECC: D6550006 03FE1706 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9ED8: BF870091
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000007E9EDC: 360C0CFF FFFF0000
	v_mul_f32_e32 v6, s1, v6                                   // 0000007E9EE4: 100C0C01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9EE8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v6                          // 0000007E9EEC: 10140CFF BFB8AA3B
	v_exp_f32_e32 v10, v10                                     // 0000007E9EF4: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E9EF8: BF870125
	v_add_f32_e32 v7, 1.0, v10                                 // 0000007E9EFC: 060E14F2
	v_div_scale_f32 v10, null, v22, v22, v21                   // 0000007E9F00: D6FC7C0A 04562D16
	v_div_scale_f32 v11, null, v7, v7, v6                      // 0000007E9F08: D6FC7C0B 041A0F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E9F10: BF870092
	v_rcp_f32_e32 v12, v10                                     // 0000007E9F14: 7E18550A
	v_rcp_f32_e32 v13, v11                                     // 0000007E9F18: 7E1A550B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E9F1C: BF870296
	v_fma_f32 v14, -v10, v12, 1.0                              // 0000007E9F20: D613000E 23CA190A
	v_fma_f32 v23, -v11, v13, 1.0                              // 0000007E9F28: D6130017 23CA1B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9F30: BF8701A2
	v_fmac_f32_e32 v12, v14, v12                               // 0000007E9F34: 5618190E
	v_div_scale_f32 v14, s0, v6, v7, v6                        // 0000007E9F38: D6FC000E 041A0F06
	v_fmac_f32_e32 v13, v23, v13                               // 0000007E9F40: 561A1B17
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9F44: BF8701A3
	v_mul_f32_e32 v23, v24, v12                                // 0000007E9F48: 102E1918
	v_add3_u32 v18, v18, v20, 0x7fff                           // 0000007E9F4C: D6550012 03FE2912 00007FFF
	v_mul_f32_e32 v25, v14, v13                                // 0000007E9F58: 10321B0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9F5C: BF870113
	v_fma_f32 v26, -v10, v23, v24                              // 0000007E9F60: D613001A 24622F0A
	v_fma_f32 v27, -v11, v25, v14                              // 0000007E9F68: D613001B 243A330B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E9F70: BF870112
	v_fmac_f32_e32 v23, v26, v12                               // 0000007E9F74: 562E191A
	v_fmac_f32_e32 v25, v27, v13                               // 0000007E9F78: 56321B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E9F7C: BF8701A2
	v_fma_f32 v10, -v10, v23, v24                              // 0000007E9F80: D613000A 24622F0A
	v_mul_f32_e32 v27, s1, v1                                  // 0000007E9F88: 10360201
	v_fma_f32 v5, -v11, v25, v14                               // 0000007E9F8C: D6130005 243A330B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007E9F94: BF870153
	v_div_fmas_f32 v23, v10, v12, v23                          // 0000007E9F98: D6370017 045E190A
	s_mov_b32 vcc_lo, s0                                       // 0000007E9FA0: BEEA0000
	.long 0x7e143984                                           // 0000007E9FA4: 7E143984
	.long 0x7f14398f                                           // 0000007E9FA8: 7F14398F
	v_div_fmas_f32 v5, v5, v13, v25                            // 0000007E9FAC: D6370005 04661B05
	v_and_b32_e32 v3, 1, v10                                   // 0000007E9FB4: 36061481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007E9FB8: BF870232
	v_div_fixup_f32 v24, v5, v7, v6                            // 0000007E9FBC: D6270018 041A0F05
	v_div_fixup_f32 v17, v23, v22, v21                         // 0000007E9FC4: D6270011 04562D17
	v_and_b32_e32 v23, 1, v29                                  // 0000007E9FCC: 362E3A81
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000007E9FD0: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9FDC: BF870214
	.long 0x7e1e3998                                           // 0000007E9FE0: 7E1E3998
	.long 0x7e3e3991                                           // 0000007E9FE4: 7E3E3991
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007E9FE8: BF870214
	v_add3_u32 v16, v16, v23, 0x7fff                           // 0000007E9FEC: D6550010 03FE2F10 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v3                           // 0000007E9FF8: 360406FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007EA000: BF870134
	v_and_b32_e32 v25, 1, v15                                  // 0000007EA004: 36321E81
	.long 0x7e1e3980                                           // 0000007EA008: 7E1E3980
	v_and_b32_e32 v29, 1, v31                                  // 0000007EA00C: 363A3E81
	v_and_b32_e32 v3, 1, v15                                   // 0000007EA010: 36061E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA014: BF870112
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000007EA018: D6550011 03FE3B11 00007FFF
	v_add3_u32 v0, v0, v3, 0x7fff                              // 0000007EA024: D6550000 03FE0700 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA030: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007EA034: 360000FF FFFF0000
	v_mul_f32_e32 v28, s1, v0                                  // 0000007EA03C: 10380001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA040: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v28                          // 0000007EA044: 100838FF BFB8AA3B
	v_exp_f32_e32 v5, v4                                       // 0000007EA04C: 7E0A4B04
	v_mul_f32_e32 v26, s1, v2                                  // 0000007EA050: 10340401
	v_mul_f32_e32 v2, 0xbfb8aa3b, v27                          // 0000007EA054: 100436FF BFB8AA3B
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000007EA05C: 8480810C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007EA060: BF870311
	v_exp_f32_e32 v2, v2                                       // 0000007EA064: 7E044B02
	v_add_f32_e32 v37, 1.0, v5                                 // 0000007EA068: 064A0AF2
	v_mul_f32_e32 v1, 0xbfb8aa3b, v26                          // 0000007EA06C: 100234FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA074: BF870112
	v_div_scale_f32 v39, null, v37, v37, v28                   // 0000007EA078: D6FC7C27 04724B25
	v_exp_f32_e32 v3, v1                                       // 0000007EA080: 7E064B01
	.long 0xd73c0000                                           // 0000007EA084: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000007EA088: 02021081
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA08C: BF870196
	v_add_f32_e32 v33, 1.0, v2                                 // 0000007EA090: 064204F2
	v_rcp_f32_e32 v40, v39                                     // 0000007EA094: 7E505527
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007EA098: BF870311
	v_div_scale_f32 v35, null, v33, v33, v27                   // 0000007EA09C: D6FC7C23 046E4321
	v_add_f32_e32 v30, 1.0, v3                                 // 0000007EA0A4: 063C06F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA0A8: BF870094
	.long 0xd7006a03                                           // 0000007EA0AC: D7006A03
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007EA0B0: 02020008
	v_add_co_ci_u32_e64 v4, null, s9, v1, vcc_lo               // 0000007EA0B4: D5207C04 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA0BC: BF870193
	v_div_scale_f32 v34, null, v30, v30, v26                   // 0000007EA0C0: D6FC7C22 046A3D1E
	.long 0xd7006a05                                           // 0000007EA0C8: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000007EA0CC: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA0D0: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000007EA0D4: D5207C06 01AA0801
	v_rcp_f32_e32 v36, v34                                     // 0000007EA0DC: 7E485522
	.long 0xd7006a07                                           // 0000007EA0E0: D7006A07
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000007EA0E4: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EA0E8: BF870121
	v_add_co_ci_u32_e64 v8, null, s5, v4, vcc_lo               // 0000007EA0EC: D5207C08 01AA0805
	v_rcp_f32_e32 v38, v35                                     // 0000007EA0F4: 7E4C5523
	.long 0xd7006a09                                           // 0000007EA0F8: D7006A09
	v_cndmask_b32_e32 v0, v7, v4, vcc_lo                       // 0000007EA0FC: 02000907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007EA100: BF870311
	v_add_co_ci_u32_e64 v10, null, s5, v8, vcc_lo              // 0000007EA104: D5207C0A 01AA1005
	v_fma_f32 v2, -v34, v36, 1.0                               // 0000007EA10C: D6130002 23CA4922
	v_div_scale_f32 v41, vcc_lo, v26, v30, v26                 // 0000007EA114: D6FC6A29 046A3D1A
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 0000007EA11C: D6FE7C00 040D0C0C
	v_div_scale_f32 v44, s1, v28, v37, v28                     // 0000007EA124: D6FC012C 04724B1C
	v_div_scale_f32 v42, s0, v27, v33, v27                     // 0000007EA12C: D6FC002A 046E431B
	v_fmac_f32_e32 v36, v2, v36                                // 0000007EA134: 56484902
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000007EA138: BF870005
	v_fma_f32 v11, -v35, v38, 1.0                              // 0000007EA13C: D613000B 23CA4D23
	s_clause 0x1                                               // 0000007EA144: BF850001
	global_store_d16_hi_b16 v[3:4], v16, off                   // 0000007EA148: DC960000 007C1003
	global_store_d16_hi_b16 v[5:6], v18, off                   // 0000007EA150: DC960000 007C1205
	v_add3_u32 v5, v24, v25, 0x7fff                            // 0000007EA158: D6550005 03FE3318 00007FFF
	v_mul_f32_e32 v43, v41, v36                                // 0000007EA164: 10564929
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000007EA168: D6FE7C01 04050C0D
	v_fma_f32 v2, -v39, v40, 1.0                               // 0000007EA170: D6130002 23CA5127
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007EA178: BF8701A3
	v_fma_f32 v45, -v34, v43, v41                              // 0000007EA17C: D613002D 24A65722
	v_fmac_f32_e32 v38, v11, v38                               // 0000007EA184: 564C4D0B
	v_fmac_f32_e32 v40, v2, v40                                // 0000007EA188: 56505102
	.long 0xd700020b                                           // 0000007EA18C: D700020B
	v_cndmask_b32_e32 v0, v9, v4, vcc_lo                       // 0000007EA190: 02000909
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007EA194: BF870224
	v_fmac_f32_e32 v43, v45, v36                               // 0000007EA198: 5656492D
	v_add_co_ci_u32_e64 v12, null, s5, v10, s2                 // 0000007EA19C: D5207C0C 000A1405
	v_mul_f32_e32 v46, v44, v40                                // 0000007EA1A4: 105C512C
	.long 0xd700020d                                           // 0000007EA1A8: D700020D
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000007EA1AC: 02000900
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007EA1B0: BF870224
	v_fma_f32 v19, -v34, v43, v41                              // 0000007EA1B4: D6130013 24A65722
	v_add_co_ci_u32_e64 v14, null, s5, v1, s2                  // 0000007EA1BC: D5207C0E 000A0205
	v_fma_f32 v47, -v39, v46, v44                              // 0000007EA1C4: D613002F 24B25D27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007EA1CC: BF870123
	v_div_fmas_f32 v19, v19, v36, v43                          // 0000007EA1D0: D6370013 04AE4913
	s_mov_b32 vcc_lo, s1                                       // 0000007EA1D8: BEEA0001
	v_fmac_f32_e32 v46, v47, v40                               // 0000007EA1DC: 565C512F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA1E0: BF870112
	v_div_fixup_f32 v19, v19, v30, v26                         // 0000007EA1E4: D6270013 046A3D13
	v_fma_f32 v21, -v39, v46, v44                              // 0000007EA1EC: D6130015 24B25D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007EA1F4: BF8701A2
	.long 0x7e403993                                           // 0000007EA1F8: 7E403993
	v_mul_f32_e32 v2, v42, v38                                 // 0000007EA1FC: 10044D2A
	v_div_fmas_f32 v21, v21, v40, v46                          // 0000007EA200: D6370015 04BA5115
	s_mov_b32 vcc_lo, s0                                       // 0000007EA208: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA20C: BF870193
	v_and_b32_e32 v3, 1, v32                                   // 0000007EA210: 36064081
	v_fma_f32 v48, -v35, v2, v42                               // 0000007EA214: D6130030 24AA0523
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA21C: BF870193
	v_div_fixup_f32 v21, v21, v37, v28                         // 0000007EA220: D6270015 04724B15
	v_add3_u32 v3, v19, v3, 0x7fff                             // 0000007EA228: D6550003 03FE0713 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007EA234: BF870193
	v_fmac_f32_e32 v2, v48, v38                                // 0000007EA238: 56044D30
	.long 0x7e1e3995                                           // 0000007EA23C: 7E1E3995
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA240: BF870112
	v_fma_f32 v22, -v35, v2, v42                               // 0000007EA244: D6130016 24AA0523
	v_and_b32_e32 v4, 1, v15                                   // 0000007EA24C: 36081E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007EA250: BF870112
	v_div_fmas_f32 v2, v22, v38, v2                            // 0000007EA254: D6370002 040A4D16
	v_add3_u32 v4, v21, v4, 0x7fff                             // 0000007EA25C: D6550004 03FE0915 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007EA268: BF870092
	v_div_fixup_f32 v2, v2, v33, v27                           // 0000007EA26C: D6270002 046E4302
	v_bfe_u32 v15, v2, 16, 1                                   // 0000007EA274: D610000F 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007EA27C: BF870001
	v_add3_u32 v2, v2, v15, 0x7fff                             // 0000007EA280: D6550002 03FE1F02 00007FFF
	s_clause 0x4                                               // 0000007EA28C: BF850004
	global_store_d16_hi_b16 v[7:8], v17, off                   // 0000007EA290: DC960000 007C1107
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007EA298: DC960000 007C0500
	global_store_d16_hi_b16 v[9:10], v3, off                   // 0000007EA2A0: DC960000 007C0309
	global_store_d16_hi_b16 v[13:14], v4, off                  // 0000007EA2A8: DC960000 007C040D
	global_store_d16_hi_b16 v[11:12], v2, off                  // 0000007EA2B0: DC960000 007C020B
	s_endpgm                                                   // 0000007EA2B8: BFB00000
		...

