0000000000848d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000848D00: F4100100 F8000000
	v_dual_mov_b32 v28, 0 :: v_dual_and_b32 v1, 15, v0         // 000000848D08: CA240080 1C00008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000848D10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000848D14: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000848D18: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000848D1C: BF870193
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000848D20: CA220080 06000282
	v_and_b32_e32 v2, 60, v2                                   // 000000848D28: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 000000848D2C: 321E0085
	.long 0x7f263880                                           // 000000848D30: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v8, 0              // 000000848D34: CA100080 11080080
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v14, 2, v0      // 000000848D3C: CA220080 070E0082
	s_waitcnt lgkmcnt(0)                                       // 000000848D44: BF89FC07
	s_clause 0x1                                               // 000000848D48: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 000000848D4C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000848D54: DC520000 0D040002
	.long 0xd4510014                                           // 000000848D5C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000848D60: 02001802
	s_and_b32 s20, s20, exec_lo                                // 000000848D64: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 000000848D68: 98188003
	s_cselect_b32 s25, s2, 0                                   // 000000848D6C: 98198002
	s_add_u32 s14, s4, s14                                     // 000000848D70: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000848D74: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 000000848D78: 85149F0B
	v_dual_mov_b32 v1, s14 :: v_dual_and_b32 v16, 31, v0       // 000000848D7C: CA24000E 0110009F
	s_add_u32 s20, s10, s20                                    // 000000848D84: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000848D88: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 000000848D8C: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 000000848D90: 86948114
	s_lshr_b32 s22, s22, 27                                    // 000000848D94: 85169B16
	v_mov_b32_e32 v2, s15                                      // 000000848D98: 7E04020F
	s_add_u32 s22, s10, s22                                    // 000000848D9C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 000000848DA0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 000000848DA4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 000000848DA8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000848DAC: BF870499
	s_add_i32 s23, s22, 7                                      // 000000848DB0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 000000848DB4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000848DB8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 000000848DBC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 000000848DC0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000848DC4: BF870009
	s_ashr_i32 s14, s23, 3                                     // 000000848DC8: 860E8317
	s_add_u32 s4, s4, s16                                      // 000000848DCC: 80041004
	s_addc_u32 s5, s5, s17                                     // 000000848DD0: 82051105
	v_mov_b32_e32 v3, s4                                       // 000000848DD4: 7E060204
	.long 0xd72c0012                                           // 000000848DD8: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 000000848DDC: 02021E0E
	v_mov_b32_e32 v4, s5                                       // 000000848DE0: 7E080205
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 000000848DE4: D6FE7C09 04042819
	s_mul_i32 s4, s24, s20                                     // 000000848DEC: 96041418
	s_waitcnt vmcnt(1)                                         // 000000848DF0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 000000848DF4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 000000848DFC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000848E00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000848E08: BF870232
	v_add3_u32 v2, v11, v12, 0x7fff                            // 000000848E0C: D6550002 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 000000848E18: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 000000848E20: 4A06240E
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000848E24: D6550001 03FE030D 00007FFF
	s_mul_i32 s25, s25, s21                                    // 000000848E30: 96191519
	.long 0x7e263982                                           // 000000848E34: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 000000848E38: 4A041404
	v_add_nc_u32_e32 v10, v18, v16                             // 000000848E3C: 4A142112
	v_min_i32_e32 v18, s22, v3                                 // 000000848E40: 22240616
	v_add_nc_u32_e32 v3, s19, v12                              // 000000848E44: 4A061813
	s_mul_i32 s4, s18, s24                                     // 000000848E48: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000848E4C: D6570001 044E02FF FFFF0000
	v_add_nc_u32_e32 v19, s25, v2                              // 000000848E58: 4A260419
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000848E5C: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 000000848E60: 4A280604
	ds_store_b32 v14, v1                                       // 000000848E64: D8340000 0000010E
	s_waitcnt lgkmcnt(0)                                       // 000000848E6C: BF89FC07
	s_barrier                                                  // 000000848E70: BFBD0000
	buffer_gl0_inv                                             // 000000848E74: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 000000848E7C: BE85206A
	s_cbranch_execz 21                                         // 000000848E80: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000848E84: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000848E88: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000848E8C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000848E90: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000848E94: 3408069F
	.long 0xd7000401                                           // 000000848E98: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000848E9C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000848EA0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 000000848EA4: D5207C02 00120514
	.long 0xd7000403                                           // 000000848EAC: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000848EB0: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 000000848EB4: D5207C04 00120913
	s_clause 0x1                                               // 000000848EBC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000848EC0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000848EC8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000848ED0: BF8907F7
	v_cvt_f32_f16_e32 v28, v1                                  // 000000848ED4: 7E381701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000848ED8: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000848EDC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v21, 0             // 000000848EE4: CA100080 18140080
	s_and_saveexec_b32 s5, vcc_lo                              // 000000848EEC: BE85206A
	s_cbranch_execz 460                                        // 000000848EF0: BFA501CC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x924>
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000848EF4: CA200080 180014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000848EFC: CA220080 150C1485
	v_mov_b32_e32 v17, 0                                       // 000000848F04: 7E220280
	s_delay_alu instid0(VALU_DEP_3)                            // 000000848F08: BF870003
	v_dual_mov_b32 v22, 0 :: v_dual_lshlrev_b32 v25, 4, v1     // 000000848F0C: CA220080 16180284
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v26, 1, v1     // 000000848F14: CA220080 171A0281
	v_mov_b32_e32 v27, v28                                     // 000000848F1C: 7E36031C
	s_mul_i32 s4, s11, 6                                       // 000000848F20: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000848F24: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000848F28: 848E820A
	s_add_i32 s16, s16, s4                                     // 000000848F2C: 81100410
	s_mul_i32 s18, s10, 6                                      // 000000848F30: 9612860A
	s_mov_b32 s17, 0                                           // 000000848F34: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000848F38: 848A810A
	s_branch 409                                               // 000000848F3C: BFA00199 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x8a4>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000848F40: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 000000848F44: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 000000848F4C: 8B046A7E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 000000848F50: 4A3232FF 00000200
	s_or_b32 s17, s4, s17                                      // 000000848F58: 8C111104
	v_add_nc_u32_e32 v26, 64, v26                              // 000000848F5C: 4A3434C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000848F60: 301A1A82
	ds_load_b32 v45, v13                                       // 000000848F64: D8D80000 2D00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000848F6C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000848F70: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000848F74: 361A1AFF 000003FC
	ds_load_b32 v46, v13                                       // 000000848F7C: D8D80000 2E00000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000848F84: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000848F88: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000848F8C: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000848F94: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000848F98: 360A0AFF 000003FC
	ds_load_b32 v47, v13                                       // 000000848FA0: D8D80000 2F00000D
	ds_load_b32 v48, v5                                        // 000000848FA8: D8D80000 30000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000848FB0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000848FB8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000848FBC: 300A0A82
	ds_load_b32 v49, v5                                        // 000000848FC0: D8D80000 31000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000848FC8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848FCC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000848FD0: 360A0AFF 000003FC
	ds_load_b32 v50, v5                                        // 000000848FD8: D8D80000 32000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000848FE0: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000848FE4: 360A0AFF 000003FC
	ds_load_b32 v51, v5                                        // 000000848FEC: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000848FF4: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000848FF8: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000848FFC: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000849004: D8D80000 34000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000084900C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000849014: 300A0A82
	ds_load_b32 v53, v5                                        // 000000849018: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000849020: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000849024: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000849028: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000849030: D8D80000 36000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000849038: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000084903C: 360A0AFF 000003FC
	ds_load_b32 v55, v5                                        // 000000849044: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000084904C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000849050: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000849054: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000084905C: D8D80000 38000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000849064: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000084906C: 300A0A82
	ds_load_b32 v57, v5                                        // 000000849070: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000849078: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000084907C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000849080: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000849088: D8D80000 3A000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000849090: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000849094: 360A0AFF 000003FC
	ds_load_b32 v59, v5                                        // 00000084909C: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 0000008490A4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008490A8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 0000008490AC: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 0000008490B4: D8D80000 3C000005
	.long 0xd73c0005                                           // 0000008490BC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008490C0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008490C4: 4A1818FF 00000400
	.long 0xd7006a29                                           // 0000008490CC: D7006A29
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 0000008490D0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008490D4: BF870001
	v_add_co_ci_u32_e64 v42, null, s7, v6, vcc_lo              // 0000008490D8: D5207C2A 01AA0C07
	s_clause 0x3                                               // 0000008490E0: BF850003
	global_load_b128 v[5:8], v[41:42], off                     // 0000008490E4: DC5E0000 057C0029
	global_load_b128 v[29:32], v[41:42], off offset:16         // 0000008490EC: DC5E0010 1D7C0029
	global_load_b128 v[33:36], v[41:42], off offset:32         // 0000008490F4: DC5E0020 217C0029
	global_load_b128 v[37:40], v[41:42], off offset:48         // 0000008490FC: DC5E0030 257C0029
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000849104: BF890CF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000849108: CC1A4005 1A025B05
	s_waitcnt lgkmcnt(14)                                      // 000000849110: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849114: BF8700A1
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000849118: CC1A4005 1C165D06
	s_waitcnt lgkmcnt(13)                                      // 000000849120: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000849124: CC1A4005 1C165F07
	s_waitcnt lgkmcnt(12)                                      // 00000084912C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849130: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000849134: CC1A4005 1C166108
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000084913C: BF8908B7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000849140: CC1A4005 1C16631D
	s_waitcnt lgkmcnt(10)                                      // 000000849148: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084914C: BF8700A1
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000849150: CC1A4005 1C16651E
	s_waitcnt lgkmcnt(9)                                       // 000000849158: BF89FC97
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000084915C: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(8)                                       // 000000849164: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849168: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000084916C: CC1A4005 1C166920
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000849174: BF890477
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000849178: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(6)                                       // 000000849180: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849184: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000849188: CC1A4005 1C166D22
	s_waitcnt lgkmcnt(5)                                       // 000000849190: BF89FC57
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000849194: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(4)                                       // 00000084919C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008491A0: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008491A4: CC1A4005 1C167124
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008491AC: BF890037
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008491B0: CC1A4005 1C167325
	.long 0xd7006a25                                           // 0000008491B8: D7006A25
	v_cndmask_b32_e32 v0, v41, v10, vcc_lo                     // 0000008491BC: 02001529
	s_waitcnt lgkmcnt(2)                                       // 0000008491C0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008491C4: BF8701C2
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008491C8: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s11, v42, vcc_lo            // 0000008491D0: D5207C26 01AA540B
	.long 0xd7006a2b                                           // 0000008491D8: D7006A2B
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 0000008491DC: 02001D29
	s_waitcnt lgkmcnt(1)                                       // 0000008491E0: BF89FC17
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008491E4: CC1A4005 1C167727
	v_add_co_ci_u32_e64 v44, null, s15, v42, vcc_lo            // 0000008491EC: D5207C2C 01AA540F
	s_waitcnt lgkmcnt(0)                                       // 0000008491F4: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008491F8: BF870092
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008491FC: CC1A4005 1C167928
	v_fmac_f32_e32 v21, v28, v5                                // 000000849204: 562A0B1C
	s_clause 0x3                                               // 000000849208: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 00000084920C: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000849214: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 00000084921C: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000849224: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 00000084922C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000849230: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849238: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 00000084923C: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000849244: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084924C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000849250: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000849258: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 00000084925C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849264: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000849268: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000849270: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849278: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000084927C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000849284: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000849288: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849290: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000849294: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000084929C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008492A4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000008492A8: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 0000008492B0: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000008492B4: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008492BC: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008492C0: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008492C8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008492D0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008492D4: CC1A4005 1C167928
	v_fmac_f32_e32 v24, v28, v5                                // 0000008492DC: 56300B1C
	s_clause 0x3                                               // 0000008492E0: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 0000008492E4: DC5E0000 057C002B
	global_load_b128 v[29:32], v[43:44], off offset:16         // 0000008492EC: DC5E0010 1D7C002B
	global_load_b128 v[33:36], v[43:44], off offset:32         // 0000008492F4: DC5E0020 217C002B
	global_load_b128 v[37:40], v[43:44], off offset:48         // 0000008492FC: DC5E0030 257C002B
	s_waitcnt vmcnt(3)                                         // 000000849304: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 000000849308: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849310: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 000000849314: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 00000084931C: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849324: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000849328: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000849330: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000849334: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084933C: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000849340: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000849348: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849350: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000849354: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 00000084935C: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000849360: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849368: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000084936C: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000849374: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084937C: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000849380: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000849388: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000084938C: CC1A4005 1C167325
	.long 0xd7006a25                                           // 000000849394: D7006A25
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 000000849398: 02002529
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000084939C: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000008493A0: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s16, v42, vcc_lo            // 0000008493A8: D5207C26 01AA5410
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000008493B0: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008493B8: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008493BC: CC1A4005 1C167928
	v_fmac_f32_e32 v23, v28, v5                                // 0000008493C4: 562E0B1C
	s_clause 0x3                                               // 0000008493C8: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008493CC: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008493D4: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008493DC: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008493E4: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008493EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008493F0: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008493F8: BF870091
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008493FC: CC1A4005 1C165D06
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 000000849404: CC1A4005 1C165F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084940C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000849410: CC1A4005 1C166108
	s_waitcnt vmcnt(2)                                         // 000000849418: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 00000084941C: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849424: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 000000849428: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000849430: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849438: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000084943C: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000849444: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000849448: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849450: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000849454: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000084945C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849464: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000849468: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000849470: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000849474: CC1A4005 1C167325
	.long 0xd7006a25                                           // 00000084947C: D7006A25
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 000000849480: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000849484: BF870122
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000849488: CC1A4005 1C167526
	v_add_co_ci_u32_e64 v38, null, s15, v44, vcc_lo            // 000000849490: D5207C26 01AA580F
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000849498: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008494A0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000008494A4: CC1A4005 1C167928
	v_fmac_f32_e32 v22, v28, v5                                // 0000008494AC: 562C0B1C
	s_clause 0x3                                               // 0000008494B0: BF850003
	global_load_b128 v[5:8], v[37:38], off                     // 0000008494B4: DC5E0000 057C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 0000008494BC: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 0000008494C4: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 0000008494CC: DC5E0030 257C0025
	s_waitcnt vmcnt(3)                                         // 0000008494D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v45, 0                             // 0000008494D8: CC1A4005 1A025B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008494E0: BF870121
	v_dot2_f32_bf16 v5, v6, v46, v5                            // 0000008494E4: CC1A4005 1C165D06
	v_mov_b32_e32 v6, v2                                       // 0000008494EC: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v47, v5                            // 0000008494F0: CC1A4005 1C165F07
	v_mov_b32_e32 v7, v3                                       // 0000008494F8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008494FC: BF870132
	v_dot2_f32_bf16 v5, v8, v48, v5                            // 000000849500: CC1A4005 1C166108
	v_mov_b32_e32 v8, v4                                       // 000000849508: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000084950C: BF890BF7
	v_dot2_f32_bf16 v5, v29, v49, v5                           // 000000849510: CC1A4005 1C16631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849518: BF870091
	v_dot2_f32_bf16 v5, v30, v50, v5                           // 00000084951C: CC1A4005 1C16651E
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000849524: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000084952C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000849530: CC1A4005 1C166920
	s_waitcnt vmcnt(1)                                         // 000000849538: BF8907F7
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000084953C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849544: BF870091
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000849548: CC1A4005 1C166D22
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000849550: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000849558: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000084955C: CC1A4005 1C167124
	s_waitcnt vmcnt(0)                                         // 000000849564: BF8903F7
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000849568: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849570: BF870091
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000849574: CC1A4005 1C167526
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000084957C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849584: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000849588: CC1A4005 1C167928
	v_fmac_f32_e32 v17, v28, v5                                // 000000849590: 56220B1C
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v28, v27           // 000000849594: CA100101 051C011B
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000084959C: 917E117E
	s_cbranch_execz 31                                         // 0000008495A0: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x920>
	s_waitcnt vmcnt(0)                                         // 0000008495A4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008495A8: BF8701C1
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 0000008495AC: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000008495B4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000008495BC: 7E080308
	s_mov_b32 s19, exec_lo                                     // 0000008495C0: BE93007E
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 0000008495C4: 7C8C250A
	.long 0xd4c1007e                                           // 0000008495C8: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 0000008495CC: 0202250A
	s_cbranch_execz 65115                                      // 0000008495D0: BFA5FE5B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	v_ashrrev_i32_e32 v2, 31, v26                              // 0000008495D4: 3404349F
	v_ashrrev_i32_e32 v4, 31, v25                              // 0000008495D8: 3408329F
	.long 0xd7000401                                           // 0000008495DC: D7000401
	v_cndmask_b32_e32 v1, v11, v26, vcc_lo                     // 0000008495E0: 0202350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008495E4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 0000008495E8: D5207C02 00120514
	.long 0xd7000403                                           // 0000008495F0: D7000403
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000008495F4: 02023309
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 0000008495F8: D5207C04 00120913
	s_clause 0x1                                               // 000000849600: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 000000849604: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000084960C: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000849614: BF8907F7
	v_cvt_f32_f16_e32 v27, v13                                 // 000000849618: 7E36170D
	s_branch 65096                                             // 00000084961C: BFA0FE48 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x240>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000849620: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000849624: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 000000849628: 8C7E057E
	.long 0xd71f0001                                           // 00000084962C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000849630: 020100C1
	s_mov_b32 s4, exec_lo                                      // 000000849634: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000849638: 3A040290
	s_waitcnt vmcnt(0)                                         // 00000084963C: BF8903F7
	v_xor_b32_e32 v7, 8, v1                                    // 000000849640: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 000000849644: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000849648: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000084964C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000849650: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 000000849654: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 000000849658: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000084965C: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000849660: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000849664: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000849668: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000084966C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000849674: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000849678: 06060715
	ds_bpermute_b32 v4, v2, v24                                // 00000084967C: DACC0000 04001802
	ds_bpermute_b32 v5, v2, v23                                // 000000849684: DACC0000 05001702
	ds_bpermute_b32 v6, v2, v22                                // 00000084968C: DACC0000 06001602
	ds_bpermute_b32 v2, v2, v17                                // 000000849694: DACC0000 02001102
	ds_bpermute_b32 v8, v7, v3                                 // 00000084969C: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 0000008496A4: BF89FC37
	v_dual_add_f32 v4, v24, v4 :: v_dual_add_f32 v5, v23, v5   // 0000008496A8: C9080918 04040B17
	s_waitcnt lgkmcnt(2)                                       // 0000008496B0: BF89FC27
	v_add_f32_e32 v6, v22, v6                                  // 0000008496B4: 060C0D16
	s_waitcnt lgkmcnt(0)                                       // 0000008496B8: BF89FC07
	v_dual_add_f32 v2, v17, v2 :: v_dual_add_f32 v3, v3, v8    // 0000008496BC: C9080511 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 0000008496C4: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 0000008496CC: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 0000008496D4: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 0000008496D8: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 0000008496E0: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 0000008496E8: 30181882
	s_waitcnt lgkmcnt(2)                                       // 0000008496EC: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 0000008496F0: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 0000008496F8: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000849700: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 000000849708: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 00000084970C: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 000000849710: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 000000849714: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 000000849718: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 00000084971C: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 000000849724: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 000000849728: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 00000084972C: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000849734: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 00000084973C: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 000000849740: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000849744: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 000000849748: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 00000084974C: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 000000849754: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 000000849758: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 00000084975C: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 000000849760: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 000000849764: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 000000849768: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 000000849770: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 000000849778: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 000000849780: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 000000849788: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 000000849790: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000849794: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 000000849798: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 00000084979C: 02021901
	s_waitcnt lgkmcnt(4)                                       // 0000008497A0: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 0000008497A4: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 0000008497AC: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 0000008497B0: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 0000008497B8: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 0000008497BC: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 0000008497C0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 0000008497C4: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 0000008497C8: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 0000008497D0: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 0000008497D8: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 0000008497E0: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 0000008497E8: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008497F0: 7D942080
	s_cbranch_execz 18                                         // 0000008497F4: BFA50012 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	v_mul_u32_u24_e32 v11, 20, v15                             // 0000008497F8: 16161E94
	s_waitcnt lgkmcnt(0)                                       // 0000008497FC: BF89FC07
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_f32 v2, v2, v6     // 000000849800: C9081103 03020D02
	v_add_f32_e32 v1, v1, v5                                   // 000000849808: 06020B01
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 00000084980C: C9081507 07041304
	v_or_b32_e32 v5, 0x400, v11                                // 000000849814: 380A16FF 00000400
	v_mad_u32_u24 v8, v15, 20, 0x408                           // 00000084981C: D60B0008 03FD290F 00000408
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 000000849828: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 000000849830: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 000000849838: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s4                              // 000000849840: 8C7E047E
	.long 0xd4510004                                           // 000000849844: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000849848: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 5, v0                             // 00000084984C: 7C980085
	s_waitcnt lgkmcnt(0)                                       // 000000849850: BF89FC07
	s_barrier                                                  // 000000849854: BFBD0000
	buffer_gl0_inv                                             // 000000849858: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 000000849860: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000849864: BF870009
	s_and_saveexec_b32 s5, s4                                  // 000000849868: BE852004
	s_cbranch_execz 85                                         // 00000084986C: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xcc4>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 000000849870: 4A0E1CFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 000000849878: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:5                     // 000000849880: D8DC0500 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:10 offset1:15         // 000000849888: D8DC0F0A 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:20 offset1:25         // 000000849890: D8DC1914 05000007
	s_waitcnt lgkmcnt(0)                                       // 000000849898: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 00000084989C: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008498A0: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000008498A4: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:30 offset1:35         // 0000008498A8: D8DC231E 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000008498B0: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000008498B4: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008498B8: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000008498BC: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000008498C0: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000008498C4: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008498C8: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000008498CC: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000008498D0: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008498D4: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000008498D8: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000008498E0: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008498EC: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000008498F0: 360202FF FFFF0000
	v_mul_f32_e32 v1, s0, v1                                   // 0000008498F8: 10020200
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000008498FC: 84808202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849900: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 000000849904: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000084990C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000849910: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 000000849914: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 000000849918: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 000000849920: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000849928: BF870292
	v_rcp_f32_e32 v6, v5                                       // 00000084992C: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 000000849930: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000849938: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 00000084993C: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000849940: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 000000849948: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000084994C: BF870091
	v_fma_f32 v3, -v5, v8, v7                                  // 000000849950: D6130003 241E1105
	v_fmac_f32_e32 v8, v3, v6                                  // 000000849958: 56100D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000084995C: BF870114
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000849960: D6FE7C02 040A000D
	v_fma_f32 v0, -v5, v8, v7                                  // 000000849968: D6130000 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000849970: BF870191
	v_div_fmas_f32 v3, v0, v6, v8                              // 000000849974: D6370003 04220D00
	.long 0xd73c0000                                           // 00000084997C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000849980: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000849984: BF870112
	v_div_fixup_f32 v2, v3, v4, 1.0                            // 000000849988: D6270002 03CA0903
	.long 0xd7006a00                                           // 000000849990: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000849994: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000849998: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000084999C: D5207C01 01AA0209
	v_add_f32_e32 v2, v2, v2                                   // 0000008499A4: 06040502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008499A8: BF870093
	.long 0xd7006a00                                           // 0000008499AC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008499B0: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008499B4: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 0000008499BC: DC6A0000 007C0200
	s_endpgm                                                   // 0000008499C4: BFB00000
		...

