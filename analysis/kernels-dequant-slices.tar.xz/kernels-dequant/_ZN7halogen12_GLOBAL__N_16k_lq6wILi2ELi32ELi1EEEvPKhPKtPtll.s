0000000000336500 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000336500: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000336508: BE830080
	v_lshrrev_b32_e32 v1, 5, v0                                // 00000033650C: 32020085
	s_lshl_b64 s[12:13], s[2:3], 3                             // 000000336510: 848C8302
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000336514: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000033651C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 31, v0         // 000000336520: CA240080 0610009F
	v_or_b32_e32 v8, s12, v1                                   // 000000336528: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000033652C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000336534: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000033653C: BF8704D3
	.long 0xd73c0001                                           // 000000336540: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000336544: 02021084
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v36, 0             // 000000336548: CA100080 0F240080
	v_mov_b32_e32 v18, 0                                       // 000000336550: 7E240280
	s_waitcnt lgkmcnt(0)                                       // 000000336554: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000336558: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000033655C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000336560: BF870009
	s_add_u32 s0, s10, s0                                      // 000000336564: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000336568: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000033656C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000336570: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000336574: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000336578: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000033657C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000336580: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000336584: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000336588: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000033658C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000336590: 86908200
	s_add_u32 s0, s10, s13                                     // 000000336594: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000336598: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000033659C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003365A0: 86808400
	s_add_u32 s13, s16, s14                                    // 0000003365A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 0000003365A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 0000003365AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 0000003365B0: 82010112
	s_add_u32 s0, s0, 15                                       // 0000003365B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003365B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003365BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 0000003365C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003365C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 0000003365C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003365CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 0000003365D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 0000003365D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003365D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003365DC: BF870149
	.long 0xd72c0003                                           // 0000003365E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003365E4: 02000301
	.long 0xd72c0002                                           // 0000003365E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003365EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 0000003365F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 0000003365F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 0000003365FC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 000000336600: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000336608: BE842000
	s_cbranch_execz 35                                         // 00000033660C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000336610: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000336614: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000336618: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033661C: BF870093
	.long 0xd7000101                                           // 000000336620: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000336624: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 000000336628: D5207C02 00062680
	.long 0xd7000103                                           // 000000336630: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000336634: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336638: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 00000033663C: D5207C04 0006260F
	v_and_b32_e32 v0, 60, v0                                   // 000000336644: 360000BC
	.long 0xd7000106                                           // 000000336648: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 00000033664C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000336650: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000336654: D5207C07 00060811
	.long 0xd700010b                                           // 00000033665C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000336660: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000336664: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033666C: BF870094
	.long 0xd700010d                                           // 000000336670: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000336674: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000336678: D5207C0E 00060E80
	s_clause 0x2                                               // 000000336680: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000336684: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 00000033668C: DC560000 0F7C000B
	global_load_b32 v36, v[13:14], off                         // 000000336694: DC520000 247C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000033669C: 8C7E047E
	v_mov_b32_e32 v20, 0                                       // 0000003366A0: 7E280280
	s_and_saveexec_b32 s13, s0                                 // 0000003366A4: BE8D2000
	s_cbranch_execz 774                                        // 0000003366A8: BFA50306 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0xdc4>
	.long 0xd7000015                                           // 0000003366AC: D7000015
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 0000003366B0: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003366B4: BF8701A1
	v_add_co_ci_u32_e64 v22, null, s15, v19, s0                // 0000003366B8: D5207C16 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 0000003366C0: CA220080 0C0A2285
	.long 0xd7000017                                           // 0000003366C8: D7000017
	v_cndmask_b32_e32 v0, v21, v16, vcc_lo                     // 0000003366CC: 02002115
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003366D0: BF870001
	v_add_co_ci_u32_e64 v24, null, s17, v22, s0                // 0000003366D4: D5207C18 00022C11
	v_lshl_or_b32 v25, v17, 4, 0x200                           // 0000003366DC: D6560019 03FD0911 00000200
	v_lshl_or_b32 v26, v17, 3, 0x100                           // 0000003366E8: D656001A 03FD0711 00000100
	v_lshl_or_b32 v27, v17, 1, 64                              // 0000003366F4: D656001B 03010311
	v_mov_b32_e32 v18, v12                                     // 0000003366FC: 7E24030C
	s_waitcnt vmcnt(0)                                         // 000000336700: BF8903F7
	v_dual_mov_b32 v28, v17 :: v_dual_mov_b32 v29, v36         // 000000336704: CA100111 1C1C0124
	v_mov_b32_e32 v20, v12                                     // 00000033670C: 7E28030C
	s_mov_b32 s14, 0                                           // 000000336710: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000336714: 8484810A
	s_branch 707                                               // 000000336718: BFA002C3 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0xd28>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000033671C: 8C7E0A7E
	v_lshlrev_b32_e32 v30, 4, v15                              // 000000336720: 303C1E84
	v_lshlrev_b32_e32 v32, 2, v15                              // 000000336724: 30401E82
	v_lshrrev_b32_e32 v31, 4, v4                               // 000000336728: 323E0884
	v_lshrrev_b32_e32 v33, 2, v15                              // 00000033672C: 32421E82
	.long 0x7f4a3880                                           // 000000336730: 7F4A3880
	v_and_b32_e32 v30, 48, v30                                 // 000000336734: 363C3CB0
	v_and_b32_e32 v32, 48, v32                                 // 000000336738: 364040B0
	v_lshrrev_b32_e32 v35, 6, v15                              // 00000033673C: 32461E86
	v_and_b32_e32 v33, 48, v33                                 // 000000336740: 364242B0
	v_lshrrev_b32_e32 v34, 20, v4                              // 000000336744: 32440894
	v_and_or_b32 v30, v4, 15, v30                              // 000000336748: D657001E 04791F04
	v_and_or_b32 v31, v31, 15, v32                             // 000000336750: D657001F 04811F1F
	v_and_b32_e32 v35, 48, v35                                 // 000000336758: 364646B0
	v_lshrrev_b32_e32 v39, 18, v15                             // 00000033675C: 324E1E92
	v_lshrrev_b32_e32 v40, 22, v15                             // 000000336760: 32501E96
	v_cvt_f32_ubyte0_e32 v30, v30                              // 000000336764: 7E3C231E
	v_lshrrev_b32_e32 v41, 6, v16                              // 000000336768: 32522086
	v_and_or_b32 v34, v34, 15, v35                             // 00000033676C: D6570022 048D1F22
	v_and_b32_e32 v39, 48, v39                                 // 000000336774: 364E4EB0
	v_and_b32_e32 v40, 48, v40                                 // 000000336778: 365050B0
	v_fma_mix_f32 v30, v30, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033677C: CC20601E 1492491E
	v_and_b32_e32 v41, 48, v41                                 // 000000336784: 365252B0
	s_and_b32 s0, exec_lo, s0                                  // 000000336788: 8B00007E
	v_add_nc_u32_e32 v25, 0x200, v25                           // 00000033678C: 4A3232FF 00000200
	s_or_b32 s14, s0, s14                                      // 000000336794: 8C0E0E00
	v_bfe_u32 v32, v30, 16, 1                                  // 000000336798: D6100020 0205211E
	v_add_nc_u32_e32 v26, 0x100, v26                           // 0000003367A0: 4A3434FF 00000100
	v_add_nc_u32_e32 v27, 64, v27                              // 0000003367A8: 4A3636C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003367AC: BF870123
	v_add3_u32 v30, v30, v32, 0x7fff                           // 0000003367B0: D655001E 03FE411E 00007FFF
	v_and_b32_e32 v32, 48, v15                                 // 0000003367BC: 36401EB0
	.long 0x7e4a399e                                           // 0000003367C0: 7E4A399E
	v_cvt_f32_ubyte0_e32 v30, v31                              // 0000003367C4: 7E3C231F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003367C8: BF870091
	v_fma_mix_f32 v30, v30, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003367CC: CC20601E 1492491E
	v_bfe_u32 v31, v30, 16, 1                                  // 0000003367D4: D610001F 0205211E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003367DC: BF870121
	v_add3_u32 v30, v30, v31, 0x7fff                           // 0000003367E0: D655001E 03FE3F1E 00007FFF
	v_lshrrev_b32_e32 v31, 8, v4                               // 0000003367EC: 323E0888
	v_and_or_b32 v30, 0xffff0000, v30, v37                     // 0000003367F0: D657001E 04963CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003367FC: BF870122
	v_and_or_b32 v31, v31, 15, v32                             // 000000336800: D657001F 04811F1F
	v_lshrrev_b32_e32 v32, 12, v4                              // 000000336808: 3240088C
	v_cvt_f32_ubyte0_e32 v31, v31                              // 00000033680C: 7E3E231F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336810: BF870112
	v_and_or_b32 v32, v32, 15, v33                             // 000000336814: D6570020 04851F20
	v_fma_mix_f32 v31, v31, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000033681C: CC20601F 1492491F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336824: BF870091
	v_bfe_u32 v33, v31, 16, 1                                  // 000000336828: D6100021 0205211F
	v_add3_u32 v31, v31, v33, 0x7fff                           // 000000336830: D655001F 03FE431F 00007FFF
	v_lshrrev_b32_e32 v33, 8, v15                              // 00000033683C: 32421E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336840: BF8701A2
	.long 0x7e4a399f                                           // 000000336844: 7E4A399F
	v_cvt_f32_ubyte0_e32 v31, v32                              // 000000336848: 7E3E2320
	v_and_b32_e32 v33, 48, v33                                 // 00000033684C: 364242B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336850: BF870092
	v_fma_mix_f32 v31, v31, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336854: CC20601F 1492491F
	v_bfe_u32 v32, v31, 16, 1                                  // 00000033685C: D6100020 0205211F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336864: BF870121
	v_add3_u32 v31, v31, v32, 0x7fff                           // 000000336868: D655001F 03FE411F 00007FFF
	v_lshrrev_b32_e32 v32, 4, v15                              // 000000336874: 32401E84
	v_and_or_b32 v31, 0xffff0000, v31, v37                     // 000000336878: D657001F 04963EFF FFFF0000
	.long 0x7e4a3984                                           // 000000336884: 7E4A3984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336888: BF870093
	v_and_b32_e32 v32, 48, v32                                 // 00000033688C: 364040B0
	v_and_or_b32 v32, v37, 15, v32                             // 000000336890: D6570020 04811F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336898: BF870091
	v_cvt_f32_ubyte0_e32 v32, v32                              // 00000033689C: 7E402320
	v_fma_mix_f32 v32, v32, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003368A0: CC206020 14924920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003368A8: BF870091
	v_bfe_u32 v35, v32, 16, 1                                  // 0000003368AC: D6100023 02052120
	v_add3_u32 v32, v32, v35, 0x7fff                           // 0000003368B4: D6550020 03FE4720 00007FFF
	v_lshrrev_b32_e32 v35, 12, v15                             // 0000003368C0: 32461E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003368C4: BF8700A2
	.long 0x7e4a39a0                                           // 0000003368C8: 7E4A39A0
	v_cvt_f32_ubyte0_e32 v32, v34                              // 0000003368CC: 7E402322
	v_fma_mix_f32 v32, v32, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003368D0: CC206020 14924920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003368D8: BF870091
	v_bfe_u32 v34, v32, 16, 1                                  // 0000003368DC: D6100022 02052120
	v_add3_u32 v32, v32, v34, 0x7fff                           // 0000003368E4: D6550020 03FE4520 00007FFF
	v_lshrrev_b32_e32 v34, 24, v4                              // 0000003368F0: 32440898
	v_lshrrev_b32_e32 v4, 28, v4                               // 0000003368F4: 3208089C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003368F8: BF870193
	v_and_or_b32 v32, 0xffff0000, v32, v37                     // 0000003368FC: D6570020 049640FF FFFF0000
	v_and_or_b32 v33, v34, 15, v33                             // 000000336908: D6570021 04851F22
	v_lshrrev_b32_e32 v34, 10, v15                             // 000000336910: 32441E8A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336914: BF870112
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000336918: 7E422321
	v_and_or_b32 v4, v34, 48, v4                               // 00000033691C: D6570004 04116122
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336924: BF870112
	v_fma_mix_f32 v33, v33, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336928: CC206021 14924921
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000336930: 7E082304
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336934: BF870112
	v_bfe_u32 v34, v33, 16, 1                                  // 000000336938: D6100022 02052121
	v_fma_mix_f32 v4, v4, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336940: CC206004 14924904
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336948: BF870122
	v_add3_u32 v33, v33, v34, 0x7fff                           // 00000033694C: D6550021 03FE4521 00007FFF
	v_lshrrev_b32_e32 v34, 4, v5                               // 000000336958: 32440A84
	.long 0x7e4a39a1                                           // 00000033695C: 7E4A39A1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336960: BF870094
	v_bfe_u32 v33, v4, 16, 1                                   // 000000336964: D6100021 02052104
	v_add3_u32 v4, v4, v33, 0x7fff                             // 00000033696C: D6550004 03FE4304 00007FFF
	v_and_b32_e32 v33, 48, v35                                 // 000000336978: 364246B0
	v_lshrrev_b32_e32 v35, 14, v15                             // 00000033697C: 32461E8E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336980: BF870193
	v_and_or_b32 v4, 0xffff0000, v4, v37                       // 000000336984: D6570004 049608FF FFFF0000
	v_and_or_b32 v33, v5, 15, v33                              // 000000336990: D6570021 04851F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336998: BF8701A3
	v_and_b32_e32 v35, 48, v35                                 // 00000033699C: 364646B0
	.long 0x7e4a398f                                           // 0000003369A0: 7E4A398F
	v_cvt_f32_ubyte0_e32 v33, v33                              // 0000003369A4: 7E422321
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003369A8: BF870193
	v_and_or_b32 v34, v34, 15, v35                             // 0000003369AC: D6570022 048D1F22
	v_and_b32_e32 v38, 48, v37                                 // 0000003369B4: 364C4AB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003369B8: BF870193
	v_fma_mix_f32 v33, v33, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003369BC: CC206021 14924921
	v_cvt_f32_ubyte0_e32 v34, v34                              // 0000003369C4: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003369C8: BF870112
	v_bfe_u32 v35, v33, 16, 1                                  // 0000003369CC: D6100023 02052121
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003369D4: CC206022 14924922
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003369DC: BF870112
	v_add3_u32 v33, v33, v35, 0x7fff                           // 0000003369E0: D6550021 03FE4721 00007FFF
	v_bfe_u32 v35, v34, 16, 1                                  // 0000003369EC: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003369F4: BF8701A2
	.long 0x7e4239a1                                           // 0000003369F8: 7E4239A1
	.long 0x7f4239a5                                           // 0000003369FC: 7F4239A5
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000336A00: D6550022 03FE4722 00007FFF
	v_lshrrev_b32_e32 v35, 20, v15                             // 000000336A0C: 32461E94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336A10: BF8701A2
	v_and_or_b32 v33, 0xffff0000, v34, v33                     // 000000336A14: D6570021 048644FF FFFF0000
	v_lshrrev_b32_e32 v34, 8, v5                               // 000000336A20: 32440A88
	v_and_b32_e32 v35, 48, v35                                 // 000000336A24: 364646B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336A28: BF870122
	v_and_or_b32 v34, v34, 15, v38                             // 000000336A2C: D6570022 04991F22
	v_lshrrev_b32_e32 v38, 12, v5                              // 000000336A34: 324C0A8C
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000336A38: 7E442322
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336A3C: BF870112
	v_and_or_b32 v38, v38, 15, v39                             // 000000336A40: D6570026 049D1F26
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336A48: CC206022 14924922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336A50: BF870091
	v_bfe_u32 v39, v34, 16, 1                                  // 000000336A54: D6100027 02052122
	v_add3_u32 v34, v34, v39, 0x7fff                           // 000000336A5C: D6550022 03FE4F22 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 000000336A68: 324E0A94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336A6C: BF8701A2
	.long 0x7e4a39a2                                           // 000000336A70: 7E4A39A2
	v_cvt_f32_ubyte0_e32 v34, v38                              // 000000336A74: 7E442326
	v_and_or_b32 v39, v39, 15, v40                             // 000000336A78: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336A80: BF870092
	v_fma_mix_f32 v34, v34, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336A84: CC206022 14924922
	v_bfe_u32 v38, v34, 16, 1                                  // 000000336A8C: D6100026 02052122
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000336A94: BF8701B1
	v_add3_u32 v34, v34, v38, 0x7fff                           // 000000336A98: D6550022 03FE4D22 00007FFF
	v_lshrrev_b32_e32 v38, 24, v15                             // 000000336AA4: 324C1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000336AA8: 321E1E9A
	v_and_or_b32 v34, 0xffff0000, v34, v37                     // 000000336AAC: D6570022 049644FF FFFF0000
	.long 0x7e4a3985                                           // 000000336AB8: 7E4A3985
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336ABC: BF870114
	v_and_b32_e32 v38, 48, v38                                 // 000000336AC0: 364C4CB0
	v_and_or_b32 v35, v37, 15, v35                             // 000000336AC4: D6570023 048D1F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336ACC: BF870091
	v_cvt_f32_ubyte0_e32 v35, v35                              // 000000336AD0: 7E462323
	v_fma_mix_f32 v35, v35, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336AD4: CC206023 14924923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336ADC: BF870091
	v_bfe_u32 v40, v35, 16, 1                                  // 000000336AE0: D6100028 02052123
	v_add3_u32 v35, v35, v40, 0x7fff                           // 000000336AE8: D6550023 03FE5123 00007FFF
	v_lshrrev_b32_e32 v40, 2, v16                              // 000000336AF4: 32502082
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336AF8: BF8701A2
	.long 0x7e4a39a3                                           // 000000336AFC: 7E4A39A3
	v_cvt_f32_ubyte0_e32 v35, v39                              // 000000336B00: 7E462327
	v_and_b32_e32 v40, 48, v40                                 // 000000336B04: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336B08: BF870092
	v_fma_mix_f32 v35, v35, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336B0C: CC206023 14924923
	v_bfe_u32 v39, v35, 16, 1                                  // 000000336B14: D6100027 02052123
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000336B1C: BF8701B1
	v_add3_u32 v35, v35, v39, 0x7fff                           // 000000336B20: D6550023 03FE4F23 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 000000336B2C: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000336B30: 320A0A9C
	v_and_or_b32 v35, 0xffff0000, v35, v37                     // 000000336B34: D6570023 049646FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336B40: BF870193
	v_and_or_b32 v38, v39, 15, v38                             // 000000336B44: D6570026 04991F27
	v_and_or_b32 v5, v15, 48, v5                               // 000000336B4C: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 000000336B54: 304E2082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336B58: BF870193
	v_cvt_f32_ubyte0_e32 v15, v38                              // 000000336B5C: 7E1E2326
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000336B60: 7E0A2305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336B64: BF870193
	v_and_b32_e32 v39, 48, v39                                 // 000000336B68: 364E4EB0
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336B6C: CC20600F 1492490F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336B74: BF870113
	v_fma_mix_f32 v5, v5, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336B78: CC206005 14924905
	v_bfe_u32 v38, v15, 16, 1                                  // 000000336B80: D6100026 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336B88: BF870121
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000336B8C: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 4, v6                               // 000000336B98: 324C0C84
	.long 0x7e4a398f                                           // 000000336B9C: 7E4A398F
	v_bfe_u32 v15, v5, 16, 1                                   // 000000336BA0: D610000F 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336BA8: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 000000336BAC: D6570026 049D1F26
	v_add3_u32 v5, v5, v15, 0x7fff                             // 000000336BB4: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000336BC0: 301E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336BC4: BF870112
	v_and_or_b32 v5, 0xffff0000, v5, v37                       // 000000336BC8: D6570005 04960AFF FFFF0000
	v_and_b32_e32 v15, 48, v15                                 // 000000336BD4: 361E1EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336BD8: BF870091
	v_and_or_b32 v15, v6, 15, v15                              // 000000336BDC: D657000F 043D1F06
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000336BE4: 7E1E230F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336BE8: BF870091
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336BEC: CC20600F 1492490F
	v_bfe_u32 v39, v15, 16, 1                                  // 000000336BF4: D6100027 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336BFC: BF870121
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000336C00: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 000000336C0C: 364E20B0
	.long 0x7e4a398f                                           // 000000336C10: 7E4A398F
	v_cvt_f32_ubyte0_e32 v15, v38                              // 000000336C14: 7E1E2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336C18: BF870091
	v_fma_mix_f32 v15, v15, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336C1C: CC20600F 1492490F
	v_bfe_u32 v38, v15, 16, 1                                  // 000000336C24: D6100026 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336C2C: BF870121
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000336C30: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 8, v6                               // 000000336C3C: 324C0C88
	v_and_or_b32 v15, 0xffff0000, v15, v37                     // 000000336C40: D657000F 04961EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336C4C: BF870122
	v_and_or_b32 v38, v38, 15, v39                             // 000000336C50: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v6                              // 000000336C58: 324E0C8C
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000336C5C: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336C60: BF870112
	v_and_or_b32 v39, v39, 15, v40                             // 000000336C64: D6570027 04A11F27
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336C6C: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336C74: BF870091
	v_bfe_u32 v40, v38, 16, 1                                  // 000000336C78: D6100028 02052126
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000336C80: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 20, v6                              // 000000336C8C: 32500C94
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336C90: BF8701A2
	.long 0x7e4a39a6                                           // 000000336C94: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000336C98: 7E4C2327
	v_and_or_b32 v40, v40, 15, v41                             // 000000336C9C: D6570028 04A51F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336CA4: BF870092
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336CA8: CC206026 14924926
	v_bfe_u32 v39, v38, 16, 1                                  // 000000336CB0: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336CB8: BF870121
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000336CBC: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 000000336CC8: 324E2084
	v_and_or_b32 v52, 0xffff0000, v38, v37                     // 000000336CCC: D6570034 04964CFF FFFF0000
	.long 0x7e4a3986                                           // 000000336CD8: 7E4A3986
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336CDC: BF870123
	v_and_b32_e32 v39, 48, v39                                 // 000000336CE0: 364E4EB0
	v_lshrrev_b32_e32 v38, 8, v16                              // 000000336CE4: 324C2088
	v_and_or_b32 v39, v37, 15, v39                             // 000000336CE8: D6570027 049D1F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336CF0: BF870112
	v_and_b32_e32 v38, 48, v38                                 // 000000336CF4: 364C4CB0
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000336CF8: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336CFC: BF870091
	v_fma_mix_f32 v39, v39, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336D00: CC206027 14924927
	v_bfe_u32 v41, v39, 16, 1                                  // 000000336D08: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336D10: BF870091
	v_add3_u32 v39, v39, v41, 0x7fff                           // 000000336D14: D6550027 03FE5327 00007FFF
	.long 0x7e4a39a7                                           // 000000336D20: 7E4A39A7
	v_cvt_f32_ubyte0_e32 v39, v40                              // 000000336D24: 7E4E2328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336D28: BF870091
	v_fma_mix_f32 v39, v39, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336D2C: CC206027 14924927
	v_bfe_u32 v40, v39, 16, 1                                  // 000000336D34: D6100028 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336D3C: BF870121
	v_add3_u32 v39, v39, v40, 0x7fff                           // 000000336D40: D6550027 03FE5127 00007FFF
	v_lshrrev_b32_e32 v40, 12, v16                             // 000000336D4C: 3250208C
	v_and_or_b32 v53, 0xffff0000, v39, v37                     // 000000336D50: D6570035 04964EFF FFFF0000
	v_lshrrev_b32_e32 v39, 24, v6                              // 000000336D5C: 324E0C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 000000336D60: 320C0C9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336D64: BF870122
	v_and_or_b32 v38, v39, 15, v38                             // 000000336D68: D6570026 04991F27
	v_lshrrev_b32_e32 v39, 10, v16                             // 000000336D70: 324E208A
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000336D74: 7E4C2326
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336D78: BF870112
	v_and_or_b32 v6, v39, 48, v6                               // 000000336D7C: D6570006 04196127
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336D84: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336D8C: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000336D90: 7E0C2306
	v_bfe_u32 v39, v38, 16, 1                                  // 000000336D94: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336D9C: BF870112
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336DA0: CC206006 14924906
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000336DA8: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 14, v16                             // 000000336DB4: 324E208E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000336DB8: BF870212
	.long 0x7e4a39a6                                           // 000000336DBC: 7E4A39A6
	v_bfe_u32 v38, v6, 16, 1                                   // 000000336DC0: D6100026 02052106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336DC8: BF870113
	v_and_b32_e32 v39, 48, v39                                 // 000000336DCC: 364E4EB0
	v_add3_u32 v6, v6, v38, 0x7fff                             // 000000336DD0: D6550006 03FE4D06 00007FFF
	v_lshrrev_b32_e32 v38, 4, v7                               // 000000336DDC: 324C0E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336DE0: BF8701A2
	v_and_or_b32 v54, 0xffff0000, v6, v37                      // 000000336DE4: D6570036 04960CFF FFFF0000
	v_and_b32_e32 v6, 15, v7                                   // 000000336DF0: 360C0E8F
	v_and_or_b32 v38, v38, 15, v39                             // 000000336DF4: D6570026 049D1F26
	.long 0x7e4a3990                                           // 000000336DFC: 7E4A3990
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336E00: BF870193
	v_and_or_b32 v6, v40, 48, v6                               // 000000336E04: D6570006 04196128
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000336E0C: 7E4C2326
	v_lshrrev_b32_e32 v40, 18, v16                             // 000000336E10: 32502092
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336E14: BF870193
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000336E18: 7E0C2306
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336E1C: CC206026 14924926
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336E24: BF870193
	v_and_b32_e32 v40, 48, v40                                 // 000000336E28: 365050B0
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336E2C: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336E34: BF870091
	v_bfe_u32 v39, v6, 16, 1                                   // 000000336E38: D6100027 02052106
	v_add3_u32 v6, v6, v39, 0x7fff                             // 000000336E40: D6550006 03FE4F06 00007FFF
	v_bfe_u32 v39, v38, 16, 1                                  // 000000336E4C: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336E54: BF8701A2
	.long 0x7e0c3986                                           // 000000336E58: 7E0C3986
	.long 0x7f0c39a5                                           // 000000336E5C: 7F0C39A5
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000336E60: D6550026 03FE4F26 00007FFF
	v_and_b32_e32 v39, 48, v37                                 // 000000336E6C: 364E4AB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000336E70: BF870132
	v_and_or_b32 v55, 0xffff0000, v38, v6                      // 000000336E74: D6570037 041A4CFF FFFF0000
	v_lshrrev_b32_e32 v6, 8, v7                                // 000000336E80: 320C0E88
	v_lshrrev_b32_e32 v38, 20, v16                             // 000000336E84: 324C2094
	v_and_or_b32 v6, v6, 15, v39                               // 000000336E88: D6570006 049D1F06
	v_lshrrev_b32_e32 v39, 12, v7                              // 000000336E90: 324E0E8C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000336E94: BF870193
	v_and_b32_e32 v38, 48, v38                                 // 000000336E98: 364C4CB0
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000336E9C: 7E0C2306
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336EA0: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 000000336EA4: D6570027 04A11F27
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336EAC: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336EB4: BF870091
	v_bfe_u32 v40, v6, 16, 1                                   // 000000336EB8: D6100028 02052106
	v_add3_u32 v6, v6, v40, 0x7fff                             // 000000336EC0: D6550006 03FE5106 00007FFF
	v_lshrrev_b32_e32 v40, 22, v16                             // 000000336ECC: 32502096
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000336ED0: BF8701A2
	.long 0x7e4a3986                                           // 000000336ED4: 7E4A3986
	v_cvt_f32_ubyte0_e32 v6, v39                               // 000000336ED8: 7E0C2327
	v_and_b32_e32 v40, 48, v40                                 // 000000336EDC: 365050B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336EE0: BF870092
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336EE4: CC206006 14924906
	v_bfe_u32 v39, v6, 16, 1                                   // 000000336EEC: D6100027 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000336EF4: BF870121
	v_add3_u32 v6, v6, v39, 0x7fff                             // 000000336EF8: D6550006 03FE4F06 00007FFF
	v_lshrrev_b32_e32 v39, 20, v7                              // 000000336F04: 324E0E94
	v_and_or_b32 v56, 0xffff0000, v6, v37                      // 000000336F08: D6570038 04960CFF FFFF0000
	.long 0x7e4a3987                                           // 000000336F14: 7E4A3987
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000336F18: BF870233
	v_and_or_b32 v39, v39, 15, v40                             // 000000336F1C: D6570027 04A11F27
	v_lshrrev_b32_e32 v6, 24, v16                              // 000000336F24: 320C2098
	v_lshrrev_b32_e32 v16, 26, v16                             // 000000336F28: 3220209A
	v_and_or_b32 v38, v37, 15, v38                             // 000000336F2C: D6570026 04991F25
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336F34: BF870113
	v_and_b32_e32 v6, 48, v6                                   // 000000336F38: 360C0CB0
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000336F3C: 7E4C2326
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336F40: BF870091
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336F44: CC206026 14924926
	v_bfe_u32 v40, v38, 16, 1                                  // 000000336F4C: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336F54: BF870091
	v_add3_u32 v38, v38, v40, 0x7fff                           // 000000336F58: D6550026 03FE5126 00007FFF
	.long 0x7e4a39a6                                           // 000000336F64: 7E4A39A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 000000336F68: 7E4C2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336F6C: BF870091
	v_fma_mix_f32 v38, v38, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336F70: CC206026 14924926
	v_bfe_u32 v39, v38, 16, 1                                  // 000000336F78: D6100027 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336F80: BF870091
	v_add3_u32 v38, v38, v39, 0x7fff                           // 000000336F84: D6550026 03FE4F26 00007FFF
	v_and_or_b32 v57, 0xffff0000, v38, v37                     // 000000336F90: D6570039 04964CFF FFFF0000
	v_lshrrev_b32_e32 v38, 24, v7                              // 000000336F9C: 324C0E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 000000336FA0: 320E0E9C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000336FA4: BF870112
	v_and_or_b32 v6, v38, 15, v6                               // 000000336FA8: D6570006 04191F26
	v_and_or_b32 v7, v16, 48, v7                               // 000000336FB0: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336FB8: BF870092
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000336FBC: 7E0C2306
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336FC0: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336FC8: BF870091
	v_bfe_u32 v16, v6, 16, 1                                   // 000000336FCC: D6100010 02052106
	v_add3_u32 v6, v6, v16, 0x7fff                             // 000000336FD4: D6550006 03FE2106 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000336FE0: BF8700A1
	.long 0x7e4a3986                                           // 000000336FE4: 7E4A3986
	v_cvt_f32_ubyte0_e32 v6, v7                                // 000000336FE8: 7E0C2307
	v_fma_mix_f32 v6, v6, v36, v36 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000336FEC: CC206006 14924906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000336FF4: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000336FF8: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000337000: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000033700C: BF870131
	v_and_or_b32 v16, 0xffff0000, v6, v37                      // 000000337010: D6570010 04960CFF FFFF0000
	.long 0xd73c0006                                           // 00000033701C: D73C0006
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000337020: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000337024: 4A1616FF 00000400
	.long 0xd7000006                                           // 00000033702C: D7000006
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000337030: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000337034: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, s0                   // 000000337038: D5207C07 00020E07
	s_clause 0x3                                               // 000000337040: BF850003
	global_load_b128 v[36:39], v[6:7], off                     // 000000337044: DC5E0000 247C0006
	global_load_b128 v[40:43], v[6:7], off offset:16           // 00000033704C: DC5E0010 287C0006
	global_load_b128 v[44:47], v[6:7], off offset:32           // 000000337054: DC5E0020 2C7C0006
	global_load_b128 v[48:51], v[6:7], off offset:48           // 00000033705C: DC5E0030 307C0006
	.long 0xd7000006                                           // 000000337064: D7000006
	v_cndmask_b32_e32 v0, v6, v4, vcc_lo                       // 000000337068: 02000906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000033706C: BF8700B1
	v_add_co_ci_u32_e64 v7, null, s5, v7, s0                   // 000000337070: D5207C07 00020E05
	s_waitcnt vmcnt(3)                                         // 000000337078: BF890FF7
	v_dot2_f32_bf16 v36, v36, v30, 0                           // 00000033707C: CC1A4024 1A023D24
	v_dot2_f32_bf16 v36, v37, v31, v36                         // 000000337084: CC1A4024 1C923F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000033708C: BF870091
	v_dot2_f32_bf16 v36, v38, v32, v36                         // 000000337090: CC1A4024 1C924126
	v_dot2_f32_bf16 v36, v39, v4, v36                          // 000000337098: CC1A4024 1C920927
	s_waitcnt vmcnt(2)                                         // 0000003370A0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003370A4: BF870091
	v_dot2_f32_bf16 v36, v40, v33, v36                         // 0000003370A8: CC1A4024 1C924328
	v_dot2_f32_bf16 v36, v41, v34, v36                         // 0000003370B0: CC1A4024 1C924529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003370B8: BF870091
	v_dot2_f32_bf16 v36, v42, v35, v36                         // 0000003370BC: CC1A4024 1C92472A
	v_dot2_f32_bf16 v36, v43, v5, v36                          // 0000003370C4: CC1A4024 1C920B2B
	s_waitcnt vmcnt(1)                                         // 0000003370CC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003370D0: BF870091
	v_dot2_f32_bf16 v36, v44, v15, v36                         // 0000003370D4: CC1A4024 1C921F2C
	v_dot2_f32_bf16 v36, v45, v52, v36                         // 0000003370DC: CC1A4024 1C92692D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003370E4: BF870091
	v_dot2_f32_bf16 v36, v46, v53, v36                         // 0000003370E8: CC1A4024 1C926B2E
	v_dot2_f32_bf16 v36, v47, v54, v36                         // 0000003370F0: CC1A4024 1C926D2F
	s_waitcnt vmcnt(0)                                         // 0000003370F8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003370FC: BF870091
	v_dot2_f32_bf16 v36, v48, v55, v36                         // 000000337100: CC1A4024 1C926F30
	v_dot2_f32_bf16 v36, v49, v56, v36                         // 000000337108: CC1A4024 1C927131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000337110: BF870091
	v_dot2_f32_bf16 v36, v50, v57, v36                         // 000000337114: CC1A4024 1C927332
	v_dot2_f32_bf16 v36, v51, v16, v36                         // 00000033711C: CC1A4024 1C922133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000337124: BF870001
	v_add_f32_e32 v20, v20, v36                                // 000000337128: 06284914
	s_clause 0x3                                               // 00000033712C: BF850003
	global_load_b128 v[36:39], v[6:7], off                     // 000000337130: DC5E0000 247C0006
	global_load_b128 v[40:43], v[6:7], off offset:16           // 000000337138: DC5E0010 287C0006
	global_load_b128 v[44:47], v[6:7], off offset:32           // 000000337140: DC5E0020 2C7C0006
	global_load_b128 v[48:51], v[6:7], off offset:48           // 000000337148: DC5E0030 307C0006
	v_mov_b32_e32 v7, v3                                       // 000000337150: 7E0E0303
	s_waitcnt vmcnt(3)                                         // 000000337154: BF890FF7
	v_dot2_f32_bf16 v6, v36, v30, 0                            // 000000337158: CC1A4006 1A023D24
	v_mov_b32_e32 v36, v29                                     // 000000337160: 7E48031D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000337164: BF870092
	v_dot2_f32_bf16 v6, v37, v31, v6                           // 000000337168: CC1A4006 1C1A3F25
	v_dot2_f32_bf16 v6, v38, v32, v6                           // 000000337170: CC1A4006 1C1A4126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000337178: BF870131
	v_dot2_f32_bf16 v4, v39, v4, v6                            // 00000033717C: CC1A4004 1C1A0927
	v_mov_b32_e32 v6, v2                                       // 000000337184: 7E0C0302
	s_waitcnt vmcnt(2)                                         // 000000337188: BF890BF7
	v_dot2_f32_bf16 v4, v40, v33, v4                           // 00000033718C: CC1A4004 1C124328
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000337194: BF870091
	v_dot2_f32_bf16 v4, v41, v34, v4                           // 000000337198: CC1A4004 1C124529
	v_dot2_f32_bf16 v4, v42, v35, v4                           // 0000003371A0: CC1A4004 1C12472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003371A8: BF870131
	v_dot2_f32_bf16 v4, v43, v5, v4                            // 0000003371AC: CC1A4004 1C120B2B
	v_mov_b32_e32 v5, v1                                       // 0000003371B4: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 0000003371B8: BF8907F7
	v_dot2_f32_bf16 v4, v44, v15, v4                           // 0000003371BC: CC1A4004 1C121F2C
	v_mov_b32_e32 v15, v13                                     // 0000003371C4: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003371C8: BF870092
	v_dot2_f32_bf16 v4, v45, v52, v4                           // 0000003371CC: CC1A4004 1C12692D
	v_dot2_f32_bf16 v4, v46, v53, v4                           // 0000003371D4: CC1A4004 1C126B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003371DC: BF8700A1
	v_dot2_f32_bf16 v4, v47, v54, v4                           // 0000003371E0: CC1A4004 1C126D2F
	s_waitcnt vmcnt(0)                                         // 0000003371E8: BF8903F7
	v_dot2_f32_bf16 v4, v48, v55, v4                           // 0000003371EC: CC1A4004 1C126F30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003371F4: BF870091
	v_dot2_f32_bf16 v4, v49, v56, v4                           // 0000003371F8: CC1A4004 1C127131
	v_dot2_f32_bf16 v4, v50, v57, v4                           // 000000337200: CC1A4004 1C127332
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000337208: BF870121
	v_dot2_f32_bf16 v4, v51, v16, v4                           // 00000033720C: CC1A4004 1C122133
	v_mov_b32_e32 v16, v14                                     // 000000337214: 7E20030E
	v_add_f32_e32 v18, v18, v4                                 // 000000337218: 06240912
	v_mov_b32_e32 v4, v0                                       // 00000033721C: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000337220: 917E0E7E
	s_cbranch_execz 38                                         // 000000337224: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0xdc0>
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v28, 32, v28    // 000000337228: CA200105 011C38A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000337230: BF8701A2
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000337234: CA100104 00020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 00000033723C: CA100106 020C010F
	.long 0xd4430000                                           // 000000337244: D4430000
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000337248: 0202380C
	v_mov_b32_e32 v14, v16                                     // 00000033724C: 7E1C0310
	s_mov_b32 s10, exec_lo                                     // 000000337250: BE8A007E
	.long 0xd4c4007e                                           // 000000337254: D4C4007E
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000337258: 0202380C
	s_cbranch_execz 64815                                      // 00000033725C: BFA5FD2F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0x21c>
	v_and_b32_e32 v2, 0x7ffffffc, v27                          // 000000337260: 360436FF 7FFFFFFC
	.long 0xd7000100                                           // 000000337268: D7000100
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 00000033726C: 0202330A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000337270: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000337274: D5207C01 00062680
	.long 0xd700010d                                           // 00000033727C: D700010D
	v_cndmask_b32_e32 v1, v21, v26, vcc_lo                     // 000000337280: 02023515
	v_add_co_ci_u32_e64 v14, null, 0, v22, s1                  // 000000337284: D5207C0E 00062C80
	.long 0xd700011d                                           // 00000033728C: D700011D
	v_cndmask_b32_e32 v1, v23, v2, vcc_lo                      // 000000337290: 02020517
	s_delay_alu instid0(VALU_DEP_1)                            // 000000337294: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v24, s1                  // 000000337298: D5207C1E 00063080
	s_clause 0x2                                               // 0000003372A0: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 0000003372A4: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 0000003372AC: DC560000 0D7C000D
	global_load_b32 v29, v[29:30], off                         // 0000003372B4: DC520000 1D7C001D
	s_branch 64791                                             // 0000003372BC: BFA0FD17 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0x21c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000003372C0: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003372C4: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 0000003372C8: 8C7E0D7E
	.long 0xd71f0000                                           // 0000003372CC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000003372D0: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000003372D4: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000003372D8: 3A060088
	s_waitcnt vmcnt(2)                                         // 0000003372DC: BF890BF7
	v_xor_b32_e32 v5, 4, v0                                    // 0000003372E0: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003372E4: BF870093
	.long 0xd44c0000                                           // 0000003372E8: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000003372EC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 0000003372F0: D5010001 00020300
	.long 0xd44c0000                                           // 0000003372F8: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 0000003372FC: 020206A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000337300: BF870112
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000337304: 30020282
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000337308: D5010003 00020700
	.long 0xd44c0000                                           // 000000337310: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000337314: 02020AA0
	ds_bpermute_b32 v2, v1, v20                                // 000000337318: DACC0000 02001401
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000337320: D5010005 00020B00
	s_waitcnt lgkmcnt(0)                                       // 000000337328: BF89FC07
	v_add_f32_e32 v2, v20, v2                                  // 00000033732C: 06040514
	ds_bpermute_b32 v1, v1, v18                                // 000000337330: DACC0000 01001201
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000337338: 30060682
	ds_bpermute_b32 v4, v3, v2                                 // 00000033733C: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 000000337344: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 000000337348: 06020312
	s_waitcnt lgkmcnt(0)                                       // 00000033734C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000337350: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 000000337354: DACC0000 03000103
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000033735C: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 000000337360: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 000000337364: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 000000337368: DACC0000 03000205
	s_waitcnt lgkmcnt(0)                                       // 000000337370: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000337374: 06040702
	ds_bpermute_b32 v4, v5, v1                                 // 000000337378: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 000000337380: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000337384: BF870091
	.long 0xd44c0000                                           // 000000337388: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 00000033738C: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000337390: D5010005 00020B00
	s_delay_alu instid0(VALU_DEP_1)                            // 000000337398: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000033739C: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000003373A0: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000003373A4: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 0000003373A8: DACC0000 03000205
	s_waitcnt lgkmcnt(0)                                       // 0000003373B0: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000003373B4: 06040702
	ds_bpermute_b32 v4, v5, v1                                 // 0000003373B8: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000003373C0: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003373C4: BF870091
	.long 0xd44c0000                                           // 0000003373C8: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000003373CC: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s0                           // 0000003373D0: D5010000 00020B00
	.long 0xd44a0000                                           // 0000003373D8: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 0000003373DC: 02022280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003373E0: BF870002
	v_lshlrev_b32_e32 v5, 2, v0                                // 0000003373E4: 300A0082
	s_and_b32 s0, s0, vcc_lo                                   // 0000003373E8: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000003373EC: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000003373F0: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000003373F4: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000003373FC: DACC0000 01000005
	s_and_saveexec_b32 s1, s0                                  // 000000337404: BE812000
	s_cbranch_execz 35                                         // 000000337408: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi2ELi32ELi1EEEvPKhPKtPtll+0xf98>
	s_waitcnt lgkmcnt(1)                                       // 00000033740C: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 000000337410: 06040702
	.long 0x7f063880                                           // 000000337414: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000337418: BF89FC07
	v_add_f32_e32 v4, v0, v1                                   // 00000033741C: 06080300
	.long 0xd73c0000                                           // 000000337420: D73C0000
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000337424: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000337428: 84808102
	.long 0x7e0a3982                                           // 00000033742C: 7E0A3982
	.long 0x7f0a3983                                           // 000000337430: 7F0A3983
	.long 0x7e063984                                           // 000000337434: 7E063984
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000337438: BF870194
	.long 0xd7006a00                                           // 00000033743C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000337440: 02020008
	v_and_b32_e32 v5, 1, v5                                    // 000000337444: 360A0A81
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000337448: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000337450: BF870194
	v_and_b32_e32 v6, 1, v3                                    // 000000337454: 360C0681
	v_add3_u32 v5, v2, v5, 0x7fff                              // 000000337458: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 000000337464: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000337468: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000033746C: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000337470: D5207C03 01AA0201
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000337478: D6550004 03FE0D04 00007FFF
	s_clause 0x1                                               // 000000337484: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 000000337488: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000337490: DC960000 007C0402
	s_endpgm                                                   // 000000337498: BFB00000
		...

