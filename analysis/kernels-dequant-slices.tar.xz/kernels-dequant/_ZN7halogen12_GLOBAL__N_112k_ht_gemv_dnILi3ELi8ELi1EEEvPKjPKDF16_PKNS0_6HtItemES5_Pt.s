0000000000a83300 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt>:
; _ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt():
	s_load_b256 s[4:11], s[0:1], null                          // 000000A83300: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000A83308: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A8330C: BF870009
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000A83310: 84828402
	s_waitcnt lgkmcnt(0)                                       // 000000A83314: BF89FC07
	s_add_u32 s2, s8, s2                                       // 000000A83318: 80020208
	s_addc_u32 s3, s9, s3                                      // 000000A8331C: 82030309
	s_load_b64 s[8:9], s[0:1], 0x20                            // 000000A83320: F4040200 F8000020
	s_load_b128 s[12:15], s[2:3], null                         // 000000A83328: F4080301 F8000000
	s_mov_b32 s0, exec_lo                                      // 000000A83330: BE80007E
	v_cmpx_gt_u32_e32 0x50, v0                                 // 000000A83334: 7D9800FF 00000050
	s_cbranch_execz 16                                         // 000000A8333C: BFA50010 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x80>
	s_waitcnt lgkmcnt(0)                                       // 000000A83340: BF89FC07
	s_add_i32 s1, s15, -1                                      // 000000A83344: 8101C10F
	v_lshlrev_b32_e32 v5, 4, v0                                // 000000A83348: 300A0084
	s_min_i32 s1, s14, s1                                      // 000000A8334C: 8901010E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A83350: BF870009
	s_mul_i32 s2, s1, 0x500                                    // 000000A83354: 9602FF01 00000500
	s_mul_hi_i32 s1, s1, 0x500                                 // 000000A8335C: 9701FF01 00000500
	s_add_u32 s2, s6, s2                                       // 000000A83364: 80020206
	s_addc_u32 s3, s7, s1                                      // 000000A83368: 82030107
	global_load_b128 v[1:4], v5, s[2:3]                        // 000000A8336C: DC5E0000 01020005
	s_waitcnt vmcnt(0)                                         // 000000A83374: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 000000A83378: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A83380: 8C7E007E
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000A83384: 320E0085
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v8, 31, v0         // 000000A83388: CA240080 0B08009F
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v13, 0             // 000000A83390: CA100080 120C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A83398: BF870193
	v_mul_u32_u24_e32 v1, 5, v7                                // 000000A8339C: 16020E85
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v9, 2, v8      // 000000A833A0: CA220080 0C081082
	v_mov_b32_e32 v14, 0                                       // 000000A833A8: 7E1C0280
	v_mov_b32_e32 v16, 0                                       // 000000A833AC: 7E200280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A833B0: BF870004
	v_min_u32_e32 v2, 35, v1                                   // 000000A833B4: 260402A3
	s_waitcnt lgkmcnt(0)                                       // 000000A833B8: BF89FC07
	s_mul_hi_i32 s2, s12, 0x96000                              // 000000A833BC: 9702FF0C 00096000
	s_mul_i32 s3, s12, 0x96000                                 // 000000A833C4: 9603FF0C 00096000
	s_mul_hi_i32 s6, s13, 0x7800                               // 000000A833CC: 9706FF0D 00007800
	s_mul_i32 s7, s13, 0x7800                                  // 000000A833D4: 9607FF0D 00007800
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v10, 5, v2      // 000000A833DC: CA200080 110A0485
	s_barrier                                                  // 000000A833E4: BFBD0000
	buffer_gl0_inv                                             // 000000A833E8: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v1, v10                           // 000000A833F0: 7C921501
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A833F4: BE81206A
	s_cbranch_execz 29                                         // 000000A833F8: BFA5001D <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x170>
	v_mul_u32_u24_e32 v3, 0xf00, v7                            // 000000A833FC: 16060EFF 00000F00
	s_add_u32 s0, s4, s3                                       // 000000A83404: 80000304
	s_addc_u32 s16, s5, s2                                     // 000000A83408: 82100205
	s_add_u32 s0, s0, s7                                       // 000000A8340C: 80000700
	s_addc_u32 s16, s16, s6                                    // 000000A83410: 82100610
	.long 0xd7000003                                           // 000000A83414: D7000003
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 000000A83418: 02020600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A8341C: BF870111
	v_add_co_ci_u32_e64 v4, null, s16, 0, s0                   // 000000A83420: D5207C04 00010010
	.long 0xd7000003                                           // 000000A83428: D7000003
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000A8342C: 02021303
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A83430: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 000000A83434: D5207C04 00020880
	s_clause 0x5                                               // 000000A8343C: BF850005
	global_load_b32 v11, v[3:4], off                           // 000000A83440: DC520000 0B7C0003
	global_load_b32 v12, v[3:4], off offset:128                // 000000A83448: DC520080 0C7C0003
	global_load_b32 v13, v[3:4], off offset:256                // 000000A83450: DC520100 0D7C0003
	global_load_b32 v14, v[3:4], off offset:384                // 000000A83458: DC520180 0E7C0003
	global_load_b32 v16, v[3:4], off offset:512                // 000000A83460: DC520200 107C0003
	global_load_b32 v17, v[3:4], off offset:640                // 000000A83468: DC520280 117C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A83470: 8C7E017E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000A83474: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000A8347C: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 000000A83484: CA100080 17180080
	v_mov_b32_e32 v15, 0                                       // 000000A8348C: 7E1E0280
	s_and_saveexec_b32 s1, vcc_lo                              // 000000A83490: BE81206A
	s_cbranch_execz 1040                                       // 000000A83494: BFA50410 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x11d8>
	v_lshl_or_b32 v5, v8, 3, 4                                 // 000000A83498: D6560005 02110708
	v_mad_u32_u24 v19, v8, 24, 0x2f0                           // 000000A834A0: D60B0013 03FD3108 000002F0
	v_mad_u32_u24 v21, 0x320, v7, v9                           // 000000A834AC: D60B0015 04260EFF 00000320
	s_add_u32 s16, s3, s7                                      // 000000A834B8: 80100703
	s_addc_u32 s17, s2, s6                                     // 000000A834BC: 82110602
	v_mad_u32_u24 v18, v5, 3, 0x2f0                            // 000000A834C0: D60B0012 03FD0705 000002F0
	v_cmp_lt_u32_e32 vcc_lo, 5, v5                             // 000000A834CC: 7C920A85
	v_lshrrev_b32_e32 v23, 5, v19                              // 000000A834D0: 322E2685
	v_mul_i32_i24_e32 v24, -3, v5                              // 000000A834D4: 12300AC3
	v_mul_i32_i24_e32 v20, 0xffffffe8, v8                      // 000000A834D8: 122810FF FFFFFFE8
	v_lshrrev_b32_e32 v22, 5, v18                              // 000000A834E0: 322C2485
	v_mad_u64_u32 v[3:4], null, 0x300, v1, s[16:17]            // 000000A834E4: D6FE7C03 004202FF 00000300
	v_subrev_nc_u32_e32 v23, 24, v23                           // 000000A834F0: 4E2E2E98
	v_dual_mov_b32 v15, 0 :: v_dual_and_b32 v18, 0x7e0, v18    // 000000A834F4: CA240080 0F1224FF 000007E0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83500: BF870004
	v_subrev_nc_u32_e32 v22, 24, v22                           // 000000A83504: 4E2C2C98
	v_mul_u32_u24_e32 v6, 0x320, v7                            // 000000A83508: 160C0EFF 00000320
	v_sub_nc_u32_e32 v28, 0, v2                                // 000000A83510: 4C380480
	v_add_nc_u32_e32 v29, 1, v1                                // 000000A83514: 4A3A0281
	v_add3_u32 v26, v24, v18, 0xfffffd34                       // 000000A83518: D655001A 03FE2518 FFFFFD34
	v_dual_cndmask_b32 v5, 23, v22 :: v_dual_add_nc_u32 v30, 0x400, v21// 000000A83524: CA602C97 051E2AFF 00000400
	v_cmp_ne_u32_e32 vcc_lo, 0, v8                             // 000000A83530: 7C9A1080
	s_mov_b32 s2, 0                                            // 000000A83534: BE820080
	s_movk_i32 s3, 0x1eee                                      // 000000A83538: B0031EEE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000A8353C: BF870132
	v_subrev_nc_u32_e32 v22, 23, v5                            // 000000A83540: 4E2C0A97
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v19, 0x7e0, v19    // 000000A83544: CA240080 181226FF 000007E0
	v_mov_b32_e32 v21, 0                                       // 000000A83550: 7E2A0280
	v_add3_u32 v25, v20, v19, 0xfffffd34                       // 000000A83554: D6550019 03FE2714 FFFFFD34
	v_dual_cndmask_b32 v19, 23, v23 :: v_dual_add_nc_u32 v20, 1, v5// 000000A83560: CA602E97 13140A81
	.long 0xd7006a03                                           // 000000A83568: D7006A03
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 000000A8356C: 02021303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A83570: BF870191
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000A83574: D5207C04 01AA0880
	v_cmp_gt_u32_e32 vcc_lo, 24, v20                           // 000000A8357C: 7C982898
	v_dual_mov_b32 v23, 0 :: v_dual_cndmask_b32 v18, v22, v20  // 000000A83580: CA120080 17122916
	v_cmp_gt_i32_e32 vcc_lo, 23, v19                           // 000000A83588: 7C882697
	v_lshl_add_u32 v20, v19, 2, v6                             // 000000A8358C: D6460014 04190513
	v_lshl_add_u32 v22, v5, 2, v6                              // 000000A83594: D6460016 04190505
	v_and_b32_e32 v5, 16, v0                                   // 000000A8359C: 360A0090
	v_lshl_add_u32 v18, v18, 2, v6                             // 000000A835A0: D6460012 04190512
	v_cndmask_b32_e64 v19, 0xffffffa4, 4, vcc_lo               // 000000A835A8: D5010013 01A908FF FFFFFFA4
	.long 0xd7006a03                                           // 000000A835B4: D7006A03
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000A835B8: 02020604
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A835BC: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s5, v4, vcc_lo               // 000000A835C0: D5207C04 01AA0805
	v_lshl_or_b32 v27, v1, 5, v5                               // 000000A835C8: D656001B 04150B01
	.long 0xd7006a05                                           // 000000A835D0: D7006A05
	v_cndmask_b32_e32 v1, 0x300, v3, vcc_lo                    // 000000A835D4: 020206FF 00000300
	v_add_nc_u32_e32 v3, v20, v19                              // 000000A835DC: 4A062714
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A835E0: BF870004
	v_add_co_ci_u32_e64 v6, null, 0, v4, vcc_lo                // 000000A835E4: D5207C06 01AA0880
	v_add_nc_u32_e32 v31, 0x400, v20                           // 000000A835EC: 4A3E28FF 00000400
	v_add_nc_u32_e32 v33, 0x400, v22                           // 000000A835F4: 4A422CFF 00000400
	v_add_nc_u32_e32 v34, 0x400, v18                           // 000000A835FC: 4A4424FF 00000400
	v_mov_b32_e32 v22, 0                                       // 000000A83604: 7E2C0280
	v_add_nc_u32_e32 v32, 0x400, v3                            // 000000A83608: 4A4006FF 00000400
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v19, 0             // 000000A83610: CA100080 14120080
	v_mov_b32_e32 v18, 0                                       // 000000A83618: 7E240280
	s_branch 914                                               // 000000A8361C: BFA00392 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1168>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A83620: 8C7E007E
	ds_load_2addr_b32 v[35:36], v32 offset0:64 offset1:88      // 000000A83624: D8DC5840 23000020
	ds_load_2addr_b32 v[37:38], v34 offset0:64 offset1:88      // 000000A8362C: D8DC5840 25000022
	ds_load_2addr_b32 v[41:42], v31 offset0:64 offset1:88      // 000000A83634: D8DC5840 2900001F
	ds_load_2addr_b32 v[44:45], v33 offset0:64 offset1:88      // 000000A8363C: D8DC5840 2C000021
	ds_load_b128 v[1:4], v27                                   // 000000A83644: DBFC0000 0100001B
	v_add_nc_u32_e32 v29, 1, v29                               // 000000A8364C: 4A3A3A81
	.long 0xd7000005                                           // 000000A83650: D7000005
	v_cndmask_b32_e32 v1, 0x300, v5, vcc_lo                    // 000000A83654: 02020AFF 00000300
	v_add_nc_u32_e32 v27, 32, v27                              // 000000A8365C: 4A3636A0
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000A83660: D5207C06 00020C80
	s_waitcnt lgkmcnt(3)                                       // 000000A83668: BF89FC37
	v_dual_mov_b32 v40, v35 :: v_dual_mov_b32 v43, v37         // 000000A8366C: CA100123 282A0125
	s_waitcnt lgkmcnt(2)                                       // 000000A83674: BF89FC27
	v_mov_b32_e32 v37, v42                                     // 000000A83678: 7E4A032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A8367C: BF8701B2
	.long 0xd73d002f                                           // 000000A83680: D73D002F
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 000000A83684: 02025119
	s_waitcnt lgkmcnt(1)                                       // 000000A83688: BF89FC17
	.long 0xd73d002a                                           // 000000A8368C: D73D002A
	v_cndmask_b32_e32 v1, v26, v43, vcc_lo                     // 000000A83690: 0202571A
	.long 0xd73d0023                                           // 000000A83694: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 000000A83698: 02024919
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A8369C: BF870193
	v_and_b32_e32 v43, 0xffff, v47                             // 000000A836A0: 36565EFF 0000FFFF
	v_bfe_u32 v44, v42, 9, 16                                  // 000000A836A8: D610002C 0241132A
	v_bfe_u32 v48, v42, 3, 16                                  // 000000A836B0: D6100030 0241072A
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A836B8: BF870004
	v_bfe_u32 v49, v35, 9, 16                                  // 000000A836BC: D6100031 02411323
	v_bfe_u32 v50, v35, 6, 16                                  // 000000A836C4: D6100032 02410D23
	.long 0xd72c002b                                           // 000000A836CC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A836D0: 020256FF 83DCD12D
	.long 0xd72c002c                                           // 000000A836D8: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A836DC: 020258FF 83DCD12D
	v_bfe_u32 v51, v35, 3, 16                                  // 000000A836E4: D6100033 02410723
	.long 0xd72c0031                                           // 000000A836EC: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A836F0: 020262FF 83DCD12D
	.long 0xd72c0032                                           // 000000A836F8: D72C0032
	v_cndmask_b32_e32 v1, 0x83dcd12d, v50, vcc_lo              // 000000A836FC: 020264FF 83DCD12D
	.long 0xd72c0030                                           // 000000A83704: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A83708: 020260FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83710: BF870004
	.long 0xd72c0033                                           // 000000A83714: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v51, vcc_lo              // 000000A83718: 020266FF 83DCD12D
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000A83720: D622002B 03FD012B 00006400
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A8372C: D622002C 03FD012C 00006400
	v_mov_b32_e32 v39, v45                                     // 000000A83738: 7E4E032D
	ds_load_2addr_b32 v[40:41], v31 offset0:112 offset1:136    // 000000A8373C: D8DC8870 2800001F
	ds_load_2addr_b32 v[45:46], v32 offset0:112 offset1:136    // 000000A83744: D8DC8870 2D000020
	v_sad_u8 v49, v49, 0, 0x6400                               // 000000A8374C: D6220031 03FD0131 00006400
	v_lshlrev_b32_e32 v43, 16, v43                             // 000000A83758: 30565690
	v_and_b32_e32 v44, 0xffff, v44                             // 000000A8375C: 365858FF 0000FFFF
	.long 0xd73d0024                                           // 000000A83764: D73D0024
	v_cndmask_b32_e32 v1, v26, v38, vcc_lo                     // 000000A83768: 02024D1A
	v_bfe_u32 v37, v47, 9, 16                                  // 000000A8376C: D6100025 0241132F
	v_bfe_u32 v38, v47, 6, 16                                  // 000000A83774: D6100026 02410D2F
	v_bfe_u32 v39, v47, 3, 16                                  // 000000A8377C: D6100027 0241072F
	v_bfe_u32 v47, v42, 6, 16                                  // 000000A83784: D610002F 02410D2A
	v_and_b32_e32 v42, 0xffff, v42                             // 000000A8378C: 365454FF 0000FFFF
	.long 0xd72c0025                                           // 000000A83794: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A83798: 02024AFF 83DCD12D
	.long 0xd72c0026                                           // 000000A837A0: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A837A4: 02024CFF 83DCD12D
	.long 0xd72c0027                                           // 000000A837AC: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A837B0: 02024EFF 83DCD12D
	v_bfe_u32 v52, v36, 9, 16                                  // 000000A837B8: D6100034 02411324
	.long 0xd72c002a                                           // 000000A837C0: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A837C4: 020254FF 83DCD12D
	.long 0xd72c002f                                           // 000000A837CC: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 000000A837D0: 02025EFF 83DCD12D
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A837D8: D6220030 03FD0130 00006400
	v_bfe_u32 v53, v36, 6, 16                                  // 000000A837E4: D6100035 02410D24
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A837EC: D6220025 03FD0125 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000A837F8: D6220026 03FD0126 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A83804: D6220027 03FD0127 00006400
	.long 0xd72c0034                                           // 000000A83810: D72C0034
	v_cndmask_b32_e32 v1, 0x83dcd12d, v52, vcc_lo              // 000000A83814: 020268FF 83DCD12D
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A8381C: D622002A 03FD012A 00006400
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A83828: 364A4AFF 0000FFFF
	v_bfe_u32 v54, v36, 3, 16                                  // 000000A83830: D6100036 02410724
	v_and_or_b32 v39, 0xffff, v39, v43                         // 000000A83838: D6570027 04AE4EFF 0000FFFF
	v_sad_u8 v47, v47, 0, 0x6400                               // 000000A83844: D622002F 03FD012F 00006400
	v_sad_u8 v43, v51, 0, 0x6400                               // 000000A83850: D622002B 03FD0133 00006400
	v_lshl_or_b32 v37, v38, 16, v37                            // 000000A8385C: D6560025 04952126
	v_sad_u8 v38, v50, 0, 0x6400                               // 000000A83864: D6220026 03FD0132 00006400
	v_pk_fma_f16 v39, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83870: CC0E0027 0BFC0727 0000C931
	v_lshl_or_b32 v44, v47, 16, v44                            // 000000A8387C: D656002C 04B1212F
	.long 0xd72c0033                                           // 000000A83884: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v54, vcc_lo              // 000000A83888: 02026CFF 83DCD12D
	v_pk_fma_f16 v37, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83890: CC0E0025 0BFC0725 0000C931
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A8389C: 30545490
	v_and_b32_e32 v36, 0xffff, v36                             // 000000A838A0: 364848FF 0000FFFF
	v_pk_fma_f16 v47, v44, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A838A8: CC0E002F 0BFC072C 0000C931
	s_waitcnt lgkmcnt(2)                                       // 000000A838B4: BF89FC27
	v_dot2acc_f32_f16 v15, v37, v1                             // 000000A838B8: 041E0325
	v_and_b32_e32 v37, 0xffff, v49                             // 000000A838BC: 364A62FF 0000FFFF
	v_and_or_b32 v42, 0xffff, v48, v42                         // 000000A838C4: D657002A 04AA60FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A838D0: BF870223
	v_dot2acc_f32_f16 v15, v39, v2                             // 000000A838D4: 041E0527
	v_sad_u8 v39, v52, 0, 0x6400                               // 000000A838D8: D6220027 03FD0134 00006400
	v_lshl_or_b32 v37, v38, 16, v37                            // 000000A838E4: D6560025 04952126
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A838EC: BF870004
	v_pk_fma_f16 v48, v42, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A838F0: CC0E0030 0BFC072A 0000C931
	.long 0xd72c0026                                           // 000000A838FC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000A83900: 020248FF 83DCD12D
	.long 0xd72c002a                                           // 000000A83908: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v53, vcc_lo              // 000000A8390C: 02026AFF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 000000A83914: BF89FC07
	v_dual_mov_b32 v39, v45 :: v_dual_and_b32 v50, 0xffff, v39 // 000000A83918: CA24012D 27324EFF 0000FFFF
	v_pk_fma_f16 v45, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83924: CC0E002D 0BFC0725 0000C931
	v_dot2acc_f32_f16 v15, v47, v3                             // 000000A83930: 041E072F
	v_mov_b32_e32 v47, v41                                     // 000000A83934: 7E5E0329
	v_sad_u8 v52, v38, 0, 0x6400                               // 000000A83938: D6220034 03FD0126 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83944: BF870004
	v_dual_dot2acc_f32_f16 v24, v45, v1 :: v_dual_and_b32 v35, 0xffff, v35// 000000A83948: CB24032D 182246FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A83954: D622002A 03FD012A 00006400
	.long 0xd73d0025                                           // 000000A83960: D73D0025
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000A83964: 02024F19
	v_sad_u8 v40, v51, 0, 0x6400                               // 000000A83968: D6220028 03FD0133 00006400
	v_dot2acc_f32_f16 v15, v48, v4                             // 000000A83974: 041E0930
	.long 0xd72c0023                                           // 000000A83978: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A8397C: 020246FF 83DCD12D
	v_lshl_or_b32 v39, v42, 16, v50                            // 000000A83984: D6560027 04C9212A
	v_lshlrev_b32_e32 v42, 16, v52                             // 000000A8398C: 30546890
	v_bfe_u32 v45, v37, 9, 16                                  // 000000A83990: D610002D 02411325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A83998: BF870193
	v_pk_fma_f16 v39, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8399C: CC0E0027 0BFC0727 0000C931
	v_and_or_b32 v40, 0xffff, v40, v42                         // 000000A839A8: D6570028 04AA50FF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000A839B4: D6220023 03FD0123 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A839C0: BF870194
	.long 0xd72c002d                                           // 000000A839C4: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A839C8: 02025AFF 83DCD12D
	v_pk_fma_f16 v40, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A839D0: CC0E0028 0BFC0728 0000C931
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A839DC: BF870093
	v_lshlrev_b32_e32 v35, 16, v35                             // 000000A839E0: 30464690
	v_and_or_b32 v49, 0xffff, v43, v35                         // 000000A839E4: D6570031 048E56FF 0000FFFF
	ds_load_2addr_b32 v[35:36], v34 offset0:112 offset1:136    // 000000A839F0: D8DC8870 23000022
	ds_load_2addr_b32 v[43:44], v33 offset0:112 offset1:136    // 000000A839F8: D8DC8870 2B000021
	v_pk_fma_f16 v38, v49, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83A00: CC0E0026 0BFC0731 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A83A0C: BF870091
	v_dot2acc_f32_f16 v24, v38, v2                             // 000000A83A10: 04300526
	v_dot2acc_f32_f16 v24, v39, v3                             // 000000A83A14: 04300727
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000A83A18: BF870151
	v_dot2acc_f32_f16 v24, v40, v4                             // 000000A83A1C: 04300928
	s_waitcnt lgkmcnt(1)                                       // 000000A83A20: BF89FC17
	v_mov_b32_e32 v42, v35                                     // 000000A83A24: 7E540323
	v_bfe_u32 v35, v37, 6, 16                                  // 000000A83A28: D6100023 02410D25
	s_waitcnt lgkmcnt(0)                                       // 000000A83A30: BF89FC07
	.long 0xd73d0026                                           // 000000A83A34: D73D0026
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 000000A83A38: 0202551A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A83A3C: BF870252
	.long 0xd72c0023                                           // 000000A83A40: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A83A44: 020246FF 83DCD12D
	v_and_b32_e32 v42, 0xffff, v37                             // 000000A83A4C: 36544AFF 0000FFFF
	v_sad_u8 v39, v45, 0, 0x6400                               // 000000A83A54: D6220027 03FD012D 00006400
	v_bfe_u32 v37, v37, 3, 16                                  // 000000A83A60: D6100025 02410725
	v_bfe_u32 v40, v38, 9, 16                                  // 000000A83A68: D6100028 02411326
	.long 0xd72c002a                                           // 000000A83A70: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A83A74: 020254FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83A7C: BF870004
	v_and_b32_e32 v39, 0xffff, v39                             // 000000A83A80: 364E4EFF 0000FFFF
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000A83A88: D6220023 03FD0123 00006400
	.long 0xd72c0025                                           // 000000A83A94: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A83A98: 02024AFF 83DCD12D
	.long 0xd72c0028                                           // 000000A83AA0: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A83AA4: 020250FF 83DCD12D
	v_bfe_u32 v43, v38, 6, 16                                  // 000000A83AAC: D610002B 02410D26
	v_bfe_u32 v45, v38, 3, 16                                  // 000000A83AB4: D610002D 02410726
	v_and_b32_e32 v38, 0xffff, v38                             // 000000A83ABC: 364C4CFF 0000FFFF
	v_lshl_or_b32 v35, v35, 16, v39                            // 000000A83AC4: D6560023 049D2123
	v_sad_u8 v39, v42, 0, 0x6400                               // 000000A83ACC: D6220027 03FD012A 00006400
	.long 0xd72c002a                                           // 000000A83AD8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A83ADC: 020256FF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A83AE4: D6220025 03FD0125 00006400
	.long 0xd72c002b                                           // 000000A83AF0: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A83AF4: 02024CFF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A83AFC: D6220028 03FD0128 00006400
	v_lshlrev_b32_e32 v41, 16, v39                             // 000000A83B08: 30524E90
	.long 0xd72c002d                                           // 000000A83B0C: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A83B10: 02025AFF 83DCD12D
	.long 0xd73d0026                                           // 000000A83B18: D73D0026
	v_cndmask_b32_e32 v1, v25, v46, vcc_lo                     // 000000A83B1C: 02025D19
	v_pk_fma_f16 v35, v35, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83B20: CC0E0023 0BFC0723 0000C931
	v_and_b32_e32 v40, 0xffff, v40                             // 000000A83B2C: 365050FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A83B34: D622002A 03FD012A 00006400
	v_sad_u8 v39, v43, 0, 0x6400                               // 000000A83B40: D6220027 03FD012B 00006400
	v_and_or_b32 v37, 0xffff, v37, v41                         // 000000A83B4C: D6570025 04A64AFF 0000FFFF
	v_dot2acc_f32_f16 v23, v35, v1                             // 000000A83B58: 042E0323
	v_sad_u8 v41, v45, 0, 0x6400                               // 000000A83B5C: D6220029 03FD012D 00006400
	v_and_b32_e32 v35, 0xffff, v38                             // 000000A83B68: 36464CFF 0000FFFF
	v_lshlrev_b32_e32 v39, 16, v39                             // 000000A83B70: 304E4E90
	v_pk_fma_f16 v45, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83B74: CC0E002D 0BFC0725 0000C931
	v_mov_b32_e32 v37, v44                                     // 000000A83B80: 7E4A032C
	v_lshl_or_b32 v40, v42, 16, v40                            // 000000A83B84: D6560028 04A1212A
	v_bfe_u32 v42, v38, 9, 16                                  // 000000A83B8C: D610002A 02411326
	v_and_or_b32 v47, 0xffff, v41, v39                         // 000000A83B94: D657002F 049E52FF 0000FFFF
	v_bfe_u32 v41, v38, 6, 16                                  // 000000A83BA0: D6100029 02410D26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A83BA8: BF870214
	v_pk_fma_f16 v46, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83BAC: CC0E002E 0BFC0728 0000C931
	.long 0xd72c002a                                           // 000000A83BB8: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A83BBC: 020254FF 83DCD12D
	.long 0xd73d0027                                           // 000000A83BC4: D73D0027
	v_cndmask_b32_e32 v1, v26, v36, vcc_lo                     // 000000A83BC8: 0202491A
	v_bfe_u32 v36, v38, 3, 16                                  // 000000A83BCC: D6100024 02410726
	.long 0xd72c0025                                           // 000000A83BD4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 000000A83BD8: 020252FF 83DCD12D
	.long 0xd72c0029                                           // 000000A83BE0: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A83BE4: 020246FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A83BEC: BF870003
	.long 0xd72c002c                                           // 000000A83BF0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000A83BF4: 020248FF 83DCD12D
	v_sad_u8 v38, v42, 0, 0x6400                               // 000000A83BFC: D6220026 03FD012A 00006400
	ds_load_2addr_b32 v[35:36], v32 offset0:160 offset1:184    // 000000A83C08: D8DCB8A0 23000020
	v_bfe_u32 v40, v39, 9, 16                                  // 000000A83C10: D6100028 02411327
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A83C18: D6220025 03FD0125 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 000000A83C24: D6220029 03FD0129 00006400
	v_and_b32_e32 v38, 0xffff, v38                             // 000000A83C30: 364C4CFF 0000FFFF
	v_bfe_u32 v42, v39, 6, 16                                  // 000000A83C38: D610002A 02410D27
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A83C40: D622002C 03FD012C 00006400
	.long 0xd72c0028                                           // 000000A83C4C: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A83C50: 020250FF 83DCD12D
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000A83C58: 30525290
	v_lshl_or_b32 v37, v37, 16, v38                            // 000000A83C5C: D6560025 04992125
	v_and_b32_e32 v48, 0xffff, v39                             // 000000A83C64: 36604EFF 0000FFFF
	v_bfe_u32 v43, v39, 3, 16                                  // 000000A83C6C: D610002B 02410727
	ds_load_2addr_b32 v[38:39], v31 offset0:160 offset1:184    // 000000A83C74: D8DCB8A0 2600001F
	.long 0xd72c002a                                           // 000000A83C7C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A83C80: 020254FF 83DCD12D
	v_pk_fma_f16 v50, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83C88: CC0E0032 0BFC0725 0000C931
	v_and_or_b32 v37, 0xffff, v44, v41                         // 000000A83C94: D6570025 04A658FF 0000FFFF
	v_sad_u8 v49, v40, 0, 0x6400                               // 000000A83CA0: D6220031 03FD0128 00006400
	ds_load_2addr_b32 v[40:41], v34 offset0:160 offset1:184    // 000000A83CAC: D8DCB8A0 28000022
	.long 0xd72c0033                                           // 000000A83CB4: D72C0033
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A83CB8: 020256FF 83DCD12D
	ds_load_2addr_b32 v[43:44], v33 offset0:160 offset1:184    // 000000A83CC0: D8DCB8A0 2B000021
	v_pk_fma_f16 v52, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83CC8: CC0E0034 0BFC0725 0000C931
	s_waitcnt lgkmcnt(3)                                       // 000000A83CD4: BF89FC37
	v_mov_b32_e32 v37, v35                                     // 000000A83CD8: 7E4A0323
	.long 0xd72c0030                                           // 000000A83CDC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A83CE0: 020260FF 83DCD12D
	v_and_b32_e32 v49, 0xffff, v49                             // 000000A83CE8: 366262FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A83CF0: D622002A 03FD012A 00006400
	v_dual_dot2acc_f32_f16 v23, v45, v2 :: v_dual_dot2acc_f32_f16 v22, v50, v1// 000000A83CFC: CB18052D 17160332
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A83D04: BF870002
	v_lshl_or_b32 v35, v42, 16, v49                            // 000000A83D08: D6560023 04C5212A
	v_sad_u8 v48, v48, 0, 0x6400                               // 000000A83D10: D6220030 03FD0130 00006400
	v_sad_u8 v42, v51, 0, 0x6400                               // 000000A83D1C: D622002A 03FD0133 00006400
	s_waitcnt lgkmcnt(2)                                       // 000000A83D28: BF89FC27
	.long 0xd73d0025                                           // 000000A83D2C: D73D0025
	v_cndmask_b32_e32 v1, v25, v37, vcc_lo                     // 000000A83D30: 02024B19
	v_dot2acc_f32_f16 v23, v46, v3                             // 000000A83D34: 042E072E
	v_pk_fma_f16 v35, v35, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83D38: CC0E0023 0BFC0723 0000C931
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000A83D44: 30606090
	v_dot2acc_f32_f16 v22, v52, v2                             // 000000A83D48: 042C0534
	v_pk_fma_f16 v38, v47, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83D4C: CC0E0026 0BFC072F 0000C931
	v_bfe_u32 v45, v37, 9, 16                                  // 000000A83D58: D610002D 02411325
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A83D60: BF870214
	v_and_or_b32 v42, 0xffff, v42, v48                         // 000000A83D64: D657002A 04C254FF 0000FFFF
	v_dot2acc_f32_f16 v22, v35, v3                             // 000000A83D70: 042C0723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A83D74: BF870193
	.long 0xd72c0023                                           // 000000A83D78: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A83D7C: 02025AFF 83DCD12D
	v_pk_fma_f16 v46, v42, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83D84: CC0E002E 0BFC072A 0000C931
	s_waitcnt lgkmcnt(1)                                       // 000000A83D90: BF89FC17
	v_mov_b32_e32 v42, v40                                     // 000000A83D94: 7E540328
	v_bfe_u32 v40, v37, 6, 16                                  // 000000A83D98: D6100028 02410D25
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A83DA0: BF8701A3
	v_dot2acc_f32_f16 v22, v46, v4                             // 000000A83DA4: 042C092E
	s_waitcnt lgkmcnt(0)                                       // 000000A83DA8: BF89FC07
	.long 0xd73d002a                                           // 000000A83DAC: D73D002A
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 000000A83DB0: 0202551A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A83DB4: BF8701A3
	.long 0xd72c0028                                           // 000000A83DB8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A83DBC: 020250FF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000A83DC4: D6220023 03FD0123 00006400
	v_dual_dot2acc_f32_f16 v23, v38, v4 :: v_dual_and_b32 v46, 0xffff, v42// 000000A83DD0: CB240926 172E54FF 0000FFFF
	v_bfe_u32 v38, v37, 3, 16                                  // 000000A83DDC: D6100026 02410725
	v_and_b32_e32 v37, 0xffff, v37                             // 000000A83DE4: 364A4AFF 0000FFFF
	v_bfe_u32 v43, v42, 9, 16                                  // 000000A83DEC: D610002B 0241132A
	v_and_b32_e32 v35, 0xffff, v35                             // 000000A83DF4: 364646FF 0000FFFF
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A83DFC: D6220028 03FD0128 00006400
	v_bfe_u32 v45, v42, 6, 16                                  // 000000A83E08: D610002D 02410D2A
	.long 0xd72c0025                                           // 000000A83E10: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A83E14: 02024AFF 83DCD12D
	.long 0xd72c002b                                           // 000000A83E1C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A83E20: 020256FF 83DCD12D
	v_bfe_u32 v42, v42, 3, 16                                  // 000000A83E28: D610002A 0241072A
	.long 0xd72c002e                                           // 000000A83E30: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A83E34: 02025CFF 83DCD12D
	v_lshl_or_b32 v40, v40, 16, v35                            // 000000A83E3C: D6560028 048D2128
	.long 0xd72c0026                                           // 000000A83E44: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A83E48: 02024CFF 83DCD12D
	.long 0xd72c002d                                           // 000000A83E50: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A83E54: 02025AFF 83DCD12D
	.long 0xd72c002a                                           // 000000A83E5C: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A83E60: 020254FF 83DCD12D
	v_sad_u8 v35, v37, 0, 0x6400                               // 000000A83E68: D6220023 03FD0125 00006400
	v_sad_u8 v43, v43, 0, 0x6400                               // 000000A83E74: D622002B 03FD012B 00006400
	v_mov_b32_e32 v37, v39                                     // 000000A83E80: 7E4A0327
	v_pk_fma_f16 v40, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83E84: CC0E0028 0BFC0728 0000C931
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83E90: BF870004
	v_lshlrev_b32_e32 v47, 16, v35                             // 000000A83E94: 305E4690
	v_sad_u8 v35, v46, 0, 0x6400                               // 000000A83E98: D6220023 03FD012E 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000A83EA4: D6220026 03FD0126 00006400
	v_and_b32_e32 v39, 0xffff, v43                             // 000000A83EB0: 364E56FF 0000FFFF
	v_sad_u8 v43, v45, 0, 0x6400                               // 000000A83EB8: D622002B 03FD012D 00006400
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A83EC4: D622002A 03FD012A 00006400
	v_lshlrev_b32_e32 v45, 16, v35                             // 000000A83ED0: 305A4690
	.long 0xd73d0023                                           // 000000A83ED4: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 000000A83ED8: 02024919
	v_and_or_b32 v36, 0xffff, v38, v47                         // 000000A83EDC: D6570024 04BE4CFF 0000FFFF
	v_lshl_or_b32 v37, v43, 16, v39                            // 000000A83EE8: D6560025 049D212B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A83EF0: BF870004
	v_and_or_b32 v38, 0xffff, v42, v45                         // 000000A83EF4: D6570026 04B654FF 0000FFFF
	v_mov_b32_e32 v42, v44                                     // 000000A83F00: 7E54032C
	v_bfe_u32 v39, v35, 9, 16                                  // 000000A83F04: D6100027 02411323
	v_pk_fma_f16 v45, v36, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83F0C: CC0E002D 0BFC0724 0000C931
	v_pk_fma_f16 v46, v37, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83F18: CC0E002E 0BFC0725 0000C931
	v_pk_fma_f16 v47, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A83F24: CC0E002F 0BFC0726 0000C931
	.long 0xd73d0024                                           // 000000A83F30: D73D0024
	v_cndmask_b32_e32 v1, v26, v41, vcc_lo                     // 000000A83F34: 0202531A
	.long 0xd72c0025                                           // 000000A83F38: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A83F3C: 02024EFF 83DCD12D
	v_and_b32_e32 v38, 0xffff, v35                             // 000000A83F44: 364C46FF 0000FFFF
	v_bfe_u32 v39, v35, 6, 16                                  // 000000A83F4C: D6100027 02410D23
	v_bfe_u32 v35, v35, 3, 16                                  // 000000A83F54: D6100023 02410723
	v_and_b32_e32 v43, 0xffff, v36                             // 000000A83F5C: 365648FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A83F64: BF870214
	.long 0xd72c0026                                           // 000000A83F68: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 000000A83F6C: 02024CFF 83DCD12D
	.long 0xd72c0027                                           // 000000A83F74: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A83F78: 02024EFF 83DCD12D
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A83F80: D6220025 03FD0125 00006400
	.long 0xd72c0029                                           // 000000A83F8C: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A83F90: 020246FF 83DCD12D
	.long 0xd72c0035                                           // 000000A83F98: D72C0035
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 000000A83F9C: 020256FF 83DCD12D
	v_bfe_u32 v42, v36, 6, 16                                  // 000000A83FA4: D610002A 02410D24
	v_bfe_u32 v48, v36, 3, 16                                  // 000000A83FAC: D6100030 02410724
	v_and_b32_e32 v49, 0xffff, v37                             // 000000A83FB4: 36624AFF 0000FFFF
	v_sad_u8 v37, v38, 0, 0x6400                               // 000000A83FBC: D6220025 03FD0126 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A83FC8: D6220027 03FD0127 00006400
	.long 0xd72c002a                                           // 000000A83FD4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A83FD8: 020254FF 83DCD12D
	v_sad_u8 v50, v41, 0, 0x6400                               // 000000A83FE0: D6220032 03FD0129 00006400
	.long 0xd72c0030                                           // 000000A83FEC: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A83FF0: 020260FF 83DCD12D
	v_lshlrev_b32_e32 v51, 16, v37                             // 000000A83FF8: 30664A90
	v_lshl_or_b32 v39, v39, 16, v49                            // 000000A83FFC: D6560027 04C52127
	s_delay_alu instid0(VALU_DEP_2)                            // 000000A84004: BF870002
	v_and_or_b32 v49, 0xffff, v50, v51                         // 000000A84008: D6570031 04CE64FF 0000FFFF
	v_sad_u8 v51, v53, 0, 0x6400                               // 000000A84014: D6220033 03FD0135 00006400
	v_dot2acc_f32_f16 v21, v40, v1                             // 000000A84020: 042A0328
	v_bfe_u32 v40, v36, 9, 16                                  // 000000A84024: D6100028 02411324
	ds_load_2addr_b32 v[35:36], v32 offset0:208 offset1:232    // 000000A8402C: D8DCE8D0 23000020
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A84034: D622002A 03FD012A 00006400
	v_pk_fma_f16 v49, v49, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A84040: CC0E0031 0BFC0731 0000C931
	v_dot2acc_f32_f16 v21, v45, v2                             // 000000A8404C: 042A052D
	.long 0xd72c002c                                           // 000000A84050: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A84054: 020250FF 83DCD12D
	ds_load_2addr_b32 v[37:38], v34 offset0:208 offset1:232    // 000000A8405C: D8DCE8D0 25000022
	ds_load_2addr_b32 v[40:41], v31 offset0:208 offset1:232    // 000000A84064: D8DCE8D0 2800001F
	v_pk_fma_f16 v45, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8406C: CC0E002D 0BFC0727 0000C931
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000A84078: BF8700D1
	v_dot2acc_f32_f16 v20, v45, v1                             // 000000A8407C: 0428032D
	v_sad_u8 v52, v44, 0, 0x6400                               // 000000A84080: D6220034 03FD012C 00006400
	ds_load_2addr_b32 v[43:44], v33 offset0:208 offset1:232    // 000000A8408C: D8DCE8D0 2B000021
	v_dot2acc_f32_f16 v20, v49, v2                             // 000000A84094: 04280531
	v_and_b32_e32 v50, 0xffff, v52                             // 000000A84098: 366468FF 0000FFFF
	v_lshl_or_b32 v50, v42, 16, v50                            // 000000A840A0: D6560032 04C9212A
	s_waitcnt lgkmcnt(2)                                       // 000000A840A8: BF89FC27
	v_mov_b32_e32 v42, v37                                     // 000000A840AC: 7E540325
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A840B0: BF870092
	v_pk_fma_f16 v37, v50, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A840B4: CC0E0025 0BFC0732 0000C931
	v_dot2acc_f32_f16 v20, v37, v3                             // 000000A840C0: 04280725
	s_waitcnt lgkmcnt(0)                                       // 000000A840C4: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A840C8: BF8701C3
	.long 0xd73d002a                                           // 000000A840CC: D73D002A
	v_cndmask_b32_e32 v1, v26, v42, vcc_lo                     // 000000A840D0: 0202551A
	v_mov_b32_e32 v39, v35                                     // 000000A840D4: 7E4E0323
	v_sad_u8 v35, v48, 0, 0x6400                               // 000000A840D8: D6220023 03FD0130 00006400
	v_lshlrev_b32_e32 v48, 16, v51                             // 000000A840E4: 30606690
	.long 0xd73d0027                                           // 000000A840E8: D73D0027
	v_cndmask_b32_e32 v1, v25, v39, vcc_lo                     // 000000A840EC: 02024F19
	v_bfe_u32 v37, v42, 9, 16                                  // 000000A840F0: D6100025 0241132A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A840F8: BF870223
	v_and_or_b32 v35, 0xffff, v35, v48                         // 000000A840FC: D6570023 04C246FF 0000FFFF
	v_bfe_u32 v48, v42, 3, 16                                  // 000000A84108: D6100030 0241072A
	v_bfe_u32 v40, v39, 9, 16                                  // 000000A84110: D6100028 02411327
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A84118: BF870003
	v_pk_fma_f16 v43, v35, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A8411C: CC0E002B 0BFC0723 0000C931
	v_and_b32_e32 v35, 0xffff, v39                             // 000000A84128: 36464EFF 0000FFFF
	v_bfe_u32 v45, v39, 6, 16                                  // 000000A84130: D610002D 02410D27
	v_bfe_u32 v39, v39, 3, 16                                  // 000000A84138: D6100027 02410727
	.long 0xd72c0028                                           // 000000A84140: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 000000A84144: 020250FF 83DCD12D
	.long 0xd72c0025                                           // 000000A8414C: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 000000A84150: 02024AFF 83DCD12D
	.long 0xd72c0023                                           // 000000A84158: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A8415C: 020246FF 83DCD12D
	.long 0xd72c002d                                           // 000000A84164: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 000000A84168: 02025AFF 83DCD12D
	.long 0xd72c0027                                           // 000000A84170: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A84174: 02024EFF 83DCD12D
	v_dot2acc_f32_f16 v20, v43, v4                             // 000000A8417C: 0428092B
	v_sad_u8 v40, v40, 0, 0x6400                               // 000000A84180: D6220028 03FD0128 00006400
	v_sad_u8 v37, v37, 0, 0x6400                               // 000000A8418C: D6220025 03FD0125 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000A84198: D6220023 03FD0123 00006400
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A841A4: D622002D 03FD012D 00006400
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A841B0: D6220027 03FD0127 00006400
	v_dual_dot2acc_f32_f16 v21, v46, v3 :: v_dual_and_b32 v40, 0xffff, v40// 000000A841BC: CB24072E 152850FF 0000FFFF
	v_bfe_u32 v46, v42, 6, 16                                  // 000000A841C8: D610002E 02410D2A
	v_lshlrev_b32_e32 v35, 16, v35                             // 000000A841D0: 30464690
	v_and_b32_e32 v49, 0xffff, v37                             // 000000A841D4: 36624AFF 0000FFFF
	v_dual_mov_b32 v37, v41 :: v_dual_and_b32 v42, 0xffff, v42 // 000000A841DC: CA240129 252A54FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A841E8: BF870214
	.long 0xd72c002e                                           // 000000A841EC: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 000000A841F0: 02025CFF 83DCD12D
	v_and_or_b32 v39, 0xffff, v39, v35                         // 000000A841F8: D6570027 048E4EFF 0000FFFF
	v_lshl_or_b32 v40, v45, 16, v40                            // 000000A84204: D6560028 04A1212D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A8420C: BF870234
	.long 0xd73d0023                                           // 000000A84210: D73D0023
	v_cndmask_b32_e32 v1, v25, v36, vcc_lo                     // 000000A84214: 02024919
	.long 0xd72c002a                                           // 000000A84218: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 000000A8421C: 020254FF 83DCD12D
	.long 0xd72c002d                                           // 000000A84224: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A84228: 020260FF 83DCD12D
	v_pk_fma_f16 v40, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A84230: CC0E0028 0BFC0728 0000C931
	v_sad_u8 v46, v46, 0, 0x6400                               // 000000A8423C: D622002E 03FD012E 00006400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A84248: BF870112
	v_dual_dot2acc_f32_f16 v19, v40, v1 :: v_dual_and_b32 v48, 0xffff, v35// 000000A8424C: CB240328 133046FF 0000FFFF
	v_lshl_or_b32 v41, v46, 16, v49                            // 000000A84258: D6560029 04C5212E
	v_pk_fma_f16 v46, v39, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A84260: CC0E002E 0BFC0727 0000C931
	v_mov_b32_e32 v39, v44                                     // 000000A8426C: 7E4E032C
	v_bfe_u32 v44, v35, 9, 16                                  // 000000A84270: D610002C 02411323
	v_sad_u8 v45, v45, 0, 0x6400                               // 000000A84278: D622002D 03FD012D 00006400
	v_pk_fma_f16 v41, v41, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A84284: CC0E0029 0BFC0729 0000C931
	v_dot2acc_f32_f16 v19, v46, v2                             // 000000A84290: 0426052E
	.long 0xd73d0024                                           // 000000A84294: D73D0024
	v_cndmask_b32_e32 v1, v26, v38, vcc_lo                     // 000000A84298: 02024D1A
	.long 0xd72c0026                                           // 000000A8429C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A842A0: 020258FF 83DCD12D
	v_bfe_u32 v39, v35, 6, 16                                  // 000000A842A8: D6100027 02410D23
	v_sad_u8 v37, v42, 0, 0x6400                               // 000000A842B0: D6220025 03FD012A 00006400
	v_bfe_u32 v35, v35, 3, 16                                  // 000000A842BC: D6100023 02410723
	.long 0xd72c002a                                           // 000000A842C4: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A842C8: 020260FF 83DCD12D
	v_bfe_u32 v44, v36, 9, 16                                  // 000000A842D0: D610002C 02411324
	.long 0xd72c0027                                           // 000000A842D8: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 000000A842DC: 02024EFF 83DCD12D
	v_bfe_u32 v48, v36, 6, 16                                  // 000000A842E4: D6100030 02410D24
	v_sad_u8 v38, v38, 0, 0x6400                               // 000000A842EC: D6220026 03FD0126 00006400
	.long 0xd72c0023                                           // 000000A842F8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 000000A842FC: 020246FF 83DCD12D
	.long 0xd72c002c                                           // 000000A84304: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 000000A84308: 020258FF 83DCD12D
	v_bfe_u32 v49, v36, 3, 16                                  // 000000A84310: D6100031 02410724
	v_and_b32_e32 v36, 0xffff, v36                             // 000000A84318: 364848FF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 000000A84320: D622002A 03FD012A 00006400
	v_and_b32_e32 v38, 0xffff, v38                             // 000000A8432C: 364C4CFF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A84334: D6220027 03FD0127 00006400
	.long 0xd72c0030                                           // 000000A84340: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 000000A84344: 020260FF 83DCD12D
	.long 0xd72c0024                                           // 000000A8434C: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 000000A84350: 020248FF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 000000A84358: D6220023 03FD0123 00006400
	v_lshlrev_b32_e32 v42, 16, v42                             // 000000A84364: 30545490
	v_sad_u8 v44, v44, 0, 0x6400                               // 000000A84368: D622002C 03FD012C 00006400
	v_lshl_or_b32 v38, v39, 16, v38                            // 000000A84374: D6560026 04992127
	.long 0xd72c0027                                           // 000000A8437C: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 000000A84380: 020262FF 83DCD12D
	v_lshlrev_b32_e32 v37, 16, v37                             // 000000A84388: 304A4A90
	v_and_or_b32 v35, 0xffff, v35, v42                         // 000000A8438C: D6570023 04AA46FF 0000FFFF
	v_and_b32_e32 v42, 0xffff, v44                             // 000000A84398: 365458FF 0000FFFF
	v_sad_u8 v44, v48, 0, 0x6400                               // 000000A843A0: D622002C 03FD0130 00006400
	v_pk_fma_f16 v38, v38, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A843AC: CC0E0026 0BFC0726 0000C931
	v_sad_u8 v36, v36, 0, 0x6400                               // 000000A843B8: D6220024 03FD0124 00006400
	v_pk_fma_f16 v35, v35, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A843C4: CC0E0023 0BFC0723 0000C931
	v_sad_u8 v39, v39, 0, 0x6400                               // 000000A843D0: D6220027 03FD0127 00006400
	v_lshl_or_b32 v40, v44, 16, v42                            // 000000A843DC: D6560028 04A9212C
	v_dot2acc_f32_f16 v18, v38, v1                             // 000000A843E4: 04240326
	v_dual_dot2acc_f32_f16 v19, v41, v3 :: v_dual_lshlrev_b32 v36, 16, v36// 000000A843E8: CB220729 13244890
	v_and_or_b32 v1, 0xffff, v45, v37                          // 000000A843F0: D6570001 04965AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A843FC: BF870214
	v_pk_fma_f16 v37, v40, s3, 0xc931 op_sel_hi:[1,0,0]        // 000000A84400: CC0E0025 0BFC0728 0000C931
	v_dot2acc_f32_f16 v18, v35, v2                             // 000000A8440C: 04240523
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000A84410: BF870234
	v_and_or_b32 v36, 0xffff, v39, v36                         // 000000A84414: D6570024 04924EFF 0000FFFF
	v_dot2acc_f32_f16 v21, v47, v4                             // 000000A84420: 042A092F
	v_pk_fma_f16 v1, v1, s3, 0xc931 op_sel_hi:[1,0,0]          // 000000A84424: CC0E0001 0BFC0701 0000C931
	v_dual_dot2acc_f32_f16 v18, v37, v3 :: v_dual_add_nc_u32 v3, v28, v29// 000000A84430: CB200725 12023B1C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A84438: BF870194
	v_pk_fma_f16 v2, v36, s3, 0xc931 op_sel_hi:[1,0,0]         // 000000A8443C: CC0E0002 0BFC0724 0000C931
	v_dot2acc_f32_f16 v19, v1, v4                              // 000000A84448: 04260901
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A8444C: BF870193
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 000000A84450: 7C940686
	v_dot2acc_f32_f16 v18, v2, v4                              // 000000A84454: 04240902
	s_or_b32 s2, vcc_lo, s2                                    // 000000A84458: 8C02026A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A8445C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s2                        // 000000A84460: 917E027E
	s_cbranch_execz 27                                         // 000000A84464: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x11d4>
	s_mov_b32 s0, exec_lo                                      // 000000A84468: BE80007E
	s_waitcnt vmcnt(4)                                         // 000000A8446C: BF8913F7
	ds_store_2addr_b32 v30, v11, v12 offset0:64 offset1:96     // 000000A84470: D8386040 000C0B1E
	s_waitcnt vmcnt(2)                                         // 000000A84478: BF890BF7
	ds_store_2addr_b32 v30, v13, v14 offset0:128 offset1:160   // 000000A8447C: D838A080 000E0D1E
	s_waitcnt vmcnt(0)                                         // 000000A84484: BF8903F7
	ds_store_2addr_b32 v30, v16, v17 offset0:192 offset1:224   // 000000A84488: D838E0C0 0011101E
	.long 0xd4c9007e                                           // 000000A84490: D4C9007E
	v_cndmask_b32_e32 v1, v29, v10, vcc_lo                     // 000000A84494: 0202151D
	s_cbranch_execz 64609                                      // 000000A84498: BFA5FC61 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x320>
	s_clause 0x5                                               // 000000A8449C: BF850005
	global_load_b32 v11, v[5:6], off                           // 000000A844A0: DC520000 0B7C0005
	global_load_b32 v12, v[5:6], off offset:128                // 000000A844A8: DC520080 0C7C0005
	global_load_b32 v13, v[5:6], off offset:256                // 000000A844B0: DC520100 0D7C0005
	global_load_b32 v14, v[5:6], off offset:384                // 000000A844B8: DC520180 0E7C0005
	global_load_b32 v16, v[5:6], off offset:512                // 000000A844C0: DC520200 107C0005
	global_load_b32 v17, v[5:6], off offset:640                // 000000A844C8: DC520280 117C0005
	s_branch 64595                                             // 000000A844D0: BFA0FC53 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x320>
	s_or_b32 exec_lo, exec_lo, s2                              // 000000A844D4: 8C7E027E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A844D8: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 000000A844DC: 8C7E017E
	v_dual_mov_b32 v1, v15 :: v_dual_mov_b32 v2, v24           // 000000A844E0: CA10010F 01020118
	v_dual_mov_b32 v3, v23 :: v_dual_mov_b32 v10, v22          // 000000A844E8: CA100117 030A0116
	v_dual_mov_b32 v4, v21 :: v_dual_mov_b32 v5, v20           // 000000A844F0: CA100115 04040114
	s_waitcnt vmcnt(5)                                         // 000000A844F8: BF8917F7
	v_dual_mov_b32 v6, v19 :: v_dual_mov_b32 v11, v18          // 000000A844FC: CA100113 060A0112
	s_mov_b32 s0, 0x76543210                                   // 000000A84504: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v8                            // 000000A8450C: 7C981090
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000A84510: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000A8451C: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000A84528: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000A84534: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 000000A84540: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000A8454C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000A84558: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 000000A84564: D65C000B 03FC010B FEDCBA98
	s_waitcnt vmcnt(0)                                         // 000000A84570: BF8903F7
	s_barrier                                                  // 000000A84574: BFBD0000
	buffer_gl0_inv                                             // 000000A84578: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000A84580: BE80206A
	s_cbranch_execz 18                                         // 000000A84584: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x12d0>
	v_dual_add_f32 v8, v18, v11 :: v_dual_add_f32 v1, v15, v1  // 000000A84588: C9081712 0800030F
	v_dual_add_f32 v2, v24, v2 :: v_dual_add_f32 v3, v23, v3   // 000000A84590: C9080518 02020717
	v_lshl_or_b32 v9, v7, 9, v9                                // 000000A84598: D6560009 04251307
	v_dual_add_f32 v10, v22, v10 :: v_dual_add_f32 v5, v20, v5 // 000000A845A0: C9081516 0A040B14
	v_add_f32_e32 v4, v21, v4                                  // 000000A845A8: 06080915
	v_add_f32_e32 v6, v19, v6                                  // 000000A845AC: 060C0D13
	ds_store_2addr_b32 v9, v1, v2 offset1:16                   // 000000A845B0: D8381000 00020109
	ds_store_2addr_b32 v9, v3, v10 offset0:32 offset1:48       // 000000A845B8: D8383020 000A0309
	ds_store_2addr_b32 v9, v4, v5 offset0:64 offset1:80        // 000000A845C0: D8385040 00050409
	ds_store_2addr_b32 v9, v6, v8 offset0:96 offset1:112       // 000000A845C8: D8387060 00080609
	s_or_b32 exec_lo, exec_lo, s0                              // 000000A845D0: 8C7E007E
	s_sub_i32 s0, s15, s14                                     // 000000A845D4: 81800E0F
	s_waitcnt lgkmcnt(0)                                       // 000000A845D8: BF89FC07
	s_min_i32 s0, s0, 1                                        // 000000A845DC: 89008100
	s_barrier                                                  // 000000A845E0: BFBD0000
	buffer_gl0_inv                                             // 000000A845E4: E0AC0000 00000000
	s_mov_b32 s1, exec_lo                                      // 000000A845EC: BE81007E
	.long 0xd4c4007e                                           // 000000A845F0: D4C4007E
	v_cndmask_b32_e32 v1, s0, v7, vcc_lo                       // 000000A845F4: 02020E00
	s_cbranch_execz 510                                        // 000000A845F8: BFA501FE <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1af4>
	v_and_b32_e32 v1, 15, v0                                   // 000000A845FC: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000A84600: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 000000A84604: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 000000A84608: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 000000A84610: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 000000A84618: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 000000A8461C: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 000000A84624: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 000000A8462C: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 000000A84634: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000A8463C: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 000000A84640: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 000000A84644: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 000000A8464C: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 000000A84654: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 000000A8465C: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 000000A84664: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 000000A8466C: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 000000A84674: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 000000A8467C: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 000000A84684: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 000000A8468C: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 000000A84694: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 000000A8469C: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 000000A846A4: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 000000A846AC: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 000000A846B4: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 000000A846BC: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 000000A846C4: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 000000A846CC: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 000000A846D4: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 000000A846DC: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 000000A846E4: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 000000A846EC: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 000000A846F0: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 000000A846F4: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 000000A846F8: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 000000A84700: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 000000A84708: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 000000A84710: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 000000A84718: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 000000A8471C: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 000000A84724: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 000000A84728: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 000000A84730: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 000000A84734: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 000000A8473C: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 000000A84740: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 000000A84744: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 000000A84748: 06102908
	v_add_f32_e32 v12, v11, v13                                // 000000A8474C: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 000000A84750: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 000000A84758: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 000000A8475C: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 000000A84760: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 000000A84768: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 000000A84770: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A84774: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 000000A84778: 06103108
	s_waitcnt lgkmcnt(4)                                       // 000000A8477C: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 000000A84780: 06265909
	s_waitcnt lgkmcnt(2)                                       // 000000A84784: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 000000A84788: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 000000A8478C: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 000000A84794: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 000000A84798: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 000000A8479C: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 000000A847A0: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 000000A847A4: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 000000A847AC: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 000000A847B4: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A847B8: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 000000A847BC: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 000000A847C0: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 000000A847C8: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 000000A847D0: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 000000A847D4: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 000000A847D8: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 000000A847E0: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 000000A847E4: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 000000A847EC: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 000000A847F0: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000A847F8: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 000000A847FC: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 000000A84800: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 000000A84808: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 000000A8480C: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 000000A84814: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 000000A84818: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 000000A84820: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000A84824: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 000000A84828: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 000000A84830: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 000000A84834: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000A8483C: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 000000A84840: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 000000A84848: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 000000A8484C: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 000000A84850: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 000000A84854: 08040702
	v_add_f32_e32 v16, v16, v48                                // 000000A84858: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A8485C: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 000000A84860: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 000000A84864: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000A84868: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 000000A8486C: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 000000A84870: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 000000A84874: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A84878: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 000000A8487C: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 000000A84884: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 000000A84888: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A8488C: BF870213
	.long 0xd44a0000                                           // 000000A84890: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 000000A84894: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 000000A84898: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A8489C: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 000000A848A0: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 000000A848A4: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 000000A848A8: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 000000A848B0: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A848B4: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 000000A848B8: 06105308
	.long 0xd44a0001                                           // 000000A848BC: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000A848C0: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000A848C4: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 000000A848C8: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 000000A848CC: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 000000A848D0: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 000000A848D4: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A848D8: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 000000A848DC: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 000000A848E4: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 000000A848E8: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 000000A848EC: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 000000A848F0: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A848F4: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A848FC: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000A84904: BF870113
	.long 0xd44a0002                                           // 000000A84908: D44A0002
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 000000A8490C: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 000000A84910: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 000000A84918: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A84920: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84924: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000A8492C: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 000000A84934: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A84938: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A8493C: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 000000A84944: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 000000A8494C: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000A84954: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A84958: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 000000A84960: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000A84964: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84968: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s2                          // 000000A84970: D5010004 200A0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84978: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A84980: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000A84988: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 000000A8498C: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 000000A84990: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A84998: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000A849A0: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 000000A849A8: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A849AC: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000A849B4: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 000000A849B8: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A849BC: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A849C4: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000A849CC: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000A849D4: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A849D8: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 000000A849E0: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 000000A849E8: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 000000A849EC: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 000000A849F0: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 000000A849F4: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A849F8: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 000000A84A00: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A84A08: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84A0C: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s2                          // 000000A84A14: D5010008 200A1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84A1C: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s2                       // 000000A84A24: D501000B 200A170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84A2C: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84A34: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 000000A84A3C: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A84A40: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 000000A84A48: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 000000A84A50: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A84A54: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 000000A84A5C: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000A84A64: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 000000A84A6C: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 000000A84A74: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84A78: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000A84A80: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A84A88: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 000000A84A8C: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84A94: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 000000A84A9C: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A84AA4: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 000000A84AA8: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84AAC: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000A84AB4: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000A84ABC: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 000000A84AC4: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 000000A84ACC: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84AD4: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000A84ADC: BF870214
	v_add_f32_e32 v10, v10, v12                                // 000000A84AE0: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 000000A84AE4: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A84AE8: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84AEC: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s2                         // 000000A84AF4: D501000F 200A1108
	v_cndmask_b32_e64 v9, -v9, v9, s2                          // 000000A84AFC: D5010009 200A1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84B04: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000A84B0C: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s2                       // 000000A84B14: D501000A 200A150A
	v_cndmask_b32_e64 v12, -v12, v12, s2                       // 000000A84B1C: D501000C 200A190C
	v_add_f32_e32 v14, v9, v11                                 // 000000A84B24: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 000000A84B28: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B2C: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 000000A84B34: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 000000A84B38: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B3C: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B44: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B4C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B54: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000A84B5C: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000A84B64: 8B7E6A7E
	s_cbranch_execz 162                                        // 000000A84B68: BFA500A2 <_ZN7halogen12_GLOBAL__N_112k_ht_gemv_dnILi3ELi8ELi1EEEvPKjPKDF16_PKNS0_6HtItemES5_Pt+0x1af4>
	v_and_b32_e32 v0, 8, v0                                    // 000000A84B6C: 36000088
	s_mul_i32 s0, s12, 0x1400                                  // 000000A84B70: 9600FF0C 00001400
	s_mul_hi_i32 s1, s12, 0x1400                               // 000000A84B78: 9701FF0C 00001400
	s_add_u32 s2, s10, s0                                      // 000000A84B80: 8002000A
	s_addc_u32 s3, s11, s1                                     // 000000A84B84: 8203010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 000000A84B88: 7C940080
	s_lshl_b32 s0, s13, 7                                      // 000000A84B8C: 8400870D
	.long 0x7f243880                                           // 000000A84B90: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 000000A84B94: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000A84B98: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000A84B9C: 84808100
	v_cndmask_b32_e64 v0, -v6, v6, vcc_lo                      // 000000A84BA0: D5010000 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000A84BA8: 30020281
	s_add_u32 s2, s2, s0                                       // 000000A84BAC: 80020002
	s_addc_u32 s3, s3, s1                                      // 000000A84BB0: 82030103
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000A84BB4: D5010003 21AA0703
	v_add_f32_e32 v0, v0, v4                                   // 000000A84BBC: 06000900
	s_clause 0x7                                               // 000000A84BC0: BF850007
	global_load_d16_b16 v18, v1, s[2:3] offset:32              // 000000A84BC4: DC820020 12020001
	global_load_d16_b16 v19, v1, s[2:3]                        // 000000A84BCC: DC820000 13020001
	global_load_d16_b16 v20, v1, s[2:3] offset:64              // 000000A84BD4: DC820040 14020001
	global_load_d16_b16 v21, v1, s[2:3] offset:96              // 000000A84BDC: DC820060 15020001
	global_load_d16_b16 v22, v1, s[2:3] offset:128             // 000000A84BE4: DC820080 16020001
	global_load_d16_b16 v23, v1, s[2:3] offset:160             // 000000A84BEC: DC8200A0 17020001
	global_load_d16_b16 v24, v1, s[2:3] offset:192             // 000000A84BF4: DC8200C0 18020001
	global_load_d16_b16 v25, v1, s[2:3] offset:224             // 000000A84BFC: DC8200E0 19020001
	v_cndmask_b32_e64 v4, -v5, v5, vcc_lo                      // 000000A84C04: D5010004 21AA0B05
	v_cndmask_b32_e64 v5, -v7, v7, vcc_lo                      // 000000A84C0C: D5010005 21AA0F07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000A84C14: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000A84C1C: D501000E 21AA1D0E
	v_add_f32_e32 v2, v3, v2                                   // 000000A84C24: 06040503
	v_mul_f32_e32 v0, 0x3db504f3, v0                           // 000000A84C28: 100000FF 3DB504F3
	v_dual_add_f32 v3, v5, v8 :: v_dual_add_f32 v4, v4, v9     // 000000A84C30: C9081105 03041304
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000A84C38: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000A84C40: D501000F 21AA1F0F
	v_add_f32_e32 v5, v14, v10                                 // 000000A84C48: 060A150E
	v_add_f32_e32 v7, v7, v11                                  // 000000A84C4C: 060E1707
	v_dual_mul_f32 v3, 0x3db504f3, v3 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 000000A84C50: C8C606FF 030408FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 000000A84C5C: BF8913F7
	.long 0x7f2a3992                                           // 000000A84C60: 7F2A3992
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000A84C64: C908190F 08081B10
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 000000A84C6C: C8C604FF 02060EFF 3DB504F3
	v_mul_f32_e32 v5, 0x3db504f3, v5                           // 000000A84C78: 100A0AFF 3DB504F3
	.long 0x7f263992                                           // 000000A84C80: 7F263992
	s_delay_alu instid0(VALU_DEP_4)                            // 000000A84C84: BF870004
	v_dual_mul_f32 v9, 0x3db504f3, v9 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000A84C88: C8C612FF 090810FF 3DB504F3
	.long 0x7f283992                                           // 000000A84C94: 7F283992
	.long 0x7f0c3992                                           // 000000A84C98: 7F0C3992
	s_mul_i32 s3, s14, 0x1400                                  // 000000A84C9C: 9603FF0E 00001400
	s_mul_hi_i32 s2, s14, 0x1400                               // 000000A84CA4: 9702FF0E 00001400
	s_add_u32 s3, s8, s3                                       // 000000A84CAC: 80030308
	s_addc_u32 s2, s9, s2                                      // 000000A84CB0: 82020209
	s_add_u32 s0, s3, s0                                       // 000000A84CB4: 80000003
	s_addc_u32 s1, s2, s1                                      // 000000A84CB8: 82010102
	v_fma_mix_f32 v0, v18, v0, neg(0) op_sel_hi:[1,0,0]        // 000000A84CBC: CC200000 8A020112
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 000000A84CC4: CC200002 8A020513
	v_fma_mix_f32 v3, v20, v3, neg(0) op_sel_hi:[1,0,0]        // 000000A84CCC: CC200003 8A020714
	v_fma_mix_f32 v4, v21, v4, neg(0) op_sel_hi:[1,0,0]        // 000000A84CD4: CC200004 8A020915
	s_waitcnt vmcnt(3)                                         // 000000A84CDC: BF890FF7
	v_fma_mix_f32 v5, v22, v5, neg(0) op_sel_hi:[1,0,0]        // 000000A84CE0: CC200005 8A020B16
	.long 0x7e243980                                           // 000000A84CE8: 7E243980
	s_waitcnt vmcnt(2)                                         // 000000A84CEC: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 000000A84CF0: CC200007 8A020F17
	s_waitcnt vmcnt(1)                                         // 000000A84CF8: BF8907F7
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 000000A84CFC: CC200008 8A021118
	s_waitcnt vmcnt(0)                                         // 000000A84D04: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 000000A84D08: CC200009 8A021319
	.long 0x7e0c3982                                           // 000000A84D10: 7E0C3982
	v_and_b32_e32 v10, 1, v18                                  // 000000A84D14: 36142481
	.long 0x7e243984                                           // 000000A84D18: 7E243984
	.long 0x7e263983                                           // 000000A84D1C: 7E263983
	.long 0x7e283985                                           // 000000A84D20: 7E283985
	.long 0x7e2a3988                                           // 000000A84D24: 7E2A3988
	v_and_b32_e32 v6, 1, v6                                    // 000000A84D28: 360C0C81
	v_and_b32_e32 v11, 1, v18                                  // 000000A84D2C: 36162481
	.long 0x7e243987                                           // 000000A84D30: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000A84D34: 36182681
	v_and_b32_e32 v13, 1, v20                                  // 000000A84D38: 361A2881
	v_and_b32_e32 v15, 1, v21                                  // 000000A84D3C: 361E2A81
	v_add3_u32 v2, v2, v6, 0x7fff                              // 000000A84D40: D6550002 03FE0D02 00007FFF
	v_and_b32_e32 v14, 1, v18                                  // 000000A84D4C: 361C2481
	.long 0x7e243989                                           // 000000A84D50: 7E243989
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000A84D54: D6550000 03FE1500 00007FFF
	v_add3_u32 v3, v3, v12, 0x7fff                             // 000000A84D60: D6550003 03FE1903 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 000000A84D6C: D6550004 03FE1704 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000A84D78: D6550005 03FE1B05 00007FFF
	v_and_b32_e32 v6, 1, v18                                   // 000000A84D84: 360C2481
	v_add3_u32 v8, v8, v15, 0x7fff                             // 000000A84D88: D6550008 03FE1F08 00007FFF
	v_add3_u32 v7, v7, v14, 0x7fff                             // 000000A84D94: D6550007 03FE1D07 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 000000A84DA0: BF870003
	v_add3_u32 v6, v9, v6, 0x7fff                              // 000000A84DA4: D6550006 03FE0D09 00007FFF
	s_clause 0x7                                               // 000000A84DB0: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 000000A84DB4: DC960000 00000201
	global_store_d16_hi_b16 v1, v0, s[0:1] offset:32           // 000000A84DBC: DC960020 00000001
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:64           // 000000A84DC4: DC960040 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:96           // 000000A84DCC: DC960060 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:128          // 000000A84DD4: DC960080 00000501
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 000000A84DDC: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 000000A84DE4: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:224          // 000000A84DEC: DC9600E0 00000601
	s_endpgm                                                   // 000000A84DF4: BFB00000
		...

