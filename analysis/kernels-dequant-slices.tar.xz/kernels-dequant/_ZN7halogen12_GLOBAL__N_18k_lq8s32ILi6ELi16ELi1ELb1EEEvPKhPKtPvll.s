0000000000730100 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000730100: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000730104: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000073010C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000730114: 32020084
	s_mov_b32 s3, 0                                            // 000000730118: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 15, v0        // 00000073011C: CA240080 100E008F
	s_lshl_b64 s[0:1], s[2:3], 4                               // 000000730124: 84808402
	.long 0x7e343880                                           // 000000730128: 7E343880
	v_or_b32_e32 v9, s0, v1                                    // 00000073012C: 38120200
	v_mov_b32_e32 v10, s1                                      // 000000730130: 7E140201
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000730134: CA100080 04040080
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v11, 4, v15     // 00000073013C: CA220080 060A1E84
	s_waitcnt lgkmcnt(0)                                       // 000000730144: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000730148: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 00000073014C: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 000000730150: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000730154: BF8704A9
	s_add_u32 s2, s10, s0                                      // 000000730158: 8002000A
	s_addc_u32 s3, s11, 0                                      // 00000073015C: 8203800B
	s_ashr_i64 s[2:3], s[2:3], 4                               // 000000730160: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000730164: 02021280
	s_add_u32 s0, s10, s2                                      // 000000730168: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 00000073016C: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000730174: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000730178: 80008F00
	s_addc_u32 s1, s1, 0                                       // 00000073017C: 82018001
	s_and_b32 s0, s0, -16                                      // 000000730180: 8B00D000
	.long 0xd72c0003                                           // 000000730184: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000730188: 02000301
	.long 0xd72c0007                                           // 00000073018C: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000730190: 02000102
	v_mad_u64_u32 v[1:2], null, v1, s0, 0                      // 000000730194: D6FE7C01 02000101
	.long 0xd4440000                                           // 00000073019C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000007301A0: 02021E02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007301A4: BF870192
	v_add3_u32 v2, v2, v3, v7                                  // 0000007301A8: D6550002 041E0702
	.long 0xd7000111                                           // 0000007301B0: D7000111
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000007301B4: 02020204
	v_mov_b32_e32 v7, 0                                        // 0000007301B8: 7E0E0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007301BC: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v2, s1                  // 0000007301C0: D5207C12 00060405
	s_and_saveexec_b32 s3, s0                                  // 0000007301C8: BE832000
	s_cbranch_execz 21                                         // 0000007301CC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x124>
	v_lshlrev_b32_e32 v3, 4, v15                               // 0000007301D0: 30061E84
	.long 0xd7000105                                           // 0000007301D4: D7000105
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000007301D8: 02001511
	v_and_b32_e32 v7, 14, v0                                   // 0000007301DC: 360E008E
	v_add_co_ci_u32_e64 v6, null, s11, v18, s1                 // 0000007301E0: D5207C06 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007301E8: BF870094
	.long 0xd7000103                                           // 0000007301EC: D7000103
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007301F0: 02020711
	v_add_co_ci_u32_e64 v4, null, 0, v18, s1                   // 0000007301F4: D5207C04 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007301FC: BF870094
	.long 0xd700010c                                           // 000000730200: D700010C
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000730204: 02020F05
	v_add_co_ci_u32_e64 v13, null, 0, v6, s1                   // 000000730208: D5207C0D 00060C80
	s_clause 0x1                                               // 000000730210: BF850001
	global_load_b128 v[4:7], v[3:4], off                       // 000000730214: DC5E0000 047C0003
	global_load_d16_b16 v26, v[12:13], off                     // 00000073021C: DC820000 1A7C000C
	s_or_b32 exec_lo, exec_lo, s3                              // 000000730224: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 000000730228: CA100080 13140080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000730230: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000730238: 7E2E0280
	s_and_saveexec_b32 s3, s0                                  // 00000073023C: BE832000
	s_cbranch_execz 505                                        // 000000730240: BFA501F9 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x928>
	v_and_or_b32 v0, v0, 14, 16                                // 000000730244: D6570000 02411D00
	.long 0xd7000001                                           // 00000073024C: D7000001
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 000000730250: 0202020A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000730254: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s11, v2, s0                  // 000000730258: D5207C02 0002040B
	v_mov_b32_e32 v12, 0                                       // 000000730260: 7E180280
	.long 0xd7000000                                           // 000000730264: D7000000
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 000000730268: 02020101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073026C: BF870191
	v_add_co_ci_u32_e64 v1, null, 0, v2, s0                    // 000000730270: D5207C01 00020480
	v_dual_mov_b32 v24, v15 :: v_dual_mov_b32 v23, v12         // 000000730278: CA10010F 1816010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730280: BF870093
	.long 0xd700000d                                           // 000000730284: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000730288: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v1, s0                  // 00000073028C: D5207C0E 00020205
	v_mov_b32_e32 v22, v12                                     // 000000730294: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000730298: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 00000073029C: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 0000007302A0: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 0000007302A4: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 0000007302A8: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000007302AC: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000007302B0: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000007302B4: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000007302B8: 9612860A
	s_mov_b32 s17, 0                                           // 0000007302BC: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007302C0: 8484810A
	s_branch 442                                               // 0000007302C4: BFA001BA <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x8b0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007302C8: 8C7E0A7E
	v_bfe_i32 v27, v4, 0, 8                                    // 0000007302CC: D611001B 02210104
	s_and_b32 s0, exec_lo, s0                                  // 0000007302D4: 8B00007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007302D8: BF870099
	s_or_b32 s17, s0, s17                                      // 0000007302DC: 8C111100
	v_cvt_f32_i32_e32 v27, v27                                 // 0000007302E0: 7E360B1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007302E4: BF870091
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 0000007302E8: CC20001B 8A02371A
	v_bfe_u32 v28, v27, 16, 1                                  // 0000007302F0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007302F8: BF870121
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000007302FC: D655001B 03FE391B 00007FFF
	.long 0x7f383880                                           // 000000730308: 7F383880
	.long 0x7e38399b                                           // 00000073030C: 7E38399B
	v_bfe_i32 v27, v4, 8, 8                                    // 000000730310: D611001B 02211104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730318: BF870091
	v_cvt_f32_i32_e32 v27, v27                                 // 00000073031C: 7E360B1B
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 000000730320: CC20001B 8A02371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730328: BF870091
	v_bfe_u32 v29, v27, 16, 1                                  // 00000073032C: D610001D 0205211B
	v_add3_u32 v27, v27, v29, 0x7fff                           // 000000730334: D655001B 03FE3B1B 00007FFF
	v_bfe_i32 v29, v4, 16, 8                                   // 000000730340: D611001D 02212104
	v_ashrrev_i32_e32 v4, 24, v4                               // 000000730348: 34080898
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000073034C: BF870193
	v_and_or_b32 v34, 0xffff0000, v27, v28                     // 000000730350: D6570022 047236FF FFFF0000
	v_cvt_f32_i32_e32 v29, v29                                 // 00000073035C: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730360: BF870113
	v_cvt_f32_i32_e32 v4, v4                                   // 000000730364: 7E080B04
	v_fma_mix_f32 v29, v26, v29, neg(0) op_sel_hi:[1,0,0]      // 000000730368: CC20001D 8A023B1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730370: BF870112
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000730374: CC200004 8A02091A
	v_bfe_u32 v30, v29, 16, 1                                  // 00000073037C: D610001E 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730384: BF870191
	v_add3_u32 v29, v29, v30, 0x7fff                           // 000000730388: D655001D 03FE3D1D 00007FFF
	v_bfe_u32 v30, v4, 16, 1                                   // 000000730394: D610001E 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073039C: BF8701A2
	.long 0x7e3a399d                                           // 0000007303A0: 7E3A399D
	.long 0x7f3a399c                                           // 0000007303A4: 7F3A399C
	v_add3_u32 v4, v4, v30, 0x7fff                             // 0000007303A8: D6550004 03FE3D04 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007303B4: BF8700A1
	v_and_or_b32 v35, 0xffff0000, v4, v29                      // 0000007303B8: D6570023 047608FF FFFF0000
	v_bfe_i32 v4, v5, 0, 8                                     // 0000007303C4: D6110004 02210105
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007303CC: 7E080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007303D0: BF870091
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007303D4: CC200004 8A02091A
	v_bfe_u32 v27, v4, 16, 1                                   // 0000007303DC: D610001B 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007303E4: BF870091
	v_add3_u32 v4, v4, v27, 0x7fff                             // 0000007303E8: D6550004 03FE3704 00007FFF
	.long 0x7e383984                                           // 0000007303F4: 7E383984
	v_bfe_i32 v4, v5, 8, 8                                     // 0000007303F8: D6110004 02211105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730400: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 000000730404: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000730408: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730410: BF870091
	v_bfe_u32 v27, v4, 16, 1                                   // 000000730414: D610001B 02052104
	v_add3_u32 v4, v4, v27, 0x7fff                             // 00000073041C: D6550004 03FE3704 00007FFF
	v_bfe_i32 v27, v5, 16, 8                                   // 000000730428: D611001B 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 000000730430: 340A0A98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730434: BF870193
	v_and_or_b32 v36, 0xffff0000, v4, v28                      // 000000730438: D6570024 047208FF FFFF0000
	v_cvt_f32_i32_e32 v27, v27                                 // 000000730444: 7E360B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000730448: BF8701A3
	v_cvt_f32_i32_e32 v5, v5                                   // 00000073044C: 7E0A0B05
	v_bfe_i32 v4, v6, 0, 8                                     // 000000730450: D6110004 02210106
	v_fma_mix_f32 v27, v26, v27, neg(0) op_sel_hi:[1,0,0]      // 000000730458: CC20001B 8A02371A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730460: BF870193
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000730464: CC200005 8A020B1A
	v_cvt_f32_i32_e32 v4, v4                                   // 00000073046C: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730470: BF870113
	v_bfe_u32 v29, v27, 16, 1                                  // 000000730474: D610001D 0205211B
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 00000073047C: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730484: BF870122
	v_add3_u32 v27, v27, v29, 0x7fff                           // 000000730488: D655001B 03FE3B1B 00007FFF
	v_bfe_u32 v29, v5, 16, 1                                   // 000000730494: D610001D 02052105
	.long 0x7e36399b                                           // 00000073049C: 7E36399B
	.long 0x7f36399c                                           // 0000007304A0: 7F36399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007304A4: BF870093
	v_add3_u32 v5, v5, v29, 0x7fff                             // 0000007304A8: D6550005 03FE3B05 00007FFF
	v_and_or_b32 v37, 0xffff0000, v5, v27                      // 0000007304B4: D6570025 046E0AFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007304C0: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007304C8: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007304CC: D6550004 03FE0B04 00007FFF
	.long 0x7e383984                                           // 0000007304D8: 7E383984
	v_bfe_i32 v4, v6, 8, 8                                     // 0000007304DC: D6110004 02211106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007304E4: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007304E8: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007304EC: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007304F4: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007304F8: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000730500: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v6, 16, 8                                    // 00000073050C: D6110005 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000730514: 340C0C98
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730518: BF870193
	v_and_or_b32 v38, 0xffff0000, v4, v28                      // 00000073051C: D6570026 047208FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000730528: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000073052C: BF8701A3
	v_cvt_f32_i32_e32 v6, v6                                   // 000000730530: 7E0C0B06
	v_bfe_i32 v4, v7, 0, 8                                     // 000000730534: D6110004 02210107
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 00000073053C: CC200005 8A020B1A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000730544: BF870193
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000730548: CC200006 8A020D1A
	v_cvt_f32_i32_e32 v4, v4                                   // 000000730550: 7E080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730554: BF870113
	v_bfe_u32 v27, v5, 16, 1                                   // 000000730558: D610001B 02052105
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000730560: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730568: BF870122
	v_add3_u32 v5, v5, v27, 0x7fff                             // 00000073056C: D6550005 03FE3705 00007FFF
	v_bfe_u32 v27, v6, 16, 1                                   // 000000730578: D610001B 02052106
	.long 0x7e0a3985                                           // 000000730580: 7E0A3985
	.long 0x7f0a399c                                           // 000000730584: 7F0A399C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730588: BF870093
	v_add3_u32 v6, v6, v27, 0x7fff                             // 00000073058C: D6550006 03FE3706 00007FFF
	v_and_or_b32 v39, 0xffff0000, v6, v5                       // 000000730598: D6570027 04160CFF FFFF0000
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007305A4: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007305AC: BF870091
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007305B0: D6550004 03FE0B04 00007FFF
	.long 0x7e383984                                           // 0000007305BC: 7E383984
	v_bfe_i32 v4, v7, 8, 8                                     // 0000007305C0: D6110004 02211107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007305C8: BF870091
	v_cvt_f32_i32_e32 v4, v4                                   // 0000007305CC: 7E080B04
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000007305D0: CC200004 8A02091A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007305D8: BF870091
	v_bfe_u32 v5, v4, 16, 1                                    // 0000007305DC: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000007305E4: D6550004 03FE0B04 00007FFF
	v_bfe_i32 v5, v7, 16, 8                                    // 0000007305F0: D6110005 02212107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007305F8: BF870112
	v_and_or_b32 v40, 0xffff0000, v4, v28                      // 0000007305FC: D6570028 047208FF FFFF0000
	v_cvt_f32_i32_e32 v5, v5                                   // 000000730608: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073060C: BF870091
	v_fma_mix_f32 v5, v26, v5, neg(0) op_sel_hi:[1,0,0]        // 000000730610: CC200005 8A020B1A
	v_bfe_u32 v6, v5, 16, 1                                    // 000000730618: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730620: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 000000730624: D6550005 03FE0D05 00007FFF
	v_ashrrev_i32_e32 v6, 24, v7                               // 000000730630: 340C0E98
	.long 0x7e0a3985                                           // 000000730634: 7E0A3985
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730638: BF870122
	v_cvt_f32_i32_e32 v6, v6                                   // 00000073063C: 7E0C0B06
	.long 0x7f0a399c                                           // 000000730640: 7F0A399C
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 000000730644: CC200006 8A020D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000073064C: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000730650: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000730658: D6550006 03FE0F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000730664: BF870131
	v_and_or_b32 v41, 0xffff0000, v6, v5                       // 000000730668: D6570029 04160CFF FFFF0000
	.long 0xd73c0004                                           // 000000730674: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000730678: 02021681
	v_mov_b32_e32 v11, v25                                     // 00000073067C: 7E160319
	.long 0xd700001e                                           // 000000730680: D700001E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000730684: 02020806
	s_delay_alu instid0(VALU_DEP_1)                            // 000000730688: BF870001
	v_add_co_ci_u32_e64 v31, null, s7, v5, s0                  // 00000073068C: D5207C1F 00020A07
	s_clause 0x1                                               // 000000730694: BF850001
	global_load_b128 v[4:7], v[30:31], off                     // 000000730698: DC5E0000 047C001E
	global_load_b128 v[26:29], v[30:31], off offset:16         // 0000007306A0: DC5E0010 1A7C001E
	s_waitcnt vmcnt(1)                                         // 0000007306A8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007306AC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007306B4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007306B8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007306C0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007306C8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007306CC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007306D4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007306D8: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 0000007306E0: D700001A
	v_cndmask_b32_e32 v0, v30, v4, vcc_lo                      // 0000007306E4: 0200091E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007306E8: BF8701B2
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007306EC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s5, v31, s0                 // 0000007306F4: D5207C1B 00023E05
	.long 0xd7000020                                           // 0000007306FC: D7000020
	v_cndmask_b32_e32 v0, v30, v14, vcc_lo                     // 000000730700: 02001D1E
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000730704: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v33, null, s15, v31, s0                // 00000073070C: D5207C21 00023E0F
	.long 0xd700001e                                           // 000000730714: D700001E
	v_cndmask_b32_e32 v0, v30, v18, vcc_lo                     // 000000730718: 0200251E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000073071C: BF870123
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730720: CC1A4004 1C12531D
	v_add_co_ci_u32_e64 v31, null, s16, v31, s0                // 000000730728: D5207C1F 00023E10
	v_add_f32_e32 v23, v23, v4                                 // 000000730730: 062E0917
	s_clause 0x1                                               // 000000730734: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000730738: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 000000730740: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000730748: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073074C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730754: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000730758: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000730760: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000730768: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 00000073076C: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 000000730774: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000730778: CC1A4004 1C124D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730780: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000730784: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073078C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730794: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730798: CC1A4004 1C12531D
	v_add_f32_e32 v22, v22, v4                                 // 0000007307A0: 062C0916
	s_clause 0x1                                               // 0000007307A4: BF850001
	global_load_b128 v[4:7], v[32:33], off                     // 0000007307A8: DC5E0000 047C0020
	global_load_b128 v[26:29], v[32:33], off offset:16         // 0000007307B0: DC5E0010 1A7C0020
	s_waitcnt vmcnt(1)                                         // 0000007307B8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007307BC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007307C4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007307C8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007307D0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007307D8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007307DC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007307E4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007307E8: CC1A4004 1C124D1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007307F0: BF870091
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007307F4: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 0000007307FC: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730804: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730808: CC1A4004 1C12531D
	v_add_f32_e32 v21, v21, v4                                 // 000000730810: 062A0915
	s_clause 0x1                                               // 000000730814: BF850001
	global_load_b128 v[4:7], v[30:31], off                     // 000000730818: DC5E0000 047C001E
	global_load_b128 v[26:29], v[30:31], off offset:16         // 000000730820: DC5E0010 1A7C001E
	s_waitcnt vmcnt(1)                                         // 000000730828: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073082C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730834: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000730838: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000730840: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000730848: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 00000073084C: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 000000730854: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000730858: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 000000730860: D700001A
	v_cndmask_b32_e32 v0, v32, v14, vcc_lo                     // 000000730864: 02001D20
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730868: BF870122
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 00000073086C: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s15, v33, s0                // 000000730874: D5207C1B 0002420F
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073087C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730884: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730888: CC1A4004 1C12531D
	v_add_f32_e32 v20, v20, v4                                 // 000000730890: 06280914
	s_clause 0x1                                               // 000000730894: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000730898: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 0000007308A0: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 0000007308A8: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 0000007308AC: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007308B4: BF870091
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 0000007308B8: CC1A4004 1C124705
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 0000007308C0: CC1A4004 1C124906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007308C8: BF8700A1
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 0000007308CC: CC1A4004 1C124B07
	s_waitcnt vmcnt(0)                                         // 0000007308D4: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 0000007308D8: CC1A4004 1C124D1A
	.long 0xd700001a                                           // 0000007308E0: D700001A
	v_cndmask_b32_e32 v0, v30, v14, vcc_lo                     // 0000007308E4: 02001D1E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007308E8: BF8701B2
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 0000007308EC: CC1A4004 1C124F1B
	v_add_co_ci_u32_e64 v27, null, s15, v31, s0                // 0000007308F4: D5207C1B 00023E0F
	.long 0xd700000d                                           // 0000007308FC: D700000D
	v_cndmask_b32_e32 v0, v13, v144, vcc_lo                    // 000000730900: 0201210D
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 000000730904: CC1A4004 1C12511C
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 00000073090C: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730914: BF870092
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730918: CC1A4004 1C12531D
	v_add_f32_e32 v19, v19, v4                                 // 000000730920: 06260913
	s_clause 0x1                                               // 000000730924: BF850001
	global_load_b128 v[4:7], v[26:27], off                     // 000000730928: DC5E0000 047C001A
	global_load_b128 v[26:29], v[26:27], off offset:16         // 000000730930: DC5E0010 1A7C001A
	s_waitcnt vmcnt(1)                                         // 000000730938: BF8907F7
	v_dot2_f32_bf16 v4, v4, v34, 0                             // 00000073093C: CC1A4004 1A024504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730944: BF870121
	v_dot2_f32_bf16 v4, v5, v35, v4                            // 000000730948: CC1A4004 1C124705
	v_mov_b32_e32 v5, v1                                       // 000000730950: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v36, v4                            // 000000730954: CC1A4004 1C124906
	v_mov_b32_e32 v6, v2                                       // 00000073095C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000730960: BF870132
	v_dot2_f32_bf16 v4, v7, v37, v4                            // 000000730964: CC1A4004 1C124B07
	v_mov_b32_e32 v7, v3                                       // 00000073096C: 7E0E0303
	s_waitcnt vmcnt(0)                                         // 000000730970: BF8903F7
	v_dot2_f32_bf16 v4, v26, v38, v4                           // 000000730974: CC1A4004 1C124D1A
	.long 0x7e343908                                           // 00000073097C: 7E343908
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730980: BF870092
	v_dot2_f32_bf16 v4, v27, v39, v4                           // 000000730984: CC1A4004 1C124F1B
	v_dot2_f32_bf16 v4, v28, v40, v4                           // 00000073098C: CC1A4004 1C12511C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730994: BF870091
	v_dot2_f32_bf16 v4, v29, v41, v4                           // 000000730998: CC1A4004 1C12531D
	v_add_f32_e32 v16, v16, v4                                 // 0000007309A0: 06200910
	v_mov_b32_e32 v4, v0                                       // 0000007309A4: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000007309A8: 917E117E
	s_cbranch_execz 29                                         // 0000007309AC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x924>
	v_add_nc_u32_e32 v24, 16, v24                              // 0000007309B0: 4A303090
	v_add_nc_u32_e32 v25, 0x100, v11                           // 0000007309B4: 4A3216FF 00000100
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007309BC: BF8704A2
	.long 0xd4430000                                           // 0000007309C0: D4430000
	v_cndmask_b32_e32 v1, s2, v24, vcc_lo                      // 0000007309C4: 02023002
	s_and_saveexec_b32 s1, s0                                  // 0000007309C8: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000007309CC: 8D01017E
	v_add_nc_u32_e32 v25, 0x100, v11                           // 0000007309D0: 4A3216FF 00000100
	s_or_saveexec_b32 s10, s1                                  // 0000007309D8: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000007309DC: BF8903F7
	.long 0x7e10391a                                           // 0000007309E0: 7E10391A
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v1, v5             // 0000007309E4: CA100104 00000105
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000007309EC: CA100106 02020107
	s_xor_b32 exec_lo, exec_lo, s10                            // 0000007309F4: 8D7E0A7E
	s_cbranch_execz 65075                                      // 0000007309F8: BFA5FE33 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x1c8>
	.long 0xd7000100                                           // 0000007309FC: D7000100
	v_cndmask_b32_e32 v1, v17, v25, vcc_lo                     // 000000730A00: 02023311
	s_delay_alu instid0(VALU_DEP_1)                            // 000000730A04: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v18, s1                   // 000000730A08: D5207C01 00062480
	global_load_b128 v[0:3], v[0:1], off                       // 000000730A10: DC5E0000 007C0000
	global_load_d16_b16 v8, v[13:14], off                      // 000000730A18: DC820000 087C000D
	s_branch 65065                                             // 000000730A20: BFA0FE29 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0x1c8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000730A24: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000730A28: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000730A2C: 8C7E037E
	.long 0xd71f0000                                           // 000000730A30: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000730A34: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000730A38: 3A020088
	s_waitcnt vmcnt(1)                                         // 000000730A3C: BF8907F7
	v_xor_b32_e32 v7, 4, v0                                    // 000000730A40: 3A0E0084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730A44: BF870092
	.long 0xd44c0000                                           // 000000730A48: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000730A4C: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000730A50: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000730A58: BF870113
	.long 0xd44c0000                                           // 000000730A5C: D44C0000
	v_cndmask_b32_e32 v1, 32, v7, vcc_lo                       // 000000730A60: 02020EA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000730A64: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000730A68: BF870002
	v_cndmask_b32_e64 v7, v0, v7, s0                           // 000000730A6C: D5010007 00020F00
	ds_bpermute_b32 v2, v1, v23                                // 000000730A74: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 000000730A7C: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000730A80: 06040517
	ds_bpermute_b32 v4, v1, v21                                // 000000730A84: DACC0000 04001501
	ds_bpermute_b32 v3, v1, v22                                // 000000730A8C: DACC0000 03001601
	ds_bpermute_b32 v5, v1, v20                                // 000000730A94: DACC0000 05001401
	ds_bpermute_b32 v6, v1, v19                                // 000000730A9C: DACC0000 06001301
	ds_bpermute_b32 v1, v1, v16                                // 000000730AA4: DACC0000 01001001
	s_waitcnt lgkmcnt(4)                                       // 000000730AAC: BF89FC47
	v_dual_add_f32 v4, v21, v4 :: v_dual_lshlrev_b32 v7, 2, v7 // 000000730AB0: C9220915 04060E82
	ds_bpermute_b32 v8, v7, v2                                 // 000000730AB8: DACC0000 08000207
	s_waitcnt lgkmcnt(2)                                       // 000000730AC0: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_add_f32 v6, v19, v6   // 000000730AC4: C9080716 03060D13
	s_waitcnt lgkmcnt(1)                                       // 000000730ACC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 000000730AD0: 06020310
	v_xor_b32_e32 v16, 2, v0                                   // 000000730AD4: 3A200082
	ds_bpermute_b32 v12, v7, v4                                // 000000730AD8: DACC0000 0C000407
	ds_bpermute_b32 v11, v7, v3                                // 000000730AE0: DACC0000 0B000307
	ds_bpermute_b32 v14, v7, v6                                // 000000730AE8: DACC0000 0E000607
	.long 0xd44c0000                                           // 000000730AF0: D44C0000
	v_cndmask_b32_e32 v1, 32, v16, vcc_lo                      // 000000730AF4: 020220A0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730AF8: BF870091
	v_cndmask_b32_e64 v16, v0, v16, s0                         // 000000730AFC: D5010010 00022100
	v_dual_add_f32 v5, v20, v5 :: v_dual_lshlrev_b32 v16, 2, v16// 000000730B04: C9220B14 05102082
	ds_bpermute_b32 v13, v7, v5                                // 000000730B0C: DACC0000 0D000507
	s_waitcnt lgkmcnt(4)                                       // 000000730B14: BF89FC47
	v_add_f32_e32 v2, v2, v8                                   // 000000730B18: 06041102
	ds_bpermute_b32 v7, v7, v1                                 // 000000730B1C: DACC0000 07000107
	s_waitcnt lgkmcnt(4)                                       // 000000730B24: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 000000730B28: 06081904
	s_waitcnt lgkmcnt(3)                                       // 000000730B2C: BF89FC37
	v_add_f32_e32 v8, v3, v11                                  // 000000730B30: 06101703
	v_xor_b32_e32 v3, 1, v0                                    // 000000730B34: 3A060081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730B38: BF870091
	.long 0xd44c0000                                           // 000000730B3C: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000730B40: 020206A0
	v_cndmask_b32_e64 v0, v0, v3, s0                           // 000000730B44: D5010000 00020700
	s_waitcnt lgkmcnt(2)                                       // 000000730B4C: BF89FC27
	v_add_f32_e32 v6, v6, v14                                  // 000000730B50: 060C1D06
	.long 0xd44a0000                                           // 000000730B54: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000730B58: 02021E80
	s_waitcnt lgkmcnt(1)                                       // 000000730B5C: BF89FC17
	v_add_f32_e32 v5, v5, v13                                  // 000000730B60: 060A1B05
	ds_bpermute_b32 v11, v16, v8                               // 000000730B64: DACC0000 0B000810
	s_waitcnt lgkmcnt(1)                                       // 000000730B6C: BF89FC17
	v_add_f32_e32 v7, v1, v7                                   // 000000730B70: 060E0F01
	ds_bpermute_b32 v1, v16, v2                                // 000000730B74: DACC0000 01000210
	ds_bpermute_b32 v12, v16, v4                               // 000000730B7C: DACC0000 0C000410
	ds_bpermute_b32 v13, v16, v5                               // 000000730B84: DACC0000 0D000510
	v_lshlrev_b32_e32 v17, 2, v0                               // 000000730B8C: 30220082
	ds_bpermute_b32 v14, v16, v6                               // 000000730B90: DACC0000 0E000610
	ds_bpermute_b32 v16, v16, v7                               // 000000730B98: DACC0000 10000710
	s_and_b32 s0, s0, vcc_lo                                   // 000000730BA0: 8B006A00
	s_waitcnt lgkmcnt(4)                                       // 000000730BA4: BF89FC47
	v_dual_add_f32 v0, v8, v11 :: v_dual_add_f32 v3, v2, v1    // 000000730BA8: C9081708 00020302
	s_waitcnt lgkmcnt(2)                                       // 000000730BB0: BF89FC27
	v_dual_add_f32 v1, v4, v12 :: v_dual_add_f32 v2, v5, v13   // 000000730BB4: C9081904 01021B05
	ds_bpermute_b32 v5, v17, v0                                // 000000730BBC: DACC0000 05000011
	s_waitcnt lgkmcnt(2)                                       // 000000730BC4: BF89FC27
	v_add_f32_e32 v4, v6, v14                                  // 000000730BC8: 06081D06
	s_waitcnt lgkmcnt(1)                                       // 000000730BCC: BF89FC17
	v_add_f32_e32 v8, v7, v16                                  // 000000730BD0: 06102107
	ds_bpermute_b32 v11, v17, v3                               // 000000730BD4: DACC0000 0B000311
	ds_bpermute_b32 v6, v17, v1                                // 000000730BDC: DACC0000 06000111
	ds_bpermute_b32 v7, v17, v2                                // 000000730BE4: DACC0000 07000211
	ds_bpermute_b32 v12, v17, v4                               // 000000730BEC: DACC0000 0C000411
	ds_bpermute_b32 v13, v17, v8                               // 000000730BF4: DACC0000 0D000811
	s_and_saveexec_b32 s1, s0                                  // 000000730BFC: BE812000
	s_cbranch_execz 52                                         // 000000730C00: BFA50034 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi6ELi16ELi1ELb1EEEvPKhPKtPvll+0xbd4>
	.long 0xd73c0009                                           // 000000730C04: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 000000730C08: 02021282
	s_waitcnt lgkmcnt(0)                                       // 000000730C0C: BF89FC07
	v_add_f32_e32 v13, v8, v13                                 // 000000730C10: 061A1B08
	v_dual_add_f32 v3, v3, v11 :: v_dual_add_f32 v14, v1, v6   // 000000730C14: C9081703 030E0D01
	v_add_f32_e32 v15, v0, v5                                  // 000000730C1C: 061E0B00
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000730C20: 8480820C
	.long 0xd7006a08                                           // 000000730C24: D7006A08
	v_cndmask_b32_e32 v1, s8, v9, vcc_lo                       // 000000730C28: 02021208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000730C2C: BF870121
	v_add_co_ci_u32_e64 v9, null, s9, v10, vcc_lo              // 000000730C30: D5207C09 01AA1409
	v_dual_add_f32 v11, v4, v12 :: v_dual_add_f32 v12, v2, v7  // 000000730C38: C9081904 0B0C0F02
	v_mad_u64_u32 v[0:1], null, s12, 12, v[8:9]                // 000000730C40: D6FE7C00 0421180C
	global_store_b32 v[8:9], v3, off                           // 000000730C48: DC6A0000 007C0308
	.long 0xd7006a03                                           // 000000730C50: D7006A03
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000730C54: 02000108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000730C58: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s1, v9, vcc_lo               // 000000730C5C: D5207C04 01AA1201
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000730C64: 8480830C
	.long 0xd7006a05                                           // 000000730C68: D7006A05
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000730C6C: 02000108
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000730C70: D6FE7C01 0405180D
	v_add_co_ci_u32_e64 v6, null, s1, v9, vcc_lo               // 000000730C78: D5207C06 01AA1201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000730C80: BF870093
	.long 0xd7006a07                                           // 000000730C84: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000730C88: 02000105
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 000000730C8C: D5207C08 01AA0C01
	.long 0xd7006a09                                           // 000000730C94: D7006A09
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000730C98: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000730C9C: BF870001
	v_add_co_ci_u32_e64 v10, null, s1, v1, vcc_lo              // 000000730CA0: D5207C0A 01AA0201
	s_clause 0x4                                               // 000000730CA8: BF850004
	global_store_b32 v[3:4], v15, off                          // 000000730CAC: DC6A0000 007C0F03
	global_store_b32 v[5:6], v14, off                          // 000000730CB4: DC6A0000 007C0E05
	global_store_b32 v[0:1], v12, off                          // 000000730CBC: DC6A0000 007C0C00
	global_store_b32 v[7:8], v11, off                          // 000000730CC4: DC6A0000 007C0B07
	global_store_b32 v[9:10], v13, off                         // 000000730CCC: DC6A0000 007C0D09
	s_endpgm                                                   // 000000730CD4: BFB00000
		...

