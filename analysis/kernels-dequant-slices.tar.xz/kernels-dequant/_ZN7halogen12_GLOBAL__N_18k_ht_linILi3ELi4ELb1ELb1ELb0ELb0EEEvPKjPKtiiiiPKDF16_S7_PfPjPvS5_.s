000000000050e100 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 00000050E100: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 00000050E104: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000050E10C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 00000050E114: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 00000050E11C: BE8A0003
	v_and_b32_e32 v52, 31, v0                                  // 00000050E120: 3668009F
	v_lshrrev_b32_e32 v50, 5, v0                               // 00000050E124: 32640085
	s_delay_alu instid0(VALU_DEP_2)                            // 00000050E128: BF870002
	v_lshlrev_b32_e32 v8, 3, v52                               // 00000050E12C: 30106883
	s_waitcnt lgkmcnt(0)                                       // 00000050E130: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 00000050E134: 86229F19
	s_mul_i32 s11, s27, s10                                    // 00000050E138: 960B0A1B
	s_lshr_b32 s3, s34, 25                                     // 00000050E13C: 85039922
	s_add_i32 s4, s11, s27                                     // 00000050E140: 81041B0B
	s_add_i32 s3, s25, s3                                      // 00000050E144: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000050E148: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000050E14C: 86038703
	s_min_i32 s3, s3, s4                                       // 00000050E150: 89030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000050E154: BF8704B9
	s_sub_i32 s9, s3, s11                                      // 00000050E158: 81890B03
	s_mov_b32 s3, exec_lo                                      // 00000050E15C: BE83007E
	s_lshl_b32 s27, s9, 2                                      // 00000050E160: 841B8209
	.long 0xd4c3007e                                           // 00000050E164: D4C3007E
	v_cndmask_b32_e32 v1, s27, v50, vcc_lo                     // 00000050E168: 0202641B
	s_xor_b32 s3, exec_lo, s3                                  // 00000050E16C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v52                               // 00000050E170: 30106883
	s_or_saveexec_b32 s35, s3                                  // 00000050E174: BEA32203
	s_clause 0x1                                               // 00000050E178: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 00000050E17C: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 00000050E184: F4080700 F8000000
	v_lshlrev_b32_e32 v51, 2, v52                              // 00000050E18C: 30666882
	s_xor_b32 exec_lo, exec_lo, s35                            // 00000050E190: 8D7E237E
	s_cbranch_execz 502                                        // 00000050E194: BFA501F6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x870>
	s_add_i32 s36, s24, -1                                     // 00000050E198: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000050E19C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 00000050E1A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 00000050E1A4: 982580C1
	s_abs_i32 s38, s9                                          // 00000050E1A8: BEA61509
	v_and_b32_e32 v3, 2, v0                                    // 00000050E1AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 00000050E1B0: BE806526
	v_dual_mov_b32 v9, v50 :: v_dual_and_b32 v4, 4, v0         // 00000050E1B4: CA240132 09040084
	v_and_b32_e32 v5, 8, v0                                    // 00000050E1BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050E1C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 00000050E1C4: 7E045600
	v_lshl_or_b32 v6, v50, 8, v8                               // 00000050E1C8: D6560006 04211132
	v_add_nc_u32_e32 v7, s11, v50                              // 00000050E1D0: 4A0E640B
	s_ashr_i32 s42, s9, 31                                     // 00000050E1D4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 00000050E1D8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 00000050E1DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 00000050E1E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v52, vcc_lo                      // 00000050E1E8: 02026890
	.long 0xd44a0001                                           // 00000050E1EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000050E1F0: 02020280
	.long 0xd44a0004                                           // 00000050E1F4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000050E1F8: 02020880
	.long 0xd44a0005                                           // 00000050E1FC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 00000050E200: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 00000050E204: 7E060502
	v_lshl_or_b32 v1, v7, 7, v51                               // 00000050E208: D6560001 04CD0F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 00000050E210: 4E140C2C
	s_lshl_b32 s6, s9, 7                                       // 00000050E214: 84068709
	s_mov_b32 s39, s25                                         // 00000050E218: BEA70019
	s_mul_f32 s7, s3, 0x4f7ffffe                               // 00000050E21C: A207FF03 4F7FFFFE
	.long 0xd44a0003                                           // 00000050E224: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 00000050E228: 02020680
	s_mov_b32 s40, 0                                           // 00000050E22C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 00000050E230: BEA900FF 76543210
	s_cvt_u32_f32 s7, s7                                       // 00000050E238: BE876707
	s_lshl_b32 s43, s9, 8                                      // 00000050E23C: 842B8809
	s_sub_i32 s44, 0, s6                                       // 00000050E240: 81AC0680
	s_mov_b32 s46, 0x3db504f3                                  // 00000050E244: BEAE00FF 3DB504F3
	s_mul_i32 s8, s8, s7                                       // 00000050E24C: 96080708
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000050E250: BF870499
	s_mul_hi_u32 s8, s7, s8                                    // 00000050E254: 96880807
	s_add_i32 s45, s7, s8                                      // 00000050E258: 812D0807
	s_branch 161                                               // 00000050E25C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E260: BF870091
	.long 0xd7006a02                                           // 00000050E264: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000050E268: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000050E26C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 00000050E274: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000050E27C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 00000050E284: 06061D10
	s_waitcnt vmcnt(0)                                         // 00000050E288: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000050E28C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 00000050E294: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 00000050E298: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000050E2A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 00000050E2A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 00000050E2AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050E2B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000050E2B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050E2C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 00000050E2C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050E2CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 00000050E2D4: D5010007 20060F07
	.long 0xd72c0006                                           // 00000050E2DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 00000050E2E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050E2E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000050E2F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050E2F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 00000050E2FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000050E300: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 00000050E308: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050E310: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 00000050E318: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000050E31C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050E324: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000050E32C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 00000050E330: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050E338: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 00000050E340: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 00000050E348: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000050E34C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 00000050E354: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000050E35C: 060A1905
	.long 0xd72c0007                                           // 00000050E360: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 00000050E364: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 00000050E368: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050E36C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 00000050E374: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 00000050E378: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050E380: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 00000050E388: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050E390: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000050E398: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 00000050E3A0: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 00000050E3A8: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 00000050E3B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050E3B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 00000050E3BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 00000050E3C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050E3C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 00000050E3D0: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 00000050E3D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050E3DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 00000050E3E4: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050E3EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 00000050E3F4: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 00000050E3FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000050E400: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 00000050E408: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E410: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 00000050E414: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 00000050E41C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 00000050E420: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E428: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 00000050E42C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 00000050E434: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000050E438: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 00000050E43C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 00000050E448: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 00000050E450: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 00000050E454: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 00000050E45C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 00000050E464: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 00000050E470: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 00000050E47C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 00000050E480: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s27, v9                           // 00000050E48C: 7C86121B
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 00000050E490: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 00000050E498: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E49C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 00000050E4A0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 00000050E4AC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 00000050E4B4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E4BC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 00000050E4C0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 00000050E4C8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 00000050E4D0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 00000050E4D4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 00000050E4DC: 917E287E
	s_cbranch_execz 290                                        // 00000050E4E0: BFA50122 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	.long 0xd72d0002                                           // 00000050E4E4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 00000050E4E8: 02005B09
	s_mov_b32 s6, -1                                           // 00000050E4EC: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E4F0: BF870091
	.long 0xd72c0003                                           // 00000050E4F4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 00000050E4F8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 00000050E4FC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000050E500: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 00000050E504: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000050E508: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 00000050E50C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E514: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000050E518: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 00000050E51C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E520: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 00000050E524: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 00000050E528: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 00000050E52C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E530: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 00000050E534: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 00000050E538: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050E53C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 00000050E540: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 00000050E548: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 00000050E54C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E554: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 00000050E558: 340E0C9F
	.long 0xd73c0002                                           // 00000050E55C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000050E560: 02020C81
	s_cbranch_vccnz 212                                        // 00000050E564: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E568: BF870093
	.long 0xd7006a06                                           // 00000050E56C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000050E570: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 00000050E574: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 00000050E57C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E580: BF870112
	.long 0xd73c0006                                           // 00000050E584: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000050E588: 02020C81
	.long 0x7f40399d                                           // 00000050E58C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 00000050E590: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E594: BF870092
	.long 0xd7006a0d                                           // 00000050E598: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 00000050E59C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 00000050E5A0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 00000050E5A8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 00000050E5AC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050E5B0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 00000050E5B4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 00000050E5BC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 00000050E5C4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000050E5C8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 00000050E5CC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 00000050E5D4: D5207C10 01AA060D
	s_clause 0x1                                               // 00000050E5DC: BF850001
	global_load_b32 v17, v[15:16], off                         // 00000050E5E0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 00000050E5E8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 00000050E5F0: BF890FF7
	.long 0x7e20390d                                           // 00000050E5F4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 00000050E5F8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 00000050E5FC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000050E604: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E608: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000050E60C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 00000050E610: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000050E618: BF870291
	v_exp_f32_e32 v20, v20                                     // 00000050E61C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 00000050E620: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E62C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 00000050E630: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 00000050E638: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000050E640: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 00000050E644: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 00000050E648: 30241C90
	v_div_scale_f32 v37, s7, v16, v20, v16                     // 00000050E64C: D6FC0725 04422910
	v_rcp_f32_e32 v28, v24                                     // 00000050E654: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E658: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 00000050E65C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 00000050E660: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E668: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 00000050E66C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 00000050E674: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 00000050E67C: BF870003
	v_exp_f32_e32 v21, v21                                     // 00000050E680: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 00000050E684: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 00000050E68C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 00000050E694: 56383924
	v_rcp_f32_e32 v26, v23                                     // 00000050E698: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000050E69C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 00000050E6A0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E6AC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 00000050E6B0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 00000050E6B8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050E6C0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 00000050E6C4: 7E2C4B16
	v_div_scale_f32 v35, s6, v18, v21, v18                     // 00000050E6C8: D6FC0623 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 00000050E6D0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000050E6D4: BF870293
	v_rcp_f32_e32 v30, v25                                     // 00000050E6D8: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 00000050E6DC: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E6E4: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 00000050E6E8: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 00000050E6EC: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E6F0: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 00000050E6F4: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 00000050E6F8: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E700: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 00000050E704: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 00000050E70C: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E710: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 00000050E714: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 00000050E718: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E720: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 00000050E724: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 00000050E72C: D6370017 049A3517
	s_mov_b32 vcc_lo, s7                                       // 00000050E734: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E738: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 00000050E73C: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 00000050E744: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050E74C: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 00000050E750: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s8, v14, v22, v14                     // 00000050E758: D6FC0824 043A2D0E
	.long 0x7e3a398d                                           // 00000050E760: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000050E764: BF870293
	v_rcp_f32_e32 v31, v27                                     // 00000050E768: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 00000050E76C: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050E774: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 00000050E778: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 00000050E780: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E784: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 00000050E788: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 00000050E790: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E798: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 00000050E79C: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 00000050E7A0: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E7A4: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 00000050E7A8: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 00000050E7B0: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000050E7B8: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 00000050E7BC: D6370018 048A3918
	s_mov_b32 vcc_lo, s6                                       // 00000050E7C4: BEEA0006
	s_mov_b32 s6, 0                                            // 00000050E7C8: BE860080
	v_div_fmas_f32 v19, v25, v30, v40                          // 00000050E7CC: D6370013 04A23D19
	s_mov_b32 vcc_lo, s8                                       // 00000050E7D4: BEEA0008
	v_div_fixup_f32 v16, v24, v20, v16                         // 00000050E7D8: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 00000050E7E0: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 00000050E7E4: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 00000050E7EC: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050E7F4: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 00000050E7F8: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 00000050E7FC: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 00000050E804: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E808: BF870193
	.long 0x7e403986                                           // 00000050E80C: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 00000050E810: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 00000050E818: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E81C: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 00000050E820: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 00000050E828: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050E830: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 00000050E834: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 00000050E840: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E84C: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 00000050E850: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 00000050E85C: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E864: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 00000050E868: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 00000050E870: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050E878: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000050E87C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000050E884: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000050E890: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000050E894: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 00000050E89C: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 00000050E8A0: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 00000050E8A8: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 00000050E8B0: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 00000050E8B8: 916A067E
	s_cbranch_vccnz 65128                                      // 00000050E8BC: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050E8C0: BF8700A3
	.long 0xd73c0004                                           // 00000050E8C4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000050E8C8: 02020881
	s_waitcnt lgkmcnt(0)                                       // 00000050E8CC: BF89FC07
	.long 0xd7006a04                                           // 00000050E8D0: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 00000050E8D4: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050E8D8: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 00000050E8DC: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 00000050E8E4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 00000050E8E8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050E8EC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 00000050E8F0: D5207C05 01AA0705
	.long 0xd7006a06                                           // 00000050E8F8: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 00000050E8FC: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 00000050E900: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 00000050E908: DC560000 047C0004
	s_clause 0x1                                               // 00000050E910: BF850001
	global_load_b32 v15, v[6:7], off                           // 00000050E914: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 00000050E91C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 00000050E924: BF890BF7
	.long 0x7e0e3904                                           // 00000050E928: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000050E92C: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 00000050E934: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050E938: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 00000050E93C: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000050E940: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 00000050E944: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 00000050E94C: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 00000050E950: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 00000050E958: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 00000050E960: 361E0AFF FFFF0000
	s_branch 65085                                             // 00000050E968: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 00000050E96C: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050E970: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 00000050E974: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 00000050E978: 9388FF09 0001001C
	v_mad_u32_u24 v9, v52, 24, 0x2f0                           // 00000050E980: D60B0009 03FD3134 000002F0
	s_lshr_b64 s[0:1], s[8:9], 29                              // 00000050E98C: 85809D08
	s_lshr_b32 s1, s34, 28                                     // 00000050E990: 85019C22
	s_add_i32 s0, s0, 7                                        // 00000050E994: 81008700
	s_add_i32 s1, s25, s1                                      // 00000050E998: 81010119
	s_ashr_i32 s0, s0, 3                                       // 00000050E99C: 86008300
	v_lshrrev_b32_e32 v1, 5, v9                                // 00000050E9A0: 32021285
	.long 0xd72c0007                                           // 00000050E9A4: D72C0007
	v_cndmask_b32_e32 v1, s0, v50, vcc_lo                      // 00000050E9A8: 02026400
	s_ashr_i32 s1, s1, 4                                       // 00000050E9AC: 86018401
	s_lshl_b32 s3, s9, 3                                       // 00000050E9B0: 84038309
	s_lshl_b32 s4, s11, 3                                      // 00000050E9B4: 8404830B
	s_mul_i32 s6, s1, s2                                       // 00000050E9B8: 96060201
	s_ashr_i32 s5, s4, 31                                      // 00000050E9BC: 86059F04
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000050E9C0: 4E020298
	v_cmp_eq_u32_e32 vcc_lo, 0, v52                            // 00000050E9C4: 7C946880
	v_add_nc_u32_e32 v2, s0, v7                                // 00000050E9C8: 4A040E00
	s_mul_hi_i32 s0, s1, s2                                    // 00000050E9CC: 97000201
	s_add_u32 s1, s6, s4                                       // 00000050E9D0: 80010406
	s_addc_u32 s0, s0, s5                                      // 00000050E9D4: 82000500
	s_mul_hi_u32 s4, s1, 0x300                                 // 00000050E9D8: 9684FF01 00000300
	v_min_i32_e32 v53, s3, v2                                  // 00000050E9E0: 226A0403
	s_mul_i32 s3, s0, 0x300                                    // 00000050E9E4: 9603FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 00000050E9EC: B8010300
	v_cndmask_b32_e64 v5, v1, 23, vcc_lo                       // 00000050E9F0: D5010005 01A92F01
	v_add_nc_u32_e32 v10, 8, v9                                // 00000050E9F8: 4A141288
	.long 0xd4410000                                           // 00000050E9FC: D4410000
	v_cndmask_b32_e32 v1, v7, v53, vcc_lo                      // 00000050EA00: 02026B07
	s_add_i32 s3, s4, s3                                       // 00000050EA04: 81030304
	s_waitcnt lgkmcnt(0)                                       // 00000050EA08: BF89FC07
	s_add_u32 s4, s28, s1                                      // 00000050EA0C: 8004011C
	s_addc_u32 s5, s29, s3                                     // 00000050EA10: 8205031D
	s_barrier                                                  // 00000050EA14: BFBD0000
	buffer_gl0_inv                                             // 00000050EA18: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 00000050EA20: BE832000
	s_cbranch_execz 121                                        // 00000050EA24: BFA50079 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb0c>
	v_lshrrev_b32_e32 v1, 5, v10                               // 00000050EA28: 32021485
	.long 0xd4440001                                           // 00000050EA2C: D4440001
	v_cndmask_b32_e32 v1, 23, v5, vcc_lo                       // 00000050EA30: 02020A97
	v_mad_i64_i32 v[3:4], null, 0x300, v7, s[4:5]              // 00000050EA34: D6FF7C03 00120EFF 00000300
	v_mov_b32_e32 v6, 0                                        // 00000050EA40: 7E0C0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050EA44: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000050EA48: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 00000050EA4C: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000050EA58: BF870193
	.long 0xd73c000b                                           // 00000050EA5C: D73C000B
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000050EA60: 02020A82
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000050EA64: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050EA6C: BF870113
	v_add_nc_u32_e32 v13, v2, v5                               // 00000050EA70: 4A1A0B02
	.long 0xd4440001                                           // 00000050EA74: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 00000050EA78: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000050EA7C: BF870112
	v_lshlrev_b32_e32 v14, 24, v13                             // 00000050EA80: 301C1A98
	v_cndmask_b32_e64 v15, 0xe9, 1, s1                         // 00000050EA84: D501000F 000502FF 000000E9
	v_mov_b32_e32 v2, v6                                       // 00000050EA90: 7E040306
	v_bfe_i32 v6, v13, 7, 1                                    // 00000050EA94: D6110006 02050F0D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050EA9C: BF870004
	v_ashrrev_i32_e32 v13, 22, v14                             // 00000050EAA0: 341A1C96
	.long 0xd700010b                                           // 00000050EAA4: D700010B
	v_cndmask_b32_e32 v1, v3, v11, vcc_lo                      // 00000050EAA8: 02021703
	v_add_nc_u32_e32 v15, v15, v1                              // 00000050EAAC: 4A1E030F
	.long 0xd73c0001                                           // 00000050EAB0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000050EAB4: 02020282
	v_add_co_ci_u32_e64 v12, null, v4, v12, s1                 // 00000050EAB8: D5207C0C 00061904
	.long 0xd700010d                                           // 00000050EAC0: D700010D
	v_cndmask_b32_e32 v1, v3, v13, vcc_lo                      // 00000050EAC4: 02021B03
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050EAC8: BF870244
	v_lshlrev_b32_e32 v16, 24, v15                             // 00000050EACC: 30201E98
	v_add_co_ci_u32_e64 v14, null, v4, v6, s1                  // 00000050EAD0: D5207C0E 00060D04
	v_bfe_i32 v6, v15, 7, 1                                    // 00000050EAD8: D6110006 02050F0F
	.long 0xd700010f                                           // 00000050EAE0: D700010F
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000050EAE4: 02020303
	v_ashrrev_i32_e32 v17, 22, v16                             // 00000050EAE8: 34222096
	v_add_co_ci_u32_e64 v16, null, v4, v2, s1                  // 00000050EAEC: D5207C10 00060504
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050EAF4: BF870092
	.long 0xd7000111                                           // 00000050EAF8: D7000111
	v_cndmask_b32_e32 v1, v3, v17, vcc_lo                      // 00000050EAFC: 02022303
	v_add_co_ci_u32_e64 v18, null, v4, v6, s1                  // 00000050EB00: D5207C12 00060D04
	s_clause 0x1f                                              // 00000050EB08: BF85001F
	global_load_b32 v2, v[11:12], off                          // 00000050EB0C: DC520000 027C000B
	global_load_b32 v47, v[11:12], off offset:96               // 00000050EB14: DC520060 2F7C000B
	global_load_b32 v45, v[11:12], off offset:192              // 00000050EB1C: DC5200C0 2D7C000B
	global_load_b32 v41, v[11:12], off offset:288              // 00000050EB24: DC520120 297C000B
	global_load_b32 v35, v[11:12], off offset:384              // 00000050EB2C: DC520180 237C000B
	global_load_b32 v31, v[11:12], off offset:480              // 00000050EB34: DC5201E0 1F7C000B
	global_load_b32 v27, v[11:12], off offset:576              // 00000050EB3C: DC520240 1B7C000B
	global_load_b32 v21, v[11:12], off offset:672              // 00000050EB44: DC5202A0 157C000B
	global_load_b32 v1, v[13:14], off                          // 00000050EB4C: DC520000 017C000D
	global_load_b32 v46, v[13:14], off offset:96               // 00000050EB54: DC520060 2E7C000D
	global_load_b32 v44, v[13:14], off offset:192              // 00000050EB5C: DC5200C0 2C7C000D
	global_load_b32 v40, v[13:14], off offset:288              // 00000050EB64: DC520120 287C000D
	global_load_b32 v34, v[13:14], off offset:384              // 00000050EB6C: DC520180 227C000D
	global_load_b32 v30, v[13:14], off offset:480              // 00000050EB74: DC5201E0 1E7C000D
	global_load_b32 v26, v[13:14], off offset:576              // 00000050EB7C: DC520240 1A7C000D
	global_load_b32 v20, v[13:14], off offset:672              // 00000050EB84: DC5202A0 147C000D
	global_load_b32 v4, v[15:16], off                          // 00000050EB8C: DC520000 047C000F
	global_load_b32 v49, v[15:16], off offset:96               // 00000050EB94: DC520060 317C000F
	global_load_b32 v43, v[15:16], off offset:192              // 00000050EB9C: DC5200C0 2B7C000F
	global_load_b32 v39, v[15:16], off offset:288              // 00000050EBA4: DC520120 277C000F
	global_load_b32 v37, v[15:16], off offset:384              // 00000050EBAC: DC520180 257C000F
	global_load_b32 v33, v[15:16], off offset:480              // 00000050EBB4: DC5201E0 217C000F
	global_load_b32 v29, v[15:16], off offset:576              // 00000050EBBC: DC520240 1D7C000F
	global_load_b32 v23, v[15:16], off offset:672              // 00000050EBC4: DC5202A0 177C000F
	global_load_b32 v3, v[17:18], off                          // 00000050EBCC: DC520000 037C0011
	global_load_b32 v48, v[17:18], off offset:96               // 00000050EBD4: DC520060 307C0011
	global_load_b32 v42, v[17:18], off offset:192              // 00000050EBDC: DC5200C0 2A7C0011
	global_load_b32 v38, v[17:18], off offset:288              // 00000050EBE4: DC520120 267C0011
	global_load_b32 v36, v[17:18], off offset:384              // 00000050EBEC: DC520180 247C0011
	global_load_b32 v32, v[17:18], off offset:480              // 00000050EBF4: DC5201E0 207C0011
	global_load_b32 v28, v[17:18], off offset:576              // 00000050EBFC: DC520240 1C7C0011
	global_load_b32 v22, v[17:18], off offset:672              // 00000050EC04: DC5202A0 167C0011
	s_or_b32 exec_lo, exec_lo, s3                              // 00000050EC0C: 8C7E037E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v54, 0             // 00000050EC10: CA100080 11360080
	v_dual_mov_b32 v55, 0 :: v_dual_mov_b32 v56, 0             // 00000050EC18: CA100080 37380080
	v_dual_mov_b32 v57, 0 :: v_dual_mov_b32 v58, 0             // 00000050EC20: CA100080 393A0080
	v_dual_mov_b32 v59, 0 :: v_dual_mov_b32 v60, 0             // 00000050EC28: CA100080 3B3C0080
	v_dual_mov_b32 v61, 0 :: v_dual_mov_b32 v62, 0             // 00000050EC30: CA100080 3D3E0080
	v_dual_mov_b32 v63, 0 :: v_dual_mov_b32 v66, 0             // 00000050EC38: CA100080 3F420080
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v68, 0             // 00000050EC40: CA100080 41440080
	v_dual_mov_b32 v67, 0 :: v_dual_mov_b32 v70, 0             // 00000050EC48: CA100080 43460080
	v_dual_mov_b32 v69, 0 :: v_dual_mov_b32 v72, 0             // 00000050EC50: CA100080 45480080
	v_dual_mov_b32 v73, 0 :: v_dual_mov_b32 v74, 0             // 00000050EC58: CA100080 494A0080
	v_dual_mov_b32 v75, 0 :: v_dual_mov_b32 v76, 0             // 00000050EC60: CA100080 4B4C0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v79, 0             // 00000050EC68: CA100080 4E4E0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v83, 0             // 00000050EC70: CA100080 40520080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v77, 0             // 00000050EC78: CA100080 524C0080
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v80, 0             // 00000050EC80: CA100080 47500080
	v_dual_mov_b32 v81, 0 :: v_dual_mov_b32 v84, 0             // 00000050EC88: CA100080 51540080
	s_ashr_i32 s3, s2, 31                                      // 00000050EC90: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 00000050EC94: BE812000
	s_cbranch_execz 1166                                       // 00000050EC98: BFA5048E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd4>
	v_lshrrev_b32_e32 v6, 5, v10                               // 00000050EC9C: 320C1485
	v_mul_i32_i24_e32 v10, 0xffffffe8, v52                     // 00000050ECA0: 121468FF FFFFFFE8
	v_dual_mov_b32 v12, 23 :: v_dual_and_b32 v9, 0x7e0, v9     // 00000050ECA8: CA240097 0C0812FF 000007E0
	v_or_b32_e32 v11, 4, v8                                    // 00000050ECB4: 38161084
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050ECB8: BF870004
	v_subrev_nc_u32_e32 v13, 24, v6                            // 00000050ECBC: 4E1A0C98
	.long 0xd7030008                                           // 00000050ECC0: D7030008
	v_cndmask_b32_e32 v0, v5, v129, vcc_lo                     // 00000050ECC4: 02010305
	v_ashrrev_i32_e32 v6, 31, v5                               // 00000050ECC8: 340C0A9F
	v_add3_u32 v86, v10, v9, 0xfffffd34                        // 00000050ECCC: D6550056 03FE130A FFFFFD34
	.long 0x7e14390c                                           // 00000050ECD8: 7E14390C
	v_cndmask_b32_e64 v16, v13, 23, vcc_lo                     // 00000050ECDC: D5010010 01A92F0D
	.long 0xd7624008                                           // 00000050ECE4: D7624008
	v_cndmask_b32_e32 v1, 0xff, v8, vcc_lo                     // 00000050ECE8: 020210FF 000000FF
	.long 0xd73c0012                                           // 00000050ECF0: D73C0012
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000050ECF4: 02020A82
	v_mad_u32_u24 v13, v11, 3, 0x2f0                           // 00000050ECF8: D60B000D 03FD070B 000002F0
	.long 0xd7040005                                           // 00000050ED04: D7040005
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 00000050ED08: 02021505
	.long 0xd7030009                                           // 00000050ED0C: D7030009
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 00000050ED10: 02010310
	v_cmp_gt_u16_e32 vcc_lo, 24, v136/*Invalid register, operand has 'VGPR_32_Lo128' register class*/// 00000050ED14: 7C791098
	v_mov_b32_e32 v17, 0                                       // 00000050ED18: 7E220280
	v_mul_i32_i24_e32 v11, -3, v11                             // 00000050ED1C: 121616C3
	s_movk_i32 s6, 0x1eee                                      // 00000050ED20: B0061EEE
	.long 0xd7624005                                           // 00000050ED24: D7624005
	v_cndmask_b32_e32 v1, 0xff, v9, vcc_lo                     // 00000050ED28: 020212FF 000000FF
	v_cndmask_b16 v5, v5, v8, vcc_lo                           // 00000050ED30: D65D0005 01AA1105
	v_and_b32_e32 v8, 0x7e0, v13                               // 00000050ED38: 36101AFF 000007E0
	v_mov_b32_e32 v56, v17                                     // 00000050ED40: 7E700311
	.long 0xd73c0018                                           // 00000050ED44: D73C0018
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000050ED48: 02022082
	.long 0xd43d1000                                           // 00000050ED4C: D43D1000
	v_cndmask_b32_e32 v1, 24, v5, vcc_lo                       // 00000050ED50: 02020A98
	v_and_b32_e32 v5, 0xff, v5                                 // 00000050ED54: 360A0AFF 000000FF
	v_dual_mov_b32 v54, v17 :: v_dual_and_b32 v85, 16, v0      // 00000050ED5C: CA240111 36540090
	v_mov_b32_e32 v57, v17                                     // 00000050ED64: 7E720311
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050ED68: BF870244
	v_cndmask_b16 v6, 0, v9, s0                                // 00000050ED6C: D65D0006 00021280
	v_mov_b32_e32 v55, v17                                     // 00000050ED74: 7E6E0311
	v_mov_b32_e32 v59, v17                                     // 00000050ED78: 7E760311
	v_mov_b32_e32 v60, v17                                     // 00000050ED7C: 7E780311
	v_dual_mov_b32 v61, v17 :: v_dual_and_b32 v6, 0xff, v6     // 00000050ED80: CA240111 3D060CFF 000000FF
	v_mov_b32_e32 v58, v17                                     // 00000050ED8C: 7E740311
	v_mov_b32_e32 v62, v17                                     // 00000050ED90: 7E7C0311
	v_mov_b32_e32 v63, v17                                     // 00000050ED94: 7E7E0311
	v_add3_u32 v87, v11, v8, 0xfffffd34                        // 00000050ED98: D6550057 03FE110B FFFFFD34
	v_lshlrev_b32_e32 v88, 2, v5                               // 00000050EDA4: 30B00A82
	v_lshlrev_b32_e32 v89, 2, v6                               // 00000050EDA8: 30B20C82
	v_mov_b32_e32 v65, v17                                     // 00000050EDAC: 7E820311
	v_mov_b32_e32 v66, v17                                     // 00000050EDB0: 7E840311
	v_mov_b32_e32 v67, v17                                     // 00000050EDB4: 7E860311
	v_mov_b32_e32 v68, v17                                     // 00000050EDB8: 7E880311
	v_mov_b32_e32 v69, v17                                     // 00000050EDBC: 7E8A0311
	v_mov_b32_e32 v70, v17                                     // 00000050EDC0: 7E8C0311
	v_mov_b32_e32 v72, v17                                     // 00000050EDC4: 7E900311
	v_mov_b32_e32 v73, v17                                     // 00000050EDC8: 7E920311
	v_mov_b32_e32 v74, v17                                     // 00000050EDCC: 7E940311
	v_mov_b32_e32 v75, v17                                     // 00000050EDD0: 7E960311
	v_mov_b32_e32 v76, v17                                     // 00000050EDD4: 7E980311
	v_mov_b32_e32 v78, v17                                     // 00000050EDD8: 7E9C0311
	v_mov_b32_e32 v64, v17                                     // 00000050EDDC: 7E800311
	v_mov_b32_e32 v79, v17                                     // 00000050EDE0: 7E9E0311
	v_mov_b32_e32 v82, v17                                     // 00000050EDE4: 7EA40311
	v_mov_b32_e32 v83, v17                                     // 00000050EDE8: 7EA60311
	v_mov_b32_e32 v77, v17                                     // 00000050EDEC: 7E9A0311
	v_mov_b32_e32 v71, v17                                     // 00000050EDF0: 7E8E0311
	v_mov_b32_e32 v80, v17                                     // 00000050EDF4: 7EA00311
	v_mov_b32_e32 v81, v17                                     // 00000050EDF8: 7EA20311
	v_mov_b32_e32 v84, v17                                     // 00000050EDFC: 7EA80311
	s_mov_b32 s0, 0                                            // 00000050EE00: BE800080
	s_branch 980                                               // 00000050EE04: BFA003D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c58>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000050EE08: 8C7E077E
	s_waitcnt vmcnt(23)                                        // 00000050EE0C: BF895FF7
	.long 0xd73d007b                                           // 00000050EE10: D73D007B
	v_cndmask_b32_e32 v1, v86, v1, vcc_lo                      // 00000050EE14: 02020356
	s_waitcnt vmcnt(7)                                         // 00000050EE18: BF891FF7
	.long 0xd73d007c                                           // 00000050EE1C: D73D007C
	v_cndmask_b32_e32 v1, v87, v3, vcc_lo                      // 00000050EE20: 02020757
	v_lshl_or_b32 v9, v7, 5, v85                               // 00000050EE24: D6560009 05550B07
	.long 0xd73d002e                                           // 00000050EE2C: D73D002E
	v_cndmask_b32_e32 v1, v86, v46, vcc_lo                     // 00000050EE30: 02025D56
	s_waitcnt vmcnt(6)                                         // 00000050EE34: BF891BF7
	.long 0xd73d002f                                           // 00000050EE38: D73D002F
	v_cndmask_b32_e32 v1, v87, v48, vcc_lo                     // 00000050EE3C: 02026157
	ds_load_b128 v[1:4], v9                                    // 00000050EE40: DBFC0000 01000009
	ds_load_b128 v[5:8], v9 offset:5120                        // 00000050EE48: DBFC1400 05000009
	v_bfe_u32 v125, v123, 9, 16                                // 00000050EE50: D610007D 0241137B
	v_bfe_u32 v126, v123, 6, 16                                // 00000050EE58: D610007E 02410D7B
	v_bfe_u32 v127, v123, 3, 16                                // 00000050EE60: D610007F 0241077B
	ds_load_b128 v[13:16], v9 offset:10240                     // 00000050EE68: DBFC2800 0D000009
	ds_load_b128 v[9:12], v9 offset:15360                      // 00000050EE70: DBFC3C00 09000009
	v_bfe_u32 v128, v124, 9, 16                                // 00000050EE78: D6100080 0241137C
	.long 0xd72c007d                                           // 00000050EE80: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000050EE84: 0202FAFF 83DCD12D
	.long 0xd72c007e                                           // 00000050EE8C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 00000050EE90: 0202FCFF 83DCD12D
	v_bfe_u32 v129, v124, 6, 16                                // 00000050EE98: D6100081 02410D7C
	v_bfe_u32 v130, v124, 3, 16                                // 00000050EEA0: D6100082 0241077C
	.long 0xd72c007f                                           // 00000050EEA8: D72C007F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v127, vcc_lo             // 00000050EEAC: 0202FEFF 83DCD12D
	.long 0xd72c0080                                           // 00000050EEB4: D72C0080
	v_cndmask_b32_e32 v1, 0x83dcd12d, v128, vcc_lo             // 00000050EEB8: 020300FF 83DCD12D
	v_bfe_u32 v49, v46, 6, 16                                  // 00000050EEC0: D6100031 02410D2E
	.long 0xd72c0081                                           // 00000050EEC8: D72C0081
	v_cndmask_b32_e32 v1, 0x83dcd12d, v129, vcc_lo             // 00000050EECC: 020302FF 83DCD12D
	v_sad_u8 v125, v125, 0, 0x6400                             // 00000050EED4: D622007D 03FD017D 00006400
	v_sad_u8 v126, v126, 0, 0x6400                             // 00000050EEE0: D622007E 03FD017E 00006400
	.long 0xd72c0082                                           // 00000050EEEC: D72C0082
	v_cndmask_b32_e32 v1, 0x83dcd12d, v130, vcc_lo             // 00000050EEF0: 020304FF 83DCD12D
	.long 0xd72c0031                                           // 00000050EEF8: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000050EEFC: 020262FF 83DCD12D
	v_sad_u8 v127, v127, 0, 0x6400                             // 00000050EF04: D622007F 03FD017F 00006400
	v_and_b32_e32 v125, 0xffff, v125                           // 00000050EF10: 36FAFAFF 0000FFFF
	v_sad_u8 v128, v128, 0, 0x6400                             // 00000050EF18: D6220080 03FD0180 00006400
	.long 0xd73d002c                                           // 00000050EF24: D73D002C
	v_cndmask_b32_e32 v1, v86, v44, vcc_lo                     // 00000050EF28: 02025956
	s_waitcnt vmcnt(5)                                         // 00000050EF2C: BF8917F7
	.long 0xd73d002a                                           // 00000050EF30: D73D002A
	v_cndmask_b32_e32 v1, v87, v42, vcc_lo                     // 00000050EF34: 02025557
	.long 0xd73d0028                                           // 00000050EF38: D73D0028
	v_cndmask_b32_e32 v1, v86, v40, vcc_lo                     // 00000050EF3C: 02025156
	v_lshl_or_b32 v125, v126, 16, v125                         // 00000050EF40: D656007D 05F5217E
	v_sad_u8 v126, v129, 0, 0x6400                             // 00000050EF48: D622007E 03FD0181 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000050EF54: D6220031 03FD0131 00006400
	v_bfe_u32 v43, v44, 3, 16                                  // 00000050EF60: D610002B 0241072C
	s_waitcnt vmcnt(4)                                         // 00000050EF68: BF8913F7
	.long 0xd73d0026                                           // 00000050EF6C: D73D0026
	v_cndmask_b32_e32 v1, v87, v38, vcc_lo                     // 00000050EF70: 02024D57
	v_pk_fma_f16 v125, v125, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000050EF74: CC0E007D 0BFC0D7D 0000C931
	v_and_b32_e32 v123, 0xffff, v123                           // 00000050EF80: 36F6F6FF 0000FFFF
	v_and_b32_e32 v124, 0xffff, v124                           // 00000050EF88: 36F8F8FF 0000FFFF
	v_and_b32_e32 v128, 0xffff, v128                           // 00000050EF90: 370100FF 0000FFFF
	.long 0xd72c002b                                           // 00000050EF98: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000050EF9C: 020256FF 83DCD12D
	s_waitcnt lgkmcnt(3)                                       // 00000050EFA4: BF89FC37
	v_dot2acc_f32_f16 v84, v125, v1                            // 00000050EFA8: 04A8037D
	.long 0xd72c007b                                           // 00000050EFAC: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000050EFB0: 0202F6FF 83DCD12D
	s_waitcnt lgkmcnt(2)                                       // 00000050EFB8: BF89FC27
	v_dot2acc_f32_f16 v81, v125, v5                            // 00000050EFBC: 04A20B7D
	.long 0xd72c007c                                           // 00000050EFC0: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000050EFC4: 0202F8FF 83DCD12D
	s_waitcnt lgkmcnt(0)                                       // 00000050EFCC: BF89FC07
	v_dot2acc_f32_f16 v71, v125, v9                            // 00000050EFD0: 048E137D
	v_lshl_or_b32 v126, v126, 16, v128                         // 00000050EFD4: D656007E 0601217E
	.long 0xd73d0022                                           // 00000050EFDC: D73D0022
	v_cndmask_b32_e32 v1, v86, v34, vcc_lo                     // 00000050EFE0: 02024556
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000050EFE4: D622002B 03FD012B 00006400
	s_waitcnt vmcnt(3)                                         // 00000050EFF0: BF890FF7
	.long 0xd73d0023                                           // 00000050EFF4: D73D0023
	v_cndmask_b32_e32 v1, v87, v36, vcc_lo                     // 00000050EFF8: 02024957
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000050EFFC: D622007B 03FD017B 00006400
	.long 0xd73d001e                                           // 00000050F008: D73D001E
	v_cndmask_b32_e32 v1, v86, v30, vcc_lo                     // 00000050F00C: 02023D56
	v_sad_u8 v124, v124, 0, 0x6400                             // 00000050F010: D622007C 03FD017C 00006400
	v_dot2acc_f32_f16 v80, v125, v13                           // 00000050F01C: 04A01B7D
	v_pk_fma_f16 v125, v126, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000050F020: CC0E007D 0BFC0D7E 0000C931
	v_lshlrev_b32_e32 v123, 16, v123                           // 00000050F02C: 30F6F690
	v_bfe_u32 v126, v47, 3, 16                                 // 00000050F030: D610007E 0241072F
	v_bfe_u32 v37, v34, 6, 16                                  // 00000050F038: D6100025 02410D22
	s_waitcnt vmcnt(2)                                         // 00000050F040: BF890BF7
	.long 0xd73d001f                                           // 00000050F044: D73D001F
	v_cndmask_b32_e32 v1, v87, v32, vcc_lo                     // 00000050F048: 02024157
	v_bfe_u32 v33, v30, 6, 16                                  // 00000050F04C: D6100021 02410D1E
	v_and_or_b32 v123, 0xffff, v127, v123                      // 00000050F054: D657007B 05EEFEFF 0000FFFF
	v_sad_u8 v127, v130, 0, 0x6400                             // 00000050F060: D622007F 03FD0182 00006400
	.long 0xd72c007e                                           // 00000050F06C: D72C007E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v126, vcc_lo             // 00000050F070: 0202FCFF 83DCD12D
	.long 0xd72c0025                                           // 00000050F078: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000050F07C: 02024AFF 83DCD12D
	.long 0xd72c0021                                           // 00000050F084: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000050F088: 020242FF 83DCD12D
	v_pk_fma_f16 v123, v123, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000050F090: CC0E007B 0BFC0D7B 0000C931
	v_lshlrev_b32_e32 v124, 16, v124                           // 00000050F09C: 30F8F890
	.long 0xd73d001a                                           // 00000050F0A0: D73D001A
	v_cndmask_b32_e32 v1, v86, v26, vcc_lo                     // 00000050F0A4: 02023556
	s_waitcnt vmcnt(1)                                         // 00000050F0A8: BF8907F7
	.long 0xd73d001b                                           // 00000050F0AC: D73D001B
	v_cndmask_b32_e32 v1, v87, v28, vcc_lo                     // 00000050F0B0: 02023957
	.long 0xd73d0014                                           // 00000050F0B4: D73D0014
	v_cndmask_b32_e32 v1, v86, v20, vcc_lo                     // 00000050F0B8: 02022956
	v_dot2acc_f32_f16 v81, v123, v6                            // 00000050F0BC: 04A20D7B
	v_and_or_b32 v124, 0xffff, v127, v124                      // 00000050F0C0: D657007C 05F2FEFF 0000FFFF
	v_dot2acc_f32_f16 v84, v123, v2                            // 00000050F0CC: 04A8057B
	v_dot2acc_f32_f16 v80, v123, v14                           // 00000050F0D0: 04A01D7B
	v_dot2acc_f32_f16 v71, v123, v10                           // 00000050F0D4: 048E157B
	v_dot2acc_f32_f16 v81, v125, v7                            // 00000050F0D8: 04A20F7D
	v_pk_fma_f16 v123, v124, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000050F0DC: CC0E007B 0BFC0D7C 0000C931
	v_bfe_u32 v124, v46, 9, 16                                 // 00000050F0E8: D610007C 0241132E
	v_dot2acc_f32_f16 v84, v125, v3                            // 00000050F0F0: 04A8077D
	v_dot2acc_f32_f16 v80, v125, v15                           // 00000050F0F4: 04A01F7D
	v_dot2acc_f32_f16 v71, v125, v11                           // 00000050F0F8: 048E177D
	v_dot2acc_f32_f16 v81, v123, v8                            // 00000050F0FC: 04A2117B
	.long 0xd72c0030                                           // 00000050F100: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000050F104: 0202F8FF 83DCD12D
	v_dot2acc_f32_f16 v84, v123, v4                            // 00000050F10C: 04A8097B
	v_dot2acc_f32_f16 v80, v123, v16                           // 00000050F110: 04A0217B
	v_dot2acc_f32_f16 v71, v123, v12                           // 00000050F114: 048E197B
	v_bfe_u32 v123, v46, 3, 16                                 // 00000050F118: D610007B 0241072E
	v_and_b32_e32 v46, 0xffff, v46                             // 00000050F120: 365C5CFF 0000FFFF
	v_bfe_u32 v124, v47, 9, 16                                 // 00000050F128: D610007C 0241132F
	v_bfe_u32 v125, v47, 6, 16                                 // 00000050F130: D610007D 02410D2F
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000050F138: D6220030 03FD0130 00006400
	.long 0xd72c007b                                           // 00000050F144: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000050F148: 0202F6FF 83DCD12D
	.long 0xd72c002e                                           // 00000050F150: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000050F154: 02025CFF 83DCD12D
	.long 0xd72c007c                                           // 00000050F15C: D72C007C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000050F160: 0202F8FF 83DCD12D
	.long 0xd72c007d                                           // 00000050F168: D72C007D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000050F16C: 0202FAFF 83DCD12D
	v_and_b32_e32 v48, 0xffff, v48                             // 00000050F174: 366060FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 00000050F17C: 365E5EFF 0000FFFF
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000050F184: D6220025 03FD0125 00006400
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000050F190: D6220021 03FD0121 00006400
	v_bfe_u32 v29, v26, 6, 16                                  // 00000050F19C: D610001D 02410D1A
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000050F1A4: D622002E 03FD012E 00006400
	v_sad_u8 v124, v124, 0, 0x6400                             // 00000050F1B0: D622007C 03FD017C 00006400
	v_lshl_or_b32 v48, v49, 16, v48                            // 00000050F1BC: D6560030 04C12131
	.long 0xd72c002f                                           // 00000050F1C4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000050F1C8: 02025EFF 83DCD12D
	v_sad_u8 v49, v123, 0, 0x6400                              // 00000050F1D0: D6220031 03FD017B 00006400
	v_sad_u8 v45, v125, 0, 0x6400                              // 00000050F1DC: D622002D 03FD017D 00006400
	v_bfe_u32 v125, v42, 3, 16                                 // 00000050F1E8: D610007D 0241072A
	v_pk_fma_f16 v48, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F1F0: CC0E0030 0BFC0D30 0000C931
	v_lshlrev_b32_e32 v46, 16, v46                             // 00000050F1FC: 305C5C90
	v_and_b32_e32 v123, 0xffff, v124                           // 00000050F200: 36F6F8FF 0000FFFF
	v_sad_u8 v124, v126, 0, 0x6400                             // 00000050F208: D622007C 03FD017E 00006400
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000050F214: D622002F 03FD012F 00006400
	v_dot2acc_f32_f16 v77, v48, v1                             // 00000050F220: 049A0330
	v_and_or_b32 v46, 0xffff, v49, v46                         // 00000050F224: D657002E 04BA62FF 0000FFFF
	v_bfe_u32 v49, v44, 9, 16                                  // 00000050F230: D6100031 0241132C
	v_dot2acc_f32_f16 v83, v48, v5                             // 00000050F238: 04A60B30
	v_dot2acc_f32_f16 v82, v48, v13                            // 00000050F23C: 04A41B30
	v_lshl_or_b32 v45, v45, 16, v123                           // 00000050F240: D656002D 05ED212D
	v_bfe_u32 v123, v44, 6, 16                                 // 00000050F248: D610007B 02410D2C
	v_and_b32_e32 v44, 0xffff, v44                             // 00000050F250: 365858FF 0000FFFF
	.long 0xd72c0031                                           // 00000050F258: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000050F25C: 020262FF 83DCD12D
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F264: CC0E002E 0BFC0D2E 0000C931
	v_lshlrev_b32_e32 v47, 16, v47                             // 00000050F270: 305E5E90
	v_dot2acc_f32_f16 v79, v48, v9                             // 00000050F274: 049E1330
	.long 0xd72c002c                                           // 00000050F278: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000050F27C: 020258FF 83DCD12D
	.long 0xd72c0030                                           // 00000050F284: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000050F288: 0202F6FF 83DCD12D
	v_bfe_u32 v123, v42, 9, 16                                 // 00000050F290: D610007B 0241132A
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F298: CC0E002D 0BFC0D2D 0000C931
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000050F2A4: D6220031 03FD0131 00006400
	v_dot2acc_f32_f16 v77, v46, v2                             // 00000050F2B0: 049A052E
	v_dot2acc_f32_f16 v82, v46, v14                            // 00000050F2B4: 04A41D2E
	v_and_or_b32 v47, 0xffff, v124, v47                        // 00000050F2B8: D657002F 04BEF8FF 0000FFFF
	v_bfe_u32 v124, v42, 6, 16                                 // 00000050F2C4: D610007C 02410D2A
	v_and_b32_e32 v42, 0xffff, v42                             // 00000050F2CC: 365454FF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000050F2D4: D622002C 03FD012C 00006400
	v_dual_dot2acc_f32_f16 v82, v45, v15 :: v_dual_and_b32 v49, 0xffff, v49// 00000050F2E0: CB241F2D 523062FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000050F2EC: D6220030 03FD0130 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050F2F8: BF870233
	v_dual_dot2acc_f32_f16 v77, v45, v3 :: v_dual_lshlrev_b32 v44, 16, v44// 00000050F2FC: CB22072D 4D2C5890
	.long 0xd72c002a                                           // 00000050F304: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000050F308: 020254FF 83DCD12D
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F310: CC0E002F 0BFC0D2F 0000C931
	v_lshl_or_b32 v48, v48, 16, v49                            // 00000050F31C: D6560030 04C52130
	.long 0xd72c0031                                           // 00000050F324: D72C0031
	v_cndmask_b32_e32 v1, 0x83dcd12d, v123, vcc_lo             // 00000050F328: 0202F6FF 83DCD12D
	v_and_or_b32 v43, 0xffff, v43, v44                         // 00000050F330: D657002B 04B256FF 0000FFFF
	.long 0xd72c002c                                           // 00000050F33C: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v125, vcc_lo             // 00000050F340: 0202FAFF 83DCD12D
	.long 0xd72c007b                                           // 00000050F348: D72C007B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v124, vcc_lo             // 00000050F34C: 0202F8FF 83DCD12D
	v_dual_dot2acc_f32_f16 v83, v46, v6 :: v_dual_dot2acc_f32_f16 v82, v47, v16// 00000050F354: CB180D2E 5352212F
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000050F35C: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v77, v47, v4                             // 00000050F368: 049A092F
	v_sad_u8 v49, v49, 0, 0x6400                               // 00000050F36C: D6220031 03FD0131 00006400
	v_dot2acc_f32_f16 v79, v46, v10                            // 00000050F378: 049E152E
	v_pk_fma_f16 v46, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F37C: CC0E002E 0BFC0D30 0000C931
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000050F388: D622002C 03FD012C 00006400
	v_dual_dot2acc_f32_f16 v83, v45, v7 :: v_dual_lshlrev_b32 v42, 16, v42// 00000050F394: CB220F2D 532A5490
	v_sad_u8 v123, v123, 0, 0x6400                             // 00000050F39C: D622007B 03FD017B 00006400
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F3A8: CC0E002B 0BFC0D2B 0000C931
	v_dot2acc_f32_f16 v64, v46, v1                             // 00000050F3B4: 0480032E
	v_and_b32_e32 v49, 0xffff, v49                             // 00000050F3B8: 366262FF 0000FFFF
	v_and_or_b32 v42, 0xffff, v44, v42                         // 00000050F3C0: D657002A 04AA58FF 0000FFFF
	v_dual_dot2acc_f32_f16 v83, v47, v8 :: v_dual_dot2acc_f32_f16 v78, v46, v5// 00000050F3CC: CB18112F 534E0B2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050F3D4: BF870214
	v_dot2acc_f32_f16 v64, v43, v2                             // 00000050F3D8: 0480052B
	v_lshl_or_b32 v48, v123, 16, v49                           // 00000050F3DC: D6560030 04C5217B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050F3E4: BF870234
	v_pk_fma_f16 v41, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F3E8: CC0E0029 0BFC0D2A 0000C931
	v_bfe_u32 v42, v40, 9, 16                                  // 00000050F3F4: D610002A 02411328
	v_dual_dot2acc_f32_f16 v79, v45, v11 :: v_dual_dot2acc_f32_f16 v78, v43, v6// 00000050F3FC: CB18172D 4F4E0D2B
	v_pk_fma_f16 v45, v48, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F404: CC0E002D 0BFC0D30 0000C931
	v_dot2acc_f32_f16 v75, v46, v9                             // 00000050F410: 0496132E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050F414: BF870234
	.long 0xd72c0027                                           // 00000050F418: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000050F41C: 020254FF 83DCD12D
	v_bfe_u32 v42, v40, 6, 16                                  // 00000050F424: D610002A 02410D28
	v_dual_dot2acc_f32_f16 v76, v46, v13 :: v_dual_dot2acc_f32_f16 v79, v47, v12// 00000050F42C: CB181B2E 4C4E192F
	v_dual_dot2acc_f32_f16 v78, v45, v7 :: v_dual_dot2acc_f32_f16 v75, v43, v10// 00000050F434: CB180F2D 4E4A152B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050F43C: BF870233
	.long 0xd72c002a                                           // 00000050F440: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000050F444: 020254FF 83DCD12D
	v_and_b32_e32 v44, 0xffff, v40                             // 00000050F44C: 365850FF 0000FFFF
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000050F454: D6220027 03FD0127 00006400
	v_dot2acc_f32_f16 v78, v41, v8                             // 00000050F460: 049C1129
	v_dot2acc_f32_f16 v76, v43, v14                            // 00000050F464: 04981D2B
	v_bfe_u32 v40, v40, 3, 16                                  // 00000050F468: D6100028 02410728
	v_bfe_u32 v47, v38, 9, 16                                  // 00000050F470: D610002F 02411326
	v_and_b32_e32 v39, 0xffff, v39                             // 00000050F478: 364E4EFF 0000FFFF
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000050F480: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v75, v45, v11                            // 00000050F48C: 0496172D
	.long 0xd72c002c                                           // 00000050F490: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000050F494: 020258FF 83DCD12D
	v_bfe_u32 v48, v38, 6, 16                                  // 00000050F49C: D6100030 02410D26
	.long 0xd72c002f                                           // 00000050F4A4: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000050F4A8: 02025EFF 83DCD12D
	v_lshl_or_b32 v39, v42, 16, v39                            // 00000050F4B0: D6560027 049D212A
	.long 0xd72c0028                                           // 00000050F4B8: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000050F4BC: 020250FF 83DCD12D
	v_dot2acc_f32_f16 v64, v45, v3                             // 00000050F4C4: 0480072D
	.long 0xd72c0030                                           // 00000050F4C8: D72C0030
	v_cndmask_b32_e32 v1, 0x83dcd12d, v48, vcc_lo              // 00000050F4CC: 020260FF 83DCD12D
	v_bfe_u32 v49, v38, 3, 16                                  // 00000050F4D4: D6100031 02410726
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000050F4DC: D622002C 03FD012C 00006400
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F4E8: CC0E0027 0BFC0D27 0000C931
	v_dot2acc_f32_f16 v76, v45, v15                            // 00000050F4F4: 04981F2D
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000050F4F8: D622002F 03FD012F 00006400
	v_sad_u8 v40, v40, 0, 0x6400                               // 00000050F504: D6220028 03FD0128 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000050F510: BF870224
	v_dual_dot2acc_f32_f16 v64, v41, v4 :: v_dual_dot2acc_f32_f16 v73, v39, v5// 00000050F514: CB180929 40480B27
	v_lshlrev_b32_e32 v42, 16, v44                             // 00000050F51C: 30545890
	v_and_b32_e32 v47, 0xffff, v47                             // 00000050F520: 365E5EFF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 00000050F528: D6220030 03FD0130 00006400
	.long 0xd72c002c                                           // 00000050F534: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v49, vcc_lo              // 00000050F538: 020262FF 83DCD12D
	v_dual_dot2acc_f32_f16 v72, v39, v13 :: v_dual_and_b32 v43, 0xffff, v34// 00000050F540: CB241B27 482A44FF 0000FFFF
	v_and_or_b32 v40, 0xffff, v40, v42                         // 00000050F54C: D6570028 04AA50FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050F558: BF870004
	v_lshl_or_b32 v42, v48, 16, v47                            // 00000050F55C: D656002A 04BD2130
	v_dot2acc_f32_f16 v76, v41, v16                            // 00000050F564: 04982129
	v_dot2acc_f32_f16 v75, v41, v12                            // 00000050F568: 04961929
	v_bfe_u32 v41, v34, 9, 16                                  // 00000050F56C: D6100029 02411322
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F574: CC0E0028 0BFC0D28 0000C931
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F580: CC0E002A 0BFC0D2A 0000C931
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000050F58C: D622002C 03FD012C 00006400
	v_bfe_u32 v34, v34, 3, 16                                  // 00000050F598: D6100022 02410722
	.long 0xd72c0024                                           // 00000050F5A0: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000050F5A4: 020252FF 83DCD12D
	v_dot2acc_f32_f16 v73, v40, v6                             // 00000050F5AC: 04920D28
	v_and_b32_e32 v38, 0xffff, v38                             // 00000050F5B0: 364C4CFF 0000FFFF
	.long 0xd72c0029                                           // 00000050F5B8: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000050F5BC: 020256FF 83DCD12D
	.long 0xd72c0022                                           // 00000050F5C4: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000050F5C8: 020244FF 83DCD12D
	v_bfe_u32 v43, v35, 9, 16                                  // 00000050F5D0: D610002B 02411323
	v_dot2acc_f32_f16 v73, v42, v7                             // 00000050F5D8: 04920F2A
	.long 0xd72c0026                                           // 00000050F5DC: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000050F5E0: 02024CFF 83DCD12D
	v_bfe_u32 v45, v35, 3, 16                                  // 00000050F5E8: D610002D 02410723
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000050F5F0: D6220024 03FD0124 00006400
	.long 0xd72c002b                                           // 00000050F5FC: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000050F600: 020256FF 83DCD12D
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000050F608: D6220029 03FD0129 00006400
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000050F614: D6220022 03FD0122 00006400
	.long 0xd72c001d                                           // 00000050F620: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 00000050F624: 02023AFF 83DCD12D
	s_waitcnt vmcnt(0)                                         // 00000050F62C: BF8903F7
	.long 0xd73d0015                                           // 00000050F630: D73D0015
	v_cndmask_b32_e32 v1, v87, v22, vcc_lo                     // 00000050F634: 02022D57
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000050F638: D6220026 03FD0126 00006400
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000050F644: 30525290
	v_bfe_u32 v22, v20, 9, 16                                  // 00000050F648: D6100016 02411314
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000050F650: D622002B 03FD012B 00006400
	v_dot2acc_f32_f16 v72, v40, v14                            // 00000050F65C: 04901D28
	v_lshlrev_b32_e32 v38, 16, v38                             // 00000050F660: 304C4C90
	v_and_or_b32 v34, 0xffff, v34, v41                         // 00000050F664: D6570022 04A644FF 0000FFFF
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000050F670: D622001D 03FD011D 00006400
	.long 0xd72c0016                                           // 00000050F67C: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000050F680: 02022CFF 83DCD12D
	v_cmp_eq_u32_e32 vcc_lo, v122, v53                         // 00000050F688: 7C946B7A
	v_and_or_b32 v38, 0xffff, v44, v38                         // 00000050F68C: D6570026 049A58FF 0000FFFF
	v_bfe_u32 v44, v35, 6, 16                                  // 00000050F698: D610002C 02410D23
	v_and_b32_e32 v35, 0xffff, v35                             // 00000050F6A0: 364646FF 0000FFFF
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F6A8: CC0E0022 0BFC0D22 0000C931
	v_and_b32_e32 v36, 0xffff, v36                             // 00000050F6B4: 364848FF 0000FFFF
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F6BC: CC0E0026 0BFC0D26 0000C931
	v_dot2acc_f32_f16 v74, v39, v1                             // 00000050F6C8: 04940327
	.long 0xd72c002c                                           // 00000050F6CC: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000050F6D0: 020258FF 83DCD12D
	.long 0xd72c0023                                           // 00000050F6D8: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000050F6DC: 020246FF 83DCD12D
	v_lshl_or_b32 v36, v37, 16, v36                            // 00000050F6E4: D6560024 04912125
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050F6EC: BF870244
	v_dual_dot2acc_f32_f16 v73, v38, v8 :: v_dual_dot2acc_f32_f16 v74, v40, v2// 00000050F6F0: CB181126 494A0528
	.long 0xd72c0025                                           // 00000050F6F8: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000050F6FC: 02025AFF 83DCD12D
	v_dual_dot2acc_f32_f16 v70, v39, v9 :: v_dual_and_b32 v39, 0xffff, v43// 00000050F704: CB241327 462656FF 0000FFFF
	v_sad_u8 v41, v44, 0, 0x6400                               // 00000050F710: D6220029 03FD012C 00006400
	v_dot2acc_f32_f16 v74, v42, v3                             // 00000050F71C: 0494072A
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000050F720: D6220023 03FD0123 00006400
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F72C: CC0E0024 0BFC0D24 0000C931
	v_dot2acc_f32_f16 v72, v42, v15                            // 00000050F738: 04901F2A
	v_lshl_or_b32 v39, v41, 16, v39                            // 00000050F73C: D6560027 049D2129
	v_dot2acc_f32_f16 v74, v38, v4                             // 00000050F744: 04940926
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000050F748: D6220025 03FD0125 00006400
	v_lshlrev_b32_e32 v35, 16, v35                             // 00000050F754: 30464690
	v_dot2acc_f32_f16 v69, v36, v1                             // 00000050F758: 048A0324
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F75C: CC0E0027 0BFC0D27 0000C931
	v_dot2acc_f32_f16 v67, v36, v13                            // 00000050F768: 04861B24
	v_bfe_u32 v41, v31, 3, 16                                  // 00000050F76C: D6100029 0241071F
	v_and_or_b32 v35, 0xffff, v37, v35                         // 00000050F774: D6570023 048E4AFF 0000FFFF
	v_dot2acc_f32_f16 v69, v34, v2                             // 00000050F780: 048A0522
	v_dot2acc_f32_f16 v72, v38, v16                            // 00000050F784: 04902126
	v_dot2acc_f32_f16 v67, v34, v14                            // 00000050F788: 04861D22
	v_bfe_u32 v37, v30, 9, 16                                  // 00000050F78C: D6100025 0241131E
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F794: CC0E0023 0BFC0D23 0000C931
	v_dual_dot2acc_f32_f16 v69, v39, v3 :: v_dual_dot2acc_f32_f16 v70, v40, v10// 00000050F7A0: CB180727 45461528
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050F7A8: BF870214
	v_dual_dot2acc_f32_f16 v68, v36, v5 :: v_dual_dot2acc_f32_f16 v67, v39, v15// 00000050F7AC: CB180B24 44421F27
	.long 0xd72c0020                                           // 00000050F7B4: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000050F7B8: 02024AFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_3)                            // 00000050F7C0: BF870003
	v_dual_dot2acc_f32_f16 v69, v35, v4 :: v_dual_dot2acc_f32_f16 v70, v42, v11// 00000050F7C4: CB180923 4546172A
	v_and_b32_e32 v37, 0xffff, v30                             // 00000050F7CC: 364A3CFF 0000FFFF
	v_bfe_u32 v30, v30, 3, 16                                  // 00000050F7D4: D610001E 0241071E
	v_bfe_u32 v40, v31, 6, 16                                  // 00000050F7DC: D6100028 02410D1F
	v_dot2acc_f32_f16 v68, v34, v6                             // 00000050F7E4: 04880D22
	v_dot2acc_f32_f16 v70, v38, v12                            // 00000050F7E8: 048C1926
	v_bfe_u32 v38, v31, 9, 16                                  // 00000050F7EC: D6100026 0241131F
	.long 0xd72c0025                                           // 00000050F7F4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000050F7F8: 02024AFF 83DCD12D
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000050F800: D6220020 03FD0120 00006400
	.long 0xd72c001e                                           // 00000050F80C: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000050F810: 02023CFF 83DCD12D
	.long 0xd72c0028                                           // 00000050F818: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000050F81C: 020250FF 83DCD12D
	.long 0xd72c0026                                           // 00000050F824: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000050F828: 02024CFF 83DCD12D
	v_and_b32_e32 v31, 0xffff, v31                             // 00000050F830: 363E3EFF 0000FFFF
	v_and_b32_e32 v32, 0xffff, v32                             // 00000050F838: 364040FF 0000FFFF
	v_dot2acc_f32_f16 v67, v35, v16                            // 00000050F840: 04862123
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000050F844: D6220025 03FD0125 00006400
	v_dot2acc_f32_f16 v68, v39, v7                             // 00000050F850: 04880F27
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000050F854: D622001E 03FD011E 00006400
	v_lshl_or_b32 v32, v33, 16, v32                            // 00000050F860: D6560020 04812121
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000050F868: D6220026 03FD0126 00006400
	v_lshlrev_b32_e32 v33, 16, v37                             // 00000050F874: 30424A90
	.long 0xd72c001f                                           // 00000050F878: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000050F87C: 02023EFF 83DCD12D
	v_sad_u8 v40, v40, 0, 0x6400                               // 00000050F884: D6220028 03FD0128 00006400
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F890: CC0E0020 0BFC0D20 0000C931
	v_and_b32_e32 v38, 0xffff, v38                             // 00000050F89C: 364C4CFF 0000FFFF
	v_and_or_b32 v30, 0xffff, v30, v33                         // 00000050F8A4: D657001E 04863CFF 0000FFFF
	v_dot2acc_f32_f16 v68, v35, v8                             // 00000050F8B0: 04881123
	.long 0xd72c0025                                           // 00000050F8B4: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000050F8B8: 020252FF 83DCD12D
	v_dot2acc_f32_f16 v65, v32, v1                             // 00000050F8C0: 04820320
	v_dot2acc_f32_f16 v63, v32, v5                             // 00000050F8C4: 047E0B20
	v_lshl_or_b32 v33, v40, 16, v38                            // 00000050F8C8: D6560021 04992128
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F8D0: CC0E001E 0BFC0D1E 0000C931
	v_dot2acc_f32_f16 v66, v36, v9                             // 00000050F8DC: 04841324
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000050F8E0: D622001F 03FD011F 00006400
	v_dot2acc_f32_f16 v62, v32, v13                            // 00000050F8EC: 047C1B20
	v_pk_fma_f16 v33, v33, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F8F0: CC0E0021 0BFC0D21 0000C931
	v_dot2acc_f32_f16 v65, v30, v2                             // 00000050F8FC: 0482051E
	v_dot2acc_f32_f16 v63, v30, v6                             // 00000050F900: 047E0D1E
	v_dot2acc_f32_f16 v66, v34, v10                            // 00000050F904: 04841522
	v_sad_u8 v36, v37, 0, 0x6400                               // 00000050F908: D6220024 03FD0125 00006400
	v_lshlrev_b32_e32 v31, 16, v31                             // 00000050F914: 303E3E90
	v_dot2acc_f32_f16 v65, v33, v3                             // 00000050F918: 04820721
	v_bfe_u32 v34, v26, 9, 16                                  // 00000050F91C: D6100022 0241131A
	v_dot2acc_f32_f16 v66, v39, v11                            // 00000050F924: 04841727
	v_dual_dot2acc_f32_f16 v62, v30, v14 :: v_dual_dot2acc_f32_f16 v63, v33, v7// 00000050F928: CB181D1E 3E3E0F21
	v_and_or_b32 v31, 0xffff, v36, v31                         // 00000050F930: D657001F 047E48FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050F93C: BF870214
	.long 0xd72c001c                                           // 00000050F940: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000050F944: 020244FF 83DCD12D
	v_dual_dot2acc_f32_f16 v66, v35, v12 :: v_dual_and_b32 v35, 0xffff, v26// 00000050F94C: CB241923 422234FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 00000050F958: D610001A 0241071A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050F960: BF870004
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050F964: CC0E001F 0BFC0D1F 0000C931
	v_dot2acc_f32_f16 v62, v33, v15                            // 00000050F970: 047C1F21
	v_bfe_u32 v36, v27, 6, 16                                  // 00000050F974: D6100024 02410D1B
	.long 0xd72c0022                                           // 00000050F97C: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000050F980: 020246FF 83DCD12D
	v_bfe_u32 v35, v27, 9, 16                                  // 00000050F988: D6100023 0241131B
	v_dot2acc_f32_f16 v65, v31, v4                             // 00000050F990: 0482091F
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000050F994: D622001C 03FD011C 00006400
	.long 0xd72c001a                                           // 00000050F9A0: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000050F9A4: 020234FF 83DCD12D
	v_bfe_u32 v37, v27, 3, 16                                  // 00000050F9AC: D6100025 0241071B
	.long 0xd72c0023                                           // 00000050F9B4: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000050F9B8: 020246FF 83DCD12D
	v_dual_dot2acc_f32_f16 v62, v31, v16 :: v_dual_and_b32 v27, 0xffff, v27// 00000050F9C0: CB24211F 3E1A36FF 0000FFFF
	v_dot2acc_f32_f16 v61, v32, v9                             // 00000050F9CC: 047A1320
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000050F9D0: D6220022 03FD0122 00006400
	v_and_b32_e32 v28, 0xffff, v28                             // 00000050F9DC: 363838FF 0000FFFF
	.long 0xd72c0024                                           // 00000050F9E4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000050F9E8: 020248FF 83DCD12D
	.long 0xd72c001b                                           // 00000050F9F0: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 00000050F9F4: 020236FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050F9FC: BF870004
	v_dual_dot2acc_f32_f16 v63, v31, v8 :: v_dual_lshlrev_b32 v34, 16, v34// 00000050FA00: CB22111F 3F224490
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000050FA08: D622001A 03FD011A 00006400
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000050FA14: D6220023 03FD0123 00006400
	v_dot2acc_f32_f16 v61, v30, v10                            // 00000050FA20: 047A151E
	v_lshl_or_b32 v28, v29, 16, v28                            // 00000050FA24: D656001C 0471211D
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000050FA2C: D6220016 03FD0116 00006400
	v_and_or_b32 v26, 0xffff, v26, v34                         // 00000050FA38: D657001A 048A34FF 0000FFFF
	v_sad_u8 v34, v36, 0, 0x6400                               // 00000050FA44: D6220022 03FD0124 00006400
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000050FA50: D622001B 03FD011B 00006400
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FA5C: CC0E001C 0BFC0D1C 0000C931
	v_and_b32_e32 v32, 0xffff, v35                             // 00000050FA68: 364046FF 0000FFFF
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FA70: CC0E001A 0BFC0D1A 0000C931
	v_dot2acc_f32_f16 v61, v33, v11                            // 00000050FA7C: 047A1721
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000050FA80: BF870234
	v_dual_dot2acc_f32_f16 v60, v28, v1 :: v_dual_lshlrev_b32 v27, 16, v27// 00000050FA84: CB22031C 3C1A3690
	v_dot2acc_f32_f16 v59, v28, v5                             // 00000050FA8C: 04760B1C
	v_lshl_or_b32 v30, v34, 16, v32                            // 00000050FA90: D656001E 04812122
	v_dual_dot2acc_f32_f16 v58, v28, v13 :: v_dual_dot2acc_f32_f16 v61, v31, v12// 00000050FA98: CB181B1C 3A3C191F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050FAA0: BF870214
	v_dot2acc_f32_f16 v60, v26, v2                             // 00000050FAA4: 0478051A
	v_dot2acc_f32_f16 v59, v26, v6                             // 00000050FAA8: 04760D1A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000050FAAC: BF870214
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FAB0: CC0E001E 0BFC0D1E 0000C931
	v_dual_dot2acc_f32_f16 v58, v26, v14 :: v_dual_dot2acc_f32_f16 v57, v28, v9// 00000050FABC: CB181D1A 3A38131C
	v_bfe_u32 v28, v20, 6, 16                                  // 00000050FAC4: D610001C 02410D14
	.long 0xd72c001d                                           // 00000050FACC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000050FAD0: 02024AFF 83DCD12D
	v_bfe_u32 v31, v21, 6, 16                                  // 00000050FAD8: D610001F 02410D15
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050FAE0: BF870004
	v_dot2acc_f32_f16 v58, v30, v15                            // 00000050FAE4: 04741F1E
	v_dot2acc_f32_f16 v57, v26, v10                            // 00000050FAE8: 0472151A
	.long 0xd72c001c                                           // 00000050FAEC: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000050FAF0: 020238FF 83DCD12D
	v_and_b32_e32 v22, 0xffff, v22                             // 00000050FAF8: 362C2CFF 0000FFFF
	v_bfe_u32 v32, v21, 3, 16                                  // 00000050FB00: D6100020 02410715
	.long 0xd72c001f                                           // 00000050FB08: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000050FB0C: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v57, v30, v11                            // 00000050FB14: 0472171E
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000050FB18: D622001D 03FD011D 00006400
	v_mov_b32_e32 v39, v111                                    // 00000050FB24: 7E4E036F
	.long 0xd72c001a                                           // 00000050FB28: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v32, vcc_lo              // 00000050FB2C: 020240FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000050FB34: D622001C 03FD011C 00006400
	v_mov_b32_e32 v41, v94                                     // 00000050FB40: 7E52035E
	v_and_or_b32 v27, 0xffff, v29, v27                         // 00000050FB44: D657001B 046E3AFF 0000FFFF
	v_bfe_u32 v29, v21, 9, 16                                  // 00000050FB50: D610001D 02411315
	v_and_b32_e32 v21, 0xffff, v21                             // 00000050FB58: 362A2AFF 0000FFFF
	v_lshl_or_b32 v22, v28, 16, v22                            // 00000050FB60: D6560016 0459211C
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000050FB68: D622001F 03FD011F 00006400
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FB74: CC0E001B 0BFC0D1B 0000C931
	.long 0xd72c001d                                           // 00000050FB80: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 00000050FB84: 02023AFF 83DCD12D
	.long 0xd72c0015                                           // 00000050FB8C: D72C0015
	v_cndmask_b32_e32 v1, 0x83dcd12d, v21, vcc_lo              // 00000050FB90: 02022AFF 83DCD12D
	v_pk_fma_f16 v22, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FB98: CC0E0016 0BFC0D16 0000C931
	v_and_b32_e32 v23, 0xffff, v20                             // 00000050FBA4: 362E28FF 0000FFFF
	v_bfe_u32 v20, v20, 3, 16                                  // 00000050FBAC: D6100014 02410714
	v_dot2acc_f32_f16 v58, v27, v16                            // 00000050FBB4: 0474211B
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000050FBB8: D622001A 03FD011A 00006400
	v_dot2acc_f32_f16 v56, v22, v1                             // 00000050FBC4: 04700316
	.long 0xd72c0017                                           // 00000050FBC8: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000050FBCC: 02022EFF 83DCD12D
	.long 0xd72c0014                                           // 00000050FBD4: D72C0014
	v_cndmask_b32_e32 v1, 0x83dcd12d, v20, vcc_lo              // 00000050FBD8: 020228FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000050FBE0: D622001D 03FD011D 00006400
	v_dot2acc_f32_f16 v54, v22, v13                            // 00000050FBEC: 046C1B16
	v_sad_u8 v21, v21, 0, 0x6400                               // 00000050FBF0: D6220015 03FD0115 00006400
	v_dot2acc_f32_f16 v59, v30, v7                             // 00000050FBFC: 04760F1E
	v_dual_dot2acc_f32_f16 v60, v30, v3 :: v_dual_dot2acc_f32_f16 v57, v27, v12// 00000050FC00: CB18071E 3C38191B
	v_mov_b32_e32 v46, v110                                    // 00000050FC08: 7E5C036E
	v_sad_u8 v23, v23, 0, 0x6400                               // 00000050FC0C: D6220017 03FD0117 00006400
	v_sad_u8 v20, v20, 0, 0x6400                               // 00000050FC18: D6220014 03FD0114 00006400
	v_dot2acc_f32_f16 v59, v27, v8                             // 00000050FC24: 0476111B
	v_dual_dot2acc_f32_f16 v60, v27, v4 :: v_dual_mov_b32 v43, v114// 00000050FC28: CB10091B 3C2A0172
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000050FC30: BF8701B4
	v_dual_mov_b32 v36, v115 :: v_dual_lshlrev_b32 v23, 16, v23// 00000050FC34: CA220173 24162E90
	v_dual_mov_b32 v45, v95 :: v_dual_mov_b32 v34, v102        // 00000050FC3C: CA10015F 2D220166
	v_dual_mov_b32 v49, v116 :: v_dual_mov_b32 v38, v117       // 00000050FC44: CA100174 31260175
	v_and_or_b32 v20, 0xffff, v20, v23                         // 00000050FC4C: D6570014 045E28FF 0000FFFF
	v_mov_b32_e32 v40, v104                                    // 00000050FC58: 7E500368
	v_dual_mov_b32 v47, v96 :: v_dual_mov_b32 v28, v109        // 00000050FC5C: CA100160 2F1C016D
	v_mov_b32_e32 v42, v119                                    // 00000050FC64: 7E540377
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000050FC68: BF870244
	v_pk_fma_f16 v20, v20, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FC6C: CC0E0014 0BFC0D14 0000C931
	v_and_b32_e32 v29, 0xffff, v29                             // 00000050FC78: 363A3AFF 0000FFFF
	v_dual_mov_b32 v48, v120 :: v_dual_lshlrev_b32 v21, 16, v21// 00000050FC80: CA220178 30142A90
	v_mov_b32_e32 v44, v107                                    // 00000050FC88: 7E58036B
	v_dot2acc_f32_f16 v56, v20, v2                             // 00000050FC8C: 04700514
	s_delay_alu instid0(VALU_DEP_4)                            // 00000050FC90: BF870004
	v_lshl_or_b32 v23, v31, 16, v29                            // 00000050FC94: D6560017 0475211F
	v_dot2acc_f32_f16 v54, v20, v14                            // 00000050FC9C: 046C1D14
	v_and_or_b32 v1, 0xffff, v26, v21                          // 00000050FCA0: D6570001 045634FF 0000FFFF
	v_mov_b32_e32 v2, v97                                      // 00000050FCAC: 7E040361
	v_mov_b32_e32 v35, v93                                     // 00000050FCB0: 7E46035D
	v_pk_fma_f16 v23, v23, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000050FCB4: CC0E0017 0BFC0D17 0000C931
	v_dot2acc_f32_f16 v55, v22, v5                             // 00000050FCC0: 046E0B16
	v_pk_fma_f16 v1, v1, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000050FCC4: CC0E0001 0BFC0D01 0000C931
	v_mov_b32_e32 v37, v108                                    // 00000050FCD0: 7E4A036C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000050FCD4: BF8701C4
	v_dual_mov_b32 v31, v92 :: v_dual_dot2acc_f32_f16 v56, v23, v3// 00000050FCD8: CA18015C 1F380717
	v_dual_dot2acc_f32_f16 v17, v22, v9 :: v_dual_dot2acc_f32_f16 v54, v23, v15// 00000050FCE0: CB181316 11361F17
	v_dot2acc_f32_f16 v55, v20, v6                             // 00000050FCE8: 046E0D14
	v_dual_mov_b32 v3, v121 :: v_dual_mov_b32 v30, v100        // 00000050FCEC: CA100179 031E0164
	v_dual_dot2acc_f32_f16 v56, v1, v4 :: v_dual_dot2acc_f32_f16 v17, v20, v10// 00000050FCF4: CB180901 38101514
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050FCFC: BF8701A3
	v_dual_dot2acc_f32_f16 v54, v1, v16 :: v_dual_dot2acc_f32_f16 v55, v23, v7// 00000050FD00: CB182101 36360F17
	v_dual_mov_b32 v4, v118 :: v_dual_mov_b32 v33, v105        // 00000050FD08: CA100176 04200169
	v_dual_dot2acc_f32_f16 v17, v23, v11 :: v_dual_mov_b32 v32, v112// 00000050FD10: CB101717 11200170
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000050FD18: BF8701A3
	v_dot2acc_f32_f16 v55, v1, v8                              // 00000050FD1C: 046E1101
	v_mov_b32_e32 v27, v91                                     // 00000050FD20: 7E36035B
	v_dual_mov_b32 v26, v99 :: v_dual_dot2acc_f32_f16 v17, v1, v12// 00000050FD24: CA180163 1A101901
	v_mov_b32_e32 v1, v113                                     // 00000050FD2C: 7E020371
	v_mov_b32_e32 v29, v103                                    // 00000050FD30: 7E3A0367
	v_mov_b32_e32 v21, v90                                     // 00000050FD34: 7E2A035A
	v_dual_mov_b32 v20, v98 :: v_dual_mov_b32 v23, v101        // 00000050FD38: CA100162 14160165
	v_mov_b32_e32 v22, v106                                    // 00000050FD40: 7E2C036A
	v_mov_b32_e32 v7, v122                                     // 00000050FD44: 7E0E037A
	s_or_b32 s0, vcc_lo, s0                                    // 00000050FD48: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050FD4C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000050FD50: 917E007E
	s_cbranch_execz 94                                         // 00000050FD54: BFA5005E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1dd0>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050FD58: BF8700A1
	v_add_nc_u32_e32 v122, 1, v7                               // 00000050FD5C: 4AF40E81
	s_mov_b32 s7, exec_lo                                      // 00000050FD60: BE87007E
	.long 0xd4c1007e                                           // 00000050FD64: D4C1007E
	v_cndmask_b32_e32 v1, v122, v53, vcc_lo                    // 00000050FD68: 02026B7A
	s_cbranch_execz 64550                                      // 00000050FD6C: BFA5FC26 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd08>
	v_mad_i64_i32 v[5:6], null, 0x300, v122, s[4:5]            // 00000050FD70: D6FF7C05 0012F4FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000050FD7C: BF870091
	.long 0xd7006a08                                           // 00000050FD80: D7006A08
	v_cndmask_b32_e32 v1, v5, v18, vcc_lo                      // 00000050FD84: 02022505
	v_add_co_ci_u32_e64 v9, null, v6, v19, vcc_lo              // 00000050FD88: D5207C09 01AA2706
	.long 0xd7006a0a                                           // 00000050FD90: D7006A0A
	v_cndmask_b32_e32 v1, v5, v88, vcc_lo                      // 00000050FD94: 0202B105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000050FD98: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 00000050FD9C: D5207C0B 01AA0C80
	.long 0xd7006a0c                                           // 00000050FDA4: D7006A0C
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 00000050FDA8: 02023105
	v_add_co_ci_u32_e64 v13, null, v6, v25, vcc_lo             // 00000050FDAC: D5207C0D 01AA3306
	.long 0xd7006a05                                           // 00000050FDB4: D7006A05
	v_cndmask_b32_e32 v1, v5, v89, vcc_lo                      // 00000050FDB8: 0202B305
	s_delay_alu instid0(VALU_DEP_1)                            // 00000050FDBC: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 00000050FDC0: D5207C06 01AA0C80
	s_clause 0x1f                                              // 00000050FDC8: BF85001F
	global_load_b32 v97, v[8:9], off                           // 00000050FDCC: DC520000 617C0008
	global_load_b32 v96, v[8:9], off offset:96                 // 00000050FDD4: DC520060 607C0008
	global_load_b32 v95, v[8:9], off offset:192                // 00000050FDDC: DC5200C0 5F7C0008
	global_load_b32 v94, v[8:9], off offset:288                // 00000050FDE4: DC520120 5E7C0008
	global_load_b32 v93, v[8:9], off offset:384                // 00000050FDEC: DC520180 5D7C0008
	global_load_b32 v92, v[8:9], off offset:480                // 00000050FDF4: DC5201E0 5C7C0008
	global_load_b32 v91, v[8:9], off offset:576                // 00000050FDFC: DC520240 5B7C0008
	global_load_b32 v90, v[8:9], off offset:672                // 00000050FE04: DC5202A0 5A7C0008
	global_load_b32 v113, v[10:11], off                        // 00000050FE0C: DC520000 717C000A
	global_load_b32 v110, v[10:11], off offset:96              // 00000050FE14: DC520060 6E7C000A
	global_load_b32 v107, v[10:11], off offset:192             // 00000050FE1C: DC5200C0 6B7C000A
	global_load_b32 v104, v[10:11], off offset:288             // 00000050FE24: DC520120 687C000A
	global_load_b32 v102, v[10:11], off offset:384             // 00000050FE2C: DC520180 667C000A
	global_load_b32 v100, v[10:11], off offset:480             // 00000050FE34: DC5201E0 647C000A
	global_load_b32 v99, v[10:11], off offset:576              // 00000050FE3C: DC520240 637C000A
	global_load_b32 v98, v[10:11], off offset:672              // 00000050FE44: DC5202A0 627C000A
	global_load_b32 v118, v[12:13], off                        // 00000050FE4C: DC520000 767C000C
	global_load_b32 v116, v[12:13], off offset:96              // 00000050FE54: DC520060 747C000C
	global_load_b32 v114, v[12:13], off offset:192             // 00000050FE5C: DC5200C0 727C000C
	global_load_b32 v111, v[12:13], off offset:288             // 00000050FE64: DC520120 6F7C000C
	global_load_b32 v108, v[12:13], off offset:384             // 00000050FE6C: DC520180 6C7C000C
	global_load_b32 v105, v[12:13], off offset:480             // 00000050FE74: DC5201E0 697C000C
	global_load_b32 v103, v[12:13], off offset:576             // 00000050FE7C: DC520240 677C000C
	global_load_b32 v101, v[12:13], off offset:672             // 00000050FE84: DC5202A0 657C000C
	global_load_b32 v121, v[5:6], off                          // 00000050FE8C: DC520000 797C0005
	global_load_b32 v120, v[5:6], off offset:96                // 00000050FE94: DC520060 787C0005
	global_load_b32 v119, v[5:6], off offset:192               // 00000050FE9C: DC5200C0 777C0005
	global_load_b32 v117, v[5:6], off offset:288               // 00000050FEA4: DC520120 757C0005
	global_load_b32 v115, v[5:6], off offset:384               // 00000050FEAC: DC520180 737C0005
	global_load_b32 v112, v[5:6], off offset:480               // 00000050FEB4: DC5201E0 707C0005
	global_load_b32 v109, v[5:6], off offset:576               // 00000050FEBC: DC520240 6D7C0005
	global_load_b32 v106, v[5:6], off offset:672               // 00000050FEC4: DC5202A0 6A7C0005
	s_branch 64462                                             // 00000050FECC: BFA0FBCE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd08>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000050FED0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050FED4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000050FED8: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 00000050FEDC: BF895FF7
	v_dual_mov_b32 v1, v84 :: v_dual_mov_b32 v2, v81           // 00000050FEE0: CA100154 01020151
	s_waitcnt vmcnt(7)                                         // 00000050FEE8: BF891FF7
	v_dual_mov_b32 v4, v80 :: v_dual_mov_b32 v3, v71           // 00000050FEEC: CA100150 04020147
	v_dual_mov_b32 v5, v77 :: v_dual_mov_b32 v8, v82           // 00000050FEF4: CA10014D 05080152
	v_dual_mov_b32 v7, v83 :: v_dual_mov_b32 v6, v64           // 00000050FEFC: CA100153 07060140
	v_dual_mov_b32 v9, v79 :: v_dual_mov_b32 v10, v78          // 00000050FF04: CA10014F 090A014E
	v_dual_mov_b32 v11, v76 :: v_dual_mov_b32 v12, v75         // 00000050FF0C: CA10014C 0B0C014B
	v_dual_mov_b32 v13, v74 :: v_dual_mov_b32 v14, v73         // 00000050FF14: CA10014A 0D0E0149
	v_dual_mov_b32 v15, v72 :: v_dual_mov_b32 v16, v70         // 00000050FF1C: CA100148 0F100146
	v_dual_mov_b32 v18, v69 :: v_dual_mov_b32 v19, v68         // 00000050FF24: CA100145 12120144
	v_dual_mov_b32 v20, v67 :: v_dual_mov_b32 v21, v66         // 00000050FF2C: CA100143 14140142
	s_waitcnt vmcnt(0)                                         // 00000050FF34: BF8903F7
	v_dual_mov_b32 v22, v65 :: v_dual_mov_b32 v23, v63         // 00000050FF38: CA100141 1616013F
	v_dual_mov_b32 v24, v62 :: v_dual_mov_b32 v25, v61         // 00000050FF40: CA10013E 1818013D
	v_dual_mov_b32 v26, v60 :: v_dual_mov_b32 v27, v59         // 00000050FF48: CA10013C 1A1A013B
	v_dual_mov_b32 v28, v58 :: v_dual_mov_b32 v29, v57         // 00000050FF50: CA10013A 1C1C0139
	v_dual_mov_b32 v30, v56 :: v_dual_mov_b32 v31, v55         // 00000050FF58: CA100138 1E1E0137
	v_dual_mov_b32 v32, v54 :: v_dual_mov_b32 v33, v17         // 00000050FF60: CA100136 20200111
	s_mov_b32 s0, 0x76543210                                   // 00000050FF68: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000050FF70: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000050FF74: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000050FF80: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000050FF8C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000050FF98: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000050FFA4: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000050FFB0: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000050FFBC: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000050FFC8: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000050FFD4: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000050FFE0: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000050FFEC: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000050FFF8: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 000000510004: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 000000510010: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000051001C: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 000000510028: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 000000510034: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 000000510040: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 00000051004C: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 000000510058: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 000000510064: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 000000510070: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 00000051007C: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 000000510088: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 000000510094: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 0000005100A0: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 0000005100AC: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 0000005100B8: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 0000005100C4: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 0000005100D0: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 0000005100DC: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 0000005100E8: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 0000005100F4: D44C0000
	v_cndmask_b32_e32 v1, 16, v52, vcc_lo                      // 0000005100F8: 02026890
	s_barrier                                                  // 0000005100FC: BFBD0000
	buffer_gl0_inv                                             // 000000510100: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000510108: BE812000
	s_cbranch_execz 69                                         // 00000051010C: BFA50045 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2124>
	v_dual_add_f32 v17, v17, v33 :: v_dual_add_f32 v32, v54, v32// 000000510110: C9084311 11204136
	v_lshl_or_b32 v33, v50, 11, v51                            // 000000510118: D6560021 04CD1732
	v_dual_add_f32 v5, v77, v5 :: v_dual_add_f32 v4, v80, v4   // 000000510120: C9080B4D 05040950
	v_dual_add_f32 v1, v84, v1 :: v_dual_add_f32 v2, v81, v2   // 000000510128: C9080354 01020551
	v_dual_add_f32 v8, v82, v8 :: v_dual_add_f32 v7, v83, v7   // 000000510130: C9081152 08060F53
	s_delay_alu instid0(VALU_DEP_4)                            // 000000510138: BF870004
	v_dual_add_f32 v3, v71, v3 :: v_dual_add_nc_u32 v34, 0x400, v33// 00000051013C: C9200747 032242FF 00000400
	v_dual_add_f32 v10, v78, v10 :: v_dual_add_f32 v9, v79, v9 // 000000510148: C908154E 0A08134F
	v_dual_add_f32 v14, v73, v14 :: v_dual_add_f32 v13, v74, v13// 000000510150: C9081D49 0E0C1B4A
	v_dual_add_f32 v6, v64, v6 :: v_dual_add_f32 v31, v55, v31 // 000000510158: C9080D40 061E3F37
	v_dual_add_f32 v30, v56, v30 :: v_dual_add_f32 v29, v57, v29// 000000510160: C9083D38 1E1C3B39
	v_dual_add_f32 v28, v58, v28 :: v_dual_add_f32 v27, v59, v27// 000000510168: C908393A 1C1A373B
	v_dual_add_f32 v26, v60, v26 :: v_dual_add_f32 v25, v61, v25// 000000510170: C908353C 1A18333D
	v_dual_add_f32 v24, v62, v24 :: v_dual_add_f32 v23, v63, v23// 000000510178: C908313E 18162F3F
	v_dual_add_f32 v22, v65, v22 :: v_dual_add_f32 v21, v66, v21// 000000510180: C9082D41 16142B42
	v_dual_add_f32 v20, v67, v20 :: v_dual_add_f32 v19, v68, v19// 000000510188: C9082943 14122744
	v_add_f32_e32 v18, v69, v18                                // 000000510190: 06242545
	v_dual_add_f32 v16, v70, v16 :: v_dual_add_f32 v15, v72, v15// 000000510194: C9082146 100E1F48
	v_dual_add_f32 v12, v75, v12 :: v_dual_add_f32 v11, v76, v11// 00000051019C: C908194B 0C0A174C
	ds_store_2addr_b32 v33, v1, v5 offset1:16                  // 0000005101A4: D8381000 00050121
	ds_store_2addr_b32 v33, v2, v7 offset0:128 offset1:144     // 0000005101AC: D8389080 00070221
	ds_store_2addr_b32 v34, v4, v8 offset1:16                  // 0000005101B4: D8381000 00080422
	ds_store_2addr_b32 v34, v3, v9 offset0:128 offset1:144     // 0000005101BC: D8389080 00090322
	ds_store_2addr_b32 v33, v6, v13 offset0:32 offset1:48      // 0000005101C4: D8383020 000D0621
	ds_store_2addr_b32 v33, v10, v14 offset0:160 offset1:176   // 0000005101CC: D838B0A0 000E0A21
	ds_store_2addr_b32 v34, v11, v15 offset0:32 offset1:48     // 0000005101D4: D8383020 000F0B22
	ds_store_2addr_b32 v34, v12, v16 offset0:160 offset1:176   // 0000005101DC: D838B0A0 00100C22
	ds_store_2addr_b32 v33, v18, v22 offset0:64 offset1:80     // 0000005101E4: D8385040 00161221
	ds_store_2addr_b32 v33, v19, v23 offset0:192 offset1:208   // 0000005101EC: D838D0C0 00171321
	ds_store_2addr_b32 v34, v20, v24 offset0:64 offset1:80     // 0000005101F4: D8385040 00181422
	ds_store_2addr_b32 v34, v21, v25 offset0:192 offset1:208   // 0000005101FC: D838D0C0 00191522
	ds_store_2addr_b32 v33, v26, v30 offset0:96 offset1:112    // 000000510204: D8387060 001E1A21
	ds_store_2addr_b32 v33, v27, v31 offset0:224 offset1:240   // 00000051020C: D838F0E0 001F1B21
	ds_store_2addr_b32 v34, v28, v32 offset0:96 offset1:112    // 000000510214: D8387060 00201C22
	ds_store_2addr_b32 v34, v29, v17 offset0:224 offset1:240   // 00000051021C: D838F0E0 00111D22
	s_or_b32 exec_lo, exec_lo, s1                              // 000000510224: 8C7E017E
	.long 0xd44c0001                                           // 000000510228: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000051022C: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 000000510234: BF89FC07
	s_barrier                                                  // 000000510238: BFBD0000
	buffer_gl0_inv                                             // 00000051023C: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 000000510244: BE842001
	s_cbranch_execz 48                                         // 000000510248: BFA50030 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x220c>
	v_mov_b32_e32 v1, v0                                       // 00000051024C: 7E020300
	s_mov_b32 s5, 0                                            // 000000510250: BE850080
	s_nop 0                                                    // 000000510254: BF800000
	s_nop 0                                                    // 000000510258: BF800000
	s_nop 0                                                    // 00000051025C: BF800000
	s_nop 0                                                    // 000000510260: BF800000
	s_nop 0                                                    // 000000510264: BF800000
	s_nop 0                                                    // 000000510268: BF800000
	s_nop 0                                                    // 00000051026C: BF800000
	s_nop 0                                                    // 000000510270: BF800000
	s_nop 0                                                    // 000000510274: BF800000
	s_nop 0                                                    // 000000510278: BF800000
	s_nop 0                                                    // 00000051027C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000510280: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000510284: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000510288: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000510290: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000510298: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 0000005102A0: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 0000005102A8: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 0000005102AC: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 0000005102B0: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000005102B4: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 0000005102B8: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 0000005102BC: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 0000005102C4: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 0000005102C8: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 0000005102CC: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 0000005102D0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005102D4: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 0000005102D8: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 0000005102DC: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 0000005102E0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005102E4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 0000005102E8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 0000005102EC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 0000005102F4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 0000005102FC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000510304: 917E057E
	s_cbranch_execnz 65501                                     // 000000510308: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000051030C: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 000000510310: BF048221
	s_mov_b32 s4, -1                                           // 000000510314: BE8400C1
	s_cbranch_scc1 212                                         // 000000510318: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x256c>
	s_waitcnt lgkmcnt(0)                                       // 00000051031C: BF89FC07
	s_barrier                                                  // 000000510320: BFBD0000
	buffer_gl0_inv                                             // 000000510324: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000051032C: BE862001
	s_cbranch_execz 71                                         // 000000510330: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2350>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000510334: 32020087
	s_ashr_i32 s11, s10, 31                                    // 000000510338: 860B9F0A
	s_ashr_i32 s27, s26, 31                                    // 00000051033C: 861B9F1A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000510340: 8484820A
	s_mov_b32 s7, 0                                            // 000000510344: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 000000510348: 38020204
	s_mul_i32 s4, s5, s26                                      // 00000051034C: 96041A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000510350: BF8700A1
	.long 0xd72c0003                                           // 000000510354: D72C0003
	v_cndmask_b32_e32 v0, v1, v27, vcc_lo                      // 000000510358: 02003701
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000051035C: D6FE7C01 02003501
	v_add3_u32 v2, v2, v3, s4                                  // 000000510364: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 00000051036C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000510370: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 000000510378: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000051037C: BF870122
	.long 0xd73c0001                                           // 000000510380: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000510384: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000510388: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000051038C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000510390: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000510394: BF870093
	.long 0xd7006a01                                           // 000000510398: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000051039C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000005103A0: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[26:27], 3                             // 0000005103A8: 8484831A
	.long 0xd7006a01                                           // 0000005103AC: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 0000005103B0: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005103B4: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000005103B8: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 0000005103C0: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 0000005103C8: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000005103CC: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005103D0: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 0000005103D4: D5207C02 01AA0411
	s_nop 0                                                    // 0000005103DC: BF800000
	s_nop 0                                                    // 0000005103E0: BF800000
	s_nop 0                                                    // 0000005103E4: BF800000
	s_nop 0                                                    // 0000005103E8: BF800000
	s_nop 0                                                    // 0000005103EC: BF800000
	s_nop 0                                                    // 0000005103F0: BF800000
	s_nop 0                                                    // 0000005103F4: BF800000
	s_nop 0                                                    // 0000005103F8: BF800000
	s_nop 0                                                    // 0000005103FC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 000000510400: D8D84000 05000003
	.long 0xd7000804                                           // 000000510408: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000051040C: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 000000510414: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000510418: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 000000510420: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000510424: BF8700C9
	s_or_b32 s7, s8, s7                                        // 000000510428: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 00000051042C: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 000000510430: DC6A0000 007C0501
	.long 0xd7006a01                                           // 000000510438: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000051043C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000510440: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 000000510448: 917E077E
	s_cbranch_execnz 65516                                     // 00000051044C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2300>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000510450: 8C7E067E
	.long 0xd44a0004                                           // 000000510454: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000510458: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000051045C: BC7C0000
	buffer_gl1_inv                                             // 000000510460: E0B00000 00000000
	buffer_gl0_inv                                             // 000000510468: E0AC0000 00000000
	s_barrier                                                  // 000000510470: BFBD0000
	buffer_gl0_inv                                             // 000000510474: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000051047C: BE852004
	s_cbranch_execz 29                                         // 000000510480: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23f8>
	s_mov_b32 s7, exec_lo                                      // 000000510484: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000510488: BE86007E
	.long 0xd71f0001                                           // 00000051048C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000510490: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000510494: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000510498: 7D940280
	s_cbranch_execz 9                                          // 00000051049C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23c4>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000005104A0: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000005104A4: BF8704B9
	s_add_u32 s8, s18, s8                                      // 0000005104A8: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000005104AC: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 0000005104B0: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 0000005104B4: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 0000005104BC: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 0000005104C4: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 0000005104C8: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 0000005104CC: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005104D0: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 0000005104D4: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 0000005104DC: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000005104E0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 0000005104E4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000005104E8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 0000005104F0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 0000005104F8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 0000005104FC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000510500: BF89FC07
	s_barrier                                                  // 000000510504: BFBD0000
	buffer_gl0_inv                                             // 000000510508: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 000000510510: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000510518: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000051051C: 7C940280
	s_cbranch_vccnz 424                                        // 000000510520: BFA401A8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ac4>
	buffer_gl1_inv                                             // 000000510524: E0B00000 00000000
	buffer_gl0_inv                                             // 00000051052C: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000510534: BE852001
	s_cbranch_execz 65                                         // 000000510538: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2540>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000051053C: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000510540: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000510544: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000051054C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000510550: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s26, 0                     // 000000510554: D6FF7C01 02003501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000051055C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000510560: 30060682
	s_ashr_i32 s27, s26, 31                                    // 000000510564: 861B9F1A
	s_mov_b32 s10, 0                                           // 000000510568: BE8A0080
	s_lshl_b64 s[8:9], s[26:27], 4                             // 00000051056C: 8488841A
	.long 0xd73c0001                                           // 000000510570: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000510574: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000510578: BF870091
	.long 0xd7006a01                                           // 00000051057C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000510580: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000510584: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[26:27], 3                             // 00000051058C: 8486831A
	.long 0xd7006a01                                           // 000000510590: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000510594: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000510598: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000051059C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 0000005105A4: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000005105A8: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005105AC: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 0000005105B0: D5207C02 01AA0411
	s_nop 0                                                    // 0000005105B8: BF800000
	s_nop 0                                                    // 0000005105BC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005105C0: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 0000005105C4: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 0000005105CC: 7E0C0280
	s_mov_b32 s1, s33                                          // 0000005105D0: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 0000005105D4: DC524000 077C0003
	.long 0xd7006a03                                           // 0000005105DC: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 0000005105E0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005105E4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000005105E8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 0000005105F0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 0000005105F4: BF068001
	s_waitcnt vmcnt(0)                                         // 0000005105F8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 0000005105FC: 060C0F06
	s_cbranch_scc0 65524                                       // 000000510600: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x24d4>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000510604: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000051060C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000510614: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000510618: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000051061C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 000000510620: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 000000510628: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000051062C: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 000000510630: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000510638: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000051063C: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x24c0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000510640: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000510644: BE812004
	s_cbranch_execz 6                                          // 000000510648: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2564>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000051064C: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000510650: 7E020280
	s_add_u32 s4, s18, s4                                      // 000000510654: 80040412
	s_addc_u32 s5, s19, s5                                     // 000000510658: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000051065C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000510664: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000510668: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000051066C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000510670: 8B6A047E
	s_cbranch_vccz 339                                         // 000000510674: BFA30153 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ac4>
	v_cmp_gt_i32_e32 vcc_lo, s24, v50                          // 000000510678: 7C886418
	.long 0xd44c0001                                           // 00000051067C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000510680: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000510688: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000051068C: BC7C0000
	s_barrier                                                  // 000000510690: BFBD0000
	buffer_gl0_inv                                             // 000000510694: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000051069C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005106A0: BF870009
	s_and_saveexec_b32 s3, s1                                  // 0000005106A4: BE832001
	s_cbranch_execz 326                                        // 0000005106A8: BFA50146 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ac4>
	v_and_b32_e32 v1, 15, v0                                   // 0000005106AC: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005106B0: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 0000005106B4: 30040282
	v_lshl_or_b32 v2, v50, 9, v2                               // 0000005106B8: D6560002 04091332
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005106C0: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 0000005106C4: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 0000005106CC: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 0000005106D4: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 0000005106DC: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 0000005106E4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 0000005106EC: 36140081
	s_waitcnt lgkmcnt(3)                                       // 0000005106F0: BF89FC37
	v_dual_add_f32 v12, v2, v3 :: v_dual_and_b32 v11, 2, v0    // 0000005106F4: C9240702 0C0A0082
	s_waitcnt lgkmcnt(2)                                       // 0000005106FC: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000510700: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000510708: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000051070C: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000510714: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_sub_f32 v7, v8, v9     // 000000510718: C94A0F06 06061308
	v_dual_add_f32 v8, v8, v9 :: v_dual_and_b32 v9, 4, v0      // 000000510720: C9241308 08080084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000510728: BF8701A3
	v_add_f32_e32 v13, v2, v4                                  // 00000051072C: 061A0902
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000510730: 7C941480
	v_add_f32_e32 v16, v5, v8                                  // 000000510734: 06201105
	v_dual_sub_f32 v5, v5, v8 :: v_dual_add_f32 v14, v12, v3   // 000000510738: C9481105 050E070C
	v_add_f32_e32 v15, v6, v7                                  // 000000510740: 061E0F06
	v_dual_sub_f32 v3, v12, v3 :: v_dual_sub_f32 v2, v2, v4    // 000000510744: C94A070C 03020902
	v_sub_f32_e32 v4, v6, v7                                   // 00000051074C: 08080F06
	.long 0xd44a0001                                           // 000000510750: D44A0001
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000510754: 02021280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000510758: BF870214
	v_add_f32_e32 v6, v13, v15                                 // 00000051075C: 060C1F0D
	v_dual_sub_f32 v8, v13, v15 :: v_dual_add_f32 v13, v3, v5  // 000000510760: C9481F0D 080C0B03
	v_add_f32_e32 v7, v14, v16                                 // 000000510768: 060E210E
	v_dual_sub_f32 v3, v3, v5 :: v_dual_add_f32 v12, v2, v4    // 00000051076C: C9480B03 030C0902
	v_sub_f32_e32 v2, v2, v4                                   // 000000510774: 08040902
	v_mov_b32_dpp v5, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510778: 7E0A02FA FF016106
	s_delay_alu instid0(VALU_DEP_4)                            // 000000510780: BF870004
	v_mov_b32_dpp v4, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510784: 7E0802FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000051078C: D5010007 21AA0F07
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000510794: D5010006 21AA0D06
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000051079C: 7E2402FA FF016103
	v_cndmask_b32_e64 v21, -v3, v3, vcc_lo                     // 0000005107A4: D5010015 21AA0703
	v_mov_b32_dpp v19, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005107AC: 7E2602FA FF016102
	v_add_f32_e32 v3, v7, v4                                   // 0000005107B4: 06060907
	v_mov_b32_dpp v15, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005107B8: 7E1E02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 0000005107C0: D5010008 21AA1108
	v_cndmask_b32_e64 v20, -v2, v2, vcc_lo                     // 0000005107C8: D5010014 21AA0502
	v_add_f32_e32 v2, v6, v5                                   // 0000005107D0: 06040B06
	v_mov_b32_dpp v6, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005107D4: 7E0C02FA FF016203
	v_sub_f32_e32 v10, v14, v16                                // 0000005107DC: 0814210E
	v_mov_b32_dpp v16, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005107E0: 7E2002FA FF01610D
	v_mov_b32_dpp v17, v12 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000005107E8: 7E2202FA FF01610C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 0000005107F0: D501000C 21AA190C
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 0000005107F8: D501000D 21AA1B0D
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000510800: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000510808: D501000A 21AA150A
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000510810: 7C941680
	v_add_f32_e32 v4, v8, v15                                  // 000000510814: 06081F08
	v_dual_add_f32 v7, v12, v17 :: v_dual_add_f32 v8, v13, v16 // 000000510818: C908230C 0708210D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000510820: BF870224
	v_add_f32_e32 v5, v10, v14                                 // 000000510824: 060A1D0A
	v_add_f32_e32 v13, v20, v19                                // 000000510828: 061A2714
	v_mov_b32_dpp v12, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000051082C: 7E1802FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000510834: D5010004 21AA0904
	v_mov_b32_dpp v10, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000051083C: 7E1402FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000510844: D5010002 21AA0502
	v_mov_b32_dpp v9, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000051084C: 7E1202FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000510854: D5010008 21AA1108
	v_add_f32_e32 v4, v4, v12                                  // 00000051085C: 06081904
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510860: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000510868: D5010005 21AA0B05
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000510870: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000510878: D501000D 21AA1B0D
	v_mov_b32_dpp v12, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510880: 7E1802FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000510888: D5010004 20060904
	v_dual_add_f32 v8, v8, v9 :: v_dual_add_f32 v11, v5, v11   // 000000510890: C9081308 080A1705
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000510898: D5010003 21AA0703
	v_mov_b32_dpp v14, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005108A0: 7E1C02FA FF016207
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000005108A8: BF8701C4
	v_add_f32_e32 v4, v4, v12                                  // 0000005108AC: 06081904
	v_add_f32_e32 v12, v21, v18                                // 0000005108B0: 06182515
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 0000005108B4: D5010007 21AA0F07
	v_add_f32_e32 v3, v3, v6                                   // 0000005108BC: 06060D03
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000005108C0: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, vcc_lo                   // 0000005108C8: D501000C 21AA190C
	v_add_f32_e32 v2, v2, v10                                  // 0000005108D0: 06041502
	v_add_f32_e32 v14, v7, v14                                 // 0000005108D4: 061C1D07
	v_mov_b32_dpp v6, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005108D8: 7E0C02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000005108E0: D5010003 20060703
	v_add_f32_e32 v9, v12, v9                                  // 0000005108E8: 0612130C
	v_cndmask_b32_e64 v10, -v2, v2, s1                         // 0000005108EC: D501000A 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005108F4: 7E0402FA FF016402
	v_mov_b32_dpp v12, v14 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000005108FC: 7E1802FA FF01640E
	v_add_f32_e32 v3, v3, v6                                   // 000000510904: 06060D03
	v_mov_b32_dpp v16, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510908: 7E2002FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000510910: D5010009 20061309
	v_add_f32_e32 v5, v10, v2                                  // 000000510918: 060A050A
	v_mov_b32_dpp v10, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000051091C: 7E1402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000510924: D501000B 2006170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000051092C: 7E0402FA FF016803
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000510934: BF870194
	v_mov_b32_dpp v6, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510938: 7E0C02FA FF016805
	v_add_f32_e32 v7, v11, v10                                 // 000000510940: 060E150B
	v_add_f32_e32 v11, v13, v15                                // 000000510944: 06161F0D
	v_mov_b32_dpp v10, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510948: 7E1402FA FF016408
	v_cndmask_b32_e64 v13, -v14, v14, s1                       // 000000510950: D501000D 20061D0E
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000510958: D501000E 20061108
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510960: 7E1002FA FF016807
	v_mov_b32_dpp v18, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000510968: 7E2402FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 000000510970: D501000B 2006170B
	v_add_f32_e32 v17, v13, v12                                // 000000510978: 0622190D
	v_dual_add_f32 v15, v14, v10 :: v_dual_add_f32 v14, v9, v16// 00000051097C: C908150E 0F0E2109
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510984: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000051098C: BF870214
	v_add_f32_e32 v16, v11, v18                                // 000000510990: 0620250B
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000510994: 7E1A02FA FF016811
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000051099C: BF870224
	v_mov_b32_dpp v11, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005109A0: 7E1602FA FF01680F
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005109A8: 7E1402FA FF01680E
	v_mov_b32_dpp v12, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000005109B0: 7E1802FA FF016810
	s_and_b32 exec_lo, exec_lo, s0                             // 0000005109B8: 8B7E007E
	s_cbranch_execz 129                                        // 0000005109BC: BFA50081 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb1ELb1ELb0ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2ac4>
	v_lshl_or_b32 v18, s2, 7, v1                               // 0000005109C0: D6560012 04050E02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005109C8: BF870091
	v_ashrrev_i32_e32 v19, 31, v18                             // 0000005109CC: 3426249F
	.long 0xd73c0014                                           // 0000005109D0: D73C0014
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 0000005109D4: 02022481
	.long 0xd73c0012                                           // 0000005109D8: D73C0012
	v_cndmask_b32_e32 v1, 2, v18, vcc_lo                       // 0000005109DC: 02022482
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005109E0: BF870092
	.long 0xd7006a14                                           // 0000005109E4: D7006A14
	v_cndmask_b32_e32 v1, s14, v20, vcc_lo                     // 0000005109E8: 0202280E
	v_add_co_ci_u32_e64 v21, null, s15, v21, vcc_lo            // 0000005109EC: D5207C15 01AA2A0F
	s_clause 0x7                                               // 0000005109F4: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 0000005109F8: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 000000510A00: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:96           // 000000510A08: DC820060 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:64           // 000000510A10: DC820040 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:160          // 000000510A18: DC8200A0 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:128          // 000000510A20: DC820080 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:224          // 000000510A28: DC8200E0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:192          // 000000510A30: DC8200C0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 000000510A38: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v50, 0                    // 000000510A3C: D6FF7C00 0202641A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000510A44: BF870112
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 000000510A48: 7C942A80
	.long 0xd73c0000                                           // 000000510A4C: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 000000510A50: 02020082
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000510A54: D5010005 21AA0B05
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000510A5C: D5010003 21AA0703
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000510A64: D501000F 21AA1F0F
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000510A6C: D5010004 21AA0904
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000510A74: D5010007 21AA0F07
	v_add_f32_e32 v5, v5, v6                                   // 000000510A7C: 060A0D05
	v_cndmask_b32_e64 v6, -v17, v17, vcc_lo                    // 000000510A80: D5010006 21AA2311
	v_cndmask_b32_e64 v16, -v16, v16, vcc_lo                   // 000000510A88: D5010010 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 000000510A90: D501000E 21AA1D0E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000510A98: BF870214
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000510A9C: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v13 :: v_dual_add_f32 v6, v15, v11  // 000000510AA8: C9081B06 0506170F
	.long 0xd7006a00                                           // 000000510AB0: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 000000510AB4: 02020014
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v7, v7, v8     // 000000510AB8: C9081304 04061107
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 000000510AC0: D5207C01 01AA0215
	v_dual_add_f32 v8, v16, v12 :: v_dual_add_f32 v9, v14, v10 // 000000510AC8: C9081910 0808150E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000510AD0: BF870003
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000510AD4: 100808FF 3DB504F3
	v_mul_f32_e32 v2, 0x3db504f3, v2                           // 000000510ADC: 100404FF 3DB504F3
	v_dual_mul_f32 v6, 0x3db504f3, v6 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000510AE4: C8C60CFF 06040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000510AF0: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 000000510AF4: 02022500
	v_dual_mul_f32 v7, 0x3db504f3, v7 :: v_dual_mul_f32 v8, 0x3db504f3, v8// 000000510AF8: C8C60EFF 070810FF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 000000510B04: D5207C01 01AA2701
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 000000510B0C: 101212FF 3DB504F3
	s_waitcnt vmcnt(7)                                         // 000000510B14: BF891FF7
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 000000510B18: CC200003 8A020716
	s_waitcnt vmcnt(6)                                         // 000000510B20: BF891BF7
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000510B24: CC200002 8A020517
	s_waitcnt vmcnt(5)                                         // 000000510B2C: BF8917F7
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 000000510B30: CC200005 8A020B18
	s_waitcnt vmcnt(4)                                         // 000000510B38: BF8913F7
	v_fma_mix_f32 v6, v25, v6, neg(0) op_sel_hi:[1,0,0]        // 000000510B3C: CC200006 8A020D19
	s_waitcnt vmcnt(3)                                         // 000000510B44: BF890FF7
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 000000510B48: CC200004 8A02091A
	s_waitcnt vmcnt(2)                                         // 000000510B50: BF890BF7
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 000000510B54: CC200007 8A020F1B
	s_waitcnt vmcnt(1)                                         // 000000510B5C: BF8907F7
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 000000510B60: CC200008 8A02111C
	s_waitcnt vmcnt(0)                                         // 000000510B68: BF8903F7
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 000000510B6C: CC200009 8A021314
	s_clause 0x7                                               // 000000510B74: BF850007
	global_store_b32 v[0:1], v2, off                           // 000000510B78: DC6A0000 007C0200
	global_store_b32 v[0:1], v3, off offset:64                 // 000000510B80: DC6A0040 007C0300
	global_store_b32 v[0:1], v6, off offset:128                // 000000510B88: DC6A0080 007C0600
	global_store_b32 v[0:1], v5, off offset:192                // 000000510B90: DC6A00C0 007C0500
	global_store_b32 v[0:1], v7, off offset:256                // 000000510B98: DC6A0100 007C0700
	global_store_b32 v[0:1], v4, off offset:320                // 000000510BA0: DC6A0140 007C0400
	global_store_b32 v[0:1], v9, off offset:384                // 000000510BA8: DC6A0180 007C0900
	global_store_b32 v[0:1], v8, off offset:448                // 000000510BB0: DC6A01C0 007C0800
	s_nop 0                                                    // 000000510BB8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000510BBC: BFB60003
	s_endpgm                                                   // 000000510BC0: BFB00000
	s_nop 0                                                    // 000000510BC4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000510BC8: BFB60003
	s_endpgm                                                   // 000000510BCC: BFB00000
		...

