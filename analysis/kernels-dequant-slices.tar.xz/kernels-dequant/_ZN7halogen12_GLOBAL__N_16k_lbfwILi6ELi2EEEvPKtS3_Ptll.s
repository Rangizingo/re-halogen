00000000002dba00 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002DBA00: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002DBA08: 32020085
	s_mov_b32 s3, 0                                            // 0000002DBA0C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DBA10: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002DBA14: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002DBA18: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002DBA1C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002DBA20: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002DBA24: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002DBA28: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DBA2C: BF870001
	.long 0xd4d4007e                                           // 0000002DBA30: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002DBA34: 02020208
	s_cbranch_execz 474                                        // 0000002DBA38: BFA501DA <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll+0x7a4>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002DBA3C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002DBA44: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002DBA48: BF89FC07
	.long 0xd451000a                                           // 0000002DBA4C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002DBA50: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002DBA54: 8B6A0A7E
	s_cbranch_vccnz 241                                        // 0000002DBA58: BFA400F1 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll+0x420>
	.long 0xd72c0006                                           // 0000002DBA5C: D72C0006
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002DBA60: 02020207
	.long 0xd72c0007                                           // 0000002DBA64: D72C0007
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002DBA68: 02020406
	v_mad_u64_u32 v[4:5], null, s6, v1, 0                      // 0000002DBA6C: D6FE7C04 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002DBA74: 848A8106
	s_mul_i32 s12, s7, 10                                      // 0000002DBA78: 960C8A07
	s_mul_hi_u32 s13, s6, 10                                   // 0000002DBA7C: 968D8A06
	s_mul_i32 s14, s6, 10                                      // 0000002DBA80: 960E8A06
	s_add_u32 s10, s2, s10                                     // 0000002DBA84: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002DBA88: 820B0B03
	s_add_i32 s13, s13, s12                                    // 0000002DBA8C: 810D0C0D
	v_add3_u32 v5, v5, v7, v6                                  // 0000002DBA90: D6550005 041A0F05
	s_add_u32 s12, s2, s14                                     // 0000002DBA98: 800C0E02
	s_addc_u32 s13, s3, s13                                    // 0000002DBA9C: 820D0D03
	s_lshl_b64 s[14:15], s[6:7], 3                             // 0000002DBAA0: 848E8306
	s_mul_i32 s16, s6, 6                                       // 0000002DBAA4: 96108606
	.long 0xd73c0004                                           // 0000002DBAA8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002DBAAC: 02020881
	s_add_u32 s14, s2, s14                                     // 0000002DBAB0: 800E0E02
	s_addc_u32 s15, s3, s15                                    // 0000002DBAB4: 820F0F03
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000002DBAB8: CA220080 06020084
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v10, 0             // 0000002DBAC0: CA100080 0B0A0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DBAC8: BF870093
	.long 0xd7006a07                                           // 0000002DBACC: D7006A07
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002DBAD0: 02020800
	v_add_co_ci_u32_e64 v8, null, s1, v5, vcc_lo               // 0000002DBAD4: D5207C08 01AA0A01
	s_mul_i32 s0, s7, 6                                        // 0000002DBADC: 96008607
	s_mul_hi_u32 s1, s6, 6                                     // 0000002DBAE0: 96818606
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v4, 0               // 0000002DBAE4: CA100080 09040080
	s_add_i32 s1, s1, s0                                       // 0000002DBAEC: 81010001
	s_add_u32 s16, s2, s16                                     // 0000002DBAF0: 80101002
	s_addc_u32 s17, s3, s1                                     // 0000002DBAF4: 82110103
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002DBAF8: 84808206
	v_mov_b32_e32 v5, 0                                        // 0000002DBAFC: 7E0A0280
	s_add_u32 s18, s2, s0                                      // 0000002DBB00: 80120002
	s_addc_u32 s19, s3, s1                                     // 0000002DBB04: 82130103
	s_mov_b64 s[0:1], 0                                        // 0000002DBB08: BE800180
	.long 0xd700142c                                           // 0000002DBB0C: D700142C
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002DBB10: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DBB14: BF8700A1
	v_add_co_ci_u32_e64 v45, null, s3, 0, s20                  // 0000002DBB18: D5207C2D 00510003
	.long 0xd7001430                                           // 0000002DBB20: D7001430
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002DBB24: 0202060A
	v_add_co_ci_u32_e64 v49, null, s11, 0, s20                 // 0000002DBB28: D5207C31 0051000B
	.long 0xd7001434                                           // 0000002DBB30: D7001434
	v_cndmask_b32_e32 v1, s18, v3, vcc_lo                      // 0000002DBB34: 02020612
	.long 0xd7006a28                                           // 0000002DBB38: D7006A28
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 0000002DBB3C: 02020707
	v_add_co_ci_u32_e64 v53, null, s19, 0, s20                 // 0000002DBB40: D5207C35 00510013
	.long 0xd7001438                                           // 0000002DBB48: D7001438
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 0000002DBB4C: 02020610
	v_add_co_ci_u32_e64 v41, null, 0, v8, vcc_lo               // 0000002DBB50: D5207C29 01AA1080
	v_add_co_ci_u32_e64 v57, null, s17, 0, s20                 // 0000002DBB58: D5207C39 00510011
	.long 0xd700143c                                           // 0000002DBB60: D700143C
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000002DBB64: 0202060E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DBB68: BF8700A1
	v_add_co_ci_u32_e64 v61, null, s15, 0, s20                 // 0000002DBB6C: D5207C3D 0051000F
	.long 0xd7001440                                           // 0000002DBB74: D7001440
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000002DBB78: 0202060C
	v_add_co_ci_u32_e64 v65, null, s13, 0, s20                 // 0000002DBB7C: D5207C41 0051000D
	global_load_b128 v[12:15], v[40:41], off                   // 0000002DBB84: DC5E0000 0C7C0028
	global_load_b128 v[16:19], v[44:45], off                   // 0000002DBB8C: DC5E0000 107C002C
	global_load_b128 v[20:23], v[48:49], off                   // 0000002DBB94: DC5E0000 147C0030
	global_load_b128 v[24:27], v[52:53], off                   // 0000002DBB9C: DC5E0000 187C0034
	global_load_b128 v[28:31], v[56:57], off                   // 0000002DBBA4: DC5E0000 1C7C0038
	global_load_b128 v[32:35], v[60:61], off                   // 0000002DBBAC: DC5E0000 207C003C
	global_load_b128 v[36:39], v[64:65], off                   // 0000002DBBB4: DC5E0000 247C0040
	global_load_b128 v[40:43], v[40:41], off offset:512        // 0000002DBBBC: DC5E0200 287C0028
	global_load_b128 v[44:47], v[44:45], off offset:512        // 0000002DBBC4: DC5E0200 2C7C002C
	global_load_b128 v[48:51], v[48:49], off offset:512        // 0000002DBBCC: DC5E0200 307C0030
	global_load_b128 v[52:55], v[52:53], off offset:512        // 0000002DBBD4: DC5E0200 347C0034
	global_load_b128 v[56:59], v[56:57], off offset:512        // 0000002DBBDC: DC5E0200 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:512        // 0000002DBBE4: DC5E0200 3C7C003C
	global_load_b128 v[64:67], v[64:65], off offset:512        // 0000002DBBEC: DC5E0200 407C0040
	s_add_u32 s0, s0, 0x200                                    // 0000002DBBF4: 8000FF00 00000200
	s_addc_u32 s1, s1, 0                                       // 0000002DBBFC: 82018001
	s_add_u32 s10, s10, 0x400                                  // 0000002DBC00: 800AFF0A 00000400
	s_addc_u32 s11, s11, 0                                     // 0000002DBC08: 820B800B
	s_add_u32 s12, s12, 0x400                                  // 0000002DBC0C: 800CFF0C 00000400
	s_addc_u32 s13, s13, 0                                     // 0000002DBC14: 820D800D
	s_add_u32 s2, s2, 0x400                                    // 0000002DBC18: 8002FF02 00000400
	.long 0xd4560014                                           // 0000002DBC20: D4560014
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002DBC24: 02000C00
	s_addc_u32 s3, s3, 0                                       // 0000002DBC28: 82038003
	.long 0xd7006a07                                           // 0000002DBC2C: D7006A07
	v_cndmask_b32_e32 v1, 0x400, v7, vcc_lo                    // 0000002DBC30: 02020EFF 00000400
	s_add_u32 s14, s14, 0x400                                  // 0000002DBC38: 800EFF0E 00000400
	s_addc_u32 s15, s15, 0                                     // 0000002DBC40: 820F800F
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 0000002DBC44: D5207C08 01AA1080
	s_add_u32 s16, s16, 0x400                                  // 0000002DBC4C: 8010FF10 00000400
	s_addc_u32 s17, s17, 0                                     // 0000002DBC54: 82118011
	s_add_u32 s18, s18, 0x400                                  // 0000002DBC58: 8012FF12 00000400
	s_addc_u32 s19, s19, 0                                     // 0000002DBC60: 82138013
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000002DBC64: 8B6A147E
	s_waitcnt vmcnt(12)                                        // 0000002DBC68: BF8933F7
	v_dot2_f32_bf16 v6, v16, v12, v6                           // 0000002DBC6C: CC1A4006 1C1A1910
	s_waitcnt vmcnt(11)                                        // 0000002DBC74: BF892FF7
	v_dot2_f32_bf16 v11, v20, v12, v11                         // 0000002DBC78: CC1A400B 1C2E1914
	s_waitcnt vmcnt(10)                                        // 0000002DBC80: BF892BF7
	v_dot2_f32_bf16 v9, v24, v12, v9                           // 0000002DBC84: CC1A4009 1C261918
	s_waitcnt vmcnt(9)                                         // 0000002DBC8C: BF8927F7
	v_dot2_f32_bf16 v10, v28, v12, v10                         // 0000002DBC90: CC1A400A 1C2A191C
	s_waitcnt vmcnt(8)                                         // 0000002DBC98: BF8923F7
	v_dot2_f32_bf16 v5, v32, v12, v5                           // 0000002DBC9C: CC1A4005 1C161920
	s_waitcnt vmcnt(7)                                         // 0000002DBCA4: BF891FF7
	v_dot2_f32_bf16 v4, v36, v12, v4                           // 0000002DBCA8: CC1A4004 1C121924
	v_dot2_f32_bf16 v6, v17, v13, v6                           // 0000002DBCB0: CC1A4006 1C1A1B11
	v_dot2_f32_bf16 v11, v21, v13, v11                         // 0000002DBCB8: CC1A400B 1C2E1B15
	v_dot2_f32_bf16 v9, v25, v13, v9                           // 0000002DBCC0: CC1A4009 1C261B19
	v_dot2_f32_bf16 v10, v29, v13, v10                         // 0000002DBCC8: CC1A400A 1C2A1B1D
	v_dot2_f32_bf16 v5, v33, v13, v5                           // 0000002DBCD0: CC1A4005 1C161B21
	v_dot2_f32_bf16 v4, v37, v13, v4                           // 0000002DBCD8: CC1A4004 1C121B25
	v_dot2_f32_bf16 v6, v18, v14, v6                           // 0000002DBCE0: CC1A4006 1C1A1D12
	v_dot2_f32_bf16 v11, v22, v14, v11                         // 0000002DBCE8: CC1A400B 1C2E1D16
	v_dot2_f32_bf16 v9, v26, v14, v9                           // 0000002DBCF0: CC1A4009 1C261D1A
	v_dot2_f32_bf16 v10, v30, v14, v10                         // 0000002DBCF8: CC1A400A 1C2A1D1E
	v_dot2_f32_bf16 v5, v34, v14, v5                           // 0000002DBD00: CC1A4005 1C161D22
	v_dot2_f32_bf16 v4, v38, v14, v4                           // 0000002DBD08: CC1A4004 1C121D26
	v_dot2_f32_bf16 v6, v19, v15, v6                           // 0000002DBD10: CC1A4006 1C1A1F13
	v_dot2_f32_bf16 v11, v23, v15, v11                         // 0000002DBD18: CC1A400B 1C2E1F17
	v_dot2_f32_bf16 v9, v27, v15, v9                           // 0000002DBD20: CC1A4009 1C261F1B
	v_dot2_f32_bf16 v10, v31, v15, v10                         // 0000002DBD28: CC1A400A 1C2A1F1F
	v_dot2_f32_bf16 v5, v35, v15, v5                           // 0000002DBD30: CC1A4005 1C161F23
	v_dot2_f32_bf16 v4, v39, v15, v4                           // 0000002DBD38: CC1A4004 1C121F27
	s_waitcnt vmcnt(5)                                         // 0000002DBD40: BF8917F7
	v_dot2_f32_bf16 v6, v44, v40, v6                           // 0000002DBD44: CC1A4006 1C1A512C
	s_waitcnt vmcnt(4)                                         // 0000002DBD4C: BF8913F7
	v_dot2_f32_bf16 v11, v48, v40, v11                         // 0000002DBD50: CC1A400B 1C2E5130
	s_waitcnt vmcnt(3)                                         // 0000002DBD58: BF890FF7
	v_dot2_f32_bf16 v9, v52, v40, v9                           // 0000002DBD5C: CC1A4009 1C265134
	s_waitcnt vmcnt(2)                                         // 0000002DBD64: BF890BF7
	v_dot2_f32_bf16 v10, v56, v40, v10                         // 0000002DBD68: CC1A400A 1C2A5138
	s_waitcnt vmcnt(1)                                         // 0000002DBD70: BF8907F7
	v_dot2_f32_bf16 v5, v60, v40, v5                           // 0000002DBD74: CC1A4005 1C16513C
	s_waitcnt vmcnt(0)                                         // 0000002DBD7C: BF8903F7
	v_dot2_f32_bf16 v4, v64, v40, v4                           // 0000002DBD80: CC1A4004 1C125140
	v_dot2_f32_bf16 v6, v45, v41, v6                           // 0000002DBD88: CC1A4006 1C1A532D
	v_dot2_f32_bf16 v11, v49, v41, v11                         // 0000002DBD90: CC1A400B 1C2E5331
	v_dot2_f32_bf16 v9, v53, v41, v9                           // 0000002DBD98: CC1A4009 1C265335
	v_dot2_f32_bf16 v10, v57, v41, v10                         // 0000002DBDA0: CC1A400A 1C2A5339
	v_dot2_f32_bf16 v5, v61, v41, v5                           // 0000002DBDA8: CC1A4005 1C16533D
	v_dot2_f32_bf16 v4, v65, v41, v4                           // 0000002DBDB0: CC1A4004 1C125341
	v_dot2_f32_bf16 v6, v46, v42, v6                           // 0000002DBDB8: CC1A4006 1C1A552E
	v_dot2_f32_bf16 v11, v50, v42, v11                         // 0000002DBDC0: CC1A400B 1C2E5532
	v_dot2_f32_bf16 v9, v54, v42, v9                           // 0000002DBDC8: CC1A4009 1C265536
	v_dot2_f32_bf16 v10, v58, v42, v10                         // 0000002DBDD0: CC1A400A 1C2A553A
	v_dot2_f32_bf16 v5, v62, v42, v5                           // 0000002DBDD8: CC1A4005 1C16553E
	v_dot2_f32_bf16 v4, v66, v42, v4                           // 0000002DBDE0: CC1A4004 1C125542
	v_dot2_f32_bf16 v6, v47, v43, v6                           // 0000002DBDE8: CC1A4006 1C1A572F
	v_dot2_f32_bf16 v11, v51, v43, v11                         // 0000002DBDF0: CC1A400B 1C2E5733
	v_dot2_f32_bf16 v9, v55, v43, v9                           // 0000002DBDF8: CC1A4009 1C265737
	v_dot2_f32_bf16 v10, v59, v43, v10                         // 0000002DBE00: CC1A400A 1C2A573B
	v_dot2_f32_bf16 v5, v63, v43, v5                           // 0000002DBE08: CC1A4005 1C16573F
	v_dot2_f32_bf16 v4, v67, v43, v4                           // 0000002DBE10: CC1A4004 1C125743
	s_cbranch_vccz 65340                                       // 0000002DBE18: BFA3FF3C <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll+0x10c>
	s_branch 6                                                 // 0000002DBE1C: BFA00006 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll+0x438>
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000002DBE20: CA100080 04040080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000002DBE28: CA100080 0A080080
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v6, 0              // 0000002DBE30: CA100080 0B060080
	.long 0xd71f0003                                           // 0000002DBE38: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DBE3C: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DBE40: BF870121
	v_xor_b32_e32 v7, 16, v3                                   // 0000002DBE44: 3A0E0690
	v_xor_b32_e32 v16, 8, v3                                   // 0000002DBE48: 3A200688
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 0000002DBE4C: 7C980EA0
	v_cndmask_b32_e32 v7, v3, v7, vcc_lo                       // 0000002DBE50: 020E0F03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DBE54: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DBE58: 7C9820A0
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DBE5C: 02202103
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DBE60: 30202082
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002DBE64: BF870004
	v_lshlrev_b32_e32 v7, 2, v7                                // 0000002DBE68: 300E0E82
	ds_bpermute_b32 v8, v7, v11                                // 0000002DBE6C: DACC0000 08000B07
	s_waitcnt lgkmcnt(0)                                       // 0000002DBE74: BF89FC07
	v_add_f32_e32 v8, v11, v8                                  // 0000002DBE78: 0610110B
	ds_bpermute_b32 v14, v7, v9                                // 0000002DBE7C: DACC0000 0E000907
	ds_bpermute_b32 v12, v7, v6                                // 0000002DBE84: DACC0000 0C000607
	ds_bpermute_b32 v13, v7, v10                               // 0000002DBE8C: DACC0000 0D000A07
	ds_bpermute_b32 v15, v7, v4                                // 0000002DBE94: DACC0000 0F000407
	ds_bpermute_b32 v7, v7, v5                                 // 0000002DBE9C: DACC0000 07000507
	s_waitcnt lgkmcnt(3)                                       // 0000002DBEA4: BF89FC37
	v_dual_add_f32 v9, v9, v14 :: v_dual_add_f32 v6, v6, v12   // 0000002DBEA8: C9081D09 09061906
	s_waitcnt lgkmcnt(0)                                       // 0000002DBEB0: BF89FC07
	v_add_f32_e32 v5, v5, v7                                   // 0000002DBEB4: 060A0F05
	ds_bpermute_b32 v7, v16, v8                                // 0000002DBEB8: DACC0000 07000810
	v_add_f32_e32 v10, v10, v13                                // 0000002DBEC0: 06141B0A
	ds_bpermute_b32 v13, v16, v9                               // 0000002DBEC4: DACC0000 0D000910
	v_add_f32_e32 v4, v4, v15                                  // 0000002DBECC: 06081F04
	ds_bpermute_b32 v15, v16, v5                               // 0000002DBED0: DACC0000 0F000510
	ds_bpermute_b32 v11, v16, v6                               // 0000002DBED8: DACC0000 0B000610
	s_waitcnt lgkmcnt(3)                                       // 0000002DBEE0: BF89FC37
	v_add_f32_e32 v7, v8, v7                                   // 0000002DBEE4: 060E0F08
	ds_bpermute_b32 v12, v16, v10                              // 0000002DBEE8: DACC0000 0C000A10
	s_waitcnt lgkmcnt(3)                                       // 0000002DBEF0: BF89FC37
	v_add_f32_e32 v9, v9, v13                                  // 0000002DBEF4: 06121B09
	ds_bpermute_b32 v14, v16, v4                               // 0000002DBEF8: DACC0000 0E000410
	v_xor_b32_e32 v16, 4, v3                                   // 0000002DBF00: 3A200684
	s_waitcnt lgkmcnt(3)                                       // 0000002DBF04: BF89FC37
	v_add_f32_e32 v5, v5, v15                                  // 0000002DBF08: 060A1F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DBF0C: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DBF10: 7C9820A0
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DBF14: 02202103
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DBF18: 30202082
	s_waitcnt lgkmcnt(1)                                       // 0000002DBF1C: BF89FC17
	v_add_f32_e32 v8, v10, v12                                 // 0000002DBF20: 0610190A
	ds_bpermute_b32 v10, v16, v7                               // 0000002DBF24: DACC0000 0A000710
	s_waitcnt lgkmcnt(0)                                       // 0000002DBF2C: BF89FC07
	v_add_f32_e32 v7, v7, v10                                  // 0000002DBF30: 060E1507
	ds_bpermute_b32 v13, v16, v9                               // 0000002DBF34: DACC0000 0D000910
	ds_bpermute_b32 v15, v16, v5                               // 0000002DBF3C: DACC0000 0F000510
	s_waitcnt lgkmcnt(1)                                       // 0000002DBF44: BF89FC17
	v_dual_add_f32 v6, v6, v11 :: v_dual_add_f32 v9, v9, v13   // 0000002DBF48: C9081706 06081B09
	ds_bpermute_b32 v11, v16, v6                               // 0000002DBF50: DACC0000 0B000610
	s_waitcnt lgkmcnt(1)                                       // 0000002DBF58: BF89FC17
	v_add_f32_e32 v5, v5, v15                                  // 0000002DBF5C: 060A1F05
	ds_bpermute_b32 v12, v16, v8                               // 0000002DBF60: DACC0000 0C000810
	s_waitcnt lgkmcnt(0)                                       // 0000002DBF68: BF89FC07
	v_add_f32_e32 v8, v8, v12                                  // 0000002DBF6C: 06101908
	v_add_f32_e32 v6, v6, v11                                  // 0000002DBF70: 060C1706
	v_xor_b32_e32 v11, 1, v3                                   // 0000002DBF74: 3A160681
	v_add_f32_e32 v4, v4, v14                                  // 0000002DBF78: 06081D04
	ds_bpermute_b32 v14, v16, v4                               // 0000002DBF7C: DACC0000 0E000410
	v_xor_b32_e32 v16, 2, v3                                   // 0000002DBF84: 3A200682
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DBF88: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000002DBF8C: 7C9820A0
	v_cndmask_b32_e32 v16, v3, v16, vcc_lo                     // 0000002DBF90: 02202103
	v_cmp_gt_u32_e32 vcc_lo, 32, v11                           // 0000002DBF94: 7C9816A0
	v_cndmask_b32_e32 v3, v3, v11, vcc_lo                      // 0000002DBF98: 02061703
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002DBF9C: 7C940080
	s_waitcnt lgkmcnt(0)                                       // 0000002DBFA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002DBFA4: BF870002
	v_dual_add_f32 v4, v4, v14 :: v_dual_lshlrev_b32 v17, 2, v3// 0000002DBFA8: C9221D04 04100682
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000002DBFB0: 30202082
	ds_bpermute_b32 v10, v16, v7                               // 0000002DBFB4: DACC0000 0A000710
	s_waitcnt lgkmcnt(0)                                       // 0000002DBFBC: BF89FC07
	v_add_f32_e32 v11, v7, v10                                 // 0000002DBFC0: 06161507
	ds_bpermute_b32 v13, v16, v8                               // 0000002DBFC4: DACC0000 0D000810
	ds_bpermute_b32 v14, v16, v9                               // 0000002DBFCC: DACC0000 0E000910
	ds_bpermute_b32 v15, v16, v4                               // 0000002DBFD4: DACC0000 0F000410
	s_waitcnt lgkmcnt(2)                                       // 0000002DBFDC: BF89FC27
	v_add_f32_e32 v7, v8, v13                                  // 0000002DBFE0: 060E1B08
	ds_bpermute_b32 v12, v16, v6                               // 0000002DBFE4: DACC0000 0C000610
	ds_bpermute_b32 v16, v16, v5                               // 0000002DBFEC: DACC0000 10000510
	s_waitcnt lgkmcnt(2)                                       // 0000002DBFF4: BF89FC27
	v_dual_add_f32 v8, v9, v14 :: v_dual_add_f32 v3, v4, v15   // 0000002DBFF8: C9081D09 08021F04
	ds_bpermute_b32 v13, v17, v11                              // 0000002DC000: DACC0000 0D000B11
	ds_bpermute_b32 v10, v17, v7                               // 0000002DC008: DACC0000 0A000711
	ds_bpermute_b32 v9, v17, v8                                // 0000002DC010: DACC0000 09000811
	s_waitcnt lgkmcnt(4)                                       // 0000002DC018: BF89FC47
	v_add_f32_e32 v12, v6, v12                                 // 0000002DC01C: 06181906
	s_waitcnt lgkmcnt(3)                                       // 0000002DC020: BF89FC37
	v_add_f32_e32 v4, v5, v16                                  // 0000002DC024: 06082105
	ds_bpermute_b32 v6, v17, v3                                // 0000002DC028: DACC0000 06000311
	ds_bpermute_b32 v14, v17, v12                              // 0000002DC030: DACC0000 0E000C11
	ds_bpermute_b32 v5, v17, v4                                // 0000002DC038: DACC0000 05000411
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002DC040: 8B7E6A7E
	s_cbranch_execz 87                                         // 0000002DC044: BFA50057 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi6ELi2EEEvPKtS3_Ptll+0x7a4>
	s_waitcnt lgkmcnt(1)                                       // 0000002DC048: BF89FC17
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v13, v11, v13// 0000002DC04C: C9081D0C 0C0C1B0B
	.long 0x7f1c3880                                           // 0000002DC054: 7F1C3880
	.long 0xd73c0000                                           // 0000002DC058: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002DC05C: 02020281
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002DC060: 84808108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000002DC064: BF8700D3
	.long 0x7e16398c                                           // 0000002DC068: 7E16398C
	.long 0x7e1c398d                                           // 0000002DC06C: 7E1C398D
	.long 0x7f16398e                                           // 0000002DC070: 7F16398E
	v_add_f32_e32 v6, v3, v6                                   // 0000002DC074: 060C0D03
	.long 0xd7006a00                                           // 0000002DC078: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002DC07C: 02020004
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000002DC080: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000002DC088: BF870224
	v_and_b32_e32 v2, 1, v11                                   // 0000002DC08C: 36041681
	v_and_b32_e32 v15, 1, v14                                  // 0000002DC090: 361E1C81
	.long 0xd7006a0b                                           // 0000002DC094: D7006A0B
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DC098: 02000100
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DC09C: BF870003
	v_add3_u32 v2, v12, v2, 0x7fff                             // 0000002DC0A0: D6550002 03FE050C 00007FFF
	v_add_co_ci_u32_e64 v12, null, s1, v1, vcc_lo              // 0000002DC0AC: D5207C0C 01AA0201
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002DC0B4: 84808208
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000002DC0B8: DC960000 007C0200
	v_dual_add_f32 v2, v8, v9 :: v_dual_add_f32 v9, v7, v10    // 0000002DC0C0: C9081308 02081507
	.long 0xd7006a07                                           // 0000002DC0C8: D7006A07
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DC0CC: 02000100
	.long 0x7f14398e                                           // 0000002DC0D0: 7F14398E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DC0D4: BF870213
	.long 0x7e143982                                           // 0000002DC0D8: 7E143982
	.long 0x7e1c3989                                           // 0000002DC0DC: 7E1C3989
	s_waitcnt lgkmcnt(0)                                       // 0000002DC0E0: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 0000002DC0E4: 06080B04
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 0000002DC0E8: D5207C08 01AA0201
	v_mad_u64_u32 v[0:1], null, s8, 6, v[0:1]                  // 0000002DC0F0: D6FE7C00 04010C08
	v_and_b32_e32 v5, 1, v10                                   // 0000002DC0F8: 360A1481
	v_and_b32_e32 v3, 1, v14                                   // 0000002DC0FC: 36061C81
	.long 0x7e143984                                           // 0000002DC100: 7E143984
	.long 0x7e1c3986                                           // 0000002DC104: 7E1C3986
	v_add3_u32 v13, v13, v15, 0x7fff                           // 0000002DC108: D655000D 03FE1F0D 00007FFF
	v_add3_u32 v15, v2, v5, 0x7fff                             // 0000002DC114: D655000F 03FE0B02 00007FFF
	v_add3_u32 v9, v9, v3, 0x7fff                              // 0000002DC120: D6550009 03FE0709 00007FFF
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002DC12C: D6FE7C01 04050C09
	v_and_b32_e32 v10, 1, v10                                  // 0000002DC134: 36141481
	v_and_b32_e32 v5, 1, v14                                   // 0000002DC138: 360A1C81
	.long 0xd7006a02                                           // 0000002DC13C: D7006A02
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DC140: 02000107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DC144: BF870211
	v_add_co_ci_u32_e64 v3, null, s1, v8, vcc_lo               // 0000002DC148: D5207C03 01AA1001
	v_add3_u32 v10, v4, v10, 0x7fff                            // 0000002DC150: D655000A 03FE1504 00007FFF
	.long 0xd7006a04                                           // 0000002DC15C: D7006A04
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000002DC160: 02000100
	v_add3_u32 v6, v6, v5, 0x7fff                              // 0000002DC164: D6550006 03FE0B06 00007FFF
	v_add_co_ci_u32_e64 v5, null, s1, v1, vcc_lo               // 0000002DC170: D5207C05 01AA0201
	s_clause 0x4                                               // 0000002DC178: BF850004
	global_store_d16_hi_b16 v[11:12], v13, off                 // 0000002DC17C: DC960000 007C0D0B
	global_store_d16_hi_b16 v[7:8], v15, off                   // 0000002DC184: DC960000 007C0F07
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000002DC18C: DC960000 007C0900
	global_store_d16_hi_b16 v[2:3], v10, off                   // 0000002DC194: DC960000 007C0A02
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000002DC19C: DC960000 007C0604
	s_endpgm                                                   // 0000002DC1A4: BFB00000
		...

