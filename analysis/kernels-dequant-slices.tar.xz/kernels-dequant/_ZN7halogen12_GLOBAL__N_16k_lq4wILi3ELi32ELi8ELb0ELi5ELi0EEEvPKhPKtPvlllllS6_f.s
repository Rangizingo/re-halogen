00000000008bc400 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008BC400: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000008BC408: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008BC410: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008BC414: 86039F02
	v_lshrrev_b32_e32 v15, 5, v0                               // 0000008BC418: 321E0085
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BC41C: BF870003
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BC420: 30020282
	.long 0x7f283880                                           // 0000008BC424: 7F283880
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v2, 60, v2         // 0000008BC428: CA240080 110204BC
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000008BC430: CA100080 04020080
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000008BC438: 301C0082
	s_waitcnt lgkmcnt(0)                                       // 0000008BC43C: BF89FC07
	s_clause 0x1                                               // 0000008BC440: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 0000008BC444: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 0000008BC44C: DC520000 0D040002
	.long 0xd4510014                                           // 0000008BC454: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008BC458: 02001802
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000008BC45C: CA100080 01020080
	s_and_b32 s20, s20, exec_lo                                // 0000008BC464: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 0000008BC468: 98188003
	s_cselect_b32 s25, s2, 0                                   // 0000008BC46C: 98198002
	s_add_u32 s14, s4, s14                                     // 0000008BC470: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000008BC474: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 0000008BC478: 85149F0B
	v_dual_mov_b32 v5, s14 :: v_dual_and_b32 v16, 31, v0       // 0000008BC47C: CA24000E 0510009F
	s_add_u32 s20, s10, s20                                    // 0000008BC484: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000008BC488: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000008BC48C: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000008BC490: 86948114
	s_lshr_b32 s22, s22, 27                                    // 0000008BC494: 85169B16
	v_mov_b32_e32 v6, s15                                      // 0000008BC498: 7E0C020F
	s_add_u32 s22, s10, s22                                    // 0000008BC49C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008BC4A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000008BC4A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008BC4A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008BC4AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000008BC4B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000008BC4B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008BC4B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000008BC4BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000008BC4C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BC4C4: BF870009
	s_ashr_i32 s14, s23, 3                                     // 0000008BC4C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000008BC4CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000008BC4D0: 82051105
	.long 0xd72c0013                                           // 0000008BC4D4: D72C0013
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008BC4D8: 02021E0E
	v_dual_mov_b32 v8, s5 :: v_dual_mov_b32 v7, s4             // 0000008BC4DC: CA100005 08060004
	v_mad_u64_u32 v[9:10], null, s25, s20, v[5:6]              // 0000008BC4E4: D6FE7C09 04142819
	s_mul_i32 s4, s24, s20                                     // 0000008BC4EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000008BC4F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008BC4F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008BC4FC: BF8903F7
	v_bfe_u32 v5, v13, 16, 1                                   // 0000008BC500: D6100005 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000008BC508: BF870232
	v_add3_u32 v6, v11, v12, 0x7fff                            // 0000008BC50C: D6550006 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s25, v[7:8]             // 0000008BC518: D6FE7C0B 041C3212
	v_add_nc_u32_e32 v7, s14, v19                              // 0000008BC520: 4A0E260E
	v_add3_u32 v5, v13, v5, 0x7fff                             // 0000008BC524: D6550005 03FE0B0D 00007FFF
	s_mul_i32 s25, s25, s21                                    // 0000008BC530: 96191519
	.long 0x7e283986                                           // 0000008BC534: 7E283986
	v_add_nc_u32_e32 v6, s4, v10                               // 0000008BC538: 4A0C1404
	v_add_nc_u32_e32 v10, v19, v16                             // 0000008BC53C: 4A142113
	v_min_i32_e32 v19, s22, v7                                 // 0000008BC540: 22260E16
	v_add_nc_u32_e32 v7, s19, v12                              // 0000008BC544: 4A0E1813
	s_mul_i32 s4, s18, s24                                     // 0000008BC548: 96041812
	v_and_or_b32 v5, 0xffff0000, v5, v20                       // 0000008BC54C: D6570005 04520AFF FFFF0000
	v_add_nc_u32_e32 v20, s25, v6                              // 0000008BC558: 4A280C19
	v_cmp_lt_i32_e32 vcc_lo, v10, v19                          // 0000008BC55C: 7C82270A
	v_add_nc_u32_e32 v21, s4, v7                               // 0000008BC560: 4A2A0E04
	ds_store_b32 v14, v5                                       // 0000008BC564: D8340000 0000050E
	s_waitcnt lgkmcnt(0)                                       // 0000008BC56C: BF89FC07
	s_barrier                                                  // 0000008BC570: BFBD0000
	buffer_gl0_inv                                             // 0000008BC574: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008BC57C: BE85206A
	s_cbranch_execz 21                                         // 0000008BC580: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 0000008BC584: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 0000008BC588: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BC58C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008BC590: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008BC594: 3408069F
	.long 0xd7000401                                           // 0000008BC598: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008BC59C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BC5A0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s4                  // 0000008BC5A4: D5207C02 00120515
	.long 0xd7000403                                           // 0000008BC5AC: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008BC5B0: 02020709
	v_add_co_ci_u32_e64 v4, null, v20, v4, s4                  // 0000008BC5B4: D5207C04 00120914
	s_clause 0x1                                               // 0000008BC5BC: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000008BC5C0: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008BC5C8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008BC5D0: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000008BC5D4: 7E241705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BC5D8: 8C7E057E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000008BC5DC: CA100080 17160080
	s_and_saveexec_b32 s5, vcc_lo                              // 0000008BC5E4: BE85206A
	s_cbranch_execz 314                                        // 0000008BC5E8: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x6d4>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v10     // 0000008BC5EC: CA200080 160414A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000008BC5F4: CA220080 170C1485
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000008BC5FC: 848E820A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BC600: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 0000008BC604: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 0000008BC60C: CA220112 1A180A81
	s_mov_b32 s16, 0                                           // 0000008BC614: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008BC618: 848A810A
	s_branch 269                                               // 0000008BC61C: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x654>
	s_or_b32 exec_lo, exec_lo, s17                             // 0000008BC620: 8C7E117E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008BC624: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 0000008BC628: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 0000008BC62C: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 0000008BC630: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 0000008BC638: 329C0486
	.long 0xd73c001b                                           // 0000008BC63C: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008BC640: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000008BC644: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 0000008BC64C: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000008BC654: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008BC65C: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 0000008BC660: 329E048E
	.long 0xd700043f                                           // 0000008BC664: D700043F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000008BC668: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BC66C: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s4                 // 0000008BC670: D5207C40 00123807
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008BC678: 301A1A82
	.long 0xd7000443                                           // 0000008BC67C: D7000443
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 0000008BC680: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BC684: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s4                // 0000008BC688: D5207C44 0012800B
	.long 0xd7000447                                           // 0000008BC690: D7000447
	v_cndmask_b32_e32 v0, v63, v14, vcc_lo                     // 0000008BC694: 02001D3F
	v_add_co_ci_u32_e64 v72, null, s15, v64, s4                // 0000008BC698: D5207C48 0012800F
	s_clause 0xb                                               // 0000008BC6A0: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 0000008BC6A4: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 0000008BC6AC: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 0000008BC6B4: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 0000008BC6BC: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 0000008BC6C4: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 0000008BC6CC: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 0000008BC6D4: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 0000008BC6DC: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 0000008BC6E4: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000008BC6EC: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 0000008BC6F4: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 0000008BC6FC: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 0000008BC704: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 0000008BC70C: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000008BC714: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008BC71C: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008BC720: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 0000008BC728: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 0000008BC72C: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000008BC734: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008BC73C: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008BC744: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 0000008BC74C: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 0000008BC754: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 0000008BC75C: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 0000008BC764: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 0000008BC76C: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 0000008BC774: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 0000008BC778: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008BC77C: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 0000008BC780: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 0000008BC788: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000008BC78C: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 0000008BC794: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008BC798: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008BC7A0: 4A1818FF 00000400
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000008BC7A8: 8B046A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BC7AC: BF870009
	s_or_b32 s16, s4, s16                                      // 0000008BC7B0: 8C101004
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008BC7B4: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 0000008BC7B8: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 0000008BC7C0: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000008BC7C4: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 0000008BC7CC: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 0000008BC7D0: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 0000008BC7D8: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008BC7DC: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000008BC7E0: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 0000008BC7E4: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 0000008BC7EC: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 0000008BC7F4: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 0000008BC7FC: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 0000008BC800: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008BC808: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 0000008BC80C: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 0000008BC814: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 0000008BC81C: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 0000008BC824: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 0000008BC82C: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 0000008BC834: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 0000008BC838: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 0000008BC840: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 0000008BC848: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 0000008BC850: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 0000008BC858: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008BC860: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 0000008BC864: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 0000008BC86C: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 0000008BC870: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 0000008BC878: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 0000008BC87C: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 0000008BC884: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 0000008BC888: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008BC890: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 0000008BC894: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 0000008BC89C: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 0000008BC8A4: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 0000008BC8AC: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008BC8B4: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008BC8BC: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 0000008BC8C0: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 0000008BC8C8: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 0000008BC8D0: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 0000008BC8D8: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BC8DC: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 0000008BC8E0: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 0000008BC8E8: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BC8F0: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 0000008BC8F4: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 0000008BC8FC: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 0000008BC904: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 0000008BC90C: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 0000008BC914: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 0000008BC91C: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 0000008BC924: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 0000008BC928: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 0000008BC930: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 0000008BC934: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 0000008BC93C: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 0000008BC940: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 0000008BC948: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 0000008BC94C: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 0000008BC954: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BC95C: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 0000008BC960: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 0000008BC968: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BC970: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 0000008BC974: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 0000008BC97C: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 0000008BC984: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BC988: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 0000008BC98C: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 0000008BC994: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BC99C: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000008BC9A0: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008BC9A8: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 0000008BC9AC: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 0000008BC9B4: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 0000008BC9B8: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 0000008BC9C0: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 0000008BC9C4: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 0000008BC9CC: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 0000008BC9D0: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 0000008BC9D8: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BC9E0: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 0000008BC9E4: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 0000008BC9EC: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000008BC9F0: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 0000008BC9F4: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 0000008BC9FC: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 0000008BCA04: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000008BCA0C: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 0000008BCA14: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 0000008BCA18: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 0000008BCA20: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 0000008BCA28: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BCA30: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 0000008BCA34: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 0000008BCA3C: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BCA40: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 0000008BCA44: 56221112
	v_mov_b32_e32 v18, v26                                     // 0000008BCA48: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000008BCA4C: 917E107E
	s_cbranch_execz 31                                         // 0000008BCA50: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x6d0>
	s_waitcnt vmcnt(0)                                         // 0000008BCA54: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v10, 32, v10    // 0000008BCA58: CA200101 050A14A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000008BCA60: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000008BCA68: 7E100304
	s_mov_b32 s17, exec_lo                                     // 0000008BCA6C: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BCA70: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v19                          // 0000008BCA74: 7C8C270A
	.long 0xd4c1007e                                           // 0000008BCA78: D4C1007E
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 0000008BCA7C: 0202270A
	s_cbranch_execz 65255                                      // 0000008BCA80: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x220>
	v_ashrrev_i32_e32 v6, 31, v25                              // 0000008BCA84: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 0000008BCA88: 3410309F
	.long 0xd7000405                                           // 0000008BCA8C: D7000405
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000008BCA90: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BCA94: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s4                  // 0000008BCA98: D5207C06 00120D15
	.long 0xd7000407                                           // 0000008BCAA0: D7000407
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000008BCAA4: 02023109
	v_add_co_ci_u32_e64 v8, null, v20, v8, s4                  // 0000008BCAA8: D5207C08 00121114
	s_clause 0x1                                               // 0000008BCAB0: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000008BCAB4: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000008BCABC: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000008BCAC4: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 0000008BCAC8: 7E34170D
	s_branch 65236                                             // 0000008BCACC: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x220>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000008BCAD0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008BCAD4: BF8700C9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BCAD8: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 0000008BCADC: BF8903F7
	.long 0xd71f0001                                           // 0000008BCAE0: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008BCAE4: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008BCAE8: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008BCAEC: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000008BCAF0: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000008BCAF4: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008BCAF8: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008BCAFC: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008BCB00: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008BCB04: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000008BCB08: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BCB0C: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BCB10: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008BCB14: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008BCB18: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000008BCB1C: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000008BCB24: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 0000008BCB28: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 0000008BCB2C: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 0000008BCB34: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 0000008BCB3C: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000008BCB44: 02101101
	s_waitcnt lgkmcnt(2)                                       // 0000008BCB48: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 0000008BCB4C: 06080917
	s_waitcnt lgkmcnt(0)                                       // 0000008BCB50: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000008BCB54: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000008BCB58: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 0000008BCB60: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008BCB64: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 0000008BCB68: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 0000008BCB70: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000008BCB74: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 0000008BCB78: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 0000008BCB80: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000008BCB84: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 0000008BCB88: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000008BCB8C: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000008BCB94: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000008BCB9C: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008BCBA0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BCBA4: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000008BCBA8: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000008BCBAC: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000008BCBB0: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000008BCBB8: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000008BCBBC: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000008BCBC0: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000008BCBC8: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000008BCBD0: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000008BCBD8: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BCBDC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BCBE0: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000008BCBE4: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000008BCBE8: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000008BCBEC: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000008BCBF0: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000008BCBF4: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000008BCBF8: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000008BCC00: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000008BCC08: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000008BCC10: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008BCC18: 7D942080
	s_cbranch_execz 12                                         // 0000008BCC1C: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x850>
	v_mul_u32_u24_e32 v7, 12, v15                              // 0000008BCC20: 160E1E8C
	s_waitcnt lgkmcnt(0)                                       // 0000008BCC24: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 0000008BCC28: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 0000008BCC30: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BCC34: BF870003
	v_or_b32_e32 v4, 0x400, v7                                 // 0000008BCC38: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000008BCC40: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 0000008BCC48: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BCC50: 8C7E047E
	.long 0xd4510004                                           // 0000008BCC54: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000008BCC58: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 0000008BCC5C: 7C980083
	s_waitcnt lgkmcnt(0)                                       // 0000008BCC60: BF89FC07
	s_barrier                                                  // 0000008BCC64: BFBD0000
	buffer_gl0_inv                                             // 0000008BCC68: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008BCC70: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BCC74: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008BCC78: BE852004
	s_cbranch_execz 79                                         // 0000008BCC7C: BFA5004F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x9bc>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 0000008BCC80: 4A0E1CFF 00000400
	s_lshr_b32 s4, s13, 31                                     // 0000008BCC88: 85049F0D
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008BCC8C: F4040000 F8000040
	s_add_u32 s4, s12, s4                                      // 0000008BCC94: 8004040C
	s_addc_u32 s5, s13, 0                                      // 0000008BCC98: 8205800D
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 0000008BCC9C: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 0000008BCCA4: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 0000008BCCAC: D8DC0F0C 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008BCCB4: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008BCCB8: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008BCCBC: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008BCCC0: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008BCCC4: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008BCCC8: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008BCCD0: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008BCCD4: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008BCCD8: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008BCCDC: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BCCE0: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008BCCE4: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008BCCE8: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008BCCEC: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008BCCF4: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008BCCF8: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BCD00: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008BCD04: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008BCD08: 06080B03
	ds_load_2addr_b32 v[7:8], v7 offset0:18 offset1:21         // 0000008BCD0C: D8DC1512 07000007
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008BCD14: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008BCD1C: 8B057E04
	s_cselect_b32 s8, s8, s0                                   // 0000008BCD20: 98080008
	v_add_f32_e32 v0, v4, v6                                   // 0000008BCD24: 06000D04
	s_cselect_b32 s5, s9, s1                                   // 0000008BCD28: 98050109
	s_add_u32 s0, s2, 0xffffff00                               // 0000008BCD2C: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008BCD34: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008BCD38: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008BCD3C: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008BCD40: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008BCD44: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008BCD48: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008BCD4C: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008BCD50: 06060F00
	.long 0xd73c0000                                           // 0000008BCD54: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008BCD58: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008BCD5C: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BCD60: BF870092
	.long 0xd7006a00                                           // 0000008BCD64: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008BCD68: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008BCD6C: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BCD74: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008BCD78: D6100003 02052102
	.long 0xd7006a00                                           // 0000008BCD80: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008BCD84: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BCD88: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008BCD8C: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008BCD94: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BCDA0: BF870093
	.long 0xd7006a00                                           // 0000008BCDA4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008BCDA8: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008BCDAC: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008BCDB4: DC960000 007C0200
	s_endpgm                                                   // 0000008BCDBC: BFB00000
		...

