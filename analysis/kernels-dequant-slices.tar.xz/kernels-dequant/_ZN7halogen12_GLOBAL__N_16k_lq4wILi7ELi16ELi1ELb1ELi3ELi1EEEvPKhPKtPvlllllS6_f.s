000000000085cc00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 00000085CC00: F4100200 F8000000
	v_and_b32_e32 v30, 15, v0                                  // 00000085CC08: 363C008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000085CC0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 00000085CC10: 86039F02
	v_lshlrev_b32_e32 v7, 2, v0                                // 00000085CC14: 300E0082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 00000085CC18: 84828402
	v_lshlrev_b32_e32 v2, 2, v30                               // 00000085CC1C: 30043C82
	v_dual_mov_b32 v24, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 00000085CC20: CA220003 18020282
	v_or_b32_e32 v23, s2, v1                                   // 00000085CC28: 382E0202
	.long 0x7f0c3880                                           // 00000085CC2C: 7F0C3880
	s_waitcnt lgkmcnt(0)                                       // 00000085CC30: BF89FC07
	s_clause 0x1                                               // 00000085CC34: BF850001
	global_load_b32 v4, v2, s[8:9]                             // 00000085CC38: DC520000 04080002
	global_load_b32 v3, v3, s[8:9]                             // 00000085CC40: DC520000 03080003
	.long 0xd4540002                                           // 00000085CC48: D4540002
	v_cndmask_b32_e32 v1, s16, v23, vcc_lo                     // 00000085CC4C: 02022E10
	s_add_u32 s24, s8, s20                                     // 00000085CC50: 80181408
	s_addc_u32 s25, s9, s21                                    // 00000085CC54: 82191509
	s_ashr_i32 s4, s15, 31                                     // 00000085CC58: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000085CC5C: BF870159
	s_lshr_b32 s4, s4, 27                                      // 00000085CC60: 85049B04
	v_cndmask_b32_e64 v2, 0, v23, s2                           // 00000085CC64: D5010002 000A2E80
	v_cndmask_b32_e64 v5, 0, s3, s2                            // 00000085CC6C: D5010005 00080680
	s_add_u32 s4, s14, s4                                      // 00000085CC74: 8004040E
	s_addc_u32 s5, s15, 0                                      // 00000085CC78: 8205800F
	.long 0xd72c0008                                           // 00000085CC7C: D72C0008
	v_cndmask_b32_e32 v1, s23, v2, vcc_lo                      // 00000085CC80: 02020417
	v_mad_u64_u32 v[0:1], null, s22, v2, 0                     // 00000085CC84: D6FE7C00 02020416
	s_lshr_b64 s[6:7], s[4:5], 5                               // 00000085CC8C: 85868504
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000085CC90: BF8704D9
	s_cmpk_lt_i32 s6, 0x81                                     // 00000085CC94: B3860081
	.long 0xd4440004                                           // 00000085CC98: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000085CC9C: 02023C06
	s_cselect_b32 s3, -1, 0                                    // 00000085CCA0: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 00000085CCA4: B2860080
	s_cselect_b32 s7, -1, 0                                    // 00000085CCA8: 980780C1
	s_and_b32 vcc_lo, exec_lo, s7                              // 00000085CCAC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 00000085CCB0: BF8907F7
	v_bfe_u32 v9, v4, 16, 1                                    // 00000085CCB4: D6100009 02052104
	s_waitcnt vmcnt(0)                                         // 00000085CCBC: BF8903F7
	v_bfe_u32 v10, v3, 16, 1                                   // 00000085CCC0: D610000A 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085CCC8: BF8701A2
	v_add3_u32 v4, v4, v9, 0x7fff                              // 00000085CCCC: D6550004 03FE1304 00007FFF
	.long 0xd72c0009                                           // 00000085CCD8: D72C0009
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000085CCDC: 02020A16
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000085CCE0: D6550003 03FE1503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085CCEC: BF870193
	.long 0x7e0c3984                                           // 00000085CCF0: 7E0C3984
	v_add3_u32 v1, v1, v9, v8                                  // 00000085CCF4: D6550001 04221301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085CCFC: BF8700A2
	v_and_or_b32 v6, 0xffff0000, v3, v6                        // 00000085CD00: D6570006 041A06FF FFFF0000
	.long 0xd7000503                                           // 00000085CD0C: D7000503
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000085CD10: 02020018
	v_add_co_ci_u32_e64 v4, null, s25, v1, s5                  // 00000085CD14: D5207C04 00160219
	ds_store_b32 v7, v6                                        // 00000085CD1C: D8340000 00000607
	s_waitcnt lgkmcnt(0)                                       // 00000085CD24: BF89FC07
	s_barrier                                                  // 00000085CD28: BFBD0000
	buffer_gl0_inv                                             // 00000085CD2C: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000085CD34: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v7, 0               // 00000085CD38: CA100080 08060080
	s_and_saveexec_b32 s5, s4                                  // 00000085CD40: BE852004
	s_cbranch_execz 10                                         // 00000085CD44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x170>
	v_lshlrev_b32_e32 v6, 1, v30                               // 00000085CD48: 300C3C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CD4C: BF870091
	.long 0xd7006a06                                           // 00000085CD50: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CD54: 02020D03
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000085CD58: D5207C07 01AA0880
	global_load_d16_b16 v6, v[6:7], off                        // 00000085CD60: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 00000085CD68: BF8903F7
	v_cvt_f32_f16_e32 v7, v6                                   // 00000085CD6C: 7E0E1706
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085CD70: 8C7E057E
	v_or_b32_e32 v6, 16, v30                                   // 00000085CD74: 380C3C90
	s_mov_b32 s4, exec_lo                                      // 00000085CD78: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085CD7C: BF870001
	.long 0xd4c4007e                                           // 00000085CD80: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CD84: 02020C06
	s_cbranch_execz 10                                         // 00000085CD88: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1b4>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CD8C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CD90: BF870091
	.long 0xd7006a08                                           // 00000085CD94: D7006A08
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CD98: 02020D03
	v_add_co_ci_u32_e64 v9, null, 0, v4, vcc_lo                // 00000085CD9C: D5207C09 01AA0880
	global_load_d16_b16 v6, v[8:9], off                        // 00000085CDA4: DC820000 067C0008
	s_waitcnt vmcnt(0)                                         // 00000085CDAC: BF8903F7
	v_cvt_f32_f16_e32 v8, v6                                   // 00000085CDB0: 7E101706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CDB4: 8C7E047E
	v_or_b32_e32 v6, 32, v30                                   // 00000085CDB8: 380C3CA0
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 00000085CDBC: CA100080 0A080080
	s_mov_b32 s4, exec_lo                                      // 00000085CDC4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085CDC8: BF870002
	.long 0xd4c4007e                                           // 00000085CDCC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CDD0: 02020C06
	s_cbranch_execz 10                                         // 00000085CDD4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x200>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CDD8: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CDDC: BF870091
	.long 0xd7006a0b                                           // 00000085CDE0: D7006A0B
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CDE4: 02020D03
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000085CDE8: D5207C0C 01AA0880
	global_load_d16_b16 v6, v[11:12], off                      // 00000085CDF0: DC820000 067C000B
	s_waitcnt vmcnt(0)                                         // 00000085CDF8: BF8903F7
	v_cvt_f32_f16_e32 v9, v6                                   // 00000085CDFC: 7E121706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CE00: 8C7E047E
	v_or_b32_e32 v6, 48, v30                                   // 00000085CE04: 380C3CB0
	s_mov_b32 s4, exec_lo                                      // 00000085CE08: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085CE0C: BF870001
	.long 0xd4c4007e                                           // 00000085CE10: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CE14: 02020C06
	s_cbranch_execz 10                                         // 00000085CE18: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x244>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CE1C: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CE20: BF870091
	.long 0xd7006a0a                                           // 00000085CE24: D7006A0A
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CE28: 02020D03
	v_add_co_ci_u32_e64 v11, null, 0, v4, vcc_lo               // 00000085CE2C: D5207C0B 01AA0880
	global_load_d16_b16 v6, v[10:11], off                      // 00000085CE34: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 00000085CE3C: BF8903F7
	v_cvt_f32_f16_e32 v10, v6                                  // 00000085CE40: 7E141706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CE44: 8C7E047E
	v_or_b32_e32 v6, 64, v30                                   // 00000085CE48: 380C3CC0
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000085CE4C: CA100080 0C0A0080
	s_mov_b32 s4, exec_lo                                      // 00000085CE54: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085CE58: BF870002
	.long 0xd4c4007e                                           // 00000085CE5C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CE60: 02020C06
	s_cbranch_execz 10                                         // 00000085CE64: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x290>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CE68: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CE6C: BF870091
	.long 0xd7006a0d                                           // 00000085CE70: D7006A0D
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CE74: 02020D03
	v_add_co_ci_u32_e64 v14, null, 0, v4, vcc_lo               // 00000085CE78: D5207C0E 01AA0880
	global_load_d16_b16 v6, v[13:14], off                      // 00000085CE80: DC820000 067C000D
	s_waitcnt vmcnt(0)                                         // 00000085CE88: BF8903F7
	v_cvt_f32_f16_e32 v11, v6                                  // 00000085CE8C: 7E161706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CE90: 8C7E047E
	v_or_b32_e32 v6, 0x50, v30                                 // 00000085CE94: 380C3CFF 00000050
	s_mov_b32 s4, exec_lo                                      // 00000085CE9C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085CEA0: BF870001
	.long 0xd4c4007e                                           // 00000085CEA4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CEA8: 02020C06
	s_cbranch_execz 10                                         // 00000085CEAC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2d8>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CEB0: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CEB4: BF870091
	.long 0xd7006a0c                                           // 00000085CEB8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CEBC: 02020D03
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000085CEC0: D5207C0D 01AA0880
	global_load_d16_b16 v6, v[12:13], off                      // 00000085CEC8: DC820000 067C000C
	s_waitcnt vmcnt(0)                                         // 00000085CED0: BF8903F7
	v_cvt_f32_f16_e32 v12, v6                                  // 00000085CED4: 7E181706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CED8: 8C7E047E
	v_or_b32_e32 v6, 0x60, v30                                 // 00000085CEDC: 380C3CFF 00000060
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 00000085CEE4: CA100080 0E0C0080
	s_mov_b32 s4, exec_lo                                      // 00000085CEEC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085CEF0: BF870002
	.long 0xd4c4007e                                           // 00000085CEF4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CEF8: 02020C06
	s_cbranch_execz 10                                         // 00000085CEFC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x328>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CF00: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CF04: BF870091
	.long 0xd7006a0f                                           // 00000085CF08: D7006A0F
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CF0C: 02020D03
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000085CF10: D5207C10 01AA0880
	global_load_d16_b16 v6, v[15:16], off                      // 00000085CF18: DC820000 067C000F
	s_waitcnt vmcnt(0)                                         // 00000085CF20: BF8903F7
	v_cvt_f32_f16_e32 v13, v6                                  // 00000085CF24: 7E1A1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CF28: 8C7E047E
	v_or_b32_e32 v6, 0x70, v30                                 // 00000085CF2C: 380C3CFF 00000070
	s_mov_b32 s4, exec_lo                                      // 00000085CF34: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085CF38: BF870001
	.long 0xd4c4007e                                           // 00000085CF3C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000085CF40: 02020C06
	s_cbranch_execz 10                                         // 00000085CF44: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x370>
	v_lshlrev_b32_e32 v6, 1, v6                                // 00000085CF48: 300C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085CF4C: BF870091
	.long 0xd7006a0e                                           // 00000085CF50: D7006A0E
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000085CF54: 02020D03
	v_add_co_ci_u32_e64 v15, null, 0, v4, vcc_lo               // 00000085CF58: D5207C0F 01AA0880
	global_load_d16_b16 v6, v[14:15], off                      // 00000085CF60: DC820000 067C000E
	s_waitcnt vmcnt(0)                                         // 00000085CF68: BF8903F7
	v_cvt_f32_f16_e32 v14, v6                                  // 00000085CF6C: 7E1C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085CF70: 8C7E047E
	s_branch 9                                                 // 00000085CF74: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x39c>
	v_mov_b32_e32 v7, 0                                        // 00000085CF78: 7E0E0280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085CF7C: BF870001
	v_mov_b32_e32 v8, v7                                       // 00000085CF80: 7E100307
	v_mov_b32_e32 v9, v7                                       // 00000085CF84: 7E120307
	v_mov_b32_e32 v10, v7                                      // 00000085CF88: 7E140307
	v_mov_b32_e32 v11, v7                                      // 00000085CF8C: 7E160307
	v_mov_b32_e32 v12, v7                                      // 00000085CF90: 7E180307
	v_mov_b32_e32 v13, v7                                      // 00000085CF94: 7E1A0307
	v_mov_b32_e32 v14, v7                                      // 00000085CF98: 7E1C0307
	s_add_u32 s4, s8, s18                                      // 00000085CF9C: 80041208
	s_addc_u32 s5, s9, s19                                     // 00000085CFA0: 82051309
	s_lshr_b32 s18, s15, 31                                    // 00000085CFA4: 85129F0F
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000085CFA8: CA100080 13140080
	s_add_u32 s18, s14, s18                                    // 00000085CFB0: 8012120E
	s_addc_u32 s19, s15, 0                                     // 00000085CFB4: 8213800F
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v22, 0             // 00000085CFB8: CA100080 1F160080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 00000085CFC0: 86928112
	v_cndmask_b32_e64 v32, 0, 1, s7                            // 00000085CFC4: D5010020 001D0280
	v_mad_u64_u32 v[25:26], null, v2, s18, s[4:5]              // 00000085CFCC: D6FE7C19 00102502
	.long 0xd72c0002                                           // 00000085CFD4: D72C0002
	v_cndmask_b32_e32 v0, v2, v19, vcc_lo                      // 00000085CFD8: 02002702
	.long 0xd72c0005                                           // 00000085CFDC: D72C0005
	v_cndmask_b32_e32 v0, v5, v18, vcc_lo                      // 00000085CFE0: 02002505
	.long 0xd4440004                                           // 00000085CFE4: D4440004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000085CFE8: 02023C06
	v_mov_b32_e32 v43, 0                                       // 00000085CFEC: 7E560280
	v_mov_b32_e32 v21, 0                                       // 00000085CFF0: 7E2A0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085CFF4: BF870004
	v_add3_u32 v33, v5, v26, v2                                // 00000085CFF8: D6550021 040A3505
	s_and_saveexec_b32 s5, s4                                  // 00000085D000: BE852004
	s_cbranch_execz 21                                         // 00000085D004: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v2, 4, v30     // 00000085D008: CA220080 2B023C84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D010: BF870091
	.long 0xd7006a05                                           // 00000085D014: D7006A05
	v_cndmask_b32_e32 v1, v25, v2, vcc_lo                      // 00000085D018: 02020519
	v_add_co_ci_u32_e64 v6, null, 0, v33, vcc_lo               // 00000085D01C: D5207C06 01AA4280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000085D024: 916A077E
	global_load_b128 v[19:22], v[5:6], off                     // 00000085D028: DC5E0000 137C0005
	s_cbranch_vccnz 10                                         // 00000085D030: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x45c>
	v_lshlrev_b32_e32 v2, 1, v30                               // 00000085D034: 30043C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D038: BF870091
	.long 0xd7006a02                                           // 00000085D03C: D7006A02
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 00000085D040: 02020503
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000085D044: D5207C03 01AA0880
	global_load_d16_b16 v2, v[2:3], off                        // 00000085D04C: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 00000085D054: BF8903F7
	v_cvt_f32_f16_e32 v43, v2                                  // 00000085D058: 7E561702
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085D05C: 8C7E057E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v35, 0             // 00000085D060: CA100080 22220080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v37, 0             // 00000085D068: CA100080 24240080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000085D070: CA100080 26260080
	s_and_saveexec_b32 s5, s4                                  // 00000085D078: BE852004
	s_cbranch_execz 627                                        // 00000085D07C: BFA50273 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xe4c>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v2, 1, v30     // 00000085D080: CA220080 1B023C81
	.long 0xd7006a00                                           // 00000085D088: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000085D08C: 02020014
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085D090: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000085D094: D5207C01 01AA0215
	v_dual_mov_b32 v41, v30 :: v_dual_lshlrev_b32 v26, 5, v30  // 00000085D09C: CA22011E 291A3C85
	.long 0xd7006a00                                           // 00000085D0A4: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000085D0A8: 02020500
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085D0AC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000085D0B0: D5207C01 01AA0280
	v_lshl_or_b32 v40, v30, 4, 0x100                           // 00000085D0B8: D6560028 03FD091E 00000100
	.long 0xd7006a00                                           // 00000085D0C4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000085D0C8: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085D0CC: BF8701A1
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000085D0D0: D5207C01 01AA0209
	v_mov_b32_e32 v39, v27                                     // 00000085D0D8: 7E4E031B
	.long 0xd7006a1c                                           // 00000085D0DC: D7006A1C
	v_cndmask_b32_e32 v0, v0, v160, vcc_lo                     // 00000085D0E0: 02014100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085D0E4: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v1, vcc_lo               // 00000085D0E8: D5207C1D 01AA0280
	v_mov_b32_e32 v38, v27                                     // 00000085D0F0: 7E4C031B
	v_mov_b32_e32 v37, v27                                     // 00000085D0F4: 7E4A031B
	v_mov_b32_e32 v36, v27                                     // 00000085D0F8: 7E48031B
	v_mov_b32_e32 v35, v27                                     // 00000085D0FC: 7E46031B
	v_mov_b32_e32 v34, v27                                     // 00000085D100: 7E44031B
	v_mov_b32_e32 v31, v27                                     // 00000085D104: 7E3E031B
	v_mov_b32_e32 v42, v43                                     // 00000085D108: 7E54032B
	s_mul_i32 s4, s15, 6                                       // 00000085D10C: 9604860F
	s_mul_hi_u32 s7, s14, 6                                    // 00000085D110: 9687860E
	s_lshl_b64 s[18:19], s[14:15], 2                           // 00000085D114: 8492820E
	s_add_i32 s7, s7, s4                                       // 00000085D118: 81070407
	s_mul_i32 s21, s14, 6                                      // 00000085D11C: 9615860E
	s_mov_b32 s20, 0                                           // 00000085D120: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 00000085D124: 8488810E
	s_branch 555                                               // 00000085D128: BFA0022B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xdd8>
	s_or_b32 exec_lo, exec_lo, s14                             // 00000085D12C: 8C7E0E7E
	v_cndmask_b32_e64 v53, v43, v7, s3                         // 00000085D130: D5010035 000E0F2B
	v_cndmask_b32_e64 v1, v8, v9, s3                           // 00000085D138: D5010001 000E1308
	v_cndmask_b32_e64 v0, v7, v8, s3                           // 00000085D140: D5010000 000E1107
	v_dual_mov_b32 v7, v14 :: v_dual_and_b32 v8, 0xff, v19     // 00000085D148: CA24010E 070826FF 000000FF
	v_cndmask_b32_e64 v6, v13, v14, s3                         // 00000085D154: D5010006 000E1D0D
	v_cndmask_b32_e64 v5, v12, v13, s3                         // 00000085D15C: D5010005 000E1B0C
	v_cndmask_b32_e64 v4, v11, v12, s3                         // 00000085D164: D5010004 000E190B
	v_cndmask_b32_e64 v3, v10, v11, s3                         // 00000085D16C: D5010003 000E170A
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085D174: 30101082
	v_cndmask_b32_e64 v2, v9, v10, s3                          // 00000085D178: D5010002 000E1509
	v_add_nc_u32_e32 v40, 0x100, v40                           // 00000085D180: 4A5050FF 00000100
	s_and_b32 s4, exec_lo, s4                                  // 00000085D188: 8B04047E
	ds_load_b32 v14, v8                                        // 00000085D18C: D8D80000 0E000008
	v_lshrrev_b32_e32 v8, 6, v19                               // 00000085D194: 32102686
	s_or_b32 s20, s4, s20                                      // 00000085D198: 8C141404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D19C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D1A0: 361010FF 000003FC
	ds_load_b32 v54, v8                                        // 00000085D1A8: D8D80000 36000008
	v_lshrrev_b32_e32 v8, 14, v19                              // 00000085D1B0: 3210268E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D1B4: 361010FF 000003FC
	ds_load_b32 v55, v8                                        // 00000085D1BC: D8D80000 37000008
	v_lshrrev_b32_e32 v8, 22, v19                              // 00000085D1C4: 32102696
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D1C8: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D1CC: 361010FF 000003FC
	ds_load_b32 v56, v8                                        // 00000085D1D4: D8D80000 38000008
	v_and_b32_e32 v8, 0xff, v20                                // 00000085D1DC: 361028FF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085D1E4: 30101082
	ds_load_b32 v57, v8                                        // 00000085D1E8: D8D80000 39000008
	v_lshrrev_b32_e32 v8, 6, v20                               // 00000085D1F0: 32102886
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D1F4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D1F8: 361010FF 000003FC
	ds_load_b32 v58, v8                                        // 00000085D200: D8D80000 3A000008
	v_lshrrev_b32_e32 v8, 14, v20                              // 00000085D208: 3210288E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D20C: 361010FF 000003FC
	ds_load_b32 v59, v8                                        // 00000085D214: D8D80000 3B000008
	v_lshrrev_b32_e32 v8, 22, v20                              // 00000085D21C: 32102896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D220: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D224: 361010FF 000003FC
	ds_load_b32 v60, v8                                        // 00000085D22C: D8D80000 3C000008
	v_and_b32_e32 v8, 0xff, v21                                // 00000085D234: 36102AFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085D23C: 30101082
	ds_load_b32 v61, v8                                        // 00000085D240: D8D80000 3D000008
	v_lshrrev_b32_e32 v8, 6, v21                               // 00000085D248: 32102A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D24C: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D250: 361010FF 000003FC
	ds_load_b32 v62, v8                                        // 00000085D258: D8D80000 3E000008
	v_lshrrev_b32_e32 v8, 14, v21                              // 00000085D260: 32102A8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D264: 361010FF 000003FC
	ds_load_b32 v63, v8                                        // 00000085D26C: D8D80000 3F000008
	v_lshrrev_b32_e32 v8, 22, v21                              // 00000085D274: 32102A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D278: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D27C: 361010FF 000003FC
	ds_load_b32 v64, v8                                        // 00000085D284: D8D80000 40000008
	v_and_b32_e32 v8, 0xff, v22                                // 00000085D28C: 36102CFF 000000FF
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085D294: 30101082
	ds_load_b32 v65, v8                                        // 00000085D298: D8D80000 41000008
	v_lshrrev_b32_e32 v8, 6, v22                               // 00000085D2A0: 32102C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D2A4: BF8700B1
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D2A8: 361010FF 000003FC
	ds_load_b32 v66, v8                                        // 00000085D2B0: D8D80000 42000008
	v_lshrrev_b32_e32 v8, 14, v22                              // 00000085D2B8: 32102C8E
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D2BC: 361010FF 000003FC
	ds_load_b32 v67, v8                                        // 00000085D2C4: D8D80000 43000008
	v_lshrrev_b32_e32 v8, 22, v22                              // 00000085D2CC: 32102C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000085D2D0: BF870141
	v_and_b32_e32 v8, 0x3fc, v8                                // 00000085D2D4: 361010FF 000003FC
	ds_load_b32 v68, v8                                        // 00000085D2DC: D8D80000 44000008
	.long 0xd73c0008                                           // 00000085D2E4: D73C0008
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000085D2E8: 02023481
	v_add_nc_u32_e32 v26, 0x200, v26                           // 00000085D2EC: 4A3434FF 00000200
	.long 0xd7006a0c                                           // 00000085D2F4: D7006A0C
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000085D2F8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085D2FC: BF870001
	v_add_co_ci_u32_e64 v13, null, s11, v9, vcc_lo             // 00000085D300: D5207C0D 01AA120B
	s_clause 0x3                                               // 00000085D308: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085D30C: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085D314: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085D31C: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085D324: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000085D32C: BF890CF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D330: CC1A4008 1A021D08
	s_waitcnt lgkmcnt(14)                                      // 00000085D338: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D33C: BF8700A1
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D340: CC1A4008 1C226D09
	s_waitcnt lgkmcnt(13)                                      // 00000085D348: BF89FCD7
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D34C: CC1A4008 1C226F0A
	s_waitcnt lgkmcnt(12)                                      // 00000085D354: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D358: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D35C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000085D364: BF8908B7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D368: CC1A4008 1C227313
	s_waitcnt lgkmcnt(10)                                      // 00000085D370: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D374: BF8700A1
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D378: CC1A4008 1C227514
	s_waitcnt lgkmcnt(9)                                       // 00000085D380: BF89FC97
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D384: CC1A4008 1C227715
	s_waitcnt lgkmcnt(8)                                       // 00000085D38C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D390: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D394: CC1A4008 1C227916
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000085D39C: BF890477
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D3A0: CC1A4008 1C227B2B
	s_waitcnt lgkmcnt(6)                                       // 00000085D3A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D3AC: BF8700A1
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D3B0: CC1A4008 1C227D2C
	s_waitcnt lgkmcnt(5)                                       // 00000085D3B8: BF89FC57
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D3BC: CC1A4008 1C227F2D
	s_waitcnt lgkmcnt(4)                                       // 00000085D3C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D3C8: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D3CC: CC1A4008 1C22812E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000085D3D4: BF890037
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D3D8: CC1A4008 1C22832F
	.long 0xd7006a2f                                           // 00000085D3E0: D7006A2F
	v_cndmask_b32_e32 v0, v12, v8, vcc_lo                      // 00000085D3E4: 0200110C
	s_waitcnt lgkmcnt(2)                                       // 00000085D3E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000085D3EC: BF8701C2
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D3F0: CC1A4008 1C228530
	v_add_co_ci_u32_e64 v48, null, s9, v13, vcc_lo             // 00000085D3F8: D5207C30 01AA1A09
	.long 0xd7006a33                                           // 00000085D400: D7006A33
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000085D404: 0200250C
	s_waitcnt lgkmcnt(1)                                       // 00000085D408: BF89FC17
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D40C: CC1A4008 1C228731
	v_add_co_ci_u32_e64 v52, null, s19, v13, vcc_lo            // 00000085D414: D5207C34 01AA1A13
	.long 0xd7006a0c                                           // 00000085D41C: D7006A0C
	v_cndmask_b32_e32 v0, v12, v21, vcc_lo                     // 00000085D420: 02002B0C
	s_waitcnt lgkmcnt(0)                                       // 00000085D424: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085D428: BF870123
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D42C: CC1A4008 1C228932
	v_add_co_ci_u32_e64 v13, null, s7, v13, vcc_lo             // 00000085D434: D5207C0D 01AA1A07
	v_fmac_f32_e32 v39, v53, v8                                // 00000085D43C: 564E1135
	s_clause 0x3                                               // 00000085D440: BF850003
	global_load_b128 v[8:11], v[47:48], off                    // 00000085D444: DC5E0000 087C002F
	global_load_b128 v[19:22], v[47:48], off offset:16         // 00000085D44C: DC5E0010 137C002F
	global_load_b128 v[43:46], v[47:48], off offset:32         // 00000085D454: DC5E0020 2B7C002F
	global_load_b128 v[47:50], v[47:48], off offset:48         // 00000085D45C: DC5E0030 2F7C002F
	s_waitcnt vmcnt(3)                                         // 00000085D464: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D468: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D470: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D474: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D47C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D484: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D488: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D490: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D494: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D49C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D4A0: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D4A8: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D4B0: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D4B4: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085D4BC: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D4C0: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D4C8: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D4CC: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D4D4: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D4DC: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D4E0: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D4E8: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D4EC: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D4F4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D4F8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D500: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D508: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D50C: CC1A4008 1C228932
	v_fmac_f32_e32 v38, v53, v8                                // 00000085D514: 564C1135
	s_clause 0x3                                               // 00000085D518: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 00000085D51C: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 00000085D524: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 00000085D52C: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 00000085D534: DC5E0030 2F7C0033
	.long 0xd7006a33                                           // 00000085D53C: D7006A33
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 00000085D540: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D544: BF8700B1
	v_add_co_ci_u32_e64 v52, null, s19, v52, vcc_lo            // 00000085D548: D5207C34 01AA6813
	s_waitcnt vmcnt(3)                                         // 00000085D550: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D554: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D55C: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D564: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D568: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D570: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D578: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D57C: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D580: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D588: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D590: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D594: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D59C: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085D5A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D5A8: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D5AC: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D5B4: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D5BC: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D5C0: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D5C8: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D5D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D5D4: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D5D8: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D5E0: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D5E8: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D5EC: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D5F4: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085D5FC: BF870001
	v_fmac_f32_e32 v37, v53, v8                                // 00000085D600: 564A1135
	s_clause 0x3                                               // 00000085D604: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085D608: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085D610: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085D618: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085D620: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 00000085D628: D7006A0C
	v_cndmask_b32_e32 v0, v12, v18, vcc_lo                     // 00000085D62C: 0200250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085D630: BF8700B1
	v_add_co_ci_u32_e64 v13, null, s19, v13, vcc_lo            // 00000085D634: D5207C0D 01AA1A13
	s_waitcnt vmcnt(3)                                         // 00000085D63C: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D640: CC1A4008 1A021D08
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D648: CC1A4008 1C226D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D650: BF870091
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D654: CC1A4008 1C226F0A
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D65C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D664: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D668: BF870091
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D66C: CC1A4008 1C227313
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D674: CC1A4008 1C227514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D67C: BF870091
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D680: CC1A4008 1C227715
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D688: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085D690: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D694: BF870091
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D698: CC1A4008 1C227B2B
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D6A0: CC1A4008 1C227D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D6A8: BF870091
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D6AC: CC1A4008 1C227F2D
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D6B4: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D6BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D6C0: BF870091
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D6C4: CC1A4008 1C22832F
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D6CC: CC1A4008 1C228530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D6D4: BF870091
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D6D8: CC1A4008 1C228731
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D6E0: CC1A4008 1C228932
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085D6E8: BF870001
	v_fmac_f32_e32 v36, v53, v8                                // 00000085D6EC: 56481135
	s_clause 0x3                                               // 00000085D6F0: BF850003
	global_load_b128 v[8:11], v[51:52], off                    // 00000085D6F4: DC5E0000 087C0033
	global_load_b128 v[19:22], v[51:52], off offset:16         // 00000085D6FC: DC5E0010 137C0033
	global_load_b128 v[43:46], v[51:52], off offset:32         // 00000085D704: DC5E0020 2B7C0033
	global_load_b128 v[47:50], v[51:52], off offset:48         // 00000085D70C: DC5E0030 2F7C0033
	s_waitcnt vmcnt(3)                                         // 00000085D714: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D718: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D720: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D724: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D72C: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D734: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D738: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D740: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D744: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D74C: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D750: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D758: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D760: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D764: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085D76C: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D770: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D778: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D77C: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D784: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D78C: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D790: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D798: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D79C: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D7A4: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D7A8: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D7B0: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D7B8: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D7BC: CC1A4008 1C228932
	v_fmac_f32_e32 v35, v53, v8                                // 00000085D7C4: 56461135
	s_clause 0x3                                               // 00000085D7C8: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085D7CC: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085D7D4: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085D7DC: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085D7E4: DC5E0030 2F7C000C
	.long 0xd7006a0c                                           // 00000085D7EC: D7006A0C
	v_cndmask_b32_e32 v0, v51, v18, vcc_lo                     // 00000085D7F0: 02002533
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D7F4: BF8700A1
	v_add_co_ci_u32_e64 v13, null, s19, v52, vcc_lo            // 00000085D7F8: D5207C0D 01AA6813
	.long 0xd7006a1c                                           // 00000085D800: D7006A1C
	v_cndmask_b32_e32 v0, v28, v160, vcc_lo                    // 00000085D804: 0201411C
	v_add_co_ci_u32_e64 v29, null, 0, v29, vcc_lo              // 00000085D808: D5207C1D 01AA3A80
	s_waitcnt vmcnt(3)                                         // 00000085D810: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D814: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D81C: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D820: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D828: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D830: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D834: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D83C: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D840: CC1A4008 1C227313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D848: BF870091
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D84C: CC1A4008 1C227514
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D854: CC1A4008 1C227715
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D85C: BF8700A1
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D860: CC1A4008 1C227916
	s_waitcnt vmcnt(1)                                         // 00000085D868: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D86C: CC1A4008 1C227B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D874: BF870091
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D878: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D880: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D888: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D88C: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D894: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D898: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D8A0: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D8A4: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D8AC: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D8B4: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D8B8: CC1A4008 1C228932
	v_fmac_f32_e32 v34, v53, v8                                // 00000085D8C0: 56441135
	s_clause 0x3                                               // 00000085D8C4: BF850003
	global_load_b128 v[8:11], v[12:13], off                    // 00000085D8C8: DC5E0000 087C000C
	global_load_b128 v[19:22], v[12:13], off offset:16         // 00000085D8D0: DC5E0010 137C000C
	global_load_b128 v[43:46], v[12:13], off offset:32         // 00000085D8D8: DC5E0020 2B7C000C
	global_load_b128 v[47:50], v[12:13], off offset:48         // 00000085D8E0: DC5E0030 2F7C000C
	s_waitcnt vmcnt(3)                                         // 00000085D8E8: BF890FF7
	v_dot2_f32_bf16 v8, v8, v14, 0                             // 00000085D8EC: CC1A4008 1A021D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D8F4: BF870091
	v_dot2_f32_bf16 v8, v9, v54, v8                            // 00000085D8F8: CC1A4008 1C226D09
	v_dot2_f32_bf16 v8, v10, v55, v8                           // 00000085D900: CC1A4008 1C226F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D908: BF8700A1
	v_dot2_f32_bf16 v8, v11, v56, v8                           // 00000085D90C: CC1A4008 1C22710B
	s_waitcnt vmcnt(2)                                         // 00000085D914: BF890BF7
	v_dot2_f32_bf16 v8, v19, v57, v8                           // 00000085D918: CC1A4008 1C227313
	v_mov_b32_e32 v19, v15                                     // 00000085D920: 7E26030F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085D924: BF870122
	v_dot2_f32_bf16 v8, v20, v58, v8                           // 00000085D928: CC1A4008 1C227514
	v_mov_b32_e32 v20, v16                                     // 00000085D930: 7E280310
	v_dot2_f32_bf16 v8, v21, v59, v8                           // 00000085D934: CC1A4008 1C227715
	v_mov_b32_e32 v21, v17                                     // 00000085D93C: 7E2A0311
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000085D940: BF870132
	v_dot2_f32_bf16 v8, v22, v60, v8                           // 00000085D944: CC1A4008 1C227916
	v_mov_b32_e32 v22, v18                                     // 00000085D94C: 7E2C0312
	s_waitcnt vmcnt(1)                                         // 00000085D950: BF8907F7
	v_dot2_f32_bf16 v8, v43, v61, v8                           // 00000085D954: CC1A4008 1C227B2B
	v_mov_b32_e32 v43, v42                                     // 00000085D95C: 7E56032A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D960: BF870092
	v_dot2_f32_bf16 v8, v44, v62, v8                           // 00000085D964: CC1A4008 1C227D2C
	v_dot2_f32_bf16 v8, v45, v63, v8                           // 00000085D96C: CC1A4008 1C227F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085D974: BF8700A1
	v_dot2_f32_bf16 v8, v46, v64, v8                           // 00000085D978: CC1A4008 1C22812E
	s_waitcnt vmcnt(0)                                         // 00000085D980: BF8903F7
	v_dot2_f32_bf16 v8, v47, v65, v8                           // 00000085D984: CC1A4008 1C22832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D98C: BF870091
	v_dot2_f32_bf16 v8, v48, v66, v8                           // 00000085D990: CC1A4008 1C228530
	v_dot2_f32_bf16 v8, v49, v67, v8                           // 00000085D998: CC1A4008 1C228731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085D9A0: BF870091
	v_dot2_f32_bf16 v8, v50, v68, v8                           // 00000085D9A4: CC1A4008 1C228932
	v_dual_fmac_f32 v31, v53, v8 :: v_dual_mov_b32 v14, v7     // 00000085D9AC: C8101135 1F0E0107
	v_dual_mov_b32 v13, v6 :: v_dual_mov_b32 v12, v5           // 00000085D9B4: CA100106 0D0C0105
	v_dual_mov_b32 v11, v4 :: v_dual_mov_b32 v10, v3           // 00000085D9BC: CA100104 0B0A0103
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v8, v1             // 00000085D9C4: CA100102 09080101
	v_mov_b32_e32 v7, v0                                       // 00000085D9CC: 7E0E0300
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 00000085D9D0: 917E147E
	s_cbranch_execz 28                                         // 00000085D9D4: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xe48>
	s_waitcnt vmcnt(0)                                         // 00000085D9D8: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v41, 16, v41  // 00000085D9DC: CA200114 10285290
	v_dual_mov_b32 v15, v19 :: v_dual_mov_b32 v18, v22         // 00000085D9E4: CA100113 0F120116
	v_mov_b32_e32 v17, v21                                     // 00000085D9EC: 7E220315
	s_delay_alu instid0(VALU_DEP_3)                            // 00000085D9F0: BF870003
	.long 0xd4430004                                           // 00000085D9F4: D4430004
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 00000085D9F8: 02025206
	s_mov_b32 s14, exec_lo                                     // 00000085D9FC: BE8E007E
	.long 0xd4c4007e                                           // 00000085DA00: D4C4007E
	v_cndmask_b32_e32 v1, s6, v41, vcc_lo                      // 00000085DA04: 02025206
	s_cbranch_execz 64968                                      // 00000085DA08: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	.long 0xd7006a00                                           // 00000085DA0C: D7006A00
	v_cndmask_b32_e32 v1, v25, v40, vcc_lo                     // 00000085DA10: 02025119
	s_delay_alu instid0(VALU_DEP_1)                            // 00000085DA14: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v33, vcc_lo               // 00000085DA18: D5207C01 01AA4280
	v_cmp_ne_u32_e32 vcc_lo, 1, v32                            // 00000085DA20: 7C9A4081
	v_mov_b32_e32 v42, v43                                     // 00000085DA24: 7E54032B
	global_load_b128 v[15:18], v[0:1], off                     // 00000085DA28: DC5E0000 0F7C0000
	s_cbranch_vccnz 64958                                      // 00000085DA30: BFA4FDBE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	global_load_d16_b16 v0, v[28:29], off                      // 00000085DA34: DC820000 007C001C
	s_waitcnt vmcnt(0)                                         // 00000085DA3C: BF8903F7
	v_cvt_f32_f16_e32 v42, v0                                  // 00000085DA40: 7E541700
	s_branch 64953                                             // 00000085DA44: BFA0FDB9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x52c>
	s_or_b32 exec_lo, exec_lo, s20                             // 00000085DA48: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085DA4C: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085DA50: 8C7E057E
	.long 0xd71f0000                                           // 00000085DA54: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000085DA58: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 00000085DA5C: 3A020088
	v_xor_b32_e32 v8, 4, v0                                    // 00000085DA60: 3A100084
	v_xor_b32_e32 v15, 2, v0                                   // 00000085DA64: 3A1E0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000085DA68: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 00000085DA6C: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000085DA70: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 00000085DA74: 7C9810A0
	v_cndmask_b32_e32 v8, v0, v8, vcc_lo                       // 00000085DA78: 02101100
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 00000085DA7C: 7C981EA0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085DA80: BF870002
	v_lshlrev_b32_e32 v8, 2, v8                                // 00000085DA84: 30101082
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000085DA88: 30020282
	ds_bpermute_b32 v2, v1, v39                                // 00000085DA8C: DACC0000 02002701
	s_waitcnt lgkmcnt(0)                                       // 00000085DA94: BF89FC07
	v_add_f32_e32 v2, v39, v2                                  // 00000085DA98: 06040527
	ds_bpermute_b32 v4, v1, v37                                // 00000085DA9C: DACC0000 04002501
	ds_bpermute_b32 v5, v1, v36                                // 00000085DAA4: DACC0000 05002401
	ds_bpermute_b32 v3, v1, v38                                // 00000085DAAC: DACC0000 03002601
	ds_bpermute_b32 v6, v1, v35                                // 00000085DAB4: DACC0000 06002301
	ds_bpermute_b32 v7, v1, v34                                // 00000085DABC: DACC0000 07002201
	ds_bpermute_b32 v1, v1, v31                                // 00000085DAC4: DACC0000 01001F01
	ds_bpermute_b32 v9, v8, v2                                 // 00000085DACC: DACC0000 09000208
	s_waitcnt lgkmcnt(6)                                       // 00000085DAD4: BF89FC67
	v_dual_cndmask_b32 v15, v0, v15 :: v_dual_add_f32 v4, v37, v4// 00000085DAD8: CA481F00 0F040925
	s_waitcnt lgkmcnt(5)                                       // 00000085DAE0: BF89FC57
	v_add_f32_e32 v5, v36, v5                                  // 00000085DAE4: 060A0B24
	s_waitcnt lgkmcnt(3)                                       // 00000085DAE8: BF89FC37
	v_dual_add_f32 v3, v38, v3 :: v_dual_add_f32 v6, v35, v6   // 00000085DAEC: C9080726 03060D23
	s_waitcnt lgkmcnt(2)                                       // 00000085DAF4: BF89FC27
	v_add_f32_e32 v7, v34, v7                                  // 00000085DAF8: 060E0F22
	ds_bpermute_b32 v11, v8, v4                                // 00000085DAFC: DACC0000 0B000408
	s_waitcnt lgkmcnt(2)                                       // 00000085DB04: BF89FC27
	v_add_f32_e32 v1, v31, v1                                  // 00000085DB08: 0602031F
	ds_bpermute_b32 v10, v8, v3                                // 00000085DB0C: DACC0000 0A000308
	ds_bpermute_b32 v12, v8, v5                                // 00000085DB14: DACC0000 0C000508
	ds_bpermute_b32 v13, v8, v6                                // 00000085DB1C: DACC0000 0D000608
	ds_bpermute_b32 v14, v8, v7                                // 00000085DB24: DACC0000 0E000708
	s_waitcnt lgkmcnt(5)                                       // 00000085DB2C: BF89FC57
	v_dual_add_f32 v2, v2, v9 :: v_dual_lshlrev_b32 v15, 2, v15// 00000085DB30: C9221302 020E1E82
	s_waitcnt lgkmcnt(4)                                       // 00000085DB38: BF89FC47
	v_add_f32_e32 v4, v4, v11                                  // 00000085DB3C: 06081704
	ds_bpermute_b32 v8, v8, v1                                 // 00000085DB40: DACC0000 08000108
	s_waitcnt lgkmcnt(4)                                       // 00000085DB48: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 00000085DB4C: 06061503
	v_xor_b32_e32 v10, 1, v0                                   // 00000085DB50: 3A140081
	s_waitcnt lgkmcnt(2)                                       // 00000085DB54: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 00000085DB58: 060C1B06
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085DB5C: BF870002
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000085DB60: 7C9814A0
	v_add_f32_e32 v5, v5, v12                                  // 00000085DB64: 060A1905
	ds_bpermute_b32 v12, v15, v4                               // 00000085DB68: DACC0000 0C00040F
	v_cndmask_b32_e32 v0, v0, v10, vcc_lo                      // 00000085DB70: 02001500
	ds_bpermute_b32 v13, v15, v5                               // 00000085DB74: DACC0000 0D00050F
	v_cmp_eq_u32_e32 vcc_lo, 0, v30                            // 00000085DB7C: 7C943C80
	v_lshlrev_b32_e32 v17, 2, v0                               // 00000085DB80: 30220082
	s_and_b32 s2, vcc_lo, s2                                   // 00000085DB84: 8B02026A
	s_waitcnt lgkmcnt(2)                                       // 00000085DB88: BF89FC27
	v_add_f32_e32 v8, v1, v8                                   // 00000085DB8C: 06101101
	ds_bpermute_b32 v1, v15, v2                                // 00000085DB90: DACC0000 0100020F
	v_add_f32_e32 v7, v7, v14                                  // 00000085DB98: 060E1D07
	ds_bpermute_b32 v9, v15, v3                                // 00000085DB9C: DACC0000 0900030F
	ds_bpermute_b32 v14, v15, v6                               // 00000085DBA4: DACC0000 0E00060F
	s_waitcnt lgkmcnt(2)                                       // 00000085DBAC: BF89FC27
	v_add_f32_e32 v10, v2, v1                                  // 00000085DBB0: 06140302
	ds_bpermute_b32 v16, v15, v7                               // 00000085DBB4: DACC0000 1000070F
	ds_bpermute_b32 v15, v15, v8                               // 00000085DBBC: DACC0000 0F00080F
	s_waitcnt lgkmcnt(3)                                       // 00000085DBC4: BF89FC37
	v_add_f32_e32 v11, v3, v9                                  // 00000085DBC8: 06161303
	v_dual_add_f32 v1, v4, v12 :: v_dual_add_f32 v2, v5, v13   // 00000085DBCC: C9081904 01021B05
	s_waitcnt lgkmcnt(2)                                       // 00000085DBD4: BF89FC27
	v_add_f32_e32 v3, v6, v14                                  // 00000085DBD8: 06061D06
	ds_bpermute_b32 v12, v17, v10                              // 00000085DBDC: DACC0000 0C000A11
	ds_bpermute_b32 v13, v17, v11                              // 00000085DBE4: DACC0000 0D000B11
	ds_bpermute_b32 v6, v17, v1                                // 00000085DBEC: DACC0000 06000111
	s_waitcnt lgkmcnt(3)                                       // 00000085DBF4: BF89FC37
	v_dual_add_f32 v0, v7, v16 :: v_dual_add_f32 v5, v8, v15   // 00000085DBF8: C9082107 00041F08
	ds_bpermute_b32 v7, v17, v2                                // 00000085DC00: DACC0000 07000211
	ds_bpermute_b32 v8, v17, v3                                // 00000085DC08: DACC0000 08000311
	ds_bpermute_b32 v4, v17, v0                                // 00000085DC10: DACC0000 04000011
	ds_bpermute_b32 v9, v17, v5                                // 00000085DC18: DACC0000 09000511
	s_and_saveexec_b32 s3, s2                                  // 00000085DC20: BE832002
	s_cbranch_execz 320                                        // 00000085DC24: BFA50140 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1528>
	s_load_b32 s2, s[0:1], 0x48                                // 00000085DC28: F4000080 F8000048
	s_waitcnt lgkmcnt(0)                                       // 00000085DC30: BF89FC07
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v11, v11, v13// 00000085DC34: C908190A 0A0A1B0B
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v2, v2, v7     // 00000085DC3C: C9081305 05020F02
	v_dual_add_f32 v6, v1, v6 :: v_dual_add_f32 v3, v3, v8     // 00000085DC44: C9080D01 06021103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000085DC4C: BF870213
	v_bfe_u32 v12, v10, 16, 1                                  // 00000085DC50: D610000C 0205210A
	v_bfe_u32 v13, v11, 16, 1                                  // 00000085DC58: D610000D 0205210B
	s_lshl_b64 s[0:1], s[16:17], 2                             // 00000085DC60: 84808210
	s_lshl_b64 s[4:5], s[16:17], 3                             // 00000085DC64: 84848310
	v_add_f32_e32 v4, v0, v4                                   // 00000085DC68: 06080900
	v_add3_u32 v9, v10, v12, 0x7fff                            // 00000085DC6C: D6550009 03FE190A 00007FFF
	v_add3_u32 v10, v11, v13, 0x7fff                           // 00000085DC78: D655000A 03FE1B0B 00007FFF
	v_bfe_u32 v11, v3, 16, 1                                   // 00000085DC84: D610000B 02052103
	v_bfe_u32 v13, v5, 16, 1                                   // 00000085DC8C: D610000D 02052105
	.long 0xd73c0000                                           // 00000085DC94: D73C0000
	v_cndmask_b32_e32 v1, 2, v23, vcc_lo                       // 00000085DC98: 02022E82
	v_and_b32_e32 v7, 0xffff0000, v9                           // 00000085DC9C: 360E12FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v10                          // 00000085DCA4: 361014FF FFFF0000
	v_bfe_u32 v9, v6, 16, 1                                    // 00000085DCAC: D6100009 02052106
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000085DCB4: D6550003 03FE1703 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 00000085DCC0: D610000C 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000085DCC8: BF870214
	v_dual_mul_f32 v7, s2, v7 :: v_dual_mul_f32 v8, s2, v8     // 00000085DCCC: C8C60E02 07081002
	v_add3_u32 v6, v6, v9, 0x7fff                              // 00000085DCD4: D6550006 03FE1306 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000085DCE0: D6550005 03FE1B05 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000085DCEC: BF870214
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000085DCF0: D6550004 03FE1904 00007FFF
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 00000085DCFC: 100E0EFF BFB8AA3B
	v_bfe_u32 v10, v2, 16, 1                                   // 00000085DD04: D610000A 02052102
	.long 0xd7006a00                                           // 00000085DD0C: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000085DD10: 0202000C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000085DD14: BF870214
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000085DD18: 360808FF FFFF0000
	v_exp_f32_e32 v7, v7                                       // 00000085DD20: 7E0E4B07
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 00000085DD24: 101010FF BFB8AA3B
	v_add3_u32 v2, v2, v10, 0x7fff                             // 00000085DD2C: D6550002 03FE1502 00007FFF
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 00000085DD38: D5207C01 01AA020D
	v_and_b32_e32 v9, 0xffff0000, v3                           // 00000085DD40: 361206FF FFFF0000
	v_and_b32_e32 v6, 0xffff0000, v6                           // 00000085DD48: 360C0CFF FFFF0000
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000085DD50: 360A0AFF FFFF0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085DD58: BF8701A5
	v_add_f32_e32 v7, 1.0, v7                                  // 00000085DD5C: 060E0EF2
	v_exp_f32_e32 v8, v8                                       // 00000085DD60: 7E104B08
	v_dual_mul_f32 v9, s2, v9 :: v_dual_mul_f32 v6, s2, v6     // 00000085DD64: C8C61202 09060C02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085DD6C: BF870113
	v_mul_f32_e32 v5, s2, v5                                   // 00000085DD70: 100A0A02
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 00000085DD74: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000085DD7C: BF870003
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 00000085DD80: 10060CFF BFB8AA3B
	v_div_scale_f32 v6, null, v7, v7, 1.0                      // 00000085DD88: D6FC7C06 03CA0F07
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 00000085DD90: BF870205
	v_dual_mul_f32 v5, 0xbfb8aa3b, v5 :: v_dual_add_f32 v8, 1.0, v8// 00000085DD94: C8C80AFF 050810F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085DDA0: BF870114
	v_exp_f32_e32 v9, v9                                       // 00000085DDA4: 7E124B09
	v_rcp_f32_e32 v13, v6                                      // 00000085DDA8: 7E1A5506
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085DDAC: BF870091
	v_exp_f32_e32 v5, v5                                       // 00000085DDB0: 7E0A4B05
	v_div_scale_f32 v10, null, v8, v8, 1.0                     // 00000085DDB4: D6FC7C0A 03CA1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 00000085DDBC: BF8703A1
	v_rcp_f32_e32 v14, v10                                     // 00000085DDC0: 7E1C550A
	v_add_f32_e32 v9, 1.0, v9                                  // 00000085DDC4: 061212F2
	v_fma_f32 v15, -v6, v13, 1.0                               // 00000085DDC8: D613000F 23CA1B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085DDD0: BF870091
	v_dual_fmac_f32 v13, v15, v13 :: v_dual_and_b32 v2, 0xffff0000, v2// 00000085DDD4: C8241B0F 0D0204FF FFFF0000
	v_dual_mul_f32 v11, s2, v2 :: v_dual_mul_f32 v4, s2, v4    // 00000085DDE0: C8C60402 0B040802
	v_exp_f32_e32 v12, v3                                      // 00000085DDE8: 7E184B03
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085DDEC: BF8701A6
	v_fma_f32 v16, -v10, v14, 1.0                              // 00000085DDF0: D6130010 23CA1D0A
	.long 0xd7006a02                                           // 00000085DDF8: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000085DDFC: 02000100
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 00000085DE00: 101616FF BFB8AA3B
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 00000085DE08: D5207C03 01AA0201
	v_div_scale_f32 v17, vcc_lo, 1.0, v7, 1.0                  // 00000085DE10: D6FC6A11 03CA0EF2
	v_div_scale_f32 v18, s0, 1.0, v8, 1.0                      // 00000085DE18: D6FC0012 03CA10F2
	v_fmac_f32_e32 v14, v16, v14                               // 00000085DE20: 561C1D10
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000085DE24: BF870005
	v_add_f32_e32 v12, 1.0, v12                                // 00000085DE28: 061818F2
	v_exp_f32_e32 v11, v11                                     // 00000085DE2C: 7E164B0B
	v_mul_f32_e32 v16, v17, v13                                // 00000085DE30: 10201B11
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000085DE34: 100808FF BFB8AA3B
	s_waitcnt vmcnt(0)                                         // 00000085DE3C: BF8903F7
	v_mul_f32_e32 v20, v18, v14                                // 00000085DE40: 10281D12
	v_div_scale_f32 v19, null, v12, v12, 1.0                   // 00000085DE44: D6FC7C13 03CA190C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085DE4C: BF870113
	v_exp_f32_e32 v4, v4                                       // 00000085DE50: 7E084B04
	v_fma_f32 v22, -v10, v20, v18                              // 00000085DE54: D6130016 244A290A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 00000085DE5C: BF870392
	v_rcp_f32_e32 v15, v19                                     // 00000085DE60: 7E1E5513
	v_add_f32_e32 v11, 1.0, v11                                // 00000085DE64: 061616F2
	v_fma_f32 v21, -v6, v16, v17                               // 00000085DE68: D6130015 24462106
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085DE70: BF870193
	v_fmac_f32_e32 v20, v22, v14                               // 00000085DE74: 56281D16
	v_div_scale_f32 v22, null, v11, v11, 1.0                   // 00000085DE78: D6FC7C16 03CA170B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000085DE80: BF870292
	v_fma_f32 v10, -v10, v20, v18                              // 00000085DE84: D613000A 244A290A
	v_fma_f32 v23, -v19, v15, 1.0                              // 00000085DE8C: D6130017 23CA1F13
	v_fmac_f32_e32 v16, v21, v13                               // 00000085DE94: 56201B15
	v_div_scale_f32 v21, s1, 1.0, v12, 1.0                     // 00000085DE98: D6FC0115 03CA18F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085DEA0: BF870193
	v_fmac_f32_e32 v15, v23, v15                               // 00000085DEA4: 561E1F17
	v_fma_f32 v6, -v6, v16, v17                                // 00000085DEA8: D6130006 24462106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085DEB0: BF8701A1
	v_div_fmas_f32 v6, v6, v13, v16                            // 00000085DEB4: D6370006 04421B06
	s_mov_b32 vcc_lo, s0                                       // 00000085DEBC: BEEA0000
	v_mul_f32_e32 v13, v21, v15                                // 00000085DEC0: 101A1F15
	v_div_scale_f32 v16, null, v9, v9, 1.0                     // 00000085DEC4: D6FC7C10 03CA1309
	v_div_fmas_f32 v10, v10, v14, v20                          // 00000085DECC: D637000A 04521D0A
	v_rcp_f32_e32 v14, v22                                     // 00000085DED4: 7E1C5516
	s_mov_b32 vcc_lo, s1                                       // 00000085DED8: BEEA0001
	v_div_fixup_f32 v6, v6, v7, 1.0                            // 00000085DEDC: D6270006 03CA0F06
	v_rcp_f32_e32 v17, v16                                     // 00000085DEE4: 7E225510
	v_div_fixup_f32 v7, v10, v8, 1.0                           // 00000085DEE8: D6270007 03CA110A
	v_add_f32_e32 v10, 1.0, v4                                 // 00000085DEF0: 061408F2
	v_fma_f32 v8, -v19, v13, v21                               // 00000085DEF4: D6130008 24561B13
	v_add_f32_e32 v4, v6, v6                                   // 00000085DEFC: 06080D06
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000085DF00: BF870314
	v_add_f32_e32 v6, v7, v7                                   // 00000085DF04: 060C0F07
	v_fma_f32 v7, -v22, v14, 1.0                               // 00000085DF08: D6130007 23CA1D16
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085DF10: BF870004
	v_fmac_f32_e32 v13, v8, v15                                // 00000085DF14: 561A1F08
	v_div_scale_f32 v8, null, v10, v10, 1.0                    // 00000085DF18: D6FC7C08 03CA150A
	v_div_scale_f32 v20, s2, 1.0, v10, 1.0                     // 00000085DF20: D6FC0214 03CA14F2
	s_clause 0x1                                               // 00000085DF28: BF850001
	global_store_b32 v[0:1], v4, off                           // 00000085DF2C: DC6A0000 007C0400
	global_store_b32 v[2:3], v6, off                           // 00000085DF34: DC6A0000 007C0602
	v_fma_f32 v3, -v16, v17, 1.0                               // 00000085DF3C: D6130003 23CA2310
	v_div_scale_f32 v6, s0, 1.0, v11, 1.0                      // 00000085DF44: D6FC0006 03CA16F2
	v_fmac_f32_e32 v14, v7, v14                                // 00000085DF4C: 561C1D07
	v_rcp_f32_e32 v7, v8                                       // 00000085DF50: 7E0E5508
	v_fma_f32 v2, -v19, v13, v21                               // 00000085DF54: D6130002 24561B13
	v_fmac_f32_e32 v17, v3, v17                                // 00000085DF5C: 56222303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 00000085DF60: BF8702A2
	v_div_fmas_f32 v2, v2, v15, v13                            // 00000085DF64: D6370002 04361F02
	v_div_scale_f32 v15, s1, 1.0, v9, 1.0                      // 00000085DF6C: D6FC010F 03CA12F2
	v_fma_f32 v3, -v8, v7, 1.0                                 // 00000085DF74: D6130003 23CA0F08
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085DF7C: BF870113
	v_div_fixup_f32 v2, v2, v12, 1.0                           // 00000085DF80: D6270002 03CA1902
	v_fmac_f32_e32 v7, v3, v7                                  // 00000085DF88: 560E0F03
	.long 0xd7006a03                                           // 00000085DF8C: D7006A03
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000085DF90: 02000900
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085DF94: BF870193
	v_add_f32_e32 v21, v2, v2                                  // 00000085DF98: 062A0502
	v_dual_mul_f32 v23, v20, v7 :: v_dual_add_f32 v18, 1.0, v5 // 00000085DF9C: C8C80F14 17120AF2
	v_mul_f32_e32 v5, v6, v14                                  // 00000085DFA4: 100A1D06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085DFA8: BF870112
	v_div_scale_f32 v13, null, v18, v18, 1.0                   // 00000085DFAC: D6FC7C0D 03CA2512
	v_fma_f32 v4, -v22, v5, v6                                 // 00000085DFB4: D6130004 241A0B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085DFBC: BF870092
	v_rcp_f32_e32 v12, v13                                     // 00000085DFC0: 7E18550D
	v_fmac_f32_e32 v5, v4, v14                                 // 00000085DFC4: 560A1D04
	v_add_co_ci_u32_e64 v4, null, s5, v1, vcc_lo               // 00000085DFC8: D5207C04 01AA0205
	s_mov_b32 vcc_lo, s0                                       // 00000085DFD0: BEEA0000
	v_mad_u64_u32 v[0:1], null, s16, 12, v[0:1]                // 00000085DFD4: D6FE7C00 04011810
	v_fma_f32 v6, -v22, v5, v6                                 // 00000085DFDC: D6130006 241A0B16
	v_div_scale_f32 v22, s3, 1.0, v18, 1.0                     // 00000085DFE4: D6FC0316 03CA24F2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085DFEC: BF870195
	v_fma_f32 v24, -v13, v12, 1.0                              // 00000085DFF0: D6130018 23CA190D
	v_div_fmas_f32 v5, v6, v14, v5                             // 00000085DFF8: D6370005 04161D06
	s_mov_b32 vcc_lo, s1                                       // 00000085E000: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085E004: BF870112
	v_dual_fmac_f32 v12, v24, v12 :: v_dual_mul_f32 v19, v15, v17// 00000085E008: C8061918 0C12230F
	v_div_fixup_f32 v5, v5, v11, 1.0                           // 00000085E010: D6270005 03CA1705
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085E018: BF870192
	v_mul_f32_e32 v14, v22, v12                                // 00000085E01C: 101C1916
	v_fma_f32 v2, -v16, v19, v15                               // 00000085E020: D6130002 243E2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085E028: BF870121
	v_fmac_f32_e32 v19, v2, v17                                // 00000085E02C: 56262302
	v_fma_f32 v2, -v8, v23, v20                                // 00000085E030: D6130002 24522F08
	v_fma_f32 v6, -v16, v19, v15                               // 00000085E038: D6130006 243E2710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085E040: BF870112
	v_fmac_f32_e32 v23, v2, v7                                 // 00000085E044: 562E0F02
	v_div_fmas_f32 v2, v6, v17, v19                            // 00000085E048: D6370002 044E2306
	v_fma_f32 v6, -v13, v14, v22                               // 00000085E050: D6130006 245A1D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000085E058: BF8701A3
	v_fma_f32 v8, -v8, v23, v20                                // 00000085E05C: D6130008 24522F08
	s_mov_b32 vcc_lo, s2                                       // 00000085E064: BEEA0002
	v_div_fixup_f32 v9, v2, v9, 1.0                            // 00000085E068: D6270009 03CA1302
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000085E070: BF8701C3
	v_fmac_f32_e32 v14, v6, v12                                // 00000085E074: 561C1906
	v_mad_u64_u32 v[1:2], null, s17, 12, v[1:2]                // 00000085E078: D6FE7C01 04051811
	v_div_fmas_f32 v6, v8, v7, v23                             // 00000085E080: D6370006 045E0F08
	s_mov_b32 vcc_lo, s3                                       // 00000085E088: BEEA0003
	v_fma_f32 v2, -v13, v14, v22                               // 00000085E08C: D6130002 245A1D0D
	v_add_f32_e32 v13, v9, v9                                  // 00000085E094: 061A1309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085E098: BF870193
	v_div_fixup_f32 v7, v6, v10, 1.0                           // 00000085E09C: D6270007 03CA1506
	v_div_fmas_f32 v2, v2, v12, v14                            // 00000085E0A4: D6370002 043A1902
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085E0AC: BF870112
	v_add_f32_e32 v12, v7, v7                                  // 00000085E0B0: 06180F07
	v_div_fixup_f32 v2, v2, v18, 1.0                           // 00000085E0B4: D6270002 03CA2502
	v_add_f32_e32 v11, v5, v5                                  // 00000085E0BC: 06160B05
	.long 0xd7006a05                                           // 00000085E0C0: D7006A05
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 00000085E0C4: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085E0C8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s5, v4, vcc_lo               // 00000085E0CC: D5207C06 01AA0805
	.long 0xd7006a07                                           // 00000085E0D4: D7006A07
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 00000085E0D8: 02000900
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 00000085E0DC: D5207C08 01AA0205
	s_delay_alu instid0(VALU_DEP_4)                            // 00000085E0E4: BF870004
	.long 0xd7006a09                                           // 00000085E0E8: D7006A09
	v_cndmask_b32_e32 v0, v5, v4, vcc_lo                       // 00000085E0EC: 02000905
	v_add_f32_e32 v2, v2, v2                                   // 00000085E0F0: 06040502
	v_add_co_ci_u32_e64 v10, null, s5, v6, vcc_lo              // 00000085E0F4: D5207C0A 01AA0C05
	s_clause 0x4                                               // 00000085E0FC: BF850004
	global_store_b32 v[3:4], v21, off                          // 00000085E100: DC6A0000 007C1503
	global_store_b32 v[0:1], v11, off                          // 00000085E108: DC6A0000 007C0B00
	global_store_b32 v[5:6], v13, off                          // 00000085E110: DC6A0000 007C0D05
	global_store_b32 v[7:8], v12, off                          // 00000085E118: DC6A0000 007C0C07
	global_store_b32 v[9:10], v2, off                          // 00000085E120: DC6A0000 007C0209
	s_endpgm                                                   // 00000085E128: BFB00000
		...

