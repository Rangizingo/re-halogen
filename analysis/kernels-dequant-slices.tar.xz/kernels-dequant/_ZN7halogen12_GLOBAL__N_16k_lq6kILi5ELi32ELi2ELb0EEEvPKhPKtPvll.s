00000000005a0400 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_load_b256 s[4:11], s[0:1], null                          // 0000005A0400: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 0000005A0408: BE830080
	v_bfe_u32 v5, v0, 5, 1                                     // 0000005A040C: D6100005 02050B00
	s_lshl_b64 s[14:15], s[2:3], 2                             // 0000005A0414: 848E8202
	v_dual_mov_b32 v12, 0 :: v_dual_and_b32 v7, 31, v0         // 0000005A0418: CA240080 0C06009F
	v_mov_b32_e32 v14, 0                                       // 0000005A0420: 7E1C0280
	v_lshrrev_b32_e32 v6, 6, v0                                // 0000005A0424: 320C0086
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000005A0428: CA100080 0A0A0080
	v_mov_b32_e32 v13, 0                                       // 0000005A0430: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 0000005A0434: BF89FC07
	s_ashr_i32 s12, s11, 31                                    // 0000005A0438: 860C9F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A043C: BF870499
	s_lshr_b32 s12, s12, 28                                    // 0000005A0440: 850C9C0C
	s_add_u32 s12, s10, s12                                    // 0000005A0444: 800C0C0A
	s_addc_u32 s13, s11, 0                                     // 0000005A0448: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A044C: BF870499
	s_lshr_b64 s[16:17], s[12:13], 4                           // 0000005A0450: 8590840C
	s_add_i32 s2, s16, 1                                       // 0000005A0454: 81028110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000005A0458: BF870499
	s_lshr_b32 s12, s2, 31                                     // 0000005A045C: 850C9F02
	s_add_i32 s2, s2, s12                                      // 0000005A0460: 81020C02
	s_load_b64 s[12:13], s[0:1], 0x20                          // 0000005A0464: F4040300 F8000020
	s_ashr_i32 s2, s2, 1                                       // 0000005A046C: 86028102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A0470: BF870099
	.long 0xd72c0001                                           // 0000005A0474: D72C0001
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000005A0478: 02020A02
	v_add_nc_u32_e32 v2, s2, v1                                // 0000005A047C: 4A040202
	v_add_nc_u32_e32 v8, v1, v7                                // 0000005A0480: 4A100F01
	s_mov_b32 s2, exec_lo                                      // 0000005A0484: BE82007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A0488: BF870092
	v_min_i32_e32 v9, s16, v2                                  // 0000005A048C: 22120410
	.long 0xd4c1007e                                           // 0000005A0490: D4C1007E
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 0000005A0494: 02021308
	s_cbranch_execz 491                                        // 0000005A0498: BFA501EB <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll+0x848>
	.long 0xd7000001                                           // 0000005A049C: D7000001
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 0000005A04A0: 02020C0E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A04A4: BF870001
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 0000005A04A8: D5207C02 0001000F
	s_ashr_i32 s0, s11, 31                                     // 0000005A04B0: 86009F0B
	v_dual_mov_b32 v10, 0 :: v_dual_lshlrev_b32 v3, 4, v8      // 0000005A04B4: CA220080 0A021084
	s_lshr_b32 s0, s0, 24                                      // 0000005A04BC: 85009800
	s_waitcnt lgkmcnt(0)                                       // 0000005A04C0: BF89FC07
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005A04C4: 7CA8020C
	s_add_u32 s0, s10, s0                                      // 0000005A04C8: 8000000A
	s_addc_u32 s1, s11, 0                                      // 0000005A04CC: 8201800B
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 0000005A04D0: CA100080 0E0C0080
	s_ashr_i64 s[0:1], s[0:1], 8                               // 0000005A04D8: 86808800
	v_dual_cndmask_b32 v2, 0, v2 :: v_dual_cndmask_b32 v1, 0, v1// 0000005A04DC: CA520480 02000280
	s_mulk_i32 s1, 0xd2                                        // 0000005A04E4: B80100D2
	s_mul_hi_u32 s16, s0, 0xd2                                 // 0000005A04E8: 9690FF00 000000D2
	s_mulk_i32 s0, 0xd2                                        // 0000005A04F0: B80000D2
	s_add_i32 s16, s16, s1                                     // 0000005A04F4: 81100110
	.long 0xd72c000b                                           // 0000005A04F8: D72C000B
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000005A04FC: 02020400
	.long 0xd72c0004                                           // 0000005A0500: D72C0004
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000005A0504: 02020210
	v_mad_u64_u32 v[1:2], null, s0, v1, s[4:5]                 // 0000005A0508: D6FE7C01 00120200
	v_mov_b32_e32 v12, 0                                       // 0000005A0510: 7E180280
	s_mul_i32 s0, s11, 6                                       // 0000005A0514: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 0000005A0518: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000005A051C: 8484820A
	s_add_i32 s16, s1, s0                                      // 0000005A0520: 81100001
	s_mul_i32 s17, s10, 6                                      // 0000005A0524: 9611860A
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000005A0528: 848A810A
	v_add3_u32 v2, v4, v2, v11                                 // 0000005A052C: D6550002 042E0504
	v_mov_b32_e32 v11, 0                                       // 0000005A0534: 7E160280
	v_ashrrev_i32_e32 v15, 4, v8                               // 0000005A0538: 341E1084
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000005A053C: 3408069F
	v_bfe_u32 v17, v8, 3, 1                                    // 0000005A0540: D6100011 02050708
	v_and_b32_e32 v18, 32, v3                                  // 0000005A0548: 362406A0
	v_and_b32_e32 v16, 15, v8                                  // 0000005A054C: 3620108F
	.long 0xd72c000f                                           // 0000005A0550: D72C000F
	v_cndmask_b32_e32 v1, 0xd2, v15, vcc_lo                    // 0000005A0554: 02021EFF 000000D2
	.long 0xd73c0017                                           // 0000005A055C: D73C0017
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000005A0560: 02020681
	v_lshlrev_b32_e32 v20, 6, v17                              // 0000005A0564: 30282286
	v_lshlrev_b32_e32 v17, 5, v17                              // 0000005A0568: 30222285
	v_and_b32_e32 v19, 16, v3                                  // 0000005A056C: 36260690
	v_ashrrev_i32_e32 v4, 31, v15                              // 0000005A0570: 34081E9F
	.long 0xd7006a19                                           // 0000005A0574: D7006A19
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 0000005A0578: 02021F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A057C: BF870111
	v_add_co_ci_u32_e64 v26, null, v2, v4, vcc_lo              // 0000005A0580: D5207C1A 01AA0902
	.long 0xd7006a04                                           // 0000005A0588: D7006A04
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000005A058C: 02022919
	.long 0xd7000011                                           // 0000005A0590: D7000011
	v_cndmask_b32_e32 v1, v25, v17, vcc_lo                     // 0000005A0594: 02022319
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005A0598: BF870193
	v_add_co_ci_u32_e64 v20, null, 0, v26, vcc_lo              // 0000005A059C: D5207C14 01AA3480
	.long 0xd7006a04                                           // 0000005A05A4: D7006A04
	v_cndmask_b32_e32 v1, v4, v18, vcc_lo                      // 0000005A05A8: 02022504
	v_add_co_ci_u32_e64 v18, null, 0, v26, s0                  // 0000005A05AC: D5207C12 00023480
	.long 0xd700010f                                           // 0000005A05B4: D700010F
	v_cndmask_b32_e32 v1, v25, v16, vcc_lo                     // 0000005A05B8: 02022119
	.long 0xd7000011                                           // 0000005A05BC: D7000011
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 0000005A05C0: 02022711
	v_add_co_ci_u32_e64 v20, null, 0, v20, vcc_lo              // 0000005A05C4: D5207C14 01AA2880
	v_add_co_ci_u32_e64 v16, null, 0, v26, s1                  // 0000005A05CC: D5207C10 00063480
	v_add_co_ci_u32_e64 v18, null, 0, v18, s0                  // 0000005A05D4: D5207C12 00022480
	.long 0xd7006a13                                           // 0000005A05DC: D7006A13
	v_cndmask_b32_e32 v1, v4, v19, vcc_lo                      // 0000005A05E0: 02022704
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A05E4: BF870001
	v_add_co_ci_u32_e64 v20, null, 0, v20, vcc_lo              // 0000005A05E8: D5207C14 01AA2880
	s_clause 0x3                                               // 0000005A05F0: BF850003
	global_load_i8 v4, v[15:16], off offset:192                // 0000005A05F4: DC4600C0 047C000F
	global_load_b128 v[15:18], v[17:18], off offset:128        // 0000005A05FC: DC5E0080 0F7C0011
	global_load_b128 v[19:22], v[19:20], off                   // 0000005A0604: DC5E0000 137C0013
	global_load_d16_b16 v63, v[25:26], off offset:208          // 0000005A060C: DC8200D0 3F7C0019
	.long 0xd7006a2b                                           // 0000005A0614: D7006A2B
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000005A0618: 02022E06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005A061C: BF870111
	v_add_co_ci_u32_e64 v44, null, s7, v24, vcc_lo             // 0000005A0620: D5207C2C 01AA3007
	.long 0xd7006a2f                                           // 0000005A0628: D7006A2F
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 0000005A062C: 0200152B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A0630: BF8700A1
	v_add_co_ci_u32_e64 v48, null, s11, v44, vcc_lo            // 0000005A0634: D5207C30 01AA580B
	.long 0xd7006a33                                           // 0000005A063C: D7006A33
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 0000005A0640: 0200092B
	v_add_co_ci_u32_e64 v52, null, s5, v44, vcc_lo             // 0000005A0644: D5207C34 01AA5805
	.long 0xd7006a37                                           // 0000005A064C: D7006A37
	v_cndmask_b32_e32 v0, v43, v17, vcc_lo                     // 0000005A0650: 0200232B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005A0654: BF870211
	v_add_co_ci_u32_e64 v56, null, s16, v44, vcc_lo            // 0000005A0658: D5207C38 01AA5810
	.long 0xd7006a3b                                           // 0000005A0660: D7006A3B
	v_cndmask_b32_e32 v0, v51, v4, vcc_lo                      // 0000005A0664: 02000933
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005A0668: BF870001
	v_add_co_ci_u32_e64 v60, null, s5, v52, vcc_lo             // 0000005A066C: D5207C3C 01AA6805
	s_clause 0x9                                               // 0000005A0674: BF850009
	global_load_b128 v[23:26], v[43:44], off                   // 0000005A0678: DC5E0000 177C002B
	global_load_b128 v[27:30], v[47:48], off                   // 0000005A0680: DC5E0000 1B7C002F
	global_load_b128 v[31:34], v[51:52], off                   // 0000005A0688: DC5E0000 1F7C0033
	global_load_b128 v[35:38], v[55:56], off                   // 0000005A0690: DC5E0000 237C0037
	global_load_b128 v[39:42], v[59:60], off                   // 0000005A0698: DC5E0000 277C003B
	global_load_b128 v[43:46], v[43:44], off offset:16         // 0000005A06A0: DC5E0010 2B7C002B
	global_load_b128 v[47:50], v[47:48], off offset:16         // 0000005A06A8: DC5E0010 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:16         // 0000005A06B0: DC5E0010 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:16         // 0000005A06B8: DC5E0010 377C0037
	global_load_b128 v[59:62], v[59:60], off offset:16         // 0000005A06C0: DC5E0010 3B7C003B
	s_waitcnt vmcnt(13)                                        // 0000005A06C8: BF8937F7
	v_cvt_f32_i32_e32 v4, v4                                   // 0000005A06CC: 7E080B04
	s_waitcnt vmcnt(10)                                        // 0000005A06D0: BF892BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005A06D4: BF870131
	v_fma_mix_f32 v4, v63, v4, neg(0) op_sel_hi:[1,0,0]        // 0000005A06D8: CC200004 8A02093F
	v_and_b32_e32 v65, 6, v8                                   // 0000005A06E0: 36821086
	v_and_b32_e32 v64, 4, v8                                   // 0000005A06E4: 36801084
	v_or_b32_e32 v67, 8, v65                                   // 0000005A06E8: 38868288
	v_or_b32_e32 v69, 16, v65                                  // 0000005A06EC: 388A8290
	v_or_b32_e32 v71, 24, v65                                  // 0000005A06F0: 388E8298
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005A06F4: BF870004
	v_or_b32_e32 v66, 8, v64                                   // 0000005A06F8: 38848088
	v_or_b32_e32 v68, 16, v64                                  // 0000005A06FC: 38888090
	v_or_b32_e32 v70, 24, v64                                  // 0000005A0700: 388C8098
	v_lshrrev_b32_e32 v72, v65, v15                            // 0000005A0704: 32901F41
	v_lshrrev_b32_e32 v73, v67, v15                            // 0000005A0708: 32921F43
	v_lshrrev_b32_e32 v74, v69, v15                            // 0000005A070C: 32941F45
	v_lshrrev_b32_e32 v15, v71, v15                            // 0000005A0710: 321E1F47
	v_lshrrev_b32_e32 v75, v65, v16                            // 0000005A0714: 32962141
	v_lshrrev_b32_e32 v76, v67, v16                            // 0000005A0718: 32982143
	v_lshrrev_b32_e32 v77, v69, v16                            // 0000005A071C: 329A2145
	v_lshrrev_b32_e32 v16, v71, v16                            // 0000005A0720: 32202147
	v_lshrrev_b32_e32 v78, v65, v17                            // 0000005A0724: 329C2341
	v_lshrrev_b32_e32 v79, v67, v17                            // 0000005A0728: 329E2343
	v_lshrrev_b32_e32 v80, v69, v17                            // 0000005A072C: 32A02345
	v_lshrrev_b32_e32 v17, v71, v17                            // 0000005A0730: 32222347
	v_lshrrev_b32_e32 v65, v65, v18                            // 0000005A0734: 32822541
	v_lshrrev_b32_e32 v67, v67, v18                            // 0000005A0738: 32862543
	v_lshrrev_b32_e32 v69, v69, v18                            // 0000005A073C: 328A2545
	v_lshrrev_b32_e32 v18, v71, v18                            // 0000005A0740: 32242547
	v_bfe_u32 v63, v19, v64, 4                                 // 0000005A0744: D610003F 02128113
	v_lshlrev_b32_e32 v71, 4, v72                              // 0000005A074C: 308E9084
	v_bfe_u32 v72, v19, v66, 4                                 // 0000005A0750: D6100048 02128513
	v_bfe_u32 v81, v19, v68, 4                                 // 0000005A0758: D6100051 02128913
	v_bfe_u32 v19, v19, v70, 4                                 // 0000005A0760: D6100013 02128D13
	v_lshlrev_b32_e32 v15, 4, v15                              // 0000005A0768: 301E1E84
	v_bfe_u32 v82, v20, v64, 4                                 // 0000005A076C: D6100052 02128114
	v_lshlrev_b32_e32 v75, 4, v75                              // 0000005A0774: 30969684
	v_bfe_u32 v84, v20, v68, 4                                 // 0000005A0778: D6100054 02128914
	v_bfe_u32 v86, v21, v66, 4                                 // 0000005A0780: D6100056 02128515
	v_and_or_b32 v15, v15, 48, v19                             // 0000005A0788: D657000F 044D610F
	v_bfe_u32 v87, v21, v68, 4                                 // 0000005A0790: D6100057 02128915
	v_and_or_b32 v19, v75, 48, v82                             // 0000005A0798: D6570013 0549614B
	v_lshlrev_b32_e32 v17, 4, v17                              // 0000005A07A0: 30222284
	v_lshlrev_b32_e32 v65, 4, v65                              // 0000005A07A4: 30828284
	v_bfe_u32 v68, v22, v68, 4                                 // 0000005A07A8: D6100044 02128916
	v_lshlrev_b32_e32 v69, 4, v69                              // 0000005A07B0: 308A8A84
	v_subrev_nc_u32_e32 v19, 32, v19                           // 0000005A07B4: 4E2626A0
	v_bfe_u32 v83, v20, v66, 4                                 // 0000005A07B8: D6100053 02128514
	v_bfe_u32 v20, v20, v70, 4                                 // 0000005A07C0: D6100014 02128D14
	v_lshlrev_b32_e32 v77, 4, v77                              // 0000005A07C8: 309A9A84
	v_lshlrev_b32_e32 v78, 4, v78                              // 0000005A07CC: 309C9C84
	v_cvt_f32_i32_e32 v19, v19                                 // 0000005A07D0: 7E260B13
	v_lshlrev_b32_e32 v79, 4, v79                              // 0000005A07D4: 309E9E84
	v_lshlrev_b32_e32 v80, 4, v80                              // 0000005A07D8: 30A0A084
	v_bfe_u32 v66, v22, v66, 4                                 // 0000005A07DC: D6100042 02128516
	v_lshlrev_b32_e32 v67, 4, v67                              // 0000005A07E4: 30868684
	v_mul_f32_e32 v19, v4, v19                                 // 0000005A07E8: 10262704
	v_bfe_u32 v85, v21, v64, 4                                 // 0000005A07EC: D6100055 02128115
	v_bfe_u32 v21, v21, v70, 4                                 // 0000005A07F4: D6100015 02128D15
	v_bfe_u32 v64, v22, v64, 4                                 // 0000005A07FC: D6100040 02128116
	v_bfe_u32 v22, v22, v70, 4                                 // 0000005A0804: D6100016 02128D16
	v_lshlrev_b32_e32 v18, 4, v18                              // 0000005A080C: 30242484
	v_and_or_b32 v63, v71, 48, v63                             // 0000005A0810: D657003F 04FD6147
	v_and_or_b32 v17, v17, 48, v21                             // 0000005A0818: D6570011 04556111
	v_and_or_b32 v21, v65, 48, v64                             // 0000005A0820: D6570015 05016141
	v_and_or_b32 v65, v69, 48, v68                             // 0000005A0828: D6570041 05116145
	v_and_or_b32 v75, v80, 48, v87                             // 0000005A0830: D657004B 055D6150
	v_and_or_b32 v64, v67, 48, v66                             // 0000005A0838: D6570040 05096143
	v_subrev_nc_u32_e32 v17, 32, v17                           // 0000005A0840: 4E2222A0
	v_subrev_nc_u32_e32 v21, 32, v21                           // 0000005A0844: 4E2A2AA0
	v_subrev_nc_u32_e32 v65, 32, v65                           // 0000005A0848: 4E8282A0
	v_and_or_b32 v18, v18, 48, v22                             // 0000005A084C: D6570012 04596112
	v_subrev_nc_u32_e32 v22, 32, v63                           // 0000005A0854: 4E2C7EA0
	v_cvt_f32_i32_e32 v17, v17                                 // 0000005A0858: 7E220B11
	v_lshlrev_b32_e32 v74, 4, v74                              // 0000005A085C: 30949484
	v_cvt_f32_i32_e32 v65, v65                                 // 0000005A0860: 7E820B41
	v_lshlrev_b32_e32 v16, 4, v16                              // 0000005A0864: 30202084
	v_cvt_f32_i32_e32 v21, v21                                 // 0000005A0868: 7E2A0B15
	v_dual_mul_f32 v17, v4, v17 :: v_dual_lshlrev_b32 v76, 4, v76// 0000005A086C: C8E22304 114C9884
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005A0874: BF870214
	v_mul_f32_e32 v65, v4, v65                                 // 0000005A0878: 10828304
	v_and_or_b32 v16, v16, 48, v20                             // 0000005A087C: D6570010 04516110
	v_and_or_b32 v71, v74, 48, v81                             // 0000005A0884: D6570047 0545614A
	v_and_or_b32 v20, v78, 48, v85                             // 0000005A088C: D6570014 0555614E
	v_and_or_b32 v74, v79, 48, v86                             // 0000005A0894: D657004A 0559614F
	v_mul_f32_e32 v21, v4, v21                                 // 0000005A089C: 102A2B04
	v_subrev_nc_u32_e32 v16, 32, v16                           // 0000005A08A0: 4E2020A0
	v_subrev_nc_u32_e32 v66, 32, v71                           // 0000005A08A4: 4E848EA0
	v_subrev_nc_u32_e32 v15, 32, v15                           // 0000005A08A8: 4E1E1EA0
	v_subrev_nc_u32_e32 v20, 32, v20                           // 0000005A08AC: 4E2828A0
	v_subrev_nc_u32_e32 v69, 32, v74                           // 0000005A08B0: 4E8A94A0
	v_cvt_f32_i32_e32 v16, v16                                 // 0000005A08B4: 7E200B10
	v_lshlrev_b32_e32 v73, 4, v73                              // 0000005A08B8: 30929284
	v_subrev_nc_u32_e32 v64, 32, v64                           // 0000005A08BC: 4E8080A0
	v_subrev_nc_u32_e32 v18, 32, v18                           // 0000005A08C0: 4E2424A0
	v_cvt_f32_i32_e32 v22, v22                                 // 0000005A08C4: 7E2C0B16
	v_mul_f32_e32 v16, v4, v16                                 // 0000005A08C8: 10202104
	v_and_or_b32 v70, v73, 48, v72                             // 0000005A08CC: D6570046 05216149
	v_and_or_b32 v72, v76, 48, v83                             // 0000005A08D4: D6570048 054D614C
	v_and_or_b32 v73, v77, 48, v84                             // 0000005A08DC: D6570049 0551614D
	v_cvt_f32_i32_e32 v66, v66                                 // 0000005A08E4: 7E840B42
	v_cvt_f32_i32_e32 v15, v15                                 // 0000005A08E8: 7E1E0B0F
	v_subrev_nc_u32_e32 v63, 32, v70                           // 0000005A08EC: 4E7E8CA0
	v_subrev_nc_u32_e32 v67, 32, v72                           // 0000005A08F0: 4E8690A0
	v_subrev_nc_u32_e32 v68, 32, v73                           // 0000005A08F4: 4E8892A0
	v_subrev_nc_u32_e32 v70, 32, v75                           // 0000005A08F8: 4E8C96A0
	v_cvt_f32_i32_e32 v20, v20                                 // 0000005A08FC: 7E280B14
	v_cvt_f32_i32_e32 v63, v63                                 // 0000005A0900: 7E7E0B3F
	v_cvt_f32_i32_e32 v67, v67                                 // 0000005A0904: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 0000005A0908: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 0000005A090C: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 0000005A0910: 7E8C0B46
	v_cvt_f32_i32_e32 v64, v64                                 // 0000005A0914: 7E800B40
	v_cvt_f32_i32_e32 v18, v18                                 // 0000005A0918: 7E240B12
	v_mul_f32_e32 v22, v4, v22                                 // 0000005A091C: 102C2D04
	v_dual_mul_f32 v63, v4, v63 :: v_dual_add_nc_u32 v8, 32, v8// 0000005A0920: C8E07F04 3F0810A0
	v_mul_f32_e32 v67, v4, v67                                 // 0000005A0928: 10868704
	v_dual_mul_f32 v68, v4, v68 :: v_dual_add_nc_u32 v3, 0x200, v3// 0000005A092C: C8E08904 440206FF 00000200
	v_mul_f32_e32 v66, v4, v66                                 // 0000005A0938: 10848504
	v_mul_f32_e32 v15, v4, v15                                 // 0000005A093C: 101E1F04
	v_mul_f32_e32 v20, v4, v20                                 // 0000005A0940: 10282904
	v_mul_f32_e32 v69, v4, v69                                 // 0000005A0944: 108A8B04
	v_mul_f32_e32 v70, v4, v70                                 // 0000005A0948: 108C8D04
	v_mul_f32_e32 v64, v4, v64                                 // 0000005A094C: 10808104
	v_mul_f32_e32 v4, v4, v18                                  // 0000005A0950: 10082504
	v_bfe_u32 v18, v22, 16, 1                                  // 0000005A0954: D6100012 02052116
	v_bfe_u32 v71, v63, 16, 1                                  // 0000005A095C: D6100047 0205213F
	v_bfe_u32 v72, v66, 16, 1                                  // 0000005A0964: D6100048 02052142
	v_bfe_u32 v74, v19, 16, 1                                  // 0000005A096C: D610004A 02052113
	v_bfe_u32 v78, v20, 16, 1                                  // 0000005A0974: D610004E 02052114
	v_bfe_u32 v82, v21, 16, 1                                  // 0000005A097C: D6100052 02052115
	v_add3_u32 v18, v22, v18, 0x7fff                           // 0000005A0984: D6550012 03FE2516 00007FFF
	v_bfe_u32 v73, v15, 16, 1                                  // 0000005A0990: D6100049 0205210F
	v_bfe_u32 v75, v67, 16, 1                                  // 0000005A0998: D610004B 02052143
	v_bfe_u32 v76, v68, 16, 1                                  // 0000005A09A0: D610004C 02052144
	v_bfe_u32 v79, v69, 16, 1                                  // 0000005A09A8: D610004F 02052145
	v_bfe_u32 v83, v64, 16, 1                                  // 0000005A09B0: D6100053 02052140
	v_add3_u32 v22, v63, v71, 0x7fff                           // 0000005A09B8: D6550016 03FE8F3F 00007FFF
	v_add3_u32 v63, v66, v72, 0x7fff                           // 0000005A09C4: D655003F 03FE9142 00007FFF
	v_add3_u32 v19, v19, v74, 0x7fff                           // 0000005A09D0: D6550013 03FE9513 00007FFF
	v_add3_u32 v20, v20, v78, 0x7fff                           // 0000005A09DC: D6550014 03FE9D14 00007FFF
	v_add3_u32 v21, v21, v82, 0x7fff                           // 0000005A09E8: D6550015 03FEA515 00007FFF
	.long 0x7e2c3992                                           // 0000005A09F4: 7E2C3992
	v_add3_u32 v15, v15, v73, 0x7fff                           // 0000005A09F8: D655000F 03FE930F 00007FFF
	v_add3_u32 v66, v67, v75, 0x7fff                           // 0000005A0A04: D6550042 03FE9743 00007FFF
	v_add3_u32 v67, v68, v76, 0x7fff                           // 0000005A0A10: D6550043 03FE9944 00007FFF
	v_add3_u32 v68, v69, v79, 0x7fff                           // 0000005A0A1C: D6550044 03FE9F45 00007FFF
	v_add3_u32 v64, v64, v83, 0x7fff                           // 0000005A0A28: D6550040 03FEA740 00007FFF
	.long 0x7e1e39bf                                           // 0000005A0A34: 7E1E39BF
	.long 0x7e843993                                           // 0000005A0A38: 7E843993
	.long 0x7e883994                                           // 0000005A0A3C: 7E883994
	.long 0x7e803995                                           // 0000005A0A40: 7E803995
	s_waitcnt vmcnt(9)                                         // 0000005A0A44: BF8927F7
	v_dot2_f32_bf16 v18, v23, v22, 0                           // 0000005A0A48: CC1A4012 1A022D17
	s_waitcnt vmcnt(8)                                         // 0000005A0A50: BF8923F7
	v_dot2_f32_bf16 v19, v27, v22, 0                           // 0000005A0A54: CC1A4013 1A022D1B
	s_waitcnt vmcnt(7)                                         // 0000005A0A5C: BF891FF7
	v_dot2_f32_bf16 v20, v31, v22, 0                           // 0000005A0A60: CC1A4014 1A022D1F
	s_waitcnt vmcnt(6)                                         // 0000005A0A68: BF891BF7
	v_dot2_f32_bf16 v21, v35, v22, 0                           // 0000005A0A6C: CC1A4015 1A022D23
	s_waitcnt vmcnt(5)                                         // 0000005A0A74: BF8917F7
	v_dot2_f32_bf16 v22, v39, v22, 0                           // 0000005A0A78: CC1A4016 1A022D27
	v_bfe_u32 v77, v16, 16, 1                                  // 0000005A0A80: D610004D 02052110
	v_dot2_f32_bf16 v18, v24, v15, v18                         // 0000005A0A88: CC1A4012 1C4A1F18
	v_dot2_f32_bf16 v19, v28, v15, v19                         // 0000005A0A90: CC1A4013 1C4E1F1C
	v_dot2_f32_bf16 v20, v32, v15, v20                         // 0000005A0A98: CC1A4014 1C521F20
	v_dot2_f32_bf16 v21, v36, v15, v21                         // 0000005A0AA0: CC1A4015 1C561F24
	v_dot2_f32_bf16 v15, v40, v15, v22                         // 0000005A0AA8: CC1A400F 1C5A1F28
	v_add3_u32 v16, v16, v77, 0x7fff                           // 0000005A0AB0: D6550010 03FE9B10 00007FFF
	v_bfe_u32 v80, v70, 16, 1                                  // 0000005A0ABC: D6100050 02052146
	.long 0x7e2039c3                                           // 0000005A0AC4: 7E2039C3
	v_dot2_f32_bf16 v18, v25, v66, v18                         // 0000005A0AC8: CC1A4012 1C4A8519
	v_dot2_f32_bf16 v19, v29, v66, v19                         // 0000005A0AD0: CC1A4013 1C4E851D
	v_dot2_f32_bf16 v20, v33, v66, v20                         // 0000005A0AD8: CC1A4014 1C528521
	v_dot2_f32_bf16 v21, v37, v66, v21                         // 0000005A0AE0: CC1A4015 1C568525
	v_dot2_f32_bf16 v15, v41, v66, v15                         // 0000005A0AE8: CC1A400F 1C3E8529
	v_bfe_u32 v81, v17, 16, 1                                  // 0000005A0AF0: D6100051 02052111
	v_add3_u32 v69, v70, v80, 0x7fff                           // 0000005A0AF8: D6550045 03FEA146 00007FFF
	v_dot2_f32_bf16 v18, v26, v16, v18                         // 0000005A0B04: CC1A4012 1C4A211A
	v_dot2_f32_bf16 v19, v30, v16, v19                         // 0000005A0B0C: CC1A4013 1C4E211E
	v_dot2_f32_bf16 v20, v34, v16, v20                         // 0000005A0B14: CC1A4014 1C522122
	v_dot2_f32_bf16 v21, v38, v16, v21                         // 0000005A0B1C: CC1A4015 1C562126
	v_dot2_f32_bf16 v15, v42, v16, v15                         // 0000005A0B24: CC1A400F 1C3E212A
	v_add3_u32 v17, v17, v81, 0x7fff                           // 0000005A0B2C: D6550011 03FEA311 00007FFF
	v_bfe_u32 v84, v65, 16, 1                                  // 0000005A0B38: D6100054 02052141
	.long 0x7e2239c5                                           // 0000005A0B40: 7E2239C5
	s_waitcnt vmcnt(4)                                         // 0000005A0B44: BF8913F7
	v_dot2_f32_bf16 v16, v43, v68, v18                         // 0000005A0B48: CC1A4010 1C4A892B
	s_waitcnt vmcnt(3)                                         // 0000005A0B50: BF890FF7
	v_dot2_f32_bf16 v18, v47, v68, v19                         // 0000005A0B54: CC1A4012 1C4E892F
	s_waitcnt vmcnt(2)                                         // 0000005A0B5C: BF890BF7
	v_dot2_f32_bf16 v19, v51, v68, v20                         // 0000005A0B60: CC1A4013 1C528933
	s_waitcnt vmcnt(1)                                         // 0000005A0B68: BF8907F7
	v_dot2_f32_bf16 v20, v55, v68, v21                         // 0000005A0B6C: CC1A4014 1C568937
	s_waitcnt vmcnt(0)                                         // 0000005A0B74: BF8903F7
	v_dot2_f32_bf16 v15, v59, v68, v15                         // 0000005A0B78: CC1A400F 1C3E893B
	v_bfe_u32 v85, v4, 16, 1                                   // 0000005A0B80: D6100055 02052104
	v_add3_u32 v65, v65, v84, 0x7fff                           // 0000005A0B88: D6550041 03FEA941 00007FFF
	v_dot2_f32_bf16 v16, v44, v17, v16                         // 0000005A0B94: CC1A4010 1C42232C
	v_dot2_f32_bf16 v18, v48, v17, v18                         // 0000005A0B9C: CC1A4012 1C4A2330
	v_dot2_f32_bf16 v19, v52, v17, v19                         // 0000005A0BA4: CC1A4013 1C4E2334
	v_dot2_f32_bf16 v20, v56, v17, v20                         // 0000005A0BAC: CC1A4014 1C522338
	v_dot2_f32_bf16 v15, v60, v17, v15                         // 0000005A0BB4: CC1A400F 1C3E233C
	v_add3_u32 v4, v4, v85, 0x7fff                             // 0000005A0BBC: D6550004 03FEAB04 00007FFF
	.long 0x7e0839c1                                           // 0000005A0BC8: 7E0839C1
	v_dot2_f32_bf16 v16, v45, v64, v16                         // 0000005A0BCC: CC1A4010 1C42812D
	v_dot2_f32_bf16 v17, v49, v64, v18                         // 0000005A0BD4: CC1A4011 1C4A8131
	v_dot2_f32_bf16 v18, v53, v64, v19                         // 0000005A0BDC: CC1A4012 1C4E8135
	v_dot2_f32_bf16 v19, v57, v64, v20                         // 0000005A0BE4: CC1A4013 1C528139
	v_dot2_f32_bf16 v15, v61, v64, v15                         // 0000005A0BEC: CC1A400F 1C3E813D
	v_dot2_f32_bf16 v16, v46, v4, v16                          // 0000005A0BF4: CC1A4010 1C42092E
	v_dot2_f32_bf16 v17, v50, v4, v17                          // 0000005A0BFC: CC1A4011 1C460932
	v_dot2_f32_bf16 v18, v54, v4, v18                          // 0000005A0C04: CC1A4012 1C4A0936
	v_dot2_f32_bf16 v19, v58, v4, v19                          // 0000005A0C0C: CC1A4013 1C4E093A
	v_dot2_f32_bf16 v4, v62, v4, v15                           // 0000005A0C14: CC1A4004 1C3E093E
	v_cmp_ge_i32_e32 vcc_lo, v8, v9                            // 0000005A0C1C: 7C8C1308
	v_add_f32_e32 v10, v10, v16                                // 0000005A0C20: 0614210A
	v_dual_add_f32 v14, v14, v17 :: v_dual_add_f32 v13, v13, v18// 0000005A0C24: C908230E 0E0C250D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005A0C2C: BF8704A4
	v_dual_add_f32 v12, v12, v19 :: v_dual_add_f32 v11, v11, v4// 0000005A0C30: C908270C 0C0A090B
	s_or_b32 s3, vcc_lo, s3                                    // 0000005A0C38: 8C03036A
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 0000005A0C3C: 917E037E
	s_cbranch_execnz 65085                                     // 0000005A0C40: BFA6FE3D <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll+0x138>
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005A0C44: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A0C48: BF8700B9
	s_or_b32 exec_lo, exec_lo, s2                              // 0000005A0C4C: 8C7E027E
	.long 0xd71f0001                                           // 0000005A0C50: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005A0C54: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000005A0C58: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000005A0C5C: 3A040290
	v_xor_b32_e32 v15, 8, v1                                   // 0000005A0C60: 3A1E0288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005A0C64: BF8701A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000005A0C68: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000005A0C6C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000005A0C70: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000005A0C74: 021E1F01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005A0C78: BF870211
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000005A0C7C: 301E1E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000005A0C80: 30040482
	ds_bpermute_b32 v3, v2, v10                                // 0000005A0C84: DACC0000 03000A02
	s_waitcnt lgkmcnt(0)                                       // 0000005A0C8C: BF89FC07
	v_add_f32_e32 v3, v10, v3                                  // 0000005A0C90: 0606070A
	ds_bpermute_b32 v4, v2, v14                                // 0000005A0C94: DACC0000 04000E02
	ds_bpermute_b32 v8, v2, v13                                // 0000005A0C9C: DACC0000 08000D02
	ds_bpermute_b32 v9, v2, v12                                // 0000005A0CA4: DACC0000 09000C02
	ds_bpermute_b32 v2, v2, v11                                // 0000005A0CAC: DACC0000 02000B02
	ds_bpermute_b32 v10, v15, v3                               // 0000005A0CB4: DACC0000 0A00030F
	s_waitcnt lgkmcnt(4)                                       // 0000005A0CBC: BF89FC47
	v_add_f32_e32 v4, v14, v4                                  // 0000005A0CC0: 0608090E
	s_waitcnt lgkmcnt(2)                                       // 0000005A0CC4: BF89FC27
	v_dual_add_f32 v8, v13, v8 :: v_dual_add_f32 v9, v12, v9   // 0000005A0CC8: C908110D 0808130C
	s_waitcnt lgkmcnt(1)                                       // 0000005A0CD0: BF89FC17
	v_add_f32_e32 v2, v11, v2                                  // 0000005A0CD4: 0604050B
	ds_bpermute_b32 v11, v15, v4                               // 0000005A0CD8: DACC0000 0B00040F
	ds_bpermute_b32 v12, v15, v8                               // 0000005A0CE0: DACC0000 0C00080F
	ds_bpermute_b32 v13, v15, v9                               // 0000005A0CE8: DACC0000 0D00090F
	ds_bpermute_b32 v14, v15, v2                               // 0000005A0CF0: DACC0000 0E00020F
	v_xor_b32_e32 v15, 4, v1                                   // 0000005A0CF8: 3A1E0284
	s_waitcnt lgkmcnt(4)                                       // 0000005A0CFC: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 0000005A0D00: 06061503
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A0D04: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000005A0D08: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000005A0D0C: 021E1F01
	v_lshlrev_b32_e32 v15, 2, v15                              // 0000005A0D10: 301E1E82
	s_waitcnt lgkmcnt(3)                                       // 0000005A0D14: BF89FC37
	v_add_f32_e32 v4, v4, v11                                  // 0000005A0D18: 06081704
	s_waitcnt lgkmcnt(1)                                       // 0000005A0D1C: BF89FC17
	v_dual_add_f32 v8, v8, v12 :: v_dual_add_f32 v9, v9, v13   // 0000005A0D20: C9081908 08081B09
	s_waitcnt lgkmcnt(0)                                       // 0000005A0D28: BF89FC07
	v_add_f32_e32 v2, v2, v14                                  // 0000005A0D2C: 06041D02
	ds_bpermute_b32 v10, v15, v3                               // 0000005A0D30: DACC0000 0A00030F
	ds_bpermute_b32 v11, v15, v4                               // 0000005A0D38: DACC0000 0B00040F
	ds_bpermute_b32 v12, v15, v8                               // 0000005A0D40: DACC0000 0C00080F
	ds_bpermute_b32 v13, v15, v9                               // 0000005A0D48: DACC0000 0D00090F
	ds_bpermute_b32 v14, v15, v2                               // 0000005A0D50: DACC0000 0E00020F
	v_xor_b32_e32 v15, 2, v1                                   // 0000005A0D58: 3A1E0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005A0D5C: BF870151
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000005A0D60: 7C981EA0
	v_cndmask_b32_e32 v15, v1, v15, vcc_lo                     // 0000005A0D64: 021E1F01
	s_waitcnt lgkmcnt(3)                                       // 0000005A0D68: BF89FC37
	v_dual_add_f32 v3, v3, v10 :: v_dual_add_f32 v4, v4, v11   // 0000005A0D6C: C9081503 03041704
	s_waitcnt lgkmcnt(2)                                       // 0000005A0D74: BF89FC27
	v_dual_add_f32 v8, v8, v12 :: v_dual_lshlrev_b32 v15, 2, v15// 0000005A0D78: C9221908 080E1E82
	s_waitcnt lgkmcnt(0)                                       // 0000005A0D80: BF89FC07
	v_add_f32_e32 v10, v2, v14                                 // 0000005A0D84: 06141D02
	ds_bpermute_b32 v11, v15, v4                               // 0000005A0D88: DACC0000 0B00040F
	v_add_f32_e32 v9, v9, v13                                  // 0000005A0D90: 06121B09
	ds_bpermute_b32 v2, v15, v3                                // 0000005A0D94: DACC0000 0200030F
	ds_bpermute_b32 v12, v15, v8                               // 0000005A0D9C: DACC0000 0C00080F
	ds_bpermute_b32 v14, v15, v10                              // 0000005A0DA4: DACC0000 0E000A0F
	s_waitcnt lgkmcnt(3)                                       // 0000005A0DAC: BF89FC37
	v_add_f32_e32 v4, v4, v11                                  // 0000005A0DB0: 06081704
	ds_bpermute_b32 v13, v15, v9                               // 0000005A0DB4: DACC0000 0D00090F
	v_xor_b32_e32 v15, 1, v1                                   // 0000005A0DBC: 3A1E0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005A0DC0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v15                           // 0000005A0DC4: 7C981EA0
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 0000005A0DC8: 02021F01
	v_lshlrev_b32_e32 v15, 2, v1                               // 0000005A0DCC: 301E0282
	s_waitcnt lgkmcnt(2)                                       // 0000005A0DD0: BF89FC27
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v8, v12    // 0000005A0DD4: C9080503 01021908
	s_waitcnt lgkmcnt(0)                                       // 0000005A0DDC: BF89FC07
	v_dual_add_f32 v3, v10, v14 :: v_dual_add_f32 v8, v9, v13  // 0000005A0DE0: C9081D0A 03081B09
	ds_bpermute_b32 v12, v15, v4                               // 0000005A0DE8: DACC0000 0C00040F
	ds_bpermute_b32 v9, v15, v1                                // 0000005A0DF0: DACC0000 0900010F
	ds_bpermute_b32 v10, v15, v2                               // 0000005A0DF8: DACC0000 0A00020F
	ds_bpermute_b32 v11, v15, v3                               // 0000005A0E00: DACC0000 0B00030F
	ds_bpermute_b32 v13, v15, v8                               // 0000005A0E08: DACC0000 0D00080F
	v_cmpx_eq_u32_e32 0, v7                                    // 0000005A0E10: 7D940E80
	s_cbranch_execz 16                                         // 0000005A0E14: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll+0xa58>
	v_mul_u32_u24_e32 v5, 20, v5                               // 0000005A0E18: 160A0A94
	s_waitcnt lgkmcnt(3)                                       // 0000005A0E1C: BF89FC37
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v1, v1, v9    // 0000005A0E20: C9081904 04001301
	s_waitcnt lgkmcnt(0)                                       // 0000005A0E28: BF89FC07
	v_dual_add_f32 v7, v8, v13 :: v_dual_add_f32 v2, v2, v10   // 0000005A0E2C: C9081B08 07021502
	v_mad_u32_u24 v5, v6, 40, v5                               // 0000005A0E34: D60B0005 04155106
	v_add_f32_e32 v3, v3, v11                                  // 0000005A0E3C: 06061703
	ds_store_2addr_b32 v5, v1, v4 offset1:1                    // 0000005A0E40: D8380100 00040105
	ds_store_2addr_b32 v5, v2, v7 offset0:2 offset1:3          // 0000005A0E48: D8380302 00070205
	ds_store_b32 v5, v3 offset:16                              // 0000005A0E50: D8340010 00000305
	s_or_b32 exec_lo, exec_lo, s0                              // 0000005A0E58: 8C7E007E
	.long 0xd7050001                                           // 0000005A0E5C: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 0000005A0E60: 020200FF 000000CD
	.long 0x7f063880                                           // 0000005A0E68: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000005A0E6C: BF89FC07
	s_barrier                                                  // 0000005A0E70: BFBD0000
	buffer_gl0_inv                                             // 0000005A0E74: E0AC0000 00000000
	.long 0xd7390003                                           // 0000005A0E7C: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 0000005A0E80: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A0E84: BF870091
	.long 0xd7000001                                           // 0000005A0E88: D7000001
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000005A0E8C: 0202060E
	v_add_co_ci_u32_e64 v2, null, s15, 0, s0                   // 0000005A0E90: D5207C02 0001000F
	.long 0xd44c0000                                           // 0000005A0E98: D44C0000
	v_cndmask_b32_e32 v1, 20, v0, vcc_lo                       // 0000005A0E9C: 02020094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005A0EA0: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005A0EA4: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000005A0EA8: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 0000005A0EAC: BE812000
	s_cbranch_execz 43                                         // 0000005A0EB0: BFA5002B <_ZN7halogen12_GLOBAL__N_16k_lq6kILi5ELi32ELi2ELb0EEEvPKhPKtPvll+0xb60>
	.long 0xd7054000                                           // 0000005A0EB4: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 0000005A0EB8: 02010B03
	v_mul_u32_u24_e32 v3, 40, v3                               // 0000005A0EBC: 160606A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A0EC0: BF870092
	.long 0xd7041000                                           // 0000005A0EC4: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000005A0EC8: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000005A0ECC: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005A0ED4: BF8700B1
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000005A0ED8: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:5                     // 0000005A0EE0: D8DC0500 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000005A0EE8: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000005A0EF0: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005A0EF8: BF870131
	.long 0xd73c0003                                           // 0000005A0EFC: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000005A0F00: 02020681
	s_waitcnt lgkmcnt(0)                                       // 0000005A0F04: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 0000005A0F08: 06000C80
	.long 0xd7006a03                                           // 0000005A0F0C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000005A0F10: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005A0F14: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 0000005A0F18: 060A0F00
	.long 0xd73c0000                                           // 0000005A0F1C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000005A0F20: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000005A0F24: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 0000005A0F2C: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005A0F34: BF870093
	.long 0xd7006a00                                           // 0000005A0F38: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000005A0F3C: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000005A0F40: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005A0F48: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000005A0F4C: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000005A0F58: DC960000 007C0200
	s_endpgm                                                   // 0000005A0F60: BFB00000
		...

