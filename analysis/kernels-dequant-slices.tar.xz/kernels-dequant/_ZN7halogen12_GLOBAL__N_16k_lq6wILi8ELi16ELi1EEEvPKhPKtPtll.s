0000000000353900 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll():
	s_load_b256 s[4:11], s[0:1], null                          // 000000353900: F40C0100 F8000000
	s_mov_b32 s3, 0                                            // 000000353908: BE830080
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000035390C: 32020084
	s_lshl_b64 s[12:13], s[2:3], 4                             // 000000353910: 848C8402
	s_load_b64 s[2:3], s[0:1], 0x20                            // 000000353914: F4040080 F8000020
	v_mov_b32_e32 v9, s13                                      // 00000035391C: 7E12020D
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v17, 15, v0         // 000000353920: CA240080 0610008F
	v_or_b32_e32 v8, s12, v1                                   // 000000353928: 3810020C
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000035392C: CA100080 04040080
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v16, 0              // 000000353934: CA100080 07100080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000035393C: BF8704D3
	.long 0xd73c0001                                           // 000000353940: D73C0001
	v_cndmask_b32_e32 v1, 4, v8, vcc_lo                        // 000000353944: 02021084
	v_mov_b32_e32 v15, 0                                       // 000000353948: 7E1E0280
	v_dual_mov_b32 v47, 0 :: v_dual_mov_b32 v18, 0             // 00000035394C: CA100080 2F120080
	s_waitcnt lgkmcnt(0)                                       // 000000353954: BF89FC07
	s_ashr_i32 s16, s11, 31                                    // 000000353958: 86109F0B
	s_lshr_b32 s0, s16, 27                                     // 00000035395C: 85009B10
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000353960: BF870009
	s_add_u32 s0, s10, s0                                      // 000000353964: 8000000A
	s_addc_u32 s1, s11, 0                                      // 000000353968: 8201800B
	s_lshr_b32 s14, s11, 31                                    // 00000035396C: 850E9F0B
	s_lshr_b64 s[12:13], s[0:1], 5                             // 000000353970: 858C8500
	s_add_u32 s0, s10, s14                                     // 000000353974: 80000E0A
	s_addc_u32 s1, s11, 0                                      // 000000353978: 8201800B
	s_lshr_b32 s13, s16, 30                                    // 00000035397C: 850D9E10
	s_ashr_i64 s[14:15], s[0:1], 1                             // 000000353980: 868E8100
	s_add_u32 s0, s10, s13                                     // 000000353984: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000353988: 8201800B
	s_lshr_b32 s13, s16, 28                                    // 00000035398C: 850D9C10
	s_ashr_i64 s[16:17], s[0:1], 2                             // 000000353990: 86908200
	s_add_u32 s0, s10, s13                                     // 000000353994: 80000D0A
	s_addc_u32 s1, s11, 0                                      // 000000353998: 8201800B
	v_cmp_gt_i64_e32 vcc_lo, s[2:3], v[8:9]                    // 00000035399C: 7CA81002
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003539A0: 86808400
	s_add_u32 s13, s16, s14                                    // 0000003539A4: 800D0E10
	s_addc_u32 s18, s17, s15                                   // 0000003539A8: 82120F11
	s_add_u32 s0, s13, s0                                      // 0000003539AC: 8000000D
	s_addc_u32 s1, s18, s1                                     // 0000003539B0: 82010112
	s_add_u32 s0, s0, 15                                       // 0000003539B4: 80008F00
	s_addc_u32 s1, s1, 0                                       // 0000003539B8: 82018001
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003539BC: 02040480
	s_ashr_i32 s13, s1, 31                                     // 0000003539C0: 860D9F01
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000003539C4: 02020280
	s_lshr_b32 s13, s13, 28                                    // 0000003539C8: 850D9C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003539CC: BF8704A9
	s_add_u32 s0, s0, s13                                      // 0000003539D0: 80000D00
	s_addc_u32 s1, s1, 0                                       // 0000003539D4: 82018001
	s_ashr_i64 s[0:1], s[0:1], 4                               // 0000003539D8: 86808400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000003539DC: BF870149
	.long 0xd72c0003                                           // 0000003539E0: D72C0003
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 0000003539E4: 02000301
	.long 0xd72c0002                                           // 0000003539E8: D72C0002
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 0000003539EC: 02000102
	v_mad_u64_u32 v[10:11], null, v1, s0, s[4:5]               // 0000003539F0: D6FE7C0A 00100101
	.long 0xd4440000                                           // 0000003539F8: D4440000
	v_cndmask_b32_e32 v1, s12, v17, vcc_lo                     // 0000003539FC: 0202220C
	v_add3_u32 v19, v2, v11, v3                                // 000000353A00: D6550013 040E1702
	s_and_saveexec_b32 s4, s0                                  // 000000353A08: BE842000
	s_cbranch_execz 35                                         // 000000353A0C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x19c>
	v_lshlrev_b32_e32 v1, 4, v17                               // 000000353A10: 30022284
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000353A14: 30000081
	v_lshlrev_b32_e32 v5, 3, v17                               // 000000353A18: 300A2283
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353A1C: BF870093
	.long 0xd7000101                                           // 000000353A20: D7000101
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 000000353A24: 0202030A
	v_add_co_ci_u32_e64 v2, null, 0, v19, s1                   // 000000353A28: D5207C02 00062680
	.long 0xd7000103                                           // 000000353A30: D7000103
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000353A34: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353A38: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s15, v19, s1                 // 000000353A3C: D5207C04 0006260F
	v_and_b32_e32 v0, 28, v0                                   // 000000353A44: 3600009C
	.long 0xd7000106                                           // 000000353A48: D7000106
	v_cndmask_b32_e32 v0, v3, v16, vcc_lo                      // 000000353A4C: 02002103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000353A50: BF8700A1
	v_add_co_ci_u32_e64 v7, null, s17, v4, s1                  // 000000353A54: D5207C07 00060811
	.long 0xd700010b                                           // 000000353A5C: D700010B
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 000000353A60: 02020B03
	v_add_co_ci_u32_e64 v12, null, 0, v4, s1                   // 000000353A64: D5207C0C 00060880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353A6C: BF870094
	.long 0xd700010d                                           // 000000353A70: D700010D
	v_cndmask_b32_e32 v1, v6, v0, vcc_lo                       // 000000353A74: 02020106
	v_add_co_ci_u32_e64 v14, null, 0, v7, s1                   // 000000353A78: D5207C0E 00060E80
	s_clause 0x2                                               // 000000353A80: BF850002
	global_load_b128 v[4:7], v[1:2], off                       // 000000353A84: DC5E0000 047C0001
	global_load_b64 v[15:16], v[11:12], off                    // 000000353A8C: DC560000 0F7C000B
	global_load_b32 v47, v[13:14], off                         // 000000353A94: DC520000 2F7C000D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000353A9C: 8C7E047E
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000353AA0: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000353AA8: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000353AB0: CA100080 18180080
	v_mov_b32_e32 v26, 0                                       // 000000353AB8: 7E340280
	s_and_saveexec_b32 s13, s0                                 // 000000353ABC: BE8D2000
	s_cbranch_execz 1133                                       // 000000353AC0: BFA5046D <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x1378>
	.long 0xd700001b                                           // 000000353AC4: D700001B
	v_cndmask_b32_e32 v0, v10, v14, vcc_lo                     // 000000353AC8: 02001D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353ACC: BF8701A1
	v_add_co_ci_u32_e64 v28, null, s15, v19, s0                // 000000353AD0: D5207C1C 0002260F
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v17    // 000000353AD8: CA220080 0C0A2285
	.long 0xd700001d                                           // 000000353AE0: D700001D
	v_cndmask_b32_e32 v0, v27, v16, vcc_lo                     // 000000353AE4: 0200211B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000353AE8: BF870001
	v_add_co_ci_u32_e64 v30, null, s17, v28, s0                // 000000353AEC: D5207C1E 00023811
	v_lshl_or_b32 v31, v17, 4, 0x100                           // 000000353AF4: D656001F 03FD0911 00000100
	v_lshl_or_b32 v32, v17, 3, 0x80                            // 000000353B00: D6560020 03FD0711 00000080
	v_lshl_or_b32 v33, v17, 1, 32                              // 000000353B0C: D6560021 02810311
	s_waitcnt vmcnt(0)                                         // 000000353B14: BF8903F7
	v_dual_mov_b32 v18, v12 :: v_dual_mov_b32 v35, v47         // 000000353B18: CA10010C 1222012F
	v_mov_b32_e32 v20, v12                                     // 000000353B20: 7E28030C
	v_dual_mov_b32 v21, v12 :: v_dual_mov_b32 v34, v17         // 000000353B24: CA10010C 15220111
	v_mov_b32_e32 v22, v12                                     // 000000353B2C: 7E2C030C
	v_mov_b32_e32 v23, v12                                     // 000000353B30: 7E2E030C
	v_mov_b32_e32 v24, v12                                     // 000000353B34: 7E30030C
	v_mov_b32_e32 v25, v12                                     // 000000353B38: 7E32030C
	v_mov_b32_e32 v26, v12                                     // 000000353B3C: 7E34030C
	s_mul_i32 s0, s11, 6                                       // 000000353B40: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000353B44: 9681860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000353B48: 8484820A
	s_add_i32 s14, s1, s0                                      // 000000353B4C: 810E0001
	s_mul_i32 s16, s10, 6                                      // 000000353B50: 9610860A
	s_mov_b32 s15, 0                                           // 000000353B54: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000353B58: 848A810A
	s_branch 1055                                              // 000000353B5C: BFA0041F <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x12dc>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000353B60: 8C7E117E
	v_lshlrev_b32_e32 v36, 4, v15                              // 000000353B64: 30481E84
	v_lshlrev_b32_e32 v38, 2, v15                              // 000000353B68: 304C1E82
	v_lshrrev_b32_e32 v37, 4, v4                               // 000000353B6C: 324A0884
	.long 0x7f603880                                           // 000000353B70: 7F603880
	v_lshrrev_b32_e32 v39, 6, v15                              // 000000353B74: 324E1E86
	v_and_b32_e32 v36, 48, v36                                 // 000000353B78: 364848B0
	v_and_b32_e32 v38, 48, v38                                 // 000000353B7C: 364C4CB0
	v_lshrrev_b32_e32 v40, 22, v15                             // 000000353B80: 32501E96
	v_lshrrev_b32_e32 v42, 6, v16                              // 000000353B84: 32542086
	v_and_b32_e32 v39, 48, v39                                 // 000000353B88: 364E4EB0
	v_and_or_b32 v36, v4, 15, v36                              // 000000353B8C: D6570024 04911F04
	v_and_or_b32 v37, v37, 15, v38                             // 000000353B94: D6570025 04991F25
	v_and_b32_e32 v40, 48, v40                                 // 000000353B9C: 365050B0
	v_lshrrev_b32_e32 v41, 20, v6                              // 000000353BA0: 32520C94
	v_and_b32_e32 v42, 48, v42                                 // 000000353BA4: 365454B0
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000353BA8: 7E482324
	v_lshrrev_b32_e32 v50, 18, v16                             // 000000353BAC: 32642092
	v_lshrrev_b32_e32 v51, 22, v16                             // 000000353BB0: 32662096
	s_and_b32 s0, exec_lo, s0                                  // 000000353BB4: 8B00007E
	v_and_or_b32 v41, v41, 15, v42                             // 000000353BB8: D6570029 04A91F29
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353BC0: CC206024 14BE5F24
	v_and_b32_e32 v50, 48, v50                                 // 000000353BC8: 366464B0
	v_and_b32_e32 v51, 48, v51                                 // 000000353BCC: 366666B0
	s_or_b32 s15, s0, s15                                      // 000000353BD0: 8C0F0F00
	v_add_nc_u32_e32 v31, 0x100, v31                           // 000000353BD4: 4A3E3EFF 00000100
	v_bfe_u32 v38, v36, 16, 1                                  // 000000353BDC: D6100026 02052124
	v_add_nc_u32_e32 v32, 0x80, v32                            // 000000353BE4: 4A4040FF 00000080
	v_add_nc_u32_e32 v33, 32, v33                              // 000000353BEC: 4A4242A0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353BF0: BF870123
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000353BF4: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 2, v15                              // 000000353C00: 324C1E82
	.long 0x7e6039a4                                           // 000000353C04: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 000000353C08: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353C0C: BF870113
	v_and_b32_e32 v38, 48, v38                                 // 000000353C10: 364C4CB0
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353C14: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353C1C: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 000000353C20: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000353C28: D6550024 03FE4B24 00007FFF
	v_and_b32_e32 v37, 48, v15                                 // 000000353C34: 364A1EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000353C38: BF8700A2
	v_and_or_b32 v43, 0xffff0000, v36, v48                     // 000000353C3C: D657002B 04C248FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v4                               // 000000353C48: 32480888
	v_and_or_b32 v36, v36, 15, v37                             // 000000353C4C: D6570024 04951F24
	v_lshrrev_b32_e32 v37, 12, v4                              // 000000353C54: 324A088C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353C58: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000353C5C: 7E482324
	v_and_or_b32 v37, v37, 15, v38                             // 000000353C60: D6570025 04991F25
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353C68: BF870092
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353C6C: CC206024 14BE5F24
	v_bfe_u32 v38, v36, 16, 1                                  // 000000353C74: D6100026 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353C7C: BF870121
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000353C80: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 20, v4                              // 000000353C8C: 324C0894
	.long 0x7e6039a4                                           // 000000353C90: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v37                              // 000000353C94: 7E482325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353C98: BF870113
	v_and_or_b32 v38, v38, 15, v39                             // 000000353C9C: D6570026 049D1F26
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353CA4: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353CAC: BF870091
	v_bfe_u32 v37, v36, 16, 1                                  // 000000353CB0: D6100025 02052124
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000353CB8: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 4, v15                              // 000000353CC4: 324A1E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353CC8: BF8701A2
	v_and_or_b32 v44, 0xffff0000, v36, v48                     // 000000353CCC: D657002C 04C248FF FFFF0000
	.long 0x7e603984                                           // 000000353CD8: 7E603984
	v_and_b32_e32 v37, 48, v37                                 // 000000353CDC: 364A4AB0
	v_lshrrev_b32_e32 v36, 8, v15                              // 000000353CE0: 32481E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353CE4: BF870112
	v_and_or_b32 v37, v48, 15, v37                             // 000000353CE8: D6570025 04951F30
	v_and_b32_e32 v36, 48, v36                                 // 000000353CF0: 364848B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353CF4: BF870092
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000353CF8: 7E4A2325
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353CFC: CC206025 14BE5F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353D04: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 000000353D08: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000353D10: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 18, v15                             // 000000353D1C: 324E1E92
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353D20: BF8701A2
	.long 0x7e6039a5                                           // 000000353D24: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v38                              // 000000353D28: 7E4A2326
	v_and_b32_e32 v39, 48, v39                                 // 000000353D2C: 364E4EB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353D30: BF870092
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353D34: CC206025 14BE5F25
	v_bfe_u32 v38, v37, 16, 1                                  // 000000353D3C: D6100026 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353D44: BF870121
	v_add3_u32 v37, v37, v38, 0x7fff                           // 000000353D48: D6550025 03FE4D25 00007FFF
	v_lshrrev_b32_e32 v38, 12, v15                             // 000000353D54: 324C1E8C
	v_and_or_b32 v45, 0xffff0000, v37, v48                     // 000000353D58: D657002D 04C24AFF FFFF0000
	v_lshrrev_b32_e32 v37, 24, v4                              // 000000353D64: 324A0898
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000353D68: 3208089C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353D6C: BF870122
	v_and_or_b32 v36, v37, 15, v36                             // 000000353D70: D6570024 04911F25
	v_lshrrev_b32_e32 v37, 10, v15                             // 000000353D78: 324A1E8A
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000353D7C: 7E482324
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353D80: BF870112
	v_and_or_b32 v4, v37, 48, v4                               // 000000353D84: D6570004 04116125
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353D8C: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353D94: BF870112
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000353D98: 7E082304
	v_bfe_u32 v37, v36, 16, 1                                  // 000000353D9C: D6100025 02052124
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353DA4: BF870112
	v_fma_mix_f32 v4, v4, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353DA8: CC206004 14BE5F04
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000353DB0: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 14, v15                             // 000000353DBC: 324A1E8E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000353DC0: BF870212
	.long 0x7e6039a4                                           // 000000353DC4: 7E6039A4
	v_bfe_u32 v36, v4, 16, 1                                   // 000000353DC8: D6100024 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353DD0: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 000000353DD4: 364A4AB0
	v_add3_u32 v4, v4, v36, 0x7fff                             // 000000353DD8: D6550004 03FE4904 00007FFF
	v_lshrrev_b32_e32 v36, 4, v5                               // 000000353DE4: 32480A84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353DE8: BF8701A2
	v_and_or_b32 v46, 0xffff0000, v4, v48                      // 000000353DEC: D657002E 04C208FF FFFF0000
	v_and_b32_e32 v4, 48, v38                                  // 000000353DF8: 36084CB0
	v_and_or_b32 v36, v36, 15, v37                             // 000000353DFC: D6570024 04951F24
	.long 0x7e60398f                                           // 000000353E04: 7E60398F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000353E08: BF870193
	v_and_or_b32 v4, v5, 15, v4                                // 000000353E0C: D6570004 04111F05
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000353E14: 7E482324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000353E18: BF870193
	v_and_b32_e32 v38, 48, v48                                 // 000000353E1C: 364C60B0
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000353E20: 7E082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353E24: BF870113
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353E28: CC206024 14BE5F24
	v_fma_mix_f32 v4, v4, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353E30: CC206004 14BE5F04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353E38: BF870091
	v_bfe_u32 v37, v4, 16, 1                                   // 000000353E3C: D6100025 02052104
	v_add3_u32 v4, v4, v37, 0x7fff                             // 000000353E44: D6550004 03FE4B04 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353E50: BF870114
	v_bfe_u32 v37, v36, 16, 1                                  // 000000353E54: D6100025 02052124
	.long 0x7e083984                                           // 000000353E5C: 7E083984
	.long 0x7f0839b0                                           // 000000353E60: 7F0839B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353E64: BF870123
	v_add3_u32 v36, v36, v37, 0x7fff                           // 000000353E68: D6550024 03FE4B24 00007FFF
	v_lshrrev_b32_e32 v37, 20, v15                             // 000000353E74: 324A1E94
	v_and_or_b32 v4, 0xffff0000, v36, v4                       // 000000353E78: D6570004 041248FF FFFF0000
	v_lshrrev_b32_e32 v36, 8, v5                               // 000000353E84: 32480A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353E88: BF870113
	v_and_b32_e32 v37, 48, v37                                 // 000000353E8C: 364A4AB0
	v_and_or_b32 v36, v36, 15, v38                             // 000000353E90: D6570024 04991F24
	v_lshrrev_b32_e32 v38, 12, v5                              // 000000353E98: 324C0A8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353E9C: BF870112
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000353EA0: 7E482324
	v_and_or_b32 v38, v38, 15, v39                             // 000000353EA4: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353EAC: BF870092
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353EB0: CC206024 14BE5F24
	v_bfe_u32 v39, v36, 16, 1                                  // 000000353EB8: D6100027 02052124
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353EC0: BF870121
	v_add3_u32 v36, v36, v39, 0x7fff                           // 000000353EC4: D6550024 03FE4F24 00007FFF
	v_lshrrev_b32_e32 v39, 20, v5                              // 000000353ED0: 324E0A94
	.long 0x7e6039a4                                           // 000000353ED4: 7E6039A4
	v_cvt_f32_ubyte0_e32 v36, v38                              // 000000353ED8: 7E482326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353EDC: BF870113
	v_and_or_b32 v39, v39, 15, v40                             // 000000353EE0: D6570027 04A11F27
	v_fma_mix_f32 v36, v36, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353EE8: CC206024 14BE5F24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353EF0: BF870091
	v_bfe_u32 v38, v36, 16, 1                                  // 000000353EF4: D6100026 02052124
	v_add3_u32 v36, v36, v38, 0x7fff                           // 000000353EFC: D6550024 03FE4D24 00007FFF
	v_lshrrev_b32_e32 v38, 24, v15                             // 000000353F08: 324C1E98
	v_lshrrev_b32_e32 v15, 26, v15                             // 000000353F0C: 321E1E9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000353F10: BF870223
	v_and_or_b32 v36, 0xffff0000, v36, v48                     // 000000353F14: D6570024 04C248FF FFFF0000
	.long 0x7e603985                                           // 000000353F20: 7E603985
	v_and_b32_e32 v38, 48, v38                                 // 000000353F24: 364C4CB0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353F28: BF870092
	v_and_or_b32 v37, v48, 15, v37                             // 000000353F2C: D6570025 04951F30
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000353F34: 7E4A2325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353F38: BF870091
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353F3C: CC206025 14BE5F25
	v_bfe_u32 v40, v37, 16, 1                                  // 000000353F44: D6100028 02052125
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000353F4C: BF870121
	v_add3_u32 v37, v37, v40, 0x7fff                           // 000000353F50: D6550025 03FE5125 00007FFF
	v_lshrrev_b32_e32 v40, 2, v16                              // 000000353F5C: 32502082
	.long 0x7e6039a5                                           // 000000353F60: 7E6039A5
	v_cvt_f32_ubyte0_e32 v37, v39                              // 000000353F64: 7E4A2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000353F68: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 000000353F6C: 365050B0
	v_fma_mix_f32 v37, v37, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353F70: CC206025 14BE5F25
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353F78: BF870091
	v_bfe_u32 v39, v37, 16, 1                                  // 000000353F7C: D6100027 02052125
	v_add3_u32 v37, v37, v39, 0x7fff                           // 000000353F84: D6550025 03FE4F25 00007FFF
	v_lshrrev_b32_e32 v39, 24, v5                              // 000000353F90: 324E0A98
	v_lshrrev_b32_e32 v5, 28, v5                               // 000000353F94: 320A0A9C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000353F98: BF870193
	v_and_or_b32 v37, 0xffff0000, v37, v48                     // 000000353F9C: D6570025 04C24AFF FFFF0000
	v_and_or_b32 v38, v39, 15, v38                             // 000000353FA8: D6570026 04991F27
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000353FB0: BF8701A3
	v_and_or_b32 v5, v15, 48, v5                               // 000000353FB4: D6570005 0415610F
	v_lshlrev_b32_e32 v39, 2, v16                              // 000000353FBC: 304E2082
	v_cvt_f32_ubyte0_e32 v15, v38                              // 000000353FC0: 7E1E2326
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000353FC4: BF870193
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000353FC8: 7E0A2305
	v_and_b32_e32 v39, 48, v39                                 // 000000353FCC: 364E4EB0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000353FD0: BF870193
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353FD4: CC20600F 14BE5F0F
	v_fma_mix_f32 v5, v5, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000353FDC: CC206005 14BE5F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000353FE4: BF870092
	v_bfe_u32 v38, v15, 16, 1                                  // 000000353FE8: D6100026 0205210F
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000353FF0: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 4, v6                               // 000000353FFC: 324C0C84
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000354000: BF8701A2
	.long 0x7e60398f                                           // 000000354004: 7E60398F
	v_bfe_u32 v15, v5, 16, 1                                   // 000000354008: D610000F 02052105
	v_and_or_b32 v38, v38, 15, v39                             // 000000354010: D6570026 049D1F26
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000354018: BF870122
	v_add3_u32 v5, v5, v15, 0x7fff                             // 00000035401C: D6550005 03FE1F05 00007FFF
	v_lshlrev_b32_e32 v15, 4, v16                              // 000000354028: 301E2084
	v_and_or_b32 v5, 0xffff0000, v5, v48                       // 00000035402C: D6570005 04C20AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354038: BF870092
	v_and_b32_e32 v15, 48, v15                                 // 00000035403C: 361E1EB0
	v_and_or_b32 v15, v6, 15, v15                              // 000000354040: D657000F 043D1F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354048: BF870091
	v_cvt_f32_ubyte0_e32 v15, v15                              // 00000035404C: 7E1E230F
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354050: CC20600F 14BE5F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354058: BF870091
	v_bfe_u32 v39, v15, 16, 1                                  // 00000035405C: D6100027 0205210F
	v_add3_u32 v15, v15, v39, 0x7fff                           // 000000354064: D655000F 03FE4F0F 00007FFF
	v_and_b32_e32 v39, 48, v16                                 // 000000354070: 364E20B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354074: BF8700A2
	.long 0x7e60398f                                           // 000000354078: 7E60398F
	v_cvt_f32_ubyte0_e32 v15, v38                              // 00000035407C: 7E1E2326
	v_fma_mix_f32 v15, v15, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354080: CC20600F 14BE5F0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354088: BF870091
	v_bfe_u32 v38, v15, 16, 1                                  // 00000035408C: D6100026 0205210F
	v_add3_u32 v15, v15, v38, 0x7fff                           // 000000354094: D655000F 03FE4D0F 00007FFF
	v_lshrrev_b32_e32 v38, 8, v6                               // 0000003540A0: 324C0C88
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003540A4: BF870112
	v_and_or_b32 v15, 0xffff0000, v15, v48                     // 0000003540A8: D657000F 04C21EFF FFFF0000
	v_and_or_b32 v38, v38, 15, v39                             // 0000003540B4: D6570026 049D1F26
	v_lshrrev_b32_e32 v39, 12, v6                              // 0000003540BC: 324E0C8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003540C0: BF870112
	v_cvt_f32_ubyte0_e32 v38, v38                              // 0000003540C4: 7E4C2326
	v_and_or_b32 v39, v39, 15, v40                             // 0000003540C8: D6570027 04A11F27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003540D0: BF870092
	v_fma_mix_f32 v38, v38, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003540D4: CC206026 14BE5F26
	v_bfe_u32 v40, v38, 16, 1                                  // 0000003540DC: D6100028 02052126
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003540E4: BF870121
	v_add3_u32 v38, v38, v40, 0x7fff                           // 0000003540E8: D6550026 03FE5126 00007FFF
	v_lshrrev_b32_e32 v40, 8, v16                              // 0000003540F4: 32502088
	.long 0x7e6039a6                                           // 0000003540F8: 7E6039A6
	v_cvt_f32_ubyte0_e32 v38, v39                              // 0000003540FC: 7E4C2327
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000354100: BF870113
	v_and_b32_e32 v40, 48, v40                                 // 000000354104: 365050B0
	v_fma_mix_f32 v38, v38, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354108: CC206026 14BE5F26
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354110: BF870091
	v_bfe_u32 v39, v38, 16, 1                                  // 000000354114: D6100027 02052126
	v_add3_u32 v38, v38, v39, 0x7fff                           // 00000035411C: D6550026 03FE4F26 00007FFF
	v_lshrrev_b32_e32 v39, 4, v16                              // 000000354128: 324E2084
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000035412C: BF8701A2
	v_and_or_b32 v38, 0xffff0000, v38, v48                     // 000000354130: D6570026 04C24CFF FFFF0000
	.long 0x7e603986                                           // 00000035413C: 7E603986
	v_and_b32_e32 v39, 48, v39                                 // 000000354140: 364E4EB0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354144: BF870091
	v_and_or_b32 v39, v48, 15, v39                             // 000000354148: D6570027 049D1F30
	v_cvt_f32_ubyte0_e32 v39, v39                              // 000000354150: 7E4E2327
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354154: BF870091
	v_fma_mix_f32 v39, v39, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354158: CC206027 14BE5F27
	v_bfe_u32 v42, v39, 16, 1                                  // 000000354160: D610002A 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000354168: BF870121
	v_add3_u32 v39, v39, v42, 0x7fff                           // 00000035416C: D6550027 03FE5527 00007FFF
	v_lshrrev_b32_e32 v42, 12, v16                             // 000000354178: 3254208C
	.long 0x7e6039a7                                           // 00000035417C: 7E6039A7
	v_cvt_f32_ubyte0_e32 v39, v41                              // 000000354180: 7E4E2329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354184: BF870091
	v_fma_mix_f32 v39, v39, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354188: CC206027 14BE5F27
	v_bfe_u32 v41, v39, 16, 1                                  // 000000354190: D6100029 02052127
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000354198: BF8701B1
	v_add3_u32 v39, v39, v41, 0x7fff                           // 00000035419C: D6550027 03FE5327 00007FFF
	v_lshrrev_b32_e32 v41, 24, v6                              // 0000003541A8: 32520C98
	v_lshrrev_b32_e32 v6, 28, v6                               // 0000003541AC: 320C0C9C
	v_and_or_b32 v39, 0xffff0000, v39, v48                     // 0000003541B0: D6570027 04C24EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003541BC: BF870123
	v_and_or_b32 v40, v41, 15, v40                             // 0000003541C0: D6570028 04A11F29
	v_lshrrev_b32_e32 v41, 10, v16                             // 0000003541C8: 3252208A
	v_cvt_f32_ubyte0_e32 v40, v40                              // 0000003541CC: 7E502328
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003541D0: BF870112
	v_and_or_b32 v6, v41, 48, v6                               // 0000003541D4: D6570006 04196129
	v_fma_mix_f32 v40, v40, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003541DC: CC206028 14BE5F28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003541E4: BF870112
	v_cvt_f32_ubyte0_e32 v6, v6                                // 0000003541E8: 7E0C2306
	v_bfe_u32 v41, v40, 16, 1                                  // 0000003541EC: D6100029 02052128
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003541F4: BF870112
	v_fma_mix_f32 v6, v6, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003541F8: CC206006 14BE5F06
	v_add3_u32 v40, v40, v41, 0x7fff                           // 000000354200: D6550028 03FE5328 00007FFF
	v_lshrrev_b32_e32 v41, 4, v7                               // 00000035420C: 32520E84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000354210: BF870212
	.long 0x7e6039a8                                           // 000000354214: 7E6039A8
	v_bfe_u32 v40, v6, 16, 1                                   // 000000354218: D6100028 02052106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000354220: BF870121
	v_add3_u32 v6, v6, v40, 0x7fff                             // 000000354224: D6550006 03FE5106 00007FFF
	v_and_b32_e32 v40, 15, v7                                  // 000000354230: 36500E8F
	v_and_or_b32 v6, 0xffff0000, v6, v48                       // 000000354234: D6570006 04C20CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000354240: BF8701B2
	v_and_or_b32 v40, v42, 48, v40                             // 000000354244: D6570028 04A1612A
	v_lshrrev_b32_e32 v42, 14, v16                             // 00000035424C: 3254208E
	.long 0x7e603990                                           // 000000354250: 7E603990
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000354254: 7E502328
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000354258: BF870193
	v_and_b32_e32 v42, 48, v42                                 // 00000035425C: 365454B0
	v_and_b32_e32 v49, 48, v48                                 // 000000354260: 366260B0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000354264: BF870193
	v_fma_mix_f32 v40, v40, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354268: CC206028 14BE5F28
	v_and_or_b32 v41, v41, 15, v42                             // 000000354270: D6570029 04A91F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000354278: BF870112
	v_bfe_u32 v42, v40, 16, 1                                  // 00000035427C: D610002A 02052128
	v_cvt_f32_ubyte0_e32 v41, v41                              // 000000354284: 7E522329
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000354288: BF870112
	v_add3_u32 v40, v40, v42, 0x7fff                           // 00000035428C: D6550028 03FE5528 00007FFF
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354298: CC206029 14BE5F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003542A0: BF870112
	.long 0x7e5039a8                                           // 0000003542A4: 7E5039A8
	v_bfe_u32 v42, v41, 16, 1                                  // 0000003542A8: D610002A 02052129
	.long 0x7f5039b0                                           // 0000003542B0: 7F5039B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003542B4: BF870122
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000003542B8: D6550029 03FE5529 00007FFF
	v_lshrrev_b32_e32 v42, 20, v16                             // 0000003542C4: 32542094
	v_and_or_b32 v40, 0xffff0000, v41, v40                     // 0000003542C8: D6570028 04A252FF FFFF0000
	v_lshrrev_b32_e32 v41, 8, v7                               // 0000003542D4: 32520E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003542D8: BF870113
	v_and_b32_e32 v42, 48, v42                                 // 0000003542DC: 365454B0
	v_and_or_b32 v41, v41, 15, v49                             // 0000003542E0: D6570029 04C51F29
	v_lshrrev_b32_e32 v49, 12, v7                              // 0000003542E8: 32620E8C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003542EC: BF870112
	v_cvt_f32_ubyte0_e32 v41, v41                              // 0000003542F0: 7E522329
	v_and_or_b32 v49, v49, 15, v50                             // 0000003542F4: D6570031 04C91F31
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003542FC: BF870092
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354300: CC206029 14BE5F29
	v_bfe_u32 v50, v41, 16, 1                                  // 000000354308: D6100032 02052129
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000354310: BF870121
	v_add3_u32 v41, v41, v50, 0x7fff                           // 000000354314: D6550029 03FE6529 00007FFF
	v_lshrrev_b32_e32 v50, 20, v7                              // 000000354320: 32640E94
	.long 0x7e6039a9                                           // 000000354324: 7E6039A9
	v_cvt_f32_ubyte0_e32 v41, v49                              // 000000354328: 7E522331
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035432C: BF870113
	v_and_or_b32 v50, v50, 15, v51                             // 000000354330: D6570032 04CD1F32
	v_fma_mix_f32 v41, v41, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354338: CC206029 14BE5F29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354340: BF870091
	v_bfe_u32 v49, v41, 16, 1                                  // 000000354344: D6100031 02052129
	v_add3_u32 v41, v41, v49, 0x7fff                           // 00000035434C: D6550029 03FE6329 00007FFF
	v_lshrrev_b32_e32 v49, 24, v16                             // 000000354358: 32622098
	v_lshrrev_b32_e32 v16, 26, v16                             // 00000035435C: 3220209A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000354360: BF870223
	v_and_or_b32 v41, 0xffff0000, v41, v48                     // 000000354364: D6570029 04C252FF FFFF0000
	.long 0x7e603987                                           // 000000354370: 7E603987
	v_and_b32_e32 v49, 48, v49                                 // 000000354374: 366262B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354378: BF870092
	v_and_or_b32 v42, v48, 15, v42                             // 00000035437C: D657002A 04A91F30
	v_cvt_f32_ubyte0_e32 v42, v42                              // 000000354384: 7E54232A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354388: BF870091
	v_fma_mix_f32 v42, v42, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000035438C: CC20602A 14BE5F2A
	v_bfe_u32 v51, v42, 16, 1                                  // 000000354394: D6100033 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035439C: BF870091
	v_add3_u32 v42, v42, v51, 0x7fff                           // 0000003543A0: D655002A 03FE672A 00007FFF
	.long 0x7e6039aa                                           // 0000003543AC: 7E6039AA
	v_cvt_f32_ubyte0_e32 v42, v50                              // 0000003543B0: 7E542332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003543B4: BF870091
	v_fma_mix_f32 v42, v42, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003543B8: CC20602A 14BE5F2A
	v_bfe_u32 v50, v42, 16, 1                                  // 0000003543C0: D6100032 0205212A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003543C8: BF8701B1
	v_add3_u32 v42, v42, v50, 0x7fff                           // 0000003543CC: D655002A 03FE652A 00007FFF
	v_lshrrev_b32_e32 v50, 24, v7                              // 0000003543D8: 32640E98
	v_lshrrev_b32_e32 v7, 28, v7                               // 0000003543DC: 320E0E9C
	v_and_or_b32 v42, 0xffff0000, v42, v48                     // 0000003543E0: D657002A 04C254FF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003543EC: BF870193
	v_and_or_b32 v49, v50, 15, v49                             // 0000003543F0: D6570031 04C51F32
	v_and_or_b32 v7, v16, 48, v7                               // 0000003543F8: D6570007 041D6110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000354400: BF870112
	v_cvt_f32_ubyte0_e32 v16, v49                              // 000000354404: 7E202331
	v_cvt_f32_ubyte0_e32 v7, v7                                // 000000354408: 7E0E2307
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000035440C: BF870112
	v_fma_mix_f32 v16, v16, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354410: CC206010 14BE5F10
	v_fma_mix_f32 v7, v7, v47, v47 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000354418: CC206007 14BE5F07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354420: BF870092
	v_bfe_u32 v49, v16, 16, 1                                  // 000000354424: D6100031 02052110
	v_add3_u32 v16, v16, v49, 0x7fff                           // 00000035442C: D6550010 03FE6310 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000354438: BF870211
	.long 0x7e603990                                           // 00000035443C: 7E603990
	v_bfe_u32 v16, v7, 16, 1                                   // 000000354440: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354448: BF870091
	v_add3_u32 v7, v7, v16, 0x7fff                             // 00000035444C: D6550007 03FE2107 00007FFF
	v_and_or_b32 v7, 0xffff0000, v7, v48                       // 000000354458: D6570007 04C20EFF FFFF0000
	.long 0xd73c002f                                           // 000000354464: D73C002F
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000354468: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 00000035446C: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354474: BF870092
	.long 0xd700003f                                           // 000000354478: D700003F
	v_cndmask_b32_e32 v1, s6, v47, vcc_lo                      // 00000035447C: 02025E06
	v_add_co_ci_u32_e64 v64, null, s7, v48, s0                 // 000000354480: D5207C40 00026007
	s_clause 0x3                                               // 000000354488: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 00000035448C: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000354494: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 00000035449C: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 0000003544A4: DC5E0030 3B7C003F
	s_waitcnt vmcnt(3)                                         // 0000003544AC: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 0000003544B0: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003544B8: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 0000003544BC: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 0000003544C4: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003544CC: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 0000003544D0: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 0000003544D8: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 0000003544DC: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003544E4: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 0000003544E8: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003544F0: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003544F8: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 0000003544FC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000354504: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000354508: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354510: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000354514: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 00000035451C: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354524: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000354528: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000354530: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000354534: CC1A4010 1C42513B
	.long 0xd700003b                                           // 00000035453C: D700003B
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 000000354540: 0200153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000354544: BF8701B2
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000354548: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s11, v64, s0                // 000000354550: D5207C3C 0002800B
	.long 0xd7000041                                           // 000000354558: D7000041
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 00000035455C: 0200093F
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000354560: CC1A4010 1C42553D
	v_add_co_ci_u32_e64 v66, null, s5, v64, s0                 // 000000354568: D5207C42 00028005
	.long 0xd700003f                                           // 000000354570: D700003F
	v_cndmask_b32_e32 v0, v63, v16, vcc_lo                     // 000000354574: 0200213F
	s_delay_alu instid0(VALU_DEP_3)                            // 000000354578: BF870003
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 00000035457C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000354584: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 000000354588: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 000000354590: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 000000354598: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 0000003545A0: DC5E0030 3B7C003B
	v_add_co_ci_u32_e64 v64, null, s14, v64, s0                // 0000003545A8: D5207C40 0002800E
	v_add_f32_e32 v26, v26, v16                                // 0000003545B0: 0634211A
	s_waitcnt vmcnt(3)                                         // 0000003545B4: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 0000003545B8: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003545C0: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 0000003545C4: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 0000003545CC: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003545D4: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 0000003545D8: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 0000003545E0: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 0000003545E4: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003545EC: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 0000003545F0: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003545F8: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354600: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000354604: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 00000035460C: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000354610: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354618: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 00000035461C: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000354624: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035462C: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000354630: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000354638: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 00000035463C: CC1A4010 1C42513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354644: BF870091
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000354648: CC1A4010 1C42533C
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000354650: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000354658: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 00000035465C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000354664: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 000000354668: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 000000354670: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 000000354678: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 000000354680: DC5E0030 3B7C0041
	.long 0xd7000041                                           // 000000354688: D7000041
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 00000035468C: 02000941
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000354690: BF8700C1
	v_add_co_ci_u32_e64 v66, null, s5, v66, s0                 // 000000354694: D5207C42 00028405
	v_add_f32_e32 v25, v25, v16                                // 00000035469C: 06322119
	s_waitcnt vmcnt(3)                                         // 0000003546A0: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 0000003546A4: CC1A4010 1A02572F
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 0000003546AC: CC1A4010 1C425930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003546B4: BF870091
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 0000003546B8: CC1A4010 1C425B31
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 0000003546C0: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 0000003546C8: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003546CC: BF870091
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 0000003546D0: CC1A4010 1C420933
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 0000003546D8: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003546E0: BF870091
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003546E4: CC1A4010 1C424B35
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 0000003546EC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 0000003546F4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003546F8: BF870091
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 0000003546FC: CC1A4010 1C421F37
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000354704: CC1A4010 1C424D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035470C: BF870091
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000354710: CC1A4010 1C424F39
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000354718: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000354720: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354724: BF870091
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000354728: CC1A4010 1C42513B
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000354730: CC1A4010 1C42533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354738: BF870091
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 00000035473C: CC1A4010 1C42553D
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000354744: CC1A4010 1C420F3E
	s_clause 0x3                                               // 00000035474C: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 000000354750: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000354758: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000354760: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 000000354768: DC5E0030 3B7C003F
	.long 0xd700003f                                           // 000000354770: D700003F
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 000000354774: 0200093F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000354778: BF8700C1
	v_add_co_ci_u32_e64 v64, null, s5, v64, s0                 // 00000035477C: D5207C40 00028005
	v_add_f32_e32 v24, v24, v16                                // 000000354784: 06302118
	s_waitcnt vmcnt(3)                                         // 000000354788: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 00000035478C: CC1A4010 1A02572F
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000354794: CC1A4010 1C425930
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035479C: BF870091
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 0000003547A0: CC1A4010 1C425B31
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 0000003547A8: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 0000003547B0: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003547B4: BF870091
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 0000003547B8: CC1A4010 1C420933
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 0000003547C0: CC1A4010 1C424934
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003547C8: BF870091
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003547CC: CC1A4010 1C424B35
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 0000003547D4: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 0000003547DC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003547E0: BF870091
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 0000003547E4: CC1A4010 1C421F37
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 0000003547EC: CC1A4010 1C424D38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003547F4: BF870091
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 0000003547F8: CC1A4010 1C424F39
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000354800: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000354808: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035480C: BF870091
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000354810: CC1A4010 1C42513B
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000354818: CC1A4010 1C42533C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354820: BF870091
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000354824: CC1A4010 1C42553D
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 00000035482C: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000354834: BF850003
	global_load_b128 v[47:50], v[65:66], off                   // 000000354838: DC5E0000 2F7C0041
	global_load_b128 v[51:54], v[65:66], off offset:16         // 000000354840: DC5E0010 337C0041
	global_load_b128 v[55:58], v[65:66], off offset:32         // 000000354848: DC5E0020 377C0041
	global_load_b128 v[59:62], v[65:66], off offset:48         // 000000354850: DC5E0030 3B7C0041
	v_add_f32_e32 v23, v23, v16                                // 000000354858: 062E2117
	s_waitcnt vmcnt(3)                                         // 00000035485C: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000354860: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354868: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 00000035486C: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000354874: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000035487C: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000354880: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000354888: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 00000035488C: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354894: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000354898: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 0000003548A0: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003548A8: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 0000003548AC: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 0000003548B4: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 0000003548B8: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003548C0: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 0000003548C4: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 0000003548CC: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003548D4: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 0000003548D8: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 0000003548E0: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 0000003548E4: CC1A4010 1C42513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003548EC: BF870091
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 0000003548F0: CC1A4010 1C42533C
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 0000003548F8: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000354900: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000354904: CC1A4010 1C420F3E
	s_clause 0x3                                               // 00000035490C: BF850003
	global_load_b128 v[47:50], v[63:64], off                   // 000000354910: DC5E0000 2F7C003F
	global_load_b128 v[51:54], v[63:64], off offset:16         // 000000354918: DC5E0010 337C003F
	global_load_b128 v[55:58], v[63:64], off offset:32         // 000000354920: DC5E0020 377C003F
	global_load_b128 v[59:62], v[63:64], off offset:48         // 000000354928: DC5E0030 3B7C003F
	v_add_f32_e32 v22, v22, v16                                // 000000354930: 062C2116
	s_waitcnt vmcnt(3)                                         // 000000354934: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000354938: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354940: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000354944: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 00000035494C: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354954: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000354958: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000354960: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000354964: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000035496C: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000354970: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000354978: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354980: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000354984: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 00000035498C: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000354990: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354998: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 00000035499C: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 0000003549A4: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003549AC: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 0000003549B0: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 0000003549B8: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 0000003549BC: CC1A4010 1C42513B
	.long 0xd700003b                                           // 0000003549C4: D700003B
	v_cndmask_b32_e32 v0, v65, v4, vcc_lo                      // 0000003549C8: 02000941
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003549CC: BF870122
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 0000003549D0: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s5, v66, s0                 // 0000003549D8: D5207C3C 00028405
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 0000003549E0: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003549E8: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 0000003549EC: CC1A4010 1C420F3E
	s_clause 0x3                                               // 0000003549F4: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 0000003549F8: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 000000354A00: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 000000354A08: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000354A10: DC5E0030 3B7C003B
	v_add_f32_e32 v21, v21, v16                                // 000000354A18: 062A2115
	s_waitcnt vmcnt(3)                                         // 000000354A1C: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000354A20: CC1A4010 1A02572F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354A28: BF870091
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000354A2C: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000354A34: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354A3C: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000354A40: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000354A48: BF890BF7
	v_dot2_f32_bf16 v16, v51, v4, v16                          // 000000354A4C: CC1A4010 1C420933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354A54: BF870091
	v_dot2_f32_bf16 v16, v52, v36, v16                         // 000000354A58: CC1A4010 1C424934
	v_dot2_f32_bf16 v16, v53, v37, v16                         // 000000354A60: CC1A4010 1C424B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354A68: BF8700A1
	v_dot2_f32_bf16 v16, v54, v5, v16                          // 000000354A6C: CC1A4010 1C420B36
	s_waitcnt vmcnt(1)                                         // 000000354A74: BF8907F7
	v_dot2_f32_bf16 v16, v55, v15, v16                         // 000000354A78: CC1A4010 1C421F37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354A80: BF870091
	v_dot2_f32_bf16 v16, v56, v38, v16                         // 000000354A84: CC1A4010 1C424D38
	v_dot2_f32_bf16 v16, v57, v39, v16                         // 000000354A8C: CC1A4010 1C424F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354A94: BF8700A1
	v_dot2_f32_bf16 v16, v58, v6, v16                          // 000000354A98: CC1A4010 1C420D3A
	s_waitcnt vmcnt(0)                                         // 000000354AA0: BF8903F7
	v_dot2_f32_bf16 v16, v59, v40, v16                         // 000000354AA4: CC1A4010 1C42513B
	.long 0xd700003b                                           // 000000354AAC: D700003B
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 000000354AB0: 0200093F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000354AB4: BF870122
	v_dot2_f32_bf16 v16, v60, v41, v16                         // 000000354AB8: CC1A4010 1C42533C
	v_add_co_ci_u32_e64 v60, null, s5, v64, s0                 // 000000354AC0: D5207C3C 00028005
	v_dot2_f32_bf16 v16, v61, v42, v16                         // 000000354AC8: CC1A4010 1C42553D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000354AD0: BF870001
	v_dot2_f32_bf16 v16, v62, v7, v16                          // 000000354AD4: CC1A4010 1C420F3E
	s_clause 0x3                                               // 000000354ADC: BF850003
	global_load_b128 v[47:50], v[59:60], off                   // 000000354AE0: DC5E0000 2F7C003B
	global_load_b128 v[51:54], v[59:60], off offset:16         // 000000354AE8: DC5E0010 337C003B
	global_load_b128 v[55:58], v[59:60], off offset:32         // 000000354AF0: DC5E0020 377C003B
	global_load_b128 v[59:62], v[59:60], off offset:48         // 000000354AF8: DC5E0030 3B7C003B
	v_add_f32_e32 v20, v20, v16                                // 000000354B00: 06282114
	s_waitcnt vmcnt(3)                                         // 000000354B04: BF890FF7
	v_dot2_f32_bf16 v16, v47, v43, 0                           // 000000354B08: CC1A4010 1A02572F
	v_mov_b32_e32 v47, v35                                     // 000000354B10: 7E5E0323
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354B14: BF870092
	v_dot2_f32_bf16 v16, v48, v44, v16                         // 000000354B18: CC1A4010 1C425930
	v_dot2_f32_bf16 v16, v49, v45, v16                         // 000000354B20: CC1A4010 1C425B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354B28: BF8700A1
	v_dot2_f32_bf16 v16, v50, v46, v16                         // 000000354B2C: CC1A4010 1C425D32
	s_waitcnt vmcnt(2)                                         // 000000354B34: BF890BF7
	v_dot2_f32_bf16 v4, v51, v4, v16                           // 000000354B38: CC1A4004 1C420933
	v_mov_b32_e32 v16, v14                                     // 000000354B40: 7E20030E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354B44: BF870092
	v_dot2_f32_bf16 v4, v52, v36, v4                           // 000000354B48: CC1A4004 1C124934
	v_dot2_f32_bf16 v4, v53, v37, v4                           // 000000354B50: CC1A4004 1C124B35
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000354B58: BF870131
	v_dot2_f32_bf16 v4, v54, v5, v4                            // 000000354B5C: CC1A4004 1C120B36
	v_mov_b32_e32 v5, v1                                       // 000000354B64: 7E0A0301
	s_waitcnt vmcnt(1)                                         // 000000354B68: BF8907F7
	v_dot2_f32_bf16 v4, v55, v15, v4                           // 000000354B6C: CC1A4004 1C121F37
	v_mov_b32_e32 v15, v13                                     // 000000354B74: 7E1E030D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354B78: BF870092
	v_dot2_f32_bf16 v4, v56, v38, v4                           // 000000354B7C: CC1A4004 1C124D38
	v_dot2_f32_bf16 v4, v57, v39, v4                           // 000000354B84: CC1A4004 1C124F39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000354B8C: BF870131
	v_dot2_f32_bf16 v4, v58, v6, v4                            // 000000354B90: CC1A4004 1C120D3A
	v_mov_b32_e32 v6, v2                                       // 000000354B98: 7E0C0302
	s_waitcnt vmcnt(0)                                         // 000000354B9C: BF8903F7
	v_dot2_f32_bf16 v4, v59, v40, v4                           // 000000354BA0: CC1A4004 1C12513B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354BA8: BF870091
	v_dot2_f32_bf16 v4, v60, v41, v4                           // 000000354BAC: CC1A4004 1C12533C
	v_dot2_f32_bf16 v4, v61, v42, v4                           // 000000354BB4: CC1A4004 1C12553D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354BBC: BF870091
	v_dot2_f32_bf16 v4, v62, v7, v4                            // 000000354BC0: CC1A4004 1C120F3E
	v_dual_mov_b32 v7, v3 :: v_dual_add_f32 v18, v18, v4       // 000000354BC8: CA080103 07120912
	v_mov_b32_e32 v4, v0                                       // 000000354BD0: 7E080300
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000354BD4: 917E0F7E
	s_cbranch_execz 38                                         // 000000354BD8: BFA50026 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x1374>
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v34, 16, v34    // 000000354BDC: CA200105 01224490
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000354BE4: BF8701A2
	v_dual_mov_b32 v0, v4 :: v_dual_mov_b32 v3, v7             // 000000354BE8: CA100104 00020107
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v13, v15           // 000000354BF0: CA100106 020C010F
	.long 0xd4430000                                           // 000000354BF8: D4430000
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 000000354BFC: 0202440C
	v_mov_b32_e32 v14, v16                                     // 000000354C00: 7E1C0310
	s_mov_b32 s17, exec_lo                                     // 000000354C04: BE91007E
	.long 0xd4c4007e                                           // 000000354C08: D4C4007E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 000000354C0C: 0202440C
	s_cbranch_execz 64467                                      // 000000354C10: BFA5FBD3 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x260>
	v_and_b32_e32 v2, 0x7ffffffc, v33                          // 000000354C14: 360442FF 7FFFFFFC
	.long 0xd7000100                                           // 000000354C1C: D7000100
	v_cndmask_b32_e32 v1, v10, v31, vcc_lo                     // 000000354C20: 02023F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354C24: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v19, s1                   // 000000354C28: D5207C01 00062680
	.long 0xd700010d                                           // 000000354C30: D700010D
	v_cndmask_b32_e32 v1, v27, v32, vcc_lo                     // 000000354C34: 0202411B
	v_add_co_ci_u32_e64 v14, null, 0, v28, s1                  // 000000354C38: D5207C0E 00063880
	.long 0xd7000123                                           // 000000354C40: D7000123
	v_cndmask_b32_e32 v1, v29, v2, vcc_lo                      // 000000354C44: 0202051D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000354C48: BF870001
	v_add_co_ci_u32_e64 v36, null, 0, v30, s1                  // 000000354C4C: D5207C24 00063C80
	s_clause 0x2                                               // 000000354C54: BF850002
	global_load_b128 v[0:3], v[0:1], off                       // 000000354C58: DC5E0000 007C0000
	global_load_b64 v[13:14], v[13:14], off                    // 000000354C60: DC560000 0D7C000D
	global_load_b32 v35, v[35:36], off                         // 000000354C68: DC520000 237C0023
	s_branch 64443                                             // 000000354C70: BFA0FBBB <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000354C74: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000354C78: BF8700A9
	s_or_b32 exec_lo, exec_lo, s13                             // 000000354C7C: 8C7E0D7E
	.long 0xd71f0000                                           // 000000354C80: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000354C84: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000354C88: 3A020088
	v_xor_b32_e32 v11, 4, v0                                   // 000000354C8C: 3A160084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000354C90: BF870092
	.long 0xd44c0000                                           // 000000354C94: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000354C98: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000354C9C: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000354CA4: BF870113
	.long 0xd44c0000                                           // 000000354CA8: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 000000354CAC: 020216A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000354CB0: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000354CB4: BF870002
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 000000354CB8: D501000B 00021700
	ds_bpermute_b32 v2, v1, v25                                // 000000354CC0: DACC0000 02001901
	s_waitcnt lgkmcnt(0)                                       // 000000354CC8: BF89FC07
	v_add_f32_e32 v2, v25, v2                                  // 000000354CCC: 06040519
	s_waitcnt vmcnt(2)                                         // 000000354CD0: BF890BF7
	ds_bpermute_b32 v4, v1, v23                                // 000000354CD4: DACC0000 04001701
	ds_bpermute_b32 v3, v1, v26                                // 000000354CDC: DACC0000 03001A01
	ds_bpermute_b32 v5, v1, v24                                // 000000354CE4: DACC0000 05001801
	ds_bpermute_b32 v6, v1, v21                                // 000000354CEC: DACC0000 06001501
	ds_bpermute_b32 v7, v1, v22                                // 000000354CF4: DACC0000 07001601
	ds_bpermute_b32 v10, v1, v18                               // 000000354CFC: DACC0000 0A001201
	ds_bpermute_b32 v1, v1, v20                                // 000000354D04: DACC0000 01001401
	s_waitcnt lgkmcnt(6)                                       // 000000354D0C: BF89FC67
	v_dual_add_f32 v4, v23, v4 :: v_dual_lshlrev_b32 v11, 2, v11// 000000354D10: C9220917 040A1682
	ds_bpermute_b32 v12, v11, v2                               // 000000354D18: DACC0000 0C00020B
	s_waitcnt lgkmcnt(4)                                       // 000000354D20: BF89FC47
	v_dual_add_f32 v3, v26, v3 :: v_dual_add_f32 v6, v21, v6   // 000000354D24: C908071A 03060D15
	s_waitcnt lgkmcnt(2)                                       // 000000354D2C: BF89FC27
	v_dual_add_f32 v5, v24, v5 :: v_dual_add_f32 v10, v18, v10 // 000000354D30: C9080B18 050A1512
	s_waitcnt lgkmcnt(1)                                       // 000000354D38: BF89FC17
	v_add_f32_e32 v1, v20, v1                                  // 000000354D3C: 06020314
	v_xor_b32_e32 v20, 2, v0                                   // 000000354D40: 3A280082
	ds_bpermute_b32 v13, v11, v3                               // 000000354D44: DACC0000 0D00030B
	ds_bpermute_b32 v14, v11, v4                               // 000000354D4C: DACC0000 0E00040B
	s_waitcnt vmcnt(1)                                         // 000000354D54: BF8907F7
	ds_bpermute_b32 v15, v11, v5                               // 000000354D58: DACC0000 0F00050B
	ds_bpermute_b32 v16, v11, v6                               // 000000354D60: DACC0000 1000060B
	.long 0xd44c0000                                           // 000000354D68: D44C0000
	v_cndmask_b32_e32 v1, 32, v20, vcc_lo                      // 000000354D6C: 020228A0
	ds_bpermute_b32 v19, v11, v10                              // 000000354D70: DACC0000 13000A0B
	v_cndmask_b32_e64 v20, v0, v20, s0                         // 000000354D78: D5010014 00022900
	v_add_f32_e32 v7, v22, v7                                  // 000000354D80: 060E0F16
	s_waitcnt lgkmcnt(5)                                       // 000000354D84: BF89FC57
	v_add_f32_e32 v2, v2, v12                                  // 000000354D88: 06041902
	s_delay_alu instid0(VALU_DEP_3)                            // 000000354D8C: BF870003
	v_lshlrev_b32_e32 v20, 2, v20                              // 000000354D90: 30282882
	ds_bpermute_b32 v18, v11, v7                               // 000000354D94: DACC0000 1200070B
	ds_bpermute_b32 v11, v11, v1                               // 000000354D9C: DACC0000 0B00010B
	s_waitcnt lgkmcnt(5)                                       // 000000354DA4: BF89FC57
	v_dual_add_f32 v3, v3, v13 :: v_dual_add_f32 v4, v4, v14   // 000000354DA8: C9081B03 03041D04
	v_xor_b32_e32 v14, 1, v0                                   // 000000354DB0: 3A1C0081
	s_waitcnt lgkmcnt(3)                                       // 000000354DB4: BF89FC37
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v6, v16   // 000000354DB8: C9081F05 05062106
	s_waitcnt lgkmcnt(2)                                       // 000000354DC0: BF89FC27
	v_add_f32_e32 v12, v10, v19                                // 000000354DC4: 0618270A
	ds_bpermute_b32 v10, v20, v2                               // 000000354DC8: DACC0000 0A000214
	.long 0xd44c0000                                           // 000000354DD0: D44C0000
	v_cndmask_b32_e32 v1, 32, v14, vcc_lo                      // 000000354DD4: 02021CA0
	ds_bpermute_b32 v13, v20, v4                               // 000000354DD8: DACC0000 0D000414
	ds_bpermute_b32 v16, v20, v5                               // 000000354DE0: DACC0000 10000514
	ds_bpermute_b32 v21, v20, v12                              // 000000354DE8: DACC0000 15000C14
	v_cndmask_b32_e64 v0, v0, v14, s0                          // 000000354DF0: D5010000 00021D00
	.long 0xd44a0000                                           // 000000354DF8: D44A0000
	v_cndmask_b32_e32 v1, 0, v17, vcc_lo                       // 000000354DFC: 02022280
	s_waitcnt lgkmcnt(5)                                       // 000000354E00: BF89FC57
	v_add_f32_e32 v7, v7, v18                                  // 000000354E04: 060E2507
	s_waitcnt lgkmcnt(4)                                       // 000000354E08: BF89FC47
	v_dual_add_f32 v1, v1, v11 :: v_dual_lshlrev_b32 v22, 2, v0// 000000354E0C: C9221701 01160082
	ds_bpermute_b32 v11, v20, v3                               // 000000354E14: DACC0000 0B000314
	ds_bpermute_b32 v18, v20, v6                               // 000000354E1C: DACC0000 12000614
	ds_bpermute_b32 v19, v20, v7                               // 000000354E24: DACC0000 13000714
	ds_bpermute_b32 v20, v20, v1                               // 000000354E2C: DACC0000 14000114
	s_and_b32 s0, s0, vcc_lo                                   // 000000354E34: 8B006A00
	s_waitcnt lgkmcnt(7)                                       // 000000354E38: BF89FC77
	v_add_f32_e32 v14, v2, v10                                 // 000000354E3C: 061C1502
	s_waitcnt lgkmcnt(6)                                       // 000000354E40: BF89FC67
	v_add_f32_e32 v10, v4, v13                                 // 000000354E44: 06141B04
	s_waitcnt lgkmcnt(3)                                       // 000000354E48: BF89FC37
	v_dual_add_f32 v0, v12, v21 :: v_dual_add_f32 v15, v3, v11 // 000000354E4C: C9082B0C 000E1703
	s_waitcnt lgkmcnt(2)                                       // 000000354E54: BF89FC27
	v_dual_add_f32 v11, v5, v16 :: v_dual_add_f32 v4, v6, v18  // 000000354E58: C9082105 0B042506
	s_waitcnt lgkmcnt(1)                                       // 000000354E60: BF89FC17
	v_add_f32_e32 v5, v7, v19                                  // 000000354E64: 060A2707
	s_waitcnt lgkmcnt(0)                                       // 000000354E68: BF89FC07
	v_add_f32_e32 v1, v1, v20                                  // 000000354E6C: 06022901
	ds_bpermute_b32 v16, v22, v15                              // 000000354E70: DACC0000 10000F16
	ds_bpermute_b32 v18, v22, v14                              // 000000354E78: DACC0000 12000E16
	ds_bpermute_b32 v13, v22, v11                              // 000000354E80: DACC0000 0D000B16
	ds_bpermute_b32 v12, v22, v10                              // 000000354E88: DACC0000 0C000A16
	ds_bpermute_b32 v6, v22, v5                                // 000000354E90: DACC0000 06000516
	ds_bpermute_b32 v7, v22, v4                                // 000000354E98: DACC0000 07000416
	ds_bpermute_b32 v2, v22, v1                                // 000000354EA0: DACC0000 02000116
	ds_bpermute_b32 v3, v22, v0                                // 000000354EA8: DACC0000 03000016
	s_and_saveexec_b32 s1, s0                                  // 000000354EB0: BE812000
	s_cbranch_execz 120                                        // 000000354EB4: BFA50078 <_ZN7halogen12_GLOBAL__N_16k_lq6wILi8ELi16ELi1EEEvPKhPKtPtll+0x1798>
	s_waitcnt lgkmcnt(6)                                       // 000000354EB8: BF89FC67
	v_dual_add_f32 v14, v14, v18 :: v_dual_add_f32 v15, v15, v16// 000000354EBC: C908250E 0E0E210F
	.long 0x7f203880                                           // 000000354EC4: 7F203880
	.long 0xd73c0008                                           // 000000354EC8: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000354ECC: 02021081
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000354ED0: 84808102
	s_delay_alu instid0(VALU_DEP_3)                            // 000000354ED4: BF870003
	.long 0x7e20398e                                           // 000000354ED8: 7E20398E
	.long 0x7e22398f                                           // 000000354EDC: 7E22398F
	.long 0x7f223990                                           // 000000354EE0: 7F223990
	s_waitcnt lgkmcnt(5)                                       // 000000354EE4: BF89FC57
	v_add_f32_e32 v13, v11, v13                                // 000000354EE8: 061A1B0B
	.long 0xd7006a08                                           // 000000354EEC: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000354EF0: 02021008
	v_and_b32_e32 v18, 1, v16                                  // 000000354EF4: 36242081
	s_waitcnt lgkmcnt(4)                                       // 000000354EF8: BF89FC47
	v_dual_add_f32 v12, v10, v12 :: v_dual_and_b32 v17, 1, v17 // 000000354EFC: C924190A 0C102281
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 000000354F04: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000354F0C: BF870223
	v_add3_u32 v18, v14, v18, 0x7fff                           // 000000354F10: D6550012 03FE250E 00007FFF
	.long 0xd7006a0e                                           // 000000354F1C: D7006A0E
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000354F20: 02000108
	v_add3_u32 v17, v15, v17, 0x7fff                           // 000000354F24: D6550011 03FE230F 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000354F30: BF870004
	v_add_co_ci_u32_e64 v15, null, s1, v9, vcc_lo              // 000000354F34: D5207C0F 01AA1201
	s_clause 0x1                                               // 000000354F3C: BF850001
	global_store_d16_hi_b16 v[8:9], v17, off                   // 000000354F40: DC960000 007C1108
	global_store_d16_hi_b16 v[14:15], v18, off                 // 000000354F48: DC960000 007C120E
	.long 0x7e1c398d                                           // 000000354F50: 7E1C398D
	.long 0x7f1c3990                                           // 000000354F54: 7F1C3990
	.long 0x7e20398c                                           // 000000354F58: 7E20398C
	s_waitcnt lgkmcnt(3)                                       // 000000354F5C: BF89FC37
	v_add_f32_e32 v15, v5, v6                                  // 000000354F60: 061E0D05
	s_lshl_b64 s[0:1], s[2:3], 2                               // 000000354F64: 84808202
	s_waitcnt lgkmcnt(2)                                       // 000000354F68: BF89FC27
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v14, 1, v14    // 000000354F6C: C9240F04 070E1C81
	v_mad_u64_u32 v[4:5], null, s2, 6, v[8:9]                  // 000000354F74: D6FE7C04 04210C02
	.long 0xd7006a0a                                           // 000000354F7C: D7006A0A
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 000000354F80: 02000108
	s_delay_alu instid0(VALU_DEP_1)                            // 000000354F84: BF870001
	v_add_co_ci_u32_e64 v11, null, s1, v9, vcc_lo              // 000000354F88: D5207C0B 01AA1201
	v_and_b32_e32 v6, 1, v16                                   // 000000354F90: 360C2081
	v_add3_u32 v8, v13, v14, 0x7fff                            // 000000354F94: D6550008 03FE1D0D 00007FFF
	.long 0x7e12398f                                           // 000000354FA0: 7E12398F
	.long 0x7f123990                                           // 000000354FA4: 7F123990
	.long 0x7e203987                                           // 000000354FA8: 7E203987
	v_add3_u32 v12, v12, v6, 0x7fff                            // 000000354FAC: D655000C 03FE0D0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v8, off                  // 000000354FB8: DC960000 007C080A
	v_mad_u64_u32 v[5:6], null, s3, 6, v[5:6]                  // 000000354FC0: D6FE7C05 04150C03
	s_waitcnt lgkmcnt(0)                                       // 000000354FC8: BF89FC07
	v_dual_add_f32 v13, v0, v3 :: v_dual_and_b32 v8, 1, v9     // 000000354FCC: C9240700 0D081281
	v_dual_add_f32 v9, v1, v2 :: v_dual_and_b32 v6, 1, v16     // 000000354FD4: C9240501 09062081
	.long 0xd7006a00                                           // 000000354FDC: D7006A00
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 000000354FE0: 0200010A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000354FE4: BF870193
	.long 0x7e20398d                                           // 000000354FE8: 7E20398D
	v_add3_u32 v10, v7, v6, 0x7fff                             // 000000354FEC: D655000A 03FE0D07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000354FF8: BF870004
	.long 0x7e0c3989                                           // 000000354FFC: 7E0C3989
	.long 0x7f0c3990                                           // 000000355000: 7F0C3990
	v_add_co_ci_u32_e64 v1, null, s1, v11, vcc_lo              // 000000355004: D5207C01 01AA1601
	v_add3_u32 v11, v15, v8, 0x7fff                            // 00000035500C: D655000B 03FE110F 00007FFF
	.long 0xd7006a02                                           // 000000355018: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 00000035501C: 02000104
	v_and_b32_e32 v8, 1, v16                                   // 000000355020: 36102081
	v_and_b32_e32 v14, 1, v6                                   // 000000355024: 361C0C81
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 000000355028: D5207C03 01AA0A01
	.long 0xd7006a06                                           // 000000355030: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000355034: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000355038: BF870001
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000035503C: D5207C07 01AA0201
	v_add3_u32 v13, v13, v8, 0x7fff                            // 000000355044: D655000D 03FE110D 00007FFF
	.long 0xd7006a08                                           // 000000355050: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000355054: 02000102
	v_add3_u32 v14, v9, v14, 0x7fff                            // 000000355058: D655000E 03FE1D09 00007FFF
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 000000355064: D5207C09 01AA0601
	s_clause 0x4                                               // 00000035506C: BF850004
	global_store_d16_hi_b16 v[4:5], v12, off                   // 000000355070: DC960000 007C0C04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 000000355078: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v10, off                   // 000000355080: DC960000 007C0A02
	global_store_d16_hi_b16 v[6:7], v14, off                   // 000000355088: DC960000 007C0E06
	global_store_d16_hi_b16 v[8:9], v13, off                   // 000000355090: DC960000 007C0D08
	s_endpgm                                                   // 000000355098: BFB00000
		...

