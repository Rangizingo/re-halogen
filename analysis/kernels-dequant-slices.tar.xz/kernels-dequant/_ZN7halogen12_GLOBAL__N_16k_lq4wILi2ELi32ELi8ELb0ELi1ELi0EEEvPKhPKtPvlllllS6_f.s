00000000007bd500 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007BD500: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000007BD508: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007BD510: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007BD514: 86039F02
	v_lshrrev_b32_e32 v15, 5, v0                               // 0000007BD518: 321E0085
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BD51C: BF870003
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BD520: 30020282
	.long 0x7f283880                                           // 0000007BD524: 7F283880
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v2, 60, v2         // 0000007BD528: CA240080 110204BC
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 0000007BD530: CA100080 04020080
	v_lshlrev_b32_e32 v14, 2, v0                               // 0000007BD538: 301C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007BD53C: BF89FC07
	s_clause 0x1                                               // 0000007BD540: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 0000007BD544: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 0000007BD54C: DC520000 0D040002
	.long 0xd4510014                                           // 0000007BD554: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007BD558: 02001802
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000007BD55C: CA100080 01020080
	s_and_b32 s20, s20, exec_lo                                // 0000007BD564: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 0000007BD568: 98188003
	s_cselect_b32 s25, s2, 0                                   // 0000007BD56C: 98198002
	s_add_u32 s14, s4, s14                                     // 0000007BD570: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007BD574: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 0000007BD578: 85149F0B
	v_dual_mov_b32 v5, s14 :: v_dual_and_b32 v16, 31, v0       // 0000007BD57C: CA24000E 0510009F
	s_add_u32 s20, s10, s20                                    // 0000007BD584: 8014140A
	s_addc_u32 s21, s11, 0                                     // 0000007BD588: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000007BD58C: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 0000007BD590: 86948114
	s_lshr_b32 s22, s22, 27                                    // 0000007BD594: 85169B16
	v_mov_b32_e32 v6, s15                                      // 0000007BD598: 7E0C020F
	s_add_u32 s22, s10, s22                                    // 0000007BD59C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000007BD5A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000007BD5A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000007BD5A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007BD5AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000007BD5B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000007BD5B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007BD5B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000007BD5BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000007BD5C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BD5C4: BF870009
	s_ashr_i32 s14, s23, 3                                     // 0000007BD5C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000007BD5CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000007BD5D0: 82051105
	.long 0xd72c0013                                           // 0000007BD5D4: D72C0013
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000007BD5D8: 02021E0E
	v_dual_mov_b32 v8, s5 :: v_dual_mov_b32 v7, s4             // 0000007BD5DC: CA100005 08060004
	v_mad_u64_u32 v[9:10], null, s25, s20, v[5:6]              // 0000007BD5E4: D6FE7C09 04142819
	s_mul_i32 s4, s24, s20                                     // 0000007BD5EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000007BD5F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000007BD5F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000007BD5FC: BF8903F7
	v_bfe_u32 v5, v13, 16, 1                                   // 0000007BD600: D6100005 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000007BD608: BF870232
	v_add3_u32 v6, v11, v12, 0x7fff                            // 0000007BD60C: D6550006 03FE190B 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, s25, v[7:8]             // 0000007BD618: D6FE7C0B 041C3212
	v_add_nc_u32_e32 v7, s14, v19                              // 0000007BD620: 4A0E260E
	v_add3_u32 v5, v13, v5, 0x7fff                             // 0000007BD624: D6550005 03FE0B0D 00007FFF
	s_mul_i32 s25, s25, s21                                    // 0000007BD630: 96191519
	.long 0x7e283986                                           // 0000007BD634: 7E283986
	v_add_nc_u32_e32 v6, s4, v10                               // 0000007BD638: 4A0C1404
	v_add_nc_u32_e32 v10, v19, v16                             // 0000007BD63C: 4A142113
	v_min_i32_e32 v19, s22, v7                                 // 0000007BD640: 22260E16
	v_add_nc_u32_e32 v7, s19, v12                              // 0000007BD644: 4A0E1813
	s_mul_i32 s4, s18, s24                                     // 0000007BD648: 96041812
	v_and_or_b32 v5, 0xffff0000, v5, v20                       // 0000007BD64C: D6570005 04520AFF FFFF0000
	v_add_nc_u32_e32 v20, s25, v6                              // 0000007BD658: 4A280C19
	v_cmp_lt_i32_e32 vcc_lo, v10, v19                          // 0000007BD65C: 7C82270A
	v_add_nc_u32_e32 v21, s4, v7                               // 0000007BD660: 4A2A0E04
	ds_store_b32 v14, v5                                       // 0000007BD664: D8340000 0000050E
	s_waitcnt lgkmcnt(0)                                       // 0000007BD66C: BF89FC07
	s_barrier                                                  // 0000007BD670: BFBD0000
	buffer_gl0_inv                                             // 0000007BD674: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 0000007BD67C: BE85206A
	s_cbranch_execz 21                                         // 0000007BD680: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1d8>
	v_lshlrev_b32_e32 v1, 1, v10                               // 0000007BD684: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 0000007BD688: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD68C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007BD690: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007BD694: 3408069F
	.long 0xd7000401                                           // 0000007BD698: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000007BD69C: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BD6A0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s4                  // 0000007BD6A4: D5207C02 00120515
	.long 0xd7000403                                           // 0000007BD6AC: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000007BD6B0: 02020709
	v_add_co_ci_u32_e64 v4, null, v20, v4, s4                  // 0000007BD6B4: D5207C04 00120914
	s_clause 0x1                                               // 0000007BD6BC: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000007BD6C0: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007BD6C8: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007BD6D0: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000007BD6D4: 7E241705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BD6D8: 8C7E057E
	v_mov_b32_e32 v22, 0                                       // 0000007BD6DC: 7E2C0280
	s_and_saveexec_b32 s5, vcc_lo                              // 0000007BD6E0: BE85206A
	s_cbranch_execz 264                                        // 0000007BD6E4: BFA50108 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x608>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v10     // 0000007BD6E8: CA200080 160414A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 0000007BD6F0: CA220080 110C1485
	s_mov_b32 s14, 0                                           // 0000007BD6F8: BE8E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BD6FC: BF870002
	v_lshlrev_b32_e32 v23, 4, v5                               // 0000007BD700: 302E0A84
	v_dual_mov_b32 v25, v18 :: v_dual_lshlrev_b32 v24, 1, v5   // 0000007BD704: CA220112 19180A81
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007BD70C: 848A810A
	s_branch 221                                               // 0000007BD710: BFA000DD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x588>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007BD714: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000007BD718: 341A189F
	v_lshrrev_b32_e32 v58, 6, v1                               // 0000007BD71C: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 0000007BD720: 3276028E
	v_and_b32_e32 v60, 0xff, v2                                // 0000007BD724: 367804FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v2                               // 0000007BD72C: 327A0486
	.long 0xd73c001a                                           // 0000007BD730: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007BD734: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000007BD738: 361A02FF 000000FF
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000007BD740: 367474FF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000007BD748: 367676FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007BD750: 32020296
	v_lshrrev_b32_e32 v62, 14, v2                              // 0000007BD754: 327C048E
	.long 0xd7000432                                           // 0000007BD758: D7000432
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 0000007BD75C: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BD760: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s7, v27, s4                 // 0000007BD764: D5207C33 00123607
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000007BD76C: 301A1A82
	.long 0xd7000436                                           // 0000007BD770: D7000436
	v_cndmask_b32_e32 v0, v50, v10, vcc_lo                     // 0000007BD774: 02001532
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BD778: BF870001
	v_add_co_ci_u32_e64 v55, null, s11, v51, s4                // 0000007BD77C: D5207C37 0012660B
	ds_load_b32 v13, v13                                       // 0000007BD784: D8D80000 0D00000D
	ds_load_b32 v58, v58                                       // 0000007BD78C: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000007BD794: D8D80000 3B00003B
	s_clause 0x7                                               // 0000007BD79C: BF850007
	global_load_b128 v[26:29], v[50:51], off                   // 0000007BD7A0: DC5E0000 1A7C0032
	global_load_b128 v[30:33], v[54:55], off                   // 0000007BD7A8: DC5E0000 1E7C0036
	global_load_b128 v[34:37], v[50:51], off offset:16         // 0000007BD7B0: DC5E0010 227C0032
	global_load_b128 v[38:41], v[54:55], off offset:16         // 0000007BD7B8: DC5E0010 267C0036
	global_load_b128 v[42:45], v[50:51], off offset:32         // 0000007BD7C0: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000007BD7C8: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000007BD7D0: DC5E0030 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:48         // 0000007BD7D8: DC5E0030 367C0036
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007BD7E0: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007BD7E4: 360202FF 000003FC
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000007BD7EC: 30787882
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000007BD7F0: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 0000007BD7F8: 367C7CFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007BD800: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007BD808: D8D80000 01000001
	ds_load_b32 v60, v60                                       // 0000007BD810: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 0000007BD818: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 0000007BD820: D8D80000 3E00003E
	ds_load_b32 v2, v2                                         // 0000007BD828: D8D80000 02000002
	v_add_nc_u32_e32 v23, 0x200, v23                           // 0000007BD830: 4A2E2EFF 00000200
	v_add_nc_u32_e32 v24, 64, v24                              // 0000007BD838: 4A3030C0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000007BD83C: 4A1818FF 00000400
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000007BD844: 8B046A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BD848: BF870009
	s_or_b32 s14, s4, s14                                      // 0000007BD84C: 8C0E0E04
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007BD850: BF891C77
	v_dot2_f32_bf16 v26, v26, v13, 0                           // 0000007BD854: CC1A401A 1A021B1A
	s_waitcnt vmcnt(6)                                         // 0000007BD85C: BF891BF7
	v_dot2_f32_bf16 v13, v30, v13, 0                           // 0000007BD860: CC1A400D 1A021B1E
	v_and_b32_e32 v30, 0xff, v3                                // 0000007BD868: 363C06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007BD870: BF89FC67
	v_dot2_f32_bf16 v26, v27, v58, v26                         // 0000007BD874: CC1A401A 1C6A751B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BD87C: BF870003
	v_dot2_f32_bf16 v13, v31, v58, v13                         // 0000007BD880: CC1A400D 1C36751F
	v_lshrrev_b32_e32 v27, 6, v3                               // 0000007BD888: 32360686
	v_lshrrev_b32_e32 v31, 14, v3                              // 0000007BD88C: 323E068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007BD890: 32060696
	s_waitcnt lgkmcnt(5)                                       // 0000007BD894: BF89FC57
	v_dot2_f32_bf16 v26, v28, v59, v26                         // 0000007BD898: CC1A401A 1C6A771C
	v_dot2_f32_bf16 v13, v32, v59, v13                         // 0000007BD8A0: CC1A400D 1C367720
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000007BD8A8: 363636FF 000003FC
	v_and_b32_e32 v28, 0xff, v4                                // 0000007BD8B0: 363808FF 000000FF
	v_lshrrev_b32_e32 v32, 6, v4                               // 0000007BD8B8: 32400886
	s_waitcnt lgkmcnt(4)                                       // 0000007BD8BC: BF89FC47
	v_dot2_f32_bf16 v26, v29, v1, v26                          // 0000007BD8C0: CC1A401A 1C6A031D
	v_dot2_f32_bf16 v1, v33, v1, v13                           // 0000007BD8C8: CC1A4001 1C360321
	v_lshlrev_b32_e32 v13, 2, v30                              // 0000007BD8D0: 301A3C82
	v_and_b32_e32 v29, 0x3fc, v31                              // 0000007BD8D4: 363A3EFF 000003FC
	v_lshrrev_b32_e32 v58, 14, v4                              // 0000007BD8DC: 3274088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007BD8E0: BF891437
	v_dot2_f32_bf16 v26, v34, v60, v26                         // 0000007BD8E4: CC1A401A 1C6A7922
	s_waitcnt vmcnt(4)                                         // 0000007BD8EC: BF8913F7
	v_dot2_f32_bf16 v1, v38, v60, v1                           // 0000007BD8F0: CC1A4001 1C067926
	ds_load_b32 v13, v13                                       // 0000007BD8F8: D8D80000 0D00000D
	ds_load_b32 v27, v27                                       // 0000007BD900: D8D80000 1B00001B
	ds_load_b32 v29, v29                                       // 0000007BD908: D8D80000 1D00001D
	s_waitcnt lgkmcnt(5)                                       // 0000007BD910: BF89FC57
	v_dot2_f32_bf16 v26, v35, v61, v26                         // 0000007BD914: CC1A401A 1C6A7B23
	v_dot2_f32_bf16 v1, v39, v61, v1                           // 0000007BD91C: CC1A4001 1C067B27
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007BD924: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007BD928: 360606FF 000003FC
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000007BD930: 30383882
	s_waitcnt lgkmcnt(4)                                       // 0000007BD934: BF89FC47
	v_dot2_f32_bf16 v26, v36, v62, v26                         // 0000007BD938: CC1A401A 1C6A7D24
	v_dot2_f32_bf16 v1, v40, v62, v1                           // 0000007BD940: CC1A4001 1C067D28
	v_and_b32_e32 v30, 0x3fc, v32                              // 0000007BD948: 363C40FF 000003FC
	v_and_b32_e32 v31, 0x3fc, v58                              // 0000007BD950: 363E74FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007BD958: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007BD960: BF89FC37
	v_dot2_f32_bf16 v26, v37, v2, v26                          // 0000007BD964: CC1A401A 1C6A0525
	v_dot2_f32_bf16 v1, v41, v2, v1                            // 0000007BD96C: CC1A4001 1C060529
	ds_load_b32 v2, v3                                         // 0000007BD974: D8D80000 02000003
	ds_load_b32 v3, v28                                        // 0000007BD97C: D8D80000 0300001C
	ds_load_b32 v28, v30                                       // 0000007BD984: D8D80000 1C00001E
	ds_load_b32 v30, v31                                       // 0000007BD98C: D8D80000 1E00001F
	ds_load_b32 v31, v4                                        // 0000007BD994: D8D80000 1F000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000007BD99C: BF890C77
	v_dot2_f32_bf16 v4, v42, v13, v26                          // 0000007BD9A0: CC1A4004 1C6A1B2A
	s_waitcnt vmcnt(2)                                         // 0000007BD9A8: BF890BF7
	v_dot2_f32_bf16 v1, v46, v13, v1                           // 0000007BD9AC: CC1A4001 1C061B2E
	s_waitcnt lgkmcnt(6)                                       // 0000007BD9B4: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD9B8: BF870112
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 0000007BD9BC: CC1A4004 1C12372B
	v_dot2_f32_bf16 v1, v47, v27, v1                           // 0000007BD9C4: CC1A4001 1C06372F
	s_waitcnt lgkmcnt(5)                                       // 0000007BD9CC: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD9D0: BF870112
	v_dot2_f32_bf16 v4, v44, v29, v4                           // 0000007BD9D4: CC1A4004 1C123B2C
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 0000007BD9DC: CC1A4001 1C063B30
	s_waitcnt lgkmcnt(4)                                       // 0000007BD9E4: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BD9E8: BF870112
	v_dot2_f32_bf16 v4, v45, v2, v4                            // 0000007BD9EC: CC1A4004 1C12052D
	v_dot2_f32_bf16 v1, v49, v2, v1                            // 0000007BD9F4: CC1A4001 1C060531
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007BD9FC: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BDA00: BF870122
	v_dot2_f32_bf16 v2, v50, v3, v4                            // 0000007BDA04: CC1A4002 1C120732
	s_waitcnt vmcnt(0)                                         // 0000007BDA0C: BF8903F7
	v_dot2_f32_bf16 v1, v54, v3, v1                            // 0000007BDA10: CC1A4001 1C060736
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000007BDA18: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 0000007BDA20: BF89FC27
	v_dot2_f32_bf16 v2, v51, v28, v2                           // 0000007BDA24: CC1A4002 1C0A3933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BDA2C: BF870123
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 0000007BDA30: CC1A4001 1C063937
	s_waitcnt lgkmcnt(1)                                       // 0000007BDA38: BF89FC17
	v_dot2_f32_bf16 v2, v52, v30, v2                           // 0000007BDA3C: CC1A4002 1C0A3D34
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BDA44: BF870122
	v_dot2_f32_bf16 v1, v56, v30, v1                           // 0000007BDA48: CC1A4001 1C063D38
	s_waitcnt lgkmcnt(0)                                       // 0000007BDA50: BF89FC07
	v_dot2_f32_bf16 v7, v53, v31, v2                           // 0000007BDA54: CC1A4007 1C0A3F35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BDA5C: BF8701A2
	v_dot2_f32_bf16 v8, v57, v31, v1                           // 0000007BDA60: CC1A4008 1C063F39
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 0000007BDA68: CA100106 02000105
	v_fmac_f32_e32 v22, v18, v7                                // 0000007BDA70: 562C0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BDA74: BF870003
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v25    // 0000007BDA78: C8101112 11120119
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007BDA80: 917E0E7E
	s_cbranch_execz 31                                         // 0000007BDA84: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x604>
	s_waitcnt vmcnt(0)                                         // 0000007BDA88: BF8903F7
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v10, 32, v10    // 0000007BDA8C: CA200101 050A14A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 0000007BDA94: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 0000007BDA9C: 7E100304
	s_mov_b32 s15, exec_lo                                     // 0000007BDAA0: BE8F007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BDAA4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v19                          // 0000007BDAA8: 7C8C270A
	.long 0xd4c1007e                                           // 0000007BDAAC: D4C1007E
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 0000007BDAB0: 0202270A
	s_cbranch_execz 65303                                      // 0000007BDAB4: BFA5FF17 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x214>
	v_ashrrev_i32_e32 v6, 31, v24                              // 0000007BDAB8: 340C309F
	v_ashrrev_i32_e32 v8, 31, v23                              // 0000007BDABC: 34102E9F
	.long 0xd7000405                                           // 0000007BDAC0: D7000405
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 0000007BDAC4: 0202310B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BDAC8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s4                  // 0000007BDACC: D5207C06 00120D15
	.long 0xd7000407                                           // 0000007BDAD4: D7000407
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 0000007BDAD8: 02022F09
	v_add_co_ci_u32_e64 v8, null, v20, v8, s4                  // 0000007BDADC: D5207C08 00121114
	s_clause 0x1                                               // 0000007BDAE4: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000007BDAE8: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000007BDAF0: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000007BDAF8: BF8907F7
	v_cvt_f32_f16_e32 v25, v13                                 // 0000007BDAFC: 7E32170D
	s_branch 65284                                             // 0000007BDB00: BFA0FF04 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x214>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007BDB04: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000007BDB08: BF8700C9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BDB0C: 8C7E057E
	s_waitcnt vmcnt(0)                                         // 0000007BDB10: BF8903F7
	.long 0xd71f0001                                           // 0000007BDB14: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BDB18: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007BDB1C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007BDB20: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 0000007BDB24: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 0000007BDB28: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BDB2C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007BDB30: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007BDB34: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007BDB38: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BDB3C: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007BDB40: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007BDB44: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BDB48: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 0000007BDB4C: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007BDB54: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BDB58: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 0000007BDB5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BDB60: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 0000007BDB64: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 0000007BDB6C: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 0000007BDB74: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 0000007BDB78: 06060B03
	ds_bpermute_b32 v2, v2, v17                                // 0000007BDB7C: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 0000007BDB84: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 0000007BDB88: 06040511
	ds_bpermute_b32 v4, v4, v2                                 // 0000007BDB8C: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 0000007BDB94: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007BDB98: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BDB9C: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BDBA4: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 0000007BDBAC: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BDBB0: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BDBB4: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 0000007BDBB8: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BDBBC: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 0000007BDBC0: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 0000007BDBC8: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000007BDBCC: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 0000007BDBD0: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 0000007BDBD8: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 0000007BDBE0: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BDBE4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000007BDBE8: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 0000007BDBEC: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 0000007BDBF0: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 0000007BDBF4: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 0000007BDBFC: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000007BDC00: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 0000007BDC04: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 0000007BDC0C: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v16                                   // 0000007BDC14: 7D942080
	s_cbranch_execz 6                                          // 0000007BDC18: BFA50006 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x734>
	s_waitcnt lgkmcnt(0)                                       // 0000007BDC1C: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v15 // 0000007BDC20: C9220902 02041E83
	v_add_f32_e32 v1, v1, v3                                   // 0000007BDC28: 06020701
	ds_store_b64 v5, v[1:2] offset:1024                        // 0000007BDC2C: D9340400 00000105
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BDC34: 8C7E047E
	.long 0xd4510004                                           // 0000007BDC38: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 0000007BDC3C: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 2, v0                             // 0000007BDC40: 7C980082
	s_waitcnt lgkmcnt(0)                                       // 0000007BDC44: BF89FC07
	s_barrier                                                  // 0000007BDC48: BFBD0000
	buffer_gl0_inv                                             // 0000007BDC4C: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007BDC54: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BDC58: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007BDC5C: BE852004
	s_cbranch_execz 89                                         // 0000007BDC60: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi8ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x8c8>
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BDC64: F4000000 F8000048
	v_add_nc_u32_e32 v7, 0x400, v14                            // 0000007BDC6C: 4A0E1CFF 00000400
	ds_load_2addr_b32 v[1:2], v7 offset1:2                     // 0000007BDC74: D8DC0200 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:4 offset1:6           // 0000007BDC7C: D8DC0604 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:8 offset1:10          // 0000007BDC84: D8DC0A08 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007BDC8C: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007BDC90: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007BDC94: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007BDC98: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:12 offset1:14         // 0000007BDC9C: D8DC0E0C 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007BDCA4: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007BDCA8: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDCAC: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007BDCB0: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007BDCB4: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007BDCB8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDCBC: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007BDCC0: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007BDCC4: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDCC8: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007BDCCC: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007BDCD4: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDCE0: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007BDCE4: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007BDCEC: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007BDCF0: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDCF4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007BDCF8: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007BDD00: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDD04: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007BDD08: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007BDD0C: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007BDD14: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BDD1C: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007BDD20: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007BDD24: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BDD2C: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007BDD30: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 0000007BDD34: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 0000007BDD3C: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDD40: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007BDD44: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007BDD4C: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BDD50: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007BDD54: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 0000007BDD5C: D6FE7C02 040A000D
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007BDD64: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BDD6C: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007BDD70: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007BDD78: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007BDD7C: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BDD80: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007BDD84: D6100002 02052103
	.long 0xd7006a00                                           // 0000007BDD8C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007BDD90: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BDD94: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007BDD98: D5207C01 01AA0209
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007BDDA0: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BDDAC: BF870093
	.long 0xd7006a00                                           // 0000007BDDB0: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007BDDB4: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007BDDB8: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007BDDC0: DC960000 007C0200
	s_endpgm                                                   // 0000007BDDC8: BFB00000
		...

