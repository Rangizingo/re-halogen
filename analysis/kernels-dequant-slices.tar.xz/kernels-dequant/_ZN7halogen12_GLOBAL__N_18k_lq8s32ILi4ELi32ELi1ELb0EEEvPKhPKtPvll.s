0000000000588000 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000588000: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000588004: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000058800C: F4040300 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000588014: 32020085
	s_mov_b32 s3, 0                                            // 000000588018: BE830080
	v_dual_mov_b32 v16, 0 :: v_dual_and_b32 v15, 31, v0        // 00000058801C: CA240080 100E009F
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000588024: 84808302
	.long 0x7e2e3880                                           // 000000588028: 7E2E3880
	v_or_b32_e32 v9, s0, v1                                    // 00000058802C: 38120200
	v_dual_mov_b32 v10, s1 :: v_dual_mov_b32 v3, 0             // 000000588030: CA100001 0A020080
	v_lshlrev_b32_e32 v11, 4, v15                              // 000000588038: 30161E84
	s_waitcnt lgkmcnt(0)                                       // 00000058803C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 000000588040: 86009F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000588044: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 000000588048: 7CA8120C
	s_lshr_b32 s0, s0, 28                                      // 00000058804C: 85009C00
	s_add_u32 s2, s10, s0                                      // 000000588050: 8002000A
	s_addc_u32 s3, s11, 0                                      // 000000588054: 8203800B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000588058: BF870009
	s_ashr_i64 s[2:3], s[2:3], 4                               // 00000058805C: 86828402
	v_cndmask_b32_e32 v1, 0, v9, vcc_lo                        // 000000588060: 02021280
	s_add_u32 s0, s10, s2                                      // 000000588064: 8000020A
	v_cndmask_b32_e64 v2, 0, s1, vcc_lo                        // 000000588068: D5010002 01A80280
	s_addc_u32 s1, s11, s3                                     // 000000588070: 8201030B
	s_add_u32 s0, s0, 15                                       // 000000588074: 80008F00
	s_addc_u32 s1, s1, 0                                       // 000000588078: 82018001
	s_and_b32 s0, s0, -16                                      // 00000058807C: 8B00D000
	.long 0xd72c0004                                           // 000000588080: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 000000588084: 02000301
	.long 0xd72c0007                                           // 000000588088: D72C0007
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 00000058808C: 02000102
	v_mad_u64_u32 v[5:6], null, v1, s0, 0                      // 000000588090: D6FE7C05 02000101
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 000000588098: CA100080 01020080
	.long 0xd4440000                                           // 0000005880A0: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 0000005880A4: 02021E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000005880A8: BF870213
	v_add3_u32 v6, v6, v4, v7                                  // 0000005880AC: D6550006 041E0906
	.long 0xd7000111                                           // 0000005880B4: D7000111
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000005880B8: 02020A04
	v_mov_b32_e32 v4, 0                                        // 0000005880BC: 7E080280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005880C0: BF870003
	v_add_co_ci_u32_e64 v18, null, s5, v6, s1                  // 0000005880C4: D5207C12 00060C05
	s_and_saveexec_b32 s3, s0                                  // 0000005880CC: BE832000
	s_cbranch_execz 21                                         // 0000005880D0: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x128>
	v_lshlrev_b32_e32 v1, 4, v15                               // 0000005880D4: 30021E84
	.long 0xd7000103                                           // 0000005880D8: D7000103
	v_cndmask_b32_e32 v0, v17, v10, vcc_lo                     // 0000005880DC: 02001511
	v_and_b32_e32 v7, 30, v0                                   // 0000005880E0: 360E009E
	v_add_co_ci_u32_e64 v4, null, s11, v18, s1                 // 0000005880E4: D5207C04 0006240B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005880EC: BF870094
	.long 0xd7000101                                           // 0000005880F0: D7000101
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000005880F4: 02020311
	v_add_co_ci_u32_e64 v2, null, 0, v18, s1                   // 0000005880F8: D5207C02 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588100: BF870094
	.long 0xd7000107                                           // 000000588104: D7000107
	v_cndmask_b32_e32 v1, v3, v7, vcc_lo                       // 000000588108: 02020F03
	v_add_co_ci_u32_e64 v8, null, 0, v4, s1                    // 00000058810C: D5207C08 00060880
	s_clause 0x1                                               // 000000588114: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000588118: DC5E0000 017C0001
	global_load_d16_b16 v23, v[7:8], off                       // 000000588120: DC820000 177C0007
	s_or_b32 exec_lo, exec_lo, s3                              // 000000588128: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 00000058812C: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 000000588134: 7E2A0280
	s_and_saveexec_b32 s3, s0                                  // 000000588138: BE832000
	s_cbranch_execz 386                                        // 00000058813C: BFA50182 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x748>
	v_and_or_b32 v0, v0, 30, 32                                // 000000588140: D6570000 02813D00
	.long 0xd7000005                                           // 000000588148: D7000005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000058814C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000588150: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s11, v6, s0                  // 000000588154: D5207C06 00020C0B
	v_mov_b32_e32 v12, 0                                       // 00000058815C: 7E180280
	.long 0xd7000000                                           // 000000588160: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 000000588164: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000588168: BF870191
	v_add_co_ci_u32_e64 v5, null, 0, v6, s0                    // 00000058816C: D5207C05 00020C80
	v_dual_mov_b32 v22, v15 :: v_dual_mov_b32 v21, v12         // 000000588174: CA10010F 1614010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058817C: BF870093
	.long 0xd700000d                                           // 000000588180: D700000D
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 000000588184: 02020004
	v_add_co_ci_u32_e64 v14, null, s5, v5, s0                  // 000000588188: D5207C0E 00020A05
	v_mov_b32_e32 v20, v12                                     // 000000588190: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 000000588194: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000588198: 7E20030C
	s_mul_i32 s1, s11, 6                                       // 00000058819C: 9601860B
	s_mul_hi_u32 s16, s10, 6                                   // 0000005881A0: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 0000005881A4: 848E820A
	s_add_i32 s16, s16, s1                                     // 0000005881A8: 81100110
	s_mul_i32 s18, s10, 6                                      // 0000005881AC: 9612860A
	s_mov_b32 s17, 0                                           // 0000005881B0: BE910080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000005881B4: 8484810A
	s_branch 325                                               // 0000005881B8: BFA00145 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x6d0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000005881BC: 8C7E0A7E
	.long 0xd73c0019                                           // 0000005881C0: D73C0019
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000005881C4: 02021681
	v_bfe_i32 v57, v1, 0, 8                                    // 0000005881C8: D6110039 02210101
	v_bfe_i32 v58, v1, 8, 8                                    // 0000005881D0: D611003A 02211101
	v_bfe_i32 v59, v1, 16, 8                                   // 0000005881D8: D611003B 02212101
	v_bfe_i32 v63, v3, 0, 8                                    // 0000005881E0: D611003F 02210103
	v_bfe_i32 v64, v3, 8, 8                                    // 0000005881E8: D6110040 02211103
	.long 0xd7000129                                           // 0000005881F0: D7000129
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000005881F4: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005881F8: BF8701A1
	v_add_co_ci_u32_e64 v42, null, s7, v26, s1                 // 0000005881FC: D5207C2A 00063407
	v_bfe_i32 v65, v3, 16, 8                                   // 000000588204: D6110041 02212103
	.long 0xd700012d                                           // 00000058820C: D700012D
	v_cndmask_b32_e32 v0, v41, v4, vcc_lo                      // 000000588210: 02000929
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000588214: BF8700A1
	v_add_co_ci_u32_e64 v46, null, s5, v42, s1                 // 000000588218: D5207C2E 00065405
	.long 0xd7000131                                           // 000000588220: D7000131
	v_cndmask_b32_e32 v0, v41, v14, vcc_lo                     // 000000588224: 02001D29
	v_add_co_ci_u32_e64 v50, null, s15, v42, s1                // 000000588228: D5207C32 0006540F
	.long 0xd7000135                                           // 000000588230: D7000135
	v_cndmask_b32_e32 v0, v41, v18, vcc_lo                     // 000000588234: 02002529
	s_delay_alu instid0(VALU_DEP_1)                            // 000000588238: BF870001
	v_add_co_ci_u32_e64 v54, null, s16, v42, s1                // 00000058823C: D5207C36 00065410
	s_clause 0x7                                               // 000000588244: BF850007
	global_load_b128 v[25:28], v[41:42], off                   // 000000588248: DC5E0000 197C0029
	global_load_b128 v[29:32], v[45:46], off                   // 000000588250: DC5E0000 1D7C002D
	global_load_b128 v[33:36], v[49:50], off                   // 000000588258: DC5E0000 217C0031
	global_load_b128 v[37:40], v[53:54], off                   // 000000588260: DC5E0000 257C0035
	global_load_b128 v[41:44], v[41:42], off offset:16         // 000000588268: DC5E0010 297C0029
	global_load_b128 v[45:48], v[45:46], off offset:16         // 000000588270: DC5E0010 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:16         // 000000588278: DC5E0010 317C0031
	global_load_b128 v[53:56], v[53:54], off offset:16         // 000000588280: DC5E0010 357C0035
	v_ashrrev_i32_e32 v66, 24, v3                              // 000000588288: 34840698
	v_bfe_i32 v67, v4, 0, 8                                    // 00000058828C: D6110043 02210104
	v_bfe_i32 v68, v4, 8, 8                                    // 000000588294: D6110044 02211104
	v_bfe_i32 v69, v4, 16, 8                                   // 00000058829C: D6110045 02212104
	v_ashrrev_i32_e32 v70, 24, v4                              // 0000005882A4: 348C0898
	s_waitcnt vmcnt(9)                                         // 0000005882A8: BF8927F7
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000005882AC: CA100108 04020107
	v_cvt_f32_i32_e32 v7, v57                                  // 0000005882B4: 7E0E0B39
	.long 0x7f2e3880                                           // 0000005882B8: 7F2E3880
	v_ashrrev_i32_e32 v1, 24, v1                               // 0000005882BC: 34020298
	v_bfe_i32 v60, v2, 0, 8                                    // 0000005882C0: D611003C 02210102
	v_mov_b32_e32 v11, v24                                     // 0000005882C8: 7E160318
	v_cvt_f32_i32_e32 v8, v58                                  // 0000005882CC: 7E100B3A
	v_cvt_f32_i32_e32 v24, v59                                 // 0000005882D0: 7E300B3B
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000005882D4: CC200007 8A020F17
	v_bfe_i32 v61, v2, 8, 8                                    // 0000005882DC: D611003D 02211102
	v_bfe_i32 v62, v2, 16, 8                                   // 0000005882E4: D611003E 02212102
	v_ashrrev_i32_e32 v2, 24, v2                               // 0000005882EC: 34040498
	v_cvt_f32_i32_e32 v1, v1                                   // 0000005882F0: 7E020B01
	v_cvt_f32_i32_e32 v58, v60                                 // 0000005882F4: 7E740B3C
	v_fma_mix_f32 v8, v23, v8, neg(0) op_sel_hi:[1,0,0]        // 0000005882F8: CC200008 8A021117
	v_fma_mix_f32 v24, v23, v24, neg(0) op_sel_hi:[1,0,0]      // 000000588300: CC200018 8A023117
	v_bfe_u32 v72, v7, 16, 1                                   // 000000588308: D6100048 02052107
	v_cvt_f32_i32_e32 v59, v61                                 // 000000588310: 7E760B3D
	v_cvt_f32_i32_e32 v60, v62                                 // 000000588314: 7E780B3E
	v_cvt_f32_i32_e32 v2, v2                                   // 000000588318: 7E040B02
	v_cvt_f32_i32_e32 v62, v63                                 // 00000058831C: 7E7C0B3F
	v_cvt_f32_i32_e32 v63, v64                                 // 000000588320: 7E7E0B40
	v_cvt_f32_i32_e32 v64, v65                                 // 000000588324: 7E800B41
	v_cvt_f32_i32_e32 v66, v66                                 // 000000588328: 7E840B42
	v_cvt_f32_i32_e32 v67, v67                                 // 00000058832C: 7E860B43
	v_cvt_f32_i32_e32 v68, v68                                 // 000000588330: 7E880B44
	v_cvt_f32_i32_e32 v69, v69                                 // 000000588334: 7E8A0B45
	v_cvt_f32_i32_e32 v70, v70                                 // 000000588338: 7E8C0B46
	v_fma_mix_f32 v1, v23, v1, neg(0) op_sel_hi:[1,0,0]        // 00000058833C: CC200001 8A020317
	v_fma_mix_f32 v58, v23, v58, neg(0) op_sel_hi:[1,0,0]      // 000000588344: CC20003A 8A027517
	v_bfe_u32 v73, v8, 16, 1                                   // 00000058834C: D6100049 02052108
	v_bfe_u32 v74, v24, 16, 1                                  // 000000588354: D610004A 02052118
	v_add3_u32 v7, v7, v72, 0x7fff                             // 00000058835C: D6550007 03FE9107 00007FFF
	v_fma_mix_f32 v59, v23, v59, neg(0) op_sel_hi:[1,0,0]      // 000000588368: CC20003B 8A027717
	v_fma_mix_f32 v60, v23, v60, neg(0) op_sel_hi:[1,0,0]      // 000000588370: CC20003C 8A027917
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 000000588378: CC200002 8A020517
	v_fma_mix_f32 v62, v23, v62, neg(0) op_sel_hi:[1,0,0]      // 000000588380: CC20003E 8A027D17
	v_fma_mix_f32 v63, v23, v63, neg(0) op_sel_hi:[1,0,0]      // 000000588388: CC20003F 8A027F17
	v_fma_mix_f32 v64, v23, v64, neg(0) op_sel_hi:[1,0,0]      // 000000588390: CC200040 8A028117
	v_fma_mix_f32 v66, v23, v66, neg(0) op_sel_hi:[1,0,0]      // 000000588398: CC200042 8A028517
	v_fma_mix_f32 v67, v23, v67, neg(0) op_sel_hi:[1,0,0]      // 0000005883A0: CC200043 8A028717
	v_fma_mix_f32 v68, v23, v68, neg(0) op_sel_hi:[1,0,0]      // 0000005883A8: CC200044 8A028917
	v_fma_mix_f32 v69, v23, v69, neg(0) op_sel_hi:[1,0,0]      // 0000005883B0: CC200045 8A028B17
	v_fma_mix_f32 v70, v23, v70, neg(0) op_sel_hi:[1,0,0]      // 0000005883B8: CC200046 8A028D17
	v_bfe_u32 v75, v1, 16, 1                                   // 0000005883C0: D610004B 02052101
	v_bfe_u32 v76, v58, 16, 1                                  // 0000005883C8: D610004C 0205213A
	v_add3_u32 v8, v8, v73, 0x7fff                             // 0000005883D0: D6550008 03FE9308 00007FFF
	v_add3_u32 v24, v24, v74, 0x7fff                           // 0000005883DC: D6550018 03FE9518 00007FFF
	.long 0x7e2e3987                                           // 0000005883E8: 7E2E3987
	.long 0x7f723997                                           // 0000005883EC: 7F723997
	v_bfe_u32 v77, v59, 16, 1                                  // 0000005883F0: D610004D 0205213B
	v_bfe_u32 v78, v60, 16, 1                                  // 0000005883F8: D610004E 0205213C
	v_add3_u32 v1, v1, v75, 0x7fff                             // 000000588400: D6550001 03FE9701 00007FFF
	v_add3_u32 v58, v58, v76, 0x7fff                           // 00000058840C: D655003A 03FE993A 00007FFF
	.long 0x7e723998                                           // 000000588418: 7E723998
	v_and_or_b32 v7, 0xffff0000, v8, v23                       // 00000058841C: D6570007 045E10FF FFFF0000
	v_bfe_u32 v79, v2, 16, 1                                   // 000000588428: D610004F 02052102
	v_bfe_u32 v80, v62, 16, 1                                  // 000000588430: D6100050 0205213E
	v_add3_u32 v59, v59, v77, 0x7fff                           // 000000588438: D655003B 03FE9B3B 00007FFF
	v_add3_u32 v60, v60, v78, 0x7fff                           // 000000588444: D655003C 03FE9D3C 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v57                       // 000000588450: D6570001 04E602FF FFFF0000
	.long 0x7e2e39ba                                           // 00000058845C: 7E2E39BA
	.long 0x7f7a3997                                           // 000000588460: 7F7A3997
	v_bfe_u32 v81, v63, 16, 1                                  // 000000588464: D6100051 0205213F
	v_bfe_u32 v82, v64, 16, 1                                  // 00000058846C: D6100052 02052140
	v_add3_u32 v2, v2, v79, 0x7fff                             // 000000588474: D6550002 03FE9F02 00007FFF
	v_add3_u32 v62, v62, v80, 0x7fff                           // 000000588480: D655003E 03FEA13E 00007FFF
	.long 0x7e7a39bc                                           // 00000058848C: 7E7A39BC
	v_bfe_u32 v83, v66, 16, 1                                  // 000000588490: D6100053 02052142
	v_bfe_u32 v84, v67, 16, 1                                  // 000000588498: D6100054 02052143
	v_add3_u32 v63, v63, v81, 0x7fff                           // 0000005884A0: D655003F 03FEA33F 00007FFF
	v_add3_u32 v64, v64, v82, 0x7fff                           // 0000005884AC: D6550040 03FEA540 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v61                       // 0000005884B8: D6570002 04F604FF FFFF0000
	.long 0x7f823997                                           // 0000005884C4: 7F823997
	v_bfe_u32 v85, v68, 16, 1                                  // 0000005884C8: D6100055 02052144
	v_bfe_u32 v86, v69, 16, 1                                  // 0000005884D0: D6100056 02052145
	v_add3_u32 v66, v66, v83, 0x7fff                           // 0000005884D8: D6550042 03FEA742 00007FFF
	v_add3_u32 v67, v67, v84, 0x7fff                           // 0000005884E4: D6550043 03FEA943 00007FFF
	.long 0x7e8239c0                                           // 0000005884F0: 7E8239C0
	v_bfe_u32 v87, v70, 16, 1                                  // 0000005884F4: D6100057 02052146
	v_add3_u32 v68, v68, v85, 0x7fff                           // 0000005884FC: D6550044 03FEAB44 00007FFF
	v_add3_u32 v69, v69, v86, 0x7fff                           // 000000588508: D6550045 03FEAD45 00007FFF
	.long 0x7f8e3997                                           // 000000588514: 7F8E3997
	v_and_or_b32 v8, 0xffff0000, v66, v65                      // 000000588518: D6570008 050684FF FFFF0000
	v_add3_u32 v70, v70, v87, 0x7fff                           // 000000588524: D6550046 03FEAF46 00007FFF
	s_and_b32 s1, exec_lo, s0                                  // 000000588530: 8B01007E
	.long 0x7e8e39c5                                           // 000000588534: 7E8E39C5
	.long 0xd700000d                                           // 000000588538: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 00000058853C: 0201410D
	s_delay_alu instid0(VALU_DEP_1)                            // 000000588540: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000588544: D5207C0E 00021C80
	s_or_b32 s17, s1, s17                                      // 00000058854C: 8C111101
	s_waitcnt vmcnt(7)                                         // 000000588550: BF891FF7
	v_dot2_f32_bf16 v24, v25, v7, 0                            // 000000588554: CC1A4018 1A020F19
	s_waitcnt vmcnt(6)                                         // 00000058855C: BF891BF7
	v_dot2_f32_bf16 v25, v29, v7, 0                            // 000000588560: CC1A4019 1A020F1D
	s_waitcnt vmcnt(5)                                         // 000000588568: BF8917F7
	v_dot2_f32_bf16 v29, v33, v7, 0                            // 00000058856C: CC1A401D 1A020F21
	s_waitcnt vmcnt(4)                                         // 000000588574: BF8913F7
	v_dot2_f32_bf16 v7, v37, v7, 0                             // 000000588578: CC1A4007 1A020F25
	v_and_or_b32 v33, 0xffff0000, v59, v23                     // 000000588580: D6570021 045E76FF FFFF0000
	v_dot2_f32_bf16 v24, v26, v1, v24                          // 00000058858C: CC1A4018 1C62031A
	v_dot2_f32_bf16 v25, v30, v1, v25                          // 000000588594: CC1A4019 1C66031E
	v_dot2_f32_bf16 v26, v34, v1, v29                          // 00000058859C: CC1A401A 1C760322
	v_dot2_f32_bf16 v1, v38, v1, v7                            // 0000005885A4: CC1A4001 1C1E0326
	.long 0x7e2e39be                                           // 0000005885AC: 7E2E39BE
	v_dot2_f32_bf16 v7, v27, v33, v24                          // 0000005885B0: CC1A4007 1C62431B
	v_dot2_f32_bf16 v24, v31, v33, v25                         // 0000005885B8: CC1A4018 1C66431F
	v_dot2_f32_bf16 v25, v35, v33, v26                         // 0000005885C0: CC1A4019 1C6A4323
	v_dot2_f32_bf16 v1, v39, v33, v1                           // 0000005885C8: CC1A4001 1C064327
	v_and_or_b32 v26, 0xffff0000, v63, v23                     // 0000005885D0: D657001A 045E7EFF FFFF0000
	v_dot2_f32_bf16 v7, v28, v2, v7                            // 0000005885DC: CC1A4007 1C1E051C
	v_dot2_f32_bf16 v24, v32, v2, v24                          // 0000005885E4: CC1A4018 1C620520
	v_dot2_f32_bf16 v25, v36, v2, v25                          // 0000005885EC: CC1A4019 1C660524
	v_dot2_f32_bf16 v1, v40, v2, v1                            // 0000005885F4: CC1A4001 1C060528
	.long 0x7e2e39c3                                           // 0000005885FC: 7E2E39C3
	s_waitcnt vmcnt(3)                                         // 000000588600: BF890FF7
	v_dot2_f32_bf16 v2, v41, v26, v7                           // 000000588604: CC1A4002 1C1E3529
	s_waitcnt vmcnt(2)                                         // 00000058860C: BF890BF7
	v_dot2_f32_bf16 v7, v45, v26, v24                          // 000000588610: CC1A4007 1C62352D
	s_waitcnt vmcnt(1)                                         // 000000588618: BF8907F7
	v_dot2_f32_bf16 v24, v49, v26, v25                         // 00000058861C: CC1A4018 1C663531
	s_waitcnt vmcnt(0)                                         // 000000588624: BF8903F7
	v_dot2_f32_bf16 v1, v53, v26, v1                           // 000000588628: CC1A4001 1C063535
	v_and_or_b32 v23, 0xffff0000, v68, v23                     // 000000588630: D6570017 045E88FF FFFF0000
	v_dot2_f32_bf16 v2, v42, v8, v2                            // 00000058863C: CC1A4002 1C0A112A
	v_dot2_f32_bf16 v7, v46, v8, v7                            // 000000588644: CC1A4007 1C1E112E
	v_dot2_f32_bf16 v24, v50, v8, v24                          // 00000058864C: CC1A4018 1C621132
	v_dot2_f32_bf16 v1, v54, v8, v1                            // 000000588654: CC1A4001 1C061136
	v_and_or_b32 v8, 0xffff0000, v70, v71                      // 00000058865C: D6570008 051E8CFF FFFF0000
	v_dot2_f32_bf16 v25, v43, v23, v2                          // 000000588668: CC1A4019 1C0A2F2B
	v_dot2_f32_bf16 v7, v47, v23, v7                           // 000000588670: CC1A4007 1C1E2F2F
	v_dot2_f32_bf16 v24, v51, v23, v24                         // 000000588678: CC1A4018 1C622F33
	v_dot2_f32_bf16 v1, v55, v23, v1                           // 000000588680: CC1A4001 1C062F37
	v_mov_b32_e32 v2, v6                                       // 000000588688: 7E040306
	v_dot2_f32_bf16 v6, v44, v8, v25                           // 00000058868C: CC1A4006 1C66112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 000000588694: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v23, v52, v8, v24                          // 00000058869C: CC1A4017 1C621134
	v_dot2_f32_bf16 v8, v56, v8, v1                            // 0000005886A4: CC1A4008 1C061138
	v_mov_b32_e32 v1, v5                                       // 0000005886AC: 7E020305
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000005886B0: BF870194
	v_dual_add_f32 v21, v21, v6 :: v_dual_add_f32 v20, v20, v7 // 0000005886B4: C9080D15 15140F14
	v_dual_add_f32 v19, v19, v23 :: v_dual_add_f32 v16, v16, v8// 0000005886BC: C9082F13 13101110
	.long 0x7e2e3900                                           // 0000005886C4: 7E2E3900
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 0000005886C8: 917E117E
	s_cbranch_execz 29                                         // 0000005886CC: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x744>
	v_add_nc_u32_e32 v22, 32, v22                              // 0000005886D0: 4A2C2CA0
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000005886D4: 4A3016FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000005886DC: BF8704A2
	.long 0xd4430000                                           // 0000005886E0: D4430000
	v_cndmask_b32_e32 v1, s2, v22, vcc_lo                      // 0000005886E4: 02022C02
	s_and_saveexec_b32 s1, s0                                  // 0000005886E8: BE812000
	s_xor_b32 s1, exec_lo, s1                                  // 0000005886EC: 8D01017E
	v_add_nc_u32_e32 v24, 0x200, v11                           // 0000005886F0: 4A3016FF 00000200
	s_or_saveexec_b32 s10, s1                                  // 0000005886F8: BE8A2201
	s_waitcnt vmcnt(0)                                         // 0000005886FC: BF8903F7
	.long 0x7e003917                                           // 000000588700: 7E003917
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v6, v2             // 000000588704: CA100101 05060102
	v_dual_mov_b32 v7, v3 :: v_dual_mov_b32 v8, v4             // 00000058870C: CA100103 07080104
	s_xor_b32 exec_lo, exec_lo, s10                            // 000000588714: 8D7E0A7E
	s_cbranch_execz 65192                                      // 000000588718: BFA5FEA8 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x1bc>
	.long 0xd7000105                                           // 00000058871C: D7000105
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 000000588720: 02023111
	s_delay_alu instid0(VALU_DEP_1)                            // 000000588724: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v18, s1                   // 000000588728: D5207C06 00062480
	global_load_b128 v[5:8], v[5:6], off                       // 000000588730: DC5E0000 057C0005
	global_load_d16_b16 v0, v[13:14], off                      // 000000588738: DC820000 007C000D
	s_branch 65182                                             // 000000588740: BFA0FE9E <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0x1bc>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000588744: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000588748: BF8700B9
	s_or_b32 exec_lo, exec_lo, s3                              // 00000058874C: 8C7E037E
	.long 0xd71f0000                                           // 000000588750: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000588754: 020100C1
	s_waitcnt vmcnt(1)                                         // 000000588758: BF8907F7
	v_xor_b32_e32 v1, 16, v0                                   // 00000058875C: 3A020090
	v_xor_b32_e32 v5, 8, v0                                    // 000000588760: 3A0A0088
	v_xor_b32_e32 v11, 4, v0                                   // 000000588764: 3A160084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588768: BF870093
	.long 0xd44c0000                                           // 00000058876C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000588770: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000588774: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058877C: BF870114
	.long 0xd44c0000                                           // 000000588780: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000588784: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000588788: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058878C: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000588790: D5010005 00020B00
	.long 0xd44c0000                                           // 000000588798: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000058879C: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 0000005887A0: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 0000005887A8: D501000B 00021700
	s_waitcnt lgkmcnt(0)                                       // 0000005887B0: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000005887B4: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 0000005887B8: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 0000005887C0: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v16                                // 0000005887C8: DACC0000 01001001
	s_waitcnt lgkmcnt(2)                                       // 0000005887D0: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000005887D4: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 0000005887DC: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 0000005887E4: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 0000005887E8: 06060714
	s_waitcnt lgkmcnt(1)                                       // 0000005887EC: BF89FC17
	v_add_f32_e32 v1, v16, v1                                  // 0000005887F0: 06020310
	ds_bpermute_b32 v8, v5, v4                                 // 0000005887F4: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 0000005887FC: BF89FC17
	v_dual_add_f32 v2, v2, v6 :: v_dual_lshlrev_b32 v11, 2, v11// 000000588800: C9220D02 020A1682
	ds_bpermute_b32 v7, v5, v3                                 // 000000588808: DACC0000 07000305
	ds_bpermute_b32 v5, v5, v1                                 // 000000588810: DACC0000 05000105
	s_waitcnt lgkmcnt(0)                                       // 000000588818: BF89FC07
	v_dual_add_f32 v4, v4, v8 :: v_dual_add_f32 v1, v1, v5     // 00000058881C: C9081104 04000B01
	ds_bpermute_b32 v5, v11, v2                                // 000000588824: DACC0000 0500020B
	v_add_f32_e32 v3, v3, v7                                   // 00000058882C: 06060F03
	ds_bpermute_b32 v7, v11, v4                                // 000000588830: DACC0000 0700040B
	s_waitcnt lgkmcnt(1)                                       // 000000588838: BF89FC17
	v_add_f32_e32 v2, v2, v5                                   // 00000058883C: 06040B02
	ds_bpermute_b32 v6, v11, v3                                // 000000588840: DACC0000 0600030B
	s_waitcnt lgkmcnt(0)                                       // 000000588848: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v6, v4, v7     // 00000058884C: C9080D03 03060F04
	ds_bpermute_b32 v8, v11, v1                                // 000000588854: DACC0000 0800010B
	v_xor_b32_e32 v11, 2, v0                                   // 00000058885C: 3A160082
	v_xor_b32_e32 v4, 1, v0                                    // 000000588860: 3A080081
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000588864: BF870092
	.long 0xd44c0000                                           // 000000588868: D44C0000
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 00000058886C: 020216A0
	v_cndmask_b32_e64 v11, v0, v11, s0                         // 000000588870: D501000B 00021700
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000588878: BF870113
	.long 0xd44c0000                                           // 00000058887C: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 000000588880: 020208A0
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000588884: 30161682
	s_delay_alu instid0(VALU_DEP_2)                            // 000000588888: BF870002
	v_cndmask_b32_e64 v0, v0, v4, s0                           // 00000058888C: D5010000 00020900
	.long 0xd44a0000                                           // 000000588894: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000588898: 02021E80
	s_waitcnt lgkmcnt(0)                                       // 00000058889C: BF89FC07
	v_add_f32_e32 v7, v1, v8                                   // 0000005888A0: 060E1101
	ds_bpermute_b32 v1, v11, v2                                // 0000005888A4: DACC0000 0100020B
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000005888AC: 30180082
	s_and_b32 s0, s0, vcc_lo                                   // 0000005888B0: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 0000005888B4: BF89FC07
	v_add_f32_e32 v4, v2, v1                                   // 0000005888B8: 06080302
	ds_bpermute_b32 v5, v11, v3                                // 0000005888BC: DACC0000 0500030B
	ds_bpermute_b32 v8, v11, v6                                // 0000005888C4: DACC0000 0800060B
	ds_bpermute_b32 v11, v11, v7                               // 0000005888CC: DACC0000 0B00070B
	s_waitcnt lgkmcnt(2)                                       // 0000005888D4: BF89FC27
	v_add_f32_e32 v5, v3, v5                                   // 0000005888D8: 060A0B03
	s_waitcnt lgkmcnt(0)                                       // 0000005888DC: BF89FC07
	v_dual_add_f32 v1, v6, v8 :: v_dual_add_f32 v0, v7, v11    // 0000005888E0: C9081106 01001707
	ds_bpermute_b32 v6, v12, v4                                // 0000005888E8: DACC0000 0600040C
	ds_bpermute_b32 v7, v12, v5                                // 0000005888F0: DACC0000 0700050C
	ds_bpermute_b32 v2, v12, v1                                // 0000005888F8: DACC0000 0200010C
	ds_bpermute_b32 v3, v12, v0                                // 000000588900: DACC0000 0300000C
	s_and_saveexec_b32 s1, s0                                  // 000000588908: BE812000
	s_cbranch_execz 61                                         // 00000058890C: BFA5003D <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi4ELi32ELi1ELb0EEEvPKhPKtPvll+0xa04>
	s_waitcnt lgkmcnt(2)                                       // 000000588910: BF89FC27
	v_dual_add_f32 v7, v5, v7 :: v_dual_add_f32 v6, v4, v6     // 000000588914: C9080F05 07060D04
	.long 0x7f103880                                           // 00000058891C: 7F103880
	.long 0xd73c0004                                           // 000000588920: D73C0004
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 000000588924: 02021281
	s_waitcnt lgkmcnt(0)                                       // 000000588928: BF89FC07
	v_dual_add_f32 v9, v1, v2 :: v_dual_add_f32 v10, v0, v3    // 00000058892C: C9080501 090A0700
	.long 0x7e103987                                           // 000000588934: 7E103987
	.long 0x7e163986                                           // 000000588938: 7E163986
	.long 0x7f163988                                           // 00000058893C: 7F163988
	.long 0xd7006a03                                           // 000000588940: D7006A03
	v_cndmask_b32_e32 v1, s8, v4, vcc_lo                       // 000000588944: 02020808
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000588948: BF870224
	v_and_b32_e32 v0, 1, v8                                    // 00000058894C: 36001081
	v_add_co_ci_u32_e64 v4, null, s9, v5, vcc_lo               // 000000588950: D5207C04 01AA0A09
	v_and_b32_e32 v1, 1, v11                                   // 000000588958: 36021681
	.long 0x7e043989                                           // 00000058895C: 7E043989
	s_delay_alu instid0(VALU_DEP_4)                            // 000000588960: BF870004
	v_add3_u32 v11, v7, v0, 0x7fff                             // 000000588964: D655000B 03FE0107 00007FFF
	.long 0x7f043988                                           // 000000588970: 7F043988
	.long 0x7e10398a                                           // 000000588974: 7E10398A
	v_add3_u32 v12, v6, v1, 0x7fff                             // 000000588978: D655000C 03FE0306 00007FFF
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 000000588984: D6FE7C00 040D0C0C
	s_lshl_b64 s[0:1], s[12:13], 1                             // 00000058898C: 8480810C
	v_and_b32_e32 v14, 1, v2                                   // 000000588990: 361C0481
	.long 0xd7006a05                                           // 000000588994: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000588998: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000058899C: BF8700D1
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 0000005889A0: D5207C06 01AA0801
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005889A8: 8480820C
	v_and_b32_e32 v13, 1, v8                                   // 0000005889AC: 361A1081
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000005889B0: D6FE7C01 04050C0D
	.long 0xd7006a07                                           // 0000005889B8: D7006A07
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 0000005889BC: 02000103
	v_add_co_ci_u32_e64 v8, null, s1, v4, vcc_lo               // 0000005889C0: D5207C08 01AA0801
	v_add3_u32 v2, v9, v14, 0x7fff                             // 0000005889C8: D6550002 03FE1D09 00007FFF
	v_add3_u32 v9, v10, v13, 0x7fff                            // 0000005889D4: D6550009 03FE1B0A 00007FFF
	s_clause 0x3                                               // 0000005889E0: BF850003
	global_store_d16_hi_b16 v[3:4], v12, off                   // 0000005889E4: DC960000 007C0C03
	global_store_d16_hi_b16 v[5:6], v11, off                   // 0000005889EC: DC960000 007C0B05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000005889F4: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v9, off                    // 0000005889FC: DC960000 007C0900
	s_endpgm                                                   // 000000588A04: BFB00000
		...

