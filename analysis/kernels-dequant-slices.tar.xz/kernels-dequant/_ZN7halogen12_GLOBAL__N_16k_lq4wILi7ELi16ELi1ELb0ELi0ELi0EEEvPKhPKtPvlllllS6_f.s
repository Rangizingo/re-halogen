0000000000573600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000573600: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v15, 15, v0         // 000000573608: CA240080 040E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000573610: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000573614: 86039F02
	v_mov_b32_e32 v16, 0                                       // 000000573618: 7E200280
	s_lshl_b64 s[0:1], s[2:3], 4                               // 00000057361C: 84808402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000573620: BF870009
	v_dual_mov_b32 v9, s1 :: v_dual_lshlrev_b32 v2, 2, v15     // 000000573624: CA220001 09021E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000057362C: 30060282
	v_or_b32_e32 v8, s0, v1                                    // 000000573630: 38100200
	.long 0x7f183880                                           // 000000573634: 7F183880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 000000573638: CA100080 05060080
	s_waitcnt lgkmcnt(0)                                       // 000000573640: BF89FC07
	s_clause 0x1                                               // 000000573644: BF850001
	global_load_b32 v7, v2, s[4:5]                             // 000000573648: DC520000 07040002
	global_load_b32 v3, v3, s[4:5]                             // 000000573650: DC520000 03040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000573658: 7CA8100C
	s_add_u32 s2, s4, s14                                      // 00000057365C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000573660: 82030F05
	s_lshr_b32 s0, s11, 31                                     // 000000573664: 85009F0B
	v_mov_b32_e32 v27, 0                                       // 000000573668: 7E360280
	s_add_u32 s14, s10, s0                                     // 00000057366C: 800E000A
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000573670: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000573674: D501000E 01A80280
	s_addc_u32 s15, s11, 0                                     // 00000057367C: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 000000573680: 86149F0B
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000573684: 8680810E
	.long 0xd72c000d                                           // 000000573688: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 00000057368C: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000573690: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000573698: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 00000057369C: 0200030A
	.long 0xd72c0013                                           // 0000005736A0: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 0000005736A4: 0200010E
	.long 0xd72c000e                                           // 0000005736A8: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000005736AC: 02021C12
	s_lshr_b32 s14, s20, 27                                    // 0000005736B0: 850E9B14
	s_waitcnt vmcnt(1)                                         // 0000005736B4: BF8907F7
	v_bfe_u32 v11, v7, 16, 1                                   // 0000005736B8: D610000B 02052107
	s_waitcnt vmcnt(0)                                         // 0000005736C0: BF8903F7
	v_bfe_u32 v18, v3, 16, 1                                   // 0000005736C4: D6100012 02052103
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005736CC: BF870002
	v_add3_u32 v7, v7, v11, 0x7fff                             // 0000005736D0: D6550007 03FE1707 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 0000005736DC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 0000005736E4: 80020E0A
	v_add3_u32 v3, v3, v18, 0x7fff                             // 0000005736E8: D6550003 03FE2503 00007FFF
	s_addc_u32 s3, s11, 0                                      // 0000005736F4: 8203800B
	.long 0x7e183987                                           // 0000005736F8: 7E183987
	s_lshr_b64 s[2:3], s[2:3], 5                               // 0000005736FC: 85828502
	v_dual_mov_b32 v7, 0 :: v_dual_lshlrev_b32 v18, 2, v0      // 000000573700: CA220080 07120082
	.long 0xd4440000                                           // 000000573708: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 00000057370C: 02021E02
	s_delay_alu instid0(VALU_DEP_3)                            // 000000573710: BF870003
	v_and_or_b32 v3, 0xffff0000, v3, v12                       // 000000573714: D6570003 043206FF FFFF0000
	v_add3_u32 v17, v19, v11, v17                              // 000000573720: D6550011 04461713
	v_add3_u32 v0, v2, v14, v13                                // 000000573728: D6550000 04361D02
	ds_store_b32 v18, v3                                       // 000000573730: D8340000 00000312
	s_waitcnt lgkmcnt(0)                                       // 000000573738: BF89FC07
	s_barrier                                                  // 00000057373C: BFBD0000
	buffer_gl0_inv                                             // 000000573740: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000573748: BE832000
	s_cbranch_execz 26                                         // 00000057374C: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1b8>
	s_add_u32 s1, s4, s16                                      // 000000573750: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000573754: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000573758: 30041E81
	.long 0xd7000103                                           // 00000057375C: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000573760: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000573764: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000573768: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000573770: 300A1E84
	.long 0xd7000102                                           // 000000573774: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000573778: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000057377C: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000573780: D5207C03 00060880
	.long 0xd7000104                                           // 000000573788: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 00000057378C: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000573790: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000573794: D5207C05 00062280
	s_clause 0x1                                               // 00000057379C: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 0000005737A0: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 0000005737A8: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 0000005737B0: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 0000005737B4: 7E361702
	s_or_b32 exec_lo, exec_lo, s3                              // 0000005737B8: 8C7E037E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v18, 0             // 0000005737BC: CA100080 13120080
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0             // 0000005737C4: CA100080 15140080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000005737CC: CA100080 17160080
	s_and_saveexec_b32 s3, s0                                  // 0000005737D4: BE832000
	s_cbranch_execz 597                                        // 0000005737D8: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb30>
	s_mul_i32 s0, s11, 6                                       // 0000005737DC: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 0000005737E0: 9681860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 0000005737E4: CA22010F 19021E81
	s_add_i32 s18, s1, s0                                      // 0000005737EC: 81120001
	.long 0xd7000001                                           // 0000005737F0: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 0000005737F4: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000005737F8: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 0000005737FC: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000573804: CA220080 0C0A1E85
	.long 0xd7000001                                           // 00000057380C: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000573810: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000573814: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 000000573818: D5207C00 00020080
	v_lshl_or_b32 v24, v15, 4, 0x100                           // 000000573820: D6560018 03FD090F 00000100
	.long 0xd7000001                                           // 00000057382C: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000573830: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000573834: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 000000573838: D5207C00 00020005
	v_mov_b32_e32 v22, v12                                     // 000000573840: 7E2C030C
	.long 0xd700000d                                           // 000000573844: D700000D
	v_cndmask_b32_e32 v0, v1, v160, vcc_lo                     // 000000573848: 02014101
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057384C: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000573850: D5207C0E 00020080
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 000000573858: CA10010C 171A011B
	v_mov_b32_e32 v20, v12                                     // 000000573860: 7E28030C
	v_mov_b32_e32 v21, v12                                     // 000000573864: 7E2A030C
	v_mov_b32_e32 v18, v12                                     // 000000573868: 7E24030C
	v_mov_b32_e32 v19, v12                                     // 00000057386C: 7E26030C
	v_mov_b32_e32 v16, v12                                     // 000000573870: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000573874: 848E820A
	s_mul_i32 s17, s10, 6                                      // 000000573878: 9611860A
	s_mov_b32 s16, 0                                           // 00000057387C: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000573880: 8484810A
	s_branch 528                                               // 000000573884: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xac8>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000573888: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 00000057388C: 363808FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 000000573894: 8B00007E
	v_add_nc_u32_e32 v24, 0x100, v24                           // 000000573898: 4A3030FF 00000100
	s_or_b32 s16, s0, s16                                      // 0000005738A0: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005738A4: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000005738A8: 30383882
	ds_load_b32 v44, v28                                       // 0000005738AC: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000005738B4: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000005738B8: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 0000005738C0: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 0000005738C8: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000005738CC: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000005738D0: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000005738D4: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005738DC: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 0000005738E4: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 0000005738EC: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 0000005738F4: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005738FC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000573900: 30080882
	ds_load_b32 v48, v4                                        // 000000573904: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 00000057390C: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000573910: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 000000573918: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000573920: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000573924: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000573928: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000573930: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 000000573938: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000057393C: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000573944: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 00000057394C: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000573954: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000573958: 30080882
	ds_load_b32 v52, v4                                        // 00000057395C: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000573964: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000573968: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000573970: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 000000573978: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057397C: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000573980: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 000000573988: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 000000573990: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000573994: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 00000057399C: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000005739A4: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005739AC: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000005739B0: 30080882
	ds_load_b32 v56, v4                                        // 0000005739B4: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000005739BC: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005739C0: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000005739C8: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000005739D0: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005739D4: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005739D8: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000005739E0: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000005739E8: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000005739EC: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 0000005739F4: D8D80000 3B000004
	.long 0xd73c0004                                           // 0000005739FC: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000573A00: 02021681
	v_add_nc_u32_e32 v11, 0x200, v11                           // 000000573A04: 4A1616FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573A0C: BF870092
	.long 0xd7000028                                           // 000000573A10: D7000028
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000573A14: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s0                  // 000000573A18: D5207C29 00020A07
	s_clause 0x3                                               // 000000573A20: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000573A24: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000573A2C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000573A34: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000573A3C: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000573A44: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573A48: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 000000573A50: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573A54: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573A58: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 000000573A60: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573A64: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 000000573A6C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573A70: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573A74: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000573A7C: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573A80: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 000000573A88: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573A8C: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573A90: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 000000573A98: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573A9C: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 000000573AA4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573AA8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573AAC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000573AB4: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573AB8: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 000000573AC0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573AC4: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573AC8: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 000000573AD0: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573AD4: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 000000573ADC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573AE0: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573AE4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000573AEC: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573AF0: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000573AF8: D7000024
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000573AFC: 02000928
	s_waitcnt lgkmcnt(2)                                       // 000000573B00: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000573B04: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573B08: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s0                 // 000000573B10: D5207C25 00025205
	.long 0xd700002a                                           // 000000573B18: D700002A
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000573B1C: 02001D28
	s_waitcnt lgkmcnt(1)                                       // 000000573B20: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573B24: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s15, v41, s0                // 000000573B2C: D5207C2B 0002520F
	.long 0xd7000028                                           // 000000573B34: D7000028
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 000000573B38: 02002328
	s_waitcnt lgkmcnt(0)                                       // 000000573B3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000573B40: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573B44: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s18, v41, s0                // 000000573B4C: D5207C29 00025212
	v_fmac_f32_e32 v22, v27, v4                                // 000000573B54: 562C091B
	s_clause 0x3                                               // 000000573B58: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000573B5C: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000573B64: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000573B6C: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000573B74: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000573B7C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573B80: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573B88: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573B8C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573B94: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573B9C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573BA0: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000573BA8: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573BAC: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573BB4: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573BB8: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573BC0: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573BC8: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573BCC: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000573BD4: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573BD8: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573BE0: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573BE4: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573BEC: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573BF4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573BF8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000573C00: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573C04: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573C0C: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573C10: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573C18: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573C20: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573C24: CC1A4004 1C127727
	v_fmac_f32_e32 v23, v27, v4                                // 000000573C2C: 562E091B
	s_clause 0x3                                               // 000000573C30: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000573C34: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000573C3C: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000573C44: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000573C4C: DC5E0030 247C002A
	.long 0xd700002a                                           // 000000573C54: D700002A
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 000000573C58: 02001D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000573C5C: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s15, v43, s0                // 000000573C60: D5207C2B 0002560F
	s_waitcnt vmcnt(3)                                         // 000000573C68: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573C6C: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573C74: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573C7C: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573C80: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573C88: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000573C90: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573C94: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573C98: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573CA0: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573CA8: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573CAC: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573CB4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000573CBC: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573CC0: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573CC4: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573CCC: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573CD4: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573CD8: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573CE0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000573CE8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573CEC: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573CF0: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573CF8: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573D00: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573D04: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573D0C: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 000000573D14: BF870001
	v_fmac_f32_e32 v20, v27, v4                                // 000000573D18: 5628091B
	s_clause 0x3                                               // 000000573D1C: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000573D20: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000573D28: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000573D30: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000573D38: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 000000573D40: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573D44: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573D4C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573D50: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573D58: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573D60: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573D64: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000573D6C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573D70: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573D78: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573D7C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573D84: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573D8C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573D90: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000573D98: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573D9C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573DA4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573DA8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573DB0: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573DB8: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573DBC: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000573DC4: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573DC8: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573DD0: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573DD4: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573DDC: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573DE4: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573DE8: CC1A4004 1C127727
	v_fmac_f32_e32 v21, v27, v4                                // 000000573DF0: 562A091B
	s_clause 0x3                                               // 000000573DF4: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000573DF8: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000573E00: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000573E08: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000573E10: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 000000573E18: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573E1C: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573E24: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573E28: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573E30: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573E38: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573E3C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000573E44: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573E48: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573E50: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573E54: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573E5C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573E64: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573E68: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000573E70: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573E74: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573E7C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573E80: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573E88: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573E90: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573E94: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000573E9C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573EA0: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000573EA8: D7000024
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000573EAC: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000573EB0: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573EB4: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v41, s0                // 000000573EBC: D5207C25 0002520F
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573EC4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573ECC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573ED0: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 000000573ED8: 5624091B
	s_clause 0x3                                               // 000000573EDC: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000573EE0: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000573EE8: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000573EF0: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000573EF8: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000573F00: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573F04: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573F0C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000573F10: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000573F18: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573F20: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000573F24: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000573F2C: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000573F30: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573F38: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000573F3C: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000573F44: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573F4C: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000573F50: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000573F58: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000573F5C: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573F64: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000573F68: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000573F70: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000573F78: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000573F7C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000573F84: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000573F88: CC1A4004 1C127124
	.long 0xd7000024                                           // 000000573F90: D7000024
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 000000573F94: 02001D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000573F98: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000573F9C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v43, s0                // 000000573FA4: D5207C25 0002560F
	.long 0xd700000d                                           // 000000573FAC: D700000D
	v_cndmask_b32_e32 v0, v13, v160, vcc_lo                    // 000000573FB0: 0201410D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000573FB4: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 000000573FBC: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000573FC4: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000573FC8: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 000000573FD0: 5626091B
	s_clause 0x3                                               // 000000573FD4: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000573FD8: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000573FE0: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000573FE8: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000573FF0: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000573FF8: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000573FFC: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000574004: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000574008: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 000000574010: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000574014: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 00000057401C: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000574020: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000574024: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 00000057402C: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000574030: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000574034: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057403C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000574040: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000574048: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000574050: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000574054: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 00000057405C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000574060: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000574068: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000057406C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000574074: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057407C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000574080: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000574088: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000057408C: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000574094: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000574098: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000005740A0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005740A8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000005740AC: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 0000005740B4: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 0000005740B8: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000005740C0: 917E107E
	s_cbranch_execz 25                                         // 0000005740C4: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb2c>
	s_waitcnt vmcnt(0)                                         // 0000005740C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005740CC: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 16, v25    // 0000005740D0: CA200104 00183290
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000005740D8: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000005740E0: 7E060307
	.long 0xd4430000                                           // 0000005740E4: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 0000005740E8: 02023202
	s_mov_b32 s10, exec_lo                                     // 0000005740EC: BE8A007E
	.long 0xd4c4007e                                           // 0000005740F0: D4C4007E
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 0000005740F4: 02023202
	s_cbranch_execz 64995                                      // 0000005740F8: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	.long 0xd7000100                                           // 0000005740FC: D7000100
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 000000574100: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000574104: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 000000574108: D5207C01 00062280
	global_load_d16_b16 v26, v[13:14], off                     // 000000574110: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 000000574118: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000574120: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 000000574124: 7E34171A
	s_branch 64983                                             // 000000574128: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x288>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000057412C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000574130: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000574134: 8C7E037E
	.long 0xd71f0000                                           // 000000574138: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057413C: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000574140: 3A020088
	v_xor_b32_e32 v10, 4, v0                                   // 000000574144: 3A140084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000574148: BF870092
	.long 0xd44c0000                                           // 00000057414C: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000574150: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000574154: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057415C: BF870113
	.long 0xd44c0000                                           // 000000574160: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000574164: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000574168: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 00000057416C: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 000000574170: D501000A 00021500
	ds_bpermute_b32 v2, v1, v16                                // 000000574178: DACC0000 02001001
	s_waitcnt lgkmcnt(0)                                       // 000000574180: BF89FC07
	v_add_f32_e32 v2, v16, v2                                  // 000000574184: 06040510
	ds_bpermute_b32 v3, v1, v23                                // 000000574188: DACC0000 03001701
	s_waitcnt vmcnt(0)                                         // 000000574190: BF8903F7
	ds_bpermute_b32 v4, v1, v22                                // 000000574194: DACC0000 04001601
	ds_bpermute_b32 v5, v1, v21                                // 00000057419C: DACC0000 05001501
	ds_bpermute_b32 v6, v1, v20                                // 0000005741A4: DACC0000 06001401
	ds_bpermute_b32 v7, v1, v19                                // 0000005741AC: DACC0000 07001301
	ds_bpermute_b32 v1, v1, v18                                // 0000005741B4: DACC0000 01001201
	s_waitcnt lgkmcnt(5)                                       // 0000005741BC: BF89FC57
	v_dual_add_f32 v3, v23, v3 :: v_dual_lshlrev_b32 v10, 2, v10// 0000005741C0: C9220717 030A1482
	ds_bpermute_b32 v11, v10, v2                               // 0000005741C8: DACC0000 0B00020A
	s_waitcnt lgkmcnt(4)                                       // 0000005741D0: BF89FC47
	v_dual_add_f32 v4, v22, v4 :: v_dual_add_f32 v5, v21, v5   // 0000005741D4: C9080916 04040B15
	s_waitcnt lgkmcnt(2)                                       // 0000005741DC: BF89FC27
	v_dual_add_f32 v6, v20, v6 :: v_dual_add_f32 v7, v19, v7   // 0000005741E0: C9080D14 06060F13
	s_waitcnt lgkmcnt(1)                                       // 0000005741E8: BF89FC17
	v_add_f32_e32 v1, v18, v1                                  // 0000005741EC: 06020312
	v_xor_b32_e32 v18, 2, v0                                   // 0000005741F0: 3A240082
	ds_bpermute_b32 v12, v10, v3                               // 0000005741F4: DACC0000 0C00030A
	ds_bpermute_b32 v13, v10, v4                               // 0000005741FC: DACC0000 0D00040A
	ds_bpermute_b32 v14, v10, v5                               // 000000574204: DACC0000 0E00050A
	ds_bpermute_b32 v16, v10, v6                               // 00000057420C: DACC0000 1000060A
	.long 0xd44c0000                                           // 000000574214: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000574218: 020224A0
	ds_bpermute_b32 v17, v10, v7                               // 00000057421C: DACC0000 1100070A
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000574224: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 00000057422C: BF89FC57
	v_add_f32_e32 v2, v2, v11                                  // 000000574230: 06041702
	s_delay_alu instid0(VALU_DEP_2)                            // 000000574234: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000574238: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 00000057423C: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 000000574244: BF89FC57
	v_add_f32_e32 v3, v3, v12                                  // 000000574248: 06061903
	v_xor_b32_e32 v12, 1, v0                                   // 00000057424C: 3A180081
	s_waitcnt lgkmcnt(3)                                       // 000000574250: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 000000574254: C9081B04 04041D05
	s_waitcnt lgkmcnt(1)                                       // 00000057425C: BF89FC17
	v_dual_add_f32 v6, v6, v16 :: v_dual_add_f32 v7, v7, v17   // 000000574260: C9082106 06062307
	.long 0xd44c0000                                           // 000000574268: D44C0000
	v_cndmask_b32_e32 v1, 32, v12, vcc_lo                      // 00000057426C: 020218A0
	ds_bpermute_b32 v11, v18, v4                               // 000000574270: DACC0000 0B000412
	ds_bpermute_b32 v14, v18, v5                               // 000000574278: DACC0000 0E000512
	ds_bpermute_b32 v16, v18, v6                               // 000000574280: DACC0000 10000612
	ds_bpermute_b32 v17, v18, v7                               // 000000574288: DACC0000 11000712
	v_cndmask_b32_e64 v0, v0, v12, s0                          // 000000574290: D5010000 00021900
	.long 0xd44a0000                                           // 000000574298: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 00000057429C: 02021E80
	s_waitcnt lgkmcnt(4)                                       // 0000005742A0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005742A4: BF870002
	v_dual_add_f32 v1, v1, v10 :: v_dual_lshlrev_b32 v20, 2, v0// 0000005742A8: C9221501 01140082
	ds_bpermute_b32 v10, v18, v3                               // 0000005742B0: DACC0000 0A000312
	s_and_b32 s0, s0, vcc_lo                                   // 0000005742B8: 8B006A00
	ds_bpermute_b32 v19, v18, v1                               // 0000005742BC: DACC0000 13000112
	ds_bpermute_b32 v18, v18, v2                               // 0000005742C4: DACC0000 12000212
	s_waitcnt lgkmcnt(5)                                       // 0000005742CC: BF89FC57
	v_dual_add_f32 v13, v4, v11 :: v_dual_add_f32 v4, v5, v14  // 0000005742D0: C9081704 0D041D05
	s_waitcnt lgkmcnt(3)                                       // 0000005742D8: BF89FC37
	v_dual_add_f32 v5, v6, v16 :: v_dual_add_f32 v0, v7, v17   // 0000005742DC: C9082106 05002307
	ds_bpermute_b32 v14, v20, v13                              // 0000005742E4: DACC0000 0E000D14
	ds_bpermute_b32 v7, v20, v4                                // 0000005742EC: DACC0000 07000414
	ds_bpermute_b32 v6, v20, v5                                // 0000005742F4: DACC0000 06000514
	s_waitcnt lgkmcnt(4)                                       // 0000005742FC: BF89FC47
	v_dual_add_f32 v12, v3, v10 :: v_dual_add_f32 v1, v1, v19  // 000000574300: C9081503 0C002701
	s_waitcnt lgkmcnt(3)                                       // 000000574308: BF89FC37
	v_add_f32_e32 v10, v2, v18                                 // 00000057430C: 06142502
	ds_bpermute_b32 v16, v20, v12                              // 000000574310: DACC0000 10000C14
	ds_bpermute_b32 v3, v20, v0                                // 000000574318: DACC0000 03000014
	ds_bpermute_b32 v2, v20, v1                                // 000000574320: DACC0000 02000114
	ds_bpermute_b32 v11, v20, v10                              // 000000574328: DACC0000 0B000A14
	s_and_saveexec_b32 s1, s0                                  // 000000574330: BE812000
	s_cbranch_execz 102                                        // 000000574334: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi16ELi1ELb0ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xed0>
	s_waitcnt lgkmcnt(3)                                       // 000000574338: BF89FC37
	v_dual_add_f32 v12, v12, v16 :: v_dual_add_f32 v13, v13, v14// 00000057433C: C908210C 0C0C1D0D
	.long 0x7f1c3880                                           // 000000574344: 7F1C3880
	.long 0xd73c0008                                           // 000000574348: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000057434C: 02021081
	s_lshl_b64 s[0:1], s[12:13], 1                             // 000000574350: 8480810C
	s_delay_alu instid0(VALU_DEP_3)                            // 000000574354: BF870003
	.long 0x7e1c398c                                           // 000000574358: 7E1C398C
	.long 0x7e1e398d                                           // 00000057435C: 7E1E398D
	.long 0x7f1e398e                                           // 000000574360: 7F1E398E
	s_waitcnt lgkmcnt(0)                                       // 000000574364: BF89FC07
	v_add_f32_e32 v10, v10, v11                                // 000000574368: 0614170A
	.long 0xd7006a08                                           // 00000057436C: D7006A08
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000574370: 02021008
	v_dual_add_f32 v7, v4, v7 :: v_dual_and_b32 v16, 1, v14    // 000000574374: C9240F04 07101C81
	v_dual_add_f32 v6, v5, v6 :: v_dual_and_b32 v15, 1, v15    // 00000057437C: C9240D05 060E1E81
	v_add_co_ci_u32_e64 v9, null, s9, v9, vcc_lo               // 000000574384: D5207C09 01AA1209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000057438C: BF870223
	v_add3_u32 v16, v12, v16, 0x7fff                           // 000000574390: D6550010 03FE210C 00007FFF
	.long 0xd7006a0c                                           // 00000057439C: D7006A0C
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000005743A0: 02000108
	v_add3_u32 v15, v13, v15, 0x7fff                           // 0000005743A4: D655000F 03FE1F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005743B0: BF870004
	v_add_co_ci_u32_e64 v13, null, s1, v9, vcc_lo              // 0000005743B4: D5207C0D 01AA1201
	s_clause 0x1                                               // 0000005743BC: BF850001
	global_store_d16_hi_b16 v[8:9], v15, off                   // 0000005743C0: DC960000 007C0F08
	global_store_d16_hi_b16 v[12:13], v16, off                 // 0000005743C8: DC960000 007C100C
	.long 0x7e1c3987                                           // 0000005743D0: 7E1C3987
	v_add_f32_e32 v13, v1, v2                                  // 0000005743D4: 061A0501
	s_lshl_b64 s[0:1], s[12:13], 2                             // 0000005743D8: 8480820C
	.long 0x7e163986                                           // 0000005743DC: 7E163986
	.long 0xd7006a04                                           // 0000005743E0: D7006A04
	v_cndmask_b32_e32 v0, v8, v0, vcc_lo                       // 0000005743E4: 02000108
	.long 0x7f16398e                                           // 0000005743E8: 7F16398E
	v_add_f32_e32 v12, v0, v3                                  // 0000005743EC: 06180700
	v_mad_u64_u32 v[0:1], null, s12, 6, v[8:9]                 // 0000005743F0: D6FE7C00 04210C0C
	v_and_b32_e32 v2, 1, v14                                   // 0000005743F8: 36041C81
	.long 0x7e10398d                                           // 0000005743FC: 7E10398D
	.long 0x7f10398e                                           // 000000574400: 7F10398E
	v_and_b32_e32 v3, 1, v11                                   // 000000574404: 36061681
	v_add_co_ci_u32_e64 v5, null, s1, v9, vcc_lo               // 000000574408: D5207C05 01AA1201
	v_add3_u32 v11, v7, v2, 0x7fff                             // 000000574410: D655000B 03FE0507 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000057441C: BF870254
	v_and_b32_e32 v7, 1, v8                                    // 000000574420: 360E1081
	.long 0x7e1c398c                                           // 000000574424: 7E1C398C
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 000000574428: D6FE7C01 04050C0D
	v_add3_u32 v15, v6, v3, 0x7fff                             // 000000574430: D655000F 03FE0706 00007FFF
	.long 0xd7006a02                                           // 00000057443C: D7006A02
	v_cndmask_b32_e32 v0, v4, v0, vcc_lo                       // 000000574440: 02000104
	v_and_b32_e32 v6, 1, v14                                   // 000000574444: 360C1C81
	v_bfe_u32 v8, v10, 16, 1                                   // 000000574448: D6100008 0205210A
	v_add_co_ci_u32_e64 v3, null, s1, v5, vcc_lo               // 000000574450: D5207C03 01AA0A01
	v_add3_u32 v13, v13, v7, 0x7fff                            // 000000574458: D655000D 03FE0F0D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000574464: BF8700A4
	v_add3_u32 v12, v12, v6, 0x7fff                            // 000000574468: D655000C 03FE0D0C 00007FFF
	.long 0xd7006a06                                           // 000000574474: D7006A06
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000574478: 02000100
	v_add_co_ci_u32_e64 v7, null, s1, v1, vcc_lo               // 00000057447C: D5207C07 01AA0201
	v_add3_u32 v10, v10, v8, 0x7fff                            // 000000574484: D655000A 03FE110A 00007FFF
	.long 0xd7006a08                                           // 000000574490: D7006A08
	v_cndmask_b32_e32 v0, v2, v0, vcc_lo                       // 000000574494: 02000102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000574498: BF870001
	v_add_co_ci_u32_e64 v9, null, s1, v3, vcc_lo               // 00000057449C: D5207C09 01AA0601
	s_clause 0x4                                               // 0000005744A4: BF850004
	global_store_d16_hi_b16 v[4:5], v15, off                   // 0000005744A8: DC960000 007C0F04
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000005744B0: DC960000 007C0B00
	global_store_d16_hi_b16 v[2:3], v13, off                   // 0000005744B8: DC960000 007C0D02
	global_store_d16_hi_b16 v[6:7], v12, off                   // 0000005744C0: DC960000 007C0C06
	global_store_d16_hi_b16 v[8:9], v10, off                   // 0000005744C8: DC960000 007C0A08
	s_endpgm                                                   // 0000005744D0: BFB00000
		...

