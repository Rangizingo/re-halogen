00000000007ccb00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007CCB00: F4100100 F8000000
	v_and_b32_e32 v16, 15, v0                                  // 0000007CCB08: 3620008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007CCB0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007CCB10: 86039F02
	.long 0x7f103880                                           // 0000007CCB14: 7F103880
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000007CCB18: 84828402
	v_mov_b32_e32 v17, 0                                       // 0000007CCB1C: 7E220280
	v_dual_mov_b32 v10, s3 :: v_dual_lshlrev_b32 v3, 2, v1     // 0000007CCB20: CA220003 0A020282
	v_or_b32_e32 v9, s2, v1                                    // 0000007CCB28: 38120202
	v_dual_mov_b32 v1, 0 :: v_dual_lshlrev_b32 v2, 2, v16      // 0000007CCB2C: CA220080 01022082
	s_waitcnt lgkmcnt(0)                                       // 0000007CCB34: BF89FC07
	s_clause 0x1                                               // 0000007CCB38: BF850001
	global_load_b32 v4, v2, s[4:5]                             // 0000007CCB3C: DC520000 04040002
	global_load_b32 v7, v3, s[4:5]                             // 0000007CCB44: DC520000 07040003
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[9:10]                 // 0000007CCB4C: 7CA8120C
	s_add_u32 s14, s4, s14                                     // 0000007CCB50: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 0000007CCB54: 820F0F05
	s_lshr_b32 s2, s11, 31                                     // 0000007CCB58: 85029F0B
	v_mov_b32_e32 v18, 0                                       // 0000007CCB5C: 7E240280
	s_add_u32 s20, s10, s2                                     // 0000007CCB60: 8014020A
	v_cndmask_b32_e32 v11, 0, v9, vcc_lo                       // 0000007CCB64: 02161280
	v_cndmask_b32_e64 v14, 0, s3, vcc_lo                       // 0000007CCB68: D501000E 01A80680
	s_addc_u32 s21, s11, 0                                     // 0000007CCB70: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 0000007CCB74: 86169F0B
	s_ashr_i64 s[2:3], s[20:21], 1                             // 0000007CCB78: 86828114
	.long 0xd72c000d                                           // 0000007CCB7C: D72C000D
	v_cndmask_b32_e32 v1, s19, v11, vcc_lo                     // 0000007CCB80: 02021613
	v_mad_u64_u32 v[5:6], null, s18, v11, 0                    // 0000007CCB84: D6FE7C05 02021612
	.long 0xd72c000f                                           // 0000007CCB8C: D72C000F
	v_cndmask_b32_e32 v0, v11, v3, vcc_lo                      // 0000007CCB90: 0200070B
	.long 0xd72c0014                                           // 0000007CCB94: D72C0014
	v_cndmask_b32_e32 v0, v14, v2, vcc_lo                      // 0000007CCB98: 0200050E
	.long 0xd72c000e                                           // 0000007CCB9C: D72C000E
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 0000007CCBA0: 02021C12
	s_lshr_b32 s19, s22, 27                                    // 0000007CCBA4: 85139B16
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000007CCBA8: CA100080 02020080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007CCBB0: BF870152
	v_add3_u32 v6, v6, v14, v13                                // 0000007CCBB4: D6550006 04361D06
	s_waitcnt vmcnt(1)                                         // 0000007CCBBC: BF8907F7
	v_bfe_u32 v12, v4, 16, 1                                   // 0000007CCBC0: D610000C 02052104
	s_waitcnt vmcnt(0)                                         // 0000007CCBC8: BF8903F7
	v_bfe_u32 v19, v7, 16, 1                                   // 0000007CCBCC: D6100013 02052107
	v_add3_u32 v4, v4, v12, 0x7fff                             // 0000007CCBD4: D6550004 03FE1904 00007FFF
	v_mad_u64_u32 v[11:12], null, v11, s2, s[14:15]            // 0000007CCBE0: D6FE7C0B 0038050B
	s_add_u32 s14, s10, s19                                    // 0000007CCBE8: 800E130A
	v_add3_u32 v7, v7, v19, 0x7fff                             // 0000007CCBEC: D6550007 03FE2707 00007FFF
	s_addc_u32 s15, s11, 0                                     // 0000007CCBF8: 820F800B
	.long 0x7e103984                                           // 0000007CCBFC: 7E103984
	s_lshr_b64 s[14:15], s[14:15], 5                           // 0000007CCC00: 858E850E
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v19, 2, v0      // 0000007CCC04: CA220080 04120082
	.long 0xd4440002                                           // 0000007CCC0C: D4440002
	v_cndmask_b32_e32 v1, s14, v16, vcc_lo                     // 0000007CCC10: 0202200E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CCC14: BF870003
	v_and_or_b32 v7, 0xffff0000, v7, v8                        // 0000007CCC18: D6570007 04220EFF FFFF0000
	v_add3_u32 v0, v20, v12, v15                               // 0000007CCC24: D6550000 043E1914
	ds_store_b32 v19, v7                                       // 0000007CCC2C: D8340000 00000713
	s_waitcnt lgkmcnt(0)                                       // 0000007CCC34: BF89FC07
	s_barrier                                                  // 0000007CCC38: BFBD0000
	buffer_gl0_inv                                             // 0000007CCC3C: E0AC0000 00000000
	s_and_saveexec_b32 s15, s2                                 // 0000007CCC44: BE8F2002
	s_cbranch_execz 26                                         // 0000007CCC48: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x1b4>
	s_add_u32 s3, s4, s16                                      // 0000007CCC4C: 80031004
	s_addc_u32 s18, s5, s17                                    // 0000007CCC50: 82121105
	v_lshlrev_b32_e32 v1, 1, v16                               // 0000007CCC54: 30022081
	.long 0xd7000302                                           // 0000007CCC58: D7000302
	v_cndmask_b32_e32 v1, s3, v5, vcc_lo                       // 0000007CCC5C: 02020A03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CCC60: BF8701A1
	v_add_co_ci_u32_e64 v3, null, s18, v6, s3                  // 0000007CCC64: D5207C03 000E0C12
	v_lshlrev_b32_e32 v4, 4, v16                               // 0000007CCC6C: 30082084
	.long 0xd7000301                                           // 0000007CCC70: D7000301
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000007CCC74: 02020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CCC78: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v3, s3                    // 0000007CCC7C: D5207C02 000E0680
	.long 0xd7000303                                           // 0000007CCC84: D7000303
	v_cndmask_b32_e32 v1, v11, v4, vcc_lo                      // 0000007CCC88: 0202090B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CCC8C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v0, s3                    // 0000007CCC90: D5207C04 000E0080
	s_clause 0x1                                               // 0000007CCC98: BF850001
	global_load_d16_b16 v7, v[1:2], off                        // 0000007CCC9C: DC820000 077C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000007CCCA4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000007CCCAC: BF8907F7
	v_cvt_f32_f16_e32 v18, v7                                  // 0000007CCCB0: 7E241707
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007CCCB4: 8C7E0F7E
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0             // 0000007CCCB8: CA100080 13140080
	v_mov_b32_e32 v21, 0                                       // 0000007CCCC0: 7E2A0280
	s_and_saveexec_b32 s15, s2                                 // 0000007CCCC4: BE8F2002
	s_cbranch_execz 382                                        // 0000007CCCC8: BFA5017E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x7c4>
	s_mul_i32 s2, s11, 6                                       // 0000007CCCCC: 9602860B
	s_mul_hi_u32 s3, s10, 6                                    // 0000007CCCD0: 9683860A
	v_dual_mov_b32 v13, 0 :: v_dual_lshlrev_b32 v12, 5, v16    // 0000007CCCD4: CA220080 0D0C2085
	s_add_i32 s20, s3, s2                                      // 0000007CCCDC: 81140203
	v_lshlrev_b32_e32 v7, 1, v16                               // 0000007CCCE0: 300E2081
	.long 0xd7000205                                           // 0000007CCCE4: D7000205
	v_cndmask_b32_e32 v1, s16, v5, vcc_lo                      // 0000007CCCE8: 02020A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CCCEC: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s17, v6, s2                  // 0000007CCCF0: D5207C06 000A0C11
	v_mov_b32_e32 v20, v13                                     // 0000007CCCF8: 7E28030D
	.long 0xd7000205                                           // 0000007CCCFC: D7000205
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000007CCD00: 02020F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CCD04: BF8701A1
	v_add_co_ci_u32_e64 v6, null, 0, v6, s2                    // 0000007CCD08: D5207C06 000A0C80
	v_lshl_or_b32 v22, v16, 4, 0x100                           // 0000007CCD10: D6560016 03FD0910 00000100
	.long 0xd7000205                                           // 0000007CCD1C: D7000205
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 0000007CCD20: 02020A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CCD24: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s5, v6, s2                   // 0000007CCD28: D5207C06 000A0C05
	v_dual_mov_b32 v23, v16 :: v_dual_mov_b32 v24, v18         // 0000007CCD30: CA100110 17180112
	.long 0xd700020e                                           // 0000007CCD38: D700020E
	v_cndmask_b32_e32 v0, v5, v160, vcc_lo                     // 0000007CCD3C: 02014105
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CCD40: BF870001
	v_add_co_ci_u32_e64 v15, null, 0, v6, s2                   // 0000007CCD44: D5207C0F 000A0C80
	v_mov_b32_e32 v21, v13                                     // 0000007CCD4C: 7E2A030D
	v_mov_b32_e32 v19, v13                                     // 0000007CCD50: 7E26030D
	v_mov_b32_e32 v17, v13                                     // 0000007CCD54: 7E22030D
	s_lshl_b64 s[18:19], s[10:11], 2                           // 0000007CCD58: 8492820A
	s_mul_i32 s17, s10, 6                                      // 0000007CCD5C: 9611860A
	s_mov_b32 s16, 0                                           // 0000007CCD60: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007CCD64: 8484810A
	s_branch 316                                               // 0000007CCD68: BFA0013C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x75c>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007CCD6C: 8C7E0A7E
	.long 0xd73c0019                                           // 0000007CCD70: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000007CCD74: 02021881
	v_and_b32_e32 v57, 0xff, v1                                // 0000007CCD78: 367202FF 000000FF
	v_lshrrev_b32_e32 v58, 6, v1                               // 0000007CCD80: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 0000007CCD84: 3276028E
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000007CCD88: 32020296
	v_and_b32_e32 v60, 0xff, v2                                // 0000007CCD8C: 367804FF 000000FF
	.long 0xd7000349                                           // 0000007CCD94: D7000349
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 0000007CCD98: 02023206
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CCD9C: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s7, v26, s3                 // 0000007CCDA0: D5207C4A 000E3407
	v_lshlrev_b32_e32 v57, 2, v57                              // 0000007CCDA8: 30727282
	.long 0xd700034d                                           // 0000007CCDAC: D700034D
	v_cndmask_b32_e32 v0, v73, v4, vcc_lo                      // 0000007CCDB0: 02000949
	global_load_b128 v[25:28], v[73:74], off                   // 0000007CCDB4: DC5E0000 197C0049
	v_add_co_ci_u32_e64 v78, null, s5, v74, s3                 // 0000007CCDBC: D5207C4E 000E9405
	.long 0xd700034f                                           // 0000007CCDC4: D700034F
	v_cndmask_b32_e32 v0, v73, v18, vcc_lo                     // 0000007CCDC8: 02002549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CCDCC: BF8700A1
	v_add_co_ci_u32_e64 v80, null, s19, v74, s3                // 0000007CCDD0: D5207C50 000E9413
	.long 0xd7000351                                           // 0000007CCDD8: D7000351
	v_cndmask_b32_e32 v0, v73, v17, vcc_lo                     // 0000007CCDDC: 02002349
	v_add_co_ci_u32_e64 v82, null, s20, v74, s3                // 0000007CCDE0: D5207C52 000E9414
	s_clause 0x6                                               // 0000007CCDE8: BF850006
	global_load_b128 v[29:32], v[77:78], off                   // 0000007CCDEC: DC5E0000 1D7C004D
	global_load_b128 v[33:36], v[79:80], off                   // 0000007CCDF4: DC5E0000 217C004F
	global_load_b128 v[37:40], v[81:82], off                   // 0000007CCDFC: DC5E0000 257C0051
	global_load_b128 v[41:44], v[73:74], off offset:16         // 0000007CCE04: DC5E0010 297C0049
	global_load_b128 v[45:48], v[77:78], off offset:16         // 0000007CCE0C: DC5E0010 2D7C004D
	global_load_b128 v[49:52], v[79:80], off offset:16         // 0000007CCE14: DC5E0010 317C004F
	global_load_b128 v[53:56], v[81:82], off offset:16         // 0000007CCE1C: DC5E0010 357C0051
	v_and_b32_e32 v58, 0x3fc, v58                              // 0000007CCE24: 367474FF 000003FC
	ds_load_b32 v75, v57                                       // 0000007CCE2C: D8D80000 4B000039
	v_lshrrev_b32_e32 v61, 6, v2                               // 0000007CCE34: 327A0486
	v_lshrrev_b32_e32 v62, 14, v2                              // 0000007CCE38: 327C048E
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000007CCE3C: 32040496
	ds_load_b32 v83, v58                                       // 0000007CCE40: D8D80000 5300003A
	v_and_b32_e32 v57, 0x3fc, v59                              // 0000007CCE48: 367276FF 000003FC
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000007CCE50: 360202FF 000003FC
	v_lshlrev_b32_e32 v76, 2, v60                              // 0000007CCE58: 30987882
	v_and_b32_e32 v84, 0x3fc, v61                              // 0000007CCE5C: 36A87AFF 000003FC
	v_and_b32_e32 v88, 0x3fc, v62                              // 0000007CCE64: 36B07CFF 000003FC
	ds_load_b32 v89, v57                                       // 0000007CCE6C: D8D80000 59000039
	s_clause 0x3                                               // 0000007CCE74: BF850003
	global_load_b128 v[57:60], v[73:74], off offset:32         // 0000007CCE78: DC5E0020 397C0049
	global_load_b128 v[61:64], v[77:78], off offset:32         // 0000007CCE80: DC5E0020 3D7C004D
	global_load_b128 v[65:68], v[79:80], off offset:32         // 0000007CCE88: DC5E0020 417C004F
	global_load_b128 v[69:72], v[81:82], off offset:32         // 0000007CCE90: DC5E0020 457C0051
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000007CCE98: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000007CCEA0: D8D80000 01000001
	ds_load_b32 v90, v76                                       // 0000007CCEA8: D8D80000 5A00004C
	ds_load_b32 v91, v84                                       // 0000007CCEB0: D8D80000 5B000054
	ds_load_b32 v88, v88                                       // 0000007CCEB8: D8D80000 58000058
	ds_load_b32 v2, v2                                         // 0000007CCEC0: D8D80000 02000002
	v_and_b32_e32 v85, 0xff, v3                                // 0000007CCEC8: 36AA06FF 000000FF
	v_lshrrev_b32_e32 v86, 6, v3                               // 0000007CCED0: 32AC0686
	v_lshrrev_b32_e32 v87, 14, v3                              // 0000007CCED4: 32AE068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000007CCED8: 32060696
	v_and_b32_e32 v92, 0xff, v4                                // 0000007CCEDC: 36B808FF 000000FF
	v_lshrrev_b32_e32 v93, 6, v4                               // 0000007CCEE4: 32BA0886
	v_lshrrev_b32_e32 v94, 14, v4                              // 0000007CCEE8: 32BC088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007CCEEC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000007CCEF0: 360606FF 000003FC
	s_and_b32 s3, exec_lo, s2                                  // 0000007CCEF8: 8B03027E
	.long 0xd700020e                                           // 0000007CCEFC: D700020E
	v_cndmask_b32_e32 v0, v14, v160, vcc_lo                    // 0000007CCF00: 0201410E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CCF04: BF870003
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007CCF08: 360808FF 000003FC
	v_add_nc_u32_e32 v12, 0x200, v12                           // 0000007CCF10: 4A1818FF 00000200
	v_add_nc_u32_e32 v22, 0x100, v22                           // 0000007CCF18: 4A2C2CFF 00000100
	v_add_co_ci_u32_e64 v15, null, 0, v15, s2                  // 0000007CCF20: D5207C0F 000A1E80
	s_or_b32 s16, s3, s16                                      // 0000007CCF28: 8C101003
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000007CCF2C: BF892C77
	v_dot2_f32_bf16 v25, v25, v75, 0                           // 0000007CCF30: CC1A4019 1A029719
	s_waitcnt lgkmcnt(6)                                       // 0000007CCF38: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CCF3C: BF870001
	v_dot2_f32_bf16 v25, v26, v83, v25                         // 0000007CCF40: CC1A4019 1C66A71A
	s_waitcnt vmcnt(10)                                        // 0000007CCF48: BF892BF7
	v_dot2_f32_bf16 v26, v29, v75, 0                           // 0000007CCF4C: CC1A401A 1A02971D
	s_waitcnt vmcnt(9)                                         // 0000007CCF54: BF8927F7
	v_dot2_f32_bf16 v29, v33, v75, 0                           // 0000007CCF58: CC1A401D 1A029721
	s_waitcnt vmcnt(8)                                         // 0000007CCF60: BF8923F7
	v_dot2_f32_bf16 v33, v37, v75, 0                           // 0000007CCF64: CC1A4021 1A029725
	s_waitcnt lgkmcnt(5)                                       // 0000007CCF6C: BF89FC57
	v_dot2_f32_bf16 v25, v27, v89, v25                         // 0000007CCF70: CC1A4019 1C66B31B
	global_load_b128 v[73:76], v[73:74], off offset:48         // 0000007CCF78: DC5E0030 497C0049
	v_dot2_f32_bf16 v30, v30, v83, v26                         // 0000007CCF80: CC1A401E 1C6AA71E
	v_dot2_f32_bf16 v29, v34, v83, v29                         // 0000007CCF88: CC1A401D 1C76A722
	v_dot2_f32_bf16 v33, v38, v83, v33                         // 0000007CCF90: CC1A4021 1C86A726
	s_waitcnt lgkmcnt(4)                                       // 0000007CCF98: BF89FC47
	v_dot2_f32_bf16 v34, v28, v1, v25                          // 0000007CCF9C: CC1A4022 1C66031C
	s_clause 0x2                                               // 0000007CCFA4: BF850002
	global_load_b128 v[25:28], v[77:78], off offset:48         // 0000007CCFA8: DC5E0030 197C004D
	global_load_b128 v[77:80], v[79:80], off offset:48         // 0000007CCFB0: DC5E0030 4D7C004F
	global_load_b128 v[81:84], v[81:82], off offset:48         // 0000007CCFB8: DC5E0030 517C0051
	v_dot2_f32_bf16 v30, v31, v89, v30                         // 0000007CCFC0: CC1A401E 1C7AB31F
	v_dot2_f32_bf16 v29, v35, v89, v29                         // 0000007CCFC8: CC1A401D 1C76B323
	v_dot2_f32_bf16 v31, v39, v89, v33                         // 0000007CCFD0: CC1A401F 1C86B327
	v_lshlrev_b32_e32 v33, 2, v85                              // 0000007CCFD8: 3042AA82
	v_and_b32_e32 v35, 0x3fc, v86                              // 0000007CCFDC: 3646ACFF 000003FC
	v_dot2_f32_bf16 v30, v32, v1, v30                          // 0000007CCFE4: CC1A401E 1C7A0320
	v_dot2_f32_bf16 v29, v36, v1, v29                          // 0000007CCFEC: CC1A401D 1C760324
	v_dot2_f32_bf16 v1, v40, v1, v31                           // 0000007CCFF4: CC1A4001 1C7E0328
	v_and_b32_e32 v37, 0x3fc, v87                              // 0000007CCFFC: 364AAEFF 000003FC
	s_waitcnt vmcnt(11) lgkmcnt(3)                             // 0000007CD004: BF892C37
	v_dot2_f32_bf16 v31, v41, v90, v34                         // 0000007CD008: CC1A401F 1C8AB529
	s_waitcnt vmcnt(10)                                        // 0000007CD010: BF892BF7
	v_dot2_f32_bf16 v30, v45, v90, v30                         // 0000007CD014: CC1A401E 1C7AB52D
	s_waitcnt vmcnt(9)                                         // 0000007CD01C: BF8927F7
	v_dot2_f32_bf16 v29, v49, v90, v29                         // 0000007CD020: CC1A401D 1C76B531
	s_waitcnt vmcnt(8)                                         // 0000007CD028: BF8923F7
	v_dot2_f32_bf16 v1, v53, v90, v1                           // 0000007CD02C: CC1A4001 1C06B535
	ds_load_b32 v32, v33                                       // 0000007CD034: D8D80000 20000021
	ds_load_b32 v34, v37                                       // 0000007CD03C: D8D80000 22000025
	s_waitcnt lgkmcnt(4)                                       // 0000007CD044: BF89FC47
	v_dot2_f32_bf16 v31, v42, v91, v31                         // 0000007CD048: CC1A401F 1C7EB72A
	v_dot2_f32_bf16 v30, v46, v91, v30                         // 0000007CD050: CC1A401E 1C7AB72E
	v_dot2_f32_bf16 v29, v50, v91, v29                         // 0000007CD058: CC1A401D 1C76B732
	v_dot2_f32_bf16 v1, v54, v91, v1                           // 0000007CD060: CC1A4001 1C06B736
	ds_load_b32 v33, v35                                       // 0000007CD068: D8D80000 21000023
	s_waitcnt lgkmcnt(4)                                       // 0000007CD070: BF89FC47
	v_dot2_f32_bf16 v31, v43, v88, v31                         // 0000007CD074: CC1A401F 1C7EB12B
	v_dot2_f32_bf16 v30, v47, v88, v30                         // 0000007CD07C: CC1A401E 1C7AB12F
	v_dot2_f32_bf16 v29, v51, v88, v29                         // 0000007CD084: CC1A401D 1C76B133
	v_dot2_f32_bf16 v1, v55, v88, v1                           // 0000007CD08C: CC1A4001 1C06B137
	v_lshlrev_b32_e32 v38, 2, v92                              // 0000007CD094: 304CB882
	s_waitcnt lgkmcnt(3)                                       // 0000007CD098: BF89FC37
	v_dot2_f32_bf16 v31, v44, v2, v31                          // 0000007CD09C: CC1A401F 1C7E052C
	v_dot2_f32_bf16 v30, v48, v2, v30                          // 0000007CD0A4: CC1A401E 1C7A0530
	v_dot2_f32_bf16 v29, v52, v2, v29                          // 0000007CD0AC: CC1A401D 1C760534
	v_dot2_f32_bf16 v1, v56, v2, v1                            // 0000007CD0B4: CC1A4001 1C060538
	v_and_b32_e32 v39, 0x3fc, v93                              // 0000007CD0BC: 364EBAFF 000003FC
	v_and_b32_e32 v85, 0x3fc, v94                              // 0000007CD0C4: 36AABCFF 000003FC
	ds_load_b32 v2, v3                                         // 0000007CD0CC: D8D80000 02000003
	ds_load_b32 v3, v38                                        // 0000007CD0D4: D8D80000 03000026
	ds_load_b32 v35, v39                                       // 0000007CD0DC: D8D80000 23000027
	ds_load_b32 v36, v85                                       // 0000007CD0E4: D8D80000 24000055
	ds_load_b32 v37, v4                                        // 0000007CD0EC: D8D80000 25000004
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007CD0F4: BF891C77
	v_dot2_f32_bf16 v4, v57, v32, v31                          // 0000007CD0F8: CC1A4004 1C7E4139
	s_waitcnt vmcnt(6)                                         // 0000007CD100: BF891BF7
	v_dot2_f32_bf16 v30, v61, v32, v30                         // 0000007CD104: CC1A401E 1C7A413D
	s_waitcnt vmcnt(5)                                         // 0000007CD10C: BF8917F7
	v_dot2_f32_bf16 v29, v65, v32, v29                         // 0000007CD110: CC1A401D 1C764141
	s_waitcnt vmcnt(4)                                         // 0000007CD118: BF8913F7
	v_dot2_f32_bf16 v1, v69, v32, v1                           // 0000007CD11C: CC1A4001 1C064145
	s_waitcnt lgkmcnt(5)                                       // 0000007CD124: BF89FC57
	v_dot2_f32_bf16 v4, v58, v33, v4                           // 0000007CD128: CC1A4004 1C12433A
	v_dot2_f32_bf16 v30, v62, v33, v30                         // 0000007CD130: CC1A401E 1C7A433E
	v_dot2_f32_bf16 v29, v66, v33, v29                         // 0000007CD138: CC1A401D 1C764342
	v_dot2_f32_bf16 v1, v70, v33, v1                           // 0000007CD140: CC1A4001 1C064346
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007CD148: BF870214
	v_dot2_f32_bf16 v4, v59, v34, v4                           // 0000007CD14C: CC1A4004 1C12453B
	v_dot2_f32_bf16 v30, v63, v34, v30                         // 0000007CD154: CC1A401E 1C7A453F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007CD15C: BF870214
	v_dot2_f32_bf16 v29, v67, v34, v29                         // 0000007CD160: CC1A401D 1C764543
	v_dot2_f32_bf16 v1, v71, v34, v1                           // 0000007CD168: CC1A4001 1C064547
	s_waitcnt lgkmcnt(4)                                       // 0000007CD170: BF89FC47
	v_dot2_f32_bf16 v4, v60, v2, v4                            // 0000007CD174: CC1A4004 1C12053C
	v_dot2_f32_bf16 v30, v64, v2, v30                          // 0000007CD17C: CC1A401E 1C7A0540
	v_dot2_f32_bf16 v29, v68, v2, v29                          // 0000007CD184: CC1A401D 1C760544
	v_dot2_f32_bf16 v1, v72, v2, v1                            // 0000007CD18C: CC1A4001 1C060548
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000007CD194: BF890C37
	v_dot2_f32_bf16 v2, v73, v3, v4                            // 0000007CD198: CC1A4002 1C120749
	v_mov_b32_e32 v4, v8                                       // 0000007CD1A0: 7E080308
	s_waitcnt vmcnt(2)                                         // 0000007CD1A4: BF890BF7
	v_dot2_f32_bf16 v25, v25, v3, v30                          // 0000007CD1A8: CC1A4019 1C7A0719
	s_waitcnt vmcnt(1)                                         // 0000007CD1B0: BF8907F7
	v_dot2_f32_bf16 v29, v77, v3, v29                          // 0000007CD1B4: CC1A401D 1C76074D
	s_waitcnt vmcnt(0)                                         // 0000007CD1BC: BF8903F7
	v_dot2_f32_bf16 v1, v81, v3, v1                            // 0000007CD1C0: CC1A4001 1C060751
	s_waitcnt lgkmcnt(2)                                       // 0000007CD1C8: BF89FC27
	v_dot2_f32_bf16 v2, v74, v35, v2                           // 0000007CD1CC: CC1A4002 1C0A474A
	v_mov_b32_e32 v3, v7                                       // 0000007CD1D4: 7E060307
	v_dot2_f32_bf16 v8, v26, v35, v25                          // 0000007CD1D8: CC1A4008 1C66471A
	v_dot2_f32_bf16 v25, v78, v35, v29                         // 0000007CD1E0: CC1A4019 1C76474E
	v_dot2_f32_bf16 v1, v82, v35, v1                           // 0000007CD1E8: CC1A4001 1C064752
	s_waitcnt lgkmcnt(1)                                       // 0000007CD1F0: BF89FC17
	v_dot2_f32_bf16 v7, v75, v36, v2                           // 0000007CD1F4: CC1A4007 1C0A494B
	v_mov_b32_e32 v2, v6                                       // 0000007CD1FC: 7E040306
	v_dot2_f32_bf16 v8, v27, v36, v8                           // 0000007CD200: CC1A4008 1C22491B
	v_dot2_f32_bf16 v25, v79, v36, v25                         // 0000007CD208: CC1A4019 1C66494F
	v_dot2_f32_bf16 v1, v83, v36, v1                           // 0000007CD210: CC1A4001 1C064953
	s_waitcnt lgkmcnt(0)                                       // 0000007CD218: BF89FC07
	v_dot2_f32_bf16 v6, v76, v37, v7                           // 0000007CD21C: CC1A4006 1C1E4B4C
	v_dot2_f32_bf16 v7, v28, v37, v8                           // 0000007CD224: CC1A4007 1C224B1C
	v_dot2_f32_bf16 v8, v80, v37, v25                          // 0000007CD22C: CC1A4008 1C664B50
	v_dot2_f32_bf16 v25, v84, v37, v1                          // 0000007CD234: CC1A4019 1C064B54
	v_mov_b32_e32 v1, v5                                       // 0000007CD23C: 7E020305
	v_fmac_f32_e32 v21, v18, v6                                // 0000007CD240: 562A0D12
	v_fmac_f32_e32 v20, v18, v7                                // 0000007CD244: 56280F12
	v_fmac_f32_e32 v19, v18, v8                                // 0000007CD248: 56261112
	v_dual_fmac_f32 v17, v18, v25 :: v_dual_mov_b32 v18, v24   // 0000007CD24C: C8103312 11120118
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007CD254: 917E107E
	s_cbranch_execz 25                                         // 0000007CD258: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_waitcnt vmcnt(0)                                         // 0000007CD25C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v23, 16, v23    // 0000007CD260: CA200102 06162E90
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000007CD268: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000007CD270: 7E0E0303
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CD274: BF870003
	.long 0xd4430002                                           // 0000007CD278: D4430002
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000007CD27C: 02022E0E
	s_mov_b32 s10, exec_lo                                     // 0000007CD280: BE8A007E
	.long 0xd4c4007e                                           // 0000007CD284: D4C4007E
	v_cndmask_b32_e32 v1, s14, v23, vcc_lo                     // 0000007CD288: 02022E0E
	s_cbranch_execz 65207                                      // 0000007CD28C: BFA5FEB7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	.long 0xd7000305                                           // 0000007CD290: D7000305
	v_cndmask_b32_e32 v1, v11, v22, vcc_lo                     // 0000007CD294: 02022D0B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007CD298: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v0, s3                    // 0000007CD29C: D5207C06 000E0080
	global_load_d16_b16 v24, v[14:15], off                     // 0000007CD2A4: DC820000 187C000E
	global_load_b128 v[5:8], v[5:6], off                       // 0000007CD2AC: DC5E0000 057C0005
	s_waitcnt vmcnt(1)                                         // 0000007CD2B4: BF8907F7
	v_cvt_f32_f16_e32 v24, v24                                 // 0000007CD2B8: 7E301718
	s_branch 65195                                             // 0000007CD2BC: BFA0FEAB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0x26c>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007CD2C0: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007CD2C4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s15                             // 0000007CD2C8: 8C7E0F7E
	.long 0xd71f0000                                           // 0000007CD2CC: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007CD2D0: 020100C1
	s_waitcnt vmcnt(0)                                         // 0000007CD2D4: BF8903F7
	v_xor_b32_e32 v1, 8, v0                                    // 0000007CD2D8: 3A020088
	v_xor_b32_e32 v5, 4, v0                                    // 0000007CD2DC: 3A0A0084
	v_xor_b32_e32 v11, 2, v0                                   // 0000007CD2E0: 3A160082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD2E4: BF870093
	.long 0xd44c0002                                           // 0000007CD2E8: D44C0002
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 0000007CD2EC: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s2                           // 0000007CD2F0: D5010001 000A0300
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD2F8: BF870114
	.long 0xd44c0002                                           // 0000007CD2FC: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007CD300: 02020AA0
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007CD304: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CD308: BF870002
	v_cndmask_b32_e64 v5, v0, v5, s2                           // 0000007CD30C: D5010005 000A0B00
	.long 0xd44c0002                                           // 0000007CD314: D44C0002
	v_cndmask_b32_e32 v1, 32, v11, vcc_lo                      // 0000007CD318: 020216A0
	ds_bpermute_b32 v2, v1, v21                                // 0000007CD31C: DACC0000 02001501
	v_cndmask_b32_e64 v11, v0, v11, s2                         // 0000007CD324: D501000B 000A1700
	s_waitcnt lgkmcnt(0)                                       // 0000007CD32C: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000007CD330: 06040515
	ds_bpermute_b32 v4, v1, v19                                // 0000007CD334: DACC0000 04001301
	ds_bpermute_b32 v3, v1, v20                                // 0000007CD33C: DACC0000 03001401
	ds_bpermute_b32 v1, v1, v17                                // 0000007CD344: DACC0000 01001101
	s_waitcnt lgkmcnt(2)                                       // 0000007CD34C: BF89FC27
	v_dual_add_f32 v4, v19, v4 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000007CD350: C9220913 04040A82
	ds_bpermute_b32 v6, v5, v2                                 // 0000007CD358: DACC0000 06000205
	s_waitcnt lgkmcnt(2)                                       // 0000007CD360: BF89FC27
	v_add_f32_e32 v3, v20, v3                                  // 0000007CD364: 06060714
	ds_bpermute_b32 v8, v5, v4                                 // 0000007CD368: DACC0000 08000405
	s_waitcnt lgkmcnt(1)                                       // 0000007CD370: BF89FC17
	v_dual_add_f32 v1, v17, v1 :: v_dual_add_f32 v2, v2, v6    // 0000007CD374: C9080311 01020D02
	ds_bpermute_b32 v7, v5, v3                                 // 0000007CD37C: DACC0000 07000305
	s_waitcnt lgkmcnt(1)                                       // 0000007CD384: BF89FC17
	v_add_f32_e32 v6, v4, v8                                   // 0000007CD388: 060C1104
	ds_bpermute_b32 v5, v5, v1                                 // 0000007CD38C: DACC0000 05000105
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000007CD394: 30161682
	ds_bpermute_b32 v4, v11, v2                                // 0000007CD398: DACC0000 0400020B
	ds_bpermute_b32 v8, v11, v6                                // 0000007CD3A0: DACC0000 0800060B
	s_waitcnt lgkmcnt(2)                                       // 0000007CD3A8: BF89FC27
	v_add_f32_e32 v1, v1, v5                                   // 0000007CD3AC: 06020B01
	v_xor_b32_e32 v5, 1, v0                                    // 0000007CD3B0: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD3B4: BF870091
	.long 0xd44c0002                                           // 0000007CD3B8: D44C0002
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 0000007CD3BC: 02020AA0
	v_cndmask_b32_e64 v0, v0, v5, s2                           // 0000007CD3C0: D5010000 000A0B00
	v_add_f32_e32 v3, v3, v7                                   // 0000007CD3C8: 06060F03
	s_waitcnt lgkmcnt(1)                                       // 0000007CD3CC: BF89FC17
	v_add_f32_e32 v5, v2, v4                                   // 0000007CD3D0: 060A0902
	s_waitcnt lgkmcnt(0)                                       // 0000007CD3D4: BF89FC07
	v_add_f32_e32 v2, v6, v8                                   // 0000007CD3D8: 06041106
	.long 0xd44a0002                                           // 0000007CD3DC: D44A0002
	v_cndmask_b32_e32 v1, 0, v16, vcc_lo                       // 0000007CD3E0: 02022080
	v_lshlrev_b32_e32 v12, 2, v0                               // 0000007CD3E4: 30180082
	ds_bpermute_b32 v7, v11, v3                                // 0000007CD3E8: DACC0000 0700030B
	s_and_b32 s2, s2, vcc_lo                                   // 0000007CD3F0: 8B026A02
	s_waitcnt lgkmcnt(0)                                       // 0000007CD3F4: BF89FC07
	v_add_f32_e32 v4, v3, v7                                   // 0000007CD3F8: 06080F03
	ds_bpermute_b32 v11, v11, v1                               // 0000007CD3FC: DACC0000 0B00010B
	ds_bpermute_b32 v3, v12, v2                                // 0000007CD404: DACC0000 0300020C
	ds_bpermute_b32 v6, v12, v4                                // 0000007CD40C: DACC0000 0600040C
	s_waitcnt lgkmcnt(2)                                       // 0000007CD414: BF89FC27
	v_add_f32_e32 v0, v1, v11                                  // 0000007CD418: 06001701
	ds_bpermute_b32 v7, v12, v5                                // 0000007CD41C: DACC0000 0700050C
	ds_bpermute_b32 v1, v12, v0                                // 0000007CD424: DACC0000 0100000C
	s_and_saveexec_b32 s3, s2                                  // 0000007CD42C: BE832002
	s_cbranch_execz 219                                        // 0000007CD430: BFA500DB <_ZN7halogen12_GLOBAL__N_16k_lq4wILi4ELi16ELi1ELb0ELi1ELi0EEEvPKhPKtPvlllllS6_f+0xca0>
	s_waitcnt lgkmcnt(1)                                       // 0000007CD434: BF89FC17
	v_dual_add_f32 v5, v5, v7 :: v_dual_add_f32 v4, v4, v6     // 0000007CD438: C9080F05 05040D04
	.long 0x7f0e3880                                           // 0000007CD440: 7F0E3880
	s_load_b32 s1, s[0:1], 0x48                                // 0000007CD444: F4000040 F8000048
	v_add_f32_e32 v2, v2, v3                                   // 0000007CD44C: 06040702
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007CD450: BF870003
	.long 0x7e0c3985                                           // 0000007CD454: 7E0C3985
	.long 0x7e0e3984                                           // 0000007CD458: 7E0E3984
	.long 0x7f0c3987                                           // 0000007CD45C: 7F0C3987
	s_waitcnt lgkmcnt(0)                                       // 0000007CD460: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007CD464: 06000300
	s_lshl_b64 s[2:3], s[12:13], 1                             // 0000007CD468: 8482810C
	s_lshl_b64 s[4:5], s[12:13], 2                             // 0000007CD46C: 8484820C
	v_and_b32_e32 v6, 1, v6                                    // 0000007CD470: 360C0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD474: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000007CD478: D6550005 03FE0D05 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000007CD484: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD48C: BF870091
	v_mul_f32_e32 v5, s1, v5                                   // 0000007CD490: 100A0A01
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 0000007CD494: 100C0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CD49C: BF870291
	v_exp_f32_e32 v6, v6                                       // 0000007CD4A0: 7E0C4B06
	v_add_f32_e32 v6, 1.0, v6                                  // 0000007CD4A4: 060C0CF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CD4A8: BF870121
	v_div_scale_f32 v11, null, v6, v6, v5                      // 0000007CD4AC: D6FC7C0B 04160D06
	v_div_scale_f32 v17, vcc_lo, v5, v6, v5                    // 0000007CD4B4: D6FC6A11 04160D05
	v_rcp_f32_e32 v13, v11                                     // 0000007CD4BC: 7E1A550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD4C0: BF870095
	v_fma_f32 v15, -v11, v13, 1.0                              // 0000007CD4C4: D613000F 23CA1B0B
	v_dual_fmac_f32 v13, v15, v13 :: v_dual_and_b32 v8, 1, v7  // 0000007CD4CC: C8241B0F 0D080E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD4D4: BF870091
	v_add3_u32 v4, v4, v8, 0x7fff                              // 0000007CD4D8: D6550004 03FE1104 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000007CD4E4: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD4EC: BF870091
	v_mul_f32_e32 v4, s1, v4                                   // 0000007CD4F0: 10080801
	v_mul_f32_e32 v8, 0xbfb8aa3b, v4                           // 0000007CD4F4: 101008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CD4FC: BF870291
	v_exp_f32_e32 v8, v8                                       // 0000007CD500: 7E104B08
	v_add_f32_e32 v8, 1.0, v8                                  // 0000007CD504: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007CD508: BF870121
	v_div_scale_f32 v12, null, v8, v8, v4                      // 0000007CD50C: D6FC7C0C 04121108
	v_div_scale_f32 v15, s0, v4, v8, v4                        // 0000007CD514: D6FC000F 04121104
	v_rcp_f32_e32 v14, v12                                     // 0000007CD51C: 7E1C550C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD520: BF870095
	v_fma_f32 v16, -v12, v14, 1.0                              // 0000007CD524: D6130010 23CA1D0C
	v_fmac_f32_e32 v14, v16, v14                               // 0000007CD52C: 561C1D10
	v_mul_f32_e32 v16, v17, v13                                // 0000007CD530: 10201B11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD534: BF870112
	v_mul_f32_e32 v18, v15, v14                                // 0000007CD538: 10241D0F
	v_fma_f32 v19, -v11, v16, v17                              // 0000007CD53C: D6130013 2446210B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD544: BF870112
	v_fma_f32 v20, -v12, v18, v15                              // 0000007CD548: D6130014 243E250C
	v_fmac_f32_e32 v16, v19, v13                               // 0000007CD550: 56201B13
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD554: BF870112
	v_fmac_f32_e32 v18, v20, v14                               // 0000007CD558: 56241D14
	v_fma_f32 v11, -v11, v16, v17                              // 0000007CD55C: D613000B 2446210B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD564: BF870112
	v_fma_f32 v3, -v12, v18, v15                               // 0000007CD568: D6130003 243E250C
	v_div_fmas_f32 v11, v11, v13, v16                          // 0000007CD570: D637000B 04421B0B
	s_mov_b32 vcc_lo, s0                                       // 0000007CD578: BEEA0000
	.long 0x7e183982                                           // 0000007CD57C: 7E183982
	.long 0x7f183987                                           // 0000007CD580: 7F183987
	v_div_fmas_f32 v3, v3, v14, v18                            // 0000007CD584: D6370003 044A1D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CD58C: BF870191
	v_div_fixup_f32 v8, v3, v8, v4                             // 0000007CD590: D6270008 04121103
	v_and_b32_e32 v3, 1, v12                                   // 0000007CD598: 36061881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD59C: BF870112
	.long 0x7e0e3988                                           // 0000007CD5A0: 7E0E3988
	v_add3_u32 v1, v2, v3, 0x7fff                              // 0000007CD5A4: D6550001 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007CD5B0: BF8701A2
	v_and_b32_e32 v12, 1, v7                                   // 0000007CD5B4: 36180E81
	.long 0x7e0e3980                                           // 0000007CD5B8: 7E0E3980
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007CD5BC: 360202FF FFFF0000
	v_div_fixup_f32 v11, v11, v6, v5                           // 0000007CD5C4: D627000B 04160D0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD5CC: BF870092
	v_dual_mul_f32 v13, s1, v1 :: v_dual_and_b32 v2, 1, v7     // 0000007CD5D0: C8E40201 0D020E81
	v_add3_u32 v0, v0, v2, 0x7fff                              // 0000007CD5D8: D6550000 03FE0500 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD5E4: BF870112
	v_mul_f32_e32 v1, 0xbfb8aa3b, v13                          // 0000007CD5E8: 10021AFF BFB8AA3B
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007CD5F0: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD5F8: BF870092
	v_exp_f32_e32 v1, v1                                       // 0000007CD5FC: 7E024B01
	v_mul_f32_e32 v2, s1, v0                                   // 0000007CD600: 10040001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CD604: BF870291
	v_mul_f32_e32 v0, 0xbfb8aa3b, v2                           // 0000007CD608: 100004FF BFB8AA3B
	v_add_f32_e32 v14, 1.0, v1                                 // 0000007CD610: 061C02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007CD614: BF870092
	v_exp_f32_e32 v0, v0                                       // 0000007CD618: 7E004B00
	v_div_scale_f32 v3, null, v14, v14, v13                    // 0000007CD61C: D6FC7C03 04361D0E
	v_div_scale_f32 v18, vcc_lo, v13, v14, v13                 // 0000007CD624: D6FC6A12 04361D0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000007CD62C: BF870312
	v_rcp_f32_e32 v4, v3                                       // 0000007CD630: 7E085503
	v_add_f32_e32 v15, 1.0, v0                                 // 0000007CD634: 061E00F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CD638: BF870291
	v_div_scale_f32 v16, null, v15, v15, v2                    // 0000007CD63C: D6FC7C10 040A1F0F
	v_fma_f32 v0, -v3, v4, 1.0                                 // 0000007CD644: D6130000 23CA0903
	v_div_scale_f32 v20, s0, v2, v15, v2                       // 0000007CD64C: D6FC0014 040A1F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD654: BF870113
	v_rcp_f32_e32 v17, v16                                     // 0000007CD658: 7E225510
	v_fmac_f32_e32 v4, v0, v4                                  // 0000007CD65C: 56080900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007CD660: BF870291
	v_mul_f32_e32 v19, v18, v4                                 // 0000007CD664: 10260912
	v_fma_f32 v0, -v16, v17, 1.0                               // 0000007CD668: D6130000 23CA2310
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007CD670: BF870112
	v_fma_f32 v1, -v3, v19, v18                                // 0000007CD674: D6130001 244A2703
	v_fmac_f32_e32 v17, v0, v17                                // 0000007CD67C: 56222300
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007CD680: BF870002
	v_fmac_f32_e32 v19, v1, v4                                 // 0000007CD684: 56260901
	.long 0xd73c0000                                           // 0000007CD688: D73C0000
	v_cndmask_b32_e32 v1, 1, v9, vcc_lo                        // 0000007CD68C: 02021281
	.long 0x7f143987                                           // 0000007CD690: 7F143987
	.long 0x7e14398b                                           // 0000007CD694: 7E14398B
	v_mul_f32_e32 v9, v20, v17                                 // 0000007CD698: 10122314
	v_fma_f32 v3, -v3, v19, v18                                // 0000007CD69C: D6130003 244A2703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CD6A4: BF870193
	v_and_b32_e32 v10, 1, v10                                  // 0000007CD6A8: 36141481
	v_fma_f32 v18, -v16, v9, v20                               // 0000007CD6AC: D6130012 24521310
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007CD6B4: BF8700A3
	v_div_fmas_f32 v19, v3, v4, v19                            // 0000007CD6B8: D6370013 044E0903
	.long 0xd7006a03                                           // 0000007CD6C0: D7006A03
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007CD6C4: 02020008
	v_add_co_ci_u32_e64 v4, null, s9, v1, vcc_lo               // 0000007CD6C8: D5207C04 01AA0209
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007CD6D0: BF870134
	v_fmac_f32_e32 v9, v18, v17                                // 0000007CD6D4: 56122312
	s_mov_b32 vcc_lo, s0                                       // 0000007CD6D8: BEEA0000
	v_div_fixup_f32 v13, v19, v14, v13                         // 0000007CD6DC: D627000D 04361D13
	v_fma_f32 v0, -v16, v9, v20                                // 0000007CD6E4: D6130000 24521310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000007CD6EC: BF870241
	v_div_fmas_f32 v5, v0, v17, v9                             // 0000007CD6F0: D6370005 04262300
	v_mad_u64_u32 v[0:1], null, s12, 6, v[3:4]                 // 0000007CD6F8: D6FE7C00 040D0C0C
	.long 0x7f123987                                           // 0000007CD700: 7F123987
	.long 0x7e12398d                                           // 0000007CD704: 7E12398D
	v_div_fixup_f32 v14, v5, v15, v2                           // 0000007CD708: D627000E 040A1F05
	.long 0xd7006a05                                           // 0000007CD710: D7006A05
	v_cndmask_b32_e32 v0, v3, v2, vcc_lo                       // 0000007CD714: 02000503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007CD718: BF870191
	v_add_co_ci_u32_e64 v6, null, s3, v4, vcc_lo               // 0000007CD71C: D5207C06 01AA0803
	.long 0x7e0e398e                                           // 0000007CD724: 7E0E398E
	v_mad_u64_u32 v[1:2], null, s13, 6, v[1:2]                 // 0000007CD728: D6FE7C01 04050C0D
	v_and_b32_e32 v2, 1, v9                                    // 0000007CD730: 36041281
	v_add3_u32 v9, v11, v10, 0x7fff                            // 0000007CD734: D6550009 03FE150B 00007FFF
	v_add3_u32 v10, v8, v12, 0x7fff                            // 0000007CD740: D655000A 03FE1908 00007FFF
	v_and_b32_e32 v11, 1, v7                                   // 0000007CD74C: 36160E81
	.long 0xd7006a07                                           // 0000007CD750: D7006A07
	v_cndmask_b32_e32 v0, v3, v4, vcc_lo                       // 0000007CD754: 02000903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007CD758: BF870221
	v_add_co_ci_u32_e64 v8, null, s5, v4, vcc_lo               // 0000007CD75C: D5207C08 01AA0805
	v_add3_u32 v2, v13, v2, 0x7fff                             // 0000007CD764: D6550002 03FE050D 00007FFF
	v_add3_u32 v11, v14, v11, 0x7fff                           // 0000007CD770: D655000B 03FE170E 00007FFF
	s_clause 0x3                                               // 0000007CD77C: BF850003
	global_store_d16_hi_b16 v[3:4], v9, off                    // 0000007CD780: DC960000 007C0903
	global_store_d16_hi_b16 v[5:6], v10, off                   // 0000007CD788: DC960000 007C0A05
	global_store_d16_hi_b16 v[7:8], v2, off                    // 0000007CD790: DC960000 007C0207
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000007CD798: DC960000 007C0B00
	s_endpgm                                                   // 0000007CD7A0: BFB00000
		...

