000000000056df00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000056DF00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000056DF08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000056DF0C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 00000056DF10: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 00000056DF14: 363C009F
	.long 0x7f0a3880                                           // 00000056DF18: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 00000056DF1C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 00000056DF20: BF89FC07
	.long 0xd4510000                                           // 00000056DF24: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000056DF28: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 00000056DF2C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 00000056DF30: 98148003
	s_cselect_b32 s21, s2, 0                                   // 00000056DF34: 98158002
	s_add_u32 s0, s4, s16                                      // 00000056DF38: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000056DF3C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 00000056DF40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 00000056DF44: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 00000056DF48: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056DF4C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 00000056DF50: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000056DF54: 30020282
	s_add_u32 s16, s10, s16                                    // 00000056DF58: 8010100A
	s_clause 0x1                                               // 00000056DF5C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000056DF60: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000056DF68: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 00000056DF70: 8211800B
	v_mov_b32_e32 v2, s1                                       // 00000056DF74: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000056DF78: 85908510
	v_mov_b32_e32 v1, s0                                       // 00000056DF7C: 7E020200
	s_add_i32 s17, s16, 7                                      // 00000056DF80: 81118710
	s_mul_i32 s1, s19, s21                                     // 00000056DF84: 96011513
	s_ashr_i32 s22, s17, 31                                    // 00000056DF88: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000056DF8C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 00000056DF90: 85009D16
	v_mad_u64_u32 v[24:25], null, s18, s21, v[1:2]             // 00000056DF94: D6FE7C18 04042A12
	s_add_i32 s17, s17, s0                                     // 00000056DF9C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 00000056DFA0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 00000056DFA4: B3900801
	.long 0xd72c0001                                           // 00000056DFA8: D72C0001
	v_cndmask_b32_e32 v1, s0, v29, vcc_lo                      // 00000056DFAC: 02023A00
	s_mul_i32 s17, s18, s20                                    // 00000056DFB0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000056DFB4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 00000056DFB8: 4A0E0200
	v_add_nc_u32_e32 v31, v1, v30                              // 00000056DFBC: 4A3E3D01
	s_cselect_b32 s0, -1, 0                                    // 00000056DFC0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 00000056DFC4: B2900800
	v_min_i32_e32 v32, s16, v7                                 // 00000056DFC8: 22400E10
	s_cselect_b32 s16, -1, 0                                   // 00000056DFCC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000056DFD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000056DFD4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 00000056DFD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 00000056DFDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 00000056DFE4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 00000056DFE8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000056DFF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v25                               // 00000056DFFC: 4A063201
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000056E000: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 00000056E004: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 00000056E010: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000056E014: 0202411F
	.long 0x7e0a3982                                           // 00000056E018: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056E01C: BF870114
	v_add_nc_u32_e32 v33, s17, v3                              // 00000056E020: 4A420611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 00000056E024: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 00000056E030: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 00000056E038: BF89FC07
	s_barrier                                                  // 00000056E03C: BFBD0000
	buffer_gl0_inv                                             // 00000056E040: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000056E048: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000056E04C: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 00000056E054: BE912001
	s_cbranch_execz 11                                         // 00000056E058: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000056E05C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E060: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E064: 3404029F
	.long 0xd7006a01                                           // 00000056E068: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E06C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E070: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E078: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E080: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 00000056E084: 7E101701
	s_or_b32 exec_lo, exec_lo, s17                             // 00000056E088: 8C7E117E
	v_add_nc_u32_e32 v1, 32, v31                               // 00000056E08C: 4A023EA0
	s_mov_b32 s1, exec_lo                                      // 00000056E090: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E094: BF870001
	.long 0xd4c1007e                                           // 00000056E098: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E09C: 02024101
	s_cbranch_execz 11                                         // 00000056E0A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E0A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E0A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E0AC: 3404029F
	.long 0xd7006a01                                           // 00000056E0B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E0B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E0B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E0C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E0C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 00000056E0CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E0D0: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 00000056E0D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 00000056E0DC: 7E160280
	s_mov_b32 s1, exec_lo                                      // 00000056E0E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056E0E4: BF870002
	.long 0xd4c1007e                                           // 00000056E0E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E0EC: 02024101
	s_cbranch_execz 11                                         // 00000056E0F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E0F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E0F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E0FC: 3404029F
	.long 0xd7006a01                                           // 00000056E100: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E104: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E108: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E110: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E118: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 00000056E11C: 7E141701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E120: 8C7E017E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 00000056E124: 4A023EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000056E12C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E130: BF870001
	.long 0xd4c1007e                                           // 00000056E134: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E138: 02024101
	s_cbranch_execz 11                                         // 00000056E13C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E140: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E144: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E148: 3404029F
	.long 0xd7006a01                                           // 00000056E14C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E150: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E154: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E15C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E164: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 00000056E168: 7E161701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E16C: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 00000056E170: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 00000056E17C: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 00000056E180: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056E184: BF870002
	.long 0xd4c1007e                                           // 00000056E188: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E18C: 02024101
	s_cbranch_execz 11                                         // 00000056E190: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E194: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E198: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E19C: 3404029F
	.long 0xd7006a01                                           // 00000056E1A0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E1A4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E1A8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E1B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E1B8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 00000056E1BC: 7E181701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E1C0: 8C7E017E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 00000056E1C4: 4A023EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000056E1CC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E1D0: BF870001
	.long 0xd4c1007e                                           // 00000056E1D4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E1D8: 02024101
	s_cbranch_execz 11                                         // 00000056E1DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E1E0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E1E4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E1E8: 3404029F
	.long 0xd7006a01                                           // 00000056E1EC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E1F0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E1F4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E1FC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E204: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 00000056E208: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E20C: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 00000056E210: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 00000056E21C: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 00000056E220: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056E224: BF870002
	.long 0xd4c1007e                                           // 00000056E228: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E22C: 02024101
	s_cbranch_execz 11                                         // 00000056E230: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E234: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E238: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E23C: 3404029F
	.long 0xd7006a01                                           // 00000056E240: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E244: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E248: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E250: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E258: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 00000056E25C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E260: 8C7E017E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 00000056E264: 4A023EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000056E26C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E270: BF870001
	.long 0xd4c1007e                                           // 00000056E274: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000056E278: 02024101
	s_cbranch_execz 11                                         // 00000056E27C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 00000056E280: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E284: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E288: 3404029F
	.long 0xd7006a01                                           // 00000056E28C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E290: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056E294: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E29C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E2A4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 00000056E2A8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000056E2AC: 8C7E017E
	s_branch 9                                                 // 00000056E2B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 00000056E2B4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E2B8: BF870001
	v_mov_b32_e32 v9, v8                                       // 00000056E2BC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 00000056E2C0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 00000056E2C4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 00000056E2C8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 00000056E2CC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 00000056E2D0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 00000056E2D4: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 00000056E2D8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000056E2DC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000056E2E0: 85019F0B
	v_dual_mov_b32 v1, s21 :: v_dual_mov_b32 v20, 0            // 00000056E2E4: CA100015 01140080
	s_add_u32 s14, s10, s1                                     // 00000056E2EC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000056E2F0: 820F800B
	.long 0xd4410001                                           // 00000056E2F4: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000056E2F8: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000056E2FC: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 00000056E300: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 00000056E308: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000056E310: D72C0001
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 00000056E314: 02001E15
	.long 0xd72c0002                                           // 00000056E318: D72C0002
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 00000056E31C: 02001C14
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000056E320: D5010023 00410280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 00000056E328: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 00000056E330: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000056E334: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 00000056E338: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 00000056E340: BE842001
	s_cbranch_execz 22                                         // 00000056E344: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 00000056E348: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000056E34C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E350: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000056E354: 3404029F
	.long 0xd7006a01                                           // 00000056E358: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000056E35C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000056E360: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000056E368: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 00000056E36C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000056E374: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000056E378: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E37C: BF870091
	.long 0xd7006a01                                           // 00000056E380: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000056E384: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 00000056E388: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 00000056E390: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056E398: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000056E39C: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 00000056E3A0: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000056E3A4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 00000056E3AC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v37, 0             // 00000056E3B4: CA100080 2A240080
	s_and_saveexec_b32 s14, s1                                 // 00000056E3BC: BE8E2001
	s_cbranch_execz 610                                        // 00000056E3C0: BFA50262 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe4c>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 00000056E3C4: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 00000056E3CC: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 00000056E3D4: CA100080 27260080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056E3DC: BF870003
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v43, 4, v1     // 00000056E3E0: CA220080 282A0284
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v44, 1, v1     // 00000056E3E8: CA220080 292C0281
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, v27           // 00000056E3F0: CA100080 222C011B
	s_mul_i32 s1, s11, 6                                       // 00000056E3F8: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 00000056E3FC: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000056E400: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000056E404: 810F010F
	s_mul_i32 s17, s10, 6                                      // 00000056E408: 9611860A
	s_mov_b32 s16, 0                                           // 00000056E40C: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000056E410: 848A810A
	s_branch 553                                               // 00000056E414: BFA00229 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xdbc>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000056E418: 8C7E127E
	v_cndmask_b32_e64 v56, v27, v8, s0                         // 00000056E41C: D5010038 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 00000056E424: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000056E42C: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 00000056E434: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 00000056E440: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 00000056E448: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 00000056E450: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 00000056E458: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000056E460: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 00000056E464: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000056E46C: 3436349F
	s_and_b32 s1, exec_lo, s1                                  // 00000056E470: 8B01017E
	v_add_nc_u32_e32 v43, 0x200, v43                           // 00000056E474: 4A5656FF 00000200
	ds_load_b32 v15, v9                                        // 00000056E47C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 00000056E484: 32122886
	s_or_b32 s16, s1, s16                                      // 00000056E488: 8C101001
	v_add_nc_u32_e32 v44, 64, v44                              // 00000056E48C: 4A5858C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E490: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E494: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 00000056E49C: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 00000056E4A4: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E4A8: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 00000056E4B0: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 00000056E4B8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E4BC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E4C0: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 00000056E4C8: D8D80000 3B000009
	v_and_b32_e32 v9, 0xff, v21                                // 00000056E4D0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000056E4D8: 30121282
	ds_load_b32 v60, v9                                        // 00000056E4DC: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 00000056E4E4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E4E8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E4EC: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 00000056E4F4: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 00000056E4FC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E500: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 00000056E508: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 00000056E510: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E514: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E518: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 00000056E520: D8D80000 3F000009
	v_and_b32_e32 v9, 0xff, v22                                // 00000056E528: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000056E530: 30121282
	ds_load_b32 v64, v9                                        // 00000056E534: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000056E53C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E540: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E544: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 00000056E54C: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 00000056E554: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E558: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 00000056E560: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 00000056E568: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E56C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E570: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 00000056E578: D8D80000 43000009
	v_and_b32_e32 v9, 0xff, v23                                // 00000056E580: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000056E588: 30121282
	ds_load_b32 v68, v9                                        // 00000056E58C: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 00000056E594: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E598: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E59C: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 00000056E5A4: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 00000056E5AC: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E5B0: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 00000056E5B8: D8D80000 46000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 00000056E5C0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000056E5C4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000056E5C8: 361212FF 000003FC
	ds_load_b32 v71, v9                                        // 00000056E5D0: D8D80000 47000009
	.long 0xd73c0009                                           // 00000056E5D8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000056E5DC: 02023481
	v_dual_mov_b32 v27, v45 :: v_dual_add_nc_u32 v26, 0x400, v26// 00000056E5E0: CA20012D 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 00000056E5EC: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 00000056E5F0: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E5F4: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 00000056E5F8: D5207C0E 01AA1407
	s_clause 0x3                                               // 00000056E600: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000056E604: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000056E60C: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000056E614: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000056E61C: DC5E0030 327C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000056E624: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056E628: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 00000056E630: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E634: BF8700A1
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056E638: CC1A4009 1C26730A
	s_waitcnt lgkmcnt(13)                                      // 00000056E640: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056E644: CC1A4009 1C26750B
	s_waitcnt lgkmcnt(12)                                      // 00000056E64C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E650: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056E654: CC1A4009 1C26770C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000056E65C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056E660: CC1A4009 1C267914
	s_waitcnt lgkmcnt(10)                                      // 00000056E668: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E66C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056E670: CC1A4009 1C267B15
	s_waitcnt lgkmcnt(9)                                       // 00000056E678: BF89FC97
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056E67C: CC1A4009 1C267D16
	s_waitcnt lgkmcnt(8)                                       // 00000056E684: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E688: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056E68C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000056E694: BF890477
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056E698: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(6)                                       // 00000056E6A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E6A4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056E6A8: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(5)                                       // 00000056E6B0: BF89FC57
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056E6B4: CC1A4009 1C268530
	s_waitcnt lgkmcnt(4)                                       // 00000056E6BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E6C0: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056E6C4: CC1A4009 1C268731
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000056E6CC: BF890037
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056E6D0: CC1A4009 1C268932
	.long 0xd7006a32                                           // 00000056E6D8: D7006A32
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 00000056E6DC: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 00000056E6E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000056E6E4: BF8701C2
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056E6E8: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v51, null, s11, v14, vcc_lo            // 00000056E6F0: D5207C33 01AA1C0B
	.long 0xd7006a36                                           // 00000056E6F8: D7006A36
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000056E6FC: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 00000056E700: BF89FC17
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056E704: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v55, null, s5, v14, vcc_lo             // 00000056E70C: D5207C37 01AA1C05
	.long 0xd7006a0d                                           // 00000056E714: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 00000056E718: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000056E71C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056E720: BF870123
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056E724: CC1A4009 1C268F35
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000056E72C: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v56, v9                                // 00000056E734: 564A1338
	s_clause 0x3                                               // 00000056E738: BF850003
	global_load_b128 v[9:12], v[50:51], off                    // 00000056E73C: DC5E0000 097C0032
	global_load_b128 v[20:23], v[50:51], off offset:16         // 00000056E744: DC5E0010 147C0032
	global_load_b128 v[46:49], v[50:51], off offset:32         // 00000056E74C: DC5E0020 2E7C0032
	global_load_b128 v[50:53], v[50:51], off offset:48         // 00000056E754: DC5E0030 327C0032
	s_waitcnt vmcnt(3)                                         // 00000056E75C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056E760: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E768: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056E76C: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056E774: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E77C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056E780: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056E788: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056E78C: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E794: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056E798: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056E7A0: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E7A8: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056E7AC: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000056E7B4: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056E7B8: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E7C0: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056E7C4: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056E7CC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056E7D4: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056E7D8: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056E7E0: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056E7E4: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E7EC: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056E7F0: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056E7F8: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E800: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056E804: CC1A4009 1C268F35
	v_fmac_f32_e32 v42, v56, v9                                // 00000056E80C: 56541338
	s_clause 0x3                                               // 00000056E810: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 00000056E814: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 00000056E81C: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 00000056E824: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 00000056E82C: DC5E0030 327C0036
	.long 0xd7006a36                                           // 00000056E834: D7006A36
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 00000056E838: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E83C: BF8700B1
	v_add_co_ci_u32_e64 v55, null, s5, v55, vcc_lo             // 00000056E840: D5207C37 01AA6E05
	s_waitcnt vmcnt(3)                                         // 00000056E848: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056E84C: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056E854: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E85C: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056E860: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056E868: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056E870: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E874: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056E878: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056E880: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E888: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056E88C: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056E894: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000056E89C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E8A0: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056E8A4: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056E8AC: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E8B4: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056E8B8: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056E8C0: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056E8C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E8CC: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056E8D0: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056E8D8: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E8E0: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056E8E4: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056E8EC: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E8F4: BF870001
	v_fmac_f32_e32 v41, v56, v9                                // 00000056E8F8: 56521338
	s_clause 0x3                                               // 00000056E8FC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000056E900: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000056E908: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000056E910: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000056E918: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 00000056E920: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000056E924: 0200090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056E928: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 00000056E92C: D5207C0E 01AA1C05
	s_waitcnt vmcnt(3)                                         // 00000056E934: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056E938: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056E940: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E948: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056E94C: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056E954: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056E95C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E960: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056E964: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056E96C: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E974: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056E978: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056E980: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000056E988: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E98C: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056E990: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056E998: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E9A0: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056E9A4: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056E9AC: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056E9B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E9B8: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056E9BC: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056E9C4: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056E9CC: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056E9D0: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056E9D8: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056E9E0: BF870001
	v_fmac_f32_e32 v40, v56, v9                                // 00000056E9E4: 56501338
	s_clause 0x3                                               // 00000056E9E8: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 00000056E9EC: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 00000056E9F4: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 00000056E9FC: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 00000056EA04: DC5E0030 327C0036
	s_waitcnt vmcnt(3)                                         // 00000056EA0C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056EA10: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EA18: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056EA1C: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056EA24: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EA2C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056EA30: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056EA38: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056EA3C: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EA44: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056EA48: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056EA50: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EA58: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056EA5C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000056EA64: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056EA68: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EA70: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056EA74: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056EA7C: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EA84: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056EA88: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056EA90: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056EA94: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EA9C: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056EAA0: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056EAA8: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EAB0: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056EAB4: CC1A4009 1C268F35
	v_fmac_f32_e32 v39, v56, v9                                // 00000056EABC: 564E1338
	s_clause 0x3                                               // 00000056EAC0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000056EAC4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000056EACC: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000056EAD4: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000056EADC: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 00000056EAE4: D7006A0D
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 00000056EAE8: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056EAEC: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v55, vcc_lo             // 00000056EAF0: D5207C0E 01AA6E05
	s_waitcnt vmcnt(3)                                         // 00000056EAF8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056EAFC: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056EB04: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB0C: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056EB10: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056EB18: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056EB20: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB24: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056EB28: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056EB30: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB38: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056EB3C: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056EB44: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 00000056EB4C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB50: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056EB54: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056EB5C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB64: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056EB68: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056EB70: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056EB78: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB7C: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056EB80: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056EB88: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EB90: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056EB94: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056EB9C: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056EBA4: BF870001
	v_fmac_f32_e32 v38, v56, v9                                // 00000056EBA8: 564C1338
	s_clause 0x3                                               // 00000056EBAC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000056EBB0: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000056EBB8: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 00000056EBC0: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 00000056EBC8: DC5E0030 327C000D
	s_waitcnt vmcnt(3)                                         // 00000056EBD0: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000056EBD4: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EBDC: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 00000056EBE0: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 00000056EBE8: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EBF0: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 00000056EBF4: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 00000056EBFC: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 00000056EC00: CC1A4009 1C267914
	v_mov_b32_e32 v20, v16                                     // 00000056EC08: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000056EC0C: BF870122
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 00000056EC10: CC1A4009 1C267B15
	v_mov_b32_e32 v21, v17                                     // 00000056EC18: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 00000056EC1C: CC1A4009 1C267D16
	v_mov_b32_e32 v22, v18                                     // 00000056EC24: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000056EC28: BF870132
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 00000056EC2C: CC1A4009 1C267F17
	v_mov_b32_e32 v23, v19                                     // 00000056EC34: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 00000056EC38: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000056EC3C: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EC44: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000056EC48: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000056EC50: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EC58: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000056EC5C: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 00000056EC64: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000056EC68: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EC70: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000056EC74: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 00000056EC7C: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056EC84: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 00000056EC88: CC1A4009 1C268F35
	v_fmac_f32_e32 v34, v56, v9                                // 00000056EC90: 56441338
	v_mov_b32_e32 v15, v8                                      // 00000056EC94: 7E1E0308
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 00000056EC98: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000056ECA0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000056ECA8: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 00000056ECB0: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000056ECB4: 917E107E
	s_cbranch_execz 35                                         // 00000056ECB8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xe48>
	s_waitcnt vmcnt(0)                                         // 00000056ECBC: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 00000056ECC0: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 00000056ECC8: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 00000056ECD0: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056ECD4: BF870003
	.long 0xd4460001                                           // 00000056ECD8: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000056ECDC: 0202411F
	s_mov_b32 s18, exec_lo                                     // 00000056ECE0: BE92007E
	.long 0xd4c1007e                                           // 00000056ECE4: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000056ECE8: 0202411F
	s_cbranch_execz 64970                                      // 00000056ECEC: BFA5FDCA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v43                              // 00000056ECF0: 3404569F
	.long 0xd7006a01                                           // 00000056ECF4: D7006A01
	v_cndmask_b32_e32 v1, v25, v43, vcc_lo                     // 00000056ECF8: 02025719
	v_mov_b32_e32 v45, v27                                     // 00000056ECFC: 7E5A031B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056ED00: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000056ED04: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 00000056ED0C: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 00000056ED10: DC5E0000 107C0001
	s_cbranch_vccnz 64959                                      // 00000056ED18: BFA4FDBF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v44                              // 00000056ED1C: 3404589F
	.long 0xd7006a01                                           // 00000056ED20: D7006A01
	v_cndmask_b32_e32 v1, v24, v44, vcc_lo                     // 00000056ED24: 02025918
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056ED28: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000056ED2C: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000056ED34: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000056ED3C: BF8903F7
	v_cvt_f32_f16_e32 v45, v1                                  // 00000056ED40: 7E5A1701
	s_branch 64948                                             // 00000056ED44: BFA0FDB4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000056ED48: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000056ED4C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000056ED50: 8C7E0E7E
	.long 0xd71f0001                                           // 00000056ED54: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000056ED58: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000056ED5C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000056ED60: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000056ED64: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 00000056ED68: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000056ED6C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000056ED70: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000056ED74: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000056ED78: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000056ED7C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000056ED80: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000056ED84: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000056ED88: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000056ED8C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 00000056ED90: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 00000056ED98: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000056ED9C: 06060725
	ds_bpermute_b32 v5, v2, v41                                // 00000056EDA0: DACC0000 05002902
	ds_bpermute_b32 v6, v2, v40                                // 00000056EDA8: DACC0000 06002802
	ds_bpermute_b32 v7, v2, v39                                // 00000056EDB0: DACC0000 07002702
	ds_bpermute_b32 v4, v2, v42                                // 00000056EDB8: DACC0000 04002A02
	ds_bpermute_b32 v8, v2, v38                                // 00000056EDC0: DACC0000 08002602
	ds_bpermute_b32 v2, v2, v34                                // 00000056EDC8: DACC0000 02002202
	ds_bpermute_b32 v10, v9, v3                                // 00000056EDD0: DACC0000 0A000309
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 00000056EDD8: 02202101
	s_waitcnt lgkmcnt(5)                                       // 00000056EDDC: BF89FC57
	v_dual_add_f32 v5, v41, v5 :: v_dual_add_f32 v6, v40, v6   // 00000056EDE0: C9080B29 05060D28
	s_waitcnt lgkmcnt(3)                                       // 00000056EDE8: BF89FC37
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v42, v4   // 00000056EDEC: C9080F27 0704092A
	s_waitcnt lgkmcnt(2)                                       // 00000056EDF4: BF89FC27
	v_add_f32_e32 v8, v38, v8                                  // 00000056EDF8: 06101126
	ds_bpermute_b32 v12, v9, v5                                // 00000056EDFC: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 00000056EE04: BF89FC27
	v_add_f32_e32 v2, v34, v2                                  // 00000056EE08: 06040522
	ds_bpermute_b32 v14, v9, v7                                // 00000056EE0C: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 00000056EE14: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 00000056EE1C: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 00000056EE24: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 00000056EE2C: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 00000056EE30: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 00000056EE38: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 00000056EE3C: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 00000056EE40: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 00000056EE48: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 00000056EE4C: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 00000056EE54: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 00000056EE5C: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 00000056EE60: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 00000056EE68: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 00000056EE6C: DACC0000 0D000710
	v_add_f32_e32 v8, v8, v15                                  // 00000056EE74: 06101F08
	ds_bpermute_b32 v15, v16, v2                               // 00000056EE78: DACC0000 0F000210
	s_waitcnt lgkmcnt(3)                                       // 00000056EE80: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 00000056EE84: 06061303
	ds_bpermute_b32 v10, v16, v4                               // 00000056EE88: DACC0000 0A000410
	s_waitcnt lgkmcnt(3)                                       // 00000056EE90: BF89FC37
	v_add_f32_e32 v5, v5, v11                                  // 00000056EE94: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 00000056EE98: DACC0000 0C000610
	s_waitcnt lgkmcnt(3)                                       // 00000056EEA0: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 00000056EEA4: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 00000056EEA8: DACC0000 0E000810
	v_xor_b32_e32 v16, 2, v1                                   // 00000056EEB0: 3A200282
	s_waitcnt lgkmcnt(3)                                       // 00000056EEB4: BF89FC37
	v_add_f32_e32 v2, v2, v15                                  // 00000056EEB8: 06041F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000056EEBC: BF8701D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000056EEC0: 7C9820A0
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 00000056EEC4: 02202101
	s_waitcnt lgkmcnt(1)                                       // 00000056EEC8: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 00000056EECC: 060C1906
	v_add_f32_e32 v4, v4, v10                                  // 00000056EED0: 06081504
	v_lshlrev_b32_e32 v16, 2, v16                              // 00000056EED4: 30202082
	s_waitcnt lgkmcnt(0)                                       // 00000056EED8: BF89FC07
	v_add_f32_e32 v8, v8, v14                                  // 00000056EEDC: 06101D08
	ds_bpermute_b32 v9, v16, v3                                // 00000056EEE0: DACC0000 09000310
	ds_bpermute_b32 v10, v16, v4                               // 00000056EEE8: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 00000056EEF0: DACC0000 0B000510
	ds_bpermute_b32 v12, v16, v6                               // 00000056EEF8: DACC0000 0C000610
	ds_bpermute_b32 v13, v16, v7                               // 00000056EF00: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v8                               // 00000056EF08: DACC0000 0E000810
	ds_bpermute_b32 v15, v16, v2                               // 00000056EF10: DACC0000 0F000210
	v_xor_b32_e32 v16, 1, v1                                   // 00000056EF18: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056EF1C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 00000056EF20: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 00000056EF24: 02022101
	v_lshlrev_b32_e32 v16, 2, v1                               // 00000056EF28: 30200282
	s_waitcnt lgkmcnt(6)                                       // 00000056EF2C: BF89FC67
	v_add_f32_e32 v1, v3, v9                                   // 00000056EF30: 06021303
	s_waitcnt lgkmcnt(4)                                       // 00000056EF34: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 00000056EF38: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 00000056EF40: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v10, v7, v13  // 00000056EF44: C9081906 050A1B07
	s_waitcnt lgkmcnt(1)                                       // 00000056EF4C: BF89FC17
	v_add_f32_e32 v12, v8, v14                                 // 00000056EF50: 06181D08
	s_waitcnt lgkmcnt(0)                                       // 00000056EF54: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 00000056EF58: 06041F02
	ds_bpermute_b32 v6, v16, v1                                // 00000056EF5C: DACC0000 06000110
	ds_bpermute_b32 v8, v16, v3                                // 00000056EF64: DACC0000 08000310
	ds_bpermute_b32 v9, v16, v4                                // 00000056EF6C: DACC0000 09000410
	ds_bpermute_b32 v11, v16, v5                               // 00000056EF74: DACC0000 0B000510
	ds_bpermute_b32 v13, v16, v10                              // 00000056EF7C: DACC0000 0D000A10
	ds_bpermute_b32 v14, v16, v12                              // 00000056EF84: DACC0000 0E000C10
	ds_bpermute_b32 v7, v16, v2                                // 00000056EF8C: DACC0000 07000210
	v_cmpx_eq_u32_e32 0, v30                                   // 00000056EF94: 7D943C80
	s_cbranch_execz 28                                         // 00000056EF98: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x110c>
	s_waitcnt lgkmcnt(2)                                       // 00000056EF9C: BF89FC27
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v8  // 00000056EFA0: C9081B0A 0A021103
	v_mul_u32_u24_e32 v13, 28, v29                             // 00000056EFA8: 161A3A9C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v1, v6     // 00000056EFAC: C9081304 04000D01
	s_waitcnt lgkmcnt(1)                                       // 00000056EFB4: BF89FC17
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v5, v5, v11 // 00000056EFB8: C9081D0C 0C041705
	s_delay_alu instid0(VALU_DEP_3)                            // 00000056EFC0: BF870003
	v_or_b32_e32 v6, 0x400, v13                                // 00000056EFC4: 380C1AFF 00000400
	v_mad_u32_u24 v8, v29, 28, 0x408                           // 00000056EFCC: D60B0008 03FD391D 00000408
	v_mad_u32_u24 v9, v29, 28, 0x410                           // 00000056EFD8: D60B0009 03FD391D 00000410
	s_waitcnt lgkmcnt(0)                                       // 00000056EFE4: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000056EFE8: 06040F02
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 00000056EFEC: D8380100 00030106
	ds_store_2addr_b32 v8, v4, v5 offset1:1                    // 00000056EFF4: D8380100 00050408
	ds_store_2addr_b32 v9, v10, v12 offset1:1                  // 00000056EFFC: D8380100 000C0A09
	ds_store_b32 v13, v2 offset:1048                           // 00000056F004: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 00000056F00C: 8C7E007E
	.long 0xd4510000                                           // 00000056F010: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000056F014: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 00000056F018: 7C980087
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000056F01C: BF890007
	s_barrier                                                  // 00000056F020: BFBD0000
	buffer_gl0_inv                                             // 00000056F024: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 00000056F02C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000056F030: BF870009
	s_and_saveexec_b32 s1, s0                                  // 00000056F034: BE812000
	s_cbranch_execz 51                                         // 00000056F038: BFA50033 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1208>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 00000056F03C: 4A0E38FF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 00000056F044: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 00000056F048: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 00000056F050: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 00000056F058: D8DC231C 05000007
	s_waitcnt lgkmcnt(2)                                       // 00000056F060: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 00000056F064: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000056F068: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 00000056F06C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 00000056F070: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 00000056F074: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000056F078: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 00000056F07C: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000056F080: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 00000056F088: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000056F08C: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000056F090: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 00000056F094: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:42 offset1:49         // 00000056F098: D8DC312A 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000056F0A0: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 00000056F0A8: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 00000056F0AC: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 00000056F0B0: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000056F0B4: BF870113
	.long 0xd73c0000                                           // 00000056F0B8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000056F0BC: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 00000056F0C0: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000056F0C8: BF870092
	.long 0xd7006a00                                           // 00000056F0CC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000056F0D0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000056F0D4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000056F0DC: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 00000056F0E0: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 00000056F0EC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000056F0F0: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000056F0F4: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000056F0F8: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000056F100: DC960000 007C0200
	s_endpgm                                                   // 00000056F108: BFB00000
		...

