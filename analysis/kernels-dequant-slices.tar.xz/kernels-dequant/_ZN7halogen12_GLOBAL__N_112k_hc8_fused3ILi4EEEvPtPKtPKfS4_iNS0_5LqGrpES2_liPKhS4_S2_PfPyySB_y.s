000000000031fe00 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y>:
; _ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y():
	s_clause 0x2                                               // 00000031FE00: BF850002
	s_load_b32 s24, s[0:1], 0x20                               // 00000031FE04: F4000600 F8000020
	s_load_b128 s[20:23], s[0:1], 0x150                        // 00000031FE0C: F4080500 F8000150
	s_load_b512 s[4:19], s[0:1], 0x168                         // 00000031FE14: F4100100 F8000168
	s_mov_b32 s3, -1                                           // 00000031FE1C: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 00000031FE20: BF89FC07
	s_cmp_ge_i32 s2, s24                                       // 00000031FE24: BF031802
	s_cbranch_scc0 3892                                        // 00000031FE28: BFA10F34 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3cfc>
	s_load_b32 s3, s[0:1], 0x160                               // 00000031FE2C: F40000C0 F8000160
	s_mov_b32 s25, -1                                          // 00000031FE34: BE9900C1
	s_waitcnt lgkmcnt(0)                                       // 00000031FE38: BF89FC07
	s_add_i32 s3, s3, s24                                      // 00000031FE3C: 81031803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031FE40: BF870009
	s_cmp_ge_i32 s2, s3                                        // 00000031FE44: BF030302
	s_cbranch_scc0 3338                                        // 00000031FE48: BFA10D0A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3474>
	v_lshrrev_b32_e32 v1, 4, v0                                // 00000031FE4C: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 00000031FE50: D6100002 02050900
	s_sub_i32 s3, s2, s3                                       // 00000031FE58: 81830302
	v_and_b32_e32 v66, 15, v0                                  // 00000031FE5C: 3684008F
	s_lshl_b32 s3, s3, 4                                       // 00000031FE60: 84038403
	v_and_b32_e32 v1, 14, v1                                   // 00000031FE64: 3602028E
	v_and_b32_e32 v3, 12, v0                                   // 00000031FE68: 3606008C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000031FE6C: BF870223
	v_lshlrev_b32_e32 v25, 4, v66                              // 00000031FE70: 30328484
	v_or_b32_e32 v71, 16, v66                                  // 00000031FE74: 388E8490
	v_or3_b32 v65, s3, v1, v2                                  // 00000031FE78: D6580041 040A0203
	s_mov_b32 s3, exec_lo                                      // 00000031FE80: BE83007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031FE84: BF870091
	v_mad_i64_i32 v[1:2], null, 0x154, v65, s[4:5]             // 00000031FE88: D6FF7C01 001282FF 00000154
	.long 0xd7006a09                                           // 00000031FE94: D7006A09
	v_cndmask_b32_e32 v1, v1, v25, vcc_lo                      // 00000031FE98: 02023301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031FE9C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000031FEA0: D5207C0A 01AA0480
	.long 0xd7006a03                                           // 00000031FEA8: D7006A03
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000031FEAC: 02020701
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 00000031FEB0: D5207C04 01AA0480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031FEB8: BF870094
	.long 0xd7006a05                                           // 00000031FEBC: D7006A05
	v_cndmask_b32_e32 v1, 0xd4000, v9, vcc_lo                  // 00000031FEC0: 020212FF 000D4000
	v_add_co_ci_u32_e64 v6, null, 0, v10, vcc_lo               // 00000031FEC8: D5207C06 01AA1480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031FED0: BF870094
	.long 0xd7006a07                                           // 00000031FED4: D7006A07
	v_cndmask_b32_e32 v1, 0xd4000, v3, vcc_lo                  // 00000031FED8: 020206FF 000D4000
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000031FEE0: D5207C08 01AA0880
	.long 0xd7006a15                                           // 00000031FEE8: D7006A15
	v_cndmask_b32_e32 v1, 0x1a9000, v9, vcc_lo                 // 00000031FEEC: 020212FF 001A9000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031FEF4: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v10, vcc_lo              // 00000031FEF8: D5207C16 01AA1480
	.long 0xd7006a0b                                           // 00000031FF00: D7006A0B
	v_cndmask_b32_e32 v1, 0x1a9000, v3, vcc_lo                 // 00000031FF04: 020206FF 001A9000
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 00000031FF0C: D5207C0C 01AA0880
	.long 0xd7006a17                                           // 00000031FF14: D7006A17
	v_cndmask_b32_e32 v1, 0x27d000, v9, vcc_lo                 // 00000031FF18: 020212FF 0027D000
	s_clause 0x1                                               // 00000031FF20: BF850001
	global_load_b128 v[53:56], v[9:10], off                    // 00000031FF24: DC5E0000 357C0009
	global_load_b32 v75, v[3:4], off offset:320                // 00000031FF2C: DC520140 4B7C0003
	v_add_co_ci_u32_e64 v24, null, 0, v10, vcc_lo              // 00000031FF34: D5207C18 01AA1480
	.long 0xd7006a03                                           // 00000031FF3C: D7006A03
	v_cndmask_b32_e32 v1, 0x27d000, v3, vcc_lo                 // 00000031FF40: 020206FF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031FF48: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000031FF4C: D5207C04 01AA0880
	s_clause 0x5                                               // 00000031FF54: BF850005
	global_load_b128 v[61:64], v[5:6], off offset:2048         // 00000031FF58: DC5E0800 3D7C0005
	global_load_b32 v76, v[7:8], off offset:2368               // 00000031FF60: DC520940 4C7C0007
	global_load_b128 v[57:60], v[21:22], off                   // 00000031FF68: DC5E0000 397C0015
	global_load_b32 v74, v[11:12], off offset:320              // 00000031FF70: DC520140 4A7C000B
	global_load_b128 v[17:20], v[23:24], off offset:2048       // 00000031FF78: DC5E0800 117C0017
	global_load_b32 v72, v[3:4], off offset:2368               // 00000031FF80: DC520940 487C0003
	v_cmpx_gt_u32_e32 20, v71                                  // 00000031FF88: 7D988E94
	s_cbranch_execz 35                                         // 00000031FF8C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x21c>
	.long 0xd7006a03                                           // 00000031FF90: D7006A03
	v_cndmask_b32_e32 v1, 0xd4000, v1, vcc_lo                  // 00000031FF94: 020202FF 000D4000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031FF9C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 00000031FFA0: D5207C04 01AA0480
	.long 0xd7006a1a                                           // 00000031FFA8: D7006A1A
	v_cndmask_b32_e32 v1, 0x1a9000, v1, vcc_lo                 // 00000031FFAC: 020202FF 001A9000
	s_clause 0x1                                               // 00000031FFB4: BF850001
	global_load_b128 v[13:16], v[9:10], off offset:256         // 00000031FFB8: DC5E0100 0D7C0009
	global_load_b32 v69, v[1:2], off offset:336                // 00000031FFC0: DC520150 457C0001
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 00000031FFC8: D5207C1B 01AA0480
	.long 0xd7006a01                                           // 00000031FFD0: D7006A01
	v_cndmask_b32_e32 v1, 0x27d000, v1, vcc_lo                 // 00000031FFD4: 020202FF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031FFDC: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000031FFE0: D5207C02 01AA0480
	s_clause 0x5                                               // 00000031FFE8: BF850005
	global_load_b128 v[9:12], v[5:6], off offset:2304          // 00000031FFEC: DC5E0900 097C0005
	global_load_b128 v[5:8], v[21:22], off offset:256          // 00000031FFF4: DC5E0100 057C0015
	global_load_b32 v70, v[3:4], off offset:2384               // 00000031FFFC: DC520950 467C0003
	global_load_b32 v68, v[26:27], off offset:336              // 000000320004: DC520150 447C001A
	global_load_b32 v67, v[1:2], off offset:2384               // 00000032000C: DC520950 437C0001
	global_load_b128 v[1:4], v[23:24], off offset:2304         // 000000320014: DC5E0900 017C0017
	s_or_b32 exec_lo, exec_lo, s3                              // 00000032001C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000320020: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000320024: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000320028: 7D940080
	s_xor_b32 s3, exec_lo, s3                                  // 00000032002C: 8D03037E
	s_cbranch_execz 20                                         // 000000320030: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x284>
	v_mov_b32_e32 v21, 0                                       // 000000320034: 7E2A0280
	global_load_b64 v[22:23], v21, s[16:17] glc                // 000000320038: DC564000 16100015
	s_waitcnt vmcnt(0)                                         // 000000320040: BF8903F7
	buffer_gl1_inv                                             // 000000320044: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032004C: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[18:19], v[22:23]                // 000000320054: 7CB62C12
	s_cbranch_vccnz 10                                         // 000000320058: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x284>
	s_sleep 1                                                  // 00000032005C: BF830001
	global_load_b64 v[22:23], v21, s[16:17] glc                // 000000320060: DC564000 16100015
	s_waitcnt vmcnt(0)                                         // 000000320068: BF8903F7
	buffer_gl1_inv                                             // 00000032006C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000320074: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[18:19], v[22:23]                // 00000032007C: 7CB82C12
	s_cbranch_vccnz 65526                                      // 000000320080: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x25c>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000320084: 8C7E037E
	v_lshlrev_b32_e32 v73, 1, v25                              // 000000320088: 30923281
	s_waitcnt vmcnt(0)                                         // 00000032008C: BF8903F7
	s_barrier                                                  // 000000320090: BFBD0000
	buffer_gl0_inv                                             // 000000320094: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000032009C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003200A4: E0AC0000 00000000
	s_clause 0x7                                               // 0000003200AC: BF850007
	global_load_b128 v[21:24], v73, s[6:7]                     // 0000003200B0: DC5E0000 15060049
	global_load_b128 v[25:28], v73, s[6:7] offset:640          // 0000003200B8: DC5E0280 19060049
	global_load_b128 v[29:32], v73, s[6:7] offset:1280         // 0000003200C0: DC5E0500 1D060049
	global_load_b128 v[45:48], v73, s[6:7] offset:1920         // 0000003200C8: DC5E0780 2D060049
	global_load_b128 v[33:36], v73, s[6:7] offset:16           // 0000003200D0: DC5E0010 21060049
	global_load_b128 v[37:40], v73, s[6:7] offset:656          // 0000003200D8: DC5E0290 25060049
	global_load_b128 v[41:44], v73, s[6:7] offset:1296         // 0000003200E0: DC5E0510 29060049
	global_load_b128 v[49:52], v73, s[6:7] offset:1936         // 0000003200E8: DC5E0790 31060049
	v_cvt_f32_ubyte0_e32 v77, v53                              // 0000003200F0: 7E9A2335
	v_cvt_f32_ubyte1_e32 v78, v53                              // 0000003200F4: 7E9C2535
	v_cvt_f32_ubyte0_e32 v81, v54                              // 0000003200F8: 7EA22336
	v_cvt_f32_ubyte1_e32 v82, v54                              // 0000003200FC: 7EA42536
	v_cvt_f32_ubyte0_e32 v84, v55                              // 000000320100: 7EA82337
	v_fma_mix_f32 v77, v77, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320104: CC20604D 152E974D
	v_fma_mix_f32 v78, v78, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032010C: CC20604E 152E974E
	v_fma_mix_f32 v81, v81, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320114: CC206051 152E9751
	v_cvt_f32_ubyte1_e32 v85, v55                              // 00000032011C: 7EAA2537
	v_cvt_f32_ubyte0_e32 v87, v56                              // 000000320120: 7EAE2338
	v_bfe_u32 v124, v77, 16, 1                                 // 000000320124: D610007C 0205214D
	v_fma_mix_f32 v82, v82, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032012C: CC206052 152E9752
	v_fma_mix_f32 v84, v84, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320134: CC206054 152E9754
	v_bfe_u32 v125, v78, 16, 1                                 // 00000032013C: D610007D 0205214E
	v_bfe_u32 v128, v81, 16, 1                                 // 000000320144: D6100080 02052151
	v_add3_u32 v77, v77, v124, 0x7fff                          // 00000032014C: D655004D 03FEF94D 00007FFF
	v_cvt_f32_ubyte2_e32 v79, v53                              // 000000320158: 7E9E2735
	v_cvt_f32_ubyte3_e32 v80, v53                              // 00000032015C: 7EA02935
	v_cvt_f32_ubyte2_e32 v83, v54                              // 000000320160: 7EA62736
	v_cvt_f32_ubyte3_e32 v54, v54                              // 000000320164: 7E6C2936
	v_cvt_f32_ubyte2_e32 v86, v55                              // 000000320168: 7EAC2737
	v_cvt_f32_ubyte3_e32 v55, v55                              // 00000032016C: 7E6E2937
	v_cvt_f32_ubyte1_e32 v88, v56                              // 000000320170: 7EB02538
	v_cvt_f32_ubyte2_e32 v89, v56                              // 000000320174: 7EB22738
	v_cvt_f32_ubyte3_e32 v56, v56                              // 000000320178: 7E702938
	v_cvt_f32_ubyte0_e32 v90, v61                              // 00000032017C: 7EB4233D
	.long 0x7f6a3880                                           // 000000320180: 7F6A3880
	v_fma_mix_f32 v85, v85, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320184: CC206055 152E9755
	v_fma_mix_f32 v87, v87, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032018C: CC206057 152E9757
	v_bfe_u32 v129, v82, 16, 1                                 // 000000320194: D6100081 02052152
	v_bfe_u32 v132, v84, 16, 1                                 // 00000032019C: D6100084 02052154
	v_add3_u32 v78, v78, v125, 0x7fff                          // 0000003201A4: D655004E 03FEFB4E 00007FFF
	v_add3_u32 v81, v81, v128, 0x7fff                          // 0000003201B0: D6550051 03FF0151 00007FFF
	.long 0x7e6a39cd                                           // 0000003201BC: 7E6A39CD
	v_cvt_f32_ubyte1_e32 v91, v61                              // 0000003201C0: 7EB6253D
	v_cvt_f32_ubyte2_e32 v92, v61                              // 0000003201C4: 7EB8273D
	v_cvt_f32_ubyte0_e32 v93, v62                              // 0000003201C8: 7EBA233E
	v_fma_mix_f32 v79, v79, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201CC: CC20604F 152E974F
	v_fma_mix_f32 v80, v80, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201D4: CC206050 152E9750
	v_fma_mix_f32 v83, v83, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201DC: CC206053 152E9753
	v_fma_mix_f32 v54, v54, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201E4: CC206036 152E9736
	v_fma_mix_f32 v86, v86, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201EC: CC206056 152E9756
	v_fma_mix_f32 v55, v55, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201F4: CC206037 152E9737
	v_fma_mix_f32 v88, v88, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003201FC: CC206058 152E9758
	v_fma_mix_f32 v89, v89, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320204: CC206059 152E9759
	v_fma_mix_f32 v56, v56, v75, v75 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032020C: CC206038 152E9738
	v_fma_mix_f32 v75, v90, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320214: CC20604B 1532995A
	v_bfe_u32 v133, v85, 16, 1                                 // 00000032021C: D6100085 02052155
	v_bfe_u32 v136, v87, 16, 1                                 // 000000320224: D6100088 02052157
	v_add3_u32 v82, v82, v129, 0x7fff                          // 00000032022C: D6550052 03FF0352 00007FFF
	v_add3_u32 v84, v84, v132, 0x7fff                          // 000000320238: D6550054 03FF0954 00007FFF
	v_and_or_b32 v78, 0xffff0000, v78, v53                     // 000000320244: D657004E 04D69CFF FFFF0000
	.long 0x7e6a39d1                                           // 000000320250: 7E6A39D1
	v_cvt_f32_ubyte1_e32 v94, v62                              // 000000320254: 7EBC253E
	v_cvt_f32_ubyte2_e32 v95, v62                              // 000000320258: 7EBE273E
	v_cvt_f32_ubyte0_e32 v96, v63                              // 00000032025C: 7EC0233F
	v_cvt_f32_ubyte0_e32 v109, v59                             // 000000320260: 7EDA233B
	v_cvt_f32_ubyte1_e32 v110, v59                             // 000000320264: 7EDC253B
	v_cvt_f32_ubyte2_e32 v111, v59                             // 000000320268: 7EDE273B
	v_cvt_f32_ubyte3_e32 v59, v59                              // 00000032026C: 7E76293B
	v_fma_mix_f32 v90, v91, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320270: CC20605A 1532995B
	v_fma_mix_f32 v91, v92, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320278: CC20605B 1532995C
	v_fma_mix_f32 v92, v93, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320280: CC20605C 1532995D
	v_bfe_u32 v126, v79, 16, 1                                 // 000000320288: D610007E 0205214F
	v_bfe_u32 v137, v88, 16, 1                                 // 000000320290: D6100089 02052158
	v_bfe_u32 v125, v75, 16, 1                                 // 000000320298: D610007D 0205214B
	v_add3_u32 v85, v85, v133, 0x7fff                          // 0000003202A0: D6550055 03FF0B55 00007FFF
	v_add3_u32 v87, v87, v136, 0x7fff                          // 0000003202AC: D6550057 03FF1157 00007FFF
	v_and_or_b32 v82, 0xffff0000, v82, v53                     // 0000003202B8: D6570052 04D6A4FF FFFF0000
	.long 0x7e6a39d4                                           // 0000003202C4: 7E6A39D4
	v_cvt_f32_ubyte1_e32 v97, v63                              // 0000003202C8: 7EC2253F
	v_cvt_f32_ubyte2_e32 v98, v63                              // 0000003202CC: 7EC4273F
	v_cvt_f32_ubyte0_e32 v99, v64                              // 0000003202D0: 7EC62340
	v_fma_mix_f32 v93, v94, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003202D4: CC20605D 1532995E
	v_fma_mix_f32 v94, v95, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003202DC: CC20605E 1532995F
	v_fma_mix_f32 v95, v96, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003202E4: CC20605F 15329960
	v_fma_mix_f32 v59, v59, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003202EC: CC20603B 152A953B
	v_bfe_u32 v130, v83, 16, 1                                 // 0000003202F4: D6100082 02052153
	v_add3_u32 v79, v79, v126, 0x7fff                          // 0000003202FC: D655004F 03FEFD4F 00007FFF
	v_bfe_u32 v126, v90, 16, 1                                 // 000000320308: D610007E 0205215A
	v_bfe_u32 v129, v92, 16, 1                                 // 000000320310: D6100081 0205215C
	v_add3_u32 v88, v88, v137, 0x7fff                          // 000000320318: D6550058 03FF1358 00007FFF
	v_add3_u32 v75, v75, v125, 0x7fff                          // 000000320324: D655004B 03FEFB4B 00007FFF
	v_and_or_b32 v85, 0xffff0000, v85, v53                     // 000000320330: D6570055 04D6AAFF FFFF0000
	.long 0x7e6a39d7                                           // 00000032033C: 7E6A39D7
	v_cvt_f32_ubyte1_e32 v100, v64                             // 000000320340: 7EC82540
	v_cvt_f32_ubyte2_e32 v101, v64                             // 000000320344: 7ECA2740
	v_cvt_f32_ubyte0_e32 v103, v57                             // 000000320348: 7ECE2339
	v_fma_mix_f32 v96, v97, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032034C: CC206060 15329961
	v_fma_mix_f32 v97, v98, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320354: CC206061 15329962
	v_fma_mix_f32 v98, v99, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032035C: CC206062 15329963
	v_bfe_u32 v134, v86, 16, 1                                 // 000000320364: D6100086 02052156
	v_add3_u32 v83, v83, v130, 0x7fff                          // 00000032036C: D6550053 03FF0553 00007FFF
	v_bfe_u32 v130, v93, 16, 1                                 // 000000320378: D6100082 0205215D
	v_bfe_u32 v133, v95, 16, 1                                 // 000000320380: D6100085 0205215F
	v_add3_u32 v90, v90, v126, 0x7fff                          // 000000320388: D655005A 03FEFD5A 00007FFF
	v_add3_u32 v92, v92, v129, 0x7fff                          // 000000320394: D655005C 03FF035C 00007FFF
	v_bfe_u32 v77, v59, 16, 1                                  // 0000003203A0: D610004D 0205213B
	v_and_or_b32 v88, 0xffff0000, v88, v53                     // 0000003203A8: D6570058 04D6B0FF FFFF0000
	.long 0x7e6a39cb                                           // 0000003203B4: 7E6A39CB
	v_cvt_f32_ubyte3_e32 v61, v61                              // 0000003203B8: 7E7A293D
	v_cvt_f32_ubyte3_e32 v62, v62                              // 0000003203BC: 7E7C293E
	v_cvt_f32_ubyte3_e32 v63, v63                              // 0000003203C0: 7E7E293F
	v_cvt_f32_ubyte3_e32 v102, v64                             // 0000003203C4: 7ECC2940
	v_cvt_f32_ubyte1_e32 v104, v57                             // 0000003203C8: 7ED02539
	v_cvt_f32_ubyte0_e32 v106, v58                             // 0000003203CC: 7ED4233A
	v_cvt_f32_ubyte2_e32 v108, v58                             // 0000003203D0: 7ED8273A
	v_cvt_f32_ubyte0_e32 v112, v60                             // 0000003203D4: 7EE0233C
	v_cvt_f32_ubyte2_e32 v114, v60                             // 0000003203D8: 7EE4273C
	v_fma_mix_f32 v99, v100, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003203DC: CC206063 15329964
	v_fma_mix_f32 v100, v101, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003203E4: CC206064 15329965
	v_fma_mix_f32 v101, v103, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003203EC: CC206065 152A9567
	v_bfe_u32 v127, v80, 16, 1                                 // 0000003203F4: D610007F 02052150
	v_bfe_u32 v138, v89, 16, 1                                 // 0000003203FC: D610008A 02052159
	v_add3_u32 v86, v86, v134, 0x7fff                          // 000000320404: D6550056 03FF0D56 00007FFF
	v_bfe_u32 v134, v96, 16, 1                                 // 000000320410: D6100086 02052160
	v_bfe_u32 v137, v98, 16, 1                                 // 000000320418: D6100089 02052162
	v_add3_u32 v93, v93, v130, 0x7fff                          // 000000320420: D655005D 03FF055D 00007FFF
	v_add3_u32 v95, v95, v133, 0x7fff                          // 00000032042C: D655005F 03FF0B5F 00007FFF
	v_add3_u32 v59, v59, v77, 0x7fff                           // 000000320438: D655003B 03FE9B3B 00007FFF
	v_and_or_b32 v77, 0xffff0000, v90, v53                     // 000000320444: D657004D 04D6B4FF FFFF0000
	.long 0x7e6a39dc                                           // 000000320450: 7E6A39DC
	v_cvt_f32_ubyte2_e32 v105, v57                             // 000000320454: 7ED22739
	v_cvt_f32_ubyte3_e32 v57, v57                              // 000000320458: 7E722939
	v_cvt_f32_ubyte1_e32 v107, v58                             // 00000032045C: 7ED6253A
	v_cvt_f32_ubyte3_e32 v58, v58                              // 000000320460: 7E74293A
	v_cvt_f32_ubyte1_e32 v113, v60                             // 000000320464: 7EE2253C
	v_cvt_f32_ubyte3_e32 v60, v60                              // 000000320468: 7E78293C
	v_fma_mix_f32 v61, v61, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032046C: CC20603D 1532993D
	v_fma_mix_f32 v62, v62, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320474: CC20603E 1532993E
	v_fma_mix_f32 v63, v63, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032047C: CC20603F 1532993F
	v_fma_mix_f32 v76, v102, v76, v76 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320484: CC20604C 15329966
	v_fma_mix_f32 v102, v104, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032048C: CC206066 152A9568
	v_fma_mix_f32 v104, v106, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320494: CC206068 152A956A
	v_fma_mix_f32 v106, v108, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032049C: CC20606A 152A956C
	v_fma_mix_f32 v108, v110, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003204A4: CC20606C 152A956E
	v_fma_mix_f32 v110, v112, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003204AC: CC20606E 152A9570
	v_fma_mix_f32 v112, v114, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003204B4: CC206070 152A9572
	v_bfe_u32 v131, v54, 16, 1                                 // 0000003204BC: D6100083 02052136
	v_add3_u32 v80, v80, v127, 0x7fff                          // 0000003204C4: D6550050 03FEFF50 00007FFF
	v_bfe_u32 v127, v91, 16, 1                                 // 0000003204D0: D610007F 0205215B
	v_add3_u32 v89, v89, v138, 0x7fff                          // 0000003204D8: D6550059 03FF1559 00007FFF
	v_bfe_u32 v138, v99, 16, 1                                 // 0000003204E4: D610008A 02052163
	v_bfe_u32 v126, v101, 16, 1                                // 0000003204EC: D610007E 02052165
	v_add3_u32 v96, v96, v134, 0x7fff                          // 0000003204F4: D6550060 03FF0D60 00007FFF
	v_add3_u32 v98, v98, v137, 0x7fff                          // 000000320500: D6550062 03FF1362 00007FFF
	v_and_or_b32 v93, 0xffff0000, v93, v53                     // 00000032050C: D657005D 04D6BAFF FFFF0000
	.long 0x7e6a39df                                           // 000000320518: 7E6A39DF
	v_fma_mix_f32 v103, v105, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032051C: CC206067 152A9569
	v_fma_mix_f32 v57, v57, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320524: CC206039 152A9539
	v_fma_mix_f32 v105, v107, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032052C: CC206069 152A956B
	v_fma_mix_f32 v58, v58, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320534: CC20603A 152A953A
	v_fma_mix_f32 v107, v109, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032053C: CC20606B 152A956D
	v_fma_mix_f32 v109, v111, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320544: CC20606D 152A956F
	v_fma_mix_f32 v111, v113, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032054C: CC20606F 152A9571
	v_fma_mix_f32 v60, v60, v74, v74 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320554: CC20603C 152A953C
	v_bfe_u32 v135, v55, 16, 1                                 // 00000032055C: D6100087 02052137
	v_bfe_u32 v124, v56, 16, 1                                 // 000000320564: D610007C 02052138
	v_bfe_u32 v128, v61, 16, 1                                 // 00000032056C: D6100080 0205213D
	v_add3_u32 v54, v54, v131, 0x7fff                          // 000000320574: D6550036 03FF0736 00007FFF
	v_bfe_u32 v131, v94, 16, 1                                 // 000000320580: D6100083 0205215E
	v_add3_u32 v91, v91, v127, 0x7fff                          // 000000320588: D655005B 03FEFF5B 00007FFF
	v_bfe_u32 v127, v102, 16, 1                                // 000000320594: D610007F 02052166
	v_bfe_u32 v130, v104, 16, 1                                // 00000032059C: D6100082 02052168
	v_add3_u32 v99, v99, v138, 0x7fff                          // 0000003205A4: D6550063 03FF1563 00007FFF
	v_bfe_u32 v81, v112, 16, 1                                 // 0000003205B0: D6100051 02052170
	v_add3_u32 v84, v101, v126, 0x7fff                         // 0000003205B8: D6550054 03FEFD65 00007FFF
	.long 0x7e9439cf                                           // 0000003205C4: 7E9439CF
	v_and_or_b32 v79, 0xffff0000, v96, v53                     // 0000003205C8: D657004F 04D6C0FF FFFF0000
	.long 0x7e6a39e2                                           // 0000003205D4: 7E6A39E2
	v_bfe_u32 v132, v62, 16, 1                                 // 0000003205D8: D6100084 0205213E
	v_add3_u32 v55, v55, v135, 0x7fff                          // 0000003205E0: D6550037 03FF0F37 00007FFF
	v_bfe_u32 v135, v97, 16, 1                                 // 0000003205EC: D6100087 02052161
	v_bfe_u32 v136, v63, 16, 1                                 // 0000003205F4: D6100088 0205213F
	v_add3_u32 v56, v56, v124, 0x7fff                          // 0000003205FC: D6550038 03FEF938 00007FFF
	v_bfe_u32 v124, v100, 16, 1                                // 000000320608: D610007C 02052164
	v_add3_u32 v61, v61, v128, 0x7fff                          // 000000320610: D655003D 03FF013D 00007FFF
	v_bfe_u32 v128, v103, 16, 1                                // 00000032061C: D6100080 02052167
	v_add3_u32 v94, v94, v131, 0x7fff                          // 000000320624: D655005E 03FF075E 00007FFF
	v_bfe_u32 v131, v105, 16, 1                                // 000000320630: D6100083 02052169
	v_bfe_u32 v134, v107, 16, 1                                // 000000320638: D6100086 0205216B
	v_add3_u32 v101, v102, v127, 0x7fff                        // 000000320640: D6550065 03FEFF66 00007FFF
	v_add3_u32 v87, v104, v130, 0x7fff                         // 00000032064C: D6550057 03FF0568 00007FFF
	v_add3_u32 v81, v112, v81, 0x7fff                          // 000000320658: D6550051 03FEA370 00007FFF
	.long 0x7ee239d3                                           // 000000320664: 7EE239D3
	v_and_or_b32 v83, 0xffff0000, v99, v53                     // 000000320668: D6570053 04D6C6FF FFFF0000
	.long 0x7e6a39d4                                           // 000000320674: 7E6A39D4
	.long 0x7f9439b5                                           // 000000320678: 7F9439B5
	v_bfe_u32 v125, v76, 16, 1                                 // 00000032067C: D610007D 0205214C
	v_add3_u32 v62, v62, v132, 0x7fff                          // 000000320684: D655003E 03FF093E 00007FFF
	v_bfe_u32 v132, v106, 16, 1                                // 000000320690: D6100084 0205216A
	v_add3_u32 v97, v97, v135, 0x7fff                          // 000000320698: D6550061 03FF0F61 00007FFF
	v_bfe_u32 v135, v108, 16, 1                                // 0000003206A4: D6100087 0205216C
	v_add3_u32 v63, v63, v136, 0x7fff                          // 0000003206AC: D655003F 03FF113F 00007FFF
	v_bfe_u32 v136, v109, 16, 1                                // 0000003206B8: D6100088 0205216D
	v_bfe_u32 v137, v110, 16, 1                                // 0000003206C0: D6100089 0205216E
	v_add3_u32 v100, v100, v124, 0x7fff                        // 0000003206C8: D6550064 03FEF964 00007FFF
	v_add3_u32 v102, v103, v128, 0x7fff                        // 0000003206D4: D6550066 03FF0167 00007FFF
	v_add3_u32 v103, v105, v131, 0x7fff                        // 0000003206E0: D6550067 03FF0769 00007FFF
	v_add3_u32 v75, v107, v134, 0x7fff                         // 0000003206EC: D655004B 03FF0D6B 00007FFF
	.long 0x7ef639d1                                           // 0000003206F8: 7EF639D1
	v_and_or_b32 v81, 0xffff0000, v101, v53                    // 0000003206FC: D6570051 04D6CAFF FFFF0000
	.long 0x7e6a39d7                                           // 000000320708: 7E6A39D7
	.long 0x7fee39b5                                           // 00000032070C: 7FEE39B5
	v_bfe_u32 v129, v57, 16, 1                                 // 000000320710: D6100081 02052139
	v_bfe_u32 v133, v58, 16, 1                                 // 000000320718: D6100085 0205213A
	v_bfe_u32 v138, v111, 16, 1                                // 000000320720: D610008A 0205216F
	v_bfe_u32 v124, v60, 16, 1                                 // 000000320728: D610007C 0205213C
	v_add3_u32 v76, v76, v125, 0x7fff                          // 000000320730: D655004C 03FEFB4C 00007FFF
	v_add3_u32 v104, v106, v132, 0x7fff                        // 00000032073C: D6550068 03FF096A 00007FFF
	v_add3_u32 v105, v108, v135, 0x7fff                        // 000000320748: D6550069 03FF0F6C 00007FFF
	v_add3_u32 v106, v109, v136, 0x7fff                        // 000000320754: D655006A 03FF116D 00007FFF
	v_add3_u32 v90, v110, v137, 0x7fff                         // 000000320760: D655005A 03FF136E 00007FFF
	.long 0x7eee39e4                                           // 00000032076C: 7EEE39E4
	v_and_or_b32 v74, 0xffff0000, v80, v74                     // 000000320770: D657004A 052AA0FF FFFF0000
	v_and_or_b32 v80, 0xffff0000, v103, v53                    // 00000032077C: D6570050 04D6CEFF FFFF0000
	.long 0x7e6a39cb                                           // 000000320788: 7E6A39CB
	.long 0x7fe839b5                                           // 00000032078C: 7FE839B5
	.long 0x7ff039b5                                           // 000000320790: 7FF039B5
	.long 0x7ff239b5                                           // 000000320794: 7FF239B5
	.long 0x7ff439b5                                           // 000000320798: 7FF439B5
	.long 0x7ff639b5                                           // 00000032079C: 7FF639B5
	v_add3_u32 v57, v57, v129, 0x7fff                          // 0000003207A0: D6550039 03FF0339 00007FFF
	v_add3_u32 v58, v58, v133, 0x7fff                          // 0000003207AC: D655003A 03FF0B3A 00007FFF
	v_add3_u32 v92, v111, v138, 0x7fff                         // 0000003207B8: D655005C 03FF156F 00007FFF
	v_add3_u32 v60, v60, v124, 0x7fff                          // 0000003207C4: D655003C 03FEF93C 00007FFF
	.long 0x7ee839db                                           // 0000003207D0: 7EE839DB
	.long 0x7ef039e6                                           // 0000003207D4: 7EF039E6
	.long 0x7ef239e8                                           // 0000003207D8: 7EF239E8
	.long 0x7ef439ea                                           // 0000003207DC: 7EF439EA
	v_and_or_b32 v75, 0xffff0000, v76, v119                    // 0000003207E0: D657004B 05DE98FF FFFF0000
	v_and_or_b32 v76, 0xffff0000, v105, v53                    // 0000003207EC: D657004C 04D6D2FF FFFF0000
	.long 0x7e6a39da                                           // 0000003207F8: 7E6A39DA
	.long 0x7ee439d6                                           // 0000003207FC: 7EE439D6
	.long 0x7ee639d9                                           // 000000320800: 7EE639D9
	.long 0x7eea39de                                           // 000000320804: 7EEA39DE
	v_and_or_b32 v61, 0xffff0000, v61, v116                    // 000000320808: D657003D 05D27AFF FFFF0000
	v_and_or_b32 v57, 0xffff0000, v57, v120                    // 000000320814: D6570039 05E272FF FFFF0000
	v_and_or_b32 v84, 0xffff0000, v58, v121                    // 000000320820: D6570054 05E674FF FFFF0000
	v_and_or_b32 v86, 0xffff0000, v59, v122                    // 00000032082C: D6570056 05EA76FF FFFF0000
	v_and_or_b32 v87, 0xffff0000, v60, v123                    // 000000320838: D6570057 05EE78FF FFFF0000
	v_and_or_b32 v89, 0xffff0000, v92, v53                     // 000000320844: D6570059 04D6B8FF FFFF0000
	.long 0x7fe239b5                                           // 000000320850: 7FE239B5
	.long 0x7fea39b5                                           // 000000320854: 7FEA39B5
	.long 0x7fe439b5                                           // 000000320858: 7FE439B5
	.long 0x7fec39b5                                           // 00000032085C: 7FEC39B5
	.long 0x7eec39e1                                           // 000000320860: 7EEC39E1
	v_and_or_b32 v54, 0xffff0000, v54, v113                    // 000000320864: D6570036 05C66CFF FFFF0000
	v_and_or_b32 v62, 0xffff0000, v62, v117                    // 000000320870: D657003E 05D67CFF FFFF0000
	v_and_or_b32 v55, 0xffff0000, v55, v114                    // 00000032087C: D6570037 05CA6EFF FFFF0000
	.long 0x7fe639b5                                           // 000000320888: 7FE639B5
	v_and_or_b32 v63, 0xffff0000, v63, v118                    // 00000032088C: D657003F 05DA7EFF FFFF0000
	v_cvt_f32_ubyte0_e32 v64, v17                              // 000000320898: 7E802311
	s_mov_b32 s3, exec_lo                                      // 00000032089C: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003208A0: BF870003
	v_and_or_b32 v56, 0xffff0000, v56, v115                    // 0000003208A4: D6570038 05CE70FF FFFF0000
	s_waitcnt vmcnt(7)                                         // 0000003208B0: BF891FF7
	v_dot2_f32_bf16 v58, v21, v78, 0                           // 0000003208B4: CC1A403A 1A029D15
	s_waitcnt vmcnt(6)                                         // 0000003208BC: BF891BF7
	v_dot2_f32_bf16 v59, v25, v78, 0                           // 0000003208C0: CC1A403B 1A029D19
	s_waitcnt vmcnt(5)                                         // 0000003208C8: BF8917F7
	v_dot2_f32_bf16 v60, v29, v78, 0                           // 0000003208CC: CC1A403C 1A029D1D
	s_waitcnt vmcnt(4)                                         // 0000003208D4: BF8913F7
	v_dot2_f32_bf16 v78, v45, v78, 0                           // 0000003208D8: CC1A404E 1A029D2D
	v_dot2_f32_bf16 v90, v21, v77, 0                           // 0000003208E0: CC1A405A 1A029B15
	v_dot2_f32_bf16 v91, v25, v77, 0                           // 0000003208E8: CC1A405B 1A029B19
	v_dot2_f32_bf16 v92, v29, v77, 0                           // 0000003208F0: CC1A405C 1A029B1D
	v_dot2_f32_bf16 v77, v45, v77, 0                           // 0000003208F8: CC1A404D 1A029B2D
	v_dot2_f32_bf16 v94, v21, v81, 0                           // 000000320900: CC1A405E 1A02A315
	v_dot2_f32_bf16 v95, v25, v81, 0                           // 000000320908: CC1A405F 1A02A319
	v_dot2_f32_bf16 v96, v29, v81, 0                           // 000000320910: CC1A4060 1A02A31D
	v_dot2_f32_bf16 v81, v45, v81, 0                           // 000000320918: CC1A4051 1A02A32D
	v_dot2_f32_bf16 v58, v22, v74, v58                         // 000000320920: CC1A403A 1CEA9516
	v_dot2_f32_bf16 v59, v26, v74, v59                         // 000000320928: CC1A403B 1CEE951A
	v_dot2_f32_bf16 v60, v30, v74, v60                         // 000000320930: CC1A403C 1CF2951E
	v_dot2_f32_bf16 v74, v46, v74, v78                         // 000000320938: CC1A404A 1D3A952E
	v_dot2_f32_bf16 v78, v22, v61, v90                         // 000000320940: CC1A404E 1D6A7B16
	v_dot2_f32_bf16 v90, v26, v61, v91                         // 000000320948: CC1A405A 1D6E7B1A
	v_dot2_f32_bf16 v91, v30, v61, v92                         // 000000320950: CC1A405B 1D727B1E
	v_dot2_f32_bf16 v61, v46, v61, v77                         // 000000320958: CC1A403D 1D367B2E
	v_dot2_f32_bf16 v77, v22, v57, v94                         // 000000320960: CC1A404D 1D7A7316
	v_dot2_f32_bf16 v92, v26, v57, v95                         // 000000320968: CC1A405C 1D7E731A
	v_dot2_f32_bf16 v94, v30, v57, v96                         // 000000320970: CC1A405E 1D82731E
	v_dot2_f32_bf16 v57, v46, v57, v81                         // 000000320978: CC1A4039 1D46732E
	v_dot2_f32_bf16 v58, v23, v82, v58                         // 000000320980: CC1A403A 1CEAA517
	v_dot2_f32_bf16 v59, v27, v82, v59                         // 000000320988: CC1A403B 1CEEA51B
	v_dot2_f32_bf16 v60, v31, v82, v60                         // 000000320990: CC1A403C 1CF2A51F
	v_dot2_f32_bf16 v74, v47, v82, v74                         // 000000320998: CC1A404A 1D2AA52F
	v_dot2_f32_bf16 v78, v23, v93, v78                         // 0000003209A0: CC1A404E 1D3ABB17
	v_dot2_f32_bf16 v81, v27, v93, v90                         // 0000003209A8: CC1A4051 1D6ABB1B
	v_dot2_f32_bf16 v82, v31, v93, v91                         // 0000003209B0: CC1A4052 1D6EBB1F
	v_dot2_f32_bf16 v61, v47, v93, v61                         // 0000003209B8: CC1A403D 1CF6BB2F
	v_dot2_f32_bf16 v77, v23, v80, v77                         // 0000003209C0: CC1A404D 1D36A117
	v_dot2_f32_bf16 v90, v27, v80, v92                         // 0000003209C8: CC1A405A 1D72A11B
	v_dot2_f32_bf16 v91, v31, v80, v94                         // 0000003209D0: CC1A405B 1D7AA11F
	v_dot2_f32_bf16 v80, v47, v80, v57                         // 0000003209D8: CC1A4050 1CE6A12F
	v_dot2_f32_bf16 v57, v24, v54, v58                         // 0000003209E0: CC1A4039 1CEA6D18
	v_dot2_f32_bf16 v58, v28, v54, v59                         // 0000003209E8: CC1A403A 1CEE6D1C
	v_dot2_f32_bf16 v59, v32, v54, v60                         // 0000003209F0: CC1A403B 1CF26D20
	v_dot2_f32_bf16 v54, v48, v54, v74                         // 0000003209F8: CC1A4036 1D2A6D30
	v_dot2_f32_bf16 v60, v24, v62, v78                         // 000000320A00: CC1A403C 1D3A7D18
	v_dot2_f32_bf16 v74, v28, v62, v81                         // 000000320A08: CC1A404A 1D467D1C
	v_dot2_f32_bf16 v78, v32, v62, v82                         // 000000320A10: CC1A404E 1D4A7D20
	v_dot2_f32_bf16 v61, v48, v62, v61                         // 000000320A18: CC1A403D 1CF67D30
	v_dot2_f32_bf16 v62, v24, v84, v77                         // 000000320A20: CC1A403E 1D36A918
	v_dot2_f32_bf16 v77, v28, v84, v90                         // 000000320A28: CC1A404D 1D6AA91C
	v_dot2_f32_bf16 v81, v32, v84, v91                         // 000000320A30: CC1A4051 1D6EA920
	s_waitcnt vmcnt(3)                                         // 000000320A38: BF890FF7
	v_dot2_f32_bf16 v57, v33, v85, v57                         // 000000320A3C: CC1A4039 1CE6AB21
	s_waitcnt vmcnt(2)                                         // 000000320A44: BF890BF7
	v_dot2_f32_bf16 v58, v37, v85, v58                         // 000000320A48: CC1A403A 1CEAAB25
	s_waitcnt vmcnt(1)                                         // 000000320A50: BF8907F7
	v_dot2_f32_bf16 v59, v41, v85, v59                         // 000000320A54: CC1A403B 1CEEAB29
	s_waitcnt vmcnt(0)                                         // 000000320A5C: BF8903F7
	v_dot2_f32_bf16 v54, v49, v85, v54                         // 000000320A60: CC1A4036 1CDAAB31
	v_dot2_f32_bf16 v60, v33, v79, v60                         // 000000320A68: CC1A403C 1CF29F21
	v_dot2_f32_bf16 v74, v37, v79, v74                         // 000000320A70: CC1A404A 1D2A9F25
	v_dot2_f32_bf16 v78, v41, v79, v78                         // 000000320A78: CC1A404E 1D3A9F29
	v_dot2_f32_bf16 v61, v49, v79, v61                         // 000000320A80: CC1A403D 1CF69F31
	v_dot2_f32_bf16 v62, v33, v76, v62                         // 000000320A88: CC1A403E 1CFA9921
	v_dot2_f32_bf16 v77, v37, v76, v77                         // 000000320A90: CC1A404D 1D369925
	v_dot2_f32_bf16 v79, v41, v76, v81                         // 000000320A98: CC1A404F 1D469929
	v_dot2_f32_bf16 v57, v34, v55, v57                         // 000000320AA0: CC1A4039 1CE66F22
	v_dot2_f32_bf16 v58, v38, v55, v58                         // 000000320AA8: CC1A403A 1CEA6F26
	v_dot2_f32_bf16 v59, v42, v55, v59                         // 000000320AB0: CC1A403B 1CEE6F2A
	v_dot2_f32_bf16 v54, v50, v55, v54                         // 000000320AB8: CC1A4036 1CDA6F32
	v_dot2_f32_bf16 v55, v34, v63, v60                         // 000000320AC0: CC1A4037 1CF27F22
	v_dot2_f32_bf16 v60, v38, v63, v74                         // 000000320AC8: CC1A403C 1D2A7F26
	v_dot2_f32_bf16 v74, v42, v63, v78                         // 000000320AD0: CC1A404A 1D3A7F2A
	v_dot2_f32_bf16 v61, v50, v63, v61                         // 000000320AD8: CC1A403D 1CF67F32
	v_dot2_f32_bf16 v62, v34, v86, v62                         // 000000320AE0: CC1A403E 1CFAAD22
	v_dot2_f32_bf16 v63, v38, v86, v77                         // 000000320AE8: CC1A403F 1D36AD26
	v_dot2_f32_bf16 v77, v42, v86, v79                         // 000000320AF0: CC1A404D 1D3EAD2A
	v_dot2_f32_bf16 v57, v35, v88, v57                         // 000000320AF8: CC1A4039 1CE6B123
	v_dot2_f32_bf16 v58, v39, v88, v58                         // 000000320B00: CC1A403A 1CEAB127
	v_dot2_f32_bf16 v59, v43, v88, v59                         // 000000320B08: CC1A403B 1CEEB12B
	v_dot2_f32_bf16 v54, v51, v88, v54                         // 000000320B10: CC1A4036 1CDAB133
	v_dot2_f32_bf16 v55, v35, v83, v55                         // 000000320B18: CC1A4037 1CDEA723
	v_dot2_f32_bf16 v60, v39, v83, v60                         // 000000320B20: CC1A403C 1CF2A727
	v_dot2_f32_bf16 v74, v43, v83, v74                         // 000000320B28: CC1A404A 1D2AA72B
	v_dot2_f32_bf16 v61, v51, v83, v61                         // 000000320B30: CC1A403D 1CF6A733
	v_dot2_f32_bf16 v62, v35, v89, v62                         // 000000320B38: CC1A403E 1CFAB323
	v_dot2_f32_bf16 v63, v39, v89, v63                         // 000000320B40: CC1A403F 1CFEB327
	v_dot2_f32_bf16 v77, v43, v89, v77                         // 000000320B48: CC1A404D 1D36B32B
	v_dot2_f32_bf16 v57, v36, v56, v57                         // 000000320B50: CC1A4039 1CE67124
	v_dot2_f32_bf16 v58, v40, v56, v58                         // 000000320B58: CC1A403A 1CEA7128
	v_dot2_f32_bf16 v59, v44, v56, v59                         // 000000320B60: CC1A403B 1CEE712C
	v_dot2_f32_bf16 v54, v52, v56, v54                         // 000000320B68: CC1A4036 1CDA7134
	v_dot2_f32_bf16 v55, v36, v75, v55                         // 000000320B70: CC1A4037 1CDE9724
	v_dot2_f32_bf16 v56, v40, v75, v60                         // 000000320B78: CC1A4038 1CF29728
	v_dot2_f32_bf16 v74, v44, v75, v74                         // 000000320B80: CC1A404A 1D2A972C
	v_dot2_f32_bf16 v75, v52, v75, v61                         // 000000320B88: CC1A404B 1CF69734
	v_dot2_f32_bf16 v78, v36, v87, v62                         // 000000320B90: CC1A404E 1CFAAF24
	v_dot2_f32_bf16 v79, v40, v87, v63                         // 000000320B98: CC1A404F 1CFEAF28
	v_dual_add_f32 v63, 0, v57 :: v_dual_add_f32 v60, 0, v54   // 000000320BA0: C9087280 3F3C6C80
	v_dual_add_f32 v62, 0, v58 :: v_dual_add_f32 v61, 0, v59   // 000000320BA8: C9087480 3E3C7680
	v_dual_add_f32 v58, 0, v56 :: v_dual_add_f32 v59, 0, v55   // 000000320BB0: C9087080 3A3A6E80
	v_dual_add_f32 v57, 0, v74 :: v_dual_add_f32 v56, 0, v75   // 000000320BB8: C9089480 39389680
	v_dual_add_f32 v55, 0, v78 :: v_dual_add_f32 v54, 0, v79   // 000000320BC0: C9089C80 37369E80
	v_dot2_f32_bf16 v74, v48, v84, v80                         // 000000320BC8: CC1A404A 1D42A930
	v_dot2_f32_bf16 v75, v44, v87, v77                         // 000000320BD0: CC1A404B 1D36AF2C
	v_cvt_f32_ubyte2_e32 v77, v17                              // 000000320BD8: 7E9A2711
	v_fma_mix_f32 v78, v64, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320BDC: CC20604E 15229140
	v_cvt_f32_ubyte1_e32 v79, v17                              // 000000320BE4: 7E9E2511
	v_dot2_f32_bf16 v74, v49, v76, v74                         // 000000320BE8: CC1A404A 1D2A9931
	v_add_f32_e32 v64, 0, v75                                  // 000000320BF0: 06809680
	v_fma_mix_f32 v75, v77, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320BF4: CC20604B 1522914D
	v_bfe_u32 v76, v78, 16, 1                                  // 000000320BFC: D610004C 0205214E
	v_fma_mix_f32 v77, v79, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320C04: CC20604D 1522914F
	v_cvt_f32_ubyte3_e32 v17, v17                              // 000000320C0C: 7E222911
	v_cvt_f32_ubyte2_e32 v82, v19                              // 000000320C10: 7EA42713
	v_bfe_u32 v79, v75, 16, 1                                  // 000000320C14: D610004F 0205214B
	v_add3_u32 v76, v78, v76, 0x7fff                           // 000000320C1C: D655004C 03FE994E 00007FFF
	v_bfe_u32 v78, v77, 16, 1                                  // 000000320C28: D610004E 0205214D
	v_fma_mix_f32 v17, v17, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320C30: CC206011 15229111
	v_dot2_f32_bf16 v74, v50, v86, v74                         // 000000320C38: CC1A404A 1D2AAD32
	v_add3_u32 v75, v75, v79, 0x7fff                           // 000000320C40: D655004B 03FE9F4B 00007FFF
	.long 0x7e6a39cc                                           // 000000320C4C: 7E6A39CC
	v_add3_u32 v76, v77, v78, 0x7fff                           // 000000320C50: D655004C 03FE9D4D 00007FFF
	v_cvt_f32_ubyte0_e32 v77, v18                              // 000000320C5C: 7E9A2312
	v_bfe_u32 v78, v17, 16, 1                                  // 000000320C60: D610004E 02052111
	.long 0x7e9639cb                                           // 000000320C68: 7E9639CB
	v_cvt_f32_ubyte2_e32 v79, v18                              // 000000320C6C: 7E9E2712
	.long 0x7f9639b5                                           // 000000320C70: 7F9639B5
	v_fma_mix_f32 v77, v77, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320C74: CC20604D 1522914D
	v_add3_u32 v17, v17, v78, 0x7fff                           // 000000320C7C: D6550011 03FE9D11 00007FFF
	v_cvt_f32_ubyte1_e32 v78, v18                              // 000000320C88: 7E9C2512
	v_fma_mix_f32 v79, v79, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320C8C: CC20604F 1522914F
	v_cvt_f32_ubyte3_e32 v18, v18                              // 000000320C94: 7E242912
	v_bfe_u32 v80, v77, 16, 1                                  // 000000320C98: D6100050 0205214D
	v_and_or_b32 v17, 0xffff0000, v17, v75                     // 000000320CA0: D6570011 052E22FF FFFF0000
	v_fma_mix_f32 v75, v78, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320CAC: CC20604B 1522914E
	v_and_or_b32 v76, 0xffff0000, v76, v53                     // 000000320CB4: D657004C 04D698FF FFFF0000
	v_bfe_u32 v78, v79, 16, 1                                  // 000000320CC0: D610004E 0205214F
	v_add3_u32 v77, v77, v80, 0x7fff                           // 000000320CC8: D655004D 03FEA14D 00007FFF
	v_cvt_f32_ubyte0_e32 v80, v19                              // 000000320CD4: 7EA02313
	v_bfe_u32 v81, v75, 16, 1                                  // 000000320CD8: D6100051 0205214B
	v_fma_mix_f32 v18, v18, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320CE0: CC206012 15229112
	v_add3_u32 v78, v79, v78, 0x7fff                           // 000000320CE8: D655004E 03FE9D4F 00007FFF
	.long 0x7e6a39cd                                           // 000000320CF4: 7E6A39CD
	v_fma_mix_f32 v77, v80, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320CF8: CC20604D 15229150
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000320D00: D655004B 03FEA34B 00007FFF
	v_bfe_u32 v79, v18, 16, 1                                  // 000000320D0C: D610004F 02052112
	v_cvt_f32_ubyte1_e32 v80, v19                              // 000000320D14: 7EA02513
	.long 0x7e9c39ce                                           // 000000320D18: 7E9C39CE
	v_bfe_u32 v81, v77, 16, 1                                  // 000000320D1C: D6100051 0205214D
	.long 0x7f9c39b5                                           // 000000320D24: 7F9C39B5
	v_add3_u32 v18, v18, v79, 0x7fff                           // 000000320D28: D6550012 03FE9F12 00007FFF
	v_fma_mix_f32 v79, v80, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320D34: CC20604F 15229150
	v_fma_mix_f32 v80, v82, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320D3C: CC206050 15229152
	v_add3_u32 v77, v77, v81, 0x7fff                           // 000000320D44: D655004D 03FEA34D 00007FFF
	v_and_or_b32 v75, 0xffff0000, v75, v53                     // 000000320D50: D657004B 04D696FF FFFF0000
	v_and_or_b32 v18, 0xffff0000, v18, v78                     // 000000320D5C: D6570012 053A24FF FFFF0000
	v_bfe_u32 v78, v79, 16, 1                                  // 000000320D68: D610004E 0205214F
	v_cvt_f32_ubyte3_e32 v19, v19                              // 000000320D70: 7E262913
	.long 0x7e6a39cd                                           // 000000320D74: 7E6A39CD
	v_bfe_u32 v77, v80, 16, 1                                  // 000000320D78: D610004D 02052150
	v_cvt_f32_ubyte0_e32 v81, v20                              // 000000320D80: 7EA22314
	v_dot2_f32_bf16 v21, v21, v76, 0                           // 000000320D84: CC1A4015 1A029915
	v_dot2_f32_bf16 v25, v25, v76, 0                           // 000000320D8C: CC1A4019 1A029919
	v_dot2_f32_bf16 v29, v29, v76, 0                           // 000000320D94: CC1A401D 1A02991D
	v_dot2_f32_bf16 v45, v45, v76, 0                           // 000000320D9C: CC1A402D 1A02992D
	v_add3_u32 v78, v79, v78, 0x7fff                           // 000000320DA4: D655004E 03FE9D4F 00007FFF
	v_cvt_f32_ubyte2_e32 v79, v20                              // 000000320DB0: 7E9E2714
	v_add3_u32 v77, v80, v77, 0x7fff                           // 000000320DB4: D655004D 03FE9B50 00007FFF
	v_fma_mix_f32 v19, v19, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320DC0: CC206013 15229113
	v_fma_mix_f32 v80, v81, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320DC8: CC206050 15229151
	v_cvt_f32_ubyte1_e32 v81, v20                              // 000000320DD0: 7EA22514
	v_cvt_f32_ubyte3_e32 v20, v20                              // 000000320DD4: 7E282914
	v_dot2_f32_bf16 v21, v22, v17, v21                         // 000000320DD8: CC1A4015 1C562316
	v_dot2_f32_bf16 v22, v26, v17, v25                         // 000000320DE0: CC1A4016 1C66231A
	v_dot2_f32_bf16 v25, v30, v17, v29                         // 000000320DE8: CC1A4019 1C76231E
	v_dot2_f32_bf16 v17, v46, v17, v45                         // 000000320DF0: CC1A4011 1CB6232E
	v_fma_mix_f32 v79, v79, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320DF8: CC20604F 1522914F
	v_bfe_u32 v82, v19, 16, 1                                  // 000000320E00: D6100052 02052113
	v_bfe_u32 v83, v80, 16, 1                                  // 000000320E08: D6100053 02052150
	v_fma_mix_f32 v81, v81, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320E10: CC206051 15229151
	v_fma_mix_f32 v20, v20, v72, v72 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000320E18: CC206014 15229114
	v_dot2_f32_bf16 v21, v23, v75, v21                         // 000000320E20: CC1A4015 1C569717
	v_dot2_f32_bf16 v22, v27, v75, v22                         // 000000320E28: CC1A4016 1C5A971B
	v_dot2_f32_bf16 v23, v31, v75, v25                         // 000000320E30: CC1A4017 1C66971F
	v_dot2_f32_bf16 v17, v47, v75, v17                         // 000000320E38: CC1A4011 1C46972F
	.long 0x7e9a39cd                                           // 000000320E40: 7E9A39CD
	v_bfe_u32 v84, v79, 16, 1                                  // 000000320E44: D6100054 0205214F
	.long 0x7f9a39b5                                           // 000000320E4C: 7F9A39B5
	v_add3_u32 v19, v19, v82, 0x7fff                           // 000000320E50: D6550013 03FEA513 00007FFF
	v_add3_u32 v80, v80, v83, 0x7fff                           // 000000320E5C: D6550050 03FEA750 00007FFF
	v_bfe_u32 v82, v81, 16, 1                                  // 000000320E68: D6100052 02052151
	v_and_or_b32 v78, 0xffff0000, v78, v53                     // 000000320E70: D657004E 04D69CFF FFFF0000
	v_bfe_u32 v25, v20, 16, 1                                  // 000000320E7C: D6100019 02052114
	v_dot2_f32_bf16 v21, v24, v18, v21                         // 000000320E84: CC1A4015 1C562518
	v_dot2_f32_bf16 v22, v28, v18, v22                         // 000000320E8C: CC1A4016 1C5A251C
	v_dot2_f32_bf16 v23, v32, v18, v23                         // 000000320E94: CC1A4017 1C5E2520
	v_dot2_f32_bf16 v17, v48, v18, v17                         // 000000320E9C: CC1A4011 1C462530
	v_add3_u32 v79, v79, v84, 0x7fff                           // 000000320EA4: D655004F 03FEA94F 00007FFF
	v_and_or_b32 v19, 0xffff0000, v19, v77                     // 000000320EB0: D6570013 053626FF FFFF0000
	.long 0x7e6a39d0                                           // 000000320EBC: 7E6A39D0
	v_add3_u32 v77, v81, v82, 0x7fff                           // 000000320EC0: D655004D 03FEA551 00007FFF
	v_add3_u32 v18, v20, v25, 0x7fff                           // 000000320ECC: D6550012 03FE3314 00007FFF
	v_dot2_f32_bf16 v20, v33, v78, v21                         // 000000320ED8: CC1A4014 1C569D21
	v_dot2_f32_bf16 v21, v37, v78, v22                         // 000000320EE0: CC1A4015 1C5A9D25
	v_dot2_f32_bf16 v22, v41, v78, v23                         // 000000320EE8: CC1A4016 1C5E9D29
	v_dot2_f32_bf16 v17, v49, v78, v17                         // 000000320EF0: CC1A4011 1C469D31
	.long 0x7e9e39cf                                           // 000000320EF8: 7E9E39CF
	.long 0x7f9e39b5                                           // 000000320EFC: 7F9E39B5
	v_and_or_b32 v23, 0xffff0000, v77, v53                     // 000000320F00: D6570017 04D69AFF FFFF0000
	v_dot2_f32_bf16 v20, v34, v19, v20                         // 000000320F0C: CC1A4014 1C522722
	v_dot2_f32_bf16 v21, v38, v19, v21                         // 000000320F14: CC1A4015 1C562726
	v_dot2_f32_bf16 v22, v42, v19, v22                         // 000000320F1C: CC1A4016 1C5A272A
	v_dot2_f32_bf16 v17, v50, v19, v17                         // 000000320F24: CC1A4011 1C462732
	v_dot2_f32_bf16 v74, v51, v89, v74                         // 000000320F2C: CC1A404A 1D2AB333
	v_and_or_b32 v18, 0xffff0000, v18, v79                     // 000000320F34: D6570012 053E24FF FFFF0000
	v_dot2_f32_bf16 v19, v35, v23, v20                         // 000000320F40: CC1A4013 1C522F23
	v_dot2_f32_bf16 v20, v39, v23, v21                         // 000000320F48: CC1A4014 1C562F27
	v_dot2_f32_bf16 v21, v43, v23, v22                         // 000000320F50: CC1A4015 1C5A2F2B
	v_dot2_f32_bf16 v17, v51, v23, v17                         // 000000320F58: CC1A4011 1C462F33
	v_dot2_f32_bf16 v22, v52, v87, v74                         // 000000320F60: CC1A4016 1D2AAF34
	v_dot2_f32_bf16 v19, v36, v18, v19                         // 000000320F68: CC1A4013 1C4E2524
	v_dot2_f32_bf16 v20, v40, v18, v20                         // 000000320F70: CC1A4014 1C522528
	v_dot2_f32_bf16 v21, v44, v18, v21                         // 000000320F78: CC1A4015 1C56252C
	v_dot2_f32_bf16 v17, v52, v18, v17                         // 000000320F80: CC1A4011 1C462534
	v_add_f32_e32 v72, 0, v22                                  // 000000320F88: 06902C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000320F8C: BF870214
	v_dual_add_f32 v52, 0, v19 :: v_dual_add_f32 v51, 0, v20   // 000000320F90: C9082680 34322880
	v_add_f32_e32 v50, 0, v21                                  // 000000320F98: 06642A80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000320F9C: BF870004
	v_add_f32_e32 v49, 0, v17                                  // 000000320FA0: 06622280
	v_cmpx_gt_u32_e32 20, v71                                  // 000000320FA4: 7D988E94
	s_cbranch_execz 963                                        // 000000320FA8: BFA503C3 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x20b8>
	.long 0xd7000425                                           // 000000320FAC: D7000425
	v_cndmask_b32_e32 v1, s6, v73, vcc_lo                      // 000000320FB0: 02029206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000320FB4: BF870001
	v_add_co_ci_u32_e64 v38, null, s7, 0, s4                   // 000000320FB8: D5207C26 00110007
	v_cvt_f32_ubyte0_e32 v73, v13                              // 000000320FC0: 7E92230D
	v_cvt_f32_ubyte1_e32 v74, v13                              // 000000320FC4: 7E94250D
	v_cvt_f32_ubyte2_e32 v75, v13                              // 000000320FC8: 7E96270D
	s_clause 0x7                                               // 000000320FCC: BF850007
	global_load_b128 v[17:20], v[37:38], off offset:512        // 000000320FD0: DC5E0200 117C0025
	global_load_b128 v[21:24], v[37:38], off offset:1152       // 000000320FD8: DC5E0480 157C0025
	global_load_b128 v[41:44], v[37:38], off offset:1792       // 000000320FE0: DC5E0700 297C0025
	global_load_b128 v[45:48], v[37:38], off offset:2432       // 000000320FE8: DC5E0980 2D7C0025
	global_load_b128 v[25:28], v[37:38], off offset:528        // 000000320FF0: DC5E0210 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:1168       // 000000320FF8: DC5E0490 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:1808       // 000000321000: DC5E0710 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:2448       // 000000321008: DC5E0990 257C0025
	v_cvt_f32_ubyte3_e32 v76, v13                              // 000000321010: 7E98290D
	v_cvt_f32_ubyte0_e32 v77, v14                              // 000000321014: 7E9A230E
	v_cvt_f32_ubyte1_e32 v78, v14                              // 000000321018: 7E9C250E
	v_cvt_f32_ubyte2_e32 v79, v14                              // 00000032101C: 7E9E270E
	v_cvt_f32_ubyte3_e32 v80, v14                              // 000000321020: 7EA0290E
	v_cvt_f32_ubyte0_e32 v81, v15                              // 000000321024: 7EA2230F
	v_cvt_f32_ubyte1_e32 v82, v15                              // 000000321028: 7EA4250F
	v_cvt_f32_ubyte2_e32 v83, v15                              // 00000032102C: 7EA6270F
	v_cvt_f32_ubyte3_e32 v84, v15                              // 000000321030: 7EA8290F
	v_cvt_f32_ubyte0_e32 v85, v16                              // 000000321034: 7EAA2310
	v_cvt_f32_ubyte1_e32 v86, v16                              // 000000321038: 7EAC2510
	v_cvt_f32_ubyte2_e32 v87, v16                              // 00000032103C: 7EAE2710
	v_cvt_f32_ubyte3_e32 v88, v16                              // 000000321040: 7EB02910
	v_cvt_f32_ubyte0_e32 v89, v9                               // 000000321044: 7EB22309
	v_cvt_f32_ubyte1_e32 v90, v9                               // 000000321048: 7EB42509
	v_cvt_f32_ubyte2_e32 v91, v9                               // 00000032104C: 7EB62709
	v_cvt_f32_ubyte3_e32 v92, v9                               // 000000321050: 7EB82909
	v_cvt_f32_ubyte0_e32 v93, v10                              // 000000321054: 7EBA230A
	v_cvt_f32_ubyte1_e32 v94, v10                              // 000000321058: 7EBC250A
	v_cvt_f32_ubyte2_e32 v95, v10                              // 00000032105C: 7EBE270A
	v_cvt_f32_ubyte3_e32 v96, v10                              // 000000321060: 7EC0290A
	v_cvt_f32_ubyte0_e32 v97, v11                              // 000000321064: 7EC2230B
	v_cvt_f32_ubyte1_e32 v98, v11                              // 000000321068: 7EC4250B
	v_cvt_f32_ubyte2_e32 v99, v11                              // 00000032106C: 7EC6270B
	v_cvt_f32_ubyte3_e32 v11, v11                              // 000000321070: 7E16290B
	v_cvt_f32_ubyte0_e32 v100, v12                             // 000000321074: 7EC8230C
	v_cvt_f32_ubyte1_e32 v101, v12                             // 000000321078: 7ECA250C
	v_cvt_f32_ubyte2_e32 v102, v12                             // 00000032107C: 7ECC270C
	v_cvt_f32_ubyte3_e32 v12, v12                              // 000000321080: 7E18290C
	v_cvt_f32_ubyte0_e32 v104, v5                              // 000000321084: 7ED02305
	v_cvt_f32_ubyte1_e32 v105, v5                              // 000000321088: 7ED22505
	v_cvt_f32_ubyte2_e32 v106, v5                              // 00000032108C: 7ED42705
	v_cvt_f32_ubyte3_e32 v5, v5                                // 000000321090: 7E0A2905
	v_cvt_f32_ubyte0_e32 v107, v6                              // 000000321094: 7ED62306
	v_cvt_f32_ubyte1_e32 v108, v6                              // 000000321098: 7ED82506
	v_cvt_f32_ubyte2_e32 v109, v6                              // 00000032109C: 7EDA2706
	v_cvt_f32_ubyte3_e32 v6, v6                                // 0000003210A0: 7E0C2906
	v_cvt_f32_ubyte0_e32 v110, v7                              // 0000003210A4: 7EDC2307
	v_cvt_f32_ubyte1_e32 v111, v7                              // 0000003210A8: 7EDE2507
	v_cvt_f32_ubyte2_e32 v112, v7                              // 0000003210AC: 7EE02707
	v_cvt_f32_ubyte3_e32 v7, v7                                // 0000003210B0: 7E0E2907
	v_cvt_f32_ubyte0_e32 v113, v8                              // 0000003210B4: 7EE22308
	v_cvt_f32_ubyte1_e32 v114, v8                              // 0000003210B8: 7EE42508
	v_cvt_f32_ubyte2_e32 v115, v8                              // 0000003210BC: 7EE62708
	v_cvt_f32_ubyte3_e32 v8, v8                                // 0000003210C0: 7E102908
	v_fma_mix_f32 v73, v73, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210C4: CC206049 15168B49
	v_fma_mix_f32 v74, v74, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210CC: CC20604A 15168B4A
	v_fma_mix_f32 v75, v75, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210D4: CC20604B 15168B4B
	v_fma_mix_f32 v76, v76, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210DC: CC20604C 15168B4C
	v_fma_mix_f32 v77, v77, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210E4: CC20604D 15168B4D
	v_fma_mix_f32 v78, v78, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210EC: CC20604E 15168B4E
	v_fma_mix_f32 v79, v79, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210F4: CC20604F 15168B4F
	v_fma_mix_f32 v80, v80, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003210FC: CC206050 15168B50
	v_fma_mix_f32 v81, v81, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321104: CC206051 15168B51
	v_fma_mix_f32 v82, v82, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032110C: CC206052 15168B52
	v_fma_mix_f32 v83, v83, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321114: CC206053 15168B53
	v_fma_mix_f32 v84, v84, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032111C: CC206054 15168B54
	v_fma_mix_f32 v85, v85, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321124: CC206055 15168B55
	v_fma_mix_f32 v86, v86, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032112C: CC206056 15168B56
	v_fma_mix_f32 v87, v87, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321134: CC206057 15168B57
	v_fma_mix_f32 v69, v88, v69, v69 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032113C: CC206045 15168B58
	v_fma_mix_f32 v88, v89, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321144: CC206058 151A8D59
	v_fma_mix_f32 v89, v90, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032114C: CC206059 151A8D5A
	v_fma_mix_f32 v90, v91, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321154: CC20605A 151A8D5B
	v_fma_mix_f32 v91, v92, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032115C: CC20605B 151A8D5C
	v_fma_mix_f32 v92, v93, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321164: CC20605C 151A8D5D
	v_fma_mix_f32 v93, v94, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032116C: CC20605D 151A8D5E
	v_fma_mix_f32 v94, v95, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321174: CC20605E 151A8D5F
	v_fma_mix_f32 v95, v96, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032117C: CC20605F 151A8D60
	v_fma_mix_f32 v96, v97, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321184: CC206060 151A8D61
	v_fma_mix_f32 v97, v98, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032118C: CC206061 151A8D62
	v_fma_mix_f32 v98, v99, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321194: CC206062 151A8D63
	v_fma_mix_f32 v11, v11, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032119C: CC20600B 151A8D0B
	v_fma_mix_f32 v99, v100, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211A4: CC206063 151A8D64
	v_fma_mix_f32 v100, v101, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211AC: CC206064 151A8D65
	v_fma_mix_f32 v101, v102, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211B4: CC206065 151A8D66
	v_fma_mix_f32 v12, v12, v70, v70 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211BC: CC20600C 151A8D0C
	v_fma_mix_f32 v70, v104, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211C4: CC206046 15128968
	v_fma_mix_f32 v102, v105, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211CC: CC206066 15128969
	v_fma_mix_f32 v104, v106, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211D4: CC206068 1512896A
	v_fma_mix_f32 v5, v5, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211DC: CC206005 15128905
	v_fma_mix_f32 v105, v107, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211E4: CC206069 1512896B
	v_fma_mix_f32 v106, v108, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211EC: CC20606A 1512896C
	v_fma_mix_f32 v107, v109, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211F4: CC20606B 1512896D
	v_fma_mix_f32 v6, v6, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003211FC: CC206006 15128906
	v_fma_mix_f32 v108, v110, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321204: CC20606C 1512896E
	v_fma_mix_f32 v109, v111, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032120C: CC20606D 1512896F
	v_fma_mix_f32 v110, v112, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321214: CC20606E 15128970
	v_fma_mix_f32 v7, v7, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032121C: CC206007 15128907
	v_fma_mix_f32 v111, v113, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321224: CC20606F 15128971
	v_fma_mix_f32 v112, v114, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032122C: CC206070 15128972
	v_fma_mix_f32 v113, v115, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321234: CC206071 15128973
	v_fma_mix_f32 v8, v8, v68, v68 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000032123C: CC206008 15128908
	v_bfe_u32 v68, v73, 16, 1                                  // 000000321244: D6100044 02052149
	v_bfe_u32 v114, v74, 16, 1                                 // 00000032124C: D6100072 0205214A
	v_bfe_u32 v122, v77, 16, 1                                 // 000000321254: D610007A 0205214D
	v_bfe_u32 v123, v78, 16, 1                                 // 00000032125C: D610007B 0205214E
	v_bfe_u32 v126, v81, 16, 1                                 // 000000321264: D610007E 02052151
	v_add3_u32 v68, v73, v68, 0x7fff                           // 00000032126C: D6550044 03FE8949 00007FFF
	v_add3_u32 v74, v74, v114, 0x7fff                          // 000000321278: D655004A 03FEE54A 00007FFF
	v_add3_u32 v77, v77, v122, 0x7fff                          // 000000321284: D655004D 03FEF54D 00007FFF
	v_bfe_u32 v127, v82, 16, 1                                 // 000000321290: D610007F 02052152
	v_bfe_u32 v130, v85, 16, 1                                 // 000000321298: D6100082 02052155
	.long 0x7e6a39c4                                           // 0000003212A0: 7E6A39C4
	v_add3_u32 v78, v78, v123, 0x7fff                          // 0000003212A4: D655004E 03FEF74E 00007FFF
	v_add3_u32 v81, v81, v126, 0x7fff                          // 0000003212B0: D6550051 03FEFD51 00007FFF
	v_bfe_u32 v131, v86, 16, 1                                 // 0000003212BC: D6100083 02052156
	v_bfe_u32 v134, v88, 16, 1                                 // 0000003212C4: D6100086 02052158
	v_and_or_b32 v74, 0xffff0000, v74, v53                     // 0000003212CC: D657004A 04D694FF FFFF0000
	.long 0x7e6a39cd                                           // 0000003212D8: 7E6A39CD
	v_add3_u32 v82, v82, v127, 0x7fff                          // 0000003212DC: D6550052 03FEFF52 00007FFF
	v_add3_u32 v85, v85, v130, 0x7fff                          // 0000003212E8: D6550055 03FF0555 00007FFF
	v_bfe_u32 v135, v89, 16, 1                                 // 0000003212F4: D6100087 02052159
	v_bfe_u32 v138, v92, 16, 1                                 // 0000003212FC: D610008A 0205215C
	v_and_or_b32 v78, 0xffff0000, v78, v53                     // 000000321304: D657004E 04D69CFF FFFF0000
	.long 0x7e6a39d1                                           // 000000321310: 7E6A39D1
	v_add3_u32 v86, v86, v131, 0x7fff                          // 000000321314: D6550056 03FF0756 00007FFF
	v_add3_u32 v88, v88, v134, 0x7fff                          // 000000321320: D6550058 03FF0D58 00007FFF
	v_bfe_u32 v121, v76, 16, 1                                 // 00000032132C: D6100079 0205214C
	v_bfe_u32 v139, v93, 16, 1                                 // 000000321334: D610008B 0205215D
	v_and_or_b32 v82, 0xffff0000, v82, v53                     // 00000032133C: D6570052 04D6A4FF FFFF0000
	.long 0x7e6a39d5                                           // 000000321348: 7E6A39D5
	v_bfe_u32 v142, v96, 16, 1                                 // 00000032134C: D610008E 02052160
	v_add3_u32 v89, v89, v135, 0x7fff                          // 000000321354: D6550059 03FF0F59 00007FFF
	v_add3_u32 v92, v92, v138, 0x7fff                          // 000000321360: D655005C 03FF155C 00007FFF
	v_bfe_u32 v125, v80, 16, 1                                 // 00000032136C: D610007D 02052150
	v_and_or_b32 v86, 0xffff0000, v86, v53                     // 000000321374: D6570056 04D6ACFF FFFF0000
	.long 0x7e6a39d8                                           // 000000321380: 7E6A39D8
	v_bfe_u32 v73, v97, 16, 1                                  // 000000321384: D6100049 02052161
	v_add3_u32 v76, v76, v121, 0x7fff                          // 00000032138C: D655004C 03FEF34C 00007FFF
	v_bfe_u32 v121, v99, 16, 1                                 // 000000321398: D6100079 02052163
	v_add3_u32 v93, v93, v139, 0x7fff                          // 0000003213A0: D655005D 03FF175D 00007FFF
	v_add3_u32 v68, v96, v142, 0x7fff                          // 0000003213AC: D6550044 03FF1D60 00007FFF
	v_and_or_b32 v89, 0xffff0000, v89, v53                     // 0000003213B8: D6570059 04D6B2FF FFFF0000
	.long 0x7e6a39dc                                           // 0000003213C4: 7E6A39DC
	v_bfe_u32 v122, v100, 16, 1                                // 0000003213C8: D610007A 02052164
	v_add3_u32 v80, v80, v125, 0x7fff                          // 0000003213D0: D6550050 03FEFB50 00007FFF
	v_bfe_u32 v125, v70, 16, 1                                 // 0000003213DC: D610007D 02052146
	v_add3_u32 v73, v97, v73, 0x7fff                           // 0000003213E4: D6550049 03FE9361 00007FFF
	v_add3_u32 v77, v99, v121, 0x7fff                          // 0000003213F0: D655004D 03FEF363 00007FFF
	v_and_or_b32 v93, 0xffff0000, v93, v53                     // 0000003213FC: D657005D 04D6BAFF FFFF0000
	.long 0x7e6a39c4                                           // 000000321408: 7E6A39C4
	v_bfe_u32 v115, v75, 16, 1                                 // 00000032140C: D6100073 0205214B
	v_bfe_u32 v124, v79, 16, 1                                 // 000000321414: D610007C 0205214F
	v_bfe_u32 v128, v83, 16, 1                                 // 00000032141C: D6100080 02052153
	v_bfe_u32 v129, v84, 16, 1                                 // 000000321424: D6100081 02052154
	v_bfe_u32 v136, v90, 16, 1                                 // 00000032142C: D6100088 0205215A
	v_bfe_u32 v126, v102, 16, 1                                // 000000321434: D610007E 02052166
	v_bfe_u32 v127, v104, 16, 1                                // 00000032143C: D610007F 02052168
	v_add3_u32 v97, v100, v122, 0x7fff                         // 000000321444: D6550061 03FEF564 00007FFF
	v_add3_u32 v70, v70, v125, 0x7fff                          // 000000321450: D6550046 03FEFB46 00007FFF
	v_and_or_b32 v68, 0xffff0000, v73, v53                     // 00000032145C: D6570044 04D692FF FFFF0000
	.long 0x7e6a39cd                                           // 000000321468: 7E6A39CD
	v_bfe_u32 v132, v87, 16, 1                                 // 00000032146C: D6100084 02052157
	v_bfe_u32 v133, v69, 16, 1                                 // 000000321474: D6100085 02052145
	v_bfe_u32 v137, v91, 16, 1                                 // 00000032147C: D6100089 0205215B
	v_add3_u32 v75, v75, v115, 0x7fff                          // 000000321484: D655004B 03FEE74B 00007FFF
	v_add3_u32 v79, v79, v124, 0x7fff                          // 000000321490: D655004F 03FEF94F 00007FFF
	v_add3_u32 v83, v83, v128, 0x7fff                          // 00000032149C: D6550053 03FF0153 00007FFF
	v_bfe_u32 v128, v5, 16, 1                                  // 0000003214A8: D6100080 02052105
	v_add3_u32 v84, v84, v129, 0x7fff                          // 0000003214B0: D6550054 03FF0354 00007FFF
	v_bfe_u32 v129, v105, 16, 1                                // 0000003214BC: D6100081 02052169
	v_add3_u32 v90, v90, v136, 0x7fff                          // 0000003214C4: D655005A 03FF115A 00007FFF
	v_add3_u32 v81, v102, v126, 0x7fff                         // 0000003214D0: D6550051 03FEFD66 00007FFF
	v_add3_u32 v99, v104, v127, 0x7fff                         // 0000003214DC: D6550063 03FEFF68 00007FFF
	v_and_or_b32 v73, 0xffff0000, v97, v53                     // 0000003214E8: D6570049 04D6C2FF FFFF0000
	.long 0x7e6a39c6                                           // 0000003214F4: 7E6A39C6
	.long 0x7f8e39b5                                           // 0000003214F8: 7F8E39B5
	.long 0x7f1a39b5                                           // 0000003214FC: 7F1A39B5
	.long 0x7f1c39b5                                           // 000000321500: 7F1C39B5
	.long 0x7f2039b5                                           // 000000321504: 7F2039B5
	.long 0x7fe839b5                                           // 000000321508: 7FE839B5
	v_bfe_u32 v140, v94, 16, 1                                 // 00000032150C: D610008C 0205215E
	v_bfe_u32 v114, v98, 16, 1                                 // 000000321514: D6100072 02052162
	v_bfe_u32 v123, v101, 16, 1                                // 00000032151C: D610007B 02052165
	v_bfe_u32 v130, v106, 16, 1                                // 000000321524: D6100082 0205216A
	v_bfe_u32 v131, v107, 16, 1                                // 00000032152C: D6100083 0205216B
	v_add3_u32 v87, v87, v132, 0x7fff                          // 000000321534: D6550057 03FF0957 00007FFF
	v_add3_u32 v69, v69, v133, 0x7fff                          // 000000321540: D6550045 03FF0B45 00007FFF
	v_bfe_u32 v133, v108, 16, 1                                // 00000032154C: D6100085 0205216C
	v_add3_u32 v91, v91, v137, 0x7fff                          // 000000321554: D655005B 03FF135B 00007FFF
	v_add3_u32 v5, v5, v128, 0x7fff                            // 000000321560: D6550005 03FF0105 00007FFF
	v_add3_u32 v85, v105, v129, 0x7fff                         // 00000032156C: D6550055 03FF0369 00007FFF
	.long 0x7e8e39cb                                           // 000000321578: 7E8E39CB
	.long 0x7e1a39cf                                           // 00000032157C: 7E1A39CF
	.long 0x7e1c39d3                                           // 000000321580: 7E1C39D3
	.long 0x7e2039da                                           // 000000321584: 7E2039DA
	.long 0x7ee839e3                                           // 000000321588: 7EE839E3
	v_and_or_b32 v70, 0xffff0000, v81, v53                     // 00000032158C: D6570046 04D6A2FF FFFF0000
	.long 0x7f1e39b5                                           // 000000321598: 7F1E39B5
	v_bfe_u32 v141, v95, 16, 1                                 // 00000032159C: D610008D 0205215F
	v_bfe_u32 v132, v6, 16, 1                                  // 0000003215A4: D6100084 02052106
	v_add3_u32 v94, v94, v140, 0x7fff                          // 0000003215AC: D655005E 03FF195E 00007FFF
	v_add3_u32 v96, v98, v114, 0x7fff                          // 0000003215B8: D6550060 03FEE562 00007FFF
	v_add3_u32 v98, v101, v123, 0x7fff                         // 0000003215C4: D6550062 03FEF765 00007FFF
	v_add3_u32 v100, v106, v130, 0x7fff                        // 0000003215D0: D6550064 03FF056A 00007FFF
	v_add3_u32 v101, v107, v131, 0x7fff                        // 0000003215DC: D6550065 03FF076B 00007FFF
	v_add3_u32 v88, v108, v133, 0x7fff                         // 0000003215E8: D6550058 03FF0B6C 00007FFF
	.long 0x7e1e39d7                                           // 0000003215F4: 7E1E39D7
	.long 0x7e6a39d5                                           // 0000003215F8: 7E6A39D5
	v_and_or_b32 v71, 0xffff0000, v76, v71                     // 0000003215FC: D6570047 051E98FF FFFF0000
	v_and_or_b32 v13, 0xffff0000, v80, v13                     // 000000321608: D657000D 0436A0FF FFFF0000
	v_and_or_b32 v14, 0xffff0000, v84, v14                     // 000000321614: D657000E 043AA8FF FFFF0000
	v_and_or_b32 v16, 0xffff0000, v91, v16                     // 000000321620: D6570010 0442B6FF FFFF0000
	v_and_or_b32 v5, 0xffff0000, v5, v116                      // 00000032162C: D6570005 05D20AFF FFFF0000
	.long 0x7f1239b5                                           // 000000321638: 7F1239B5
	.long 0x7fea39b5                                           // 00000032163C: 7FEA39B5
	v_bfe_u32 v115, v11, 16, 1                                 // 000000321640: D6100073 0205210B
	v_bfe_u32 v124, v12, 16, 1                                 // 000000321648: D610007C 0205210C
	v_bfe_u32 v134, v109, 16, 1                                // 000000321650: D6100086 0205216D
	v_bfe_u32 v135, v110, 16, 1                                // 000000321658: D6100087 0205216E
	v_add3_u32 v95, v95, v141, 0x7fff                          // 000000321660: D655005F 03FF1B5F 00007FFF
	v_add3_u32 v6, v6, v132, 0x7fff                            // 00000032166C: D6550006 03FF0906 00007FFF
	.long 0x7e1239de                                           // 000000321678: 7E1239DE
	.long 0x7eea39e5                                           // 00000032167C: 7EEA39E5
	v_and_or_b32 v15, 0xffff0000, v69, v15                     // 000000321680: D657000F 043E8AFF FFFF0000
	v_and_or_b32 v69, 0xffff0000, v100, v53                    // 00000032168C: D6570045 04D6C8FF FFFF0000
	.long 0x7e6a39d8                                           // 000000321698: 7E6A39D8
	.long 0x7f1439b5                                           // 00000032169C: 7F1439B5
	.long 0x7fce39b5                                           // 0000003216A0: 7FCE39B5
	v_bfe_u32 v136, v7, 16, 1                                  // 0000003216A4: D6100088 02052107
	v_bfe_u32 v137, v111, 16, 1                                // 0000003216AC: D6100089 0205216F
	v_add3_u32 v11, v11, v115, 0x7fff                          // 0000003216B4: D655000B 03FEE70B 00007FFF
	v_add3_u32 v12, v12, v124, 0x7fff                          // 0000003216C0: D655000C 03FEF90C 00007FFF
	v_add3_u32 v102, v109, v134, 0x7fff                        // 0000003216CC: D6550066 03FF0D6D 00007FFF
	v_add3_u32 v104, v110, v135, 0x7fff                        // 0000003216D8: D6550068 03FF0F6E 00007FFF
	.long 0x7e1439e0                                           // 0000003216E4: 7E1439E0
	.long 0x7ece39e2                                           // 0000003216E8: 7ECE39E2
	v_and_or_b32 v9, 0xffff0000, v95, v9                       // 0000003216EC: D6570009 0426BEFF FFFF0000
	v_and_or_b32 v6, 0xffff0000, v6, v117                      // 0000003216F8: D6570006 05D60CFF FFFF0000
	.long 0x7fec39b5                                           // 000000321704: 7FEC39B5
	v_bfe_u32 v138, v112, 16, 1                                // 000000321708: D610008A 02052170
	v_bfe_u32 v139, v113, 16, 1                                // 000000321710: D610008B 02052171
	v_add3_u32 v7, v7, v136, 0x7fff                            // 000000321718: D6550007 03FF1107 00007FFF
	v_add3_u32 v92, v111, v137, 0x7fff                         // 000000321724: D655005C 03FF136F 00007FFF
	.long 0x7eec39e8                                           // 000000321730: 7EEC39E8
	v_and_or_b32 v10, 0xffff0000, v11, v10                     // 000000321734: D657000A 042A16FF FFFF0000
	v_and_or_b32 v11, 0xffff0000, v12, v103                    // 000000321740: D657000B 059E18FF FFFF0000
	v_and_or_b32 v12, 0xffff0000, v102, v53                    // 00000032174C: D657000C 04D6CCFF FFFF0000
	v_bfe_u32 v140, v8, 16, 1                                  // 000000321758: D610008C 02052108
	v_add3_u32 v105, v112, v138, 0x7fff                        // 000000321760: D6550069 03FF1570 00007FFF
	v_add3_u32 v106, v113, v139, 0x7fff                        // 00000032176C: D655006A 03FF1771 00007FFF
	.long 0x7e6a39dc                                           // 000000321778: 7E6A39DC
	v_and_or_b32 v7, 0xffff0000, v7, v118                      // 00000032177C: D6570007 05DA0EFF FFFF0000
	.long 0x7fee39b5                                           // 000000321788: 7FEE39B5
	v_add3_u32 v8, v8, v140, 0x7fff                            // 00000032178C: D6550008 03FF1908 00007FFF
	.long 0x7eee39ea                                           // 000000321798: 7EEE39EA
	v_and_or_b32 v75, 0xffff0000, v105, v53                    // 00000032179C: D657004B 04D6D2FF FFFF0000
	v_cvt_f32_ubyte0_e32 v120, v1                              // 0000003217A8: 7EF02301
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003217AC: BF870003
	v_and_or_b32 v8, 0xffff0000, v8, v119                      // 0000003217B0: D6570008 05DE10FF FFFF0000
	s_waitcnt vmcnt(7)                                         // 0000003217BC: BF891FF7
	v_dot2_f32_bf16 v76, v17, v74, 0                           // 0000003217C0: CC1A404C 1A029511
	s_waitcnt vmcnt(6)                                         // 0000003217C8: BF891BF7
	v_dot2_f32_bf16 v77, v21, v74, 0                           // 0000003217CC: CC1A404D 1A029515
	s_waitcnt vmcnt(5)                                         // 0000003217D4: BF8917F7
	v_dot2_f32_bf16 v79, v41, v74, 0                           // 0000003217D8: CC1A404F 1A029529
	s_waitcnt vmcnt(4)                                         // 0000003217E0: BF8913F7
	v_dot2_f32_bf16 v74, v45, v74, 0                           // 0000003217E4: CC1A404A 1A02952D
	v_dot2_f32_bf16 v80, v17, v89, 0                           // 0000003217EC: CC1A4050 1A02B311
	v_dot2_f32_bf16 v81, v21, v89, 0                           // 0000003217F4: CC1A4051 1A02B315
	v_dot2_f32_bf16 v83, v41, v89, 0                           // 0000003217FC: CC1A4053 1A02B329
	v_dot2_f32_bf16 v84, v45, v89, 0                           // 000000321804: CC1A4054 1A02B32D
	v_dot2_f32_bf16 v85, v17, v70, 0                           // 00000032180C: CC1A4055 1A028D11
	v_dot2_f32_bf16 v87, v21, v70, 0                           // 000000321814: CC1A4057 1A028D15
	v_dot2_f32_bf16 v88, v41, v70, 0                           // 00000032181C: CC1A4058 1A028D29
	v_dot2_f32_bf16 v70, v45, v70, 0                           // 000000321824: CC1A4046 1A028D2D
	v_dot2_f32_bf16 v76, v18, v71, v76                         // 00000032182C: CC1A404C 1D328F12
	v_dot2_f32_bf16 v77, v22, v71, v77                         // 000000321834: CC1A404D 1D368F16
	v_dot2_f32_bf16 v79, v42, v71, v79                         // 00000032183C: CC1A404F 1D3E8F2A
	v_dot2_f32_bf16 v71, v46, v71, v74                         // 000000321844: CC1A4047 1D2A8F2E
	v_dot2_f32_bf16 v74, v18, v16, v80                         // 00000032184C: CC1A404A 1D422112
	v_dot2_f32_bf16 v80, v22, v16, v81                         // 000000321854: CC1A4050 1D462116
	v_dot2_f32_bf16 v81, v42, v16, v83                         // 00000032185C: CC1A4051 1D4E212A
	v_dot2_f32_bf16 v16, v46, v16, v84                         // 000000321864: CC1A4010 1D52212E
	v_dot2_f32_bf16 v83, v18, v5, v85                          // 00000032186C: CC1A4053 1D560B12
	v_dot2_f32_bf16 v84, v22, v5, v87                          // 000000321874: CC1A4054 1D5E0B16
	v_dot2_f32_bf16 v85, v42, v5, v88                          // 00000032187C: CC1A4055 1D620B2A
	v_dot2_f32_bf16 v5, v46, v5, v70                           // 000000321884: CC1A4005 1D1A0B2E
	v_dot2_f32_bf16 v70, v19, v78, v76                         // 00000032188C: CC1A4046 1D329D13
	v_dot2_f32_bf16 v76, v23, v78, v77                         // 000000321894: CC1A404C 1D369D17
	v_dot2_f32_bf16 v77, v43, v78, v79                         // 00000032189C: CC1A404D 1D3E9D2B
	v_dot2_f32_bf16 v71, v47, v78, v71                         // 0000003218A4: CC1A4047 1D1E9D2F
	v_dot2_f32_bf16 v74, v19, v93, v74                         // 0000003218AC: CC1A404A 1D2ABB13
	v_dot2_f32_bf16 v78, v23, v93, v80                         // 0000003218B4: CC1A404E 1D42BB17
	v_dot2_f32_bf16 v79, v43, v93, v81                         // 0000003218BC: CC1A404F 1D46BB2B
	v_dot2_f32_bf16 v16, v47, v93, v16                         // 0000003218C4: CC1A4010 1C42BB2F
	v_dot2_f32_bf16 v80, v19, v69, v83                         // 0000003218CC: CC1A4050 1D4E8B13
	v_dot2_f32_bf16 v81, v23, v69, v84                         // 0000003218D4: CC1A4051 1D528B17
	v_dot2_f32_bf16 v83, v43, v69, v85                         // 0000003218DC: CC1A4053 1D568B2B
	v_dot2_f32_bf16 v5, v47, v69, v5                           // 0000003218E4: CC1A4005 1C168B2F
	v_dot2_f32_bf16 v69, v20, v13, v70                         // 0000003218EC: CC1A4045 1D1A1B14
	v_dot2_f32_bf16 v70, v24, v13, v76                         // 0000003218F4: CC1A4046 1D321B18
	v_dot2_f32_bf16 v76, v44, v13, v77                         // 0000003218FC: CC1A404C 1D361B2C
	v_dot2_f32_bf16 v13, v48, v13, v71                         // 000000321904: CC1A400D 1D1E1B30
	v_dot2_f32_bf16 v71, v20, v9, v74                          // 00000032190C: CC1A4047 1D2A1314
	v_dot2_f32_bf16 v74, v24, v9, v78                          // 000000321914: CC1A404A 1D3A1318
	v_dot2_f32_bf16 v77, v44, v9, v79                          // 00000032191C: CC1A404D 1D3E132C
	v_dot2_f32_bf16 v9, v48, v9, v16                           // 000000321924: CC1A4009 1C421330
	v_dot2_f32_bf16 v16, v20, v6, v80                          // 00000032192C: CC1A4010 1D420D14
	v_dot2_f32_bf16 v78, v24, v6, v81                          // 000000321934: CC1A404E 1D460D18
	v_dot2_f32_bf16 v79, v44, v6, v83                          // 00000032193C: CC1A404F 1D4E0D2C
	v_dot2_f32_bf16 v5, v48, v6, v5                            // 000000321944: CC1A4005 1C160D30
	s_waitcnt vmcnt(3)                                         // 00000032194C: BF890FF7
	v_dot2_f32_bf16 v6, v25, v82, v69                          // 000000321950: CC1A4006 1D16A519
	s_waitcnt vmcnt(2)                                         // 000000321958: BF890BF7
	v_dot2_f32_bf16 v69, v29, v82, v70                         // 00000032195C: CC1A4045 1D1AA51D
	s_waitcnt vmcnt(1)                                         // 000000321964: BF8907F7
	v_dot2_f32_bf16 v70, v33, v82, v76                         // 000000321968: CC1A4046 1D32A521
	s_waitcnt vmcnt(0)                                         // 000000321970: BF8903F7
	v_dot2_f32_bf16 v13, v37, v82, v13                         // 000000321974: CC1A400D 1C36A525
	v_dot2_f32_bf16 v71, v25, v68, v71                         // 00000032197C: CC1A4047 1D1E8919
	v_dot2_f32_bf16 v74, v29, v68, v74                         // 000000321984: CC1A404A 1D2A891D
	v_dot2_f32_bf16 v76, v33, v68, v77                         // 00000032198C: CC1A404C 1D368921
	v_dot2_f32_bf16 v9, v37, v68, v9                           // 000000321994: CC1A4009 1C268925
	v_dot2_f32_bf16 v16, v25, v12, v16                         // 00000032199C: CC1A4010 1C421919
	v_dot2_f32_bf16 v68, v29, v12, v78                         // 0000003219A4: CC1A4044 1D3A191D
	v_dot2_f32_bf16 v77, v33, v12, v79                         // 0000003219AC: CC1A404D 1D3E1921
	v_dot2_f32_bf16 v6, v26, v14, v6                           // 0000003219B4: CC1A4006 1C1A1D1A
	v_dot2_f32_bf16 v69, v30, v14, v69                         // 0000003219BC: CC1A4045 1D161D1E
	v_dot2_f32_bf16 v70, v34, v14, v70                         // 0000003219C4: CC1A4046 1D1A1D22
	v_dot2_f32_bf16 v13, v38, v14, v13                         // 0000003219CC: CC1A400D 1C361D26
	v_dot2_f32_bf16 v14, v26, v10, v71                         // 0000003219D4: CC1A400E 1D1E151A
	v_dot2_f32_bf16 v71, v30, v10, v74                         // 0000003219DC: CC1A4047 1D2A151E
	v_dot2_f32_bf16 v74, v34, v10, v76                         // 0000003219E4: CC1A404A 1D321522
	v_dot2_f32_bf16 v9, v38, v10, v9                           // 0000003219EC: CC1A4009 1C261526
	v_dot2_f32_bf16 v10, v26, v7, v16                          // 0000003219F4: CC1A400A 1C420F1A
	v_dot2_f32_bf16 v16, v30, v7, v68                          // 0000003219FC: CC1A4010 1D120F1E
	v_dot2_f32_bf16 v68, v34, v7, v77                          // 000000321A04: CC1A4044 1D360F22
	v_dot2_f32_bf16 v6, v27, v86, v6                           // 000000321A0C: CC1A4006 1C1AAD1B
	v_dot2_f32_bf16 v69, v31, v86, v69                         // 000000321A14: CC1A4045 1D16AD1F
	v_dot2_f32_bf16 v70, v35, v86, v70                         // 000000321A1C: CC1A4046 1D1AAD23
	v_dot2_f32_bf16 v13, v39, v86, v13                         // 000000321A24: CC1A400D 1C36AD27
	v_dot2_f32_bf16 v71, v31, v73, v71                         // 000000321A2C: CC1A4047 1D1E931F
	v_dot2_f32_bf16 v74, v35, v73, v74                         // 000000321A34: CC1A404A 1D2A9323
	v_dot2_f32_bf16 v9, v39, v73, v9                           // 000000321A3C: CC1A4009 1C269327
	v_dot2_f32_bf16 v10, v27, v75, v10                         // 000000321A44: CC1A400A 1C2A971B
	v_dot2_f32_bf16 v14, v27, v73, v14                         // 000000321A4C: CC1A400E 1C3A931B
	v_dot2_f32_bf16 v16, v31, v75, v16                         // 000000321A54: CC1A4010 1C42971F
	v_dot2_f32_bf16 v68, v35, v75, v68                         // 000000321A5C: CC1A4044 1D129723
	v_dot2_f32_bf16 v6, v28, v15, v6                           // 000000321A64: CC1A4006 1C1A1F1C
	v_dot2_f32_bf16 v69, v32, v15, v69                         // 000000321A6C: CC1A4045 1D161F20
	v_dot2_f32_bf16 v70, v36, v15, v70                         // 000000321A74: CC1A4046 1D1A1F24
	v_dot2_f32_bf16 v13, v40, v15, v13                         // 000000321A7C: CC1A400D 1C361F28
	v_dot2_f32_bf16 v15, v32, v11, v71                         // 000000321A84: CC1A400F 1D1E1720
	v_dot2_f32_bf16 v71, v36, v11, v74                         // 000000321A8C: CC1A4047 1D2A1724
	v_dot2_f32_bf16 v9, v40, v11, v9                           // 000000321A94: CC1A4009 1C261728
	v_dot2_f32_bf16 v10, v28, v8, v10                          // 000000321A9C: CC1A400A 1C2A111C
	v_dot2_f32_bf16 v14, v28, v11, v14                         // 000000321AA4: CC1A400E 1C3A171C
	v_dot2_f32_bf16 v11, v32, v8, v16                          // 000000321AAC: CC1A400B 1C421120
	v_dual_add_f32 v63, v63, v6 :: v_dual_add_f32 v62, v62, v69// 000000321AB4: C9080D3F 3F3E8B3E
	v_dual_add_f32 v57, v57, v71 :: v_dual_add_f32 v56, v56, v9// 000000321ABC: C9088F39 39381338
	s_delay_alu instid0(VALU_DEP_3)                            // 000000321AC4: BF870003
	v_dual_add_f32 v55, v55, v10 :: v_dual_add_f32 v54, v54, v11// 000000321AC8: C9081537 37361736
	v_dot2_f32_bf16 v6, v36, v8, v68                           // 000000321AD0: CC1A4006 1D121124
	v_cvt_f32_ubyte2_e32 v9, v1                                // 000000321AD8: 7E122701
	v_fma_mix_f32 v10, v120, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321ADC: CC20600A 150E8778
	v_cvt_f32_ubyte1_e32 v11, v1                               // 000000321AE4: 7E162501
	v_dot2_f32_bf16 v5, v37, v12, v5                           // 000000321AE8: CC1A4005 1C161925
	v_add_f32_e32 v64, v64, v6                                 // 000000321AF0: 06800D40
	v_fma_mix_f32 v6, v9, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321AF4: CC206006 150E8709
	v_bfe_u32 v9, v10, 16, 1                                   // 000000321AFC: D6100009 0205210A
	v_fma_mix_f32 v11, v11, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321B04: CC20600B 150E870B
	v_cvt_f32_ubyte3_e32 v1, v1                                // 000000321B0C: 7E022901
	v_dot2_f32_bf16 v5, v38, v7, v5                            // 000000321B10: CC1A4005 1C160F26
	v_bfe_u32 v7, v6, 16, 1                                    // 000000321B18: D6100007 02052106
	v_add3_u32 v9, v10, v9, 0x7fff                             // 000000321B20: D6550009 03FE130A 00007FFF
	v_bfe_u32 v10, v11, 16, 1                                  // 000000321B2C: D610000A 0205210B
	v_fma_mix_f32 v1, v1, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321B34: CC206001 150E8701
	v_dual_add_f32 v61, v61, v70 :: v_dual_add_f32 v60, v60, v13// 000000321B3C: C9088D3D 3D3C1B3C
	s_delay_alu instid0(VALU_DEP_4)                            // 000000321B44: BF870004
	.long 0x7e6a3989                                           // 000000321B48: 7E6A3989
	v_cvt_f32_ubyte0_e32 v9, v2                                // 000000321B4C: 7E122302
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000321B50: D6550006 03FE0F06 00007FFF
	v_add3_u32 v7, v11, v10, 0x7fff                            // 000000321B5C: D6550007 03FE150B 00007FFF
	v_bfe_u32 v10, v1, 16, 1                                   // 000000321B68: D610000A 02052101
	v_cvt_f32_ubyte2_e32 v11, v2                               // 000000321B70: 7E162702
	v_fma_mix_f32 v9, v9, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321B74: CC206009 150E8709
	.long 0x7e0c3986                                           // 000000321B7C: 7E0C3986
	.long 0x7f0c39b5                                           // 000000321B80: 7F0C39B5
	v_add3_u32 v1, v1, v10, 0x7fff                             // 000000321B84: D6550001 03FE1501 00007FFF
	v_cvt_f32_ubyte1_e32 v10, v2                               // 000000321B90: 7E142502
	v_bfe_u32 v12, v9, 16, 1                                   // 000000321B94: D610000C 02052109
	v_fma_mix_f32 v11, v11, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321B9C: CC20600B 150E870B
	v_cvt_f32_ubyte3_e32 v2, v2                                // 000000321BA4: 7E042902
	v_and_or_b32 v1, 0xffff0000, v1, v6                        // 000000321BA8: D6570001 041A02FF FFFF0000
	v_fma_mix_f32 v6, v10, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321BB4: CC206006 150E870A
	v_add3_u32 v9, v9, v12, 0x7fff                             // 000000321BBC: D6550009 03FE1909 00007FFF
	v_cvt_f32_ubyte0_e32 v12, v3                               // 000000321BC8: 7E182303
	v_and_or_b32 v7, 0xffff0000, v7, v53                       // 000000321BCC: D6570007 04D60EFF FFFF0000
	v_bfe_u32 v10, v11, 16, 1                                  // 000000321BD8: D610000A 0205210B
	v_bfe_u32 v13, v6, 16, 1                                   // 000000321BE0: D610000D 02052106
	v_fma_mix_f32 v2, v2, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321BE8: CC206002 150E8702
	.long 0x7e6a3989                                           // 000000321BF0: 7E6A3989
	v_fma_mix_f32 v9, v12, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321BF4: CC206009 150E870C
	v_dual_add_f32 v59, v59, v14 :: v_dual_add_f32 v58, v58, v15// 000000321BFC: C9081D3B 3B3A1F3A
	v_add3_u32 v10, v11, v10, 0x7fff                           // 000000321C04: D655000A 03FE150B 00007FFF
	v_add3_u32 v6, v6, v13, 0x7fff                             // 000000321C10: D6550006 03FE1B06 00007FFF
	v_bfe_u32 v11, v2, 16, 1                                   // 000000321C1C: D610000B 02052102
	v_cvt_f32_ubyte1_e32 v12, v3                               // 000000321C24: 7E182503
	v_bfe_u32 v13, v9, 16, 1                                   // 000000321C28: D610000D 02052109
	v_cvt_f32_ubyte2_e32 v14, v3                               // 000000321C30: 7E1C2703
	v_and_or_b32 v6, 0xffff0000, v6, v53                       // 000000321C34: D6570006 04D60CFF FFFF0000
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000321C40: D6550002 03FE1702 00007FFF
	v_fma_mix_f32 v11, v12, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321C4C: CC20600B 150E870C
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000321C54: D6550009 03FE1B09 00007FFF
	v_fma_mix_f32 v12, v14, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321C60: CC20600C 150E870E
	v_cvt_f32_ubyte3_e32 v3, v3                                // 000000321C68: 7E062903
	v_cvt_f32_ubyte0_e32 v13, v4                               // 000000321C6C: 7E1A2304
	.long 0x7e14398a                                           // 000000321C70: 7E14398A
	.long 0x7e6a3989                                           // 000000321C74: 7E6A3989
	v_bfe_u32 v9, v12, 16, 1                                   // 000000321C78: D6100009 0205210C
	.long 0x7f1439b5                                           // 000000321C80: 7F1439B5
	v_fma_mix_f32 v3, v3, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321C84: CC206003 150E8703
	v_dot2_f32_bf16 v5, v39, v75, v5                           // 000000321C8C: CC1A4005 1C169727
	s_delay_alu instid0(VALU_DEP_4)                            // 000000321C94: BF870004
	v_add3_u32 v9, v12, v9, 0x7fff                             // 000000321C98: D6550009 03FE130C 00007FFF
	v_fma_mix_f32 v12, v13, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321CA4: CC20600C 150E870D
	v_cvt_f32_ubyte1_e32 v13, v4                               // 000000321CAC: 7E1A2504
	v_and_or_b32 v2, 0xffff0000, v2, v10                       // 000000321CB0: D6570002 042A04FF FFFF0000
	v_bfe_u32 v10, v11, 16, 1                                  // 000000321CBC: D610000A 0205210B
	v_bfe_u32 v14, v3, 16, 1                                   // 000000321CC4: D610000E 02052103
	v_bfe_u32 v15, v12, 16, 1                                  // 000000321CCC: D610000F 0205210C
	v_fma_mix_f32 v13, v13, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321CD4: CC20600D 150E870D
	.long 0x7e123989                                           // 000000321CDC: 7E123989
	v_add3_u32 v10, v11, v10, 0x7fff                           // 000000321CE0: D655000A 03FE150B 00007FFF
	.long 0x7f1239b5                                           // 000000321CEC: 7F1239B5
	v_add3_u32 v3, v3, v14, 0x7fff                             // 000000321CF0: D6550003 03FE1D03 00007FFF
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000321CFC: D655000C 03FE1F0C 00007FFF
	v_bfe_u32 v14, v13, 16, 1                                  // 000000321D08: D610000E 0205210D
	v_and_or_b32 v10, 0xffff0000, v10, v53                     // 000000321D10: D657000A 04D614FF FFFF0000
	v_cvt_f32_ubyte2_e32 v11, v4                               // 000000321D1C: 7E162704
	v_and_or_b32 v3, 0xffff0000, v3, v9                        // 000000321D20: D6570003 042606FF FFFF0000
	.long 0x7e6a398c                                           // 000000321D2C: 7E6A398C
	v_add3_u32 v9, v13, v14, 0x7fff                            // 000000321D30: D6550009 03FE1D0D 00007FFF
	v_dot2_f32_bf16 v12, v17, v7, 0                            // 000000321D3C: CC1A400C 1A020F11
	v_dot2_f32_bf16 v13, v21, v7, 0                            // 000000321D44: CC1A400D 1A020F15
	v_dot2_f32_bf16 v14, v41, v7, 0                            // 000000321D4C: CC1A400E 1A020F29
	v_dot2_f32_bf16 v7, v45, v7, 0                             // 000000321D54: CC1A4007 1A020F2D
	v_cvt_f32_ubyte3_e32 v4, v4                                // 000000321D5C: 7E082904
	v_dot2_f32_bf16 v12, v18, v1, v12                          // 000000321D60: CC1A400C 1C320312
	v_dot2_f32_bf16 v13, v22, v1, v13                          // 000000321D68: CC1A400D 1C360316
	v_dot2_f32_bf16 v14, v42, v1, v14                          // 000000321D70: CC1A400E 1C3A032A
	v_dot2_f32_bf16 v1, v46, v1, v7                            // 000000321D78: CC1A4001 1C1E032E
	v_fma_mix_f32 v11, v11, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321D80: CC20600B 150E870B
	v_fma_mix_f32 v4, v4, v67, v67 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000321D88: CC206004 150E8704
	v_dot2_f32_bf16 v7, v19, v6, v12                           // 000000321D90: CC1A4007 1C320D13
	v_dot2_f32_bf16 v12, v23, v6, v13                          // 000000321D98: CC1A400C 1C360D17
	v_dot2_f32_bf16 v13, v43, v6, v14                          // 000000321DA0: CC1A400D 1C3A0D2B
	v_dot2_f32_bf16 v1, v47, v6, v1                            // 000000321DA8: CC1A4001 1C060D2F
	v_bfe_u32 v16, v11, 16, 1                                  // 000000321DB0: D6100010 0205210B
	v_bfe_u32 v6, v4, 16, 1                                    // 000000321DB8: D6100006 02052104
	v_dot2_f32_bf16 v7, v20, v2, v7                            // 000000321DC0: CC1A4007 1C1E0514
	v_dot2_f32_bf16 v12, v24, v2, v12                          // 000000321DC8: CC1A400C 1C320518
	v_dot2_f32_bf16 v13, v44, v2, v13                          // 000000321DD0: CC1A400D 1C36052C
	v_dot2_f32_bf16 v1, v48, v2, v1                            // 000000321DD8: CC1A4001 1C060530
	v_add3_u32 v11, v11, v16, 0x7fff                           // 000000321DE0: D655000B 03FE210B 00007FFF
	v_add3_u32 v2, v4, v6, 0x7fff                              // 000000321DEC: D6550002 03FE0D04 00007FFF
	v_dot2_f32_bf16 v4, v25, v10, v7                           // 000000321DF8: CC1A4004 1C1E1519
	v_dot2_f32_bf16 v6, v29, v10, v12                          // 000000321E00: CC1A4006 1C32151D
	v_dot2_f32_bf16 v7, v33, v10, v13                          // 000000321E08: CC1A4007 1C361521
	v_dot2_f32_bf16 v1, v37, v10, v1                           // 000000321E10: CC1A4001 1C061525
	.long 0x7e16398b                                           // 000000321E18: 7E16398B
	.long 0x7f1639b5                                           // 000000321E1C: 7F1639B5
	v_and_or_b32 v9, 0xffff0000, v9, v53                       // 000000321E20: D6570009 04D612FF FFFF0000
	v_dot2_f32_bf16 v4, v26, v3, v4                            // 000000321E2C: CC1A4004 1C12071A
	v_dot2_f32_bf16 v6, v30, v3, v6                            // 000000321E34: CC1A4006 1C1A071E
	v_dot2_f32_bf16 v7, v34, v3, v7                            // 000000321E3C: CC1A4007 1C1E0722
	v_dot2_f32_bf16 v1, v38, v3, v1                            // 000000321E44: CC1A4001 1C060726
	v_and_or_b32 v2, 0xffff0000, v2, v11                       // 000000321E4C: D6570002 042E04FF FFFF0000
	v_dot2_f32_bf16 v3, v27, v9, v4                            // 000000321E58: CC1A4003 1C12131B
	v_dot2_f32_bf16 v4, v31, v9, v6                            // 000000321E60: CC1A4004 1C1A131F
	v_dot2_f32_bf16 v6, v35, v9, v7                            // 000000321E68: CC1A4006 1C1E1323
	v_dot2_f32_bf16 v1, v39, v9, v1                            // 000000321E70: CC1A4001 1C061327
	v_dot2_f32_bf16 v5, v40, v8, v5                            // 000000321E78: CC1A4005 1C161128
	v_dot2_f32_bf16 v3, v28, v2, v3                            // 000000321E80: CC1A4003 1C0E051C
	v_dot2_f32_bf16 v4, v32, v2, v4                            // 000000321E88: CC1A4004 1C120520
	v_dot2_f32_bf16 v6, v36, v2, v6                            // 000000321E90: CC1A4006 1C1A0524
	v_dot2_f32_bf16 v1, v40, v2, v1                            // 000000321E98: CC1A4001 1C060528
	v_add_f32_e32 v72, v72, v5                                 // 000000321EA0: 06900B48
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000321EA4: BF870194
	v_dual_add_f32 v52, v52, v3 :: v_dual_add_f32 v51, v51, v4 // 000000321EA8: C9080734 34320933
	v_dual_add_f32 v50, v50, v6 :: v_dual_add_f32 v49, v49, v1 // 000000321EB0: C9080D32 32300331
	s_or_b32 exec_lo, exec_lo, s3                              // 000000321EB8: 8C7E037E
	.long 0xd71f0001                                           // 000000321EBC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000321EC0: 020100C1
	s_mov_b32 s6, exec_lo                                      // 000000321EC4: BE86007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000321EC8: BF8701B1
	v_xor_b32_e32 v2, 8, v1                                    // 000000321ECC: 3A040288
	v_xor_b32_e32 v3, 4, v1                                    // 000000321ED0: 3A060284
	v_xor_b32_e32 v18, 2, v1                                   // 000000321ED4: 3A240282
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000321ED8: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000321EDC: 02040501
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000321EE0: BF870134
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000321EE4: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000321EE8: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000321EEC: 7C9824A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000321EF0: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000321EF4: 30040482
	ds_bpermute_b32 v5, v2, v62                                // 000000321EF8: DACC0000 05003E02
	s_waitcnt lgkmcnt(0)                                       // 000000321F00: BF89FC07
	v_add_f32_e32 v5, v62, v5                                  // 000000321F04: 060A0B3E
	ds_bpermute_b32 v4, v2, v63                                // 000000321F08: DACC0000 04003F02
	ds_bpermute_b32 v6, v2, v61                                // 000000321F10: DACC0000 06003D02
	ds_bpermute_b32 v7, v2, v60                                // 000000321F18: DACC0000 07003C02
	ds_bpermute_b32 v8, v2, v59                                // 000000321F20: DACC0000 08003B02
	ds_bpermute_b32 v9, v2, v58                                // 000000321F28: DACC0000 09003A02
	ds_bpermute_b32 v15, v2, v72                               // 000000321F30: DACC0000 0F004802
	ds_bpermute_b32 v16, v2, v52                               // 000000321F38: DACC0000 10003402
	ds_bpermute_b32 v10, v2, v57                               // 000000321F40: DACC0000 0A003902
	ds_bpermute_b32 v11, v2, v56                               // 000000321F48: DACC0000 0B003802
	ds_bpermute_b32 v12, v2, v55                               // 000000321F50: DACC0000 0C003702
	ds_bpermute_b32 v13, v2, v54                               // 000000321F58: DACC0000 0D003602
	ds_bpermute_b32 v14, v2, v64                               // 000000321F60: DACC0000 0E004002
	ds_bpermute_b32 v17, v2, v51                               // 000000321F68: DACC0000 11003302
	ds_bpermute_b32 v19, v2, v50                               // 000000321F70: DACC0000 13003202
	ds_bpermute_b32 v2, v2, v49                                // 000000321F78: DACC0000 02003102
	ds_bpermute_b32 v21, v3, v5                                // 000000321F80: DACC0000 15000503
	s_waitcnt lgkmcnt(15)                                      // 000000321F88: BF89FCF7
	v_add_f32_e32 v4, v63, v4                                  // 000000321F8C: 0608093F
	s_waitcnt lgkmcnt(13)                                      // 000000321F90: BF89FCD7
	v_dual_add_f32 v6, v61, v6 :: v_dual_add_f32 v7, v60, v7   // 000000321F94: C9080D3D 06060F3C
	s_waitcnt lgkmcnt(11)                                      // 000000321F9C: BF89FCB7
	v_dual_add_f32 v8, v59, v8 :: v_dual_add_f32 v9, v58, v9   // 000000321FA0: C908113B 0808133A
	s_waitcnt lgkmcnt(10)                                      // 000000321FA8: BF89FCA7
	v_add_f32_e32 v15, v72, v15                                // 000000321FAC: 061E1F48
	s_waitcnt lgkmcnt(9)                                       // 000000321FB0: BF89FC97
	v_add_f32_e32 v16, v52, v16                                // 000000321FB4: 06202134
	ds_bpermute_b32 v20, v3, v4                                // 000000321FB8: DACC0000 14000403
	ds_bpermute_b32 v22, v3, v6                                // 000000321FC0: DACC0000 16000603
	ds_bpermute_b32 v23, v3, v7                                // 000000321FC8: DACC0000 17000703
	ds_bpermute_b32 v24, v3, v8                                // 000000321FD0: DACC0000 18000803
	ds_bpermute_b32 v25, v3, v9                                // 000000321FD8: DACC0000 19000903
	s_waitcnt lgkmcnt(12)                                      // 000000321FE0: BF89FCC7
	v_dual_add_f32 v10, v57, v10 :: v_dual_add_f32 v11, v56, v11// 000000321FE4: C9081539 0A0A1738
	s_waitcnt lgkmcnt(7)                                       // 000000321FEC: BF89FC77
	v_add_f32_e32 v19, v50, v19                                // 000000321FF0: 06262732
	ds_bpermute_b32 v32, v3, v16                               // 000000321FF4: DACC0000 20001003
	s_waitcnt lgkmcnt(7)                                       // 000000321FFC: BF89FC77
	v_add_f32_e32 v2, v49, v2                                  // 000000322000: 06040531
	ds_bpermute_b32 v31, v3, v15                               // 000000322004: DACC0000 1F000F03
	v_dual_add_f32 v12, v55, v12 :: v_dual_add_f32 v13, v54, v13// 00000032200C: C9081937 0C0C1B36
	v_dual_add_f32 v14, v64, v14 :: v_dual_add_f32 v17, v51, v17// 000000322014: C9081D40 0E102333
	ds_bpermute_b32 v26, v3, v10                               // 00000032201C: DACC0000 1A000A03
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000322024: 02242501
	ds_bpermute_b32 v27, v3, v11                               // 000000322028: DACC0000 1B000B03
	ds_bpermute_b32 v28, v3, v12                               // 000000322030: DACC0000 1C000C03
	ds_bpermute_b32 v29, v3, v13                               // 000000322038: DACC0000 1D000D03
	ds_bpermute_b32 v30, v3, v14                               // 000000322040: DACC0000 1E000E03
	ds_bpermute_b32 v33, v3, v17                               // 000000322048: DACC0000 21001103
	ds_bpermute_b32 v34, v3, v19                               // 000000322050: DACC0000 22001303
	ds_bpermute_b32 v3, v3, v2                                 // 000000322058: DACC0000 03000203
	s_waitcnt lgkmcnt(14)                                      // 000000322060: BF89FCE7
	v_dual_add_f32 v4, v4, v20 :: v_dual_add_f32 v5, v5, v21   // 000000322064: C9082904 04042B05
	s_waitcnt lgkmcnt(10)                                      // 00000032206C: BF89FCA7
	v_dual_add_f32 v6, v6, v22 :: v_dual_add_f32 v9, v9, v25   // 000000322070: C9082D06 06083309
	v_dual_add_f32 v7, v7, v23 :: v_dual_lshlrev_b32 v18, 2, v18// 000000322078: C9222F07 07122482
	s_waitcnt lgkmcnt(9)                                       // 000000322080: BF89FC97
	v_add_f32_e32 v21, v16, v32                                // 000000322084: 062A4110
	v_add_f32_e32 v8, v8, v24                                  // 000000322088: 06103108
	ds_bpermute_b32 v16, v18, v5                               // 00000032208C: DACC0000 10000512
	s_waitcnt lgkmcnt(9)                                       // 000000322094: BF89FC97
	v_add_f32_e32 v20, v15, v31                                // 000000322098: 06283F0F
	ds_bpermute_b32 v15, v18, v4                               // 00000032209C: DACC0000 0F000412
	ds_bpermute_b32 v22, v18, v6                               // 0000003220A4: DACC0000 16000612
	ds_bpermute_b32 v24, v18, v7                               // 0000003220AC: DACC0000 18000712
	s_waitcnt lgkmcnt(8)                                       // 0000003220B4: BF89FC87
	v_dual_add_f32 v10, v10, v26 :: v_dual_add_f32 v13, v13, v29// 0000003220B8: C908350A 0A0C3B0D
	v_dual_add_f32 v11, v11, v27 :: v_dual_add_f32 v12, v12, v28// 0000003220C0: C908370B 0B0C390C
	s_waitcnt lgkmcnt(5)                                       // 0000003220C8: BF89FC57
	v_add_f32_e32 v19, v19, v34                                // 0000003220CC: 06264513
	v_add_f32_e32 v14, v14, v30                                // 0000003220D0: 061C3D0E
	v_add_f32_e32 v26, v17, v33                                // 0000003220D4: 06344311
	ds_bpermute_b32 v27, v18, v10                              // 0000003220D8: DACC0000 1B000A12
	s_waitcnt lgkmcnt(5)                                       // 0000003220E0: BF89FC57
	v_add_f32_e32 v2, v2, v3                                   // 0000003220E4: 06040702
	ds_bpermute_b32 v17, v18, v8                               // 0000003220E8: DACC0000 11000812
	ds_bpermute_b32 v25, v18, v9                               // 0000003220F0: DACC0000 19000912
	ds_bpermute_b32 v28, v18, v11                              // 0000003220F8: DACC0000 1C000B12
	ds_bpermute_b32 v29, v18, v12                              // 000000322100: DACC0000 1D000C12
	ds_bpermute_b32 v30, v18, v13                              // 000000322108: DACC0000 1E000D12
	ds_bpermute_b32 v33, v18, v21                              // 000000322110: DACC0000 21001512
	ds_bpermute_b32 v35, v18, v19                              // 000000322118: DACC0000 23001312
	s_waitcnt lgkmcnt(11)                                      // 000000322120: BF89FCB7
	v_add_f32_e32 v23, v5, v16                                 // 000000322124: 062E2105
	ds_bpermute_b32 v32, v18, v20                              // 000000322128: DACC0000 20001412
	s_waitcnt lgkmcnt(11)                                      // 000000322130: BF89FCB7
	v_add_f32_e32 v3, v4, v15                                  // 000000322134: 06061F04
	ds_bpermute_b32 v31, v18, v14                              // 000000322138: DACC0000 1F000E12
	s_waitcnt lgkmcnt(11)                                      // 000000322140: BF89FCB7
	v_add_f32_e32 v15, v6, v22                                 // 000000322144: 061E2D06
	ds_bpermute_b32 v34, v18, v26                              // 000000322148: DACC0000 22001A12
	s_waitcnt lgkmcnt(11)                                      // 000000322150: BF89FCB7
	v_add_f32_e32 v7, v7, v24                                  // 000000322154: 060E3107
	ds_bpermute_b32 v36, v18, v2                               // 000000322158: DACC0000 24000212
	v_xor_b32_e32 v5, 1, v1                                    // 000000322160: 3A0A0281
	s_delay_alu instid0(VALU_DEP_1)                            // 000000322164: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000322168: 7C980AA0
	s_waitcnt lgkmcnt(11)                                      // 00000032216C: BF89FCB7
	v_add_f32_e32 v16, v10, v27                                // 000000322170: 0620370A
	s_waitcnt lgkmcnt(10)                                      // 000000322174: BF89FCA7
	v_add_f32_e32 v4, v8, v17                                  // 000000322178: 06082308
	s_waitcnt lgkmcnt(9)                                       // 00000032217C: BF89FC97
	v_add_f32_e32 v24, v9, v25                                 // 000000322180: 06303309
	s_waitcnt lgkmcnt(8)                                       // 000000322184: BF89FC87
	v_dual_add_f32 v8, v11, v28 :: v_dual_cndmask_b32 v1, v1, v5// 000000322188: C912390B 08000B01
	s_waitcnt lgkmcnt(7)                                       // 000000322190: BF89FC77
	v_add_f32_e32 v5, v12, v29                                 // 000000322194: 060A3B0C
	s_waitcnt lgkmcnt(6)                                       // 000000322198: BF89FC67
	v_add_f32_e32 v25, v13, v30                                // 00000032219C: 06323D0D
	s_waitcnt lgkmcnt(3)                                       // 0000003221A0: BF89FC37
	v_dual_add_f32 v9, v20, v32 :: v_dual_add_f32 v6, v21, v33 // 0000003221A4: C9084114 09064315
	s_waitcnt lgkmcnt(2)                                       // 0000003221AC: BF89FC27
	v_add_f32_e32 v17, v14, v31                                // 0000003221B0: 06223F0E
	s_waitcnt lgkmcnt(1)                                       // 0000003221B4: BF89FC17
	v_dual_add_f32 v26, v26, v34 :: v_dual_lshlrev_b32 v1, 2, v1// 0000003221B8: C922451A 1A000282
	v_add_f32_e32 v18, v19, v35                                // 0000003221C0: 06244713
	s_waitcnt lgkmcnt(0)                                       // 0000003221C4: BF89FC07
	v_add_f32_e32 v10, v2, v36                                 // 0000003221C8: 06144902
	ds_bpermute_b32 v31, v1, v3                                // 0000003221CC: DACC0000 1F000301
	ds_bpermute_b32 v27, v1, v23                               // 0000003221D4: DACC0000 1B001701
	ds_bpermute_b32 v19, v1, v15                               // 0000003221DC: DACC0000 13000F01
	ds_bpermute_b32 v11, v1, v7                                // 0000003221E4: DACC0000 0B000701
	ds_bpermute_b32 v32, v1, v4                                // 0000003221EC: DACC0000 20000401
	ds_bpermute_b32 v28, v1, v24                               // 0000003221F4: DACC0000 1C001801
	ds_bpermute_b32 v20, v1, v16                               // 0000003221FC: DACC0000 14001001
	ds_bpermute_b32 v12, v1, v8                                // 000000322204: DACC0000 0C000801
	ds_bpermute_b32 v33, v1, v5                                // 00000032220C: DACC0000 21000501
	ds_bpermute_b32 v29, v1, v25                               // 000000322214: DACC0000 1D001901
	ds_bpermute_b32 v21, v1, v17                               // 00000032221C: DACC0000 15001101
	ds_bpermute_b32 v13, v1, v9                                // 000000322224: DACC0000 0D000901
	ds_bpermute_b32 v34, v1, v6                                // 00000032222C: DACC0000 22000601
	ds_bpermute_b32 v30, v1, v26                               // 000000322234: DACC0000 1E001A01
	ds_bpermute_b32 v22, v1, v18                               // 00000032223C: DACC0000 16001201
	ds_bpermute_b32 v14, v1, v10                               // 000000322244: DACC0000 0E000A01
	v_cmpx_eq_u32_e32 0, v66                                   // 00000032224C: 7D948480
	s_cbranch_execz 1030                                       // 000000322250: BFA50406 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x346c>
	v_ashrrev_i32_e32 v66, 31, v65                             // 000000322254: 3484829F
	s_waitcnt lgkmcnt(11)                                      // 000000322258: BF89FCB7
	v_dual_add_f32 v3, v3, v31 :: v_dual_add_f32 v4, v4, v32   // 00000032225C: C9083F03 03044104
	s_waitcnt lgkmcnt(3)                                       // 000000322264: BF89FC37
	v_dual_add_f32 v5, v5, v33 :: v_dual_add_f32 v6, v6, v34   // 000000322268: C9084305 05064506
	.long 0xd73c0023                                           // 000000322270: D73C0023
	v_cndmask_b32_e32 v1, 1, v65, vcc_lo                       // 000000322274: 02028281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000322278: BF870223
	v_bfe_u32 v31, v3, 16, 1                                   // 00000032227C: D610001F 02052103
	v_bfe_u32 v32, v4, 16, 1                                   // 000000322284: D6100020 02052104
	v_bfe_u32 v33, v5, 16, 1                                   // 00000032228C: D6100021 02052105
	v_bfe_u32 v34, v6, 16, 1                                   // 000000322294: D6100022 02052106
	s_cmp_lg_u64 s[10:11], 0                                   // 00000032229C: BF11800A
	.long 0xd7006a01                                           // 0000003222A0: D7006A01
	v_cndmask_b32_e32 v1, s20, v35, vcc_lo                     // 0000003222A4: 02024614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003222A8: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s21, v36, vcc_lo             // 0000003222AC: D5207C02 01AA4815
	v_add3_u32 v4, v4, v32, 0x7fff                             // 0000003222B4: D6550004 03FE4104 00007FFF
	.long 0xd7006a25                                           // 0000003222C0: D7006A25
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 0000003222C4: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003222CC: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v2, vcc_lo               // 0000003222D0: D5207C26 01AA0480
	.long 0xd7006a27                                           // 0000003222D8: D7006A27
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 0000003222DC: 020202FF 00003000
	v_add_co_ci_u32_e64 v40, null, 0, v2, vcc_lo               // 0000003222E4: D5207C28 01AA0480
	.long 0xd7006a29                                           // 0000003222EC: D7006A29
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 0000003222F0: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003222F8: BF870001
	v_add_co_ci_u32_e64 v42, null, 0, v2, vcc_lo               // 0000003222FC: D5207C2A 01AA0480
	s_clause 0x3                                               // 000000322304: BF850003
	global_load_u16 v37, v[37:38], off offset:2048             // 000000322308: DC4A0800 257C0025
	global_load_u16 v38, v[39:40], off offset:3072             // 000000322310: DC4A0C00 267C0027
	global_load_u16 v39, v[1:2], off                           // 000000322318: DC4A0000 277C0001
	global_load_u16 v40, v[41:42], off offset:1024             // 000000322320: DC4A0400 287C0029
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000322328: 360808FF FFFF0000
	v_add3_u32 v3, v3, v31, 0x7fff                             // 000000322330: D6550003 03FE3F03 00007FFF
	v_add3_u32 v6, v6, v34, 0x7fff                             // 00000032233C: D6550006 03FE4506 00007FFF
	v_add3_u32 v5, v5, v33, 0x7fff                             // 000000322348: D6550005 03FE4305 00007FFF
	s_cselect_b32 s7, -1, 0                                    // 000000322354: 980780C1
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000322358: 100808FF BFB8AA3B
	s_cmp_eq_u64 s[10:11], 0                                   // 000000322360: BF10800A
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000322364: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000032236C: BF870122
	v_exp_f32_e32 v4, v4                                       // 000000322370: 7E084B04
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000322374: 360606FF FFFF0000
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 00000032237C: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322384: BF870311
	v_exp_f32_e32 v6, v6                                       // 000000322388: 7E0C4B06
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 00000032238C: C92408F2 04040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322398: BF870113
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000032239C: 100606FF BFB8AA3B
	v_div_scale_f32 v32, null, v4, v4, 1.0                     // 0000003223A4: D6FC7C20 03CA0904
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003223AC: BF870002
	v_exp_f32_e32 v3, v3                                       // 0000003223B0: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 0000003223B4: BF870186
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 0000003223B8: C9060CF2 06040AFF BFB8AA3B
	v_div_scale_f32 v46, s3, 1.0, v4, 1.0                      // 0000003223C4: D6FC032E 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003223CC: BF870113
	v_rcp_f32_e32 v42, v32                                     // 0000003223D0: 7E545520
	v_div_scale_f32 v34, null, v6, v6, 1.0                     // 0000003223D4: D6FC7C22 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003223DC: BF870393
	v_exp_f32_e32 v5, v5                                       // 0000003223E0: 7E0A4B05
	v_add_f32_e32 v3, 1.0, v3                                  // 0000003223E4: 060606F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000003223E8: BF870392
	v_rcp_f32_e32 v44, v34                                     // 0000003223EC: 7E585522
	v_fma_f32 v48, -v32, v42, 1.0                              // 0000003223F0: D6130030 23CA5520
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003223F8: BF870002
	v_div_scale_f32 v31, null, v3, v3, 1.0                     // 0000003223FC: D6FC7C1F 03CA0703
	v_div_scale_f32 v45, vcc_lo, 1.0, v3, 1.0                  // 000000322404: D6FC6A2D 03CA06F2
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 00000032240C: BF870186
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_fmac_f32 v42, v48, v42// 000000322410: C9000AF2 052A5530
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322418: BF870313
	v_rcp_f32_e32 v41, v31                                     // 00000032241C: 7E52551F
	v_fma_f32 v51, -v34, v44, 1.0                              // 000000322420: D6130033 23CA5922
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000322428: BF8701A2
	v_div_scale_f32 v33, null, v5, v5, 1.0                     // 00000032242C: D6FC7C21 03CA0B05
	v_div_scale_f32 v50, s4, 1.0, v5, 1.0                      // 000000322434: D6FC0432 03CA0AF2
	v_fmac_f32_e32 v44, v51, v44                               // 00000032243C: 56585933
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322440: BF870313
	v_rcp_f32_e32 v43, v33                                     // 000000322444: 7E565521
	v_fma_f32 v47, -v31, v41, 1.0                              // 000000322448: D613002F 23CA531F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000322450: BF8702A1
	v_fmac_f32_e32 v41, v47, v41                               // 000000322454: 5652532F
	v_div_scale_f32 v47, s5, 1.0, v6, 1.0                      // 000000322458: D6FC052F 03CA0CF2
	v_fma_f32 v49, -v33, v43, 1.0                              // 000000322460: D6130031 23CA5721
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322468: BF870113
	v_mul_f32_e32 v48, v45, v41                                // 00000032246C: 1060532D
	v_dual_mul_f32 v52, v47, v44 :: v_dual_fmac_f32 v43, v49, v43// 000000322470: C8C0592F 342A5731
	v_mul_f32_e32 v49, v46, v42                                // 000000322478: 1062552E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032247C: BF870193
	v_fma_f32 v53, -v31, v48, v45                              // 000000322480: D6130035 24B6611F
	v_fma_f32 v56, -v34, v52, v47                              // 000000322488: D6130038 24BE6922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322490: BF870214
	v_mul_f32_e32 v51, v50, v43                                // 000000322494: 10665732
	v_fma_f32 v54, -v32, v49, v46                              // 000000322498: D6130036 24BA6320
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003224A0: BF870214
	v_fmac_f32_e32 v48, v53, v41                               // 0000003224A4: 56605335
	v_fmac_f32_e32 v52, v56, v44                               // 0000003224A8: 56685938
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003224AC: BF870214
	v_fma_f32 v55, -v33, v51, v50                              // 0000003224B0: D6130037 24CA6721
	v_fmac_f32_e32 v49, v54, v42                               // 0000003224B8: 56625536
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003224BC: BF870214
	v_fma_f32 v31, -v31, v48, v45                              // 0000003224C0: D613001F 24B6611F
	v_fma_f32 v34, -v34, v52, v47                              // 0000003224C8: D6130022 24BE6922
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003224D0: BF870214
	v_fmac_f32_e32 v51, v55, v43                               // 0000003224D4: 56665737
	v_fma_f32 v32, -v32, v49, v46                              // 0000003224D8: D6130020 24BA6320
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003224E0: BF8701A4
	v_div_fmas_f32 v31, v31, v41, v48                          // 0000003224E4: D637001F 04C2531F
	s_mov_b32 vcc_lo, s3                                       // 0000003224EC: BEEA0003
	v_fma_f32 v33, -v33, v51, v50                              // 0000003224F0: D6130021 24CA6721
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000003224F8: BF8701B3
	v_div_fmas_f32 v32, v32, v42, v49                          // 0000003224FC: D6370020 04C65520
	s_mov_b32 vcc_lo, s4                                       // 000000322504: BEEA0004
	v_div_fixup_f32 v3, v31, v3, 1.0                           // 000000322508: D6270003 03CA071F
	v_div_fmas_f32 v31, v33, v43, v51                          // 000000322510: D637001F 04CE5721
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000322518: BF8701A3
	v_div_fixup_f32 v4, v32, v4, 1.0                           // 00000032251C: D6270004 03CA0920
	s_mov_b32 vcc_lo, s5                                       // 000000322524: BEEA0005
	v_bfe_u32 v32, v3, 16, 1                                   // 000000322528: D6100020 02052103
	v_div_fmas_f32 v33, v34, v44, v52                          // 000000322530: D6370021 04D25922
	v_div_fixup_f32 v5, v31, v5, 1.0                           // 000000322538: D6270005 03CA0B1F
	v_bfe_u32 v31, v4, 16, 1                                   // 000000322540: D610001F 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322548: BF870214
	v_add3_u32 v3, v3, v32, 0x7fff                             // 00000032254C: D6550003 03FE4103 00007FFF
	v_div_fixup_f32 v6, v33, v6, 1.0                           // 000000322558: D6270006 03CA0D21
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322560: BF870214
	v_bfe_u32 v32, v5, 16, 1                                   // 000000322564: D6100020 02052105
	v_add3_u32 v4, v4, v31, 0x7fff                             // 00000032256C: D6550004 03FE3F04 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322578: BF870214
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000032257C: 360606FF FFFF0000
	v_bfe_u32 v33, v6, 16, 1                                   // 000000322584: D6100021 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032258C: BF870114
	v_add3_u32 v5, v5, v32, 0x7fff                             // 000000322590: D6550005 03FE4105 00007FFF
	v_add3_u32 v6, v6, v33, 0x7fff                             // 00000032259C: D6550006 03FE4306 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000003225A8: BF870152
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000003225AC: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000003225B4: BF8907F7
	v_lshlrev_b32_e32 v31, 16, v39                             // 0000003225B8: 303E4E90
	s_waitcnt vmcnt(0)                                         // 0000003225BC: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v40                             // 0000003225C0: 30405090
	v_fma_f32 v3, v3, v31, 0                                   // 0000003225C4: D6130003 02023F03
	v_lshlrev_b32_e32 v31, 16, v37                             // 0000003225CC: 303E4A90
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000003225D0: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003225D8: BF870091
	v_dual_fmac_f32 v3, v4, v32 :: v_dual_and_b32 v4, 0xffff0000, v6// 0000003225DC: C8244104 03040CFF FFFF0000
	v_dual_fmac_f32 v3, v5, v31 :: v_dual_lshlrev_b32 v6, 16, v38// 0000003225E8: C8223F05 03064C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003225F0: BF870091
	v_fmac_f32_e32 v3, v4, v6                                  // 0000003225F4: 56060D04
	v_mul_f32_e32 v31, 0x3e800000, v3                          // 0000003225F8: 103E06FF 3E800000
	.long 0xd7006a03                                           // 000000322600: D7006A03
	v_cndmask_b32_e32 v1, s8, v35, vcc_lo                      // 000000322604: 02024608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322608: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v36, vcc_lo              // 00000032260C: D5207C04 01AA4809
	v_bfe_u32 v5, v31, 16, 1                                   // 000000322614: D6100005 0205211F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032261C: BF870001
	v_add3_u32 v32, v31, v5, 0x7fff                            // 000000322620: D6550020 03FE0B1F 00007FFF
	.long 0xd73c0005                                           // 00000032262C: D73C0005
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 000000322630: 02028282
	global_store_d16_hi_b16 v[3:4], v32, off                   // 000000322634: DC960000 007C2003
	s_cbranch_scc1 7                                           // 00000032263C: BFA20007 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x285c>
	.long 0xd7006a20                                           // 000000322640: D7006A20
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000322644: 02020A0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000322648: BF870001
	v_add_co_ci_u32_e64 v33, null, s11, v6, vcc_lo             // 00000032264C: D5207C21 01AA0C0B
	global_store_b32 v[32:33], v31, off                        // 000000322654: DC6A0000 007C1F20
	.long 0xd7006a1f                                           // 00000032265C: D7006A1F
	v_cndmask_b32_e32 v1, 0x5000, v1, vcc_lo                   // 000000322660: 020202FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322668: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v2, vcc_lo               // 00000032266C: D5207C20 01AA0480
	.long 0xd7006a21                                           // 000000322674: D7006A21
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 000000322678: 020202FF 00006000
	v_add_co_ci_u32_e64 v34, null, 0, v2, vcc_lo               // 000000322680: D5207C22 01AA0480
	s_clause 0x1                                               // 000000322688: BF850001
	global_load_u16 v35, v[31:32], off                         // 00000032268C: DC4A0000 237C001F
	global_load_u16 v36, v[33:34], off offset:1024             // 000000322694: DC4A0400 247C0021
	.long 0xd7006a1f                                           // 00000032269C: D7006A1F
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 0000003226A0: 020202FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003226A8: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v2, vcc_lo               // 0000003226AC: D5207C20 01AA0480
	.long 0xd7006a21                                           // 0000003226B4: D7006A21
	v_cndmask_b32_e32 v1, 0x8000, v1, vcc_lo                   // 0000003226B8: 020202FF 00008000
	v_add_co_ci_u32_e64 v34, null, 0, v2, vcc_lo               // 0000003226C0: D5207C22 01AA0480
	s_clause 0x1                                               // 0000003226C8: BF850001
	global_load_u16 v31, v[31:32], off offset:2048             // 0000003226CC: DC4A0800 1F7C001F
	global_load_u16 v32, v[33:34], off offset:3072             // 0000003226D4: DC4A0C00 207C0021
	v_dual_add_f32 v23, v23, v27 :: v_dual_add_f32 v24, v24, v28// 0000003226DC: C9083717 17183918
	s_waitcnt lgkmcnt(2)                                       // 0000003226E4: BF89FC27
	v_dual_add_f32 v25, v25, v29 :: v_dual_add_f32 v26, v26, v30// 0000003226E8: C9083B19 191A3D1A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003226F0: BF870192
	v_bfe_u32 v27, v23, 16, 1                                  // 0000003226F4: D610001B 02052117
	v_bfe_u32 v28, v24, 16, 1                                  // 0000003226FC: D610001C 02052118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322704: BF870213
	v_bfe_u32 v29, v25, 16, 1                                  // 000000322708: D610001D 02052119
	v_bfe_u32 v30, v26, 16, 1                                  // 000000322710: D610001E 0205211A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322718: BF870214
	v_add3_u32 v23, v23, v27, 0x7fff                           // 00000032271C: D6550017 03FE3717 00007FFF
	v_add3_u32 v24, v24, v28, 0x7fff                           // 000000322728: D6550018 03FE3918 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322734: BF870214
	v_add3_u32 v25, v25, v29, 0x7fff                           // 000000322738: D6550019 03FE3B19 00007FFF
	v_add3_u32 v26, v26, v30, 0x7fff                           // 000000322744: D655001A 03FE3D1A 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322750: BF870113
	v_and_b32_e32 v24, 0xffff0000, v24                         // 000000322754: 363030FF FFFF0000
	v_and_b32_e32 v26, 0xffff0000, v26                         // 00000032275C: 363434FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322764: BF870112
	v_mul_f32_e32 v24, 0xbfb8aa3b, v24                         // 000000322768: 103030FF BFB8AA3B
	v_mul_f32_e32 v26, 0xbfb8aa3b, v26                         // 000000322770: 103434FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000322778: BF870122
	v_exp_f32_e32 v24, v24                                     // 00000032277C: 7E304B18
	v_and_b32_e32 v23, 0xffff0000, v23                         // 000000322780: 362E2EFF FFFF0000
	v_exp_f32_e32 v26, v26                                     // 000000322788: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032278C: BF870296
	v_dual_add_f32 v24, 1.0, v24 :: v_dual_and_b32 v25, 0xffff0000, v25// 000000322790: C92430F2 181832FF FFFF0000
	v_dual_mul_f32 v23, 0xbfb8aa3b, v23 :: v_dual_add_f32 v26, 1.0, v26// 00000032279C: C8C82EFF 171A34F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003227A8: BF870192
	v_mul_f32_e32 v25, 0xbfb8aa3b, v25                         // 0000003227AC: 103232FF BFB8AA3B
	v_div_scale_f32 v28, null, v24, v24, 1.0                   // 0000003227B4: D6FC7C1C 03CA3118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003227BC: BF870193
	v_exp_f32_e32 v23, v23                                     // 0000003227C0: 7E2E4B17
	v_div_scale_f32 v30, null, v26, v26, 1.0                   // 0000003227C4: D6FC7C1E 03CA351A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003227CC: BF870133
	v_exp_f32_e32 v25, v25                                     // 0000003227D0: 7E324B19
	v_div_scale_f32 v40, s3, 1.0, v24, 1.0                     // 0000003227D4: D6FC0328 03CA30F2
	v_rcp_f32_e32 v34, v28                                     // 0000003227DC: 7E44551C
	v_rcp_f32_e32 v38, v30                                     // 0000003227E0: 7E4C551E
	v_add_f32_e32 v23, 1.0, v23                                // 0000003227E4: 062E2EF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000003227E8: BF870317
	v_add_f32_e32 v25, 1.0, v25                                // 0000003227EC: 063232F2
	v_fma_f32 v42, -v28, v34, 1.0                              // 0000003227F0: D613002A 23CA451C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000003227F8: BF870223
	v_div_scale_f32 v27, null, v23, v23, 1.0                   // 0000003227FC: D6FC7C1B 03CA2F17
	v_div_scale_f32 v39, vcc_lo, 1.0, v23, 1.0                 // 000000322804: D6FC6A27 03CA2EF2
	v_div_scale_f32 v29, null, v25, v25, 1.0                   // 00000032280C: D6FC7C1D 03CA3319
	v_div_scale_f32 v44, s4, 1.0, v25, 1.0                     // 000000322814: D6FC042C 03CA32F2
	v_fmac_f32_e32 v34, v42, v34                               // 00000032281C: 5644452A
	v_rcp_f32_e32 v33, v27                                     // 000000322820: 7E42551B
	v_fma_f32 v45, -v30, v38, 1.0                              // 000000322824: D613002D 23CA4D1E
	v_rcp_f32_e32 v37, v29                                     // 00000032282C: 7E4A551D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322830: BF870311
	v_fmac_f32_e32 v38, v45, v38                               // 000000322834: 564C4D2D
	v_fma_f32 v41, -v27, v33, 1.0                              // 000000322838: D6130029 23CA431B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322840: BF870115
	v_fma_f32 v43, -v29, v37, 1.0                              // 000000322844: D613002B 23CA4B1D
	v_fmac_f32_e32 v33, v41, v33                               // 00000032284C: 56424329
	v_div_scale_f32 v41, s5, 1.0, v26, 1.0                     // 000000322850: D6FC0529 03CA34F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322858: BF870193
	v_fmac_f32_e32 v37, v43, v37                               // 00000032285C: 564A4B2B
	v_dual_mul_f32 v43, v40, v34 :: v_dual_mul_f32 v42, v39, v33// 000000322860: C8C64528 2B2A4327
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322868: BF870112
	v_dual_mul_f32 v46, v41, v38 :: v_dual_mul_f32 v45, v44, v37// 00000032286C: C8C64D29 2E2C4B2C
	v_fma_f32 v48, -v28, v43, v40                              // 000000322874: D6130030 24A2571C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032287C: BF870193
	v_fma_f32 v47, -v27, v42, v39                              // 000000322880: D613002F 249E551B
	v_fma_f32 v50, -v30, v46, v41                              // 000000322888: D6130032 24A65D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322890: BF870194
	v_fma_f32 v49, -v29, v45, v44                              // 000000322894: D6130031 24B25B1D
	v_dual_fmac_f32 v43, v48, v34 :: v_dual_fmac_f32 v42, v47, v33// 00000032289C: C8004530 2B2A432F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003228A4: BF870112
	v_dual_fmac_f32 v46, v50, v38 :: v_dual_fmac_f32 v45, v49, v37// 0000003228A8: C8004D32 2E2C4B31
	v_fma_f32 v28, -v28, v43, v40                              // 0000003228B0: D613001C 24A2571C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003228B8: BF870193
	v_fma_f32 v27, -v27, v42, v39                              // 0000003228BC: D613001B 249E551B
	v_fma_f32 v30, -v30, v46, v41                              // 0000003228C4: D613001E 24A65D1E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003228CC: BF870194
	v_fma_f32 v29, -v29, v45, v44                              // 0000003228D0: D613001D 24B25B1D
	v_div_fmas_f32 v27, v27, v33, v42                          // 0000003228D8: D637001B 04AA431B
	s_mov_b32 vcc_lo, s3                                       // 0000003228E0: BEEA0003
	v_div_fmas_f32 v28, v28, v34, v43                          // 0000003228E4: D637001C 04AE451C
	s_mov_b32 vcc_lo, s4                                       // 0000003228EC: BEEA0004
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003228F0: BF870002
	v_div_fixup_f32 v23, v27, v23, 1.0                         // 0000003228F4: D6270017 03CA2F1B
	v_div_fmas_f32 v27, v29, v37, v45                          // 0000003228FC: D637001B 04B64B1D
	s_mov_b32 vcc_lo, s5                                       // 000000322904: BEEA0005
	v_div_fixup_f32 v24, v28, v24, 1.0                         // 000000322908: D6270018 03CA311C
	v_div_fmas_f32 v29, v30, v38, v46                          // 000000322910: D637001D 04BA4D1E
	v_bfe_u32 v28, v23, 16, 1                                  // 000000322918: D610001C 02052117
	v_div_fixup_f32 v25, v27, v25, 1.0                         // 000000322920: D6270019 03CA331B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322928: BF870214
	v_bfe_u32 v27, v24, 16, 1                                  // 00000032292C: D610001B 02052118
	v_div_fixup_f32 v26, v29, v26, 1.0                         // 000000322934: D627001A 03CA351D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032293C: BF870214
	v_add3_u32 v23, v23, v28, 0x7fff                           // 000000322940: D6550017 03FE3917 00007FFF
	v_bfe_u32 v28, v25, 16, 1                                  // 00000032294C: D610001C 02052119
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322954: BF870214
	v_add3_u32 v24, v24, v27, 0x7fff                           // 000000322958: D6550018 03FE3718 00007FFF
	v_bfe_u32 v29, v26, 16, 1                                  // 000000322964: D610001D 0205211A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000032296C: BF870214
	v_and_b32_e32 v23, 0xffff0000, v23                         // 000000322970: 362E2EFF FFFF0000
	v_add3_u32 v25, v25, v28, 0x7fff                           // 000000322978: D6550019 03FE3919 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322984: BF870113
	v_add3_u32 v26, v26, v29, 0x7fff                           // 000000322988: D655001A 03FE3B1A 00007FFF
	v_and_b32_e32 v25, 0xffff0000, v25                         // 000000322994: 363232FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 00000032299C: BF890FF7
	v_lshlrev_b32_e32 v27, 16, v35                             // 0000003229A0: 30364690
	s_waitcnt vmcnt(2)                                         // 0000003229A4: BF890BF7
	v_lshlrev_b32_e32 v28, 16, v36                             // 0000003229A8: 30384890
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000003229AC: BF8700C2
	v_fma_f32 v23, v23, v27, 0                                 // 0000003229B0: D6130017 02023717
	s_waitcnt vmcnt(1)                                         // 0000003229B8: BF8907F7
	v_lshlrev_b32_e32 v27, 16, v31                             // 0000003229BC: 30363E90
	v_and_b32_e32 v24, 0xffff0000, v24                         // 0000003229C0: 363030FF FFFF0000
	v_dual_fmac_f32 v23, v24, v28 :: v_dual_and_b32 v24, 0xffff0000, v26// 0000003229C8: C8243918 171834FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000003229D4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003229D8: BF870091
	v_dual_fmac_f32 v23, v25, v27 :: v_dual_lshlrev_b32 v26, 16, v32// 0000003229DC: C8223719 171A4090
	v_fmac_f32_e32 v23, v24, v26                               // 0000003229E4: 562E3518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003229E8: BF870121
	v_mul_f32_e32 v24, 0x3e800000, v23                         // 0000003229EC: 10302EFF 3E800000
	v_cndmask_b32_e64 v23, 0, 1, s7                            // 0000003229F4: D5010017 001D0280
	v_bfe_u32 v25, v24, 16, 1                                  // 0000003229FC: D6100019 02052118
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322A04: BF8700A1
	v_add3_u32 v27, v24, v25, 0x7fff                           // 000000322A08: D655001B 03FE3318 00007FFF
	.long 0xd7006a19                                           // 000000322A14: D7006A19
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 000000322A18: 020206FF 00001000
	v_add_co_ci_u32_e64 v26, null, 0, v4, vcc_lo               // 000000322A20: D5207C1A 01AA0880
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 000000322A28: 916A077E
	global_store_d16_hi_b16 v[25:26], v27, off offset:1024     // 000000322A2C: DC960400 007C1B19
	s_cbranch_vccnz 13                                         // 000000322A34: BFA4000D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2c6c>
	.long 0xd7006a19                                           // 000000322A38: D7006A19
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000322A3C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322A40: BF870111
	v_add_co_ci_u32_e64 v26, null, s11, v6, vcc_lo             // 000000322A44: D5207C1A 01AA0C0B
	.long 0xd7006a19                                           // 000000322A4C: D7006A19
	v_cndmask_b32_e32 v1, 0x2000, v25, vcc_lo                  // 000000322A50: 020232FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000322A58: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v26, vcc_lo              // 000000322A5C: D5207C1A 01AA3480
	global_store_b32 v[25:26], v24, off offset:2048            // 000000322A64: DC6A0800 007C1819
	.long 0xd7006a18                                           // 000000322A6C: D7006A18
	v_cndmask_b32_e32 v1, 0xa000, v1, vcc_lo                   // 000000322A70: 020202FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322A78: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v2, vcc_lo               // 000000322A7C: D5207C19 01AA0480
	.long 0xd7006a1a                                           // 000000322A84: D7006A1A
	v_cndmask_b32_e32 v1, 0xb000, v1, vcc_lo                   // 000000322A88: 020202FF 0000B000
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 000000322A90: D5207C1B 01AA0480
	s_clause 0x1                                               // 000000322A98: BF850001
	global_load_u16 v28, v[24:25], off                         // 000000322A9C: DC4A0000 1C7C0018
	global_load_u16 v29, v[26:27], off offset:1024             // 000000322AA4: DC4A0400 1D7C001A
	.long 0xd7006a18                                           // 000000322AAC: D7006A18
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 000000322AB0: 020202FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322AB8: BF8700A1
	v_add_co_ci_u32_e64 v25, null, 0, v2, vcc_lo               // 000000322ABC: D5207C19 01AA0480
	.long 0xd7006a1a                                           // 000000322AC4: D7006A1A
	v_cndmask_b32_e32 v1, 0xd000, v1, vcc_lo                   // 000000322AC8: 020202FF 0000D000
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 000000322AD0: D5207C1B 01AA0480
	s_clause 0x1                                               // 000000322AD8: BF850001
	global_load_u16 v24, v[24:25], off offset:2048             // 000000322ADC: DC4A0800 187C0018
	global_load_u16 v25, v[26:27], off offset:3072             // 000000322AE4: DC4A0C00 197C001A
	v_dual_add_f32 v15, v15, v19 :: v_dual_add_f32 v16, v16, v20// 000000322AEC: C908270F 0F102910
	s_waitcnt lgkmcnt(1)                                       // 000000322AF4: BF89FC17
	v_dual_add_f32 v17, v17, v21 :: v_dual_add_f32 v18, v18, v22// 000000322AF8: C9082B11 11122D12
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322B00: BF870192
	v_bfe_u32 v19, v15, 16, 1                                  // 000000322B04: D6100013 0205210F
	v_bfe_u32 v20, v16, 16, 1                                  // 000000322B0C: D6100014 02052110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322B14: BF870213
	v_bfe_u32 v21, v17, 16, 1                                  // 000000322B18: D6100015 02052111
	v_bfe_u32 v22, v18, 16, 1                                  // 000000322B20: D6100016 02052112
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322B28: BF870214
	v_add3_u32 v15, v15, v19, 0x7fff                           // 000000322B2C: D655000F 03FE270F 00007FFF
	v_add3_u32 v16, v16, v20, 0x7fff                           // 000000322B38: D6550010 03FE2910 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322B44: BF870214
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000322B48: D6550011 03FE2B11 00007FFF
	v_add3_u32 v18, v18, v22, 0x7fff                           // 000000322B54: D6550012 03FE2D12 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322B60: BF870113
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000322B64: 362020FF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v18                         // 000000322B6C: 362424FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322B74: BF870112
	v_mul_f32_e32 v16, 0xbfb8aa3b, v16                         // 000000322B78: 102020FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 000000322B80: 102424FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000322B88: BF870122
	v_exp_f32_e32 v16, v16                                     // 000000322B8C: 7E204B10
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000322B90: 361E1EFF FFFF0000
	v_exp_f32_e32 v18, v18                                     // 000000322B98: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000322B9C: BF870296
	v_dual_add_f32 v16, 1.0, v16 :: v_dual_and_b32 v17, 0xffff0000, v17// 000000322BA0: C92420F2 101022FF FFFF0000
	v_dual_mul_f32 v15, 0xbfb8aa3b, v15 :: v_dual_add_f32 v18, 1.0, v18// 000000322BAC: C8C81EFF 0F1224F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322BB8: BF870192
	v_mul_f32_e32 v17, 0xbfb8aa3b, v17                         // 000000322BBC: 102222FF BFB8AA3B
	v_div_scale_f32 v20, null, v16, v16, 1.0                   // 000000322BC4: D6FC7C14 03CA2110
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322BCC: BF870193
	v_exp_f32_e32 v15, v15                                     // 000000322BD0: 7E1E4B0F
	v_div_scale_f32 v22, null, v18, v18, 1.0                   // 000000322BD4: D6FC7C16 03CA2512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000322BDC: BF870133
	v_exp_f32_e32 v17, v17                                     // 000000322BE0: 7E224B11
	v_div_scale_f32 v33, s3, 1.0, v16, 1.0                     // 000000322BE4: D6FC0321 03CA20F2
	v_rcp_f32_e32 v27, v20                                     // 000000322BEC: 7E365514
	v_rcp_f32_e32 v31, v22                                     // 000000322BF0: 7E3E5516
	v_add_f32_e32 v15, 1.0, v15                                // 000000322BF4: 061E1EF2
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322BF8: BF870317
	v_add_f32_e32 v17, 1.0, v17                                // 000000322BFC: 062222F2
	v_fma_f32 v35, -v20, v27, 1.0                              // 000000322C00: D6130023 23CA3714
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000322C08: BF870223
	v_div_scale_f32 v19, null, v15, v15, 1.0                   // 000000322C0C: D6FC7C13 03CA1F0F
	v_div_scale_f32 v32, vcc_lo, 1.0, v15, 1.0                 // 000000322C14: D6FC6A20 03CA1EF2
	v_div_scale_f32 v21, null, v17, v17, 1.0                   // 000000322C1C: D6FC7C15 03CA2311
	v_div_scale_f32 v37, s4, 1.0, v17, 1.0                     // 000000322C24: D6FC0425 03CA22F2
	v_fmac_f32_e32 v27, v35, v27                               // 000000322C2C: 56363723
	v_rcp_f32_e32 v26, v19                                     // 000000322C30: 7E345513
	v_fma_f32 v38, -v22, v31, 1.0                              // 000000322C34: D6130026 23CA3F16
	v_rcp_f32_e32 v30, v21                                     // 000000322C3C: 7E3C5515
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000322C40: BF870311
	v_fmac_f32_e32 v31, v38, v31                               // 000000322C44: 563E3F26
	v_fma_f32 v34, -v19, v26, 1.0                              // 000000322C48: D6130022 23CA3513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322C50: BF870115
	v_fma_f32 v36, -v21, v30, 1.0                              // 000000322C54: D6130024 23CA3D15
	v_fmac_f32_e32 v26, v34, v26                               // 000000322C5C: 56343522
	v_div_scale_f32 v34, s5, 1.0, v18, 1.0                     // 000000322C60: D6FC0522 03CA24F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322C68: BF870193
	v_fmac_f32_e32 v30, v36, v30                               // 000000322C6C: 563C3D24
	v_dual_mul_f32 v36, v33, v27 :: v_dual_mul_f32 v35, v32, v26// 000000322C70: C8C63721 24223520
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322C78: BF870112
	v_dual_mul_f32 v39, v34, v31 :: v_dual_mul_f32 v38, v37, v30// 000000322C7C: C8C63F22 27263D25
	v_fma_f32 v41, -v20, v36, v33                              // 000000322C84: D6130029 24864914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322C8C: BF870193
	v_fma_f32 v40, -v19, v35, v32                              // 000000322C90: D6130028 24824713
	v_fma_f32 v43, -v22, v39, v34                              // 000000322C98: D613002B 248A4F16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322CA0: BF870194
	v_fma_f32 v42, -v21, v38, v37                              // 000000322CA4: D613002A 24964D15
	v_dual_fmac_f32 v36, v41, v27 :: v_dual_fmac_f32 v35, v40, v26// 000000322CAC: C8003729 24223528
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322CB4: BF870112
	v_dual_fmac_f32 v39, v43, v31 :: v_dual_fmac_f32 v38, v42, v30// 000000322CB8: C8003F2B 27263D2A
	v_fma_f32 v20, -v20, v36, v33                              // 000000322CC0: D6130014 24864914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322CC8: BF870193
	v_fma_f32 v19, -v19, v35, v32                              // 000000322CCC: D6130013 24824713
	v_fma_f32 v22, -v22, v39, v34                              // 000000322CD4: D6130016 248A4F16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322CDC: BF870194
	v_fma_f32 v21, -v21, v38, v37                              // 000000322CE0: D6130015 24964D15
	v_div_fmas_f32 v19, v19, v26, v35                          // 000000322CE8: D6370013 048E3513
	s_mov_b32 vcc_lo, s3                                       // 000000322CF0: BEEA0003
	v_div_fmas_f32 v20, v20, v27, v36                          // 000000322CF4: D6370014 04923714
	s_mov_b32 vcc_lo, s4                                       // 000000322CFC: BEEA0004
	s_delay_alu instid0(VALU_DEP_2)                            // 000000322D00: BF870002
	v_div_fixup_f32 v15, v19, v15, 1.0                         // 000000322D04: D627000F 03CA1F13
	v_div_fmas_f32 v19, v21, v30, v38                          // 000000322D0C: D6370013 049A3D15
	s_mov_b32 vcc_lo, s5                                       // 000000322D14: BEEA0005
	v_div_fixup_f32 v16, v20, v16, 1.0                         // 000000322D18: D6270010 03CA2114
	v_div_fmas_f32 v21, v22, v31, v39                          // 000000322D20: D6370015 049E3F16
	v_bfe_u32 v20, v15, 16, 1                                  // 000000322D28: D6100014 0205210F
	v_div_fixup_f32 v17, v19, v17, 1.0                         // 000000322D30: D6270011 03CA2313
	v_cmp_ne_u32_e32 vcc_lo, 1, v23                            // 000000322D38: 7C9A2E81
	v_bfe_u32 v19, v16, 16, 1                                  // 000000322D3C: D6100013 02052110
	v_div_fixup_f32 v18, v21, v18, 1.0                         // 000000322D44: D6270012 03CA2515
	v_add3_u32 v15, v15, v20, 0x7fff                           // 000000322D4C: D655000F 03FE290F 00007FFF
	v_bfe_u32 v20, v17, 16, 1                                  // 000000322D58: D6100014 02052111
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000322D60: 8B6A6A7E
	v_add3_u32 v16, v16, v19, 0x7fff                           // 000000322D64: D6550010 03FE2710 00007FFF
	v_bfe_u32 v21, v18, 16, 1                                  // 000000322D70: D6100015 02052112
	v_and_b32_e32 v15, 0xffff0000, v15                         // 000000322D78: 361E1EFF FFFF0000
	v_add3_u32 v17, v17, v20, 0x7fff                           // 000000322D80: D6550011 03FE2911 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322D8C: BF870113
	v_add3_u32 v18, v18, v21, 0x7fff                           // 000000322D90: D6550012 03FE2B12 00007FFF
	v_and_b32_e32 v17, 0xffff0000, v17                         // 000000322D9C: 362222FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000322DA4: BF890FF7
	v_lshlrev_b32_e32 v19, 16, v28                             // 000000322DA8: 30263890
	s_waitcnt vmcnt(2)                                         // 000000322DAC: BF890BF7
	v_lshlrev_b32_e32 v20, 16, v29                             // 000000322DB0: 30283A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000322DB4: BF8700C2
	v_fma_f32 v15, v15, v19, 0                                 // 000000322DB8: D613000F 0202270F
	s_waitcnt vmcnt(1)                                         // 000000322DC0: BF8907F7
	v_lshlrev_b32_e32 v19, 16, v24                             // 000000322DC4: 30263090
	v_and_b32_e32 v16, 0xffff0000, v16                         // 000000322DC8: 362020FF FFFF0000
	v_dual_fmac_f32 v15, v16, v20 :: v_dual_and_b32 v16, 0xffff0000, v18// 000000322DD0: C8242910 0F1024FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000322DDC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000322DE0: BF870091
	v_dual_fmac_f32 v15, v17, v19 :: v_dual_lshlrev_b32 v18, 16, v25// 000000322DE4: C8222711 0F123290
	v_fmac_f32_e32 v15, v16, v18                               // 000000322DEC: 561E2510
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000322DF0: BF870091
	v_mul_f32_e32 v15, 0x3e800000, v15                         // 000000322DF4: 101E1EFF 3E800000
	v_bfe_u32 v16, v15, 16, 1                                  // 000000322DFC: D6100010 0205210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322E04: BF8700A1
	v_add3_u32 v18, v15, v16, 0x7fff                           // 000000322E08: D6550012 03FE210F 00007FFF
	.long 0xd7000310                                           // 000000322E14: D7000310
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000322E18: 020206FF 00002000
	v_add_co_ci_u32_e64 v17, null, 0, v4, s3                   // 000000322E20: D5207C11 000E0880
	global_store_d16_hi_b16 v[16:17], v18, off offset:2048     // 000000322E28: DC960800 007C1210
	s_cbranch_vccnz 13                                         // 000000322E30: BFA4000D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3068>
	.long 0xd7006a10                                           // 000000322E34: D7006A10
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000322E38: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322E3C: BF870111
	v_add_co_ci_u32_e64 v17, null, s11, v6, vcc_lo             // 000000322E40: D5207C11 01AA0C0B
	.long 0xd7006a10                                           // 000000322E48: D7006A10
	v_cndmask_b32_e32 v1, 0x5000, v16, vcc_lo                  // 000000322E4C: 020220FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000322E54: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, vcc_lo              // 000000322E58: D5207C11 01AA2280
	global_store_b32 v[16:17], v15, off                        // 000000322E60: DC6A0000 007C0F10
	.long 0xd7006a0f                                           // 000000322E68: D7006A0F
	v_cndmask_b32_e32 v1, 0xf000, v1, vcc_lo                   // 000000322E6C: 020202FF 0000F000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322E74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 000000322E78: D5207C10 01AA0480
	.long 0xd7006a11                                           // 000000322E80: D7006A11
	v_cndmask_b32_e32 v1, 0x10000, v1, vcc_lo                  // 000000322E84: 020202FF 00010000
	v_add_co_ci_u32_e64 v18, null, 0, v2, vcc_lo               // 000000322E8C: D5207C12 01AA0480
	s_clause 0x1                                               // 000000322E94: BF850001
	global_load_u16 v19, v[15:16], off                         // 000000322E98: DC4A0000 137C000F
	global_load_u16 v17, v[17:18], off offset:1024             // 000000322EA0: DC4A0400 117C0011
	.long 0xd7006a0f                                           // 000000322EA8: D7006A0F
	v_cndmask_b32_e32 v1, 0x11000, v1, vcc_lo                  // 000000322EAC: 020202FF 00011000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000322EB4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 000000322EB8: D5207C10 01AA0480
	.long 0xd7006a01                                           // 000000322EC0: D7006A01
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 000000322EC4: 020202FF 00012000
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000322ECC: D5207C02 01AA0480
	s_clause 0x1                                               // 000000322ED4: BF850001
	global_load_u16 v15, v[15:16], off offset:2048             // 000000322ED8: DC4A0800 0F7C000F
	global_load_u16 v1, v[1:2], off offset:3072                // 000000322EE0: DC4A0C00 017C0001
	v_dual_add_f32 v2, v7, v11 :: v_dual_add_f32 v7, v8, v12   // 000000322EE8: C9081707 02061908
	s_waitcnt lgkmcnt(0)                                       // 000000322EF0: BF89FC07
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v10, v14  // 000000322EF4: C9081B09 08081D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322EFC: BF870192
	v_bfe_u32 v10, v2, 16, 1                                   // 000000322F00: D610000A 02052102
	v_bfe_u32 v11, v7, 16, 1                                   // 000000322F08: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322F10: BF870213
	v_bfe_u32 v12, v8, 16, 1                                   // 000000322F14: D610000C 02052108
	v_bfe_u32 v13, v9, 16, 1                                   // 000000322F1C: D610000D 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322F24: BF870214
	v_add3_u32 v2, v2, v10, 0x7fff                             // 000000322F28: D6550002 03FE1502 00007FFF
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000322F34: D6550007 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000322F40: BF870214
	v_add3_u32 v8, v8, v12, 0x7fff                             // 000000322F44: D6550008 03FE1908 00007FFF
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000322F50: D6550009 03FE1B09 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322F5C: BF870113
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000322F60: 360E0EFF FFFF0000
	v_and_b32_e32 v9, 0xffff0000, v9                           // 000000322F68: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000322F70: BF870112
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 000000322F74: 100E0EFF BFB8AA3B
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000322F7C: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000322F84: BF870122
	v_exp_f32_e32 v7, v7                                       // 000000322F88: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000322F8C: 360404FF FFFF0000
	v_exp_f32_e32 v9, v9                                       // 000000322F94: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000322F98: BF870296
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_and_b32 v8, 0xffff0000, v8// 000000322F9C: C9240EF2 070810FF FFFF0000
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_add_f32 v9, 1.0, v9// 000000322FA8: C8C804FF 020812F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322FB4: BF870192
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 000000322FB8: 101010FF BFB8AA3B
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000322FC0: D6FC7C0B 03CA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000322FC8: BF8701A3
	v_exp_f32_e32 v2, v2                                       // 000000322FCC: 7E044B02
	v_div_scale_f32 v22, s3, 1.0, v7, 1.0                      // 000000322FD0: D6FC0316 03CA0EF2
	v_exp_f32_e32 v8, v8                                       // 000000322FD8: 7E104B08
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000322FDC: D6FC7C0D 03CA1309
	v_rcp_f32_e32 v16, v11                                     // 000000322FE4: 7E20550B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000322FE8: BF8703A1
	v_rcp_f32_e32 v20, v13                                     // 000000322FEC: 7E28550D
	v_add_f32_e32 v2, 1.0, v2                                  // 000000322FF0: 060404F2
	v_add_f32_e32 v8, 1.0, v8                                  // 000000322FF4: 061010F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000322FF8: BF870196
	v_fma_f32 v25, -v11, v16, 1.0                              // 000000322FFC: D6130019 23CA210B
	v_div_scale_f32 v10, null, v2, v2, 1.0                     // 000000323004: D6FC7C0A 03CA0502
	v_div_scale_f32 v21, vcc_lo, 1.0, v2, 1.0                  // 00000032300C: D6FC6A15 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000323014: BF870294
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000323018: D6FC7C0C 03CA1108
	v_fma_f32 v28, -v13, v20, 1.0                              // 000000323020: D613001C 23CA290D
	v_div_scale_f32 v27, s4, 1.0, v8, 1.0                      // 000000323028: D6FC041B 03CA10F2
	v_rcp_f32_e32 v14, v10                                     // 000000323030: 7E1C550A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323034: BF870113
	v_rcp_f32_e32 v18, v12                                     // 000000323038: 7E24550C
	v_fmac_f32_e32 v20, v28, v20                               // 00000032303C: 5628291C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000323040: BF870296
	v_fma_f32 v24, -v10, v14, 1.0                              // 000000323044: D6130018 23CA1D0A
	v_fma_f32 v26, -v12, v18, 1.0                              // 00000032304C: D613001A 23CA250C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000323054: BF8700A2
	v_fmac_f32_e32 v14, v24, v14                               // 000000323058: 561C1D18
	v_div_scale_f32 v24, s5, 1.0, v9, 1.0                      // 00000032305C: D6FC0518 03CA12F2
	v_dual_fmac_f32 v18, v26, v18 :: v_dual_mul_f32 v29, v24, v20// 000000323064: C806251A 121C2918
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032306C: BF870111
	v_mul_f32_e32 v28, v27, v18                                // 000000323070: 1038251B
	v_fma_f32 v33, -v13, v29, v24                              // 000000323074: D6130021 24623B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032307C: BF870112
	v_fma_f32 v32, -v12, v28, v27                              // 000000323080: D6130020 246E390C
	v_fmac_f32_e32 v29, v33, v20                               // 000000323088: 563A2921
	v_fmac_f32_e32 v16, v25, v16                               // 00000032308C: 56202119
	v_mul_f32_e32 v25, v21, v14                                // 000000323090: 10321D15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000323094: BF870214
	v_fmac_f32_e32 v28, v32, v18                               // 000000323098: 56382520
	v_fma_f32 v13, -v13, v29, v24                              // 00000032309C: D613000D 24623B0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003230A4: BF870093
	v_fma_f32 v30, -v10, v25, v21                              // 0000003230A8: D613001E 2456330A
	v_fmac_f32_e32 v25, v30, v14                               // 0000003230B0: 56321D1E
	v_mul_f32_e32 v26, v22, v16                                // 0000003230B4: 10342116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003230B8: BF870112
	v_fma_f32 v10, -v10, v25, v21                              // 0000003230BC: D613000A 2456330A
	v_fma_f32 v31, -v11, v26, v22                              // 0000003230C4: D613001F 245A350B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003230CC: BF870112
	v_div_fmas_f32 v10, v10, v14, v25                          // 0000003230D0: D637000A 04661D0A
	v_fmac_f32_e32 v26, v31, v16                               // 0000003230D8: 5634211F
	s_mov_b32 vcc_lo, s3                                       // 0000003230DC: BEEA0003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003230E0: BF870112
	v_div_fixup_f32 v2, v10, v2, 1.0                           // 0000003230E4: D6270002 03CA050A
	v_fma_f32 v11, -v11, v26, v22                              // 0000003230EC: D613000B 245A350B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003230F4: BF8700A1
	v_div_fmas_f32 v11, v11, v16, v26                          // 0000003230F8: D637000B 046A210B
	s_mov_b32 vcc_lo, s4                                       // 000000323100: BEEA0004
	v_div_fixup_f32 v7, v11, v7, 1.0                           // 000000323104: D6270007 03CA0F0B
	v_bfe_u32 v11, v2, 16, 1                                   // 00000032310C: D610000B 02052102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323114: BF870091
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000323118: D6550002 03FE1702 00007FFF
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000323124: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 00000032312C: BF8903F7
	v_lshlrev_b32_e32 v1, 16, v1                               // 000000323130: 30020290
	v_fma_f32 v12, -v12, v28, v27                              // 000000323134: D613000C 246E390C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000032313C: BF8701C1
	v_div_fmas_f32 v10, v12, v18, v28                          // 000000323140: D637000A 0472250C
	s_mov_b32 vcc_lo, s5                                       // 000000323148: BEEA0005
	v_div_fmas_f32 v12, v13, v20, v29                          // 00000032314C: D637000C 0476290D
	v_cmp_ne_u32_e32 vcc_lo, 1, v23                            // 000000323154: 7C9A2E81
	v_div_fixup_f32 v8, v10, v8, 1.0                           // 000000323158: D6270008 03CA110A
	v_bfe_u32 v10, v7, 16, 1                                   // 000000323160: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000323168: BF8701A4
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 00000032316C: D6270009 03CA130C
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 000000323174: 8B6A6A7E
	v_bfe_u32 v11, v8, 16, 1                                   // 000000323178: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000323180: BF870233
	v_add3_u32 v7, v7, v10, 0x7fff                             // 000000323184: D6550007 03FE1507 00007FFF
	v_lshlrev_b32_e32 v10, 16, v19                             // 000000323190: 30142690
	v_bfe_u32 v12, v9, 16, 1                                   // 000000323194: D610000C 02052109
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000032319C: D6550008 03FE1708 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003231A8: BF870004
	v_and_b32_e32 v7, 0xffff0000, v7                           // 0000003231AC: 360E0EFF FFFF0000
	v_lshlrev_b32_e32 v11, 16, v17                             // 0000003231B4: 30162290
	v_fma_f32 v2, v2, v10, 0                                   // 0000003231B8: D6130002 02021502
	v_add3_u32 v9, v9, v12, 0x7fff                             // 0000003231C0: D6550009 03FE1909 00007FFF
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000003231CC: 361010FF FFFF0000
	v_lshlrev_b32_e32 v10, 16, v15                             // 0000003231D4: 30141E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003231D8: BF870093
	v_dual_fmac_f32 v2, v7, v11 :: v_dual_and_b32 v7, 0xffff0000, v9// 0000003231DC: C8241707 020612FF FFFF0000
	v_fmac_f32_e32 v2, v8, v10                                 // 0000003231E8: 56041508
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003231EC: BF870091
	v_fmac_f32_e32 v2, v7, v1                                  // 0000003231F0: 56040307
	v_mul_f32_e32 v1, 0x3e800000, v2                           // 0000003231F4: 100204FF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003231FC: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 000000323200: D6100002 02052101
	v_add3_u32 v7, v1, v2, 0x7fff                              // 000000323208: D6550007 03FE0501 00007FFF
	.long 0xd7000302                                           // 000000323214: D7000302
	v_cndmask_b32_e32 v1, 0x3000, v3, vcc_lo                   // 000000323218: 020206FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323220: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v4, s3                    // 000000323224: D5207C03 000E0880
	global_store_d16_hi_b16 v[2:3], v7, off offset:3072        // 00000032322C: DC960C00 007C0702
	s_cbranch_vccnz 13                                         // 000000323234: BFA4000D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x346c>
	.long 0xd7006a02                                           // 000000323238: D7006A02
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032323C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323240: BF870111
	v_add_co_ci_u32_e64 v3, null, s11, v6, vcc_lo              // 000000323244: D5207C03 01AA0C0B
	.long 0xd7006a02                                           // 00000032324C: D7006A02
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 000000323250: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323258: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000032325C: D5207C03 01AA0680
	global_store_b32 v[2:3], v1, off offset:2048               // 000000323264: DC6A0800 007C0102
	s_or_b32 exec_lo, exec_lo, s6                              // 00000032326C: 8C7E067E
	s_mov_b32 s25, 0                                           // 000000323270: BE990080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000323274: BF870009
	s_and_b32 vcc_lo, exec_lo, s25                             // 000000323278: 8B6A197E
	s_cbranch_vccz 542                                         // 00000032327C: BFA3021E <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3cf8>
	s_clause 0x3                                               // 000000323280: BF850003
	s_load_b32 s3, s[0:1], 0x148                               // 000000323284: F40000C0 F8000148
	s_load_b32 s4, s[0:1], 0xb0                                // 00000032328C: F4000100 F80000B0
	s_load_b32 s6, s[0:1], 0xf8                                // 000000323294: F4000180 F80000F8
	s_load_b32 s7, s[0:1], 0x140                               // 00000032329C: F40001C0 F8000140
	s_sub_i32 s5, s2, s24                                      // 0000003232A4: 81851802
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000003232A8: 32060085
	v_dual_mov_b32 v24, 0 :: v_dual_and_b32 v15, 31, v0        // 0000003232AC: CA240080 180E009F
	s_waitcnt lgkmcnt(0)                                       // 0000003232B4: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 0000003232B8: BF028103
	s_cselect_b32 s8, -1, 0                                    // 0000003232BC: 980880C1
	s_cmp_ge_i32 s5, s4                                        // 0000003232C0: BF030405
	s_cselect_b32 s4, -1, 0                                    // 0000003232C4: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003232C8: BF870009
	s_and_b32 s4, s8, s4                                       // 0000003232CC: 8B040408
	s_cmp_gt_i32 s3, 2                                         // 0000003232D0: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 0000003232D4: D5010001 00110280
	s_cselect_b32 s8, -1, 0                                    // 0000003232DC: 980880C1
	s_cmp_ge_i32 s5, s6                                        // 0000003232E0: BF030605
	s_cselect_b32 s6, -1, 0                                    // 0000003232E4: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003232E8: BF870009
	s_and_b32 s4, s8, s6                                       // 0000003232EC: 8B040608
	s_cmp_gt_i32 s3, 3                                         // 0000003232F0: BF028303
	v_readfirstlane_b32 s6, v1                                 // 0000003232F4: 7E0C0501
	s_cselect_b32 s3, -1, 0                                    // 0000003232F8: 980380C1
	s_cmp_ge_i32 s5, s7                                        // 0000003232FC: BF030705
	s_cselect_b32 s7, -1, 0                                    // 000000323300: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000323304: BF8704D9
	s_and_b32 s3, s3, s7                                       // 000000323308: 8B030703
	s_and_b32 s4, s4, exec_lo                                  // 00000032330C: 8B047E04
	s_cselect_b32 s4, 2, s6                                    // 000000323310: 98040682
	s_and_b32 s3, s3, exec_lo                                  // 000000323314: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000323318: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000032331C: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000323320: BF870009
	s_add_u32 s10, s0, s3                                      // 000000323324: 800A0300
	s_addc_u32 s11, s1, 0                                      // 000000323328: 820B8001
	s_clause 0x1                                               // 00000032332C: BF850001
	s_load_b64 s[6:7], s[10:11], 0x58                          // 000000323330: F4040185 F8000058
	s_load_b32 s3, s[10:11], 0x68                              // 000000323338: F40000C5 F8000068
	s_add_u32 s8, s10, 40                                      // 000000323340: 8008A80A
	s_addc_u32 s9, s11, 0                                      // 000000323344: 8209800B
	s_load_b64 s[10:11], s[10:11], 0x28                        // 000000323348: F4040285 F8000028
	s_waitcnt lgkmcnt(0)                                       // 000000323350: BF89FC07
	.long 0xd4510013                                           // 000000323354: D4510013
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 000000323358: 02011206
	s_and_b32 s4, s19, exec_lo                                 // 00000032335C: 8B047E13
	s_cselect_b32 s18, 8, 2                                    // 000000323360: 98128288
	s_cselect_b32 s24, 3, 1                                    // 000000323364: 98188183
	v_cvt_f32_ubyte0_e32 v1, s18                               // 000000323368: 7E022212
	s_sub_i32 s26, s5, s3                                      // 00000032336C: 819A0305
	s_add_i32 s3, s18, -1                                      // 000000323370: 8103C112
	s_ashr_i32 s27, s26, 31                                    // 000000323374: 861B9F1A
	s_and_b32 s4, s19, exec_lo                                 // 000000323378: 8B047E13
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000032337C: 7E025701
	s_cselect_b32 s25, 0, 2                                    // 000000323380: 98198280
	s_ashr_i32 s4, s23, 31                                     // 000000323384: 86049F17
	s_lshl_b64 s[26:27], s[26:27], s25                         // 000000323388: 849A191A
	s_lshr_b32 s4, s4, 28                                      // 00000032338C: 85049C04
	v_lshrrev_b32_e32 v13, s24, v3                             // 000000323390: 321A0618
	s_add_u32 s28, s22, s4                                     // 000000323394: 801C0416
	s_addc_u32 s29, s23, 0                                     // 000000323398: 821D8017
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032339C: BF870299
	s_ashr_i64 s[28:29], s[28:29], 4                           // 0000003233A0: 869C841C
	v_readfirstlane_b32 s30, v1                                // 0000003233A4: 7E3C0501
	.long 0xd7001a01                                           // 0000003233A8: D7001A01
	v_cndmask_b32_e32 v1, s26, v13, vcc_lo                     // 0000003233AC: 02021A1A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003233B0: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, 0, s26                  // 0000003233B4: D5207C02 0069001B
	s_mul_f32 s4, s30, 0x4f7ffffe                              // 0000003233BC: A204FF1E 4F7FFFFE
	s_add_u32 s30, s28, s22                                    // 0000003233C4: 801E161C
	s_addc_u32 s29, s29, s23                                   // 0000003233C8: 821D171D
	s_sub_i32 s31, 0, s18                                      // 0000003233CC: 819F1280
	s_cvt_u32_f32 s4, s4                                       // 0000003233D0: BE846704
	s_add_i32 s33, s3, s28                                     // 0000003233D4: 81211C03
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 0000003233D8: 7CA80206
	s_abs_i32 s34, s33                                         // 0000003233DC: BEA21521
	s_mul_i32 s31, s31, s4                                     // 0000003233E0: 961F041F
	s_ashr_i32 s27, s33, 31                                    // 0000003233E4: 861B9F21
	s_mul_hi_u32 s31, s4, s31                                  // 0000003233E8: 969F1F04
	v_dual_cndmask_b32 v1, 0, v1 :: v_dual_and_b32 v14, s3, v3 // 0000003233EC: CA640280 010E0603
	s_add_i32 s4, s4, s31                                      // 0000003233F4: 81041F04
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 0000003233F8: 02040480
	s_mul_hi_u32 s4, s34, s4                                   // 0000003233FC: 96840422
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000323400: BF870009
	s_mul_i32 s26, s4, s18                                     // 000000323404: 961A1204
	s_add_i32 s31, s4, 1                                       // 000000323408: 811F8104
	s_sub_i32 s26, s34, s26                                    // 00000032340C: 819A1A22
	.long 0xd72c0004                                           // 000000323410: D72C0004
	v_cndmask_b32_e32 v0, v2, v30, vcc_lo                      // 000000323414: 02003D02
	s_sub_i32 s33, s26, s18                                    // 000000323418: 81A1121A
	s_cmp_ge_u32 s26, s18                                      // 00000032341C: BF09121A
	.long 0xd72c0006                                           // 000000323420: D72C0006
	v_cndmask_b32_e32 v0, v1, v29, vcc_lo                      // 000000323424: 02003B01
	s_cselect_b32 s4, s31, s4                                  // 000000323428: 9804041F
	s_cselect_b32 s26, s33, s26                                // 00000032342C: 981A1A21
	s_add_i32 s31, s4, 1                                       // 000000323430: 811F8104
	s_cmp_ge_u32 s26, s18                                      // 000000323434: BF09121A
	v_mad_u64_u32 v[9:10], null, v1, s30, s[10:11]             // 000000323438: D6FE7C09 00283D01
	s_cselect_b32 s3, s31, s4                                  // 000000323440: 9803041F
	v_mov_b32_e32 v1, 0                                        // 000000323444: 7E020280
	s_xor_b32 s3, s3, s27                                      // 000000323448: 8D031B03
	v_mov_b32_e32 v2, 0                                        // 00000032344C: 7E040280
	s_sub_i32 s3, s3, s27                                      // 000000323450: 81831B03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000323454: BF8701D9
	.long 0xd72c0005                                           // 000000323458: D72C0005
	v_cndmask_b32_e32 v0, v14, v3, vcc_lo                      // 00000032345C: 0200070E
	v_mov_b32_e32 v3, 0                                        // 000000323460: 7E060280
	v_add3_u32 v10, v4, v10, v6                                // 000000323464: D655000A 041A1504
	.long 0xd7006a12                                           // 00000032346C: D7006A12
	v_cndmask_b32_e32 v0, v9, v22, vcc_lo                      // 000000323470: 02002D09
	v_mov_b32_e32 v4, 0                                        // 000000323474: 7E080280
	v_add_co_ci_u32_e64 v19, null, s23, v10, vcc_lo            // 000000323478: D5207C13 01AA1417
	v_add_nc_u32_e32 v7, s3, v5                                // 000000323480: 4A0E0A03
	v_add_nc_u32_e32 v16, v5, v15                              // 000000323484: 4A201F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323488: BF870092
	v_min_i32_e32 v17, s28, v7                                 // 00000032348C: 22220E1C
	.long 0xd4410004                                           // 000000323490: D4410004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 000000323494: 02022310
	s_and_saveexec_b32 s3, s4                                  // 000000323498: BE832004
	s_cbranch_execz 19                                         // 00000032349C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x36ec>
	v_lshlrev_b32_e32 v1, 4, v16                               // 0000003234A0: 30022084
	v_and_b32_e32 v3, -4, v16                                  // 0000003234A4: 360620C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003234A8: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000003234AC: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000003234B0: 3408069F
	.long 0xd7006a01                                           // 0000003234B4: D7006A01
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000003234B8: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003234BC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, vcc_lo              // 0000003234C0: D5207C02 01AA050A
	.long 0xd7006a06                                           // 0000003234C8: D7006A06
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 0000003234CC: 02020712
	v_add_co_ci_u32_e64 v7, null, v19, v4, vcc_lo              // 0000003234D0: D5207C07 01AA0913
	s_clause 0x1                                               // 0000003234D8: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 0000003234DC: DC5E0000 017C0001
	global_load_b32 v24, v[6:7], off                           // 0000003234E4: DC520000 187C0006
	s_or_b32 exec_lo, exec_lo, s3                              // 0000003234EC: 8C7E037E
	.long 0xd44a0003                                           // 0000003234F0: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000003234F4: 02020080
	s_and_saveexec_b32 s10, s3                                 // 0000003234F8: BE8A2003
	s_cbranch_execz 20                                         // 0000003234FC: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3750>
	v_mov_b32_e32 v6, 0                                        // 000000323500: 7E0C0280
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 000000323504: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 00000032350C: BF8903F7
	buffer_gl1_inv                                             // 000000323510: E0B00000 00000000
	buffer_gl0_inv                                             // 000000323518: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 000000323520: 7CB60E0E
	s_cbranch_vccnz 10                                         // 000000323524: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3750>
	s_sleep 1                                                  // 000000323528: BF830001
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 00000032352C: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 000000323534: BF8903F7
	buffer_gl1_inv                                             // 000000323538: E0B00000 00000000
	buffer_gl0_inv                                             // 000000323540: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 000000323548: 7CB80E0E
	s_cbranch_vccnz 65526                                      // 00000032354C: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3728>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000323550: 8C7E0A7E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000323554: CA100080 15160080
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v20, 0             // 00000032355C: CA100080 17140080
	s_waitcnt vmcnt(0)                                         // 000000323564: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 000000323568: BC7C0000
	s_barrier                                                  // 00000032356C: BFBD0000
	buffer_gl0_inv                                             // 000000323570: E0AC0000 00000000
	buffer_gl1_inv                                             // 000000323578: E0B00000 00000000
	buffer_gl0_inv                                             // 000000323580: E0AC0000 00000000
	s_and_saveexec_b32 s26, s4                                 // 000000323588: BE9A2004
	s_cbranch_execz 745                                        // 00000032358C: BFA502E9 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4334>
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 000000323590: CA220080 17061E84
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000323598: CA100080 14140080
	v_mov_b32_e32 v22, 0                                       // 0000003235A0: 7E2C0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003235A4: BF870003
	v_lshl_add_u32 v11, v5, 4, v6                              // 0000003235A8: D646000B 04190905
	s_mul_i32 s4, s23, 6                                       // 0000003235B0: 96048617
	s_mul_hi_u32 s14, s22, 6                                   // 0000003235B4: 968E8616
	s_lshl_b64 s[10:11], s[22:23], 2                           // 0000003235B8: 848A8216
	s_add_i32 s27, s14, s4                                     // 0000003235BC: 811B040E
	s_mul_i32 s29, s22, 6                                      // 0000003235C0: 961D8616
	s_mov_b32 s28, 0                                           // 0000003235C4: BE9C0080
	s_lshl_b64 s[14:15], s[22:23], 1                           // 0000003235C8: 848E8116
	s_branch 294                                               // 0000003235CC: BFA00126 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3c68>
	s_or_b32 exec_lo, exec_lo, s22                             // 0000003235D0: 8C7E167E
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000003235D4: 3418169F
	v_cvt_f32_ubyte1_e32 v59, v1                               // 0000003235D8: 7E762501
	v_cvt_f32_ubyte2_e32 v60, v1                               // 0000003235DC: 7E782701
	v_cvt_f32_ubyte0_e32 v61, v2                               // 0000003235E0: 7E7A2302
	v_cvt_f32_ubyte1_e32 v62, v2                               // 0000003235E4: 7E7C2502
	.long 0xd73c000b                                           // 0000003235E8: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000003235EC: 02021681
	v_cvt_f32_ubyte2_e32 v63, v2                               // 0000003235F0: 7E7E2702
	v_cvt_f32_ubyte3_e32 v64, v2                               // 0000003235F4: 7E802902
	v_cvt_f32_ubyte0_e32 v65, v3                               // 0000003235F8: 7E822303
	v_cvt_f32_ubyte1_e32 v66, v3                               // 0000003235FC: 7E842503
	v_cvt_f32_ubyte2_e32 v67, v3                               // 000000323600: 7E862703
	.long 0xd700040b                                           // 000000323604: D700040B
	v_cndmask_b32_e32 v1, s20, v11, vcc_lo                     // 000000323608: 02021614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032360C: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s21, v12, s4                // 000000323610: D5207C0C 00121815
	v_cvt_f32_ubyte3_e32 v68, v3                               // 000000323618: 7E882903
	.long 0xd700042f                                           // 00000032361C: D700042F
	v_cndmask_b32_e32 v0, v11, v14, vcc_lo                     // 000000323620: 02001D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000323624: BF8700A1
	v_add_co_ci_u32_e64 v48, null, s15, v12, s4                // 000000323628: D5207C30 0012180F
	.long 0xd7000433                                           // 000000323630: D7000433
	v_cndmask_b32_e32 v0, v11, v10, vcc_lo                     // 000000323634: 0200150B
	v_add_co_ci_u32_e64 v52, null, s11, v12, s4                // 000000323638: D5207C34 0012180B
	.long 0xd7000437                                           // 000000323640: D7000437
	v_cndmask_b32_e32 v0, v11, v29, vcc_lo                     // 000000323644: 02003B0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323648: BF870001
	v_add_co_ci_u32_e64 v56, null, s27, v12, s4                // 00000032364C: D5207C38 0012181B
	s_clause 0x7                                               // 000000323654: BF850007
	global_load_b128 v[27:30], v[11:12], off                   // 000000323658: DC5E0000 1B7C000B
	global_load_b128 v[31:34], v[47:48], off                   // 000000323660: DC5E0000 1F7C002F
	global_load_b128 v[35:38], v[51:52], off                   // 000000323668: DC5E0000 237C0033
	global_load_b128 v[39:42], v[55:56], off                   // 000000323670: DC5E0000 277C0037
	global_load_b128 v[43:46], v[11:12], off offset:16         // 000000323678: DC5E0010 2B7C000B
	global_load_b128 v[47:50], v[47:48], off offset:16         // 000000323680: DC5E0010 2F7C002F
	global_load_b128 v[51:54], v[51:52], off offset:16         // 000000323688: DC5E0010 337C0033
	global_load_b128 v[55:58], v[55:56], off offset:16         // 000000323690: DC5E0010 377C0037
	v_cvt_f32_ubyte0_e32 v11, v1                               // 000000323698: 7E162301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 00000032369C: 7E022901
	v_cvt_f32_ubyte0_e32 v69, v4                               // 0000003236A0: 7E8A2304
	v_cvt_f32_ubyte1_e32 v70, v4                               // 0000003236A4: 7E8C2504
	v_cvt_f32_ubyte2_e32 v71, v4                               // 0000003236A8: 7E8E2704
	v_cvt_f32_ubyte3_e32 v72, v4                               // 0000003236AC: 7E902904
	s_waitcnt vmcnt(9)                                         // 0000003236B0: BF8927F7
	v_mov_b32_e32 v2, v6                                       // 0000003236B4: 7E040306
	v_fma_mix_f32 v6, v11, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236B8: CC206006 1462310B
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 0000003236C0: CA100108 04020107
	v_fma_mix_f32 v7, v59, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236C8: CC206007 1462313B
	v_fma_mix_f32 v8, v60, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236D0: CC206008 1462313C
	v_fma_mix_f32 v1, v1, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236D8: CC206001 14623101
	v_fma_mix_f32 v59, v61, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236E0: CC20603B 1462313D
	v_fma_mix_f32 v60, v62, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236E8: CC20603C 1462313E
	v_fma_mix_f32 v61, v63, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236F0: CC20603D 1462313F
	v_fma_mix_f32 v63, v64, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003236F8: CC20603F 14623140
	v_fma_mix_f32 v64, v65, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323700: CC206040 14623141
	v_fma_mix_f32 v65, v66, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323708: CC206041 14623142
	v_fma_mix_f32 v66, v67, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323710: CC206042 14623143
	v_fma_mix_f32 v68, v68, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323718: CC206044 14623144
	v_fma_mix_f32 v69, v69, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323720: CC206045 14623145
	v_fma_mix_f32 v70, v70, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323728: CC206046 14623146
	v_fma_mix_f32 v71, v71, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323730: CC206047 14623147
	v_fma_mix_f32 v24, v72, v24, v24 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000323738: CC206018 14623148
	v_bfe_u32 v72, v6, 16, 1                                   // 000000323740: D6100048 02052106
	v_bfe_u32 v74, v7, 16, 1                                   // 000000323748: D610004A 02052107
	v_bfe_u32 v75, v8, 16, 1                                   // 000000323750: D610004B 02052108
	.long 0x7f183880                                           // 000000323758: 7F183880
	v_bfe_u32 v76, v1, 16, 1                                   // 00000032375C: D610004C 02052101
	v_add3_u32 v6, v6, v72, 0x7fff                             // 000000323764: D6550006 03FE9106 00007FFF
	v_bfe_u32 v77, v59, 16, 1                                  // 000000323770: D610004D 0205213B
	v_add3_u32 v7, v7, v74, 0x7fff                             // 000000323778: D6550007 03FE9507 00007FFF
	v_add3_u32 v8, v8, v75, 0x7fff                             // 000000323784: D6550008 03FE9708 00007FFF
	.long 0x7f16398c                                           // 000000323790: 7F16398C
	.long 0x7e183986                                           // 000000323794: 7E183986
	v_bfe_u32 v78, v60, 16, 1                                  // 000000323798: D610004E 0205213C
	v_bfe_u32 v79, v61, 16, 1                                  // 0000003237A0: D610004F 0205213D
	v_add3_u32 v1, v1, v76, 0x7fff                             // 0000003237A8: D6550001 03FE9901 00007FFF
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000003237B4: D655003B 03FE9B3B 00007FFF
	.long 0x7e163988                                           // 0000003237C0: 7E163988
	v_and_or_b32 v6, 0xffff0000, v7, v12                       // 0000003237C4: D6570006 04320EFF FFFF0000
	v_bfe_u32 v80, v63, 16, 1                                  // 0000003237D0: D6100050 0205213F
	v_bfe_u32 v81, v64, 16, 1                                  // 0000003237D8: D6100051 02052140
	v_add3_u32 v60, v60, v78, 0x7fff                           // 0000003237E0: D655003C 03FE9D3C 00007FFF
	v_add3_u32 v61, v61, v79, 0x7fff                           // 0000003237EC: D655003D 03FE9F3D 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v11                       // 0000003237F8: D6570001 042E02FF FFFF0000
	.long 0x7e1839bb                                           // 000000323804: 7E1839BB
	.long 0x7f7c398c                                           // 000000323808: 7F7C398C
	v_bfe_u32 v82, v65, 16, 1                                  // 00000032380C: D6100052 02052141
	v_bfe_u32 v83, v66, 16, 1                                  // 000000323814: D6100053 02052142
	v_add3_u32 v63, v63, v80, 0x7fff                           // 00000032381C: D655003F 03FEA13F 00007FFF
	v_add3_u32 v64, v64, v81, 0x7fff                           // 000000323828: D6550040 03FEA340 00007FFF
	.long 0x7e7c39bd                                           // 000000323834: 7E7C39BD
	v_bfe_u32 v84, v68, 16, 1                                  // 000000323838: D6100054 02052144
	v_bfe_u32 v85, v69, 16, 1                                  // 000000323840: D6100055 02052145
	v_add3_u32 v65, v65, v82, 0x7fff                           // 000000323848: D6550041 03FEA541 00007FFF
	v_add3_u32 v66, v66, v83, 0x7fff                           // 000000323854: D6550042 03FEA742 00007FFF
	v_and_or_b32 v7, 0xffff0000, v63, v62                      // 000000323860: D6570007 04FA7EFF FFFF0000
	.long 0x7f86398c                                           // 00000032386C: 7F86398C
	v_bfe_u32 v86, v70, 16, 1                                  // 000000323870: D6100056 02052146
	v_bfe_u32 v87, v71, 16, 1                                  // 000000323878: D6100057 02052147
	v_add3_u32 v68, v68, v84, 0x7fff                           // 000000323880: D6550044 03FEA944 00007FFF
	v_add3_u32 v69, v69, v85, 0x7fff                           // 00000032388C: D6550045 03FEAB45 00007FFF
	.long 0x7e8639c2                                           // 000000323898: 7E8639C2
	v_bfe_u32 v88, v24, 16, 1                                  // 00000032389C: D6100058 02052118
	v_add3_u32 v70, v70, v86, 0x7fff                           // 0000003238A4: D6550046 03FEAD46 00007FFF
	v_add3_u32 v71, v71, v87, 0x7fff                           // 0000003238B0: D6550047 03FEAF47 00007FFF
	.long 0x7f92398c                                           // 0000003238BC: 7F92398C
	v_and_or_b32 v8, 0xffff0000, v68, v67                      // 0000003238C0: D6570008 050E88FF FFFF0000
	v_add3_u32 v24, v24, v88, 0x7fff                           // 0000003238CC: D6550018 03FEB118 00007FFF
	s_and_b32 s4, exec_lo, vcc_lo                              // 0000003238D8: 8B046A7E
	.long 0x7e9239c7                                           // 0000003238DC: 7E9239C7
	s_or_b32 s28, s4, s28                                      // 0000003238E0: 8C1C1C04
	s_waitcnt vmcnt(7)                                         // 0000003238E4: BF891FF7
	v_dot2_f32_bf16 v11, v27, v6, 0                            // 0000003238E8: CC1A400B 1A020D1B
	s_waitcnt vmcnt(6)                                         // 0000003238F0: BF891BF7
	v_dot2_f32_bf16 v27, v31, v6, 0                            // 0000003238F4: CC1A401B 1A020D1F
	s_waitcnt vmcnt(5)                                         // 0000003238FC: BF8917F7
	v_dot2_f32_bf16 v31, v35, v6, 0                            // 000000323900: CC1A401F 1A020D23
	s_waitcnt vmcnt(4)                                         // 000000323908: BF8913F7
	v_dot2_f32_bf16 v6, v39, v6, 0                             // 00000032390C: CC1A4006 1A020D27
	v_and_or_b32 v35, 0xffff0000, v60, v12                     // 000000323914: D6570023 043278FF FFFF0000
	v_dot2_f32_bf16 v11, v28, v1, v11                          // 000000323920: CC1A400B 1C2E031C
	v_dot2_f32_bf16 v27, v32, v1, v27                          // 000000323928: CC1A401B 1C6E0320
	v_dot2_f32_bf16 v28, v36, v1, v31                          // 000000323930: CC1A401C 1C7E0324
	v_dot2_f32_bf16 v1, v40, v1, v6                            // 000000323938: CC1A4001 1C1A0328
	.long 0x7e1839c0                                           // 000000323940: 7E1839C0
	v_dot2_f32_bf16 v6, v29, v35, v11                          // 000000323944: CC1A4006 1C2E471D
	v_dot2_f32_bf16 v11, v33, v35, v27                         // 00000032394C: CC1A400B 1C6E4721
	v_dot2_f32_bf16 v27, v37, v35, v28                         // 000000323954: CC1A401B 1C724725
	v_dot2_f32_bf16 v1, v41, v35, v1                           // 00000032395C: CC1A4001 1C064729
	v_and_or_b32 v28, 0xffff0000, v65, v12                     // 000000323964: D657001C 043282FF FFFF0000
	v_dot2_f32_bf16 v6, v30, v7, v6                            // 000000323970: CC1A4006 1C1A0F1E
	v_dot2_f32_bf16 v11, v34, v7, v11                          // 000000323978: CC1A400B 1C2E0F22
	v_dot2_f32_bf16 v27, v38, v7, v27                          // 000000323980: CC1A401B 1C6E0F26
	v_dot2_f32_bf16 v1, v42, v7, v1                            // 000000323988: CC1A4001 1C060F2A
	.long 0x7e1839c5                                           // 000000323990: 7E1839C5
	s_waitcnt vmcnt(3)                                         // 000000323994: BF890FF7
	v_dot2_f32_bf16 v6, v43, v28, v6                           // 000000323998: CC1A4006 1C1A392B
	s_waitcnt vmcnt(2)                                         // 0000003239A0: BF890BF7
	v_dot2_f32_bf16 v7, v47, v28, v11                          // 0000003239A4: CC1A4007 1C2E392F
	s_waitcnt vmcnt(1)                                         // 0000003239AC: BF8907F7
	v_dot2_f32_bf16 v11, v51, v28, v27                         // 0000003239B0: CC1A400B 1C6E3933
	s_waitcnt vmcnt(0)                                         // 0000003239B8: BF8903F7
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 0000003239BC: CC1A4001 1C063937
	v_and_or_b32 v12, 0xffff0000, v70, v12                     // 0000003239C4: D657000C 04328CFF FFFF0000
	v_dot2_f32_bf16 v6, v44, v8, v6                            // 0000003239D0: CC1A4006 1C1A112C
	v_dot2_f32_bf16 v7, v48, v8, v7                            // 0000003239D8: CC1A4007 1C1E1130
	v_dot2_f32_bf16 v11, v52, v8, v11                          // 0000003239E0: CC1A400B 1C2E1134
	v_dot2_f32_bf16 v1, v56, v8, v1                            // 0000003239E8: CC1A4001 1C061138
	v_and_or_b32 v8, 0xffff0000, v24, v73                      // 0000003239F0: D6570008 052630FF FFFF0000
	v_dot2_f32_bf16 v6, v45, v12, v6                           // 0000003239FC: CC1A4006 1C1A192D
	v_dot2_f32_bf16 v7, v49, v12, v7                           // 000000323A04: CC1A4007 1C1E1931
	v_dot2_f32_bf16 v11, v53, v12, v11                         // 000000323A0C: CC1A400B 1C2E1935
	v_dot2_f32_bf16 v12, v57, v12, v1                          // 000000323A14: CC1A400C 1C061939
	v_mov_b32_e32 v1, v5                                       // 000000323A1C: 7E020305
	v_dot2_f32_bf16 v5, v46, v8, v6                            // 000000323A20: CC1A4005 1C1A112E
	v_dot2_f32_bf16 v6, v50, v8, v7                            // 000000323A28: CC1A4006 1C1E1132
	v_dot2_f32_bf16 v7, v54, v8, v11                           // 000000323A30: CC1A4007 1C2E1136
	v_dot2_f32_bf16 v8, v58, v8, v12                           // 000000323A38: CC1A4008 1C32113A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000323A40: BF870194
	v_dual_mov_b32 v11, v25 :: v_dual_add_f32 v20, v20, v5     // 000000323A44: CA080119 0B140B14
	v_dual_add_f32 v23, v23, v6 :: v_dual_add_f32 v22, v22, v7 // 000000323A4C: C9080D17 17160F16
	s_delay_alu instid0(VALU_DEP_3)                            // 000000323A54: BF870003
	v_dual_add_f32 v21, v21, v8 :: v_dual_mov_b32 v24, v26     // 000000323A58: C9101115 1518011A
	s_and_not1_b32 exec_lo, exec_lo, s28                       // 000000323A60: 917E1C7E
	s_cbranch_execz 434                                        // 000000323A64: BFA501B2 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4330>
	v_add_nc_u32_e32 v16, 32, v16                              // 000000323A68: 4A2020A0
	v_add_nc_u32_e32 v25, 0x200, v11                           // 000000323A6C: 4A3216FF 00000200
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000323A74: BF8704A2
	v_cmp_ge_i32_e32 vcc_lo, v16, v17                          // 000000323A78: 7C8C2310
	s_and_saveexec_b32 s4, vcc_lo                              // 000000323A7C: BE84206A
	s_xor_b32 s4, exec_lo, s4                                  // 000000323A80: 8D04047E
	v_add_nc_u32_e32 v25, 0x200, v11                           // 000000323A84: 4A3216FF 00000200
	s_or_saveexec_b32 s22, s4                                  // 000000323A8C: BE962204
	v_dual_mov_b32 v26, v24 :: v_dual_mov_b32 v5, v1           // 000000323A90: CA100118 1A040101
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000323A98: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 000000323AA0: 7E100304
	s_xor_b32 exec_lo, exec_lo, s22                            // 000000323AA4: 8D7E167E
	s_cbranch_execz 65225                                      // 000000323AA8: BFA5FEC9 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x37d0>
	v_and_b32_e32 v7, -4, v16                                  // 000000323AAC: 360E20C4
	v_ashrrev_i32_e32 v6, 31, v25                              // 000000323AB0: 340C329F
	.long 0xd7000405                                           // 000000323AB4: D7000405
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 000000323AB8: 02023309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000323ABC: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 000000323AC0: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s4                  // 000000323AC4: D5207C06 00120D0A
	.long 0xd700041a                                           // 000000323ACC: D700041A
	v_cndmask_b32_e32 v1, v18, v7, vcc_lo                      // 000000323AD0: 02020F12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323AD4: BF870001
	v_add_co_ci_u32_e64 v27, null, v19, v8, s4                 // 000000323AD8: D5207C1B 00121113
	s_clause 0x1                                               // 000000323AE0: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 000000323AE4: DC5E0000 057C0005
	global_load_b32 v26, v[26:27], off                         // 000000323AEC: DC520000 1A7C001A
	s_branch 65206                                             // 000000323AF4: BFA0FEB6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x37d0>
	s_mov_b32 s3, 0                                            // 000000323AF8: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000323AFC: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 000000323B00: 916A037E
	s_cbranch_vccnz 950                                        // 000000323B04: BFA403B6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4be0>
	s_load_b256 s[4:11], s[0:1], null                          // 000000323B08: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000323B10: 86039F02
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, v0              // 000000323B14: CA100080 02040100
	s_lshr_b32 s14, s3, 30                                     // 000000323B1C: 850E9E03
	s_load_b32 s1, s[0:1], 0x1b4                               // 000000323B20: F4000040 F80001B4
	s_add_i32 s16, s2, s14                                     // 000000323B28: 81100E02
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000323B2C: 848E8202
	s_ashr_i32 s3, s16, 2                                      // 000000323B30: 86038210
	s_mul_i32 s0, s2, 0x1400                                   // 000000323B34: 9600FF02 00001400
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, v0              // 000000323B3C: CA100080 04000100
	s_waitcnt lgkmcnt(0)                                       // 000000323B44: BF89FC07
	s_add_u32 s8, s8, s14                                      // 000000323B48: 80080E08
	s_addc_u32 s9, s9, s15                                     // 000000323B4C: 82090F09
	s_add_u32 s0, s4, s0                                       // 000000323B50: 80000004
	global_load_b32 v3, v2, s[8:9]                             // 000000323B54: DC520000 03080002
	s_mul_hi_i32 s8, s2, 0x1400                                // 000000323B5C: 9708FF02 00001400
	s_mul_i32 s9, s3, 0x1400                                   // 000000323B64: 9609FF03 00001400
	s_addc_u32 s8, s5, s8                                      // 000000323B6C: 82080805
	s_mul_hi_i32 s14, s3, 0x1400                               // 000000323B70: 970EFF03 00001400
	s_add_u32 s6, s6, s9                                       // 000000323B78: 80060906
	s_addc_u32 s7, s7, s14                                     // 000000323B7C: 82070E07
	s_and_b32 s1, s1, 0xffff                                   // 000000323B80: 8B01FF01 0000FFFF
	s_mov_b32 s9, 0                                            // 000000323B88: BE890080
	s_set_inst_prefetch_distance 0x1                           // 000000323B8C: BF840001
	s_nop 0                                                    // 000000323B90: BF800000
	s_nop 0                                                    // 000000323B94: BF800000
	s_nop 0                                                    // 000000323B98: BF800000
	s_nop 0                                                    // 000000323B9C: BF800000
	s_nop 0                                                    // 000000323BA0: BF800000
	s_nop 0                                                    // 000000323BA4: BF800000
	s_nop 0                                                    // 000000323BA8: BF800000
	s_nop 0                                                    // 000000323BAC: BF800000
	s_nop 0                                                    // 000000323BB0: BF800000
	s_nop 0                                                    // 000000323BB4: BF800000
	s_nop 0                                                    // 000000323BB8: BF800000
	s_nop 0                                                    // 000000323BBC: BF800000
	.long 0xd73c0006                                           // 000000323BC0: D73C0006
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000323BC4: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323BC8: BF870091
	.long 0xd7006a08                                           // 000000323BCC: D7006A08
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 000000323BD0: 02020C00
	v_add_co_ci_u32_e64 v9, null, s8, v7, vcc_lo               // 000000323BD4: D5207C09 01AA0E08
	.long 0xd7006a06                                           // 000000323BDC: D7006A06
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000323BE0: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323BE4: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, vcc_lo               // 000000323BE8: D5207C07 01AA0E07
	global_load_u16 v10, v[8:9], off                           // 000000323BF0: DC4A0000 0A7C0008
	global_load_u16 v6, v[6:7], off                            // 000000323BF8: DC4A0000 067C0006
	s_waitcnt vmcnt(1)                                         // 000000323C00: BF8907F7
	v_lshlrev_b32_e32 v7, 16, v10                              // 000000323C04: 300E1490
	s_waitcnt vmcnt(0)                                         // 000000323C08: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000323C0C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323C10: BF870091
	v_fmac_f32_e32 v7, v3, v6                                  // 000000323C14: 560E0D03
	v_bfe_u32 v6, v7, 16, 1                                    // 000000323C18: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323C20: BF870091
	v_add3_u32 v6, v7, v6, 0x7fff                              // 000000323C24: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v6                           // 000000323C30: 360E0CFF FFFF0000
	v_add_nc_u32_e32 v1, s1, v1                                // 000000323C38: 4A020201
	global_store_d16_hi_b16 v[8:9], v6, off                    // 000000323C3C: DC960000 007C0608
	v_fmac_f32_e32 v4, v7, v7                                  // 000000323C44: 56080F07
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v1                         // 000000323C48: 7C9202FF 000009FF
	s_or_b32 s9, vcc_lo, s9                                    // 000000323C50: 8C09096A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000323C54: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000323C58: 917E097E
	s_cbranch_execnz 65496                                     // 000000323C5C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3dc0>
	s_set_inst_prefetch_distance 0x2                           // 000000323C60: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 000000323C64: 8C7E097E
	v_lshlrev_b32_e32 v1, 2, v0                                // 000000323C68: 30020082
	s_lshr_b32 s6, s1, 1                                       // 000000323C6C: 85068101
	s_mov_b32 s0, 0                                            // 000000323C70: BE800080
	ds_store_b32 v1, v4                                        // 000000323C74: D8340000 00000401
	s_waitcnt lgkmcnt(0)                                       // 000000323C7C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000323C80: BC7C0000
	s_barrier                                                  // 000000323C84: BFBD0000
	s_branch 17                                                // 000000323C88: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ed0>
	s_nop 0                                                    // 000000323C8C: BF800000
	s_nop 0                                                    // 000000323C90: BF800000
	s_nop 0                                                    // 000000323C94: BF800000
	s_nop 0                                                    // 000000323C98: BF800000
	s_nop 0                                                    // 000000323C9C: BF800000
	s_nop 0                                                    // 000000323CA0: BF800000
	s_nop 0                                                    // 000000323CA4: BF800000
	s_nop 0                                                    // 000000323CA8: BF800000
	s_nop 0                                                    // 000000323CAC: BF800000
	s_nop 0                                                    // 000000323CB0: BF800000
	s_nop 0                                                    // 000000323CB4: BF800000
	s_nop 0                                                    // 000000323CB8: BF800000
	s_nop 0                                                    // 000000323CBC: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 000000323CC0: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 000000323CC4: BF89FC07
	s_barrier                                                  // 000000323CC8: BFBD0000
	s_lshr_b32 s6, s6, 1                                       // 000000323CCC: 85068106
	buffer_gl0_inv                                             // 000000323CD0: E0AC0000 00000000
	s_cbranch_scc0 15                                          // 000000323CD8: BFA1000F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3f18>
	s_mov_b32 s7, exec_lo                                      // 000000323CDC: BE87007E
	.long 0xd4cc007e                                           // 000000323CE0: D4CC007E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000323CE4: 02020006
	s_cbranch_execz 65525                                      // 000000323CE8: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ec0>
	v_lshl_add_u32 v2, s6, 2, v1                               // 000000323CEC: D6460002 04050406
	ds_load_b32 v2, v2                                         // 000000323CF4: D8D80000 02000002
	ds_load_b32 v3, v1                                         // 000000323CFC: D8D80000 03000001
	s_waitcnt lgkmcnt(0)                                       // 000000323D04: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000323D08: 06040702
	ds_store_b32 v1, v2                                        // 000000323D0C: D8340000 00000201
	s_branch 65514                                             // 000000323D14: BFA0FFEA <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ec0>
	v_mov_b32_e32 v1, 0                                        // 000000323D18: 7E020280
	s_cmp_eq_u32 s1, 1                                         // 000000323D1C: BF068101
	s_mul_hi_i32 s6, s2, 0x1400                                // 000000323D20: 9706FF02 00001400
	s_mul_i32 s7, s2, 0x1400                                   // 000000323D28: 9607FF02 00001400
	ds_load_b32 v1, v1                                         // 000000323D30: D8D80000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000323D38: BF89FC07
	v_div_scale_f32 v2, null, 0x45200000, 0x45200000, v1       // 000000323D3C: D6FC7C02 0405FEFF 45200000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323D48: BF870001
	v_rcp_f32_e32 v3, v2                                       // 000000323D4C: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 000000323D50: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 000000323D58: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 000000323D5C: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000323D64: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 000000323D68: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, 0x45200000, v1             // 000000323D6C: D6FC6A04 0405FF01 45200000
	v_mul_f32_e32 v6, v4, v3                                   // 000000323D78: 100C0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323D7C: BF870091
	v_fma_f32 v7, v2, v6, v4                                   // 000000323D80: D6130007 04120D02
	v_fmac_f32_e32 v6, v7, v3                                  // 000000323D88: 560C0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323D8C: BF870091
	v_fmac_f32_e32 v4, v2, v6                                  // 000000323D90: 56080D02
	v_div_fmas_f32 v2, v4, v3, v6                              // 000000323D94: D6370002 041A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323D9C: BF870091
	v_div_fixup_f32 v1, v2, 0x45200000, v1                     // 000000323DA0: D6270001 0405FF02 45200000
	v_add_f32_e32 v1, 0x358637bd, v1                           // 000000323DAC: 060202FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000323DB4: BF870121
	v_mul_f32_e32 v2, 0x4b800000, v1                           // 000000323DB8: 100402FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 000000323DC0: 7C2802FF 00800000
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000323DC8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000323DCC: BF870291
	v_rsq_f32_e32 v1, v1                                       // 000000323DD0: 7E025D01
	v_mul_f32_e32 v2, 0x45800000, v1                           // 000000323DD4: 100402FF 45800000
	s_cbranch_scc1 5                                           // 000000323DDC: BFA20005 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ff4>
	s_mov_b32 s0, -1                                           // 000000323DE0: BE8000C1
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323DE4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 000000323DE8: 020E0501
	s_cbranch_execz 3                                          // 000000323DEC: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ffc>
	s_branch 95                                                // 000000323DF0: BFA0005F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4170>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323DF4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 000000323DF8: 020E0501
	v_sub_nc_u32_e32 v8, 0xa00, v0                             // 000000323DFC: 4C1000FF 00000A00
	v_lshl_or_b32 v2, v0, 1, s7                                // 000000323E04: D6560002 001D0300
	s_mul_i32 s0, s2, 0xa00                                    // 000000323E0C: 9600FF02 00000A00
	v_mov_b32_e32 v6, s6                                       // 000000323E14: 7E0C0206
	v_or_b32_e32 v1, s0, v0                                    // 000000323E18: 38020000
	v_and_b32_e32 v9, 0xbfe, v8                                // 000000323E1C: 361210FF 00000BFE
	.long 0xd7006a03                                           // 000000323E24: D7006A03
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000323E28: 02020404
	s_mul_i32 s0, s3, 0x2800                                   // 000000323E2C: 9600FF03 00002800
	v_add_co_ci_u32_e64 v4, null, s5, v6, vcc_lo               // 000000323E34: D5207C04 01AA0C05
	.long 0xd7006a05                                           // 000000323E3C: D7006A05
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000323E40: 02020414
	v_subrev_nc_u32_e32 v1, s0, v1                             // 000000323E44: 4E020200
	v_add_co_ci_u32_e64 v6, null, s21, v6, vcc_lo              // 000000323E48: D5207C06 01AA0C15
	v_mov_b32_e32 v10, v9                                      // 000000323E50: 7E140309
	s_mov_b32 s8, 0                                            // 000000323E54: BE880080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000323E58: BF8700B3
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000323E5C: 3404029F
	global_load_b32 v13, v[3:4], off                           // 000000323E60: DC520000 0D7C0003
	.long 0xd73c000b                                           // 000000323E68: D73C000B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000323E6C: 02020281
	.long 0xd7006a0b                                           // 000000323E70: D7006A0B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000323E74: 0202160A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000323E78: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s11, v12, vcc_lo            // 000000323E7C: D5207C0C 01AA180B
	.long 0xd7006a03                                           // 000000323E84: D7006A03
	v_cndmask_b32_e32 v0, v3, v132, vcc_lo                     // 000000323E88: 02010903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000323E8C: D5207C04 01AA0880
	global_load_b32 v2, v[11:12], off                          // 000000323E94: DC520000 027C000B
	.long 0x7f163880                                           // 000000323E9C: 7F163880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000323EA0: BF8700D1
	.long 0x7f18398b                                           // 000000323EA4: 7F18398B
	s_waitcnt vmcnt(1)                                         // 000000323EA8: BF8907F7
	.long 0x7e1c390d                                           // 000000323EAC: 7E1C390D
	s_waitcnt vmcnt(0)                                         // 000000323EB0: BF8903F7
	.long 0x7e1e3902                                           // 000000323EB4: 7E1E3902
	v_lshlrev_b32_e32 v15, 16, v15                             // 000000323EB8: 301E1E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323EBC: BF870091
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_lshlrev_b32 v14, 16, v14// 000000323EC0: C9221EF2 0F0E1C90
	v_dual_mul_f32 v14, v7, v14 :: v_dual_add_nc_u32 v1, 2, v1 // 000000323EC8: C8E01D07 0E000282
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000323ED0: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323ED8: BF870091
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000323EDC: C92404F2 020C1AFF FFFF0000
	v_dual_mul_f32 v13, v7, v13 :: v_dual_add_nc_u32 v10, -2, v10// 000000323EE8: C8E01B07 0D0A14C2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323EF0: BF870111
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000323EF4: 7C941480
	v_dual_mul_f32 v2, v13, v2 :: v_dual_mul_f32 v13, v14, v15 // 000000323EF8: C8C6050D 020C1F0E
	s_or_b32 s8, vcc_lo, s8                                    // 000000323F00: 8C08086A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323F04: BF870111
	.long 0x7e163982                                           // 000000323F08: 7E163982
	.long 0x7e18398d                                           // 000000323F0C: 7E18398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323F10: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 000000323F14: 36161681
	v_and_b32_e32 v12, 1, v12                                  // 000000323F18: 36181881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000323F1C: BF870112
	v_add3_u32 v2, v2, v11, 0x7fff                             // 000000323F20: D6550002 03FE1702 00007FFF
	v_add3_u32 v11, v13, v12, 0x7fff                           // 000000323F2C: D655000B 03FE190D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000323F38: BF8700B1
	.long 0x7e04398b                                           // 000000323F3C: 7E04398B
	global_store_b32 v[5:6], v2, off                           // 000000323F40: DC6A0000 007C0205
	.long 0xd7000005                                           // 000000323F48: D7000005
	v_cndmask_b32_e32 v0, v5, v132, vcc_lo                     // 000000323F4C: 02010905
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 000000323F50: D5207C06 00020C80
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 000000323F58: 917E087E
	s_cbranch_execnz 65470                                     // 000000323F5C: BFA6FFBE <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4058>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000323F60: 8C7E087E
	v_add_nc_u32_e32 v5, v0, v9                                // 000000323F64: 4A0A1300
	.long 0xd44d0000                                           // 000000323F68: D44D0000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000323F6C: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323F70: BF870001
	s_and_saveexec_b32 s8, s0                                  // 000000323F74: BE882000
	s_cbranch_execz 79                                         // 000000323F78: BFA5004F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x42b8>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000323F7C: BF8704A2
	v_lshlrev_b32_e32 v1, 1, v5                                // 000000323F80: 30020A81
	s_lshl_b32 s0, s3, 2                                       // 000000323F84: 84008203
	s_sub_i32 s2, s2, s0                                       // 000000323F88: 81820002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000323F8C: BF870099
	s_mulk_i32 s2, 0xa00                                       // 000000323F90: B8020A00
	.long 0xd7000303                                           // 000000323F94: D7000303
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 000000323F98: 02020207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000323F9C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s6, 0, s3                    // 000000323FA0: D5207C04 000D0006
	s_lshl_b32 s3, s1, 1                                       // 000000323FA8: 84038101
	.long 0xd7006a01                                           // 000000323FAC: D7006A01
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 000000323FB0: 02020604
	v_add_co_ci_u32_e64 v2, null, s5, v4, vcc_lo               // 000000323FB4: D5207C02 01AA0805
	.long 0xd7006a03                                           // 000000323FBC: D7006A03
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 000000323FC0: 02020614
	s_delay_alu instid0(VALU_DEP_1)                            // 000000323FC4: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v4, vcc_lo              // 000000323FC8: D5207C04 01AA0815
	s_mov_b32 s4, 0                                            // 000000323FD0: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000323FD4: BF840001
	s_nop 0                                                    // 000000323FD8: BF800000
	s_nop 0                                                    // 000000323FDC: BF800000
	s_nop 0                                                    // 000000323FE0: BF800000
	s_nop 0                                                    // 000000323FE4: BF800000
	s_nop 0                                                    // 000000323FE8: BF800000
	s_nop 0                                                    // 000000323FEC: BF800000
	s_nop 0                                                    // 000000323FF0: BF800000
	s_nop 0                                                    // 000000323FF4: BF800000
	s_nop 0                                                    // 000000323FF8: BF800000
	s_nop 0                                                    // 000000323FFC: BF800000
	v_add_nc_u32_e32 v8, s2, v5                                // 000000324000: 4A100A02
	global_load_u16 v6, v[1:2], off                            // 000000324004: DC4A0000 067C0001
	v_ashrrev_i32_e32 v9, 31, v8                               // 00000032400C: 3412109F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324010: BF870091
	.long 0xd73c0008                                           // 000000324014: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 000000324018: 02021081
	.long 0xd7006a08                                           // 00000032401C: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 000000324020: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000324024: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 000000324028: D5207C09 01AA120B
	.long 0xd7006a01                                           // 000000324030: D7006A01
	v_cndmask_b32_e32 v0, v1, v3, vcc_lo                       // 000000324034: 02000701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000324038: D5207C02 01AA0480
	global_load_u16 v8, v[8:9], off                            // 000000324040: DC4A0000 087C0008
	s_waitcnt vmcnt(1)                                         // 000000324048: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000032404C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324050: BF870091
	v_dual_mul_f32 v6, v7, v6 :: v_dual_add_nc_u32 v5, s1, v5  // 000000324054: C8E00D07 06040A01
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v5                         // 00000032405C: 7C920AFF 000009FF
	s_or_b32 s4, vcc_lo, s4                                    // 000000324064: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000324068: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000032406C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324070: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 000000324074: 061010F2
	v_mul_f32_e32 v6, v6, v8                                   // 000000324078: 100C1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032407C: BF870091
	v_bfe_u32 v8, v6, 16, 1                                    // 000000324080: D6100008 02052106
	v_add3_u32 v6, v6, v8, 0x7fff                              // 000000324088: D6550006 03FE1106 00007FFF
	global_store_d16_hi_b16 v[3:4], v6, off                    // 000000324094: DC960000 007C0603
	.long 0xd7000003                                           // 00000032409C: D7000003
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 0000003240A0: 02000703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003240A4: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 0000003240A8: D5207C04 00020880
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000003240B0: 917E047E
	s_cbranch_execnz 65490                                     // 0000003240B4: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4200>
	s_set_inst_prefetch_distance 0x2                           // 0000003240B8: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 0000003240BC: 8C7E087E
	s_waitcnt_vscnt null, 0x0                                  // 0000003240C0: BC7C0000
	s_barrier                                                  // 0000003240C4: BFBD0000
	buffer_gl0_inv                                             // 0000003240C8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 0000003240D0: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000003240D4: 7D940080
	s_cbranch_execz 577                                        // 0000003240D8: BFA50241 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4be0>
	s_mov_b32 s0, exec_lo                                      // 0000003240DC: BE80007E
	buffer_gl1_inv                                             // 0000003240E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000003240E8: E0AC0000 00000000
	.long 0xd71f0000                                           // 0000003240F0: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 0000003240F4: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003240F8: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000003240FC: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 000000324100: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 000000324104: BEFE0001
	s_cbranch_execz 565                                        // 000000324108: BFA50235 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4be0>
	s_bcnt1_i32_b32 s0, s0                                     // 00000032410C: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000324110: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 000000324114: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 00000032411C: DD0E0000 000C0001
	s_nop 0                                                    // 000000324124: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000324128: BFB60003
	s_endpgm                                                   // 00000032412C: BFB00000
	s_or_b32 exec_lo, exec_lo, s28                             // 000000324130: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000324134: BF8700B9
	s_or_b32 exec_lo, exec_lo, s26                             // 000000324138: 8C7E1A7E
	.long 0xd71f0001                                           // 00000032413C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000324140: 020100C1
	s_mov_b32 s4, exec_lo                                      // 000000324144: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000324148: 3A040290
	v_xor_b32_e32 v6, 8, v1                                    // 00000032414C: 3A0C0288
	v_xor_b32_e32 v10, 4, v1                                   // 000000324150: 3A140284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000324154: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000324158: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000032415C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000324160: 7C980CA0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000324164: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000324168: 30040482
	ds_bpermute_b32 v5, v2, v22                                // 00000032416C: DACC0000 05001602
	s_waitcnt lgkmcnt(0)                                       // 000000324174: BF89FC07
	v_add_f32_e32 v5, v22, v5                                  // 000000324178: 060A0B16
	ds_bpermute_b32 v3, v2, v20                                // 00000032417C: DACC0000 03001402
	ds_bpermute_b32 v4, v2, v23                                // 000000324184: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v21                                // 00000032418C: DACC0000 02001502
	s_waitcnt lgkmcnt(2)                                       // 000000324194: BF89FC27
	v_dual_add_f32 v3, v20, v3 :: v_dual_cndmask_b32 v6, v1, v6// 000000324198: C9120714 03060D01
	s_waitcnt lgkmcnt(1)                                       // 0000003241A0: BF89FC17
	v_add_f32_e32 v4, v23, v4                                  // 0000003241A4: 06080917
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 0000003241A8: 7C9814A0
	s_waitcnt lgkmcnt(0)                                       // 0000003241AC: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 0000003241B0: 06040515
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000003241B4: 300C0C82
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 0000003241B8: 02141501
	ds_bpermute_b32 v9, v6, v5                                 // 0000003241BC: DACC0000 09000506
	s_waitcnt lgkmcnt(0)                                       // 0000003241C4: BF89FC07
	v_add_f32_e32 v5, v5, v9                                   // 0000003241C8: 060A1305
	ds_bpermute_b32 v7, v6, v3                                 // 0000003241CC: DACC0000 07000306
	ds_bpermute_b32 v8, v6, v4                                 // 0000003241D4: DACC0000 08000406
	v_lshlrev_b32_e32 v10, 2, v10                              // 0000003241DC: 30141482
	ds_bpermute_b32 v6, v6, v2                                 // 0000003241E0: DACC0000 06000206
	s_waitcnt lgkmcnt(1)                                       // 0000003241E8: BF89FC17
	v_dual_add_f32 v3, v3, v7 :: v_dual_add_f32 v4, v4, v8     // 0000003241EC: C9080F03 03041104
	ds_bpermute_b32 v8, v10, v5                                // 0000003241F4: DACC0000 0800050A
	s_waitcnt lgkmcnt(0)                                       // 0000003241FC: BF89FC07
	v_dual_add_f32 v5, v5, v8 :: v_dual_add_f32 v2, v2, v6     // 000000324200: C9081105 05020D02
	ds_bpermute_b32 v6, v10, v3                                // 000000324208: DACC0000 0600030A
	ds_bpermute_b32 v9, v10, v2                                // 000000324210: DACC0000 0900020A
	s_waitcnt lgkmcnt(1)                                       // 000000324218: BF89FC17
	v_add_f32_e32 v3, v3, v6                                   // 00000032421C: 06060D03
	ds_bpermute_b32 v7, v10, v4                                // 000000324220: DACC0000 0700040A
	v_xor_b32_e32 v10, 2, v1                                   // 000000324228: 3A140282
	s_waitcnt lgkmcnt(1)                                       // 00000032422C: BF89FC17
	v_add_f32_e32 v6, v2, v9                                   // 000000324230: 060C1302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000324234: BF8700A2
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000324238: 7C9814A0
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000032423C: 02141501
	v_lshlrev_b32_e32 v10, 2, v10                              // 000000324240: 30141482
	ds_bpermute_b32 v2, v10, v3                                // 000000324244: DACC0000 0200030A
	s_waitcnt lgkmcnt(1)                                       // 00000032424C: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000324250: 06080F04
	ds_bpermute_b32 v8, v10, v5                                // 000000324254: DACC0000 0800050A
	ds_bpermute_b32 v9, v10, v6                                // 00000032425C: DACC0000 0900060A
	ds_bpermute_b32 v7, v10, v4                                // 000000324264: DACC0000 0700040A
	v_xor_b32_e32 v10, 1, v1                                   // 00000032426C: 3A140281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000324270: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 000000324274: 7C9814A0
	v_cndmask_b32_e32 v1, v1, v10, vcc_lo                      // 000000324278: 02021501
	s_waitcnt lgkmcnt(3)                                       // 00000032427C: BF89FC37
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v10, 2, v1 // 000000324280: C9220503 010A0282
	s_waitcnt lgkmcnt(2)                                       // 000000324288: BF89FC27
	v_add_f32_e32 v3, v5, v8                                   // 00000032428C: 06061105
	s_waitcnt lgkmcnt(0)                                       // 000000324290: BF89FC07
	v_dual_add_f32 v5, v6, v9 :: v_dual_add_f32 v2, v4, v7     // 000000324294: C9081306 05020F04
	ds_bpermute_b32 v4, v10, v1                                // 00000032429C: DACC0000 0400010A
	ds_bpermute_b32 v7, v10, v3                                // 0000003242A4: DACC0000 0700030A
	ds_bpermute_b32 v8, v10, v5                                // 0000003242AC: DACC0000 0800050A
	ds_bpermute_b32 v6, v10, v2                                // 0000003242B4: DACC0000 0600020A
	v_cmpx_eq_u32_e32 0, v15                                   // 0000003242BC: 7D941E80
	s_cbranch_execz 12                                         // 0000003242C0: BFA5000C <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x44f4>
	s_waitcnt lgkmcnt(1)                                       // 0000003242C4: BF89FC17
	v_dual_add_f32 v8, v5, v8 :: v_dual_lshlrev_b32 v9, s24, v13// 0000003242C8: C9221105 08081A18
	s_waitcnt lgkmcnt(0)                                       // 0000003242D0: BF89FC07
	v_dual_add_f32 v7, v3, v7 :: v_dual_add_f32 v6, v2, v6     // 0000003242D4: C9080F03 07060D02
	v_add_f32_e32 v5, v1, v4                                   // 0000003242DC: 060A0901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003242E0: BF870003
	v_add_lshl_u32 v1, v9, v14, 4                              // 0000003242E4: D6470001 02121D09
	ds_store_b128 v1, v[5:8] offset:1024                       // 0000003242EC: DB7C0400 00000501
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003242F4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003242F8: BF870009
	s_and_b32 s4, s19, exec_lo                                 // 0000003242FC: 8B047E13
	s_cselect_b32 s4, 4, 16                                    // 000000324300: 98049084
	s_mov_b32 s19, exec_lo                                     // 000000324304: BE93007E
	s_waitcnt lgkmcnt(0)                                       // 000000324308: BF89FC07
	s_barrier                                                  // 00000032430C: BFBD0000
	buffer_gl0_inv                                             // 000000324310: E0AC0000 00000000
	.long 0xd4cc007e                                           // 000000324318: D4CC007E
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000032431C: 02020004
	s_cbranch_execz 404                                        // 000000324320: BFA50194 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4b74>
	s_load_b32 s4, s[8:9], 0x40                                // 000000324324: F4000104 F8000040
	v_lshrrev_b32_e32 v5, 2, v0                                // 00000032432C: 320A0082
	v_mov_b32_e32 v4, 0                                        // 000000324330: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 000000324334: BF89FC07
	s_sub_i32 s4, s5, s4                                       // 000000324338: 81840405
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000032433C: BF870499
	s_ashr_i32 s5, s4, 31                                      // 000000324340: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s25                             // 000000324344: 84841904
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324348: BF870099
	.long 0xd7000401                                           // 00000032434C: D7000401
	v_cndmask_b32_e32 v1, s4, v5, vcc_lo                       // 000000324350: 02020A04
	v_add_co_ci_u32_e64 v2, null, s5, 0, s4                    // 000000324354: D5207C02 00110005
	s_delay_alu instid0(VALU_DEP_1)                            // 00000032435C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 000000324360: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000324364: 8B7E6A7E
	s_cbranch_execz 386                                        // 000000324368: BFA50182 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4b74>
	v_and_b32_e32 v3, 3, v0                                    // 00000032436C: 36060083
	v_lshlrev_b32_e32 v5, s24, v5                              // 000000324370: 300A0A18
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324374: BF870092
	v_lshlrev_b32_e32 v6, 2, v3                                // 000000324378: 300C0682
	v_lshl_or_b32 v5, v5, 4, v6                                // 00000032437C: D6560005 04190905
	ds_load_b32 v6, v5 offset:1024                             // 000000324384: D8D80400 06000005
	v_add_nc_u32_e32 v5, 16, v5                                // 00000032438C: 4A0A0A90
	s_add_i32 s18, s18, -1                                     // 000000324390: 8112C112
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000324394: BF870009
	s_cmp_eq_u32 s18, 0                                        // 000000324398: BF068012
	s_waitcnt lgkmcnt(0)                                       // 00000032439C: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000003243A0: 06080D04
	s_cbranch_scc0 65527                                       // 0000003243A4: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4584>
	s_clause 0x1                                               // 0000003243A8: BF850001
	s_load_b64 s[14:15], s[8:9], 0x38                          // 0000003243AC: F4040384 F8000038
	s_load_b64 s[10:11], s[8:9], 0x8                           // 0000003243B4: F4040284 F8000008
	s_mov_b32 s18, -1                                          // 0000003243BC: BE9200C1
	s_mov_b32 s5, 0                                            // 0000003243C0: BE850080
	s_mov_b32 s4, 0                                            // 0000003243C4: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000003243C8: BF89FC07
	s_cmp_lt_i32 s15, 3                                        // 0000003243CC: BF04830F
	s_cbranch_scc1 195                                         // 0000003243D0: BFA200C3 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x48e0>
	s_cmp_gt_i32 s15, 3                                        // 0000003243D4: BF02830F
	s_cbranch_scc0 73                                          // 0000003243D8: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4700>
	s_cmp_gt_i32 s15, 4                                        // 0000003243DC: BF02840F
	s_cbranch_scc0 73                                          // 0000003243E0: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4708>
	s_cmp_eq_u32 s15, 5                                        // 0000003243E4: BF06850F
	s_mov_b32 s4, -1                                           // 0000003243E8: BE8400C1
	s_cbranch_scc0 66                                          // 0000003243EC: BFA10042 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x46f8>
	v_lshrrev_b32_e32 v5, 23, v2                               // 0000003243F0: 320A0497
	s_lshr_b32 s4, s7, 31                                      // 0000003243F4: 85049F07
	s_load_b64 s[8:9], s[8:9], 0x10                            // 0000003243F8: F4040204 F8000010
	s_add_u32 s22, s6, s4                                      // 000000324400: 80160406
	s_addc_u32 s23, s7, 0                                      // 000000324404: 82178007
	.long 0xd7006a05                                           // 000000324408: D7006A05
	v_cndmask_b32_e32 v1, v1, v5, vcc_lo                       // 00000032440C: 02020B01
	s_ashr_i64 s[22:23], s[22:23], 1                           // 000000324410: 86968116
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 000000324414: D5207C0A 01AA0480
	v_dual_mov_b32 v12, s11 :: v_dual_and_b32 v11, 0xfffffe00, v5// 00000032441C: CA24000B 0C0A0AFF FFFFFE00
	v_mad_u64_u32 v[5:6], null, s22, v3, 0                     // 000000324428: D6FE7C05 02020616
	v_bfe_u32 v15, v4, 16, 1                                   // 000000324430: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324438: BF870093
	.long 0xd7016a08                                           // 00000032443C: D7016A08
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 000000324440: 02021701
	v_sub_co_ci_u32_e64 v9, null, v2, v10, vcc_lo              // 000000324444: D5217C09 01AA1502
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000032444C: BF870194
	v_mad_u64_u32 v[6:7], null, s23, v3, v[6:7]                // 000000324450: D6FE7C06 041A0617
	.long 0xd700040d                                           // 000000324458: D700040D
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 00000032445C: 020210FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_3)                            // 000000324464: BF870003
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[8:9]                     // 000000324468: 7CA810FF 00000100
	v_mov_b32_e32 v7, s10                                      // 000000324470: 7E0E020A
	v_add_co_ci_u32_e64 v14, null, -1, v9, s4                  // 000000324474: D5207C0E 001212C1
	s_mov_b32 s4, 0                                            // 00000032447C: BE840080
	.long 0xd73c0005                                           // 000000324480: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000324484: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 000000324488: BF89FC07
	v_dual_cndmask_b32 v8, v13, v8 :: v_dual_cndmask_b32 v7, s8, v7// 00000032448C: CA52110D 08060E08
	v_dual_cndmask_b32 v12, s9, v12 :: v_dual_cndmask_b32 v9, v14, v9// 000000324494: CA521809 0C08130E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032449C: BF870092
	.long 0xd7006a07                                           // 0000003244A0: D7006A07
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003244A4: 02020B07
	v_add_co_ci_u32_e64 v12, null, v12, v6, vcc_lo             // 0000003244A8: D5207C0C 01AA0D0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003244B0: BF870193
	.long 0xd73c0005                                           // 0000003244B4: D73C0005
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 0000003244B8: 02021081
	.long 0xd7006a07                                           // 0000003244BC: D7006A07
	v_cndmask_b32_e32 v1, v7, v11, vcc_lo                      // 0000003244C0: 02021707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003244C4: BF8701A1
	v_add_co_ci_u32_e64 v8, null, v12, v10, vcc_lo             // 0000003244C8: D5207C08 01AA150C
	v_add3_u32 v9, v4, v15, 0x7fff                             // 0000003244D0: D6550009 03FE1F04 00007FFF
	.long 0xd7006a05                                           // 0000003244DC: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 0000003244E0: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000003244E4: BF870001
	v_add_co_ci_u32_e64 v6, null, v8, v6, vcc_lo               // 0000003244E8: D5207C06 01AA0D08
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003244F0: DC960000 007C0905
	s_mov_b32 s8, 0                                            // 0000003244F8: BE880080
	s_branch 3                                                 // 0000003244FC: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x470c>
	s_mov_b32 s8, -1                                           // 000000324500: BE8800C1
	s_branch 54                                                // 000000324504: BFA00036 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x47e0>
	s_mov_b32 s8, -1                                           // 000000324508: BE8800C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000032450C: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 000000324510: 8B6A087E
	s_cbranch_vccz 49                                          // 000000324514: BFA30031 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x47dc>
	v_mul_f32_e32 v5, 0xbfb8aa3b, v4                           // 000000324518: 100A08FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000324520: BF870291
	v_exp_f32_e32 v5, v5                                       // 000000324524: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 000000324528: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032452C: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 000000324530: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 000000324538: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032453C: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 000000324540: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 000000324548: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 00000032454C: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 000000324554: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032455C: BF870112
	v_mul_f32_e32 v12, v11, v10                                // 000000324560: 1018150B
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 000000324564: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032456C: BF870092
	v_fma_f32 v13, -v8, v12, v11                               // 000000324570: D613000D 242E1908
	v_fmac_f32_e32 v12, v13, v10                               // 000000324578: 5618150D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032457C: BF870113
	.long 0xd73c0005                                           // 000000324580: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000324584: 02020A82
	v_fma_f32 v11, -v8, v12, v11                               // 000000324588: D613000B 242E1908
	.long 0xd73c0007                                           // 000000324590: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000324594: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000324598: BF870212
	v_div_fmas_f32 v10, v11, v10, v12                          // 00000032459C: D637000A 0432150B
	.long 0xd7006a05                                           // 0000003245A4: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003245A8: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003245AC: BF870191
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003245B0: D5207C06 01AA0C0B
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003245B8: D6270009 03CA130A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003245C0: BF870093
	.long 0xd7006a05                                           // 0000003245C4: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003245C8: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003245CC: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003245D4: DC6A0000 007C0905
	s_mov_b32 s8, 0                                            // 0000003245DC: BE880080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003245E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 0000003245E4: 8B6A087E
	s_cbranch_vccz 60                                          // 0000003245E8: BFA3003C <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x48dc>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003245EC: D6100005 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003245F4: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 0000003245F8: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000324604: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032460C: BF870091
	v_mul_f32_e32 v5, s14, v5                                  // 000000324610: 100A0A0E
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000324614: 100A0AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000032461C: BF870291
	v_exp_f32_e32 v5, v5                                       // 000000324620: 7E0A4B05
	v_add_f32_e32 v9, 1.0, v5                                  // 000000324624: 06120AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324628: BF870091
	v_div_scale_f32 v8, null, v9, v9, 1.0                      // 00000032462C: D6FC7C08 03CA1309
	v_rcp_f32_e32 v10, v8                                      // 000000324634: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324638: BF870095
	v_fma_f32 v5, -v8, v10, 1.0                                // 00000032463C: D6130005 23CA1508
	v_fmac_f32_e32 v10, v5, v10                                // 000000324644: 56141505
	v_div_scale_f32 v11, vcc_lo, 1.0, v9, 1.0                  // 000000324648: D6FC6A0B 03CA12F2
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 000000324650: D6FE7C05 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324658: BF870092
	v_mul_f32_e32 v12, v11, v10                                // 00000032465C: 1018150B
	v_fma_f32 v7, -v8, v12, v11                                // 000000324660: D6130007 242E1908
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000324668: BF870211
	v_fmac_f32_e32 v12, v7, v10                                // 00000032466C: 56181507
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 000000324670: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000324678: BF870112
	v_fma_f32 v7, -v8, v12, v11                                // 00000032467C: D6130007 242E1908
	.long 0xd73c0005                                           // 000000324684: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000324688: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000032468C: BF8701A2
	v_div_fmas_f32 v10, v7, v10, v12                           // 000000324690: D637000A 04321507
	.long 0xd73c0007                                           // 000000324698: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000032469C: 02020282
	.long 0xd7006a05                                           // 0000003246A0: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003246A4: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003246A8: BF8701A3
	v_div_fixup_f32 v9, v10, v9, 1.0                           // 0000003246AC: D6270009 03CA130A
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003246B4: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 0000003246BC: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003246C0: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003246C4: BF870193
	v_add_f32_e32 v9, v9, v9                                   // 0000003246C8: 06121309
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003246CC: D5207C06 01AA1106
	global_store_b32 v[5:6], v9, off                           // 0000003246D4: DC6A0000 007C0905
	s_mov_b32 s18, 0                                           // 0000003246DC: BE920080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003246E0: BF870009
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000003246E4: 8B6A127E
	s_cbranch_vccz 73                                          // 0000003246E8: BFA30049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4a10>
	s_cmp_gt_i32 s15, 1                                        // 0000003246EC: BF02810F
	s_mov_b32 s5, -1                                           // 0000003246F0: BE8500C1
	s_cbranch_scc0 64                                          // 0000003246F4: BFA10040 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x49f8>
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003246F8: D6100005 02052104
	s_mov_b32 s5, 0                                            // 000000324700: BE850080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324704: BF870091
	v_add3_u32 v5, v4, v5, 0x7fff                              // 000000324708: D6550005 03FE0B04 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000324714: 360A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032471C: BF870091
	v_mul_f32_e32 v5, 0xbfb8aa3b, v5                           // 000000324720: 100A0AFF BFB8AA3B
	v_exp_f32_e32 v5, v5                                       // 000000324728: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032472C: BF870095
	v_add_f32_e32 v8, 1.0, v5                                  // 000000324730: 06100AF2
	v_div_scale_f32 v7, null, v8, v8, 1.0                      // 000000324734: D6FC7C07 03CA1108
	v_div_scale_f32 v10, vcc_lo, 1.0, v8, 1.0                  // 00000032473C: D6FC6A0A 03CA10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000324744: BF870292
	v_rcp_f32_e32 v9, v7                                       // 000000324748: 7E125507
	v_fma_f32 v5, -v7, v9, 1.0                                 // 00000032474C: D6130005 23CA1307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000324754: BF870121
	v_fmac_f32_e32 v9, v5, v9                                  // 000000324758: 56121305
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 00000032475C: D6FE7C05 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 000000324764: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324768: BF870091
	v_fma_f32 v12, -v7, v11, v10                               // 00000032476C: D613000C 242A1707
	v_fmac_f32_e32 v11, v12, v9                                // 000000324774: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000324778: BF870121
	v_fma_f32 v10, -v7, v11, v10                               // 00000032477C: D613000A 242A1707
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 000000324784: D6FE7C06 041A0607
	v_div_fmas_f32 v7, v10, v9, v11                            // 00000032478C: D6370007 042E130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000324794: BF870112
	.long 0xd73c0005                                           // 000000324798: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 00000032479C: 02020A81
	v_div_fixup_f32 v9, v7, v8, 1.0                            // 0000003247A0: D6270009 03CA1107
	.long 0xd73c0007                                           // 0000003247A8: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003247AC: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003247B0: BF870193
	.long 0xd7006a05                                           // 0000003247B4: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 0000003247B8: 02020A0A
	v_bfe_u32 v10, v9, 16, 1                                   // 0000003247BC: D610000A 02052109
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 0000003247C4: D5207C06 01AA0C0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003247CC: BF870193
	.long 0xd7006a05                                           // 0000003247D0: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 0000003247D4: 02020F05
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000003247D8: D6550009 03FE1509 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003247E4: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003247E8: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v9, off                    // 0000003247F0: DC960000 007C0905
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 0000003247F8: 916A057E
	s_mov_b32 s5, 0                                            // 0000003247FC: BE850080
	s_cbranch_vccnz 3                                          // 000000324800: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4a10>
	s_cmp_lg_u32 s15, 1                                        // 000000324804: BF07810F
	s_mov_b32 s5, -1                                           // 000000324808: BE8500C1
	s_cselect_b32 s4, -1, 0                                    // 00000032480C: 980480C1
	v_bfe_u32 v5, v4, 16, 1                                    // 000000324810: D6100005 02052104
	.long 0xd73c0001                                           // 000000324818: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000032481C: 02020281
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000324820: 8B6A047E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000324824: BF870002
	v_add3_u32 v4, v4, v5, 0x7fff                              // 000000324828: D6550004 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 000000324834: BFA30014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4a88>
	v_mad_u64_u32 v[5:6], null, s6, v3, 0                      // 000000324838: D6FE7C05 02020606
	s_mov_b32 s5, 0                                            // 000000324840: BE850080
	v_mad_u64_u32 v[6:7], null, s7, v3, v[6:7]                 // 000000324844: D6FE7C06 041A0607
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000032484C: BF870091
	.long 0xd73c0005                                           // 000000324850: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000324854: 02020A81
	.long 0xd7006a05                                           // 000000324858: D7006A05
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000032485C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000324860: BF870111
	v_add_co_ci_u32_e64 v6, null, s11, v6, vcc_lo              // 000000324864: D5207C06 01AA0C0B
	.long 0xd7006a05                                           // 00000032486C: D7006A05
	v_cndmask_b32_e32 v1, v5, v1, vcc_lo                       // 000000324870: 02020305
	s_delay_alu instid0(VALU_DEP_1)                            // 000000324874: BF870001
	v_add_co_ci_u32_e64 v6, null, v6, v2, vcc_lo               // 000000324878: D5207C06 01AA0506
	global_store_d16_hi_b16 v[5:6], v4, off                    // 000000324880: DC960000 007C0405
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 000000324888: 916A057E
	s_cbranch_vccnz 57                                         // 00000032488C: BFA40039 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4b74>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324890: BF870091
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000324894: 360808FF FFFF0000
	v_mul_f32_e32 v7, s14, v4                                  // 00000032489C: 100E080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003248A0: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v7                           // 0000003248A4: 10080EFF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 0000003248AC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003248B0: BF870095
	v_add_f32_e32 v8, 1.0, v4                                  // 0000003248B4: 061008F2
	v_div_scale_f32 v6, null, v8, v8, v7                       // 0000003248B8: D6FC7C06 041E1108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003248C0: BF870291
	v_rcp_f32_e32 v9, v6                                       // 0000003248C4: 7E125506
	v_fma_f32 v4, -v6, v9, 1.0                                 // 0000003248C8: D6130004 23CA1306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000003248D0: BF870131
	v_fmac_f32_e32 v9, v4, v9                                  // 0000003248D4: 56121304
	v_div_scale_f32 v10, vcc_lo, v7, v8, v7                    // 0000003248D8: D6FC6A0A 041E1107
	v_mad_u64_u32 v[4:5], null, s6, v3, 0                      // 0000003248E0: D6FE7C04 02020606
	v_mul_f32_e32 v11, v10, v9                                 // 0000003248E8: 1016130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003248EC: BF870091
	v_fma_f32 v12, -v6, v11, v10                               // 0000003248F0: D613000C 242A1706
	v_fmac_f32_e32 v11, v12, v9                                // 0000003248F8: 5616130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003248FC: BF870121
	v_fma_f32 v10, -v6, v11, v10                               // 000000324900: D613000A 242A1706
	v_mad_u64_u32 v[5:6], null, s7, v3, v[5:6]                 // 000000324908: D6FE7C05 04160607
	v_div_fmas_f32 v3, v10, v9, v11                            // 000000324910: D6370003 042E130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000324918: BF870191
	v_div_fixup_f32 v6, v3, v8, v7                             // 00000032491C: D6270006 041E1103
	.long 0xd73c0003                                           // 000000324924: D73C0003
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000324928: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000032492C: BF870112
	v_bfe_u32 v5, v6, 16, 1                                    // 000000324930: D6100005 02052106
	.long 0xd7006a03                                           // 000000324938: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000032493C: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000324940: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 000000324944: D5207C04 01AA080B
	v_add3_u32 v5, v6, v5, 0x7fff                              // 00000032494C: D6550005 03FE0B06 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000324958: BF870093
	.long 0xd7006a01                                           // 00000032495C: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 000000324960: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 000000324964: D5207C02 01AA0504
	global_store_d16_hi_b16 v[1:2], v5, off                    // 00000032496C: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s19                             // 000000324974: 8C7E137E
	s_waitcnt_vscnt null, 0x0                                  // 000000324978: BC7C0000
	s_barrier                                                  // 00000032497C: BFBD0000
	buffer_gl0_inv                                             // 000000324980: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 000000324988: BE842003
	s_cbranch_execz 18                                         // 00000032498C: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4bd8>
	s_mov_b32 s3, exec_lo                                      // 000000324990: BE83007E
	buffer_gl1_inv                                             // 000000324994: E0B00000 00000000
	buffer_gl0_inv                                             // 00000032499C: E0AC0000 00000000
	.long 0xd71f0001                                           // 0000003249A4: D71F0001
	v_cndmask_b32_e32 v0, s3, v128, vcc_lo                     // 0000003249A8: 02010003
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000003249AC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000003249B0: 7C940280
	s_and_b32 s5, exec_lo, vcc_lo                              // 0000003249B4: 8B056A7E
	s_mov_b32 exec_lo, s5                                      // 0000003249B8: BEFE0005
	s_cbranch_execz 6                                          // 0000003249BC: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x4bd8>
	s_bcnt1_i32_b32 s3, s3                                     // 0000003249C0: BE831803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000003249C4: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s3              // 0000003249C8: CA100080 02000003
	global_atomic_add_u64 v2, v[1:2], s[16:17]                 // 0000003249D0: DD0E0000 00100102
	s_or_b32 exec_lo, exec_lo, s4                              // 0000003249D8: 8C7E047E
	s_cbranch_execz 64586                                      // 0000003249DC: BFA5FC4A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi4EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3d08>
	s_nop 0                                                    // 0000003249E0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000003249E4: BFB60003
	s_endpgm                                                   // 0000003249E8: BFB00000
		...

