00000000008d7900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008D7900: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000008D7908: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008D790C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 0000008D7910: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 0000008D7914: 363C009F
	.long 0x7f0a3880                                           // 0000008D7918: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 0000008D791C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 0000008D7920: BF89FC07
	.long 0xd4510004                                           // 0000008D7924: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008D7928: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000008D792C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000008D7930: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000008D7934: 98078002
	s_add_u32 s4, s8, s20                                      // 0000008D7938: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000008D793C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000008D7940: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000008D7944: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000008D7948: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008D794C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000008D7950: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008D7954: 30020282
	s_add_u32 s20, s14, s20                                    // 0000008D7958: 8014140E
	s_clause 0x1                                               // 0000008D795C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000008D7960: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000008D7968: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000008D7970: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000008D7974: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000008D7978: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000008D797C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000008D7980: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000008D7984: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000008D7988: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008D798C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000008D7990: 85049D18
	v_mad_u64_u32 v[24:25], null, s22, s7, v[1:2]              // 0000008D7994: D6FE7C18 04040E16
	s_add_i32 s21, s21, s4                                     // 0000008D799C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000008D79A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000008D79A4: B3940801
	.long 0xd72c0001                                           // 0000008D79A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v29, vcc_lo                      // 0000008D79AC: 02023A04
	s_mul_i32 s21, s22, s6                                     // 0000008D79B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D79B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000008D79B8: 4A0E0204
	v_add_nc_u32_e32 v31, v1, v30                              // 0000008D79BC: 4A3E3D01
	s_cselect_b32 s4, -1, 0                                    // 0000008D79C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000008D79C4: B2940800
	v_min_i32_e32 v32, s20, v7                                 // 0000008D79C8: 22400E14
	s_cselect_b32 s20, -1, 0                                   // 0000008D79CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008D79D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000008D79D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000008D79D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000008D79DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000008D79E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000008D79E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000008D79F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v25                               // 0000008D79FC: 4A063205
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008D7A00: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000008D7A04: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000008D7A10: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008D7A14: 0202411F
	.long 0x7e0a3982                                           // 0000008D7A18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008D7A1C: BF870114
	v_add_nc_u32_e32 v33, s21, v3                              // 0000008D7A20: 4A420615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000008D7A24: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 0000008D7A30: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 0000008D7A38: BF89FC07
	s_barrier                                                  // 0000008D7A3C: BFBD0000
	buffer_gl0_inv                                             // 0000008D7A40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000008D7A48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000008D7A4C: CA100080 09080080
	s_and_saveexec_b32 s21, s5                                 // 0000008D7A54: BE952005
	s_cbranch_execz 11                                         // 0000008D7A58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000008D7A5C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7A60: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7A64: 3404029F
	.long 0xd7006a01                                           // 0000008D7A68: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7A6C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7A70: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7A78: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7A80: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 0000008D7A84: 7E101701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000008D7A88: 8C7E157E
	v_add_nc_u32_e32 v1, 32, v31                               // 0000008D7A8C: 4A023EA0
	s_mov_b32 s5, exec_lo                                      // 0000008D7A90: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7A94: BF870001
	.long 0xd4c1007e                                           // 0000008D7A98: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7A9C: 02024101
	s_cbranch_execz 11                                         // 0000008D7AA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7AA4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7AA8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7AAC: 3404029F
	.long 0xd7006a01                                           // 0000008D7AB0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7AB4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7AB8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7AC0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7AC8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 0000008D7ACC: 7E121701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7AD0: 8C7E057E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 0000008D7AD4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 0000008D7ADC: 7E160280
	s_mov_b32 s5, exec_lo                                      // 0000008D7AE0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D7AE4: BF870002
	.long 0xd4c1007e                                           // 0000008D7AE8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7AEC: 02024101
	s_cbranch_execz 11                                         // 0000008D7AF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7AF4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7AF8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7AFC: 3404029F
	.long 0xd7006a01                                           // 0000008D7B00: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7B04: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7B08: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7B10: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7B18: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 0000008D7B1C: 7E141701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7B20: 8C7E057E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 0000008D7B24: 4A023EFF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000008D7B2C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7B30: BF870001
	.long 0xd4c1007e                                           // 0000008D7B34: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7B38: 02024101
	s_cbranch_execz 11                                         // 0000008D7B3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7B40: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7B44: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7B48: 3404029F
	.long 0xd7006a01                                           // 0000008D7B4C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7B50: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7B54: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7B5C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7B64: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 0000008D7B68: 7E161701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7B6C: 8C7E057E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 0000008D7B70: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000008D7B7C: 7E1A0280
	s_mov_b32 s5, exec_lo                                      // 0000008D7B80: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D7B84: BF870002
	.long 0xd4c1007e                                           // 0000008D7B88: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7B8C: 02024101
	s_cbranch_execz 11                                         // 0000008D7B90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7B94: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7B98: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7B9C: 3404029F
	.long 0xd7006a01                                           // 0000008D7BA0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7BA4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7BA8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7BB0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7BB8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 0000008D7BBC: 7E181701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7BC0: 8C7E057E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 0000008D7BC4: 4A023EFF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000008D7BCC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7BD0: BF870001
	.long 0xd4c1007e                                           // 0000008D7BD4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7BD8: 02024101
	s_cbranch_execz 11                                         // 0000008D7BDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7BE0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7BE4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7BE8: 3404029F
	.long 0xd7006a01                                           // 0000008D7BEC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7BF0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7BF4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7BFC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7C04: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 0000008D7C08: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7C0C: 8C7E057E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 0000008D7C10: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000008D7C1C: 7E1E0280
	s_mov_b32 s5, exec_lo                                      // 0000008D7C20: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D7C24: BF870002
	.long 0xd4c1007e                                           // 0000008D7C28: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7C2C: 02024101
	s_cbranch_execz 11                                         // 0000008D7C30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7C34: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7C38: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7C3C: 3404029F
	.long 0xd7006a01                                           // 0000008D7C40: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7C44: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7C48: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7C50: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7C58: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 0000008D7C5C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7C60: 8C7E057E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 0000008D7C64: 4A023EFF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000008D7C6C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7C70: BF870001
	.long 0xd4c1007e                                           // 0000008D7C74: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000008D7C78: 02024101
	s_cbranch_execz 11                                         // 0000008D7C7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000008D7C80: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7C84: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7C88: 3404029F
	.long 0xd7006a01                                           // 0000008D7C8C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7C90: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D7C94: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7C9C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7CA4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 0000008D7CA8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008D7CAC: 8C7E057E
	s_branch 9                                                 // 0000008D7CB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 0000008D7CB4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7CB8: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000008D7CBC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000008D7CC0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000008D7CC4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000008D7CC8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000008D7CCC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000008D7CD0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000008D7CD4: 7E1E0308
	s_add_u32 s8, s8, s18                                      // 0000008D7CD8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000008D7CDC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000008D7CE0: 85059F0F
	v_dual_mov_b32 v1, s7 :: v_dual_mov_b32 v20, 0             // 0000008D7CE4: CA100007 01140080
	s_add_u32 s18, s14, s5                                     // 0000008D7CEC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000008D7CF0: 8213800F
	.long 0xd4410005                                           // 0000008D7CF4: D4410005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008D7CF8: 0202411F
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008D7CFC: 86928112
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 0000008D7D00: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s18, s[8:9]              // 0000008D7D08: D6FE7C19 00202501
	.long 0xd72c0001                                           // 0000008D7D10: D72C0001
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000008D7D14: 02002607
	.long 0xd72c0002                                           // 0000008D7D18: D72C0002
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000008D7D1C: 02002406
	v_cndmask_b32_e64 v35, 0, 1, s20                           // 0000008D7D20: D5010023 00510280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 0000008D7D28: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 0000008D7D30: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008D7D34: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 0000008D7D38: D6550024 04063502
	s_and_saveexec_b32 s6, s5                                  // 0000008D7D40: BE862005
	s_cbranch_execz 22                                         // 0000008D7D44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000008D7D48: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000008D7D4C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D7D50: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008D7D54: 3404029F
	.long 0xd7006a01                                           // 0000008D7D58: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000008D7D5C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008D7D60: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000008D7D68: 916A147E
	global_load_b128 v[20:23], v[1:2], off                     // 0000008D7D6C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000008D7D74: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000008D7D78: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D7D7C: BF870091
	.long 0xd7006a01                                           // 0000008D7D80: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000008D7D84: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000008D7D88: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D7D90: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D7D98: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000008D7D9C: 7E361701
	s_or_b32 exec_lo, exec_lo, s6                              // 0000008D7DA0: 8C7E067E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000008D7DA4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000008D7DAC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v37, 0             // 0000008D7DB4: CA100080 2A240080
	s_and_saveexec_b32 s18, s5                                 // 0000008D7DBC: BE922005
	s_cbranch_execz 610                                        // 0000008D7DC0: BFA50262 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe4c>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000008D7DC4: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000008D7DCC: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 0000008D7DD4: CA100080 27260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D7DDC: BF870003
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v43, 4, v1     // 0000008D7DE0: CA220080 282A0284
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v44, 1, v1     // 0000008D7DE8: CA220080 292C0281
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, v27           // 0000008D7DF0: CA100080 222C011B
	s_mul_i32 s5, s15, 6                                       // 0000008D7DF8: 9605860F
	s_mul_hi_u32 s8, s14, 6                                    // 0000008D7DFC: 9688860E
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000008D7E00: 8486820E
	s_add_i32 s19, s8, s5                                      // 0000008D7E04: 81130508
	s_mul_i32 s21, s14, 6                                      // 0000008D7E08: 9615860E
	s_mov_b32 s20, 0                                           // 0000008D7E0C: BE940080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008D7E10: 8488810E
	s_branch 553                                               // 0000008D7E14: BFA00229 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xdbc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008D7E18: 8C7E0E7E
	v_cndmask_b32_e64 v56, v27, v8, s4                         // 0000008D7E1C: D5010038 0012111B
	v_cndmask_b32_e64 v2, v9, v10, s4                          // 0000008D7E24: D5010002 00121509
	v_cndmask_b32_e64 v1, v8, v9, s4                           // 0000008D7E2C: D5010001 00121308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000008D7E34: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s4                         // 0000008D7E40: D5010007 00121F0E
	v_cndmask_b32_e64 v6, v13, v14, s4                         // 0000008D7E48: D5010006 00121D0D
	v_cndmask_b32_e64 v5, v12, v13, s4                         // 0000008D7E50: D5010005 00121B0C
	v_cndmask_b32_e64 v4, v11, v12, s4                         // 0000008D7E58: D5010004 0012190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008D7E60: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s4                         // 0000008D7E64: D5010003 0012170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000008D7E6C: 3436349F
	s_and_b32 s5, exec_lo, s5                                  // 0000008D7E70: 8B05057E
	v_add_nc_u32_e32 v43, 0x200, v43                           // 0000008D7E74: 4A5656FF 00000200
	ds_load_b32 v15, v9                                        // 0000008D7E7C: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 0000008D7E84: 32122886
	s_or_b32 s20, s5, s20                                      // 0000008D7E88: 8C141405
	v_add_nc_u32_e32 v44, 64, v44                              // 0000008D7E8C: 4A5858C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7E90: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7E94: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000008D7E9C: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 0000008D7EA4: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7EA8: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 0000008D7EB0: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000008D7EB8: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7EBC: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7EC0: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 0000008D7EC8: D8D80000 3B000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000008D7ED0: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008D7ED8: 30121282
	ds_load_b32 v60, v9                                        // 0000008D7EDC: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000008D7EE4: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7EE8: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7EEC: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 0000008D7EF4: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000008D7EFC: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F00: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 0000008D7F08: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 0000008D7F10: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7F14: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F18: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 0000008D7F20: D8D80000 3F000009
	v_and_b32_e32 v9, 0xff, v22                                // 0000008D7F28: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008D7F30: 30121282
	ds_load_b32 v64, v9                                        // 0000008D7F34: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 0000008D7F3C: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7F40: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F44: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 0000008D7F4C: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 0000008D7F54: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F58: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 0000008D7F60: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 0000008D7F68: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7F6C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F70: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 0000008D7F78: D8D80000 43000009
	v_and_b32_e32 v9, 0xff, v23                                // 0000008D7F80: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008D7F88: 30121282
	ds_load_b32 v68, v9                                        // 0000008D7F8C: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 0000008D7F94: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D7F98: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7F9C: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000008D7FA4: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000008D7FAC: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7FB0: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 0000008D7FB8: D8D80000 46000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000008D7FC0: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D7FC4: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008D7FC8: 361212FF 000003FC
	ds_load_b32 v71, v9                                        // 0000008D7FD0: D8D80000 47000009
	.long 0xd73c0009                                           // 0000008D7FD8: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000008D7FDC: 02023481
	v_dual_mov_b32 v27, v45 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000008D7FE0: CA20012D 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000008D7FEC: D7006A0D
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 0000008D7FF0: 0202120A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D7FF4: BF870001
	v_add_co_ci_u32_e64 v14, null, s11, v10, vcc_lo            // 0000008D7FF8: D5207C0E 01AA140B
	s_clause 0x3                                               // 0000008D8000: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008D8004: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008D800C: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000008D8014: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000008D801C: DC5E0030 327C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000008D8024: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D8028: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 0000008D8030: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8034: BF8700A1
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D8038: CC1A4009 1C26730A
	s_waitcnt lgkmcnt(13)                                      // 0000008D8040: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D8044: CC1A4009 1C26750B
	s_waitcnt lgkmcnt(12)                                      // 0000008D804C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8050: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8054: CC1A4009 1C26770C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000008D805C: BF8908B7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D8060: CC1A4009 1C267914
	s_waitcnt lgkmcnt(10)                                      // 0000008D8068: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D806C: BF8700A1
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8070: CC1A4009 1C267B15
	s_waitcnt lgkmcnt(9)                                       // 0000008D8078: BF89FC97
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D807C: CC1A4009 1C267D16
	s_waitcnt lgkmcnt(8)                                       // 0000008D8084: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8088: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D808C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000008D8094: BF890477
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D8098: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(6)                                       // 0000008D80A0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D80A4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D80A8: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(5)                                       // 0000008D80B0: BF89FC57
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D80B4: CC1A4009 1C268530
	s_waitcnt lgkmcnt(4)                                       // 0000008D80BC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D80C0: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D80C4: CC1A4009 1C268731
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000008D80CC: BF890037
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D80D0: CC1A4009 1C268932
	.long 0xd7006a32                                           // 0000008D80D8: D7006A32
	v_cndmask_b32_e32 v0, v13, v8, vcc_lo                      // 0000008D80DC: 0200110D
	s_waitcnt lgkmcnt(2)                                       // 0000008D80E0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000008D80E4: BF8701C2
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D80E8: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v51, null, s9, v14, vcc_lo             // 0000008D80F0: D5207C33 01AA1C09
	.long 0xd7006a36                                           // 0000008D80F8: D7006A36
	v_cndmask_b32_e32 v0, v13, v6, vcc_lo                      // 0000008D80FC: 02000D0D
	s_waitcnt lgkmcnt(1)                                       // 0000008D8100: BF89FC17
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D8104: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v55, null, s7, v14, vcc_lo             // 0000008D810C: D5207C37 01AA1C07
	.long 0xd7006a0d                                           // 0000008D8114: D7006A0D
	v_cndmask_b32_e32 v0, v13, v21, vcc_lo                     // 0000008D8118: 02002B0D
	s_waitcnt lgkmcnt(0)                                       // 0000008D811C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D8120: BF870123
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D8124: CC1A4009 1C268F35
	v_add_co_ci_u32_e64 v14, null, s19, v14, vcc_lo            // 0000008D812C: D5207C0E 01AA1C13
	v_fmac_f32_e32 v37, v56, v9                                // 0000008D8134: 564A1338
	s_clause 0x3                                               // 0000008D8138: BF850003
	global_load_b128 v[9:12], v[50:51], off                    // 0000008D813C: DC5E0000 097C0032
	global_load_b128 v[20:23], v[50:51], off offset:16         // 0000008D8144: DC5E0010 147C0032
	global_load_b128 v[46:49], v[50:51], off offset:32         // 0000008D814C: DC5E0020 2E7C0032
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000008D8154: DC5E0030 327C0032
	s_waitcnt vmcnt(3)                                         // 0000008D815C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D8160: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8168: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D816C: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D8174: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D817C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8180: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D8188: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D818C: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8194: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8198: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D81A0: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D81A8: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D81AC: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000008D81B4: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D81B8: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D81C0: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D81C4: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D81CC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D81D4: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D81D8: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D81E0: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D81E4: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D81EC: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D81F0: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D81F8: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8200: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D8204: CC1A4009 1C268F35
	v_fmac_f32_e32 v42, v56, v9                                // 0000008D820C: 56541338
	s_clause 0x3                                               // 0000008D8210: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 0000008D8214: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 0000008D821C: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000008D8224: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 0000008D822C: DC5E0030 327C0036
	.long 0xd7006a36                                           // 0000008D8234: D7006A36
	v_cndmask_b32_e32 v0, v54, v6, vcc_lo                      // 0000008D8238: 02000D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D823C: BF8700B1
	v_add_co_ci_u32_e64 v55, null, s7, v55, vcc_lo             // 0000008D8240: D5207C37 01AA6E07
	s_waitcnt vmcnt(3)                                         // 0000008D8248: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D824C: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D8254: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D825C: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D8260: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8268: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D8270: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8274: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D8278: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8280: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8288: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D828C: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D8294: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000008D829C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D82A0: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D82A4: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D82AC: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D82B4: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D82B8: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D82C0: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D82C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D82CC: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D82D0: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D82D8: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D82E0: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D82E4: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D82EC: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D82F4: BF870001
	v_fmac_f32_e32 v41, v56, v9                                // 0000008D82F8: 56521338
	s_clause 0x3                                               // 0000008D82FC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008D8300: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008D8308: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000008D8310: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000008D8318: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 0000008D8320: D7006A0D
	v_cndmask_b32_e32 v0, v13, v6, vcc_lo                      // 0000008D8324: 02000D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D8328: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s7, v14, vcc_lo             // 0000008D832C: D5207C0E 01AA1C07
	s_waitcnt vmcnt(3)                                         // 0000008D8334: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D8338: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D8340: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8348: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D834C: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8354: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D835C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8360: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D8364: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D836C: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8374: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D8378: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D8380: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000008D8388: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D838C: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D8390: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D8398: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D83A0: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D83A4: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D83AC: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D83B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D83B8: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D83BC: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D83C4: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D83CC: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D83D0: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D83D8: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D83E0: BF870001
	v_fmac_f32_e32 v40, v56, v9                                // 0000008D83E4: 56501338
	s_clause 0x3                                               // 0000008D83E8: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 0000008D83EC: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 0000008D83F4: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000008D83FC: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 0000008D8404: DC5E0030 327C0036
	s_waitcnt vmcnt(3)                                         // 0000008D840C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D8410: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8418: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D841C: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D8424: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D842C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8430: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D8438: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D843C: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8444: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8448: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D8450: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8458: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D845C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000008D8464: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D8468: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8470: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D8474: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D847C: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8484: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D8488: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D8490: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D8494: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D849C: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D84A0: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D84A8: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D84B0: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D84B4: CC1A4009 1C268F35
	v_fmac_f32_e32 v39, v56, v9                                // 0000008D84BC: 564E1338
	s_clause 0x3                                               // 0000008D84C0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008D84C4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008D84CC: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000008D84D4: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000008D84DC: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 0000008D84E4: D7006A0D
	v_cndmask_b32_e32 v0, v54, v6, vcc_lo                      // 0000008D84E8: 02000D36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D84EC: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s7, v55, vcc_lo             // 0000008D84F0: D5207C0E 01AA6E07
	s_waitcnt vmcnt(3)                                         // 0000008D84F8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D84FC: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D8504: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D850C: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D8510: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D8518: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D8520: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8524: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D8528: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8530: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8538: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D853C: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D8544: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000008D854C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8550: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D8554: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D855C: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8564: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D8568: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D8570: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D8578: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D857C: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D8580: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D8588: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8590: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D8594: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D859C: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D85A4: BF870001
	v_fmac_f32_e32 v38, v56, v9                                // 0000008D85A8: 564C1338
	s_clause 0x3                                               // 0000008D85AC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000008D85B0: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000008D85B8: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000008D85C0: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000008D85C8: DC5E0030 327C000D
	s_waitcnt vmcnt(3)                                         // 0000008D85D0: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000008D85D4: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D85DC: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000008D85E0: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000008D85E8: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D85F0: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000008D85F4: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000008D85FC: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000008D8600: CC1A4009 1C267914
	v_mov_b32_e32 v20, v16                                     // 0000008D8608: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008D860C: BF870122
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000008D8610: CC1A4009 1C267B15
	v_mov_b32_e32 v21, v17                                     // 0000008D8618: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000008D861C: CC1A4009 1C267D16
	v_mov_b32_e32 v22, v18                                     // 0000008D8624: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000008D8628: BF870132
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000008D862C: CC1A4009 1C267F17
	v_mov_b32_e32 v23, v19                                     // 0000008D8634: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000008D8638: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000008D863C: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8644: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000008D8648: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000008D8650: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D8658: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000008D865C: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000008D8664: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000008D8668: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8670: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000008D8674: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000008D867C: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8684: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000008D8688: CC1A4009 1C268F35
	v_fmac_f32_e32 v34, v56, v9                                // 0000008D8690: 56441338
	v_mov_b32_e32 v15, v8                                      // 0000008D8694: 7E1E0308
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000008D8698: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000008D86A0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000008D86A8: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000008D86B0: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s20                       // 0000008D86B4: 917E147E
	s_cbranch_execz 35                                         // 0000008D86B8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xe48>
	s_waitcnt vmcnt(0)                                         // 0000008D86BC: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000008D86C0: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000008D86C8: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000008D86D0: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D86D4: BF870003
	.long 0xd4460005                                           // 0000008D86D8: D4460005
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008D86DC: 0202411F
	s_mov_b32 s14, exec_lo                                     // 0000008D86E0: BE8E007E
	.long 0xd4c1007e                                           // 0000008D86E4: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000008D86E8: 0202411F
	s_cbranch_execz 64970                                      // 0000008D86EC: BFA5FDCA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v43                              // 0000008D86F0: 3404569F
	.long 0xd7006a01                                           // 0000008D86F4: D7006A01
	v_cndmask_b32_e32 v1, v25, v43, vcc_lo                     // 0000008D86F8: 02025719
	v_mov_b32_e32 v45, v27                                     // 0000008D86FC: 7E5A031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D8700: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000008D8704: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000008D870C: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000008D8710: DC5E0000 107C0001
	s_cbranch_vccnz 64959                                      // 0000008D8718: BFA4FDBF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000008D871C: 3404589F
	.long 0xd7006a01                                           // 0000008D8720: D7006A01
	v_cndmask_b32_e32 v1, v24, v44, vcc_lo                     // 0000008D8724: 02025918
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008D8728: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000008D872C: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000008D8734: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008D873C: BF8903F7
	v_cvt_f32_f16_e32 v45, v1                                  // 0000008D8740: 7E5A1701
	s_branch 64948                                             // 0000008D8744: BFA0FDB4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x518>
	s_or_b32 exec_lo, exec_lo, s20                             // 0000008D8748: 8C7E147E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008D874C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000008D8750: 8C7E127E
	.long 0xd71f0001                                           // 0000008D8754: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008D8758: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000008D875C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008D8760: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000008D8764: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 0000008D8768: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008D876C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008D8770: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008D8774: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000008D8778: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000008D877C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000008D8780: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008D8784: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000008D8788: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008D878C: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000008D8790: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000008D8798: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000008D879C: 06060725
	ds_bpermute_b32 v5, v2, v41                                // 0000008D87A0: DACC0000 05002902
	ds_bpermute_b32 v6, v2, v40                                // 0000008D87A8: DACC0000 06002802
	ds_bpermute_b32 v7, v2, v39                                // 0000008D87B0: DACC0000 07002702
	ds_bpermute_b32 v4, v2, v42                                // 0000008D87B8: DACC0000 04002A02
	ds_bpermute_b32 v8, v2, v38                                // 0000008D87C0: DACC0000 08002602
	ds_bpermute_b32 v2, v2, v34                                // 0000008D87C8: DACC0000 02002202
	ds_bpermute_b32 v10, v9, v3                                // 0000008D87D0: DACC0000 0A000309
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000008D87D8: 02202101
	s_waitcnt lgkmcnt(5)                                       // 0000008D87DC: BF89FC57
	v_dual_add_f32 v5, v41, v5 :: v_dual_add_f32 v6, v40, v6   // 0000008D87E0: C9080B29 05060D28
	s_waitcnt lgkmcnt(3)                                       // 0000008D87E8: BF89FC37
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v42, v4   // 0000008D87EC: C9080F27 0704092A
	s_waitcnt lgkmcnt(2)                                       // 0000008D87F4: BF89FC27
	v_add_f32_e32 v8, v38, v8                                  // 0000008D87F8: 06101126
	ds_bpermute_b32 v12, v9, v5                                // 0000008D87FC: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 0000008D8804: BF89FC27
	v_add_f32_e32 v2, v34, v2                                  // 0000008D8808: 06040522
	ds_bpermute_b32 v14, v9, v7                                // 0000008D880C: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 0000008D8814: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 0000008D881C: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 0000008D8824: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 0000008D882C: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 0000008D8830: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 0000008D8838: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 0000008D883C: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 0000008D8840: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 0000008D8848: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 0000008D884C: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 0000008D8854: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 0000008D885C: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 0000008D8860: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 0000008D8868: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 0000008D886C: DACC0000 0D000710
	v_add_f32_e32 v8, v8, v15                                  // 0000008D8874: 06101F08
	ds_bpermute_b32 v15, v16, v2                               // 0000008D8878: DACC0000 0F000210
	s_waitcnt lgkmcnt(3)                                       // 0000008D8880: BF89FC37
	v_add_f32_e32 v3, v3, v9                                   // 0000008D8884: 06061303
	ds_bpermute_b32 v10, v16, v4                               // 0000008D8888: DACC0000 0A000410
	s_waitcnt lgkmcnt(3)                                       // 0000008D8890: BF89FC37
	v_add_f32_e32 v5, v5, v11                                  // 0000008D8894: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 0000008D8898: DACC0000 0C000610
	s_waitcnt lgkmcnt(3)                                       // 0000008D88A0: BF89FC37
	v_add_f32_e32 v7, v7, v13                                  // 0000008D88A4: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 0000008D88A8: DACC0000 0E000810
	v_xor_b32_e32 v16, 2, v1                                   // 0000008D88B0: 3A200282
	s_waitcnt lgkmcnt(3)                                       // 0000008D88B4: BF89FC37
	v_add_f32_e32 v2, v2, v15                                  // 0000008D88B8: 06041F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000008D88BC: BF8701D2
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000008D88C0: 7C9820A0
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000008D88C4: 02202101
	s_waitcnt lgkmcnt(1)                                       // 0000008D88C8: BF89FC17
	v_add_f32_e32 v6, v6, v12                                  // 0000008D88CC: 060C1906
	v_add_f32_e32 v4, v4, v10                                  // 0000008D88D0: 06081504
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000008D88D4: 30202082
	s_waitcnt lgkmcnt(0)                                       // 0000008D88D8: BF89FC07
	v_add_f32_e32 v8, v8, v14                                  // 0000008D88DC: 06101D08
	ds_bpermute_b32 v9, v16, v3                                // 0000008D88E0: DACC0000 09000310
	ds_bpermute_b32 v10, v16, v4                               // 0000008D88E8: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 0000008D88F0: DACC0000 0B000510
	ds_bpermute_b32 v12, v16, v6                               // 0000008D88F8: DACC0000 0C000610
	ds_bpermute_b32 v13, v16, v7                               // 0000008D8900: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v8                               // 0000008D8908: DACC0000 0E000810
	ds_bpermute_b32 v15, v16, v2                               // 0000008D8910: DACC0000 0F000210
	v_xor_b32_e32 v16, 1, v1                                   // 0000008D8918: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008D891C: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000008D8920: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 0000008D8924: 02022101
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000008D8928: 30200282
	s_waitcnt lgkmcnt(6)                                       // 0000008D892C: BF89FC67
	v_add_f32_e32 v1, v3, v9                                   // 0000008D8930: 06021303
	s_waitcnt lgkmcnt(4)                                       // 0000008D8934: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 0000008D8938: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 0000008D8940: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v10, v7, v13  // 0000008D8944: C9081906 050A1B07
	s_waitcnt lgkmcnt(1)                                       // 0000008D894C: BF89FC17
	v_add_f32_e32 v12, v8, v14                                 // 0000008D8950: 06181D08
	s_waitcnt lgkmcnt(0)                                       // 0000008D8954: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 0000008D8958: 06041F02
	ds_bpermute_b32 v6, v16, v1                                // 0000008D895C: DACC0000 06000110
	ds_bpermute_b32 v8, v16, v3                                // 0000008D8964: DACC0000 08000310
	ds_bpermute_b32 v9, v16, v4                                // 0000008D896C: DACC0000 09000410
	ds_bpermute_b32 v11, v16, v5                               // 0000008D8974: DACC0000 0B000510
	ds_bpermute_b32 v13, v16, v10                              // 0000008D897C: DACC0000 0D000A10
	ds_bpermute_b32 v14, v16, v12                              // 0000008D8984: DACC0000 0E000C10
	ds_bpermute_b32 v7, v16, v2                                // 0000008D898C: DACC0000 07000210
	v_cmpx_eq_u32_e32 0, v30                                   // 0000008D8994: 7D943C80
	s_cbranch_execz 28                                         // 0000008D8998: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x110c>
	s_waitcnt lgkmcnt(2)                                       // 0000008D899C: BF89FC27
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v8  // 0000008D89A0: C9081B0A 0A021103
	v_mul_u32_u24_e32 v13, 28, v29                             // 0000008D89A8: 161A3A9C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v1, v6     // 0000008D89AC: C9081304 04000D01
	s_waitcnt lgkmcnt(1)                                       // 0000008D89B4: BF89FC17
	v_dual_add_f32 v12, v12, v14 :: v_dual_add_f32 v5, v5, v11 // 0000008D89B8: C9081D0C 0C041705
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008D89C0: BF870003
	v_or_b32_e32 v6, 0x400, v13                                // 0000008D89C4: 380C1AFF 00000400
	v_mad_u32_u24 v8, v29, 28, 0x408                           // 0000008D89CC: D60B0008 03FD391D 00000408
	v_mad_u32_u24 v9, v29, 28, 0x410                           // 0000008D89D8: D60B0009 03FD391D 00000410
	s_waitcnt lgkmcnt(0)                                       // 0000008D89E4: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000008D89E8: 06040F02
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 0000008D89EC: D8380100 00030106
	ds_store_2addr_b32 v8, v4, v5 offset1:1                    // 0000008D89F4: D8380100 00050408
	ds_store_2addr_b32 v9, v10, v12 offset1:1                  // 0000008D89FC: D8380100 000C0A09
	ds_store_b32 v13, v2 offset:1048                           // 0000008D8A04: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008D8A0C: 8C7E047E
	.long 0xd4510004                                           // 0000008D8A10: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000008D8A14: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 0000008D8A18: 7C980087
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008D8A1C: BF890007
	s_barrier                                                  // 0000008D8A20: BFBD0000
	buffer_gl0_inv                                             // 0000008D8A24: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000008D8A2C: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008D8A30: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000008D8A34: BE852004
	s_cbranch_execz 79                                         // 0000008D8A38: BFA5004F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1278>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 0000008D8A3C: 4A0E38FF 00000400
	s_lshr_b32 s4, s17, 31                                     // 0000008D8A44: 85049F11
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000008D8A48: F4040000 F8000040
	s_add_u32 s4, s16, s4                                      // 0000008D8A50: 80040410
	s_addc_u32 s5, s17, 0                                      // 0000008D8A54: 82058011
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 0000008D8A58: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 0000008D8A60: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 0000008D8A68: D8DC231C 05000007
	s_ashr_i64 s[4:5], s[4:5], 1                               // 0000008D8A70: 86848104
	s_lshr_b32 s6, s3, 23                                      // 0000008D8A74: 85069703
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008D8A78: BF8704B9
	s_add_u32 s6, s2, s6                                       // 0000008D8A7C: 80060602
	s_addc_u32 s7, s3, 0                                       // 0000008D8A80: 82078003
	s_and_b32 s6, s6, 0xfffffe00                               // 0000008D8A84: 8B06FF06 FFFFFE00
	s_sub_u32 s2, s2, s6                                       // 0000008D8A8C: 80820602
	s_subb_u32 s3, s3, s7                                      // 0000008D8A90: 82830703
	s_waitcnt lgkmcnt(0)                                       // 0000008D8A94: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000008D8A98: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8A9C: BF870091
	v_add_f32_e32 v1, v1, v2                                   // 0000008D8AA0: 06020501
	v_add_f32_e32 v3, v1, v3                                   // 0000008D8AA4: 06060701
	v_mad_u64_u32 v[1:2], null, s4, v0, 0                      // 0000008D8AA8: D6FE7C01 02020004
	.long 0xd4540004                                           // 0000008D8AB0: D4540004
	v_cndmask_b32_e32 v0, 0x100, v2, vcc_lo                    // 0000008D8AB4: 020004FF 00000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8ABC: BF870093
	v_add_f32_e32 v3, v3, v4                                   // 0000008D8AC0: 06060903
	v_add_f32_e32 v4, v3, v5                                   // 0000008D8AC4: 06080B03
	ds_load_2addr_b32 v[7:8], v7 offset0:42 offset1:49         // 0000008D8AC8: D8DC312A 07000007
	v_mad_u64_u32 v[2:3], null, s5, v0, v[2:3]                 // 0000008D8AD0: D6FE7C02 040A0005
	s_and_b32 s5, s4, exec_lo                                  // 0000008D8AD8: 8B057E04
	s_cselect_b32 s8, s12, s0                                  // 0000008D8ADC: 9808000C
	v_add_f32_e32 v0, v4, v6                                   // 0000008D8AE0: 06000D04
	s_cselect_b32 s5, s13, s1                                  // 0000008D8AE4: 9805010D
	s_add_u32 s0, s2, 0xffffff00                               // 0000008D8AE8: 8000FF02 FFFFFF00
	s_addc_u32 s1, s3, -1                                      // 0000008D8AF0: 8201C103
	s_and_b32 s4, s4, exec_lo                                  // 0000008D8AF4: 8B047E04
	s_cselect_b32 s1, s3, s1                                   // 0000008D8AF8: 98010103
	s_cselect_b32 s0, s2, s0                                   // 0000008D8AFC: 98000002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008D8B00: BF870149
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000008D8B04: 84808100
	s_waitcnt lgkmcnt(0)                                       // 0000008D8B08: BF89FC07
	v_add_f32_e32 v3, v0, v7                                   // 0000008D8B0C: 06060F00
	.long 0xd73c0000                                           // 0000008D8B10: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000008D8B14: 02020281
	v_add_f32_e32 v2, v3, v8                                   // 0000008D8B18: 06041103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8B1C: BF870092
	.long 0xd7006a00                                           // 0000008D8B20: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000008D8B24: 02020008
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000008D8B28: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008D8B30: BF870193
	v_bfe_u32 v3, v2, 16, 1                                    // 0000008D8B34: D6100003 02052102
	.long 0xd7006a00                                           // 0000008D8B3C: D7006A00
	v_cndmask_b32_e32 v0, v0, v6, vcc_lo                       // 0000008D8B40: 02000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008D8B44: BF870191
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 0000008D8B48: D5207C01 01AA0207
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000008D8B50: D6550002 03FE0702 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008D8B5C: BF870093
	.long 0xd7006a00                                           // 0000008D8B60: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008D8B64: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000008D8B68: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000008D8B70: DC960000 007C0200
	s_endpgm                                                   // 0000008D8B78: BFB00000
		...

