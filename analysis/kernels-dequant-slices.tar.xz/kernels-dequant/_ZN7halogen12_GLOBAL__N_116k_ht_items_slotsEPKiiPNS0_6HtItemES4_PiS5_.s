000000000022f700 <_ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_>:
; _ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_():
	s_clause 0x3                                               // 00000022F700: BF850003
	s_load_b32 s14, s[0:1], 0x3c                               // 00000022F704: F4000380 F800003C
	s_load_b32 s3, s[0:1], 0x8                                 // 00000022F70C: F40000C0 F8000008
	s_load_b64 s[12:13], s[0:1], null                          // 00000022F714: F4040300 F8000000
	s_load_b256 s[4:11], s[0:1], 0x10                          // 00000022F71C: F40C0100 F8000010
	s_waitcnt lgkmcnt(0)                                       // 00000022F724: BF89FC07
	s_and_b32 s0, s14, 0xffff                                  // 00000022F728: 8B00FF0E 0000FFFF
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022F730: BF870009
	v_mad_u64_u32 v[0:1], null, s2, s0, v[0:1]                 // 00000022F734: D6FE7C00 04000002
	s_mul_i32 s0, s3, 20                                       // 00000022F73C: 96009403
	.long 0xd72e0002                                           // 00000022F740: D72E0002
	v_cndmask_b32_e32 v1, 0x66666667, v0, vcc_lo               // 00000022F744: 020200FF 66666667
	v_cmp_gt_i32_e32 vcc_lo, s0, v0                            // 00000022F74C: 7C880000
	v_ashrrev_i32_e32 v1, 31, v0                               // 00000022F750: 3402009F
	s_and_saveexec_b32 s0, vcc_lo                              // 00000022F754: BE80206A
	s_cbranch_execz 30                                         // 00000022F758: BFA5001E <_ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_+0xd4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000022F75C: BF8700A3
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000022F760: 3206049F
	v_ashrrev_i32_e32 v4, 3, v2                                // 00000022F764: 34080483
	v_add_nc_u32_e32 v7, v4, v3                                // 00000022F768: 4A0E0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022F76C: BF870121
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000022F770: 34100E9F
	v_add_nc_u32_e32 v6, 1, v7                                 // 00000022F774: 4A0C0E81
	.long 0xd73c0003                                           // 00000022F778: D73C0003
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000022F77C: 02020E82
	.long 0xd73c0008                                           // 00000022F780: D73C0008
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 00000022F784: 02020084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F788: BF870092
	.long 0xd7006a03                                           // 00000022F78C: D7006A03
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 00000022F790: 0202060C
	v_add_co_ci_u32_e64 v4, null, s13, v4, vcc_lo              // 00000022F794: D5207C04 01AA080D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F79C: BF870093
	.long 0xd7006a08                                           // 00000022F7A0: D7006A08
	v_cndmask_b32_e32 v1, s6, v8, vcc_lo                       // 00000022F7A4: 02021006
	v_add_co_ci_u32_e64 v9, null, s7, v9, vcc_lo               // 00000022F7A8: D5207C09 01AA1207
	global_load_b32 v3, v[3:4], off                            // 00000022F7B0: DC520000 037C0003
	v_mad_u64_u32 v[4:5], null, 0xffffffec, v7, v[0:1]         // 00000022F7B8: D6FE7C04 04020EFF FFFFFFEC
	v_mov_b32_e32 v5, v7                                       // 00000022F7C4: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 00000022F7C8: BF8903F7
	global_store_b128 v[8:9], v[3:6], off                      // 00000022F7CC: DC760000 007C0308
	s_or_b32 exec_lo, exec_lo, s0                              // 00000022F7D4: 8C7E007E
	s_mul_i32 s0, s3, 5                                        // 00000022F7D8: 96008503
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022F7DC: BF870009
	v_cmp_gt_i32_e32 vcc_lo, s0, v0                            // 00000022F7E0: 7C880000
	s_and_saveexec_b32 s0, vcc_lo                              // 00000022F7E4: BE80206A
	s_cbranch_execnz 7                                         // 00000022F7E8: BFA60007 <_ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_+0x108>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000022F7EC: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022F7F0: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000022F7F4: BE80007E
	.long 0xd4c4007e                                           // 00000022F7F8: D4C4007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 00000022F7FC: 02020003
	s_cbranch_execnz 36                                        // 00000022F800: BFA60024 <_ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_+0x194>
	s_endpgm                                                   // 00000022F804: BFB00000
	v_lshrrev_b32_e32 v3, 31, v2                               // 00000022F808: 3206049F
	v_ashrrev_i32_e32 v4, 1, v2                                // 00000022F80C: 34080481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F810: BF870091
	v_add_nc_u32_e32 v7, v4, v3                                // 00000022F814: 4A0E0704
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000022F818: 34100E9F
	v_add_nc_u32_e32 v6, 1, v7                                 // 00000022F81C: 4A0C0E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000022F820: BF870122
	.long 0xd73c0003                                           // 00000022F824: D73C0003
	v_cndmask_b32_e32 v1, 2, v7, vcc_lo                        // 00000022F828: 02020E82
	.long 0xd73c0008                                           // 00000022F82C: D73C0008
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 00000022F830: 02020084
	.long 0xd7006a03                                           // 00000022F834: D7006A03
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 00000022F838: 0202060C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000022F83C: BF870191
	v_add_co_ci_u32_e64 v4, null, s13, v4, vcc_lo              // 00000022F840: D5207C04 01AA080D
	.long 0xd7006a08                                           // 00000022F848: D7006A08
	v_cndmask_b32_e32 v1, s4, v8, vcc_lo                       // 00000022F84C: 02021004
	s_delay_alu instid0(VALU_DEP_1)                            // 00000022F850: BF870001
	v_add_co_ci_u32_e64 v9, null, s5, v9, vcc_lo               // 00000022F854: D5207C09 01AA1205
	global_load_b32 v3, v[3:4], off                            // 00000022F85C: DC520000 037C0003
	v_mad_u64_u32 v[4:5], null, v7, -5, v[0:1]                 // 00000022F864: D6FE7C04 04018B07
	v_mov_b32_e32 v5, v7                                       // 00000022F86C: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 00000022F870: BF8903F7
	global_store_b128 v[8:9], v[3:6], off                      // 00000022F874: DC760000 007C0308
	s_or_b32 exec_lo, exec_lo, s0                              // 00000022F87C: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000022F880: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000022F884: BE80007E
	.long 0xd4c4007e                                           // 00000022F888: D4C4007E
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 00000022F88C: 02020003
	s_cbranch_execz 65500                                      // 00000022F890: BFA5FFDC <_ZN7halogen12_GLOBAL__N_116k_ht_items_slotsEPKiiPNS0_6HtItemES4_PiS5_+0x104>
	.long 0xd73c0003                                           // 00000022F894: D73C0003
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000022F898: 02020082
	v_lshrrev_b32_e32 v5, 31, v2                               // 00000022F89C: 320A049F
	v_ashrrev_i32_e32 v6, 2, v2                                // 00000022F8A0: 340C0482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000022F8A4: BF870093
	.long 0xd7006a01                                           // 00000022F8A8: D7006A01
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000022F8AC: 02020608
	v_add_co_ci_u32_e64 v2, null, s9, v4, vcc_lo               // 00000022F8B0: D5207C02 01AA0809
	.long 0xd7006a03                                           // 00000022F8B8: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000022F8BC: 0202060A
	s_delay_alu instid0(VALU_DEP_4)                            // 00000022F8C0: BF870004
	v_add_nc_u32_e32 v5, v6, v5                                // 00000022F8C4: 4A0A0B06
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 00000022F8C8: D5207C04 01AA080B
	global_store_b32 v[1:2], v5, off                           // 00000022F8D0: DC6A0000 007C0501
	global_store_b32 v[3:4], v0, off                           // 00000022F8D8: DC6A0000 007C0003
	s_endpgm                                                   // 00000022F8E0: BFB00000
		...

