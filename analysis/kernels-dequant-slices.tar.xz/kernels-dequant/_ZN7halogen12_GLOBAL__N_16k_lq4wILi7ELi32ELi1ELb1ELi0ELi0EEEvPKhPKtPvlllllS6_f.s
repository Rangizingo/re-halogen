0000000000763e00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000763E00: F4100100 F8000000
	v_dual_mov_b32 v4, 0 :: v_dual_and_b32 v1, 15, v0          // 000000763E08: CA240080 0400008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000763E10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000763E14: 86039F02
	s_delay_alu instid0(VALU_DEP_2)                            // 000000763E18: BF870002
	v_dual_mov_b32 v16, 0 :: v_dual_lshlrev_b32 v1, 2, v1      // 000000763E1C: CA220080 10000282
	s_lshl_b64 s[0:1], s[2:3], 3                               // 000000763E24: 84808302
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 000000763E28: BF870482
	v_dual_mov_b32 v9, s1 :: v_dual_and_b32 v2, 60, v2         // 000000763E2C: CA240001 090204BC
	.long 0x7f183880                                           // 000000763E34: 7F183880
	v_and_b32_e32 v15, 31, v0                                  // 000000763E38: 361E009F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v6, 0              // 000000763E3C: CA100080 1B060080
	s_waitcnt lgkmcnt(0)                                       // 000000763E44: BF89FC07
	s_clause 0x1                                               // 000000763E48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000763E4C: DC520000 03040001
	global_load_b32 v7, v2, s[4:5]                             // 000000763E54: DC520000 07040002
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000763E5C: 32020085
	s_add_u32 s2, s4, s14                                      // 000000763E60: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000763E64: 82030F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000763E68: BF8704A1
	v_or_b32_e32 v8, s0, v1                                    // 000000763E6C: 38100200
	s_lshr_b32 s0, s11, 31                                     // 000000763E70: 85009F0B
	s_add_u32 s14, s10, s0                                     // 000000763E74: 800E000A
	s_addc_u32 s15, s11, 0                                     // 000000763E78: 820F800B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000763E7C: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[8:9]                  // 000000763E80: 7CA8100C
	v_mov_b32_e32 v5, 0                                        // 000000763E84: 7E0A0280
	s_ashr_i32 s20, s11, 31                                    // 000000763E88: 86149F0B
	v_cndmask_b32_e32 v10, 0, v8, vcc_lo                       // 000000763E8C: 02141080
	v_cndmask_b32_e64 v14, 0, s1, vcc_lo                       // 000000763E90: D501000E 01A80280
	s_ashr_i64 s[0:1], s[14:15], 1                             // 000000763E98: 8680810E
	s_lshr_b32 s14, s20, 27                                    // 000000763E9C: 850E9B14
	s_delay_alu instid0(VALU_DEP_2)                            // 000000763EA0: BF870002
	.long 0xd72c000d                                           // 000000763EA4: D72C000D
	v_cndmask_b32_e32 v1, s19, v10, vcc_lo                     // 000000763EA8: 02021413
	v_mad_u64_u32 v[1:2], null, s18, v10, 0                    // 000000763EAC: D6FE7C01 02021412
	.long 0xd72c0011                                           // 000000763EB4: D72C0011
	v_cndmask_b32_e32 v0, v10, v1, vcc_lo                      // 000000763EB8: 0200030A
	.long 0xd72c0013                                           // 000000763EBC: D72C0013
	v_cndmask_b32_e32 v0, v14, v0, vcc_lo                      // 000000763EC0: 0200010E
	s_waitcnt vmcnt(1)                                         // 000000763EC4: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 000000763EC8: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 000000763ED0: BF8903F7
	v_bfe_u32 v18, v7, 16, 1                                   // 000000763ED4: D6100012 02052107
	s_delay_alu instid0(VALU_DEP_2)                            // 000000763EDC: BF870002
	v_add3_u32 v3, v3, v11, 0x7fff                             // 000000763EE0: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[10:11], null, v10, s0, s[2:3]              // 000000763EEC: D6FE7C0A 0008010A
	s_add_u32 s2, s10, s14                                     // 000000763EF4: 80020E0A
	v_add3_u32 v7, v7, v18, 0x7fff                             // 000000763EF8: D6550007 03FE2507 00007FFF
	s_addc_u32 s3, s11, 0                                      // 000000763F04: 8203800B
	.long 0x7e183983                                           // 000000763F08: 7E183983
	.long 0xd72c0003                                           // 000000763F0C: D72C0003
	v_cndmask_b32_e32 v1, s18, v14, vcc_lo                     // 000000763F10: 02021C12
	s_lshr_b64 s[2:3], s[2:3], 5                               // 000000763F14: 85828502
	v_lshlrev_b32_e32 v14, 2, v0                               // 000000763F18: 301C0082
	.long 0xd4440000                                           // 000000763F1C: D4440000
	v_cndmask_b32_e32 v1, s2, v15, vcc_lo                      // 000000763F20: 02021E02
	v_and_or_b32 v12, 0xffff0000, v7, v12                      // 000000763F24: D657000C 04320EFF FFFF0000
	v_mov_b32_e32 v7, 0                                        // 000000763F30: 7E0E0280
	v_add3_u32 v17, v19, v11, v17                              // 000000763F34: D6550011 04461713
	v_add3_u32 v0, v2, v3, v13                                 // 000000763F3C: D6550000 04360702
	ds_store_b32 v14, v12                                      // 000000763F44: D8340000 00000C0E
	s_waitcnt lgkmcnt(0)                                       // 000000763F4C: BF89FC07
	s_barrier                                                  // 000000763F50: BFBD0000
	buffer_gl0_inv                                             // 000000763F54: E0AC0000 00000000
	s_and_saveexec_b32 s3, s0                                  // 000000763F5C: BE832000
	s_cbranch_execz 26                                         // 000000763F60: BFA5001A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1cc>
	s_add_u32 s1, s4, s16                                      // 000000763F64: 80011004
	s_addc_u32 s14, s5, s17                                    // 000000763F68: 820E1105
	v_lshlrev_b32_e32 v2, 1, v15                               // 000000763F6C: 30041E81
	.long 0xd7000103                                           // 000000763F70: D7000103
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 000000763F74: 02020201
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000763F78: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s14, v0, s1                  // 000000763F7C: D5207C04 0006000E
	v_lshlrev_b32_e32 v5, 4, v15                               // 000000763F84: 300A1E84
	.long 0xd7000102                                           // 000000763F88: D7000102
	v_cndmask_b32_e32 v1, v3, v2, vcc_lo                       // 000000763F8C: 02020503
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000763F90: BF870191
	v_add_co_ci_u32_e64 v3, null, 0, v4, s1                    // 000000763F94: D5207C03 00060880
	.long 0xd7000104                                           // 000000763F9C: D7000104
	v_cndmask_b32_e32 v1, v10, v5, vcc_lo                      // 000000763FA0: 02020B0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000763FA4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v17, s1                   // 000000763FA8: D5207C05 00062280
	s_clause 0x1                                               // 000000763FB0: BF850001
	global_load_d16_b16 v2, v[2:3], off                        // 000000763FB4: DC820000 027C0002
	global_load_b128 v[4:7], v[4:5], off                       // 000000763FBC: DC5E0000 047C0004
	s_waitcnt vmcnt(1)                                         // 000000763FC4: BF8907F7
	v_cvt_f32_f16_e32 v27, v2                                  // 000000763FC8: 7E361702
	s_or_b32 exec_lo, exec_lo, s3                              // 000000763FCC: 8C7E037E
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 000000763FD0: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 000000763FD8: CA100080 14140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000763FE0: CA100080 16160080
	s_and_saveexec_b32 s3, s0                                  // 000000763FE8: BE832000
	s_cbranch_execz 597                                        // 000000763FEC: BFA50255 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb44>
	s_mul_i32 s0, s11, 6                                       // 000000763FF0: 9600860B
	s_mul_hi_u32 s1, s10, 6                                    // 000000763FF4: 9681860A
	v_dual_mov_b32 v25, v15 :: v_dual_lshlrev_b32 v2, 1, v15   // 000000763FF8: CA22010F 19021E81
	s_add_i32 s18, s1, s0                                      // 000000764000: 81120001
	.long 0xd7000001                                           // 000000764004: D7000001
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 000000764008: 02020210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000076400C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s17, v0, s0                  // 000000764010: D5207C00 00020011
	v_dual_mov_b32 v12, 0 :: v_dual_lshlrev_b32 v11, 5, v15    // 000000764018: CA220080 0C0A1E85
	.long 0xd7000001                                           // 000000764020: D7000001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000764024: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000764028: BF8701A1
	v_add_co_ci_u32_e64 v0, null, 0, v0, s0                    // 00000076402C: D5207C00 00020080
	v_lshl_or_b32 v24, v15, 4, 0x200                           // 000000764034: D6560018 03FD090F 00000200
	.long 0xd7000001                                           // 000000764040: D7000001
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000764044: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000764048: BF8701A1
	v_add_co_ci_u32_e64 v0, null, s5, v0, s0                   // 00000076404C: D5207C00 00020005
	v_dual_mov_b32 v23, v12 :: v_dual_mov_b32 v26, v27         // 000000764054: CA10010C 171A011B
	.long 0xd700000d                                           // 00000076405C: D700000D
	v_cndmask_b32_e32 v0, v1, v192, vcc_lo                     // 000000764060: 02018101
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764064: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v0, s0                   // 000000764068: D5207C0E 00020080
	v_mov_b32_e32 v22, v12                                     // 000000764070: 7E2C030C
	v_mov_b32_e32 v21, v12                                     // 000000764074: 7E2A030C
	v_mov_b32_e32 v20, v12                                     // 000000764078: 7E28030C
	v_mov_b32_e32 v19, v12                                     // 00000076407C: 7E26030C
	v_mov_b32_e32 v18, v12                                     // 000000764080: 7E24030C
	v_mov_b32_e32 v16, v12                                     // 000000764084: 7E20030C
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000764088: 848E820A
	s_mul_i32 s17, s10, 6                                      // 00000076408C: 9611860A
	s_mov_b32 s16, 0                                           // 000000764090: BE900080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000764094: 8484810A
	s_branch 528                                               // 000000764098: BFA00210 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xadc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000076409C: 8C7E0A7E
	v_and_b32_e32 v28, 0xff, v4                                // 0000007640A0: 363808FF 000000FF
	s_and_b32 s0, exec_lo, s0                                  // 0000007640A8: 8B00007E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000007640AC: 4A3030FF 00000200
	s_or_b32 s16, s0, s16                                      // 0000007640B4: 8C101000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007640B8: BF8700B2
	v_lshlrev_b32_e32 v28, 2, v28                              // 0000007640BC: 30383882
	ds_load_b32 v44, v28                                       // 0000007640C0: D8D80000 2C00001C
	v_lshrrev_b32_e32 v28, 6, v4                               // 0000007640C8: 32380886
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007640CC: 363838FF 000003FC
	ds_load_b32 v45, v28                                       // 0000007640D4: D8D80000 2D00001C
	v_lshrrev_b32_e32 v28, 14, v4                              // 0000007640DC: 3238088E
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000007640E0: 32080896
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007640E4: BF870112
	v_and_b32_e32 v28, 0x3fc, v28                              // 0000007640E8: 363838FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007640F0: 360808FF 000003FC
	ds_load_b32 v46, v28                                       // 0000007640F8: D8D80000 2E00001C
	ds_load_b32 v47, v4                                        // 000000764100: D8D80000 2F000004
	v_and_b32_e32 v4, 0xff, v5                                 // 000000764108: 36080AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000764110: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000764114: 30080882
	ds_load_b32 v48, v4                                        // 000000764118: D8D80000 30000004
	v_lshrrev_b32_e32 v4, 6, v5                                // 000000764120: 32080A86
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000764124: 360808FF 000003FC
	ds_load_b32 v49, v4                                        // 00000076412C: D8D80000 31000004
	v_lshrrev_b32_e32 v4, 14, v5                               // 000000764134: 32080A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000764138: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076413C: 360808FF 000003FC
	ds_load_b32 v50, v4                                        // 000000764144: D8D80000 32000004
	v_lshrrev_b32_e32 v4, 22, v5                               // 00000076414C: 32080A96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000764150: 360808FF 000003FC
	ds_load_b32 v51, v4                                        // 000000764158: D8D80000 33000004
	v_and_b32_e32 v4, 0xff, v6                                 // 000000764160: 36080CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000764168: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000076416C: 30080882
	ds_load_b32 v52, v4                                        // 000000764170: D8D80000 34000004
	v_lshrrev_b32_e32 v4, 6, v6                                // 000000764178: 32080C86
	v_and_b32_e32 v4, 0x3fc, v4                                // 00000076417C: 360808FF 000003FC
	ds_load_b32 v53, v4                                        // 000000764184: D8D80000 35000004
	v_lshrrev_b32_e32 v4, 14, v6                               // 00000076418C: 32080C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000764190: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000764194: 360808FF 000003FC
	ds_load_b32 v54, v4                                        // 00000076419C: D8D80000 36000004
	v_lshrrev_b32_e32 v4, 22, v6                               // 0000007641A4: 32080C96
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007641A8: 360808FF 000003FC
	ds_load_b32 v55, v4                                        // 0000007641B0: D8D80000 37000004
	v_and_b32_e32 v4, 0xff, v7                                 // 0000007641B8: 36080EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007641C0: BF8700B1
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007641C4: 30080882
	ds_load_b32 v56, v4                                        // 0000007641C8: D8D80000 38000004
	v_lshrrev_b32_e32 v4, 6, v7                                // 0000007641D0: 32080E86
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007641D4: 360808FF 000003FC
	ds_load_b32 v57, v4                                        // 0000007641DC: D8D80000 39000004
	v_lshrrev_b32_e32 v4, 14, v7                               // 0000007641E4: 32080E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007641E8: BF8700B1
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000007641EC: 360808FF 000003FC
	ds_load_b32 v58, v4                                        // 0000007641F4: D8D80000 3A000004
	v_lshrrev_b32_e32 v4, 22, v7                               // 0000007641FC: 32080E96
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000764200: 360808FF 000003FC
	ds_load_b32 v59, v4                                        // 000000764208: D8D80000 3B000004
	.long 0xd73c0004                                           // 000000764210: D73C0004
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 000000764214: 02021681
	v_add_nc_u32_e32 v11, 0x400, v11                           // 000000764218: 4A1616FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764220: BF870092
	.long 0xd7000028                                           // 000000764224: D7000028
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 000000764228: 02020806
	v_add_co_ci_u32_e64 v41, null, s7, v5, s0                  // 00000076422C: D5207C29 00020A07
	s_clause 0x3                                               // 000000764234: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000764238: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 000000764240: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000764248: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 000000764250: DC5E0030 247C0028
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000764258: BF890CF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 00000076425C: CC1A4004 1A025904
	s_waitcnt lgkmcnt(14)                                      // 000000764264: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764268: BF8700A1
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000076426C: CC1A4004 1C125B05
	s_waitcnt lgkmcnt(13)                                      // 000000764274: BF89FCD7
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000764278: CC1A4004 1C125D06
	s_waitcnt lgkmcnt(12)                                      // 000000764280: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764284: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000764288: CC1A4004 1C125F07
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000764290: BF8908B7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000764294: CC1A4004 1C12611C
	s_waitcnt lgkmcnt(10)                                      // 00000076429C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007642A0: BF8700A1
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007642A4: CC1A4004 1C12631D
	s_waitcnt lgkmcnt(9)                                       // 0000007642AC: BF89FC97
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007642B0: CC1A4004 1C12651E
	s_waitcnt lgkmcnt(8)                                       // 0000007642B8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007642BC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007642C0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007642C8: BF890477
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007642CC: CC1A4004 1C126920
	s_waitcnt lgkmcnt(6)                                       // 0000007642D4: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007642D8: BF8700A1
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007642DC: CC1A4004 1C126B21
	s_waitcnt lgkmcnt(5)                                       // 0000007642E4: BF89FC57
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007642E8: CC1A4004 1C126D22
	s_waitcnt lgkmcnt(4)                                       // 0000007642F0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007642F4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007642F8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000764300: BF890037
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000764304: CC1A4004 1C127124
	.long 0xd7000024                                           // 00000076430C: D7000024
	v_cndmask_b32_e32 v0, v40, v4, vcc_lo                      // 000000764310: 02000928
	s_waitcnt lgkmcnt(2)                                       // 000000764314: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000764318: BF8701C2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076431C: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s5, v41, s0                 // 000000764324: D5207C25 00025205
	.long 0xd700002a                                           // 00000076432C: D700002A
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 000000764330: 02001D28
	s_waitcnt lgkmcnt(1)                                       // 000000764334: BF89FC17
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000764338: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v43, null, s15, v41, s0                // 000000764340: D5207C2B 0002520F
	.long 0xd7000028                                           // 000000764348: D7000028
	v_cndmask_b32_e32 v0, v40, v17, vcc_lo                     // 00000076434C: 02002328
	s_waitcnt lgkmcnt(0)                                       // 000000764350: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000764354: BF870123
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000764358: CC1A4004 1C127727
	v_add_co_ci_u32_e64 v41, null, s18, v41, s0                // 000000764360: D5207C29 00025212
	v_fmac_f32_e32 v23, v27, v4                                // 000000764368: 562E091B
	s_clause 0x3                                               // 00000076436C: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 000000764370: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 000000764378: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000764380: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000764388: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000764390: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764394: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076439C: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 0000007643A0: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 0000007643A8: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007643B0: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 0000007643B4: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007643BC: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007643C0: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007643C8: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007643CC: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007643D4: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007643DC: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007643E0: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007643E8: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007643EC: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007643F4: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007643F8: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000764400: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764408: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 00000076440C: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000764414: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000764418: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764420: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 000000764424: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 00000076442C: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764434: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000764438: CC1A4004 1C127727
	v_fmac_f32_e32 v22, v27, v4                                // 000000764440: 562C091B
	s_clause 0x3                                               // 000000764444: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 000000764448: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000764450: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 000000764458: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000764460: DC5E0030 247C002A
	.long 0xd700002a                                           // 000000764468: D700002A
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 00000076446C: 02001D2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000764470: BF8700B1
	v_add_co_ci_u32_e64 v43, null, s15, v43, s0                // 000000764474: D5207C2B 0002560F
	s_waitcnt vmcnt(3)                                         // 00000076447C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764480: CC1A4004 1A025904
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000764488: CC1A4004 1C125B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764490: BF870091
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000764494: CC1A4004 1C125D06
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 00000076449C: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 0000007644A4: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007644A8: BF870091
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 0000007644AC: CC1A4004 1C12611C
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 0000007644B4: CC1A4004 1C12631D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007644BC: BF870091
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 0000007644C0: CC1A4004 1C12651E
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007644C8: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007644D0: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007644D4: BF870091
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007644D8: CC1A4004 1C126920
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007644E0: CC1A4004 1C126B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007644E8: BF870091
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007644EC: CC1A4004 1C126D22
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007644F4: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007644FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764500: BF870091
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 000000764504: CC1A4004 1C127124
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 00000076450C: CC1A4004 1C127325
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764514: BF870091
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 000000764518: CC1A4004 1C127526
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 000000764520: CC1A4004 1C127727
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764528: BF870001
	v_fmac_f32_e32 v21, v27, v4                                // 00000076452C: 562A091B
	s_clause 0x3                                               // 000000764530: BF850003
	global_load_b128 v[4:7], v[40:41], off                     // 000000764534: DC5E0000 047C0028
	global_load_b128 v[28:31], v[40:41], off offset:16         // 00000076453C: DC5E0010 1C7C0028
	global_load_b128 v[32:35], v[40:41], off offset:32         // 000000764544: DC5E0020 207C0028
	global_load_b128 v[36:39], v[40:41], off offset:48         // 00000076454C: DC5E0030 247C0028
	s_waitcnt vmcnt(3)                                         // 000000764554: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764558: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764560: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000764564: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 00000076456C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764574: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000764578: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000764580: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000764584: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076458C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000764590: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000764598: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007645A0: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 0000007645A4: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 0000007645AC: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 0000007645B0: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007645B8: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 0000007645BC: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 0000007645C4: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007645CC: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007645D0: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007645D8: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007645DC: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007645E4: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007645E8: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007645F0: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007645F8: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007645FC: CC1A4004 1C127727
	v_fmac_f32_e32 v20, v27, v4                                // 000000764604: 5628091B
	s_clause 0x3                                               // 000000764608: BF850003
	global_load_b128 v[4:7], v[42:43], off                     // 00000076460C: DC5E0000 047C002A
	global_load_b128 v[28:31], v[42:43], off offset:16         // 000000764614: DC5E0010 1C7C002A
	global_load_b128 v[32:35], v[42:43], off offset:32         // 00000076461C: DC5E0020 207C002A
	global_load_b128 v[36:39], v[42:43], off offset:48         // 000000764624: DC5E0030 247C002A
	s_waitcnt vmcnt(3)                                         // 00000076462C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764630: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764638: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000076463C: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000764644: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076464C: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000764650: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000764658: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 00000076465C: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764664: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000764668: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000764670: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764678: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 00000076467C: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000764684: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000764688: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764690: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000764694: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 00000076469C: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007646A4: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 0000007646A8: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 0000007646B0: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007646B4: CC1A4004 1C127124
	.long 0xd7000024                                           // 0000007646BC: D7000024
	v_cndmask_b32_e32 v0, v40, v14, vcc_lo                     // 0000007646C0: 02001D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007646C4: BF870122
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007646C8: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v41, s0                // 0000007646D0: D5207C25 0002520F
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007646D8: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007646E0: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007646E4: CC1A4004 1C127727
	v_fmac_f32_e32 v19, v27, v4                                // 0000007646EC: 5626091B
	s_clause 0x3                                               // 0000007646F0: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007646F4: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007646FC: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 000000764704: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 00000076470C: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 000000764714: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764718: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764720: BF870091
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 000000764724: CC1A4004 1C125B05
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 00000076472C: CC1A4004 1C125D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764734: BF8700A1
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000764738: CC1A4004 1C125F07
	s_waitcnt vmcnt(2)                                         // 000000764740: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000764744: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076474C: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000764750: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 000000764758: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764760: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000764764: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 00000076476C: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000764770: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764778: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 00000076477C: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000764784: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076478C: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000764790: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 000000764798: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 00000076479C: CC1A4004 1C127124
	.long 0xd7000024                                           // 0000007647A4: D7000024
	v_cndmask_b32_e32 v0, v42, v14, vcc_lo                     // 0000007647A8: 02001D2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007647AC: BF8701B2
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007647B0: CC1A4004 1C127325
	v_add_co_ci_u32_e64 v37, null, s15, v43, s0                // 0000007647B8: D5207C25 0002560F
	.long 0xd700000d                                           // 0000007647C0: D700000D
	v_cndmask_b32_e32 v0, v13, v192, vcc_lo                    // 0000007647C4: 0201810D
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007647C8: CC1A4004 1C127526
	v_add_co_ci_u32_e64 v14, null, 0, v14, s0                  // 0000007647D0: D5207C0E 00021C80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007647D8: BF870092
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007647DC: CC1A4004 1C127727
	v_fmac_f32_e32 v18, v27, v4                                // 0000007647E4: 5624091B
	s_clause 0x3                                               // 0000007647E8: BF850003
	global_load_b128 v[4:7], v[36:37], off                     // 0000007647EC: DC5E0000 047C0024
	global_load_b128 v[28:31], v[36:37], off offset:16         // 0000007647F4: DC5E0010 1C7C0024
	global_load_b128 v[32:35], v[36:37], off offset:32         // 0000007647FC: DC5E0020 207C0024
	global_load_b128 v[36:39], v[36:37], off offset:48         // 000000764804: DC5E0030 247C0024
	s_waitcnt vmcnt(3)                                         // 00000076480C: BF890FF7
	v_dot2_f32_bf16 v4, v4, v44, 0                             // 000000764810: CC1A4004 1A025904
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000764818: BF870121
	v_dot2_f32_bf16 v4, v5, v45, v4                            // 00000076481C: CC1A4004 1C125B05
	v_mov_b32_e32 v5, v1                                       // 000000764824: 7E0A0301
	v_dot2_f32_bf16 v4, v6, v46, v4                            // 000000764828: CC1A4004 1C125D06
	v_mov_b32_e32 v6, v2                                       // 000000764830: 7E0C0302
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000764834: BF870132
	v_dot2_f32_bf16 v4, v7, v47, v4                            // 000000764838: CC1A4004 1C125F07
	v_mov_b32_e32 v7, v3                                       // 000000764840: 7E0E0303
	s_waitcnt vmcnt(2)                                         // 000000764844: BF890BF7
	v_dot2_f32_bf16 v4, v28, v48, v4                           // 000000764848: CC1A4004 1C12611C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764850: BF870091
	v_dot2_f32_bf16 v4, v29, v49, v4                           // 000000764854: CC1A4004 1C12631D
	v_dot2_f32_bf16 v4, v30, v50, v4                           // 00000076485C: CC1A4004 1C12651E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764864: BF8700A1
	v_dot2_f32_bf16 v4, v31, v51, v4                           // 000000764868: CC1A4004 1C12671F
	s_waitcnt vmcnt(1)                                         // 000000764870: BF8907F7
	v_dot2_f32_bf16 v4, v32, v52, v4                           // 000000764874: CC1A4004 1C126920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076487C: BF870091
	v_dot2_f32_bf16 v4, v33, v53, v4                           // 000000764880: CC1A4004 1C126B21
	v_dot2_f32_bf16 v4, v34, v54, v4                           // 000000764888: CC1A4004 1C126D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764890: BF8700A1
	v_dot2_f32_bf16 v4, v35, v55, v4                           // 000000764894: CC1A4004 1C126F23
	s_waitcnt vmcnt(0)                                         // 00000076489C: BF8903F7
	v_dot2_f32_bf16 v4, v36, v56, v4                           // 0000007648A0: CC1A4004 1C127124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007648A8: BF870091
	v_dot2_f32_bf16 v4, v37, v57, v4                           // 0000007648AC: CC1A4004 1C127325
	v_dot2_f32_bf16 v4, v38, v58, v4                           // 0000007648B4: CC1A4004 1C127526
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007648BC: BF870091
	v_dot2_f32_bf16 v4, v39, v59, v4                           // 0000007648C0: CC1A4004 1C127727
	v_fmac_f32_e32 v16, v27, v4                                // 0000007648C8: 5620091B
	v_dual_mov_b32 v4, v0 :: v_dual_mov_b32 v27, v26           // 0000007648CC: CA100100 041A011A
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007648D4: 917E107E
	s_cbranch_execz 25                                         // 0000007648D8: BFA50019 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb40>
	s_waitcnt vmcnt(0)                                         // 0000007648DC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007648E0: BF8701B1
	v_dual_mov_b32 v0, v4 :: v_dual_add_nc_u32 v25, 32, v25    // 0000007648E4: CA200104 001832A0
	v_dual_mov_b32 v1, v5 :: v_dual_mov_b32 v2, v6             // 0000007648EC: CA100105 01020106
	v_mov_b32_e32 v3, v7                                       // 0000007648F4: 7E060307
	.long 0xd4430000                                           // 0000007648F8: D4430000
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 0000007648FC: 02023202
	s_mov_b32 s10, exec_lo                                     // 000000764900: BE8A007E
	.long 0xd4c4007e                                           // 000000764904: D4C4007E
	v_cndmask_b32_e32 v1, s2, v25, vcc_lo                      // 000000764908: 02023202
	s_cbranch_execz 64995                                      // 00000076490C: BFA5FDE3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	.long 0xd7000100                                           // 000000764910: D7000100
	v_cndmask_b32_e32 v1, v10, v24, vcc_lo                     // 000000764914: 0202310A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000764918: BF870001
	v_add_co_ci_u32_e64 v1, null, 0, v17, s1                   // 00000076491C: D5207C01 00062280
	global_load_d16_b16 v26, v[13:14], off                     // 000000764924: DC820000 1A7C000D
	global_load_b128 v[0:3], v[0:1], off                       // 00000076492C: DC5E0000 007C0000
	s_waitcnt vmcnt(1)                                         // 000000764934: BF8907F7
	v_cvt_f32_f16_e32 v26, v26                                 // 000000764938: 7E34171A
	s_branch 64983                                             // 00000076493C: BFA0FDD7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x29c>
	s_or_b32 exec_lo, exec_lo, s16                             // 000000764940: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764944: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000764948: 8C7E037E
	.long 0xd71f0000                                           // 00000076494C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000764950: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 000000764954: 3A020090
	v_xor_b32_e32 v10, 8, v0                                   // 000000764958: 3A140088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076495C: BF870092
	.long 0xd44c0000                                           // 000000764960: D44C0000
	v_cndmask_b32_e32 v1, 32, v1, vcc_lo                       // 000000764964: 020202A0
	v_cndmask_b32_e64 v1, v0, v1, s0                           // 000000764968: D5010001 00020300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000764970: BF870113
	.long 0xd44c0000                                           // 000000764974: D44C0000
	v_cndmask_b32_e32 v1, 32, v10, vcc_lo                      // 000000764978: 020214A0
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000076497C: 30020282
	s_delay_alu instid0(VALU_DEP_2)                            // 000000764980: BF870002
	v_cndmask_b32_e64 v10, v0, v10, s0                         // 000000764984: D501000A 00021500
	ds_bpermute_b32 v2, v1, v23                                // 00000076498C: DACC0000 02001701
	s_waitcnt lgkmcnt(0)                                       // 000000764994: BF89FC07
	v_add_f32_e32 v2, v23, v2                                  // 000000764998: 06040517
	s_waitcnt vmcnt(0)                                         // 00000076499C: BF8903F7
	ds_bpermute_b32 v6, v1, v19                                // 0000007649A0: DACC0000 06001301
	ds_bpermute_b32 v7, v1, v18                                // 0000007649A8: DACC0000 07001201
	ds_bpermute_b32 v3, v1, v22                                // 0000007649B0: DACC0000 03001601
	ds_bpermute_b32 v4, v1, v21                                // 0000007649B8: DACC0000 04001501
	ds_bpermute_b32 v5, v1, v20                                // 0000007649C0: DACC0000 05001401
	ds_bpermute_b32 v1, v1, v16                                // 0000007649C8: DACC0000 01001001
	v_lshlrev_b32_e32 v10, 2, v10                              // 0000007649D0: 30141482
	s_waitcnt lgkmcnt(4)                                       // 0000007649D4: BF89FC47
	v_dual_add_f32 v6, v19, v6 :: v_dual_add_f32 v7, v18, v7   // 0000007649D8: C9080D13 06060F12
	v_xor_b32_e32 v18, 4, v0                                   // 0000007649E0: 3A240084
	s_waitcnt lgkmcnt(2)                                       // 0000007649E4: BF89FC27
	v_dual_add_f32 v3, v22, v3 :: v_dual_add_f32 v4, v21, v4   // 0000007649E8: C9080716 03040915
	s_waitcnt lgkmcnt(1)                                       // 0000007649F0: BF89FC17
	v_add_f32_e32 v5, v20, v5                                  // 0000007649F4: 060A0B14
	ds_bpermute_b32 v11, v10, v2                               // 0000007649F8: DACC0000 0B00020A
	.long 0xd44c0000                                           // 000000764A00: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000764A04: 020224A0
	ds_bpermute_b32 v12, v10, v3                               // 000000764A08: DACC0000 0C00030A
	ds_bpermute_b32 v13, v10, v4                               // 000000764A10: DACC0000 0D00040A
	ds_bpermute_b32 v14, v10, v5                               // 000000764A18: DACC0000 0E00050A
	ds_bpermute_b32 v17, v10, v7                               // 000000764A20: DACC0000 1100070A
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000764A28: D5010012 00022500
	s_waitcnt lgkmcnt(5)                                       // 000000764A30: BF89FC57
	v_add_f32_e32 v1, v16, v1                                  // 000000764A34: 06020310
	ds_bpermute_b32 v16, v10, v6                               // 000000764A38: DACC0000 1000060A
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000764A40: 30242482
	ds_bpermute_b32 v10, v10, v1                               // 000000764A44: DACC0000 0A00010A
	s_waitcnt lgkmcnt(5)                                       // 000000764A4C: BF89FC57
	v_dual_add_f32 v2, v2, v11 :: v_dual_add_f32 v3, v3, v12   // 000000764A50: C9081702 02021903
	s_waitcnt lgkmcnt(3)                                       // 000000764A58: BF89FC37
	v_dual_add_f32 v4, v4, v13 :: v_dual_add_f32 v5, v5, v14   // 000000764A5C: C9081B04 04041D05
	s_waitcnt lgkmcnt(2)                                       // 000000764A64: BF89FC27
	v_add_f32_e32 v7, v7, v17                                  // 000000764A68: 060E2307
	ds_bpermute_b32 v11, v18, v3                               // 000000764A6C: DACC0000 0B000312
	s_waitcnt lgkmcnt(2)                                       // 000000764A74: BF89FC27
	v_add_f32_e32 v6, v6, v16                                  // 000000764A78: 060C2106
	ds_bpermute_b32 v13, v18, v5                               // 000000764A7C: DACC0000 0D000512
	ds_bpermute_b32 v12, v18, v4                               // 000000764A84: DACC0000 0C000412
	ds_bpermute_b32 v16, v18, v7                               // 000000764A8C: DACC0000 10000712
	s_waitcnt lgkmcnt(4)                                       // 000000764A94: BF89FC47
	v_add_f32_e32 v1, v1, v10                                  // 000000764A98: 06021501
	ds_bpermute_b32 v10, v18, v2                               // 000000764A9C: DACC0000 0A000212
	ds_bpermute_b32 v14, v18, v6                               // 000000764AA4: DACC0000 0E000612
	s_waitcnt lgkmcnt(1)                                       // 000000764AAC: BF89FC17
	v_dual_add_f32 v7, v7, v16 :: v_dual_add_f32 v2, v2, v10   // 000000764AB0: C9082107 07021502
	v_add_f32_e32 v10, v3, v11                                 // 000000764AB8: 06141703
	ds_bpermute_b32 v17, v18, v1                               // 000000764ABC: DACC0000 11000112
	v_xor_b32_e32 v18, 2, v0                                   // 000000764AC4: 3A240082
	v_xor_b32_e32 v3, 1, v0                                    // 000000764AC8: 3A060081
	v_dual_add_f32 v4, v4, v12 :: v_dual_add_f32 v11, v5, v13  // 000000764ACC: C9081904 040A1B05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764AD4: BF870093
	.long 0xd44c0000                                           // 000000764AD8: D44C0000
	v_cndmask_b32_e32 v1, 32, v18, vcc_lo                      // 000000764ADC: 020224A0
	v_cndmask_b32_e64 v18, v0, v18, s0                         // 000000764AE0: D5010012 00022500
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000764AE8: BF870114
	.long 0xd44c0000                                           // 000000764AEC: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000764AF0: 020206A0
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000764AF4: 30242482
	s_delay_alu instid0(VALU_DEP_2)                            // 000000764AF8: BF870002
	v_cndmask_b32_e64 v0, v0, v3, s0                           // 000000764AFC: D5010000 00020700
	s_waitcnt lgkmcnt(1)                                       // 000000764B04: BF89FC17
	v_add_f32_e32 v6, v6, v14                                  // 000000764B08: 060C1D06
	.long 0xd44a0000                                           // 000000764B0C: D44A0000
	v_cndmask_b32_e32 v1, 0, v15, vcc_lo                       // 000000764B10: 02021E80
	ds_bpermute_b32 v14, v18, v11                              // 000000764B14: DACC0000 0E000B12
	s_waitcnt lgkmcnt(1)                                       // 000000764B1C: BF89FC17
	v_add_f32_e32 v12, v1, v17                                 // 000000764B20: 06182301
	ds_bpermute_b32 v1, v18, v2                                // 000000764B24: DACC0000 01000212
	ds_bpermute_b32 v5, v18, v10                               // 000000764B2C: DACC0000 05000A12
	ds_bpermute_b32 v17, v18, v7                               // 000000764B34: DACC0000 11000712
	v_lshlrev_b32_e32 v19, 2, v0                               // 000000764B3C: 30260082
	ds_bpermute_b32 v16, v18, v6                               // 000000764B40: DACC0000 10000612
	s_and_b32 s0, s0, vcc_lo                                   // 000000764B48: 8B006A00
	s_waitcnt lgkmcnt(3)                                       // 000000764B4C: BF89FC37
	v_add_f32_e32 v3, v2, v1                                   // 000000764B50: 06060302
	ds_bpermute_b32 v13, v18, v4                               // 000000764B54: DACC0000 0D000412
	v_add_f32_e32 v1, v11, v14                                 // 000000764B5C: 06021D0B
	ds_bpermute_b32 v18, v18, v12                              // 000000764B60: DACC0000 12000C12
	s_waitcnt lgkmcnt(4)                                       // 000000764B68: BF89FC47
	v_add_f32_e32 v5, v10, v5                                  // 000000764B6C: 060A0B0A
	s_waitcnt lgkmcnt(2)                                       // 000000764B70: BF89FC27
	v_add_f32_e32 v6, v6, v16                                  // 000000764B74: 060C2106
	v_add_f32_e32 v10, v7, v17                                 // 000000764B78: 06142307
	ds_bpermute_b32 v7, v19, v3                                // 000000764B7C: DACC0000 07000313
	s_waitcnt lgkmcnt(2)                                       // 000000764B84: BF89FC27
	v_add_f32_e32 v0, v4, v13                                  // 000000764B88: 06001B04
	ds_bpermute_b32 v4, v19, v1                                // 000000764B8C: DACC0000 04000113
	s_waitcnt lgkmcnt(2)                                       // 000000764B94: BF89FC27
	v_add_f32_e32 v14, v12, v18                                // 000000764B98: 061C250C
	ds_bpermute_b32 v11, v19, v5                               // 000000764B9C: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 000000764BA4: DACC0000 0C000613
	ds_bpermute_b32 v2, v19, v0                                // 000000764BAC: DACC0000 02000013
	ds_bpermute_b32 v13, v19, v10                              // 000000764BB4: DACC0000 0D000A13
	ds_bpermute_b32 v16, v19, v14                              // 000000764BBC: DACC0000 10000E13
	s_and_saveexec_b32 s1, s0                                  // 000000764BC4: BE812000
	s_cbranch_execz 62                                         // 000000764BC8: BFA5003E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi1ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xec4>
	.long 0xd73c0008                                           // 000000764BCC: D73C0008
	v_cndmask_b32_e32 v1, 2, v8, vcc_lo                        // 000000764BD0: 02021082
	s_waitcnt lgkmcnt(1)                                       // 000000764BD4: BF89FC17
	v_dual_add_f32 v13, v10, v13 :: v_dual_add_f32 v10, v5, v11// 000000764BD8: C9081B0A 0D0A1705
	v_dual_add_f32 v12, v6, v12 :: v_dual_add_f32 v15, v0, v2  // 000000764BE0: C9081906 0C0E0500
	s_lshl_b64 s[0:1], s[12:13], 2                             // 000000764BE8: 8480820C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764BEC: BF870093
	.long 0xd7006a05                                           // 000000764BF0: D7006A05
	v_cndmask_b32_e32 v1, s8, v8, vcc_lo                       // 000000764BF4: 02021008
	v_add_co_ci_u32_e64 v6, null, s9, v9, vcc_lo               // 000000764BF8: D5207C06 01AA1209
	s_waitcnt lgkmcnt(0)                                       // 000000764C00: BF89FC07
	v_dual_add_f32 v14, v14, v16 :: v_dual_add_f32 v3, v3, v7  // 000000764C04: C908210E 0E020F03
	s_delay_alu instid0(VALU_DEP_3)                            // 000000764C0C: BF870003
	.long 0xd7006a07                                           // 000000764C10: D7006A07
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000764C14: 02000105
	v_add_f32_e32 v11, v1, v4                                  // 000000764C18: 06160901
	v_mad_u64_u32 v[0:1], null, s12, 12, v[5:6]                // 000000764C1C: D6FE7C00 0415180C
	v_add_co_ci_u32_e64 v8, null, s1, v6, vcc_lo               // 000000764C24: D5207C08 01AA0C01
	s_lshl_b64 s[0:1], s[12:13], 3                             // 000000764C2C: 8480830C
	s_clause 0x1                                               // 000000764C30: BF850001
	global_store_b32 v[5:6], v3, off                           // 000000764C34: DC6A0000 007C0305
	global_store_b32 v[7:8], v10, off                          // 000000764C3C: DC6A0000 007C0A07
	.long 0xd7006a03                                           // 000000764C44: D7006A03
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000764C48: 02000105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000764C4C: BF8701A1
	v_add_co_ci_u32_e64 v4, null, s1, v6, vcc_lo               // 000000764C50: D5207C04 01AA0C01
	v_mad_u64_u32 v[1:2], null, s13, 12, v[1:2]                // 000000764C58: D6FE7C01 0405180D
	.long 0xd7006a05                                           // 000000764C60: D7006A05
	v_cndmask_b32_e32 v0, v3, v0, vcc_lo                       // 000000764C64: 02000103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000764C68: BF8700A1
	v_add_co_ci_u32_e64 v6, null, s1, v4, vcc_lo               // 000000764C6C: D5207C06 01AA0801
	.long 0xd7006a07                                           // 000000764C74: D7006A07
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000764C78: 02000100
	v_add_co_ci_u32_e64 v8, null, s1, v1, vcc_lo               // 000000764C7C: D5207C08 01AA0201
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000764C84: BF870094
	.long 0xd7006a09                                           // 000000764C88: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 000000764C8C: 02000105
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 000000764C90: D5207C0A 01AA0C01
	s_clause 0x4                                               // 000000764C98: BF850004
	global_store_b32 v[3:4], v15, off                          // 000000764C9C: DC6A0000 007C0F03
	global_store_b32 v[0:1], v11, off                          // 000000764CA4: DC6A0000 007C0B00
	global_store_b32 v[5:6], v12, off                          // 000000764CAC: DC6A0000 007C0C05
	global_store_b32 v[7:8], v13, off                          // 000000764CB4: DC6A0000 007C0D07
	global_store_b32 v[9:10], v14, off                         // 000000764CBC: DC6A0000 007C0E09
	s_endpgm                                                   // 000000764CC4: BFB00000
		...

