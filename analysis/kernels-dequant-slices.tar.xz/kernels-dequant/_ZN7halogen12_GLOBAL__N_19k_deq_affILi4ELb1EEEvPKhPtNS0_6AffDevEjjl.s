0000000000286400 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb1EEEvPKhPtNS0_6AffDevEjjl>:
; _ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb1EEEvPKhPtNS0_6AffDevEjjl():
	s_load_b64 s[16:17], s[0:1], 0x40                          // 000000286400: F4040400 F8000040
	v_lshl_or_b32 v2, s2, 8, v0                                // 000000286408: D6560002 04011002
	s_mov_b32 s2, exec_lo                                      // 000000286410: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 000000286414: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000286418: BF870001
	.long 0xd4cc007e                                           // 00000028641C: D4CC007E
	v_cndmask_b32_e32 v1, s17, v2, vcc_lo                      // 000000286420: 02020411
	s_cbranch_execz 520                                        // 000000286424: BFA50208 <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb1EEEvPKhPtNS0_6AffDevEjjl+0x848>
	s_clause 0x3                                               // 000000286428: BF850003
	s_load_b128 s[12:15], s[0:1], null                         // 00000028642C: F4080300 F8000000
	s_load_b64 s[18:19], s[0:1], 0x10                          // 000000286434: F4040480 F8000010
	s_load_b64 s[2:3], s[0:1], 0x48                            // 00000028643C: F4040080 F8000048
	s_load_b32 s22, s[0:1], 0x50                               // 000000286444: F4000580 F8000050
	s_cvt_f32_u32 s4, s16                                      // 00000028644C: BE846510
	v_mov_b32_e32 v1, 0                                        // 000000286450: 7E020280
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000286454: BF8702AA
	v_rcp_iflag_f32_e32 v0, s4                                 // 000000286458: 7E005604
	s_load_b256 s[4:11], s[0:1], 0x20                          // 00000028645C: F40C0100 F8000020
	v_readfirstlane_b32 s20, v0                                // 000000286464: 7E280500
	s_waitcnt lgkmcnt(0)                                       // 000000286468: BF89FC07
	s_add_u32 s18, s12, s18                                    // 00000028646C: 8012120C
	s_addc_u32 s19, s13, s19                                   // 000000286470: 8213130D
	s_lshr_b32 s0, s3, 31                                      // 000000286474: 85009F03
	s_mul_f32 s20, s20, 0x4f7ffffe                             // 000000286478: A214FF14 4F7FFFFE
	s_add_u32 s0, s2, s0                                       // 000000286480: 80000002
	s_addc_u32 s1, s3, 0                                       // 000000286484: 82018003
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000286488: BF870009
	s_cvt_u32_f32 s23, s20                                     // 00000028648C: BE976714
	s_ashr_i64 s[20:21], s[0:1], 1                             // 000000286490: 86948100
	s_add_u32 s4, s12, s4                                      // 000000286494: 8004040C
	s_addc_u32 s5, s13, s5                                     // 000000286498: 8205050D
	s_add_u32 s8, s12, s8                                      // 00000028649C: 8008080C
	s_addc_u32 s9, s13, s9                                     // 0000002864A0: 8209090D
	s_sub_i32 s0, 0, s16                                       // 0000002864A4: 81801080
	s_mov_b32 s1, 0                                            // 0000002864A8: BE810080
	s_mul_i32 s0, s0, s23                                      // 0000002864AC: 96001700
	s_lshl_b32 s12, s22, 8                                     // 0000002864B0: 840C8816
	s_mul_hi_u32 s0, s23, s0                                   // 0000002864B4: 96800017
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002864B8: BF870009
	s_add_i32 s13, s23, s0                                     // 0000002864BC: 810D0017
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002864C0: BF870129
	.long 0xd72d0000                                           // 0000002864C4: D72D0000
	v_cndmask_b32_e32 v0, v2, v13, vcc_lo                      // 0000002864C8: 02001B02
	.long 0x7f2a3880                                           // 0000002864CC: 7F2A3880
	.long 0xd72c0003                                           // 0000002864D0: D72C0003
	v_cndmask_b32_e32 v0, v0, v16, vcc_lo                      // 0000002864D4: 02002100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002864D8: BF870091
	v_sub_nc_u32_e32 v3, v2, v3                                // 0000002864DC: 4C060702
	v_subrev_nc_u32_e32 v5, s16, v3                            // 0000002864E0: 4E0A0610
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 0000002864E4: 7C960610
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002864E8: BF870092
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v0// 0000002864EC: CA600B03 03040081
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 0000002864F4: 02000900
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002864F8: BF870112
	v_cmp_le_u32_e32 vcc_lo, s16, v3                           // 0000002864FC: 7C960610
	v_add_nc_u32_e32 v4, 1, v0                                 // 000000286500: 4A080081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000286504: BF870091
	v_cndmask_b32_e32 v0, v0, v4, vcc_lo                       // 000000286508: 02000900
	.long 0xd72c0009                                           // 00000028650C: D72C0009
	v_cndmask_b32_e32 v0, v0, v16, vcc_lo                      // 000000286510: 02002100
	v_mad_u64_u32 v[3:4], null, s20, v0, s[18:19]              // 000000286514: D6FE7C03 004A0014
	v_mad_u64_u32 v[5:6], null, s6, v0, s[4:5]                 // 00000028651C: D6FE7C05 00120006
	v_mad_u64_u32 v[7:8], null, s10, v0, s[8:9]                // 000000286524: D6FE7C07 0022000A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000028652C: BF870224
	v_sub_nc_u32_e32 v13, v2, v9                               // 000000286530: 4C1A1302
	v_add_nc_u32_e32 v2, s12, v2                               // 000000286534: 4A04040C
	v_mad_u64_u32 v[9:10], null, s21, v0, v[4:5]               // 000000286538: D6FE7C09 04120015
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000286540: BF870214
	v_mad_u64_u32 v[10:11], null, s7, v0, v[6:7]               // 000000286544: D6FE7C0A 041A0007
	v_lshlrev_b32_e32 v4, 4, v13                               // 00000028654C: 30081A84
	v_lshlrev_b32_e32 v6, 1, v13                               // 000000286550: 300C1A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000286554: BF870194
	v_mad_u64_u32 v[11:12], null, s11, v0, v[8:9]              // 000000286558: D6FE7C0B 0422000B
	.long 0xd7006a03                                           // 000000286560: D7006A03
	v_cndmask_b32_e32 v1, v3, v4, vcc_lo                       // 000000286564: 02020903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000286568: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v9, vcc_lo                // 00000028656C: D5207C04 01AA1280
	v_ashrrev_i32_e32 v9, 31, v6                               // 000000286574: 34120C9F
	.long 0xd7006a08                                           // 000000286578: D7006A08
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000028657C: 02020D05
	global_load_b128 v[3:6], v[3:4], off                       // 000000286580: DC5E0000 037C0003
	v_ashrrev_i32_e32 v12, 1, v13                              // 000000286588: 34181A81
	v_add_co_ci_u32_e64 v9, null, v10, v9, vcc_lo              // 00000028658C: D5207C09 01AA130A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000286594: BF870092
	v_and_b32_e32 v12, -4, v12                                 // 000000286598: 361818C4
	v_ashrrev_i32_e32 v14, 31, v12                             // 00000028659C: 341C189F
	.long 0xd7006a0a                                           // 0000002865A0: D7006A0A
	v_cndmask_b32_e32 v1, v7, v12, vcc_lo                      // 0000002865A4: 02021907
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002865A8: BF870001
	v_add_co_ci_u32_e64 v11, null, v11, v14, vcc_lo            // 0000002865AC: D5207C0B 01AA1D0B
	s_clause 0x1                                               // 0000002865B4: BF850001
	global_load_u16 v12, v[8:9], off                           // 0000002865B8: DC4A0000 0C7C0008
	global_load_b32 v10, v[10:11], off                         // 0000002865C0: DC520000 0A7C000A
	v_cmp_le_u32_e32 vcc_lo, s17, v2                           // 0000002865C8: 7C960411
	s_or_b32 s1, vcc_lo, s1                                    // 0000002865CC: 8C01016A
	s_waitcnt vmcnt(2)                                         // 0000002865D0: BF890BF7
	v_and_b32_e32 v27, 15, v5                                  // 0000002865D4: 36360A8F
	v_mad_u64_u32 v[7:8], null, s2, v0, 0                      // 0000002865D8: D6FE7C07 02020002
	v_bfe_u32 v11, v3, 12, 4                                   // 0000002865E0: D610000B 02111903
	v_bfe_u32 v14, v3, 20, 4                                   // 0000002865E8: D610000E 02112903
	v_bfe_u32 v15, v3, 24, 4                                   // 0000002865F0: D610000F 02113103
	v_and_b32_e32 v16, 15, v4                                  // 0000002865F8: 3620088F
	v_bfe_u32 v19, v4, 4, 4                                    // 0000002865FC: D6100013 02110904
	v_bfe_u32 v22, v4, 8, 4                                    // 000000286604: D6100016 02111104
	v_bfe_u32 v23, v4, 12, 4                                   // 00000028660C: D6100017 02111904
	v_mad_u64_u32 v[8:9], null, s3, v0, v[8:9]                 // 000000286614: D6FE7C08 04220003
	v_lshlrev_b32_e32 v0, 5, v13                               // 00000028661C: 30001A85
	v_bfe_u32 v9, v3, 8, 4                                     // 000000286620: D6100009 02111103
	v_bfe_u32 v13, v3, 16, 4                                   // 000000286628: D610000D 02112103
	v_bfe_u32 v24, v4, 16, 4                                   // 000000286630: D6100018 02112104
	v_bfe_u32 v25, v4, 20, 4                                   // 000000286638: D6100019 02112904
	.long 0xd73c0011                                           // 000000286640: D73C0011
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000286644: 02020081
	v_bfe_u32 v26, v4, 24, 4                                   // 000000286648: D610001A 02113104
	.long 0xd73c0007                                           // 000000286650: D73C0007
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000286654: 02020E81
	v_lshrrev_b32_e32 v4, 28, v4                               // 000000286658: 3208089C
	s_waitcnt vmcnt(1)                                         // 00000028665C: BF8907F7
	v_cvt_f32_ubyte0_e32 v41, v12                              // 000000286660: 7E52230C
	v_cvt_f32_ubyte1_e32 v12, v12                              // 000000286664: 7E18250C
	v_bfe_u32 v28, v5, 4, 4                                    // 000000286668: D610001C 02110905
	v_bfe_u32 v29, v5, 8, 4                                    // 000000286670: D610001D 02111105
	.long 0xd7000000                                           // 000000286678: D7000000
	v_cndmask_b32_e32 v1, s14, v7, vcc_lo                      // 00000028667C: 02020E0E
	v_and_b32_e32 v7, 15, v3                                   // 000000286680: 360E068F
	v_add_co_ci_u32_e64 v20, null, s15, v8, s0                 // 000000286684: D5207C14 0002100F
	v_bfe_u32 v8, v3, 4, 4                                     // 00000028668C: D6100008 02110903
	v_lshrrev_b32_e32 v3, 28, v3                               // 000000286694: 3206069C
	v_bfe_u32 v30, v5, 12, 4                                   // 000000286698: D610001E 02111905
	v_bfe_u32 v31, v5, 16, 4                                   // 0000002866A0: D610001F 02112105
	v_bfe_u32 v32, v5, 20, 4                                   // 0000002866A8: D6100020 02112905
	v_bfe_u32 v33, v5, 24, 4                                   // 0000002866B0: D6100021 02113105
	v_lshrrev_b32_e32 v5, 28, v5                               // 0000002866B8: 320A0A9C
	v_and_b32_e32 v34, 15, v6                                  // 0000002866BC: 36440C8F
	v_bfe_u32 v35, v6, 4, 4                                    // 0000002866C0: D6100023 02110906
	v_bfe_u32 v36, v6, 8, 4                                    // 0000002866C8: D6100024 02111106
	v_bfe_u32 v37, v6, 12, 4                                   // 0000002866D0: D6100025 02111906
	v_bfe_u32 v38, v6, 16, 4                                   // 0000002866D8: D6100026 02112106
	v_bfe_u32 v39, v6, 20, 4                                   // 0000002866E0: D6100027 02112906
	v_bfe_u32 v40, v6, 24, 4                                   // 0000002866E8: D6100028 02113106
	v_lshrrev_b32_e32 v6, 28, v6                               // 0000002866F0: 320C0C9C
	v_cvt_f32_ubyte0_e32 v7, v7                                // 0000002866F4: 7E0E2307
	s_waitcnt vmcnt(0)                                         // 0000002866F8: BF8903F7
	v_fma_mix_f32 v41, v10, v41, neg(0) op_sel_hi:[1,0,0]      // 0000002866FC: CC200029 8A02530A
	v_fma_mix_f32 v42, v10, -v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000286704: CC20082A CA02190A
	v_cvt_f32_ubyte0_e32 v8, v8                                // 00000028670C: 7E102308
	v_cvt_f32_ubyte0_e32 v9, v9                                // 000000286710: 7E122309
	v_cvt_f32_ubyte0_e32 v11, v11                              // 000000286714: 7E16230B
	v_cvt_f32_ubyte0_e32 v13, v13                              // 000000286718: 7E1A230D
	v_cvt_f32_ubyte0_e32 v14, v14                              // 00000028671C: 7E1C230E
	v_cvt_f32_ubyte0_e32 v15, v15                              // 000000286720: 7E1E230F
	v_cvt_f32_ubyte0_e32 v3, v3                                // 000000286724: 7E062303
	v_cvt_f32_ubyte0_e32 v16, v16                              // 000000286728: 7E202310
	v_cvt_f32_ubyte0_e32 v19, v19                              // 00000028672C: 7E262313
	v_cvt_f32_ubyte0_e32 v22, v22                              // 000000286730: 7E2C2316
	v_cvt_f32_ubyte0_e32 v23, v23                              // 000000286734: 7E2E2317
	v_cvt_f32_ubyte0_e32 v24, v24                              // 000000286738: 7E302318
	v_cvt_f32_ubyte0_e32 v25, v25                              // 00000028673C: 7E322319
	v_cvt_f32_ubyte0_e32 v26, v26                              // 000000286740: 7E34231A
	v_cvt_f32_ubyte0_e32 v4, v4                                // 000000286744: 7E082304
	v_cvt_f32_ubyte0_e32 v27, v27                              // 000000286748: 7E36231B
	v_cvt_f32_ubyte0_e32 v28, v28                              // 00000028674C: 7E38231C
	v_cvt_f32_ubyte0_e32 v29, v29                              // 000000286750: 7E3A231D
	v_cvt_f32_ubyte0_e32 v30, v30                              // 000000286754: 7E3C231E
	v_cvt_f32_ubyte0_e32 v31, v31                              // 000000286758: 7E3E231F
	v_cvt_f32_ubyte0_e32 v32, v32                              // 00000028675C: 7E402320
	v_cvt_f32_ubyte0_e32 v33, v33                              // 000000286760: 7E422321
	v_cvt_f32_ubyte0_e32 v5, v5                                // 000000286764: 7E0A2305
	v_cvt_f32_ubyte0_e32 v34, v34                              // 000000286768: 7E442322
	v_cvt_f32_ubyte0_e32 v35, v35                              // 00000028676C: 7E462323
	v_cvt_f32_ubyte0_e32 v36, v36                              // 000000286770: 7E482324
	v_cvt_f32_ubyte0_e32 v37, v37                              // 000000286774: 7E4A2325
	v_cvt_f32_ubyte0_e32 v38, v38                              // 000000286778: 7E4C2326
	v_cvt_f32_ubyte0_e32 v39, v39                              // 00000028677C: 7E4E2327
	v_cvt_f32_ubyte0_e32 v40, v40                              // 000000286780: 7E502328
	v_cvt_f32_ubyte0_e32 v6, v6                                // 000000286784: 7E0C2306
	v_fma_f32 v7, v7, v41, v42                                 // 000000286788: D6130007 04AA5307
	v_fma_f32 v8, v8, v41, v42                                 // 000000286790: D6130008 04AA5308
	v_fma_f32 v9, v9, v41, v42                                 // 000000286798: D6130009 04AA5309
	v_fma_f32 v10, v11, v41, v42                               // 0000002867A0: D613000A 04AA530B
	v_fma_f32 v11, v13, v41, v42                               // 0000002867A8: D613000B 04AA530D
	v_fma_f32 v12, v14, v41, v42                               // 0000002867B0: D613000C 04AA530E
	v_fma_f32 v13, v15, v41, v42                               // 0000002867B8: D613000D 04AA530F
	v_fma_f32 v3, v3, v41, v42                                 // 0000002867C0: D6130003 04AA5303
	v_fma_f32 v14, v16, v41, v42                               // 0000002867C8: D613000E 04AA5310
	v_fma_f32 v15, v19, v41, v42                               // 0000002867D0: D613000F 04AA5313
	v_fma_f32 v16, v22, v41, v42                               // 0000002867D8: D6130010 04AA5316
	v_fma_f32 v19, v23, v41, v42                               // 0000002867E0: D6130013 04AA5317
	v_fma_f32 v22, v24, v41, v42                               // 0000002867E8: D6130016 04AA5318
	v_fma_f32 v23, v25, v41, v42                               // 0000002867F0: D6130017 04AA5319
	v_fma_f32 v24, v26, v41, v42                               // 0000002867F8: D6130018 04AA531A
	v_fma_f32 v4, v4, v41, v42                                 // 000000286800: D6130004 04AA5304
	v_fma_f32 v25, v27, v41, v42                               // 000000286808: D6130019 04AA531B
	v_fma_f32 v26, v28, v41, v42                               // 000000286810: D613001A 04AA531C
	v_fma_f32 v27, v29, v41, v42                               // 000000286818: D613001B 04AA531D
	v_fma_f32 v28, v30, v41, v42                               // 000000286820: D613001C 04AA531E
	v_fma_f32 v29, v31, v41, v42                               // 000000286828: D613001D 04AA531F
	v_fma_f32 v30, v32, v41, v42                               // 000000286830: D613001E 04AA5320
	v_fma_f32 v31, v33, v41, v42                               // 000000286838: D613001F 04AA5321
	v_fma_f32 v5, v5, v41, v42                                 // 000000286840: D6130005 04AA5305
	v_fma_f32 v32, v34, v41, v42                               // 000000286848: D6130020 04AA5322
	v_fma_f32 v33, v35, v41, v42                               // 000000286850: D6130021 04AA5323
	v_fma_f32 v34, v36, v41, v42                               // 000000286858: D6130022 04AA5324
	v_fma_f32 v35, v37, v41, v42                               // 000000286860: D6130023 04AA5325
	v_fma_f32 v36, v38, v41, v42                               // 000000286868: D6130024 04AA5326
	v_fma_f32 v37, v39, v41, v42                               // 000000286870: D6130025 04AA5327
	v_fma_f32 v38, v40, v41, v42                               // 000000286878: D6130026 04AA5328
	v_fmac_f32_e32 v42, v6, v41                                // 000000286880: 56545306
	v_bfe_u32 v6, v7, 16, 1                                    // 000000286884: D6100006 02052107
	v_bfe_u32 v39, v8, 16, 1                                   // 00000028688C: D6100027 02052108
	v_bfe_u32 v40, v9, 16, 1                                   // 000000286894: D6100028 02052109
	v_bfe_u32 v41, v10, 16, 1                                  // 00000028689C: D6100029 0205210A
	v_bfe_u32 v43, v11, 16, 1                                  // 0000002868A4: D610002B 0205210B
	v_add3_u32 v6, v7, v6, 0x7fff                              // 0000002868AC: D6550006 03FE0D07 00007FFF
	v_bfe_u32 v44, v12, 16, 1                                  // 0000002868B8: D610002C 0205210C
	v_bfe_u32 v45, v13, 16, 1                                  // 0000002868C0: D610002D 0205210D
	v_bfe_u32 v46, v3, 16, 1                                   // 0000002868C8: D610002E 02052103
	v_add3_u32 v7, v8, v39, 0x7fff                             // 0000002868D0: D6550007 03FE4F08 00007FFF
	v_add3_u32 v8, v9, v40, 0x7fff                             // 0000002868DC: D6550008 03FE5109 00007FFF
	.long 0x7e2a3986                                           // 0000002868E8: 7E2A3986
	v_bfe_u32 v54, v4, 16, 1                                   // 0000002868EC: D6100036 02052104
	v_add3_u32 v9, v10, v41, 0x7fff                            // 0000002868F4: D6550009 03FE530A 00007FFF
	v_add3_u32 v10, v11, v43, 0x7fff                           // 000000286900: D655000A 03FE570B 00007FFF
	v_add3_u32 v11, v12, v44, 0x7fff                           // 00000028690C: D655000B 03FE590C 00007FFF
	v_add3_u32 v12, v13, v45, 0x7fff                           // 000000286918: D655000C 03FE5B0D 00007FFF
	v_add3_u32 v13, v3, v46, 0x7fff                            // 000000286924: D655000D 03FE5D03 00007FFF
	v_and_or_b32 v3, 0xffff0000, v7, v21                       // 000000286930: D6570003 04560EFF FFFF0000
	.long 0x7e2a3988                                           // 00000028693C: 7E2A3988
	v_bfe_u32 v47, v14, 16, 1                                  // 000000286940: D610002F 0205210E
	v_bfe_u32 v62, v5, 16, 1                                   // 000000286948: D610003E 02052105
	v_add3_u32 v39, v4, v54, 0x7fff                            // 000000286950: D6550027 03FE6D04 00007FFF
	v_bfe_u32 v48, v15, 16, 1                                  // 00000028695C: D6100030 0205210F
	v_and_or_b32 v4, 0xffff0000, v9, v21                       // 000000286964: D6570004 045612FF FFFF0000
	.long 0x7e2a398a                                           // 000000286970: 7E2A398A
	v_bfe_u32 v49, v16, 16, 1                                  // 000000286974: D6100031 02052110
	v_add3_u32 v14, v14, v47, 0x7fff                           // 00000028697C: D655000E 03FE5F0E 00007FFF
	v_add3_u32 v40, v5, v62, 0x7fff                            // 000000286988: D6550028 03FE7D05 00007FFF
	v_bfe_u32 v50, v19, 16, 1                                  // 000000286994: D6100032 02052113
	v_and_or_b32 v5, 0xffff0000, v11, v21                      // 00000028699C: D6570005 045616FF FFFF0000
	.long 0x7e2a398c                                           // 0000002869A8: 7E2A398C
	v_bfe_u32 v51, v22, 16, 1                                  // 0000002869AC: D6100033 02052116
	v_add3_u32 v15, v15, v48, 0x7fff                           // 0000002869B4: D655000F 03FE610F 00007FFF
	v_add3_u32 v16, v16, v49, 0x7fff                           // 0000002869C0: D6550010 03FE6310 00007FFF
	v_bfe_u32 v52, v23, 16, 1                                  // 0000002869CC: D6100034 02052117
	v_and_or_b32 v6, 0xffff0000, v13, v21                      // 0000002869D4: D6570006 04561AFF FFFF0000
	.long 0x7e2a398e                                           // 0000002869E0: 7E2A398E
	v_bfe_u32 v53, v24, 16, 1                                  // 0000002869E4: D6100035 02052118
	v_add3_u32 v19, v19, v50, 0x7fff                           // 0000002869EC: D6550013 03FE6513 00007FFF
	v_add3_u32 v22, v22, v51, 0x7fff                           // 0000002869F8: D6550016 03FE6716 00007FFF
	v_bfe_u32 v55, v25, 16, 1                                  // 000000286A04: D6100037 02052119
	v_and_or_b32 v7, 0xffff0000, v15, v21                      // 000000286A0C: D6570007 04561EFF FFFF0000
	.long 0x7e2a3990                                           // 000000286A18: 7E2A3990
	v_add3_u32 v23, v23, v52, 0x7fff                           // 000000286A1C: D6550017 03FE6917 00007FFF
	v_add3_u32 v24, v24, v53, 0x7fff                           // 000000286A28: D6550018 03FE6B18 00007FFF
	v_bfe_u32 v56, v26, 16, 1                                  // 000000286A34: D6100038 0205211A
	v_bfe_u32 v57, v27, 16, 1                                  // 000000286A3C: D6100039 0205211B
	v_and_or_b32 v8, 0xffff0000, v19, v21                      // 000000286A44: D6570008 045626FF FFFF0000
	.long 0x7e2a3996                                           // 000000286A50: 7E2A3996
	v_add3_u32 v25, v25, v55, 0x7fff                           // 000000286A54: D6550019 03FE6F19 00007FFF
	v_bfe_u32 v58, v28, 16, 1                                  // 000000286A60: D610003A 0205211C
	v_bfe_u32 v59, v29, 16, 1                                  // 000000286A68: D610003B 0205211D
	v_add3_u32 v26, v26, v56, 0x7fff                           // 000000286A70: D655001A 03FE711A 00007FFF
	v_and_or_b32 v9, 0xffff0000, v23, v21                      // 000000286A7C: D6570009 04562EFF FFFF0000
	.long 0x7e2a3998                                           // 000000286A88: 7E2A3998
	v_add3_u32 v27, v27, v57, 0x7fff                           // 000000286A8C: D655001B 03FE731B 00007FFF
	v_bfe_u32 v60, v30, 16, 1                                  // 000000286A98: D610003C 0205211E
	v_bfe_u32 v61, v31, 16, 1                                  // 000000286AA0: D610003D 0205211F
	v_add3_u32 v28, v28, v58, 0x7fff                           // 000000286AA8: D655001C 03FE751C 00007FFF
	v_and_or_b32 v10, 0xffff0000, v39, v21                     // 000000286AB4: D657000A 04564EFF FFFF0000
	.long 0x7e2a3999                                           // 000000286AC0: 7E2A3999
	v_add3_u32 v29, v29, v59, 0x7fff                           // 000000286AC4: D655001D 03FE771D 00007FFF
	v_bfe_u32 v63, v32, 16, 1                                  // 000000286AD0: D610003F 02052120
	v_add3_u32 v30, v30, v60, 0x7fff                           // 000000286AD8: D655001E 03FE791E 00007FFF
	v_add3_u32 v31, v31, v61, 0x7fff                           // 000000286AE4: D655001F 03FE7B1F 00007FFF
	v_and_or_b32 v11, 0xffff0000, v26, v21                     // 000000286AF0: D657000B 045634FF FFFF0000
	.long 0x7e2a399b                                           // 000000286AFC: 7E2A399B
	v_bfe_u32 v64, v33, 16, 1                                  // 000000286B00: D6100040 02052121
	v_bfe_u32 v65, v34, 16, 1                                  // 000000286B08: D6100041 02052122
	v_add3_u32 v32, v32, v63, 0x7fff                           // 000000286B10: D6550020 03FE7F20 00007FFF
	v_bfe_u32 v66, v35, 16, 1                                  // 000000286B1C: D6100042 02052123
	v_and_or_b32 v12, 0xffff0000, v28, v21                     // 000000286B24: D657000C 045638FF FFFF0000
	.long 0x7e2a399d                                           // 000000286B30: 7E2A399D
	v_bfe_u32 v67, v36, 16, 1                                  // 000000286B34: D6100043 02052124
	v_add3_u32 v33, v33, v64, 0x7fff                           // 000000286B3C: D6550021 03FE8121 00007FFF
	v_add3_u32 v34, v34, v65, 0x7fff                           // 000000286B48: D6550022 03FE8322 00007FFF
	v_bfe_u32 v68, v37, 16, 1                                  // 000000286B54: D6100044 02052125
	v_and_or_b32 v13, 0xffff0000, v30, v21                     // 000000286B5C: D657000D 04563CFF FFFF0000
	.long 0x7e2a399f                                           // 000000286B68: 7E2A399F
	v_bfe_u32 v69, v38, 16, 1                                  // 000000286B6C: D6100045 02052126
	v_add3_u32 v35, v35, v66, 0x7fff                           // 000000286B74: D6550023 03FE8523 00007FFF
	v_add3_u32 v19, v36, v67, 0x7fff                           // 000000286B80: D6550013 03FE8724 00007FFF
	v_bfe_u32 v70, v42, 16, 1                                  // 000000286B8C: D6100046 0205212A
	v_and_or_b32 v14, 0xffff0000, v40, v21                     // 000000286B94: D657000E 045650FF FFFF0000
	.long 0x7e2a39a0                                           // 000000286BA0: 7E2A39A0
	v_add3_u32 v22, v37, v68, 0x7fff                           // 000000286BA4: D6550016 03FE8925 00007FFF
	v_add3_u32 v23, v38, v69, 0x7fff                           // 000000286BB0: D6550017 03FE8B26 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000286BBC: BF8700A3
	v_and_or_b32 v15, 0xffff0000, v33, v21                     // 000000286BC0: D657000F 045642FF FFFF0000
	.long 0x7e2a39a2                                           // 000000286BCC: 7E2A39A2
	v_and_or_b32 v16, 0xffff0000, v35, v21                     // 000000286BD0: D6570010 045646FF FFFF0000
	.long 0x7e2a3993                                           // 000000286BDC: 7E2A3993
	.long 0xd7000013                                           // 000000286BE0: D7000013
	v_cndmask_b32_e32 v1, v0, v17, vcc_lo                      // 000000286BE4: 02022300
	v_add3_u32 v0, v42, v70, 0x7fff                            // 000000286BE8: D6550000 03FE8D2A 00007FFF
	v_add_co_ci_u32_e64 v20, null, v20, v18, s0                // 000000286BF4: D5207C14 00022514
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000286BFC: BF8700A4
	v_and_or_b32 v17, 0xffff0000, v22, v21                     // 000000286C00: D6570011 04562CFF FFFF0000
	.long 0x7e2a3997                                           // 000000286C0C: 7E2A3997
	v_and_or_b32 v18, 0xffff0000, v0, v21                      // 000000286C10: D6570012 045600FF FFFF0000
	s_clause 0x3                                               // 000000286C1C: BF850003
	global_store_b128 v[19:20], v[3:6], off                    // 000000286C20: DC760000 007C0313
	global_store_b128 v[19:20], v[7:10], off offset:16         // 000000286C28: DC760010 007C0713
	global_store_b128 v[19:20], v[11:14], off offset:32        // 000000286C30: DC760020 007C0B13
	global_store_b128 v[19:20], v[15:18], off offset:48        // 000000286C38: DC760030 007C0F13
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000286C40: 917E017E
	s_cbranch_execnz 65054                                     // 000000286C44: BFA6FE1E <_ZN7halogen12_GLOBAL__N_19k_deq_affILi4ELb1EEEvPKhPtNS0_6AffDevEjjl+0xc0>
	s_endpgm                                                   // 000000286C48: BFB00000
		...

