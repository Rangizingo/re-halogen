0000000000837f00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 000000837F00: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 000000837F08: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000837F0C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 000000837F10: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 000000837F14: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 000000837F18: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000837F1C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 000000837F20: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 000000837F28: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 000000837F2C: 38200202
	.long 0x7f023880                                           // 000000837F30: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 000000837F34: BF89FC07
	s_clause 0x1                                               // 000000837F38: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 000000837F3C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 000000837F44: DC520000 03080003
	.long 0xd4540002                                           // 000000837F4C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 000000837F50: 02022010
	s_add_u32 s24, s8, s20                                     // 000000837F54: 80181408
	s_addc_u32 s25, s9, s21                                    // 000000837F58: 82191509
	s_ashr_i32 s4, s15, 31                                     // 000000837F5C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000837F60: BF870159
	s_lshr_b32 s4, s4, 27                                      // 000000837F64: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 000000837F68: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 000000837F70: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 000000837F78: 8004040E
	s_addc_u32 s5, s15, 0                                      // 000000837F7C: 8205800F
	.long 0xd72c0004                                           // 000000837F80: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 000000837F84: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 000000837F88: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 000000837F90: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000837F94: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 000000837F98: B3860081
	.long 0xd4440004                                           // 000000837F9C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 000000837FA0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 000000837FA4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 000000837FA8: B2860080
	.long 0xd700050e                                           // 000000837FAC: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 000000837FB0: 02021818
	s_cselect_b32 s7, -1, 0                                    // 000000837FB4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000837FB8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 000000837FBC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 000000837FC0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 000000837FC4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 000000837FCC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 000000837FD0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 000000837FD8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 000000837FE4: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 000000837FE8: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000837FEC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 000000837FF0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 000000837FFC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838000: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 000000838004: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 00000083800C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000838018: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 00000083801C: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 000000838024: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 00000083802C: BF89FC07
	s_barrier                                                  // 000000838030: BFBD0000
	buffer_gl0_inv                                             // 000000838034: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 00000083803C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 000000838040: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 000000838048: BE852004
	s_cbranch_execz 10                                         // 00000083804C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 000000838050: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838054: BF870091
	.long 0xd7006a02                                           // 000000838058: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 00000083805C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 000000838060: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 000000838068: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 000000838070: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 000000838074: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 000000838078: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 00000083807C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 000000838080: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838084: BF870001
	.long 0xd4c4007e                                           // 000000838088: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000083808C: 02020406
	s_cbranch_execz 10                                         // 000000838090: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 000000838094: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838098: BF870091
	.long 0xd7006a01                                           // 00000083809C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008380A0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008380A4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008380AC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008380B4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008380B8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008380BC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 0000008380C0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008380C4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008380CC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008380D0: BF870002
	.long 0xd4c4007e                                           // 0000008380D4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008380D8: 02020806
	s_cbranch_execz 10                                         // 0000008380DC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008380E0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008380E4: BF870091
	.long 0xd7006a04                                           // 0000008380E8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008380EC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008380F0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000008380F8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 000000838100: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 000000838104: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 000000838108: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 00000083810C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 000000838110: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838114: BF870001
	.long 0xd4c4007e                                           // 000000838118: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 00000083811C: 02020806
	s_cbranch_execz 10                                         // 000000838120: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 000000838124: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838128: BF870091
	.long 0xd7006a03                                           // 00000083812C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 000000838130: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 000000838134: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 00000083813C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 000000838144: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 000000838148: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 00000083814C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 000000838150: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 000000838154: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 00000083815C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000838160: BF870002
	.long 0xd4c4007e                                           // 000000838164: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 000000838168: 02020C06
	s_cbranch_execz 10                                         // 00000083816C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 000000838170: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838174: BF870091
	.long 0xd7006a06                                           // 000000838178: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 00000083817C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 000000838180: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 000000838188: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 000000838190: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 000000838194: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 000000838198: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 00000083819C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000008381A4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008381A8: BF870001
	.long 0xd4c4007e                                           // 0000008381AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008381B0: 02020C06
	s_cbranch_execz 10                                         // 0000008381B4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008381B8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008381BC: BF870091
	.long 0xd7006a05                                           // 0000008381C0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008381C4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008381C8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008381D0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008381D8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008381DC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008381E0: 8C7E047E
	v_or_b32_e32 v10, 0x60, v23                                // 0000008381E4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008381EC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008381F4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008381F8: BF870002
	.long 0xd4c4007e                                           // 0000008381FC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000838200: 02021406
	s_cbranch_execz 10                                         // 000000838204: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 000000838208: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083820C: BF870091
	.long 0xd7006a0a                                           // 000000838210: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 000000838214: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000838218: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 000000838220: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 000000838228: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 00000083822C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 000000838230: 8C7E047E
	v_or_b32_e32 v10, 0x70, v23                                // 000000838234: 38142EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 00000083823C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838240: BF870001
	.long 0xd4c4007e                                           // 000000838244: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000838248: 02021406
	s_cbranch_execz 10                                         // 00000083824C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 000000838250: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838254: BF870091
	.long 0xd7006a0a                                           // 000000838258: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 00000083825C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 000000838260: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 000000838268: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 000000838270: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 000000838274: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 000000838278: 8C7E047E
	s_branch 9                                                 // 00000083827C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 000000838280: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838284: BF870001
	v_mov_b32_e32 v1, v0                                       // 000000838288: 7E020300
	v_mov_b32_e32 v2, v0                                       // 00000083828C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 000000838290: 7E060300
	v_mov_b32_e32 v4, v0                                       // 000000838294: 7E080300
	v_mov_b32_e32 v5, v0                                       // 000000838298: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 00000083829C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008382A0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008382A4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008382A8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008382AC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 0000008382B0: 7E340280
	s_add_u32 s18, s14, s18                                    // 0000008382B4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008382B8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008382BC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008382C4: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000008382C8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008382CC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008382D4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008382D8: 02002708
	.long 0xd72c0014                                           // 0000008382DC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008382E0: 02002509
	.long 0xd4440004                                           // 0000008382E4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008382E8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008382EC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000008382F4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000008382F8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000008382FC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 000000838304: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 000000838308: BE852004
	s_cbranch_execz 21                                         // 00000083830C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 000000838310: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838318: BF870091
	.long 0xd7006a08                                           // 00000083831C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 000000838320: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 000000838324: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000083832C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 000000838330: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 000000838338: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 00000083833C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838340: BF870091
	.long 0xd7006a0e                                           // 000000838344: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 000000838348: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 00000083834C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 000000838354: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 00000083835C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 000000838360: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 000000838364: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 000000838368: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 00000083836C: BE852004
	s_cbranch_execz 305                                        // 000000838370: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 000000838374: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 00000083837C: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 000000838380: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000838384: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 000000838388: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 000000838390: CA220080 14122E85
	.long 0xd7006a0c                                           // 000000838398: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000083839C: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008383A0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008383A4: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 0000008383AC: D656001D 03FD0917 00000100
	.long 0xd7006a0c                                           // 0000008383B8: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008383BC: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008383C0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008383C4: D5207C0D 01AA1A09
	v_mov_b32_e32 v30, v23                                     // 0000008383CC: 7E3C0317
	.long 0xd7006a15                                           // 0000008383D0: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000008383D4: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008383D8: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008383DC: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000008383E4: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000008383E8: 7E340314
	s_mov_b32 s7, 0                                            // 0000008383EC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008383F0: 8488810E
	s_branch 243                                               // 0000008383F4: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x8c4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008383F8: 8C7E0E7E
	.long 0xd73c0020                                           // 0000008383FC: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 000000838400: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 000000838404: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 00000083840C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 000000838410: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 000000838414: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 000000838418: 368612FF 000000FF
	.long 0xd7006a38                                           // 000000838420: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 000000838424: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000838428: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 00000083842C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 000000838434: 30808082
	.long 0xd7006a3c                                           // 000000838438: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 00000083843C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838440: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 000000838444: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 00000083844C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 000000838454: D8D80000 40000040
	s_clause 0x7                                               // 00000083845C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 000000838460: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 000000838468: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 000000838470: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 000000838478: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000838480: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 000000838488: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 000000838490: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 000000838498: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000008384A0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000008384A8: 32881286
	ds_load_b32 v65, v65                                       // 0000008384AC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000008384B4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008384B8: 32121296
	ds_load_b32 v66, v66                                       // 0000008384BC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008384C4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000008384CC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000008384D0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000008384D8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008384E0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008384E8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000008384F0: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000008384F8: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 000000838500: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 000000838508: D8D80000 09000009
	.long 0xd7006a15                                           // 000000838510: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 000000838514: 02014115
	v_add_nc_u32_e32 v29, 0x100, v29                           // 000000838518: 4A3A3AFF 00000100
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 000000838520: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 000000838528: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000083852C: BF870009
	s_or_b32 s7, s4, s7                                        // 000000838530: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000838534: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 000000838538: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 000000838540: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 000000838544: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 00000083854C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000838554: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 000000838558: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 000000838560: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 000000838564: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 00000083856C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 000000838570: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 000000838574: 32141496
	s_waitcnt lgkmcnt(5)                                       // 000000838578: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 00000083857C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 000000838584: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 00000083858C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 000000838594: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 000000838598: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 00000083859C: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000008385A0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000008385A8: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000008385B0: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000008385B8: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008385C0: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008385C4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000008385C8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000008385D0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000008385D4: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008385DC: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000008385E4: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000008385E8: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000008385F0: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000008385F4: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000008385FC: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 000000838604: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 00000083860C: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 000000838614: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 00000083861C: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 000000838624: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 000000838628: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 000000838630: D501002A 000E011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 000000838638: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 00000083863C: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 000000838644: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 000000838648: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 00000083864C: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 000000838654: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 00000083865C: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 000000838664: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 00000083866C: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 000000838674: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 00000083867C: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 000000838684: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 00000083868C: D5010025 000E0D05
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 000000838694: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 00000083869C: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000008386A4: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000008386A8: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000008386B0: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000008386B4: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 0000008386BC: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 0000008386C4: D5010020 000E0300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000008386CC: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008386D4: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000008386D8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 0000008386E0: D5010023 000E0903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000008386E8: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008386F0: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000008386F4: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 0000008386FC: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 000000838704: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 000000838708: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000838710: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 000000838714: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 00000083871C: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000838720: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 000000838724: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 00000083872C: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 000000838730: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 000000838738: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 000000838740: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 000000838744: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 000000838748: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 000000838750: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 000000838758: 7E4E0307
	v_add_nc_u32_e32 v19, 0x200, v19                           // 00000083875C: 4A2626FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 000000838764: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 000000838768: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 000000838770: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 000000838778: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083877C: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 000000838780: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 000000838788: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838790: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 000000838794: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 000000838798: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 00000083879C: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000008387A4: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000008387AC: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000008387B4: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000008387BC: 917E077E
	s_cbranch_execz 28                                         // 0000008387C0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 0000008387C4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 0000008387C8: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000008387D0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000008387D8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008387DC: BF870003
	.long 0xd4430004                                           // 0000008387E0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008387E4: 02023C06
	s_mov_b32 s14, exec_lo                                     // 0000008387E8: BE8E007E
	.long 0xd4c4007e                                           // 0000008387EC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008387F0: 02023C06
	s_cbranch_execz 65280                                      // 0000008387F4: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	.long 0xd7006a0c                                           // 0000008387F8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008387FC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000838800: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 000000838804: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 00000083880C: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 000000838810: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 000000838814: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 00000083881C: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	global_load_d16_b16 v31, v[21:22], off                     // 000000838820: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 000000838828: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 00000083882C: 7E3E171F
	s_branch 65265                                             // 000000838830: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	s_or_b32 exec_lo, exec_lo, s7                              // 000000838834: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000838838: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000083883C: 8C7E057E
	.long 0xd71f0000                                           // 000000838840: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000838844: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 000000838848: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 00000083884C: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 000000838850: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000838854: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 000000838858: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000083885C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000838860: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000838864: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000838868: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 00000083886C: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000838870: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 000000838874: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 00000083887C: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 000000838880: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 000000838888: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 000000838890: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 000000838898: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 00000083889C: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000008388A0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000008388A4: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000008388A8: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000008388B0: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008388B4: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008388B8: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000008388BC: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000008388C0: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000008388C4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008388CC: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000008388D4: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008388D8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008388DC: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000008388E0: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008388E4: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000008388E8: BF89FC17
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000008388EC: C9220702 00040082
	s_and_b32 s2, vcc_lo, s2                                   // 0000008388F4: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000008388F8: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000008388FC: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 000000838900: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 000000838908: DACC0000 03000105
	s_and_saveexec_b32 s3, s2                                  // 000000838910: BE832002
	s_cbranch_execz 102                                        // 000000838914: BFA50066 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb1ELi3ELi1EEEvPKhPKtPvlllllS6_f+0xbb0>
	s_load_b32 s0, s[0:1], 0x48                                // 000000838918: F4000000 F8000048
	s_waitcnt lgkmcnt(0)                                       // 000000838920: BF89FC07
	v_dual_add_f32 v0, v0, v2 :: v_dual_add_f32 v1, v1, v3     // 000000838924: C9080500 00000701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083892C: BF870111
	v_bfe_u32 v2, v0, 16, 1                                    // 000000838930: D6100002 02052100
	v_bfe_u32 v3, v1, 16, 1                                    // 000000838938: D6100003 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838940: BF870112
	v_add3_u32 v0, v0, v2, 0x7fff                              // 000000838944: D6550000 03FE0500 00007FFF
	v_add3_u32 v1, v1, v3, 0x7fff                              // 000000838950: D6550001 03FE0701 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083895C: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 000000838960: 360202FF FFFF0000
	v_dual_mul_f32 v1, s0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 000000838968: C8E40200 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838974: BF870091
	v_dual_mul_f32 v0, s0, v0 :: v_dual_mul_f32 v1, 0xbfb8aa3b, v1// 000000838978: C8C60000 000002FF BFB8AA3B
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000838984: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000083898C: BF870092
	v_exp_f32_e32 v1, v1                                       // 000000838990: 7E024B01
	v_exp_f32_e32 v0, v0                                       // 000000838994: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000838998: BF870095
	v_dual_add_f32 v3, 1.0, v1 :: v_dual_add_f32 v2, 1.0, v0   // 00000083899C: C90802F2 030200F2
	v_div_scale_f32 v1, null, v3, v3, 1.0                      // 0000008389A4: D6FC7C01 03CA0703
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008389AC: BF8701B2
	v_div_scale_f32 v0, null, v2, v2, 1.0                      // 0000008389B0: D6FC7C00 03CA0502
	s_waitcnt vmcnt(0)                                         // 0000008389B8: BF8903F7
	v_div_scale_f32 v8, vcc_lo, 1.0, v2, 1.0                   // 0000008389BC: D6FC6A08 03CA04F2
	v_rcp_f32_e32 v5, v1                                       // 0000008389C4: 7E0A5501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000008389C8: BF870312
	v_rcp_f32_e32 v4, v0                                       // 0000008389CC: 7E085500
	v_fma_f32 v7, -v1, v5, 1.0                                 // 0000008389D0: D6130007 23CA0B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008389D8: BF870095
	v_fma_f32 v6, -v0, v4, 1.0                                 // 0000008389DC: D6130006 23CA0900
	v_dual_fmac_f32 v5, v7, v5 :: v_dual_fmac_f32 v4, v6, v4   // 0000008389E4: C8000B07 05040906
	v_div_scale_f32 v6, s0, 1.0, v3, 1.0                       // 0000008389EC: D6FC0006 03CA06F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008389F4: BF870112
	v_mul_f32_e32 v7, v8, v4                                   // 0000008389F8: 100E0908
	v_mul_f32_e32 v9, v6, v5                                   // 0000008389FC: 10120B06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838A00: BF870112
	v_fma_f32 v10, -v0, v7, v8                                 // 000000838A04: D613000A 24220F00
	v_fma_f32 v11, -v1, v9, v6                                 // 000000838A0C: D613000B 241A1301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838A14: BF870112
	v_fmac_f32_e32 v7, v10, v4                                 // 000000838A18: 560E090A
	v_fmac_f32_e32 v9, v11, v5                                 // 000000838A1C: 56120B0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000838A20: BF870112
	v_fma_f32 v0, -v0, v7, v8                                  // 000000838A24: D6130000 24220F00
	v_fma_f32 v1, -v1, v9, v6                                  // 000000838A2C: D6130001 241A1301
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000838A34: BF870132
	v_div_fmas_f32 v4, v0, v4, v7                              // 000000838A38: D6370004 041E0900
	s_mov_b32 vcc_lo, s0                                       // 000000838A40: BEEA0000
	s_lshl_b64 s[0:1], s[16:17], 2                             // 000000838A44: 84808210
	v_div_fmas_f32 v5, v1, v5, v9                              // 000000838A48: D6370005 04260B01
	.long 0xd73c0000                                           // 000000838A50: D73C0000
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 000000838A54: 02022082
	v_div_fixup_f32 v2, v4, v2, 1.0                            // 000000838A58: D6270002 03CA0504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000838A60: BF870193
	v_div_fixup_f32 v3, v5, v3, 1.0                            // 000000838A64: D6270003 03CA0705
	.long 0xd7006a00                                           // 000000838A6C: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000838A70: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000838A74: BF870211
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000838A78: D5207C01 01AA020D
	v_add_f32_e32 v4, v2, v2                                   // 000000838A80: 06080502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000838A84: BF870223
	.long 0xd7006a02                                           // 000000838A88: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000838A8C: 02000100
	v_add_f32_e32 v5, v3, v3                                   // 000000838A90: 060A0703
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 000000838A94: D5207C03 01AA0201
	s_clause 0x1                                               // 000000838A9C: BF850001
	global_store_b32 v[0:1], v4, off                           // 000000838AA0: DC6A0000 007C0400
	global_store_b32 v[2:3], v5, off                           // 000000838AA8: DC6A0000 007C0502
	s_endpgm                                                   // 000000838AB0: BFB00000
		...

