00000000008f8c00 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_>:
; _ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_():
	s_load_b32 s30, s[0:1], 0x8                                // 0000008F8C00: F4000780 F8000008
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000008F8C08: 30040082
	s_waitcnt lgkmcnt(0)                                       // 0000008F8C0C: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s30, v0                           // 0000008F8C10: 7C88001E
	s_and_saveexec_b32 s2, vcc_lo                              // 0000008F8C14: BE82206A
	s_cbranch_execz 8                                          // 0000008F8C18: BFA50008 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x3c>
	s_load_b64 s[4:5], s[0:1], null                            // 0000008F8C1C: F4040100 F8000000
	s_waitcnt lgkmcnt(0)                                       // 0000008F8C24: BF89FC07
	global_load_b32 v1, v2, s[4:5]                             // 0000008F8C28: DC520000 01040002
	s_waitcnt vmcnt(0)                                         // 0000008F8C30: BF8903F7
	ds_store_b32 v2, v1                                        // 0000008F8C34: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008F8C3C: 8C7E027E
	s_clause 0x1                                               // 0000008F8C40: BF850001
	s_load_b256 s[20:27], s[0:1], 0x10                         // 0000008F8C44: F40C0500 F8000010
	s_load_b64 s[28:29], s[0:1], 0x30                          // 0000008F8C4C: F4040700 F8000030
	v_mov_b32_e32 v3, 0                                        // 0000008F8C54: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000008F8C58: 7E0A0280
	s_mov_b32 s1, 0                                            // 0000008F8C5C: BE810080
	s_waitcnt lgkmcnt(0)                                       // 0000008F8C60: BF89FC07
	s_barrier                                                  // 0000008F8C64: BFBD0000
	buffer_gl0_inv                                             // 0000008F8C68: E0AC0000 00000000
	s_and_saveexec_b32 s31, vcc_lo                             // 0000008F8C70: BE9F206A
	s_cbranch_execz 208                                        // 0000008F8C74: BFA500D0 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x3b8>
	ds_load_b32 v1, v2                                         // 0000008F8C78: D8D80000 01000002
	s_add_i32 s0, s30, -1                                      // 0000008F8C80: 8100C11E
	s_and_b32 s33, s30, 7                                      // 0000008F8C84: 8B21871E
	s_mov_b32 s2, -1                                           // 0000008F8C88: BE8200C1
	s_cmp_lt_u32 s0, 7                                         // 0000008F8C8C: BF0A8700
	s_mov_b32 s34, 7                                           // 0000008F8C90: BEA20087
	s_cbranch_scc1 142                                         // 0000008F8C94: BFA2008E <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x2d0>
	v_mov_b32_e32 v3, 0                                        // 0000008F8C98: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000008F8C9C: 7E0A0280
	s_and_b32 s0, s30, -8                                      // 0000008F8CA0: 8B00C81E
	s_mov_b32 s35, 0                                           // 0000008F8CA4: BEA30080
	s_sub_i32 s36, 0, s0                                       // 0000008F8CA8: 81A40080
	s_mov_b32 s37, -1                                          // 0000008F8CAC: BEA500C1
	v_mov_b32_e32 v4, s35                                      // 0000008F8CB0: 7E080223
	s_add_i32 s0, s34, -7                                      // 0000008F8CB4: 8100C722
	s_add_i32 s1, s34, -6                                      // 0000008F8CB8: 8101C622
	s_add_i32 s3, s34, -5                                      // 0000008F8CBC: 8103C522
	s_add_i32 s4, s34, -4                                      // 0000008F8CC0: 8104C422
	ds_load_b128 v[6:9], v4                                    // 0000008F8CC4: DBFC0000 06000004
	ds_load_b128 v[10:13], v4 offset:16                        // 0000008F8CCC: DBFC0010 0A000004
	s_add_i32 s5, s34, -3                                      // 0000008F8CD4: 8105C322
	s_add_i32 s6, s34, -2                                      // 0000008F8CD8: 8106C222
	s_add_i32 s7, s34, -1                                      // 0000008F8CDC: 8107C122
	.long 0xd4490000                                           // 0000008F8CE0: D4490000
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000008F8CE4: 02020000
	s_and_not1_b32 s38, s2, exec_lo                            // 0000008F8CE8: 91267E02
	.long 0xd4490001                                           // 0000008F8CEC: D4490001
	v_cndmask_b32_e32 v1, s1, v0, vcc_lo                       // 0000008F8CF0: 02020001
	.long 0xd4490002                                           // 0000008F8CF4: D4490002
	v_cndmask_b32_e32 v1, s3, v0, vcc_lo                       // 0000008F8CF8: 02020003
	.long 0xd4490003                                           // 0000008F8CFC: D4490003
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000008F8D00: 02020004
	.long 0xd4490004                                           // 0000008F8D04: D4490004
	v_cndmask_b32_e32 v1, s5, v0, vcc_lo                       // 0000008F8D08: 02020005
	.long 0xd4490005                                           // 0000008F8D0C: D4490005
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 0000008F8D10: 02020006
	.long 0xd4490006                                           // 0000008F8D14: D4490006
	v_cndmask_b32_e32 v1, s7, v0, vcc_lo                       // 0000008F8D18: 02020007
	v_cmp_lt_u32_e32 vcc_lo, s34, v0                           // 0000008F8D1C: 7C920022
	s_add_i32 s34, s34, 8                                      // 0000008F8D20: 81228822
	s_add_i32 s35, s35, 32                                     // 0000008F8D24: 8123A023
	s_add_i32 s39, s36, s34                                    // 0000008F8D28: 81272224
	s_waitcnt lgkmcnt(1)                                       // 0000008F8D2C: BF89FC17
	.long 0xd44a0008                                           // 0000008F8D30: D44A0008
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 0000008F8D34: 02020306
	.long 0xd4410007                                           // 0000008F8D38: D4410007
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 0000008F8D3C: 02020306
	.long 0xd44a000a                                           // 0000008F8D40: D44A000A
	v_cndmask_b32_e32 v1, v7, v1, vcc_lo                       // 0000008F8D44: 02020307
	.long 0xd44a000c                                           // 0000008F8D48: D44A000C
	v_cndmask_b32_e32 v1, v8, v1, vcc_lo                       // 0000008F8D4C: 02020308
	.long 0xd4410009                                           // 0000008F8D50: D4410009
	v_cndmask_b32_e32 v1, v7, v1, vcc_lo                       // 0000008F8D54: 02020307
	v_cndmask_b32_e64 v4, 0, 1, s8                             // 0000008F8D58: D5010004 00210280
	s_and_b32 s8, s8, s0                                       // 0000008F8D60: 8B080008
	.long 0xd441000b                                           // 0000008F8D64: D441000B
	v_cndmask_b32_e32 v1, v8, v1, vcc_lo                       // 0000008F8D68: 02020308
	v_cndmask_b32_e64 v6, 0, 1, s12                            // 0000008F8D6C: D5010006 00310280
	s_waitcnt lgkmcnt(0)                                       // 0000008F8D74: BF89FC07
	.long 0xd44a000f                                           // 0000008F8D78: D44A000F
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 0000008F8D7C: 0202030A
	v_add_co_ci_u32_e64 v4, null, v5, v4, s10                  // 0000008F8D80: D5207C04 002A0905
	s_and_b32 s10, s10, s1                                     // 0000008F8D88: 8B0A010A
	.long 0xd44a0000                                           // 0000008F8D8C: D44A0000
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000008F8D90: 02020309
	s_or_b32 s1, s7, s8                                        // 0000008F8D94: 8C010807
	s_and_b32 s2, s12, s2                                      // 0000008F8D98: 8B02020C
	v_cndmask_b32_e64 v5, 0, 1, s1                             // 0000008F8D9C: D5010005 00050280
	.long 0xd441000d                                           // 0000008F8DA4: D441000D
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 0000008F8DA8: 02020309
	.long 0xd441000e                                           // 0000008F8DAC: D441000E
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 0000008F8DB0: 0202030A
	v_cndmask_b32_e64 v7, 0, 1, s15                            // 0000008F8DB4: D5010007 003D0280
	.long 0xd44a0012                                           // 0000008F8DBC: D44A0012
	v_cndmask_b32_e32 v1, v12, v1, vcc_lo                      // 0000008F8DC0: 0202030C
	s_or_b32 s1, s9, s10                                       // 0000008F8DC4: 8C010A09
	s_or_b32 s7, s11, s2                                       // 0000008F8DC8: 8C07020B
	v_add_co_ci_u32_e64 v4, null, v4, v6, s0                   // 0000008F8DCC: D5207C04 00020D04
	s_and_b32 s3, s0, s3                                       // 0000008F8DD4: 8B030300
	.long 0xd44a0000                                           // 0000008F8DD8: D44A0000
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008F8DDC: 0202030B
	v_cndmask_b32_e64 v9, 0, 1, s7                             // 0000008F8DE0: D5010009 001D0280
	v_add_co_ci_u32_e64 v3, null, v3, v5, s1                   // 0000008F8DE8: D5207C03 00060B03
	s_and_b32 s4, s15, s4                                      // 0000008F8DF0: 8B04040F
	.long 0xd4410010                                           // 0000008F8DF4: D4410010
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008F8DF8: 0202030B
	v_cndmask_b32_e64 v8, 0, 1, s18                            // 0000008F8DFC: D5010008 00490280
	s_or_b32 s7, s14, s4                                       // 0000008F8E04: 8C07040E
	s_or_b32 s1, s13, s3                                       // 0000008F8E08: 8C01030D
	v_add_co_ci_u32_e64 v4, null, v4, v7, s0                   // 0000008F8E0C: D5207C04 00020F04
	s_and_b32 s5, s0, s5                                       // 0000008F8E14: 8B050500
	.long 0xd44a0000                                           // 0000008F8E18: D44A0000
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000008F8E1C: 0202030D
	v_cndmask_b32_e64 v10, 0, 1, s7                            // 0000008F8E20: D501000A 001D0280
	v_add_co_ci_u32_e64 v3, null, v3, v9, s1                   // 0000008F8E28: D5207C03 00061303
	.long 0xd4410013                                           // 0000008F8E30: D4410013
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000008F8E34: 0202030D
	s_and_b32 s6, s18, s6                                      // 0000008F8E38: 8B060612
	s_or_b32 s1, s16, s5                                       // 0000008F8E3C: 8C010510
	v_add_co_ci_u32_e64 v5, null, v4, v8, s0                   // 0000008F8E40: D5207C05 00021104
	s_and_b32 s0, s0, vcc_lo                                   // 0000008F8E48: 8B006A00
	v_add_co_ci_u32_e64 v3, null, v3, v10, s1                  // 0000008F8E4C: D5207C03 00061503
	s_or_b32 s1, s0, s6                                        // 0000008F8E54: 8C010600
	s_or_b32 vcc_lo, s19, s0                                   // 0000008F8E58: 8C6A0013
	s_or_b32 s0, s1, s5                                        // 0000008F8E5C: 8C000501
	.long 0xd4410011                                           // 0000008F8E60: D4410011
	v_cndmask_b32_e32 v1, v12, v1, vcc_lo                      // 0000008F8E64: 0202030C
	s_or_b32 s0, s0, s4                                        // 0000008F8E68: 8C000400
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008F8E6C: BF870499
	s_or_b32 s0, s0, s3                                        // 0000008F8E70: 8C000300
	s_or_b32 s0, s0, s2                                        // 0000008F8E74: 8C000200
	s_or_b32 s7, s17, s6                                       // 0000008F8E78: 8C070611
	s_or_b32 s0, s0, s10                                       // 0000008F8E7C: 8C000A00
	v_cndmask_b32_e64 v12, 0, 1, s7                            // 0000008F8E80: D501000C 001D0280
	s_nor_b32 s0, s0, s8                                       // 0000008F8E88: 8F000800
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008F8E8C: BF870499
	s_and_b32 s37, s0, s37                                     // 0000008F8E90: 8B252500
	s_and_b32 s0, s37, exec_lo                                 // 0000008F8E94: 8B007E25
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008F8E98: BF870001
	v_add_co_ci_u32_e64 v3, null, v3, v12, vcc_lo              // 0000008F8E9C: D5207C03 01AA1903
	s_or_b32 s2, s38, s0                                       // 0000008F8EA4: 8C020026
	s_cmp_eq_u32 s39, 7                                        // 0000008F8EA8: BF068727
	s_cbranch_scc0 65408                                       // 0000008F8EAC: BFA1FF80 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xb0>
	s_add_i32 s3, s34, -7                                      // 0000008F8EB0: 8103C722
	s_cmp_lg_u32 s33, 0                                        // 0000008F8EB4: BF078021
	s_cselect_b32 s0, -1, 0                                    // 0000008F8EB8: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F8EBC: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 0000008F8EC0: 8B6A007E
	s_mov_b32 s0, s2                                           // 0000008F8EC4: BE800002
	s_cbranch_vccnz 6                                          // 0000008F8EC8: BFA40006 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x2e4>
	s_branch 40                                                // 0000008F8ECC: BFA00028 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x370>
	v_mov_b32_e32 v5, 0                                        // 0000008F8ED0: 7E0A0280
	v_mov_b32_e32 v3, 0                                        // 0000008F8ED4: 7E060280
	s_mov_b32 s3, 0                                            // 0000008F8ED8: BE830080
	s_mov_b32 s0, s2                                           // 0000008F8EDC: BE800002
	s_cbranch_execz 35                                         // 0000008F8EE0: BFA50023 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x370>
	s_lshl_b32 s4, s3, 2                                       // 0000008F8EE4: 84048203
	s_nop 0                                                    // 0000008F8EE8: BF800000
	s_nop 0                                                    // 0000008F8EEC: BF800000
	s_nop 0                                                    // 0000008F8EF0: BF800000
	s_nop 0                                                    // 0000008F8EF4: BF800000
	s_nop 0                                                    // 0000008F8EF8: BF800000
	s_nop 0                                                    // 0000008F8EFC: BF800000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F8F00: BF870009
	v_mov_b32_e32 v4, s4                                       // 0000008F8F04: 7E080204
	v_cmp_lt_u32_e32 vcc_lo, s3, v0                            // 0000008F8F08: 7C920003
	s_and_not1_b32 s5, s0, exec_lo                             // 0000008F8F0C: 91057E00
	s_add_i32 s33, s33, -1                                     // 0000008F8F10: 8121C121
	s_add_i32 s3, s3, 1                                        // 0000008F8F14: 81038103
	ds_load_b32 v4, v4                                         // 0000008F8F18: D8D80000 04000004
	s_add_i32 s4, s4, 4                                        // 0000008F8F20: 81048404
	s_waitcnt lgkmcnt(0)                                       // 0000008F8F24: BF89FC07
	.long 0xd44a0000                                           // 0000008F8F28: D44A0000
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 0000008F8F2C: 02020304
	.long 0xd4410001                                           // 0000008F8F30: D4410001
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 0000008F8F34: 02020304
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008F8F38: BF8704A2
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 0000008F8F3C: D5207C05 00020A80
	s_and_b32 s0, s0, vcc_lo                                   // 0000008F8F44: 8B006A00
	s_xor_b32 s6, s0, -1                                       // 0000008F8F48: 8D06C100
	s_or_b32 vcc_lo, s1, s0                                    // 0000008F8F4C: 8C6A0001
	s_and_b32 s2, s6, s2                                       // 0000008F8F50: 8B020206
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000008F8F54: D5207C03 01AA0680
	s_and_b32 s0, s2, exec_lo                                  // 0000008F8F5C: 8B007E02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F8F60: BF870009
	s_or_b32 s0, s5, s0                                        // 0000008F8F64: 8C000005
	s_cmp_lg_u32 s33, 0                                        // 0000008F8F68: BF078021
	s_cbranch_scc1 65508                                       // 0000008F8F6C: BFA2FFE4 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x300>
	v_mov_b32_e32 v4, 0                                        // 0000008F8F70: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 0000008F8F74: BF89FC07
	v_mul_u32_u24_e32 v1, 0x199a, v0                           // 0000008F8F78: 160200FF 0000199A
	s_and_b32 s1, s0, exec_lo                                  // 0000008F8F80: 8B017E00
	global_store_b32 v2, v3, s[26:27]                          // 0000008F8F84: DC6A0000 001A0302
	.long 0xd73c0006                                           // 0000008F8F8C: D73C0006
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000008F8F90: 02020682
	.long 0x7f083880                                           // 0000008F8F94: 7F083880
	.long 0x7e083981                                           // 0000008F8F98: 7E083981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008F8F9C: BF870093
	.long 0xd7006a06                                           // 0000008F8FA0: D7006A06
	v_cndmask_b32_e32 v1, s24, v6, vcc_lo                      // 0000008F8FA4: 02020C18
	v_add_co_ci_u32_e64 v7, null, s25, v7, vcc_lo              // 0000008F8FA8: D5207C07 01AA0E19
	global_store_b32 v[6:7], v4, off                           // 0000008F8FB0: DC6A0000 007C0406
	s_or_b32 exec_lo, exec_lo, s31                             // 0000008F8FB8: 8C7E1F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F8FBC: BF870009
	s_mov_b32 s0, exec_lo                                      // 0000008F8FC0: BE80007E
	v_cmpx_gt_u32_e32 0x80, v0                                 // 0000008F8FC4: 7D9800FF 00000080
	s_cbranch_execz 10                                         // 0000008F8FCC: BFA5000A <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x3f8>
	v_add_nc_u32_e32 v1, 1, v5                                 // 0000008F8FD0: 4A020A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008F8FD4: BF870091
	v_lshrrev_b32_e32 v4, 31, v1                               // 0000008F8FD8: 3208029F
	v_add_nc_u32_e32 v1, v1, v4                                // 0000008F8FDC: 4A020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008F8FE0: BF870091
	v_ashrrev_i32_e32 v1, 1, v1                                // 0000008F8FE4: 34020281
	v_cndmask_b32_e64 v1, 0, v1, s1                            // 0000008F8FE8: D5010001 00060280
	ds_store_b32 v2, v1 offset:512                             // 0000008F8FF0: D8340200 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000008F8FF8: 8C7E007E
	s_waitcnt lgkmcnt(0)                                       // 0000008F8FFC: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 0000008F9000: BC7C0000
	s_barrier                                                  // 0000008F9004: BFBD0000
	buffer_gl0_inv                                             // 0000008F9008: E0AC0000 00000000
	s_and_saveexec_b32 s0, s1                                  // 0000008F9010: BE802001
	s_cbranch_execz 482                                        // 0000008F9014: BFA501E2 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xba0>
	ds_load_b32 v1, v2                                         // 0000008F9018: D8D80000 01000002
	s_cmp_lt_i32 s30, 1                                        // 0000008F9020: BF04811E
	s_cbranch_scc1 117                                         // 0000008F9024: BFA20075 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x5fc>
	v_mov_b32_e32 v6, 0                                        // 0000008F9028: 7E0C0280
	s_and_b32 s1, s30, 7                                       // 0000008F902C: 8B01871E
	s_cmp_lt_u32 s30, 8                                        // 0000008F9030: BF0A881E
	s_cbranch_scc1 115                                         // 0000008F9034: BFA20073 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x604>
	v_mov_b32_e32 v4, 0                                        // 0000008F9038: 7E080280
	s_and_b32 s2, s30, 0x7ffffff8                              // 0000008F903C: 8B02FF1E 7FFFFFF8
	s_mov_b32 s3, 0                                            // 0000008F9044: BE830080
	s_branch 16                                                // 0000008F9048: BFA00010 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x48c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F904C: 8C7E047E
	v_add3_u32 v6, v7, v6, v8                                  // 0000008F9050: D6550006 04220D07
	v_add_nc_u32_e32 v4, 8, v4                                 // 0000008F9058: 4A080888
	s_add_i32 s3, s3, 32                                       // 0000008F905C: 8103A003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008F9060: BF870112
	v_add3_u32 v6, v10, v6, v9                                 // 0000008F9064: D6550006 04260D0A
	v_cmp_eq_u32_e32 vcc_lo, s2, v4                            // 0000008F906C: 7C940802
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008F9070: BF8700A2
	v_add3_u32 v6, v12, v6, v11                                // 0000008F9074: D6550006 042E0D0C
	s_waitcnt lgkmcnt(0)                                       // 0000008F907C: BF89FC07
	v_add3_u32 v6, v14, v6, v13                                // 0000008F9080: D6550006 04360D0E
	s_cbranch_vccnz 97                                         // 0000008F9088: BFA40061 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x610>
	v_mov_b32_e32 v7, s3                                       // 0000008F908C: 7E0E0203
	ds_load_b32 v7, v7                                         // 0000008F9090: D8D80000 07000007
	s_waitcnt lgkmcnt(0)                                       // 0000008F9098: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v7, v1                            // 0000008F909C: 7C820307
	v_mov_b32_e32 v7, 0                                        // 0000008F90A0: 7E0E0280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000008F90A4: BE84206A
	v_mov_b32_e32 v7, s3                                       // 0000008F90A8: 7E0E0203
	ds_load_b32 v7, v7 offset:512                              // 0000008F90AC: D8D80200 07000007
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F90B4: 8C7E047E
	v_mov_b32_e32 v8, s3                                       // 0000008F90B8: 7E100203
	ds_load_b32 v8, v8 offset:4                                // 0000008F90BC: D8D80004 08000008
	s_waitcnt lgkmcnt(0)                                       // 0000008F90C4: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v8, v1                            // 0000008F90C8: 7C820308
	v_mov_b32_e32 v8, 0                                        // 0000008F90CC: 7E100280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000008F90D0: BE84206A
	v_mov_b32_e32 v8, s3                                       // 0000008F90D4: 7E100203
	ds_load_b32 v8, v8 offset:516                              // 0000008F90D8: D8D80204 08000008
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F90E0: 8C7E047E
	v_mov_b32_e32 v9, s3                                       // 0000008F90E4: 7E120203
	ds_load_b32 v10, v9 offset:8                               // 0000008F90E8: D8D80008 0A000009
	v_mov_b32_e32 v9, 0                                        // 0000008F90F0: 7E120280
	s_waitcnt lgkmcnt(0)                                       // 0000008F90F4: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v10, v1                           // 0000008F90F8: 7C82030A
	v_mov_b32_e32 v10, 0                                       // 0000008F90FC: 7E140280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000008F9100: BE84206A
	v_mov_b32_e32 v10, s3                                      // 0000008F9104: 7E140203
	ds_load_b32 v10, v10 offset:520                            // 0000008F9108: D8D80208 0A00000A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F9110: 8C7E047E
	v_mov_b32_e32 v11, s3                                      // 0000008F9114: 7E160203
	s_mov_b32 s4, exec_lo                                      // 0000008F9118: BE84007E
	ds_load_b32 v11, v11 offset:12                             // 0000008F911C: D8D8000C 0B00000B
	s_waitcnt lgkmcnt(0)                                       // 0000008F9124: BF89FC07
	.long 0xd4c1007e                                           // 0000008F9128: D4C1007E
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008F912C: 0202030B
	v_mov_b32_e32 v9, s3                                       // 0000008F9130: 7E120203
	ds_load_b32 v9, v9 offset:524                              // 0000008F9134: D8D8020C 09000009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F913C: 8C7E047E
	v_mov_b32_e32 v11, s3                                      // 0000008F9140: 7E160203
	ds_load_b32 v12, v11 offset:16                             // 0000008F9144: D8D80010 0C00000B
	v_mov_b32_e32 v11, 0                                       // 0000008F914C: 7E160280
	s_waitcnt lgkmcnt(0)                                       // 0000008F9150: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v12, v1                           // 0000008F9154: 7C82030C
	v_mov_b32_e32 v12, 0                                       // 0000008F9158: 7E180280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000008F915C: BE84206A
	v_mov_b32_e32 v12, s3                                      // 0000008F9160: 7E180203
	ds_load_b32 v12, v12 offset:528                            // 0000008F9164: D8D80210 0C00000C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F916C: 8C7E047E
	v_mov_b32_e32 v13, s3                                      // 0000008F9170: 7E1A0203
	s_mov_b32 s4, exec_lo                                      // 0000008F9174: BE84007E
	ds_load_b32 v13, v13 offset:20                             // 0000008F9178: D8D80014 0D00000D
	s_waitcnt lgkmcnt(0)                                       // 0000008F9180: BF89FC07
	.long 0xd4c1007e                                           // 0000008F9184: D4C1007E
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000008F9188: 0202030D
	v_mov_b32_e32 v11, s3                                      // 0000008F918C: 7E160203
	ds_load_b32 v11, v11 offset:532                            // 0000008F9190: D8D80214 0B00000B
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F9198: 8C7E047E
	v_mov_b32_e32 v13, s3                                      // 0000008F919C: 7E1A0203
	ds_load_b32 v14, v13 offset:24                             // 0000008F91A0: D8D80018 0E00000D
	v_mov_b32_e32 v13, 0                                       // 0000008F91A8: 7E1A0280
	s_waitcnt lgkmcnt(0)                                       // 0000008F91AC: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v14, v1                           // 0000008F91B0: 7C82030E
	v_mov_b32_e32 v14, 0                                       // 0000008F91B4: 7E1C0280
	s_and_saveexec_b32 s4, vcc_lo                              // 0000008F91B8: BE84206A
	v_mov_b32_e32 v14, s3                                      // 0000008F91BC: 7E1C0203
	ds_load_b32 v14, v14 offset:536                            // 0000008F91C0: D8D80218 0E00000E
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008F91C8: 8C7E047E
	v_mov_b32_e32 v15, s3                                      // 0000008F91CC: 7E1E0203
	s_mov_b32 s4, exec_lo                                      // 0000008F91D0: BE84007E
	ds_load_b32 v15, v15 offset:28                             // 0000008F91D4: D8D8001C 0F00000F
	s_waitcnt lgkmcnt(0)                                       // 0000008F91DC: BF89FC07
	.long 0xd4c1007e                                           // 0000008F91E0: D4C1007E
	v_cndmask_b32_e32 v1, v15, v1, vcc_lo                      // 0000008F91E4: 0202030F
	s_cbranch_execz 65432                                      // 0000008F91E8: BFA5FF98 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x44c>
	v_mov_b32_e32 v13, s3                                      // 0000008F91EC: 7E1A0203
	ds_load_b32 v13, v13 offset:540                            // 0000008F91F0: D8D8021C 0D00000D
	s_branch 65428                                             // 0000008F91F8: BFA0FF94 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x44c>
	v_mov_b32_e32 v6, 0                                        // 0000008F91FC: 7E0C0280
	s_branch 34                                                // 0000008F9200: BFA00022 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x68c>
	s_mov_b32 s2, 0                                            // 0000008F9204: BE820080
	s_cbranch_execnz 6                                         // 0000008F9208: BFA60006 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x624>
	s_branch 31                                                // 0000008F920C: BFA0001F <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x68c>
	s_cmp_lg_u32 s1, 0                                         // 0000008F9210: BF078001
	s_cselect_b32 s3, -1, 0                                    // 0000008F9214: 980380C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F9218: BF870009
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000008F921C: 8B6A037E
	s_cbranch_vccz 26                                          // 0000008F9220: BFA3001A <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x68c>
	s_lshl_b32 s2, s2, 2                                       // 0000008F9224: 84028202
	s_branch 12                                                // 0000008F9228: BFA0000C <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x65c>
	s_nop 0                                                    // 0000008F922C: BF800000
	s_nop 0                                                    // 0000008F9230: BF800000
	s_nop 0                                                    // 0000008F9234: BF800000
	s_nop 0                                                    // 0000008F9238: BF800000
	s_nop 0                                                    // 0000008F923C: BF800000
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008F9240: 8C7E037E
	s_waitcnt lgkmcnt(0)                                       // 0000008F9244: BF89FC07
	v_add_nc_u32_e32 v6, v4, v6                                // 0000008F9248: 4A0C0D04
	s_add_i32 s1, s1, -1                                       // 0000008F924C: 8101C101
	s_add_i32 s2, s2, 4                                        // 0000008F9250: 81028402
	s_cmp_lg_u32 s1, 0                                         // 0000008F9254: BF078001
	s_cbranch_scc0 12                                          // 0000008F9258: BFA1000C <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x68c>
	v_mov_b32_e32 v4, s2                                       // 0000008F925C: 7E080202
	ds_load_b32 v4, v4                                         // 0000008F9260: D8D80000 04000004
	s_waitcnt lgkmcnt(0)                                       // 0000008F9268: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, v4, v1                            // 0000008F926C: 7C820304
	v_mov_b32_e32 v4, 0                                        // 0000008F9270: 7E080280
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008F9274: BE83206A
	s_cbranch_execz 65521                                      // 0000008F9278: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x640>
	v_mov_b32_e32 v4, s2                                       // 0000008F927C: 7E080202
	ds_load_b32 v4, v4 offset:512                              // 0000008F9280: D8D80200 04000004
	s_branch 65517                                             // 0000008F9288: BFA0FFED <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x640>
	ds_load_b32 v85, v2 offset:512                             // 0000008F928C: D8D80200 55000002
	s_mov_b32 s1, 0                                            // 0000008F9294: BE810080
	s_waitcnt lgkmcnt(0)                                       // 0000008F9298: BF89FC07
	v_cmp_lt_i32_e32 vcc_lo, 0, v85                            // 0000008F929C: 7C82AA80
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000008F92A0: 8B7E6A7E
	s_cbranch_execz 318                                        // 0000008F92A4: BFA5013E <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xba0>
	v_add_nc_u32_e32 v4, v3, v5                                // 0000008F92A8: 4A080B03
	v_mov_b32_e32 v2, s1                                       // 0000008F92AC: 7E040201
	s_mov_b32 s2, 4                                            // 0000008F92B0: BE820084
	.long 0xd72c0051                                           // 0000008F92B4: D72C0051
	v_cndmask_b32_e32 v0, v6, v148, vcc_lo                     // 0000008F92B8: 02012906
	v_lshl_add_u32 v83, v6, 2, v6                              // 0000008F92BC: D6460053 04190506
	v_mov_b32_e32 v20, v4                                      // 0000008F92C4: 7E280304
	v_mov_b32_e32 v18, v2                                      // 0000008F92C8: 7E240302
	v_mov_b32_e32 v18, s2                                      // 0000008F92CC: 7E240202
	s_mov_b32 s2, 5                                            // 0000008F92D0: BE820085
	v_mov_b32_e32 v24, v4                                      // 0000008F92D4: 7E300304
	v_mov_b32_e32 v22, v2                                      // 0000008F92D8: 7E2C0302
	v_mov_b32_e32 v22, s2                                      // 0000008F92DC: 7E2C0202
	s_mov_b32 s2, 6                                            // 0000008F92E0: BE820086
	v_mov_b32_e32 v28, v4                                      // 0000008F92E4: 7E380304
	v_mov_b32_e32 v26, v2                                      // 0000008F92E8: 7E340302
	v_mov_b32_e32 v26, s2                                      // 0000008F92EC: 7E340202
	s_mov_b32 s2, 7                                            // 0000008F92F0: BE820087
	v_mov_b32_e32 v32, v4                                      // 0000008F92F4: 7E400304
	v_mov_b32_e32 v30, v2                                      // 0000008F92F8: 7E3C0302
	v_mov_b32_e32 v30, s2                                      // 0000008F92FC: 7E3C0202
	s_mov_b32 s2, 8                                            // 0000008F9300: BE820088
	v_mov_b32_e32 v36, v4                                      // 0000008F9304: 7E480304
	v_mov_b32_e32 v34, v2                                      // 0000008F9308: 7E440302
	v_mov_b32_e32 v34, s2                                      // 0000008F930C: 7E440202
	s_mov_b32 s2, 9                                            // 0000008F9310: BE820089
	v_mov_b32_e32 v40, v4                                      // 0000008F9314: 7E500304
	v_mov_b32_e32 v38, v2                                      // 0000008F9318: 7E4C0302
	v_mov_b32_e32 v38, s2                                      // 0000008F931C: 7E4C0202
	s_mov_b32 s2, 10                                           // 0000008F9320: BE82008A
	v_mov_b32_e32 v44, v4                                      // 0000008F9324: 7E580304
	v_mov_b32_e32 v42, v2                                      // 0000008F9328: 7E540302
	v_mov_b32_e32 v42, s2                                      // 0000008F932C: 7E540202
	s_mov_b32 s2, 11                                           // 0000008F9330: BE82008B
	v_mov_b32_e32 v48, v4                                      // 0000008F9334: 7E600304
	v_mov_b32_e32 v46, v2                                      // 0000008F9338: 7E5C0302
	v_mov_b32_e32 v46, s2                                      // 0000008F933C: 7E5C0202
	s_mov_b32 s2, 12                                           // 0000008F9340: BE82008C
	v_mov_b32_e32 v52, v4                                      // 0000008F9344: 7E680304
	v_mov_b32_e32 v50, v2                                      // 0000008F9348: 7E640302
	v_mov_b32_e32 v50, s2                                      // 0000008F934C: 7E640202
	s_mov_b32 s2, 13                                           // 0000008F9350: BE82008D
	v_mov_b32_e32 v56, v4                                      // 0000008F9354: 7E700304
	v_mov_b32_e32 v54, v2                                      // 0000008F9358: 7E6C0302
	v_mov_b32_e32 v54, s2                                      // 0000008F935C: 7E6C0202
	s_mov_b32 s2, 14                                           // 0000008F9360: BE82008E
	v_mov_b32_e32 v60, v4                                      // 0000008F9364: 7E780304
	v_mov_b32_e32 v58, v2                                      // 0000008F9368: 7E740302
	v_mov_b32_e32 v58, s2                                      // 0000008F936C: 7E740202
	s_mov_b32 s2, 15                                           // 0000008F9370: BE82008F
	v_mov_b32_e32 v64, v4                                      // 0000008F9374: 7E800304
	v_mov_b32_e32 v62, v2                                      // 0000008F9378: 7E7C0302
	v_mov_b32_e32 v62, s2                                      // 0000008F937C: 7E7C0202
	s_mov_b32 s2, 16                                           // 0000008F9380: BE820090
	v_mov_b32_e32 v68, v4                                      // 0000008F9384: 7E880304
	v_mov_b32_e32 v66, v2                                      // 0000008F9388: 7E840302
	s_mov_b32 s3, 1                                            // 0000008F938C: BE830081
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v7, v3             // 0000008F9390: CA100104 08060103
	v_mov_b32_e32 v66, s2                                      // 0000008F9398: 7E840202
	s_mov_b32 s2, 17                                           // 0000008F939C: BE820091
	v_mov_b32_e32 v72, v4                                      // 0000008F93A0: 7E900304
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v5, v1             // 0000008F93A4: CA100102 06040101
	v_mov_b32_e32 v70, v2                                      // 0000008F93AC: 7E8C0302
	v_mov_b32_e32 v6, s3                                       // 0000008F93B0: 7E0C0203
	s_mov_b32 s3, 2                                            // 0000008F93B4: BE830082
	v_dual_mov_b32 v12, v4 :: v_dual_mov_b32 v9, v1            // 0000008F93B8: CA100104 0C080101
	v_mov_b32_e32 v70, s2                                      // 0000008F93C0: 7E8C0202
	s_mov_b32 s2, 18                                           // 0000008F93C4: BE820092
	v_mov_b32_e32 v76, v4                                      // 0000008F93C8: 7E980304
	v_mov_b32_e32 v10, v2                                      // 0000008F93CC: 7E140302
	v_mov_b32_e32 v74, v2                                      // 0000008F93D0: 7E940302
	v_mov_b32_e32 v10, s3                                      // 0000008F93D4: 7E140203
	s_mov_b32 s3, 3                                            // 0000008F93D8: BE830083
	v_dual_mov_b32 v16, v4 :: v_dual_mov_b32 v19, v3           // 0000008F93DC: CA100104 10120103
	v_mov_b32_e32 v74, s2                                      // 0000008F93E4: 7E940202
	s_mov_b32 s2, 19                                           // 0000008F93E8: BE820093
	v_mov_b32_e32 v80, v4                                      // 0000008F93EC: 7EA00304
	v_dual_mov_b32 v14, v2 :: v_dual_mov_b32 v17, v1           // 0000008F93F0: CA100102 0E100101
	v_dual_mov_b32 v78, v2 :: v_dual_mov_b32 v11, v3           // 0000008F93F8: CA100102 4E0A0103
	v_mov_b32_e32 v15, v3                                      // 0000008F9400: 7E1E0303
	v_dual_mov_b32 v13, v1 :: v_dual_mov_b32 v14, s3           // 0000008F9404: CA100101 0D0E0003
	v_mov_b32_e32 v23, v3                                      // 0000008F940C: 7E2E0303
	v_mov_b32_e32 v21, v1                                      // 0000008F9410: 7E2A0301
	v_mov_b32_e32 v27, v3                                      // 0000008F9414: 7E360303
	v_mov_b32_e32 v25, v1                                      // 0000008F9418: 7E320301
	v_mov_b32_e32 v31, v3                                      // 0000008F941C: 7E3E0303
	v_mov_b32_e32 v29, v1                                      // 0000008F9420: 7E3A0301
	v_mov_b32_e32 v35, v3                                      // 0000008F9424: 7E460303
	v_mov_b32_e32 v33, v1                                      // 0000008F9428: 7E420301
	v_mov_b32_e32 v39, v3                                      // 0000008F942C: 7E4E0303
	v_mov_b32_e32 v37, v1                                      // 0000008F9430: 7E4A0301
	v_mov_b32_e32 v43, v3                                      // 0000008F9434: 7E560303
	v_mov_b32_e32 v41, v1                                      // 0000008F9438: 7E520301
	v_mov_b32_e32 v47, v3                                      // 0000008F943C: 7E5E0303
	v_mov_b32_e32 v45, v1                                      // 0000008F9440: 7E5A0301
	v_mov_b32_e32 v51, v3                                      // 0000008F9444: 7E660303
	v_mov_b32_e32 v49, v1                                      // 0000008F9448: 7E620301
	v_mov_b32_e32 v55, v3                                      // 0000008F944C: 7E6E0303
	v_mov_b32_e32 v53, v1                                      // 0000008F9450: 7E6A0301
	v_mov_b32_e32 v59, v3                                      // 0000008F9454: 7E760303
	v_mov_b32_e32 v57, v1                                      // 0000008F9458: 7E720301
	v_mov_b32_e32 v63, v3                                      // 0000008F945C: 7E7E0303
	v_mov_b32_e32 v61, v1                                      // 0000008F9460: 7E7A0301
	v_mov_b32_e32 v67, v3                                      // 0000008F9464: 7E860303
	v_mov_b32_e32 v65, v1                                      // 0000008F9468: 7E820301
	v_mov_b32_e32 v71, v3                                      // 0000008F946C: 7E8E0303
	v_mov_b32_e32 v69, v1                                      // 0000008F9470: 7E8A0301
	v_mov_b32_e32 v75, v3                                      // 0000008F9474: 7E960303
	v_mov_b32_e32 v73, v1                                      // 0000008F9478: 7E920301
	v_mov_b32_e32 v79, v3                                      // 0000008F947C: 7E9E0303
	v_dual_mov_b32 v77, v1 :: v_dual_mov_b32 v78, s2           // 0000008F9480: CA100101 4D4E0002
	v_ashrrev_i32_e32 v84, 31, v83                             // 0000008F9488: 34A8A69F
	v_ashrrev_i32_e32 v82, 31, v81                             // 0000008F948C: 34A4A29F
	v_dual_mov_b32 v93, v16 :: v_dual_mov_b32 v92, v15         // 0000008F9490: CA100110 5D5C010F
	v_dual_mov_b32 v91, v14 :: v_dual_mov_b32 v90, v13         // 0000008F9498: CA10010E 5B5A010D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008F94A0: BF870214
	.long 0xd73c0056                                           // 0000008F94A4: D73C0056
	v_cndmask_b32_e32 v1, 4, v83, vcc_lo                       // 0000008F94A8: 0202A684
	.long 0xd73c0058                                           // 0000008F94AC: D73C0058
	v_cndmask_b32_e32 v1, 4, v81, vcc_lo                       // 0000008F94B0: 0202A284
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F94B4: CA100103 5C5C0104
	v_add_nc_u32_e32 v85, -1, v85                              // 0000008F94BC: 4AAAAAC1
	v_add_nc_u32_e32 v81, 20, v81                              // 0000008F94C0: 4AA2A294
	.long 0xd7006a5e                                           // 0000008F94C4: D7006A5E
	v_cndmask_b32_e32 v1, s20, v86, vcc_lo                     // 0000008F94C8: 0202AC14
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008F94CC: BF8700A1
	v_add_co_ci_u32_e64 v95, null, s21, v87, vcc_lo            // 0000008F94D0: D5207C5F 01AAAE15
	.long 0xd7006a60                                           // 0000008F94D8: D7006A60
	v_cndmask_b32_e32 v1, s22, v88, vcc_lo                     // 0000008F94DC: 0202B016
	v_add_co_ci_u32_e64 v97, null, s23, v89, vcc_lo            // 0000008F94E0: D5207C61 01AAB217
	v_dual_mov_b32 v89, v12 :: v_dual_mov_b32 v88, v11         // 0000008F94E8: CA10010C 5958010B
	v_dual_mov_b32 v87, v10 :: v_dual_mov_b32 v86, v9          // 0000008F94F0: CA10010A 57560109
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F94F8: CA100103 58580104
	global_store_b128 v[96:97], v[86:89], off offset:32        // 0000008F9500: DC760020 007C5660
	s_clause 0x1                                               // 0000008F9508: BF850001
	global_store_b128 v[94:95], v[86:89], off offset:32        // 0000008F950C: DC760020 007C565E
	global_store_b128 v[94:95], v[90:93], off offset:48        // 0000008F9514: DC760030 007C5A5E
	global_store_b128 v[96:97], v[90:93], off offset:48        // 0000008F951C: DC760030 007C5A60
	v_dual_mov_b32 v89, v20 :: v_dual_mov_b32 v88, v19         // 0000008F9524: CA100114 59580113
	v_dual_mov_b32 v87, v18 :: v_dual_mov_b32 v86, v17         // 0000008F952C: CA100112 57560111
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9534: CA100103 58580104
	v_dual_mov_b32 v93, v24 :: v_dual_mov_b32 v92, v23         // 0000008F953C: CA100118 5D5C0117
	v_dual_mov_b32 v91, v22 :: v_dual_mov_b32 v90, v21         // 0000008F9544: CA100116 5B5A0115
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F954C: CA100103 5C5C0104
	global_store_b128 v[94:95], v[86:89], off offset:64        // 0000008F9554: DC760040 007C565E
	s_clause 0x1                                               // 0000008F955C: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:64        // 0000008F9560: DC760040 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:80        // 0000008F9568: DC760050 007C5A60
	v_dual_mov_b32 v89, v28 :: v_dual_mov_b32 v88, v27         // 0000008F9570: CA10011C 5958011B
	v_dual_mov_b32 v87, v26 :: v_dual_mov_b32 v86, v25         // 0000008F9578: CA10011A 57560119
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9580: CA100103 58580104
	v_dual_mov_b32 v93, v32 :: v_dual_mov_b32 v92, v31         // 0000008F9588: CA100120 5D5C011F
	v_dual_mov_b32 v91, v30 :: v_dual_mov_b32 v90, v29         // 0000008F9590: CA10011E 5B5A011D
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F9598: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F95A0: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:96        // 0000008F95A4: DC760060 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:112       // 0000008F95AC: DC760070 007C5A60
	v_dual_mov_b32 v89, v36 :: v_dual_mov_b32 v88, v35         // 0000008F95B4: CA100124 59580123
	v_dual_mov_b32 v87, v34 :: v_dual_mov_b32 v86, v33         // 0000008F95BC: CA100122 57560121
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F95C4: CA100103 58580104
	v_dual_mov_b32 v93, v40 :: v_dual_mov_b32 v92, v39         // 0000008F95CC: CA100128 5D5C0127
	v_dual_mov_b32 v91, v38 :: v_dual_mov_b32 v90, v37         // 0000008F95D4: CA100126 5B5A0125
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F95DC: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F95E4: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:128       // 0000008F95E8: DC760080 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:144       // 0000008F95F0: DC760090 007C5A60
	v_dual_mov_b32 v89, v44 :: v_dual_mov_b32 v88, v43         // 0000008F95F8: CA10012C 5958012B
	v_dual_mov_b32 v87, v42 :: v_dual_mov_b32 v86, v41         // 0000008F9600: CA10012A 57560129
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9608: CA100103 58580104
	v_dual_mov_b32 v93, v48 :: v_dual_mov_b32 v92, v47         // 0000008F9610: CA100130 5D5C012F
	v_dual_mov_b32 v91, v46 :: v_dual_mov_b32 v90, v45         // 0000008F9618: CA10012E 5B5A012D
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F9620: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F9628: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:160       // 0000008F962C: DC7600A0 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:176       // 0000008F9634: DC7600B0 007C5A60
	v_dual_mov_b32 v89, v52 :: v_dual_mov_b32 v88, v51         // 0000008F963C: CA100134 59580133
	v_dual_mov_b32 v87, v50 :: v_dual_mov_b32 v86, v49         // 0000008F9644: CA100132 57560131
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F964C: CA100103 58580104
	v_dual_mov_b32 v93, v56 :: v_dual_mov_b32 v92, v55         // 0000008F9654: CA100138 5D5C0137
	v_dual_mov_b32 v91, v54 :: v_dual_mov_b32 v90, v53         // 0000008F965C: CA100136 5B5A0135
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F9664: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F966C: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:192       // 0000008F9670: DC7600C0 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:208       // 0000008F9678: DC7600D0 007C5A60
	v_dual_mov_b32 v89, v60 :: v_dual_mov_b32 v88, v59         // 0000008F9680: CA10013C 5958013B
	v_dual_mov_b32 v87, v58 :: v_dual_mov_b32 v86, v57         // 0000008F9688: CA10013A 57560139
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9690: CA100103 58580104
	v_dual_mov_b32 v93, v64 :: v_dual_mov_b32 v92, v63         // 0000008F9698: CA100140 5D5C013F
	v_dual_mov_b32 v91, v62 :: v_dual_mov_b32 v90, v61         // 0000008F96A0: CA10013E 5B5A013D
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F96A8: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F96B0: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:224       // 0000008F96B4: DC7600E0 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:240       // 0000008F96BC: DC7600F0 007C5A60
	v_dual_mov_b32 v89, v68 :: v_dual_mov_b32 v88, v67         // 0000008F96C4: CA100144 59580143
	v_dual_mov_b32 v87, v66 :: v_dual_mov_b32 v86, v65         // 0000008F96CC: CA100142 57560141
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F96D4: CA100103 58580104
	v_dual_mov_b32 v93, v72 :: v_dual_mov_b32 v92, v71         // 0000008F96DC: CA100148 5D5C0147
	v_dual_mov_b32 v91, v70 :: v_dual_mov_b32 v90, v69         // 0000008F96E4: CA100146 5B5A0145
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F96EC: CA100103 5C5C0104
	s_clause 0x1                                               // 0000008F96F4: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:256       // 0000008F96F8: DC760100 007C5660
	global_store_b128 v[96:97], v[90:93], off offset:272       // 0000008F9700: DC760110 007C5A60
	v_dual_mov_b32 v89, v76 :: v_dual_mov_b32 v88, v75         // 0000008F9708: CA10014C 5958014B
	v_dual_mov_b32 v87, v74 :: v_dual_mov_b32 v86, v73         // 0000008F9710: CA10014A 57560149
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9718: CA100103 58580104
	v_cmp_eq_u32_e32 vcc_lo, 0, v85                            // 0000008F9720: 7C94AA80
	v_dual_mov_b32 v93, v80 :: v_dual_mov_b32 v92, v79         // 0000008F9724: CA100150 5D5C014F
	v_dual_mov_b32 v91, v78 :: v_dual_mov_b32 v90, v77         // 0000008F972C: CA10014E 5B5A014D
	s_clause 0x1                                               // 0000008F9734: BF850001
	global_store_b128 v[96:97], v[86:89], off offset:288       // 0000008F9738: DC760120 007C5660
	global_store_b128 v[96:97], v[1:4], off                    // 0000008F9740: DC760000 007C0160
	v_dual_mov_b32 v89, v8 :: v_dual_mov_b32 v88, v7           // 0000008F9748: CA100108 59580107
	v_dual_mov_b32 v87, v6 :: v_dual_mov_b32 v86, v5           // 0000008F9750: CA100106 57560105
	v_dual_mov_b32 v88, v3 :: v_dual_mov_b32 v89, v4           // 0000008F9758: CA100103 58580104
	v_dual_mov_b32 v92, v3 :: v_dual_mov_b32 v93, v4           // 0000008F9760: CA100103 5C5C0104
	global_store_b128 v[96:97], v[86:89], off offset:16        // 0000008F9768: DC760010 007C5660
	s_clause 0x1                                               // 0000008F9770: BF850001
	global_store_b128 v[94:95], v[86:89], off offset:16        // 0000008F9774: DC760010 007C565E
	global_store_b128 v[94:95], v[1:4], off                    // 0000008F977C: DC760000 007C015E
	v_add_nc_u32_e32 v83, 5, v83                               // 0000008F9784: 4AA6A685
	v_add_nc_u32_e32 v3, 2, v3                                 // 0000008F9788: 4A060682
	s_or_b32 s1, vcc_lo, s1                                    // 0000008F978C: 8C01016A
	global_store_b128 v[96:97], v[90:93], off offset:304       // 0000008F9790: DC760130 007C5A60
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000008F9798: 917E017E
	s_cbranch_execnz 65338                                     // 0000008F979C: BFA6FF3A <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0x888>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000008F97A0: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F97A4: BF870009
	s_mov_b32 s0, exec_lo                                      // 0000008F97A8: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 0000008F97AC: 7D940080
	s_cbranch_execz 64                                         // 0000008F97B0: BFA50040 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xcb4>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 0000008F97B4: CA100080 00000080
	s_cmp_lt_i32 s30, 1                                        // 0000008F97BC: BF04811E
	s_cbranch_scc1 58                                          // 0000008F97C0: BFA2003A <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xcac>
	s_and_b32 s0, s30, 7                                       // 0000008F97C4: 8B00871E
	s_cmp_lt_u32 s30, 8                                        // 0000008F97C8: BF0A881E
	s_cbranch_scc1 41                                          // 0000008F97CC: BFA20029 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xc74>
	v_mov_b32_e32 v1, 0                                        // 0000008F97D0: 7E020280
	s_and_b32 s1, s30, 0x7ffffff8                              // 0000008F97D4: 8B01FF1E 7FFFFFF8
	s_mov_b32 s2, 0                                            // 0000008F97DC: BE820080
	s_mov_b32 s3, 0                                            // 0000008F97E0: BE830080
	s_nop 0                                                    // 0000008F97E4: BF800000
	s_nop 0                                                    // 0000008F97E8: BF800000
	s_nop 0                                                    // 0000008F97EC: BF800000
	s_nop 0                                                    // 0000008F97F0: BF800000
	s_nop 0                                                    // 0000008F97F4: BF800000
	s_nop 0                                                    // 0000008F97F8: BF800000
	s_nop 0                                                    // 0000008F97FC: BF800000
	v_mov_b32_e32 v6, s2                                       // 0000008F9800: 7E0C0202
	s_add_i32 s3, s3, 8                                        // 0000008F9804: 81038803
	s_add_i32 s2, s2, 32                                       // 0000008F9808: 8102A002
	s_cmp_eq_u32 s1, s3                                        // 0000008F980C: BF060301
	ds_load_b128 v[2:5], v6 offset:512                         // 0000008F9810: DBFC0200 02000006
	ds_load_b128 v[6:9], v6 offset:528                         // 0000008F9818: DBFC0210 06000006
	s_waitcnt lgkmcnt(1)                                       // 0000008F9820: BF89FC17
	v_add_nc_u32_e32 v1, v2, v1                                // 0000008F9824: 4A020302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008F9828: BF870091
	v_add_nc_u32_e32 v1, v3, v1                                // 0000008F982C: 4A020303
	v_add_nc_u32_e32 v1, v4, v1                                // 0000008F9830: 4A020304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008F9834: BF8700A1
	v_add_nc_u32_e32 v1, v5, v1                                // 0000008F9838: 4A020305
	s_waitcnt lgkmcnt(0)                                       // 0000008F983C: BF89FC07
	v_add_nc_u32_e32 v1, v6, v1                                // 0000008F9840: 4A020306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008F9844: BF870091
	v_add_nc_u32_e32 v1, v7, v1                                // 0000008F9848: 4A020307
	v_add_nc_u32_e32 v1, v8, v1                                // 0000008F984C: 4A020308
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008F9850: BF870001
	v_add_nc_u32_e32 v1, v9, v1                                // 0000008F9854: 4A020309
	s_cbranch_scc0 65513                                       // 0000008F9858: BFA1FFE9 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xc00>
	s_cmp_lg_u32 s0, 0                                         // 0000008F985C: BF078000
	s_cselect_b32 s2, -1, 0                                    // 0000008F9860: 980280C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F9864: BF870009
	s_and_b32 vcc_lo, exec_lo, s2                              // 0000008F9868: 8B6A027E
	s_cbranch_vccnz 4                                          // 0000008F986C: BFA40004 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xc80>
	s_branch 14                                                // 0000008F9870: BFA0000E <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xcac>
	v_mov_b32_e32 v1, 0                                        // 0000008F9874: 7E020280
	s_mov_b32 s1, 0                                            // 0000008F9878: BE810080
	s_cbranch_execz 11                                         // 0000008F987C: BFA5000B <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xcac>
	s_lshl_b32 s1, s1, 2                                       // 0000008F9880: 84018201
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008F9884: BF870009
	v_mov_b32_e32 v2, s1                                       // 0000008F9888: 7E040201
	s_add_i32 s0, s0, -1                                       // 0000008F988C: 8100C100
	s_add_i32 s1, s1, 4                                        // 0000008F9890: 81018401
	s_cmp_lg_u32 s0, 0                                         // 0000008F9894: BF078000
	ds_load_b32 v2, v2 offset:512                              // 0000008F9898: D8D80200 02000002
	s_waitcnt lgkmcnt(0)                                       // 0000008F98A0: BF89FC07
	v_add_nc_u32_e32 v1, v2, v1                                // 0000008F98A4: 4A020302
	s_cbranch_scc1 65526                                       // 0000008F98A8: BFA2FFF6 <_ZN7halogen12_GLOBAL__N_116k_ht_items_groupILi2EEEvPKiiPNS0_6HtItemES5_PiS6_S6_+0xc84>
	global_store_b32 v0, v1, s[28:29]                          // 0000008F98AC: DC6A0000 001C0100
	s_nop 0                                                    // 0000008F98B4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000008F98B8: BFB60003
	s_endpgm                                                   // 0000008F98BC: BFB00000
		...

