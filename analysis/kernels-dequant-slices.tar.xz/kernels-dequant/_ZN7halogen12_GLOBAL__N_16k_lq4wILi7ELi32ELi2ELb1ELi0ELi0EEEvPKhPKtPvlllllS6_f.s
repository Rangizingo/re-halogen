000000000075fb00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000075FB00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000075FB08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000075FB0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000075FB10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000075FB14: 3602008F
	v_mov_b32_e32 v5, 0                                        // 00000075FB18: 7E0A0280
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000075FB1C: 321C0086
	v_and_b32_e32 v2, 60, v2                                   // 00000075FB20: 360404BC
	s_delay_alu instid0(VALU_DEP_4)                            // 00000075FB24: BF870004
	v_dual_mov_b32 v6, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 00000075FB28: CA220080 06000282
	v_bfe_u32 v15, v0, 5, 1                                    // 00000075FB30: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 00000075FB38: CA240080 1110009F
	.long 0x7f103880                                           // 00000075FB40: 7F103880
	s_waitcnt lgkmcnt(0)                                       // 00000075FB44: BF89FC07
	s_clause 0x1                                               // 00000075FB48: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000075FB4C: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000075FB54: DC520000 04040002
	v_mov_b32_e32 v2, s3                                       // 00000075FB5C: 7E040203
	v_or_b32_e32 v1, s2, v14                                   // 00000075FB60: 38021C02
	s_add_u32 s0, s4, s14                                      // 00000075FB64: 80000E04
	s_addc_u32 s1, s5, s15                                     // 00000075FB68: 82010F05
	s_lshr_b32 s14, s11, 31                                    // 00000075FB6C: 850E9F0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000075FB70: BF870009
	s_add_u32 s14, s10, s14                                    // 00000075FB74: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 00000075FB78: 820F800B
	s_ashr_i32 s20, s11, 31                                    // 00000075FB7C: 86149F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000075FB80: 7CA8020C
	s_lshr_b32 s20, s20, 27                                    // 00000075FB84: 85149B14
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000075FB88: 868E810E
	s_add_u32 s20, s10, s20                                    // 00000075FB8C: 8014140A
	s_addc_u32 s21, s11, 0                                     // 00000075FB90: 8215800B
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000075FB94: 02020280
	s_lshr_b64 s[20:21], s[20:21], 5                           // 00000075FB98: 85948514
	v_cndmask_b32_e64 v7, 0, s3, vcc_lo                        // 00000075FB9C: D5010007 01A80680
	s_add_i32 s21, s20, 1                                      // 00000075FBA4: 81158114
	s_delay_alu instid0(VALU_DEP_2)                            // 00000075FBA8: BF870002
	.long 0xd72c0002                                           // 00000075FBAC: D72C0002
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 00000075FBB0: 02020213
	s_lshr_b32 s19, s21, 31                                    // 00000075FBB4: 85139F15
	.long 0xd72c000d                                           // 00000075FBB8: D72C000D
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 00000075FBBC: 02001F01
	s_add_i32 s21, s21, s19                                    // 00000075FBC0: 81151315
	v_mad_u64_u32 v[9:10], null, v1, s14, s[0:1]               // 00000075FBC4: D6FE7C09 00001D01
	s_ashr_i32 s15, s21, 1                                     // 00000075FBCC: 860F8115
	s_add_u32 s0, s4, s16                                      // 00000075FBD0: 80001004
	.long 0xd72c0012                                           // 00000075FBD4: D72C0012
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 00000075FBD8: 02021E0F
	s_addc_u32 s1, s5, s17                                     // 00000075FBDC: 82011105
	.long 0xd72c0014                                           // 00000075FBE0: D72C0014
	v_cndmask_b32_e32 v0, v7, v14, vcc_lo                      // 00000075FBE4: 02001D07
	.long 0xd72c0015                                           // 00000075FBE8: D72C0015
	v_cndmask_b32_e32 v1, s18, v7, vcc_lo                      // 00000075FBEC: 02020E12
	v_mov_b32_e32 v29, 0                                       // 00000075FBF0: 7E3A0280
	v_mov_b32_e32 v7, 0                                        // 00000075FBF4: 7E0E0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000075FBF8: BF870154
	v_add3_u32 v10, v20, v10, v13                              // 00000075FBFC: D655000A 04361514
	s_waitcnt vmcnt(1)                                         // 00000075FC04: BF8907F7
	v_bfe_u32 v11, v3, 16, 1                                   // 00000075FC08: D610000B 02052103
	s_waitcnt vmcnt(0)                                         // 00000075FC10: BF8903F7
	v_bfe_u32 v19, v4, 16, 1                                   // 00000075FC14: D6100013 02052104
	v_add3_u32 v3, v3, v11, 0x7fff                             // 00000075FC1C: D6550003 03FE1703 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v1, s[0:1]              // 00000075FC28: D6FE7C0B 00020212
	v_add_nc_u32_e32 v1, s15, v18                              // 00000075FC30: 4A02240F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000075FC34: BF870004
	v_add3_u32 v4, v4, v19, 0x7fff                             // 00000075FC38: D6550004 03FE2704 00007FFF
	v_add_nc_u32_e32 v18, v18, v16                             // 00000075FC44: 4A242112
	.long 0x7e103983                                           // 00000075FC48: 7E103983
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000075FC4C: 30060082
	v_min_i32_e32 v19, s20, v1                                 // 00000075FC50: 22260214
	v_add3_u32 v20, v2, v12, v21                               // 00000075FC54: D6550014 04561902
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000075FC5C: BF870224
	v_and_or_b32 v1, 0xffff0000, v4, v8                        // 00000075FC60: D6570001 042208FF FFFF0000
	v_mov_b32_e32 v8, 0                                        // 00000075FC6C: 7E100280
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 00000075FC70: 7C822712
	ds_store_b32 v3, v1                                        // 00000075FC74: D8340000 00000103
	s_waitcnt lgkmcnt(0)                                       // 00000075FC7C: BF89FC07
	s_barrier                                                  // 00000075FC80: BFBD0000
	buffer_gl0_inv                                             // 00000075FC84: E0AC0000 00000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000075FC8C: BE81206A
	s_cbranch_execz 21                                         // 00000075FC90: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x1e8>
	v_lshlrev_b32_e32 v1, 1, v18                               // 00000075FC94: 30022481
	v_lshlrev_b32_e32 v3, 4, v18                               // 00000075FC98: 30062484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000075FC9C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000075FCA0: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000075FCA4: 3408069F
	.long 0xd7000001                                           // 00000075FCA8: D7000001
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 00000075FCAC: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FCB0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 00000075FCB4: D5207C02 00020514
	.long 0xd7000003                                           // 00000075FCBC: D7000003
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000075FCC0: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 00000075FCC4: D5207C04 0002090A
	s_clause 0x1                                               // 00000075FCCC: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 00000075FCD0: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 00000075FCD8: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 00000075FCE0: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 00000075FCE4: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 00000075FCE8: 8C7E017E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000075FCEC: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 00000075FCF4: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 00000075FCFC: CA100080 1A140080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000075FD04: BE81206A
	s_cbranch_execz 579                                        // 00000075FD08: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb18>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v18     // 00000075FD0C: CA200080 1A0024A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v18    // 00000075FD14: CA220080 150C2485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 00000075FD1C: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000075FD24: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 00000075FD28: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 00000075FD30: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 00000075FD38: CA100080 111E011D
	s_mul_i32 s0, s11, 6                                       // 00000075FD40: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000075FD44: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000075FD48: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000075FD4C: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000075FD50: 9610860A
	s_mov_b32 s15, 0                                           // 00000075FD54: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000075FD58: 848A810A
	s_branch 526                                               // 00000075FD5C: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xa98>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000075FD60: 8C7E117E
	v_and_b32_e32 v13, 0xff, v5                                // 00000075FD64: 361A0AFF 000000FF
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000075FD6C: 8B006A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 00000075FD70: 4A3636FF 00000200
	s_or_b32 s15, s0, s15                                      // 00000075FD78: 8C0F0F00
	v_add_nc_u32_e32 v28, 64, v28                              // 00000075FD7C: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 00000075FD80: 301A1A82
	ds_load_b32 v47, v13                                       // 00000075FD84: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 00000075FD8C: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000075FD90: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000075FD94: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 00000075FD9C: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 00000075FDA4: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 00000075FDA8: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 00000075FDAC: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000075FDB4: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FDB8: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 00000075FDC0: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 00000075FDC8: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 00000075FDD0: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 00000075FDD8: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000075FDDC: 300A0A82
	ds_load_b32 v51, v5                                        // 00000075FDE0: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 00000075FDE8: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075FDEC: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FDF0: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 00000075FDF8: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 00000075FE00: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FE04: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 00000075FE0C: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 00000075FE14: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075FE18: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FE1C: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 00000075FE24: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 00000075FE2C: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000075FE34: 300A0A82
	ds_load_b32 v55, v5                                        // 00000075FE38: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 00000075FE40: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075FE44: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FE48: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 00000075FE50: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 00000075FE58: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FE5C: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 00000075FE64: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 00000075FE6C: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075FE70: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FE74: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 00000075FE7C: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 00000075FE84: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 00000075FE8C: 300A0A82
	ds_load_b32 v59, v5                                        // 00000075FE90: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 00000075FE98: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000075FE9C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FEA0: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 00000075FEA8: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 00000075FEB0: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FEB4: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 00000075FEBC: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 00000075FEC4: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000075FEC8: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 00000075FECC: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 00000075FED4: D8D80000 3E000005
	.long 0xd73c0005                                           // 00000075FEDC: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000075FEE0: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 00000075FEE4: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 00000075FEEC: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000075FEF0: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000075FEF4: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 00000075FEF8: D5207C2C 01AA0C07
	s_clause 0x3                                               // 00000075FF00: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 00000075FF04: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 00000075FF0C: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 00000075FF14: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 00000075FF1C: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000075FF24: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000075FF28: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 00000075FF30: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FF34: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000075FF38: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 00000075FF40: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000075FF44: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 00000075FF4C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FF50: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000075FF54: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000075FF5C: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000075FF60: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 00000075FF68: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FF6C: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000075FF70: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 00000075FF78: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000075FF7C: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 00000075FF84: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FF88: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000075FF8C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000075FF94: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000075FF98: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 00000075FFA0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FFA4: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000075FFA8: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 00000075FFB0: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000075FFB4: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 00000075FFBC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000075FFC0: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000075FFC4: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000075FFCC: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000075FFD0: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000075FFD8: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 00000075FFDC: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 00000075FFE0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000075FFE4: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000075FFE8: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 00000075FFF0: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 00000075FFF8: D7006A2D
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000075FFFC: 0200092B
	s_waitcnt lgkmcnt(1)                                       // 000000760000: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000760004: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s5, v44, vcc_lo             // 00000076000C: D5207C2E 01AA5805
	.long 0xd7006a2b                                           // 000000760014: D7006A2B
	v_cndmask_b32_e32 v0, v43, v16, vcc_lo                     // 000000760018: 0200212B
	s_waitcnt lgkmcnt(0)                                       // 00000076001C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000760020: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000760024: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s14, v44, vcc_lo            // 00000076002C: D5207C2C 01AA580E
	v_fmac_f32_e32 v21, v29, v5                                // 000000760034: 562A0B1D
	s_clause 0x3                                               // 000000760038: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000076003C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000760044: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000076004C: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000760054: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000076005C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000760060: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760068: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000076006C: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000760074: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076007C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000760080: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000760088: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000076008C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760094: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000760098: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 0000007600A0: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007600A8: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 0000007600AC: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 0000007600B4: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000007600B8: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007600C0: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000007600C4: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000007600CC: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007600D4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000007600D8: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000007600E0: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000007600E4: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007600EC: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000007600F0: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000007600F8: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760100: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000760104: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 00000076010C: 56340B1D
	s_clause 0x3                                               // 000000760110: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 000000760114: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 00000076011C: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 000000760124: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 00000076012C: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 000000760134: D7006A2D
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000760138: 0200092D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000076013C: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s5, v46, vcc_lo             // 000000760140: D5207C2E 01AA5C05
	s_waitcnt vmcnt(3)                                         // 000000760148: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000076014C: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000760154: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076015C: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000760160: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000760168: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000760170: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760174: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000760178: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000760180: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760188: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000076018C: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000760194: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000076019C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007601A0: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 0000007601A4: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 0000007601AC: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007601B4: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 0000007601B8: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 0000007601C0: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000007601C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007601CC: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000007601D0: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000007601D8: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007601E0: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000007601E4: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000007601EC: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007601F4: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 0000007601F8: 56320B1D
	s_clause 0x3                                               // 0000007601FC: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000760200: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000760208: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000760210: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 000000760218: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 000000760220: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000760224: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076022C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000760230: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000760238: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760240: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000760244: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000076024C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000760250: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760258: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000076025C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000760264: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076026C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000760270: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000760278: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000076027C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760284: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000760288: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000760290: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760298: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000076029C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 0000007602A4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 0000007602A8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007602B0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 0000007602B4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000007602BC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007602C4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000007602C8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 0000007602D0: 56300B1D
	s_clause 0x3                                               // 0000007602D4: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 0000007602D8: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 0000007602E0: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 0000007602E8: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 0000007602F0: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 0000007602F8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000007602FC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760304: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000760308: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000760310: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760318: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000076031C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000760324: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000760328: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760330: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000760334: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000076033C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760344: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000760348: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000760350: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000760354: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076035C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000760360: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000760368: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760370: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000760374: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000076037C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000760380: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000760388: D7006A27
	v_cndmask_b32_e32 v0, v43, v4, vcc_lo                      // 00000076038C: 0200092B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000760390: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000760394: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v44, vcc_lo             // 00000076039C: D5207C28 01AA5805
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 0000007603A4: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007603AC: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 0000007603B0: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 0000007603B8: 562E0B1D
	s_clause 0x3                                               // 0000007603BC: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000007603C0: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000007603C8: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000007603D0: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000007603D8: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000007603E0: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000007603E4: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007603EC: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000007603F0: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000007603F8: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760400: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000760404: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000076040C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000760410: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760418: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000076041C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000760424: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076042C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000760430: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000760438: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000076043C: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760444: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000760448: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000760450: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760458: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000076045C: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000760464: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000760468: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000760470: D7006A27
	v_cndmask_b32_e32 v0, v45, v4, vcc_lo                      // 000000760474: 0200092D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000760478: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000076047C: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s5, v46, vcc_lo             // 000000760484: D5207C28 01AA5C05
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000076048C: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760494: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000760498: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 0000007604A0: 562C0B1D
	s_clause 0x3                                               // 0000007604A4: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 0000007604A8: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 0000007604B0: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 0000007604B8: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 0000007604C0: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 0000007604C8: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 0000007604CC: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007604D4: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 0000007604D8: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 0000007604E0: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 0000007604E4: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 0000007604EC: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007604F0: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 0000007604F4: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 0000007604FC: 7E100304
	s_waitcnt vmcnt(2)                                         // 000000760500: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000760504: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076050C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000760510: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000760518: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760520: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000760524: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000076052C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000760530: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760538: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000076053C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000760544: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000076054C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000760550: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000760558: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000076055C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760564: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000760568: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000760570: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760578: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000076057C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 000000760584: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 000000760588: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 00000076058C: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000760590: 917E0F7E
	s_cbranch_execz 31                                         // 000000760594: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xb14>
	s_waitcnt vmcnt(0)                                         // 000000760598: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 00000076059C: CA200105 011224A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 0000007605A4: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 0000007605AC: 7E080308
	s_mov_b32 s17, exec_lo                                     // 0000007605B0: BE91007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007605B4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 0000007605B8: 7C8C2712
	.long 0xd4c1007e                                           // 0000007605BC: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000007605C0: 02022712
	s_cbranch_execz 64998                                      // 0000007605C4: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	v_ashrrev_i32_e32 v2, 31, v28                              // 0000007605C8: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 0000007605CC: 3408369F
	.long 0xd7000001                                           // 0000007605D0: D7000001
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 0000007605D4: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007605D8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s0                  // 0000007605DC: D5207C02 00020514
	.long 0xd7000003                                           // 0000007605E4: D7000003
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 0000007605E8: 02023709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s0                  // 0000007605EC: D5207C04 0002090A
	s_clause 0x1                                               // 0000007605F4: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 0000007605F8: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000760600: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000760608: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 00000076060C: 7E3C170D
	s_branch 64979                                             // 000000760610: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0x260>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000760614: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000760618: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 00000076061C: 8C7E017E
	.long 0xd71f0001                                           // 000000760620: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000760624: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000760628: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000076062C: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 000000760630: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 000000760634: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000760638: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000076063C: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000760640: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 000000760644: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 000000760648: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000076064C: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000760650: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000760654: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000760658: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000076065C: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 000000760664: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 000000760668: 06060715
	s_waitcnt vmcnt(0)                                         // 00000076066C: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 000000760670: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 000000760678: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 000000760680: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 000000760688: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 000000760690: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 000000760698: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 0000007606A0: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 0000007606A8: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 0000007606AC: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 0000007606B4: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 0000007606B8: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 0000007606C0: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 0000007606C4: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 0000007606C8: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 0000007606D0: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 0000007606D8: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 0000007606E0: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 0000007606E4: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 0000007606EC: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 0000007606F0: 06061503
	s_waitcnt lgkmcnt(2)                                       // 0000007606F4: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 0000007606F8: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 000000760700: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 000000760708: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 000000760710: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 000000760714: 06081704
	s_waitcnt lgkmcnt(1)                                       // 000000760718: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 00000076071C: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 000000760720: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 000000760728: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 000000760730: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 000000760738: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 000000760740: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 000000760744: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 000000760748: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 000000760750: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 000000760754: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 000000760758: DACC0000 09000313
	s_waitcnt lgkmcnt(3)                                       // 000000760760: BF89FC37
	v_add_f32_e32 v6, v6, v12                                  // 000000760764: 060C1906
	s_waitcnt lgkmcnt(2)                                       // 000000760768: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 00000076076C: 06081504
	ds_bpermute_b32 v13, v19, v7                               // 000000760770: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000760778: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 000000760780: 3A260282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000760784: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000760788: 7C9826A0
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 00000076078C: 02262701
	v_lshlrev_b32_e32 v19, 2, v19                              // 000000760790: 30262682
	s_waitcnt lgkmcnt(2)                                       // 000000760794: BF89FC27
	v_add_f32_e32 v3, v3, v9                                   // 000000760798: 06061303
	s_waitcnt lgkmcnt(0)                                       // 00000076079C: BF89FC07
	v_dual_add_f32 v7, v7, v13 :: v_dual_add_f32 v2, v2, v18   // 0000007607A0: C9081B07 07022502
	ds_bpermute_b32 v10, v19, v4                               // 0000007607A8: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 0000007607B0: DACC0000 0C000613
	ds_bpermute_b32 v13, v19, v7                               // 0000007607B8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 0000007607C0: DACC0000 12000213
	v_add_f32_e32 v5, v5, v11                                  // 0000007607C8: 060A1705
	v_add_f32_e32 v9, v8, v17                                  // 0000007607CC: 06122308
	ds_bpermute_b32 v8, v19, v3                                // 0000007607D0: DACC0000 08000313
	ds_bpermute_b32 v11, v19, v5                               // 0000007607D8: DACC0000 0B000513
	s_waitcnt lgkmcnt(2)                                       // 0000007607E0: BF89FC27
	v_add_f32_e32 v2, v2, v18                                  // 0000007607E4: 06042502
	ds_bpermute_b32 v17, v19, v9                               // 0000007607E8: DACC0000 11000913
	v_xor_b32_e32 v19, 1, v1                                   // 0000007607F0: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007607F4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000007607F8: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 0000007607FC: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 000000760800: 30260282
	s_waitcnt lgkmcnt(2)                                       // 000000760804: BF89FC27
	v_add_f32_e32 v1, v3, v8                                   // 000000760808: 06021103
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v8, v7, v13   // 00000076080C: C9081504 03081B07
	s_waitcnt lgkmcnt(1)                                       // 000000760814: BF89FC17
	v_dual_add_f32 v4, v5, v11 :: v_dual_add_f32 v5, v6, v12   // 000000760818: C9081705 04041906
	s_waitcnt lgkmcnt(0)                                       // 000000760820: BF89FC07
	v_add_f32_e32 v10, v9, v17                                 // 000000760824: 06142309
	ds_bpermute_b32 v6, v19, v1                                // 000000760828: DACC0000 06000113
	ds_bpermute_b32 v9, v19, v3                                // 000000760830: DACC0000 09000313
	ds_bpermute_b32 v11, v19, v4                               // 000000760838: DACC0000 0B000413
	ds_bpermute_b32 v12, v19, v5                               // 000000760840: DACC0000 0C000513
	ds_bpermute_b32 v13, v19, v8                               // 000000760848: DACC0000 0D000813
	ds_bpermute_b32 v17, v19, v10                              // 000000760850: DACC0000 11000A13
	ds_bpermute_b32 v7, v19, v2                                // 000000760858: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 000000760860: 7D942080
	s_cbranch_execz 29                                         // 000000760864: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xddc>
	.long 0xd72c000e                                           // 000000760868: D72C000E
	v_cndmask_b32_e32 v0, v14, v184, vcc_lo                    // 00000076086C: 0201710E
	s_waitcnt lgkmcnt(2)                                       // 000000760870: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 000000760874: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 00000076087C: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 000000760884: BF89FC17
	v_dual_add_f32 v10, v10, v17 :: v_dual_add_f32 v5, v5, v12 // 000000760888: C908230A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 000000760890: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 000000760894: 06040F02
	v_mad_u32_u24 v13, v15, 28, v14                            // 000000760898: D60B000D 0439390F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007608A0: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 0000007608A4: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 0000007608AC: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 0000007608B4: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 0000007608BC: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 0000007608C4: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 0000007608CC: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 0000007608D4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s0                              // 0000007608DC: 8C7E007E
	.long 0xd7050001                                           // 0000007608E0: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000007608E4: 02014B00
	.long 0x7f063880                                           // 0000007608E8: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000007608EC: BF89FC07
	s_barrier                                                  // 0000007608F0: BFBD0000
	buffer_gl0_inv                                             // 0000007608F4: E0AC0000 00000000
	.long 0xd7390001                                           // 0000007608FC: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000760900: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760904: BF870091
	.long 0xd7044001                                           // 000000760908: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000076090C: 02020300
	.long 0xd7395001                                           // 000000760910: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000760914: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760918: BF870091
	.long 0xd7625001                                           // 00000076091C: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 000000760920: 020202FF 0000007F
	.long 0xd7030801                                           // 000000760928: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 00000076092C: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760930: BF870091
	.long 0xd7390003                                           // 000000760934: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000760938: 02020282
	.long 0xd7000001                                           // 00000076093C: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000760940: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000760944: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000760948: D5207C02 00010003
	.long 0xd44c0000                                           // 000000760950: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 000000760954: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000760958: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000076095C: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000760960: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000760964: BE812000
	s_cbranch_execz 39                                         // 000000760968: BFA50027 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb1ELi0ELi0EEEvPKhPKtPvlllllS6_f+0xf08>
	.long 0xd7054000                                           // 00000076096C: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 000000760970: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 000000760974: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000760978: BF870092
	.long 0xd7041000                                           // 00000076097C: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000760980: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 000000760984: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000076098C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000760990: D6460003 040D0500
	v_add_nc_u32_e32 v5, 0x400, v3                             // 000000760998: 4A0A06FF 00000400
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000007609A0: D6FE7C03 0202000C
	ds_load_2addr_b32 v[6:7], v5 offset1:7                     // 0000007609A8: D8DC0700 06000005
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000007609B0: D6FE7C04 0412000D
	.long 0xd73c0000                                           // 0000007609B8: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000007609BC: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007609C0: BF870092
	.long 0xd73c0003                                           // 0000007609C4: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 0000007609C8: 02020682
	.long 0xd7006a03                                           // 0000007609CC: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007609D0: 02020608
	s_waitcnt lgkmcnt(0)                                       // 0000007609D4: BF89FC07
	v_add_f32_e32 v2, 0, v6                                    // 0000007609D8: 06040C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007609DC: BF870193
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007609E0: D5207C04 01AA0809
	.long 0xd7006a00                                           // 0000007609E8: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007609EC: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007609F0: BF870193
	v_add_f32_e32 v2, v2, v7                                   // 0000007609F4: 06040F02
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007609F8: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000760A00: DC6A0000 007C0200
	s_endpgm                                                   // 000000760A08: BFB00000
		...

