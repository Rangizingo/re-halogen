0000000000597900 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi1ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi1ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 000000597900: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000597904: F40C0100 F8000000
	s_load_b64 s[0:1], s[0:1], 0x20                            // 00000059790C: F4040000 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 000000597914: 32020085
	s_mov_b32 s3, 0                                            // 000000597918: BE830080
	v_mov_b32_e32 v10, 0                                       // 00000059791C: 7E140280
	s_lshl_b64 s[12:13], s[2:3], 3                             // 000000597920: 848C8302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000597924: BF8700C9
	v_dual_mov_b32 v2, s13 :: v_dual_and_b32 v7, 31, v0        // 000000597928: CA24000D 0206009F
	v_or_b32_e32 v1, s12, v1                                   // 000000597930: 3802020C
	s_waitcnt lgkmcnt(0)                                       // 000000597934: BF89FC07
	s_ashr_i32 s2, s11, 31                                     // 000000597938: 86029F0B
	v_cmp_gt_i64_e32 vcc_lo, s[0:1], v[1:2]                    // 00000059793C: 7CA80200
	s_lshr_b32 s2, s2, 28                                      // 000000597940: 85029C02
	s_mov_b32 s1, exec_lo                                      // 000000597944: BE81007E
	s_add_u32 s12, s10, s2                                     // 000000597948: 800C020A
	s_addc_u32 s13, s11, 0                                     // 00000059794C: 820D800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000597950: BF870499
	s_lshr_b64 s[12:13], s[12:13], 4                           // 000000597954: 858C840C
	.long 0xd4c4007e                                           // 000000597958: D4C4007E
	v_cndmask_b32_e32 v1, s12, v7, vcc_lo                      // 00000059795C: 02020E0C
	s_cbranch_execz 369                                        // 000000597960: BFA50171 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x628>
	s_ashr_i32 s0, s11, 31                                     // 000000597964: 86009F0B
	v_dual_cndmask_b32 v3, 0, v2 :: v_dual_and_b32 v8, 6, v0   // 000000597968: CA640480 03080086
	s_lshr_b32 s0, s0, 24                                      // 000000597970: 85009800
	v_cndmask_b32_e32 v5, 0, v1, vcc_lo                        // 000000597974: 020A0280
	s_add_u32 s10, s10, s0                                     // 000000597978: 800A000A
	s_addc_u32 s11, s11, 0                                     // 00000059797C: 820B800B
	v_bfe_u32 v12, v0, 3, 1                                    // 000000597980: D610000C 02050700
	s_ashr_i64 s[10:11], s[10:11], 8                           // 000000597988: 868A880A
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v9, 4, v0           // 00000059798C: CA240080 06080084
	s_mul_i32 s0, s11, 0xd2                                    // 000000597994: 9600FF0B 000000D2
	s_mul_hi_u32 s2, s10, 0xd2                                 // 00000059799C: 9682FF0A 000000D2
	s_mulk_i32 s10, 0xd2                                       // 0000005979A4: B80A00D2
	s_add_i32 s2, s2, s0                                       // 0000005979A8: 81020002
	.long 0xd72c000a                                           // 0000005979AC: D72C000A
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000005979B0: 0202060A
	v_and_b32_e32 v0, 15, v0                                   // 0000005979B4: 3600008F
	v_mad_u64_u32 v[3:4], null, s10, v5, s[4:5]                // 0000005979B8: D6FE7C03 00120A0A
	.long 0xd72c0005                                           // 0000005979C0: D72C0005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 0000005979C4: 02020A02
	v_dual_mov_b32 v20, v7 :: v_dual_lshlrev_b32 v11, 6, v12   // 0000005979C8: CA220107 140A1886
	v_lshlrev_b32_e32 v12, 5, v12                              // 0000005979D0: 30181885
	v_or_b32_e32 v13, 8, v9                                    // 0000005979D4: 381A1288
	v_or_b32_e32 v14, 8, v8                                    // 0000005979D8: 381C1088
	v_or_b32_e32 v15, 16, v9                                   // 0000005979DC: 381E1290
	v_or_b32_e32 v16, 16, v8                                   // 0000005979E0: 38201090
	v_add3_u32 v4, v5, v4, v10                                 // 0000005979E4: D6550004 042A0905
	v_lshrrev_b32_e32 v10, 4, v7                               // 0000005979EC: 32140E84
	v_or_b32_e32 v17, 24, v9                                   // 0000005979F0: 38221298
	v_or_b32_e32 v18, 24, v8                                   // 0000005979F4: 38241098
	v_lshlrev_b32_e32 v5, 4, v7                                // 0000005979F8: 300A0E84
	s_delay_alu instid0(VALU_DEP_4)                            // 0000005979FC: BF870004
	v_mul_u32_u24_e32 v19, 0xd2, v10                           // 000000597A00: 162614FF 000000D2
	v_mov_b32_e32 v10, v6                                      // 000000597A08: 7E140306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597A0C: BF870091
	.long 0xd700001d                                           // 000000597A10: D700001D
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000597A14: 02022703
	v_add_co_ci_u32_e64 v30, null, 0, v4, s0                   // 000000597A18: D5207C1E 00020880
	v_and_b32_e32 v25, 16, v5                                  // 000000597A20: 36320A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597A24: BF870093
	.long 0xd700001b                                           // 000000597A28: D700001B
	v_cndmask_b32_e32 v1, v29, v11, vcc_lo                     // 000000597A2C: 0202171D
	v_add_co_ci_u32_e64 v28, null, 0, v30, s0                  // 000000597A30: D5207C1C 00023C80
	.long 0xd7000017                                           // 000000597A38: D7000017
	v_cndmask_b32_e32 v1, v29, v12, vcc_lo                     // 000000597A3C: 0202191D
	v_and_b32_e32 v26, 32, v5                                  // 000000597A40: 36340AA0
	v_add_co_ci_u32_e64 v24, null, 0, v30, s0                  // 000000597A44: D5207C18 00023C80
	.long 0xd7000015                                           // 000000597A4C: D7000015
	v_cndmask_b32_e32 v1, v29, v0, vcc_lo                      // 000000597A50: 0202011D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000597A54: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v30, s0                  // 000000597A58: D5207C16 00023C80
	.long 0xd7000017                                           // 000000597A60: D7000017
	v_cndmask_b32_e32 v1, v23, v25, vcc_lo                     // 000000597A64: 02023317
	v_add_co_ci_u32_e64 v24, null, 0, v24, s0                  // 000000597A68: D5207C18 00023080
	.long 0xd700001a                                           // 000000597A70: D700001A
	v_cndmask_b32_e32 v1, v27, v26, vcc_lo                     // 000000597A74: 0202351B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000597A78: BF8700D1
	v_add_co_ci_u32_e64 v27, null, 0, v28, s0                  // 000000597A7C: D5207C1B 00023880
	s_clause 0x1                                               // 000000597A84: BF850001
	global_load_i8 v37, v[21:22], off offset:192               // 000000597A88: DC4600C0 257C0015
	global_load_b128 v[21:24], v[23:24], off offset:128        // 000000597A90: DC5E0080 157C0017
	.long 0xd7000019                                           // 000000597A98: D7000019
	v_cndmask_b32_e32 v1, v26, v25, vcc_lo                     // 000000597A9C: 0202331A
	v_add_co_ci_u32_e64 v26, null, 0, v27, s0                  // 000000597AA0: D5207C1A 00023680
	s_clause 0x1                                               // 000000597AA8: BF850001
	global_load_b128 v[25:28], v[25:26], off                   // 000000597AAC: DC5E0000 197C0019
	global_load_d16_b16 v38, v[29:30], off offset:208          // 000000597AB4: DC8200D0 267C001D
	.long 0xd73c001d                                           // 000000597ABC: D73C001D
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000597AC0: 02020A81
	v_add_nc_u32_e32 v20, 32, v20                              // 000000597AC4: 4A2828A0
	v_add_nc_u32_e32 v5, 0x200, v5                             // 000000597AC8: 4A0A0AFF 00000200
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597AD0: BF870093
	.long 0xd7000021                                           // 000000597AD4: D7000021
	v_cndmask_b32_e32 v1, s6, v29, vcc_lo                      // 000000597AD8: 02023A06
	v_add_co_ci_u32_e64 v34, null, s7, v30, s0                 // 000000597ADC: D5207C22 00023C07
	s_clause 0x1                                               // 000000597AE4: BF850001
	global_load_b128 v[29:32], v[33:34], off                   // 000000597AE8: DC5E0000 1D7C0021
	global_load_b128 v[33:36], v[33:34], off offset:16         // 000000597AF0: DC5E0010 217C0021
	.long 0xd4430000                                           // 000000597AF8: D4430000
	v_cndmask_b32_e32 v1, s12, v20, vcc_lo                     // 000000597AFC: 0202280C
	s_or_b32 s3, s0, s3                                        // 000000597B00: 8C030300
	s_waitcnt vmcnt(5)                                         // 000000597B04: BF8917F7
	v_cvt_f32_i32_e32 v37, v37                                 // 000000597B08: 7E4A0B25
	s_waitcnt vmcnt(4)                                         // 000000597B0C: BF8913F7
	v_lshrrev_b32_e32 v42, v8, v22                             // 000000597B10: 32542D08
	v_lshrrev_b32_e32 v43, v14, v22                            // 000000597B14: 32562D0E
	v_lshrrev_b32_e32 v44, v16, v22                            // 000000597B18: 32582D10
	v_lshrrev_b32_e32 v22, v18, v22                            // 000000597B1C: 322C2D12
	v_lshrrev_b32_e32 v48, v8, v24                             // 000000597B20: 32603108
	v_lshrrev_b32_e32 v49, v14, v24                            // 000000597B24: 3262310E
	v_lshrrev_b32_e32 v50, v16, v24                            // 000000597B28: 32643110
	v_lshrrev_b32_e32 v24, v18, v24                            // 000000597B2C: 32303112
	s_waitcnt vmcnt(2)                                         // 000000597B30: BF890BF7
	v_fma_mix_f32 v37, v38, v37, neg(0) op_sel_hi:[1,0,0]      // 000000597B34: CC200025 8A024B26
	v_bfe_u32 v53, v26, v9, 4                                  // 000000597B3C: D6100035 0212131A
	v_bfe_u32 v54, v26, v13, 4                                 // 000000597B44: D6100036 02121B1A
	v_bfe_u32 v55, v26, v15, 4                                 // 000000597B4C: D6100037 02121F1A
	v_bfe_u32 v26, v26, v17, 4                                 // 000000597B54: D610001A 0212231A
	v_lshlrev_b32_e32 v22, 4, v22                              // 000000597B5C: 302C2C84
	v_bfe_u32 v59, v28, v9, 4                                  // 000000597B60: D610003B 0212131C
	v_bfe_u32 v60, v28, v13, 4                                 // 000000597B68: D610003C 02121B1C
	v_bfe_u32 v61, v28, v15, 4                                 // 000000597B70: D610003D 02121F1C
	v_bfe_u32 v28, v28, v17, 4                                 // 000000597B78: D610001C 0212231C
	v_lshlrev_b32_e32 v24, 4, v24                              // 000000597B80: 30303084
	v_and_or_b32 v22, v22, 48, v26                             // 000000597B84: D6570016 04696116
	v_lshrrev_b32_e32 v39, v8, v21                             // 000000597B8C: 324E2B08
	v_lshrrev_b32_e32 v40, v14, v21                            // 000000597B90: 32502B0E
	v_lshrrev_b32_e32 v41, v16, v21                            // 000000597B94: 32522B10
	v_and_or_b32 v24, v24, 48, v28                             // 000000597B98: D6570018 04716118
	v_lshrrev_b32_e32 v21, v18, v21                            // 000000597BA0: 322A2B12
	v_subrev_nc_u32_e32 v22, 32, v22                           // 000000597BA4: 4E2C2CA0
	v_lshrrev_b32_e32 v45, v8, v23                             // 000000597BA8: 325A2F08
	v_lshrrev_b32_e32 v46, v14, v23                            // 000000597BAC: 325C2F0E
	v_lshrrev_b32_e32 v47, v16, v23                            // 000000597BB0: 325E2F10
	v_lshrrev_b32_e32 v23, v18, v23                            // 000000597BB4: 322E2F12
	v_subrev_nc_u32_e32 v24, 32, v24                           // 000000597BB8: 4E3030A0
	v_bfe_u32 v38, v25, v9, 4                                  // 000000597BBC: D6100026 02121319
	v_bfe_u32 v51, v25, v13, 4                                 // 000000597BC4: D6100033 02121B19
	v_bfe_u32 v52, v25, v15, 4                                 // 000000597BCC: D6100034 02121F19
	v_bfe_u32 v25, v25, v17, 4                                 // 000000597BD4: D6100019 02122319
	v_cvt_f32_i32_e32 v22, v22                                 // 000000597BDC: 7E2C0B16
	v_lshlrev_b32_e32 v21, 4, v21                              // 000000597BE0: 302A2A84
	v_bfe_u32 v56, v27, v9, 4                                  // 000000597BE4: D6100038 0212131B
	v_lshlrev_b32_e32 v45, 4, v45                              // 000000597BEC: 305A5A84
	v_bfe_u32 v57, v27, v13, 4                                 // 000000597BF0: D6100039 02121B1B
	v_bfe_u32 v58, v27, v15, 4                                 // 000000597BF8: D610003A 02121F1B
	v_bfe_u32 v27, v27, v17, 4                                 // 000000597C00: D610001B 0212231B
	v_cvt_f32_i32_e32 v24, v24                                 // 000000597C08: 7E300B18
	v_dual_mul_f32 v22, v37, v22 :: v_dual_lshlrev_b32 v23, 4, v23// 000000597C0C: C8E22D25 16162E84
	v_and_or_b32 v21, v21, 48, v25                             // 000000597C14: D6570015 04656115
	v_and_or_b32 v26, v45, 48, v56                             // 000000597C1C: D657001A 04E1612D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000597C24: BF870214
	v_mul_f32_e32 v24, v37, v24                                // 000000597C28: 10303125
	v_and_or_b32 v23, v23, 48, v27                             // 000000597C2C: D6570017 046D6117
	v_lshlrev_b32_e32 v39, 4, v39                              // 000000597C34: 304E4E84
	v_subrev_nc_u32_e32 v21, 32, v21                           // 000000597C38: 4E2A2AA0
	v_subrev_nc_u32_e32 v26, 32, v26                           // 000000597C3C: 4E3434A0
	v_lshlrev_b32_e32 v41, 4, v41                              // 000000597C40: 30525284
	v_subrev_nc_u32_e32 v23, 32, v23                           // 000000597C44: 4E2E2EA0
	v_lshlrev_b32_e32 v42, 4, v42                              // 000000597C48: 30545484
	v_cvt_f32_i32_e32 v21, v21                                 // 000000597C4C: 7E2A0B15
	v_lshlrev_b32_e32 v40, 4, v40                              // 000000597C50: 30505084
	v_lshlrev_b32_e32 v44, 4, v44                              // 000000597C54: 30585884
	v_lshlrev_b32_e32 v47, 4, v47                              // 000000597C58: 305E5E84
	v_lshlrev_b32_e32 v48, 4, v48                              // 000000597C5C: 30606084
	v_lshlrev_b32_e32 v49, 4, v49                              // 000000597C60: 30626284
	v_lshlrev_b32_e32 v50, 4, v50                              // 000000597C64: 30646484
	v_and_or_b32 v38, v39, 48, v38                             // 000000597C68: D6570026 04996127
	v_cvt_f32_i32_e32 v26, v26                                 // 000000597C70: 7E340B1A
	v_lshlrev_b32_e32 v43, 4, v43                              // 000000597C74: 30565684
	v_cvt_f32_i32_e32 v23, v23                                 // 000000597C78: 7E2E0B17
	v_dual_mul_f32 v21, v37, v21 :: v_dual_lshlrev_b32 v46, 4, v46// 000000597C7C: C8E22B25 152E5C84
	v_and_or_b32 v39, v40, 48, v51                             // 000000597C84: D6570027 04CD6128
	v_and_or_b32 v40, v41, 48, v52                             // 000000597C8C: D6570028 04D16129
	v_and_or_b32 v25, v42, 48, v53                             // 000000597C94: D6570019 04D5612A
	v_and_or_b32 v42, v44, 48, v55                             // 000000597C9C: D657002A 04DD612C
	v_and_or_b32 v44, v47, 48, v58                             // 000000597CA4: D657002C 04E9612F
	v_and_or_b32 v27, v48, 48, v59                             // 000000597CAC: D657001B 04ED6130
	v_and_or_b32 v45, v49, 48, v60                             // 000000597CB4: D657002D 04F16131
	v_subrev_nc_u32_e32 v28, 32, v38                           // 000000597CBC: 4E384CA0
	v_mul_f32_e32 v26, v37, v26                                // 000000597CC0: 10343525
	v_and_or_b32 v41, v43, 48, v54                             // 000000597CC4: D6570029 04D9612B
	v_mul_f32_e32 v23, v37, v23                                // 000000597CCC: 102E2F25
	v_and_or_b32 v43, v46, 48, v57                             // 000000597CD0: D657002B 04E5612E
	v_and_or_b32 v46, v50, 48, v61                             // 000000597CD8: D657002E 04F56132
	v_subrev_nc_u32_e32 v38, 32, v39                           // 000000597CE0: 4E4C4EA0
	v_subrev_nc_u32_e32 v39, 32, v40                           // 000000597CE4: 4E4E50A0
	v_subrev_nc_u32_e32 v25, 32, v25                           // 000000597CE8: 4E3232A0
	v_subrev_nc_u32_e32 v40, 32, v41                           // 000000597CEC: 4E5052A0
	v_subrev_nc_u32_e32 v41, 32, v42                           // 000000597CF0: 4E5254A0
	v_subrev_nc_u32_e32 v42, 32, v43                           // 000000597CF4: 4E5456A0
	v_subrev_nc_u32_e32 v43, 32, v44                           // 000000597CF8: 4E5658A0
	v_subrev_nc_u32_e32 v27, 32, v27                           // 000000597CFC: 4E3636A0
	v_subrev_nc_u32_e32 v44, 32, v45                           // 000000597D00: 4E585AA0
	v_subrev_nc_u32_e32 v45, 32, v46                           // 000000597D04: 4E5A5CA0
	v_cvt_f32_i32_e32 v28, v28                                 // 000000597D08: 7E380B1C
	v_cvt_f32_i32_e32 v38, v38                                 // 000000597D0C: 7E4C0B26
	v_cvt_f32_i32_e32 v39, v39                                 // 000000597D10: 7E4E0B27
	v_cvt_f32_i32_e32 v25, v25                                 // 000000597D14: 7E320B19
	v_cvt_f32_i32_e32 v40, v40                                 // 000000597D18: 7E500B28
	v_cvt_f32_i32_e32 v41, v41                                 // 000000597D1C: 7E520B29
	v_cvt_f32_i32_e32 v42, v42                                 // 000000597D20: 7E540B2A
	v_cvt_f32_i32_e32 v43, v43                                 // 000000597D24: 7E560B2B
	v_cvt_f32_i32_e32 v27, v27                                 // 000000597D28: 7E360B1B
	v_cvt_f32_i32_e32 v44, v44                                 // 000000597D2C: 7E580B2C
	v_cvt_f32_i32_e32 v45, v45                                 // 000000597D30: 7E5A0B2D
	v_mul_f32_e32 v28, v37, v28                                // 000000597D34: 10383925
	v_mul_f32_e32 v38, v37, v38                                // 000000597D38: 104C4D25
	v_mul_f32_e32 v39, v37, v39                                // 000000597D3C: 104E4F25
	v_mul_f32_e32 v25, v37, v25                                // 000000597D40: 10323325
	v_mul_f32_e32 v40, v37, v40                                // 000000597D44: 10505125
	v_mul_f32_e32 v41, v37, v41                                // 000000597D48: 10525325
	v_mul_f32_e32 v42, v37, v42                                // 000000597D4C: 10545525
	v_mul_f32_e32 v43, v37, v43                                // 000000597D50: 10565725
	v_mul_f32_e32 v27, v37, v27                                // 000000597D54: 10363725
	v_mul_f32_e32 v44, v37, v44                                // 000000597D58: 10585925
	v_mul_f32_e32 v45, v37, v45                                // 000000597D5C: 105A5B25
	v_bfe_u32 v37, v28, 16, 1                                  // 000000597D60: D6100025 0205211C
	v_bfe_u32 v46, v38, 16, 1                                  // 000000597D68: D610002E 02052126
	v_bfe_u32 v47, v39, 16, 1                                  // 000000597D70: D610002F 02052127
	v_bfe_u32 v48, v21, 16, 1                                  // 000000597D78: D6100030 02052115
	v_bfe_u32 v49, v25, 16, 1                                  // 000000597D80: D6100031 02052119
	v_add3_u32 v28, v28, v37, 0x7fff                           // 000000597D88: D655001C 03FE4B1C 00007FFF
	v_add3_u32 v38, v38, v46, 0x7fff                           // 000000597D94: D6550026 03FE5D26 00007FFF
	v_add3_u32 v39, v39, v47, 0x7fff                           // 000000597DA0: D6550027 03FE5F27 00007FFF
	v_bfe_u32 v50, v40, 16, 1                                  // 000000597DAC: D6100032 02052128
	v_add3_u32 v21, v21, v48, 0x7fff                           // 000000597DB4: D6550015 03FE6115 00007FFF
	.long 0x7e4c399c                                           // 000000597DC0: 7E4C399C
	v_bfe_u32 v51, v41, 16, 1                                  // 000000597DC4: D6100033 02052129
	v_add3_u32 v25, v25, v49, 0x7fff                           // 000000597DCC: D6550019 03FE6319 00007FFF
	.long 0x7e2a39a7                                           // 000000597DD8: 7E2A39A7
	v_bfe_u32 v52, v22, 16, 1                                  // 000000597DDC: D6100034 02052116
	s_waitcnt vmcnt(1)                                         // 000000597DE4: BF8907F7
	v_dot2_f32_bf16 v29, v29, v38, 0                           // 000000597DE8: CC1A401D 1A024D1D
	v_add3_u32 v39, v40, v50, 0x7fff                           // 000000597DF0: D6550027 03FE6528 00007FFF
	v_bfe_u32 v37, v26, 16, 1                                  // 000000597DFC: D6100025 0205211A
	v_add3_u32 v40, v41, v51, 0x7fff                           // 000000597E04: D6550028 03FE6729 00007FFF
	.long 0x7e4e3999                                           // 000000597E10: 7E4E3999
	v_dot2_f32_bf16 v21, v30, v21, v29                         // 000000597E14: CC1A4015 1C762B1E
	v_bfe_u32 v53, v42, 16, 1                                  // 000000597E1C: D6100035 0205212A
	v_add3_u32 v22, v22, v52, 0x7fff                           // 000000597E24: D6550016 03FE6916 00007FFF
	v_bfe_u32 v28, v43, 16, 1                                  // 000000597E30: D610001C 0205212B
	v_add3_u32 v26, v26, v37, 0x7fff                           // 000000597E38: D655001A 03FE4B1A 00007FFF
	.long 0x7e2c39a8                                           // 000000597E44: 7E2C39A8
	v_dot2_f32_bf16 v21, v31, v39, v21                         // 000000597E48: CC1A4015 1C564F1F
	v_bfe_u32 v38, v23, 16, 1                                  // 000000597E50: D6100026 02052117
	v_add3_u32 v30, v42, v53, 0x7fff                           // 000000597E58: D655001E 03FE6B2A 00007FFF
	v_bfe_u32 v25, v27, 16, 1                                  // 000000597E64: D6100019 0205211B
	v_add3_u32 v28, v43, v28, 0x7fff                           // 000000597E6C: D655001C 03FE392B 00007FFF
	.long 0x7e3c399a                                           // 000000597E78: 7E3C399A
	v_dot2_f32_bf16 v21, v32, v22, v21                         // 000000597E7C: CC1A4015 1C562D20
	v_bfe_u32 v29, v44, 16, 1                                  // 000000597E84: D610001D 0205212C
	v_add3_u32 v23, v23, v38, 0x7fff                           // 000000597E8C: D6550017 03FE4D17 00007FFF
	v_bfe_u32 v22, v45, 16, 1                                  // 000000597E98: D6100016 0205212D
	v_add3_u32 v25, v27, v25, 0x7fff                           // 000000597EA0: D6550019 03FE331B 00007FFF
	.long 0x7e2e399c                                           // 000000597EAC: 7E2E399C
	s_waitcnt vmcnt(0)                                         // 000000597EB0: BF8903F7
	v_dot2_f32_bf16 v21, v33, v30, v21                         // 000000597EB4: CC1A4015 1C563D21
	v_bfe_u32 v26, v24, 16, 1                                  // 000000597EBC: D610001A 02052118
	v_add3_u32 v27, v44, v29, 0x7fff                           // 000000597EC4: D655001B 03FE3B2C 00007FFF
	v_add3_u32 v22, v45, v22, 0x7fff                           // 000000597ED0: D6550016 03FE2D2D 00007FFF
	.long 0x7e363999                                           // 000000597EDC: 7E363999
	v_dot2_f32_bf16 v21, v34, v23, v21                         // 000000597EE0: CC1A4015 1C562F22
	v_add3_u32 v23, v24, v26, 0x7fff                           // 000000597EE8: D6550017 03FE3518 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000597EF4: BF870194
	.long 0x7e2e3996                                           // 000000597EF8: 7E2E3996
	v_dot2_f32_bf16 v21, v35, v27, v21                         // 000000597EFC: CC1A4015 1C563723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597F04: BF870091
	v_dot2_f32_bf16 v21, v36, v23, v21                         // 000000597F08: CC1A4015 1C562F24
	v_dual_add_f32 v10, v10, v21 :: v_dual_add_nc_u32 v19, 0x1a4, v19// 000000597F10: C9202B0A 0A1226FF 000001A4
	s_and_not1_b32 exec_lo, exec_lo, s3                        // 000000597F1C: 917E037E
	s_cbranch_execnz 65210                                     // 000000597F20: BFA6FEBA <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x10c>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000597F24: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000597F28: BF8700A9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000597F2C: 8C7E017E
	.long 0xd71f0000                                           // 000000597F30: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000597F34: 020100C1
	v_xor_b32_e32 v3, 16, v0                                   // 000000597F38: 3A060090
	v_xor_b32_e32 v4, 8, v0                                    // 000000597F3C: 3A080088
	v_xor_b32_e32 v5, 4, v0                                    // 000000597F40: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597F44: BF870093
	.long 0xd44c0000                                           // 000000597F48: D44C0000
	v_cndmask_b32_e32 v1, 32, v3, vcc_lo                       // 000000597F4C: 020206A0
	v_cndmask_b32_e64 v3, v0, v3, s0                           // 000000597F50: D5010003 00020700
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000597F58: BF870114
	.long 0xd44c0000                                           // 000000597F5C: D44C0000
	v_cndmask_b32_e32 v1, 32, v4, vcc_lo                       // 000000597F60: 020208A0
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000597F64: 30060682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000597F68: BF8700D2
	v_cndmask_b32_e64 v4, v0, v4, s0                           // 000000597F6C: D5010004 00020900
	.long 0xd44c0000                                           // 000000597F74: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000597F78: 02020AA0
	ds_bpermute_b32 v3, v3, v10                                // 000000597F7C: DACC0000 03000A03
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000597F84: 30080882
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000597F88: D5010005 00020B00
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000597F90: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 000000597F94: BF89FC07
	v_add_f32_e32 v3, v10, v3                                  // 000000597F98: 0606070A
	ds_bpermute_b32 v4, v4, v3                                 // 000000597F9C: DACC0000 04000304
	s_waitcnt lgkmcnt(0)                                       // 000000597FA4: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 000000597FA8: 06060903
	ds_bpermute_b32 v4, v5, v3                                 // 000000597FAC: DACC0000 04000305
	v_xor_b32_e32 v5, 2, v0                                    // 000000597FB4: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000597FB8: BF870091
	.long 0xd44c0000                                           // 000000597FBC: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000597FC0: 02020AA0
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000597FC4: D5010005 00020B00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000597FCC: BF8700D1
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000597FD0: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 000000597FD4: BF89FC07
	v_add_f32_e32 v3, v3, v4                                   // 000000597FD8: 06060903
	ds_bpermute_b32 v4, v5, v3                                 // 000000597FDC: DACC0000 04000305
	v_xor_b32_e32 v5, 1, v0                                    // 000000597FE4: 3A0A0081
	.long 0xd44c0000                                           // 000000597FE8: D44C0000
	v_cndmask_b32_e32 v1, 32, v5, vcc_lo                       // 000000597FEC: 02020AA0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000597FF0: BF870001
	v_cndmask_b32_e64 v5, v0, v5, s0                           // 000000597FF4: D5010005 00020B00
	.long 0xd44a0000                                           // 000000597FFC: D44A0000
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 000000598000: 02020E80
	s_and_b32 s0, s0, vcc_lo                                   // 000000598004: 8B006A00
	s_waitcnt lgkmcnt(0)                                       // 000000598008: BF89FC07
	v_dual_add_f32 v0, v3, v4 :: v_dual_lshlrev_b32 v3, 2, v5  // 00000059800C: C9220903 00020A82
	ds_bpermute_b32 v3, v3, v0                                 // 000000598014: DACC0000 03000003
	s_and_saveexec_b32 s1, s0                                  // 00000059801C: BE812000
	s_cbranch_execz 17                                         // 000000598020: BFA50011 <_ZN7halogen12_GLOBAL__N_16k_lq6kILi1ELi32ELi1ELb0EEEvPKhPKtPvll+0x768>
	s_waitcnt lgkmcnt(0)                                       // 000000598024: BF89FC07
	v_add_f32_e32 v3, v0, v3                                   // 000000598028: 06060700
	.long 0xd73c0000                                           // 00000059802C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000598030: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000598034: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 000000598038: D6100004 02052103
	.long 0xd7006a00                                           // 000000598040: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000598044: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000598048: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000059804C: D5207C01 01AA0209
	v_add3_u32 v2, v3, v4, 0x7fff                              // 000000598054: D6550002 03FE0903 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000598060: DC960000 007C0200
	s_endpgm                                                   // 000000598068: BFB00000
		...

