0000000000370e00 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl>:
; _ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl():
	s_clause 0x3                                               // 000000370E00: BF850003
	s_load_b32 s3, s[0:1], 0x120                               // 000000370E04: F40000C0 F8000120
	s_load_b32 s4, s[0:1], 0x88                                // 000000370E0C: F4000100 F8000088
	s_load_b32 s5, s[0:1], 0xd0                                // 000000370E14: F4000140 F80000D0
	s_load_b32 s6, s[0:1], 0x118                               // 000000370E1C: F4000180 F8000118
	v_lshrrev_b32_e32 v5, 5, v0                                // 000000370E24: 320A0085
	v_mov_b32_e32 v64, 0                                       // 000000370E28: 7E800280
	v_mov_b32_e32 v60, 0                                       // 000000370E2C: 7E780280
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v61, 0             // 000000370E30: CA100080 503C0080
	s_waitcnt lgkmcnt(0)                                       // 000000370E38: BF89FC07
	s_cmp_gt_i32 s3, 1                                         // 000000370E3C: BF028103
	s_cselect_b32 s7, -1, 0                                    // 000000370E40: 980780C1
	s_cmp_ge_i32 s2, s4                                        // 000000370E44: BF030402
	s_cselect_b32 s4, -1, 0                                    // 000000370E48: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370E4C: BF870009
	s_and_b32 s4, s7, s4                                       // 000000370E50: 8B040407
	s_cmp_gt_i32 s3, 2                                         // 000000370E54: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 000000370E58: D5010001 00110280
	s_cselect_b32 s7, -1, 0                                    // 000000370E60: 980780C1
	s_cmp_ge_i32 s2, s5                                        // 000000370E64: BF030502
	s_cselect_b32 s5, -1, 0                                    // 000000370E68: 980580C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370E6C: BF870009
	s_and_b32 s4, s7, s5                                       // 000000370E70: 8B040507
	s_cmp_gt_i32 s3, 3                                         // 000000370E74: BF028303
	v_readfirstlane_b32 s5, v1                                 // 000000370E78: 7E0A0501
	s_cselect_b32 s3, -1, 0                                    // 000000370E7C: 980380C1
	s_cmp_ge_i32 s2, s6                                        // 000000370E80: BF030602
	s_cselect_b32 s6, -1, 0                                    // 000000370E84: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370E88: BF870009
	s_and_b32 s3, s3, s6                                       // 000000370E8C: 8B030603
	s_and_b32 s4, s4, exec_lo                                  // 000000370E90: 8B047E04
	s_cselect_b32 s4, 2, s5                                    // 000000370E94: 98040582
	s_and_b32 s3, s3, exec_lo                                  // 000000370E98: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 000000370E9C: 98030483
	s_load_b128 s[4:7], s[0:1], 0x128                          // 000000370EA0: F4080100 F8000128
	s_mulk_i32 s3, 0x48                                        // 000000370EA8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370EAC: BF870009
	s_add_u32 s10, s0, s3                                      // 000000370EB0: 800A0300
	s_addc_u32 s11, s1, 0                                      // 000000370EB4: 820B8001
	s_clause 0x2                                               // 000000370EB8: BF850002
	s_load_b64 s[8:9], s[10:11], 0x30                          // 000000370EBC: F4040205 F8000030
	s_load_b32 s12, s[10:11], 0x40                             // 000000370EC4: F4000305 F8000040
	s_load_b64 s[0:1], s[10:11], null                          // 000000370ECC: F4040005 F8000000
	s_waitcnt lgkmcnt(0)                                       // 000000370ED4: BF89FC07
	.long 0xd4510011                                           // 000000370ED8: D4510011
	v_cndmask_b32_e32 v0, s8, v137, vcc_lo                     // 000000370EDC: 02011208
	s_and_b32 s3, s17, exec_lo                                 // 000000370EE0: 8B037E11
	s_cselect_b32 s16, 8, 2                                    // 000000370EE4: 98108288
	s_cselect_b32 s18, 3, 1                                    // 000000370EE8: 98128183
	v_cvt_f32_ubyte0_e32 v1, s16                               // 000000370EEC: 7E022210
	s_sub_i32 s2, s2, s12                                      // 000000370EF0: 81820C02
	s_add_i32 s14, s16, -1                                     // 000000370EF4: 810EC110
	s_and_b32 s13, s17, exec_lo                                // 000000370EF8: 8B0D7E11
	s_cselect_b32 s13, 0, 2                                    // 000000370EFC: 980D8280
	v_rcp_iflag_f32_e32 v3, v1                                 // 000000370F00: 7E065701
	s_ashr_i32 s19, s7, 31                                     // 000000370F04: 86139F07
	s_mov_b32 s3, 0                                            // 000000370F08: BE830080
	v_dual_mov_b32 v2, 0 :: v_dual_and_b32 v67, s14, v5        // 000000370F0C: CA240080 02420A0E
	s_lshl_b64 s[2:3], s[2:3], s13                             // 000000370F14: 84820D02
	v_lshrrev_b32_e32 v65, s18, v5                             // 000000370F18: 32820A12
	v_mov_b32_e32 v1, 0                                        // 000000370F1C: 7E020280
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000370F20: BF870195
	v_readfirstlane_b32 s12, v3                                // 000000370F24: 7E180503
	.long 0xd7001703                                           // 000000370F28: D7001703
	v_cndmask_b32_e32 v1, s2, v65, vcc_lo                      // 000000370F2C: 02028202
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000370F30: BF8704B1
	v_add_co_ci_u32_e64 v4, null, s3, 0, s23                   // 000000370F34: D5207C04 005D0003
	s_mul_f32 s15, s12, 0x4f7ffffe                             // 000000370F3C: A20FFF0C 4F7FFFFE
	s_lshr_b32 s12, s19, 27                                    // 000000370F44: 850C9B13
	s_add_u32 s12, s6, s12                                     // 000000370F48: 800C0C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370F4C: BF870009
	s_cvt_u32_f32 s15, s15                                     // 000000370F50: BE8F670F
	s_addc_u32 s13, s7, 0                                      // 000000370F54: 820D8007
	s_sub_i32 s22, 0, s16                                      // 000000370F58: 81961080
	s_lshr_b64 s[20:21], s[12:13], 5                           // 000000370F5C: 8594850C
	s_mul_i32 s22, s22, s15                                    // 000000370F60: 96160F16
	s_add_i32 s12, s14, s20                                    // 000000370F64: 810C140E
	s_mul_hi_u32 s13, s15, s22                                 // 000000370F68: 968D160F
	s_abs_i32 s21, s12                                         // 000000370F6C: BE95150C
	s_add_i32 s15, s15, s13                                    // 000000370F70: 810F0D0F
	s_ashr_i32 s12, s12, 31                                    // 000000370F74: 860C9F0C
	s_mul_hi_u32 s13, s21, s15                                 // 000000370F78: 968D0F15
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[3:4]                    // 000000370F7C: 7CA80608
	s_mul_i32 s15, s13, s16                                    // 000000370F80: 960F100D
	v_and_b32_e32 v66, 31, v0                                  // 000000370F84: 3684009F
	s_sub_i32 s15, s21, s15                                    // 000000370F88: 818F0F15
	s_add_i32 s21, s13, 1                                      // 000000370F8C: 8115810D
	s_sub_i32 s22, s15, s16                                    // 000000370F90: 8196100F
	s_cmp_ge_u32 s15, s16                                      // 000000370F94: BF09100F
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 000000370F98: 02060680
	s_cselect_b32 s13, s21, s13                                // 000000370F9C: 980D0D15
	s_cselect_b32 s15, s22, s15                                // 000000370FA0: 980F0F16
	s_add_i32 s21, s13, 1                                      // 000000370FA4: 8115810D
	s_cmp_ge_u32 s15, s16                                      // 000000370FA8: BF09100F
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000370FAC: 02080880
	s_cselect_b32 s13, s21, s13                                // 000000370FB0: 980D0D15
	s_lshr_b32 s14, s7, 31                                     // 000000370FB4: 850E9F07
	s_xor_b32 s13, s13, s12                                    // 000000370FB8: 8D0D0C0D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000370FBC: BF870009
	s_sub_i32 s21, s13, s12                                    // 000000370FC0: 81950C0D
	s_add_u32 s12, s6, s14                                     // 000000370FC4: 800C0E06
	s_addc_u32 s13, s7, 0                                      // 000000370FC8: 820D8007
	s_lshr_b32 s22, s19, 30                                    // 000000370FCC: 85169E13
	s_ashr_i64 s[14:15], s[12:13], 1                           // 000000370FD0: 868E810C
	s_add_u32 s12, s6, s22                                     // 000000370FD4: 800C1606
	s_addc_u32 s13, s7, 0                                      // 000000370FD8: 820D8007
	s_lshr_b32 s19, s19, 28                                    // 000000370FDC: 85139C13
	s_ashr_i64 s[12:13], s[12:13], 2                           // 000000370FE0: 868C820C
	s_add_u32 s22, s6, s19                                     // 000000370FE4: 80161306
	s_addc_u32 s23, s7, 0                                      // 000000370FE8: 82178007
	.long 0xd72c0005                                           // 000000370FEC: D72C0005
	v_cndmask_b32_e32 v0, v67, v21, vcc_lo                     // 000000370FF0: 02002B43
	s_ashr_i64 s[22:23], s[22:23], 4                           // 000000370FF4: 86968416
	s_add_u32 s19, s12, s14                                    // 000000370FF8: 80130E0C
	s_addc_u32 s24, s13, s15                                   // 000000370FFC: 82180F0D
	s_add_u32 s19, s19, s22                                    // 000000371000: 80131613
	s_addc_u32 s22, s24, s23                                   // 000000371004: 82161718
	s_add_u32 s19, s19, 15                                     // 000000371008: 80138F13
	s_addc_u32 s22, s22, 0                                     // 00000037100C: 82168016
	v_add_nc_u32_e32 v6, s21, v5                               // 000000371010: 4A0C0A15
	s_ashr_i32 s23, s22, 31                                    // 000000371014: 86179F16
	v_add_nc_u32_e32 v68, v5, v66                              // 000000371018: 4A888505
	s_lshr_b32 s23, s23, 28                                    // 00000037101C: 85179C17
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000371020: BF870009
	s_add_u32 s19, s19, s23                                    // 000000371024: 80131713
	s_addc_u32 s21, s22, 0                                     // 000000371028: 82158016
	s_and_b32 s19, s19, -16                                    // 00000037102C: 8B13D013
	.long 0xd72c0007                                           // 000000371030: D72C0007
	v_cndmask_b32_e32 v1, s21, v3, vcc_lo                      // 000000371034: 02020615
	v_mad_u64_u32 v[57:58], null, s19, v3, s[0:1]              // 000000371038: D6FE7C39 00020613
	v_mov_b32_e32 v3, 0                                        // 000000371040: 7E060280
	.long 0xd72c0008                                           // 000000371044: D72C0008
	v_cndmask_b32_e32 v1, s19, v4, vcc_lo                      // 000000371048: 02020813
	v_min_i32_e32 v69, s20, v6                                 // 00000037104C: 228A0C14
	v_mov_b32_e32 v4, 0                                        // 000000371050: 7E080280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000371054: BF870212
	v_cmp_lt_i32_e32 vcc_lo, v68, v69                          // 000000371058: 7C828B44
	v_add3_u32 v70, v7, v58, v8                                // 00000037105C: D6550046 04227507
	s_and_saveexec_b32 s1, vcc_lo                              // 000000371064: BE81206A
	s_cbranch_execz 39                                         // 000000371068: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x308>
	v_lshlrev_b32_e32 v1, 4, v68                               // 00000037106C: 30028884
	v_lshlrev_b32_e32 v4, 1, v68                               // 000000371070: 30088881
	v_lshlrev_b32_e32 v3, 3, v68                               // 000000371074: 30068883
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000371078: BF870223
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000037107C: 3404029F
	.long 0xd7000001                                           // 000000371080: D7000001
	v_cndmask_b32_e32 v1, v57, v1, vcc_lo                      // 000000371084: 02020339
	v_and_b32_e32 v4, -4, v4                                   // 000000371088: 360808C4
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000037108C: BF870214
	v_ashrrev_i32_e32 v8, 31, v3                               // 000000371090: 3410069F
	v_add_co_ci_u32_e64 v2, null, v70, v2, s0                  // 000000371094: D5207C02 00020546
	.long 0xd7000006                                           // 00000037109C: D7000006
	v_cndmask_b32_e32 v0, v57, v14, vcc_lo                     // 0000003710A0: 02001D39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003710A4: BF8701A1
	v_add_co_ci_u32_e64 v7, null, s15, v70, s0                 // 0000003710A8: D5207C07 00028C0F
	v_ashrrev_i32_e32 v11, 31, v4                              // 0000003710B0: 3416089F
	.long 0xd7000009                                           // 0000003710B4: D7000009
	v_cndmask_b32_e32 v0, v6, v12, vcc_lo                      // 0000003710B8: 02001906
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003710BC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, s13, v7, s0                 // 0000003710C0: D5207C0A 00020E0D
	.long 0xd7000006                                           // 0000003710C8: D7000006
	v_cndmask_b32_e32 v1, v6, v3, vcc_lo                       // 0000003710CC: 02020706
	v_add_co_ci_u32_e64 v7, null, v7, v8, s0                   // 0000003710D0: D5207C07 00021107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003710D8: BF870094
	.long 0xd7000008                                           // 0000003710DC: D7000008
	v_cndmask_b32_e32 v1, v9, v4, vcc_lo                       // 0000003710E0: 02020909
	v_add_co_ci_u32_e64 v9, null, v10, v11, s0                 // 0000003710E4: D5207C09 0002170A
	s_clause 0x2                                               // 0000003710EC: BF850002
	global_load_b128 v[1:4], v[1:2], off                       // 0000003710F0: DC5E0000 017C0001
	global_load_b64 v[60:61], v[6:7], off                      // 0000003710F8: DC560000 3C7C0006
	global_load_b32 v80, v[8:9], off                           // 000000371100: DC520000 507C0008
	s_or_b32 exec_lo, exec_lo, s1                              // 000000371108: 8C7E017E
	v_dual_mov_b32 v71, 0 :: v_dual_mov_b32 v72, 0             // 00000037110C: CA100080 47480080
	s_and_saveexec_b32 s1, vcc_lo                              // 000000371114: BE81206A
	s_cbranch_execz 716                                        // 000000371118: BFA502CC <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe4c>
	.long 0xd7006a49                                           // 00000037111C: D7006A49
	v_cndmask_b32_e32 v0, v57, v14, vcc_lo                     // 000000371120: 02001D39
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000371124: BF870231
	v_add_co_ci_u32_e64 v74, null, s15, v70, vcc_lo            // 000000371128: D5207C4A 01AA8C0F
	v_dual_mov_b32 v71, 0 :: v_dual_lshlrev_b32 v6, 5, v66     // 000000371130: CA220080 47068485
	v_dual_mov_b32 v64, 0 :: v_dual_add_nc_u32 v7, 32, v68     // 000000371138: CA200080 400688A0
	.long 0xd7006a4b                                           // 000000371140: D7006A4B
	v_cndmask_b32_e32 v0, v73, v12, vcc_lo                     // 000000371144: 02001949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000371148: BF870211
	v_add_co_ci_u32_e64 v76, null, s13, v74, vcc_lo            // 00000037114C: D5207C4C 01AA940D
	v_lshl_add_u32 v58, v5, 5, v6                              // 000000371154: D646003A 04190B05
	s_delay_alu instid0(VALU_DEP_4)                            // 00000037115C: BF870004
	v_dual_mov_b32 v72, 0 :: v_dual_lshlrev_b32 v77, 4, v7     // 000000371160: CA220080 484C0E84
	s_waitcnt vmcnt(0)                                         // 000000371168: BF8903F7
	v_dual_mov_b32 v81, v80 :: v_dual_lshlrev_b32 v78, 3, v7   // 00000037116C: CA220150 514E0E83
	v_lshlrev_b32_e32 v79, 1, v7                               // 000000371174: 309E0E81
	s_lshl_b64 s[12:13], s[6:7], 2                             // 000000371178: 848C8206
	s_mov_b32 s14, 0                                           // 00000037117C: BE8E0080
	s_lshl_b64 s[6:7], s[6:7], 1                               // 000000371180: 84868106
	s_branch 649                                               // 000000371184: BFA00289 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xdac>
	s_or_b32 exec_lo, exec_lo, s15                             // 000000371188: 8C7E0F7E
	v_ashrrev_i32_e32 v59, 31, v58                             // 00000037118C: 3476749F
	v_lshlrev_b32_e32 v82, 4, v60                              // 000000371190: 30A47884
	v_lshlrev_b32_e32 v83, 2, v60                              // 000000371194: 30A67882
	v_lshrrev_b32_e32 v84, 4, v1                               // 000000371198: 32A80284
	v_lshrrev_b32_e32 v85, 8, v1                               // 00000037119C: 32AA0288
	.long 0xd73c0009                                           // 0000003711A0: D73C0009
	v_cndmask_b32_e32 v1, 1, v58, vcc_lo                       // 0000003711A4: 02027481
	v_and_b32_e32 v82, 48, v82                                 // 0000003711A8: 36A4A4B0
	v_lshrrev_b32_e32 v86, 2, v60                              // 0000003711AC: 32AC7882
	v_and_b32_e32 v87, 48, v60                                 // 0000003711B0: 36AE78B0
	v_and_b32_e32 v83, 48, v83                                 // 0000003711B4: 36A6A6B0
	v_lshrrev_b32_e32 v88, 12, v1                              // 0000003711B8: 32B0028C
	.long 0xd700002d                                           // 0000003711BC: D700002D
	v_cndmask_b32_e32 v1, s4, v9, vcc_lo                       // 0000003711C0: 02021204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000003711C4: BF8701A1
	v_add_co_ci_u32_e64 v46, null, s5, v10, s0                 // 0000003711C8: D5207C2E 00021405
	v_and_or_b32 v82, v1, 15, v82                              // 0000003711D0: D6570052 05491F01
	.long 0xd7000031                                           // 0000003711D8: D7000031
	v_cndmask_b32_e32 v0, v45, v6, vcc_lo                      // 0000003711DC: 02000D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000003711E0: BF8700A1
	v_add_co_ci_u32_e64 v50, null, s7, v46, s0                 // 0000003711E4: D5207C32 00025C07
	.long 0xd7000035                                           // 0000003711EC: D7000035
	v_cndmask_b32_e32 v0, v45, v12, vcc_lo                     // 0000003711F0: 0200192D
	v_add_co_ci_u32_e64 v54, null, s13, v46, s0                // 0000003711F4: D5207C36 00025C0D
	s_clause 0xb                                               // 0000003711FC: BF85000B
	global_load_b128 v[9:12], v[45:46], off                    // 000000371200: DC5E0000 097C002D
	global_load_b128 v[13:16], v[49:50], off                   // 000000371208: DC5E0000 0D7C0031
	global_load_b128 v[17:20], v[53:54], off                   // 000000371210: DC5E0000 117C0035
	global_load_b128 v[21:24], v[45:46], off offset:16         // 000000371218: DC5E0010 157C002D
	global_load_b128 v[25:28], v[49:50], off offset:16         // 000000371220: DC5E0010 197C0031
	global_load_b128 v[29:32], v[53:54], off offset:16         // 000000371228: DC5E0010 1D7C0035
	global_load_b128 v[33:36], v[45:46], off offset:32         // 000000371230: DC5E0020 217C002D
	global_load_b128 v[37:40], v[49:50], off offset:32         // 000000371238: DC5E0020 257C0031
	global_load_b128 v[41:44], v[53:54], off offset:32         // 000000371240: DC5E0020 297C0035
	global_load_b128 v[45:48], v[45:46], off offset:48         // 000000371248: DC5E0030 2D7C002D
	global_load_b128 v[49:52], v[49:50], off offset:48         // 000000371250: DC5E0030 317C0031
	global_load_b128 v[53:56], v[53:54], off offset:48         // 000000371258: DC5E0030 357C0035
	v_and_b32_e32 v86, 48, v86                                 // 000000371260: 36ACACB0
	v_and_or_b32 v83, v84, 15, v83                             // 000000371264: D6570053 054D1F54
	v_cvt_f32_ubyte0_e32 v82, v82                              // 00000037126C: 7EA42352
	v_and_or_b32 v84, v85, 15, v87                             // 000000371270: D6570054 055D1F55
	.long 0x7f763880                                           // 000000371278: 7F763880
	v_and_or_b32 v86, v88, 15, v86                             // 00000037127C: D6570056 05591F58
	v_cvt_f32_ubyte0_e32 v83, v83                              // 000000371284: 7EA62353
	v_fma_mix_f32 v82, v82, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371288: CC206052 1542A152
	v_cvt_f32_ubyte0_e32 v84, v84                              // 000000371290: 7EA82354
	v_lshrrev_b32_e32 v90, 4, v60                              // 000000371294: 32B47884
	v_cvt_f32_ubyte0_e32 v86, v86                              // 000000371298: 7EAC2356
	v_fma_mix_f32 v83, v83, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037129C: CC206053 1542A153
	v_bfe_u32 v88, v82, 16, 1                                  // 0000003712A4: D6100058 02052152
	v_fma_mix_f32 v84, v84, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003712AC: CC206054 1542A154
	v_lshrrev_b32_e32 v89, 8, v60                              // 0000003712B4: 32B27888
	v_fma_mix_f32 v86, v86, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003712B8: CC206056 1542A156
	v_bfe_u32 v106, v83, 16, 1                                 // 0000003712C0: D610006A 02052153
	v_add3_u32 v82, v82, v88, 0x7fff                           // 0000003712C8: D6550052 03FEB152 00007FFF
	v_bfe_u32 v88, v84, 16, 1                                  // 0000003712D4: D6100058 02052154
	v_lshrrev_b32_e32 v92, 6, v60                              // 0000003712DC: 32B87886
	v_bfe_u32 v108, v86, 16, 1                                 // 0000003712E0: D610006C 02052156
	v_add3_u32 v83, v83, v106, 0x7fff                          // 0000003712E8: D6550053 03FED553 00007FFF
	.long 0x7e7639d2                                           // 0000003712F4: 7E7639D2
	v_add3_u32 v82, v84, v88, 0x7fff                           // 0000003712F8: D6550052 03FEB154 00007FFF
	v_and_b32_e32 v90, 48, v90                                 // 000000371304: 36B4B4B0
	v_add3_u32 v86, v86, v108, 0x7fff                          // 000000371308: D6550056 03FED956 00007FFF
	v_lshrrev_b32_e32 v91, 20, v1                              // 000000371314: 32B60294
	v_and_or_b32 v83, 0xffff0000, v83, v59                     // 000000371318: D6570053 04EEA6FF FFFF0000
	.long 0x7e7639d2                                           // 000000371324: 7E7639D2
	v_lshrrev_b32_e32 v93, 24, v1                              // 000000371328: 32BA0298
	v_and_b32_e32 v92, 48, v92                                 // 00000037132C: 36B8B8B0
	v_and_b32_e32 v89, 48, v89                                 // 000000371330: 36B2B2B0
	v_lshrrev_b32_e32 v94, 28, v1                              // 000000371334: 32BC029C
	v_and_or_b32 v86, 0xffff0000, v86, v59                     // 000000371338: D6570056 04EEACFF FFFF0000
	.long 0x7e763981                                           // 000000371344: 7E763981
	v_lshrrev_b32_e32 v95, 10, v60                             // 000000371348: 32BE788A
	v_and_or_b32 v91, v91, 15, v92                             // 00000037134C: D657005B 05711F5B
	v_and_or_b32 v89, v93, 15, v89                             // 000000371354: D6570059 05651F5D
	v_lshrrev_b32_e32 v96, 8, v2                               // 00000037135C: 32C00488
	v_and_or_b32 v90, v59, 15, v90                             // 000000371360: D657005A 05691F3B
	v_and_or_b32 v93, v95, 48, v94                             // 000000371368: D657005D 0579615F
	v_cvt_f32_ubyte0_e32 v91, v91                              // 000000371370: 7EB6235B
	v_cvt_f32_ubyte0_e32 v89, v89                              // 000000371374: 7EB22359
	v_lshrrev_b32_e32 v99, 18, v60                             // 000000371378: 32C67892
	v_cvt_f32_ubyte0_e32 v90, v90                              // 00000037137C: 7EB4235A
	v_cvt_f32_ubyte0_e32 v93, v93                              // 000000371380: 7EBA235D
	v_fma_mix_f32 v91, v91, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371384: CC20605B 1542A15B
	v_fma_mix_f32 v89, v89, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037138C: CC206059 1542A159
	v_lshrrev_b32_e32 v98, 12, v2                              // 000000371394: 32C4048C
	v_fma_mix_f32 v90, v90, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371398: CC20605A 1542A15A
	v_fma_mix_f32 v93, v93, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003713A0: CC20605D 1542A15D
	v_bfe_u32 v114, v91, 16, 1                                 // 0000003713A8: D6100072 0205215B
	v_lshrrev_b32_e32 v84, 8, v3                               // 0000003713B0: 32A80688
	v_and_b32_e32 v88, 48, v61                                 // 0000003713B4: 36B07AB0
	v_bfe_u32 v95, v90, 16, 1                                  // 0000003713B8: D610005F 0205215A
	v_bfe_u32 v116, v93, 16, 1                                 // 0000003713C0: D6100074 0205215D
	v_add3_u32 v91, v91, v114, 0x7fff                          // 0000003713C8: D655005B 03FEE55B 00007FFF
	v_and_b32_e32 v99, 48, v99                                 // 0000003713D4: 36C6C6B0
	v_and_or_b32 v84, v84, 15, v88                             // 0000003713D8: D6570054 05611F54
	v_add3_u32 v90, v90, v95, 0x7fff                           // 0000003713E0: D655005A 03FEBF5A 00007FFF
	v_bfe_u32 v95, v89, 16, 1                                  // 0000003713EC: D610005F 02052159
	v_add3_u32 v93, v93, v116, 0x7fff                          // 0000003713F4: D655005D 03FEE95D 00007FFF
	v_and_or_b32 v88, v98, 15, v99                             // 000000371400: D6570058 058D1F62
	v_lshrrev_b32_e32 v104, 28, v2                             // 000000371408: 32D0049C
	.long 0x7e7639da                                           // 00000037140C: 7E7639DA
	v_add3_u32 v89, v89, v95, 0x7fff                           // 000000371410: D6550059 03FEBF59 00007FFF
	v_lshrrev_b32_e32 v85, 26, v60                             // 00000037141C: 32AA789A
	v_cvt_f32_ubyte0_e32 v88, v88                              // 000000371420: 7EB02358
	v_lshrrev_b32_e32 v106, 28, v3                             // 000000371424: 32D4069C
	v_and_or_b32 v91, 0xffff0000, v91, v59                     // 000000371428: D657005B 04EEB6FF FFFF0000
	.long 0x7e7639d9                                           // 000000371434: 7E7639D9
	v_lshrrev_b32_e32 v108, 10, v61                            // 000000371438: 32D87A8A
	v_and_or_b32 v85, v85, 48, v104                            // 00000037143C: D6570055 05A16155
	v_fma_mix_f32 v88, v88, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371444: CC206058 1542A158
	v_lshrrev_b32_e32 v97, 20, v60                             // 00000037144C: 32C27894
	v_and_or_b32 v93, 0xffff0000, v93, v59                     // 000000371450: D657005D 04EEBAFF FFFF0000
	.long 0x7e7639bc                                           // 00000037145C: 7E7639BC
	v_and_or_b32 v98, v108, 48, v106                           // 000000371460: D6570062 05A9616C
	v_bfe_u32 v108, v88, 16, 1                                 // 000000371468: D610006C 02052158
	v_lshrrev_b32_e32 v100, 24, v60                            // 000000371470: 32C87898
	v_lshrrev_b32_e32 v102, 22, v60                            // 000000371474: 32CC7896
	v_and_b32_e32 v121, 48, v59                                // 000000371478: 36F276B0
	v_lshlrev_b32_e32 v87, 4, v61                              // 00000037147C: 30AE7A84
	v_add3_u32 v88, v88, v108, 0x7fff                          // 000000371480: D6550058 03FED958 00007FFF
	v_lshrrev_b32_e32 v1, 2, v61                               // 00000037148C: 32027A82
	v_and_b32_e32 v97, 48, v97                                 // 000000371490: 36C2C2B0
	v_and_or_b32 v96, v96, 15, v121                            // 000000371494: D6570060 05E51F60
	v_lshrrev_b32_e32 v101, 20, v2                             // 00000037149C: 32CA0494
	v_lshrrev_b32_e32 v103, 24, v2                             // 0000003714A0: 32CE0498
	v_lshlrev_b32_e32 v107, 2, v61                             // 0000003714A4: 30D67A82
	v_lshrrev_b32_e32 v82, 12, v3                              // 0000003714A8: 32A4068C
	v_cvt_f32_ubyte0_e32 v96, v96                              // 0000003714AC: 7EC02360
	v_and_b32_e32 v99, 48, v102                                // 0000003714B0: 36C6CCB0
	v_and_b32_e32 v100, 48, v100                               // 0000003714B4: 36C8C8B0
	v_and_b32_e32 v1, 48, v1                                   // 0000003714B8: 360202B0
	v_and_b32_e32 v87, 48, v87                                 // 0000003714BC: 36AEAEB0
	v_fma_mix_f32 v96, v96, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003714C0: CC206060 1542A160
	v_lshrrev_b32_e32 v105, 4, v3                              // 0000003714C8: 32D20684
	v_and_b32_e32 v102, 48, v107                               // 0000003714CC: 36CCD6B0
	v_and_or_b32 v99, v101, 15, v99                            // 0000003714D0: D6570063 058D1F65
	v_and_or_b32 v100, v103, 15, v100                          // 0000003714D8: D6570064 05911F67
	v_bfe_u32 v104, v96, 16, 1                                 // 0000003714E0: D6100068 02052160
	v_and_or_b32 v1, v82, 15, v1                               // 0000003714E8: D6570001 04051F52
	v_and_or_b32 v82, v3, 15, v87                              // 0000003714F0: D6570052 055D1F03
	v_and_or_b32 v101, v105, 15, v102                          // 0000003714F8: D6570065 05991F69
	v_cvt_f32_ubyte0_e32 v85, v85                              // 000000371500: 7EAA2355
	v_add3_u32 v96, v96, v104, 0x7fff                          // 000000371504: D6550060 03FED160 00007FFF
	v_cvt_f32_ubyte0_e32 v84, v84                              // 000000371510: 7EA82354
	v_cvt_f32_ubyte0_e32 v82, v82                              // 000000371514: 7EA42352
	v_cvt_f32_ubyte0_e32 v1, v1                                // 000000371518: 7E022301
	v_fma_mix_f32 v85, v85, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037151C: CC206055 1542A155
	.long 0x7e7639e0                                           // 000000371524: 7E7639E0
	v_fma_mix_f32 v84, v84, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371528: CC206054 1542A154
	v_fma_mix_f32 v82, v82, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371530: CC206052 1542A152
	v_fma_mix_f32 v1, v1, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371538: CC206001 1542A101
	v_bfe_u32 v102, v85, 16, 1                                 // 000000371540: D6100066 02052155
	v_and_or_b32 v88, 0xffff0000, v88, v59                     // 000000371548: D6570058 04EEB0FF FFFF0000
	.long 0x7e763982                                           // 000000371554: 7E763982
	v_lshrrev_b32_e32 v112, 4, v61                             // 000000371558: 32E07A84
	v_lshrrev_b32_e32 v94, 12, v60                             // 00000037155C: 32BC788C
	v_add3_u32 v85, v85, v102, 0x7fff                          // 000000371560: D6550055 03FECD55 00007FFF
	v_lshrrev_b32_e32 v113, 14, v60                            // 00000037156C: 32E2788E
	v_and_or_b32 v97, v59, 15, v97                             // 000000371570: D6570061 05851F3B
	v_lshrrev_b32_e32 v110, 6, v61                             // 000000371578: 32DC7A86
	v_lshrrev_b32_e32 v111, 8, v61                             // 00000037157C: 32DE7A88
	v_lshrrev_b32_e32 v119, 4, v2                              // 000000371580: 32EE0484
	v_and_b32_e32 v104, 48, v112                               // 000000371584: 36D0E0B0
	v_cvt_f32_ubyte0_e32 v87, v97                              // 000000371588: 7EAE2361
	v_cvt_f32_ubyte0_e32 v97, v99                              // 00000037158C: 7EC22363
	v_cvt_f32_ubyte0_e32 v99, v100                             // 000000371590: 7EC62364
	v_cvt_f32_ubyte0_e32 v100, v101                            // 000000371594: 7EC82365
	v_and_b32_e32 v94, 48, v94                                 // 000000371598: 36BCBCB0
	v_fma_mix_f32 v87, v87, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037159C: CC206057 1542A157
	v_fma_mix_f32 v97, v97, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003715A4: CC206061 1542A161
	v_fma_mix_f32 v99, v99, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003715AC: CC206063 1542A163
	v_fma_mix_f32 v100, v100, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003715B4: CC206064 1542A164
	v_and_b32_e32 v96, 48, v113                                // 0000003715BC: 36C0E2B0
	v_bfe_u32 v101, v87, 16, 1                                 // 0000003715C0: D6100065 02052157
	v_bfe_u32 v103, v97, 16, 1                                 // 0000003715C8: D6100067 02052161
	v_lshrrev_b32_e32 v109, 20, v3                             // 0000003715D0: 32DA0694
	v_lshrrev_b32_e32 v92, 24, v3                              // 0000003715D4: 32B80698
	v_and_b32_e32 v106, 48, v110                               // 0000003715D8: 36D4DCB0
	v_add3_u32 v87, v87, v101, 0x7fff                          // 0000003715DC: D6550057 03FECB57 00007FFF
	v_bfe_u32 v101, v99, 16, 1                                 // 0000003715E8: D6100065 02052163
	v_add3_u32 v97, v97, v103, 0x7fff                          // 0000003715F0: D6550061 03FECF61 00007FFF
	v_and_b32_e32 v107, 48, v111                               // 0000003715FC: 36D6DEB0
	v_and_or_b32 v2, v2, 15, v94                               // 000000371600: D6570002 05791F02
	.long 0x7e7639d7                                           // 000000371608: 7E7639D7
	v_add3_u32 v87, v99, v101, 0x7fff                          // 00000037160C: D6550057 03FECB63 00007FFF
	v_bfe_u32 v99, v82, 16, 1                                  // 000000371618: D6100063 02052152
	v_bfe_u32 v101, v100, 16, 1                                // 000000371620: D6100065 02052164
	v_and_or_b32 v94, v119, 15, v96                            // 000000371628: D657005E 05811F77
	v_and_or_b32 v97, 0xffff0000, v97, v59                     // 000000371630: D6570061 04EEC2FF FFFF0000
	.long 0x7e7639d7                                           // 00000037163C: 7E7639D7
	v_add3_u32 v82, v82, v99, 0x7fff                           // 000000371640: D6550052 03FEC752 00007FFF
	v_bfe_u32 v87, v84, 16, 1                                  // 00000037164C: D6100057 02052154
	v_bfe_u32 v99, v1, 16, 1                                   // 000000371654: D6100063 02052101
	v_add3_u32 v100, v100, v101, 0x7fff                        // 00000037165C: D6550064 03FECB64 00007FFF
	v_and_or_b32 v85, 0xffff0000, v85, v59                     // 000000371668: D6570055 04EEAAFF FFFF0000
	.long 0x7e7639d2                                           // 000000371674: 7E7639D2
	v_add3_u32 v82, v84, v87, 0x7fff                           // 000000371678: D6550052 03FEAF54 00007FFF
	v_add3_u32 v1, v1, v99, 0x7fff                             // 000000371684: D6550001 03FEC701 00007FFF
	v_lshrrev_b32_e32 v115, 12, v61                            // 000000371690: 32E67A8C
	v_and_b32_e32 v90, 15, v4                                  // 000000371694: 36B4088F
	v_and_or_b32 v99, 0xffff0000, v100, v59                    // 000000371698: D6570063 04EEC8FF FFFF0000
	.long 0x7e7639d2                                           // 0000003716A4: 7E7639D2
	v_and_or_b32 v100, v109, 15, v106                          // 0000003716A8: D6570064 05A91F6D
	v_lshrrev_b32_e32 v89, 14, v61                             // 0000003716B0: 32B27A8E
	v_lshrrev_b32_e32 v114, 18, v61                            // 0000003716B4: 32E47A92
	v_lshrrev_b32_e32 v95, 26, v61                             // 0000003716B8: 32BE7A9A
	v_and_or_b32 v1, 0xffff0000, v1, v59                       // 0000003716BC: D6570001 04EE02FF FFFF0000
	.long 0x7e763983                                           // 0000003716C8: 7E763983
	v_and_or_b32 v3, v92, 15, v107                             // 0000003716CC: D6570003 05AD1F5C
	v_cvt_f32_ubyte0_e32 v100, v100                            // 0000003716D4: 7EC82364
	v_cvt_f32_ubyte0_e32 v92, v98                              // 0000003716D8: 7EB82362
	v_lshrrev_b32_e32 v118, 28, v4                             // 0000003716DC: 32EC089C
	v_and_or_b32 v96, v59, 15, v104                            // 0000003716E0: D6570060 05A11F3B
	v_cvt_f32_ubyte0_e32 v3, v3                                // 0000003716E8: 7E062303
	v_fma_mix_f32 v100, v100, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003716EC: CC206064 1542A164
	v_fma_mix_f32 v92, v92, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003716F4: CC20605C 1542A15C
	v_lshrrev_b32_e32 v120, 4, v4                              // 0000003716FC: 32F00884
	v_cvt_f32_ubyte0_e32 v96, v96                              // 000000371700: 7EC02360
	v_fma_mix_f32 v3, v3, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371704: CC206003 1542A103
	v_bfe_u32 v103, v100, 16, 1                                // 00000037170C: D6100067 02052164
	v_lshrrev_b32_e32 v122, 12, v4                             // 000000371714: 32F4088C
	v_and_or_b32 v90, v115, 48, v90                            // 000000371718: D657005A 05696173
	v_fma_mix_f32 v96, v96, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371720: CC206060 1542A160
	v_and_b32_e32 v89, 48, v89                                 // 000000371728: 36B2B2B0
	v_and_b32_e32 v108, 48, v114                               // 00000037172C: 36D8E4B0
	v_bfe_u32 v104, v92, 16, 1                                 // 000000371730: D6100068 0205215C
	v_add3_u32 v100, v100, v103, 0x7fff                        // 000000371738: D6550064 03FECF64 00007FFF
	v_bfe_u32 v102, v96, 16, 1                                 // 000000371744: D6100066 02052160
	v_and_or_b32 v95, v95, 48, v118                            // 00000037174C: D657005F 05D9615F
	v_and_or_b32 v89, v120, 15, v89                            // 000000371754: D6570059 05651F78
	v_and_or_b32 v98, v122, 15, v108                           // 00000037175C: D6570062 05B11F7A
	v_cvt_f32_ubyte0_e32 v90, v90                              // 000000371764: 7EB4235A
	v_add3_u32 v96, v96, v102, 0x7fff                          // 000000371768: D6550060 03FECD60 00007FFF
	v_bfe_u32 v102, v3, 16, 1                                  // 000000371774: D6100066 02052103
	v_add3_u32 v92, v92, v104, 0x7fff                          // 00000037177C: D655005C 03FED15C 00007FFF
	v_cvt_f32_ubyte0_e32 v95, v95                              // 000000371788: 7EBE235F
	v_fma_mix_f32 v90, v90, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037178C: CC20605A 1542A15A
	.long 0x7e7639e0                                           // 000000371794: 7E7639E0
	v_add3_u32 v3, v3, v102, 0x7fff                            // 000000371798: D6550003 03FECD03 00007FFF
	v_cvt_f32_ubyte0_e32 v89, v89                              // 0000003717A4: 7EB22359
	v_cvt_f32_ubyte0_e32 v98, v98                              // 0000003717A8: 7EC42362
	v_lshrrev_b32_e32 v116, 24, v61                            // 0000003717AC: 32E87A98
	v_and_or_b32 v100, 0xffff0000, v100, v59                   // 0000003717B0: D6570064 04EEC8FF FFFF0000
	.long 0x7e763983                                           // 0000003717BC: 7E763983
	v_lshrrev_b32_e32 v117, 22, v61                            // 0000003717C0: 32EA7A96
	v_lshrrev_b32_e32 v60, 20, v61                             // 0000003717C4: 32787A94
	v_lshrrev_b32_e32 v121, 8, v4                              // 0000003717C8: 32F20888
	v_cvt_f32_ubyte0_e32 v2, v2                                // 0000003717CC: 7E042302
	v_and_or_b32 v92, 0xffff0000, v92, v59                     // 0000003717D0: D657005C 04EEB8FF FFFF0000
	.long 0x7e7639bd                                           // 0000003717DC: 7E7639BD
	v_cvt_f32_ubyte0_e32 v94, v94                              // 0000003717E0: 7EBC235E
	v_fma_mix_f32 v3, v95, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003717E4: CC206003 1542A15F
	v_bfe_u32 v95, v90, 16, 1                                  // 0000003717EC: D610005F 0205215A
	v_fma_mix_f32 v61, v89, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003717F4: CC20603D 1542A159
	v_fma_mix_f32 v89, v98, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003717FC: CC206059 1542A162
	v_and_b32_e32 v98, 48, v59                                 // 000000371804: 36C476B0
	v_fma_mix_f32 v2, v2, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371808: CC206002 1542A102
	v_fma_mix_f32 v94, v94, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371810: CC20605E 1542A15E
	v_add3_u32 v90, v90, v95, 0x7fff                           // 000000371818: D655005A 03FEBF5A 00007FFF
	.long 0x7fae39bb                                           // 000000371824: 7FAE39BB
	v_and_or_b32 v95, v121, 15, v98                            // 000000371828: D657005F 05891F79
	v_bfe_u32 v102, v2, 16, 1                                  // 000000371830: D6100066 02052102
	v_bfe_u32 v103, v94, 16, 1                                 // 000000371838: D6100067 0205215E
	v_bfe_u32 v98, v89, 16, 1                                  // 000000371840: D6100062 02052159
	v_lshrrev_b32_e32 v123, 20, v4                             // 000000371848: 32F60894
	v_cvt_f32_ubyte0_e32 v95, v95                              // 00000037184C: 7EBE235F
	v_add3_u32 v2, v2, v102, 0x7fff                            // 000000371850: D6550002 03FECD02 00007FFF
	v_lshrrev_b32_e32 v124, 24, v4                             // 00000037185C: 32F80898
	v_and_b32_e32 v60, 48, v60                                 // 000000371860: 367878B0
	v_and_b32_e32 v110, 48, v117                               // 000000371864: 36DCEAB0
	v_and_b32_e32 v84, 48, v116                                // 000000371868: 36A8E8B0
	.long 0x7eae3982                                           // 00000037186C: 7EAE3982
	v_bfe_u32 v104, v61, 16, 1                                 // 000000371870: D6100068 0205213D
	.long 0x7fa439bb                                           // 000000371878: 7FA439BB
	v_and_or_b32 v101, v123, 15, v110                          // 00000037187C: D6570065 05B91F7B
	v_and_or_b32 v84, v124, 15, v84                            // 000000371884: D6570054 05511F7C
	.long 0x7ea439da                                           // 00000037188C: 7EA439DA
	v_add_nc_u32_e32 v77, 0x200, v77                           // 000000371890: 4A9A9AFF 00000200
	v_add_nc_u32_e32 v78, 0x100, v78                           // 000000371898: 4A9C9CFF 00000100
	v_cvt_f32_ubyte0_e32 v96, v101                             // 0000003718A0: 7EC02365
	v_cvt_f32_ubyte0_e32 v84, v84                              // 0000003718A4: 7EA82354
	v_bfe_u32 v101, v3, 16, 1                                  // 0000003718A8: D6100065 02052103
	v_add_nc_u32_e32 v79, 64, v79                              // 0000003718B0: 4A9E9EC0
	v_add_nc_u32_e32 v58, 0x400, v58                           // 0000003718B4: 4A7474FF 00000400
	v_fma_mix_f32 v96, v96, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003718BC: CC206060 1542A160
	v_fma_mix_f32 v84, v84, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003718C4: CC206054 1542A154
	v_add3_u32 v3, v3, v101, 0x7fff                            // 0000003718CC: D6550003 03FECB03 00007FFF
	s_and_b32 s0, exec_lo, vcc_lo                              // 0000003718D8: 8B006A7E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000003718DC: BF870003
	v_bfe_u32 v105, v96, 16, 1                                 // 0000003718E0: D6100069 02052160
	s_or_b32 s14, s0, s14                                      // 0000003718E8: 8C0E0E00
	s_waitcnt vmcnt(11)                                        // 0000003718EC: BF892FF7
	v_dot2_f32_bf16 v9, v9, v83, 0                             // 0000003718F0: CC1A4009 1A02A709
	s_waitcnt vmcnt(10)                                        // 0000003718F8: BF892BF7
	v_dot2_f32_bf16 v13, v13, v83, 0                           // 0000003718FC: CC1A400D 1A02A70D
	s_waitcnt vmcnt(9)                                         // 000000371904: BF8927F7
	v_dot2_f32_bf16 v17, v17, v83, 0                           // 000000371908: CC1A4011 1A02A711
	v_add3_u32 v83, v94, v103, 0x7fff                          // 000000371910: D6550053 03FECF5E 00007FFF
	v_fma_mix_f32 v94, v95, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000037191C: CC20605E 1542A15F
	v_dot2_f32_bf16 v9, v10, v86, v9                           // 000000371924: CC1A4009 1C26AD0A
	v_dot2_f32_bf16 v10, v14, v86, v13                         // 00000037192C: CC1A400A 1C36AD0E
	v_dot2_f32_bf16 v13, v18, v86, v17                         // 000000371934: CC1A400D 1C46AD12
	v_add3_u32 v14, v96, v105, 0x7fff                          // 00000037193C: D655000E 03FED360 00007FFF
	v_bfe_u32 v2, v94, 16, 1                                   // 000000371948: D6100002 0205215E
	v_dot2_f32_bf16 v9, v11, v91, v9                           // 000000371950: CC1A4009 1C26B70B
	v_dot2_f32_bf16 v10, v15, v91, v10                         // 000000371958: CC1A400A 1C2AB70F
	v_dot2_f32_bf16 v11, v19, v91, v13                         // 000000371960: CC1A400B 1C36B713
	v_and_or_b32 v13, 0xffff0000, v83, v87                     // 000000371968: D657000D 055EA6FF FFFF0000
	v_add3_u32 v2, v94, v2, 0x7fff                             // 000000371974: D6550002 03FE055E 00007FFF
	v_dot2_f32_bf16 v9, v12, v93, v9                           // 000000371980: CC1A4009 1C26BB0C
	v_dot2_f32_bf16 v10, v16, v93, v10                         // 000000371988: CC1A400A 1C2ABB10
	v_dot2_f32_bf16 v11, v20, v93, v11                         // 000000371990: CC1A400B 1C2EBB14
	v_add3_u32 v12, v89, v98, 0x7fff                           // 000000371998: D655000C 03FEC559 00007FFF
	.long 0x7e763982                                           // 0000003719A4: 7E763982
	s_waitcnt vmcnt(8)                                         // 0000003719A8: BF8923F7
	v_dot2_f32_bf16 v2, v21, v13, v9                           // 0000003719AC: CC1A4002 1C261B15
	s_waitcnt vmcnt(7)                                         // 0000003719B4: BF891FF7
	v_dot2_f32_bf16 v9, v25, v13, v10                          // 0000003719B8: CC1A4009 1C2A1B19
	s_waitcnt vmcnt(6)                                         // 0000003719C0: BF891BF7
	v_dot2_f32_bf16 v10, v29, v13, v11                         // 0000003719C4: CC1A400A 1C2E1B1D
	v_add3_u32 v13, v61, v104, 0x7fff                          // 0000003719CC: D655000D 03FED13D 00007FFF
	v_and_or_b32 v12, 0xffff0000, v12, v59                     // 0000003719D8: D657000C 04EE18FF FFFF0000
	v_dot2_f32_bf16 v2, v22, v88, v2                           // 0000003719E4: CC1A4002 1C0AB116
	v_dot2_f32_bf16 v9, v26, v88, v9                           // 0000003719EC: CC1A4009 1C26B11A
	v_dot2_f32_bf16 v10, v30, v88, v10                         // 0000003719F4: CC1A400A 1C2AB11E
	.long 0x7e763984                                           // 0000003719FC: 7E763984
	v_bfe_u32 v11, v84, 16, 1                                  // 000000371A00: D610000B 02052154
	v_dot2_f32_bf16 v2, v23, v97, v2                           // 000000371A08: CC1A4002 1C0AC317
	v_dot2_f32_bf16 v4, v27, v97, v9                           // 000000371A10: CC1A4004 1C26C31B
	v_dot2_f32_bf16 v9, v31, v97, v10                          // 000000371A18: CC1A4009 1C2AC31F
	v_and_or_b32 v10, v59, 15, v60                             // 000000371A20: D657000A 04F11F3B
	v_add3_u32 v11, v84, v11, 0x7fff                           // 000000371A28: D655000B 03FE1754 00007FFF
	v_dot2_f32_bf16 v2, v24, v85, v2                           // 000000371A34: CC1A4002 1C0AAB18
	v_dot2_f32_bf16 v4, v28, v85, v4                           // 000000371A3C: CC1A4004 1C12AB1C
	v_dot2_f32_bf16 v9, v32, v85, v9                           // 000000371A44: CC1A4009 1C26AB20
	v_cvt_f32_ubyte0_e32 v10, v10                              // 000000371A4C: 7E14230A
	v_mov_b32_e32 v60, v62                                     // 000000371A50: 7E78033E
	s_waitcnt vmcnt(5)                                         // 000000371A54: BF8917F7
	v_dot2_f32_bf16 v2, v33, v99, v2                           // 000000371A58: CC1A4002 1C0AC721
	s_waitcnt vmcnt(4)                                         // 000000371A60: BF8913F7
	v_dot2_f32_bf16 v4, v37, v99, v4                           // 000000371A64: CC1A4004 1C12C725
	s_waitcnt vmcnt(3)                                         // 000000371A6C: BF890FF7
	v_dot2_f32_bf16 v9, v41, v99, v9                           // 000000371A70: CC1A4009 1C26C729
	v_fma_mix_f32 v10, v10, v80, v80 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000371A78: CC20600A 1542A10A
	v_mov_b32_e32 v61, v63                                     // 000000371A80: 7E7A033F
	v_dot2_f32_bf16 v2, v34, v1, v2                            // 000000371A84: CC1A4002 1C0A0322
	v_dot2_f32_bf16 v4, v38, v1, v4                            // 000000371A8C: CC1A4004 1C120326
	v_dot2_f32_bf16 v1, v42, v1, v9                            // 000000371A94: CC1A4001 1C26032A
	v_bfe_u32 v9, v10, 16, 1                                   // 000000371A9C: D6100009 0205210A
	v_mov_b32_e32 v80, v81                                     // 000000371AA4: 7EA00351
	v_dot2_f32_bf16 v2, v35, v100, v2                          // 000000371AA8: CC1A4002 1C0AC923
	v_dot2_f32_bf16 v4, v39, v100, v4                          // 000000371AB0: CC1A4004 1C12C927
	v_dot2_f32_bf16 v1, v43, v100, v1                          // 000000371AB8: CC1A4001 1C06C92B
	v_add3_u32 v9, v10, v9, 0x7fff                             // 000000371AC0: D6550009 03FE130A 00007FFF
	v_and_or_b32 v10, 0xffff0000, v13, v82                     // 000000371ACC: D657000A 054A1AFF FFFF0000
	v_dot2_f32_bf16 v2, v36, v92, v2                           // 000000371AD8: CC1A4002 1C0AB924
	v_dot2_f32_bf16 v4, v40, v92, v4                           // 000000371AE0: CC1A4004 1C12B928
	v_dot2_f32_bf16 v1, v44, v92, v1                           // 000000371AE8: CC1A4001 1C06B92C
	.long 0x7e763989                                           // 000000371AF0: 7E763989
	s_waitcnt vmcnt(2)                                         // 000000371AF4: BF890BF7
	v_dot2_f32_bf16 v2, v45, v10, v2                           // 000000371AF8: CC1A4002 1C0A152D
	s_waitcnt vmcnt(1)                                         // 000000371B00: BF8907F7
	v_dot2_f32_bf16 v4, v49, v10, v4                           // 000000371B04: CC1A4004 1C121531
	s_waitcnt vmcnt(0)                                         // 000000371B0C: BF8903F7
	v_dot2_f32_bf16 v1, v53, v10, v1                           // 000000371B10: CC1A4001 1C061535
	v_and_or_b32 v9, 0xffff0000, v14, v59                      // 000000371B18: D6570009 04EE1CFF FFFF0000
	.long 0x7e76398b                                           // 000000371B24: 7E76398B
	v_dot2_f32_bf16 v10, v46, v12, v2                          // 000000371B28: CC1A400A 1C0A192E
	v_dot2_f32_bf16 v4, v50, v12, v4                           // 000000371B30: CC1A4004 1C121932
	v_dot2_f32_bf16 v1, v54, v12, v1                           // 000000371B38: CC1A4001 1C061936
	v_mov_b32_e32 v2, v6                                       // 000000371B40: 7E040306
	v_and_or_b32 v6, 0xffff0000, v3, v59                       // 000000371B44: D6570006 04EE06FF FFFF0000
	v_dot2_f32_bf16 v10, v47, v9, v10                          // 000000371B50: CC1A400A 1C2A132F
	v_dot2_f32_bf16 v4, v51, v9, v4                            // 000000371B58: CC1A4004 1C121333
	v_dot2_f32_bf16 v1, v55, v9, v1                            // 000000371B60: CC1A4001 1C061337
	v_mov_b32_e32 v3, v7                                       // 000000371B68: 7E060307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000371B6C: BF870214
	v_dot2_f32_bf16 v7, v48, v6, v10                           // 000000371B70: CC1A4007 1C2A0D30
	v_dot2_f32_bf16 v9, v52, v6, v4                            // 000000371B78: CC1A4009 1C120D34
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000371B80: BF8701A4
	v_dot2_f32_bf16 v1, v56, v6, v1                            // 000000371B84: CC1A4001 1C060D38
	v_mov_b32_e32 v4, v8                                       // 000000371B8C: 7E080308
	v_dual_add_f32 v72, v72, v7 :: v_dual_add_f32 v71, v71, v9 // 000000371B90: C9080F48 48461347
	s_delay_alu instid0(VALU_DEP_3)                            // 000000371B98: BF870003
	v_dual_add_f32 v64, v64, v1 :: v_dual_mov_b32 v1, v5       // 000000371B9C: C9100340 40000105
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000371BA4: 917E0E7E
	s_cbranch_execz 39                                         // 000000371BA8: BFA50027 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xe48>
	s_delay_alu instid0(VALU_DEP_1)                            // 000000371BAC: BF870001
	v_dual_mov_b32 v5, v1 :: v_dual_add_nc_u32 v68, 32, v68    // 000000371BB0: CA200101 054488A0
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 000000371BB8: CA100102 06060103
	v_dual_mov_b32 v8, v4 :: v_dual_mov_b32 v63, v61           // 000000371BC0: CA100104 083E013D
	v_mov_b32_e32 v62, v60                                     // 000000371BC8: 7E7C033C
	s_mov_b32 s15, exec_lo                                     // 000000371BCC: BE8F007E
	v_cmp_ge_i32_e32 vcc_lo, v68, v69                          // 000000371BD0: 7C8C8B44
	.long 0xd4c1007e                                           // 000000371BD4: D4C1007E
	v_cndmask_b32_e32 v1, v68, v69, vcc_lo                     // 000000371BD8: 02028B44
	s_cbranch_execz 64874                                      // 000000371BDC: BFA5FD6A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x388>
	v_and_b32_e32 v7, -4, v79                                  // 000000371BE0: 360E9EC4
	v_ashrrev_i32_e32 v6, 31, v77                              // 000000371BE4: 340C9A9F
	v_ashrrev_i32_e32 v8, 31, v78                              // 000000371BE8: 34109C9F
	.long 0xd7000005                                           // 000000371BEC: D7000005
	v_cndmask_b32_e32 v1, v57, v77, vcc_lo                     // 000000371BF0: 02029B39
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000371BF4: BF870214
	v_ashrrev_i32_e32 v12, 31, v7                              // 000000371BF8: 34180E9F
	v_add_co_ci_u32_e64 v6, null, v70, v6, s0                  // 000000371BFC: D5207C06 00020D46
	.long 0xd7000009                                           // 000000371C04: D7000009
	v_cndmask_b32_e32 v1, v73, v78, vcc_lo                     // 000000371C08: 02029D49
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000371C0C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, v74, v8, s0                 // 000000371C10: D5207C0A 0002114A
	.long 0xd700000b                                           // 000000371C18: D700000B
	v_cndmask_b32_e32 v1, v75, v7, vcc_lo                      // 000000371C1C: 02020F4B
	v_add_co_ci_u32_e64 v12, null, v76, v12, s0                // 000000371C20: D5207C0C 0002194C
	s_clause 0x2                                               // 000000371C28: BF850002
	global_load_b128 v[5:8], v[5:6], off                       // 000000371C2C: DC5E0000 057C0005
	global_load_b64 v[62:63], v[9:10], off                     // 000000371C34: DC560000 3E7C0009
	global_load_b32 v81, v[11:12], off                         // 000000371C3C: DC520000 517C000B
	s_branch 64848                                             // 000000371C44: BFA0FD50 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x388>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000371C48: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000371C4C: BF8700C9
	s_or_b32 exec_lo, exec_lo, s1                              // 000000371C50: 8C7E017E
	s_waitcnt vmcnt(2)                                         // 000000371C54: BF890BF7
	.long 0xd71f0001                                           // 000000371C58: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000371C5C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000371C60: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000371C64: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 000000371C68: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 000000371C6C: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000371C70: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000371C74: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000371C78: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 000000371C7C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 000000371C80: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000371C84: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000371C88: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000371C8C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000371C90: 30040482
	ds_bpermute_b32 v3, v2, v72                                // 000000371C94: DACC0000 03004802
	s_waitcnt lgkmcnt(0)                                       // 000000371C9C: BF89FC07
	v_add_f32_e32 v3, v72, v3                                  // 000000371CA0: 06060748
	ds_bpermute_b32 v4, v2, v71                                // 000000371CA4: DACC0000 04004702
	ds_bpermute_b32 v2, v2, v64                                // 000000371CAC: DACC0000 02004002
	ds_bpermute_b32 v6, v5, v3                                 // 000000371CB4: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000371CBC: 02101101
	s_waitcnt lgkmcnt(2)                                       // 000000371CC0: BF89FC27
	v_add_f32_e32 v4, v71, v4                                  // 000000371CC4: 06080947
	s_waitcnt lgkmcnt(0)                                       // 000000371CC8: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 000000371CCC: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 000000371CD0: DACC0000 07000405
	v_add_f32_e32 v2, v64, v2                                  // 000000371CD8: 06040540
	v_lshlrev_b32_e32 v8, 2, v8                                // 000000371CDC: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 000000371CE0: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 000000371CE8: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 000000371CEC: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 000000371CF0: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 000000371CF8: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 000000371CFC: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 000000371D00: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 000000371D04: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000371D0C: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 000000371D14: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000371D18: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000371D1C: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 000000371D20: 02101101
	s_waitcnt lgkmcnt(1)                                       // 000000371D24: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 000000371D28: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 000000371D30: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 000000371D34: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 000000371D38: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 000000371D40: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 000000371D48: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 000000371D50: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000371D54: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 000000371D58: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 000000371D5C: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000371D60: 30100282
	s_waitcnt lgkmcnt(1)                                       // 000000371D64: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 000000371D68: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 000000371D6C: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 000000371D70: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 000000371D78: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 000000371D80: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 000000371D88: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v66                                   // 000000371D90: 7D948480
	s_cbranch_execz 12                                         // 000000371D94: BFA5000C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0xfc8>
	v_lshl_add_u32 v7, v65, s18, v67                           // 000000371D98: D6460007 050C2541
	s_waitcnt lgkmcnt(0)                                       // 000000371DA0: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 000000371DA4: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 000000371DAC: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000371DB0: BF870003
	v_mul_u32_u24_e32 v4, 12, v7                               // 000000371DB4: 16080E8C
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 000000371DB8: D8380100 00030104
	ds_store_b32 v4, v2 offset:8                               // 000000371DC0: D8340008 00000204
	s_or_b32 exec_lo, exec_lo, s0                              // 000000371DC8: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000371DCC: BF870009
	s_and_b32 s0, s17, exec_lo                                 // 000000371DD0: 8B007E11
	s_cselect_b32 s0, 3, 12                                    // 000000371DD4: 98008C83
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000371DD8: BF890007
	v_cmp_gt_u32_e32 vcc_lo, s0, v0                            // 000000371DDC: 7C980000
	s_barrier                                                  // 000000371DE0: BFBD0000
	buffer_gl0_inv                                             // 000000371DE4: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 000000371DEC: BE80206A
	s_cbranch_execz 398                                        // 000000371DF0: BFA5018E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x162c>
	.long 0xd7054000                                           // 000000371DF4: D7054000
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 000000371DF8: 020200FF 000000AB
	.long 0x7f063880                                           // 000000371E00: 7F063880
	v_mov_b32_e32 v4, 0                                        // 000000371E04: 7E080280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000371E08: BF870093
	.long 0xd7391003                                           // 000000371E0C: D7391003
	v_cndmask_b32_e32 v1, 9, v0, vcc_lo                        // 000000371E10: 02020089
	.long 0xd7000001                                           // 000000371E14: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 000000371E18: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000371E1C: BF870091
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 000000371E20: D5207C02 00010003
	v_cmp_gt_i64_e32 vcc_lo, s[8:9], v[1:2]                    // 000000371E28: 7CA80208
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 000000371E2C: 8B7E6A7E
	s_cbranch_execz 382                                        // 000000371E30: BFA5017E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x162c>
	.long 0xd7054000                                           // 000000371E34: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 000000371E38: 02010703
	v_lshlrev_b32_e32 v3, s18, v3                              // 000000371E3C: 30060612
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000371E40: BF870112
	.long 0xd7041000                                           // 000000371E44: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 000000371E48: 02020100
	v_mul_u32_u24_e32 v3, 12, v3                               // 000000371E4C: 1606068C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000371E50: BF870092
	v_and_b32_e32 v5, 0xff, v0                                 // 000000371E54: 360A00FF 000000FF
	v_lshl_add_u32 v3, v5, 2, v3                               // 000000371E5C: D6460003 040D0505
	ds_load_b32 v5, v3                                         // 000000371E64: D8D80000 05000003
	v_add_nc_u32_e32 v3, 12, v3                                // 000000371E6C: 4A06068C
	s_add_i32 s16, s16, -1                                     // 000000371E70: 8110C110
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000371E74: BF870009
	s_cmp_eq_u32 s16, 0                                        // 000000371E78: BF068010
	s_waitcnt lgkmcnt(0)                                       // 000000371E7C: BF89FC07
	v_add_f32_e32 v4, v4, v5                                   // 000000371E80: 06080B04
	s_cbranch_scc0 65527                                       // 000000371E84: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1064>
	s_clause 0x1                                               // 000000371E88: BF850001
	s_load_b64 s[2:3], s[10:11], 0x38                          // 000000371E8C: F4040085 F8000038
	s_load_b64 s[0:1], s[10:11], 0x8                           // 000000371E94: F4040005 F8000008
	v_and_b32_e32 v3, 0xff, v0                                 // 000000371E9C: 360600FF 000000FF
	s_mov_b32 s6, -1                                           // 000000371EA4: BE8600C1
	s_mov_b32 s4, 0                                            // 000000371EA8: BE840080
	s_mov_b32 s5, 0                                            // 000000371EAC: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000371EB0: BF89FC07
	s_cmp_lt_i32 s3, 3                                         // 000000371EB4: BF048303
	s_cbranch_scc1 183                                         // 000000371EB8: BFA200B7 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1398>
	s_cmp_gt_i32 s3, 3                                         // 000000371EBC: BF028303
	s_cbranch_scc0 117                                         // 000000371EC0: BFA10075 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1298>
	s_cmp_gt_i32 s3, 4                                         // 000000371EC4: BF028403
	s_cbranch_scc0 62                                          // 000000371EC8: BFA1003E <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11c4>
	s_cmp_eq_u32 s3, 5                                         // 000000371ECC: BF068503
	s_mov_b32 s5, -1                                           // 000000371ED0: BE8500C1
	s_cbranch_scc0 58                                          // 000000371ED4: BFA1003A <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x11c0>
	s_load_b64 s[6:7], s[10:11], 0x10                          // 000000371ED8: F4040185 F8000010
	s_lshr_b64 s[10:11], s[8:9], 1                             // 000000371EE0: 858A8108
	v_dual_mov_b32 v9, 0 :: v_dual_and_b32 v0, 7, v2           // 000000371EE4: CA240080 09000487
	v_mad_u64_u32 v[5:6], null, s10, v3, 0                     // 000000371EEC: D6FE7C05 0202060A
	v_and_b32_e32 v8, 0x1ff, v1                                // 000000371EF4: 361002FF 000001FF
	s_lshr_b32 s5, s9, 1                                       // 000000371EFC: 85058109
	v_dual_mov_b32 v11, s0 :: v_dual_and_b32 v10, 0xfffffe00, v1// 000000371F00: CA240000 0B0A02FF FFFFFE00
	v_bfe_u32 v14, v4, 16, 1                                   // 000000371F0C: D610000E 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000371F14: BF8700C4
	v_mad_u64_u32 v[6:7], null, s5, v3, v[6:7]                 // 000000371F18: D6FE7C06 041A0605
	v_mov_b32_e32 v7, s1                                       // 000000371F20: 7E0E0201
	v_cmp_gt_u64_e32 vcc_lo, 0x100, v[8:9]                     // 000000371F24: 7CB810FF 00000100
	.long 0xd7000509                                           // 000000371F2C: D7000509
	v_cndmask_b32_e32 v1, 0xffffff00, v8, vcc_lo               // 000000371F30: 020210FF FFFFFF00
	v_add_co_ci_u32_e64 v12, null, 0, -1, s5                   // 000000371F38: D5207C0C 00158280
	s_mov_b32 s5, 0                                            // 000000371F40: BE850080
	.long 0xd73c0005                                           // 000000371F44: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000371F48: 02020A81
	s_waitcnt lgkmcnt(0)                                       // 000000371F4C: BF89FC07
	v_cndmask_b32_e32 v11, s6, v11, vcc_lo                     // 000000371F50: 02161606
	v_cndmask_b32_e32 v13, s7, v7, vcc_lo                      // 000000371F54: 021A0E07
	v_cndmask_b32_e32 v7, v9, v8, vcc_lo                       // 000000371F58: 020E1109
	v_cndmask_b32_e64 v8, v12, 0, vcc_lo                       // 000000371F5C: D5010008 01A9010C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000371F64: BF870094
	.long 0xd7006a09                                           // 000000371F68: D7006A09
	v_cndmask_b32_e32 v1, v11, v5, vcc_lo                      // 000000371F6C: 02020B0B
	v_add_co_ci_u32_e64 v11, null, v13, v6, vcc_lo             // 000000371F70: D5207C0B 01AA0D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000371F78: BF870193
	.long 0xd73c0005                                           // 000000371F7C: D73C0005
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 000000371F80: 02020E81
	.long 0xd7006a07                                           // 000000371F84: D7006A07
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000371F88: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000371F8C: BF8701A1
	v_add_co_ci_u32_e64 v0, null, v11, v0, vcc_lo              // 000000371F90: D5207C00 01AA010B
	v_add3_u32 v8, v4, v14, 0x7fff                             // 000000371F98: D6550008 03FE1D04 00007FFF
	.long 0xd7006a05                                           // 000000371FA4: D7006A05
	v_cndmask_b32_e32 v1, v7, v5, vcc_lo                       // 000000371FA8: 02020B07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000371FAC: BF870001
	v_add_co_ci_u32_e64 v6, null, v0, v6, vcc_lo               // 000000371FB0: D5207C06 01AA0D00
	global_store_d16_hi_b16 v[5:6], v8, off                    // 000000371FB8: DC960000 007C0805
	s_mov_b32 s6, 0                                            // 000000371FC0: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000371FC4: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 000000371FC8: 8B6A067E
	s_cbranch_vccz 49                                          // 000000371FCC: BFA30031 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1294>
	v_mul_f32_e32 v0, 0xbfb8aa3b, v4                           // 000000371FD0: 100008FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000371FD8: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000371FDC: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000371FE0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000371FE4: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 000000371FE8: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 000000371FF0: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 000000371FF8: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000371FFC: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 000000372000: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000372008: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 00000037200C: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000372014: BF870112
	v_mul_f32_e32 v11, v10, v9                                 // 000000372018: 1016130A
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 00000037201C: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372024: BF870092
	v_fma_f32 v12, -v8, v11, v10                               // 000000372028: D613000C 242A1708
	v_fmac_f32_e32 v11, v12, v9                                // 000000372030: 5616130C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000372034: BF870113
	.long 0xd73c0005                                           // 000000372038: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 00000037203C: 02020A82
	v_fma_f32 v10, -v8, v11, v10                               // 000000372040: D613000A 242A1708
	.long 0xd73c0007                                           // 000000372048: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000037204C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000372050: BF870212
	v_div_fmas_f32 v9, v10, v9, v11                            // 000000372054: D6370009 042E130A
	.long 0xd7006a05                                           // 00000037205C: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000372060: 02020A00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000372064: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 000000372068: D5207C06 01AA0C01
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000372070: D6270000 03CA0109
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372078: BF870093
	.long 0xd7006a05                                           // 00000037207C: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000372080: 02020F05
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000372084: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 00000037208C: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000372094: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000372098: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000037209C: 8B6A067E
	s_cbranch_vccz 60                                          // 0000003720A0: BFA3003C <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1394>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000003720A4: D6100000 02052104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003720AC: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000003720B0: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003720BC: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003720C4: BF870091
	v_mul_f32_e32 v0, s2, v0                                   // 0000003720C8: 10000002
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003720CC: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003720D4: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000003720D8: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003720DC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003720E0: BF870121
	v_div_scale_f32 v8, null, v0, v0, 1.0                      // 0000003720E4: D6FC7C08 03CA0100
	v_div_scale_f32 v10, vcc_lo, 1.0, v0, 1.0                  // 0000003720EC: D6FC6A0A 03CA00F2
	v_rcp_f32_e32 v9, v8                                       // 0000003720F4: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003720F8: BF870095
	v_fma_f32 v5, -v8, v9, 1.0                                 // 0000003720FC: D6130005 23CA1308
	v_fmac_f32_e32 v9, v5, v9                                  // 000000372104: 56121305
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000372108: D6FE7C05 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372110: BF870092
	v_mul_f32_e32 v11, v10, v9                                 // 000000372114: 1016130A
	v_fma_f32 v7, -v8, v11, v10                                // 000000372118: D6130007 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000372120: BF870211
	v_fmac_f32_e32 v11, v7, v9                                 // 000000372124: 56161307
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 000000372128: D6FE7C06 041A0609
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000372130: BF870112
	v_fma_f32 v7, -v8, v11, v10                                // 000000372134: D6130007 242A1708
	.long 0xd73c0005                                           // 00000037213C: D73C0005
	v_cndmask_b32_e32 v1, 2, v5, vcc_lo                        // 000000372140: 02020A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000372144: BF8701A2
	v_div_fmas_f32 v9, v7, v9, v11                             // 000000372148: D6370009 042E1307
	.long 0xd73c0007                                           // 000000372150: D73C0007
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000372154: 02020282
	.long 0xd7006a05                                           // 000000372158: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 00000037215C: 02020A00
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000372160: BF8701A3
	v_div_fixup_f32 v0, v9, v0, 1.0                            // 000000372164: D6270000 03CA0109
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 00000037216C: D5207C06 01AA0C01
	.long 0xd7006a05                                           // 000000372174: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 000000372178: 02020F05
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000037217C: BF870193
	v_add_f32_e32 v0, v0, v0                                   // 000000372180: 06000100
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 000000372184: D5207C06 01AA1106
	global_store_b32 v[5:6], v0, off                           // 00000037218C: DC6A0000 007C0005
	s_mov_b32 s6, 0                                            // 000000372194: BE860080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000372198: BF870009
	s_and_b32 vcc_lo, exec_lo, s6                              // 00000037219C: 8B6A067E
	s_cbranch_vccz 73                                          // 0000003721A0: BFA30049 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x14c8>
	s_cmp_gt_i32 s3, 1                                         // 0000003721A4: BF028103
	s_mov_b32 s4, -1                                           // 0000003721A8: BE8400C1
	s_cbranch_scc0 64                                          // 0000003721AC: BFA10040 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x14b0>
	v_bfe_u32 v0, v4, 16, 1                                    // 0000003721B0: D6100000 02052104
	s_mov_b32 s4, 0                                            // 0000003721B8: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003721BC: BF870091
	v_add3_u32 v0, v4, v0, 0x7fff                              // 0000003721C0: D6550000 03FE0104 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000003721CC: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003721D4: BF870091
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 0000003721D8: 100000FF BFB8AA3B
	v_exp_f32_e32 v0, v0                                       // 0000003721E0: 7E004B00
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003721E4: BF870095
	v_add_f32_e32 v0, 1.0, v0                                  // 0000003721E8: 060000F2
	v_div_scale_f32 v7, null, v0, v0, 1.0                      // 0000003721EC: D6FC7C07 03CA0100
	v_div_scale_f32 v9, vcc_lo, 1.0, v0, 1.0                   // 0000003721F4: D6FC6A09 03CA00F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000003721FC: BF870292
	v_rcp_f32_e32 v8, v7                                       // 000000372200: 7E105507
	v_fma_f32 v5, -v7, v8, 1.0                                 // 000000372204: D6130005 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000037220C: BF870121
	v_fmac_f32_e32 v8, v5, v8                                  // 000000372210: 56101105
	v_mad_u64_u32 v[5:6], null, s8, v3, 0                      // 000000372214: D6FE7C05 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 00000037221C: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372220: BF870091
	v_fma_f32 v11, -v7, v10, v9                                // 000000372224: D613000B 24261507
	v_fmac_f32_e32 v10, v11, v8                                // 00000037222C: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000372230: BF870121
	v_fma_f32 v9, -v7, v10, v9                                 // 000000372234: D6130009 24261507
	v_mad_u64_u32 v[6:7], null, s9, v3, v[6:7]                 // 00000037223C: D6FE7C06 041A0609
	v_div_fmas_f32 v7, v9, v8, v10                             // 000000372244: D6370007 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000037224C: BF870112
	.long 0xd73c0005                                           // 000000372250: D73C0005
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 000000372254: 02020A81
	v_div_fixup_f32 v0, v7, v0, 1.0                            // 000000372258: D6270000 03CA0107
	.long 0xd73c0007                                           // 000000372260: D73C0007
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000372264: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000372268: BF870193
	.long 0xd7006a05                                           // 00000037226C: D7006A05
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 000000372270: 02020A00
	v_bfe_u32 v9, v0, 16, 1                                    // 000000372274: D6100009 02052100
	v_add_co_ci_u32_e64 v6, null, s1, v6, vcc_lo               // 00000037227C: D5207C06 01AA0C01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000372284: BF870193
	.long 0xd7006a05                                           // 000000372288: D7006A05
	v_cndmask_b32_e32 v1, v5, v7, vcc_lo                       // 00000037228C: 02020F05
	v_add3_u32 v0, v0, v9, 0x7fff                              // 000000372290: D6550000 03FE1300 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000037229C: BF870003
	v_add_co_ci_u32_e64 v6, null, v6, v8, vcc_lo               // 0000003722A0: D5207C06 01AA1106
	global_store_d16_hi_b16 v[5:6], v0, off                    // 0000003722A8: DC960000 007C0005
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000003722B0: 916A047E
	s_mov_b32 s4, 0                                            // 0000003722B4: BE840080
	s_cbranch_vccnz 3                                          // 0000003722B8: BFA40003 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x14c8>
	s_cmp_lg_u32 s3, 1                                         // 0000003722BC: BF078103
	s_mov_b32 s4, -1                                           // 0000003722C0: BE8400C1
	s_cselect_b32 s5, -1, 0                                    // 0000003722C4: 980580C1
	v_bfe_u32 v5, v4, 16, 1                                    // 0000003722C8: D6100005 02052104
	.long 0xd73c0000                                           // 0000003722D0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000003722D4: 02020281
	s_and_b32 vcc_lo, exec_lo, s5                              // 0000003722D8: 8B6A057E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000003722DC: BF870002
	v_add3_u32 v2, v4, v5, 0x7fff                              // 0000003722E0: D6550002 03FE0B04 00007FFF
	s_cbranch_vccz 20                                          // 0000003722EC: BFA30014 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x1540>
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 0000003722F0: D6FE7C04 02020608
	s_mov_b32 s4, 0                                            // 0000003722F8: BE840080
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000003722FC: D6FE7C05 04160609
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372304: BF870091
	.long 0xd73c0004                                           // 000000372308: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 00000037230C: 02020881
	.long 0xd7006a04                                           // 000000372310: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 000000372314: 02020800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000372318: BF870111
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 00000037231C: D5207C05 01AA0A01
	.long 0xd7006a04                                           // 000000372324: D7006A04
	v_cndmask_b32_e32 v1, v4, v0, vcc_lo                       // 000000372328: 02020104
	s_delay_alu instid0(VALU_DEP_1)                            // 00000037232C: BF870001
	v_add_co_ci_u32_e64 v5, null, v5, v1, vcc_lo               // 000000372330: D5207C05 01AA0305
	global_store_d16_hi_b16 v[4:5], v2, off                    // 000000372338: DC960000 007C0204
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000372340: 916A047E
	s_cbranch_vccnz 57                                         // 000000372344: BFA40039 <_ZN7halogen12_GLOBAL__N_110k_lq6w_grpILi3ELi32ELi2EEEvNS0_5LqGrpEPKtl+0x162c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372348: BF870091
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000037234C: 360404FF FFFF0000
	v_mul_f32_e32 v2, s2, v2                                   // 000000372354: 10040402
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372358: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 00000037235C: 100804FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 000000372364: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372368: BF870095
	v_add_f32_e32 v7, 1.0, v4                                  // 00000037236C: 060E08F2
	v_div_scale_f32 v6, null, v7, v7, v2                       // 000000372370: D6FC7C06 040A0F07
	v_div_scale_f32 v9, vcc_lo, v2, v7, v2                     // 000000372378: D6FC6A09 040A0F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000372380: BF870292
	v_rcp_f32_e32 v8, v6                                       // 000000372384: 7E105506
	v_fma_f32 v4, -v6, v8, 1.0                                 // 000000372388: D6130004 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000372390: BF870121
	v_fmac_f32_e32 v8, v4, v8                                  // 000000372394: 56101104
	v_mad_u64_u32 v[4:5], null, s8, v3, 0                      // 000000372398: D6FE7C04 02020608
	v_mul_f32_e32 v10, v9, v8                                  // 0000003723A0: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000003723A4: BF870091
	v_fma_f32 v11, -v6, v10, v9                                // 0000003723A8: D613000B 24261506
	v_fmac_f32_e32 v10, v11, v8                                // 0000003723B0: 5614110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000003723B4: BF870121
	v_fma_f32 v9, -v6, v10, v9                                 // 0000003723B8: D6130009 24261506
	v_mad_u64_u32 v[5:6], null, s9, v3, v[5:6]                 // 0000003723C0: D6FE7C05 04160609
	v_div_fmas_f32 v3, v9, v8, v10                             // 0000003723C8: D6370003 042A1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003723D0: BF870191
	v_div_fixup_f32 v6, v3, v7, v2                             // 0000003723D4: D6270006 040A0F03
	.long 0xd73c0002                                           // 0000003723DC: D73C0002
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000003723E0: 02020881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000003723E4: BF870112
	v_bfe_u32 v4, v6, 16, 1                                    // 0000003723E8: D6100004 02052106
	.long 0xd7006a02                                           // 0000003723F0: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000003723F4: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003723F8: BF870191
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000003723FC: D5207C03 01AA0601
	v_add3_u32 v4, v6, v4, 0x7fff                              // 000000372404: D6550004 03FE0906 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000372410: BF870093
	.long 0xd7006a00                                           // 000000372414: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 000000372418: 02020102
	v_add_co_ci_u32_e64 v1, null, v3, v1, vcc_lo               // 00000037241C: D5207C01 01AA0303
	global_store_d16_hi_b16 v[0:1], v4, off                    // 000000372424: DC960000 007C0400
	s_nop 0                                                    // 00000037242C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000372430: BFB60003
	s_endpgm                                                   // 000000372434: BFB00000
		...

