000000000058fd00 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll>:
; _ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll():
	s_clause 0x1                                               // 00000058FD00: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 00000058FD04: F40C0100 F8000000
	s_load_b64 s[12:13], s[0:1], 0x20                          // 00000058FD0C: F4040300 F8000020
	s_mov_b32 s3, 0                                            // 00000058FD14: BE830080
	v_lshrrev_b32_e32 v14, 6, v0                               // 00000058FD18: 321C0086
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000058FD1C: 84828202
	v_bfe_u32 v15, v0, 5, 1                                    // 00000058FD20: D610000F 02050B00
	v_dual_mov_b32 v17, 0 :: v_dual_and_b32 v16, 31, v0        // 00000058FD28: CA240080 1110009F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000058FD30: BF870003
	v_or_b32_e32 v1, s2, v14                                   // 00000058FD34: 38021C02
	v_mov_b32_e32 v2, s3                                       // 00000058FD38: 7E040203
	.long 0x7e1a3880                                           // 00000058FD3C: 7E1A3880
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v6, 0               // 00000058FD40: CA100080 05060080
	v_mov_b32_e32 v8, 0                                        // 00000058FD48: 7E100280
	s_waitcnt lgkmcnt(0)                                       // 00000058FD4C: BF89FC07
	s_ashr_i32 s0, s11, 31                                     // 00000058FD50: 86009F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000058FD54: 7CA8020C
	s_lshr_b32 s0, s0, 28                                      // 00000058FD58: 85009C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000058FD5C: BF8704A9
	s_add_u32 s0, s10, s0                                      // 00000058FD60: 8000000A
	s_addc_u32 s1, s11, 0                                      // 00000058FD64: 8201800B
	s_ashr_i64 s[0:1], s[0:1], 4                               // 00000058FD68: 86808400
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000058FD6C: 02020280
	s_add_u32 s14, s10, s0                                     // 00000058FD70: 800E000A
	s_addc_u32 s1, s11, s1                                     // 00000058FD74: 8201010B
	s_add_u32 s14, s14, 15                                     // 00000058FD78: 800E8F0E
	s_addc_u32 s1, s1, 0                                       // 00000058FD7C: 82018001
	s_add_i32 s15, s0, 1                                       // 00000058FD80: 810F8100
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 00000058FD84: D5010002 01A80680
	s_lshr_b32 s16, s15, 31                                    // 00000058FD8C: 85109F0F
	s_and_b32 s14, s14, -16                                    // 00000058FD90: 8B0ED00E
	s_add_i32 s15, s15, s16                                    // 00000058FD94: 810F100F
	.long 0xd72c0004                                           // 00000058FD98: D72C0004
	v_cndmask_b32_e32 v0, v1, v1, vcc_lo                       // 00000058FD9C: 02000301
	s_ashr_i32 s15, s15, 1                                     // 00000058FDA0: 860F810F
	.long 0xd72c0002                                           // 00000058FDA4: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000058FDA8: 02001D02
	.long 0xd72c0003                                           // 00000058FDAC: D72C0003
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 00000058FDB0: 02021E0F
	v_mad_u64_u32 v[10:11], null, v1, s14, s[4:5]              // 00000058FDB4: D6FE7C0A 00101D01
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000058FDBC: BF8701A2
	v_dual_mov_b32 v7, 0 :: v_dual_add_nc_u32 v18, v3, v16     // 00000058FDC0: CA200080 07122103
	v_add_nc_u32_e32 v1, s15, v3                               // 00000058FDC8: 4A02060F
	v_add3_u32 v11, v2, v11, v4                                // 00000058FDCC: D655000B 04121702
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058FDD4: BF870214
	.long 0xd7006a14                                           // 00000058FDD8: D7006A14
	v_cndmask_b32_e32 v0, v10, v10, vcc_lo                     // 00000058FDDC: 0200150A
	v_lshlrev_b32_e32 v12, 4, v18                              // 00000058FDE0: 30182484
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000058FDE4: BF870214
	v_min_i32_e32 v19, s0, v1                                  // 00000058FDE8: 22260200
	v_add_co_ci_u32_e64 v21, null, s11, v11, vcc_lo            // 00000058FDEC: D5207C15 01AA160B
	s_delay_alu instid0(VALU_DEP_2)                            // 00000058FDF4: BF870002
	v_cmp_lt_i32_e32 vcc_lo, v18, v19                          // 00000058FDF8: 7C822712
	s_and_saveexec_b32 s1, vcc_lo                              // 00000058FDFC: BE81206A
	s_cbranch_execz 19                                         // 00000058FE00: BFA50013 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x150>
	v_lshlrev_b32_e32 v1, 4, v18                               // 00000058FE04: 30022484
	v_and_b32_e32 v3, -2, v18                                  // 00000058FE08: 360624C2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058FE0C: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000058FE10: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000058FE14: 3408069F
	.long 0xd7000001                                           // 00000058FE18: D7000001
	v_cndmask_b32_e32 v1, v10, v1, vcc_lo                      // 00000058FE1C: 0202030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058FE20: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 00000058FE24: D5207C02 0002050B
	.long 0xd7000003                                           // 00000058FE2C: D7000003
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 00000058FE30: 02020714
	v_add_co_ci_u32_e64 v4, null, v21, v4, s0                  // 00000058FE34: D5207C04 00020915
	s_clause 0x1                                               // 00000058FE3C: BF850001
	global_load_b128 v[5:8], v[1:2], off                       // 00000058FE40: DC5E0000 057C0001
	global_load_d16_b16 v13, v[3:4], off                       // 00000058FE48: DC820000 0D7C0003
	s_or_b32 exec_lo, exec_lo, s1                              // 00000058FE50: 8C7E017E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v24, 0             // 00000058FE54: CA100080 17180080
	v_dual_mov_b32 v25, 0 :: v_dual_mov_b32 v26, 0             // 00000058FE5C: CA100080 191A0080
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v22, 0             // 00000058FE64: CA100080 1B160080
	s_and_saveexec_b32 s1, vcc_lo                              // 00000058FE6C: BE81206A
	s_cbranch_execz 527                                        // 00000058FE70: BFA5020F <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x9b0>
	v_dual_mov_b32 v27, 0 :: v_dual_add_nc_u32 v28, 0x200, v12 // 00000058FE74: CA200080 1B1C18FF 00000200
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 00000058FE80: CA100080 16180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v23, 0             // 00000058FE88: CA100080 1A160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v17, 0             // 00000058FE90: CA100080 18100080
	s_mul_i32 s0, s11, 6                                       // 00000058FE98: 9600860B
	s_mul_hi_u32 s14, s10, 6                                   // 00000058FE9C: 968E860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000058FEA0: 8484820A
	s_add_i32 s14, s14, s0                                     // 00000058FEA4: 810E000E
	s_mul_i32 s16, s10, 6                                      // 00000058FEA8: 9610860A
	s_mov_b32 s15, 0                                           // 00000058FEAC: BE8F0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000058FEB0: 848A810A
	s_branch 476                                               // 00000058FEB4: BFA001DC <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x928>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000058FEB8: 8C7E117E
	v_bfe_i32 v29, v5, 0, 8                                    // 00000058FEBC: D611001D 02210105
	s_and_b32 s0, exec_lo, vcc_lo                              // 00000058FEC4: 8B006A7E
	v_add_nc_u32_e32 v28, 0x200, v28                           // 00000058FEC8: 4A3838FF 00000200
	s_or_b32 s15, s0, s15                                      // 00000058FED0: 8C0F0F00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FED4: BF870092
	v_cvt_f32_i32_e32 v29, v29                                 // 00000058FED8: 7E3A0B1D
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 00000058FEDC: CC20001D 8A023B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FEE4: BF870091
	v_bfe_u32 v30, v29, 16, 1                                  // 00000058FEE8: D610001E 0205211D
	v_add3_u32 v29, v29, v30, 0x7fff                           // 00000058FEF0: D655001D 03FE3D1D 00007FFF
	.long 0x7f3c3880                                           // 00000058FEFC: 7F3C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058FF00: BF8700A2
	.long 0x7e3c399d                                           // 00000058FF04: 7E3C399D
	v_bfe_i32 v29, v5, 8, 8                                    // 00000058FF08: D611001D 02211105
	v_cvt_f32_i32_e32 v29, v29                                 // 00000058FF10: 7E3A0B1D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FF14: BF870091
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 00000058FF18: CC20001D 8A023B0D
	v_bfe_u32 v31, v29, 16, 1                                  // 00000058FF20: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000058FF28: BF8701B1
	v_add3_u32 v29, v29, v31, 0x7fff                           // 00000058FF2C: D655001D 03FE3F1D 00007FFF
	v_bfe_i32 v31, v5, 16, 8                                   // 00000058FF38: D611001F 02212105
	v_ashrrev_i32_e32 v5, 24, v5                               // 00000058FF40: 340A0A98
	v_and_or_b32 v37, 0xffff0000, v29, v30                     // 00000058FF44: D6570025 047A3AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000058FF50: BF870193
	v_cvt_f32_i32_e32 v31, v31                                 // 00000058FF54: 7E3E0B1F
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058FF58: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058FF5C: BF870112
	v_fma_mix_f32 v31, v13, v31, neg(0) op_sel_hi:[1,0,0]      // 00000058FF60: CC20001F 8A023F0D
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058FF68: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FF70: BF870092
	v_bfe_u32 v32, v31, 16, 1                                  // 00000058FF74: D6100020 0205211F
	v_add3_u32 v31, v31, v32, 0x7fff                           // 00000058FF7C: D655001F 03FE411F 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000058FF88: BF870113
	v_bfe_u32 v32, v5, 16, 1                                   // 00000058FF8C: D6100020 02052105
	.long 0x7e3e399f                                           // 00000058FF94: 7E3E399F
	.long 0x7f3e399e                                           // 00000058FF98: 7F3E399E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FF9C: BF870093
	v_add3_u32 v5, v5, v32, 0x7fff                             // 00000058FFA0: D6550005 03FE4105 00007FFF
	v_and_or_b32 v38, 0xffff0000, v5, v31                      // 00000058FFAC: D6570026 047E0AFF FFFF0000
	v_bfe_i32 v5, v6, 0, 8                                     // 00000058FFB8: D6110005 02210106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FFC0: BF870091
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058FFC4: 7E0A0B05
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 00000058FFC8: CC200005 8A020B0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FFD0: BF870091
	v_bfe_u32 v29, v5, 16, 1                                   // 00000058FFD4: D610001D 02052105
	v_add3_u32 v5, v5, v29, 0x7fff                             // 00000058FFDC: D6550005 03FE3B05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000058FFE8: BF8700A1
	.long 0x7e3c3985                                           // 00000058FFEC: 7E3C3985
	v_bfe_i32 v5, v6, 8, 8                                     // 00000058FFF0: D6110005 02211106
	v_cvt_f32_i32_e32 v5, v5                                   // 00000058FFF8: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000058FFFC: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000590000: CC200005 8A020B0D
	v_bfe_u32 v29, v5, 16, 1                                   // 000000590008: D610001D 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000590010: BF8701B1
	v_add3_u32 v5, v5, v29, 0x7fff                             // 000000590014: D6550005 03FE3B05 00007FFF
	v_bfe_i32 v29, v6, 16, 8                                   // 000000590020: D611001D 02212106
	v_ashrrev_i32_e32 v6, 24, v6                               // 000000590028: 340C0C98
	v_and_or_b32 v39, 0xffff0000, v5, v30                      // 00000059002C: D6570027 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000590038: BF870193
	v_cvt_f32_i32_e32 v29, v29                                 // 00000059003C: 7E3A0B1D
	v_cvt_f32_i32_e32 v6, v6                                   // 000000590040: 7E0C0B06
	v_bfe_i32 v5, v7, 0, 8                                     // 000000590044: D6110005 02210107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059004C: BF870193
	v_fma_mix_f32 v29, v13, v29, neg(0) op_sel_hi:[1,0,0]      // 000000590050: CC20001D 8A023B0D
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000590058: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000590060: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000590064: 7E0A0B05
	v_bfe_u32 v31, v29, 16, 1                                  // 000000590068: D610001F 0205211D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000590070: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000590074: CC200005 8A020B0D
	v_add3_u32 v29, v29, v31, 0x7fff                           // 00000059007C: D655001D 03FE3F1D 00007FFF
	v_bfe_u32 v31, v6, 16, 1                                   // 000000590088: D610001F 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000590090: BF8701A2
	.long 0x7e3a399d                                           // 000000590094: 7E3A399D
	.long 0x7f3a399e                                           // 000000590098: 7F3A399E
	v_add3_u32 v6, v6, v31, 0x7fff                             // 00000059009C: D6550006 03FE3F06 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005900A8: BF8700A1
	v_and_or_b32 v40, 0xffff0000, v6, v29                      // 0000005900AC: D6570028 04760CFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 0000005900B8: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000005900C0: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005900CC: BF8700A1
	.long 0x7e3c3985                                           // 0000005900D0: 7E3C3985
	v_bfe_i32 v5, v7, 8, 8                                     // 0000005900D4: D6110005 02211107
	v_cvt_f32_i32_e32 v5, v5                                   // 0000005900DC: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005900E0: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005900E4: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 0000005900EC: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005900F4: BF8701B1
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000005900F8: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v7, 16, 8                                    // 000000590104: D6110006 02212107
	v_ashrrev_i32_e32 v7, 24, v7                               // 00000059010C: 340E0E98
	v_and_or_b32 v41, 0xffff0000, v5, v30                      // 000000590110: D6570029 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000059011C: BF870193
	v_cvt_f32_i32_e32 v6, v6                                   // 000000590120: 7E0C0B06
	v_cvt_f32_i32_e32 v7, v7                                   // 000000590124: 7E0E0B07
	v_bfe_i32 v5, v8, 0, 8                                     // 000000590128: D6110005 02210108
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000590130: BF870193
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000590134: CC200006 8A020D0D
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 00000059013C: CC200007 8A020F0D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000590144: BF870193
	v_cvt_f32_i32_e32 v5, v5                                   // 000000590148: 7E0A0B05
	v_bfe_u32 v29, v6, 16, 1                                   // 00000059014C: D610001D 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000590154: BF870112
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 000000590158: CC200005 8A020B0D
	v_add3_u32 v6, v6, v29, 0x7fff                             // 000000590160: D6550006 03FE3B06 00007FFF
	v_bfe_u32 v29, v7, 16, 1                                   // 00000059016C: D610001D 02052107
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000590174: BF8701A2
	.long 0x7e0c3986                                           // 000000590178: 7E0C3986
	.long 0x7f0c399e                                           // 00000059017C: 7F0C399E
	v_add3_u32 v7, v7, v29, 0x7fff                             // 000000590180: D6550007 03FE3B07 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000059018C: BF8700A1
	v_and_or_b32 v42, 0xffff0000, v7, v6                       // 000000590190: D657002A 041A0EFF FFFF0000
	v_bfe_u32 v6, v5, 16, 1                                    // 00000059019C: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000005901A4: D6550005 03FE0D05 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005901B0: BF8700A1
	.long 0x7e3c3985                                           // 0000005901B4: 7E3C3985
	v_bfe_i32 v5, v8, 8, 8                                     // 0000005901B8: D6110005 02211108
	v_cvt_f32_i32_e32 v5, v5                                   // 0000005901C0: 7E0A0B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005901C4: BF870091
	v_fma_mix_f32 v5, v13, v5, neg(0) op_sel_hi:[1,0,0]        // 0000005901C8: CC200005 8A020B0D
	v_bfe_u32 v6, v5, 16, 1                                    // 0000005901D0: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005901D8: BF870121
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000005901DC: D6550005 03FE0D05 00007FFF
	v_bfe_i32 v6, v8, 16, 8                                    // 0000005901E8: D6110006 02212108
	v_and_or_b32 v43, 0xffff0000, v5, v30                      // 0000005901F0: D657002B 047A0AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005901FC: BF870092
	v_cvt_f32_i32_e32 v6, v6                                   // 000000590200: 7E0C0B06
	v_fma_mix_f32 v6, v13, v6, neg(0) op_sel_hi:[1,0,0]        // 000000590204: CC200006 8A020D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059020C: BF870091
	v_bfe_u32 v7, v6, 16, 1                                    // 000000590210: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000590218: D6550006 03FE0F06 00007FFF
	v_ashrrev_i32_e32 v7, 24, v8                               // 000000590224: 340E1098
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000590228: BF870112
	.long 0x7e0c3986                                           // 00000059022C: 7E0C3986
	v_cvt_f32_i32_e32 v7, v7                                   // 000000590230: 7E0E0B07
	.long 0x7f0c399e                                           // 000000590234: 7F0C399E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000590238: BF870122
	v_fma_mix_f32 v7, v13, v7, neg(0) op_sel_hi:[1,0,0]        // 00000059023C: CC200007 8A020F0D
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000590244: 341A189F
	v_bfe_u32 v8, v7, 16, 1                                    // 000000590248: D6100008 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590250: BF870091
	v_add3_u32 v7, v7, v8, 0x7fff                              // 000000590254: D6550007 03FE1107 00007FFF
	v_and_or_b32 v44, 0xffff0000, v7, v6                       // 000000590260: D657002C 041A0EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000059026C: BF8701C4
	.long 0xd73c0005                                           // 000000590270: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000590274: 02021881
	s_waitcnt vmcnt(0)                                         // 000000590278: BF8903F7
	.long 0x7e1a3909                                           // 00000059027C: 7E1A3909
	v_add_nc_u32_e32 v12, 0x200, v12                           // 000000590280: 4A1818FF 00000200
	.long 0xd7006a21                                           // 000000590288: D7006A21
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 00000059028C: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000590290: BF870001
	v_add_co_ci_u32_e64 v34, null, s7, v6, vcc_lo              // 000000590294: D5207C22 01AA0C07
	s_clause 0x1                                               // 00000059029C: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 0000005902A0: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 0000005902A8: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 0000005902B0: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000005902B4: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005902BC: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000005902C0: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000005902C8: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005902D0: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000005902D4: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000005902DC: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005902E0: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 0000005902E8: D7006A1D
	v_cndmask_b32_e32 v0, v33, v10, vcc_lo                     // 0000005902EC: 02001521
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000005902F0: BF8701B2
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000005902F4: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s11, v34, vcc_lo            // 0000005902FC: D5207C1E 01AA440B
	.long 0xd7006a23                                           // 000000590304: D7006A23
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 000000590308: 02000921
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 00000059030C: CC1A4005 1C16571F
	v_add_co_ci_u32_e64 v36, null, s5, v34, vcc_lo             // 000000590314: D5207C24 01AA4405
	.long 0xd7006a21                                           // 00000059031C: D7006A21
	v_cndmask_b32_e32 v0, v33, v16, vcc_lo                     // 000000590320: 02002121
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000590324: BF870123
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590328: CC1A4005 1C165920
	v_add_co_ci_u32_e64 v34, null, s14, v34, vcc_lo            // 000000590330: D5207C22 01AA440E
	v_add_f32_e32 v22, v22, v5                                 // 000000590338: 062C0B16
	s_clause 0x1                                               // 00000059033C: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 000000590340: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 000000590348: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 000000590350: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000590354: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059035C: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000590360: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 000000590368: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000590370: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000590374: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 00000059037C: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000590380: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590388: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000059038C: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590394: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059039C: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 0000005903A0: CC1A4005 1C165920
	v_add_f32_e32 v27, v27, v5                                 // 0000005903A8: 06360B1B
	s_clause 0x1                                               // 0000005903AC: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 0000005903B0: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 0000005903B8: DC5E0010 1D7C0023
	.long 0xd7006a23                                           // 0000005903C0: D7006A23
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 0000005903C4: 02000923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005903C8: BF8700B1
	v_add_co_ci_u32_e64 v36, null, s5, v36, vcc_lo             // 0000005903CC: D5207C24 01AA4805
	s_waitcnt vmcnt(1)                                         // 0000005903D4: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000005903D8: CC1A4005 1A024B05
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000005903E0: CC1A4005 1C164D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005903E8: BF870091
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000005903EC: CC1A4005 1C164F07
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000005903F4: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000005903FC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590400: BF870091
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000590404: CC1A4005 1C16531D
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 00000059040C: CC1A4005 1C16551E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590414: BF870091
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590418: CC1A4005 1C16571F
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590420: CC1A4005 1C165920
	s_delay_alu instid0(VALU_DEP_1)                            // 000000590428: BF870001
	v_add_f32_e32 v26, v26, v5                                 // 00000059042C: 06340B1A
	s_clause 0x1                                               // 000000590430: BF850001
	global_load_b128 v[5:8], v[33:34], off                     // 000000590434: DC5E0000 057C0021
	global_load_b128 v[29:32], v[33:34], off offset:16         // 00000059043C: DC5E0010 1D7C0021
	s_waitcnt vmcnt(1)                                         // 000000590444: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000590448: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590450: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000590454: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 00000059045C: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000590464: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000590468: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000590470: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000590474: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059047C: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000590480: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590488: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590490: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590494: CC1A4005 1C165920
	v_add_f32_e32 v25, v25, v5                                 // 00000059049C: 06320B19
	s_clause 0x1                                               // 0000005904A0: BF850001
	global_load_b128 v[5:8], v[35:36], off                     // 0000005904A4: DC5E0000 057C0023
	global_load_b128 v[29:32], v[35:36], off offset:16         // 0000005904AC: DC5E0010 1D7C0023
	s_waitcnt vmcnt(1)                                         // 0000005904B4: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000005904B8: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005904C0: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000005904C4: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000005904CC: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005904D4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000005904D8: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 0000005904E0: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005904E4: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 0000005904EC: D7006A1D
	v_cndmask_b32_e32 v0, v33, v4, vcc_lo                      // 0000005904F0: 02000921
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005904F4: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000005904F8: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v34, vcc_lo             // 000000590500: D5207C1E 01AA4405
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590508: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590510: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590514: CC1A4005 1C165920
	v_add_f32_e32 v24, v24, v5                                 // 00000059051C: 06300B18
	s_clause 0x1                                               // 000000590520: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 000000590524: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 00000059052C: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 000000590534: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 000000590538: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590540: BF870091
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 000000590544: CC1A4005 1C164D06
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 00000059054C: CC1A4005 1C164F07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000590554: BF8700A1
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 000000590558: CC1A4005 1C165108
	s_waitcnt vmcnt(0)                                         // 000000590560: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 000000590564: CC1A4005 1C16531D
	.long 0xd7006a1d                                           // 00000059056C: D7006A1D
	v_cndmask_b32_e32 v0, v35, v4, vcc_lo                      // 000000590570: 02000923
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000590574: BF870122
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 000000590578: CC1A4005 1C16551E
	v_add_co_ci_u32_e64 v30, null, s5, v36, vcc_lo             // 000000590580: D5207C1E 01AA4805
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590588: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590590: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590594: CC1A4005 1C165920
	v_add_f32_e32 v23, v23, v5                                 // 00000059059C: 062E0B17
	s_clause 0x1                                               // 0000005905A0: BF850001
	global_load_b128 v[5:8], v[29:30], off                     // 0000005905A4: DC5E0000 057C001D
	global_load_b128 v[29:32], v[29:30], off offset:16         // 0000005905AC: DC5E0010 1D7C001D
	s_waitcnt vmcnt(1)                                         // 0000005905B4: BF8907F7
	v_dot2_f32_bf16 v5, v5, v37, 0                             // 0000005905B8: CC1A4005 1A024B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005905C0: BF870121
	v_dot2_f32_bf16 v5, v6, v38, v5                            // 0000005905C4: CC1A4005 1C164D06
	v_mov_b32_e32 v6, v2                                       // 0000005905CC: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v39, v5                            // 0000005905D0: CC1A4005 1C164F07
	v_mov_b32_e32 v7, v3                                       // 0000005905D8: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000005905DC: BF870132
	v_dot2_f32_bf16 v5, v8, v40, v5                            // 0000005905E0: CC1A4005 1C165108
	v_mov_b32_e32 v8, v4                                       // 0000005905E8: 7E100304
	s_waitcnt vmcnt(0)                                         // 0000005905EC: BF8903F7
	v_dot2_f32_bf16 v5, v29, v41, v5                           // 0000005905F0: CC1A4005 1C16531D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005905F8: BF870091
	v_dot2_f32_bf16 v5, v30, v42, v5                           // 0000005905FC: CC1A4005 1C16551E
	v_dot2_f32_bf16 v5, v31, v43, v5                           // 000000590604: CC1A4005 1C16571F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059060C: BF870091
	v_dot2_f32_bf16 v5, v32, v44, v5                           // 000000590610: CC1A4005 1C165920
	v_add_f32_e32 v17, v17, v5                                 // 000000590618: 06220B11
	v_mov_b32_e32 v5, v1                                       // 00000059061C: 7E0A0301
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 000000590620: 917E0F7E
	s_cbranch_execz 33                                         // 000000590624: BFA50021 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x9ac>
	s_waitcnt vmcnt(1)                                         // 000000590628: BF8907F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000059062C: BF870001
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v18, 32, v18    // 000000590630: CA200105 011224A0
	s_waitcnt vmcnt(0)                                         // 000000590638: BF8903F7
	.long 0x7e12390d                                           // 00000059063C: 7E12390D
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 000000590640: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 000000590648: 7E080308
	s_mov_b32 s17, exec_lo                                     // 00000059064C: BE91007E
	v_cmp_ge_i32_e32 vcc_lo, v18, v19                          // 000000590650: 7C8C2712
	.long 0xd4c1007e                                           // 000000590654: D4C1007E
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000590658: 02022712
	s_cbranch_execz 65046                                      // 00000059065C: BFA5FE16 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x1b8>
	v_and_b32_e32 v3, -2, v18                                  // 000000590660: 360624C2
	v_ashrrev_i32_e32 v2, 31, v28                              // 000000590664: 3404389F
	.long 0xd7000001                                           // 000000590668: D7000001
	v_cndmask_b32_e32 v1, v10, v28, vcc_lo                     // 00000059066C: 0202390A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000590670: BF870193
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000590674: 3408069F
	v_add_co_ci_u32_e64 v2, null, v11, v2, s0                  // 000000590678: D5207C02 0002050B
	.long 0xd700001d                                           // 000000590680: D700001D
	v_cndmask_b32_e32 v1, v20, v3, vcc_lo                      // 000000590684: 02020714
	s_delay_alu instid0(VALU_DEP_1)                            // 000000590688: BF870001
	v_add_co_ci_u32_e64 v30, null, v21, v4, s0                 // 00000059068C: D5207C1E 00020915
	s_clause 0x1                                               // 000000590694: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 000000590698: DC5E0000 017C0001
	global_load_d16_b16 v9, v[29:30], off                      // 0000005906A0: DC820000 097C001D
	s_branch 65027                                             // 0000005906A8: BFA0FE03 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0x1b8>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000005906AC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000005906B0: BF8700B9
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005906B4: 8C7E017E
	.long 0xd71f0001                                           // 0000005906B8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000005906BC: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000005906C0: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000005906C4: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000005906C8: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 0000005906CC: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000005906D0: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000005906D4: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000005906D8: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000005906DC: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000005906E0: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 0000005906E4: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005906E8: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000005906EC: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000005906F0: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000005906F4: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000005906FC: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 000000590700: 06060716
	s_waitcnt vmcnt(1)                                         // 000000590704: BF8907F7
	ds_bpermute_b32 v5, v2, v26                                // 000000590708: DACC0000 05001A02
	ds_bpermute_b32 v6, v2, v25                                // 000000590710: DACC0000 06001902
	ds_bpermute_b32 v4, v2, v27                                // 000000590718: DACC0000 04001B02
	ds_bpermute_b32 v7, v2, v24                                // 000000590720: DACC0000 07001802
	ds_bpermute_b32 v8, v2, v23                                // 000000590728: DACC0000 08001702
	ds_bpermute_b32 v2, v2, v17                                // 000000590730: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 000000590738: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 000000590740: BF89FC57
	v_dual_add_f32 v5, v26, v5 :: v_dual_add_f32 v6, v25, v6   // 000000590744: C9080B1A 05060D19
	s_waitcnt lgkmcnt(3)                                       // 00000059074C: BF89FC37
	v_dual_add_f32 v4, v27, v4 :: v_dual_add_f32 v7, v24, v7   // 000000590750: C908091B 04060F18
	s_waitcnt lgkmcnt(2)                                       // 000000590758: BF89FC27
	v_add_f32_e32 v8, v23, v8                                  // 00000059075C: 06101117
	ds_bpermute_b32 v12, v9, v5                                // 000000590760: DACC0000 0C000509
	s_waitcnt vmcnt(0)                                         // 000000590768: BF8903F7
	ds_bpermute_b32 v13, v9, v6                                // 00000059076C: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 000000590774: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 00000059077C: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 000000590780: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 000000590788: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 00000059078C: 06061503
	s_waitcnt lgkmcnt(2)                                       // 000000590790: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 000000590794: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 00000059079C: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 0000005907A4: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 0000005907AC: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 0000005907B0: 06081704
	s_waitcnt lgkmcnt(1)                                       // 0000005907B4: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 0000005907B8: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 0000005907BC: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 0000005907C4: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 0000005907CC: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 0000005907D4: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 0000005907DC: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 0000005907E0: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 0000005907E4: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 0000005907EC: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 0000005907F0: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 0000005907F4: DACC0000 09000313
	s_waitcnt lgkmcnt(2)                                       // 0000005907FC: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v4, v4, v10   // 000000590800: C9081705 05041504
	ds_bpermute_b32 v13, v19, v7                               // 000000590808: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 000000590810: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 000000590818: 3A260282
	v_add_f32_e32 v6, v6, v12                                  // 00000059081C: 060C1906
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000590820: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000590824: 7C9826A0
	s_waitcnt lgkmcnt(3)                                       // 000000590828: BF89FC37
	v_dual_cndmask_b32 v19, v1, v19 :: v_dual_add_f32 v8, v8, v17// 00000059082C: CA482701 13082308
	v_lshlrev_b32_e32 v19, 2, v19                              // 000000590834: 30262682
	s_waitcnt lgkmcnt(0)                                       // 000000590838: BF89FC07
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v10, v2, v18   // 00000059083C: C9081303 030A2502
	ds_bpermute_b32 v11, v19, v5                               // 000000590844: DACC0000 0B000513
	v_add_f32_e32 v7, v7, v13                                  // 00000059084C: 060E1B07
	ds_bpermute_b32 v2, v19, v3                                // 000000590850: DACC0000 02000313
	ds_bpermute_b32 v9, v19, v4                                // 000000590858: DACC0000 09000413
	ds_bpermute_b32 v12, v19, v6                               // 000000590860: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 000000590868: DACC0000 11000813
	ds_bpermute_b32 v13, v19, v7                               // 000000590870: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v10                              // 000000590878: DACC0000 12000A13
	v_xor_b32_e32 v19, 1, v1                                   // 000000590880: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000590884: BF8700C1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 000000590888: 7C9826A0
	s_waitcnt lgkmcnt(4)                                       // 00000059088C: BF89FC47
	v_dual_cndmask_b32 v1, v1, v19 :: v_dual_add_f32 v4, v4, v9// 000000590890: CA482701 01041304
	s_waitcnt lgkmcnt(3)                                       // 000000590898: BF89FC37
	v_dual_add_f32 v6, v6, v12 :: v_dual_lshlrev_b32 v19, 2, v1// 00000059089C: C9221906 06120282
	v_dual_add_f32 v1, v3, v2 :: v_dual_add_f32 v2, v5, v11    // 0000005908A4: C9080503 01021705
	s_waitcnt lgkmcnt(1)                                       // 0000005908AC: BF89FC17
	v_add_f32_e32 v3, v7, v13                                  // 0000005908B0: 06061B07
	v_add_f32_e32 v9, v8, v17                                  // 0000005908B4: 06122308
	s_waitcnt lgkmcnt(0)                                       // 0000005908B8: BF89FC07
	v_add_f32_e32 v5, v10, v18                                 // 0000005908BC: 060A250A
	ds_bpermute_b32 v7, v19, v1                                // 0000005908C0: DACC0000 07000113
	ds_bpermute_b32 v11, v19, v4                               // 0000005908C8: DACC0000 0B000413
	ds_bpermute_b32 v8, v19, v2                                // 0000005908D0: DACC0000 08000213
	ds_bpermute_b32 v13, v19, v6                               // 0000005908D8: DACC0000 0D000613
	ds_bpermute_b32 v10, v19, v3                               // 0000005908E0: DACC0000 0A000313
	ds_bpermute_b32 v17, v19, v9                               // 0000005908E8: DACC0000 11000913
	ds_bpermute_b32 v12, v19, v5                               // 0000005908F0: DACC0000 0C000513
	v_cmpx_eq_u32_e32 0, v16                                   // 0000005908F8: 7D942080
	s_cbranch_execz 21                                         // 0000005908FC: BFA50015 <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0xc54>
	.long 0xd72c000e                                           // 000000590900: D72C000E
	v_cndmask_b32_e32 v0, v14, v184, vcc_lo                    // 000000590904: 0201710E
	s_waitcnt lgkmcnt(1)                                       // 000000590908: BF89FC17
	v_dual_add_f32 v9, v9, v17 :: v_dual_add_f32 v4, v4, v11   // 00000059090C: C9082309 09041704
	v_dual_add_f32 v6, v6, v13 :: v_dual_add_f32 v1, v1, v7    // 000000590914: C9081B06 06000F01
	v_dual_add_f32 v2, v2, v8 :: v_dual_add_f32 v3, v3, v10    // 00000059091C: C9081102 02021503
	s_waitcnt lgkmcnt(0)                                       // 000000590924: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000590928: 060A1905
	v_mad_u32_u24 v7, v15, 28, v14                             // 00000059092C: D60B0007 0439390F
	ds_store_2addr_b32 v7, v1, v4 offset1:1                    // 000000590934: D8380100 00040107
	ds_store_2addr_b32 v7, v2, v6 offset0:2 offset1:3          // 00000059093C: D8380302 00060207
	ds_store_2addr_b32 v7, v3, v9 offset0:4 offset1:5          // 000000590944: D8380504 00090307
	ds_store_b32 v7, v5 offset:24                              // 00000059094C: D8340018 00000507
	s_or_b32 exec_lo, exec_lo, s0                              // 000000590954: 8C7E007E
	.long 0xd7050001                                           // 000000590958: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 00000059095C: 02014B00
	.long 0x7f063880                                           // 000000590960: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 000000590964: BF89FC07
	s_barrier                                                  // 000000590968: BFBD0000
	buffer_gl0_inv                                             // 00000059096C: E0AC0000 00000000
	.long 0xd7390001                                           // 000000590974: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 000000590978: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000059097C: BF870091
	.long 0xd7044001                                           // 000000590980: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 000000590984: 02020300
	.long 0xd7395001                                           // 000000590988: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000059098C: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590990: BF870091
	.long 0xd7625001                                           // 000000590994: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 000000590998: 020202FF 0000007F
	.long 0xd7030801                                           // 0000005909A0: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 0000005909A4: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005909A8: BF870091
	.long 0xd7390003                                           // 0000005909AC: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000005909B0: 02020282
	.long 0xd7000001                                           // 0000005909B4: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000005909B8: 02020602
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005909BC: BF870121
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 0000005909C0: D5207C02 00010003
	.long 0xd44c0000                                           // 0000005909C8: D44C0000
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 0000005909CC: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000005909D0: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 0000005909D4: 8B006A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000005909D8: BF870009
	s_and_saveexec_b32 s1, s0                                  // 0000005909DC: BE812000
	s_cbranch_execz 43                                         // 0000005909E0: BFA5002B <_ZN7halogen12_GLOBAL__N_18k_lq8s32ILi7ELi32ELi2ELb0EEEvPKhPKtPvll+0xd90>
	.long 0xd7054000                                           // 0000005909E4: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000005909E8: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 0000005909EC: 160606B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005909F0: BF870092
	.long 0xd7041000                                           // 0000005909F4: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000005909F8: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000005909FC: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000590A04: BF8700B1
	v_lshl_add_u32 v3, v0, 2, v3                               // 000000590A08: D6460003 040D0500
	ds_load_2addr_b32 v[6:7], v3 offset1:7                     // 000000590A10: D8DC0700 06000003
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 000000590A18: D6FE7C03 0202000C
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 000000590A20: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000590A28: BF870131
	.long 0xd73c0003                                           // 000000590A2C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 000000590A30: 02020681
	s_waitcnt lgkmcnt(0)                                       // 000000590A34: BF89FC07
	v_add_f32_e32 v0, 0, v6                                    // 000000590A38: 06000C80
	.long 0xd7006a03                                           // 000000590A3C: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000590A40: 02020608
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000590A44: BF8701B2
	v_add_f32_e32 v5, v0, v7                                   // 000000590A48: 060A0F00
	.long 0xd73c0000                                           // 000000590A4C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000590A50: 02020281
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000590A54: D5207C04 01AA0809
	v_bfe_u32 v2, v5, 16, 1                                    // 000000590A5C: D6100002 02052105
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000590A64: BF870093
	.long 0xd7006a00                                           // 000000590A68: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000590A6C: 02020103
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000590A70: D5207C01 01AA0304
	s_delay_alu instid0(VALU_DEP_3)                            // 000000590A78: BF870003
	v_add3_u32 v2, v5, v2, 0x7fff                              // 000000590A7C: D6550002 03FE0505 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000590A88: DC960000 007C0200
	s_endpgm                                                   // 000000590A90: BFB00000
		...

