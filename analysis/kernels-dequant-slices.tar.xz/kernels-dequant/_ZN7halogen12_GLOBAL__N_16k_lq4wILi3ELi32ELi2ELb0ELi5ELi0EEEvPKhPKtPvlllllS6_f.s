00000000008bdc00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000008BDC00: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 0000008BDC08: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008BDC10: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008BDC14: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 0000008BDC18: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000008BDC1C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BDC20: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 0000008BDC24: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 0000008BDC2C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 0000008BDC30: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 0000008BDC34: D610000F 02050B00
	.long 0x7f0e3880                                           // 0000008BDC3C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 0000008BDC40: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 0000008BDC44: BF89FC07
	s_clause 0x1                                               // 0000008BDC48: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 0000008BDC4C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 0000008BDC54: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 0000008BDC5C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000008BDC60: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000008BDC64: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 0000008BDC68: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 0000008BDC6C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000008BDC70: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 0000008BDC74: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000008BDC78: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 0000008BDC7C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 0000008BDC80: CA640680 0310009F
	s_add_u32 s22, s10, s22                                    // 0000008BDC88: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008BDC8C: 8217800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 0000008BDC90: D5010004 01A82A80
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008BDC98: 85968516
	.long 0xd72c0008                                           // 0000008BDC9C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000008BDCA0: 02020613
	s_add_i32 s23, s22, 1                                      // 0000008BDCA4: 81178116
	.long 0xd72c000d                                           // 0000008BDCA8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000008BDCAC: 02001F03
	s_lshr_b32 s19, s23, 31                                    // 0000008BDCB0: 85139F17
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000008BDCB4: D6FE7C09 00081D03
	s_add_i32 s23, s23, s19                                    // 0000008BDCBC: 81171317
	.long 0xd72c0015                                           // 0000008BDCC0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000008BDCC4: 02001D04
	s_ashr_i32 s15, s23, 1                                     // 0000008BDCC8: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000008BDCCC: 80021004
	.long 0xd72c0013                                           // 0000008BDCD0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000008BDCD4: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 0000008BDCD8: 82031105
	.long 0xd72c0016                                           // 0000008BDCDC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000008BDCE0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000008BDCE4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008BDCEC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 0000008BDCF0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 0000008BDCF8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 0000008BDCFC: 4A262113
	s_waitcnt vmcnt(1)                                         // 0000008BDD00: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 0000008BDD04: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 0000008BDD0C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 0000008BDD10: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BDD18: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000008BDD1C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 0000008BDD28: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 0000008BDD30: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 0000008BDD3C: 7E060280
	v_min_i32_e32 v20, s22, v4                                 // 0000008BDD40: 22280816
	.long 0x7e0e3985                                           // 0000008BDD44: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 0000008BDD48: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 0000008BDD50: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BDD58: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 0000008BDD5C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 0000008BDD68: 7C822913
	ds_store_b32 v5, v6                                        // 0000008BDD6C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 0000008BDD74: BF89FC07
	s_barrier                                                  // 0000008BDD78: BFBD0000
	buffer_gl0_inv                                             // 0000008BDD7C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008BDD84: BE83206A
	s_cbranch_execz 21                                         // 0000008BDD88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 0000008BDD8C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 0000008BDD90: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BDD94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000008BDD98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000008BDD9C: 3408069F
	.long 0xd7000201                                           // 0000008BDDA0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008BDDA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BDDA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000008BDDAC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000008BDDB4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008BDDB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008BDDBC: D5207C04 000A090A
	s_clause 0x1                                               // 0000008BDDC4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000008BDDC8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008BDDD0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008BDDD8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000008BDDDC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008BDDE0: 8C7E037E
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 0000008BDDE4: CA100080 17160080
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008BDDEC: BE83206A
	s_cbranch_execz 314                                        // 0000008BDDF0: BFA5013A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x6dc>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 0000008BDDF4: CA200080 160426A0
	v_dual_mov_b32 v23, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000008BDDFC: CA220080 170C2685
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000008BDE04: 8484820A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BDE08: BF870002
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v24, 4, v5     // 0000008BDE0C: CA220080 11180A84
	v_dual_mov_b32 v26, v18 :: v_dual_lshlrev_b32 v25, 1, v5   // 0000008BDE14: CA220112 1A180A81
	s_mov_b32 s14, 0                                           // 0000008BDE1C: BE8E0080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000008BDE20: 848A810A
	s_branch 269                                               // 0000008BDE24: BFA0010D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x65c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000008BDE28: 8C7E0F7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 0000008BDE2C: 341A189F
	v_lshrrev_b32_e32 v75, 6, v1                               // 0000008BDE30: 32960286
	v_lshrrev_b32_e32 v76, 14, v1                              // 0000008BDE34: 3298028E
	v_and_b32_e32 v77, 0xff, v2                                // 0000008BDE38: 369A04FF 000000FF
	v_lshrrev_b32_e32 v78, 6, v2                               // 0000008BDE40: 329C0486
	.long 0xd73c001b                                           // 0000008BDE44: D73C001B
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 0000008BDE48: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 0000008BDE4C: 361A02FF 000000FF
	v_and_b32_e32 v75, 0x3fc, v75                              // 0000008BDE54: 369696FF 000003FC
	v_and_b32_e32 v76, 0x3fc, v76                              // 0000008BDE5C: 369898FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 0000008BDE64: 32020296
	v_lshrrev_b32_e32 v79, 14, v2                              // 0000008BDE68: 329E048E
	.long 0xd700023f                                           // 0000008BDE6C: D700023F
	v_cndmask_b32_e32 v1, s6, v27, vcc_lo                      // 0000008BDE70: 02023606
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BDE74: BF8701A1
	v_add_co_ci_u32_e64 v64, null, s7, v28, s2                 // 0000008BDE78: D5207C40 000A3807
	v_lshlrev_b32_e32 v13, 2, v13                              // 0000008BDE80: 301A1A82
	.long 0xd7000243                                           // 0000008BDE84: D7000243
	v_cndmask_b32_e32 v0, v63, v10, vcc_lo                     // 0000008BDE88: 0200153F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BDE8C: BF8700A1
	v_add_co_ci_u32_e64 v68, null, s11, v64, s2                // 0000008BDE90: D5207C44 000A800B
	.long 0xd7000247                                           // 0000008BDE98: D7000247
	v_cndmask_b32_e32 v0, v63, v4, vcc_lo                      // 0000008BDE9C: 0200093F
	v_add_co_ci_u32_e64 v72, null, s5, v64, s2                 // 0000008BDEA0: D5207C48 000A8005
	s_clause 0xb                                               // 0000008BDEA8: BF85000B
	global_load_b128 v[27:30], v[63:64], off                   // 0000008BDEAC: DC5E0000 1B7C003F
	global_load_b128 v[31:34], v[67:68], off                   // 0000008BDEB4: DC5E0000 1F7C0043
	global_load_b128 v[35:38], v[71:72], off                   // 0000008BDEBC: DC5E0000 237C0047
	global_load_b128 v[39:42], v[63:64], off offset:16         // 0000008BDEC4: DC5E0010 277C003F
	global_load_b128 v[43:46], v[67:68], off offset:16         // 0000008BDECC: DC5E0010 2B7C0043
	global_load_b128 v[47:50], v[71:72], off offset:16         // 0000008BDED4: DC5E0010 2F7C0047
	global_load_b128 v[51:54], v[63:64], off offset:32         // 0000008BDEDC: DC5E0020 337C003F
	global_load_b128 v[55:58], v[67:68], off offset:32         // 0000008BDEE4: DC5E0020 377C0043
	global_load_b128 v[59:62], v[71:72], off offset:32         // 0000008BDEEC: DC5E0020 3B7C0047
	global_load_b128 v[63:66], v[63:64], off offset:48         // 0000008BDEF4: DC5E0030 3F7C003F
	global_load_b128 v[67:70], v[67:68], off offset:48         // 0000008BDEFC: DC5E0030 437C0043
	global_load_b128 v[71:74], v[71:72], off offset:48         // 0000008BDF04: DC5E0030 477C0047
	ds_load_b32 v13, v13                                       // 0000008BDF0C: D8D80000 0D00000D
	ds_load_b32 v75, v75                                       // 0000008BDF14: D8D80000 4B00004B
	ds_load_b32 v76, v76                                       // 0000008BDF1C: D8D80000 4C00004C
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008BDF24: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008BDF28: 360202FF 000003FC
	v_lshlrev_b32_e32 v77, 2, v77                              // 0000008BDF30: 309A9A82
	v_and_b32_e32 v78, 0x3fc, v78                              // 0000008BDF34: 369C9CFF 000003FC
	v_and_b32_e32 v79, 0x3fc, v79                              // 0000008BDF3C: 369E9EFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 0000008BDF44: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 0000008BDF4C: D8D80000 01000001
	ds_load_b32 v77, v77                                       // 0000008BDF54: D8D80000 4D00004D
	ds_load_b32 v78, v78                                       // 0000008BDF5C: D8D80000 4E00004E
	ds_load_b32 v79, v79                                       // 0000008BDF64: D8D80000 4F00004F
	ds_load_b32 v2, v2                                         // 0000008BDF6C: D8D80000 02000002
	v_and_b32_e32 v80, 0xff, v3                                // 0000008BDF74: 36A006FF 000000FF
	v_lshrrev_b32_e32 v81, 6, v3                               // 0000008BDF7C: 32A20686
	v_lshrrev_b32_e32 v82, 14, v3                              // 0000008BDF80: 32A4068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000008BDF84: 32060696
	v_and_b32_e32 v83, 0xff, v4                                // 0000008BDF88: 36A608FF 000000FF
	v_lshrrev_b32_e32 v84, 14, v4                              // 0000008BDF90: 32A8088E
	v_add_nc_u32_e32 v24, 0x200, v24                           // 0000008BDF94: 4A3030FF 00000200
	v_add_nc_u32_e32 v25, 64, v25                              // 0000008BDF9C: 4A3232C0
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000008BDFA0: 360606FF 000003FC
	v_add_nc_u32_e32 v12, 0x400, v12                           // 0000008BDFA8: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 0000008BDFB0: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BDFB4: BF870009
	s_or_b32 s14, s2, s14                                      // 0000008BDFB8: 8C0E0E02
	s_waitcnt vmcnt(11) lgkmcnt(7)                             // 0000008BDFBC: BF892C77
	v_dot2_f32_bf16 v27, v27, v13, 0                           // 0000008BDFC0: CC1A401B 1A021B1B
	s_waitcnt vmcnt(10)                                        // 0000008BDFC8: BF892BF7
	v_dot2_f32_bf16 v31, v31, v13, 0                           // 0000008BDFCC: CC1A401F 1A021B1F
	s_waitcnt vmcnt(9)                                         // 0000008BDFD4: BF8927F7
	v_dot2_f32_bf16 v13, v35, v13, 0                           // 0000008BDFD8: CC1A400D 1A021B23
	v_lshrrev_b32_e32 v35, 6, v4                               // 0000008BDFE0: 32460886
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000008BDFE4: 32080896
	s_waitcnt lgkmcnt(6)                                       // 0000008BDFE8: BF89FC67
	v_dot2_f32_bf16 v27, v28, v75, v27                         // 0000008BDFEC: CC1A401B 1C6E971C
	v_dot2_f32_bf16 v28, v32, v75, v31                         // 0000008BDFF4: CC1A401C 1C7E9720
	v_dot2_f32_bf16 v13, v36, v75, v13                         // 0000008BDFFC: CC1A400D 1C369724
	v_lshlrev_b32_e32 v31, 2, v80                              // 0000008BE004: 303EA082
	v_and_b32_e32 v32, 0x3fc, v82                              // 0000008BE008: 3640A4FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008BE010: BF89FC57
	v_dot2_f32_bf16 v27, v29, v76, v27                         // 0000008BE014: CC1A401B 1C6E991D
	v_dot2_f32_bf16 v28, v33, v76, v28                         // 0000008BE01C: CC1A401C 1C729921
	v_dot2_f32_bf16 v13, v37, v76, v13                         // 0000008BE024: CC1A400D 1C369925
	v_and_b32_e32 v29, 0x3fc, v81                              // 0000008BE02C: 363AA2FF 000003FC
	ds_load_b32 v32, v32                                       // 0000008BE034: D8D80000 20000020
	s_waitcnt lgkmcnt(5)                                       // 0000008BE03C: BF89FC57
	v_dot2_f32_bf16 v27, v30, v1, v27                          // 0000008BE040: CC1A401B 1C6E031E
	v_dot2_f32_bf16 v28, v34, v1, v28                          // 0000008BE048: CC1A401C 1C720322
	v_dot2_f32_bf16 v1, v38, v1, v13                           // 0000008BE050: CC1A4001 1C360326
	ds_load_b32 v30, v31                                       // 0000008BE058: D8D80000 1E00001F
	ds_load_b32 v29, v29                                       // 0000008BE060: D8D80000 1D00001D
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000008BE068: BF892067
	v_dot2_f32_bf16 v27, v39, v77, v27                         // 0000008BE06C: CC1A401B 1C6E9B27
	s_waitcnt vmcnt(7)                                         // 0000008BE074: BF891FF7
	v_dot2_f32_bf16 v28, v43, v77, v28                         // 0000008BE078: CC1A401C 1C729B2B
	s_waitcnt vmcnt(6)                                         // 0000008BE080: BF891BF7
	v_dot2_f32_bf16 v1, v47, v77, v1                           // 0000008BE084: CC1A4001 1C069B2F
	v_lshlrev_b32_e32 v13, 2, v83                              // 0000008BE08C: 301AA682
	v_and_b32_e32 v31, 0x3fc, v35                              // 0000008BE090: 363E46FF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000008BE098: BF89FC57
	v_dot2_f32_bf16 v27, v40, v78, v27                         // 0000008BE09C: CC1A401B 1C6E9D28
	v_dot2_f32_bf16 v28, v44, v78, v28                         // 0000008BE0A4: CC1A401C 1C729D2C
	v_dot2_f32_bf16 v1, v48, v78, v1                           // 0000008BE0AC: CC1A4001 1C069D30
	v_and_b32_e32 v33, 0x3fc, v84                              // 0000008BE0B4: 3642A8FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000008BE0BC: 360808FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000008BE0C4: BF89FC47
	v_dot2_f32_bf16 v27, v41, v79, v27                         // 0000008BE0C8: CC1A401B 1C6E9F29
	v_dot2_f32_bf16 v28, v45, v79, v28                         // 0000008BE0D0: CC1A401C 1C729F2D
	v_dot2_f32_bf16 v1, v49, v79, v1                           // 0000008BE0D8: CC1A4001 1C069F31
	s_waitcnt lgkmcnt(3)                                       // 0000008BE0E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE0E4: BF870193
	v_dot2_f32_bf16 v27, v42, v2, v27                          // 0000008BE0E8: CC1A401B 1C6E052A
	v_dot2_f32_bf16 v28, v46, v2, v28                          // 0000008BE0F0: CC1A401C 1C72052E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BE0F8: BF870003
	v_dot2_f32_bf16 v1, v50, v2, v1                            // 0000008BE0FC: CC1A4001 1C060532
	ds_load_b32 v2, v3                                         // 0000008BE104: D8D80000 02000003
	ds_load_b32 v3, v13                                        // 0000008BE10C: D8D80000 0300000D
	ds_load_b32 v13, v31                                       // 0000008BE114: D8D80000 0D00001F
	ds_load_b32 v31, v33                                       // 0000008BE11C: D8D80000 1F000021
	ds_load_b32 v33, v4                                        // 0000008BE124: D8D80000 21000004
	s_waitcnt vmcnt(5) lgkmcnt(6)                              // 0000008BE12C: BF891467
	v_dot2_f32_bf16 v4, v51, v30, v27                          // 0000008BE130: CC1A4004 1C6E3D33
	s_waitcnt vmcnt(4)                                         // 0000008BE138: BF8913F7
	v_dot2_f32_bf16 v27, v55, v30, v28                         // 0000008BE13C: CC1A401B 1C723D37
	s_waitcnt vmcnt(3)                                         // 0000008BE144: BF890FF7
	v_dot2_f32_bf16 v1, v59, v30, v1                           // 0000008BE148: CC1A4001 1C063D3B
	s_waitcnt lgkmcnt(5)                                       // 0000008BE150: BF89FC57
	v_dot2_f32_bf16 v4, v52, v29, v4                           // 0000008BE154: CC1A4004 1C123B34
	v_dot2_f32_bf16 v27, v56, v29, v27                         // 0000008BE15C: CC1A401B 1C6E3B38
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE164: BF870193
	v_dot2_f32_bf16 v1, v60, v29, v1                           // 0000008BE168: CC1A4001 1C063B3C
	v_dot2_f32_bf16 v4, v53, v32, v4                           // 0000008BE170: CC1A4004 1C124135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE178: BF870193
	v_dot2_f32_bf16 v27, v57, v32, v27                         // 0000008BE17C: CC1A401B 1C6E4139
	v_dot2_f32_bf16 v1, v61, v32, v1                           // 0000008BE184: CC1A4001 1C06413D
	s_waitcnt lgkmcnt(4)                                       // 0000008BE18C: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE190: BF870193
	v_dot2_f32_bf16 v4, v54, v2, v4                            // 0000008BE194: CC1A4004 1C120536
	v_dot2_f32_bf16 v27, v58, v2, v27                          // 0000008BE19C: CC1A401B 1C6E053A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BE1A4: BF8701A3
	v_dot2_f32_bf16 v1, v62, v2, v1                            // 0000008BE1A8: CC1A4001 1C06053E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000008BE1B0: BF890837
	v_dot2_f32_bf16 v2, v63, v3, v4                            // 0000008BE1B4: CC1A4002 1C12073F
	s_waitcnt vmcnt(1)                                         // 0000008BE1BC: BF8907F7
	v_dot2_f32_bf16 v4, v67, v3, v27                           // 0000008BE1C0: CC1A4004 1C6E0743
	s_waitcnt vmcnt(0)                                         // 0000008BE1C8: BF8903F7
	v_dot2_f32_bf16 v1, v71, v3, v1                            // 0000008BE1CC: CC1A4001 1C060747
	s_waitcnt lgkmcnt(2)                                       // 0000008BE1D4: BF89FC27
	v_dot2_f32_bf16 v2, v64, v13, v2                           // 0000008BE1D8: CC1A4002 1C0A1B40
	v_dot2_f32_bf16 v3, v68, v13, v4                           // 0000008BE1E0: CC1A4003 1C121B44
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BE1E8: BF870003
	v_dot2_f32_bf16 v1, v72, v13, v1                           // 0000008BE1EC: CC1A4001 1C061B48
	v_mov_b32_e32 v4, v8                                       // 0000008BE1F4: 7E080308
	s_waitcnt lgkmcnt(1)                                       // 0000008BE1F8: BF89FC17
	v_dot2_f32_bf16 v8, v65, v31, v2                           // 0000008BE1FC: CC1A4008 1C0A3F41
	v_dot2_f32_bf16 v13, v69, v31, v3                          // 0000008BE204: CC1A400D 1C0E3F45
	v_dot2_f32_bf16 v1, v73, v31, v1                           // 0000008BE20C: CC1A4001 1C063F49
	v_dual_mov_b32 v3, v7 :: v_dual_mov_b32 v2, v6             // 0000008BE214: CA100107 03020106
	s_waitcnt lgkmcnt(0)                                       // 0000008BE21C: BF89FC07
	v_dot2_f32_bf16 v6, v66, v33, v8                           // 0000008BE220: CC1A4006 1C224342
	v_dot2_f32_bf16 v7, v70, v33, v13                          // 0000008BE228: CC1A4007 1C364346
	v_dot2_f32_bf16 v8, v74, v33, v1                           // 0000008BE230: CC1A4008 1C06434A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE238: BF870193
	v_dual_mov_b32 v1, v5 :: v_dual_fmac_f32 v22, v18, v6      // 0000008BE23C: CA000105 01160D12
	v_fmac_f32_e32 v23, v18, v7                                // 0000008BE244: 562E0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BE248: BF870003
	v_fmac_f32_e32 v17, v18, v8                                // 0000008BE24C: 56221112
	v_mov_b32_e32 v18, v26                                     // 0000008BE250: 7E24031A
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000008BE254: 917E0E7E
	s_cbranch_execz 31                                         // 0000008BE258: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x6d8>
	s_waitcnt vmcnt(0)                                         // 0000008BE25C: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 0000008BE260: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 0000008BE268: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 0000008BE270: 7E0E0303
	s_mov_b32 s15, exec_lo                                     // 0000008BE274: BE8F007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BE278: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 0000008BE27C: 7C8C2913
	.long 0xd4c1007e                                           // 0000008BE280: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 0000008BE284: 02022913
	s_cbranch_execz 65255                                      // 0000008BE288: BFA5FEE7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	v_ashrrev_i32_e32 v6, 31, v25                              // 0000008BE28C: 340C329F
	v_ashrrev_i32_e32 v8, 31, v24                              // 0000008BE290: 3410309F
	.long 0xd7000205                                           // 0000008BE294: D7000205
	v_cndmask_b32_e32 v1, v11, v25, vcc_lo                     // 0000008BE298: 0202330B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BE29C: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 0000008BE2A0: D5207C06 000A0D15
	.long 0xd7000207                                           // 0000008BE2A8: D7000207
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000008BE2AC: 02023109
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 0000008BE2B0: D5207C08 000A110A
	s_clause 0x1                                               // 0000008BE2B8: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 0000008BE2BC: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 0000008BE2C4: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 0000008BE2CC: BF8907F7
	v_cvt_f32_f16_e32 v26, v13                                 // 0000008BE2D0: 7E34170D
	s_branch 65236                                             // 0000008BE2D4: BFA0FED4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x228>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008BE2D8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000008BE2DC: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008BE2E0: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 0000008BE2E4: BF8903F7
	.long 0xd71f0001                                           // 0000008BE2E8: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008BE2EC: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000008BE2F0: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000008BE2F4: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000008BE2F8: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000008BE2FC: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008BE300: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000008BE304: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000008BE308: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008BE30C: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000008BE310: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BE314: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE318: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000008BE31C: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000008BE320: 30040482
	ds_bpermute_b32 v3, v2, v22                                // 0000008BE324: DACC0000 03001602
	s_waitcnt lgkmcnt(0)                                       // 0000008BE32C: BF89FC07
	v_add_f32_e32 v3, v22, v3                                  // 0000008BE330: 06060716
	ds_bpermute_b32 v4, v2, v23                                // 0000008BE334: DACC0000 04001702
	ds_bpermute_b32 v2, v2, v17                                // 0000008BE33C: DACC0000 02001102
	ds_bpermute_b32 v6, v5, v3                                 // 0000008BE344: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000008BE34C: 02101101
	s_waitcnt lgkmcnt(2)                                       // 0000008BE350: BF89FC27
	v_add_f32_e32 v4, v23, v4                                  // 0000008BE354: 06080917
	s_waitcnt lgkmcnt(0)                                       // 0000008BE358: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000008BE35C: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000008BE360: DACC0000 07000405
	v_add_f32_e32 v2, v17, v2                                  // 0000008BE368: 06040511
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000008BE36C: 30101082
	ds_bpermute_b32 v5, v5, v2                                 // 0000008BE370: DACC0000 05000205
	s_waitcnt lgkmcnt(1)                                       // 0000008BE378: BF89FC17
	v_add_f32_e32 v4, v4, v7                                   // 0000008BE37C: 06080F04
	ds_bpermute_b32 v6, v8, v4                                 // 0000008BE380: DACC0000 06000408
	s_waitcnt lgkmcnt(0)                                       // 0000008BE388: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000008BE38C: 06080D04
	v_add_f32_e32 v2, v2, v5                                   // 0000008BE390: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000008BE394: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000008BE39C: DACC0000 07000208
	v_xor_b32_e32 v8, 2, v1                                    // 0000008BE3A4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008BE3A8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BE3AC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000008BE3B0: 02101101
	s_waitcnt lgkmcnt(1)                                       // 0000008BE3B4: BF89FC17
	v_dual_add_f32 v3, v3, v5 :: v_dual_lshlrev_b32 v8, 2, v8  // 0000008BE3B8: C9220B03 03081082
	s_waitcnt lgkmcnt(0)                                       // 0000008BE3C0: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000008BE3C4: 06040F02
	ds_bpermute_b32 v6, v8, v4                                 // 0000008BE3C8: DACC0000 06000408
	ds_bpermute_b32 v5, v8, v3                                 // 0000008BE3D0: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000008BE3D8: DACC0000 07000208
	v_xor_b32_e32 v8, 1, v1                                    // 0000008BE3E0: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BE3E4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000008BE3E8: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000008BE3EC: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000008BE3F0: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000008BE3F4: BF89FC17
	v_add_f32_e32 v1, v3, v5                                   // 0000008BE3F8: 06020B03
	s_waitcnt lgkmcnt(0)                                       // 0000008BE3FC: BF89FC07
	v_dual_add_f32 v3, v4, v6 :: v_dual_add_f32 v2, v2, v7     // 0000008BE400: C9080D04 03020F02
	ds_bpermute_b32 v4, v8, v1                                 // 0000008BE408: DACC0000 04000108
	ds_bpermute_b32 v6, v8, v3                                 // 0000008BE410: DACC0000 06000308
	ds_bpermute_b32 v5, v8, v2                                 // 0000008BE418: DACC0000 05000208
	v_cmpx_eq_u32_e32 0, v16                                   // 0000008BE420: 7D942080
	s_cbranch_execz 15                                         // 0000008BE424: BFA5000F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0x864>
	.long 0xd72c0007                                           // 0000008BE428: D72C0007
	v_cndmask_b32_e32 v0, v14, v152, vcc_lo                    // 0000008BE42C: 0201310E
	s_waitcnt lgkmcnt(0)                                       // 0000008BE430: BF89FC07
	v_dual_add_f32 v1, v1, v4 :: v_dual_add_f32 v2, v2, v5     // 0000008BE434: C9080901 01020B02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE43C: BF870092
	v_mad_u32_u24 v7, v15, 12, v7                              // 0000008BE440: D60B0007 041D190F
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_nc_u32 v4, 0x400, v7// 0000008BE448: C9200D03 03040EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000008BE454: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 0000008BE45C: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s2                              // 0000008BE464: 8C7E027E
	.long 0xd7050001                                           // 0000008BE468: D7050001
	v_cndmask_b32_e32 v1, 0xab, v0, vcc_lo                     // 0000008BE46C: 020200FF 000000AB
	.long 0x7f063880                                           // 0000008BE474: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000008BE478: BF89FC07
	s_barrier                                                  // 0000008BE47C: BFBD0000
	buffer_gl0_inv                                             // 0000008BE480: E0AC0000 00000000
	.long 0xd7390003                                           // 0000008BE488: D7390003
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000008BE48C: 02020289
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE490: BF870091
	.long 0xd7000201                                           // 0000008BE494: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000008BE498: 02020614
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 0000008BE49C: D5207C02 00090015
	.long 0xd44c0002                                           // 0000008BE4A4: D44C0002
	v_cndmask_b32_e32 v1, 12, v0, vcc_lo                       // 0000008BE4A8: 0202008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000008BE4AC: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000008BE4B0: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000008BE4B4: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 0000008BE4B8: BE832002
	s_cbranch_execz 84                                         // 0000008BE4BC: BFA50054 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi2ELb0ELi5ELi0EEEvPKhPKtPvlllllS6_f+0xa10>
	.long 0xd7054000                                           // 0000008BE4C0: D7054000
	v_cndmask_b32_e32 v0, v3, v131, vcc_lo                     // 0000008BE4C4: 02010703
	s_lshr_b32 s2, s13, 31                                     // 0000008BE4C8: 85029F0D
	v_mul_u32_u24_e32 v3, 24, v3                               // 0000008BE4CC: 16060698
	s_add_u32 s2, s12, s2                                      // 0000008BE4D0: 8002020C
	s_addc_u32 s3, s13, 0                                      // 0000008BE4D4: 8203800D
	.long 0xd7041000                                           // 0000008BE4D8: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000008BE4DC: 02020100
	s_load_b64 s[4:5], s[0:1], 0x40                            // 0000008BE4E0: F4040100 F8000040
	s_lshr_b64 s[0:1], s[2:3], 1                               // 0000008BE4E8: 85808102
	s_lshr_b32 s1, s3, 1                                       // 0000008BE4EC: 85018103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000008BE4F0: BF870121
	v_dual_mov_b32 v10, s9 :: v_dual_and_b32 v7, 0xff, v0      // 0000008BE4F4: CA240009 0A0600FF 000000FF
	v_lshrrev_b32_e32 v0, 23, v2                               // 0000008BE500: 32000497
	v_lshl_add_u32 v3, v7, 2, v3                               // 0000008BE504: D6460003 040D0507
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE50C: BF870092
	.long 0xd7006a00                                           // 0000008BE510: D7006A00
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000008BE514: 02020101
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000008BE518: D5207C08 01AA0480
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE520: BF870193
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000008BE524: 4A0606FF 00000400
	v_and_b32_e32 v9, 0xfffffe00, v0                           // 0000008BE52C: 361200FF FFFFFE00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000008BE534: BF8701B1
	.long 0xd7016a05                                           // 0000008BE538: D7016A05
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000008BE53C: 02021301
	v_mad_u64_u32 v[0:1], null, s0, v7, 0                      // 0000008BE540: D6FE7C00 02020E00
	v_sub_co_ci_u32_e64 v6, null, v2, v8, vcc_lo               // 0000008BE548: D5217C06 01AA1102
	.long 0xd700000b                                           // 0000008BE550: D700000B
	v_cndmask_b32_e32 v1, 0xffffff00, v5, vcc_lo               // 0000008BE554: 02020AFF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BE55C: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[5:6]                     // 0000008BE560: 7CA80AFF 00000100
	v_add_co_ci_u32_e64 v12, null, -1, v6, s0                  // 0000008BE568: D5207C0C 00020CC1
	v_mad_u64_u32 v[1:2], null, s1, v7, v[1:2]                 // 0000008BE570: D6FE7C01 04060E01
	v_mov_b32_e32 v2, s8                                       // 0000008BE578: 7E040208
	ds_load_2addr_b32 v[3:4], v3 offset1:3                     // 0000008BE57C: D8DC0300 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000008BE584: BF89FC07
	v_cndmask_b32_e32 v7, s5, v10, vcc_lo                      // 0000008BE588: 020E1405
	v_cndmask_b32_e32 v6, v12, v6, vcc_lo                      // 0000008BE58C: 020C0D0C
	.long 0xd73c0000                                           // 0000008BE590: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008BE594: 02020081
	v_dual_add_f32 v10, 0, v3 :: v_dual_cndmask_b32 v5, v11, v5// 0000008BE598: C9120680 0A040B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BE5A0: BF870111
	v_dual_cndmask_b32 v11, s4, v2 :: v_dual_add_f32 v4, v10, v4// 0000008BE5A4: CA480404 0B04090A
	.long 0xd73c0002                                           // 0000008BE5AC: D73C0002
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000008BE5B0: 02020A81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE5B4: BF870092
	.long 0xd7006a00                                           // 0000008BE5B8: D7006A00
	v_cndmask_b32_e32 v1, v11, v0, vcc_lo                      // 0000008BE5BC: 0202010B
	v_add_co_ci_u32_e64 v1, null, v7, v1, vcc_lo               // 0000008BE5C0: D5207C01 01AA0307
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE5C8: BF870194
	v_bfe_u32 v5, v4, 16, 1                                    // 0000008BE5CC: D6100005 02052104
	.long 0xd7006a00                                           // 0000008BE5D4: D7006A00
	v_cndmask_b32_e32 v1, v0, v9, vcc_lo                       // 0000008BE5D8: 02021300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BE5DC: BF870191
	v_add_co_ci_u32_e64 v1, null, v1, v8, vcc_lo               // 0000008BE5E0: D5207C01 01AA1101
	v_add3_u32 v4, v4, v5, 0x7fff                              // 0000008BE5E8: D6550004 03FE0B04 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BE5F4: BF870093
	.long 0xd7006a00                                           // 0000008BE5F8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 0000008BE5FC: 02020500
	v_add_co_ci_u32_e64 v1, null, v1, v3, vcc_lo               // 0000008BE600: D5207C01 01AA0701
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008BE608: DC960000 007C0400
	s_endpgm                                                   // 0000008BE610: BFB00000
		...

