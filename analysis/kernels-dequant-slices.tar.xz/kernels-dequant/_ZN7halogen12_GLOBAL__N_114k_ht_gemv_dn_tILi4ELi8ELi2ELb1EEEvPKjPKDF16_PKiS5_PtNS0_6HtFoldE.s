00000000009b5900 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE>:
; _ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE():
	s_load_b512 s[4:19], s[0:1], null                          // 0000009B5900: F4100100 F8000000
	s_mul_hi_i32 s3, s2, 0x66666667                            // 0000009B5908: 9703FF02 66666667
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009B5910: BF8704A9
	s_lshr_b32 s20, s3, 31                                     // 0000009B5914: 85149F03
	s_ashr_i32 s3, s3, 3                                       // 0000009B5918: 86038303
	s_add_i32 s20, s3, s20                                     // 0000009B591C: 81141403
	s_mov_b32 s3, exec_lo                                      // 0000009B5920: BE83007E
	s_ashr_i32 s21, s20, 31                                    // 0000009B5924: 86159F14
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B5928: BF870009
	s_lshl_b64 s[22:23], s[20:21], 2                           // 0000009B592C: 84968214
	s_waitcnt lgkmcnt(0)                                       // 0000009B5930: BF89FC07
	s_add_u32 s8, s8, s22                                      // 0000009B5934: 80081608
	s_addc_u32 s9, s9, s23                                     // 0000009B5938: 82091709
	s_load_b32 s8, s[8:9], null                                // 0000009B593C: F4000204 F8000000
	v_cmpx_gt_u32_e32 0x50, v0                                 // 0000009B5944: 7D9800FF 00000050
	s_cbranch_execz 12                                         // 0000009B594C: BFA5000C <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x80>
	s_mul_i32 s9, s20, 0x500                                   // 0000009B5950: 9609FF14 00000500
	v_lshlrev_b32_e32 v5, 4, v0                                // 0000009B5958: 300A0084
	s_mul_hi_i32 s21, s20, 0x500                               // 0000009B595C: 9715FF14 00000500
	s_add_u32 s6, s6, s9                                       // 0000009B5964: 80060906
	s_addc_u32 s7, s7, s21                                     // 0000009B5968: 82071507
	global_load_b128 v[1:4], v5, s[6:7]                        // 0000009B596C: DC5E0000 01060005
	s_waitcnt vmcnt(0)                                         // 0000009B5974: BF8903F7
	ds_store_b128 v5, v[1:4]                                   // 0000009B5978: DB7C0000 00000105
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009B5980: 8C7E037E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000009B5984: 320E0085
	v_and_b32_e32 v9, 31, v0                                   // 0000009B5988: 3612009F
	s_mul_i32 s9, s20, 0xffffffec                              // 0000009B598C: 9609FF14 FFFFFFEC
	s_waitcnt lgkmcnt(0)                                       // 0000009B5994: BF89FC07
	s_mul_i32 s6, s8, 0xc8000                                  // 0000009B5998: 9606FF08 000C8000
	s_mul_hi_i32 s3, s8, 0xc8000                               // 0000009B59A0: 9703FF08 000C8000
	v_mul_u32_u24_e32 v3, 5, v7                                // 0000009B59A8: 16060E85
	s_add_i32 s9, s9, s2                                       // 0000009B59AC: 81090209
	s_add_u32 s4, s4, s6                                       // 0000009B59B0: 80040604
	s_addc_u32 s3, s5, s3                                      // 0000009B59B4: 82030305
	s_mul_i32 s5, s9, 0xa000                                   // 0000009B59B8: 9605FF09 0000A000
	v_min_u32_e32 v4, 35, v3                                   // 0000009B59C0: 260806A3
	v_lshlrev_b32_e32 v8, 2, v9                                // 0000009B59C4: 30101282
	s_mul_hi_i32 s6, s9, 0xa000                                // 0000009B59C8: 9706FF09 0000A000
	s_add_u32 s4, s4, s5                                       // 0000009B59D0: 80040504
	s_addc_u32 s5, s3, s6                                      // 0000009B59D4: 82050603
	v_add_nc_u32_e32 v10, 5, v4                                // 0000009B59D8: 4A140885
	s_barrier                                                  // 0000009B59DC: BFBD0000
	buffer_gl0_inv                                             // 0000009B59E0: E0AC0000 00000000
	v_cmp_lt_u32_e32 vcc_lo, v3, v10                           // 0000009B59E8: 7C921503
	s_and_saveexec_b32 s6, vcc_lo                              // 0000009B59EC: BE86206A
	s_cbranch_execz 91                                         // 0000009B59F0: BFA5005B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x260>
	.long 0xd7010301                                           // 0000009B59F4: D7010301
	v_cndmask_b32_e32 v0, v9, v129, vcc_lo                     // 0000009B59F8: 02010309
	v_mul_u32_u24_e32 v6, 0x1400, v7                           // 0000009B59FC: 160C0EFF 00001400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5A04: BF870092
	v_cndmask_b32_e64 v1, v1, 31, s3                           // 0000009B5A08: D5010001 000D3F01
	.long 0xd44c0003                                           // 0000009B5A10: D44C0003
	v_cndmask_b32_e32 v1, 31, v1, vcc_lo                       // 0000009B5A14: 0202029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000009B5A18: BF8700B1
	v_cndmask_b32_e64 v5, 0xe1, 1, s3                          // 0000009B5A1C: D5010005 000D02FF 000000E1
	v_mov_b32_e32 v2, 0                                        // 0000009B5A28: 7E040280
	.long 0xd700030d                                           // 0000009B5A2C: D700030D
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 0000009B5A30: 02020C04
	v_add_co_ci_u32_e64 v14, null, s5, 0, s3                   // 0000009B5A34: D5207C0E 000D0005
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B5A3C: BF870214
	v_add_nc_u32_e32 v5, v5, v1                                // 0000009B5A40: 4A0A0305
	.long 0xd73c0001                                           // 0000009B5A44: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000009B5A48: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B5A4C: BF8701A2
	v_lshlrev_b32_e32 v11, 24, v5                              // 0000009B5A50: 30160A98
	v_bfe_i32 v12, v5, 7, 1                                    // 0000009B5A54: D611000C 02050F05
	.long 0xd7000305                                           // 0000009B5A5C: D7000305
	v_cndmask_b32_e32 v1, v13, v1, vcc_lo                      // 0000009B5A60: 0202030D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B5A64: BF870211
	v_add_co_ci_u32_e64 v6, null, v14, v2, s3                  // 0000009B5A68: D5207C06 000E050E
	v_ashrrev_i32_e32 v11, 22, v11                             // 0000009B5A70: 34161696
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B5A74: BF870091
	.long 0xd700030b                                           // 0000009B5A78: D700030B
	v_cndmask_b32_e32 v1, v13, v11, vcc_lo                     // 0000009B5A7C: 0202170D
	v_add_co_ci_u32_e64 v12, null, v14, v12, s3                // 0000009B5A80: D5207C0C 000E190E
	.long 0xd700030d                                           // 0000009B5A88: D700030D
	v_cndmask_b32_e32 v1, v13, v8, vcc_lo                      // 0000009B5A8C: 0202110D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5A90: BF870001
	v_add_co_ci_u32_e64 v14, null, 0, v14, s3                  // 0000009B5A94: D5207C0E 000E1C80
	s_clause 0x17                                              // 0000009B5A9C: BF850017
	global_load_b32 v1, v[5:6], off                            // 0000009B5AA0: DC520000 017C0005
	global_load_b32 v57, v[5:6], off offset:128                // 0000009B5AA8: DC520080 397C0005
	global_load_b32 v55, v[5:6], off offset:256                // 0000009B5AB0: DC520100 377C0005
	global_load_b32 v51, v[5:6], off offset:384                // 0000009B5AB8: DC520180 337C0005
	global_load_b32 v49, v[5:6], off offset:512                // 0000009B5AC0: DC520200 317C0005
	global_load_b32 v46, v[5:6], off offset:640                // 0000009B5AC8: DC520280 2E7C0005
	global_load_b32 v43, v[5:6], off offset:768                // 0000009B5AD0: DC520300 2B7C0005
	global_load_b32 v22, v[5:6], off offset:896                // 0000009B5AD8: DC520380 167C0005
	global_load_b32 v2, v[11:12], off                          // 0000009B5AE0: DC520000 027C000B
	global_load_b32 v59, v[11:12], off offset:128              // 0000009B5AE8: DC520080 3B7C000B
	global_load_b32 v56, v[11:12], off offset:256              // 0000009B5AF0: DC520100 387C000B
	global_load_b32 v53, v[11:12], off offset:384              // 0000009B5AF8: DC520180 357C000B
	global_load_b32 v50, v[11:12], off offset:512              // 0000009B5B00: DC520200 327C000B
	global_load_b32 v47, v[11:12], off offset:640              // 0000009B5B08: DC520280 2F7C000B
	global_load_b32 v44, v[11:12], off offset:768              // 0000009B5B10: DC520300 2C7C000B
	global_load_b32 v24, v[11:12], off offset:896              // 0000009B5B18: DC520380 187C000B
	global_load_b32 v60, v[13:14], off                         // 0000009B5B20: DC520000 3C7C000D
	global_load_b32 v58, v[13:14], off offset:128              // 0000009B5B28: DC520080 3A7C000D
	global_load_b32 v54, v[13:14], off offset:256              // 0000009B5B30: DC520100 367C000D
	global_load_b32 v52, v[13:14], off offset:384              // 0000009B5B38: DC520180 347C000D
	global_load_b32 v48, v[13:14], off offset:512              // 0000009B5B40: DC520200 307C000D
	global_load_b32 v45, v[13:14], off offset:640              // 0000009B5B48: DC520280 2D7C000D
	global_load_b32 v26, v[13:14], off offset:768              // 0000009B5B50: DC520300 1A7C000D
	global_load_b32 v19, v[13:14], off offset:896              // 0000009B5B58: DC520380 137C000D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009B5B60: 8C7E067E
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v11, 0             // 0000009B5B64: CA100080 0E0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000009B5B6C: CA100080 0C0C0080
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 0000009B5B74: CA100080 0F100080
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v18, 0             // 0000009B5B7C: CA100080 11120080
	s_and_saveexec_b32 s3, vcc_lo                              // 0000009B5B84: BE83206A
	s_cbranch_execz 987                                        // 0000009B5B88: BFA503DB <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11f8>
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v11, -1, v0      // 0000009B5B8C: CA200080 060A00C1
	v_and_b32_e32 v12, 16, v0                                  // 0000009B5B94: 36180090
	v_add_nc_u32_e32 v5, 1, v3                                 // 0000009B5B98: 4A0A0681
	v_sub_nc_u32_e32 v20, 0, v4                                // 0000009B5B9C: 4C280880
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000009B5BA0: BF870244
	v_and_b32_e32 v11, 31, v11                                 // 0000009B5BA4: 3616169F
	v_dual_mov_b32 v16, v6 :: v_dual_lshlrev_b32 v21, 2, v9    // 0000009B5BA8: CA220106 10141282
	v_mov_b32_e32 v14, v6                                      // 0000009B5BB0: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 0000009B5BB4: 7E1A0306
	v_dual_mov_b32 v18, v6 :: v_dual_lshlrev_b32 v25, 2, v11   // 0000009B5BB8: CA220106 12181682
	v_mov_b32_e32 v11, v6                                      // 0000009B5BC0: 7E160306
	v_lshl_or_b32 v23, v3, 5, v12                              // 0000009B5BC4: D6560017 04310B03
	v_mov_b32_e32 v12, v6                                      // 0000009B5BCC: 7E180306
	v_mov_b32_e32 v15, v6                                      // 0000009B5BD0: 7E1E0306
	v_mov_b32_e32 v17, v6                                      // 0000009B5BD4: 7E220306
	s_mov_b32 s6, 0                                            // 0000009B5BD8: BE860080
	s_mov_b32 s7, 0xdcd12d                                     // 0000009B5BDC: BE8700FF 00DCD12D
	s_movk_i32 s21, 0x83                                       // 0000009B5BE4: B0150083
	s_movk_i32 s22, 0x1eee                                     // 0000009B5BE8: B0161EEE
	s_branch 906                                               // 0000009B5BEC: BFA0038A <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1118>
	s_or_b32 exec_lo, exec_lo, s23                             // 0000009B5BF0: 8C7E177E
	s_waitcnt vmcnt(15)                                        // 0000009B5BF4: BF893FF7
	v_alignbit_b32 v61, v1, v2, 16                             // 0000009B5BF8: D616003D 02420501
	ds_load_b128 v[1:4], v23                                   // 0000009B5C00: DBFC0000 01000017
	s_waitcnt vmcnt(7)                                         // 0000009B5C08: BF891FF7
	v_bfe_u32 v62, v60, 12, 16                                 // 0000009B5C0C: D610003E 0241193C
	v_bfe_u32 v63, v60, 8, 16                                  // 0000009B5C14: D610003F 0241113C
	v_bfe_u32 v65, v60, 4, 16                                  // 0000009B5C1C: D6100041 0241093C
	v_bfe_u32 v64, v61, 12, 16                                 // 0000009B5C24: D6100040 0241193D
	v_mul_u32_u24_e32 v68, s7, v64                             // 0000009B5C2C: 16888007
	v_mul_u32_u24_e32 v64, s21, v64                            // 0000009B5C30: 16808015
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009B5C34: BF8700C1
	v_lshl_add_u32 v64, v64, 24, v68                           // 0000009B5C38: D6460040 05113140
	v_bfe_u32 v66, v61, 8, 16                                  // 0000009B5C40: D6100042 0241113D
	v_mul_u32_u24_e32 v68, s7, v66                             // 0000009B5C48: 16888407
	v_mul_u32_u24_e32 v66, s21, v66                            // 0000009B5C4C: 16848415
	v_lshl_add_u32 v66, v66, 24, v68                           // 0000009B5C50: D6460042 05113142
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009B5C58: D6220040 03FD0140 00006400
	v_bfe_u32 v67, v61, 4, 16                                  // 0000009B5C64: D6100043 0241093D
	v_mul_u32_u24_e32 v68, s7, v67                             // 0000009B5C6C: 16888607
	v_mul_u32_u24_e32 v67, s21, v67                            // 0000009B5C70: 16868615
	v_sad_u8 v66, v66, 0, 0x6400                               // 0000009B5C74: D6220042 03FD0142 00006400
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009B5C80: 368080FF 0000FFFF
	v_lshl_add_u32 v67, v67, 24, v68                           // 0000009B5C88: D6460043 05113143
	v_mul_u32_u24_e32 v68, s7, v62                             // 0000009B5C90: 16887C07
	v_mul_u32_u24_e32 v62, s21, v62                            // 0000009B5C94: 167C7C15
	v_lshl_add_u32 v62, v62, 24, v68                           // 0000009B5C98: D646003E 0511313E
	v_lshl_or_b32 v64, v66, 16, v64                            // 0000009B5CA0: D6560040 05012142
	v_sad_u8 v67, v67, 0, 0x6400                               // 0000009B5CA8: D6220043 03FD0143 00006400
	v_and_b32_e32 v60, 0xffff, v60                             // 0000009B5CB4: 367878FF 0000FFFF
	v_alignbit_b32 v57, v57, v59, 16                           // 0000009B5CBC: D6160039 02427739
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B5CC4: D622003E 03FD013E 00006400
	v_pk_fma_f16 v64, v64, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5CD0: CC0E0040 0BFC2D40 0000C931
	v_and_b32_e32 v67, 0xffff, v67                             // 0000009B5CDC: 368686FF 0000FFFF
	s_waitcnt vmcnt(6)                                         // 0000009B5CE4: BF891BF7
	v_bfe_u32 v66, v58, 8, 16                                  // 0000009B5CE8: D6100042 0241113A
	v_alignbit_b32 v55, v55, v56, 16                           // 0000009B5CF0: D6160037 02427137
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009B5CF8: 367C7CFF 0000FFFF
	s_waitcnt lgkmcnt(0)                                       // 0000009B5D00: BF89FC07
	v_dot2acc_f32_f16 v18, v64, v1                             // 0000009B5D04: 04240340
	v_and_b32_e32 v61, 0xffff, v61                             // 0000009B5D08: 367A7AFF 0000FFFF
	v_mul_u32_u24_e32 v68, s7, v61                             // 0000009B5D10: 16887A07
	v_mul_u32_u24_e32 v61, s21, v61                            // 0000009B5D14: 167A7A15
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B5D18: BF870001
	v_lshl_add_u32 v61, v61, 24, v68                           // 0000009B5D1C: D646003D 0511313D
	v_mul_u32_u24_e32 v68, s7, v63                             // 0000009B5D24: 16887E07
	v_mul_u32_u24_e32 v63, s21, v63                            // 0000009B5D28: 167E7E15
	v_lshl_add_u32 v63, v63, 24, v68                           // 0000009B5D2C: D646003F 0511313F
	v_mul_u32_u24_e32 v68, s7, v65                             // 0000009B5D34: 16888207
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B5D38: D622003D 03FD013D 00006400
	v_mul_u32_u24_e32 v65, s21, v65                            // 0000009B5D44: 16828215
	v_lshl_add_u32 v65, v65, 24, v68                           // 0000009B5D48: D6460041 05113141
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009B5D50: D622003F 03FD013F 00006400
	v_mul_u32_u24_e32 v68, s7, v60                             // 0000009B5D5C: 16887807
	v_lshl_or_b32 v61, v61, 16, v67                            // 0000009B5D60: D656003D 050D213D
	v_mul_u32_u24_e32 v60, s21, v60                            // 0000009B5D68: 16787815
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B5D6C: D6220041 03FD0141 00006400
	v_lshl_add_u32 v60, v60, 24, v68                           // 0000009B5D78: D646003C 0511313C
	v_lshl_or_b32 v62, v63, 16, v62                            // 0000009B5D80: D656003E 04F9213F
	v_pk_fma_f16 v59, v61, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5D88: CC0E003B 0BFC2D3D 0000C931
	v_bfe_u32 v64, v57, 4, 16                                  // 0000009B5D94: D6100040 02410939
	v_bfe_u32 v67, v58, 4, 16                                  // 0000009B5D9C: D6100043 0241093A
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B5DA4: D622003C 03FD013C 00006400
	v_pk_fma_f16 v61, v62, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5DB0: CC0E003D 0BFC2D3E 0000C931
	v_bfe_u32 v62, v57, 12, 16                                 // 0000009B5DBC: D610003E 02411939
	v_dual_dot2acc_f32_f16 v18, v59, v2 :: v_dual_and_b32 v63, 0xffff, v65// 0000009B5DC4: CB24053B 123E82FF 0000FFFF
	v_mul_u32_u24_e32 v68, s7, v62                             // 0000009B5DD0: 16887C07
	v_mul_u32_u24_e32 v62, s21, v62                            // 0000009B5DD4: 167C7C15
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B5DD8: BF870002
	v_lshl_add_u32 v62, v62, 24, v68                           // 0000009B5DDC: D646003E 0511313E
	v_mul_u32_u24_e32 v68, s7, v64                             // 0000009B5DE4: 16888007
	v_mul_u32_u24_e32 v64, s21, v64                            // 0000009B5DE8: 16808015
	v_dot2acc_f32_f16 v18, v61, v3                             // 0000009B5DEC: 0424073D
	v_lshl_or_b32 v60, v60, 16, v63                            // 0000009B5DF0: D656003C 04FD213C
	v_bfe_u32 v63, v57, 8, 16                                  // 0000009B5DF8: D610003F 02411139
	v_lshl_add_u32 v64, v64, 24, v68                           // 0000009B5E00: D6460040 05113140
	v_mul_u32_u24_e32 v68, s7, v63                             // 0000009B5E08: 16887E07
	v_mul_u32_u24_e32 v63, s21, v63                            // 0000009B5E0C: 167E7E15
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B5E10: D622003E 03FD013E 00006400
	v_lshl_add_u32 v63, v63, 24, v68                           // 0000009B5E1C: D646003F 0511313F
	v_and_b32_e32 v57, 0xffff, v57                             // 0000009B5E24: 367272FF 0000FFFF
	v_bfe_u32 v65, v58, 12, 16                                 // 0000009B5E2C: D6100041 0241193A
	v_mul_u32_u24_e32 v68, s7, v57                             // 0000009B5E34: 16887207
	v_mul_u32_u24_e32 v57, s21, v57                            // 0000009B5E38: 16727215
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B5E3C: BF870002
	v_lshl_add_u32 v57, v57, 24, v68                           // 0000009B5E40: D6460039 05113139
	v_mul_u32_u24_e32 v68, s7, v65                             // 0000009B5E48: 16888207
	v_mul_u32_u24_e32 v65, s21, v65                            // 0000009B5E4C: 16828215
	v_sad_u8 v64, v64, 0, 0x6400                               // 0000009B5E50: D6220040 03FD0140 00006400
	v_lshl_add_u32 v65, v65, 24, v68                           // 0000009B5E5C: D6460041 05113141
	v_and_b32_e32 v62, 0xffff, v62                             // 0000009B5E64: 367C7CFF 0000FFFF
	v_sad_u8 v63, v63, 0, 0x6400                               // 0000009B5E6C: D622003F 03FD013F 00006400
	v_mul_u32_u24_e32 v68, s7, v66                             // 0000009B5E78: 16888407
	v_mul_u32_u24_e32 v66, s21, v66                            // 0000009B5E7C: 16848415
	v_and_b32_e32 v64, 0xffff, v64                             // 0000009B5E80: 368080FF 0000FFFF
	v_sad_u8 v57, v57, 0, 0x6400                               // 0000009B5E88: D6220039 03FD0139 00006400
	v_sad_u8 v65, v65, 0, 0x6400                               // 0000009B5E94: D6220041 03FD0141 00006400
	v_lshl_add_u32 v66, v66, 24, v68                           // 0000009B5EA0: D6460042 05113142
	v_lshl_or_b32 v62, v63, 16, v62                            // 0000009B5EA8: D656003E 04F9213F
	v_mul_u32_u24_e32 v68, s7, v67                             // 0000009B5EB0: 16888607
	v_lshl_or_b32 v57, v57, 16, v64                            // 0000009B5EB4: D6560039 05012139
	v_and_b32_e32 v63, 0xffff, v65                             // 0000009B5EBC: 367E82FF 0000FFFF
	v_sad_u8 v64, v66, 0, 0x6400                               // 0000009B5EC4: D6220040 03FD0142 00006400
	v_pk_fma_f16 v62, v62, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5ED0: CC0E003E 0BFC2D3E 0000C931
	v_mul_u32_u24_e32 v67, s21, v67                            // 0000009B5EDC: 16868615
	v_lshl_add_u32 v67, v67, 24, v68                           // 0000009B5EE0: D6460043 05113143
	v_pk_fma_f16 v57, v57, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5EE8: CC0E0039 0BFC2D39 0000C931
	v_lshl_or_b32 v63, v64, 16, v63                            // 0000009B5EF4: D656003F 04FD2140
	v_dual_dot2acc_f32_f16 v17, v62, v1 :: v_dual_and_b32 v58, 0xffff, v58// 0000009B5EFC: CB24033E 113A74FF 0000FFFF
	v_mul_u32_u24_e32 v66, s7, v58                             // 0000009B5F08: 16847407
	v_mul_u32_u24_e32 v58, s21, v58                            // 0000009B5F0C: 16747415
	v_sad_u8 v65, v67, 0, 0x6400                               // 0000009B5F10: D6220041 03FD0143 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B5F1C: BF870002
	v_lshl_add_u32 v58, v58, 24, v66                           // 0000009B5F20: D646003A 0509313A
	v_pk_fma_f16 v56, v63, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5F28: CC0E0038 0BFC2D3F 0000C931
	v_dot2acc_f32_f16 v17, v57, v2                             // 0000009B5F34: 04220539
	v_bfe_u32 v59, v55, 12, 16                                 // 0000009B5F38: D610003B 02411937
	v_pk_fma_f16 v57, v60, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B5F40: CC0E0039 0BFC2D3C 0000C931
	v_sad_u8 v58, v58, 0, 0x6400                               // 0000009B5F4C: D622003A 03FD013A 00006400
	v_mul_u32_u24_e32 v60, s7, v59                             // 0000009B5F58: 16787607
	v_dual_dot2acc_f32_f16 v17, v56, v3 :: v_dual_and_b32 v64, 0xffff, v65// 0000009B5F5C: CB240738 114082FF 0000FFFF
	v_mul_u32_u24_e32 v59, s21, v59                            // 0000009B5F68: 16767615
	v_lshl_add_u32 v59, v59, 24, v60                           // 0000009B5F6C: D646003B 04F1313B
	v_bfe_u32 v56, v55, 8, 16                                  // 0000009B5F74: D6100038 02411137
	v_dot2acc_f32_f16 v18, v57, v4                             // 0000009B5F7C: 04240939
	v_lshl_or_b32 v58, v58, 16, v64                            // 0000009B5F80: D656003A 0501213A
	v_mul_u32_u24_e32 v64, s7, v56                             // 0000009B5F88: 16807007
	v_mul_u32_u24_e32 v56, s21, v56                            // 0000009B5F8C: 16707015
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000009B5F90: D622003B 03FD013B 00006400
	v_lshl_add_u32 v56, v56, 24, v64                           // 0000009B5F9C: D6460038 05013138
	v_bfe_u32 v60, v55, 4, 16                                  // 0000009B5FA4: D610003C 02410937
	s_waitcnt vmcnt(5)                                         // 0000009B5FAC: BF8917F7
	v_bfe_u32 v61, v54, 12, 16                                 // 0000009B5FB0: D610003D 02411936
	v_mul_u32_u24_e32 v64, s7, v60                             // 0000009B5FB8: 16807807
	v_and_b32_e32 v59, 0xffff, v59                             // 0000009B5FBC: 367676FF 0000FFFF
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009B5FC4: D6220038 03FD0138 00006400
	v_mul_u32_u24_e32 v60, s21, v60                            // 0000009B5FD0: 16787815
	v_lshl_add_u32 v60, v60, 24, v64                           // 0000009B5FD4: D646003C 0501313C
	v_mul_u32_u24_e32 v64, s7, v61                             // 0000009B5FDC: 16807A07
	v_mul_u32_u24_e32 v61, s21, v61                            // 0000009B5FE0: 167A7A15
	v_lshl_or_b32 v56, v56, 16, v59                            // 0000009B5FE4: D6560038 04ED2138
	v_lshl_add_u32 v61, v61, 24, v64                           // 0000009B5FEC: D646003D 0501313D
	v_bfe_u32 v62, v54, 8, 16                                  // 0000009B5FF4: D610003E 02411136
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B5FFC: D622003C 03FD013C 00006400
	v_bfe_u32 v63, v54, 4, 16                                  // 0000009B6008: D610003F 02410936
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6010: CC0E0038 0BFC2D38 0000C931
	v_and_b32_e32 v55, 0xffff, v55                             // 0000009B601C: 366E6EFF 0000FFFF
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B6024: D622003D 03FD013D 00006400
	v_and_b32_e32 v59, 0xffff, v60                             // 0000009B6030: 367678FF 0000FFFF
	v_alignbit_b32 v51, v51, v53, 16                           // 0000009B6038: D6160033 02426B33
	v_dot2acc_f32_f16 v16, v56, v1                             // 0000009B6040: 04200338
	v_mul_u32_u24_e32 v64, s7, v55                             // 0000009B6044: 16806E07
	v_mul_u32_u24_e32 v55, s21, v55                            // 0000009B6048: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v64                           // 0000009B604C: D6460037 05013137
	v_mul_u32_u24_e32 v64, s7, v62                             // 0000009B6054: 16807C07
	v_mul_u32_u24_e32 v62, s21, v62                            // 0000009B6058: 167C7C15
	v_lshl_add_u32 v62, v62, 24, v64                           // 0000009B605C: D646003E 0501313E
	v_and_b32_e32 v60, 0xffff, v61                             // 0000009B6064: 36787AFF 0000FFFF
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009B606C: D6220037 03FD0137 00006400
	v_bfe_u32 v56, v51, 12, 16                                 // 0000009B6078: D6100038 02411933
	v_mul_u32_u24_e32 v65, s7, v56                             // 0000009B6080: 16827007
	v_sad_u8 v61, v62, 0, 0x6400                               // 0000009B6084: D622003D 03FD013E 00006400
	v_mul_u32_u24_e32 v62, s7, v63                             // 0000009B6090: 167C7E07
	v_mul_u32_u24_e32 v63, s21, v63                            // 0000009B6094: 167E7E15
	v_lshl_add_u32 v62, v63, 24, v62                           // 0000009B6098: D646003E 04F9313F
	v_lshl_or_b32 v55, v55, 16, v59                            // 0000009B60A0: D6560037 04ED2137
	v_lshl_or_b32 v59, v61, 16, v60                            // 0000009B60A8: D656003B 04F1213D
	v_mul_u32_u24_e32 v56, s21, v56                            // 0000009B60B0: 16707015
	v_and_b32_e32 v54, 0xffff, v54                             // 0000009B60B4: 366C6CFF 0000FFFF
	v_sad_u8 v60, v62, 0, 0x6400                               // 0000009B60BC: D622003C 03FD013E 00006400
	v_lshl_add_u32 v56, v56, 24, v65                           // 0000009B60C8: D6460038 05053138
	v_mul_u32_u24_e32 v61, s7, v54                             // 0000009B60D0: 167A6C07
	v_mul_u32_u24_e32 v54, s21, v54                            // 0000009B60D4: 166C6C15
	v_lshl_add_u32 v54, v54, 24, v61                           // 0000009B60D8: D6460036 04F53136
	v_bfe_u32 v61, v51, 4, 16                                  // 0000009B60E0: D610003D 02410933
	v_pk_fma_f16 v53, v59, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B60E8: CC0E0035 0BFC2D3B 0000C931
	v_and_b32_e32 v59, 0xffff, v60                             // 0000009B60F4: 367678FF 0000FFFF
	v_bfe_u32 v60, v51, 8, 16                                  // 0000009B60FC: D610003C 02411133
	v_mul_u32_u24_e32 v65, s7, v61                             // 0000009B6104: 16827A07
	v_mul_u32_u24_e32 v61, s21, v61                            // 0000009B6108: 167A7A15
	v_pk_fma_f16 v55, v55, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B610C: CC0E0037 0BFC2D37 0000C931
	v_lshl_add_u32 v61, v61, 24, v65                           // 0000009B6118: D646003D 0505313D
	v_mul_u32_u24_e32 v65, s7, v60                             // 0000009B6120: 16827807
	v_mul_u32_u24_e32 v60, s21, v60                            // 0000009B6124: 16787815
	v_sad_u8 v56, v56, 0, 0x6400                               // 0000009B6128: D6220038 03FD0138 00006400
	v_lshl_add_u32 v60, v60, 24, v65                           // 0000009B6134: D646003C 0505313C
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009B613C: 366666FF 0000FFFF
	s_waitcnt vmcnt(4)                                         // 0000009B6144: BF8913F7
	v_bfe_u32 v62, v52, 12, 16                                 // 0000009B6148: D610003E 02411934
	v_mul_u32_u24_e32 v65, s7, v51                             // 0000009B6150: 16826607
	v_mul_u32_u24_e32 v51, s21, v51                            // 0000009B6154: 16666615
	v_sad_u8 v61, v61, 0, 0x6400                               // 0000009B6158: D622003D 03FD013D 00006400
	v_lshl_add_u32 v51, v51, 24, v65                           // 0000009B6164: D6460033 05053133
	v_mul_u32_u24_e32 v65, s7, v62                             // 0000009B616C: 16827C07
	v_mul_u32_u24_e32 v62, s21, v62                            // 0000009B6170: 167C7C15
	v_dot2acc_f32_f16 v16, v55, v2                             // 0000009B6174: 04200537
	v_lshl_add_u32 v62, v62, 24, v65                           // 0000009B6178: D646003E 0505313E
	v_and_b32_e32 v56, 0xffff, v56                             // 0000009B6180: 367070FF 0000FFFF
	v_sad_u8 v60, v60, 0, 0x6400                               // 0000009B6188: D622003C 03FD013C 00006400
	v_bfe_u32 v63, v52, 8, 16                                  // 0000009B6194: D610003F 02411134
	v_bfe_u32 v64, v52, 4, 16                                  // 0000009B619C: D6100040 02410934
	v_mul_u32_u24_e32 v65, s7, v63                             // 0000009B61A4: 16827E07
	v_mul_u32_u24_e32 v63, s21, v63                            // 0000009B61A8: 167E7E15
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009B61AC: D6220033 03FD0133 00006400
	v_lshl_add_u32 v63, v63, 24, v65                           // 0000009B61B8: D646003F 0505313F
	v_mul_u32_u24_e32 v65, s7, v64                             // 0000009B61C0: 16828007
	v_mul_u32_u24_e32 v64, s21, v64                            // 0000009B61C4: 16808015
	v_dual_dot2acc_f32_f16 v16, v53, v3 :: v_dual_and_b32 v61, 0xffff, v61// 0000009B61C8: CB240735 103C7AFF 0000FFFF
	v_sad_u8 v62, v62, 0, 0x6400                               // 0000009B61D4: D622003E 03FD013E 00006400
	v_lshl_add_u32 v64, v64, 24, v65                           // 0000009B61E0: D6460040 05053140
	v_lshl_or_b32 v56, v60, 16, v56                            // 0000009B61E8: D6560038 04E1213C
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009B61F0: 366868FF 0000FFFF
	v_lshl_or_b32 v51, v51, 16, v61                            // 0000009B61F8: D6560033 04F52133
	v_sad_u8 v61, v63, 0, 0x6400                               // 0000009B6200: D622003D 03FD013F 00006400
	v_mul_u32_u24_e32 v63, s7, v52                             // 0000009B620C: 167E6807
	v_mul_u32_u24_e32 v52, s21, v52                            // 0000009B6210: 16686815
	v_and_b32_e32 v60, 0xffff, v62                             // 0000009B6214: 36787CFF 0000FFFF
	v_sad_u8 v62, v64, 0, 0x6400                               // 0000009B621C: D622003E 03FD0140 00006400
	v_lshl_add_u32 v52, v52, 24, v63                           // 0000009B6228: D6460034 04FD3134
	v_pk_fma_f16 v56, v56, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6230: CC0E0038 0BFC2D38 0000C931
	v_pk_fma_f16 v51, v51, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B623C: CC0E0033 0BFC2D33 0000C931
	v_lshl_or_b32 v60, v61, 16, v60                            // 0000009B6248: D656003C 04F1213D
	v_and_b32_e32 v61, 0xffff, v62                             // 0000009B6250: 367A7CFF 0000FFFF
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009B6258: D6220034 03FD0134 00006400
	v_dot2acc_f32_f16 v15, v56, v1                             // 0000009B6264: 041E0338
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009B6268: D6220036 03FD0136 00006400
	v_pk_fma_f16 v55, v60, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6274: CC0E0037 0BFC2D3C 0000C931
	v_alignbit_b32 v49, v49, v50, 16                           // 0000009B6280: D6160031 02426531
	v_lshl_or_b32 v52, v52, 16, v61                            // 0000009B6288: D6560034 04F52134
	v_dot2acc_f32_f16 v15, v51, v2                             // 0000009B6290: 041E0533
	v_lshl_or_b32 v54, v54, 16, v59                            // 0000009B6294: D6560036 04ED2136
	v_alignbit_b32 v46, v46, v47, 16                           // 0000009B629C: D616002E 02425F2E
	v_alignbit_b32 v43, v43, v44, 16                           // 0000009B62A4: D616002B 0242592B
	v_pk_fma_f16 v50, v52, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B62AC: CC0E0032 0BFC2D34 0000C931
	v_dot2acc_f32_f16 v15, v55, v3                             // 0000009B62B8: 041E0737
	v_pk_fma_f16 v51, v54, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B62BC: CC0E0033 0BFC2D36 0000C931
	v_bfe_u32 v52, v49, 12, 16                                 // 0000009B62C8: D6100034 02411931
	v_mul_u32_u24_e32 v53, s7, v52                             // 0000009B62D0: 166A6807
	v_mul_u32_u24_e32 v52, s21, v52                            // 0000009B62D4: 16686815
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B62D8: BF870001
	v_lshl_add_u32 v52, v52, 24, v53                           // 0000009B62DC: D6460034 04D53134
	v_dot2acc_f32_f16 v15, v50, v4                             // 0000009B62E4: 041E0932
	v_bfe_u32 v50, v49, 8, 16                                  // 0000009B62E8: D6100032 02411131
	v_dot2acc_f32_f16 v16, v51, v4                             // 0000009B62F0: 04200933
	v_bfe_u32 v51, v49, 4, 16                                  // 0000009B62F4: D6100033 02410931
	v_mul_u32_u24_e32 v56, s7, v50                             // 0000009B62FC: 16706407
	v_mul_u32_u24_e32 v50, s21, v50                            // 0000009B6300: 16646415
	v_lshl_add_u32 v50, v50, 24, v56                           // 0000009B6304: D6460032 04E13132
	v_mul_u32_u24_e32 v56, s7, v51                             // 0000009B630C: 16706607
	v_mul_u32_u24_e32 v51, s21, v51                            // 0000009B6310: 16666615
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009B6314: D6220034 03FD0134 00006400
	v_lshl_add_u32 v51, v51, 24, v56                           // 0000009B6320: D6460033 04E13133
	s_waitcnt vmcnt(3)                                         // 0000009B6328: BF890FF7
	v_bfe_u32 v53, v48, 12, 16                                 // 0000009B632C: D6100035 02411930
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009B6334: 366262FF 0000FFFF
	v_mul_u32_u24_e32 v56, s7, v53                             // 0000009B633C: 16706A07
	v_mul_u32_u24_e32 v53, s21, v53                            // 0000009B6340: 166A6A15
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B6344: BF870002
	v_lshl_add_u32 v53, v53, 24, v56                           // 0000009B6348: D6460035 04E13135
	v_mul_u32_u24_e32 v56, s7, v49                             // 0000009B6350: 16706207
	v_mul_u32_u24_e32 v49, s21, v49                            // 0000009B6354: 16626215
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009B6358: 366868FF 0000FFFF
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009B6360: D6220032 03FD0132 00006400
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009B636C: D6220033 03FD0133 00006400
	v_lshl_add_u32 v49, v49, 24, v56                           // 0000009B6378: D6460031 04E13131
	v_bfe_u32 v54, v48, 8, 16                                  // 0000009B6380: D6100036 02411130
	v_mul_u32_u24_e32 v56, s7, v54                             // 0000009B6388: 16706C07
	v_mul_u32_u24_e32 v54, s21, v54                            // 0000009B638C: 166C6C15
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009B6390: D6220035 03FD0135 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B639C: BF870002
	v_lshl_add_u32 v54, v54, 24, v56                           // 0000009B63A0: D6460036 04E13136
	v_and_b32_e32 v51, 0xffff, v51                             // 0000009B63A8: 366666FF 0000FFFF
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009B63B0: D6220031 03FD0131 00006400
	v_lshl_or_b32 v50, v50, 16, v52                            // 0000009B63BC: D6560032 04D12132
	v_and_b32_e32 v53, 0xffff, v53                             // 0000009B63C4: 366A6AFF 0000FFFF
	v_sad_u8 v54, v54, 0, 0x6400                               // 0000009B63CC: D6220036 03FD0136 00006400
	v_bfe_u32 v55, v48, 4, 16                                  // 0000009B63D8: D6100037 02410930
	v_lshl_or_b32 v49, v49, 16, v51                            // 0000009B63E0: D6560031 04CD2131
	v_pk_fma_f16 v50, v50, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B63E8: CC0E0032 0BFC2D32 0000C931
	v_mul_u32_u24_e32 v56, s7, v55                             // 0000009B63F4: 16706E07
	v_mul_u32_u24_e32 v55, s21, v55                            // 0000009B63F8: 166E6E15
	v_lshl_add_u32 v55, v55, 24, v56                           // 0000009B63FC: D6460037 04E13137
	v_lshl_or_b32 v51, v54, 16, v53                            // 0000009B6404: D6560033 04D52136
	v_pk_fma_f16 v47, v49, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B640C: CC0E002F 0BFC2D31 0000C931
	v_dual_dot2acc_f32_f16 v13, v50, v1 :: v_dual_and_b32 v48, 0xffff, v48// 0000009B6418: CB240332 0D3060FF 0000FFFF
	v_mul_u32_u24_e32 v56, s7, v48                             // 0000009B6424: 16706007
	v_mul_u32_u24_e32 v48, s21, v48                            // 0000009B6428: 16606015
	v_sad_u8 v55, v55, 0, 0x6400                               // 0000009B642C: D6220037 03FD0137 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 0000009B6438: BF870002
	v_lshl_add_u32 v48, v48, 24, v56                           // 0000009B643C: D6460030 04E13130
	v_pk_fma_f16 v49, v51, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6444: CC0E0031 0BFC2D33 0000C931
	v_dot2acc_f32_f16 v13, v47, v2                             // 0000009B6450: 041A052F
	v_bfe_u32 v50, v46, 12, 16                                 // 0000009B6454: D6100032 0241192E
	v_mul_u32_u24_e32 v56, s7, v50                             // 0000009B645C: 16706407
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009B6460: D6220030 03FD0130 00006400
	v_mul_u32_u24_e32 v50, s21, v50                            // 0000009B646C: 16646415
	v_dot2acc_f32_f16 v13, v49, v3                             // 0000009B6470: 041A0731
	v_and_b32_e32 v52, 0xffff, v55                             // 0000009B6474: 36686EFF 0000FFFF
	v_lshl_add_u32 v50, v50, 24, v56                           // 0000009B647C: D6460032 04E13132
	v_bfe_u32 v51, v46, 8, 16                                  // 0000009B6484: D6100033 0241112E
	s_waitcnt vmcnt(2)                                         // 0000009B648C: BF890BF7
	v_bfe_u32 v53, v45, 12, 16                                 // 0000009B6490: D6100035 0241192D
	v_bfe_u32 v54, v45, 8, 16                                  // 0000009B6498: D6100036 0241112D
	v_lshl_or_b32 v48, v48, 16, v52                            // 0000009B64A0: D6560030 04D12130
	v_bfe_u32 v52, v46, 4, 16                                  // 0000009B64A8: D6100034 0241092E
	v_mul_u32_u24_e32 v56, s7, v52                             // 0000009B64B0: 16706807
	v_mul_u32_u24_e32 v52, s21, v52                            // 0000009B64B4: 16686815
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B64B8: BF870001
	v_lshl_add_u32 v52, v52, 24, v56                           // 0000009B64BC: D6460034 04E13134
	v_mul_u32_u24_e32 v56, s7, v51                             // 0000009B64C4: 16706607
	v_mul_u32_u24_e32 v51, s21, v51                            // 0000009B64C8: 16666615
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009B64CC: D6220032 03FD0132 00006400
	v_lshl_add_u32 v51, v51, 24, v56                           // 0000009B64D8: D6460033 04E13133
	v_and_b32_e32 v46, 0xffff, v46                             // 0000009B64E0: 365C5CFF 0000FFFF
	v_mul_u32_u24_e32 v56, s7, v46                             // 0000009B64E8: 16705C07
	v_mul_u32_u24_e32 v46, s21, v46                            // 0000009B64EC: 165C5C15
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B64F0: BF870001
	v_lshl_add_u32 v46, v46, 24, v56                           // 0000009B64F4: D646002E 04E1312E
	v_mul_u32_u24_e32 v56, s7, v53                             // 0000009B64FC: 16706A07
	v_mul_u32_u24_e32 v53, s21, v53                            // 0000009B6500: 166A6A15
	v_sad_u8 v52, v52, 0, 0x6400                               // 0000009B6504: D6220034 03FD0134 00006400
	v_lshl_add_u32 v53, v53, 24, v56                           // 0000009B6510: D6460035 04E13135
	v_and_b32_e32 v50, 0xffff, v50                             // 0000009B6518: 366464FF 0000FFFF
	v_sad_u8 v51, v51, 0, 0x6400                               // 0000009B6520: D6220033 03FD0133 00006400
	v_mul_u32_u24_e32 v56, s7, v54                             // 0000009B652C: 16706C07
	v_mul_u32_u24_e32 v54, s21, v54                            // 0000009B6530: 166C6C15
	v_and_b32_e32 v52, 0xffff, v52                             // 0000009B6534: 366868FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 0000009B653C: D622002E 03FD012E 00006400
	v_sad_u8 v53, v53, 0, 0x6400                               // 0000009B6548: D6220035 03FD0135 00006400
	v_lshl_add_u32 v54, v54, 24, v56                           // 0000009B6554: D6460036 04E13136
	v_lshl_or_b32 v50, v51, 16, v50                            // 0000009B655C: D6560032 04C92133
	v_bfe_u32 v55, v45, 4, 16                                  // 0000009B6564: D6100037 0241092D
	v_mul_u32_u24_e32 v56, s7, v55                             // 0000009B656C: 16706E07
	v_mul_u32_u24_e32 v55, s21, v55                            // 0000009B6570: 166E6E15
	v_lshl_or_b32 v46, v46, 16, v52                            // 0000009B6574: D656002E 04D1212E
	v_and_b32_e32 v51, 0xffff, v53                             // 0000009B657C: 36666AFF 0000FFFF
	v_sad_u8 v52, v54, 0, 0x6400                               // 0000009B6584: D6220034 03FD0136 00006400
	v_pk_fma_f16 v50, v50, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6590: CC0E0032 0BFC2D32 0000C931
	v_lshl_add_u32 v55, v55, 24, v56                           // 0000009B659C: D6460037 04E13137
	v_and_b32_e32 v45, 0xffff, v45                             // 0000009B65A4: 365A5AFF 0000FFFF
	v_mul_u32_u24_e32 v54, s7, v45                             // 0000009B65AC: 166C5A07
	v_mul_u32_u24_e32 v45, s21, v45                            // 0000009B65B0: 165A5A15
	v_pk_fma_f16 v46, v46, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B65B4: CC0E002E 0BFC2D2E 0000C931
	v_lshl_or_b32 v51, v52, 16, v51                            // 0000009B65C0: D6560033 04CD2134
	v_dot2acc_f32_f16 v12, v50, v1                             // 0000009B65C8: 04180332
	v_sad_u8 v53, v55, 0, 0x6400                               // 0000009B65CC: D6220035 03FD0137 00006400
	v_lshl_add_u32 v45, v45, 24, v54                           // 0000009B65D8: D646002D 04D9312D
	v_bfe_u32 v47, v43, 12, 16                                 // 0000009B65E0: D610002F 0241192B
	v_pk_fma_f16 v44, v51, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B65E8: CC0E002C 0BFC2D33 0000C931
	v_dot2acc_f32_f16 v12, v46, v2                             // 0000009B65F4: 0418052E
	v_and_b32_e32 v52, 0xffff, v53                             // 0000009B65F8: 36686AFF 0000FFFF
	v_sad_u8 v45, v45, 0, 0x6400                               // 0000009B6600: D622002D 03FD012D 00006400
	v_pk_fma_f16 v46, v48, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B660C: CC0E002E 0BFC2D30 0000C931
	v_mul_u32_u24_e32 v48, s7, v47                             // 0000009B6618: 16605E07
	v_mul_u32_u24_e32 v47, s21, v47                            // 0000009B661C: 165E5E15
	v_lshl_add_u32 v47, v47, 24, v48                           // 0000009B6620: D646002F 04C1312F
	v_dot2acc_f32_f16 v12, v44, v3                             // 0000009B6628: 0418072C
	v_bfe_u32 v44, v43, 8, 16                                  // 0000009B662C: D610002C 0241112B
	v_lshl_or_b32 v45, v45, 16, v52                            // 0000009B6634: D656002D 04D1212D
	v_mul_u32_u24_e32 v52, s7, v44                             // 0000009B663C: 16685807
	v_mul_u32_u24_e32 v44, s21, v44                            // 0000009B6640: 16585815
	v_bfe_u32 v48, v43, 4, 16                                  // 0000009B6644: D6100030 0241092B
	v_sad_u8 v47, v47, 0, 0x6400                               // 0000009B664C: D622002F 03FD012F 00006400
	v_lshl_add_u32 v44, v44, 24, v52                           // 0000009B6658: D646002C 04D1312C
	s_waitcnt vmcnt(1)                                         // 0000009B6660: BF8907F7
	v_bfe_u32 v49, v26, 12, 16                                 // 0000009B6664: D6100031 0241191A
	v_mul_u32_u24_e32 v52, s7, v48                             // 0000009B666C: 16686007
	v_mul_u32_u24_e32 v48, s21, v48                            // 0000009B6670: 16606015
	v_lshl_add_u32 v48, v48, 24, v52                           // 0000009B6674: D6460030 04D13130
	v_mul_u32_u24_e32 v52, s7, v49                             // 0000009B667C: 16686207
	v_mul_u32_u24_e32 v49, s21, v49                            // 0000009B6680: 16626215
	v_lshl_add_u32 v49, v49, 24, v52                           // 0000009B6684: D6460031 04D13131
	v_and_b32_e32 v43, 0xffff, v43                             // 0000009B668C: 365656FF 0000FFFF
	v_and_b32_e32 v47, 0xffff, v47                             // 0000009B6694: 365E5EFF 0000FFFF
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009B669C: D622002C 03FD012C 00006400
	v_bfe_u32 v50, v26, 8, 16                                  // 0000009B66A8: D6100032 0241111A
	v_mul_u32_u24_e32 v52, s7, v43                             // 0000009B66B0: 16685607
	v_mul_u32_u24_e32 v43, s21, v43                            // 0000009B66B4: 16565615
	v_lshl_add_u32 v43, v43, 24, v52                           // 0000009B66B8: D646002B 04D1312B
	v_mul_u32_u24_e32 v52, s7, v50                             // 0000009B66C0: 16686407
	v_mul_u32_u24_e32 v50, s21, v50                            // 0000009B66C4: 16646415
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009B66C8: D6220030 03FD0130 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009B66D4: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v52                           // 0000009B66E0: D6460032 04D13132
	v_lshl_or_b32 v44, v44, 16, v47                            // 0000009B66E8: D656002C 04BD212C
	v_bfe_u32 v51, v26, 4, 16                                  // 0000009B66F0: D6100033 0241091A
	v_and_b32_e32 v47, 0xffff, v48                             // 0000009B66F8: 365E60FF 0000FFFF
	v_and_b32_e32 v48, 0xffff, v49                             // 0000009B6700: 366062FF 0000FFFF
	v_sad_u8 v49, v50, 0, 0x6400                               // 0000009B6708: D6220031 03FD0132 00006400
	v_mul_u32_u24_e32 v50, s7, v51                             // 0000009B6714: 16646607
	v_sad_u8 v43, v43, 0, 0x6400                               // 0000009B6718: D622002B 03FD012B 00006400
	v_mul_u32_u24_e32 v51, s21, v51                            // 0000009B6724: 16666615
	v_lshl_add_u32 v50, v51, 24, v50                           // 0000009B6728: D6460032 04C93133
	v_pk_fma_f16 v44, v44, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6730: CC0E002C 0BFC2D2C 0000C931
	v_alignbit_b32 v22, v22, v24, 16                           // 0000009B673C: D6160016 02423116
	v_and_b32_e32 v26, 0xffff, v26                             // 0000009B6744: 363434FF 0000FFFF
	v_lshl_or_b32 v43, v43, 16, v47                            // 0000009B674C: D656002B 04BD212B
	v_lshl_or_b32 v47, v49, 16, v48                            // 0000009B6754: D656002F 04C12131
	v_sad_u8 v48, v50, 0, 0x6400                               // 0000009B675C: D6220030 03FD0132 00006400
	v_mul_u32_u24_e32 v49, s7, v26                             // 0000009B6768: 16623407
	v_mul_u32_u24_e32 v26, s21, v26                            // 0000009B676C: 16343415
	v_dot2acc_f32_f16 v11, v44, v1                             // 0000009B6770: 0416032C
	v_bfe_u32 v44, v22, 12, 16                                 // 0000009B6774: D610002C 02411916
	v_lshl_add_u32 v26, v26, 24, v49                           // 0000009B677C: D646001A 04C5311A
	v_bfe_u32 v49, v22, 4, 16                                  // 0000009B6784: D6100031 02410916
	v_mul_u32_u24_e32 v53, s7, v44                             // 0000009B678C: 166A5807
	v_mul_u32_u24_e32 v44, s21, v44                            // 0000009B6790: 16585815
	v_lshl_add_u32 v44, v44, 24, v53                           // 0000009B6794: D646002C 04D5312C
	v_mul_u32_u24_e32 v53, s7, v49                             // 0000009B679C: 166A6207
	v_mul_u32_u24_e32 v49, s21, v49                            // 0000009B67A0: 16626215
	v_lshl_add_u32 v49, v49, 24, v53                           // 0000009B67A4: D6460031 04D53131
	v_pk_fma_f16 v24, v47, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B67AC: CC0E0018 0BFC2D2F 0000C931
	v_and_b32_e32 v47, 0xffff, v48                             // 0000009B67B8: 365E60FF 0000FFFF
	v_bfe_u32 v48, v22, 8, 16                                  // 0000009B67C0: D6100030 02411116
	v_and_b32_e32 v22, 0xffff, v22                             // 0000009B67C8: 362C2CFF 0000FFFF
	v_mul_u32_u24_e32 v53, s7, v48                             // 0000009B67D0: 166A6007
	v_mul_u32_u24_e32 v48, s21, v48                            // 0000009B67D4: 16606015
	s_waitcnt vmcnt(0)                                         // 0000009B67D8: BF8903F7
	v_bfe_u32 v50, v19, 12, 16                                 // 0000009B67DC: D6100032 02411913
	v_lshl_add_u32 v48, v48, 24, v53                           // 0000009B67E4: D6460030 04D53130
	v_mul_u32_u24_e32 v53, s7, v22                             // 0000009B67EC: 166A2C07
	v_mul_u32_u24_e32 v22, s21, v22                            // 0000009B67F0: 162C2C15
	v_lshl_add_u32 v22, v22, 24, v53                           // 0000009B67F4: D6460016 04D53116
	v_mul_u32_u24_e32 v53, s7, v50                             // 0000009B67FC: 166A6407
	v_mul_u32_u24_e32 v50, s21, v50                            // 0000009B6800: 16646415
	v_sad_u8 v44, v44, 0, 0x6400                               // 0000009B6804: D622002C 03FD012C 00006400
	v_sad_u8 v49, v49, 0, 0x6400                               // 0000009B6810: D6220031 03FD0131 00006400
	v_lshl_add_u32 v50, v50, 24, v53                           // 0000009B681C: D6460032 04D53132
	v_bfe_u32 v51, v19, 8, 16                                  // 0000009B6824: D6100033 02411113
	v_mul_u32_u24_e32 v53, s7, v51                             // 0000009B682C: 166A6607
	v_mul_u32_u24_e32 v51, s21, v51                            // 0000009B6830: 16666615
	v_and_b32_e32 v44, 0xffff, v44                             // 0000009B6834: 365858FF 0000FFFF
	v_sad_u8 v48, v48, 0, 0x6400                               // 0000009B683C: D6220030 03FD0130 00006400
	v_and_b32_e32 v49, 0xffff, v49                             // 0000009B6848: 366262FF 0000FFFF
	v_sad_u8 v22, v22, 0, 0x6400                               // 0000009B6850: D6220016 03FD0116 00006400
	v_sad_u8 v50, v50, 0, 0x6400                               // 0000009B685C: D6220032 03FD0132 00006400
	v_lshl_add_u32 v51, v51, 24, v53                           // 0000009B6868: D6460033 04D53133
	v_lshl_or_b32 v44, v48, 16, v44                            // 0000009B6870: D656002C 04B12130
	v_bfe_u32 v52, v19, 4, 16                                  // 0000009B6878: D6100034 02410913
	v_lshl_or_b32 v22, v22, 16, v49                            // 0000009B6880: D6560016 04C52116
	v_dual_mov_b32 v55, v32 :: v_dual_and_b32 v48, 0xffff, v50 // 0000009B6888: CA240120 373064FF 0000FFFF
	v_sad_u8 v49, v51, 0, 0x6400                               // 0000009B6894: D6220031 03FD0133 00006400
	v_sad_u8 v26, v26, 0, 0x6400                               // 0000009B68A0: D622001A 03FD011A 00006400
	v_mul_u32_u24_e32 v53, s7, v52                             // 0000009B68AC: 166A6807
	v_mul_u32_u24_e32 v52, s21, v52                            // 0000009B68B0: 16686815
	v_pk_fma_f16 v44, v44, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B68B4: CC0E002C 0BFC2D2C 0000C931
	v_lshl_or_b32 v48, v49, 16, v48                            // 0000009B68C0: D6560030 04C12131
	v_lshl_add_u32 v52, v52, 24, v53                           // 0000009B68C8: D6460034 04D53134
	v_and_b32_e32 v19, 0xffff, v19                             // 0000009B68D0: 362626FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B68D8: BF870004
	v_dual_dot2acc_f32_f16 v13, v46, v4 :: v_dual_dot2acc_f32_f16 v14, v44, v1// 0000009B68DC: CB18092E 0D0E032C
	v_mov_b32_e32 v46, v29                                     // 0000009B68E4: 7E5C031D
	v_lshl_or_b32 v1, v26, 16, v47                             // 0000009B68E8: D6560001 04BD211A
	v_pk_fma_f16 v26, v48, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B68F0: CC0E001A 0BFC2D30 0000C931
	v_mov_b32_e32 v48, v38                                     // 0000009B68FC: 7E600326
	v_mul_u32_u24_e32 v51, s7, v19                             // 0000009B6900: 16662607
	v_mul_u32_u24_e32 v19, s21, v19                            // 0000009B6904: 16262615
	v_sad_u8 v50, v52, 0, 0x6400                               // 0000009B6908: D6220032 03FD0134 00006400
	v_lshl_add_u32 v19, v19, 24, v51                           // 0000009B6914: D6460013 04CD3113
	v_pk_fma_f16 v43, v43, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B691C: CC0E002B 0BFC2D2B 0000C931
	v_pk_fma_f16 v22, v22, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6928: CC0E0016 0BFC2D16 0000C931
	v_dual_mov_b32 v54, v40 :: v_dual_add_nc_u32 v5, 1, v5     // 0000009B6934: CA200128 36040A81
	v_dual_mov_b32 v52, v39 :: v_dual_and_b32 v49, 0xffff, v50 // 0000009B693C: CA240127 343064FF 0000FFFF
	v_sad_u8 v19, v19, 0, 0x6400                               // 0000009B6948: D6220013 03FD0113 00006400
	v_dot2acc_f32_f16 v11, v43, v2                             // 0000009B6954: 0416052B
	v_dot2acc_f32_f16 v14, v22, v2                             // 0000009B6958: 041C0516
	v_pk_fma_f16 v58, v58, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B695C: CC0E003A 0BFC2D3A 0000C931
	v_pk_fma_f16 v45, v45, s22, 0xc931 op_sel_hi:[1,0,0]       // 0000009B6968: CC0E002D 0BFC2D2D 0000C931
	v_lshl_or_b32 v19, v19, 16, v49                            // 0000009B6974: D6560013 04C52113
	v_dot2acc_f32_f16 v11, v24, v3                             // 0000009B697C: 04160718
	v_dual_dot2acc_f32_f16 v14, v26, v3 :: v_dual_add_nc_u32 v3, v20, v5// 0000009B6980: CB20071A 0E020B14
	v_pk_fma_f16 v1, v1, s22, 0xc931 op_sel_hi:[1,0,0]         // 0000009B6988: CC0E0001 0BFC2D01 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B6994: BF870224
	v_pk_fma_f16 v2, v19, s22, 0xc931 op_sel_hi:[1,0,0]        // 0000009B6998: CC0E0002 0BFC2D13 0000C931
	v_dual_dot2acc_f32_f16 v17, v58, v4 :: v_dual_mov_b32 v58, v41// 0000009B69A4: CB10093A 113A0129
	v_cmp_eq_u32_e32 vcc_lo, 6, v3                             // 0000009B69AC: 7C940686
	v_dot2acc_f32_f16 v12, v45, v4                             // 0000009B69B0: 0418092D
	v_dot2acc_f32_f16 v11, v1, v4                              // 0000009B69B4: 04160901
	v_dual_dot2acc_f32_f16 v14, v2, v4 :: v_dual_add_nc_u32 v23, 32, v23// 0000009B69B8: CB200902 0E162EA0
	v_dual_mov_b32 v56, v40 :: v_dual_mov_b32 v19, v34         // 0000009B69C0: CA100128 38120122
	v_mov_b32_e32 v24, v34                                     // 0000009B69C8: 7E300322
	v_mov_b32_e32 v22, v27                                     // 0000009B69CC: 7E2C031B
	v_mov_b32_e32 v26, v36                                     // 0000009B69D0: 7E340324
	v_mov_b32_e32 v44, v36                                     // 0000009B69D4: 7E580324
	v_mov_b32_e32 v43, v28                                     // 0000009B69D8: 7E56031C
	v_mov_b32_e32 v45, v37                                     // 0000009B69DC: 7E5A0325
	v_dual_mov_b32 v47, v37 :: v_dual_mov_b32 v50, v38         // 0000009B69E0: CA100125 2F320126
	v_mov_b32_e32 v49, v30                                     // 0000009B69E8: 7E62031E
	v_mov_b32_e32 v53, v39                                     // 0000009B69EC: 7E6A0327
	v_mov_b32_e32 v51, v31                                     // 0000009B69F0: 7E66031F
	v_dual_mov_b32 v59, v41 :: v_dual_mov_b32 v60, v42         // 0000009B69F4: CA100129 3B3C012A
	v_dual_mov_b32 v57, v35 :: v_dual_mov_b32 v2, v42          // 0000009B69FC: CA100123 3902012A
	v_mov_b32_e32 v1, v33                                      // 0000009B6A04: 7E020321
	s_or_b32 s6, vcc_lo, s6                                    // 0000009B6A08: 8C06066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B6A0C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000009B6A10: 917E067E
	s_cbranch_execz 55                                         // 0000009B6A14: BFA50037 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x11f4>
	s_mov_b32 s23, exec_lo                                     // 0000009B6A18: BE97007E
	.long 0xd4c9007e                                           // 0000009B6A1C: D4C9007E
	v_cndmask_b32_e32 v1, v5, v10, vcc_lo                      // 0000009B6A20: 02021505
	s_cbranch_execz 64626                                      // 0000009B6A24: BFA5FC72 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f0>
	.long 0xd73c0003                                           // 0000009B6A28: D73C0003
	v_cndmask_b32_e32 v1, 10, v5, vcc_lo                       // 0000009B6A2C: 02020A8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B6A30: BF870091
	.long 0xd7006a1b                                           // 0000009B6A34: D7006A1B
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000009B6A38: 02020604
	v_add_co_ci_u32_e64 v28, null, s5, v4, vcc_lo              // 0000009B6A3C: D5207C1C 01AA0805
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B6A44: BF870092
	.long 0xd7006a03                                           // 0000009B6A48: D7006A03
	v_cndmask_b32_e32 v1, v27, v25, vcc_lo                     // 0000009B6A4C: 0202331B
	v_add_co_ci_u32_e64 v4, null, 0, v28, vcc_lo               // 0000009B6A50: D5207C04 01AA3880
	.long 0xd7006a3d                                           // 0000009B6A58: D7006A3D
	v_cndmask_b32_e32 v1, v27, v21, vcc_lo                     // 0000009B6A5C: 02022B1B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B6A60: BF870001
	v_add_co_ci_u32_e64 v62, null, 0, v28, vcc_lo              // 0000009B6A64: D5207C3E 01AA3880
	s_clause 0xf                                               // 0000009B6A6C: BF85000F
	global_load_b32 v33, v[3:4], off                           // 0000009B6A70: DC520000 217C0003
	global_load_b32 v35, v[3:4], off offset:128                // 0000009B6A78: DC520080 237C0003
	global_load_b32 v32, v[3:4], off offset:256                // 0000009B6A80: DC520100 207C0003
	global_load_b32 v31, v[3:4], off offset:384                // 0000009B6A88: DC520180 1F7C0003
	global_load_b32 v30, v[3:4], off offset:512                // 0000009B6A90: DC520200 1E7C0003
	global_load_b32 v29, v[3:4], off offset:640                // 0000009B6A98: DC520280 1D7C0003
	global_load_b32 v28, v[3:4], off offset:768                // 0000009B6AA0: DC520300 1C7C0003
	global_load_b32 v27, v[3:4], off offset:896                // 0000009B6AA8: DC520380 1B7C0003
	global_load_b32 v42, v[61:62], off                         // 0000009B6AB0: DC520000 2A7C003D
	global_load_b32 v41, v[61:62], off offset:128              // 0000009B6AB8: DC520080 297C003D
	global_load_b32 v40, v[61:62], off offset:256              // 0000009B6AC0: DC520100 287C003D
	global_load_b32 v39, v[61:62], off offset:384              // 0000009B6AC8: DC520180 277C003D
	global_load_b32 v38, v[61:62], off offset:512              // 0000009B6AD0: DC520200 267C003D
	global_load_b32 v37, v[61:62], off offset:640              // 0000009B6AD8: DC520280 257C003D
	global_load_b32 v36, v[61:62], off offset:768              // 0000009B6AE0: DC520300 247C003D
	global_load_b32 v34, v[61:62], off offset:896              // 0000009B6AE8: DC520380 227C003D
	s_branch 64575                                             // 0000009B6AF0: BFA0FC3F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2f0>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000009B6AF4: 8C7E067E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B6AF8: BF870009
	s_or_b32 exec_lo, exec_lo, s3                              // 0000009B6AFC: 8C7E037E
	s_load_b128 s[4:7], s[0:1], 0x40                           // 0000009B6B00: F4080100 F8000040
	s_waitcnt vmcnt(15)                                        // 0000009B6B08: BF893FF7
	v_dual_mov_b32 v1, v18 :: v_dual_mov_b32 v2, v17           // 0000009B6B0C: CA100112 01020111
	v_dual_mov_b32 v3, v16 :: v_dual_mov_b32 v10, v15          // 0000009B6B14: CA100110 030A010F
	v_dual_mov_b32 v4, v13 :: v_dual_mov_b32 v5, v12           // 0000009B6B1C: CA10010D 0404010C
	s_waitcnt vmcnt(0)                                         // 0000009B6B24: BF8903F7
	v_dual_mov_b32 v6, v11 :: v_dual_mov_b32 v19, v14          // 0000009B6B28: CA10010B 0612010E
	s_mov_b32 s0, 0x76543210                                   // 0000009B6B30: BE8000FF 76543210
	v_cmp_gt_u32_e32 vcc_lo, 16, v9                            // 0000009B6B38: 7C981290
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 0000009B6B3C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 0000009B6B48: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 0000009B6B54: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 0000009B6B60: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 0000009B6B6C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 0000009B6B78: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 0000009B6B84: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 0000009B6B90: D65C0013 03FC0113 FEDCBA98
	s_waitcnt lgkmcnt(0)                                       // 0000009B6B9C: BF89FC07
	s_barrier                                                  // 0000009B6BA0: BFBD0000
	buffer_gl0_inv                                             // 0000009B6BA4: E0AC0000 00000000
	s_and_saveexec_b32 s0, vcc_lo                              // 0000009B6BAC: BE80206A
	s_cbranch_execz 18                                         // 0000009B6BB0: BFA50012 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x12fc>
	v_dual_add_f32 v9, v14, v19 :: v_dual_add_f32 v2, v17, v2  // 0000009B6BB4: C908270E 09020511
	v_dual_add_f32 v1, v18, v1 :: v_dual_add_f32 v10, v15, v10 // 0000009B6BBC: C9080312 010A150F
	v_lshl_or_b32 v8, v7, 9, v8                                // 0000009B6BC4: D6560008 04211307
	v_dual_add_f32 v3, v16, v3 :: v_dual_add_f32 v4, v13, v4   // 0000009B6BCC: C9080710 0304090D
	v_dual_add_f32 v5, v12, v5 :: v_dual_add_f32 v6, v11, v6   // 0000009B6BD4: C9080B0C 05060D0B
	ds_store_2addr_b32 v8, v1, v2 offset1:16                   // 0000009B6BDC: D8381000 00020108
	ds_store_2addr_b32 v8, v3, v10 offset0:32 offset1:48       // 0000009B6BE4: D8383020 000A0308
	ds_store_2addr_b32 v8, v4, v5 offset0:64 offset1:80        // 0000009B6BEC: D8385040 00050408
	ds_store_2addr_b32 v8, v6, v9 offset0:96 offset1:112       // 0000009B6BF4: D8387060 00090608
	s_or_b32 exec_lo, exec_lo, s0                              // 0000009B6BFC: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B6C00: BF870009
	s_mov_b32 s21, exec_lo                                     // 0000009B6C04: BE95007E
	s_waitcnt lgkmcnt(0)                                       // 0000009B6C08: BF89FC07
	s_barrier                                                  // 0000009B6C0C: BFBD0000
	buffer_gl0_inv                                             // 0000009B6C10: E0AC0000 00000000
	v_cmpx_eq_u32_e32 0, v7                                    // 0000009B6C18: 7D940E80
	s_cbranch_execz 513                                        // 0000009B6C1C: BFA50201 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b24>
	v_and_b32_e32 v1, 15, v0                                   // 0000009B6C20: 3602008F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B6C24: BF870001
	v_lshlrev_b32_e32 v16, 2, v1                               // 0000009B6C28: 30200282
	ds_load_2addr_b32 v[2:3], v16 offset1:16                   // 0000009B6C2C: D8DC1000 02000010
	ds_load_2addr_b32 v[4:5], v16 offset0:128 offset1:144      // 0000009B6C34: D8DC9080 04000010
	s_waitcnt lgkmcnt(1)                                       // 0000009B6C3C: BF89FC17
	v_dual_add_f32 v53, 0, v3 :: v_dual_add_f32 v52, 0, v2     // 0000009B6C40: C9080680 35340480
	v_add_nc_u32_e32 v48, 0x400, v16                           // 0000009B6C48: 4A6020FF 00000400
	v_add_nc_u32_e32 v50, 0x800, v16                           // 0000009B6C50: 4A6420FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v16                           // 0000009B6C58: 4A6620FF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000009B6C60: BF89FC07
	v_add_f32_e32 v53, v53, v5                                 // 0000009B6C64: 066A0B35
	ds_load_2addr_b32 v[6:7], v16 offset0:32 offset1:48        // 0000009B6C68: D8DC3020 06000010
	ds_load_2addr_b32 v[8:9], v16 offset0:160 offset1:176      // 0000009B6C70: D8DCB0A0 08000010
	ds_load_2addr_b32 v[10:11], v16 offset0:64 offset1:80      // 0000009B6C78: D8DC5040 0A000010
	ds_load_2addr_b32 v[12:13], v16 offset0:192 offset1:208    // 0000009B6C80: D8DCD0C0 0C000010
	ds_load_2addr_b32 v[14:15], v16 offset0:96 offset1:112     // 0000009B6C88: D8DC7060 0E000010
	ds_load_2addr_b32 v[16:17], v16 offset0:224 offset1:240    // 0000009B6C90: D8DCF0E0 10000010
	ds_load_2addr_b32 v[18:19], v48 offset1:16                 // 0000009B6C98: D8DC1000 12000030
	ds_load_2addr_b32 v[20:21], v48 offset0:128 offset1:144    // 0000009B6CA0: D8DC9080 14000030
	ds_load_2addr_b32 v[22:23], v50 offset1:16                 // 0000009B6CA8: D8DC1000 16000032
	ds_load_2addr_b32 v[24:25], v50 offset0:128 offset1:144    // 0000009B6CB0: D8DC9080 18000032
	ds_load_2addr_b32 v[26:27], v51 offset1:16                 // 0000009B6CB8: D8DC1000 1A000033
	ds_load_2addr_b32 v[28:29], v51 offset0:128 offset1:144    // 0000009B6CC0: D8DC9080 1C000033
	ds_load_2addr_b32 v[30:31], v48 offset0:32 offset1:48      // 0000009B6CC8: D8DC3020 1E000030
	ds_load_2addr_b32 v[32:33], v48 offset0:160 offset1:176    // 0000009B6CD0: D8DCB0A0 20000030
	ds_load_2addr_b32 v[34:35], v50 offset0:32 offset1:48      // 0000009B6CD8: D8DC3020 22000032
	ds_load_2addr_b32 v[36:37], v50 offset0:160 offset1:176    // 0000009B6CE0: D8DCB0A0 24000032
	ds_load_2addr_b32 v[38:39], v51 offset0:32 offset1:48      // 0000009B6CE8: D8DC3020 26000033
	ds_load_2addr_b32 v[40:41], v51 offset0:160 offset1:176    // 0000009B6CF0: D8DCB0A0 28000033
	ds_load_2addr_b32 v[42:43], v48 offset0:64 offset1:80      // 0000009B6CF8: D8DC5040 2A000030
	ds_load_2addr_b32 v[44:45], v48 offset0:192 offset1:208    // 0000009B6D00: D8DCD0C0 2C000030
	ds_load_2addr_b32 v[46:47], v50 offset0:64 offset1:80      // 0000009B6D08: D8DC5040 2E000032
	s_waitcnt lgkmcnt(20)                                      // 0000009B6D10: BF89FD47
	v_add_f32_e32 v6, 0, v6                                    // 0000009B6D14: 060C0C80
	s_waitcnt lgkmcnt(18)                                      // 0000009B6D18: BF89FD27
	v_dual_add_f32 v52, v52, v4 :: v_dual_add_f32 v11, 0, v11  // 0000009B6D1C: C9080934 340A1680
	ds_load_2addr_b32 v[2:3], v48 offset0:96 offset1:112       // 0000009B6D24: D8DC7060 02000030
	ds_load_2addr_b32 v[48:49], v48 offset0:224 offset1:240    // 0000009B6D2C: D8DCF0E0 30000030
	v_dual_add_f32 v7, 0, v7 :: v_dual_add_f32 v6, v6, v8      // 0000009B6D34: C9080E80 07061106
	s_waitcnt lgkmcnt(16)                                      // 0000009B6D3C: BF89FD07
	v_dual_add_f32 v15, 0, v15 :: v_dual_add_f32 v8, v52, v18  // 0000009B6D40: C9081E80 0F082534
	v_add_f32_e32 v10, 0, v10                                  // 0000009B6D48: 06141480
	ds_load_2addr_b32 v[4:5], v50 offset0:96 offset1:112       // 0000009B6D4C: D8DC7060 04000032
	v_add_f32_e32 v18, v53, v19                                // 0000009B6D54: 06242735
	v_dual_add_f32 v14, 0, v14 :: v_dual_add_f32 v7, v7, v9    // 0000009B6D58: C9081C80 0E061307
	s_waitcnt lgkmcnt(11)                                      // 0000009B6D60: BF89FCB7
	v_add_f32_e32 v6, v6, v30                                  // 0000009B6D64: 060C3D06
	v_add_f32_e32 v9, v10, v12                                 // 0000009B6D68: 0612190A
	v_add_f32_e32 v8, v8, v20                                  // 0000009B6D6C: 06102908
	v_add_f32_e32 v12, v11, v13                                // 0000009B6D70: 06181B0B
	v_dual_add_f32 v18, v18, v21 :: v_dual_add_f32 v7, v7, v31 // 0000009B6D74: C9082B12 12063F07
	s_waitcnt lgkmcnt(5)                                       // 0000009B6D7C: BF89FC57
	v_add_f32_e32 v9, v9, v42                                  // 0000009B6D80: 06125509
	v_dual_add_f32 v8, v8, v22 :: v_dual_add_f32 v13, v14, v16 // 0000009B6D84: C9082D08 080C210E
	v_dual_add_f32 v14, v15, v17 :: v_dual_add_f32 v15, v12, v43// 0000009B6D8C: C908230F 0E0E570C
	v_add_f32_e32 v6, v6, v32                                  // 0000009B6D94: 060C4106
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B6D98: BF870003
	v_add_f32_e32 v8, v8, v24                                  // 0000009B6D9C: 06103108
	s_waitcnt lgkmcnt(4)                                       // 0000009B6DA0: BF89FC47
	v_add_f32_e32 v19, v9, v44                                 // 0000009B6DA4: 06265909
	s_waitcnt lgkmcnt(2)                                       // 0000009B6DA8: BF89FC27
	v_add_f32_e32 v17, v14, v3                                 // 0000009B6DAC: 0622070E
	v_dual_add_f32 v18, v18, v23 :: v_dual_add_f32 v23, v15, v45// 0000009B6DB0: C9082F12 12165B0F
	v_add_f32_e32 v6, v6, v34                                  // 0000009B6DB8: 060C4506
	v_add_f32_e32 v16, v13, v2                                 // 0000009B6DBC: 0620050D
	s_waitcnt lgkmcnt(1)                                       // 0000009B6DC0: BF89FC17
	v_add_f32_e32 v17, v17, v49                                // 0000009B6DC4: 06226311
	v_dual_add_f32 v10, v18, v25 :: v_dual_add_f32 v19, v19, v46// 0000009B6DC8: C9083312 0A125D13
	v_dual_add_f32 v23, v23, v47 :: v_dual_add_f32 v6, v6, v36 // 0000009B6DD0: C9085F17 17064906
	s_waitcnt lgkmcnt(0)                                       // 0000009B6DD8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3)                            // 0000009B6DDC: BF870003
	v_add_f32_e32 v5, v17, v5                                  // 0000009B6DE0: 060A0B11
	ds_load_2addr_b32 v[2:3], v51 offset0:192 offset1:208      // 0000009B6DE4: D8DCD0C0 02000033
	ds_load_2addr_b32 v[14:15], v51 offset0:224 offset1:240    // 0000009B6DEC: D8DCF0E0 0E000033
	v_add_f32_e32 v18, v7, v33                                 // 0000009B6DF4: 06244307
	v_add_f32_e32 v6, v6, v38                                  // 0000009B6DF8: 060C4D06
	ds_load_2addr_b32 v[12:13], v51 offset0:96 offset1:112     // 0000009B6DFC: D8DC7060 0C000033
	v_add_f32_e32 v22, v6, v40                                 // 0000009B6E04: 062C5106
	ds_load_2addr_b32 v[6:7], v50 offset0:192 offset1:208      // 0000009B6E08: D8DCD0C0 06000032
	s_waitcnt lgkmcnt(0)                                       // 0000009B6E10: BF89FC07
	v_dual_add_f32 v8, v8, v26 :: v_dual_add_f32 v7, v23, v7   // 0000009B6E14: C9083508 08060F17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000009B6E1C: BF8700C1
	v_add_f32_e32 v20, v8, v28                                 // 0000009B6E20: 06283908
	ds_load_2addr_b32 v[8:9], v50 offset0:224 offset1:240      // 0000009B6E24: D8DCF0E0 08000032
	s_waitcnt lgkmcnt(0)                                       // 0000009B6E2C: BF89FC07
	v_dual_add_f32 v10, v10, v27 :: v_dual_add_f32 v5, v5, v9  // 0000009B6E30: C908370A 0A041305
	v_add_f32_e32 v21, v10, v29                                // 0000009B6E38: 062A3B0A
	ds_load_2addr_b32 v[10:11], v51 offset0:64 offset1:80      // 0000009B6E3C: D8DC5040 0A000033
	v_add_f32_e32 v5, v5, v13                                  // 0000009B6E44: 060A1B05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000009B6E48: BF8700A1
	v_dual_add_f32 v5, v5, v15 :: v_dual_add_f32 v6, v19, v6   // 0000009B6E4C: C9081F05 05060D13
	s_waitcnt lgkmcnt(0)                                       // 0000009B6E54: BF89FC07
	v_dual_add_f32 v6, v6, v10 :: v_dual_add_f32 v7, v7, v11   // 0000009B6E58: C9081506 06061707
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B6E60: BF8701B1
	v_dual_add_f32 v2, v6, v2 :: v_dual_add_f32 v3, v7, v3     // 0000009B6E64: C9080506 02020707
	v_sub_f32_e32 v7, v20, v21                                 // 0000009B6E6C: 080E2B14
	v_add_f32_e32 v6, v20, v21                                 // 0000009B6E70: 060C2B14
	v_add_f32_e32 v10, v2, v3                                  // 0000009B6E74: 06140702
	v_sub_f32_e32 v2, v2, v3                                   // 0000009B6E78: 08040702
	v_add_f32_e32 v16, v16, v48                                // 0000009B6E7C: 06206110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B6E80: BF870091
	v_add_f32_e32 v4, v16, v4                                  // 0000009B6E84: 06080910
	v_add_f32_e32 v4, v4, v8                                   // 0000009B6E88: 06081104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B6E8C: BF870091
	v_add_f32_e32 v4, v4, v12                                  // 0000009B6E90: 06081904
	v_add_f32_e32 v4, v4, v14                                  // 0000009B6E94: 06081D04
	v_add_f32_e32 v18, v18, v35                                // 0000009B6E98: 06244712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B6E9C: BF870112
	v_dual_add_f32 v11, v4, v5 :: v_dual_and_b32 v14, 1, v0    // 0000009B6EA0: C9240B04 0B0E0081
	v_add_f32_e32 v16, v18, v37                                // 0000009B6EA8: 06204B12
	v_sub_f32_e32 v3, v4, v5                                   // 0000009B6EAC: 08060B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B6EB0: BF870213
	.long 0xd44a0000                                           // 0000009B6EB4: D44A0000
	v_cndmask_b32_e32 v1, 0, v14, vcc_lo                       // 0000009B6EB8: 02021C80
	v_add_f32_e32 v5, v10, v11                                 // 0000009B6EBC: 060A170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B6EC0: BF870214
	v_add_f32_e32 v8, v16, v39                                 // 0000009B6EC4: 06104F10
	v_add_f32_e32 v13, v2, v3                                  // 0000009B6EC8: 061A0702
	v_dual_sub_f32 v2, v2, v3 :: v_dual_and_b32 v3, 2, v0      // 0000009B6ECC: C9640702 02020082
	v_sub_f32_e32 v10, v10, v11                                // 0000009B6ED4: 0814170A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B6ED8: BF870194
	v_add_f32_e32 v8, v8, v41                                  // 0000009B6EDC: 06105308
	.long 0xd44a0001                                           // 0000009B6EE0: D44A0001
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 0000009B6EE4: 02020680
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009B6EE8: BF870122
	v_add_f32_e32 v9, v22, v8                                  // 0000009B6EEC: 06121116
	v_sub_f32_e32 v8, v22, v8                                  // 0000009B6EF0: 08101116
	v_add_f32_e32 v4, v6, v9                                   // 0000009B6EF4: 06081306
	v_sub_f32_e32 v6, v6, v9                                   // 0000009B6EF8: 080C1306
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B6EFC: BF8701A2
	v_dual_add_f32 v12, v7, v8 :: v_dual_add_f32 v9, v4, v5    // 0000009B6F00: C9081107 0C080B04
	v_sub_f32_e32 v5, v4, v5                                   // 0000009B6F08: 080A0B04
	v_add_f32_e32 v3, v6, v10                                  // 0000009B6F0C: 06061506
	v_sub_f32_e32 v10, v6, v10                                 // 0000009B6F10: 08141506
	v_and_b32_e32 v6, 4, v0                                    // 0000009B6F14: 360C0084
	v_mov_b32_dpp v11, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B6F18: 7E1602FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009B6F20: D5010009 20021309
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B6F28: BF870113
	.long 0xd44a0003                                           // 0000009B6F2C: D44A0003
	v_cndmask_b32_e32 v1, 0, v6, vcc_lo                        // 0000009B6F30: 02020C80
	v_dual_add_f32 v4, v9, v11 :: v_dual_sub_f32 v9, v12, v13  // 0000009B6F34: C90A1709 04081B0C
	v_dual_sub_f32 v7, v7, v8 :: v_dual_add_f32 v8, v12, v13   // 0000009B6F3C: C9481107 07081B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B6F44: BF8701A2
	v_mov_b32_dpp v11, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B6F48: 7E1602FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 0000009B6F50: D5010004 20060904
	v_add_f32_e32 v13, v7, v2                                  // 0000009B6F58: 061A0507
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B6F5C: BF870224
	v_mov_b32_dpp v14, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B6F60: 7E1C02FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, s0                          // 0000009B6F68: D5010008 20021108
	v_dual_sub_f32 v7, v7, v2 :: v_dual_add_f32 v4, v4, v11    // 0000009B6F70: C9480507 07041704
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B6F78: BF870194
	v_mov_b32_dpp v11, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B6F7C: 7E1602FA FF01610D
	v_add_f32_e32 v8, v8, v14                                  // 0000009B6F84: 06101D08
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B6F88: BF8701A3
	v_mov_b32_dpp v6, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B6F8C: 7E0C02FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000009B6F94: D5010004 200E0904
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B6F9C: 7E1802FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009B6FA4: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000009B6FAC: BF8701C1
	v_add_f32_e32 v8, v8, v12                                  // 0000009B6FB0: 06101908
	v_cndmask_b32_e64 v12, -v13, v13, s0                       // 0000009B6FB4: D501000C 20021B0D
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B6FBC: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 0000009B6FC4: D5010003 20020703
	v_add_f32_e32 v11, v12, v11                                // 0000009B6FCC: 0616170C
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B6FD0: 7E1802FA FF016408
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000009B6FD8: BF870223
	v_add_f32_e32 v3, v3, v13                                  // 0000009B6FDC: 06061B03
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009B6FE0: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B6FE8: 7E1A02FA FF01620B
	v_cndmask_b32_e64 v11, -v11, v11, s1                       // 0000009B6FF0: D501000B 2006170B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000009B6FF8: BF870254
	v_mov_b32_dpp v14, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B6FFC: 7E1C02FA FF016203
	v_cndmask_b32_e64 v15, -v3, v3, s1                         // 0000009B7004: D501000F 20060703
	v_add_f32_e32 v3, v4, v6                                   // 0000009B700C: 06060D04
	v_add_f32_e32 v6, v8, v12                                  // 0000009B7010: 060C1908
	v_add_f32_e32 v8, v11, v13                                 // 0000009B7014: 06101B0B
	v_add_f32_e32 v11, v15, v14                                // 0000009B7018: 06161D0F
	v_mov_b32_dpp v14, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B701C: 7E1C02FA FF016105
	v_cndmask_b32_e64 v15, -v5, v5, s0                         // 0000009B7024: D501000F 20020B05
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B702C: BF870004
	v_mov_b32_dpp v12, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B7030: 7E1802FA FF016408
	v_cndmask_b32_e64 v8, -v8, v8, s3                          // 0000009B7038: D5010008 200E1108
	v_mov_b32_dpp v13, v11 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B7040: 7E1A02FA FF01640B
	v_cndmask_b32_e64 v11, -v11, v11, s3                       // 0000009B7048: D501000B 200E170B
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7050: 7E0402FA FF016803
	v_mov_b32_dpp v4, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7058: 7E0802FA FF016806
	v_add_f32_e32 v5, v8, v12                                  // 0000009B7060: 060A1908
	v_mov_b32_dpp v8, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B7064: 7E1002FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, s0                          // 0000009B706C: D5010009 20021309
	v_add_f32_e32 v12, v15, v14                                // 0000009B7074: 06181D0F
	v_mov_b32_dpp v14, v10 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B7078: 7E1C02FA FF01610A
	v_cndmask_b32_e64 v10, -v10, v10, s0                       // 0000009B7080: D501000A 2002150A
	v_mov_b32_dpp v15, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000009B7088: 7E1E02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s0                          // 0000009B7090: D5010007 20020F07
	v_add_f32_e32 v8, v9, v8                                   // 0000009B7098: 06101109
	v_mov_b32_dpp v9, v12 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B709C: 7E1202FA FF01620C
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 0000009B70A4: D501000C 2006190C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B70AC: BF870214
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v7, v7, v15 // 0000009B70B0: C9081D0A 0A061F07
	v_mov_b32_dpp v14, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B70B8: 7E1C02FA FF016208
	v_cndmask_b32_e64 v8, -v8, v8, s1                          // 0000009B70C0: D5010008 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B70C8: BF870214
	v_add_f32_e32 v9, v12, v9                                  // 0000009B70CC: 0612130C
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B70D0: 7E1802FA FF01620A
	v_mov_b32_dpp v15, v7 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000009B70D8: 7E1E02FA FF016207
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 0000009B70E0: D501000A 2006150A
	v_cndmask_b32_e64 v16, -v7, v7, s1                         // 0000009B70E8: D5010010 20060F07
	v_dual_add_f32 v8, v8, v14 :: v_dual_add_f32 v7, v11, v13  // 0000009B70F0: C9081D08 08061B0B
	v_mov_b32_dpp v11, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B70F8: 7E1602FA FF016409
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000009B7100: BF870214
	v_add_f32_e32 v10, v10, v12                                // 0000009B7104: 0614190A
	v_add_f32_e32 v12, v16, v15                                // 0000009B7108: 06181F10
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B710C: BF870004
	v_mov_b32_dpp v13, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B7110: 7E1A02FA FF016408
	v_cndmask_b32_e64 v15, -v8, v8, s3                         // 0000009B7118: D501000F 200E1108
	v_cndmask_b32_e64 v9, -v9, v9, s3                          // 0000009B7120: D5010009 200E1309
	v_mov_b32_dpp v17, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B7128: 7E2202FA FF01640A
	v_mov_b32_dpp v18, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 0000009B7130: 7E2402FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s3                       // 0000009B7138: D501000A 200E150A
	v_cndmask_b32_e64 v12, -v12, v12, s3                       // 0000009B7140: D501000C 200E190C
	v_add_f32_e32 v14, v9, v11                                 // 0000009B7148: 061C1709
	v_add_f32_e32 v16, v15, v13                                // 0000009B714C: 06201B0F
	v_mov_b32_dpp v8, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7150: 7E1002FA FF016807
	v_add_f32_e32 v15, v10, v17                                // 0000009B7158: 061E230A
	v_add_f32_e32 v17, v12, v18                                // 0000009B715C: 0622250C
	v_mov_b32_dpp v9, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7160: 7E1202FA FF016805
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7168: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7170: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7178: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000009B7180: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000009B7188: 8B7E6A7E
	s_cbranch_execz 165                                        // 0000009B718C: BFA500A5 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1b24>
	v_and_b32_e32 v26, 8, v0                                   // 0000009B7190: 36340088
	s_mul_i32 s0, s8, 0x1400                                   // 0000009B7194: 9600FF08 00001400
	s_mul_hi_i32 s1, s8, 0x1400                                // 0000009B719C: 9701FF08 00001400
	s_add_u32 s3, s10, s0                                      // 0000009B71A4: 8003000A
	s_addc_u32 s8, s11, s1                                     // 0000009B71A8: 8208010B
	v_cmp_eq_u32_e32 vcc_lo, 0, v26                            // 0000009B71AC: 7C943480
	s_lshl_b32 s0, s9, 7                                       // 0000009B71B0: 84008709
	.long 0x7f243880                                           // 0000009B71B4: 7F243880
	s_ashr_i32 s1, s0, 31                                      // 0000009B71B8: 86019F00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B71BC: BF870009
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000009B71C0: 84808100
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 0000009B71C4: D5010006 21AA0D06
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000009B71CC: 30020281
	s_add_u32 s10, s3, s0                                      // 0000009B71D0: 800A0003
	s_addc_u32 s11, s8, s1                                     // 0000009B71D4: 820B0108
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 0000009B71D8: D5010003 21AA0703
	v_add_f32_e32 v4, v6, v4                                   // 0000009B71E0: 06080906
	s_clause 0x7                                               // 0000009B71E4: BF850007
	global_load_d16_b16 v18, v1, s[10:11] offset:32            // 0000009B71E8: DC820020 120A0001
	global_load_d16_b16 v19, v1, s[10:11]                      // 0000009B71F0: DC820000 130A0001
	global_load_d16_b16 v20, v1, s[10:11] offset:64            // 0000009B71F8: DC820040 140A0001
	global_load_d16_b16 v21, v1, s[10:11] offset:96            // 0000009B7200: DC820060 150A0001
	global_load_d16_b16 v22, v1, s[10:11] offset:128           // 0000009B7208: DC820080 160A0001
	global_load_d16_b16 v23, v1, s[10:11] offset:160           // 0000009B7210: DC8200A0 170A0001
	global_load_d16_b16 v24, v1, s[10:11] offset:192           // 0000009B7218: DC8200C0 180A0001
	global_load_d16_b16 v25, v1, s[10:11] offset:224           // 0000009B7220: DC8200E0 190A0001
	v_cndmask_b32_e64 v6, -v7, v7, vcc_lo                      // 0000009B7228: D5010006 21AA0F07
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 0000009B7230: D5010005 21AA0B05
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 0000009B7238: D5010007 21AA2110
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 0000009B7240: D501000E 21AA1D0E
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 0000009B7248: D5010010 21AA2311
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v4// 0000009B7250: C9060503 020208FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B725C: BF8701B4
	v_dual_add_f32 v4, v6, v8 :: v_dual_add_f32 v7, v7, v11    // 0000009B7260: C9081106 04061707
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 0000009B7268: D501000F 21AA1F0F
	v_dual_add_f32 v5, v5, v9 :: v_dual_add_f32 v6, v14, v10   // 0000009B7270: C9081305 0506150E
	v_dual_add_f32 v9, v16, v13 :: v_dual_mul_f32 v4, 0x3db504f3, v4// 0000009B7278: C9061B10 090408FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000009B7284: BF8701B2
	v_dual_add_f32 v8, v15, v12 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 0000009B7288: C906190F 08040AFF 3DB504F3
	s_waitcnt vmcnt(5)                                         // 0000009B7294: BF8917F7
	.long 0x7f283992                                           // 0000009B7298: 7F283992
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000009B729C: 101212FF 3DB504F3
	s_waitcnt vmcnt(4)                                         // 0000009B72A4: BF8913F7
	.long 0x7f2a3992                                           // 0000009B72A8: 7F2A3992
	v_dual_mul_f32 v2, 0x3db504f3, v2 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 0000009B72AC: C8C604FF 02060EFF 3DB504F3
	.long 0x7f263992                                           // 0000009B72B8: 7F263992
	s_waitcnt vmcnt(3)                                         // 0000009B72BC: BF890FF7
	.long 0x7f2c3992                                           // 0000009B72C0: 7F2C3992
	s_mul_i32 s8, s20, 0x1400                                  // 0000009B72C4: 9608FF14 00001400
	s_mul_hi_i32 s3, s20, 0x1400                               // 0000009B72CC: 9703FF14 00001400
	s_add_u32 s8, s12, s8                                      // 0000009B72D4: 8008080C
	s_addc_u32 s3, s13, s3                                     // 0000009B72D8: 8203030D
	s_add_u32 s0, s8, s0                                       // 0000009B72DC: 80000008
	s_addc_u32 s1, s3, s1                                      // 0000009B72E0: 82010103
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000009B72E4: CC200003 8A020712
	v_fma_mix_f32 v2, v19, v2, neg(0) op_sel_hi:[1,0,0]        // 0000009B72EC: CC200002 8A020513
	v_fma_mix_f32 v4, v20, v4, neg(0) op_sel_hi:[1,0,0]        // 0000009B72F4: CC200004 8A020914
	v_fma_mix_f32 v5, v21, v5, neg(0) op_sel_hi:[1,0,0]        // 0000009B72FC: CC200005 8A020B15
	s_delay_alu instid0(VALU_DEP_4)                            // 0000009B7304: BF870004
	.long 0x7e243983                                           // 0000009B7308: 7E243983
	s_waitcnt vmcnt(2)                                         // 0000009B730C: BF890BF7
	v_fma_mix_f32 v7, v23, v7, neg(0) op_sel_hi:[1,0,0]        // 0000009B7310: CC200007 8A020F17
	.long 0x7e283984                                           // 0000009B7318: 7E283984
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 0000009B731C: 100C0CFF 3DB504F3
	s_waitcnt vmcnt(0)                                         // 0000009B7324: BF8903F7
	v_fma_mix_f32 v9, v25, v9, neg(0) op_sel_hi:[1,0,0]        // 0000009B7328: CC200009 8A021319
	v_and_b32_e32 v10, 1, v18                                  // 0000009B7330: 36142481
	.long 0x7e243985                                           // 0000009B7334: 7E243985
	v_mul_f32_e32 v8, 0x3db504f3, v8                           // 0000009B7338: 101010FF 3DB504F3
	v_and_b32_e32 v13, 1, v20                                  // 0000009B7340: 361A2881
	v_fma_mix_f32 v6, v22, v6, neg(0) op_sel_hi:[1,0,0]        // 0000009B7344: CC200006 8A020D16
	.long 0x7e263982                                           // 0000009B734C: 7E263982
	v_and_b32_e32 v11, 1, v18                                  // 0000009B7350: 36162481
	v_fma_mix_f32 v8, v24, v8, neg(0) op_sel_hi:[1,0,0]        // 0000009B7354: CC200008 8A021118
	.long 0x7e243987                                           // 0000009B735C: 7E243987
	.long 0x7e2a3986                                           // 0000009B7360: 7E2A3986
	v_and_b32_e32 v12, 1, v19                                  // 0000009B7364: 36182681
	v_add3_u32 v3, v3, v10, 0x7fff                             // 0000009B7368: D6550003 03FE1503 00007FFF
	.long 0x7e2c3988                                           // 0000009B7374: 7E2C3988
	v_and_b32_e32 v15, 1, v18                                  // 0000009B7378: 361E2481
	.long 0x7e243989                                           // 0000009B737C: 7E243989
	v_and_b32_e32 v14, 1, v21                                  // 0000009B7380: 361C2A81
	v_add3_u32 v2, v2, v12, 0x7fff                             // 0000009B7384: D6550002 03FE1902 00007FFF
	v_and_b32_e32 v16, 1, v22                                  // 0000009B7390: 36202C81
	v_add3_u32 v4, v4, v13, 0x7fff                             // 0000009B7394: D6550004 03FE1B04 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 0000009B73A0: 36142481
	v_add3_u32 v5, v5, v11, 0x7fff                             // 0000009B73A4: D6550005 03FE1705 00007FFF
	v_add3_u32 v6, v6, v14, 0x7fff                             // 0000009B73B0: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 0000009B73BC: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 0000009B73C8: D6550007 03FE1F07 00007FFF
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000009B73D4: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000009B73E0: BF850007
	global_store_d16_hi_b16 v1, v2, s[0:1]                     // 0000009B73E4: DC960000 00000201
	global_store_d16_hi_b16 v1, v3, s[0:1] offset:32           // 0000009B73EC: DC960020 00000301
	global_store_d16_hi_b16 v1, v4, s[0:1] offset:64           // 0000009B73F4: DC960040 00000401
	global_store_d16_hi_b16 v1, v5, s[0:1] offset:96           // 0000009B73FC: DC960060 00000501
	global_store_d16_hi_b16 v1, v6, s[0:1] offset:128          // 0000009B7404: DC960080 00000601
	global_store_d16_hi_b16 v1, v7, s[0:1] offset:160          // 0000009B740C: DC9600A0 00000701
	global_store_d16_hi_b16 v1, v8, s[0:1] offset:192          // 0000009B7414: DC9600C0 00000801
	global_store_d16_hi_b16 v1, v9, s[0:1] offset:224          // 0000009B741C: DC9600E0 00000901
	s_or_b32 exec_lo, exec_lo, s21                             // 0000009B7424: 8C7E157E
	s_mul_hi_i32 s0, s2, 0x51eb851f                            // 0000009B7428: 9700FF02 51EB851F
	s_waitcnt_vscnt null, 0x0                                  // 0000009B7430: BC7C0000
	buffer_gl1_inv                                             // 0000009B7434: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009B743C: E0AC0000 00000000
	s_lshr_b32 s1, s0, 31                                      // 0000009B7444: 85019F00
	s_ashr_i32 s0, s0, 6                                       // 0000009B7448: 86008600
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B744C: BF870009
	s_add_i32 s8, s0, s1                                       // 0000009B7450: 81080100
	.long 0xd44a0000                                           // 0000009B7454: D44A0000
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000009B7458: 02020080
	s_mul_i32 s1, s8, 20                                       // 0000009B745C: 96019408
	s_barrier                                                  // 0000009B7460: BFBD0000
	s_add_i32 s2, s9, s1                                       // 0000009B7464: 81020109
	buffer_gl0_inv                                             // 0000009B7468: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000009B7470: BE812000
	s_cbranch_execz 29                                         // 0000009B7474: BFA5001D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1bec>
	s_mov_b32 s11, exec_lo                                     // 0000009B7478: BE8B007E
	s_mov_b32 s10, exec_lo                                     // 0000009B747C: BE8A007E
	.long 0xd71f0001                                           // 0000009B7480: D71F0001
	v_cndmask_b32_e32 v0, s11, v128, vcc_lo                    // 0000009B7484: 0201000B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B7488: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 0000009B748C: 7D940280
	s_cbranch_execz 11                                         // 0000009B7490: BFA5000B <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x1bc0>
	s_ashr_i32 s3, s2, 31                                      // 0000009B7494: 86039F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000009B7498: BF870499
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000009B749C: 84948202
	s_add_u32 s20, s6, s20                                     // 0000009B74A0: 80141406
	s_addc_u32 s21, s7, s21                                    // 0000009B74A4: 82151507
	s_bcnt1_i32_b32 s3, s11                                    // 0000009B74A8: BE83180B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B74AC: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s3              // 0000009B74B0: CA100080 02020003
	global_atomic_add_u32 v2, v2, v3, s[20:21] glc             // 0000009B74B8: DCD64000 02140302
	s_or_b32 exec_lo, exec_lo, s10                             // 0000009B74C0: 8C7E0A7E
	s_waitcnt vmcnt(0)                                         // 0000009B74C4: BF8903F7
	v_readfirstlane_b32 s3, v2                                 // 0000009B74C8: 7E060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B74CC: BF870091
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s3, v1       // 0000009B74D0: CA200080 02000203
	v_cmp_eq_u32_e32 vcc_lo, 9, v1                             // 0000009B74D8: 7C940289
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 0000009B74DC: D5010001 01A90280
	ds_store_b32 v2, v1 offset:4096                            // 0000009B74E4: D8341000 00000102
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B74EC: 8C7E017E
	v_mov_b32_e32 v1, 0                                        // 0000009B74F0: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 0000009B74F4: BF89FC07
	s_barrier                                                  // 0000009B74F8: BFBD0000
	buffer_gl0_inv                                             // 0000009B74FC: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:4096                             // 0000009B7504: D8D81000 01000001
	s_waitcnt lgkmcnt(0)                                       // 0000009B750C: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 0000009B7510: 7C940280
	s_cbranch_vccnz 287                                        // 0000009B7514: BFA4011F <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2094>
	s_mov_b32 s1, exec_lo                                      // 0000009B7518: BE81007E
	buffer_gl1_inv                                             // 0000009B751C: E0B00000 00000000
	buffer_gl0_inv                                             // 0000009B7524: E0AC0000 00000000
	v_cmpx_gt_u32_e32 64, v0                                   // 0000009B752C: 7D9800C0
	s_cbranch_execz 269                                        // 0000009B7530: BFA5010D <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2068>
	v_lshlrev_b32_e32 v0, 1, v0                                // 0000009B7534: 30000081
	s_mul_i32 s10, s8, 10                                      // 0000009B7538: 960A8A08
	v_mov_b32_e32 v6, 0                                        // 0000009B753C: 7E0C0280
	s_ashr_i32 s11, s10, 31                                    // 0000009B7540: 860B9F0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B7544: BF870092
	v_lshl_or_b32 v0, s9, 7, v0                                // 0000009B7548: D6560000 04010E09
	v_ashrrev_i32_e32 v1, 31, v0                               // 0000009B7550: 3402009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000009B7554: BF870121
	.long 0xd73c0002                                           // 0000009B7558: D73C0002
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009B755C: 02020081
	v_mad_i64_i32 v[0:1], null, 0xa00, s8, v[0:1]              // 0000009B7560: D6FF7C00 040010FF 00000A00
	.long 0xd7006a02                                           // 0000009B756C: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000009B7570: 0202040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B7574: BF870191
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 0000009B7578: D5207C03 01AA060D
	.long 0xd73c0000                                           // 0000009B7580: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000009B7584: 02020081
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000009B7588: BF8704A2
	v_mad_i64_i32 v[2:3], null, 0x1400, s10, v[2:3]            // 0000009B758C: D6FF7C02 040814FF 00001400
	s_lshl_b64 s[10:11], s[10:11], 2                           // 0000009B7598: 848A820A
	s_add_u32 s10, s14, s10                                    // 0000009B759C: 800A0A0E
	s_addc_u32 s11, s15, s11                                   // 0000009B75A0: 820B0B0F
	s_ashr_i32 s9, s8, 31                                      // 0000009B75A4: 86099F08
	global_load_b32 v7, v6, s[10:11]                           // 0000009B75A8: DC520000 070A0006
	global_load_b32 v4, v[2:3], off glc                        // 0000009B75B0: DC524000 047C0002
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000009B75B8: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B75BC: BF870009
	s_add_u32 s8, s18, s8                                      // 0000009B75C0: 80080812
	s_addc_u32 s9, s19, s9                                     // 0000009B75C4: 82090913
	s_waitcnt vmcnt(0)                                         // 0000009B75C8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v4                               // 0000009B75CC: 30100890
	v_and_b32_e32 v9, 0xffff0000, v4                           // 0000009B75D0: 361208FF FFFF0000
	.long 0xd7006a04                                           // 0000009B75D8: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000009B75DC: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B75E4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B75E8: D5207C05 01AA0680
	v_mul_f32_e32 v8, v7, v8                                   // 0000009B75F0: 10101107
	v_mul_f32_e32 v7, v7, v9                                   // 0000009B75F4: 100E1307
	global_load_b32 v9, v6, s[10:11] offset:4                  // 0000009B75F8: DC520004 090A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009B7600: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B7608: BF8903F7
	v_dual_add_f32 v7, 0, v7 :: v_dual_lshlrev_b32 v10, 16, v4 // 0000009B760C: C9220E80 070A0890
	v_mul_f32_e32 v10, v9, v10                                 // 0000009B7614: 10141509
	v_and_b32_e32 v11, 0xffff0000, v4                          // 0000009B7618: 361608FF FFFF0000
	.long 0xd7006a04                                           // 0000009B7620: D7006A04
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000009B7624: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B762C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B7630: D5207C05 01AA0680
	v_mul_f32_e32 v9, v9, v11                                  // 0000009B7638: 10121709
	global_load_b32 v11, v6, s[10:11] offset:8                 // 0000009B763C: DC520008 0B0A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009B7644: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B764C: BF8903F7
	v_dual_add_f32 v7, v7, v9 :: v_dual_lshlrev_b32 v12, 16, v4// 0000009B7650: C9221307 070C0890
	v_and_b32_e32 v13, 0xffff0000, v4                          // 0000009B7658: 361A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B7660: D7006A04
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000009B7664: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B766C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B7670: D5207C05 01AA0680
	v_mul_f32_e32 v12, v11, v12                                // 0000009B7678: 1018190B
	v_mul_f32_e32 v11, v11, v13                                // 0000009B767C: 10161B0B
	global_load_b32 v13, v6, s[10:11] offset:12                // 0000009B7680: DC52000C 0D0A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009B7688: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B7690: BF8903F7
	v_dual_add_f32 v7, v7, v11 :: v_dual_lshlrev_b32 v14, 16, v4// 0000009B7694: C9221707 070E0890
	v_and_b32_e32 v15, 0xffff0000, v4                          // 0000009B769C: 361E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B76A4: D7006A04
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 0000009B76A8: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B76B0: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B76B4: D5207C05 01AA0680
	v_mul_f32_e32 v14, v13, v14                                // 0000009B76BC: 101C1D0D
	v_mul_f32_e32 v13, v13, v15                                // 0000009B76C0: 101A1F0D
	global_load_b32 v15, v6, s[10:11] offset:16                // 0000009B76C4: DC520010 0F0A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009B76CC: DC524000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B76D4: BF8903F7
	v_dual_add_f32 v7, v7, v13 :: v_dual_lshlrev_b32 v16, 16, v4// 0000009B76D8: C9221B07 07100890
	v_and_b32_e32 v17, 0xffff0000, v4                          // 0000009B76E0: 362208FF FFFF0000
	.long 0xd7006a04                                           // 0000009B76E8: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000009B76EC: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B76F4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B76F8: D5207C05 01AA0680
	v_mul_f32_e32 v16, v15, v16                                // 0000009B7700: 1020210F
	v_mul_f32_e32 v15, v15, v17                                // 0000009B7704: 101E230F
	global_load_b32 v17, v6, s[10:11] offset:20                // 0000009B7708: DC520014 110A0006
	global_load_b32 v4, v[4:5], off offset:1024 glc            // 0000009B7710: DC524400 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B7718: BF8903F7
	v_dual_add_f32 v7, v7, v15 :: v_dual_lshlrev_b32 v18, 16, v4// 0000009B771C: C9221F07 07120890
	v_and_b32_e32 v19, 0xffff0000, v4                          // 0000009B7724: 362608FF FFFF0000
	.long 0xd7006a04                                           // 0000009B772C: D7006A04
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000009B7730: 020204FF 00007000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B7738: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B773C: D5207C05 01AA0680
	v_mul_f32_e32 v18, v17, v18                                // 0000009B7744: 10242511
	v_mul_f32_e32 v17, v17, v19                                // 0000009B7748: 10222711
	global_load_b32 v19, v6, s[10:11] offset:24                // 0000009B774C: DC520018 130A0006
	global_load_b32 v4, v[4:5], off offset:2048 glc            // 0000009B7754: DC524800 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B775C: BF8903F7
	v_dual_add_f32 v7, v7, v17 :: v_dual_lshlrev_b32 v20, 16, v4// 0000009B7760: C9222307 07140890
	v_and_b32_e32 v21, 0xffff0000, v4                          // 0000009B7768: 362A08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B7770: D7006A04
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 0000009B7774: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B777C: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B7780: D5207C05 01AA0680
	v_mul_f32_e32 v20, v19, v20                                // 0000009B7788: 10282913
	v_mul_f32_e32 v19, v19, v21                                // 0000009B778C: 10262B13
	global_load_b32 v21, v6, s[10:11] offset:28                // 0000009B7790: DC52001C 150A0006
	global_load_b32 v4, v[4:5], off offset:3072 glc            // 0000009B7798: DC524C00 047C0004
	s_waitcnt vmcnt(0)                                         // 0000009B77A0: BF8903F7
	v_dual_add_f32 v7, v7, v19 :: v_dual_lshlrev_b32 v22, 16, v4// 0000009B77A4: C9222707 07160890
	v_and_b32_e32 v23, 0xffff0000, v4                          // 0000009B77AC: 362E08FF FFFF0000
	.long 0xd7006a04                                           // 0000009B77B4: D7006A04
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 0000009B77B8: 020204FF 0000A000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B77C0: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000009B77C4: D5207C05 01AA0680
	v_mul_f32_e32 v22, v21, v22                                // 0000009B77CC: 102C2D15
	v_mul_f32_e32 v21, v21, v23                                // 0000009B77D0: 102A2F15
	global_load_b32 v23, v6, s[10:11] offset:32                // 0000009B77D4: DC520020 170A0006
	global_load_b32 v4, v[4:5], off glc                        // 0000009B77DC: DC524000 047C0004
	.long 0xd7006a02                                           // 0000009B77E4: D7006A02
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000009B77E8: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B77F0: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000009B77F4: D5207C03 01AA0680
	v_add_f32_e32 v7, v7, v21                                  // 0000009B77FC: 060E2B07
	s_waitcnt vmcnt(0)                                         // 0000009B7800: BF8903F7
	v_lshlrev_b32_e32 v5, 16, v4                               // 0000009B7804: 300A0890
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009B7808: 360808FF FFFF0000
	v_mul_f32_e32 v5, v23, v5                                  // 0000009B7810: 100A0B17
	v_mul_f32_e32 v4, v23, v4                                  // 0000009B7814: 10080917
	global_load_b32 v23, v6, s[10:11] offset:36                // 0000009B7818: DC520024 170A0006
	global_load_b32 v2, v[2:3], off offset:1024 glc            // 0000009B7820: DC524400 027C0002
	v_add_f32_e32 v4, v7, v4                                   // 0000009B7828: 06080907
	s_waitcnt vmcnt(0)                                         // 0000009B782C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v2                              // 0000009B7830: 30300490
	v_and_b32_e32 v25, 0xffff0000, v2                          // 0000009B7834: 363204FF FFFF0000
	.long 0xd7006a02                                           // 0000009B783C: D7006A02
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000009B7840: 02020010
	s_delay_alu instid0(VALU_DEP_1)                            // 0000009B7844: BF870001
	v_add_co_ci_u32_e64 v3, null, s17, v1, vcc_lo              // 0000009B7848: D5207C03 01AA0211
	v_mul_f32_e32 v24, v23, v24                                // 0000009B7850: 10303117
	v_mul_f32_e32 v23, v23, v25                                // 0000009B7854: 102E3317
	v_add_f32_e32 v4, v4, v23                                  // 0000009B7858: 06082F04
	global_load_b32 v2, v[2:3], off                            // 0000009B785C: DC520000 027C0002
	global_load_b32 v3, v6, s[8:9]                             // 0000009B7864: DC520000 03080006
	v_add_f32_e32 v6, 0, v8                                    // 0000009B786C: 060C1080
	.long 0xd7006a00                                           // 0000009B7870: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000009B7874: 02020004
	v_bfe_u32 v7, v4, 16, 1                                    // 0000009B7878: D6100007 02052104
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 0000009B7880: D5207C01 01AA0205
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000009B7888: BF870194
	v_add_f32_e32 v6, v6, v10                                  // 0000009B788C: 060C1506
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000009B7890: D6550004 03FE0F04 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B789C: BF870112
	v_add_f32_e32 v6, v6, v12                                  // 0000009B78A0: 060C1906
	v_and_b32_e32 v4, 0xffff0000, v4                           // 0000009B78A4: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B78AC: BF870092
	v_add_f32_e32 v6, v6, v14                                  // 0000009B78B0: 060C1D06
	v_add_f32_e32 v6, v6, v16                                  // 0000009B78B4: 060C2106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B78B8: BF870091
	v_add_f32_e32 v6, v6, v18                                  // 0000009B78BC: 060C2506
	v_add_f32_e32 v6, v6, v20                                  // 0000009B78C0: 060C2906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B78C4: BF870091
	v_add_f32_e32 v6, v6, v22                                  // 0000009B78C8: 060C2D06
	v_add_f32_e32 v5, v6, v5                                   // 0000009B78CC: 060A0B06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B78D0: BF870091
	v_add_f32_e32 v5, v5, v24                                  // 0000009B78D4: 060A3105
	v_bfe_u32 v6, v5, 16, 1                                    // 0000009B78D8: D6100006 02052105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B78E0: BF870091
	v_add3_u32 v5, v5, v6, 0x7fff                              // 0000009B78E4: D6550005 03FE0D05 00007FFF
	v_and_b32_e32 v5, 0xffff0000, v5                           // 0000009B78F0: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 0000009B78F8: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v2                               // 0000009B78FC: 300C0490
	v_and_b32_e32 v2, 0xffff0000, v2                           // 0000009B7900: 360404FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 0000009B7908: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B790C: BF870112
	v_fmac_f32_e32 v5, v3, v6                                  // 0000009B7910: 560A0D03
	v_fmac_f32_e32 v4, v3, v2                                  // 0000009B7914: 56080503
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000009B7918: BF870112
	v_bfe_u32 v2, v5, 16, 1                                    // 0000009B791C: D6100002 02052105
	v_bfe_u32 v3, v4, 16, 1                                    // 0000009B7924: D6100003 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000009B792C: BF8701A2
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000009B7930: D6550002 03FE0505 00007FFF
	.long 0x7f0a3880                                           // 0000009B793C: 7F0A3880
	v_add3_u32 v3, v4, v3, 0x7fff                              // 0000009B7940: D6550003 03FE0704 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000009B794C: BF870093
	.long 0x7e0a3982                                           // 0000009B7950: 7E0A3982
	v_and_or_b32 v2, 0xffff0000, v3, v5                        // 0000009B7954: D6570002 041606FF FFFF0000
	global_store_b32 v[0:1], v2, off                           // 0000009B7960: DC6A0000 007C0200
	s_or_b32 exec_lo, exec_lo, s1                              // 0000009B7968: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000009B796C: BE812000
	s_cbranch_execz 8                                          // 0000009B7970: BFA50008 <_ZN7halogen12_GLOBAL__N_114k_ht_gemv_dn_tILi4ELi8ELi2ELb1EEEvPKjPKDF16_PKiS5_PtNS0_6HtFoldE+0x2094>
	s_ashr_i32 s3, s2, 31                                      // 0000009B7974: 86039F02
	v_mov_b32_e32 v0, 0                                        // 0000009B7978: 7E000280
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000009B797C: 84808202
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000009B7980: BF870009
	s_add_u32 s0, s6, s0                                       // 0000009B7984: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000009B7988: 82010107
	global_store_b32 v0, v0, s[0:1]                            // 0000009B798C: DC6A0000 00000000
	s_endpgm                                                   // 0000009B7994: BFB00000
		...

