000000000080dd00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 00000080DD00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000080DD08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000080DD0C: 32040082
	s_lshl_b64 s[2:3], s[2:3], 2                               // 00000080DD10: 84828202
	v_and_b32_e32 v1, 15, v0                                   // 00000080DD14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 00000080DD18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 00000080DD1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 00000080DD24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 00000080DD28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 00000080DD2C: 30020282
	.long 0x7f0a3880                                           // 00000080DD30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 00000080DD34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 00000080DD38: BF89FC07
	s_clause 0x1                                               // 00000080DD3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 00000080DD40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 00000080DD48: DC520000 04040002
	s_add_u32 s0, s4, s16                                      // 00000080DD50: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000080DD54: 82011105
	s_ashr_i32 s16, s11, 31                                    // 00000080DD58: 86109F0B
	v_mov_b32_e32 v2, s3                                       // 00000080DD5C: 7E040203
	s_lshr_b32 s16, s16, 27                                    // 00000080DD60: 85109B10
	v_or_b32_e32 v1, s2, v28                                   // 00000080DD64: 38023802
	s_add_u32 s16, s10, s16                                    // 00000080DD68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 00000080DD6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080DD70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 00000080DD74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000080DD78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 00000080DD7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000080DD80: BF870499
	s_lshr_b32 s20, s17, 31                                    // 00000080DD84: 85149F11
	s_add_i32 s17, s17, s20                                    // 00000080DD88: 81111411
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000080DD8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 00000080DD90: 86118111
	v_cndmask_b32_e64 v2, 0, s3, vcc_lo                        // 00000080DD94: D5010002 01A80680
	.long 0xd72c0007                                           // 00000080DD9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 00000080DDA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 00000080DDA4: B3900201
	.long 0xd72c0009                                           // 00000080DDA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 00000080DDAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[0:1]              // 00000080DDB0: D6FE7C18 00020212
	s_cselect_b32 s0, -1, 0                                    // 00000080DDB8: 980080C1
	s_cmpk_gt_i32 s16, 0x200                                   // 00000080DDBC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 00000080DDC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 00000080DDC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000080DDC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 00000080DDCC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 00000080DDD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 00000080DDD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000080DDD8: BF870151
	.long 0xd4410001                                           // 00000080DDDC: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000080DDE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 00000080DDE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 00000080DDE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 00000080DDF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 00000080DDF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 00000080DDFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 00000080DE08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 00000080DE0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000080DE10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000080DE14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 00000080DE20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000080DE24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 00000080DE28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 00000080DE30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 00000080DE3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 00000080DE44: BF89FC07
	s_barrier                                                  // 00000080DE48: BFBD0000
	buffer_gl0_inv                                             // 00000080DE4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 00000080DE54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000080DE58: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 00000080DE60: BE912001
	s_cbranch_execz 11                                         // 00000080DE64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 00000080DE68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DE6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DE70: 3408069F
	.long 0xd7006a03                                           // 00000080DE74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DE78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080DE7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080DE84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080DE8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 00000080DE90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 00000080DE94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 00000080DE98: 4A063EA0
	s_mov_b32 s1, exec_lo                                      // 00000080DE9C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080DEA0: BF870001
	.long 0xd4c1007e                                           // 00000080DEA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080DEA8: 02024103
	s_cbranch_execz 11                                         // 00000080DEAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080DEB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DEB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DEB8: 3408069F
	.long 0xd7006a03                                           // 00000080DEBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DEC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080DEC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080DECC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080DED4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 00000080DED8: 7E121703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080DEDC: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 00000080DEE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 00000080DEE8: 7E160280
	s_mov_b32 s1, exec_lo                                      // 00000080DEEC: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080DEF0: BF870002
	.long 0xd4c1007e                                           // 00000080DEF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080DEF8: 02024103
	s_cbranch_execz 11                                         // 00000080DEFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080DF00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DF04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DF08: 3408069F
	.long 0xd7006a03                                           // 00000080DF0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DF10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080DF14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080DF1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080DF24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 00000080DF28: 7E141703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080DF2C: 8C7E017E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 00000080DF30: 4A063EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 00000080DF38: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080DF3C: BF870001
	.long 0xd4c1007e                                           // 00000080DF40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080DF44: 02024103
	s_cbranch_execz 11                                         // 00000080DF48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080DF4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DF50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DF54: 3408069F
	.long 0xd7006a03                                           // 00000080DF58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DF5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080DF60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080DF68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080DF70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 00000080DF74: 7E161703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080DF78: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 00000080DF7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 00000080DF88: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 00000080DF8C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080DF90: BF870002
	.long 0xd4c1007e                                           // 00000080DF94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080DF98: 02024103
	s_cbranch_execz 11                                         // 00000080DF9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080DFA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DFA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DFA8: 3408069F
	.long 0xd7006a03                                           // 00000080DFAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DFB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080DFB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080DFBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080DFC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 00000080DFC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080DFCC: 8C7E017E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 00000080DFD0: 4A063EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 00000080DFD8: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080DFDC: BF870001
	.long 0xd4c1007e                                           // 00000080DFE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080DFE4: 02024103
	s_cbranch_execz 11                                         // 00000080DFE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080DFEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080DFF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080DFF4: 3408069F
	.long 0xd7006a03                                           // 00000080DFF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080DFFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080E000: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080E008: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080E010: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 00000080E014: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080E018: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 00000080E01C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 00000080E028: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 00000080E02C: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080E030: BF870002
	.long 0xd4c1007e                                           // 00000080E034: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080E038: 02024103
	s_cbranch_execz 11                                         // 00000080E03C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080E040: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E044: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080E048: 3408069F
	.long 0xd7006a03                                           // 00000080E04C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080E050: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080E054: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080E05C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080E064: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 00000080E068: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080E06C: 8C7E017E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 00000080E070: 4A063EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 00000080E078: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080E07C: BF870001
	.long 0xd4c1007e                                           // 00000080E080: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 00000080E084: 02024103
	s_cbranch_execz 11                                         // 00000080E088: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 00000080E08C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E090: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000080E094: 3408069F
	.long 0xd7006a03                                           // 00000080E098: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 00000080E09C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 00000080E0A0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 00000080E0A8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 00000080E0B0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 00000080E0B4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s1                              // 00000080E0B8: 8C7E017E
	s_branch 9                                                 // 00000080E0BC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 00000080E0C0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080E0C4: BF870001
	v_mov_b32_e32 v9, v8                                       // 00000080E0C8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 00000080E0CC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 00000080E0D0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 00000080E0D4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 00000080E0D8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 00000080E0DC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 00000080E0E0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 00000080E0E4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000080E0E8: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 00000080E0EC: 85019F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 00000080E0F0: CA100080 141A0080
	s_add_u32 s14, s10, s1                                     // 00000080E0F8: 800E010A
	s_addc_u32 s15, s11, 0                                     // 00000080E0FC: 820F800B
	.long 0xd4410001                                           // 00000080E100: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000080E104: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 00000080E108: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 00000080E10C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 00000080E114: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 00000080E11C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 00000080E120: 02001F01
	.long 0xd72c0002                                           // 00000080E124: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 00000080E128: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 00000080E12C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 00000080E134: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000080E13C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 00000080E140: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 00000080E148: BE842001
	s_cbranch_execz 22                                         // 00000080E14C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 00000080E150: 30023E84
	v_mov_b32_e32 v27, 0                                       // 00000080E154: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E158: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000080E15C: 3404029F
	.long 0xd7006a01                                           // 00000080E160: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 00000080E164: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000080E168: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 00000080E170: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 00000080E174: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 00000080E17C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000080E180: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E184: BF870091
	.long 0xd7006a01                                           // 00000080E188: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000080E18C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 00000080E190: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 00000080E198: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000080E1A0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 00000080E1A4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 00000080E1A8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 00000080E1AC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v37, 0             // 00000080E1B4: CA100080 28240080
	s_and_saveexec_b32 s14, s1                                 // 00000080E1BC: BE8E2001
	s_cbranch_execz 490                                        // 00000080E1C0: BFA501EA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc6c>
	v_dual_mov_b32 v40, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 00000080E1C4: CA200080 28003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 00000080E1CC: CA220080 251A3E85
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v43, v27           // 00000080E1D4: CA100080 222A011B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000080E1DC: BF870003
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v41, 4, v1     // 00000080E1E0: CA220080 26280284
	v_dual_mov_b32 v39, 0 :: v_dual_lshlrev_b32 v42, 1, v1     // 00000080E1E8: CA220080 272A0281
	s_mul_i32 s1, s11, 6                                       // 00000080E1F0: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 00000080E1F4: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000080E1F8: 8484820A
	s_add_i32 s15, s15, s1                                     // 00000080E1FC: 810F010F
	s_mul_i32 s17, s10, 6                                      // 00000080E200: 9611860A
	s_mov_b32 s16, 0                                           // 00000080E204: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 00000080E208: 848A810A
	s_branch 435                                               // 00000080E20C: BFA001B3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xbdc>
	s_or_b32 exec_lo, exec_lo, s18                             // 00000080E210: 8C7E127E
	v_cndmask_b32_e64 v54, v27, v8, s0                         // 00000080E214: D5010036 0002111B
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 00000080E21C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 00000080E224: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 00000080E22C: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 00000080E238: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 00000080E240: D5010006 00021D0D
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 00000080E248: D5010005 00021B0C
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 00000080E250: D5010004 0002190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000080E258: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 00000080E25C: D5010003 0002170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 00000080E264: 3436349F
	v_add_nc_u32_e32 v41, 0x200, v41                           // 00000080E268: 4A5252FF 00000200
	s_and_b32 s1, exec_lo, s1                                  // 00000080E270: 8B01017E
	ds_load_b32 v15, v9                                        // 00000080E274: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 00000080E27C: 32122886
	s_or_b32 s16, s1, s16                                      // 00000080E280: 8C101001
	v_add_nc_u32_e32 v42, 64, v42                              // 00000080E284: 4A5454C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E288: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E28C: 361212FF 000003FC
	ds_load_b32 v55, v9                                        // 00000080E294: D8D80000 37000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 00000080E29C: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E2A0: 361212FF 000003FC
	ds_load_b32 v56, v9                                        // 00000080E2A8: D8D80000 38000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 00000080E2B0: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E2B4: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E2B8: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 00000080E2C0: D8D80000 39000009
	v_and_b32_e32 v9, 0xff, v21                                // 00000080E2C8: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000080E2D0: 30121282
	ds_load_b32 v58, v9                                        // 00000080E2D4: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 00000080E2DC: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E2E0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E2E4: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 00000080E2EC: D8D80000 3B000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 00000080E2F4: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E2F8: 361212FF 000003FC
	ds_load_b32 v60, v9                                        // 00000080E300: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 00000080E308: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E30C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E310: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 00000080E318: D8D80000 3D000009
	v_and_b32_e32 v9, 0xff, v22                                // 00000080E320: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000080E328: 30121282
	ds_load_b32 v62, v9                                        // 00000080E32C: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 00000080E334: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E338: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E33C: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 00000080E344: D8D80000 3F000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 00000080E34C: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E350: 361212FF 000003FC
	ds_load_b32 v64, v9                                        // 00000080E358: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 00000080E360: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E364: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E368: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 00000080E370: D8D80000 41000009
	v_and_b32_e32 v9, 0xff, v23                                // 00000080E378: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000080E380: 30121282
	ds_load_b32 v66, v9                                        // 00000080E384: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 00000080E38C: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E390: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E394: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 00000080E39C: D8D80000 43000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 00000080E3A4: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E3A8: 361212FF 000003FC
	ds_load_b32 v68, v9                                        // 00000080E3B0: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 00000080E3B8: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000080E3BC: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 00000080E3C0: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 00000080E3C8: D8D80000 45000009
	.long 0xd73c0009                                           // 00000080E3D0: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 00000080E3D4: 02023481
	v_dual_mov_b32 v27, v43 :: v_dual_add_nc_u32 v26, 0x400, v26// 00000080E3D8: CA20012B 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 00000080E3E4: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 00000080E3E8: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080E3EC: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 00000080E3F0: D5207C0E 01AA1407
	s_clause 0x3                                               // 00000080E3F8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000080E3FC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000080E404: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 00000080E40C: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 00000080E414: DC5E0030 307C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 00000080E41C: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000080E420: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 00000080E428: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E42C: BF8700A1
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000080E430: CC1A4009 1C266F0A
	s_waitcnt lgkmcnt(13)                                      // 00000080E438: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000080E43C: CC1A4009 1C26710B
	s_waitcnt lgkmcnt(12)                                      // 00000080E444: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E448: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000080E44C: CC1A4009 1C26730C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 00000080E454: BF8908B7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000080E458: CC1A4009 1C267514
	s_waitcnt lgkmcnt(10)                                      // 00000080E460: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E464: BF8700A1
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000080E468: CC1A4009 1C267715
	s_waitcnt lgkmcnt(9)                                       // 00000080E470: BF89FC97
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000080E474: CC1A4009 1C267916
	s_waitcnt lgkmcnt(8)                                       // 00000080E47C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E480: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000080E484: CC1A4009 1C267B17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 00000080E48C: BF890477
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000080E490: CC1A4009 1C267D2C
	s_waitcnt lgkmcnt(6)                                       // 00000080E498: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E49C: BF8700A1
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000080E4A0: CC1A4009 1C267F2D
	s_waitcnt lgkmcnt(5)                                       // 00000080E4A8: BF89FC57
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000080E4AC: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(4)                                       // 00000080E4B4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E4B8: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000080E4BC: CC1A4009 1C26832F
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 00000080E4C4: BF890037
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000080E4C8: CC1A4009 1C268530
	.long 0xd7006a30                                           // 00000080E4D0: D7006A30
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 00000080E4D4: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 00000080E4D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000080E4DC: BF8701C2
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000080E4E0: CC1A4009 1C268731
	v_add_co_ci_u32_e64 v49, null, s11, v14, vcc_lo            // 00000080E4E8: D5207C31 01AA1C0B
	.long 0xd7006a34                                           // 00000080E4F0: D7006A34
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 00000080E4F4: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 00000080E4F8: BF89FC17
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000080E4FC: CC1A4009 1C268932
	v_add_co_ci_u32_e64 v53, null, s5, v14, vcc_lo             // 00000080E504: D5207C35 01AA1C05
	.long 0xd7006a0d                                           // 00000080E50C: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 00000080E510: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 00000080E514: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000080E518: BF870123
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000080E51C: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 00000080E524: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v54, v9                                // 00000080E52C: 564A1336
	s_clause 0x3                                               // 00000080E530: BF850003
	global_load_b128 v[9:12], v[48:49], off                    // 00000080E534: DC5E0000 097C0030
	global_load_b128 v[20:23], v[48:49], off offset:16         // 00000080E53C: DC5E0010 147C0030
	global_load_b128 v[44:47], v[48:49], off offset:32         // 00000080E544: DC5E0020 2C7C0030
	global_load_b128 v[48:51], v[48:49], off offset:48         // 00000080E54C: DC5E0030 307C0030
	s_waitcnt vmcnt(3)                                         // 00000080E554: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000080E558: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E560: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000080E564: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000080E56C: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E574: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000080E578: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 00000080E580: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000080E584: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E58C: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000080E590: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000080E598: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E5A0: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000080E5A4: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 00000080E5AC: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000080E5B0: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E5B8: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000080E5BC: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000080E5C4: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E5CC: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000080E5D0: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 00000080E5D8: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000080E5DC: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E5E4: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000080E5E8: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000080E5F0: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E5F8: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000080E5FC: CC1A4009 1C268B33
	v_fmac_f32_e32 v40, v54, v9                                // 00000080E604: 56501336
	s_clause 0x3                                               // 00000080E608: BF850003
	global_load_b128 v[9:12], v[52:53], off                    // 00000080E60C: DC5E0000 097C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 00000080E614: DC5E0010 147C0034
	global_load_b128 v[44:47], v[52:53], off offset:32         // 00000080E61C: DC5E0020 2C7C0034
	global_load_b128 v[48:51], v[52:53], off offset:48         // 00000080E624: DC5E0030 307C0034
	s_waitcnt vmcnt(3)                                         // 00000080E62C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000080E630: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E638: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000080E63C: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000080E644: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E64C: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000080E650: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 00000080E658: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000080E65C: CC1A4009 1C267514
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E664: BF870091
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000080E668: CC1A4009 1C267715
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000080E670: CC1A4009 1C267916
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E678: BF8700A1
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000080E67C: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 00000080E684: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000080E688: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E690: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000080E694: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000080E69C: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E6A4: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000080E6A8: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 00000080E6B0: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000080E6B4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E6BC: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000080E6C0: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000080E6C8: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E6D0: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000080E6D4: CC1A4009 1C268B33
	v_fmac_f32_e32 v39, v54, v9                                // 00000080E6DC: 564E1336
	s_clause 0x3                                               // 00000080E6E0: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000080E6E4: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000080E6EC: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 00000080E6F4: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 00000080E6FC: DC5E0030 307C000D
	.long 0xd7006a0d                                           // 00000080E704: D7006A0D
	v_cndmask_b32_e32 v0, v52, v4, vcc_lo                      // 00000080E708: 02000934
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E70C: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v53, vcc_lo             // 00000080E710: D5207C0E 01AA6A05
	s_waitcnt vmcnt(3)                                         // 00000080E718: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000080E71C: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000080E724: CC1A4009 1C266F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E72C: BF870091
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000080E730: CC1A4009 1C26710B
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000080E738: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 00000080E740: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E744: BF870091
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000080E748: CC1A4009 1C267514
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000080E750: CC1A4009 1C267715
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E758: BF870091
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000080E75C: CC1A4009 1C267916
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000080E764: CC1A4009 1C267B17
	s_waitcnt vmcnt(1)                                         // 00000080E76C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E770: BF870091
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000080E774: CC1A4009 1C267D2C
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000080E77C: CC1A4009 1C267F2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E784: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000080E788: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000080E790: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 00000080E798: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E79C: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000080E7A0: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000080E7A8: CC1A4009 1C268731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E7B0: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000080E7B4: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000080E7BC: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080E7C4: BF870001
	v_fmac_f32_e32 v38, v54, v9                                // 00000080E7C8: 564C1336
	s_clause 0x3                                               // 00000080E7CC: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 00000080E7D0: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 00000080E7D8: DC5E0010 147C000D
	global_load_b128 v[44:47], v[13:14], off offset:32         // 00000080E7E0: DC5E0020 2C7C000D
	global_load_b128 v[48:51], v[13:14], off offset:48         // 00000080E7E8: DC5E0030 307C000D
	s_waitcnt vmcnt(3)                                         // 00000080E7F0: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 00000080E7F4: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E7FC: BF870091
	v_dot2_f32_bf16 v9, v10, v55, v9                           // 00000080E800: CC1A4009 1C266F0A
	v_dot2_f32_bf16 v9, v11, v56, v9                           // 00000080E808: CC1A4009 1C26710B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E810: BF8700A1
	v_dot2_f32_bf16 v9, v12, v57, v9                           // 00000080E814: CC1A4009 1C26730C
	s_waitcnt vmcnt(2)                                         // 00000080E81C: BF890BF7
	v_dot2_f32_bf16 v9, v20, v58, v9                           // 00000080E820: CC1A4009 1C267514
	v_mov_b32_e32 v20, v16                                     // 00000080E828: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000080E82C: BF870122
	v_dot2_f32_bf16 v9, v21, v59, v9                           // 00000080E830: CC1A4009 1C267715
	v_mov_b32_e32 v21, v17                                     // 00000080E838: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v60, v9                           // 00000080E83C: CC1A4009 1C267916
	v_mov_b32_e32 v22, v18                                     // 00000080E844: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000080E848: BF870132
	v_dot2_f32_bf16 v9, v23, v61, v9                           // 00000080E84C: CC1A4009 1C267B17
	v_mov_b32_e32 v23, v19                                     // 00000080E854: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 00000080E858: BF8907F7
	v_dot2_f32_bf16 v9, v44, v62, v9                           // 00000080E85C: CC1A4009 1C267D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E864: BF870091
	v_dot2_f32_bf16 v9, v45, v63, v9                           // 00000080E868: CC1A4009 1C267F2D
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 00000080E870: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000080E878: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 00000080E87C: CC1A4009 1C26832F
	s_waitcnt vmcnt(0)                                         // 00000080E884: BF8903F7
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 00000080E888: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E890: BF870091
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 00000080E894: CC1A4009 1C268731
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 00000080E89C: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080E8A4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 00000080E8A8: CC1A4009 1C268B33
	v_dual_fmac_f32 v34, v54, v9 :: v_dual_mov_b32 v15, v8     // 00000080E8B0: C8101336 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 00000080E8B8: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 00000080E8C0: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000080E8C8: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 00000080E8D0: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000080E8D4: 917E107E
	s_cbranch_execz 35                                         // 00000080E8D8: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc68>
	s_waitcnt vmcnt(0)                                         // 00000080E8DC: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 00000080E8E0: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 00000080E8E8: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 00000080E8F0: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 00000080E8F4: BF870003
	.long 0xd4460001                                           // 00000080E8F8: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000080E8FC: 0202411F
	s_mov_b32 s18, exec_lo                                     // 00000080E900: BE92007E
	.long 0xd4c1007e                                           // 00000080E904: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000080E908: 0202411F
	s_cbranch_execz 65088                                      // 00000080E90C: BFA5FE40 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	v_ashrrev_i32_e32 v2, 31, v41                              // 00000080E910: 3404529F
	.long 0xd7006a01                                           // 00000080E914: D7006A01
	v_cndmask_b32_e32 v1, v25, v41, vcc_lo                     // 00000080E918: 02025319
	v_mov_b32_e32 v43, v27                                     // 00000080E91C: 7E56031B
	s_delay_alu instid0(VALU_DEP_3)                            // 00000080E920: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 00000080E924: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 00000080E92C: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 00000080E930: DC5E0000 107C0001
	s_cbranch_vccnz 65077                                      // 00000080E938: BFA4FE35 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	v_ashrrev_i32_e32 v2, 31, v42                              // 00000080E93C: 3404549F
	.long 0xd7006a01                                           // 00000080E940: D7006A01
	v_cndmask_b32_e32 v1, v24, v42, vcc_lo                     // 00000080E944: 02025518
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080E948: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000080E94C: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 00000080E954: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 00000080E95C: BF8903F7
	v_cvt_f32_f16_e32 v43, v1                                  // 00000080E960: 7E561701
	s_branch 65066                                             // 00000080E964: BFA0FE2A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x510>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000080E968: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080E96C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000080E970: 8C7E0E7E
	.long 0xd71f0001                                           // 00000080E974: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000080E978: 020100C1
	s_mov_b32 s0, exec_lo                                      // 00000080E97C: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000080E980: 3A040290
	v_xor_b32_e32 v7, 8, v1                                    // 00000080E984: 3A0E0288
	v_xor_b32_e32 v12, 4, v1                                   // 00000080E988: 3A180284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000080E98C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000080E990: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000080E994: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v7                            // 00000080E998: 7C980EA0
	v_cndmask_b32_e32 v7, v1, v7, vcc_lo                       // 00000080E99C: 020E0F01
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000080E9A0: 7C9818A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000080E9A4: BF870002
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000080E9A8: 300E0E82
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000080E9AC: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 00000080E9B0: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 00000080E9B8: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 00000080E9BC: 06060725
	ds_bpermute_b32 v4, v2, v40                                // 00000080E9C0: DACC0000 04002802
	ds_bpermute_b32 v5, v2, v39                                // 00000080E9C8: DACC0000 05002702
	ds_bpermute_b32 v6, v2, v38                                // 00000080E9D0: DACC0000 06002602
	ds_bpermute_b32 v2, v2, v34                                // 00000080E9D8: DACC0000 02002202
	ds_bpermute_b32 v8, v7, v3                                 // 00000080E9E0: DACC0000 08000307
	s_waitcnt lgkmcnt(3)                                       // 00000080E9E8: BF89FC37
	v_dual_add_f32 v4, v40, v4 :: v_dual_add_f32 v5, v39, v5   // 00000080E9EC: C9080928 04040B27
	s_waitcnt lgkmcnt(2)                                       // 00000080E9F4: BF89FC27
	v_add_f32_e32 v6, v38, v6                                  // 00000080E9F8: 060C0D26
	s_waitcnt lgkmcnt(0)                                       // 00000080E9FC: BF89FC07
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v8    // 00000080EA00: C9080522 02021103
	ds_bpermute_b32 v9, v7, v4                                 // 00000080EA08: DACC0000 09000407
	ds_bpermute_b32 v10, v7, v5                                // 00000080EA10: DACC0000 0A000507
	v_cndmask_b32_e32 v12, v1, v12, vcc_lo                     // 00000080EA18: 02181901
	ds_bpermute_b32 v11, v7, v6                                // 00000080EA1C: DACC0000 0B000607
	ds_bpermute_b32 v7, v7, v2                                 // 00000080EA24: DACC0000 07000207
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000080EA2C: 30181882
	s_waitcnt lgkmcnt(2)                                       // 00000080EA30: BF89FC27
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v5, v5, v10    // 00000080EA34: C9081304 04041505
	ds_bpermute_b32 v8, v12, v4                                // 00000080EA3C: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 00000080EA44: DACC0000 0900050C
	s_waitcnt lgkmcnt(3)                                       // 00000080EA4C: BF89FC37
	v_add_f32_e32 v6, v6, v11                                  // 00000080EA50: 060C1706
	s_waitcnt lgkmcnt(1)                                       // 00000080EA54: BF89FC17
	v_add_f32_e32 v4, v4, v8                                   // 00000080EA58: 06081104
	v_add_f32_e32 v2, v2, v7                                   // 00000080EA5C: 06040F02
	ds_bpermute_b32 v7, v12, v3                                // 00000080EA60: DACC0000 0700030C
	s_waitcnt lgkmcnt(1)                                       // 00000080EA68: BF89FC17
	v_add_f32_e32 v5, v5, v9                                   // 00000080EA6C: 060A1305
	ds_bpermute_b32 v10, v12, v6                               // 00000080EA70: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 00000080EA78: DACC0000 0B00020C
	v_xor_b32_e32 v12, 2, v1                                   // 00000080EA80: 3A180282
	s_delay_alu instid0(VALU_DEP_1)                            // 00000080EA84: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000080EA88: 7C9818A0
	s_waitcnt lgkmcnt(2)                                       // 00000080EA8C: BF89FC27
	v_dual_add_f32 v3, v3, v7 :: v_dual_cndmask_b32 v12, v1, v12// 00000080EA90: C9120F03 030C1901
	s_waitcnt lgkmcnt(1)                                       // 00000080EA98: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 00000080EA9C: 060C1506
	s_waitcnt lgkmcnt(0)                                       // 00000080EAA0: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 00000080EAA4: 06041702
	v_lshlrev_b32_e32 v12, 2, v12                              // 00000080EAA8: 30181882
	ds_bpermute_b32 v7, v12, v3                                // 00000080EAAC: DACC0000 0700030C
	ds_bpermute_b32 v8, v12, v4                                // 00000080EAB4: DACC0000 0800040C
	ds_bpermute_b32 v9, v12, v5                                // 00000080EABC: DACC0000 0900050C
	ds_bpermute_b32 v10, v12, v6                               // 00000080EAC4: DACC0000 0A00060C
	ds_bpermute_b32 v11, v12, v2                               // 00000080EACC: DACC0000 0B00020C
	v_xor_b32_e32 v12, 1, v1                                   // 00000080EAD4: 3A180281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000080EAD8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v12                           // 00000080EADC: 7C9818A0
	v_cndmask_b32_e32 v1, v1, v12, vcc_lo                      // 00000080EAE0: 02021901
	s_waitcnt lgkmcnt(4)                                       // 00000080EAE4: BF89FC47
	v_dual_add_f32 v1, v3, v7 :: v_dual_lshlrev_b32 v12, 2, v1 // 00000080EAE8: C9220F03 010C0282
	s_waitcnt lgkmcnt(2)                                       // 00000080EAF0: BF89FC27
	v_dual_add_f32 v3, v4, v8 :: v_dual_add_f32 v4, v5, v9     // 00000080EAF4: C9081104 03041305
	s_waitcnt lgkmcnt(1)                                       // 00000080EAFC: BF89FC17
	v_add_f32_e32 v7, v6, v10                                  // 00000080EB00: 060E1506
	s_waitcnt lgkmcnt(0)                                       // 00000080EB04: BF89FC07
	v_add_f32_e32 v2, v2, v11                                  // 00000080EB08: 06041702
	ds_bpermute_b32 v5, v12, v1                                // 00000080EB0C: DACC0000 0500010C
	ds_bpermute_b32 v8, v12, v3                                // 00000080EB14: DACC0000 0800030C
	ds_bpermute_b32 v9, v12, v4                                // 00000080EB1C: DACC0000 0900040C
	ds_bpermute_b32 v10, v12, v7                               // 00000080EB24: DACC0000 0A00070C
	ds_bpermute_b32 v6, v12, v2                                // 00000080EB2C: DACC0000 0600020C
	v_cmpx_eq_u32_e32 0, v30                                   // 00000080EB34: 7D943C80
	s_cbranch_execz 21                                         // 00000080EB38: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xe90>
	.long 0xd72c000b                                           // 00000080EB3C: D72C000B
	v_cndmask_b32_e32 v0, v28, v168, vcc_lo                    // 00000080EB40: 0201511C
	s_waitcnt lgkmcnt(0)                                       // 00000080EB44: BF89FC07
	v_dual_add_f32 v1, v1, v5 :: v_dual_add_f32 v2, v2, v6     // 00000080EB48: C9080B01 01020D02
	v_dual_add_f32 v7, v7, v10 :: v_dual_add_f32 v4, v4, v9    // 00000080EB50: C9081507 07041304
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EB58: BF870093
	v_mad_u32_u24 v11, v29, 20, v11                            // 00000080EB5C: D60B000B 042D291D
	v_dual_add_f32 v3, v3, v8 :: v_dual_add_nc_u32 v8, 0x408, v11// 00000080EB64: C9201103 030816FF 00000408
	v_add_nc_u32_e32 v5, 0x400, v11                            // 00000080EB70: 4A0A16FF 00000400
	ds_store_2addr_b32 v5, v1, v3 offset1:1                    // 00000080EB78: D8380100 00030105
	ds_store_2addr_b32 v8, v4, v7 offset1:1                    // 00000080EB80: D8380100 00070408
	ds_store_b32 v11, v2 offset:1040                           // 00000080EB88: D8340410 0000020B
	s_or_b32 exec_lo, exec_lo, s0                              // 00000080EB90: 8C7E007E
	.long 0xd7050001                                           // 00000080EB94: D7050001
	v_cndmask_b32_e32 v1, 0xcd, v0, vcc_lo                     // 00000080EB98: 020200FF 000000CD
	.long 0x7f063880                                           // 00000080EBA0: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000080EBA4: BF890007
	s_barrier                                                  // 00000080EBA8: BFBD0000
	buffer_gl0_inv                                             // 00000080EBAC: E0AC0000 00000000
	.long 0xd7390003                                           // 00000080EBB4: D7390003
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000080EBB8: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EBBC: BF870091
	.long 0xd7000001                                           // 00000080EBC0: D7000001
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 00000080EBC4: 02020602
	v_add_co_ci_u32_e64 v2, null, s3, 0, s0                    // 00000080EBC8: D5207C02 00010003
	.long 0xd44c0000                                           // 00000080EBD0: D44C0000
	v_cndmask_b32_e32 v1, 20, v0, vcc_lo                       // 00000080EBD4: 02020094
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000080EBD8: BF8704A2
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 00000080EBDC: 7CA8020C
	s_and_b32 s0, s0, vcc_lo                                   // 00000080EBE0: 8B006A00
	s_and_saveexec_b32 s1, s0                                  // 00000080EBE4: BE812000
	s_cbranch_execz 82                                         // 00000080EBE8: BFA50052 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi5ELi32ELi2ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1034>
	.long 0xd7054000                                           // 00000080EBEC: D7054000
	v_cndmask_b32_e32 v0, v3, v133, vcc_lo                     // 00000080EBF0: 02010B03
	v_mul_u32_u24_e32 v3, 40, v3                               // 00000080EBF4: 160606A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EBF8: BF870092
	.long 0xd7041000                                           // 00000080EBFC: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 00000080EC00: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 00000080EC04: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EC0C: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 00000080EC10: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000080EC18: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:5                     // 00000080EC20: D8DC0500 03000003
	s_waitcnt lgkmcnt(0)                                       // 00000080EC28: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 00000080EC2C: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EC30: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 00000080EC34: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 00000080EC38: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EC40: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 00000080EC44: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 00000080EC50: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EC58: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 00000080EC5C: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 00000080EC64: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080EC68: BF870095
	v_add_f32_e32 v6, 1.0, v3                                  // 00000080EC6C: 060C06F2
	v_div_scale_f32 v5, null, v6, v6, 1.0                      // 00000080EC70: D6FC7C05 03CA0D06
	v_div_scale_f32 v8, vcc_lo, 1.0, v6, 1.0                   // 00000080EC78: D6FC6A08 03CA0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000080EC80: BF870292
	v_rcp_f32_e32 v7, v5                                       // 00000080EC84: 7E0E5505
	v_fma_f32 v3, -v5, v7, 1.0                                 // 00000080EC88: D6130003 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000080EC90: BF870121
	v_fmac_f32_e32 v7, v3, v7                                  // 00000080EC94: 560E0F03
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 00000080EC98: D6FE7C03 0202000C
	v_mul_f32_e32 v9, v8, v7                                   // 00000080ECA0: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000080ECA4: BF870091
	v_fma_f32 v10, -v5, v9, v8                                 // 00000080ECA8: D613000A 24221305
	v_fmac_f32_e32 v9, v10, v7                                 // 00000080ECB0: 56120F0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000080ECB4: BF870121
	v_fma_f32 v8, -v5, v9, v8                                  // 00000080ECB8: D6130008 24221305
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 00000080ECC0: D6FE7C04 0412000D
	v_div_fmas_f32 v0, v8, v7, v9                              // 00000080ECC8: D6370000 04260F08
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000080ECD0: BF870112
	.long 0xd73c0003                                           // 00000080ECD4: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000080ECD8: 02020681
	v_div_fixup_f32 v5, v0, v6, 1.0                            // 00000080ECDC: D6270005 03CA0D00
	.long 0xd73c0000                                           // 00000080ECE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000080ECE8: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000080ECEC: BF870193
	.long 0xd7006a03                                           // 00000080ECF0: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000080ECF4: 02020608
	v_bfe_u32 v2, v5, 16, 1                                    // 00000080ECF8: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000080ED00: D5207C04 01AA0809
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000080ED08: BF870193
	.long 0xd7006a00                                           // 00000080ED0C: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000080ED10: 02020103
	v_add3_u32 v2, v5, v2, 0x7fff                              // 00000080ED14: D6550002 03FE0505 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000080ED20: BF870003
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 00000080ED24: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000080ED2C: DC960000 007C0200
	s_endpgm                                                   // 00000080ED34: BFB00000
		...

