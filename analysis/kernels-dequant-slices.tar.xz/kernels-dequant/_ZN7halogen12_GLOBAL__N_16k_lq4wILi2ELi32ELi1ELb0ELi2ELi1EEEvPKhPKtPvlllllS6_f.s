00000000007fd300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007FD300: F4100100 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000007FD308: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007FD30C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000007FD310: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000007FD314: 32060085
	s_lshl_b64 s[0:1], s[2:3], 3                               // 0000007FD318: 84808302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007FD31C: 30020282
	v_dual_mov_b32 v17, s1 :: v_dual_and_b32 v2, 60, v2        // 0000007FD320: CA240001 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FD328: BF870003
	v_or_b32_e32 v16, s0, v3                                   // 0000007FD32C: 38200600
	.long 0x7f063880                                           // 0000007FD330: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000007FD334: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007FD338: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000007FD33C: BF89FC07
	s_clause 0x1                                               // 0000007FD340: BF850001
	global_load_b32 v1, v1, s[4:5]                             // 0000007FD344: DC520000 01040001
	global_load_b32 v2, v2, s[4:5]                             // 0000007FD34C: DC520000 02040002
	.long 0xd4540000                                           // 0000007FD354: D4540000
	v_cndmask_b32_e32 v1, s12, v16, vcc_lo                     // 0000007FD358: 0202200C
	s_add_u32 s22, s4, s16                                     // 0000007FD35C: 80161004
	s_addc_u32 s23, s5, s17                                    // 0000007FD360: 82171105
	s_ashr_i32 s2, s11, 31                                     // 0000007FD364: 86029F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007FD368: BF870159
	s_lshr_b32 s2, s2, 27                                      // 0000007FD36C: 85029B02
	v_cndmask_b32_e64 v8, 0, v16, s0                           // 0000007FD370: D5010008 00022080
	v_cndmask_b32_e64 v9, 0, s1, s0                            // 0000007FD378: D5010009 00000280
	s_add_u32 s2, s10, s2                                      // 0000007FD380: 8002020A
	s_addc_u32 s3, s11, 0                                      // 0000007FD384: 8203800B
	.long 0xd72c0004                                           // 0000007FD388: D72C0004
	v_cndmask_b32_e32 v1, s19, v8, vcc_lo                      // 0000007FD38C: 02021013
	v_mad_u64_u32 v[12:13], null, s18, v8, 0                   // 0000007FD390: D6FE7C0C 02021012
	s_lshr_b64 s[20:21], s[2:3], 5                             // 0000007FD398: 85948502
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007FD39C: BF870009
	s_cmpk_lt_i32 s20, 0x101                                   // 0000007FD3A0: B3940101
	.long 0xd4440002                                           // 0000007FD3A4: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 0000007FD3A8: 02022E14
	s_cselect_b32 s1, -1, 0                                    // 0000007FD3AC: 980180C1
	s_cmpk_gt_i32 s20, 0x100                                   // 0000007FD3B0: B2940100
	.long 0xd700030e                                           // 0000007FD3B4: D700030E
	v_cndmask_b32_e32 v1, s22, v12, vcc_lo                     // 0000007FD3B8: 02021816
	s_waitcnt vmcnt(1)                                         // 0000007FD3BC: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000007FD3C0: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000007FD3C8: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000007FD3CC: D6100006 02052102
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD3D4: BF8701A2
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000007FD3D8: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000007FD3E4: D72C0005
	v_cndmask_b32_e32 v1, s18, v9, vcc_lo                      // 0000007FD3E8: 02021212
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000007FD3EC: D6550002 03FE0D02 00007FFF
	s_cselect_b32 s18, -1, 0                                   // 0000007FD3F8: 981280C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD3FC: BF8701A9
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000007FD400: 8B6A127E
	.long 0x7e063981                                           // 0000007FD404: 7E063981
	v_add3_u32 v13, v13, v5, v4                                // 0000007FD408: D655000D 04120B0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FD410: BF870112
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000007FD414: D6570001 040E04FF FFFF0000
	v_add_co_ci_u32_e64 v15, null, s23, v13, s3                // 0000007FD420: D5207C0F 000E1A17
	ds_store_b32 v0, v1                                        // 0000007FD428: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007FD430: BF89FC07
	s_barrier                                                  // 0000007FD434: BFBD0000
	buffer_gl0_inv                                             // 0000007FD438: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000007FD440: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x38c>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007FD444: CA100080 01000080
	s_and_saveexec_b32 s3, s2                                  // 0000007FD44C: BE832002
	s_cbranch_execz 10                                         // 0000007FD450: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x17c>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007FD454: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD458: BF870091
	.long 0xd7006a02                                           // 0000007FD45C: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007FD460: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007FD464: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007FD46C: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007FD474: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007FD478: 7E001700
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007FD47C: 8C7E037E
	v_or_b32_e32 v2, 32, v23                                   // 0000007FD480: 38042EA0
	s_mov_b32 s2, exec_lo                                      // 0000007FD484: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD488: BF870001
	.long 0xd4c4007e                                           // 0000007FD48C: D4C4007E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 0000007FD490: 02020414
	s_cbranch_execz 10                                         // 0000007FD494: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x1c0>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007FD498: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD49C: BF870091
	.long 0xd7006a01                                           // 0000007FD4A0: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007FD4A4: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007FD4A8: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007FD4B0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007FD4B8: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007FD4BC: 7E021701
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD4C0: 8C7E027E
	v_or_b32_e32 v4, 64, v23                                   // 0000007FD4C4: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007FD4C8: CA100080 03020080
	s_mov_b32 s2, exec_lo                                      // 0000007FD4D0: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007FD4D4: BF870002
	.long 0xd4c4007e                                           // 0000007FD4D8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 0000007FD4DC: 02020814
	s_cbranch_execz 10                                         // 0000007FD4E0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x20c>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007FD4E4: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD4E8: BF870091
	.long 0xd7006a04                                           // 0000007FD4EC: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007FD4F0: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007FD4F4: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007FD4FC: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007FD504: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007FD508: 7E041702
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD50C: 8C7E027E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000007FD510: 38082EFF 00000060
	s_mov_b32 s2, exec_lo                                      // 0000007FD518: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD51C: BF870001
	.long 0xd4c4007e                                           // 0000007FD520: D4C4007E
	v_cndmask_b32_e32 v1, s20, v4, vcc_lo                      // 0000007FD524: 02020814
	s_cbranch_execz 10                                         // 0000007FD528: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x254>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007FD52C: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD530: BF870091
	.long 0xd7006a03                                           // 0000007FD534: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007FD538: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007FD53C: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007FD544: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007FD54C: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007FD550: 7E061703
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD554: 8C7E027E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000007FD558: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007FD560: CA100080 05040080
	s_mov_b32 s2, exec_lo                                      // 0000007FD568: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007FD56C: BF870002
	.long 0xd4c4007e                                           // 0000007FD570: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000007FD574: 02020C14
	s_cbranch_execz 10                                         // 0000007FD578: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2a4>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007FD57C: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD580: BF870091
	.long 0xd7006a06                                           // 0000007FD584: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007FD588: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007FD58C: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007FD594: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007FD59C: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007FD5A0: 7E081704
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD5A4: 8C7E027E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000007FD5A8: 380C2EFF 000000A0
	s_mov_b32 s2, exec_lo                                      // 0000007FD5B0: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD5B4: BF870001
	.long 0xd4c4007e                                           // 0000007FD5B8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v6, vcc_lo                      // 0000007FD5BC: 02020C14
	s_cbranch_execz 10                                         // 0000007FD5C0: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x2ec>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007FD5C4: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD5C8: BF870091
	.long 0xd7006a05                                           // 0000007FD5CC: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007FD5D0: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007FD5D4: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007FD5DC: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007FD5E4: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007FD5E8: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD5EC: 8C7E027E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000007FD5F0: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007FD5F8: CA100080 07060080
	s_mov_b32 s2, exec_lo                                      // 0000007FD600: BE82007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007FD604: BF870002
	.long 0xd4c4007e                                           // 0000007FD608: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 0000007FD60C: 02021414
	s_cbranch_execz 10                                         // 0000007FD610: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x33c>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007FD614: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD618: BF870091
	.long 0xd7006a0a                                           // 0000007FD61C: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007FD620: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007FD624: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007FD62C: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007FD634: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007FD638: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD63C: 8C7E027E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000007FD640: 38142EFF 000000E0
	s_mov_b32 s2, exec_lo                                      // 0000007FD648: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD64C: BF870001
	.long 0xd4c4007e                                           // 0000007FD650: D4C4007E
	v_cndmask_b32_e32 v1, s20, v10, vcc_lo                     // 0000007FD654: 02021414
	s_cbranch_execz 10                                         // 0000007FD658: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x384>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007FD65C: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD660: BF870091
	.long 0xd7006a0a                                           // 0000007FD664: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007FD668: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007FD66C: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007FD674: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007FD67C: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007FD680: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007FD684: 8C7E027E
	s_branch 9                                                 // 0000007FD688: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x3b0>
	v_mov_b32_e32 v0, 0                                        // 0000007FD68C: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD690: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007FD694: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007FD698: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007FD69C: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007FD6A0: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007FD6A4: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007FD6A8: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007FD6AC: 7E0E0300
	s_add_u32 s2, s4, s14                                      // 0000007FD6B0: 80020E04
	s_addc_u32 s3, s5, s15                                     // 0000007FD6B4: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 0000007FD6B8: 850E9F0B
	v_mov_b32_e32 v26, 0                                       // 0000007FD6BC: 7E340280
	s_add_u32 s14, s10, s14                                    // 0000007FD6C0: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 0000007FD6C4: 820F800B
	v_cndmask_b32_e64 v24, 0, 1, s18                           // 0000007FD6C8: D5010018 00490280
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007FD6D0: 868E810E
	v_mov_b32_e32 v27, 0                                       // 0000007FD6D4: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s14, s[2:3]              // 0000007FD6D8: D6FE7C12 00081D08
	.long 0xd72c000b                                           // 0000007FD6E0: D72C000B
	v_cndmask_b32_e32 v0, v8, v15, vcc_lo                      // 0000007FD6E4: 02001F08
	.long 0xd72c0014                                           // 0000007FD6E8: D72C0014
	v_cndmask_b32_e32 v0, v9, v14, vcc_lo                      // 0000007FD6EC: 02001D09
	.long 0xd4440002                                           // 0000007FD6F0: D4440002
	v_cndmask_b32_e32 v1, s20, v23, vcc_lo                     // 0000007FD6F4: 02022E14
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007FD6F8: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007FD700: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007FD704: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007FD708: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007FD710: 7E160280
	s_and_saveexec_b32 s3, s2                                  // 0000007FD714: BE832002
	s_cbranch_execz 21                                         // 0000007FD718: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007FD71C: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD724: BF870091
	.long 0xd7006a08                                           // 0000007FD728: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007FD72C: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007FD730: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 0000007FD738: 916A127E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007FD73C: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007FD744: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x470>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007FD748: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FD74C: BF870091
	.long 0xd7006a0e                                           // 0000007FD750: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007FD754: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007FD758: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007FD760: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007FD768: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007FD76C: 7E36170E
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007FD770: 8C7E037E
	v_mov_b32_e32 v28, 0                                       // 0000007FD774: 7E380280
	s_and_saveexec_b32 s3, s2                                  // 0000007FD778: BE832002
	s_cbranch_execz 305                                        // 0000007FD77C: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x944>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007FD780: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 0000007FD788: D7006A0C
	v_cndmask_b32_e32 v1, s16, v12, vcc_lo                     // 0000007FD78C: 02021810
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD790: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s17, v13, vcc_lo            // 0000007FD794: D5207C0D 01AA1A11
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007FD79C: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007FD7A4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007FD7A8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD7AC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007FD7B0: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 0000007FD7B8: D656001D 03FD0917 00000200
	.long 0xd7006a0c                                           // 0000007FD7C4: D7006A0C
	v_cndmask_b32_e32 v1, s4, v12, vcc_lo                      // 0000007FD7C8: 02021804
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD7CC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s5, v13, vcc_lo             // 0000007FD7D0: D5207C0D 01AA1A05
	v_mov_b32_e32 v30, v23                                     // 0000007FD7D8: 7E3C0317
	.long 0xd7006a15                                           // 0000007FD7DC: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000007FD7E0: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD7E4: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007FD7E8: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000007FD7F0: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000007FD7F4: 7E340314
	s_mov_b32 s14, 0                                           // 0000007FD7F8: BE8E0080
	s_lshl_b64 s[4:5], s[10:11], 1                             // 0000007FD7FC: 8484810A
	s_branch 243                                               // 0000007FD800: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x8d0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000007FD804: 8C7E0A7E
	.long 0xd73c0020                                           // 0000007FD808: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007FD80C: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 0000007FD810: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 0000007FD818: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 0000007FD81C: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007FD820: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 0000007FD824: 368612FF 000000FF
	.long 0xd7006a38                                           // 0000007FD82C: D7006A38
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 0000007FD830: 02024006
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FD834: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s7, v33, vcc_lo             // 0000007FD838: D5207C39 01AA4207
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000007FD840: 30808082
	.long 0xd7006a3c                                           // 0000007FD844: D7006A3C
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 0000007FD848: 02000938
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FD84C: BF870001
	v_add_co_ci_u32_e64 v61, null, s5, v57, vcc_lo             // 0000007FD850: D5207C3D 01AA7205
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000007FD858: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 0000007FD860: D8D80000 40000040
	s_clause 0x7                                               // 0000007FD868: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 0000007FD86C: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 0000007FD874: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 0000007FD87C: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 0000007FD884: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007FD88C: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 0000007FD894: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000007FD89C: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007FD8A4: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000007FD8AC: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000007FD8B4: 32881286
	ds_load_b32 v65, v65                                       // 0000007FD8B8: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000007FD8C0: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007FD8C4: 32121296
	ds_load_b32 v66, v66                                       // 0000007FD8C8: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007FD8D0: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000007FD8D8: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007FD8DC: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000007FD8E4: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007FD8EC: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007FD8F4: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000007FD8FC: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000007FD904: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 0000007FD90C: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 0000007FD914: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007FD91C: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000007FD920: 02018115
	v_add_nc_u32_e32 v29, 0x200, v29                           // 0000007FD924: 4A3A3AFF 00000200
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007FD92C: D5207C16 01AA2C80
	s_and_b32 s2, exec_lo, s2                                  // 0000007FD934: 8B02027E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007FD938: BF870009
	s_or_b32 s14, s2, s14                                      // 0000007FD93C: 8C0E0E02
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007FD940: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 0000007FD944: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 0000007FD94C: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 0000007FD950: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 0000007FD958: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007FD960: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 0000007FD964: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FD96C: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 0000007FD970: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 0000007FD978: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 0000007FD97C: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007FD980: 32141496
	s_waitcnt lgkmcnt(5)                                       // 0000007FD984: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 0000007FD988: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 0000007FD990: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 0000007FD998: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000007FD9A0: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000007FD9A4: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000007FD9A8: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000007FD9AC: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000007FD9B4: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000007FD9BC: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000007FD9C4: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007FD9CC: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007FD9D0: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000007FD9D4: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000007FD9DC: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000007FD9E0: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007FD9E8: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007FD9F0: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000007FD9F4: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007FD9FC: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000007FDA00: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000007FDA08: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 0000007FDA10: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007FDA18: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 0000007FDA20: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 0000007FDA28: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 0000007FDA30: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 0000007FDA34: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s1                         // 0000007FDA3C: D501002A 0006011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 0000007FDA44: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 0000007FDA48: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 0000007FDA50: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 0000007FDA54: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 0000007FDA58: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 0000007FDA60: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000007FDA68: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 0000007FDA70: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 0000007FDA78: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 0000007FDA80: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 0000007FDA88: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 0000007FDA90: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s1                          // 0000007FDA98: D5010025 00060D05
	v_cndmask_b32_e64 v38, v6, v7, s1                          // 0000007FDAA0: D5010026 00060F06
	v_cndmask_b32_e64 v34, v2, v3, s1                          // 0000007FDAA8: D5010022 00060702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007FDAB0: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000007FDAB4: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000007FDABC: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000007FDAC0: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s1                          // 0000007FDAC8: D5010021 00060501
	v_cndmask_b32_e64 v32, v0, v1, s1                          // 0000007FDAD0: D5010020 00060300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000007FDAD8: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FDAE0: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000007FDAE4: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s1                          // 0000007FDAEC: D5010023 00060903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000007FDAF4: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007FDAFC: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000007FDB00: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s1                          // 0000007FDB08: D5010024 00060B04
	s_waitcnt lgkmcnt(4)                                       // 0000007FDB10: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 0000007FDB14: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007FDB1C: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 0000007FDB20: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 0000007FDB28: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007FDB2C: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 0000007FDB30: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 0000007FDB38: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 0000007FDB3C: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000007FDB44: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 0000007FDB4C: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007FDB50: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 0000007FDB54: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 0000007FDB5C: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 0000007FDB64: 7E4E0307
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007FDB68: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007FDB70: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 0000007FDB74: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 0000007FDB7C: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 0000007FDB84: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FDB88: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 0000007FDB8C: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 0000007FDB94: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FDB9C: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000007FDBA0: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 0000007FDBA4: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 0000007FDBA8: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007FDBB0: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007FDBB8: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007FDBC0: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000007FDBC8: 917E0E7E
	s_cbranch_execz 28                                         // 0000007FDBCC: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x940>
	s_waitcnt vmcnt(0)                                         // 0000007FDBD0: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 0000007FDBD4: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000007FDBDC: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000007FDBE4: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007FDBE8: BF870003
	.long 0xd4430002                                           // 0000007FDBEC: D4430002
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000007FDBF0: 02023C14
	s_mov_b32 s10, exec_lo                                     // 0000007FDBF4: BE8A007E
	.long 0xd4c4007e                                           // 0000007FDBF8: D4C4007E
	v_cndmask_b32_e32 v1, s20, v30, vcc_lo                     // 0000007FDBFC: 02023C14
	s_cbranch_execz 65280                                      // 0000007FDC00: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	.long 0xd7006a0c                                           // 0000007FDC04: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000007FDC08: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FDC0C: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007FDC10: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007FDC18: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 0000007FDC1C: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007FDC20: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 0000007FDC28: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	global_load_d16_b16 v31, v[21:22], off                     // 0000007FDC2C: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000007FDC34: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000007FDC38: 7E3E171F
	s_branch 65265                                             // 0000007FDC3C: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0x504>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007FDC40: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007FDC44: BF8700A9
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007FDC48: 8C7E037E
	.long 0xd71f0000                                           // 0000007FDC4C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007FDC50: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000007FDC54: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000007FDC58: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000007FDC5C: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007FDC60: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007FDC64: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007FDC68: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007FDC6C: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007FDC70: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007FDC74: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007FDC78: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007FDC7C: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 0000007FDC80: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000007FDC88: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 0000007FDC8C: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 0000007FDC94: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 0000007FDC9C: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 0000007FDCA4: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 0000007FDCA8: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000007FDCAC: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007FDCB0: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000007FDCB4: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007FDCBC: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FDCC0: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007FDCC4: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000007FDCC8: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007FDCCC: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007FDCD0: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007FDCD8: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000007FDCE0: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007FDCE4: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007FDCE8: 7C980AA0
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007FDCEC: 020A0B00
	s_waitcnt lgkmcnt(1)                                       // 0000007FDCF0: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 0000007FDCF4: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 0000007FDCFC: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007FDD00: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 0000007FDD04: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007FDD0C: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000007FDD14: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007FDD18: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007FDD1C: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000007FDD20: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007FDD24: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000007FDD28: BF89FC17
	v_dual_add_f32 v0, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000007FDD2C: C9220702 00040082
	s_and_b32 s0, vcc_lo, s0                                   // 0000007FDD34: 8B00006A
	s_waitcnt lgkmcnt(0)                                       // 0000007FDD38: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000007FDD3C: 06020901
	ds_bpermute_b32 v2, v5, v0                                 // 0000007FDD40: DACC0000 02000005
	ds_bpermute_b32 v3, v5, v1                                 // 0000007FDD48: DACC0000 03000105
	s_and_saveexec_b32 s1, s0                                  // 0000007FDD50: BE812000
	s_cbranch_execz 109                                        // 0000007FDD54: BFA5006D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi2ELi1EEEvPKhPKtPvlllllS6_f+0xc0c>
	s_waitcnt lgkmcnt(0)                                       // 0000007FDD58: BF89FC07
	v_dual_add_f32 v0, v0, v2 :: v_dual_add_f32 v1, v1, v3     // 0000007FDD5C: C9080500 00000701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FDD64: BF870111
	v_bfe_u32 v2, v0, 16, 1                                    // 0000007FDD68: D6100002 02052100
	v_bfe_u32 v3, v1, 16, 1                                    // 0000007FDD70: D6100003 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007FDD78: BF870112
	v_add3_u32 v0, v0, v2, 0x7fff                              // 0000007FDD7C: D6550000 03FE0500 00007FFF
	v_add3_u32 v1, v1, v3, 0x7fff                              // 0000007FDD88: D6550001 03FE0701 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDD94: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007FDD98: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000007FDDA0: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007FDDA8: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000007FDDAC: 7E024B01
	v_dual_add_f32 v1, 1.0, v1 :: v_dual_and_b32 v0, 0xffff0000, v0// 0000007FDDB0: C92402F2 010000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDDBC: BF870091
	v_div_scale_f32 v3, null, v1, v1, 1.0                      // 0000007FDDC0: D6FC7C03 03CA0301
	v_rcp_f32_e32 v5, v3                                       // 0000007FDDC8: 7E0A5503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDDCC: BF870095
	v_fma_f32 v7, -v3, v5, 1.0                                 // 0000007FDDD0: D6130007 23CA0B03
	v_dual_mul_f32 v0, 0xbfb8aa3b, v0 :: v_dual_fmac_f32 v5, v7, v5// 0000007FDDD8: C8C000FF 00040B07 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007FDDE4: BF870291
	v_exp_f32_e32 v0, v0                                       // 0000007FDDE8: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 0000007FDDEC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007FDDF0: BF870131
	v_div_scale_f32 v2, null, v0, v0, 1.0                      // 0000007FDDF4: D6FC7C02 03CA0100
	s_waitcnt vmcnt(0)                                         // 0000007FDDFC: BF8903F7
	v_div_scale_f32 v8, vcc_lo, 1.0, v0, 1.0                   // 0000007FDE00: D6FC6A08 03CA00F2
	v_rcp_f32_e32 v4, v2                                       // 0000007FDE08: 7E085502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDE0C: BF870095
	v_fma_f32 v6, -v2, v4, 1.0                                 // 0000007FDE10: D6130006 23CA0902
	v_fmac_f32_e32 v4, v6, v4                                  // 0000007FDE18: 56080906
	v_div_scale_f32 v6, s0, 1.0, v1, 1.0                       // 0000007FDE1C: D6FC0006 03CA02F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDE24: BF870092
	v_mul_f32_e32 v7, v8, v4                                   // 0000007FDE28: 100E0908
	v_fma_f32 v10, -v2, v7, v8                                 // 0000007FDE2C: D613000A 24220F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDE34: BF870091
	v_fmac_f32_e32 v7, v10, v4                                 // 0000007FDE38: 560E090A
	v_fma_f32 v2, -v2, v7, v8                                  // 0000007FDE3C: D6130002 24220F02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007FDE44: BF870001
	v_div_fmas_f32 v2, v2, v4, v7                              // 0000007FDE48: D6370002 041E0902
	.long 0x7f083880                                           // 0000007FDE50: 7F083880
	v_mul_f32_e32 v9, v6, v5                                   // 0000007FDE54: 10120B06
	s_mov_b32 vcc_lo, s0                                       // 0000007FDE58: BEEA0000
	s_lshl_b64 s[0:1], s[12:13], 1                             // 0000007FDE5C: 8480810C
	v_div_fixup_f32 v2, v2, v0, 1.0                            // 0000007FDE60: D6270002 03CA0102
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDE68: BF870092
	v_fma_f32 v11, -v3, v9, v6                                 // 0000007FDE6C: D613000B 241A1303
	v_fmac_f32_e32 v9, v11, v5                                 // 0000007FDE74: 56120B0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007FDE78: BF870091
	v_fma_f32 v3, -v3, v9, v6                                  // 0000007FDE7C: D6130003 241A1303
	v_div_fmas_f32 v3, v3, v5, v9                              // 0000007FDE84: D6370003 04260B03
	.long 0x7f0a3984                                           // 0000007FDE8C: 7F0A3984
	.long 0x7e0a3982                                           // 0000007FDE90: 7E0A3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007FDE94: BF8701A3
	v_div_fixup_f32 v3, v3, v1, 1.0                            // 0000007FDE98: D6270003 03CA0303
	.long 0xd73c0000                                           // 0000007FDEA0: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007FDEA4: 02022081
	v_and_b32_e32 v5, 1, v5                                    // 0000007FDEA8: 360A0A81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FDEAC: BF870193
	.long 0x7e083983                                           // 0000007FDEB0: 7E083983
	.long 0xd7006a00                                           // 0000007FDEB4: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 0000007FDEB8: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FDEBC: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 0000007FDEC0: D5207C01 01AA0209
	v_and_b32_e32 v4, 1, v4                                    // 0000007FDEC8: 36080881
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000007FDECC: D6550005 03FE0B02 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007FDED8: BF870194
	.long 0xd7006a02                                           // 0000007FDEDC: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007FDEE0: 02000100
	v_add3_u32 v4, v3, v4, 0x7fff                              // 0000007FDEE4: D6550004 03FE0903 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007FDEF0: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007FDEF8: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007FDEFC: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000007FDF04: DC960000 007C0402
	s_endpgm                                                   // 0000007FDF0C: BFB00000
		...

