00000000007c2000 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007C2000: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007C2008: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007C200C: 32040082
	v_lshrrev_b32_e32 v22, 5, v0                               // 0000007C2010: 322C0085
	v_and_b32_e32 v23, 31, v0                                  // 0000007C2014: 362E009F
	.long 0x7f0a3880                                           // 0000007C2018: 7F0A3880
	v_lshlrev_b32_e32 v21, 2, v0                               // 0000007C201C: 302A0082
	s_waitcnt lgkmcnt(0)                                       // 0000007C2020: BF89FC07
	.long 0xd4510004                                           // 0000007C2024: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007C2028: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000007C202C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000007C2030: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000007C2034: 98078002
	s_add_u32 s4, s8, s20                                      // 0000007C2038: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000007C203C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000007C2040: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007C2044: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000007C2048: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C204C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000007C2050: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007C2054: 30020282
	s_add_u32 s20, s14, s20                                    // 0000007C2058: 8014140E
	s_clause 0x1                                               // 0000007C205C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007C2060: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007C2068: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000007C2070: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000007C2074: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007C2078: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000007C207C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000007C2080: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000007C2084: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000007C2088: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007C208C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000007C2090: 85049D18
	v_mad_u64_u32 v[17:18], null, s22, s7, v[1:2]              // 0000007C2094: D6FE7C11 04040E16
	s_add_i32 s21, s21, s4                                     // 0000007C209C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000007C20A0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000007C20A4: B3940801
	.long 0xd72c0001                                           // 0000007C20A8: D72C0001
	v_cndmask_b32_e32 v1, s4, v22, vcc_lo                      // 0000007C20AC: 02022C04
	s_mul_i32 s21, s22, s6                                     // 0000007C20B0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007C20B4: BF870141
	v_add_nc_u32_e32 v7, s4, v1                                // 0000007C20B8: 4A0E0204
	v_add_nc_u32_e32 v24, v1, v23                              // 0000007C20BC: 4A302F01
	s_cselect_b32 s4, -1, 0                                    // 0000007C20C0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000007C20C4: B2940800
	v_min_i32_e32 v25, s20, v7                                 // 0000007C20C8: 22320E14
	s_cselect_b32 s20, -1, 0                                   // 0000007C20CC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007C20D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000007C20D4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000007C20D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007C20DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007C20E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000007C20E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007C20F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v18                               // 0000007C20FC: 4A062405
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C2100: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000007C2104: D6550004 03FE0D04 00007FFF
	.long 0xd4410005                                           // 0000007C2110: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C2114: 02023318
	.long 0x7e0a3982                                           // 0000007C2118: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C211C: BF870114
	v_add_nc_u32_e32 v26, s21, v3                              // 0000007C2120: 4A340615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007C2124: D6570001 041608FF FFFF0000
	ds_store_b32 v21, v1                                       // 0000007C2130: D8340000 00000115
	s_waitcnt lgkmcnt(0)                                       // 0000007C2138: BF89FC07
	s_barrier                                                  // 0000007C213C: BFBD0000
	buffer_gl0_inv                                             // 0000007C2140: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007C2148: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007C214C: CA100080 02000080
	s_and_saveexec_b32 s21, s5                                 // 0000007C2154: BE952005
	s_cbranch_execz 11                                         // 0000007C2158: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v24                               // 0000007C215C: 30023081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2160: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007C2164: 3408029F
	.long 0xd7006a03                                           // 0000007C2168: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007C216C: 02020311
	v_add_co_ci_u32_e64 v4, null, v26, v4, vcc_lo              // 0000007C2170: D5207C04 01AA091A
	global_load_d16_b16 v1, v[3:4], off                        // 0000007C2178: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007C2180: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007C2184: 7E021701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000007C2188: 8C7E157E
	v_add_nc_u32_e32 v3, 32, v24                               // 0000007C218C: 4A0630A0
	s_mov_b32 s5, exec_lo                                      // 0000007C2190: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C2194: BF870001
	.long 0xd4c1007e                                           // 0000007C2198: D4C1007E
	v_cndmask_b32_e32 v1, v3, v25, vcc_lo                      // 0000007C219C: 02023303
	s_cbranch_execz 11                                         // 0000007C21A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007C21A4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C21A8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007C21AC: 3406049F
	.long 0xd7006a02                                           // 0000007C21B0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007C21B4: 02020511
	v_add_co_ci_u32_e64 v3, null, v26, v3, vcc_lo              // 0000007C21B8: D5207C03 01AA071A
	global_load_d16_b16 v2, v[2:3], off                        // 0000007C21C0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007C21C8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007C21CC: 7E041702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C21D0: 8C7E057E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v24      // 0000007C21D4: CA200080 040430C0
	v_mov_b32_e32 v3, 0                                        // 0000007C21DC: 7E060280
	s_mov_b32 s5, exec_lo                                      // 0000007C21E0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C21E4: BF870002
	.long 0xd4c1007e                                           // 0000007C21E8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007C21EC: 02023305
	s_cbranch_execz 11                                         // 0000007C21F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007C21F4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C21F8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007C21FC: 340C069F
	.long 0xd7006a05                                           // 0000007C2200: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007C2204: 02020711
	v_add_co_ci_u32_e64 v6, null, v26, v6, vcc_lo              // 0000007C2208: D5207C06 01AA0D1A
	global_load_d16_b16 v3, v[5:6], off                        // 0000007C2210: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007C2218: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007C221C: 7E061703
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C2220: 8C7E057E
	v_add_nc_u32_e32 v5, 0x60, v24                             // 0000007C2224: 4A0A30FF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000007C222C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C2230: BF870001
	.long 0xd4c1007e                                           // 0000007C2234: D4C1007E
	v_cndmask_b32_e32 v1, v5, v25, vcc_lo                      // 0000007C2238: 02023305
	s_cbranch_execz 11                                         // 0000007C223C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007C2240: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2244: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007C2248: 340A089F
	.long 0xd7006a04                                           // 0000007C224C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007C2250: 02020911
	v_add_co_ci_u32_e64 v5, null, v26, v5, vcc_lo              // 0000007C2254: D5207C05 01AA0B1A
	global_load_d16_b16 v4, v[4:5], off                        // 0000007C225C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007C2264: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007C2268: 7E081704
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C226C: 8C7E057E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v24    // 0000007C2270: CA200080 060630FF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007C227C: 7E0A0280
	s_mov_b32 s5, exec_lo                                      // 0000007C2280: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C2284: BF870002
	.long 0xd4c1007e                                           // 0000007C2288: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007C228C: 02023307
	s_cbranch_execz 11                                         // 0000007C2290: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007C2294: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2298: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007C229C: 34100A9F
	.long 0xd7006a07                                           // 0000007C22A0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007C22A4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v26, v8, vcc_lo              // 0000007C22A8: D5207C08 01AA111A
	global_load_d16_b16 v5, v[7:8], off                        // 0000007C22B0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007C22B8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007C22BC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C22C0: 8C7E057E
	v_add_nc_u32_e32 v7, 0xa0, v24                             // 0000007C22C4: 4A0E30FF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000007C22CC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C22D0: BF870001
	.long 0xd4c1007e                                           // 0000007C22D4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v25, vcc_lo                      // 0000007C22D8: 02023307
	s_cbranch_execz 11                                         // 0000007C22DC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007C22E0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C22E4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007C22E8: 340E0C9F
	.long 0xd7006a06                                           // 0000007C22EC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007C22F0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v26, v7, vcc_lo              // 0000007C22F4: D5207C07 01AA0F1A
	global_load_d16_b16 v6, v[6:7], off                        // 0000007C22FC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007C2304: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007C2308: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C230C: 8C7E057E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v24    // 0000007C2310: CA200080 080830FF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007C231C: 7E0E0280
	s_mov_b32 s5, exec_lo                                      // 0000007C2320: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C2324: BF870002
	.long 0xd4c1007e                                           // 0000007C2328: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007C232C: 02023309
	s_cbranch_execz 11                                         // 0000007C2330: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000007C2334: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2338: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000007C233C: 34140E9F
	.long 0xd7006a09                                           // 0000007C2340: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007C2344: 02020F11
	v_add_co_ci_u32_e64 v10, null, v26, v10, vcc_lo            // 0000007C2348: D5207C0A 01AA151A
	global_load_d16_b16 v7, v[9:10], off                       // 0000007C2350: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000007C2358: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007C235C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C2360: 8C7E057E
	v_add_nc_u32_e32 v9, 0xe0, v24                             // 0000007C2364: 4A1230FF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000007C236C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C2370: BF870001
	.long 0xd4c1007e                                           // 0000007C2374: D4C1007E
	v_cndmask_b32_e32 v1, v9, v25, vcc_lo                      // 0000007C2378: 02023309
	s_cbranch_execz 11                                         // 0000007C237C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000007C2380: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2384: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000007C2388: 3412109F
	.long 0xd7006a08                                           // 0000007C238C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007C2390: 02021111
	v_add_co_ci_u32_e64 v9, null, v26, v9, vcc_lo              // 0000007C2394: D5207C09 01AA131A
	global_load_d16_b16 v8, v[8:9], off                        // 0000007C239C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000007C23A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007C23A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007C23AC: 8C7E057E
	s_branch 9                                                 // 0000007C23B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000007C23B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C23B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007C23BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007C23C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007C23C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007C23C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007C23CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007C23D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007C23D4: 7E100301
	s_add_u32 s8, s8, s18                                      // 0000007C23D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000007C23DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000007C23E0: 85059F0F
	v_dual_mov_b32 v9, s7 :: v_dual_mov_b32 v10, 0             // 0000007C23E4: CA100007 090A0080
	s_add_u32 s18, s14, s5                                     // 0000007C23EC: 8012050E
	s_addc_u32 s19, s15, 0                                     // 0000007C23F0: 8213800F
	.long 0xd4410005                                           // 0000007C23F4: D4410005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C23F8: 02023318
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007C23FC: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000007C2400: 7E360280
	v_mad_u64_u32 v[18:19], null, v9, s18, s[8:9]              // 0000007C2404: D6FE7C12 00202509
	.long 0xd72c000b                                           // 0000007C240C: D72C000B
	v_cndmask_b32_e32 v0, s7, v19, vcc_lo                      // 0000007C2410: 02002607
	.long 0xd72c000c                                           // 0000007C2414: D72C000C
	v_cndmask_b32_e32 v0, s6, v18, vcc_lo                      // 0000007C2418: 02002406
	v_mov_b32_e32 v9, 0                                        // 0000007C241C: 7E120280
	v_cndmask_b32_e64 v28, 0, 1, s20                           // 0000007C2420: D501001C 00510280
	v_mov_b32_e32 v35, 0                                       // 0000007C2428: 7E460280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007C242C: BF870004
	v_add3_u32 v29, v12, v19, v11                              // 0000007C2430: D655001D 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 0000007C2438: CA100080 0B0C0080
	s_and_saveexec_b32 s6, s5                                  // 0000007C2440: BE862005
	s_cbranch_execz 22                                         // 0000007C2444: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v24                               // 0000007C2448: 30123084
	v_mov_b32_e32 v35, 0                                       // 0000007C244C: 7E460280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2450: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007C2454: 3414129F
	.long 0xd7006a09                                           // 0000007C2458: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007C245C: 02021312
	v_add_co_ci_u32_e64 v10, null, v29, v10, vcc_lo            // 0000007C2460: D5207C0A 01AA151D
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000007C2468: 916A147E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007C246C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007C2474: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v24                              // 0000007C2478: 301A3081
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C247C: BF870091
	.long 0xd7006a0d                                           // 0000007C2480: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007C2484: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v26, vcc_lo              // 0000007C2488: D5207C0E 01AA3480
	global_load_d16_b16 v13, v[13:14], off                     // 0000007C2490: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007C2498: BF8903F7
	v_cvt_f32_f16_e32 v35, v13                                 // 0000007C249C: 7E46170D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007C24A0: 8C7E067E
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v30, 0             // 0000007C24A4: CA100080 1F1E0080
	s_and_saveexec_b32 s18, s5                                 // 0000007C24AC: BE922005
	s_cbranch_execz 338                                        // 0000007C24B0: BFA50152 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x9fc>
	v_dual_mov_b32 v30, 0 :: v_dual_add_nc_u32 v13, 32, v24    // 0000007C24B4: CA200080 1E0C30A0
	v_dual_mov_b32 v34, v35 :: v_dual_lshlrev_b32 v19, 5, v24  // 0000007C24BC: CA220123 22123085
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C24C4: BF870002
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v32, 4, v13    // 0000007C24C8: CA220080 1F201A84
	v_lshlrev_b32_e32 v33, 1, v13                              // 0000007C24D0: 30421A81
	v_mov_b32_e32 v27, 0                                       // 0000007C24D4: 7E360280
	s_lshl_b64 s[6:7], s[14:15], 2                             // 0000007C24D8: 8486820E
	s_mov_b32 s19, 0                                           // 0000007C24DC: BE930080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007C24E0: 8488810E
	s_branch 289                                               // 0000007C24E4: BFA00121 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x96c>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007C24E8: 8C7E0E7E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007C24EC: 3428269F
	v_cndmask_b32_e64 v84, v35, v1, s4                         // 0000007C24F0: D5010054 00120323
	v_lshrrev_b32_e32 v35, 6, v9                               // 0000007C24F8: 32461286
	v_lshrrev_b32_e32 v85, 14, v9                              // 0000007C24FC: 32AA128E
	v_and_b32_e32 v86, 0xff, v10                               // 0000007C2500: 36AC14FF 000000FF
	.long 0xd73c0024                                           // 0000007C2508: D73C0024
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007C250C: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007C2510: 362812FF 000000FF
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007C2518: 364646FF 000003FC
	v_and_b32_e32 v85, 0x3fc, v85                              // 0000007C2520: 36AAAAFF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007C2528: 32121296
	v_lshrrev_b32_e32 v87, 6, v10                              // 0000007C252C: 32AE1486
	.long 0xd7006a48                                           // 0000007C2530: D7006A48
	v_cndmask_b32_e32 v1, s10, v36, vcc_lo                     // 0000007C2534: 0202480A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007C2538: BF8701A1
	v_add_co_ci_u32_e64 v73, null, s11, v37, vcc_lo            // 0000007C253C: D5207C49 01AA4A0B
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007C2544: 30282882
	.long 0xd7006a4c                                           // 0000007C2548: D7006A4C
	v_cndmask_b32_e32 v0, v72, v8, vcc_lo                      // 0000007C254C: 02001148
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2550: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s9, v73, vcc_lo             // 0000007C2554: D5207C4D 01AA9209
	.long 0xd7006a50                                           // 0000007C255C: D7006A50
	v_cndmask_b32_e32 v0, v72, v6, vcc_lo                      // 0000007C2560: 02000D48
	v_add_co_ci_u32_e64 v81, null, s7, v73, vcc_lo             // 0000007C2564: D5207C51 01AA9207
	s_clause 0xb                                               // 0000007C256C: BF85000B
	global_load_b128 v[36:39], v[72:73], off                   // 0000007C2570: DC5E0000 247C0048
	global_load_b128 v[40:43], v[76:77], off                   // 0000007C2578: DC5E0000 287C004C
	global_load_b128 v[44:47], v[80:81], off                   // 0000007C2580: DC5E0000 2C7C0050
	global_load_b128 v[48:51], v[72:73], off offset:16         // 0000007C2588: DC5E0010 307C0048
	global_load_b128 v[52:55], v[76:77], off offset:16         // 0000007C2590: DC5E0010 347C004C
	global_load_b128 v[56:59], v[80:81], off offset:16         // 0000007C2598: DC5E0010 387C0050
	global_load_b128 v[60:63], v[72:73], off offset:32         // 0000007C25A0: DC5E0020 3C7C0048
	global_load_b128 v[64:67], v[76:77], off offset:32         // 0000007C25A8: DC5E0020 407C004C
	global_load_b128 v[68:71], v[80:81], off offset:32         // 0000007C25B0: DC5E0020 447C0050
	global_load_b128 v[72:75], v[72:73], off offset:48         // 0000007C25B8: DC5E0030 487C0048
	global_load_b128 v[76:79], v[76:77], off offset:48         // 0000007C25C0: DC5E0030 4C7C004C
	global_load_b128 v[80:83], v[80:81], off offset:48         // 0000007C25C8: DC5E0030 507C0050
	ds_load_b32 v20, v20                                       // 0000007C25D0: D8D80000 14000014
	ds_load_b32 v35, v35                                       // 0000007C25D8: D8D80000 23000023
	ds_load_b32 v85, v85                                       // 0000007C25E0: D8D80000 55000055
	v_lshrrev_b32_e32 v88, 14, v10                             // 0000007C25E8: 32B0148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007C25EC: 32141496
	v_lshlrev_b32_e32 v86, 2, v86                              // 0000007C25F0: 30ACAC82
	v_and_b32_e32 v87, 0x3fc, v87                              // 0000007C25F4: 36AEAEFF 000003FC
	v_and_b32_e32 v89, 0xff, v11                               // 0000007C25FC: 36B216FF 000000FF
	v_and_b32_e32 v88, 0x3fc, v88                              // 0000007C2604: 36B0B0FF 000003FC
	v_lshrrev_b32_e32 v90, 6, v11                              // 0000007C260C: 32B41686
	v_lshrrev_b32_e32 v91, 14, v11                             // 0000007C2610: 32B6168E
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007C2614: 32161696
	v_lshrrev_b32_e32 v93, 14, v12                             // 0000007C2618: 32BA188E
	v_add_nc_u32_e32 v33, 64, v33                              // 0000007C261C: 4A4242C0
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007C2620: 4A2626FF 00000400
	s_and_b32 s5, exec_lo, s5                                  // 0000007C2628: 8B05057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C262C: BF870009
	s_or_b32 s19, s5, s19                                      // 0000007C2630: 8C131305
	s_waitcnt vmcnt(11) lgkmcnt(2)                             // 0000007C2634: BF892C27
	v_dot2_f32_bf16 v36, v36, v20, 0                           // 0000007C2638: CC1A4024 1A022924
	s_waitcnt vmcnt(10)                                        // 0000007C2640: BF892BF7
	v_dot2_f32_bf16 v40, v40, v20, 0                           // 0000007C2644: CC1A4028 1A022928
	s_waitcnt vmcnt(9)                                         // 0000007C264C: BF8927F7
	v_dot2_f32_bf16 v20, v44, v20, 0                           // 0000007C2650: CC1A4014 1A02292C
	v_lshrrev_b32_e32 v44, 6, v12                              // 0000007C2658: 32581886
	s_waitcnt lgkmcnt(1)                                       // 0000007C265C: BF89FC17
	v_dot2_f32_bf16 v36, v37, v35, v36                         // 0000007C2660: CC1A4024 1C924725
	v_dot2_f32_bf16 v37, v41, v35, v40                         // 0000007C2668: CC1A4025 1CA24729
	v_dot2_f32_bf16 v20, v45, v35, v20                         // 0000007C2670: CC1A4014 1C52472D
	v_and_b32_e32 v40, 0x3fc, v91                              // 0000007C2678: 3650B6FF 000003FC
	v_and_b32_e32 v41, 0x3fc, v93                              // 0000007C2680: 3652BAFF 000003FC
	s_waitcnt lgkmcnt(0)                                       // 0000007C2688: BF89FC07
	v_dot2_f32_bf16 v36, v38, v85, v36                         // 0000007C268C: CC1A4024 1C92AB26
	v_dot2_f32_bf16 v37, v42, v85, v37                         // 0000007C2694: CC1A4025 1C96AB2A
	v_cndmask_b32_e64 v42, v7, v8, s4                          // 0000007C269C: D501002A 00121107
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007C26A4: 361212FF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007C26AC: 361414FF 000003FC
	ds_load_b32 v9, v9                                         // 0000007C26B4: D8D80000 09000009
	ds_load_b32 v86, v86                                       // 0000007C26BC: D8D80000 56000056
	ds_load_b32 v87, v87                                       // 0000007C26C4: D8D80000 57000057
	ds_load_b32 v88, v88                                       // 0000007C26CC: D8D80000 58000058
	ds_load_b32 v10, v10                                       // 0000007C26D4: D8D80000 0A00000A
	v_dot2_f32_bf16 v20, v46, v85, v20                         // 0000007C26DC: CC1A4014 1C52AB2E
	v_lshlrev_b32_e32 v35, 2, v89                              // 0000007C26E4: 3046B282
	v_and_b32_e32 v38, 0x3fc, v90                              // 0000007C26E8: 364CB4FF 000003FC
	ds_load_b32 v35, v35                                       // 0000007C26F0: D8D80000 23000023
	ds_load_b32 v38, v38                                       // 0000007C26F8: D8D80000 26000026
	s_waitcnt lgkmcnt(6)                                       // 0000007C2700: BF89FC67
	v_dot2_f32_bf16 v36, v39, v9, v36                          // 0000007C2704: CC1A4024 1C921327
	v_dot2_f32_bf16 v37, v43, v9, v37                          // 0000007C270C: CC1A4025 1C96132B
	v_dot2_f32_bf16 v9, v47, v9, v20                           // 0000007C2714: CC1A4009 1C52132F
	ds_load_b32 v43, v40                                       // 0000007C271C: D8D80000 2B000028
	v_and_b32_e32 v92, 0xff, v12                               // 0000007C2724: 36B818FF 000000FF
	s_waitcnt vmcnt(8) lgkmcnt(6)                              // 0000007C272C: BF892067
	v_dot2_f32_bf16 v36, v48, v86, v36                         // 0000007C2730: CC1A4024 1C92AD30
	s_waitcnt vmcnt(7)                                         // 0000007C2738: BF891FF7
	v_dot2_f32_bf16 v37, v52, v86, v37                         // 0000007C273C: CC1A4025 1C96AD34
	s_waitcnt vmcnt(6)                                         // 0000007C2744: BF891BF7
	v_dot2_f32_bf16 v9, v56, v86, v9                           // 0000007C2748: CC1A4009 1C26AD38
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007C2750: 32181896
	v_cndmask_b32_e64 v40, v5, v6, s4                          // 0000007C2754: D5010028 00120D05
	s_waitcnt lgkmcnt(5)                                       // 0000007C275C: BF89FC57
	v_dot2_f32_bf16 v36, v49, v87, v36                         // 0000007C2760: CC1A4024 1C92AF31
	v_dot2_f32_bf16 v37, v53, v87, v37                         // 0000007C2768: CC1A4025 1C96AF35
	v_dot2_f32_bf16 v9, v57, v87, v9                           // 0000007C2770: CC1A4009 1C26AF39
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007C2778: 361616FF 000003FC
	v_lshlrev_b32_e32 v20, 2, v92                              // 0000007C2780: 3028B882
	s_waitcnt lgkmcnt(4)                                       // 0000007C2784: BF89FC47
	v_dot2_f32_bf16 v36, v50, v88, v36                         // 0000007C2788: CC1A4024 1C92B132
	v_dot2_f32_bf16 v37, v54, v88, v37                         // 0000007C2790: CC1A4025 1C96B136
	v_dot2_f32_bf16 v9, v58, v88, v9                           // 0000007C2798: CC1A4009 1C26B13A
	v_and_b32_e32 v39, 0x3fc, v44                              // 0000007C27A0: 364E58FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007C27A8: 361818FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007C27B0: BF89FC37
	v_dot2_f32_bf16 v36, v51, v10, v36                         // 0000007C27B4: CC1A4024 1C921533
	v_dot2_f32_bf16 v37, v55, v10, v37                         // 0000007C27BC: CC1A4025 1C961537
	v_dot2_f32_bf16 v9, v59, v10, v9                           // 0000007C27C4: CC1A4009 1C26153B
	ds_load_b32 v10, v11                                       // 0000007C27CC: D8D80000 0A00000B
	ds_load_b32 v11, v20                                       // 0000007C27D4: D8D80000 0B000014
	ds_load_b32 v20, v39                                       // 0000007C27DC: D8D80000 14000027
	ds_load_b32 v44, v41                                       // 0000007C27E4: D8D80000 2C000029
	ds_load_b32 v45, v12                                       // 0000007C27EC: D8D80000 2D00000C
	v_cndmask_b32_e64 v41, v6, v7, s4                          // 0000007C27F4: D5010029 00120F06
	s_waitcnt vmcnt(5) lgkmcnt(7)                              // 0000007C27FC: BF891477
	v_dot2_f32_bf16 v12, v60, v35, v36                         // 0000007C2800: CC1A400C 1C92473C
	s_waitcnt vmcnt(4)                                         // 0000007C2808: BF8913F7
	v_dot2_f32_bf16 v36, v64, v35, v37                         // 0000007C280C: CC1A4024 1C964740
	s_waitcnt vmcnt(3)                                         // 0000007C2814: BF890FF7
	v_dot2_f32_bf16 v9, v68, v35, v9                           // 0000007C2818: CC1A4009 1C264744
	v_cndmask_b32_e64 v39, v4, v5, s4                          // 0000007C2820: D5010027 00120B04
	v_cndmask_b32_e64 v37, v2, v3, s4                          // 0000007C2828: D5010025 00120702
	s_waitcnt lgkmcnt(6)                                       // 0000007C2830: BF89FC67
	v_dot2_f32_bf16 v7, v61, v38, v12                          // 0000007C2834: CC1A4007 1C324D3D
	v_dot2_f32_bf16 v12, v65, v38, v36                         // 0000007C283C: CC1A400C 1C924D41
	v_dot2_f32_bf16 v9, v69, v38, v9                           // 0000007C2844: CC1A4009 1C264D45
	v_cndmask_b32_e64 v38, v3, v4, s4                          // 0000007C284C: D5010026 00120903
	v_cndmask_b32_e64 v36, v1, v2, s4                          // 0000007C2854: D5010024 00120501
	s_waitcnt lgkmcnt(5)                                       // 0000007C285C: BF89FC57
	v_dot2_f32_bf16 v5, v62, v43, v7                           // 0000007C2860: CC1A4005 1C1E573E
	v_dot2_f32_bf16 v6, v66, v43, v12                          // 0000007C2868: CC1A4006 1C325742
	v_dot2_f32_bf16 v7, v70, v43, v9                           // 0000007C2870: CC1A4007 1C265746
	v_dual_mov_b32 v43, v8 :: v_dual_add_nc_u32 v32, 0x200, v32// 0000007C2878: CA200108 2B2040FF 00000200
	s_waitcnt lgkmcnt(4)                                       // 0000007C2884: BF89FC47
	v_dot2_f32_bf16 v3, v63, v10, v5                           // 0000007C2888: CC1A4003 1C16153F
	v_dot2_f32_bf16 v4, v67, v10, v6                           // 0000007C2890: CC1A4004 1C1A1543
	v_dot2_f32_bf16 v5, v71, v10, v7                           // 0000007C2898: CC1A4005 1C1E1547
	v_mov_b32_e32 v12, v16                                     // 0000007C28A0: 7E180310
	v_mov_b32_e32 v10, v14                                     // 0000007C28A4: 7E14030E
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 0000007C28A8: BF890837
	v_dot2_f32_bf16 v1, v72, v11, v3                           // 0000007C28AC: CC1A4001 1C0E1748
	s_waitcnt vmcnt(1)                                         // 0000007C28B4: BF8907F7
	v_dot2_f32_bf16 v2, v76, v11, v4                           // 0000007C28B8: CC1A4002 1C12174C
	s_waitcnt vmcnt(0)                                         // 0000007C28C0: BF8903F7
	v_dot2_f32_bf16 v3, v80, v11, v5                           // 0000007C28C4: CC1A4003 1C161750
	v_mov_b32_e32 v11, v15                                     // 0000007C28CC: 7E16030F
	v_mov_b32_e32 v9, v13                                      // 0000007C28D0: 7E12030D
	s_waitcnt lgkmcnt(2)                                       // 0000007C28D4: BF89FC27
	v_dot2_f32_bf16 v1, v73, v20, v1                           // 0000007C28D8: CC1A4001 1C062949
	v_dot2_f32_bf16 v2, v77, v20, v2                           // 0000007C28E0: CC1A4002 1C0A294D
	v_dot2_f32_bf16 v3, v81, v20, v3                           // 0000007C28E8: CC1A4003 1C0E2951
	v_mov_b32_e32 v35, v34                                     // 0000007C28F0: 7E460322
	s_waitcnt lgkmcnt(1)                                       // 0000007C28F4: BF89FC17
	v_dot2_f32_bf16 v1, v74, v44, v1                           // 0000007C28F8: CC1A4001 1C06594A
	v_dot2_f32_bf16 v2, v78, v44, v2                           // 0000007C2900: CC1A4002 1C0A594E
	v_dot2_f32_bf16 v3, v82, v44, v3                           // 0000007C2908: CC1A4003 1C0E5952
	s_waitcnt lgkmcnt(0)                                       // 0000007C2910: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C2914: BF870193
	v_dot2_f32_bf16 v1, v75, v45, v1                           // 0000007C2918: CC1A4001 1C065B4B
	v_dot2_f32_bf16 v2, v79, v45, v2                           // 0000007C2920: CC1A4002 1C0A5B4F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C2928: BF870193
	v_dot2_f32_bf16 v3, v83, v45, v3                           // 0000007C292C: CC1A4003 1C0E5B53
	v_fmac_f32_e32 v30, v84, v1                                // 0000007C2934: 563C0354
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C2938: BF870193
	v_fmac_f32_e32 v31, v84, v2                                // 0000007C293C: 563E0554
	v_fmac_f32_e32 v27, v84, v3                                // 0000007C2940: 56360754
	v_dual_mov_b32 v1, v36 :: v_dual_mov_b32 v2, v37           // 0000007C2944: CA100124 01020125
	v_dual_mov_b32 v3, v38 :: v_dual_mov_b32 v4, v39           // 0000007C294C: CA100126 03040127
	v_dual_mov_b32 v5, v40 :: v_dual_mov_b32 v6, v41           // 0000007C2954: CA100128 05060129
	v_dual_mov_b32 v7, v42 :: v_dual_mov_b32 v8, v43           // 0000007C295C: CA10012A 0708012B
	s_and_not1_b32 exec_lo, exec_lo, s19                       // 0000007C2964: 917E137E
	s_cbranch_execz 35                                         // 0000007C2968: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x9f8>
	s_waitcnt vmcnt(0)                                         // 0000007C296C: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v24, 32, v24   // 0000007C2970: CA200109 0D1830A0
	v_dual_mov_b32 v14, v10 :: v_dual_mov_b32 v15, v11         // 0000007C2978: CA10010A 0E0E010B
	v_mov_b32_e32 v16, v12                                     // 0000007C2980: 7E20030C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C2984: BF870003
	.long 0xd4460005                                           // 0000007C2988: D4460005
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C298C: 02023318
	s_mov_b32 s14, exec_lo                                     // 0000007C2990: BE8E007E
	.long 0xd4c1007e                                           // 0000007C2994: D4C1007E
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 0000007C2998: 02023318
	s_cbranch_execz 65234                                      // 0000007C299C: BFA5FED2 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v14, 31, v32                             // 0000007C29A0: 341C409F
	.long 0xd7006a0d                                           // 0000007C29A4: D7006A0D
	v_cndmask_b32_e32 v1, v18, v32, vcc_lo                     // 0000007C29A8: 02024112
	v_mov_b32_e32 v34, v35                                     // 0000007C29AC: 7E440323
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C29B0: BF870003
	v_add_co_ci_u32_e64 v14, null, v29, v14, vcc_lo            // 0000007C29B4: D5207C0E 01AA1D1D
	v_cmp_ne_u32_e32 vcc_lo, 1, v28                            // 0000007C29BC: 7C9A3881
	global_load_b128 v[13:16], v[13:14], off                   // 0000007C29C0: DC5E0000 0D7C000D
	s_cbranch_vccnz 65223                                      // 0000007C29C8: BFA4FEC7 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	v_ashrrev_i32_e32 v20, 31, v33                             // 0000007C29CC: 3428429F
	.long 0xd7006a24                                           // 0000007C29D0: D7006A24
	v_cndmask_b32_e32 v1, v17, v33, vcc_lo                     // 0000007C29D4: 02024311
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007C29D8: BF870001
	v_add_co_ci_u32_e64 v37, null, v26, v20, vcc_lo            // 0000007C29DC: D5207C25 01AA291A
	global_load_d16_b16 v20, v[36:37], off                     // 0000007C29E4: DC820000 147C0024
	s_waitcnt vmcnt(0)                                         // 0000007C29EC: BF8903F7
	v_cvt_f32_f16_e32 v34, v20                                 // 0000007C29F0: 7E441714
	s_branch 65212                                             // 0000007C29F4: BFA0FEBC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4e8>
	s_or_b32 exec_lo, exec_lo, s19                             // 0000007C29F8: 8C7E137E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C29FC: BF8700B9
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007C2A00: 8C7E127E
	.long 0xd71f0001                                           // 0000007C2A04: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007C2A08: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007C2A0C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007C2A10: 3A040290
	v_xor_b32_e32 v5, 8, v1                                    // 0000007C2A14: 3A0A0288
	v_xor_b32_e32 v8, 4, v1                                    // 0000007C2A18: 3A100284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007C2A1C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007C2A20: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007C2A24: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007C2A28: 7C980AA0
	v_cndmask_b32_e32 v5, v1, v5, vcc_lo                       // 0000007C2A2C: 020A0B01
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C2A30: 7C9810A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007C2A34: BF870002
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007C2A38: 300A0A82
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007C2A3C: 30040482
	ds_bpermute_b32 v3, v2, v30                                // 0000007C2A40: DACC0000 03001E02
	s_waitcnt lgkmcnt(0)                                       // 0000007C2A48: BF89FC07
	v_add_f32_e32 v3, v30, v3                                  // 0000007C2A4C: 0606071E
	ds_bpermute_b32 v4, v2, v31                                // 0000007C2A50: DACC0000 04001F02
	ds_bpermute_b32 v2, v2, v27                                // 0000007C2A58: DACC0000 02001B02
	ds_bpermute_b32 v6, v5, v3                                 // 0000007C2A60: DACC0000 06000305
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C2A68: 02101101
	s_waitcnt lgkmcnt(2)                                       // 0000007C2A6C: BF89FC27
	v_add_f32_e32 v4, v31, v4                                  // 0000007C2A70: 0608091F
	s_waitcnt lgkmcnt(1)                                       // 0000007C2A74: BF89FC17
	v_add_f32_e32 v2, v27, v2                                  // 0000007C2A78: 0604051B
	s_waitcnt lgkmcnt(0)                                       // 0000007C2A7C: BF89FC07
	v_add_f32_e32 v3, v3, v6                                   // 0000007C2A80: 06060D03
	ds_bpermute_b32 v7, v5, v4                                 // 0000007C2A84: DACC0000 07000405
	ds_bpermute_b32 v5, v5, v2                                 // 0000007C2A8C: DACC0000 05000205
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007C2A94: 30101082
	s_waitcnt lgkmcnt(0)                                       // 0000007C2A98: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 0000007C2A9C: 06040B02
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C2AA0: DACC0000 05000308
	s_waitcnt lgkmcnt(0)                                       // 0000007C2AA8: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v7     // 0000007C2AAC: C9080B03 03040F04
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C2AB4: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C2ABC: DACC0000 06000408
	v_xor_b32_e32 v8, 2, v1                                    // 0000007C2AC4: 3A100282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2AC8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C2ACC: 7C9810A0
	v_cndmask_b32_e32 v8, v1, v8, vcc_lo                       // 0000007C2AD0: 02101101
	v_lshlrev_b32_e32 v8, 2, v8                                // 0000007C2AD4: 30101082
	s_waitcnt lgkmcnt(1)                                       // 0000007C2AD8: BF89FC17
	v_add_f32_e32 v2, v2, v7                                   // 0000007C2ADC: 06040F02
	s_waitcnt lgkmcnt(0)                                       // 0000007C2AE0: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000007C2AE4: 06080D04
	ds_bpermute_b32 v5, v8, v3                                 // 0000007C2AE8: DACC0000 05000308
	ds_bpermute_b32 v7, v8, v2                                 // 0000007C2AF0: DACC0000 07000208
	ds_bpermute_b32 v6, v8, v4                                 // 0000007C2AF8: DACC0000 06000408
	v_xor_b32_e32 v8, 1, v1                                    // 0000007C2B00: 3A100281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007C2B04: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000007C2B08: 7C9810A0
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000007C2B0C: 02021101
	v_lshlrev_b32_e32 v8, 2, v1                                // 0000007C2B10: 30100282
	s_waitcnt lgkmcnt(1)                                       // 0000007C2B14: BF89FC17
	v_dual_add_f32 v1, v3, v5 :: v_dual_add_f32 v2, v2, v7     // 0000007C2B18: C9080B03 01020F02
	s_waitcnt lgkmcnt(0)                                       // 0000007C2B20: BF89FC07
	v_add_f32_e32 v3, v4, v6                                   // 0000007C2B24: 06060D04
	ds_bpermute_b32 v4, v8, v1                                 // 0000007C2B28: DACC0000 04000108
	ds_bpermute_b32 v5, v8, v2                                 // 0000007C2B30: DACC0000 05000208
	ds_bpermute_b32 v6, v8, v3                                 // 0000007C2B38: DACC0000 06000308
	v_cmpx_eq_u32_e32 0, v23                                   // 0000007C2B40: 7D942E80
	s_cbranch_execz 12                                         // 0000007C2B44: BFA5000C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xb78>
	v_mul_u32_u24_e32 v7, 12, v22                              // 0000007C2B48: 160E2C8C
	s_waitcnt lgkmcnt(0)                                       // 0000007C2B4C: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v2, v2, v5     // 0000007C2B50: C9080D03 03020B02
	v_add_f32_e32 v1, v1, v4                                   // 0000007C2B58: 06020901
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007C2B5C: BF870003
	v_or_b32_e32 v4, 0x400, v7                                 // 0000007C2B60: 38080EFF 00000400
	ds_store_2addr_b32 v4, v1, v3 offset1:1                    // 0000007C2B68: D8380100 00030104
	ds_store_b32 v7, v2 offset:1032                            // 0000007C2B70: D8340408 00000207
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007C2B78: 8C7E047E
	.long 0xd4510004                                           // 0000007C2B7C: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007C2B80: 02002002
	v_cmp_gt_u32_e32 vcc_lo, 3, v0                             // 0000007C2B84: 7C980083
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007C2B88: BF890007
	s_barrier                                                  // 0000007C2B8C: BFBD0000
	buffer_gl0_inv                                             // 0000007C2B90: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007C2B98: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007C2B9C: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007C2BA0: BE852004
	s_cbranch_execz 89                                         // 0000007C2BA4: BFA50059 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi3ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xd0c>
	v_add_nc_u32_e32 v7, 0x400, v21                            // 0000007C2BA8: 4A0E2AFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 0000007C2BB0: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:3                     // 0000007C2BB8: D8DC0300 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:6 offset1:9           // 0000007C2BC0: D8DC0906 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:12 offset1:15         // 0000007C2BC8: D8DC0F0C 05000007
	s_waitcnt lgkmcnt(0)                                       // 0000007C2BD0: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 0000007C2BD4: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007C2BD8: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 0000007C2BDC: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:18 offset1:21         // 0000007C2BE0: D8DC1512 01000007
	v_add_f32_e32 v3, v8, v3                                   // 0000007C2BE8: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 0000007C2BEC: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2BF0: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 0000007C2BF4: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 0000007C2BF8: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 0000007C2BFC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C00: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 0000007C2C04: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 0000007C2C08: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C0C: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 0000007C2C10: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 0000007C2C18: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C24: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007C2C28: 360202FF FFFF0000
	v_mul_f32_e32 v4, s0, v1                                   // 0000007C2C30: 10080200
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007C2C34: 84808102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C38: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v4                           // 0000007C2C3C: 100208FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000007C2C44: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C48: BF870095
	v_add_f32_e32 v5, 1.0, v1                                  // 0000007C2C4C: 060A02F2
	v_div_scale_f32 v3, null, v5, v5, v4                       // 0000007C2C50: D6FC7C03 04120B05
	v_div_scale_f32 v7, vcc_lo, v4, v5, v4                     // 0000007C2C58: D6FC6A07 04120B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007C2C60: BF870292
	v_rcp_f32_e32 v6, v3                                       // 0000007C2C64: 7E0C5503
	v_fma_f32 v1, -v3, v6, 1.0                                 // 0000007C2C68: D6130001 23CA0D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C2C70: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 0000007C2C74: 560C0D01
	v_mad_u64_u32 v[1:2], null, s16, v0, 0                     // 0000007C2C78: D6FE7C01 02020010
	v_mul_f32_e32 v8, v7, v6                                   // 0000007C2C80: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2C84: BF870091
	v_fma_f32 v9, -v3, v8, v7                                  // 0000007C2C88: D6130009 241E1103
	v_fmac_f32_e32 v8, v9, v6                                  // 0000007C2C90: 56100D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007C2C94: BF870121
	v_fma_f32 v7, -v3, v8, v7                                  // 0000007C2C98: D6130007 241E1103
	v_mad_u64_u32 v[2:3], null, s17, v0, v[2:3]                // 0000007C2CA0: D6FE7C02 040A0011
	v_div_fmas_f32 v0, v7, v6, v8                              // 0000007C2CA8: D6370000 04220D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C2CB0: BF870191
	v_div_fixup_f32 v3, v0, v5, v4                             // 0000007C2CB4: D6270003 04120B00
	.long 0xd73c0000                                           // 0000007C2CBC: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007C2CC0: 02020281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007C2CC4: BF870112
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007C2CC8: D6100002 02052103
	.long 0xd7006a00                                           // 0000007C2CD0: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007C2CD4: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007C2CD8: BF870191
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007C2CDC: D5207C01 01AA020D
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007C2CE4: D6550002 03FE0503 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007C2CF0: BF870093
	.long 0xd7006a00                                           // 0000007C2CF4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007C2CF8: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000007C2CFC: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007C2D04: DC960000 007C0200
	s_endpgm                                                   // 0000007C2D0C: BFB00000
		...

