0000000000832900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000832900: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 000000832908: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000832910: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000832914: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000832918: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 00000083291C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000832920: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 000000832924: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000083292C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 000000832930: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 000000832934: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000083293C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 000000832940: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000832944: BF89FC07
	s_clause 0x1                                               // 000000832948: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000083294C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 000000832954: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 00000083295C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000832960: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000832964: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 000000832968: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000083296C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000832970: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 000000832974: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000832978: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 00000083297C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 000000832980: CA640680 0310009F
	s_add_u32 s10, s10, s22                                    // 000000832988: 800A160A
	s_addc_u32 s11, s11, 0                                     // 00000083298C: 820B800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 000000832990: D5010004 01A82A80
	s_lshr_b64 s[10:11], s[10:11], 5                           // 000000832998: 858A850A
	.long 0xd72c0008                                           // 00000083299C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000008329A0: 02020613
	s_add_i32 s11, s10, 1                                      // 0000008329A4: 810B810A
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000008329A8: D6FE7C09 00081D03
	s_lshr_b32 s19, s11, 31                                    // 0000008329B0: 85139F0B
	.long 0xd72c0015                                           // 0000008329B4: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000008329B8: 02001D04
	s_add_i32 s11, s11, s19                                    // 0000008329BC: 810B130B
	.long 0xd72c0016                                           // 0000008329C0: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000008329C4: 02020812
	s_ashr_i32 s11, s11, 1                                     // 0000008329C8: 860B810B
	s_add_u32 s2, s4, s16                                      // 0000008329CC: 80021004
	.long 0xd72c0013                                           // 0000008329D0: D72C0013
	v_cndmask_b32_e32 v1, s11, v15, vcc_lo                     // 0000008329D4: 02021E0B
	s_addc_u32 s3, s5, s17                                     // 0000008329D8: 82031105
	.long 0xd72c000d                                           // 0000008329DC: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000008329E0: 02001F03
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000008329E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008329EC: BF870223
	v_add_nc_u32_e32 v4, s11, v19                              // 0000008329F0: 4A08260B
	v_add_nc_u32_e32 v19, v19, v16                             // 0000008329F4: 4A262113
	v_add3_u32 v10, v21, v10, v13                              // 0000008329F8: D655000A 04361515
	s_waitcnt vmcnt(1)                                         // 000000832A00: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 000000832A04: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 000000832A0C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 000000832A10: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000832A18: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 000000832A1C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 000000832A28: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000832A30: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 000000832A3C: 7E060280
	v_min_i32_e32 v20, s10, v4                                 // 000000832A40: 2228080A
	.long 0x7e0e3985                                           // 000000832A44: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 000000832A48: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 000000832A50: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 000000832A58: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 000000832A5C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 000000832A68: 7C822913
	ds_store_b32 v5, v6                                        // 000000832A6C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 000000832A74: BF89FC07
	s_barrier                                                  // 000000832A78: BFBD0000
	buffer_gl0_inv                                             // 000000832A7C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000832A84: BE83206A
	s_cbranch_execz 21                                         // 000000832A88: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 000000832A8C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 000000832A90: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000832A94: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000832A98: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000832A9C: 3408069F
	.long 0xd7000201                                           // 000000832AA0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000832AA4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000832AA8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 000000832AAC: D5207C02 000A0515
	.long 0xd7000203                                           // 000000832AB4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000832AB8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 000000832ABC: D5207C04 000A090A
	s_clause 0x1                                               // 000000832AC4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 000000832AC8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 000000832AD0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 000000832AD8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 000000832ADC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 000000832AE0: 8C7E037E
	s_and_saveexec_b32 s3, vcc_lo                              // 000000832AE4: BE83206A
	s_cbranch_execz 207                                        // 000000832AE8: BFA500CF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x528>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000832AEC: BF870131
	v_dual_mov_b32 v24, v18 :: v_dual_add_nc_u32 v5, 32, v19   // 000000832AF0: CA200112 180426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 000000832AF8: CA220080 110C2685
	s_mov_b32 s4, 0                                            // 000000832B00: BE840080
	v_lshlrev_b32_e32 v22, 4, v5                               // 000000832B04: 302C0A84
	v_lshlrev_b32_e32 v23, 1, v5                               // 000000832B08: 302E0A81
	s_branch 166                                               // 000000832B0C: BFA000A6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x4a8>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000832B10: 8C7E057E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000832B14: 341A189F
	v_lshrrev_b32_e32 v41, 6, v1                               // 000000832B18: 32520286
	v_lshrrev_b32_e32 v42, 14, v1                              // 000000832B1C: 3254028E
	v_and_b32_e32 v43, 0xff, v2                                // 000000832B20: 365604FF 000000FF
	v_lshrrev_b32_e32 v44, 6, v2                               // 000000832B28: 32580486
	.long 0xd73c0019                                           // 000000832B2C: D73C0019
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000832B30: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 000000832B34: 361A02FF 000000FF
	v_and_b32_e32 v41, 0x3fc, v41                              // 000000832B3C: 365252FF 000003FC
	v_and_b32_e32 v42, 0x3fc, v42                              // 000000832B44: 365454FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000832B4C: 32020296
	v_lshrrev_b32_e32 v45, 14, v2                              // 000000832B50: 325A048E
	.long 0xd7000225                                           // 000000832B54: D7000225
	v_cndmask_b32_e32 v1, s6, v25, vcc_lo                      // 000000832B58: 02023206
	s_delay_alu instid0(VALU_DEP_1)                            // 000000832B5C: BF870001
	v_add_co_ci_u32_e64 v38, null, s7, v26, s2                 // 000000832B60: D5207C26 000A3407
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000832B68: 301A1A82
	ds_load_b32 v41, v41                                       // 000000832B6C: D8D80000 29000029
	ds_load_b32 v42, v42                                       // 000000832B74: D8D80000 2A00002A
	s_clause 0x3                                               // 000000832B7C: BF850003
	global_load_b128 v[25:28], v[37:38], off                   // 000000832B80: DC5E0000 197C0025
	global_load_b128 v[29:32], v[37:38], off offset:16         // 000000832B88: DC5E0010 1D7C0025
	global_load_b128 v[33:36], v[37:38], off offset:32         // 000000832B90: DC5E0020 217C0025
	global_load_b128 v[37:40], v[37:38], off offset:48         // 000000832B98: DC5E0030 257C0025
	v_lshrrev_b32_e32 v2, 22, v2                               // 000000832BA0: 32040496
	ds_load_b32 v13, v13                                       // 000000832BA4: D8D80000 0D00000D
	v_and_b32_e32 v1, 0x3fc, v1                                // 000000832BAC: 360202FF 000003FC
	v_lshlrev_b32_e32 v43, 2, v43                              // 000000832BB4: 30565682
	v_and_b32_e32 v44, 0x3fc, v44                              // 000000832BB8: 365858FF 000003FC
	v_and_b32_e32 v45, 0x3fc, v45                              // 000000832BC0: 365A5AFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000832BC8: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000832BD0: D8D80000 01000001
	ds_load_b32 v43, v43                                       // 000000832BD8: D8D80000 2B00002B
	ds_load_b32 v44, v44                                       // 000000832BE0: D8D80000 2C00002C
	ds_load_b32 v45, v45                                       // 000000832BE8: D8D80000 2D00002D
	ds_load_b32 v2, v2                                         // 000000832BF0: D8D80000 02000002
	v_add_nc_u32_e32 v22, 0x200, v22                           // 000000832BF8: 4A2C2CFF 00000200
	v_add_nc_u32_e32 v23, 64, v23                              // 000000832C00: 4A2E2EC0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000832C04: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 000000832C0C: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000832C10: BF870149
	s_or_b32 s4, s2, s4                                        // 000000832C14: 8C040402
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 000000832C18: BF890C57
	v_dot2_f32_bf16 v13, v25, v13, 0                           // 000000832C1C: CC1A400D 1A021B19
	v_and_b32_e32 v25, 0xff, v3                                // 000000832C24: 363206FF 000000FF
	v_dot2_f32_bf16 v13, v26, v41, v13                         // 000000832C2C: CC1A400D 1C36531A
	v_lshrrev_b32_e32 v26, 6, v3                               // 000000832C34: 32340686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000832C38: BF8701A2
	v_dot2_f32_bf16 v13, v27, v42, v13                         // 000000832C3C: CC1A400D 1C36551B
	v_lshrrev_b32_e32 v27, 14, v3                              // 000000832C44: 3236068E
	v_and_b32_e32 v26, 0x3fc, v26                              // 000000832C48: 363434FF 000003FC
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000832C50: 32060696
	s_waitcnt lgkmcnt(4)                                       // 000000832C54: BF89FC47
	v_dot2_f32_bf16 v1, v28, v1, v13                           // 000000832C58: CC1A4001 1C36031C
	v_lshlrev_b32_e32 v13, 2, v25                              // 000000832C60: 301A3282
	v_and_b32_e32 v27, 0x3fc, v27                              // 000000832C64: 363636FF 000003FC
	v_and_b32_e32 v25, 0xff, v4                                // 000000832C6C: 363208FF 000000FF
	v_lshrrev_b32_e32 v28, 6, v4                               // 000000832C74: 32380886
	s_waitcnt vmcnt(2) lgkmcnt(3)                              // 000000832C78: BF890837
	v_dot2_f32_bf16 v1, v29, v43, v1                           // 000000832C7C: CC1A4001 1C06571D
	ds_load_b32 v13, v13                                       // 000000832C84: D8D80000 0D00000D
	ds_load_b32 v26, v26                                       // 000000832C8C: D8D80000 1A00001A
	ds_load_b32 v27, v27                                       // 000000832C94: D8D80000 1B00001B
	v_lshrrev_b32_e32 v29, 14, v4                              // 000000832C9C: 323A088E
	s_waitcnt lgkmcnt(5)                                       // 000000832CA0: BF89FC57
	v_dot2_f32_bf16 v1, v30, v44, v1                           // 000000832CA4: CC1A4001 1C06591E
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000832CAC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000832CB0: 360606FF 000003FC
	v_lshlrev_b32_e32 v25, 2, v25                              // 000000832CB8: 30323282
	v_and_b32_e32 v28, 0x3fc, v28                              // 000000832CBC: 363838FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 000000832CC4: BF89FC47
	v_dot2_f32_bf16 v1, v31, v45, v1                           // 000000832CC8: CC1A4001 1C065B1F
	v_and_b32_e32 v29, 0x3fc, v29                              // 000000832CD0: 363A3AFF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000832CD8: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000832CE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_3)                            // 000000832CE4: BF870003
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 000000832CE8: CC1A4001 1C060520
	ds_load_b32 v2, v3                                         // 000000832CF0: D8D80000 02000003
	ds_load_b32 v3, v25                                        // 000000832CF8: D8D80000 03000019
	ds_load_b32 v25, v28                                       // 000000832D00: D8D80000 1900001C
	ds_load_b32 v28, v29                                       // 000000832D08: D8D80000 1C00001D
	ds_load_b32 v29, v4                                        // 000000832D10: D8D80000 1D000004
	v_mov_b32_e32 v4, v8                                       // 000000832D18: 7E080308
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000832D1C: BF890477
	v_dot2_f32_bf16 v1, v33, v13, v1                           // 000000832D20: CC1A4001 1C061B21
	s_waitcnt lgkmcnt(6)                                       // 000000832D28: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000832D2C: BF8700A1
	v_dot2_f32_bf16 v1, v34, v26, v1                           // 000000832D30: CC1A4001 1C063522
	s_waitcnt lgkmcnt(5)                                       // 000000832D38: BF89FC57
	v_dot2_f32_bf16 v1, v35, v27, v1                           // 000000832D3C: CC1A4001 1C063723
	s_waitcnt lgkmcnt(4)                                       // 000000832D44: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000832D48: BF870131
	v_dot2_f32_bf16 v1, v36, v2, v1                            // 000000832D4C: CC1A4001 1C060524
	v_mov_b32_e32 v2, v6                                       // 000000832D54: 7E040306
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000832D58: BF890037
	v_dot2_f32_bf16 v1, v37, v3, v1                            // 000000832D5C: CC1A4001 1C060725
	v_mov_b32_e32 v3, v7                                       // 000000832D64: 7E060307
	s_waitcnt lgkmcnt(2)                                       // 000000832D68: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000832D6C: BF8700A2
	v_dot2_f32_bf16 v1, v38, v25, v1                           // 000000832D70: CC1A4001 1C063326
	s_waitcnt lgkmcnt(1)                                       // 000000832D78: BF89FC17
	v_dot2_f32_bf16 v1, v39, v28, v1                           // 000000832D7C: CC1A4001 1C063927
	s_waitcnt lgkmcnt(0)                                       // 000000832D84: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000832D88: BF870121
	v_dot2_f32_bf16 v8, v40, v29, v1                           // 000000832D8C: CC1A4008 1C063B28
	v_mov_b32_e32 v1, v5                                       // 000000832D94: 7E020305
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v24    // 000000832D98: C8101112 11120118
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000832DA0: 917E047E
	s_cbranch_execz 31                                         // 000000832DA4: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x524>
	s_waitcnt vmcnt(0)                                         // 000000832DA8: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 000000832DAC: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000832DB4: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000832DBC: 7E0E0303
	s_mov_b32 s5, exec_lo                                      // 000000832DC0: BE85007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000832DC4: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 000000832DC8: 7C8C2913
	.long 0xd4c1007e                                           // 000000832DCC: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 000000832DD0: 02022913
	s_cbranch_execz 65358                                      // 000000832DD4: BFA5FF4E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	v_ashrrev_i32_e32 v6, 31, v23                              // 000000832DD8: 340C2E9F
	v_ashrrev_i32_e32 v8, 31, v22                              // 000000832DDC: 34102C9F
	.long 0xd7000205                                           // 000000832DE0: D7000205
	v_cndmask_b32_e32 v1, v11, v23, vcc_lo                     // 000000832DE4: 02022F0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000832DE8: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 000000832DEC: D5207C06 000A0D15
	.long 0xd7000207                                           // 000000832DF4: D7000207
	v_cndmask_b32_e32 v1, v9, v22, vcc_lo                      // 000000832DF8: 02022D09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 000000832DFC: D5207C08 000A110A
	s_clause 0x1                                               // 000000832E04: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 000000832E08: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 000000832E10: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 000000832E18: BF8907F7
	v_cvt_f32_f16_e32 v24, v13                                 // 000000832E1C: 7E30170D
	s_branch 65339                                             // 000000832E20: BFA0FF3B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x210>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000832E24: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000832E28: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000832E2C: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 000000832E30: BF8903F7
	.long 0xd71f0001                                           // 000000832E34: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000832E38: 020100C1
	s_mov_b32 s2, exec_lo                                      // 000000832E3C: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000832E40: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 000000832E44: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 000000832E48: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000832E4C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000832E50: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000832E54: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 000000832E58: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 000000832E5C: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000832E60: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000832E64: 02080901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000832E68: BF870211
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000832E6C: 30080882
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000832E70: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000832E74: 30040482
	ds_bpermute_b32 v2, v2, v17                                // 000000832E78: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 000000832E80: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000832E84: 06040511
	ds_bpermute_b32 v3, v3, v2                                 // 000000832E88: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 000000832E90: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000832E94: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000832E98: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 000000832EA0: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000832EA4: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000832EA8: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000832EAC: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000832EB0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 000000832EB4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 000000832EB8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 000000832EBC: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 000000832EC4: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000832EC8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000832ECC: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 000000832ED0: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 000000832ED4: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 000000832EDC: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 000000832EE0: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v16                                   // 000000832EE8: 7D942080
	s_cbranch_execz 8                                          // 000000832EEC: BFA50008 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_lshlrev_b32_e32 v3, 2, v15                               // 000000832EF0: 30061E82
	s_waitcnt lgkmcnt(0)                                       // 000000832EF4: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 000000832EF8: 06020501
	s_delay_alu instid0(VALU_DEP_2)                            // 000000832EFC: BF870002
	v_lshl_or_b32 v3, v14, 3, v3                               // 000000832F00: D6560003 040D070E
	ds_store_b32 v3, v1 offset:1024                            // 000000832F08: D8340400 00000103
	s_or_b32 exec_lo, exec_lo, s2                              // 000000832F10: 8C7E027E
	v_or_b32_e32 v1, s20, v0                                   // 000000832F14: 38020014
	s_waitcnt lgkmcnt(0)                                       // 000000832F18: BF89FC07
	v_mov_b32_e32 v2, s21                                      // 000000832F1C: 7E040215
	.long 0xd44c0002                                           // 000000832F20: D44C0002
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 000000832F24: 02020084
	s_barrier                                                  // 000000832F28: BFBD0000
	buffer_gl0_inv                                             // 000000832F2C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000832F34: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 000000832F38: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000832F3C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 000000832F40: BE832002
	s_cbranch_execz 58                                         // 000000832F44: BFA5003A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x730>
	v_lshlrev_b32_e32 v0, 3, v0                                // 000000832F48: 30000083
	s_load_b32 s0, s[0:1], 0x48                                // 000000832F4C: F4000000 F8000048
	ds_load_b64 v[3:4], v0 offset:1024                         // 000000832F54: D9D80400 03000000
	s_waitcnt lgkmcnt(0)                                       // 000000832F5C: BF89FC07
	v_add_f32_e32 v0, 0, v3                                    // 000000832F60: 06000680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832F64: BF870091
	v_add_f32_e32 v0, v0, v4                                   // 000000832F68: 06000900
	v_bfe_u32 v3, v0, 16, 1                                    // 000000832F6C: D6100003 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832F74: BF870091
	v_add3_u32 v0, v0, v3, 0x7fff                              // 000000832F78: D6550000 03FE0700 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 000000832F84: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832F8C: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 000000832F90: 10000000
	v_mul_f32_e32 v0, 0xbfb8aa3b, v0                           // 000000832F94: 100000FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000832F9C: BF870291
	v_exp_f32_e32 v0, v0                                       // 000000832FA0: 7E004B00
	v_add_f32_e32 v0, 1.0, v0                                  // 000000832FA4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000832FA8: BF870121
	v_div_scale_f32 v3, null, v0, v0, 1.0                      // 000000832FAC: D6FC7C03 03CA0100
	v_div_scale_f32 v6, vcc_lo, 1.0, v0, 1.0                   // 000000832FB4: D6FC6A06 03CA00F2
	v_rcp_f32_e32 v4, v3                                       // 000000832FBC: 7E085503
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832FC0: BF870095
	v_fma_f32 v5, -v3, v4, 1.0                                 // 000000832FC4: D6130005 23CA0903
	v_fmac_f32_e32 v4, v5, v4                                  // 000000832FCC: 56080905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832FD0: BF870091
	v_mul_f32_e32 v5, v6, v4                                   // 000000832FD4: 100A0906
	v_fma_f32 v7, -v3, v5, v6                                  // 000000832FD8: D6130007 241A0B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832FE0: BF870091
	v_fmac_f32_e32 v5, v7, v4                                  // 000000832FE4: 560A0907
	v_fma_f32 v3, -v3, v5, v6                                  // 000000832FE8: D6130003 241A0B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000832FF0: BF870091
	v_div_fmas_f32 v3, v3, v4, v5                              // 000000832FF4: D6370003 04160903
	v_div_fixup_f32 v3, v3, v0, 1.0                            // 000000832FFC: D6270003 03CA0103
	.long 0xd73c0000                                           // 000000833004: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000833008: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000083300C: BF870112
	v_add_f32_e32 v2, v3, v3                                   // 000000833010: 06040703
	.long 0xd7006a00                                           // 000000833014: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000833018: 02020008
	s_delay_alu instid0(VALU_DEP_1)                            // 00000083301C: BF870001
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000833020: D5207C01 01AA0209
	global_store_b32 v[0:1], v2, off                           // 000000833028: DC6A0000 007C0200
	s_endpgm                                                   // 000000833030: BFB00000
		...

