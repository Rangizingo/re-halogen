0000000000486800 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x3                                               // 000000486800: BF850003
	s_load_b256 s[12:19], s[0:1], null                         // 000000486804: F40C0300 F8000000
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000048680C: F40C0500 F8000020
	s_load_b128 s[28:31], s[0:1], 0x40                         // 000000486814: F4080700 F8000040
	s_load_b32 s33, s[0:1], 0x54                               // 00000048681C: F4000840 F8000054
	v_and_b32_e32 v21, 31, v0                                  // 000000486824: 362A009F
	v_lshrrev_b32_e32 v19, 5, v0                               // 000000486828: 32260085
	s_mov_b32 s10, s3                                          // 00000048682C: BE8A0003
	s_mov_b32 s35, exec_lo                                     // 000000486830: BEA3007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000486834: BF870002
	v_lshlrev_b32_e32 v20, 2, v21                              // 000000486838: 30282A82
	s_waitcnt lgkmcnt(0)                                       // 00000048683C: BF89FC07
	s_ashr_i32 s34, s17, 31                                    // 000000486840: 86229F11
	s_mul_i32 s11, s19, s3                                     // 000000486844: 960B0313
	s_lshr_b32 s0, s34, 25                                     // 000000486848: 85009922
	s_add_i32 s1, s11, s19                                     // 00000048684C: 8101130B
	s_add_i32 s0, s17, s0                                      // 000000486850: 81000011
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000486854: BF870499
	s_ashr_i32 s0, s0, 7                                       // 000000486858: 86008700
	s_min_i32 s0, s0, s1                                       // 00000048685C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000486860: BF870499
	s_sub_i32 s9, s0, s11                                      // 000000486864: 81890B00
	s_lshl_b32 s19, s9, 2                                      // 000000486868: 84138209
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000048686C: BF870009
	.long 0xd4c4007e                                           // 000000486870: D4C4007E
	v_cndmask_b32_e32 v1, s19, v19, vcc_lo                     // 000000486874: 02022613
	s_cbranch_execz 499                                        // 000000486878: BFA501F3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	s_add_i32 s36, s16, -1                                     // 00000048687C: 8124C110
	s_cmp_lg_u64 s[30:31], 0                                   // 000000486880: BF11801E
	v_and_b32_e32 v2, 2, v0                                    // 000000486884: 36040082
	s_cselect_b32 s37, -1, 0                                   // 000000486888: 982580C1
	s_abs_i32 s38, s9                                          // 00000048688C: BEA61509
	v_lshlrev_b32_e32 v6, 3, v21                               // 000000486890: 300C2A83
	s_cvt_f32_u32 s0, s38                                      // 000000486894: BE806526
	v_dual_mov_b32 v8, v19 :: v_dual_and_b32 v1, 1, v0         // 000000486898: CA240113 08000081
	v_and_b32_e32 v4, 4, v0                                    // 0000004868A0: 36080084
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004868A4: BF870009
	v_rcp_iflag_f32_e32 v3, s0                                 // 0000004868A8: 7E065600
	v_and_b32_e32 v5, 8, v0                                    // 0000004868AC: 360A0088
	v_add_nc_u32_e32 v7, s11, v19                              // 0000004868B0: 4A0E260B
	.long 0xd44a0003                                           // 0000004868B4: D44A0003
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000004868B8: 02020480
	v_lshl_or_b32 v2, v19, 8, v6                               // 0000004868BC: D6560002 04191113
	s_ashr_i32 s42, s9, 31                                     // 0000004868C4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 0000004868C8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 0000004868CC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000004868D4: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 0000004868D8: 02022A90
	.long 0xd44a0001                                           // 0000004868DC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004868E0: 02020280
	v_readfirstlane_b32 s4, v3                                 // 0000004868E4: 7E080503
	.long 0xd44a0005                                           // 0000004868E8: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 0000004868EC: 02020A80
	v_lshl_or_b32 v1, v7, 7, v20                               // 0000004868F0: D6560001 04510F07
	v_subrev_nc_u32_e32 v9, s44, v2                            // 0000004868F8: 4E12042C
	s_lshl_b32 s6, s9, 7                                       // 0000004868FC: 84068709
	s_mul_f32 s7, s4, 0x4f7ffffe                               // 000000486900: A207FF04 4F7FFFFE
	.long 0xd44a0004                                           // 000000486908: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 00000048690C: 02020880
	s_mov_b32 s39, s17                                         // 000000486910: BEA70011
	s_mov_b32 s40, 0                                           // 000000486914: BEA80080
	s_cvt_u32_f32 s7, s7                                       // 000000486918: BE876707
	s_mov_b32 s41, 0x76543210                                  // 00000048691C: BEA900FF 76543210
	s_lshl_b32 s43, s9, 8                                      // 000000486924: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000486928: 81AC0680
	s_mul_i32 s8, s8, s7                                       // 00000048692C: 96080708
	s_mov_b32 s46, 0x3db504f3                                  // 000000486930: BEAE00FF 3DB504F3
	s_mul_hi_u32 s8, s7, s8                                    // 000000486938: 96880807
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000048693C: BF870009
	s_add_i32 s45, s7, s8                                      // 000000486940: 812D0807
	s_branch 164                                               // 000000486944: BFA000A4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486948: BF870091
	.long 0xd7006a02                                           // 00000048694C: D7006A02
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000486950: 02020414
	v_add_co_ci_u32_e64 v3, null, s21, v3, vcc_lo              // 000000486954: D5207C03 01AA0615
	v_sub_f32_e32 v4, v15, v13                                 // 00000048695C: 08081B0F
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000486960: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 000000486968: DC820006 027C0002
	s_waitcnt vmcnt(0)                                         // 000000486970: BF8903F7
	v_fma_mix_f32 v5, v14, v2, v12 op_sel_hi:[0,1,0]           // 000000486974: CC200005 1432050E
	v_fma_mix_f32 v2, -v14, v2, v12 op_sel_hi:[0,1,0]          // 00000048697C: CC200002 3432050E
	v_add_f32_e32 v3, v15, v13                                 // 000000486984: 06061B0F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000486988: BF8701A2
	v_add_f32_e32 v7, v4, v2                                   // 00000048698C: 060E0504
	v_sub_f32_e32 v2, v4, v2                                   // 000000486990: 08040504
	v_add_f32_e32 v6, v3, v5                                   // 000000486994: 060C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000486998: 08060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000048699C: BF870193
	v_mov_b32_dpp v13, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004869A0: 7E1A02FA FF016102
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004869A8: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004869B0: D5010006 20060D06
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 0000004869B8: D5010002 20060502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000004869C0: BF870142
	v_add_f32_e32 v4, v6, v4                                   // 0000004869C4: 06080906
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004869C8: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004869D0: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004869D8: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v11, vcc_lo                  // 0000004869DC: 020216FF 00001400
	v_add_f32_e32 v5, v7, v5                                   // 0000004869E4: 060A0B07
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 0000004869E8: 7E0E02FA FF016204
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 0000004869F0: D5010004 200E0904
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004869F8: BF870001
	v_add_f32_e32 v4, v4, v7                                   // 0000004869FC: 06080F04
	v_mov_b32_dpp v12, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000486A00: 7E1802FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000486A08: D5010003 20060703
	.long 0xd72c0007                                           // 000000486A10: D72C0007
	v_cndmask_b32_e32 v1, s43, v10, vcc_lo                     // 000000486A14: 0202142B
	v_add_f32_e32 v2, v2, v13                                  // 000000486A18: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486A1C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000486A24: D5010004 20120904
	v_add_f32_e32 v3, v3, v12                                  // 000000486A2C: 06061903
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000486A30: BF870224
	v_mov_b32_dpp v13, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486A34: 7E1A02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000486A3C: D5010002 200E0502
	v_add_f32_e32 v4, v4, v10                                  // 000000486A44: 06081504
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486A48: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000486A50: D5010005 200E0B05
	v_mov_b32_dpp v12, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000486A58: 7E1802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000486A60: D5010003 200E0703
	v_add_f32_e32 v2, v2, v13                                  // 000000486A68: 06041B02
	v_mov_b32_dpp v10, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486A6C: 7E1402FA FF016804
	v_add_f32_e32 v5, v5, v11                                  // 000000486A74: 060A1705
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 000000486A78: D5010004 20160904
	v_add_f32_e32 v3, v3, v12                                  // 000000486A80: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486A84: 7E1A02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 000000486A8C: D5010002 20120502
	v_mov_b32_dpp v11, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486A94: 7E1602FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000486A9C: D5010005 20120B05
	v_mov_b32_dpp v12, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000486AA4: 7E1802FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 000000486AAC: D5010003 20120703
	v_add_f32_e32 v2, v2, v13                                  // 000000486AB4: 06041B02
	v_sub_nc_u32_e32 v6, v6, v7                                // 000000486AB8: 4C0C0F06
	v_add_f32_e32 v5, v5, v11                                  // 000000486ABC: 060A1705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486AC0: BF870214
	v_add_f32_e32 v3, v3, v12                                  // 000000486AC4: 06061903
	v_mov_b32_dpp v13, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486AC8: 7E1A02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 000000486AD0: D5010002 20160502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000486AD8: BF870254
	v_mov_b32_dpp v11, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486ADC: 7E1602FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 000000486AE4: D5010005 20160B05
	v_add_nc_u32_e32 v8, 8, v8                                 // 000000486AEC: 4A101088
	v_mov_b32_dpp v12, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000486AF0: 7E1802FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000486AF8: D5010003 20160703
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_f32 v5, v5, v11   // 000000486B00: C9081504 04041705
	v_add_f32_e32 v2, v2, v13                                  // 000000486B08: 06041B02
	v_cmp_le_i32_e32 vcc_lo, s19, v8                           // 000000486B0C: 7C861013
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486B10: BF870214
	v_dual_add_f32 v3, v3, v12 :: v_dual_add_nc_u32 v6, v9, v6 // 000000486B14: C9201903 03060D09
	v_dual_mov_b32 v11, v5 :: v_dual_mov_b32 v10, v4           // 000000486B1C: CA100105 0B0A0104
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000486B24: BF870234
	v_mov_b32_e32 v13, v2                                      // 000000486B28: 7E1A0302
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000486B2C: D5010005 20020B05
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000486B34: D5010004 20020904
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 000000486B3C: D65C000B 03FC530B FEDCBA98
	v_mov_b32_e32 v12, v3                                      // 000000486B48: 7E180303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000486B4C: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000486B54: D5010003 20020703
	v_permlanex16_b32 v10, v10, s41, 0xfedcba98                // 000000486B5C: D65C000A 03FC530A FEDCBA98
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000486B68: D65C000D 03FC530D FEDCBA98
	v_add_f32_e32 v5, v5, v11                                  // 000000486B74: 060A1705
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000486B78: D65C000C 03FC530C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486B84: BF870214
	v_dual_add_f32 v4, v4, v10 :: v_dual_add_nc_u32 v9, 0x800, v9// 000000486B88: C9201504 040812FF 00000800
	v_add_f32_e32 v7, v2, v13                                  // 000000486B94: 060E1B02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486B98: BF870214
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000486B9C: CC220002 02005D05
	v_add_f32_e32 v10, v3, v12                                 // 000000486BA4: 06141903
	s_or_b32 s40, vcc_lo, s40                                  // 000000486BA8: 8C28286A
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000486BAC: CC210002 02005D04
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000486BB4: CC220003 02005D07
	s_delay_alu instid0(VALU_DEP_3)                            // 000000486BBC: BF870003
	v_fma_mixlo_f16 v3, v10, s46, 0                            // 000000486BC0: CC210003 02005D0A
	ds_store_b64 v6, v[2:3]                                    // 000000486BC8: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000486BD0: 917E287E
	s_cbranch_execz 284                                        // 000000486BD4: BFA5011C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x848>
	.long 0xd72d0002                                           // 000000486BD8: D72D0002
	v_cndmask_b32_e32 v0, v8, v45, vcc_lo                      // 000000486BDC: 02005B08
	s_mov_b32 s6, -1                                           // 000000486BE0: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486BE4: BF870091
	.long 0xd72c0003                                           // 000000486BE8: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000486BEC: 02004D02
	v_sub_nc_u32_e32 v3, v8, v3                                // 000000486BF0: 4C060708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000486BF4: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000486BF8: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000486BFC: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000486C00: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486C08: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000486C0C: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000486C10: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486C14: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000486C18: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000486C1C: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000486C20: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486C24: BF870091
	v_xor_b32_e32 v11, s42, v2                                 // 000000486C28: 3A16042A
	v_subrev_nc_u32_e32 v10, s42, v11                          // 000000486C2C: 4E14162A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000486C30: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v10, v[1:2]               // 000000486C34: D6FE7C06 0406142C
	v_min_i32_e32 v2, s36, v10                                 // 000000486C3C: 22041424
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000486C40: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486C48: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000486C4C: 340E0C9F
	.long 0xd73c0002                                           // 000000486C50: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000486C54: 02020C81
	s_cbranch_vccnz 207                                        // 000000486C58: BFA400CF <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x798>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486C5C: BF870093
	.long 0xd7006a06                                           // 000000486C60: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000486C64: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000486C68: D5207C07 01AA0F05
	.long 0x7f3e3880                                           // 000000486C70: 7F3E3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486C74: BF870112
	.long 0xd73c0006                                           // 000000486C78: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000486C7C: 02020C81
	.long 0x7f44399f                                           // 000000486C80: 7F44399F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486C84: BF870092
	.long 0xd7006a0c                                           // 000000486C88: D7006A0C
	v_cndmask_b32_e32 v1, s14, v6, vcc_lo                      // 000000486C8C: 02020C0E
	v_add_co_ci_u32_e64 v13, null, s15, v7, vcc_lo             // 000000486C90: D5207C0D 01AA0E0F
	.long 0xd7006a06                                           // 000000486C98: D7006A06
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000486C9C: 02020C1E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000486CA0: BF870001
	v_add_co_ci_u32_e64 v7, null, s31, v7, vcc_lo              // 000000486CA4: D5207C07 01AA0E1F
	global_load_b64 v[12:13], v[12:13], off                    // 000000486CAC: DC560000 0C7C000C
	.long 0xd7006a0e                                           // 000000486CB4: D7006A0E
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000486CB8: 02020414
	global_load_b64 v[6:7], v[6:7], off                        // 000000486CBC: DC560000 067C0006
	v_add_co_ci_u32_e64 v15, null, s21, v3, vcc_lo             // 000000486CC4: D5207C0F 01AA0615
	s_clause 0x1                                               // 000000486CCC: BF850001
	global_load_b32 v16, v[14:15], off                         // 000000486CD0: DC520000 107C000E
	global_load_d16_b16 v14, v[14:15], off offset:4            // 000000486CD8: DC820004 0E7C000E
	s_waitcnt vmcnt(3)                                         // 000000486CE0: BF890FF7
	v_lshlrev_b32_e32 v17, 16, v13                             // 000000486CE4: 30221A90
	.long 0x7e1e390c                                           // 000000486CE8: 7E1E390C
	s_waitcnt vmcnt(2)                                         // 000000486CEC: BF890BF7
	v_and_b32_e32 v41, 0xffff0000, v6                          // 000000486CF0: 36520CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486CF8: BF870093
	v_dual_mul_f32 v23, 0xbfb8aa3b, v17 :: v_dual_lshlrev_b32 v6, 16, v6// 000000486CFC: C8E222FF 17060C90 BFB8AA3B
	v_exp_f32_e32 v23, v23                                     // 000000486D08: 7E2E4B17
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486D0C: BF870095
	v_dual_add_f32 v23, 1.0, v23 :: v_dual_and_b32 v12, 0xffff0000, v12// 000000486D10: C9242EF2 170C18FF FFFF0000
	v_dual_mul_f32 v18, 0xbfb8aa3b, v12 :: v_dual_lshlrev_b32 v15, 16, v15// 000000486D1C: C8E218FF 120E1E90 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486D28: BF870111
	v_mul_f32_e32 v22, 0xbfb8aa3b, v15                         // 000000486D2C: 102C1EFF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 000000486D34: 7E244B12
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000486D38: 361A1AFF FFFF0000
	v_div_scale_f32 v27, null, v23, v23, v17                   // 000000486D40: D6FC7C1B 04462F17
	v_div_scale_f32 v37, s6, v17, v23, v17                     // 000000486D48: D6FC0625 04462F11
	v_exp_f32_e32 v22, v22                                     // 000000486D50: 7E2C4B16
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000486D54: BF870392
	v_rcp_f32_e32 v32, v27                                     // 000000486D58: 7E40551B
	v_add_f32_e32 v18, 1.0, v18                                // 000000486D5C: 062424F2
	v_mul_f32_e32 v24, 0xbfb8aa3b, v13                         // 000000486D60: 10301AFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486D68: BF870196
	v_add_f32_e32 v22, 1.0, v22                                // 000000486D6C: 062C2CF2
	v_div_scale_f32 v25, null, v18, v18, v12                   // 000000486D70: D6FC7C19 04322512
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 000000486D78: BF870323
	v_exp_f32_e32 v24, v24                                     // 000000486D7C: 7E304B18
	v_div_scale_f32 v35, vcc_lo, v12, v18, v12                 // 000000486D80: D6FC6A23 0432250C
	v_fma_f32 v40, -v27, v32, 1.0                              // 000000486D88: D6130028 23CA411B
	v_div_scale_f32 v26, null, v22, v22, v15                   // 000000486D90: D6FC7C1A 043E2D16
	v_rcp_f32_e32 v28, v25                                     // 000000486D98: 7E385519
	v_div_scale_f32 v39, s7, v15, v22, v15                     // 000000486D9C: D6FC0727 043E2D0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486DA4: BF870193
	v_fmac_f32_e32 v32, v40, v32                               // 000000486DA8: 56404128
	v_rcp_f32_e32 v30, v26                                     // 000000486DAC: 7E3C551A
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486DB0: BF870117
	v_add_f32_e32 v24, 1.0, v24                                // 000000486DB4: 063030F2
	v_mul_f32_e32 v42, v37, v32                                // 000000486DB8: 10544125
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486DBC: BF870196
	v_fma_f32 v36, -v25, v28, 1.0                              // 000000486DC0: D6130024 23CA3919
	v_div_scale_f32 v29, null, v24, v24, v13                   // 000000486DC8: D6FC7C1D 04363118
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000486DD0: BF870293
	v_fma_f32 v46, -v27, v42, v37                              // 000000486DD4: D613002E 2496551B
	v_fma_f32 v38, -v26, v30, 1.0                              // 000000486DDC: D6130026 23CA3D1A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486DE4: BF870214
	v_fmac_f32_e32 v28, v36, v28                               // 000000486DE8: 56383924
	v_rcp_f32_e32 v33, v29                                     // 000000486DEC: 7E42551D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486DF0: BF870193
	v_fmac_f32_e32 v42, v46, v32                               // 000000486DF4: 5654412E
	v_fmac_f32_e32 v30, v38, v30                               // 000000486DF8: 563C3D26
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486DFC: BF870193
	v_mul_f32_e32 v40, v35, v28                                // 000000486E00: 10503923
	v_fma_f32 v27, -v27, v42, v37                              // 000000486E04: D613001B 2496551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000486E0C: BF870292
	v_fma_f32 v43, -v25, v40, v35                              // 000000486E10: D613002B 248E5119
	v_fma_f32 v36, -v29, v33, 1.0                              // 000000486E18: D6130024 23CA431D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000486E20: BF8701B1
	v_dual_fmac_f32 v40, v43, v28 :: v_dual_fmac_f32 v33, v36, v33// 000000486E24: C800392B 28204324
	v_mul_f32_e32 v36, v39, v30                                // 000000486E2C: 10483D27
	v_div_scale_f32 v38, s8, v13, v24, v13                     // 000000486E30: D6FC0826 0436310D
	v_fma_f32 v25, -v25, v40, v35                              // 000000486E38: D6130019 248E5119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486E40: BF870193
	v_fma_f32 v45, -v26, v36, v39                              // 000000486E44: D613002D 249E491A
	v_mul_f32_e32 v44, v38, v33                                // 000000486E4C: 10584326
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000486E50: BF8701A3
	v_div_fmas_f32 v25, v25, v28, v40                          // 000000486E54: D6370019 04A23919
	s_mov_b32 vcc_lo, s7                                       // 000000486E5C: BEEA0007
	v_fmac_f32_e32 v36, v45, v30                               // 000000486E60: 56483D2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486E64: BF870193
	v_fma_f32 v43, -v29, v44, v38                              // 000000486E68: D613002B 249A591D
	v_div_fixup_f32 v12, v25, v18, v12                         // 000000486E70: D627000C 04322519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486E78: BF870193
	v_fma_f32 v26, -v26, v36, v39                              // 000000486E7C: D613001A 249E491A
	v_fmac_f32_e32 v44, v43, v33                               // 000000486E84: 5658432B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486E88: BF870193
	v_mul_f32_e32 v12, v12, v41                                // 000000486E8C: 1018530C
	v_div_fmas_f32 v26, v26, v30, v36                          // 000000486E90: D637001A 04923D1A
	s_mov_b32 vcc_lo, s6                                       // 000000486E98: BEEA0006
	s_delay_alu instid0(VALU_DEP_3)                            // 000000486E9C: BF870003
	v_fma_f32 v25, -v29, v44, v38                              // 000000486EA0: D6130019 249A591D
	v_div_fmas_f32 v18, v27, v32, v42                          // 000000486EA8: D6370012 04AA411B
	s_mov_b32 vcc_lo, s8                                       // 000000486EB0: BEEA0008
	v_div_fixup_f32 v15, v26, v22, v15                         // 000000486EB4: D627000F 043E2D1A
	v_lshlrev_b32_e32 v22, 16, v7                              // 000000486EBC: 302C0E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000486EC0: 360E0EFF FFFF0000
	v_div_fixup_f32 v17, v18, v23, v17                         // 000000486EC8: D6270011 04462F12
	.long 0x7e3e398c                                           // 000000486ED0: 7E3E398C
	v_mul_f32_e32 v6, v15, v6                                  // 000000486ED4: 100C0D0F
	v_div_fmas_f32 v15, v25, v33, v44                          // 000000486ED8: D637000F 04B24319
	s_mov_b32 s6, 0                                            // 000000486EE0: BE860080
	v_mul_f32_e32 v17, v17, v22                                // 000000486EE4: 10222D11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486EE8: BF870193
	.long 0x7e443986                                           // 000000486EEC: 7E443986
	v_div_fixup_f32 v13, v15, v24, v13                         // 000000486EF0: D627000D 0436310F
	v_and_b32_e32 v15, 1, v31                                  // 000000486EF8: 361E3E81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486EFC: BF870194
	v_bfe_u32 v18, v17, 16, 1                                  // 000000486F00: D6100012 02052111
	v_dual_mul_f32 v7, v13, v7 :: v_dual_and_b32 v22, 1, v34   // 000000486F08: C8E40F0D 07164481
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000486F10: BF870193
	v_add3_u32 v12, v12, v15, 0x7fff                           // 000000486F14: D655000C 03FE1F0C 00007FFF
	v_add3_u32 v13, v17, v18, 0x7fff                           // 000000486F20: D655000D 03FE2511 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486F2C: BF870213
	v_add3_u32 v6, v6, v22, 0x7fff                             // 000000486F30: D6550006 03FE2D06 00007FFF
	v_bfe_u32 v15, v7, 16, 1                                   // 000000486F3C: D610000F 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486F44: BF870214
	v_and_b32_e32 v12, 0xffff0000, v12                         // 000000486F48: 361818FF FFFF0000
	v_and_b32_e32 v17, 0xffff0000, v13                         // 000000486F50: 36221AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000486F58: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000486F5C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000486F64: D6550007 03FE1F07 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000486F70: BF8907F7
	v_fma_mix_f32 v13, v16, v12, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000486F74: CC20080D 8A021910
	s_waitcnt vmcnt(0)                                         // 000000486F7C: BF8903F7
	v_fma_mix_f32 v12, v14, v17, neg(0) op_sel_hi:[1,0,0]      // 000000486F80: CC20000C 8A02230E
	v_fma_mix_f32 v15, v16, v6, neg(0) op_sel_hi:[1,0,0]       // 000000486F88: CC20000F 8A020D10
	v_and_b32_e32 v14, 0xffff0000, v7                          // 000000486F90: 361C0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000486F98: 916A067E
	s_cbranch_vccnz 65130                                      // 000000486F9C: BFA4FE6A <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000486FA0: BF870093
	.long 0xd73c0004                                           // 000000486FA4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000486FA8: 02020881
	.long 0xd7006a04                                           // 000000486FAC: D7006A04
	v_cndmask_b32_e32 v1, s14, v4, vcc_lo                      // 000000486FB0: 0202080E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000486FB4: BF870111
	v_add_co_ci_u32_e64 v5, null, s15, v5, vcc_lo              // 000000486FB8: D5207C05 01AA0A0F
	.long 0xd7006a04                                           // 000000486FC0: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000486FC4: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000486FC8: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000486FCC: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000486FD4: D7006A06
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 000000486FD8: 02020414
	v_add_co_ci_u32_e64 v7, null, s21, v3, vcc_lo              // 000000486FDC: D5207C07 01AA0615
	global_load_b64 v[4:5], v[4:5], off                        // 000000486FE4: DC560000 047C0004
	s_clause 0x1                                               // 000000486FEC: BF850001
	global_load_b32 v14, v[6:7], off                           // 000000486FF0: DC520000 0E7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000486FF8: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000487000: BF890BF7
	.long 0x7e0e3904                                           // 000000487004: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000487008: 360808FF FFFF0000
	v_lshlrev_b32_e32 v12, 16, v5                              // 000000487010: 30180A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000487014: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000487018: 300E0E90
	s_waitcnt vmcnt(1)                                         // 00000048701C: BF8907F7
	v_fma_mix_f32 v13, v14, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000487020: CC20080D 8A02090E
	s_waitcnt vmcnt(0)                                         // 000000487028: BF8903F7
	v_fma_mix_f32 v12, v6, v12, neg(0) op_sel_hi:[1,0,0]       // 00000048702C: CC20000C 8A021906
	v_fma_mix_f32 v15, v14, v7, neg(0) op_sel_hi:[1,0,0]       // 000000487034: CC20000F 8A020F0E
	v_and_b32_e32 v14, 0xffff0000, v5                          // 00000048703C: 361C0AFF FFFF0000
	s_branch 65088                                             // 000000487044: BFA0FE40 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x148>
	s_or_b32 exec_lo, exec_lo, s35                             // 000000487048: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 00000048704C: 9388FF09 0001001C
	s_lshl_b32 s3, s9, 3                                       // 000000487054: 84038309
	s_lshr_b64 s[0:1], s[8:9], 29                              // 000000487058: 85809D08
	s_lshr_b32 s1, s34, 28                                     // 00000048705C: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000487060: 81008700
	s_add_i32 s1, s17, s1                                      // 000000487064: 81010111
	s_ashr_i32 s0, s0, 3                                       // 000000487068: 86008300
	s_waitcnt lgkmcnt(0)                                       // 00000048706C: BF89FC07
	.long 0xd72c0001                                           // 000000487070: D72C0001
	v_cndmask_b32_e32 v1, s0, v19, vcc_lo                      // 000000487074: 02022600
	s_barrier                                                  // 000000487078: BFBD0000
	buffer_gl0_inv                                             // 00000048707C: E0AC0000 00000000
	v_add_nc_u32_e32 v2, s0, v1                                // 000000487084: 4A040200
	s_ashr_i32 s0, s1, 4                                       // 000000487088: 86008401
	s_lshl_b32 s1, s11, 3                                      // 00000048708C: 8401830B
	s_mul_hi_i32 s4, s0, s2                                    // 000000487090: 97040200
	s_mul_i32 s0, s0, s2                                       // 000000487094: 96000200
	v_min_i32_e32 v23, s3, v2                                  // 000000487098: 222E0403
	s_ashr_i32 s3, s1, 31                                      // 00000048709C: 86039F01
	s_add_u32 s0, s0, s1                                       // 0000004870A0: 80000100
	s_addc_u32 s1, s4, s3                                      // 0000004870A4: 82010304
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004870A8: BF870009
	s_lshl_b64 s[4:5], s[0:1], 10                              // 0000004870AC: 84848A00
	v_cmp_lt_i32_e32 vcc_lo, v1, v23                           // 0000004870B0: 7C822F01
	s_add_u32 s1, s12, s4                                      // 0000004870B4: 8001040C
	s_addc_u32 s4, s13, s5                                     // 0000004870B8: 8204050D
	s_and_saveexec_b32 s3, vcc_lo                              // 0000004870BC: BE83206A
	s_cbranch_execz 93                                         // 0000004870C0: BFA5005D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xa38>
	.long 0xd7010002                                           // 0000004870C4: D7010002
	v_cndmask_b32_e32 v0, v21, v129, vcc_lo                    // 0000004870C8: 02010315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004870CC: BF870121
	v_cndmask_b32_e64 v3, v2, 31, s0                           // 0000004870D0: D5010003 00013F02
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000004870D8: 3404029F
	.long 0xd44c0000                                           // 0000004870DC: D44C0000
	v_cndmask_b32_e32 v1, 31, v3, vcc_lo                       // 0000004870E0: 0202069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004870E4: BF870091
	v_cndmask_b32_e64 v5, 0xe1, 1, s0                          // 0000004870E8: D5010005 000102FF 000000E1
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v7, v5, v3       // 0000004870F4: CA200080 04060705
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004870FC: BF870114
	.long 0xd73c0005                                           // 000000487100: D73C0005
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 000000487104: 0202028A
	.long 0xd73c0002                                           // 000000487108: D73C0002
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000048710C: 02020682
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000487110: BF870223
	v_lshlrev_b32_e32 v4, 24, v7                               // 000000487114: 30080E98
	v_bfe_i32 v7, v7, 7, 1                                     // 000000487118: D6110007 02050F07
	.long 0xd7000008                                           // 000000487120: D7000008
	v_cndmask_b32_e32 v1, s1, v5, vcc_lo                       // 000000487124: 02020A01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000487128: BF870211
	v_add_co_ci_u32_e64 v9, null, s4, v6, s0                   // 00000048712C: D5207C09 00020C04
	v_ashrrev_i32_e32 v6, 22, v4                               // 000000487134: 340C0896
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000487138: BF870093
	.long 0xd7000004                                           // 00000048713C: D7000004
	v_cndmask_b32_e32 v1, v8, v2, vcc_lo                       // 000000487140: 02020508
	v_add_co_ci_u32_e64 v5, null, v9, v3, s0                   // 000000487144: D5207C05 00020709
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000048714C: BF870093
	.long 0xd7000006                                           // 000000487150: D7000006
	v_cndmask_b32_e32 v1, v8, v6, vcc_lo                       // 000000487154: 02020D08
	v_add_co_ci_u32_e64 v7, null, v9, v7, s0                   // 000000487158: D5207C07 00020F09
	.long 0xd7000008                                           // 000000487160: D7000008
	v_cndmask_b32_e32 v1, v8, v20, vcc_lo                      // 000000487164: 02022908
	s_delay_alu instid0(VALU_DEP_1)                            // 000000487168: BF870001
	v_add_co_ci_u32_e64 v9, null, 0, v9, s0                    // 00000048716C: D5207C09 00021280
	s_clause 0x17                                              // 000000487174: BF850017
	global_load_b32 v2, v[4:5], off                            // 000000487178: DC520000 027C0004
	global_load_b32 v93, v[4:5], off offset:128                // 000000487180: DC520080 5D7C0004
	global_load_b32 v90, v[4:5], off offset:256                // 000000487188: DC520100 5A7C0004
	global_load_b32 v87, v[4:5], off offset:384                // 000000487190: DC520180 577C0004
	global_load_b32 v84, v[4:5], off offset:512                // 000000487198: DC520200 547C0004
	global_load_b32 v81, v[4:5], off offset:640                // 0000004871A0: DC520280 517C0004
	global_load_b32 v78, v[4:5], off offset:768                // 0000004871A8: DC520300 4E7C0004
	global_load_b32 v69, v[4:5], off offset:896                // 0000004871B0: DC520380 457C0004
	global_load_b32 v3, v[6:7], off                            // 0000004871B8: DC520000 037C0006
	global_load_b32 v94, v[6:7], off offset:128                // 0000004871C0: DC520080 5E7C0006
	global_load_b32 v91, v[6:7], off offset:256                // 0000004871C8: DC520100 5B7C0006
	global_load_b32 v88, v[6:7], off offset:384                // 0000004871D0: DC520180 587C0006
	global_load_b32 v85, v[6:7], off offset:512                // 0000004871D8: DC520200 557C0006
	global_load_b32 v82, v[6:7], off offset:640                // 0000004871E0: DC520280 527C0006
	global_load_b32 v79, v[6:7], off offset:768                // 0000004871E8: DC520300 4F7C0006
	global_load_b32 v75, v[6:7], off offset:896                // 0000004871F0: DC520380 4B7C0006
	global_load_b32 v95, v[8:9], off                           // 0000004871F8: DC520000 5F7C0008
	global_load_b32 v92, v[8:9], off offset:128                // 000000487200: DC520080 5C7C0008
	global_load_b32 v89, v[8:9], off offset:256                // 000000487208: DC520100 597C0008
	global_load_b32 v86, v[8:9], off offset:384                // 000000487210: DC520180 567C0008
	global_load_b32 v83, v[8:9], off offset:512                // 000000487218: DC520200 537C0008
	global_load_b32 v80, v[8:9], off offset:640                // 000000487220: DC520280 507C0008
	global_load_b32 v77, v[8:9], off offset:768                // 000000487228: DC520300 4D7C0008
	global_load_b32 v59, v[8:9], off offset:896                // 000000487230: DC520380 3B7C0008
	s_or_b32 exec_lo, exec_lo, s3                              // 000000487238: 8C7E037E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v25, 0             // 00000048723C: CA100080 16180080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v27, 0             // 000000487244: CA100080 181A0080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v31, 0             // 00000048724C: CA100080 1A1E0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v33, 0             // 000000487254: CA100080 1C200080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v35, 0             // 00000048725C: CA100080 1E220080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v37, 0             // 000000487264: CA100080 20240080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v39, 0             // 00000048726C: CA100080 22260080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v43, 0             // 000000487274: CA100080 242A0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v45, 0             // 00000048727C: CA100080 262C0080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v29, 0             // 000000487284: CA100080 281C0080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v49, 0             // 00000048728C: CA100080 2A300080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v53, 0             // 000000487294: CA100080 2C340080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v47, 0             // 00000048729C: CA100080 2E2E0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v41, 0             // 0000004872A4: CA100080 30280080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v51, 0             // 0000004872AC: CA100080 34320080
	v_mov_b32_e32 v50, 0                                       // 0000004872B4: 7E640280
	v_mov_b32_e32 v54, 0                                       // 0000004872B8: 7E6C0280
	s_ashr_i32 s3, s2, 31                                      // 0000004872BC: 86039F02
	s_and_saveexec_b32 s0, vcc_lo                              // 0000004872C0: BE80206A
	s_cbranch_execz 1131                                       // 0000004872C4: BFA5046B <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c74>
	v_dual_mov_b32 v25, 0 :: v_dual_add_nc_u32 v4, -1, v0      // 0000004872C8: CA200080 190400C1
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v5, 16, v0         // 0000004872D0: CA240080 16040090
	v_dual_mov_b32 v24, 0 :: v_dual_add_nc_u32 v17, 1, v1      // 0000004872D8: CA200080 18100281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004872E0: BF870243
	v_dual_mov_b32 v27, 0 :: v_dual_and_b32 v4, 31, v4         // 0000004872E4: CA240080 1B04089F
	v_sub_nc_u32_e32 v55, 0, v23                               // 0000004872EC: 4C6E2E80
	v_dual_mov_b32 v31, 0 :: v_dual_lshlrev_b32 v56, 2, v21    // 0000004872F0: CA220080 1F382A82
	v_lshl_or_b32 v57, v1, 5, v5                               // 0000004872F8: D6560039 04150B01
	v_dual_mov_b32 v33, 0 :: v_dual_lshlrev_b32 v58, 2, v4     // 000000487300: CA220080 213A0882
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v35, 0             // 000000487308: CA100080 1A220080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v37, 0             // 000000487310: CA100080 1C240080
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v39, 0             // 000000487318: CA100080 1E260080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v43, 0             // 000000487320: CA100080 202A0080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, 0             // 000000487328: CA100080 222C0080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v29, 0             // 000000487330: CA100080 241C0080
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v49, 0             // 000000487338: CA100080 26300080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v53, 0             // 000000487340: CA100080 28340080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v47, 0             // 000000487348: CA100080 2A2E0080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v41, 0             // 000000487350: CA100080 2C280080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v51, 0             // 000000487358: CA100080 2E320080
	v_mov_b32_e32 v48, 0                                       // 000000487360: 7E600280
	v_mov_b32_e32 v52, 0                                       // 000000487364: 7E680280
	v_mov_b32_e32 v50, 0                                       // 000000487368: 7E640280
	v_mov_b32_e32 v54, 0                                       // 00000048736C: 7E6C0280
	s_mov_b32 s5, 0                                            // 000000487370: BE850080
	s_mov_b32 s6, 0xdcd12d                                     // 000000487374: BE8600FF 00DCD12D
	s_movk_i32 s7, 0x83                                        // 00000048737C: B0070083
	s_movk_i32 s8, 0x1eee                                      // 000000487380: B0081EEE
	s_branch 1026                                              // 000000487384: BFA00402 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1b90>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000487388: 8C7E097E
	s_waitcnt vmcnt(15)                                        // 00000048738C: BF893FF7
	v_alignbit_b32 v96, v2, v3, 16                             // 000000487390: D6160060 02420702
	ds_load_b128 v[5:8], v57                                   // 000000487398: DBFC0000 05000039
	ds_load_b128 v[1:4], v57 offset:5120                       // 0000004873A0: DBFC1400 01000039
	ds_load_b128 v[9:12], v57 offset:10240                     // 0000004873A8: DBFC2800 09000039
	ds_load_b128 v[13:16], v57 offset:15360                    // 0000004873B0: DBFC3C00 0D000039
	s_waitcnt vmcnt(7)                                         // 0000004873B8: BF891FF7
	v_bfe_u32 v98, v95, 12, 16                                 // 0000004873BC: D6100062 0241195F
	v_bfe_u32 v99, v95, 8, 16                                  // 0000004873C4: D6100063 0241115F
	v_bfe_u32 v97, v96, 12, 16                                 // 0000004873CC: D6100061 02411960
	v_mul_u32_u24_e32 v101, s6, v97                            // 0000004873D4: 16CAC206
	v_mul_u32_u24_e32 v97, s7, v97                             // 0000004873D8: 16C2C207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000004873DC: BF870151
	v_lshl_add_u32 v97, v97, 24, v101                          // 0000004873E0: D6460061 05953161
	v_bfe_u32 v100, v96, 4, 16                                 // 0000004873E8: D6100064 02410960
	v_bfe_u32 v101, v96, 8, 16                                 // 0000004873F0: D6100065 02411160
	v_mul_u32_u24_e32 v102, s6, v100                           // 0000004873F8: 16CCC806
	v_mul_u32_u24_e32 v100, s7, v100                           // 0000004873FC: 16C8C807
	v_lshl_add_u32 v100, v100, 24, v102                        // 000000487400: D6460064 05993164
	v_mul_u32_u24_e32 v102, s6, v101                           // 000000487408: 16CCCA06
	v_mul_u32_u24_e32 v101, s7, v101                           // 00000048740C: 16CACA07
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000487410: D6220061 03FD0161 00006400
	v_lshl_add_u32 v101, v101, 24, v102                        // 00000048741C: D6460065 05993165
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000487424: D6220064 03FD0164 00006400
	v_alignbit_b32 v93, v93, v94, 16                           // 000000487430: D616005D 0242BD5D
	v_alignbit_b32 v90, v90, v91, 16                           // 000000487438: D616005A 0242B75A
	v_and_b32_e32 v97, 0xffff, v97                             // 000000487440: 36C2C2FF 0000FFFF
	v_sad_u8 v101, v101, 0, 0x6400                             // 000000487448: D6220065 03FD0165 00006400
	v_alignbit_b32 v87, v87, v88, 16                           // 000000487454: D6160057 0242B157
	v_bfe_u32 v94, v93, 12, 16                                 // 00000048745C: D610005E 0241195D
	v_bfe_u32 v91, v90, 12, 16                                 // 000000487464: D610005B 0241195A
	v_alignbit_b32 v84, v84, v85, 16                           // 00000048746C: D6160054 0242AB54
	v_lshl_or_b32 v97, v101, 16, v97                           // 000000487474: D6560061 05852165
	v_mul_u32_u24_e32 v101, s6, v98                            // 00000048747C: 16CAC406
	v_mul_u32_u24_e32 v98, s7, v98                             // 000000487480: 16C4C407
	v_lshl_add_u32 v98, v98, 24, v101                          // 000000487484: D6460062 05953162
	v_bfe_u32 v88, v87, 12, 16                                 // 00000048748C: D6100058 02411957
	v_pk_fma_f16 v97, v97, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487494: CC0E0061 0BFC1161 0000C931
	v_and_b32_e32 v96, 0xffff, v96                             // 0000004874A0: 36C0C0FF 0000FFFF
	v_bfe_u32 v85, v84, 12, 16                                 // 0000004874A8: D6100055 02411954
	v_sad_u8 v98, v98, 0, 0x6400                               // 0000004874B0: D6220062 03FD0162 00006400
	v_alignbit_b32 v81, v81, v82, 16                           // 0000004874BC: D6160051 0242A551
	s_waitcnt lgkmcnt(2)                                       // 0000004874C4: BF89FC27
	v_dot2acc_f32_f16 v51, v97, v1                             // 0000004874C8: 04660361
	v_mul_u32_u24_e32 v102, s6, v96                            // 0000004874CC: 16CCC006
	v_mul_u32_u24_e32 v96, s7, v96                             // 0000004874D0: 16C0C007
	v_lshl_add_u32 v96, v96, 24, v102                          // 0000004874D4: D6460060 05993160
	v_and_b32_e32 v100, 0xffff, v100                           // 0000004874DC: 36C8C8FF 0000FFFF
	v_bfe_u32 v102, v95, 4, 16                                 // 0000004874E4: D6100066 0241095F
	v_mul_u32_u24_e32 v101, s7, v102                           // 0000004874EC: 16CACC07
	s_waitcnt lgkmcnt(0)                                       // 0000004874F0: BF89FC07
	v_dual_dot2acc_f32_f16 v41, v97, v13 :: v_dual_and_b32 v98, 0xffff, v98// 0000004874F4: CB241B61 2962C4FF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000487500: D6220060 03FD0160 00006400
	v_dual_dot2acc_f32_f16 v54, v97, v5 :: v_dual_and_b32 v95, 0xffff, v95// 00000048750C: CB240B61 365EBEFF 0000FFFF
	v_bfe_u32 v82, v81, 12, 16                                 // 000000487518: D6100052 02411951
	v_alignbit_b32 v78, v78, v79, 16                           // 000000487520: D616004E 02429F4E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000487528: BF870004
	v_lshl_or_b32 v96, v96, 16, v100                           // 00000048752C: D6560060 05912160
	v_mul_u32_u24_e32 v100, s6, v102                           // 000000487534: 16C8CC06
	v_lshl_add_u32 v100, v101, 24, v100                        // 000000487538: D6460064 05913165
	v_mul_u32_u24_e32 v101, s6, v99                            // 000000487540: 16CAC606
	v_mul_u32_u24_e32 v99, s7, v99                             // 000000487544: 16C6C607
	v_lshl_add_u32 v99, v99, 24, v101                          // 000000487548: D6460063 05953163
	v_mul_u32_u24_e32 v101, s6, v95                            // 000000487550: 16CABE06
	v_mul_u32_u24_e32 v95, s7, v95                             // 000000487554: 16BEBE07
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000487558: D6220064 03FD0164 00006400
	v_lshl_add_u32 v95, v95, 24, v101                          // 000000487564: D646005F 0595315F
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000048756C: D6220063 03FD0163 00006400
	v_pk_fma_f16 v96, v96, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487578: CC0E0060 0BFC1160 0000C931
	v_dot2acc_f32_f16 v50, v97, v9                             // 000000487584: 04641361
	v_bfe_u32 v97, v93, 4, 16                                  // 000000487588: D6100061 0241095D
	v_sad_u8 v95, v95, 0, 0x6400                               // 000000487590: D622005F 03FD015F 00006400
	v_lshl_or_b32 v98, v99, 16, v98                            // 00000048759C: D6560062 05892163
	v_dot2acc_f32_f16 v51, v96, v2                             // 0000004875A4: 04660560
	v_dot2acc_f32_f16 v54, v96, v6                             // 0000004875A8: 046C0D60
	v_dot2acc_f32_f16 v41, v96, v14                            // 0000004875AC: 04521D60
	s_waitcnt vmcnt(6)                                         // 0000004875B0: BF891BF7
	v_bfe_u32 v99, v92, 8, 16                                  // 0000004875B4: D6100063 0241115C
	v_pk_fma_f16 v98, v98, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004875BC: CC0E0062 0BFC1162 0000C931
	v_and_b32_e32 v100, 0xffff, v100                           // 0000004875C8: 36C8C8FF 0000FFFF
	v_bfe_u32 v79, v78, 12, 16                                 // 0000004875D0: D610004F 0241194E
	v_alignbit_b32 v69, v69, v75, 16                           // 0000004875D8: D6160045 02429745
	v_add_nc_u32_e32 v17, 1, v17                               // 0000004875E0: 4A222281
	v_dot2acc_f32_f16 v51, v98, v3                             // 0000004875E4: 04660762
	v_lshl_or_b32 v95, v95, 16, v100                           // 0000004875E8: D656005F 0591215F
	v_dot2acc_f32_f16 v54, v98, v7                             // 0000004875F0: 046C0F62
	v_dot2acc_f32_f16 v41, v98, v15                            // 0000004875F4: 04521F62
	v_bfe_u32 v100, v92, 4, 16                                 // 0000004875F8: D6100064 0241095C
	v_bfe_u32 v75, v69, 12, 16                                 // 000000487600: D610004B 02411945
	v_pk_fma_f16 v95, v95, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487608: CC0E005F 0BFC115F 0000C931
	v_dot2acc_f32_f16 v50, v96, v10                            // 000000487614: 04641560
	v_bfe_u32 v96, v93, 8, 16                                  // 000000487618: D6100060 0241115D
	v_mul_u32_u24_e32 v101, s6, v96                            // 000000487620: 16CAC006
	v_mul_u32_u24_e32 v96, s7, v96                             // 000000487624: 16C0C007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000487628: BF870001
	v_lshl_add_u32 v96, v96, 24, v101                          // 00000048762C: D6460060 05953160
	v_mul_u32_u24_e32 v101, s6, v97                            // 000000487634: 16CAC206
	v_mul_u32_u24_e32 v97, s7, v97                             // 000000487638: 16C2C207
	v_lshl_add_u32 v97, v97, 24, v101                          // 00000048763C: D6460061 05953161
	v_dot2acc_f32_f16 v51, v95, v4                             // 000000487644: 0466095F
	v_dual_dot2acc_f32_f16 v54, v95, v8 :: v_dual_and_b32 v93, 0xffff, v93// 000000487648: CB24115F 365CBAFF 0000FFFF
	v_sad_u8 v96, v96, 0, 0x6400                               // 000000487654: D6220060 03FD0160 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 000000487660: BF870004
	v_sad_u8 v97, v97, 0, 0x6400                               // 000000487664: D6220061 03FD0161 00006400
	v_dot2acc_f32_f16 v50, v98, v11                            // 000000487670: 04641762
	v_mul_u32_u24_e32 v98, s6, v94                             // 000000487674: 16C4BC06
	v_mul_u32_u24_e32 v94, s7, v94                             // 000000487678: 16BCBC07
	v_lshl_add_u32 v94, v94, 24, v98                           // 00000048767C: D646005E 0589315E
	v_bfe_u32 v98, v92, 12, 16                                 // 000000487684: D6100062 0241195C
	v_mul_u32_u24_e32 v101, s6, v98                            // 00000048768C: 16CAC406
	v_mul_u32_u24_e32 v98, s7, v98                             // 000000487690: 16C4C407
	s_delay_alu instid0(VALU_DEP_1)                            // 000000487694: BF870001
	v_lshl_add_u32 v98, v98, 24, v101                          // 000000487698: D6460062 05953162
	v_sad_u8 v94, v94, 0, 0x6400                               // 0000004876A0: D622005E 03FD015E 00006400
	v_mul_u32_u24_e32 v101, s6, v93                            // 0000004876AC: 16CABA06
	v_mul_u32_u24_e32 v93, s7, v93                             // 0000004876B0: 16BABA07
	v_dot2acc_f32_f16 v41, v95, v16                            // 0000004876B4: 0452215F
	v_lshl_add_u32 v93, v93, 24, v101                          // 0000004876B8: D646005D 0595315D
	v_and_b32_e32 v94, 0xffff, v94                             // 0000004876C0: 36BCBCFF 0000FFFF
	v_mul_u32_u24_e32 v101, s6, v99                            // 0000004876C8: 16CAC606
	v_mul_u32_u24_e32 v99, s7, v99                             // 0000004876CC: 16C6C607
	v_lshl_add_u32 v99, v99, 24, v101                          // 0000004876D0: D6460063 05953163
	v_mul_u32_u24_e32 v101, s6, v100                           // 0000004876D8: 16CAC806
	v_lshl_or_b32 v94, v96, 16, v94                            // 0000004876DC: D656005E 05792160
	v_mul_u32_u24_e32 v100, s7, v100                           // 0000004876E4: 16C8C807
	v_sad_u8 v98, v98, 0, 0x6400                               // 0000004876E8: D6220062 03FD0162 00006400
	v_lshl_add_u32 v100, v100, 24, v101                        // 0000004876F4: D6460064 05953164
	v_and_b32_e32 v97, 0xffff, v97                             // 0000004876FC: 36C2C2FF 0000FFFF
	v_pk_fma_f16 v94, v94, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487704: CC0E005E 0BFC115E 0000C931
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000487710: D622005D 03FD015D 00006400
	v_and_b32_e32 v92, 0xffff, v92                             // 00000048771C: 36B8B8FF 0000FFFF
	v_and_b32_e32 v98, 0xffff, v98                             // 000000487724: 36C4C4FF 0000FFFF
	v_sad_u8 v99, v99, 0, 0x6400                               // 00000048772C: D6220063 03FD0163 00006400
	v_dot2acc_f32_f16 v53, v94, v1                             // 000000487738: 046A035E
	v_mul_u32_u24_e32 v101, s6, v92                            // 00000048773C: 16CAB806
	v_mul_u32_u24_e32 v92, s7, v92                             // 000000487740: 16B8B807
	v_sad_u8 v100, v100, 0, 0x6400                             // 000000487744: D6220064 03FD0164 00006400
	v_lshl_add_u32 v92, v92, 24, v101                          // 000000487750: D646005C 0595315C
	v_lshl_or_b32 v93, v93, 16, v97                            // 000000487758: D656005D 0585215D
	v_dot2acc_f32_f16 v52, v94, v9                             // 000000487760: 0468135E
	v_dot2acc_f32_f16 v49, v94, v13                            // 000000487764: 04621B5E
	v_lshl_or_b32 v96, v99, 16, v98                            // 000000487768: D6560060 05892163
	v_and_b32_e32 v97, 0xffff, v100                            // 000000487770: 36C2C8FF 0000FFFF
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000487778: D622005C 03FD015C 00006400
	v_pk_fma_f16 v93, v93, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487784: CC0E005D 0BFC115D 0000C931
	v_dual_dot2acc_f32_f16 v50, v95, v12 :: v_dual_dot2acc_f32_f16 v47, v94, v5// 000000487790: CB18195F 322E0B5E
	v_pk_fma_f16 v95, v96, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487798: CC0E005F 0BFC1160 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004877A4: BF870214
	v_lshl_or_b32 v92, v92, 16, v97                            // 0000004877A8: D656005C 0585215C
	v_dot2acc_f32_f16 v52, v93, v10                            // 0000004877B0: 0468155D
	v_dot2acc_f32_f16 v49, v93, v14                            // 0000004877B4: 04621D5D
	v_dot2acc_f32_f16 v47, v93, v6                             // 0000004877B8: 045E0D5D
	s_waitcnt vmcnt(5)                                         // 0000004877BC: BF8917F7
	v_bfe_u32 v94, v89, 12, 16                                 // 0000004877C0: D610005E 02411959
	v_pk_fma_f16 v92, v92, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004877C8: CC0E005C 0BFC115C 0000C931
	v_dual_dot2acc_f32_f16 v52, v95, v11 :: v_dual_dot2acc_f32_f16 v53, v93, v2// 0000004877D4: CB18175F 3434055D
	v_dot2acc_f32_f16 v47, v95, v7                             // 0000004877DC: 045E0F5F
	v_dot2acc_f32_f16 v49, v95, v15                            // 0000004877E0: 04621F5F
	v_bfe_u32 v93, v90, 4, 16                                  // 0000004877E4: D610005D 0241095A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000004877EC: BF870214
	v_dual_dot2acc_f32_f16 v52, v92, v12 :: v_dual_dot2acc_f32_f16 v53, v95, v3// 0000004877F0: CB18195C 3434075F
	v_dot2acc_f32_f16 v47, v92, v8                             // 0000004877F8: 045E115C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004877FC: BF870004
	v_dot2acc_f32_f16 v49, v92, v16                            // 000000487800: 0462215C
	v_mul_u32_u24_e32 v96, s6, v93                             // 000000487804: 16C0BA06
	v_mul_u32_u24_e32 v93, s7, v93                             // 000000487808: 16BABA07
	v_dot2acc_f32_f16 v53, v92, v4                             // 00000048780C: 046A095C
	v_mul_u32_u24_e32 v92, s6, v91                             // 000000487810: 16B8B606
	v_mul_u32_u24_e32 v91, s7, v91                             // 000000487814: 16B6B607
	v_lshl_add_u32 v91, v91, 24, v92                           // 000000487818: D646005B 0571315B
	v_bfe_u32 v92, v90, 8, 16                                  // 000000487820: D610005C 0241115A
	v_lshl_add_u32 v93, v93, 24, v96                           // 000000487828: D646005D 0581315D
	v_mul_u32_u24_e32 v96, s6, v92                             // 000000487830: 16C0B806
	v_mul_u32_u24_e32 v92, s7, v92                             // 000000487834: 16B8B807
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000487838: D622005B 03FD015B 00006400
	v_lshl_add_u32 v92, v92, 24, v96                           // 000000487844: D646005C 0581315C
	v_and_b32_e32 v90, 0xffff, v90                             // 00000048784C: 36B4B4FF 0000FFFF
	v_mul_u32_u24_e32 v96, s6, v90                             // 000000487854: 16C0B406
	v_mul_u32_u24_e32 v90, s7, v90                             // 000000487858: 16B4B407
	v_sad_u8 v93, v93, 0, 0x6400                               // 00000048785C: D622005D 03FD015D 00006400
	s_delay_alu instid0(VALU_DEP_2)                            // 000000487868: BF870002
	v_lshl_add_u32 v90, v90, 24, v96                           // 00000048786C: D646005A 0581315A
	v_and_b32_e32 v91, 0xffff, v91                             // 000000487874: 36B6B6FF 0000FFFF
	v_sad_u8 v92, v92, 0, 0x6400                               // 00000048787C: D622005C 03FD015C 00006400
	v_bfe_u32 v96, v89, 4, 16                                  // 000000487888: D6100060 02410959
	v_and_b32_e32 v93, 0xffff, v93                             // 000000487890: 36BABAFF 0000FFFF
	v_sad_u8 v90, v90, 0, 0x6400                               // 000000487898: D622005A 03FD015A 00006400
	v_bfe_u32 v95, v89, 8, 16                                  // 0000004878A4: D610005F 02411159
	v_lshl_or_b32 v91, v92, 16, v91                            // 0000004878AC: D656005B 056D215C
	v_mul_u32_u24_e32 v92, s6, v94                             // 0000004878B4: 16B8BC06
	v_mul_u32_u24_e32 v94, s7, v94                             // 0000004878B8: 16BCBC07
	v_lshl_add_u32 v92, v94, 24, v92                           // 0000004878BC: D646005C 0571315E
	v_lshl_or_b32 v90, v90, 16, v93                            // 0000004878C4: D656005A 0575215A
	v_mul_u32_u24_e32 v93, s6, v96                             // 0000004878CC: 16BAC006
	v_mul_u32_u24_e32 v94, s7, v96                             // 0000004878D0: 16BCC007
	v_lshl_add_u32 v93, v94, 24, v93                           // 0000004878D4: D646005D 0575315E
	v_mul_u32_u24_e32 v94, s6, v95                             // 0000004878DC: 16BCBE06
	v_sad_u8 v92, v92, 0, 0x6400                               // 0000004878E0: D622005C 03FD015C 00006400
	v_mul_u32_u24_e32 v95, s7, v95                             // 0000004878EC: 16BEBE07
	v_lshl_add_u32 v94, v95, 24, v94                           // 0000004878F0: D646005E 0579315F
	v_pk_fma_f16 v91, v91, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004878F8: CC0E005B 0BFC115B 0000C931
	v_pk_fma_f16 v90, v90, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487904: CC0E005A 0BFC115A 0000C931
	v_and_b32_e32 v92, 0xffff, v92                             // 000000487910: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000487918: D622005D 03FD015D 00006400
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000487924: D622005E 03FD015E 00006400
	v_dot2acc_f32_f16 v29, v91, v5                             // 000000487930: 043A0B5B
	v_dot2acc_f32_f16 v48, v91, v1                             // 000000487934: 0460035B
	v_dot2acc_f32_f16 v46, v91, v9                             // 000000487938: 045C135B
	v_dot2acc_f32_f16 v45, v91, v13                            // 00000048793C: 045A1B5B
	v_lshl_or_b32 v92, v94, 16, v92                            // 000000487940: D656005C 0571215E
	v_dot2acc_f32_f16 v29, v90, v6                             // 000000487948: 043A0D5A
	v_dot2acc_f32_f16 v48, v90, v2                             // 00000048794C: 0460055A
	v_dot2acc_f32_f16 v46, v90, v10                            // 000000487950: 045C155A
	v_dot2acc_f32_f16 v45, v90, v14                            // 000000487954: 045A1D5A
	v_pk_fma_f16 v92, v92, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487958: CC0E005C 0BFC115C 0000C931
	v_and_b32_e32 v89, 0xffff, v89                             // 000000487964: 36B2B2FF 0000FFFF
	v_bfe_u32 v90, v87, 8, 16                                  // 00000048796C: D610005A 02411157
	v_bfe_u32 v91, v87, 4, 16                                  // 000000487974: D610005B 02410957
	s_waitcnt vmcnt(4)                                         // 00000048797C: BF8913F7
	v_bfe_u32 v94, v86, 4, 16                                  // 000000487980: D610005E 02410956
	v_dot2acc_f32_f16 v29, v92, v7                             // 000000487988: 043A0F5C
	v_dot2acc_f32_f16 v48, v92, v3                             // 00000048798C: 0460075C
	v_dot2acc_f32_f16 v46, v92, v11                            // 000000487990: 045C175C
	v_dot2acc_f32_f16 v45, v92, v15                            // 000000487994: 045A1F5C
	v_mul_u32_u24_e32 v92, s6, v88                             // 000000487998: 16B8B006
	v_mul_u32_u24_e32 v88, s7, v88                             // 00000048799C: 16B0B007
	v_lshl_add_u32 v88, v88, 24, v92                           // 0000004879A0: D6460058 05713158
	v_mul_u32_u24_e32 v95, s6, v89                             // 0000004879A8: 16BEB206
	v_mul_u32_u24_e32 v89, s7, v89                             // 0000004879AC: 16B2B207
	v_lshl_add_u32 v89, v89, 24, v95                           // 0000004879B0: D6460059 057D3159
	v_mul_u32_u24_e32 v95, s6, v90                             // 0000004879B8: 16BEB406
	v_mul_u32_u24_e32 v90, s7, v90                             // 0000004879BC: 16B4B407
	v_sad_u8 v88, v88, 0, 0x6400                               // 0000004879C0: D6220058 03FD0158 00006400
	v_lshl_add_u32 v90, v90, 24, v95                           // 0000004879CC: D646005A 057D315A
	v_mul_u32_u24_e32 v95, s6, v91                             // 0000004879D4: 16BEB606
	v_mul_u32_u24_e32 v91, s7, v91                             // 0000004879D8: 16B6B607
	v_lshl_add_u32 v91, v91, 24, v95                           // 0000004879DC: D646005B 057D315B
	v_and_b32_e32 v88, 0xffff, v88                             // 0000004879E4: 36B0B0FF 0000FFFF
	v_sad_u8 v90, v90, 0, 0x6400                               // 0000004879EC: D622005A 03FD015A 00006400
	v_bfe_u32 v92, v86, 12, 16                                 // 0000004879F8: D610005C 02411956
	v_mul_u32_u24_e32 v95, s6, v92                             // 000000487A00: 16BEB806
	v_mul_u32_u24_e32 v92, s7, v92                             // 000000487A04: 16B8B807
	s_delay_alu instid0(VALU_DEP_1)                            // 000000487A08: BF870001
	v_lshl_add_u32 v92, v92, 24, v95                           // 000000487A0C: D646005C 057D315C
	v_lshl_or_b32 v88, v90, 16, v88                            // 000000487A14: D6560058 0561215A
	v_sad_u8 v91, v91, 0, 0x6400                               // 000000487A1C: D622005B 03FD015B 00006400
	v_and_b32_e32 v93, 0xffff, v93                             // 000000487A28: 36BABAFF 0000FFFF
	v_sad_u8 v89, v89, 0, 0x6400                               // 000000487A30: D6220059 03FD0159 00006400
	v_sad_u8 v92, v92, 0, 0x6400                               // 000000487A3C: D622005C 03FD015C 00006400
	v_pk_fma_f16 v88, v88, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487A48: CC0E0058 0BFC1158 0000C931
	v_and_b32_e32 v87, 0xffff, v87                             // 000000487A54: 36AEAEFF 0000FFFF
	v_add_nc_u32_e32 v57, 32, v57                              // 000000487A5C: 4A7272A0
	v_lshl_or_b32 v89, v89, 16, v93                            // 000000487A60: D6560059 05752159
	v_bfe_u32 v93, v86, 8, 16                                  // 000000487A68: D610005D 02411156
	v_dot2acc_f32_f16 v40, v88, v13                            // 000000487A70: 04501B58
	v_mul_u32_u24_e32 v95, s6, v87                             // 000000487A74: 16BEAE06
	v_mul_u32_u24_e32 v87, s7, v87                             // 000000487A78: 16AEAE07
	v_lshl_add_u32 v87, v87, 24, v95                           // 000000487A7C: D6460057 057D3157
	v_and_b32_e32 v91, 0xffff, v91                             // 000000487A84: 36B6B6FF 0000FFFF
	v_mul_u32_u24_e32 v95, s6, v93                             // 000000487A8C: 16BEBA06
	v_mul_u32_u24_e32 v93, s7, v93                             // 000000487A90: 16BABA07
	v_lshl_add_u32 v93, v93, 24, v95                           // 000000487A94: D646005D 057D315D
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000487A9C: D6220057 03FD0157 00006400
	v_mul_u32_u24_e32 v95, s6, v94                             // 000000487AA8: 16BEBC06
	v_mul_u32_u24_e32 v94, s7, v94                             // 000000487AAC: 16BCBC07
	v_pk_fma_f16 v89, v89, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487AB0: CC0E0059 0BFC1159 0000C931
	v_lshl_add_u32 v94, v94, 24, v95                           // 000000487ABC: D646005E 057D315E
	v_lshl_or_b32 v87, v87, 16, v91                            // 000000487AC4: D6560057 056D2157
	v_and_b32_e32 v92, 0xffff, v92                             // 000000487ACC: 36B8B8FF 0000FFFF
	v_sad_u8 v93, v93, 0, 0x6400                               // 000000487AD4: D622005D 03FD015D 00006400
	v_dot2acc_f32_f16 v44, v88, v5                             // 000000487AE0: 04580B58
	v_and_b32_e32 v86, 0xffff, v86                             // 000000487AE4: 36ACACFF 0000FFFF
	v_pk_fma_f16 v87, v87, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487AEC: CC0E0057 0BFC1157 0000C931
	v_mul_u32_u24_e32 v95, s6, v86                             // 000000487AF8: 16BEAC06
	v_mul_u32_u24_e32 v86, s7, v86                             // 000000487AFC: 16ACAC07
	v_sad_u8 v94, v94, 0, 0x6400                               // 000000487B00: D622005E 03FD015E 00006400
	v_lshl_add_u32 v86, v86, 24, v95                           // 000000487B0C: D6460056 057D3156
	v_lshl_or_b32 v90, v93, 16, v92                            // 000000487B14: D656005A 0571215D
	v_dot2acc_f32_f16 v42, v88, v9                             // 000000487B1C: 04541358
	v_dual_dot2acc_f32_f16 v44, v87, v6 :: v_dual_dot2acc_f32_f16 v29, v89, v8// 000000487B20: CB180D57 2C1C1159
	v_dot2acc_f32_f16 v48, v89, v4                             // 000000487B28: 04600959
	v_dot2acc_f32_f16 v46, v89, v12                            // 000000487B2C: 045C1959
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000487B30: D6220056 03FD0156 00006400
	v_dual_dot2acc_f32_f16 v42, v87, v10 :: v_dual_dot2acc_f32_f16 v45, v89, v16// 000000487B3C: CB181557 2A2C2159
	v_pk_fma_f16 v89, v90, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487B44: CC0E0059 0BFC115A 0000C931
	v_and_b32_e32 v91, 0xffff, v94                             // 000000487B50: 36B6BCFF 0000FFFF
	v_dual_dot2acc_f32_f16 v43, v88, v1 :: v_dual_dot2acc_f32_f16 v40, v87, v14// 000000487B58: CB180358 2B281D57
	s_waitcnt vmcnt(3)                                         // 000000487B60: BF890FF7
	v_bfe_u32 v88, v83, 12, 16                                 // 000000487B64: D6100058 02411953
	v_dot2acc_f32_f16 v44, v89, v7                             // 000000487B6C: 04580F59
	v_lshl_or_b32 v86, v86, 16, v91                            // 000000487B70: D6560056 056D2156
	v_dual_dot2acc_f32_f16 v42, v89, v11 :: v_dual_dot2acc_f32_f16 v43, v87, v2// 000000487B78: CB181759 2A2A0557
	v_dot2acc_f32_f16 v40, v89, v15                            // 000000487B80: 04501F59
	v_bfe_u32 v87, v84, 4, 16                                  // 000000487B84: D6100057 02410954
	s_delay_alu instid0(VALU_DEP_4)                            // 000000487B8C: BF870004
	v_pk_fma_f16 v86, v86, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487B90: CC0E0056 0BFC1156 0000C931
	v_mul_u32_u24_e32 v90, s6, v87                             // 000000487B9C: 16B4AE06
	v_dot2acc_f32_f16 v43, v89, v3                             // 000000487BA0: 04560759
	v_mul_u32_u24_e32 v87, s7, v87                             // 000000487BA4: 16AEAE07
	v_lshl_add_u32 v87, v87, 24, v90                           // 000000487BA8: D6460057 05693157
	v_dot2acc_f32_f16 v44, v86, v8                             // 000000487BB0: 04581156
	v_dot2acc_f32_f16 v42, v86, v12                            // 000000487BB4: 04541956
	v_dot2acc_f32_f16 v43, v86, v4                             // 000000487BB8: 04560956
	v_dot2acc_f32_f16 v40, v86, v16                            // 000000487BBC: 04502156
	v_mul_u32_u24_e32 v86, s6, v85                             // 000000487BC0: 16ACAA06
	v_mul_u32_u24_e32 v85, s7, v85                             // 000000487BC4: 16AAAA07
	v_lshl_add_u32 v85, v85, 24, v86                           // 000000487BC8: D6460055 05593155
	v_bfe_u32 v86, v84, 8, 16                                  // 000000487BD0: D6100056 02411154
	v_mul_u32_u24_e32 v90, s6, v86                             // 000000487BD8: 16B4AC06
	v_mul_u32_u24_e32 v86, s7, v86                             // 000000487BDC: 16ACAC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000487BE0: BF870001
	v_lshl_add_u32 v86, v86, 24, v90                           // 000000487BE4: D6460056 05693156
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000487BEC: D6220055 03FD0155 00006400
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000487BF8: D6220057 03FD0157 00006400
	v_bfe_u32 v89, v83, 8, 16                                  // 000000487C04: D6100059 02411153
	v_mov_b32_e32 v91, v73                                     // 000000487C0C: 7EB60349
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000487C10: D6220056 03FD0156 00006400
	v_dual_mov_b32 v92, v74 :: v_dual_and_b32 v85, 0xffff, v85 // 000000487C1C: CA24014A 5C54AAFF 0000FFFF
	v_dual_mov_b32 v94, v74 :: v_dual_mov_b32 v93, v67         // 000000487C28: CA10014A 5E5C0143
	v_mov_b32_e32 v95, v76                                     // 000000487C30: 7EBE034C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000487C34: BF870143
	v_lshl_or_b32 v85, v86, 16, v85                            // 000000487C38: D6560055 05552156
	v_mul_u32_u24_e32 v86, s6, v88                             // 000000487C40: 16ACB006
	v_mul_u32_u24_e32 v88, s7, v88                             // 000000487C44: 16B0B007
	v_lshl_add_u32 v86, v88, 24, v86                           // 000000487C48: D6460056 05593158
	v_pk_fma_f16 v85, v85, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487C50: CC0E0055 0BFC1155 0000C931
	v_and_b32_e32 v84, 0xffff, v84                             // 000000487C5C: 36A8A8FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000487C64: BF870193
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000487C68: D6220056 03FD0156 00006400
	v_dot2acc_f32_f16 v39, v85, v5                             // 000000487C74: 044E0B55
	v_mul_u32_u24_e32 v90, s6, v84                             // 000000487C78: 16B4A806
	v_mul_u32_u24_e32 v84, s7, v84                             // 000000487C7C: 16A8A807
	v_lshl_add_u32 v84, v84, 24, v90                           // 000000487C80: D6460054 05693154
	v_dual_dot2acc_f32_f16 v38, v85, v1 :: v_dual_and_b32 v87, 0xffff, v87// 000000487C88: CB240355 2656AEFF 0000FFFF
	v_bfe_u32 v90, v83, 4, 16                                  // 000000487C94: D610005A 02410953
	v_mul_u32_u24_e32 v88, s7, v90                             // 000000487C9C: 16B0B407
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000487CA0: BF870243
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000487CA4: D6220054 03FD0154 00006400
	v_and_b32_e32 v83, 0xffff, v83                             // 000000487CB0: 36A6A6FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v86                             // 000000487CB8: 36ACACFF 0000FFFF
	v_dot2acc_f32_f16 v36, v85, v13                            // 000000487CC0: 04481B55
	v_lshl_or_b32 v84, v84, 16, v87                            // 000000487CC4: D6560054 055D2154
	v_mul_u32_u24_e32 v87, s6, v90                             // 000000487CCC: 16AEB406
	v_lshl_add_u32 v87, v88, 24, v87                           // 000000487CD0: D6460057 055D3158
	v_mul_u32_u24_e32 v88, s6, v89                             // 000000487CD8: 16B0B206
	v_mul_u32_u24_e32 v89, s7, v89                             // 000000487CDC: 16B2B207
	v_lshl_add_u32 v88, v89, 24, v88                           // 000000487CE0: D6460058 05613159
	v_mul_u32_u24_e32 v89, s6, v83                             // 000000487CE8: 16B2A606
	v_mul_u32_u24_e32 v83, s7, v83                             // 000000487CEC: 16A6A607
	v_sad_u8 v87, v87, 0, 0x6400                               // 000000487CF0: D6220057 03FD0157 00006400
	v_lshl_add_u32 v83, v83, 24, v89                           // 000000487CFC: D6460053 05653153
	v_sad_u8 v88, v88, 0, 0x6400                               // 000000487D04: D6220058 03FD0158 00006400
	v_pk_fma_f16 v84, v84, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487D10: CC0E0054 0BFC1154 0000C931
	v_mov_b32_e32 v89, v73                                     // 000000487D1C: 7EB20349
	v_and_b32_e32 v87, 0xffff, v87                             // 000000487D20: 36AEAEFF 0000FFFF
	v_sad_u8 v83, v83, 0, 0x6400                               // 000000487D28: D6220053 03FD0153 00006400
	v_lshl_or_b32 v86, v88, 16, v86                            // 000000487D34: D6560056 05592158
	v_dot2acc_f32_f16 v38, v84, v2                             // 000000487D3C: 044C0554
	v_dot2acc_f32_f16 v36, v84, v14                            // 000000487D40: 04481D54
	s_waitcnt vmcnt(2)                                         // 000000487D44: BF890BF7
	v_bfe_u32 v88, v80, 4, 16                                  // 000000487D48: D6100058 02410950
	v_lshl_or_b32 v83, v83, 16, v87                            // 000000487D50: D6560053 055D2153
	v_pk_fma_f16 v86, v86, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487D58: CC0E0056 0BFC1156 0000C931
	v_dot2acc_f32_f16 v37, v85, v9                             // 000000487D64: 044A1355
	v_bfe_u32 v85, v81, 4, 16                                  // 000000487D68: D6100055 02410951
	v_mov_b32_e32 v90, v64                                     // 000000487D70: 7EB40340
	v_pk_fma_f16 v83, v83, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487D74: CC0E0053 0BFC1153 0000C931
	v_dual_dot2acc_f32_f16 v38, v86, v3 :: v_dual_dot2acc_f32_f16 v39, v84, v6// 000000487D80: CB180756 26260D54
	v_dual_dot2acc_f32_f16 v37, v84, v10 :: v_dual_dot2acc_f32_f16 v36, v86, v15// 000000487D88: CB181554 25241F56
	v_mul_u32_u24_e32 v84, s6, v82                             // 000000487D90: 16A8A406
	s_delay_alu instid0(VALU_DEP_2)                            // 000000487D94: BF870002
	v_dual_dot2acc_f32_f16 v38, v83, v4 :: v_dual_dot2acc_f32_f16 v39, v86, v7// 000000487D98: CB180953 26260F56
	v_mul_u32_u24_e32 v82, s7, v82                             // 000000487DA0: 16A4A407
	v_lshl_add_u32 v82, v82, 24, v84                           // 000000487DA4: D6460052 05513152
	v_bfe_u32 v84, v81, 8, 16                                  // 000000487DAC: D6100054 02411151
	v_mul_u32_u24_e32 v87, s6, v84                             // 000000487DB4: 16AEA806
	v_mul_u32_u24_e32 v84, s7, v84                             // 000000487DB8: 16A8A807
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000487DBC: BF870151
	v_lshl_add_u32 v84, v84, 24, v87                           // 000000487DC0: D6460054 055D3154
	v_sad_u8 v82, v82, 0, 0x6400                               // 000000487DC8: D6220052 03FD0152 00006400
	v_mul_u32_u24_e32 v87, s6, v85                             // 000000487DD4: 16AEAA06
	v_mul_u32_u24_e32 v85, s7, v85                             // 000000487DD8: 16AAAA07
	v_lshl_add_u32 v85, v85, 24, v87                           // 000000487DDC: D6460055 055D3155
	v_dual_dot2acc_f32_f16 v37, v86, v11 :: v_dual_and_b32 v82, 0xffff, v82// 000000487DE4: CB241756 2552A4FF 0000FFFF
	v_sad_u8 v84, v84, 0, 0x6400                               // 000000487DF0: D6220054 03FD0154 00006400
	v_dual_dot2acc_f32_f16 v36, v83, v16 :: v_dual_and_b32 v81, 0xffff, v81// 000000487DFC: CB242153 2450A2FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000487E08: BF870224
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000487E0C: D6220055 03FD0155 00006400
	v_dot2acc_f32_f16 v39, v83, v8                             // 000000487E18: 044E1153
	v_lshl_or_b32 v82, v84, 16, v82                            // 000000487E1C: D6560052 05492154
	v_mul_u32_u24_e32 v84, s6, v81                             // 000000487E24: 16A8A206
	v_mul_u32_u24_e32 v81, s7, v81                             // 000000487E28: 16A2A207
	v_bfe_u32 v86, v80, 12, 16                                 // 000000487E2C: D6100056 02411950
	v_lshl_add_u32 v81, v81, 24, v84                           // 000000487E34: D6460051 05513151
	v_and_b32_e32 v84, 0xffff, v85                             // 000000487E3C: 36A8AAFF 0000FFFF
	v_mul_u32_u24_e32 v85, s6, v86                             // 000000487E44: 16AAAC06
	v_mul_u32_u24_e32 v86, s7, v86                             // 000000487E48: 16ACAC07
	v_lshl_add_u32 v85, v86, 24, v85                           // 000000487E4C: D6460055 05553156
	v_bfe_u32 v87, v80, 8, 16                                  // 000000487E54: D6100057 02411150
	v_mul_u32_u24_e32 v86, s6, v88                             // 000000487E5C: 16ACB006
	v_mul_u32_u24_e32 v88, s7, v88                             // 000000487E60: 16B0B007
	v_lshl_add_u32 v86, v88, 24, v86                           // 000000487E64: D6460056 05593158
	v_mul_u32_u24_e32 v88, s6, v87                             // 000000487E6C: 16B0AE06
	v_mul_u32_u24_e32 v87, s7, v87                             // 000000487E70: 16AEAE07
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000487E74: D6220051 03FD0151 00006400
	v_sad_u8 v85, v85, 0, 0x6400                               // 000000487E80: D6220055 03FD0155 00006400
	v_lshl_add_u32 v87, v87, 24, v88                           // 000000487E8C: D6460057 05613157
	v_dot2acc_f32_f16 v37, v83, v12                            // 000000487E94: 044A1953
	v_sad_u8 v86, v86, 0, 0x6400                               // 000000487E98: D6220056 03FD0156 00006400
	v_lshl_or_b32 v81, v81, 16, v84                            // 000000487EA4: D6560051 05512151
	v_and_b32_e32 v84, 0xffff, v85                             // 000000487EAC: 36A8AAFF 0000FFFF
	v_sad_u8 v85, v87, 0, 0x6400                               // 000000487EB4: D6220055 03FD0157 00006400
	v_pk_fma_f16 v82, v82, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487EC0: CC0E0052 0BFC1152 0000C931
	v_and_b32_e32 v80, 0xffff, v80                             // 000000487ECC: 36A0A0FF 0000FFFF
	v_and_b32_e32 v86, 0xffff, v86                             // 000000487ED4: 36ACACFF 0000FFFF
	v_pk_fma_f16 v81, v81, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487EDC: CC0E0051 0BFC1151 0000C931
	v_lshl_or_b32 v83, v85, 16, v84                            // 000000487EE8: D6560053 05512155
	v_dot2acc_f32_f16 v35, v82, v5                             // 000000487EF0: 04460B52
	v_mul_u32_u24_e32 v88, s6, v80                             // 000000487EF4: 16B0A006
	v_mul_u32_u24_e32 v80, s7, v80                             // 000000487EF8: 16A0A007
	v_dot2acc_f32_f16 v33, v82, v9                             // 000000487EFC: 04421352
	v_lshl_add_u32 v80, v80, 24, v88                           // 000000487F00: D6460050 05613150
	v_dual_dot2acc_f32_f16 v34, v82, v1 :: v_dual_dot2acc_f32_f16 v35, v81, v6// 000000487F08: CB180352 22220D51
	v_pk_fma_f16 v83, v83, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487F10: CC0E0053 0BFC1153 0000C931
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000487F1C: BF870214
	v_dual_dot2acc_f32_f16 v33, v81, v10 :: v_dual_dot2acc_f32_f16 v32, v82, v13// 000000487F20: CB181551 21201B52
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000487F28: D6220050 03FD0150 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000487F34: BF870193
	v_dual_dot2acc_f32_f16 v34, v81, v2 :: v_dual_dot2acc_f32_f16 v35, v83, v7// 000000487F38: CB180551 22220F53
	v_dual_dot2acc_f32_f16 v33, v83, v11 :: v_dual_dot2acc_f32_f16 v32, v81, v14// 000000487F40: CB181753 21201D51
	v_mul_u32_u24_e32 v81, s6, v79                             // 000000487F48: 16A29E06
	v_mul_u32_u24_e32 v79, s7, v79                             // 000000487F4C: 169E9E07
	v_lshl_or_b32 v80, v80, 16, v86                            // 000000487F50: D6560050 05592150
	v_lshl_add_u32 v79, v79, 24, v81                           // 000000487F58: D646004F 0545314F
	v_bfe_u32 v81, v78, 8, 16                                  // 000000487F60: D6100051 0241114E
	v_mul_u32_u24_e32 v82, s6, v81                             // 000000487F68: 16A4A206
	v_mul_u32_u24_e32 v81, s7, v81                             // 000000487F6C: 16A2A207
	v_pk_fma_f16 v80, v80, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000487F70: CC0E0050 0BFC1150 0000C931
	v_dot2acc_f32_f16 v34, v83, v3                             // 000000487F7C: 04440753
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000487F80: D622004F 03FD014F 00006400
	v_lshl_add_u32 v81, v81, 24, v82                           // 000000487F8C: D6460051 05493151
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000487F94: BF870224
	v_dual_dot2acc_f32_f16 v32, v83, v15 :: v_dual_dot2acc_f32_f16 v33, v80, v12// 000000487F98: CB181F53 20201950
	v_dot2acc_f32_f16 v35, v80, v8                             // 000000487FA0: 04461150
	v_dual_dot2acc_f32_f16 v34, v80, v4 :: v_dual_and_b32 v79, 0xffff, v79// 000000487FA4: CB240950 224E9EFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000487FB0: BF870214
	v_sad_u8 v81, v81, 0, 0x6400                               // 000000487FB4: D6220051 03FD0151 00006400
	v_dot2acc_f32_f16 v32, v80, v16                            // 000000487FC0: 04402150
	v_bfe_u32 v80, v78, 4, 16                                  // 000000487FC4: D6100050 0241094E
	v_mul_u32_u24_e32 v83, s6, v80                             // 000000487FCC: 16A6A006
	v_mul_u32_u24_e32 v80, s7, v80                             // 000000487FD0: 16A0A007
	v_lshl_or_b32 v79, v81, 16, v79                            // 000000487FD4: D656004F 053D2151
	s_delay_alu instid0(VALU_DEP_2)                            // 000000487FDC: BF870002
	v_lshl_add_u32 v80, v80, 24, v83                           // 000000487FE0: D6460050 054D3150
	s_waitcnt vmcnt(1)                                         // 000000487FE8: BF8907F7
	v_bfe_u32 v82, v77, 12, 16                                 // 000000487FEC: D6100052 0241194D
	v_bfe_u32 v83, v77, 8, 16                                  // 000000487FF4: D6100053 0241114D
	v_mov_b32_e32 v86, v72                                     // 000000487FFC: 7EAC0348
	v_pk_fma_f16 v79, v79, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000488000: CC0E004F 0BFC114F 0000C931
	v_and_b32_e32 v78, 0xffff, v78                             // 00000048800C: 369C9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000488014: D6220050 03FD0150 00006400
	v_dual_mov_b32 v88, v72 :: v_dual_mov_b32 v87, v63         // 000000488020: CA100148 5856013F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000488028: BF870004
	v_dot2acc_f32_f16 v31, v79, v5                             // 00000048802C: 043E0B4F
	v_mul_u32_u24_e32 v84, s6, v78                             // 000000488030: 16A89C06
	v_mul_u32_u24_e32 v78, s7, v78                             // 000000488034: 169C9C07
	v_lshl_add_u32 v78, v78, 24, v84                           // 000000488038: D646004E 0551314E
	v_and_b32_e32 v80, 0xffff, v80                             // 000000488040: 36A0A0FF 0000FFFF
	v_mul_u32_u24_e32 v84, s6, v82                             // 000000488048: 16A8A406
	v_mul_u32_u24_e32 v82, s7, v82                             // 00000048804C: 16A4A407
	v_lshl_add_u32 v82, v82, 24, v84                           // 000000488050: D6460052 05513152
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000488058: D622004E 03FD014E 00006400
	v_bfe_u32 v84, v77, 4, 16                                  // 000000488064: D6100054 0241094D
	v_and_b32_e32 v77, 0xffff, v77                             // 00000048806C: 369A9AFF 0000FFFF
	v_dot2acc_f32_f16 v27, v79, v13                            // 000000488074: 04361B4F
	v_sad_u8 v81, v82, 0, 0x6400                               // 000000488078: D6220051 03FD0152 00006400
	v_lshl_or_b32 v78, v78, 16, v80                            // 000000488084: D656004E 0541214E
	v_mul_u32_u24_e32 v80, s6, v84                             // 00000048808C: 16A0A806
	v_mul_u32_u24_e32 v82, s7, v84                             // 000000488090: 16A4A807
	v_lshl_add_u32 v80, v82, 24, v80                           // 000000488094: D6460050 05413152
	v_mul_u32_u24_e32 v82, s6, v83                             // 00000048809C: 16A4A606
	v_mul_u32_u24_e32 v83, s7, v83                             // 0000004880A0: 16A6A607
	v_lshl_add_u32 v82, v83, 24, v82                           // 0000004880A4: D6460052 05493153
	v_pk_fma_f16 v78, v78, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004880AC: CC0E004E 0BFC114E 0000C931
	v_mul_u32_u24_e32 v83, s6, v77                             // 0000004880B8: 16A69A06
	v_mul_u32_u24_e32 v77, s7, v77                             // 0000004880BC: 169A9A07
	v_sad_u8 v80, v80, 0, 0x6400                               // 0000004880C0: D6220050 03FD0150 00006400
	v_lshl_add_u32 v77, v77, 24, v83                           // 0000004880CC: D646004D 054D314D
	v_sad_u8 v82, v82, 0, 0x6400                               // 0000004880D4: D6220052 03FD0152 00006400
	v_dual_dot2acc_f32_f16 v31, v78, v6 :: v_dual_dot2acc_f32_f16 v30, v79, v1// 0000004880E0: CB180D4E 1F1E034F
	v_and_b32_e32 v81, 0xffff, v81                             // 0000004880E8: 36A2A2FF 0000FFFF
	v_and_b32_e32 v80, 0xffff, v80                             // 0000004880F0: 36A0A0FF 0000FFFF
	v_sad_u8 v77, v77, 0, 0x6400                               // 0000004880F8: D622004D 03FD014D 00006400
	v_dot2acc_f32_f16 v27, v78, v14                            // 000000488104: 04361D4E
	v_dot2acc_f32_f16 v30, v78, v2                             // 000000488108: 043C054E
	v_lshl_or_b32 v81, v82, 16, v81                            // 00000048810C: D6560051 05452152
	s_waitcnt vmcnt(0)                                         // 000000488114: BF8903F7
	v_bfe_u32 v82, v59, 4, 16                                  // 000000488118: D6100052 0241093B
	v_lshl_or_b32 v77, v77, 16, v80                            // 000000488120: D656004D 0541214D
	v_dual_mov_b32 v84, v62 :: v_dual_mov_b32 v85, v71         // 000000488128: CA10013E 54540147
	v_pk_fma_f16 v80, v81, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000488130: CC0E0050 0BFC1151 0000C931
	v_bfe_u32 v81, v59, 8, 16                                  // 00000048813C: D6100051 0241113B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000488144: BF870194
	v_pk_fma_f16 v77, v77, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000488148: CC0E004D 0BFC114D 0000C931
	v_dual_dot2acc_f32_f16 v31, v80, v7 :: v_dual_dot2acc_f32_f16 v28, v79, v9// 000000488154: CB180F50 1F1C134F
	v_dot2acc_f32_f16 v30, v80, v3                             // 00000048815C: 043C0750
	v_dot2acc_f32_f16 v27, v80, v15                            // 000000488160: 04361F50
	v_bfe_u32 v79, v69, 4, 16                                  // 000000488164: D610004F 02410945
	s_delay_alu instid0(VALU_DEP_4)                            // 00000048816C: BF870004
	v_dual_dot2acc_f32_f16 v31, v77, v8 :: v_dual_dot2acc_f32_f16 v28, v78, v10// 000000488170: CB18114D 1F1C154E
	v_mul_u32_u24_e32 v78, s6, v75                             // 000000488178: 169C9606
	v_mul_u32_u24_e32 v75, s7, v75                             // 00000048817C: 16969607
	v_lshl_add_u32 v75, v75, 24, v78                           // 000000488180: D646004B 0539314B
	v_bfe_u32 v78, v69, 8, 16                                  // 000000488188: D610004E 02411145
	v_dual_dot2acc_f32_f16 v28, v80, v11 :: v_dual_and_b32 v69, 0xffff, v69// 000000488190: CB241750 1C448AFF 0000FFFF
	v_mul_u32_u24_e32 v80, s6, v78                             // 00000048819C: 16A09C06
	v_mul_u32_u24_e32 v78, s7, v78                             // 0000004881A0: 169C9C07
	v_sad_u8 v75, v75, 0, 0x6400                               // 0000004881A4: D622004B 03FD014B 00006400
	v_lshl_add_u32 v78, v78, 24, v80                           // 0000004881B0: D646004E 0541314E
	v_dot2acc_f32_f16 v30, v77, v4                             // 0000004881B8: 043C094D
	v_mul_u32_u24_e32 v83, s6, v79                             // 0000004881BC: 16A69E06
	v_mul_u32_u24_e32 v79, s7, v79                             // 0000004881C0: 169E9E07
	v_and_b32_e32 v75, 0xffff, v75                             // 0000004881C4: 369696FF 0000FFFF
	v_sad_u8 v78, v78, 0, 0x6400                               // 0000004881CC: D622004E 03FD014E 00006400
	v_lshl_add_u32 v79, v79, 24, v83                           // 0000004881D8: D646004F 054D314F
	v_bfe_u32 v80, v59, 12, 16                                 // 0000004881E0: D6100050 0241193B
	v_dual_dot2acc_f32_f16 v28, v77, v12 :: v_dual_and_b32 v59, 0xffff, v59// 0000004881E8: CB24194D 1C3A76FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004881F4: BF870004
	v_lshl_or_b32 v75, v78, 16, v75                            // 0000004881F8: D656004B 052D214E
	v_mul_u32_u24_e32 v78, s6, v80                             // 000000488200: 169CA006
	v_mul_u32_u24_e32 v80, s7, v80                             // 000000488204: 16A0A007
	v_lshl_add_u32 v78, v80, 24, v78                           // 000000488208: D646004E 05393150
	v_mul_u32_u24_e32 v80, s6, v69                             // 000000488210: 16A08A06
	v_mul_u32_u24_e32 v69, s7, v69                             // 000000488214: 168A8A07
	v_sad_u8 v79, v79, 0, 0x6400                               // 000000488218: D622004F 03FD014F 00006400
	v_lshl_add_u32 v69, v69, 24, v80                           // 000000488224: D6460045 05413145
	v_mul_u32_u24_e32 v80, s6, v81                             // 00000048822C: 16A0A206
	v_sad_u8 v78, v78, 0, 0x6400                               // 000000488230: D622004E 03FD014E 00006400
	v_mul_u32_u24_e32 v81, s7, v81                             // 00000048823C: 16A2A207
	v_lshl_add_u32 v80, v81, 24, v80                           // 000000488240: D6460050 05413151
	v_sad_u8 v69, v69, 0, 0x6400                               // 000000488248: D6220045 03FD0145 00006400
	v_pk_fma_f16 v75, v75, s8, 0xc931 op_sel_hi:[1,0,0]        // 000000488254: CC0E004B 0BFC114B 0000C931
	v_and_b32_e32 v79, 0xffff, v79                             // 000000488260: 369E9EFF 0000FFFF
	v_mul_u32_u24_e32 v81, s6, v82                             // 000000488268: 16A2A406
	v_mul_u32_u24_e32 v82, s7, v82                             // 00000048826C: 16A4A407
	v_lshl_add_u32 v81, v82, 24, v81                           // 000000488270: D6460051 05453152
	v_dual_dot2acc_f32_f16 v27, v77, v16 :: v_dual_and_b32 v78, 0xffff, v78// 000000488278: CB24214D 1B4E9CFF 0000FFFF
	v_sad_u8 v80, v80, 0, 0x6400                               // 000000488284: D6220050 03FD0150 00006400
	v_dot2acc_f32_f16 v26, v75, v5                             // 000000488290: 04340B4B
	v_lshl_or_b32 v69, v69, 16, v79                            // 000000488294: D6560045 053D2145
	v_mul_u32_u24_e32 v82, s6, v59                             // 00000048829C: 16A47606
	v_mul_u32_u24_e32 v59, s7, v59                             // 0000004882A0: 16767607
	v_sad_u8 v81, v81, 0, 0x6400                               // 0000004882A4: D6220051 03FD0151 00006400
	v_lshl_add_u32 v59, v59, 24, v82                           // 0000004882B0: D646003B 0549313B
	v_lshl_or_b32 v78, v80, 16, v78                            // 0000004882B8: D656004E 05392150
	v_pk_fma_f16 v69, v69, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004882C0: CC0E0045 0BFC1145 0000C931
	v_dot2acc_f32_f16 v24, v75, v9                             // 0000004882CC: 0430134B
	v_dot2acc_f32_f16 v25, v75, v1                             // 0000004882D0: 0432034B
	v_and_b32_e32 v79, 0xffff, v81                             // 0000004882D4: 369EA2FF 0000FFFF
	v_sad_u8 v59, v59, 0, 0x6400                               // 0000004882DC: D622003B 03FD013B 00006400
	v_pk_fma_f16 v77, v78, s8, 0xc931 op_sel_hi:[1,0,0]        // 0000004882E8: CC0E004D 0BFC114E 0000C931
	v_dot2acc_f32_f16 v24, v69, v10                            // 0000004882F4: 04301545
	v_dual_dot2acc_f32_f16 v25, v69, v2 :: v_dual_dot2acc_f32_f16 v22, v75, v13// 0000004882F8: CB180545 19161B4B
	v_dot2acc_f32_f16 v26, v69, v6                             // 000000488300: 04340D45
	v_lshl_or_b32 v5, v59, 16, v79                             // 000000488304: D6560005 053D213B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000048830C: BF870214
	v_dot2acc_f32_f16 v24, v77, v11                            // 000000488310: 0430174D
	v_dot2acc_f32_f16 v25, v77, v3                             // 000000488314: 0432074D
	v_dot2acc_f32_f16 v22, v69, v14                            // 000000488318: 042C1D45
	v_dot2acc_f32_f16 v26, v77, v7                             // 00000048831C: 04340F4D
	v_pk_fma_f16 v1, v5, s8, 0xc931 op_sel_hi:[1,0,0]          // 000000488320: CC0E0001 0BFC1105 0000C931
	v_dual_mov_b32 v3, v76 :: v_dual_add_nc_u32 v2, v55, v17   // 00000048832C: CA20014C 03022337
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000488334: BF870194
	v_dual_dot2acc_f32_f16 v22, v77, v15 :: v_dual_mov_b32 v83, v71// 000000488338: CB101F4D 16520147
	v_dot2acc_f32_f16 v25, v1, v4                              // 000000488340: 04320901
	s_delay_alu instid0(VALU_DEP_3)                            // 000000488344: BF870003
	v_cmp_eq_u32_e32 vcc_lo, 1, v2                             // 000000488348: 7C940481
	v_dot2acc_f32_f16 v26, v1, v8                              // 00000048834C: 04341101
	v_dot2acc_f32_f16 v24, v1, v12                             // 000000488350: 04301901
	v_dot2acc_f32_f16 v22, v1, v16                             // 000000488354: 042C2101
	v_dual_mov_b32 v2, v65 :: v_dual_mov_b32 v77, v68          // 000000488358: CA100141 024C0144
	v_dual_mov_b32 v81, v61 :: v_dual_mov_b32 v82, v70         // 000000488360: CA10013D 51520146
	v_mov_b32_e32 v80, v70                                     // 000000488368: 7EA00346
	v_dual_mov_b32 v78, v60 :: v_dual_mov_b32 v69, v18         // 00000048836C: CA10013C 4E440112
	v_mov_b32_e32 v79, v68                                     // 000000488374: 7E9E0344
	v_mov_b32_e32 v75, v66                                     // 000000488378: 7E960342
	v_mov_b32_e32 v59, v66                                     // 00000048837C: 7E760342
	s_or_b32 s5, vcc_lo, s5                                    // 000000488380: 8C05056A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000488384: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000488388: 917E057E
	s_cbranch_execz 56                                         // 00000048838C: BFA50038 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1c70>
	s_mov_b32 s9, exec_lo                                      // 000000488390: BE89007E
	.long 0xd4c1007e                                           // 000000488394: D4C1007E
	v_cndmask_b32_e32 v1, v17, v23, vcc_lo                     // 000000488398: 02022F11
	s_cbranch_execz 64506                                      // 00000048839C: BFA5FBFA <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb88>
	v_ashrrev_i32_e32 v18, 31, v17                             // 0000004883A0: 3424229F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000004883A4: BF870091
	.long 0xd73c0004                                           // 0000004883A8: D73C0004
	v_cndmask_b32_e32 v1, 10, v17, vcc_lo                      // 0000004883AC: 0202228A
	.long 0xd7006a01                                           // 0000004883B0: D7006A01
	v_cndmask_b32_e32 v1, s1, v4, vcc_lo                       // 0000004883B4: 02020801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000004883B8: BF870111
	v_add_co_ci_u32_e64 v7, null, s4, v5, vcc_lo               // 0000004883BC: D5207C07 01AA0A04
	.long 0xd7006a04                                           // 0000004883C4: D7006A04
	v_cndmask_b32_e32 v1, v1, v58, vcc_lo                      // 0000004883C8: 02027501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004883CC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, 0, v7, vcc_lo                // 0000004883D0: D5207C05 01AA0E80
	.long 0xd7006a06                                           // 0000004883D8: D7006A06
	v_cndmask_b32_e32 v1, v1, v56, vcc_lo                      // 0000004883DC: 02027101
	v_add_co_ci_u32_e64 v7, null, 0, v7, vcc_lo                // 0000004883E0: D5207C07 01AA0E80
	s_clause 0xf                                               // 0000004883E8: BF85000F
	global_load_b32 v65, v[4:5], off                           // 0000004883EC: DC520000 417C0004
	global_load_b32 v67, v[4:5], off offset:128                // 0000004883F4: DC520080 437C0004
	global_load_b32 v64, v[4:5], off offset:256                // 0000004883FC: DC520100 407C0004
	global_load_b32 v63, v[4:5], off offset:384                // 000000488404: DC520180 3F7C0004
	global_load_b32 v62, v[4:5], off offset:512                // 00000048840C: DC520200 3E7C0004
	global_load_b32 v61, v[4:5], off offset:640                // 000000488414: DC520280 3D7C0004
	global_load_b32 v60, v[4:5], off offset:768                // 00000048841C: DC520300 3C7C0004
	global_load_b32 v18, v[4:5], off offset:896                // 000000488424: DC520380 127C0004
	global_load_b32 v76, v[6:7], off                           // 00000048842C: DC520000 4C7C0006
	global_load_b32 v74, v[6:7], off offset:128                // 000000488434: DC520080 4A7C0006
	global_load_b32 v73, v[6:7], off offset:256                // 00000048843C: DC520100 497C0006
	global_load_b32 v72, v[6:7], off offset:384                // 000000488444: DC520180 487C0006
	global_load_b32 v71, v[6:7], off offset:512                // 00000048844C: DC520200 477C0006
	global_load_b32 v70, v[6:7], off offset:640                // 000000488454: DC520280 467C0006
	global_load_b32 v68, v[6:7], off offset:768                // 00000048845C: DC520300 447C0006
	global_load_b32 v66, v[6:7], off offset:896                // 000000488464: DC520380 427C0006
	s_branch 64454                                             // 00000048846C: BFA0FBC6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb88>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000488470: 8C7E057E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000488474: BF870009
	s_or_b32 exec_lo, exec_lo, s0                              // 000000488478: 8C7E007E
	s_waitcnt vmcnt(23)                                        // 00000048847C: BF895FF7
	v_dual_mov_b32 v1, v54 :: v_dual_mov_b32 v2, v51           // 000000488480: CA100136 01020133
	s_waitcnt vmcnt(15)                                        // 000000488488: BF893FF7
	v_dual_mov_b32 v4, v50 :: v_dual_mov_b32 v3, v41           // 00000048848C: CA100132 04020129
	v_dual_mov_b32 v5, v47 :: v_dual_mov_b32 v8, v52           // 000000488494: CA10012F 05080134
	v_dual_mov_b32 v7, v53 :: v_dual_mov_b32 v10, v48          // 00000048849C: CA100135 070A0130
	v_dual_mov_b32 v9, v49 :: v_dual_mov_b32 v14, v43          // 0000004884A4: CA100131 090E012B
	v_dual_mov_b32 v6, v29 :: v_dual_mov_b32 v11, v46          // 0000004884AC: CA10011D 060A012E
	v_dual_mov_b32 v12, v45 :: v_dual_mov_b32 v13, v44         // 0000004884B4: CA10012D 0C0C012C
	v_dual_mov_b32 v15, v42 :: v_dual_mov_b32 v16, v40         // 0000004884BC: CA10012A 0F100128
	v_dual_mov_b32 v17, v39 :: v_dual_mov_b32 v18, v38         // 0000004884C4: CA100127 11120126
	v_dual_mov_b32 v23, v37 :: v_dual_mov_b32 v56, v35         // 0000004884CC: CA100125 17380123
	v_dual_mov_b32 v55, v36 :: v_dual_mov_b32 v58, v33         // 0000004884D4: CA100124 373A0121
	v_dual_mov_b32 v57, v34 :: v_dual_mov_b32 v60, v31         // 0000004884DC: CA100122 393C011F
	s_waitcnt vmcnt(0)                                         // 0000004884E4: BF8903F7
	v_dual_mov_b32 v59, v32 :: v_dual_mov_b32 v64, v26         // 0000004884E8: CA100120 3B40011A
	v_dual_mov_b32 v61, v30 :: v_dual_mov_b32 v62, v28         // 0000004884F0: CA10011E 3D3E011C
	v_dual_mov_b32 v63, v27 :: v_dual_mov_b32 v66, v24         // 0000004884F8: CA10011B 3F420118
	v_mov_b32_e32 v65, v25                                     // 000000488500: 7E820319
	v_mov_b32_e32 v67, v22                                     // 000000488504: 7E860316
	s_mov_b32 s0, 0x76543210                                   // 000000488508: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000488510: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 000000488514: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 000000488520: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000048852C: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 000000488538: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 000000488544: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 000000488550: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000048855C: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 000000488568: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 000000488574: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 000000488580: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000048858C: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 000000488598: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 0000004885A4: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 0000004885B0: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 0000004885BC: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 0000004885C8: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v17, v17, s0, 0xfedcba98                 // 0000004885D4: D65C0011 03FC0111 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 0000004885E0: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 0000004885EC: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v55, v55, s0, 0xfedcba98                 // 0000004885F8: D65C0037 03FC0137 FEDCBA98
	v_permlanex16_b32 v56, v56, s0, 0xfedcba98                 // 000000488604: D65C0038 03FC0138 FEDCBA98
	v_permlanex16_b32 v57, v57, s0, 0xfedcba98                 // 000000488610: D65C0039 03FC0139 FEDCBA98
	v_permlanex16_b32 v58, v58, s0, 0xfedcba98                 // 00000048861C: D65C003A 03FC013A FEDCBA98
	v_permlanex16_b32 v59, v59, s0, 0xfedcba98                 // 000000488628: D65C003B 03FC013B FEDCBA98
	v_permlanex16_b32 v60, v60, s0, 0xfedcba98                 // 000000488634: D65C003C 03FC013C FEDCBA98
	v_permlanex16_b32 v61, v61, s0, 0xfedcba98                 // 000000488640: D65C003D 03FC013D FEDCBA98
	v_permlanex16_b32 v62, v62, s0, 0xfedcba98                 // 00000048864C: D65C003E 03FC013E FEDCBA98
	v_permlanex16_b32 v63, v63, s0, 0xfedcba98                 // 000000488658: D65C003F 03FC013F FEDCBA98
	v_permlanex16_b32 v64, v64, s0, 0xfedcba98                 // 000000488664: D65C0040 03FC0140 FEDCBA98
	v_permlanex16_b32 v65, v65, s0, 0xfedcba98                 // 000000488670: D65C0041 03FC0141 FEDCBA98
	v_permlanex16_b32 v66, v66, s0, 0xfedcba98                 // 00000048867C: D65C0042 03FC0142 FEDCBA98
	v_permlanex16_b32 v67, v67, s0, 0xfedcba98                 // 000000488688: D65C0043 03FC0143 FEDCBA98
	.long 0xd44c0000                                           // 000000488694: D44C0000
	v_cndmask_b32_e32 v1, 16, v21, vcc_lo                      // 000000488698: 02022A90
	s_barrier                                                  // 00000048869C: BFBD0000
	buffer_gl0_inv                                             // 0000004886A0: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000004886A8: BE812000
	s_cbranch_execz 68                                         // 0000004886AC: BFA50044 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1fc0>
	v_lshl_or_b32 v20, v19, 11, v20                            // 0000004886B0: D6560014 04511713
	v_dual_add_f32 v5, v47, v5 :: v_dual_add_f32 v4, v50, v4   // 0000004886B8: C9080B2F 05040932
	v_dual_add_f32 v1, v54, v1 :: v_dual_add_f32 v2, v51, v2   // 0000004886C0: C9080336 01020533
	v_dual_add_f32 v8, v52, v8 :: v_dual_add_f32 v7, v53, v7   // 0000004886C8: C9081134 08060F35
	v_dual_add_f32 v21, v22, v67 :: v_dual_add_f32 v22, v24, v66// 0000004886D0: C9088716 15168518
	v_dual_add_f32 v24, v25, v65 :: v_dual_add_f32 v25, v26, v64// 0000004886D8: C9088319 1818811A
	v_dual_add_f32 v26, v27, v63 :: v_dual_add_f32 v27, v28, v62// 0000004886E0: C9087F1B 1A1A7D1C
	v_add_f32_e32 v28, v30, v61                                // 0000004886E8: 06387B1E
	v_dual_add_f32 v30, v31, v60 :: v_dual_add_f32 v31, v32, v59// 0000004886EC: C908791F 1E1E7720
	v_dual_add_f32 v32, v33, v58 :: v_dual_add_f32 v33, v34, v57// 0000004886F4: C9087521 20207322
	v_dual_add_f32 v34, v35, v56 :: v_dual_add_f32 v23, v37, v23// 0000004886FC: C9087123 22162F25
	v_dual_add_f32 v35, v36, v55 :: v_dual_add_nc_u32 v36, 0x400, v20// 000000488704: C9206F24 232428FF 00000400
	v_dual_add_f32 v3, v41, v3 :: v_dual_add_f32 v10, v48, v10 // 000000488710: C9080729 030A1530
	v_dual_add_f32 v9, v49, v9 :: v_dual_add_f32 v14, v43, v14 // 000000488718: C9081331 090E1D2B
	v_dual_add_f32 v13, v44, v13 :: v_dual_add_f32 v6, v29, v6 // 000000488720: C9081B2C 0D060D1D
	v_dual_add_f32 v18, v38, v18 :: v_dual_add_f32 v17, v39, v17// 000000488728: C9082526 12102327
	v_dual_add_f32 v16, v40, v16 :: v_dual_add_f32 v15, v42, v15// 000000488730: C9082128 100E1F2A
	v_dual_add_f32 v12, v45, v12 :: v_dual_add_f32 v11, v46, v11// 000000488738: C908192D 0C0A172E
	ds_store_2addr_b32 v20, v1, v5 offset1:16                  // 000000488740: D8381000 00050114
	ds_store_2addr_b32 v20, v2, v7 offset0:128 offset1:144     // 000000488748: D8389080 00070214
	ds_store_2addr_b32 v36, v4, v8 offset1:16                  // 000000488750: D8381000 00080424
	ds_store_2addr_b32 v36, v3, v9 offset0:128 offset1:144     // 000000488758: D8389080 00090324
	ds_store_2addr_b32 v20, v6, v13 offset0:32 offset1:48      // 000000488760: D8383020 000D0614
	ds_store_2addr_b32 v20, v10, v14 offset0:160 offset1:176   // 000000488768: D838B0A0 000E0A14
	ds_store_2addr_b32 v36, v11, v15 offset0:32 offset1:48     // 000000488770: D8383020 000F0B24
	ds_store_2addr_b32 v36, v12, v16 offset0:160 offset1:176   // 000000488778: D838B0A0 00100C24
	ds_store_2addr_b32 v20, v17, v34 offset0:64 offset1:80     // 000000488780: D8385040 00221114
	ds_store_2addr_b32 v20, v18, v33 offset0:192 offset1:208   // 000000488788: D838D0C0 00211214
	ds_store_2addr_b32 v36, v23, v32 offset0:64 offset1:80     // 000000488790: D8385040 00201724
	ds_store_2addr_b32 v36, v35, v31 offset0:192 offset1:208   // 000000488798: D838D0C0 001F2324
	ds_store_2addr_b32 v20, v30, v25 offset0:96 offset1:112    // 0000004887A0: D8387060 00191E14
	ds_store_2addr_b32 v20, v28, v24 offset0:224 offset1:240   // 0000004887A8: D838F0E0 00181C14
	ds_store_2addr_b32 v36, v27, v22 offset0:96 offset1:112    // 0000004887B0: D8387060 00161B24
	ds_store_2addr_b32 v36, v26, v21 offset0:224 offset1:240   // 0000004887B8: D838F0E0 00151A24
	s_or_b32 exec_lo, exec_lo, s1                              // 0000004887C0: 8C7E017E
	.long 0xd44c0001                                           // 0000004887C4: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000004887C8: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 0000004887D0: BF89FC07
	s_barrier                                                  // 0000004887D4: BFBD0000
	buffer_gl0_inv                                             // 0000004887D8: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 0000004887E0: BE842001
	s_cbranch_execz 41                                         // 0000004887E4: BFA50029 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x208c>
	v_mov_b32_e32 v1, v0                                       // 0000004887E8: 7E020300
	s_mov_b32 s5, 0                                            // 0000004887EC: BE850080
	s_nop 0                                                    // 0000004887F0: BF800000
	s_nop 0                                                    // 0000004887F4: BF800000
	s_nop 0                                                    // 0000004887F8: BF800000
	s_nop 0                                                    // 0000004887FC: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488800: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 000000488804: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 000000488808: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 000000488810: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 000000488818: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 000000488820: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 000000488828: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000048882C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 000000488830: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000488834: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 000000488838: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000048883C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 000000488844: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 000000488848: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000048884C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 000000488850: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000488854: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 000000488858: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000048885C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 000000488860: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000488864: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 000000488868: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000048886C: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 000000488874: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000048887C: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000488884: 917E057E
	s_cbranch_execnz 65501                                     // 000000488888: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2000>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000048888C: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 000000488890: BF048221
	s_mov_b32 s4, -1                                           // 000000488894: BE8400C1
	s_cbranch_scc1 212                                         // 000000488898: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23ec>
	s_waitcnt lgkmcnt(0)                                       // 00000048889C: BF89FC07
	s_barrier                                                  // 0000004888A0: BFBD0000
	buffer_gl0_inv                                             // 0000004888A4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 0000004888AC: BE862001
	s_cbranch_execz 71                                         // 0000004888B0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x21d0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 0000004888B4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 0000004888B8: 860B9F0A
	s_ashr_i32 s19, s18, 31                                    // 0000004888BC: 86139F12
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000004888C0: 8484820A
	s_mov_b32 s7, 0                                            // 0000004888C4: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 0000004888C8: 38020204
	s_mul_i32 s4, s5, s18                                      // 0000004888CC: 96041205
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000004888D0: BF8700A1
	.long 0xd72c0003                                           // 0000004888D4: D72C0003
	v_cndmask_b32_e32 v0, v1, v19, vcc_lo                      // 0000004888D8: 02002701
	v_mad_u64_u32 v[1:2], null, v1, s18, 0                     // 0000004888DC: D6FE7C01 02002501
	v_add3_u32 v2, v2, v3, s4                                  // 0000004888E4: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 0000004888EC: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 0000004888F0: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 0000004888F8: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004888FC: BF870122
	.long 0xd73c0001                                           // 000000488900: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000488904: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000488908: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000048890C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 000000488910: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000488914: BF870093
	.long 0xd7006a01                                           // 000000488918: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000048891C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 000000488920: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[18:19], 3                             // 000000488928: 84848312
	.long 0xd7006a01                                           // 00000048892C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 000000488930: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000488934: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000488938: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 000000488940: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 000000488948: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 00000048894C: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488950: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000488954: D5207C02 01AA0419
	s_nop 0                                                    // 00000048895C: BF800000
	s_nop 0                                                    // 000000488960: BF800000
	s_nop 0                                                    // 000000488964: BF800000
	s_nop 0                                                    // 000000488968: BF800000
	s_nop 0                                                    // 00000048896C: BF800000
	s_nop 0                                                    // 000000488970: BF800000
	s_nop 0                                                    // 000000488974: BF800000
	s_nop 0                                                    // 000000488978: BF800000
	s_nop 0                                                    // 00000048897C: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 000000488980: D8D84000 05000003
	.long 0xd7000804                                           // 000000488988: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000048898C: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 000000488994: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000488998: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 0000004889A0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000004889A4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 0000004889A8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 0000004889AC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000004889B0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 0000004889B8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 0000004889BC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 0000004889C0: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000004889C8: 917E077E
	s_cbranch_execnz 65516                                     // 0000004889CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000004889D0: 8C7E067E
	.long 0xd44a0004                                           // 0000004889D4: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 0000004889D8: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 0000004889DC: BC7C0000
	buffer_gl1_inv                                             // 0000004889E0: E0B00000 00000000
	buffer_gl0_inv                                             // 0000004889E8: E0AC0000 00000000
	s_barrier                                                  // 0000004889F0: BFBD0000
	buffer_gl0_inv                                             // 0000004889F4: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 0000004889FC: BE852004
	s_cbranch_execz 29                                         // 000000488A00: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2278>
	s_mov_b32 s7, exec_lo                                      // 000000488A04: BE87007E
	s_mov_b32 s6, exec_lo                                      // 000000488A08: BE86007E
	.long 0xd71f0001                                           // 000000488A0C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 000000488A10: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488A14: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 000000488A18: 7D940280
	s_cbranch_execz 9                                          // 000000488A1C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2244>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 000000488A20: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000488A24: BF8704B9
	s_add_u32 s8, s26, s8                                      // 000000488A28: 8008081A
	s_addc_u32 s9, s27, s9                                     // 000000488A2C: 8209091B
	s_bcnt1_i32_b32 s7, s7                                     // 000000488A30: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 000000488A34: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 000000488A3C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 000000488A44: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 000000488A48: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 000000488A4C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488A50: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 000000488A54: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 000000488A5C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000488A60: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 000000488A64: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 000000488A68: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 000000488A70: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 000000488A78: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 000000488A7C: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 000000488A80: BF89FC07
	s_barrier                                                  // 000000488A84: BFBD0000
	buffer_gl0_inv                                             // 000000488A88: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 000000488A90: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 000000488A98: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 000000488A9C: 7C940280
	s_cbranch_vccnz 467                                        // 000000488AA0: BFA401D3 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29f0>
	buffer_gl1_inv                                             // 000000488AA4: E0B00000 00000000
	buffer_gl0_inv                                             // 000000488AAC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 000000488AB4: BE852001
	s_cbranch_execz 65                                         // 000000488AB8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23c0>
	v_lshrrev_b32_e32 v1, 7, v0                                // 000000488ABC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 000000488AC0: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 000000488AC4: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 000000488ACC: 86079F06
	v_mov_b32_e32 v5, v0                                       // 000000488AD0: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s18, 0                     // 000000488AD4: D6FF7C01 02002501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 000000488ADC: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 000000488AE0: 30060682
	s_ashr_i32 s19, s18, 31                                    // 000000488AE4: 86139F12
	s_mov_b32 s10, 0                                           // 000000488AE8: BE8A0080
	s_lshl_b64 s[8:9], s[18:19], 4                             // 000000488AEC: 84888412
	.long 0xd73c0001                                           // 000000488AF0: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000488AF4: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000488AF8: BF870091
	.long 0xd7006a01                                           // 000000488AFC: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000488B00: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 000000488B04: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[18:19], 3                             // 000000488B0C: 84868312
	.long 0xd7006a01                                           // 000000488B10: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000488B14: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000488B18: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000488B1C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 000000488B24: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000488B28: 02020218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488B2C: BF870001
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000488B30: D5207C02 01AA0419
	s_nop 0                                                    // 000000488B38: BF800000
	s_nop 0                                                    // 000000488B3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488B40: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 000000488B44: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 000000488B4C: 7E0C0280
	s_mov_b32 s1, s33                                          // 000000488B50: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 000000488B54: DC524000 077C0003
	.long 0xd7006a03                                           // 000000488B5C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 000000488B60: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000488B64: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000488B68: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 000000488B70: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 000000488B74: BF068001
	s_waitcnt vmcnt(0)                                         // 000000488B78: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 000000488B7C: 060C0F06
	s_cbranch_scc0 65524                                       // 000000488B80: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2354>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 000000488B84: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 000000488B8C: 7C920AFF 000000FF
	.long 0xd7000101                                           // 000000488B94: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 000000488B98: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 000000488B9C: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 000000488BA0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 000000488BA8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 000000488BAC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 000000488BB0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000488BB8: 917E0A7E
	s_cbranch_execnz 65504                                     // 000000488BBC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2340>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000488BC0: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 000000488BC4: BE812004
	s_cbranch_execz 6                                          // 000000488BC8: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23e4>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000488BCC: 84848202
	v_mov_b32_e32 v1, 0                                        // 000000488BD0: 7E020280
	s_add_u32 s4, s26, s4                                      // 000000488BD4: 8004041A
	s_addc_u32 s5, s27, s5                                     // 000000488BD8: 8205051B
	global_store_b32 v1, v1, s[4:5]                            // 000000488BDC: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 000000488BE4: 8C7E017E
	s_mov_b32 s4, -1                                           // 000000488BE8: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000488BEC: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000488BF0: 8B6A047E
	s_cbranch_vccz 382                                         // 000000488BF4: BFA3017E <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29f0>
	v_cmp_gt_i32_e32 vcc_lo, s16, v19                          // 000000488BF8: 7C882610
	.long 0xd44c0001                                           // 000000488BFC: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000488C00: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 000000488C08: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000488C0C: BC7C0000
	s_barrier                                                  // 000000488C10: BFBD0000
	buffer_gl0_inv                                             // 000000488C14: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 000000488C1C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000488C20: BF870009
	s_and_saveexec_b32 s3, s1                                  // 000000488C24: BE832001
	s_cbranch_execz 369                                        // 000000488C28: BFA50171 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29f0>
	v_and_b32_e32 v1, 15, v0                                   // 000000488C2C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000488C30: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 000000488C34: 30040282
	v_lshl_or_b32 v2, v19, 9, v2                               // 000000488C38: D6560002 04091313
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488C40: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 000000488C44: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 000000488C4C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 000000488C54: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 000000488C5C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 000000488C64: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 000000488C6C: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 000000488C70: 36160082
	s_waitcnt lgkmcnt(3)                                       // 000000488C74: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 000000488C78: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 000000488C80: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 000000488C84: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 000000488C8C: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 000000488C90: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 000000488C98: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 000000488C9C: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 000000488CA4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 000000488CAC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000488CB0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 000000488CB4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 000000488CBC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 000000488CC4: 7C941480
	.long 0xd44a0001                                           // 000000488CC8: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 000000488CCC: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 000000488CD0: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 000000488CD8: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 000000488CDC: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 000000488CE0: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 000000488CE4: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 000000488CE8: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 000000488CF0: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 000000488CF4: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 000000488CF8: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488CFC: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000488D04: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D0C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000488D14: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D1C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000488D24: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D2C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000488D34: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D3C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000488D44: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D4C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000488D54: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D5C: 7E2402FA FF016103
	v_cndmask_b32_e64 v20, -v3, v3, vcc_lo                     // 000000488D64: D5010014 21AA0703
	v_cndmask_b32_e64 v22, -v2, v2, vcc_lo                     // 000000488D6C: D5010016 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 000000488D74: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 000000488D78: C9080D07 03082108
	v_mov_b32_dpp v21, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000488D80: 7E2A02FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 000000488D88: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000488D90: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488D94: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000488D9C: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 000000488DA4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488DA8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 000000488DB0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488DB8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 000000488DC0: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488DC4: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000488DCC: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 000000488DD4: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 000000488DD8: D5010008 21AA1108
	v_add_f32_e32 v13, v22, v21                                // 000000488DE0: 061A2B16
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488DE4: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 000000488DEC: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488DF0: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 000000488DF8: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 000000488E00: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 000000488E08: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488E0C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 000000488E14: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 000000488E1C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488E20: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 000000488E28: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 000000488E30: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488E34: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 000000488E3C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 000000488E44: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 000000488E48: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 000000488E4C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488E54: 7E0402FA FF016402
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 000000488E5C: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000488E64: BF870242
	v_add_f32_e32 v7, v7, v2                                   // 000000488E68: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488E6C: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 000000488E74: D5010004 20060904
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488E7C: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488E84: 7E0A02FA FF016807
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000488E8C: BF8700A3
	v_add_f32_e32 v4, v4, v10                                  // 000000488E90: 06081504
	v_add_f32_e32 v10, v20, v18                                // 000000488E94: 06142514
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000488E98: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 000000488EA0: D501000A 21AA150A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000488EA8: BF870241
	v_add_f32_e32 v10, v10, v12                                // 000000488EAC: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 000000488EB0: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488EB4: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 000000488EBC: D5010009 20061309
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488EC4: 7E1E02FA FF01640A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000488ECC: BF870254
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488ED0: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 000000488ED8: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 000000488EE0: D501000C 2006190C
	v_add_f32_e32 v6, v6, v11                                  // 000000488EE8: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000488EEC: 7E1602FA FF016408
	v_dual_add_f32 v16, v9, v13 :: v_dual_add_f32 v15, v10, v15// 000000488EF4: C9081B09 100E1F0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000488EFC: BF870214
	v_add_f32_e32 v17, v12, v17                                // 000000488F00: 0622230C
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F04: 7E1002FA FF016806
	s_delay_alu instid0(VALU_DEP_4)                            // 000000488F0C: BF870004
	v_add_f32_e32 v14, v14, v11                                // 000000488F10: 061C170E
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F14: 7E1202FA FF016804
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F1C: 7E1602FA FF016810
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F24: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F2C: 7E1A02FA FF016811
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000488F34: 7E1402FA FF01680E
	s_and_b32 exec_lo, exec_lo, s0                             // 000000488F3C: 8B7E007E
	s_cbranch_execz 171                                        // 000000488F40: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi4ELi4ELb0ELb1ELb1ELb0EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x29f0>
	v_lshl_or_b32 v20, s2, 7, v1                               // 000000488F44: D6560014 04050E02
	.long 0x7f243880                                           // 000000488F4C: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000488F50: BF870112
	v_ashrrev_i32_e32 v21, 31, v20                             // 000000488F54: 342A289F
	.long 0x7f303992                                           // 000000488F58: 7F303992
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000488F5C: BF870092
	.long 0xd73c0014                                           // 000000488F60: D73C0014
	v_cndmask_b32_e32 v1, 1, v20, vcc_lo                       // 000000488F64: 02022881
	.long 0xd7006a16                                           // 000000488F68: D7006A16
	v_cndmask_b32_e32 v1, s22, v20, vcc_lo                     // 000000488F6C: 02022816
	s_delay_alu instid0(VALU_DEP_1)                            // 000000488F70: BF870001
	v_add_co_ci_u32_e64 v23, null, s23, v21, vcc_lo            // 000000488F74: D5207C17 01AA2A17
	s_clause 0x7                                               // 000000488F7C: BF850007
	global_load_d16_b16 v18, v[22:23], off offset:32           // 000000488F80: DC820020 127C0016
	global_load_d16_b16 v24, v[22:23], off                     // 000000488F88: DC820000 187C0016
	global_load_d16_b16 v25, v[22:23], off offset:64           // 000000488F90: DC820040 197C0016
	global_load_d16_b16 v26, v[22:23], off offset:96           // 000000488F98: DC820060 1A7C0016
	global_load_d16_b16 v27, v[22:23], off offset:128          // 000000488FA0: DC820080 1B7C0016
	global_load_d16_b16 v28, v[22:23], off offset:160          // 000000488FA8: DC8200A0 1C7C0016
	global_load_d16_b16 v29, v[22:23], off offset:192          // 000000488FB0: DC8200C0 1D7C0016
	global_load_d16_b16 v22, v[22:23], off offset:224          // 000000488FB8: DC8200E0 167C0016
	v_and_b32_e32 v23, 8, v0                                   // 000000488FC0: 362E0088
	v_mad_i64_i32 v[0:1], null, s18, v19, 0                    // 000000488FC4: D6FF7C00 02022612
	s_waitcnt vmcnt(7)                                         // 000000488FCC: BF891FF7
	.long 0x7f263992                                           // 000000488FD0: 7F263992
	s_waitcnt vmcnt(0)                                         // 000000488FD4: BF8903F7
	.long 0x7f2c3992                                           // 000000488FD8: 7F2C3992
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 000000488FDC: 7C942E80
	.long 0x7f2e3992                                           // 000000488FE0: 7F2E3992
	.long 0xd73c0000                                           // 000000488FE4: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000488FE8: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 000000488FEC: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 000000488FF4: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 000000488FFC: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 000000489004: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000048900C: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 000000489014: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 000000489018: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 000000489020: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 000000489028: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000489030: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 000000489034: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 000000489040: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 000000489048: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000489054: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 000000489058: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 000000489060: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000489068: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000048906C: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 000000489078: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 000000489084: D7006A00
	v_cndmask_b32_e32 v1, s28, v0, vcc_lo                      // 000000489088: 0202001C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000048908C: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 000000489090: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s29, v1, vcc_lo              // 000000489098: D5207C01 01AA021D
	.long 0xd7006a00                                           // 0000004890A0: D7006A00
	v_cndmask_b32_e32 v1, v0, v20, vcc_lo                      // 0000004890A4: 02022900
	s_delay_alu instid0(VALU_DEP_1)                            // 0000004890A8: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v21, vcc_lo              // 0000004890AC: D5207C01 01AA2B01
	v_fma_mix_f32 v3, v18, v3, neg(0) op_sel_hi:[1,0,0]        // 0000004890B4: CC200003 8A020712
	v_fma_mix_f32 v2, v24, v2, neg(0) op_sel_hi:[1,0,0]        // 0000004890BC: CC200002 8A020518
	v_fma_mix_f32 v5, v25, v5, neg(0) op_sel_hi:[1,0,0]        // 0000004890C4: CC200005 8A020B19
	v_fma_mix_f32 v4, v26, v4, neg(0) op_sel_hi:[1,0,0]        // 0000004890CC: CC200004 8A02091A
	v_fma_mix_f32 v6, v27, v6, neg(0) op_sel_hi:[1,0,0]        // 0000004890D4: CC200006 8A020D1B
	.long 0x7e243983                                           // 0000004890DC: 7E243983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 0000004890E0: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v28, v7, neg(0) op_sel_hi:[1,0,0]        // 0000004890E8: CC200007 8A020F1C
	v_fma_mix_f32 v8, v29, v8, neg(0) op_sel_hi:[1,0,0]        // 0000004890F0: CC200008 8A02111D
	.long 0x7e263982                                           // 0000004890F8: 7E263982
	v_and_b32_e32 v10, 1, v18                                  // 0000004890FC: 36142481
	.long 0x7e243984                                           // 000000489100: 7E243984
	v_fma_mix_f32 v9, v22, v9, neg(0) op_sel_hi:[1,0,0]        // 000000489104: CC200009 8A021316
	.long 0x7e2c3985                                           // 00000048910C: 7E2C3985
	.long 0x7e2e3986                                           // 000000489110: 7E2E3986
	.long 0x7e303988                                           // 000000489114: 7E303988
	v_and_b32_e32 v11, 1, v18                                  // 000000489118: 36162481
	.long 0x7e243987                                           // 00000048911C: 7E243987
	v_and_b32_e32 v12, 1, v19                                  // 000000489120: 36182681
	v_and_b32_e32 v13, 1, v22                                  // 000000489124: 361A2C81
	v_and_b32_e32 v14, 1, v23                                  // 000000489128: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000048912C: 36203081
	v_and_b32_e32 v15, 1, v18                                  // 000000489130: 361E2481
	.long 0x7e243989                                           // 000000489134: 7E243989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 000000489138: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 000000489144: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 000000489150: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000048915C: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v18                                  // 000000489168: 36142481
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000048916C: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 000000489178: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 000000489184: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000489190: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000489194: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 0000004891A0: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000004891A4: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 0000004891AC: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 0000004891B4: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 0000004891BC: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 0000004891C4: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 0000004891CC: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 0000004891D4: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 0000004891DC: DC9600E0 007C0900
	s_nop 0                                                    // 0000004891E4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004891E8: BFB60003
	s_endpgm                                                   // 0000004891EC: BFB00000
	s_nop 0                                                    // 0000004891F0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000004891F4: BFB60003
	s_endpgm                                                   // 0000004891F8: BFB00000
	v_illegal                                                  // 0000004891FC: 00000000

