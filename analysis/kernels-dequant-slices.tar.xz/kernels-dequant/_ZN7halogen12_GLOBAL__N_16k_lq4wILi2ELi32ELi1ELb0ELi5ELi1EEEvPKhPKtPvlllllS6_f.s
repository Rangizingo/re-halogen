00000000008ba200 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000008BA200: F4100200 F8000000
	v_and_b32_e32 v1, 15, v0                                   // 0000008BA208: 3602008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000008BA20C: 32040082
	s_ashr_i32 s3, s2, 31                                      // 0000008BA210: 86039F02
	v_lshrrev_b32_e32 v3, 5, v0                                // 0000008BA214: 32060085
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000008BA218: 84828302
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BA21C: 30020282
	v_dual_mov_b32 v17, s3 :: v_dual_and_b32 v2, 60, v2        // 0000008BA220: CA240003 110204BC
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BA228: BF870003
	v_or_b32_e32 v16, s2, v3                                   // 0000008BA22C: 38200602
	.long 0x7f063880                                           // 0000008BA230: 7F063880
	v_and_b32_e32 v23, 31, v0                                  // 0000008BA234: 362E009F
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000008BA238: 30000082
	s_waitcnt lgkmcnt(0)                                       // 0000008BA23C: BF89FC07
	s_clause 0x1                                               // 0000008BA240: BF850001
	global_load_b32 v1, v1, s[8:9]                             // 0000008BA244: DC520000 01080001
	global_load_b32 v2, v2, s[8:9]                             // 0000008BA24C: DC520000 02080002
	.long 0xd4540002                                           // 0000008BA254: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000008BA258: 02022010
	s_add_u32 s24, s8, s20                                     // 0000008BA25C: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000008BA260: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000008BA264: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BA268: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000008BA26C: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000008BA270: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000008BA278: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000008BA280: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000008BA284: 8205800F
	.long 0xd72c0004                                           // 0000008BA288: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000008BA28C: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000008BA290: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000008BA298: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BA29C: BF870009
	s_cmpk_lt_i32 s6, 0x101                                    // 0000008BA2A0: B3860101
	.long 0xd4440004                                           // 0000008BA2A4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BA2A8: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000008BA2AC: 980380C1
	s_cmpk_gt_i32 s6, 0x100                                    // 0000008BA2B0: B2860100
	.long 0xd700050e                                           // 0000008BA2B4: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000008BA2B8: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000008BA2BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BA2C0: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000008BA2C4: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000008BA2C8: BF8907F7
	v_bfe_u32 v5, v1, 16, 1                                    // 0000008BA2CC: D6100005 02052101
	s_waitcnt vmcnt(0)                                         // 0000008BA2D4: BF8903F7
	v_bfe_u32 v6, v2, 16, 1                                    // 0000008BA2D8: D6100006 02052102
	v_add3_u32 v1, v1, v5, 0x7fff                              // 0000008BA2E0: D6550001 03FE0B01 00007FFF
	.long 0xd72c0005                                           // 0000008BA2EC: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000008BA2F0: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BA2F4: BF870193
	v_add3_u32 v2, v2, v6, 0x7fff                              // 0000008BA2F8: D6550002 03FE0D02 00007FFF
	.long 0x7e063981                                           // 0000008BA304: 7E063981
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BA308: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000008BA30C: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v2, v3                        // 0000008BA314: D6570001 040E04FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BA320: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000008BA324: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000008BA32C: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000008BA334: BF89FC07
	s_barrier                                                  // 0000008BA338: BFBD0000
	buffer_gl0_inv                                             // 0000008BA33C: E0AC0000 00000000
	s_cbranch_vccnz 146                                        // 0000008BA344: BFA40092 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x390>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000008BA348: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000008BA350: BE852004
	s_cbranch_execz 10                                         // 0000008BA354: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x180>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000008BA358: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA35C: BF870091
	.long 0xd7006a02                                           // 0000008BA360: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000008BA364: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000008BA368: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000008BA370: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000008BA378: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000008BA37C: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BA380: 8C7E057E
	v_or_b32_e32 v2, 32, v23                                   // 0000008BA384: 38042EA0
	s_mov_b32 s4, exec_lo                                      // 0000008BA388: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA38C: BF870001
	.long 0xd4c4007e                                           // 0000008BA390: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000008BA394: 02020406
	s_cbranch_execz 10                                         // 0000008BA398: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x1c4>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000008BA39C: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA3A0: BF870091
	.long 0xd7006a01                                           // 0000008BA3A4: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000008BA3A8: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000008BA3AC: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000008BA3B4: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000008BA3BC: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000008BA3C0: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA3C4: 8C7E047E
	v_or_b32_e32 v4, 64, v23                                   // 0000008BA3C8: 38082EC0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000008BA3CC: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000008BA3D4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BA3D8: BF870002
	.long 0xd4c4007e                                           // 0000008BA3DC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008BA3E0: 02020806
	s_cbranch_execz 10                                         // 0000008BA3E4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x210>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000008BA3E8: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA3EC: BF870091
	.long 0xd7006a04                                           // 0000008BA3F0: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000008BA3F4: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000008BA3F8: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000008BA400: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000008BA408: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000008BA40C: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA410: 8C7E047E
	v_or_b32_e32 v4, 0x60, v23                                 // 0000008BA414: 38082EFF 00000060
	s_mov_b32 s4, exec_lo                                      // 0000008BA41C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA420: BF870001
	.long 0xd4c4007e                                           // 0000008BA424: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000008BA428: 02020806
	s_cbranch_execz 10                                         // 0000008BA42C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x258>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000008BA430: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA434: BF870091
	.long 0xd7006a03                                           // 0000008BA438: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000008BA43C: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000008BA440: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000008BA448: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000008BA450: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000008BA454: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA458: 8C7E047E
	v_or_b32_e32 v6, 0x80, v23                                 // 0000008BA45C: 380C2EFF 00000080
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000008BA464: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000008BA46C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BA470: BF870002
	.long 0xd4c4007e                                           // 0000008BA474: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008BA478: 02020C06
	s_cbranch_execz 10                                         // 0000008BA47C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2a8>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000008BA480: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA484: BF870091
	.long 0xd7006a06                                           // 0000008BA488: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000008BA48C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000008BA490: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000008BA498: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000008BA4A0: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000008BA4A4: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA4A8: 8C7E047E
	v_or_b32_e32 v6, 0xa0, v23                                 // 0000008BA4AC: 380C2EFF 000000A0
	s_mov_b32 s4, exec_lo                                      // 0000008BA4B4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA4B8: BF870001
	.long 0xd4c4007e                                           // 0000008BA4BC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000008BA4C0: 02020C06
	s_cbranch_execz 10                                         // 0000008BA4C4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x2f0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000008BA4C8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA4CC: BF870091
	.long 0xd7006a05                                           // 0000008BA4D0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000008BA4D4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000008BA4D8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000008BA4E0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000008BA4E8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000008BA4EC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA4F0: 8C7E047E
	v_or_b32_e32 v10, 0xc0, v23                                // 0000008BA4F4: 38142EFF 000000C0
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000008BA4FC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000008BA504: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BA508: BF870002
	.long 0xd4c4007e                                           // 0000008BA50C: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008BA510: 02021406
	s_cbranch_execz 10                                         // 0000008BA514: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x340>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000008BA518: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA51C: BF870091
	.long 0xd7006a0a                                           // 0000008BA520: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000008BA524: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008BA528: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000008BA530: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000008BA538: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000008BA53C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA540: 8C7E047E
	v_or_b32_e32 v10, 0xe0, v23                                // 0000008BA544: 38142EFF 000000E0
	s_mov_b32 s4, exec_lo                                      // 0000008BA54C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA550: BF870001
	.long 0xd4c4007e                                           // 0000008BA554: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000008BA558: 02021406
	s_cbranch_execz 10                                         // 0000008BA55C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x388>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000008BA560: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA564: BF870091
	.long 0xd7006a0a                                           // 0000008BA568: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000008BA56C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000008BA570: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000008BA578: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000008BA580: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000008BA584: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000008BA588: 8C7E047E
	s_branch 9                                                 // 0000008BA58C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_mov_b32_e32 v0, 0                                        // 0000008BA590: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA594: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000008BA598: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000008BA59C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000008BA5A0: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000008BA5A4: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000008BA5A8: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000008BA5AC: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000008BA5B0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000008BA5B4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000008BA5B8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000008BA5BC: 85129F0F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000008BA5C0: D5010018 001D0280
	s_add_u32 s18, s14, s18                                    // 0000008BA5C8: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000008BA5CC: 8213800F
	v_dual_mov_b32 v27, 0 :: v_dual_mov_b32 v10, 0             // 0000008BA5D0: CA100080 1B0A0080
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000008BA5D8: 86928112
	v_mov_b32_e32 v25, 0                                       // 0000008BA5DC: 7E320280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000008BA5E0: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000008BA5E8: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000008BA5EC: 02002708
	.long 0xd72c0014                                           // 0000008BA5F0: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000008BA5F4: 02002509
	.long 0xd4440004                                           // 0000008BA5F8: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000008BA5FC: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000008BA600: CA100080 08080080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BA608: BF870003
	v_add3_u32 v26, v20, v19, v11                              // 0000008BA60C: D655001A 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000008BA614: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000008BA618: BE852004
	s_cbranch_execz 21                                         // 0000008BA61C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000008BA620: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA628: BF870091
	.long 0xd7006a08                                           // 0000008BA62C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000008BA630: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v26, vcc_lo               // 0000008BA634: D5207C09 01AA3480
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000008BA63C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000008BA640: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000008BA648: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x474>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000008BA64C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BA650: BF870091
	.long 0xd7006a0e                                           // 0000008BA654: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000008BA658: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000008BA65C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000008BA664: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000008BA66C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000008BA670: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BA674: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 0000008BA678: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 0000008BA67C: BE852004
	s_cbranch_execz 307                                        // 0000008BA680: BFA50133 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x950>
	.long 0xd7006a0c                                           // 0000008BA684: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000008BA688: 02021814
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000008BA68C: CA220080 14122E85
	v_lshlrev_b32_e32 v14, 1, v23                              // 0000008BA694: 301C2E81
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000008BA698: D5207C0D 01AA1A15
	v_lshl_or_b32 v29, v23, 4, 0x200                           // 0000008BA6A0: D656001D 03FD0917 00000200
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008BA6AC: BF870214
	v_mov_b32_e32 v25, v20                                     // 0000008BA6B0: 7E320314
	.long 0xd7006a0c                                           // 0000008BA6B4: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000008BA6B8: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BA6BC: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000008BA6C0: D5207C0D 01AA1A80
	v_mov_b32_e32 v30, v23                                     // 0000008BA6C8: 7E3C0317
	.long 0xd7006a0c                                           // 0000008BA6CC: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000008BA6D0: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BA6D4: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000008BA6D8: D5207C0D 01AA1A09
	v_dual_mov_b32 v28, v20 :: v_dual_mov_b32 v31, v27         // 0000008BA6E0: CA100114 1C1E011B
	.long 0xd7006a15                                           // 0000008BA6E8: D7006A15
	v_cndmask_b32_e32 v0, v12, v192, vcc_lo                    // 0000008BA6EC: 0201810C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA6F0: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000008BA6F4: D5207C16 01AA1A80
	s_mov_b32 s7, 0                                            // 0000008BA6FC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000008BA700: 8488810E
	s_branch 245                                               // 0000008BA704: BFA000F5 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x8dc>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000008BA708: 8C7E0E7E
	.long 0xd73c0020                                           // 0000008BA70C: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000008BA710: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 0000008BA714: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 0000008BA71C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 0000008BA720: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000008BA724: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 0000008BA728: 368612FF 000000FF
	.long 0xd7006a38                                           // 0000008BA730: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 0000008BA734: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000008BA738: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 0000008BA73C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000008BA744: 30808082
	.long 0xd7006a3c                                           // 0000008BA748: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 0000008BA74C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BA750: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 0000008BA754: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000008BA75C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 0000008BA764: D8D80000 40000040
	s_clause 0x7                                               // 0000008BA76C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 0000008BA770: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 0000008BA778: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 0000008BA780: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 0000008BA788: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000008BA790: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 0000008BA798: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000008BA7A0: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000008BA7A8: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000008BA7B0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000008BA7B8: 32881286
	ds_load_b32 v65, v65                                       // 0000008BA7BC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000008BA7C4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000008BA7C8: 32121296
	ds_load_b32 v66, v66                                       // 0000008BA7CC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000008BA7D4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000008BA7DC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000008BA7E0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000008BA7E8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000008BA7F0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000008BA7F8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000008BA800: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000008BA808: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 0000008BA810: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 0000008BA818: D8D80000 09000009
	.long 0xd7006a15                                           // 0000008BA820: D7006A15
	v_cndmask_b32_e32 v0, v21, v192, vcc_lo                    // 0000008BA824: 02018115
	v_add_nc_u32_e32 v29, 0x200, v29                           // 0000008BA828: 4A3A3AFF 00000200
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000008BA830: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000008BA838: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000008BA83C: BF870009
	s_or_b32 s7, s4, s7                                        // 0000008BA840: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000008BA844: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 0000008BA848: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 0000008BA850: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 0000008BA854: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 0000008BA85C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000008BA864: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 0000008BA868: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BA870: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 0000008BA874: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 0000008BA87C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 0000008BA880: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000008BA884: 32141496
	s_waitcnt lgkmcnt(5)                                       // 0000008BA888: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 0000008BA88C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 0000008BA894: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 0000008BA89C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000008BA8A4: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000008BA8A8: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000008BA8AC: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000008BA8B0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000008BA8B8: CC1A4008 1C861127
	v_lshlrev_b32_e32 v33, 2, v64                              // 0000008BA8C0: 30428082
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000008BA8C4: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000008BA8CC: 36484AFF 000003FC
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008BA8D4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000008BA8D8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000008BA8E0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000008BA8E4: CC1A4008 1C22872C
	ds_load_b32 v33, v33                                       // 0000008BA8EC: D8D80000 21000021
	ds_load_b32 v35, v35                                       // 0000008BA8F4: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 0000008BA8FC: D8D80000 24000024
	s_waitcnt lgkmcnt(5)                                       // 0000008BA904: BF89FC57
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000008BA908: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000008BA910: CC1A4008 1C22892D
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000008BA918: 32161696
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000008BA91C: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000008BA924: 30444482
	s_waitcnt lgkmcnt(4)                                       // 0000008BA928: BF89FC47
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 0000008BA92C: CC1A4020 1C828B2A
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 0000008BA934: CC1A4008 1C228B2E
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000008BA93C: 364A4CFF 000003FC
	v_and_b32_e32 v38, 0x3fc, v65                              // 0000008BA944: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000008BA94C: 361616FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000008BA954: BF89FC37
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 0000008BA958: CC1A4020 1C82132B
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000008BA960: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 0000008BA968: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 0000008BA970: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 0000008BA978: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 0000008BA980: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 0000008BA988: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 0000008BA990: D5010025 000E0D05
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 0000008BA998: D501002A 000E011B
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 0000008BA9A0: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 0000008BA9A8: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 0000008BA9B0: BF890C77
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000008BA9B4: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000008BA9BC: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000008BA9C0: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 0000008BA9C8: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 0000008BA9D0: D5010020 000E0300
	v_mov_b32_e32 v27, v31                                     // 0000008BA9D8: 7E36031F
	s_waitcnt lgkmcnt(6)                                       // 0000008BA9DC: BF89FC67
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000008BA9E0: CC1A400B 1C2E4731
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000008BA9E8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 0000008BA9F0: D5010023 000E0903
	s_waitcnt lgkmcnt(5)                                       // 0000008BA9F8: BF89FC57
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BA9FC: BF870193
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000008BAA00: CC1A400B 1C2E4932
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000008BAA08: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 0000008BAA10: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 0000008BAA18: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BAA1C: BF870193
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 0000008BAA20: CC1A400B 1C2E1333
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 0000008BAA28: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 0000008BAA30: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000008BAA34: BF890437
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BAA38: BF870003
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 0000008BAA3C: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 0000008BAA44: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 0000008BAA48: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000008BAA50: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 0000008BAA58: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000008BAA5C: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 0000008BAA60: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 0000008BAA68: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 0000008BAA70: 7E4E0307
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000008BAA74: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000008BAA7C: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 0000008BAA80: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 0000008BAA88: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 0000008BAA90: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BAA94: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 0000008BAA98: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 0000008BAAA0: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BAAA8: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000008BAAAC: 5638012A
	v_dual_fmac_f32 v25, v42, v1 :: v_dual_mov_b32 v0, v32     // 0000008BAAB0: C810032A 19000120
	v_dual_mov_b32 v1, v33 :: v_dual_mov_b32 v2, v34           // 0000008BAAB8: CA100121 01020122
	v_dual_mov_b32 v3, v35 :: v_dual_mov_b32 v4, v36           // 0000008BAAC0: CA100123 03040124
	v_dual_mov_b32 v5, v37 :: v_dual_mov_b32 v6, v38           // 0000008BAAC8: CA100125 05060126
	v_mov_b32_e32 v7, v39                                      // 0000008BAAD0: 7E0E0327
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000008BAAD4: 917E077E
	s_cbranch_execz 28                                         // 0000008BAAD8: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x94c>
	s_waitcnt vmcnt(0)                                         // 0000008BAADC: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 32, v30   // 0000008BAAE0: CA200109 0D1E3CA0
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000008BAAE8: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000008BAAF0: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000008BAAF4: BF870003
	.long 0xd4430004                                           // 0000008BAAF8: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008BAAFC: 02023C06
	s_mov_b32 s14, exec_lo                                     // 0000008BAB00: BE8E007E
	.long 0xd4c4007e                                           // 0000008BAB04: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000008BAB08: 02023C06
	s_cbranch_execz 65278                                      // 0000008BAB0C: BFA5FEFE <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	.long 0xd7006a0c                                           // 0000008BAB10: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000008BAB14: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BAB18: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v26, vcc_lo              // 0000008BAB1C: D5207C0D 01AA3480
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000008BAB24: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 0000008BAB28: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000008BAB2C: DC5E0000 0C7C000C
	s_cbranch_vccnz 65268                                      // 0000008BAB34: BFA4FEF4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	global_load_d16_b16 v31, v[21:22], off                     // 0000008BAB38: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000008BAB40: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000008BAB44: 7E3E171F
	s_branch 65263                                             // 0000008BAB48: BFA0FEEF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0x508>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000008BAB4C: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008BAB50: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000008BAB54: 8C7E057E
	.long 0xd71f0000                                           // 0000008BAB58: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000008BAB5C: 020100C1
	v_xor_b32_e32 v1, 16, v0                                   // 0000008BAB60: 3A020090
	v_xor_b32_e32 v3, 8, v0                                    // 0000008BAB64: 3A060088
	v_xor_b32_e32 v5, 4, v0                                    // 0000008BAB68: 3A0A0084
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000008BAB6C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000008BAB70: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000008BAB74: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000008BAB78: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BAB7C: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000008BAB80: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000008BAB84: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008BAB88: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 0000008BAB8C: DACC0000 02001C01
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000008BAB94: 30060682
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000008BAB98: 020A0B00
	s_waitcnt lgkmcnt(0)                                       // 0000008BAB9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000008BABA0: BF870001
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v5, 2, v5 // 0000008BABA4: C922051C 02040A82
	ds_bpermute_b32 v1, v1, v25                                // 0000008BABAC: DACC0000 01001901
	ds_bpermute_b32 v4, v3, v2                                 // 0000008BABB4: DACC0000 04000203
	s_waitcnt lgkmcnt(0)                                       // 0000008BABBC: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_add_f32 v1, v25, v1    // 0000008BABC0: C9080902 02000319
	ds_bpermute_b32 v3, v3, v1                                 // 0000008BABC8: DACC0000 03000103
	s_waitcnt lgkmcnt(0)                                       // 0000008BABD0: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000008BABD4: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BABD8: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008BABE0: DACC0000 04000105
	v_xor_b32_e32 v5, 2, v0                                    // 0000008BABE8: 3A0A0082
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000008BABEC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008BABF0: 7C980AA0
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000008BABF4: 020A0B00
	s_waitcnt lgkmcnt(1)                                       // 0000008BABF8: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v5  // 0000008BABFC: C9220702 02040A82
	s_waitcnt lgkmcnt(0)                                       // 0000008BAC04: BF89FC07
	v_add_f32_e32 v1, v1, v4                                   // 0000008BAC08: 06020901
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BAC0C: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000008BAC14: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000008BAC1C: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000008BAC20: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000008BAC24: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000008BAC28: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000008BAC2C: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000008BAC30: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000008BAC34: C9220702 02040082
	s_and_b32 s2, vcc_lo, s2                                   // 0000008BAC3C: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000008BAC40: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000008BAC44: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000008BAC48: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000008BAC50: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000008BAC58: BE832002
	s_cbranch_execz 72                                         // 0000008BAC5C: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi1ELb0ELi5ELi1EEEvPKhPKtPvlllllS6_f+0xb80>
	v_ashrrev_i32_e32 v4, 31, v17                              // 0000008BAC60: 3408229F
	s_load_b64 s[2:3], s[0:1], 0x40                            // 0000008BAC64: F4040080 F8000040
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000008BAC6C: BF890007
	v_dual_mov_b32 v6, s13 :: v_dual_add_f32 v9, v0, v1        // 0000008BAC70: CA08000D 06080300
	.long 0x7f143880                                           // 0000008BAC78: 7F143880
	v_lshrrev_b32_e32 v4, 23, v4                               // 0000008BAC7C: 32080897
	s_lshr_b32 s0, s17, 31                                     // 0000008BAC80: 85009F11
	v_mov_b32_e32 v7, s12                                      // 0000008BAC84: 7E0E020C
	.long 0x7e143989                                           // 0000008BAC88: 7E143989
	v_add_f32_e32 v8, v2, v3                                   // 0000008BAC8C: 06100702
	.long 0xd7006a04                                           // 0000008BAC90: D7006A04
	v_cndmask_b32_e32 v1, v16, v4, vcc_lo                      // 0000008BAC94: 02020910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000008BAC98: BF870151
	v_add_co_ci_u32_e64 v5, null, 0, v17, vcc_lo               // 0000008BAC9C: D5207C05 01AA2280
	s_add_u32 s1, s16, s0                                      // 0000008BACA4: 80010010
	v_and_b32_e32 v4, 0xfffffe00, v4                           // 0000008BACA8: 360808FF FFFFFE00
	.long 0x7f16398a                                           // 0000008BACB0: 7F16398A
	s_addc_u32 s4, s17, 0                                      // 0000008BACB4: 82048011
	.long 0xd7016a02                                           // 0000008BACB8: D7016A02
	v_cndmask_b32_e32 v1, v16, v4, vcc_lo                      // 0000008BACBC: 02020910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000008BACC0: BF870111
	v_sub_co_ci_u32_e64 v3, null, v17, v5, vcc_lo              // 0000008BACC4: D5217C03 01AA0B11
	.long 0xd7000000                                           // 0000008BACCC: D7000000
	v_cndmask_b32_e32 v1, 0xffffff00, v2, vcc_lo               // 0000008BACD0: 020204FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 0000008BACD8: BF870002
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[2:3]                     // 0000008BACDC: 7CA804FF 00000100
	v_add_co_ci_u32_e64 v1, null, -1, v3, s0                   // 0000008BACE4: D5207C01 000206C1
	s_and_b32 s0, s1, -2                                       // 0000008BACEC: 8B00C201
	v_dual_cndmask_b32 v6, s3, v6 :: v_dual_cndmask_b32 v1, v1, v3// 0000008BACF0: CA520C03 06000701
	v_and_b32_e32 v3, 1, v10                                   // 0000008BACF8: 36061481
	.long 0x7e163988                                           // 0000008BACFC: 7E163988
	v_cndmask_b32_e32 v0, v0, v2, vcc_lo                       // 0000008BAD00: 02000500
	v_cndmask_b32_e32 v2, s2, v7, vcc_lo                       // 0000008BAD04: 02040E02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000008BAD08: BF870193
	v_and_b32_e32 v7, 1, v11                                   // 0000008BAD0C: 360E1681
	.long 0xd73c0000                                           // 0000008BAD10: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 0000008BAD14: 02020081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BAD18: BF870093
	.long 0xd7006a02                                           // 0000008BAD1C: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 0000008BAD20: 02020902
	v_add_co_ci_u32_e64 v4, null, v6, v5, vcc_lo               // 0000008BAD24: D5207C04 01AA0B06
	v_add3_u32 v5, v9, v3, 0x7fff                              // 0000008BAD2C: D6550005 03FE0709 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BAD38: BF870093
	.long 0xd7006a00                                           // 0000008BAD3C: D7006A00
	v_cndmask_b32_e32 v1, v2, v0, vcc_lo                       // 0000008BAD40: 02020102
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000008BAD44: D5207C01 01AA0304
	v_add3_u32 v4, v8, v7, 0x7fff                              // 0000008BAD4C: D6550004 03FE0F08 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000008BAD58: BF870093
	.long 0xd7006a02                                           // 0000008BAD5C: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000008BAD60: 02000100
	v_add_co_ci_u32_e64 v3, null, s4, v1, vcc_lo               // 0000008BAD64: D5207C03 01AA0204
	s_clause 0x1                                               // 0000008BAD6C: BF850001
	global_store_d16_hi_b16 v[0:1], v4, off                    // 0000008BAD70: DC960000 007C0400
	global_store_d16_hi_b16 v[2:3], v5, off                    // 0000008BAD78: DC960000 007C0502
	s_endpgm                                                   // 0000008BAD80: BFB00000
		...

