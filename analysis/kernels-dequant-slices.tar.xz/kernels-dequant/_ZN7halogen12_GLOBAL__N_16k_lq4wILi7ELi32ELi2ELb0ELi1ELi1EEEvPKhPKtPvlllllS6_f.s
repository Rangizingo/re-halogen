00000000007e2a00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 0000007E2A00: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007E2A08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007E2A0C: 32040082
	s_lshl_b64 s[20:21], s[2:3], 2                             // 0000007E2A10: 84948202
	v_and_b32_e32 v1, 15, v0                                   // 0000007E2A14: 3602008F
	v_lshrrev_b32_e32 v28, 6, v0                               // 0000007E2A18: 32380086
	v_bfe_u32 v29, v0, 5, 1                                    // 0000007E2A1C: D610001D 02050B00
	v_and_b32_e32 v2, 60, v2                                   // 0000007E2A24: 360404BC
	v_and_b32_e32 v30, 31, v0                                  // 0000007E2A28: 363C009F
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007E2A2C: 30020282
	.long 0x7f0a3880                                           // 0000007E2A30: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000007E2A34: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007E2A38: BF89FC07
	s_clause 0x1                                               // 0000007E2A3C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 0000007E2A40: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 0000007E2A48: DC520000 04040002
	s_add_u32 s2, s4, s16                                      // 0000007E2A50: 80021004
	s_addc_u32 s3, s5, s17                                     // 0000007E2A54: 82031105
	s_ashr_i32 s16, s11, 31                                    // 0000007E2A58: 86109F0B
	v_mov_b32_e32 v2, s21                                      // 0000007E2A5C: 7E040215
	s_lshr_b32 s16, s16, 27                                    // 0000007E2A60: 85109B10
	v_or_b32_e32 v1, s20, v28                                  // 0000007E2A64: 38023814
	s_add_u32 s16, s10, s16                                    // 0000007E2A68: 8010100A
	s_addc_u32 s17, s11, 0                                     // 0000007E2A6C: 8211800B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E2A70: BF870099
	s_lshr_b64 s[16:17], s[16:17], 5                           // 0000007E2A74: 85908510
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007E2A78: 7CA8020C
	s_add_i32 s17, s16, 1                                      // 0000007E2A7C: 81118110
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000007E2A80: BF870499
	s_lshr_b32 s22, s17, 31                                    // 0000007E2A84: 85169F11
	s_add_i32 s17, s17, s22                                    // 0000007E2A88: 81111611
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000007E2A8C: 02020280
	s_ashr_i32 s17, s17, 1                                     // 0000007E2A90: 86118111
	v_cndmask_b32_e64 v2, 0, s21, vcc_lo                       // 0000007E2A94: D5010002 01A82A80
	.long 0xd72c0007                                           // 0000007E2A9C: D72C0007
	v_cndmask_b32_e32 v1, s17, v29, vcc_lo                     // 0000007E2AA0: 02023A11
	s_cmpk_lt_i32 s16, 0x201                                   // 0000007E2AA4: B3900201
	.long 0xd72c0009                                           // 0000007E2AA8: D72C0009
	v_cndmask_b32_e32 v1, s19, v1, vcc_lo                      // 0000007E2AAC: 02020213
	v_mad_u64_u32 v[24:25], null, s18, v1, s[2:3]              // 0000007E2AB0: D6FE7C18 000A0212
	s_cselect_b32 s2, -1, 0                                    // 0000007E2AB8: 980280C1
	s_cmpk_gt_i32 s16, 0x200                                   // 0000007E2ABC: B2900200
	v_add_nc_u32_e32 v11, s17, v7                              // 0000007E2AC0: 4A160E11
	v_add_nc_u32_e32 v31, v7, v30                              // 0000007E2AC4: 4A3E3D07
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000007E2AC8: BF8704A2
	v_min_i32_e32 v32, s16, v11                                // 0000007E2ACC: 22401610
	s_cselect_b32 s16, -1, 0                                   // 0000007E2AD0: 981080C1
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000007E2AD4: 8B6A107E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007E2AD8: BF870151
	.long 0xd4410003                                           // 0000007E2ADC: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007E2AE0: 0202411F
	s_waitcnt vmcnt(1)                                         // 0000007E2AE4: BF8907F7
	v_bfe_u32 v8, v3, 16, 1                                    // 0000007E2AE8: D6100008 02052103
	s_waitcnt vmcnt(0)                                         // 0000007E2AF0: BF8903F7
	v_bfe_u32 v10, v4, 16, 1                                   // 0000007E2AF4: D610000A 02052104
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000007E2AFC: D6550003 03FE1103 00007FFF
	.long 0xd72c0008                                           // 0000007E2B08: D72C0008
	v_cndmask_b32_e32 v1, s18, v2, vcc_lo                      // 0000007E2B0C: 02020412
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E2B10: BF870193
	v_add3_u32 v4, v4, v10, 0x7fff                             // 0000007E2B14: D6550004 03FE1504 00007FFF
	.long 0x7e0a3983                                           // 0000007E2B20: 7E0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E2B24: BF870113
	v_add3_u32 v33, v9, v25, v8                                // 0000007E2B28: D6550021 04223309
	v_and_or_b32 v3, 0xffff0000, v4, v5                        // 0000007E2B30: D6570003 041608FF FFFF0000
	ds_store_b32 v6, v3                                        // 0000007E2B3C: D8340000 00000306
	s_waitcnt lgkmcnt(0)                                       // 0000007E2B44: BF89FC07
	s_barrier                                                  // 0000007E2B48: BFBD0000
	buffer_gl0_inv                                             // 0000007E2B4C: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007E2B54: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3c0>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 0000007E2B58: CA100080 09080080
	s_and_saveexec_b32 s17, s3                                 // 0000007E2B60: BE912003
	s_cbranch_execz 11                                         // 0000007E2B64: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x194>
	v_lshlrev_b32_e32 v3, 1, v31                               // 0000007E2B68: 30063E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2B6C: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2B70: 3408069F
	.long 0xd7006a03                                           // 0000007E2B74: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2B78: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2B7C: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2B84: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2B8C: BF8903F7
	v_cvt_f32_f16_e32 v8, v3                                   // 0000007E2B90: 7E101703
	s_or_b32 exec_lo, exec_lo, s17                             // 0000007E2B94: 8C7E117E
	v_add_nc_u32_e32 v3, 32, v31                               // 0000007E2B98: 4A063EA0
	s_mov_b32 s3, exec_lo                                      // 0000007E2B9C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E2BA0: BF870001
	.long 0xd4c1007e                                           // 0000007E2BA4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2BA8: 02024103
	s_cbranch_execz 11                                         // 0000007E2BAC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2BB0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2BB4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2BB8: 3408069F
	.long 0xd7006a03                                           // 0000007E2BBC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2BC0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2BC4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2BCC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2BD4: BF8903F7
	v_cvt_f32_f16_e32 v9, v3                                   // 0000007E2BD8: 7E121703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2BDC: 8C7E037E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v3, 64, v31     // 0000007E2BE0: CA200080 0A023EC0
	v_mov_b32_e32 v11, 0                                       // 0000007E2BE8: 7E160280
	s_mov_b32 s3, exec_lo                                      // 0000007E2BEC: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E2BF0: BF870002
	.long 0xd4c1007e                                           // 0000007E2BF4: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2BF8: 02024103
	s_cbranch_execz 11                                         // 0000007E2BFC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x22c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2C00: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2C04: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2C08: 3408069F
	.long 0xd7006a03                                           // 0000007E2C0C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2C10: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2C14: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2C1C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2C24: BF8903F7
	v_cvt_f32_f16_e32 v10, v3                                  // 0000007E2C28: 7E141703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2C2C: 8C7E037E
	v_add_nc_u32_e32 v3, 0x60, v31                             // 0000007E2C30: 4A063EFF 00000060
	s_mov_b32 s3, exec_lo                                      // 0000007E2C38: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E2C3C: BF870001
	.long 0xd4c1007e                                           // 0000007E2C40: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2C44: 02024103
	s_cbranch_execz 11                                         // 0000007E2C48: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x278>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2C4C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2C50: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2C54: 3408069F
	.long 0xd7006a03                                           // 0000007E2C58: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2C5C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2C60: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2C68: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2C70: BF8903F7
	v_cvt_f32_f16_e32 v11, v3                                  // 0000007E2C74: 7E161703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2C78: 8C7E037E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0x80, v31   // 0000007E2C7C: CA200080 0C023EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 0000007E2C88: 7E1A0280
	s_mov_b32 s3, exec_lo                                      // 0000007E2C8C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E2C90: BF870002
	.long 0xd4c1007e                                           // 0000007E2C94: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2C98: 02024103
	s_cbranch_execz 11                                         // 0000007E2C9C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2cc>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2CA0: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2CA4: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2CA8: 3408069F
	.long 0xd7006a03                                           // 0000007E2CAC: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2CB0: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2CB4: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2CBC: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2CC4: BF8903F7
	v_cvt_f32_f16_e32 v12, v3                                  // 0000007E2CC8: 7E181703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2CCC: 8C7E037E
	v_add_nc_u32_e32 v3, 0xa0, v31                             // 0000007E2CD0: 4A063EFF 000000A0
	s_mov_b32 s3, exec_lo                                      // 0000007E2CD8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E2CDC: BF870001
	.long 0xd4c1007e                                           // 0000007E2CE0: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2CE4: 02024103
	s_cbranch_execz 11                                         // 0000007E2CE8: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x318>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2CEC: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2CF0: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2CF4: 3408069F
	.long 0xd7006a03                                           // 0000007E2CF8: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2CFC: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2D00: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2D08: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2D10: BF8903F7
	v_cvt_f32_f16_e32 v13, v3                                  // 0000007E2D14: 7E1A1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2D18: 8C7E037E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v3, 0xc0, v31   // 0000007E2D1C: CA200080 0E023EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 0000007E2D28: 7E1E0280
	s_mov_b32 s3, exec_lo                                      // 0000007E2D2C: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E2D30: BF870002
	.long 0xd4c1007e                                           // 0000007E2D34: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2D38: 02024103
	s_cbranch_execz 11                                         // 0000007E2D3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x36c>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2D40: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2D44: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2D48: 3408069F
	.long 0xd7006a03                                           // 0000007E2D4C: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2D50: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2D54: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2D5C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2D64: BF8903F7
	v_cvt_f32_f16_e32 v14, v3                                  // 0000007E2D68: 7E1C1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2D6C: 8C7E037E
	v_add_nc_u32_e32 v3, 0xe0, v31                             // 0000007E2D70: 4A063EFF 000000E0
	s_mov_b32 s3, exec_lo                                      // 0000007E2D78: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E2D7C: BF870001
	.long 0xd4c1007e                                           // 0000007E2D80: D4C1007E
	v_cndmask_b32_e32 v1, v3, v32, vcc_lo                      // 0000007E2D84: 02024103
	s_cbranch_execz 11                                         // 0000007E2D88: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b8>
	v_lshlrev_b32_e32 v3, 1, v3                                // 0000007E2D8C: 30060681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2D90: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v3                               // 0000007E2D94: 3408069F
	.long 0xd7006a03                                           // 0000007E2D98: D7006A03
	v_cndmask_b32_e32 v1, v24, v3, vcc_lo                      // 0000007E2D9C: 02020718
	v_add_co_ci_u32_e64 v4, null, v33, v4, vcc_lo              // 0000007E2DA0: D5207C04 01AA0921
	global_load_d16_b16 v3, v[3:4], off                        // 0000007E2DA8: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007E2DB0: BF8903F7
	v_cvt_f32_f16_e32 v15, v3                                  // 0000007E2DB4: 7E1E1703
	s_or_b32 exec_lo, exec_lo, s3                              // 0000007E2DB8: 8C7E037E
	s_branch 9                                                 // 0000007E2DBC: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3e4>
	v_mov_b32_e32 v8, 0                                        // 0000007E2DC0: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E2DC4: BF870001
	v_mov_b32_e32 v9, v8                                       // 0000007E2DC8: 7E120308
	v_mov_b32_e32 v10, v8                                      // 0000007E2DCC: 7E140308
	v_mov_b32_e32 v11, v8                                      // 0000007E2DD0: 7E160308
	v_mov_b32_e32 v12, v8                                      // 0000007E2DD4: 7E180308
	v_mov_b32_e32 v13, v8                                      // 0000007E2DD8: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 0000007E2DDC: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 0000007E2DE0: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 0000007E2DE4: 80040E04
	s_addc_u32 s5, s5, s15                                     // 0000007E2DE8: 82050F05
	s_lshr_b32 s3, s11, 31                                     // 0000007E2DEC: 85039F0B
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v27, 0             // 0000007E2DF0: CA100080 141A0080
	s_add_u32 s14, s10, s3                                     // 0000007E2DF8: 800E030A
	s_addc_u32 s15, s11, 0                                     // 0000007E2DFC: 820F800B
	.long 0xd4410003                                           // 0000007E2E00: D4410003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007E2E04: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007E2E08: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v21, 0             // 0000007E2E0C: CA100080 22140080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 0000007E2E14: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 0000007E2E1C: D72C0001
	v_cndmask_b32_e32 v0, v1, v15, vcc_lo                      // 0000007E2E20: 02001F01
	.long 0xd72c0002                                           // 0000007E2E24: D72C0002
	v_cndmask_b32_e32 v0, v2, v14, vcc_lo                      // 0000007E2E28: 02001D02
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 0000007E2E2C: D5010023 00410280
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 0000007E2E34: CA100080 16160080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E2E3C: BF870003
	v_add3_u32 v36, v2, v26, v1                                // 0000007E2E40: D6550024 04063502
	s_and_saveexec_b32 s4, s3                                  // 0000007E2E48: BE842003
	s_cbranch_execz 22                                         // 0000007E2E4C: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 4, v31                               // 0000007E2E50: 30023E84
	v_mov_b32_e32 v27, 0                                       // 0000007E2E54: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E2E58: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000007E2E5C: 3404029F
	.long 0xd7006a01                                           // 0000007E2E60: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 0000007E2E64: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007E2E68: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 0000007E2E70: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 0000007E2E74: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 0000007E2E7C: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a8>
	v_lshlrev_b32_e32 v1, 1, v31                               // 0000007E2E80: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E2E84: BF870091
	.long 0xd7006a01                                           // 0000007E2E88: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000007E2E8C: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 0000007E2E90: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 0000007E2E98: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007E2EA0: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 0000007E2EA4: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007E2EA8: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 0000007E2EAC: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 0000007E2EB4: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v37, 0             // 0000007E2EBC: CA100080 2A240080
	s_and_saveexec_b32 s14, s3                                 // 0000007E2EC4: BE8E2003
	s_cbranch_execz 610                                        // 0000007E2EC8: BFA50262 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xe54>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 0000007E2ECC: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 0000007E2ED4: CA220080 251A3E85
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v38, 0             // 0000007E2EDC: CA100080 27260080
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E2EE4: BF870003
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v43, 4, v1     // 0000007E2EE8: CA220080 282A0284
	v_dual_mov_b32 v41, 0 :: v_dual_lshlrev_b32 v44, 1, v1     // 0000007E2EF0: CA220080 292C0281
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, v27           // 0000007E2EF8: CA100080 222C011B
	s_mul_i32 s3, s11, 6                                       // 0000007E2F00: 9603860B
	s_mul_hi_u32 s15, s10, 6                                   // 0000007E2F04: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 0000007E2F08: 8484820A
	s_add_i32 s15, s15, s3                                     // 0000007E2F0C: 810F030F
	s_mul_i32 s17, s10, 6                                      // 0000007E2F10: 9611860A
	s_mov_b32 s16, 0                                           // 0000007E2F14: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 0000007E2F18: 848A810A
	s_branch 553                                               // 0000007E2F1C: BFA00229 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xdc4>
	s_or_b32 exec_lo, exec_lo, s18                             // 0000007E2F20: 8C7E127E
	v_cndmask_b32_e64 v56, v27, v8, s2                         // 0000007E2F24: D5010038 000A111B
	v_cndmask_b32_e64 v2, v9, v10, s2                          // 0000007E2F2C: D5010002 000A1509
	v_cndmask_b32_e64 v1, v8, v9, s2                           // 0000007E2F34: D5010001 000A1308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 0000007E2F3C: CA24010F 080828FF 000000FF
	v_cndmask_b32_e64 v7, v14, v15, s2                         // 0000007E2F48: D5010007 000A1F0E
	v_cndmask_b32_e64 v6, v13, v14, s2                         // 0000007E2F50: D5010006 000A1D0D
	v_cndmask_b32_e64 v5, v12, v13, s2                         // 0000007E2F58: D5010005 000A1B0C
	v_cndmask_b32_e64 v4, v11, v12, s2                         // 0000007E2F60: D5010004 000A190B
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007E2F68: 30121282
	v_cndmask_b32_e64 v3, v10, v11, s2                         // 0000007E2F6C: D5010003 000A170A
	v_ashrrev_i32_e32 v27, 31, v26                             // 0000007E2F74: 3436349F
	s_and_b32 s3, exec_lo, s3                                  // 0000007E2F78: 8B03037E
	v_add_nc_u32_e32 v43, 0x200, v43                           // 0000007E2F7C: 4A5656FF 00000200
	ds_load_b32 v15, v9                                        // 0000007E2F84: D8D80000 0F000009
	v_lshrrev_b32_e32 v9, 6, v20                               // 0000007E2F8C: 32122886
	s_or_b32 s16, s3, s16                                      // 0000007E2F90: 8C101003
	v_add_nc_u32_e32 v44, 64, v44                              // 0000007E2F94: 4A5858C0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E2F98: BF8700B2
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E2F9C: 361212FF 000003FC
	ds_load_b32 v57, v9                                        // 0000007E2FA4: D8D80000 39000009
	v_lshrrev_b32_e32 v9, 14, v20                              // 0000007E2FAC: 3212288E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E2FB0: 361212FF 000003FC
	ds_load_b32 v58, v9                                        // 0000007E2FB8: D8D80000 3A000009
	v_lshrrev_b32_e32 v9, 22, v20                              // 0000007E2FC0: 32122896
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E2FC4: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E2FC8: 361212FF 000003FC
	ds_load_b32 v59, v9                                        // 0000007E2FD0: D8D80000 3B000009
	v_and_b32_e32 v9, 0xff, v21                                // 0000007E2FD8: 36122AFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007E2FE0: 30121282
	ds_load_b32 v60, v9                                        // 0000007E2FE4: D8D80000 3C000009
	v_lshrrev_b32_e32 v9, 6, v21                               // 0000007E2FEC: 32122A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E2FF0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E2FF4: 361212FF 000003FC
	ds_load_b32 v61, v9                                        // 0000007E2FFC: D8D80000 3D000009
	v_lshrrev_b32_e32 v9, 14, v21                              // 0000007E3004: 32122A8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E3008: 361212FF 000003FC
	ds_load_b32 v62, v9                                        // 0000007E3010: D8D80000 3E000009
	v_lshrrev_b32_e32 v9, 22, v21                              // 0000007E3018: 32122A96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E301C: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E3020: 361212FF 000003FC
	ds_load_b32 v63, v9                                        // 0000007E3028: D8D80000 3F000009
	v_and_b32_e32 v9, 0xff, v22                                // 0000007E3030: 36122CFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007E3038: 30121282
	ds_load_b32 v64, v9                                        // 0000007E303C: D8D80000 40000009
	v_lshrrev_b32_e32 v9, 6, v22                               // 0000007E3044: 32122C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3048: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E304C: 361212FF 000003FC
	ds_load_b32 v65, v9                                        // 0000007E3054: D8D80000 41000009
	v_lshrrev_b32_e32 v9, 14, v22                              // 0000007E305C: 32122C8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E3060: 361212FF 000003FC
	ds_load_b32 v66, v9                                        // 0000007E3068: D8D80000 42000009
	v_lshrrev_b32_e32 v9, 22, v22                              // 0000007E3070: 32122C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3074: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E3078: 361212FF 000003FC
	ds_load_b32 v67, v9                                        // 0000007E3080: D8D80000 43000009
	v_and_b32_e32 v9, 0xff, v23                                // 0000007E3088: 36122EFF 000000FF
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007E3090: 30121282
	ds_load_b32 v68, v9                                        // 0000007E3094: D8D80000 44000009
	v_lshrrev_b32_e32 v9, 6, v23                               // 0000007E309C: 32122E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E30A0: BF8700B1
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E30A4: 361212FF 000003FC
	ds_load_b32 v69, v9                                        // 0000007E30AC: D8D80000 45000009
	v_lshrrev_b32_e32 v9, 14, v23                              // 0000007E30B4: 32122E8E
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E30B8: 361212FF 000003FC
	ds_load_b32 v70, v9                                        // 0000007E30C0: D8D80000 46000009
	v_lshrrev_b32_e32 v9, 22, v23                              // 0000007E30C8: 32122E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007E30CC: BF870141
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007E30D0: 361212FF 000003FC
	ds_load_b32 v71, v9                                        // 0000007E30D8: D8D80000 47000009
	.long 0xd73c0009                                           // 0000007E30E0: D73C0009
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 0000007E30E4: 02023481
	v_dual_mov_b32 v27, v45 :: v_dual_add_nc_u32 v26, 0x400, v26// 0000007E30E8: CA20012D 1B1A34FF 00000400
	.long 0xd7006a0d                                           // 0000007E30F4: D7006A0D
	v_cndmask_b32_e32 v1, s6, v9, vcc_lo                       // 0000007E30F8: 02021206
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E30FC: BF870001
	v_add_co_ci_u32_e64 v14, null, s7, v10, vcc_lo             // 0000007E3100: D5207C0E 01AA1407
	s_clause 0x3                                               // 0000007E3108: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007E310C: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007E3114: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000007E311C: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000007E3124: DC5E0030 327C000D
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 0000007E312C: BF890CF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3130: CC1A4009 1A021F09
	s_waitcnt lgkmcnt(14)                                      // 0000007E3138: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E313C: BF8700A1
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E3140: CC1A4009 1C26730A
	s_waitcnt lgkmcnt(13)                                      // 0000007E3148: BF89FCD7
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E314C: CC1A4009 1C26750B
	s_waitcnt lgkmcnt(12)                                      // 0000007E3154: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3158: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E315C: CC1A4009 1C26770C
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 0000007E3164: BF8908B7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3168: CC1A4009 1C267914
	s_waitcnt lgkmcnt(10)                                      // 0000007E3170: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3174: BF8700A1
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3178: CC1A4009 1C267B15
	s_waitcnt lgkmcnt(9)                                       // 0000007E3180: BF89FC97
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3184: CC1A4009 1C267D16
	s_waitcnt lgkmcnt(8)                                       // 0000007E318C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3190: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E3194: CC1A4009 1C267F17
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 0000007E319C: BF890477
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E31A0: CC1A4009 1C26812E
	s_waitcnt lgkmcnt(6)                                       // 0000007E31A8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E31AC: BF8700A1
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E31B0: CC1A4009 1C26832F
	s_waitcnt lgkmcnt(5)                                       // 0000007E31B8: BF89FC57
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E31BC: CC1A4009 1C268530
	s_waitcnt lgkmcnt(4)                                       // 0000007E31C4: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E31C8: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E31CC: CC1A4009 1C268731
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007E31D4: BF890037
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E31D8: CC1A4009 1C268932
	.long 0xd7006a32                                           // 0000007E31E0: D7006A32
	v_cndmask_b32_e32 v0, v13, v10, vcc_lo                     // 0000007E31E4: 0200150D
	s_waitcnt lgkmcnt(2)                                       // 0000007E31E8: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000007E31EC: BF8701C2
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E31F0: CC1A4009 1C268B33
	v_add_co_ci_u32_e64 v51, null, s11, v14, vcc_lo            // 0000007E31F8: D5207C33 01AA1C0B
	.long 0xd7006a36                                           // 0000007E3200: D7006A36
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000007E3204: 0200090D
	s_waitcnt lgkmcnt(1)                                       // 0000007E3208: BF89FC17
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E320C: CC1A4009 1C268D34
	v_add_co_ci_u32_e64 v55, null, s5, v14, vcc_lo             // 0000007E3214: D5207C37 01AA1C05
	.long 0xd7006a0d                                           // 0000007E321C: D7006A0D
	v_cndmask_b32_e32 v0, v13, v17, vcc_lo                     // 0000007E3220: 0200230D
	s_waitcnt lgkmcnt(0)                                       // 0000007E3224: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E3228: BF870123
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E322C: CC1A4009 1C268F35
	v_add_co_ci_u32_e64 v14, null, s15, v14, vcc_lo            // 0000007E3234: D5207C0E 01AA1C0F
	v_fmac_f32_e32 v37, v56, v9                                // 0000007E323C: 564A1338
	s_clause 0x3                                               // 0000007E3240: BF850003
	global_load_b128 v[9:12], v[50:51], off                    // 0000007E3244: DC5E0000 097C0032
	global_load_b128 v[20:23], v[50:51], off offset:16         // 0000007E324C: DC5E0010 147C0032
	global_load_b128 v[46:49], v[50:51], off offset:32         // 0000007E3254: DC5E0020 2E7C0032
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000007E325C: DC5E0030 327C0032
	s_waitcnt vmcnt(3)                                         // 0000007E3264: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3268: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3270: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E3274: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E327C: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3284: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E3288: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3290: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3294: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E329C: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E32A0: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E32A8: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E32B0: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E32B4: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000007E32BC: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E32C0: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E32C8: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E32CC: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E32D4: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E32DC: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E32E0: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E32E8: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E32EC: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E32F4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E32F8: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E3300: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3308: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E330C: CC1A4009 1C268F35
	v_fmac_f32_e32 v42, v56, v9                                // 0000007E3314: 56541338
	s_clause 0x3                                               // 0000007E3318: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 0000007E331C: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 0000007E3324: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000007E332C: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 0000007E3334: DC5E0030 327C0036
	.long 0xd7006a36                                           // 0000007E333C: D7006A36
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 0000007E3340: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3344: BF8700B1
	v_add_co_ci_u32_e64 v55, null, s5, v55, vcc_lo             // 0000007E3348: D5207C37 01AA6E05
	s_waitcnt vmcnt(3)                                         // 0000007E3350: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3354: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E335C: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3364: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E3368: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E3370: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3378: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E337C: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3380: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3388: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3390: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3394: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E339C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000007E33A4: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E33A8: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E33AC: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E33B4: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E33BC: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E33C0: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E33C8: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E33D0: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E33D4: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E33D8: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E33E0: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E33E8: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E33EC: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E33F4: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E33FC: BF870001
	v_fmac_f32_e32 v41, v56, v9                                // 0000007E3400: 56521338
	s_clause 0x3                                               // 0000007E3404: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007E3408: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007E3410: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000007E3418: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000007E3420: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 0000007E3428: D7006A0D
	v_cndmask_b32_e32 v0, v13, v4, vcc_lo                      // 0000007E342C: 0200090D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3430: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v14, vcc_lo             // 0000007E3434: D5207C0E 01AA1C05
	s_waitcnt vmcnt(3)                                         // 0000007E343C: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3440: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E3448: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3450: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E3454: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E345C: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3464: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3468: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E346C: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3474: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E347C: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3480: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E3488: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000007E3490: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3494: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E3498: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E34A0: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E34A8: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E34AC: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E34B4: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E34BC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E34C0: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E34C4: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E34CC: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E34D4: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E34D8: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E34E0: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E34E8: BF870001
	v_fmac_f32_e32 v40, v56, v9                                // 0000007E34EC: 56501338
	s_clause 0x3                                               // 0000007E34F0: BF850003
	global_load_b128 v[9:12], v[54:55], off                    // 0000007E34F4: DC5E0000 097C0036
	global_load_b128 v[20:23], v[54:55], off offset:16         // 0000007E34FC: DC5E0010 147C0036
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000007E3504: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[54:55], off offset:48         // 0000007E350C: DC5E0030 327C0036
	s_waitcnt vmcnt(3)                                         // 0000007E3514: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3518: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3520: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E3524: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E352C: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3534: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E3538: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3540: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3544: CC1A4009 1C267914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E354C: BF870091
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3550: CC1A4009 1C267B15
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3558: CC1A4009 1C267D16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3560: BF8700A1
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E3564: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000007E356C: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E3570: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3578: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E357C: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E3584: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E358C: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E3590: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E3598: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E359C: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E35A4: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E35A8: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E35B0: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E35B8: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E35BC: CC1A4009 1C268F35
	v_fmac_f32_e32 v39, v56, v9                                // 0000007E35C4: 564E1338
	s_clause 0x3                                               // 0000007E35C8: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007E35CC: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007E35D4: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000007E35DC: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000007E35E4: DC5E0030 327C000D
	.long 0xd7006a0d                                           // 0000007E35EC: D7006A0D
	v_cndmask_b32_e32 v0, v54, v4, vcc_lo                      // 0000007E35F0: 02000936
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E35F4: BF8700B1
	v_add_co_ci_u32_e64 v14, null, s5, v55, vcc_lo             // 0000007E35F8: D5207C0E 01AA6E05
	s_waitcnt vmcnt(3)                                         // 0000007E3600: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E3604: CC1A4009 1A021F09
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E360C: CC1A4009 1C26730A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3614: BF870091
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E3618: CC1A4009 1C26750B
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E3620: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3628: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E362C: BF870091
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3630: CC1A4009 1C267914
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3638: CC1A4009 1C267B15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3640: BF870091
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3644: CC1A4009 1C267D16
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E364C: CC1A4009 1C267F17
	s_waitcnt vmcnt(1)                                         // 0000007E3654: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3658: BF870091
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E365C: CC1A4009 1C26812E
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E3664: CC1A4009 1C26832F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E366C: BF870091
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E3670: CC1A4009 1C268530
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E3678: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E3680: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3684: BF870091
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E3688: CC1A4009 1C268932
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E3690: CC1A4009 1C268B33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3698: BF870091
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E369C: CC1A4009 1C268D34
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E36A4: CC1A4009 1C268F35
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E36AC: BF870001
	v_fmac_f32_e32 v38, v56, v9                                // 0000007E36B0: 564C1338
	s_clause 0x3                                               // 0000007E36B4: BF850003
	global_load_b128 v[9:12], v[13:14], off                    // 0000007E36B8: DC5E0000 097C000D
	global_load_b128 v[20:23], v[13:14], off offset:16         // 0000007E36C0: DC5E0010 147C000D
	global_load_b128 v[46:49], v[13:14], off offset:32         // 0000007E36C8: DC5E0020 2E7C000D
	global_load_b128 v[50:53], v[13:14], off offset:48         // 0000007E36D0: DC5E0030 327C000D
	s_waitcnt vmcnt(3)                                         // 0000007E36D8: BF890FF7
	v_dot2_f32_bf16 v9, v9, v15, 0                             // 0000007E36DC: CC1A4009 1A021F09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E36E4: BF870091
	v_dot2_f32_bf16 v9, v10, v57, v9                           // 0000007E36E8: CC1A4009 1C26730A
	v_dot2_f32_bf16 v9, v11, v58, v9                           // 0000007E36F0: CC1A4009 1C26750B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E36F8: BF8700A1
	v_dot2_f32_bf16 v9, v12, v59, v9                           // 0000007E36FC: CC1A4009 1C26770C
	s_waitcnt vmcnt(2)                                         // 0000007E3704: BF890BF7
	v_dot2_f32_bf16 v9, v20, v60, v9                           // 0000007E3708: CC1A4009 1C267914
	v_mov_b32_e32 v20, v16                                     // 0000007E3710: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E3714: BF870122
	v_dot2_f32_bf16 v9, v21, v61, v9                           // 0000007E3718: CC1A4009 1C267B15
	v_mov_b32_e32 v21, v17                                     // 0000007E3720: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v62, v9                           // 0000007E3724: CC1A4009 1C267D16
	v_mov_b32_e32 v22, v18                                     // 0000007E372C: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007E3730: BF870132
	v_dot2_f32_bf16 v9, v23, v63, v9                           // 0000007E3734: CC1A4009 1C267F17
	v_mov_b32_e32 v23, v19                                     // 0000007E373C: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 0000007E3740: BF8907F7
	v_dot2_f32_bf16 v9, v46, v64, v9                           // 0000007E3744: CC1A4009 1C26812E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E374C: BF870091
	v_dot2_f32_bf16 v9, v47, v65, v9                           // 0000007E3750: CC1A4009 1C26832F
	v_dot2_f32_bf16 v9, v48, v66, v9                           // 0000007E3758: CC1A4009 1C268530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E3760: BF8700A1
	v_dot2_f32_bf16 v9, v49, v67, v9                           // 0000007E3764: CC1A4009 1C268731
	s_waitcnt vmcnt(0)                                         // 0000007E376C: BF8903F7
	v_dot2_f32_bf16 v9, v50, v68, v9                           // 0000007E3770: CC1A4009 1C268932
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3778: BF870091
	v_dot2_f32_bf16 v9, v51, v69, v9                           // 0000007E377C: CC1A4009 1C268B33
	v_dot2_f32_bf16 v9, v52, v70, v9                           // 0000007E3784: CC1A4009 1C268D34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E378C: BF870091
	v_dot2_f32_bf16 v9, v53, v71, v9                           // 0000007E3790: CC1A4009 1C268F35
	v_fmac_f32_e32 v34, v56, v9                                // 0000007E3798: 56441338
	v_mov_b32_e32 v15, v8                                      // 0000007E379C: 7E1E0308
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 0000007E37A0: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 0000007E37A8: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 0000007E37B0: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 0000007E37B8: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 0000007E37BC: 917E107E
	s_cbranch_execz 35                                         // 0000007E37C0: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xe50>
	s_waitcnt vmcnt(0)                                         // 0000007E37C4: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000007E37C8: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000007E37D0: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000007E37D8: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E37DC: BF870003
	.long 0xd4460003                                           // 0000007E37E0: D4460003
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007E37E4: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000007E37E8: BE92007E
	.long 0xd4c1007e                                           // 0000007E37EC: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000007E37F0: 0202411F
	s_cbranch_execz 64970                                      // 0000007E37F4: BFA5FDCA <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v43                              // 0000007E37F8: 3404569F
	.long 0xd7006a01                                           // 0000007E37FC: D7006A01
	v_cndmask_b32_e32 v1, v25, v43, vcc_lo                     // 0000007E3800: 02025719
	v_mov_b32_e32 v45, v27                                     // 0000007E3804: 7E5A031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007E3808: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000007E380C: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000007E3814: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000007E3818: DC5E0000 107C0001
	s_cbranch_vccnz 64959                                      // 0000007E3820: BFA4FDBF <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000007E3824: 3404589F
	.long 0xd7006a01                                           // 0000007E3828: D7006A01
	v_cndmask_b32_e32 v1, v24, v44, vcc_lo                     // 0000007E382C: 02025918
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E3830: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000007E3834: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000007E383C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007E3844: BF8903F7
	v_cvt_f32_f16_e32 v45, v1                                  // 0000007E3848: 7E5A1701
	s_branch 64948                                             // 0000007E384C: BFA0FDB4 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s16                             // 0000007E3850: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3854: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007E3858: 8C7E0E7E
	.long 0xd71f0001                                           // 0000007E385C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007E3860: 020100C1
	s_mov_b32 s2, exec_lo                                      // 0000007E3864: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007E3868: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 0000007E386C: 3A120288
	v_xor_b32_e32 v16, 4, v1                                   // 0000007E3870: 3A200284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007E3874: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007E3878: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007E387C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000007E3880: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 0000007E3884: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000007E3888: 7C9820A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007E388C: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000007E3890: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007E3894: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 0000007E3898: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 0000007E38A0: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 0000007E38A4: 06060725
	ds_bpermute_b32 v5, v2, v41                                // 0000007E38A8: DACC0000 05002902
	ds_bpermute_b32 v6, v2, v40                                // 0000007E38B0: DACC0000 06002802
	ds_bpermute_b32 v7, v2, v39                                // 0000007E38B8: DACC0000 07002702
	ds_bpermute_b32 v4, v2, v42                                // 0000007E38C0: DACC0000 04002A02
	ds_bpermute_b32 v8, v2, v38                                // 0000007E38C8: DACC0000 08002602
	ds_bpermute_b32 v2, v2, v34                                // 0000007E38D0: DACC0000 02002202
	ds_bpermute_b32 v10, v9, v3                                // 0000007E38D8: DACC0000 0A000309
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000007E38E0: 02202101
	s_waitcnt lgkmcnt(5)                                       // 0000007E38E4: BF89FC57
	v_dual_add_f32 v5, v41, v5 :: v_dual_add_f32 v6, v40, v6   // 0000007E38E8: C9080B29 05060D28
	s_waitcnt lgkmcnt(3)                                       // 0000007E38F0: BF89FC37
	v_dual_add_f32 v7, v39, v7 :: v_dual_add_f32 v4, v42, v4   // 0000007E38F4: C9080F27 0704092A
	s_waitcnt lgkmcnt(2)                                       // 0000007E38FC: BF89FC27
	v_add_f32_e32 v8, v38, v8                                  // 0000007E3900: 06101126
	ds_bpermute_b32 v12, v9, v5                                // 0000007E3904: DACC0000 0C000509
	s_waitcnt lgkmcnt(2)                                       // 0000007E390C: BF89FC27
	v_add_f32_e32 v2, v34, v2                                  // 0000007E3910: 06040522
	ds_bpermute_b32 v14, v9, v7                                // 0000007E3914: DACC0000 0E000709
	ds_bpermute_b32 v11, v9, v4                                // 0000007E391C: DACC0000 0B000409
	ds_bpermute_b32 v13, v9, v6                                // 0000007E3924: DACC0000 0D000609
	ds_bpermute_b32 v15, v9, v8                                // 0000007E392C: DACC0000 0F000809
	s_waitcnt lgkmcnt(5)                                       // 0000007E3934: BF89FC57
	v_dual_add_f32 v3, v3, v10 :: v_dual_lshlrev_b32 v16, 2, v16// 0000007E3938: C9221503 03102082
	s_waitcnt lgkmcnt(4)                                       // 0000007E3940: BF89FC47
	v_add_f32_e32 v5, v5, v12                                  // 0000007E3944: 060A1905
	ds_bpermute_b32 v9, v9, v2                                 // 0000007E3948: DACC0000 09000209
	s_waitcnt lgkmcnt(0)                                       // 0000007E3950: BF89FC07
	v_dual_add_f32 v7, v7, v14 :: v_dual_add_f32 v2, v2, v9    // 0000007E3954: C9081D07 07021302
	ds_bpermute_b32 v9, v16, v3                                // 0000007E395C: DACC0000 09000310
	v_add_f32_e32 v4, v4, v11                                  // 0000007E3964: 06081704
	ds_bpermute_b32 v11, v16, v5                               // 0000007E3968: DACC0000 0B000510
	v_add_f32_e32 v6, v6, v13                                  // 0000007E3970: 060C1B06
	ds_bpermute_b32 v13, v16, v7                               // 0000007E3974: DACC0000 0D000710
	s_waitcnt lgkmcnt(2)                                       // 0000007E397C: BF89FC27
	v_dual_add_f32 v8, v8, v15 :: v_dual_add_f32 v3, v3, v9    // 0000007E3980: C9081F08 08021303
	ds_bpermute_b32 v10, v16, v4                               // 0000007E3988: DACC0000 0A000410
	s_waitcnt lgkmcnt(2)                                       // 0000007E3990: BF89FC27
	v_add_f32_e32 v5, v5, v11                                  // 0000007E3994: 060A1705
	ds_bpermute_b32 v12, v16, v6                               // 0000007E3998: DACC0000 0C000610
	s_waitcnt lgkmcnt(2)                                       // 0000007E39A0: BF89FC27
	v_add_f32_e32 v7, v7, v13                                  // 0000007E39A4: 060E1B07
	ds_bpermute_b32 v14, v16, v8                               // 0000007E39A8: DACC0000 0E000810
	s_waitcnt lgkmcnt(2)                                       // 0000007E39B0: BF89FC27
	v_add_f32_e32 v4, v4, v10                                  // 0000007E39B4: 06081504
	s_waitcnt lgkmcnt(0)                                       // 0000007E39B8: BF89FC07
	v_dual_add_f32 v6, v6, v12 :: v_dual_add_f32 v9, v8, v14   // 0000007E39BC: C9081906 06081D08
	ds_bpermute_b32 v15, v16, v2                               // 0000007E39C4: DACC0000 0F000210
	v_xor_b32_e32 v16, 2, v1                                   // 0000007E39CC: 3A200282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007E39D0: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000007E39D4: 7C9820A0
	v_cndmask_b32_e32 v16, v1, v16, vcc_lo                     // 0000007E39D8: 02202101
	v_lshlrev_b32_e32 v16, 2, v16                              // 0000007E39DC: 30202082
	ds_bpermute_b32 v8, v16, v3                                // 0000007E39E0: DACC0000 08000310
	s_waitcnt lgkmcnt(1)                                       // 0000007E39E8: BF89FC17
	v_add_f32_e32 v2, v2, v15                                  // 0000007E39EC: 06041F02
	ds_bpermute_b32 v10, v16, v4                               // 0000007E39F0: DACC0000 0A000410
	ds_bpermute_b32 v11, v16, v5                               // 0000007E39F8: DACC0000 0B000510
	ds_bpermute_b32 v12, v16, v6                               // 0000007E3A00: DACC0000 0C000610
	ds_bpermute_b32 v13, v16, v7                               // 0000007E3A08: DACC0000 0D000710
	ds_bpermute_b32 v14, v16, v9                               // 0000007E3A10: DACC0000 0E000910
	ds_bpermute_b32 v15, v16, v2                               // 0000007E3A18: DACC0000 0F000210
	v_xor_b32_e32 v16, 1, v1                                   // 0000007E3A20: 3A200281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007E3A24: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v16                           // 0000007E3A28: 7C9820A0
	v_cndmask_b32_e32 v1, v1, v16, vcc_lo                      // 0000007E3A2C: 02022101
	s_waitcnt lgkmcnt(6)                                       // 0000007E3A30: BF89FC67
	v_dual_add_f32 v1, v3, v8 :: v_dual_lshlrev_b32 v16, 2, v1 // 0000007E3A34: C9221103 01100282
	s_waitcnt lgkmcnt(4)                                       // 0000007E3A3C: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 0000007E3A40: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 0000007E3A48: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v8, v7, v13   // 0000007E3A4C: C9081906 05081B07
	s_waitcnt lgkmcnt(1)                                       // 0000007E3A54: BF89FC17
	v_add_f32_e32 v10, v9, v14                                 // 0000007E3A58: 06141D09
	s_waitcnt lgkmcnt(0)                                       // 0000007E3A5C: BF89FC07
	v_add_f32_e32 v2, v2, v15                                  // 0000007E3A60: 06041F02
	ds_bpermute_b32 v6, v16, v1                                // 0000007E3A64: DACC0000 06000110
	ds_bpermute_b32 v9, v16, v3                                // 0000007E3A6C: DACC0000 09000310
	ds_bpermute_b32 v11, v16, v4                               // 0000007E3A74: DACC0000 0B000410
	ds_bpermute_b32 v12, v16, v5                               // 0000007E3A7C: DACC0000 0C000510
	ds_bpermute_b32 v13, v16, v8                               // 0000007E3A84: DACC0000 0D000810
	ds_bpermute_b32 v14, v16, v10                              // 0000007E3A8C: DACC0000 0E000A10
	ds_bpermute_b32 v7, v16, v2                                // 0000007E3A94: DACC0000 07000210
	v_cmpx_eq_u32_e32 0, v30                                   // 0000007E3A9C: 7D943C80
	s_cbranch_execz 29                                         // 0000007E3AA0: BFA5001D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1118>
	.long 0xd72c000f                                           // 0000007E3AA4: D72C000F
	v_cndmask_b32_e32 v0, v28, v184, vcc_lo                    // 0000007E3AA8: 0201711C
	s_waitcnt lgkmcnt(2)                                       // 0000007E3AAC: BF89FC27
	v_dual_add_f32 v8, v8, v13 :: v_dual_add_f32 v1, v1, v6    // 0000007E3AB0: C9081B08 08000D01
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v3, v3, v9    // 0000007E3AB8: C9081704 04021303
	s_waitcnt lgkmcnt(1)                                       // 0000007E3AC0: BF89FC17
	v_dual_add_f32 v10, v10, v14 :: v_dual_add_f32 v5, v5, v12 // 0000007E3AC4: C9081D0A 0A041905
	s_waitcnt lgkmcnt(0)                                       // 0000007E3ACC: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 0000007E3AD0: 06040F02
	v_mad_u32_u24 v13, v29, 28, v15                            // 0000007E3AD4: D60B000D 043D391D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007E3ADC: BF870001
	v_add_nc_u32_e32 v6, 0x400, v13                            // 0000007E3AE0: 4A0C1AFF 00000400
	v_add_nc_u32_e32 v9, 0x408, v13                            // 0000007E3AE8: 4A121AFF 00000408
	v_add_nc_u32_e32 v11, 0x410, v13                           // 0000007E3AF0: 4A161AFF 00000410
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 0000007E3AF8: D8380100 00030106
	ds_store_2addr_b32 v9, v4, v5 offset1:1                    // 0000007E3B00: D8380100 00050409
	ds_store_2addr_b32 v11, v8, v10 offset1:1                  // 0000007E3B08: D8380100 000A080B
	ds_store_b32 v13, v2 offset:1048                           // 0000007E3B10: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000007E3B18: 8C7E027E
	.long 0xd7050001                                           // 0000007E3B1C: D7050001
	v_cndmask_b32_e32 v0, v0, v165, vcc_lo                     // 0000007E3B20: 02014B00
	.long 0x7f063880                                           // 0000007E3B24: 7F063880
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007E3B28: BF890007
	s_barrier                                                  // 0000007E3B2C: BFBD0000
	buffer_gl0_inv                                             // 0000007E3B30: E0AC0000 00000000
	.long 0xd7390001                                           // 0000007E3B38: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000007E3B3C: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3B40: BF870091
	.long 0xd7044001                                           // 0000007E3B44: D7044001
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007E3B48: 02020300
	.long 0xd7395001                                           // 0000007E3B4C: D7395001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007E3B50: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3B54: BF870091
	.long 0xd7625001                                           // 0000007E3B58: D7625001
	v_cndmask_b32_e32 v1, 0x7f, v1, vcc_lo                     // 0000007E3B5C: 020202FF 0000007F
	.long 0xd7030801                                           // 0000007E3B64: D7030801
	v_cndmask_b32_e32 v1, v1, v1, vcc_lo                       // 0000007E3B68: 02020301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3B6C: BF870091
	.long 0xd7390003                                           // 0000007E3B70: D7390003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000007E3B74: 02020282
	.long 0xd7000201                                           // 0000007E3B78: D7000201
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 0000007E3B7C: 02020614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007E3B80: BF870121
	v_add_co_ci_u32_e64 v2, null, s21, 0, s2                   // 0000007E3B84: D5207C02 00090015
	.long 0xd44c0002                                           // 0000007E3B8C: D44C0002
	v_cndmask_b32_e32 v1, 28, v0, vcc_lo                       // 0000007E3B90: 0202009C
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 0000007E3B94: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 0000007E3B98: 8B026A02
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007E3B9C: BF870009
	s_and_saveexec_b32 s3, s2                                  // 0000007E3BA0: BE832002
	s_cbranch_execz 85                                         // 0000007E3BA4: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi2ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x12fc>
	.long 0xd7054000                                           // 0000007E3BA8: D7054000
	v_cndmask_b32_e32 v0, v3, v135, vcc_lo                     // 0000007E3BAC: 02010F03
	v_mul_u32_u24_e32 v3, 56, v3                               // 0000007E3BB0: 160606B8
	s_load_b32 s0, s[0:1], 0x48                                // 0000007E3BB4: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3BBC: BF870092
	.long 0xd7041000                                           // 0000007E3BC0: D7041000
	v_cndmask_b32_e32 v1, v0, v0, vcc_lo                       // 0000007E3BC4: 02020100
	v_and_b32_e32 v0, 0xff, v0                                 // 0000007E3BC8: 360000FF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3BD0: BF870091
	v_lshl_add_u32 v3, v0, 2, v3                               // 0000007E3BD4: D6460003 040D0500
	v_add_nc_u32_e32 v3, 0x400, v3                             // 0000007E3BDC: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:7                     // 0000007E3BE4: D8DC0700 03000003
	s_waitcnt lgkmcnt(0)                                       // 0000007E3BEC: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 0000007E3BF0: 06060680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3BF4: BF870091
	v_add_f32_e32 v3, v3, v4                                   // 0000007E3BF8: 06060903
	v_bfe_u32 v4, v3, 16, 1                                    // 0000007E3BFC: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C04: BF870091
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000007E3C08: D6550003 03FE0903 00007FFF
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000007E3C14: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C1C: BF870091
	v_mul_f32_e32 v6, s0, v3                                   // 0000007E3C20: 100C0600
	v_mul_f32_e32 v3, 0xbfb8aa3b, v6                           // 0000007E3C24: 10060CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007E3C2C: BF870291
	v_exp_f32_e32 v3, v3                                       // 0000007E3C30: 7E064B03
	v_add_f32_e32 v7, 1.0, v3                                  // 0000007E3C34: 060E06F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C38: BF870091
	v_div_scale_f32 v5, null, v7, v7, v6                       // 0000007E3C3C: D6FC7C05 041A0F07
	v_rcp_f32_e32 v8, v5                                       // 0000007E3C44: 7E105505
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C48: BF870095
	v_fma_f32 v3, -v5, v8, 1.0                                 // 0000007E3C4C: D6130003 23CA1105
	v_fmac_f32_e32 v8, v3, v8                                  // 0000007E3C54: 56101103
	v_div_scale_f32 v9, vcc_lo, v6, v7, v6                     // 0000007E3C58: D6FC6A09 041A0F06
	v_mad_u64_u32 v[3:4], null, s12, v0, 0                     // 0000007E3C60: D6FE7C03 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C68: BF870092
	v_mul_f32_e32 v10, v9, v8                                  // 0000007E3C6C: 10141109
	v_fma_f32 v11, -v5, v10, v9                                // 0000007E3C70: D613000B 24261505
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007E3C78: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 0000007E3C7C: 5614110B
	v_fma_f32 v9, -v5, v10, v9                                 // 0000007E3C80: D6130009 24261505
	v_mad_u64_u32 v[4:5], null, s13, v0, v[4:5]                // 0000007E3C88: D6FE7C04 0412000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007E3C90: BF870112
	v_div_fmas_f32 v0, v9, v8, v10                             // 0000007E3C94: D6370000 042A1109
	.long 0xd73c0003                                           // 0000007E3C9C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000007E3CA0: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E3CA4: BF8701A2
	v_div_fixup_f32 v5, v0, v7, v6                             // 0000007E3CA8: D6270005 041A0F00
	.long 0xd73c0000                                           // 0000007E3CB0: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000007E3CB4: 02020281
	.long 0xd7006a03                                           // 0000007E3CB8: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 0000007E3CBC: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007E3CC0: BF8701A3
	v_bfe_u32 v2, v5, 16, 1                                    // 0000007E3CC4: D6100002 02052105
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 0000007E3CCC: D5207C04 01AA0809
	.long 0xd7006a00                                           // 0000007E3CD4: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 0000007E3CD8: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007E3CDC: BF870193
	v_add3_u32 v2, v5, v2, 0x7fff                              // 0000007E3CE0: D6550002 03FE0505 00007FFF
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 0000007E3CEC: D5207C01 01AA0304
	global_store_d16_hi_b16 v[0:1], v2, off                    // 0000007E3CF4: DC960000 007C0200
	s_endpgm                                                   // 0000007E3CFC: BFB00000

