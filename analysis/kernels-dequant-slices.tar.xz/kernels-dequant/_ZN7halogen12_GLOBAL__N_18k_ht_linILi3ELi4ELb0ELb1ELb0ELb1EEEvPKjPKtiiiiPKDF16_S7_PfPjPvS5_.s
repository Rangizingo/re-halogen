0000000000459700 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_>:
; _ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_():
	s_clause 0x2                                               // 000000459700: BF850002
	s_load_b128 s[24:27], s[0:1], 0x10                         // 000000459704: F4080600 F8000010
	s_load_b256 s[12:19], s[0:1], 0x20                         // 00000045970C: F40C0300 F8000020
	s_load_b128 s[20:23], s[0:1], 0x40                         // 000000459714: F4080500 F8000040
	s_mov_b32 s10, s3                                          // 00000045971C: BE8A0003
	v_and_b32_e32 v50, 31, v0                                  // 000000459720: 3664009F
	v_lshrrev_b32_e32 v48, 5, v0                               // 000000459724: 32600085
	s_delay_alu instid0(VALU_DEP_2)                            // 000000459728: BF870002
	v_lshlrev_b32_e32 v8, 3, v50                               // 00000045972C: 30106483
	s_waitcnt lgkmcnt(0)                                       // 000000459730: BF89FC07
	s_ashr_i32 s34, s25, 31                                    // 000000459734: 86229F19
	s_mul_i32 s11, s27, s10                                    // 000000459738: 960B0A1B
	s_lshr_b32 s3, s34, 25                                     // 00000045973C: 85039922
	s_add_i32 s4, s11, s27                                     // 000000459740: 81041B0B
	s_add_i32 s3, s25, s3                                      // 000000459744: 81030319
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000459748: BF870499
	s_ashr_i32 s3, s3, 7                                       // 00000045974C: 86038703
	s_min_i32 s3, s3, s4                                       // 000000459750: 89030403
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000459754: BF8704B9
	s_sub_i32 s9, s3, s11                                      // 000000459758: 81890B03
	s_mov_b32 s3, exec_lo                                      // 00000045975C: BE83007E
	s_lshl_b32 s27, s9, 2                                      // 000000459760: 841B8209
	.long 0xd4c3007e                                           // 000000459764: D4C3007E
	v_cndmask_b32_e32 v1, s27, v48, vcc_lo                     // 000000459768: 0202601B
	s_xor_b32 s3, exec_lo, s3                                  // 00000045976C: 8D03037E
	v_lshlrev_b32_e32 v8, 3, v50                               // 000000459770: 30106483
	s_or_saveexec_b32 s35, s3                                  // 000000459774: BEA32203
	s_clause 0x1                                               // 000000459778: BF850001
	s_load_b32 s33, s[0:1], 0x54                               // 00000045977C: F4000840 F8000054
	s_load_b128 s[28:31], s[0:1], null                         // 000000459784: F4080700 F8000000
	v_lshlrev_b32_e32 v49, 2, v50                              // 00000045978C: 30626482
	s_xor_b32 exec_lo, exec_lo, s35                            // 000000459790: 8D7E237E
	s_cbranch_execz 502                                        // 000000459794: BFA501F6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x870>
	s_add_i32 s36, s24, -1                                     // 000000459798: 8124C118
	s_cmp_lg_u64 s[22:23], 0                                   // 00000045979C: BF118016
	v_and_b32_e32 v1, 1, v0                                    // 0000004597A0: 36020081
	s_cselect_b32 s37, -1, 0                                   // 0000004597A4: 982580C1
	s_abs_i32 s38, s9                                          // 0000004597A8: BEA61509
	v_and_b32_e32 v3, 2, v0                                    // 0000004597AC: 36060082
	s_cvt_f32_u32 s0, s38                                      // 0000004597B0: BE806526
	v_dual_mov_b32 v9, v48 :: v_dual_and_b32 v4, 4, v0         // 0000004597B4: CA240130 09040084
	v_and_b32_e32 v5, 8, v0                                    // 0000004597BC: 360A0088
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000004597C0: BF870009
	v_rcp_iflag_f32_e32 v2, s0                                 // 0000004597C4: 7E045600
	v_lshl_or_b32 v6, v48, 8, v8                               // 0000004597C8: D6560006 04211130
	v_add_nc_u32_e32 v7, s11, v48                              // 0000004597D0: 4A0E600B
	s_ashr_i32 s42, s9, 31                                     // 0000004597D4: 862A9F09
	s_sub_i32 s8, 0, s38                                       // 0000004597D8: 81882680
	s_mul_i32 s44, s42, 0x1400                                 // 0000004597DC: 962CFF2A 00001400
	.long 0xd44c0000                                           // 0000004597E4: D44C0000
	v_cndmask_b32_e32 v1, 16, v50, vcc_lo                      // 0000004597E8: 02026490
	.long 0xd44a0001                                           // 0000004597EC: D44A0001
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000004597F0: 02020280
	.long 0xd44a0004                                           // 0000004597F4: D44A0004
	v_cndmask_b32_e32 v1, 0, v4, vcc_lo                        // 0000004597F8: 02020880
	.long 0xd44a0005                                           // 0000004597FC: D44A0005
	v_cndmask_b32_e32 v1, 0, v5, vcc_lo                        // 000000459800: 02020A80
	v_readfirstlane_b32 s3, v2                                 // 000000459804: 7E060502
	v_lshl_or_b32 v1, v7, 7, v49                               // 000000459808: D6560001 04C50F07
	v_subrev_nc_u32_e32 v10, s44, v6                           // 000000459810: 4E140C2C
	s_lshl_b32 s6, s9, 7                                       // 000000459814: 84068709
	s_mov_b32 s39, s25                                         // 000000459818: BEA70019
	s_mul_f32 s7, s3, 0x4f7ffffe                               // 00000045981C: A207FF03 4F7FFFFE
	.long 0xd44a0003                                           // 000000459824: D44A0003
	v_cndmask_b32_e32 v1, 0, v3, vcc_lo                        // 000000459828: 02020680
	s_mov_b32 s40, 0                                           // 00000045982C: BEA80080
	s_mov_b32 s41, 0x76543210                                  // 000000459830: BEA900FF 76543210
	s_cvt_u32_f32 s7, s7                                       // 000000459838: BE876707
	s_lshl_b32 s43, s9, 8                                      // 00000045983C: 842B8809
	s_sub_i32 s44, 0, s6                                       // 000000459840: 81AC0680
	s_mov_b32 s46, 0x3db504f3                                  // 000000459844: BEAE00FF 3DB504F3
	s_mul_i32 s8, s8, s7                                       // 00000045984C: 96080708
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000459850: BF870499
	s_mul_hi_u32 s8, s7, s8                                    // 000000459854: 96880807
	s_add_i32 s45, s7, s8                                      // 000000459858: 812D0807
	s_branch 161                                               // 00000045985C: BFA000A1 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x3e4>
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459860: BF870091
	.long 0xd7006a02                                           // 000000459864: D7006A02
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000459868: 0202040C
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 00000045986C: D5207C03 01AA060D
	v_add_nc_u32_e32 v1, 0x400, v1                             // 000000459874: 4A0202FF 00000400
	global_load_d16_b16 v2, v[2:3], off offset:6               // 00000045987C: DC820006 027C0002
	v_add_f32_e32 v3, v16, v14                                 // 000000459884: 06061D10
	s_waitcnt vmcnt(0)                                         // 000000459888: BF8903F7
	v_fma_mix_f32 v5, v15, v2, v13 op_sel_hi:[0,1,0]           // 00000045988C: CC200005 1436050F
	v_sub_f32_e32 v4, v16, v14                                 // 000000459894: 08081D10
	v_fma_mix_f32 v2, -v15, v2, v13 op_sel_hi:[0,1,0]          // 000000459898: CC200002 3436050F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000004598A0: BF870121
	v_dual_add_f32 v6, v3, v5 :: v_dual_add_f32 v7, v4, v2     // 0000004598A4: C9080B03 06060504
	v_sub_f32_e32 v2, v4, v2                                   // 0000004598AC: 08040504
	v_mov_b32_dpp v4, v6 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004598B0: 7E0802FA FF016106
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 0000004598B8: D5010006 20060D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000004598C0: BF870241
	v_dual_add_f32 v4, v6, v4 :: v_dual_sub_f32 v3, v3, v5     // 0000004598C4: C90A0906 04020B03
	v_mov_b32_dpp v5, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004598CC: 7E0A02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, s1                          // 0000004598D4: D5010007 20060F07
	.long 0xd72c0006                                           // 0000004598DC: D72C0006
	v_cndmask_b32_e32 v1, 0x1400, v12, vcc_lo                  // 0000004598E0: 020218FF 00001400
	v_mov_b32_dpp v13, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 0000004598E8: 7E1A02FA FF016103
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 0000004598F0: D5010003 20060703
	s_delay_alu instid0(VALU_DEP_4)                            // 0000004598F8: BF870004
	v_add_f32_e32 v5, v7, v5                                   // 0000004598FC: 060A0B07
	v_mov_b32_dpp v14, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 000000459900: 7E1C02FA FF016102
	v_cndmask_b32_e64 v2, -v2, v2, s1                          // 000000459908: D5010002 20060502
	v_mov_b32_dpp v7, v4 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000459910: 7E0E02FA FF016204
	v_add_f32_e32 v3, v3, v13                                  // 000000459918: 06061B03
	v_cndmask_b32_e64 v4, -v4, v4, s3                          // 00000045991C: D5010004 200E0904
	v_mov_b32_dpp v12, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000459924: 7E1802FA FF016205
	v_add_f32_e32 v2, v2, v14                                  // 00000045992C: 06041D02
	v_cndmask_b32_e64 v5, -v5, v5, s3                          // 000000459930: D5010005 200E0B05
	v_mov_b32_dpp v13, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 000000459938: 7E1A02FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, s3                          // 000000459940: D5010003 200E0703
	v_add_f32_e32 v4, v4, v7                                   // 000000459948: 06080F04
	v_mov_b32_dpp v14, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045994C: 7E1C02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, s3                          // 000000459954: D5010002 200E0502
	v_add_f32_e32 v5, v5, v12                                  // 00000045995C: 060A1905
	.long 0xd72c0007                                           // 000000459960: D72C0007
	v_cndmask_b32_e32 v1, s43, v11, vcc_lo                     // 000000459964: 0202162B
	v_add_f32_e32 v3, v3, v13                                  // 000000459968: 06061B03
	v_mov_b32_dpp v11, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045996C: 7E1602FA FF016404
	v_add_f32_e32 v2, v2, v14                                  // 000000459974: 06041D02
	v_cndmask_b32_e64 v4, -v4, v4, s4                          // 000000459978: D5010004 20120904
	v_mov_b32_dpp v12, v5 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000459980: 7E1802FA FF016405
	v_cndmask_b32_e64 v5, -v5, v5, s4                          // 000000459988: D5010005 20120B05
	v_mov_b32_dpp v13, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000459990: 7E1A02FA FF016403
	v_mov_b32_dpp v14, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 000000459998: 7E1C02FA FF016402
	v_cndmask_b32_e64 v2, -v2, v2, s4                          // 0000004599A0: D5010002 20120502
	v_cndmask_b32_e64 v3, -v3, v3, s4                          // 0000004599A8: D5010003 20120703
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v5, v5, v12   // 0000004599B0: C9081704 04041905
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000004599B8: BF8701A3
	v_dual_add_f32 v2, v2, v14 :: v_dual_add_nc_u32 v9, 8, v9  // 0000004599BC: C9201D02 02081288
	v_sub_nc_u32_e32 v6, v6, v7                                // 0000004599C4: 4C0C0F06
	v_mov_b32_dpp v11, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004599C8: 7E1602FA FF016804
	v_cndmask_b32_e64 v4, -v4, v4, s5                          // 0000004599D0: D5010004 20160904
	v_add_f32_e32 v3, v3, v13                                  // 0000004599D8: 06061B03
	v_mov_b32_dpp v12, v5 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004599DC: 7E1802FA FF016805
	v_cndmask_b32_e64 v5, -v5, v5, s5                          // 0000004599E4: D5010005 20160B05
	v_mov_b32_dpp v14, v2 row_xmask:8 row_mask:0xf bank_mask:0xf// 0000004599EC: 7E1C02FA FF016802
	v_cndmask_b32_e64 v2, -v2, v2, s5                          // 0000004599F4: D5010002 20160502
	v_add_f32_e32 v4, v4, v11                                  // 0000004599FC: 06081704
	v_mov_b32_dpp v13, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 000000459A00: 7E1A02FA FF016803
	v_cndmask_b32_e64 v3, -v3, v3, s5                          // 000000459A08: D5010003 20160703
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459A10: BF870214
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v2, v2, v14   // 000000459A14: C9081905 05021D02
	v_mov_b32_e32 v11, v4                                      // 000000459A1C: 7E160304
	v_cndmask_b32_e64 v4, -v4, v4, s0                          // 000000459A20: D5010004 20020904
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459A28: BF870213
	v_dual_add_f32 v3, v3, v13 :: v_dual_mov_b32 v12, v5       // 000000459A2C: C9101B03 030C0105
	v_mov_b32_e32 v14, v2                                      // 000000459A34: 7E1C0302
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000459A38: BF870224
	v_permlanex16_b32 v11, v11, s41, 0xfedcba98                // 000000459A3C: D65C000B 03FC530B FEDCBA98
	v_cndmask_b32_e64 v5, -v5, v5, s0                          // 000000459A48: D5010005 20020B05
	v_mov_b32_e32 v13, v3                                      // 000000459A50: 7E1A0303
	v_cndmask_b32_e64 v2, -v2, v2, s0                          // 000000459A54: D5010002 20020502
	v_cndmask_b32_e64 v3, -v3, v3, s0                          // 000000459A5C: D5010003 20020703
	v_permlanex16_b32 v12, v12, s41, 0xfedcba98                // 000000459A64: D65C000C 03FC530C FEDCBA98
	v_permlanex16_b32 v14, v14, s41, 0xfedcba98                // 000000459A70: D65C000E 03FC530E FEDCBA98
	v_add_f32_e32 v4, v4, v11                                  // 000000459A7C: 06081704
	v_permlanex16_b32 v13, v13, s41, 0xfedcba98                // 000000459A80: D65C000D 03FC530D FEDCBA98
	v_cmp_le_i32_e32 vcc_lo, s27, v9                           // 000000459A8C: 7C86121B
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_nc_u32 v6, v10, v6// 000000459A90: C9201905 05060D0A
	v_add_f32_e32 v7, v2, v14                                  // 000000459A98: 060E1D02
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459A9C: BF870194
	v_dual_add_f32 v11, v3, v13 :: v_dual_add_nc_u32 v10, 0x800, v10// 000000459AA0: C9201B03 0B0A14FF 00000800
	v_fma_mixhi_f16 v2, v5, s46, 0                             // 000000459AAC: CC220002 02005D05
	v_fma_mixlo_f16 v2, v4, s46, 0                             // 000000459AB4: CC210002 02005D04
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459ABC: BF870214
	v_fma_mixhi_f16 v3, v7, s46, 0                             // 000000459AC0: CC220003 02005D07
	v_fma_mixlo_f16 v3, v11, s46, 0                            // 000000459AC8: CC210003 02005D0B
	s_or_b32 s40, vcc_lo, s40                                  // 000000459AD0: 8C28286A
	ds_store_b64 v6, v[2:3]                                    // 000000459AD4: D9340000 00000206
	s_and_not1_b32 exec_lo, exec_lo, s40                       // 000000459ADC: 917E287E
	s_cbranch_execz 290                                        // 000000459AE0: BFA50122 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x86c>
	.long 0xd72d0002                                           // 000000459AE4: D72D0002
	v_cndmask_b32_e32 v0, v9, v45, vcc_lo                      // 000000459AE8: 02005B09
	s_mov_b32 s6, -1                                           // 000000459AEC: BE8600C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459AF0: BF870091
	.long 0xd72c0003                                           // 000000459AF4: D72C0003
	v_cndmask_b32_e32 v0, v2, v38, vcc_lo                      // 000000459AF8: 02004D02
	v_sub_nc_u32_e32 v3, v9, v3                                // 000000459AFC: 4C060709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000459B00: BF870121
	v_subrev_nc_u32_e32 v5, s38, v3                            // 000000459B04: 4E0A0626
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000459B08: 7C960626
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_add_nc_u32 v4, 1, v2// 000000459B0C: CA600B03 03040481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459B14: BF870111
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000459B18: 02040902
	v_cmp_le_u32_e32 vcc_lo, s38, v3                           // 000000459B1C: 7C960626
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459B20: BF870092
	v_add_nc_u32_e32 v4, 1, v2                                 // 000000459B24: 4A080481
	v_cndmask_b32_e32 v2, v2, v4, vcc_lo                       // 000000459B28: 02040902
	s_and_not1_b32 vcc_lo, exec_lo, s37                        // 000000459B2C: 916A257E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459B30: BF870091
	v_xor_b32_e32 v12, s42, v2                                 // 000000459B34: 3A18042A
	v_subrev_nc_u32_e32 v11, s42, v12                          // 000000459B38: 4E16182A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000459B3C: BF8700A1
	v_mad_u64_u32 v[6:7], null, s44, v11, v[1:2]               // 000000459B40: D6FE7C06 0406162C
	v_min_i32_e32 v2, s36, v11                                 // 000000459B48: 22041624
	v_mad_i64_i32 v[4:5], null, v2, s39, 0                     // 000000459B4C: D6FF7C04 02004F02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459B54: BF870093
	v_ashrrev_i32_e32 v7, 31, v6                               // 000000459B58: 340E0C9F
	.long 0xd73c0002                                           // 000000459B5C: D73C0002
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000459B60: 02020C81
	s_cbranch_vccnz 212                                        // 000000459B64: BFA400D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x7b8>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459B68: BF870093
	.long 0xd7006a06                                           // 000000459B6C: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 000000459B70: 02020D04
	v_add_co_ci_u32_e64 v7, null, v5, v7, vcc_lo               // 000000459B74: D5207C07 01AA0F05
	.long 0x7f3a3880                                           // 000000459B7C: 7F3A3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459B80: BF870112
	.long 0xd73c0006                                           // 000000459B84: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 000000459B88: 02020C81
	.long 0x7f40399d                                           // 000000459B8C: 7F40399D
	s_waitcnt lgkmcnt(0)                                       // 000000459B90: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459B94: BF870092
	.long 0xd7006a0d                                           // 000000459B98: D7006A0D
	v_cndmask_b32_e32 v1, s30, v6, vcc_lo                      // 000000459B9C: 02020C1E
	v_add_co_ci_u32_e64 v14, null, s31, v7, vcc_lo             // 000000459BA0: D5207C0E 01AA0E1F
	.long 0xd7006a06                                           // 000000459BA8: D7006A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 000000459BAC: 02020C16
	s_delay_alu instid0(VALU_DEP_1)                            // 000000459BB0: BF870001
	v_add_co_ci_u32_e64 v7, null, s23, v7, vcc_lo              // 000000459BB4: D5207C07 01AA0E17
	global_load_b64 v[13:14], v[13:14], off                    // 000000459BBC: DC560000 0D7C000D
	.long 0xd7006a0f                                           // 000000459BC4: D7006A0F
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000459BC8: 0202040C
	global_load_b64 v[6:7], v[6:7], off                        // 000000459BCC: DC560000 067C0006
	v_add_co_ci_u32_e64 v16, null, s13, v3, vcc_lo             // 000000459BD4: D5207C10 01AA060D
	s_clause 0x1                                               // 000000459BDC: BF850001
	global_load_b32 v17, v[15:16], off                         // 000000459BE0: DC520000 117C000F
	global_load_d16_b16 v15, v[15:16], off offset:4            // 000000459BE8: DC820004 0F7C000F
	s_waitcnt vmcnt(3)                                         // 000000459BF0: BF890FF7
	.long 0x7e20390d                                           // 000000459BF4: 7E20390D
	s_waitcnt vmcnt(2)                                         // 000000459BF8: BF890BF7
	v_and_b32_e32 v39, 0xffff0000, v6                          // 000000459BFC: 364E0CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000459C04: 300C0C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459C08: BF870093
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000459C0C: 30202090
	v_mul_f32_e32 v20, 0xbfb8aa3b, v16                         // 000000459C10: 102820FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000459C18: BF870291
	v_exp_f32_e32 v20, v20                                     // 000000459C1C: 7E284B14
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_and_b32 v13, 0xffff0000, v13// 000000459C20: C92428F2 140C1AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459C2C: BF870111
	v_mul_f32_e32 v19, 0xbfb8aa3b, v13                         // 000000459C30: 10261AFF BFB8AA3B
	v_div_scale_f32 v24, null, v20, v20, v16                   // 000000459C38: D6FC7C18 04422914
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000459C40: BF8701B2
	v_exp_f32_e32 v19, v19                                     // 000000459C44: 7E264B13
	v_lshlrev_b32_e32 v18, 16, v14                             // 000000459C48: 30241C90
	v_div_scale_f32 v37, s7, v16, v20, v16                     // 000000459C4C: D6FC0725 04422910
	v_rcp_f32_e32 v28, v24                                     // 000000459C54: 7E385518
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459C58: BF870196
	v_add_f32_e32 v19, 1.0, v19                                // 000000459C5C: 062626F2
	v_mul_f32_e32 v21, 0xbfb8aa3b, v18                         // 000000459C60: 102A24FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459C68: BF870195
	v_fma_f32 v36, -v24, v28, 1.0                              // 000000459C6C: D6130024 23CA3918
	v_div_scale_f32 v23, null, v19, v19, v13                   // 000000459C74: D6FC7C17 04362713
	s_delay_alu instid0(VALU_DEP_3)                            // 000000459C7C: BF870003
	v_exp_f32_e32 v21, v21                                     // 000000459C80: 7E2A4B15
	v_and_b32_e32 v14, 0xffff0000, v14                         // 000000459C84: 361C1CFF FFFF0000
	v_div_scale_f32 v33, vcc_lo, v13, v19, v13                 // 000000459C8C: D6FC6A21 0436270D
	v_fmac_f32_e32 v28, v36, v28                               // 000000459C94: 56383924
	v_rcp_f32_e32 v26, v23                                     // 000000459C98: 7E345517
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000459C9C: BF870186
	v_dual_add_f32 v21, 1.0, v21 :: v_dual_mul_f32 v22, 0xbfb8aa3b, v14// 000000459CA0: C9062AF2 15161CFF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459CAC: BF870115
	v_fma_f32 v34, -v23, v26, 1.0                              // 000000459CB0: D6130022 23CA3517
	v_div_scale_f32 v25, null, v21, v21, v18                   // 000000459CB8: D6FC7C19 044A2B15
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000459CC0: BF8701A3
	v_exp_f32_e32 v22, v22                                     // 000000459CC4: 7E2C4B16
	v_div_scale_f32 v35, s6, v18, v21, v18                     // 000000459CC8: D6FC0623 044A2B12
	v_fmac_f32_e32 v26, v34, v26                               // 000000459CD0: 56343522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000459CD4: BF870293
	v_rcp_f32_e32 v30, v25                                     // 000000459CD8: 7E3C5519
	v_fma_f32 v38, -v25, v30, 1.0                              // 000000459CDC: D6130026 23CA3D19
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459CE4: BF870191
	v_fmac_f32_e32 v30, v38, v30                               // 000000459CE8: 563C3D26
	v_mul_f32_e32 v38, v33, v26                                // 000000459CEC: 104C3521
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459CF0: BF870112
	v_mul_f32_e32 v40, v35, v30                                // 000000459CF4: 10503D23
	v_fma_f32 v41, -v23, v38, v33                              // 000000459CF8: D6130029 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459D00: BF870112
	v_fma_f32 v44, -v25, v40, v35                              // 000000459D04: D613002C 248E5119
	v_fmac_f32_e32 v38, v41, v26                               // 000000459D0C: 564C3529
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459D10: BF870112
	v_fmac_f32_e32 v40, v44, v30                               // 000000459D14: 56503D2C
	v_fma_f32 v23, -v23, v38, v33                              // 000000459D18: D6130017 24864D17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459D20: BF870112
	v_fma_f32 v25, -v25, v40, v35                              // 000000459D24: D6130019 248E5119
	v_div_fmas_f32 v23, v23, v26, v38                          // 000000459D2C: D6370017 049A3517
	s_mov_b32 vcc_lo, s7                                       // 000000459D34: BEEA0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459D38: BF870091
	v_div_fixup_f32 v13, v23, v19, v13                         // 000000459D3C: D627000D 04362717
	v_dual_add_f32 v22, 1.0, v22 :: v_dual_mul_f32 v13, v13, v39// 000000459D44: C9062CF2 160C4F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000459D4C: BF8701A1
	v_div_scale_f32 v27, null, v22, v22, v14                   // 000000459D50: D6FC7C1B 043A2D16
	v_div_scale_f32 v36, s8, v14, v22, v14                     // 000000459D58: D6FC0824 043A2D0E
	.long 0x7e3a398d                                           // 000000459D60: 7E3A398D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000459D64: BF870293
	v_rcp_f32_e32 v31, v27                                     // 000000459D68: 7E3E551B
	v_fma_f32 v34, -v27, v31, 1.0                              // 000000459D6C: D6130022 23CA3F1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000459D74: BF870091
	v_dual_fmac_f32 v31, v34, v31 :: v_dual_mul_f32 v34, v37, v28// 000000459D78: C8063F22 1F223925
	v_mul_f32_e32 v42, v36, v31                                // 000000459D80: 10543F24
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459D84: BF870112
	v_fma_f32 v43, -v24, v34, v37                              // 000000459D88: D613002B 24964518
	v_fma_f32 v41, -v27, v42, v36                              // 000000459D90: D6130029 2492551B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459D98: BF870112
	v_fmac_f32_e32 v34, v43, v28                               // 000000459D9C: 5644392B
	v_fmac_f32_e32 v42, v41, v31                               // 000000459DA0: 56543F29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459DA4: BF870112
	v_fma_f32 v24, -v24, v34, v37                              // 000000459DA8: D6130018 24964518
	v_fma_f32 v23, -v27, v42, v36                              // 000000459DB0: D6130017 2492551B
	s_delay_alu instid0(VALU_DEP_2)                            // 000000459DB8: BF870002
	v_div_fmas_f32 v24, v24, v28, v34                          // 000000459DBC: D6370018 048A3918
	s_mov_b32 vcc_lo, s6                                       // 000000459DC4: BEEA0006
	s_mov_b32 s6, 0                                            // 000000459DC8: BE860080
	v_div_fmas_f32 v19, v25, v30, v40                          // 000000459DCC: D6370013 04A23D19
	s_mov_b32 vcc_lo, s8                                       // 000000459DD4: BEEA0008
	v_div_fixup_f32 v16, v24, v20, v16                         // 000000459DD8: D6270010 04422918
	v_lshlrev_b32_e32 v20, 16, v7                              // 000000459DE0: 30280E90
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000459DE4: 360E0EFF FFFF0000
	v_div_fixup_f32 v18, v19, v21, v18                         // 000000459DEC: D6270012 044A2B13
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000459DF4: BF8701A4
	v_mul_f32_e32 v6, v16, v6                                  // 000000459DF8: 100C0D10
	v_div_fmas_f32 v16, v23, v31, v42                          // 000000459DFC: D6370010 04AA3F17
	v_mul_f32_e32 v18, v18, v20                                // 000000459E04: 10242912
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459E08: BF870193
	.long 0x7e403986                                           // 000000459E0C: 7E403986
	v_div_fixup_f32 v14, v16, v22, v14                         // 000000459E10: D627000E 043A2D10
	v_and_b32_e32 v16, 1, v29                                  // 000000459E18: 36203A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459E1C: BF870194
	v_bfe_u32 v19, v18, 16, 1                                  // 000000459E20: D6100013 02052112
	v_dual_mul_f32 v7, v14, v7 :: v_dual_and_b32 v20, 1, v32   // 000000459E28: C8E40F0E 07144081
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000459E30: BF870193
	v_add3_u32 v13, v13, v16, 0x7fff                           // 000000459E34: D655000D 03FE210D 00007FFF
	v_add3_u32 v14, v18, v19, 0x7fff                           // 000000459E40: D655000E 03FE2712 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459E4C: BF870213
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000459E50: D6550006 03FE2906 00007FFF
	v_bfe_u32 v16, v7, 16, 1                                   // 000000459E5C: D6100010 02052107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459E64: BF870214
	v_and_b32_e32 v13, 0xffff0000, v13                         // 000000459E68: 361A1AFF FFFF0000
	v_and_b32_e32 v18, 0xffff0000, v14                         // 000000459E70: 36241CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000459E78: BF870214
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000459E7C: 360C0CFF FFFF0000
	v_add3_u32 v7, v7, v16, 0x7fff                             // 000000459E84: D6550007 03FE2107 00007FFF
	s_waitcnt vmcnt(1)                                         // 000000459E90: BF8907F7
	v_fma_mix_f32 v14, v17, v13, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000459E94: CC20080E 8A021B11
	s_waitcnt vmcnt(0)                                         // 000000459E9C: BF8903F7
	v_fma_mix_f32 v13, v15, v18, neg(0) op_sel_hi:[1,0,0]      // 000000459EA0: CC20000D 8A02250F
	v_fma_mix_f32 v16, v17, v6, neg(0) op_sel_hi:[1,0,0]       // 000000459EA8: CC200010 8A020D11
	v_and_b32_e32 v15, 0xffff0000, v7                          // 000000459EB0: 361E0EFF FFFF0000
	s_and_not1_b32 vcc_lo, exec_lo, s6                         // 000000459EB8: 916A067E
	s_cbranch_vccnz 65128                                      // 000000459EBC: BFA4FE68 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000459EC0: BF8700A3
	.long 0xd73c0004                                           // 000000459EC4: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 000000459EC8: 02020881
	s_waitcnt lgkmcnt(0)                                       // 000000459ECC: BF89FC07
	.long 0xd7006a04                                           // 000000459ED0: D7006A04
	v_cndmask_b32_e32 v1, s30, v4, vcc_lo                      // 000000459ED4: 0202081E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000459ED8: BF870111
	v_add_co_ci_u32_e64 v5, null, s31, v5, vcc_lo              // 000000459EDC: D5207C05 01AA0A1F
	.long 0xd7006a04                                           // 000000459EE4: D7006A04
	v_cndmask_b32_e32 v1, v4, v2, vcc_lo                       // 000000459EE8: 02020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000459EEC: BF8700A1
	v_add_co_ci_u32_e64 v5, null, v5, v3, vcc_lo               // 000000459EF0: D5207C05 01AA0705
	.long 0xd7006a06                                           // 000000459EF8: D7006A06
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 000000459EFC: 0202040C
	v_add_co_ci_u32_e64 v7, null, s13, v3, vcc_lo              // 000000459F00: D5207C07 01AA060D
	global_load_b64 v[4:5], v[4:5], off                        // 000000459F08: DC560000 047C0004
	s_clause 0x1                                               // 000000459F10: BF850001
	global_load_b32 v15, v[6:7], off                           // 000000459F14: DC520000 0F7C0006
	global_load_d16_b16 v6, v[6:7], off offset:4               // 000000459F1C: DC820004 067C0006
	s_waitcnt vmcnt(2)                                         // 000000459F24: BF890BF7
	.long 0x7e0e3904                                           // 000000459F28: 7E0E3904
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000459F2C: 360808FF FFFF0000
	v_lshlrev_b32_e32 v13, 16, v5                              // 000000459F34: 301A0A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000459F38: BF8701A3
	v_lshlrev_b32_e32 v7, 16, v7                               // 000000459F3C: 300E0E90
	s_waitcnt vmcnt(1)                                         // 000000459F40: BF8907F7
	v_fma_mix_f32 v14, v15, v4, neg(0) op_sel:[1,0,0] op_sel_hi:[1,0,0]// 000000459F44: CC20080E 8A02090F
	s_waitcnt vmcnt(0)                                         // 000000459F4C: BF8903F7
	v_fma_mix_f32 v13, v6, v13, neg(0) op_sel_hi:[1,0,0]       // 000000459F50: CC20000D 8A021B06
	v_fma_mix_f32 v16, v15, v7, neg(0) op_sel_hi:[1,0,0]       // 000000459F58: CC200010 8A020F0F
	v_and_b32_e32 v15, 0xffff0000, v5                          // 000000459F60: 361E0AFF FFFF0000
	s_branch 65085                                             // 000000459F68: BFA0FE3D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x160>
	s_or_b32 exec_lo, exec_lo, s40                             // 000000459F6C: 8C7E287E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000459F70: BF870009
	s_or_b32 exec_lo, exec_lo, s35                             // 000000459F74: 8C7E237E
	s_bfe_i32 s8, s9, 0x1001c                                  // 000000459F78: 9388FF09 0001001C
	v_mad_u32_u24 v6, v50, 24, 0x2f0                           // 000000459F80: D60B0006 03FD3132 000002F0
	s_lshr_b64 s[0:1], s[8:9], 29                              // 000000459F8C: 85809D08
	s_lshr_b32 s1, s34, 28                                     // 000000459F90: 85019C22
	s_add_i32 s0, s0, 7                                        // 000000459F94: 81008700
	s_add_i32 s1, s25, s1                                      // 000000459F98: 81010119
	s_ashr_i32 s0, s0, 3                                       // 000000459F9C: 86008300
	v_lshrrev_b32_e32 v1, 5, v6                                // 000000459FA0: 32020C85
	.long 0xd72c0005                                           // 000000459FA4: D72C0005
	v_cndmask_b32_e32 v1, s0, v48, vcc_lo                      // 000000459FA8: 02026000
	s_ashr_i32 s1, s1, 4                                       // 000000459FAC: 86018401
	s_lshl_b32 s3, s9, 3                                       // 000000459FB0: 84038309
	s_lshl_b32 s4, s11, 3                                      // 000000459FB4: 8404830B
	s_mul_hi_i32 s6, s1, s2                                    // 000000459FB8: 97060201
	s_mul_i32 s1, s1, s2                                       // 000000459FBC: 96010201
	s_ashr_i32 s5, s4, 31                                      // 000000459FC0: 86059F04
	v_cmp_eq_u32_e32 vcc_lo, 0, v50                            // 000000459FC4: 7C946480
	v_add_nc_u32_e32 v2, s0, v5                                // 000000459FC8: 4A040A00
	s_add_u32 s0, s1, s4                                       // 000000459FCC: 80000401
	s_addc_u32 s1, s6, s5                                      // 000000459FD0: 82010506
	s_mul_i32 s4, s0, 0x300                                    // 000000459FD4: 9604FF00 00000300
	s_mulk_i32 s1, 0x300                                       // 000000459FDC: B8010300
	v_min_i32_e32 v51, s3, v2                                  // 000000459FE0: 22660403
	v_subrev_nc_u32_e32 v2, 24, v1                             // 000000459FE4: 4E040298
	v_add_nc_u32_e32 v1, 1, v5                                 // 000000459FE8: 4A020A81
	s_mul_hi_u32 s3, s0, 0x300                                 // 000000459FEC: 9683FF00 00000300
	v_add_nc_u32_e32 v7, 8, v6                                 // 000000459FF4: 4A0E0C88
	s_add_i32 s3, s3, s1                                       // 000000459FF8: 81030103
	v_cndmask_b32_e64 v3, v2, 23, vcc_lo                       // 000000459FFC: D5010003 01A92F02
	.long 0xd4410000                                           // 00000045A004: D4410000
	v_cndmask_b32_e32 v1, v1, v51, vcc_lo                      // 00000045A008: 02026701
	s_waitcnt lgkmcnt(0)                                       // 00000045A00C: BF89FC07
	s_add_u32 s4, s28, s4                                      // 00000045A010: 8004041C
	s_addc_u32 s5, s29, s3                                     // 00000045A014: 8205031D
	s_barrier                                                  // 00000045A018: BFBD0000
	buffer_gl0_inv                                             // 00000045A01C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000045A024: BE812000
	s_cbranch_execz 120                                        // 00000045A028: BFA50078 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xb0c>
	v_lshrrev_b32_e32 v2, 5, v7                                // 00000045A02C: 32040E85
	.long 0xd4440000                                           // 00000045A030: D4440000
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 00000045A034: 02020697
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045A038: BF870112
	v_subrev_nc_u32_e32 v2, 24, v2                             // 00000045A03C: 4E040498
	v_cndmask_b32_e64 v4, 0xe9, 1, s0                          // 00000045A040: D5010004 000102FF 000000E9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045A04C: BF870112
	v_cndmask_b32_e64 v9, v2, 23, vcc_lo                       // 00000045A050: D5010009 01A92F02
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v13, v4, v3      // 00000045A058: CA200080 040C0704
	v_mad_i64_i32 v[1:2], null, 0x300, v1, s[4:5]              // 00000045A060: D6FF7C01 001202FF 00000300
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A06C: BF870193
	.long 0xd4440000                                           // 00000045A070: D4440000
	v_cndmask_b32_e32 v1, 23, v9, vcc_lo                       // 00000045A074: 02021297
	v_lshlrev_b32_e32 v14, 24, v13                             // 00000045A078: 301C1A98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A07C: BF870194
	.long 0xd73c000b                                           // 00000045A080: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000045A084: 02020682
	v_cndmask_b32_e64 v15, 0xe9, 1, s0                         // 00000045A088: D501000F 000102FF 000000E9
	v_mov_b32_e32 v10, v4                                      // 00000045A094: 7E140304
	v_bfe_i32 v4, v13, 7, 1                                    // 00000045A098: D6110004 02050F0D
	v_ashrrev_i32_e32 v13, 22, v14                             // 00000045A0A0: 341A1C96
	.long 0xd700000b                                           // 00000045A0A4: D700000B
	v_cndmask_b32_e32 v1, v1, v11, vcc_lo                      // 00000045A0A8: 02021701
	v_add_nc_u32_e32 v15, v15, v9                              // 00000045A0AC: 4A1E130F
	.long 0xd73c0009                                           // 00000045A0B0: D73C0009
	v_cndmask_b32_e32 v1, 2, v9, vcc_lo                        // 00000045A0B4: 02021282
	v_add_co_ci_u32_e64 v12, null, v2, v12, s0                 // 00000045A0B8: D5207C0C 00021902
	.long 0xd700000d                                           // 00000045A0C0: D700000D
	v_cndmask_b32_e32 v1, v1, v13, vcc_lo                      // 00000045A0C4: 02021B01
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045A0C8: BF870244
	v_lshlrev_b32_e32 v16, 24, v15                             // 00000045A0CC: 30201E98
	v_add_co_ci_u32_e64 v14, null, v2, v4, s0                  // 00000045A0D0: D5207C0E 00020902
	v_bfe_i32 v4, v15, 7, 1                                    // 00000045A0D8: D6110004 02050F0F
	.long 0xd7000009                                           // 00000045A0E0: D7000009
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 00000045A0E4: 02021301
	v_ashrrev_i32_e32 v15, 22, v16                             // 00000045A0E8: 341E2096
	v_add_co_ci_u32_e64 v10, null, v2, v10, s0                 // 00000045A0EC: D5207C0A 00021502
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045A0F4: BF870092
	.long 0xd7000001                                           // 00000045A0F8: D7000001
	v_cndmask_b32_e32 v1, v1, v15, vcc_lo                      // 00000045A0FC: 02021F01
	v_add_co_ci_u32_e64 v2, null, v2, v4, s0                   // 00000045A100: D5207C02 00020902
	s_clause 0x1f                                              // 00000045A108: BF85001F
	global_load_b32 v55, v[11:12], off                         // 00000045A10C: DC520000 377C000B
	global_load_b32 v54, v[11:12], off offset:96               // 00000045A114: DC520060 367C000B
	global_load_b32 v53, v[11:12], off offset:192              // 00000045A11C: DC5200C0 357C000B
	global_load_b32 v52, v[11:12], off offset:288              // 00000045A124: DC520120 347C000B
	global_load_b32 v56, v[11:12], off offset:384              // 00000045A12C: DC520180 387C000B
	global_load_b32 v57, v[11:12], off offset:480              // 00000045A134: DC5201E0 397C000B
	global_load_b32 v58, v[11:12], off offset:576              // 00000045A13C: DC520240 3A7C000B
	global_load_b32 v59, v[11:12], off offset:672              // 00000045A144: DC5202A0 3B7C000B
	global_load_b32 v64, v[13:14], off                         // 00000045A14C: DC520000 407C000D
	global_load_b32 v62, v[13:14], off offset:96               // 00000045A154: DC520060 3E7C000D
	global_load_b32 v61, v[13:14], off offset:192              // 00000045A15C: DC5200C0 3D7C000D
	global_load_b32 v60, v[13:14], off offset:288              // 00000045A164: DC520120 3C7C000D
	global_load_b32 v73, v[13:14], off offset:384              // 00000045A16C: DC520180 497C000D
	global_load_b32 v70, v[13:14], off offset:480              // 00000045A174: DC5201E0 467C000D
	global_load_b32 v68, v[13:14], off offset:576              // 00000045A17C: DC520240 447C000D
	global_load_b32 v66, v[13:14], off offset:672              // 00000045A184: DC5202A0 427C000D
	global_load_b32 v71, v[9:10], off                          // 00000045A18C: DC520000 477C0009
	global_load_b32 v67, v[9:10], off offset:96                // 00000045A194: DC520060 437C0009
	global_load_b32 v65, v[9:10], off offset:192               // 00000045A19C: DC5200C0 417C0009
	global_load_b32 v63, v[9:10], off offset:288               // 00000045A1A4: DC520120 3F7C0009
	global_load_b32 v79, v[9:10], off offset:384               // 00000045A1AC: DC520180 4F7C0009
	global_load_b32 v78, v[9:10], off offset:480               // 00000045A1B4: DC5201E0 4E7C0009
	global_load_b32 v77, v[9:10], off offset:576               // 00000045A1BC: DC520240 4D7C0009
	global_load_b32 v76, v[9:10], off offset:672               // 00000045A1C4: DC5202A0 4C7C0009
	global_load_b32 v75, v[1:2], off                           // 00000045A1CC: DC520000 4B7C0001
	global_load_b32 v74, v[1:2], off offset:96                 // 00000045A1D4: DC520060 4A7C0001
	global_load_b32 v72, v[1:2], off offset:192                // 00000045A1DC: DC5200C0 487C0001
	global_load_b32 v69, v[1:2], off offset:288                // 00000045A1E4: DC520120 457C0001
	global_load_b32 v83, v[1:2], off offset:384                // 00000045A1EC: DC520180 537C0001
	global_load_b32 v82, v[1:2], off offset:480                // 00000045A1F4: DC5201E0 527C0001
	global_load_b32 v81, v[1:2], off offset:576                // 00000045A1FC: DC520240 517C0001
	global_load_b32 v80, v[1:2], off offset:672                // 00000045A204: DC5202A0 507C0001
	s_or_b32 exec_lo, exec_lo, s1                              // 00000045A20C: 8C7E017E
	.long 0xd4410000                                           // 00000045A210: D4410000
	v_cndmask_b32_e32 v1, v5, v51, vcc_lo                      // 00000045A214: 02026705
	s_and_saveexec_b32 s3, s0                                  // 00000045A218: BE832000
	s_cbranch_execz 124                                        // 00000045A21C: BFA5007C <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xd10>
	v_lshrrev_b32_e32 v1, 5, v7                                // 00000045A220: 32020E85
	.long 0xd4440001                                           // 00000045A224: D4440001
	v_cndmask_b32_e32 v1, 23, v3, vcc_lo                       // 00000045A228: 02020697
	v_mad_i64_i32 v[9:10], null, 0x300, v5, s[4:5]             // 00000045A22C: D6FF7C09 00120AFF 00000300
	v_mov_b32_e32 v4, 0                                        // 00000045A238: 7E080280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045A23C: BF870214
	v_subrev_nc_u32_e32 v1, 24, v1                             // 00000045A240: 4E020298
	v_cndmask_b32_e64 v2, 0xe9, 1, s1                          // 00000045A244: D5010002 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A250: BF870193
	.long 0xd73c000b                                           // 00000045A254: D73C000B
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000045A258: 02020682
	v_cndmask_b32_e64 v1, v1, 23, vcc_lo                       // 00000045A25C: D5010001 01A92F01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045A264: BF870113
	v_dual_mov_b32 v2, v4 :: v_dual_add_nc_u32 v13, v2, v3     // 00000045A268: CA200104 020C0702
	.long 0xd4440001                                           // 00000045A270: D4440001
	v_cndmask_b32_e32 v1, 23, v1, vcc_lo                       // 00000045A274: 02020297
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045A278: BF8701A2
	v_lshlrev_b32_e32 v14, 24, v13                             // 00000045A27C: 301C1A98
	v_bfe_i32 v4, v13, 7, 1                                    // 00000045A280: D6110004 02050F0D
	v_cndmask_b32_e64 v15, 0xe9, 1, s1                         // 00000045A288: D501000F 000502FF 000000E9
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045A294: BF8700A3
	v_ashrrev_i32_e32 v13, 22, v14                             // 00000045A298: 341A1C96
	.long 0xd700010b                                           // 00000045A29C: D700010B
	v_cndmask_b32_e32 v1, v9, v11, vcc_lo                      // 00000045A2A0: 02021709
	v_add_co_ci_u32_e64 v12, null, v10, v12, s1                // 00000045A2A4: D5207C0C 0006190A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045A2AC: BF870214
	v_add_nc_u32_e32 v14, v15, v1                              // 00000045A2B0: 4A1C030F
	.long 0xd700010f                                           // 00000045A2B4: D700010F
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 00000045A2B8: 02021B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A2BC: BF870191
	v_add_co_ci_u32_e64 v16, null, v10, v4, s1                 // 00000045A2C0: D5207C10 0006090A
	v_lshlrev_b32_e32 v17, 24, v14                             // 00000045A2C8: 30221C98
	.long 0xd73c0001                                           // 00000045A2CC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000045A2D0: 02020282
	v_bfe_i32 v4, v14, 7, 1                                    // 00000045A2D4: D6110004 02050F0E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A2DC: BF870193
	v_ashrrev_i32_e32 v13, 22, v17                             // 00000045A2E0: 341A2296
	.long 0xd7000111                                           // 00000045A2E4: D7000111
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000045A2E8: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045A2EC: BF870191
	v_add_co_ci_u32_e64 v18, null, v10, v2, s1                 // 00000045A2F0: D5207C12 0006050A
	.long 0xd7000113                                           // 00000045A2F8: D7000113
	v_cndmask_b32_e32 v1, v9, v13, vcc_lo                      // 00000045A2FC: 02021B09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045A300: BF870001
	v_add_co_ci_u32_e64 v20, null, v10, v4, s1                 // 00000045A304: D5207C14 0006090A
	s_clause 0x1f                                              // 00000045A30C: BF85001F
	global_load_b32 v2, v[11:12], off                          // 00000045A310: DC520000 027C000B
	global_load_b32 v14, v[11:12], off offset:96               // 00000045A318: DC520060 0E7C000B
	global_load_b32 v43, v[11:12], off offset:192              // 00000045A320: DC5200C0 2B7C000B
	global_load_b32 v39, v[11:12], off offset:288              // 00000045A328: DC520120 277C000B
	global_load_b32 v35, v[11:12], off offset:384              // 00000045A330: DC520180 237C000B
	global_load_b32 v31, v[11:12], off offset:480              // 00000045A338: DC5201E0 1F7C000B
	global_load_b32 v27, v[11:12], off offset:576              // 00000045A340: DC520240 1B7C000B
	global_load_b32 v23, v[11:12], off offset:672              // 00000045A348: DC5202A0 177C000B
	global_load_b32 v1, v[15:16], off                          // 00000045A350: DC520000 017C000F
	global_load_b32 v13, v[15:16], off offset:96               // 00000045A358: DC520060 0D7C000F
	global_load_b32 v42, v[15:16], off offset:192              // 00000045A360: DC5200C0 2A7C000F
	global_load_b32 v38, v[15:16], off offset:288              // 00000045A368: DC520120 267C000F
	global_load_b32 v34, v[15:16], off offset:384              // 00000045A370: DC520180 227C000F
	global_load_b32 v30, v[15:16], off offset:480              // 00000045A378: DC5201E0 1E7C000F
	global_load_b32 v26, v[15:16], off offset:576              // 00000045A380: DC520240 1A7C000F
	global_load_b32 v22, v[15:16], off offset:672              // 00000045A388: DC5202A0 167C000F
	global_load_b32 v10, v[17:18], off                         // 00000045A390: DC520000 0A7C0011
	global_load_b32 v47, v[17:18], off offset:96               // 00000045A398: DC520060 2F7C0011
	global_load_b32 v45, v[17:18], off offset:192              // 00000045A3A0: DC5200C0 2D7C0011
	global_load_b32 v41, v[17:18], off offset:288              // 00000045A3A8: DC520120 297C0011
	global_load_b32 v37, v[17:18], off offset:384              // 00000045A3B0: DC520180 257C0011
	global_load_b32 v33, v[17:18], off offset:480              // 00000045A3B8: DC5201E0 217C0011
	global_load_b32 v29, v[17:18], off offset:576              // 00000045A3C0: DC520240 1D7C0011
	global_load_b32 v25, v[17:18], off offset:672              // 00000045A3C8: DC5202A0 197C0011
	global_load_b32 v9, v[19:20], off                          // 00000045A3D0: DC520000 097C0013
	global_load_b32 v46, v[19:20], off offset:96               // 00000045A3D8: DC520060 2E7C0013
	global_load_b32 v44, v[19:20], off offset:192              // 00000045A3E0: DC5200C0 2C7C0013
	global_load_b32 v40, v[19:20], off offset:288              // 00000045A3E8: DC520120 287C0013
	global_load_b32 v36, v[19:20], off offset:384              // 00000045A3F0: DC520180 247C0013
	global_load_b32 v32, v[19:20], off offset:480              // 00000045A3F8: DC5201E0 207C0013
	global_load_b32 v28, v[19:20], off offset:576              // 00000045A400: DC520240 1C7C0013
	global_load_b32 v24, v[19:20], off offset:672              // 00000045A408: DC5202A0 187C0013
	s_or_b32 exec_lo, exec_lo, s3                              // 00000045A410: 8C7E037E
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v84, 0             // 00000045A414: CA100080 11540080
	v_dual_mov_b32 v85, 0 :: v_dual_mov_b32 v86, 0             // 00000045A41C: CA100080 55560080
	v_dual_mov_b32 v87, 0 :: v_dual_mov_b32 v88, 0             // 00000045A424: CA100080 57580080
	v_dual_mov_b32 v89, 0 :: v_dual_mov_b32 v90, 0             // 00000045A42C: CA100080 595A0080
	v_dual_mov_b32 v91, 0 :: v_dual_mov_b32 v94, 0             // 00000045A434: CA100080 5B5E0080
	v_dual_mov_b32 v93, 0 :: v_dual_mov_b32 v96, 0             // 00000045A43C: CA100080 5D600080
	v_dual_mov_b32 v95, 0 :: v_dual_mov_b32 v98, 0             // 00000045A444: CA100080 5F620080
	v_dual_mov_b32 v97, 0 :: v_dual_mov_b32 v100, 0            // 00000045A44C: CA100080 61640080
	v_dual_mov_b32 v99, 0 :: v_dual_mov_b32 v102, 0            // 00000045A454: CA100080 63660080
	v_dual_mov_b32 v103, 0 :: v_dual_mov_b32 v104, 0           // 00000045A45C: CA100080 67680080
	v_dual_mov_b32 v105, 0 :: v_dual_mov_b32 v106, 0           // 00000045A464: CA100080 696A0080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v109, 0           // 00000045A46C: CA100080 6C6C0080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v113, 0            // 00000045A474: CA100080 5C700080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v107, 0           // 00000045A47C: CA100080 706A0080
	v_dual_mov_b32 v101, 0 :: v_dual_mov_b32 v110, 0           // 00000045A484: CA100080 656E0080
	v_dual_mov_b32 v111, 0 :: v_dual_mov_b32 v114, 0           // 00000045A48C: CA100080 6F720080
	s_ashr_i32 s3, s2, 31                                      // 00000045A494: 86039F02
	s_and_saveexec_b32 s1, s0                                  // 00000045A498: BE812000
	s_cbranch_execz 1211                                       // 00000045A49C: BFA504BB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x208c>
	v_lshrrev_b32_e32 v4, 5, v7                                // 00000045A4A0: 32080E85
	v_mul_i32_i24_e32 v7, 0xffffffe8, v50                      // 00000045A4A4: 120E64FF FFFFFFE8
	v_dual_mov_b32 v12, 23 :: v_dual_and_b32 v11, 0x7e0, v6    // 00000045A4AC: CA240097 0C0A0CFF 000007E0
	v_or_b32_e32 v8, 4, v8                                     // 00000045A4B8: 38101084
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045A4BC: BF870244
	v_subrev_nc_u32_e32 v15, 24, v4                            // 00000045A4C0: 4E1E0898
	.long 0xd7030006                                           // 00000045A4C4: D7030006
	v_cndmask_b32_e32 v0, v3, v129, vcc_lo                     // 00000045A4C8: 02010303
	v_dual_mov_b32 v17, 0 :: v_dual_add_nc_u32 v116, 2, v5     // 00000045A4CC: CA200080 11740A82
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000045A4D4: 3408069F
	v_cndmask_b32_e64 v16, v15, 23, vcc_lo                     // 00000045A4D8: D5010010 01A92F0F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000045A4E0: BF870233
	v_dual_mov_b32 v84, v17 :: v_dual_and_b32 v15, 16, v0      // 00000045A4E4: CA240111 540E0090
	v_add3_u32 v117, v7, v11, 0xfffffd34                       // 00000045A4EC: D6550075 03FE1707 FFFFFD34
	v_mad_u32_u24 v11, v8, 3, 0x2f0                            // 00000045A4F8: D60B000B 03FD0708 000002F0
	.long 0xd7034006                                           // 00000045A504: D7034006
	v_cndmask_b32_e32 v0, v16, v129, vcc_lo                    // 00000045A508: 02010310
	v_mul_i32_i24_e32 v20, -3, v8                              // 00000045A50C: 122810C3
	.long 0xd7620007                                           // 00000045A510: D7620007
	v_cndmask_b32_e32 v1, 0xff, v6, vcc_lo                     // 00000045A514: 02020CFF 000000FF
	.long 0x7e10390c                                           // 00000045A51C: 7E10390C
	v_lshl_or_b32 v118, v5, 5, v15                             // 00000045A520: D6560076 043D0B05
	.long 0xd7621005                                           // 00000045A528: D7621005
	v_cndmask_b32_e32 v1, 0xff, v6, vcc_lo                     // 00000045A52C: 02020CFF 000000FF
	.long 0xd73c0012                                           // 00000045A534: D73C0012
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 00000045A538: 02020682
	v_cmp_gt_u16_e32 vcc_lo, 24, v7                            // 00000045A53C: 7C780E98
	.long 0xd7040003                                           // 00000045A540: D7040003
	v_cndmask_b32_e32 v1, v3, v8, vcc_lo                       // 00000045A544: 02021103
	v_mov_b32_e32 v86, v17                                     // 00000045A548: 7EAC0311
	.long 0xd43d0000                                           // 00000045A54C: D43D0000
	v_cndmask_b32_e32 v1, 24, v5, vcc_lo                       // 00000045A550: 02020A98
	v_and_b32_e32 v5, 0x7e0, v11                               // 00000045A554: 360A16FF 000007E0
	v_sub_nc_u32_e32 v115, 0, v51                              // 00000045A55C: 4CE66680
	v_cndmask_b16 v3, v3, v6, vcc_lo                           // 00000045A560: D65D0003 01AA0D03
	v_mov_b32_e32 v88, v17                                     // 00000045A568: 7EB00311
	v_cndmask_b16 v4, 0, v6, s0                                // 00000045A56C: D65D1004 00020C80
	v_mov_b32_e32 v85, v17                                     // 00000045A574: 7EAA0311
	v_add3_u32 v119, v20, v5, 0xfffffd34                       // 00000045A578: D6550077 03FE0B14 FFFFFD34
	v_and_b32_e32 v3, 0xff, v3                                 // 00000045A584: 360606FF 000000FF
	.long 0xd73c0014                                           // 00000045A58C: D73C0014
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000045A590: 02022082
	v_dual_mov_b32 v87, v17 :: v_dual_and_b32 v4, 0xff, v4     // 00000045A594: CA240111 570408FF 000000FF
	v_mov_b32_e32 v89, v17                                     // 00000045A5A0: 7EB20311
	v_mov_b32_e32 v90, v17                                     // 00000045A5A4: 7EB40311
	v_lshlrev_b32_e32 v120, 2, v3                              // 00000045A5A8: 30F00682
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045A5AC: BF870004
	v_lshlrev_b32_e32 v121, 2, v4                              // 00000045A5B0: 30F20882
	v_mov_b32_e32 v91, v17                                     // 00000045A5B4: 7EB60311
	v_mov_b32_e32 v93, v17                                     // 00000045A5B8: 7EBA0311
	v_mov_b32_e32 v94, v17                                     // 00000045A5BC: 7EBC0311
	v_mov_b32_e32 v95, v17                                     // 00000045A5C0: 7EBE0311
	v_mov_b32_e32 v96, v17                                     // 00000045A5C4: 7EC00311
	v_mov_b32_e32 v97, v17                                     // 00000045A5C8: 7EC20311
	v_mov_b32_e32 v98, v17                                     // 00000045A5CC: 7EC40311
	v_mov_b32_e32 v99, v17                                     // 00000045A5D0: 7EC60311
	v_mov_b32_e32 v100, v17                                    // 00000045A5D4: 7EC80311
	v_mov_b32_e32 v102, v17                                    // 00000045A5D8: 7ECC0311
	v_mov_b32_e32 v103, v17                                    // 00000045A5DC: 7ECE0311
	v_mov_b32_e32 v104, v17                                    // 00000045A5E0: 7ED00311
	v_mov_b32_e32 v105, v17                                    // 00000045A5E4: 7ED20311
	v_mov_b32_e32 v106, v17                                    // 00000045A5E8: 7ED40311
	v_mov_b32_e32 v108, v17                                    // 00000045A5EC: 7ED80311
	v_mov_b32_e32 v92, v17                                     // 00000045A5F0: 7EB80311
	v_mov_b32_e32 v109, v17                                    // 00000045A5F4: 7EDA0311
	v_mov_b32_e32 v112, v17                                    // 00000045A5F8: 7EE00311
	v_mov_b32_e32 v113, v17                                    // 00000045A5FC: 7EE20311
	v_mov_b32_e32 v107, v17                                    // 00000045A600: 7ED60311
	v_mov_b32_e32 v101, v17                                    // 00000045A604: 7ECA0311
	v_mov_b32_e32 v110, v17                                    // 00000045A608: 7EDC0311
	v_mov_b32_e32 v111, v17                                    // 00000045A60C: 7EDE0311
	v_mov_b32_e32 v114, v17                                    // 00000045A610: 7EE40311
	s_mov_b32 s0, 0                                            // 00000045A614: BE800080
	s_movk_i32 s6, 0x1eee                                      // 00000045A618: B0061EEE
	s_branch 1000                                              // 00000045A61C: BFA003E8 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x1ec0>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000045A620: 8C7E077E
	.long 0xd73d000f                                           // 00000045A624: D73D000F
	v_cndmask_b32_e32 v1, v117, v1, vcc_lo                     // 00000045A628: 02020375
	.long 0xd73d009a                                           // 00000045A62C: D73D009A
	v_cndmask_b32_e32 v1, v119, v9, vcc_lo                     // 00000045A630: 02021377
	ds_load_b128 v[5:8], v118                                  // 00000045A634: DBFC0000 05000076
	ds_load_b128 v[1:4], v118 offset:5120                      // 00000045A63C: DBFC1400 01000076
	ds_load_b128 v[9:12], v118 offset:10240                    // 00000045A644: DBFC2800 09000076
	.long 0xd73d002e                                           // 00000045A64C: D73D002E
	v_cndmask_b32_e32 v1, v119, v46, vcc_lo                    // 00000045A650: 02025D77
	.long 0xd73d002a                                           // 00000045A654: D73D002A
	v_cndmask_b32_e32 v1, v117, v42, vcc_lo                    // 00000045A658: 02025575
	v_bfe_u32 v16, v15, 9, 16                                  // 00000045A65C: D6100010 0241130F
	v_bfe_u32 v155, v15, 6, 16                                 // 00000045A664: D610009B 02410D0F
	v_bfe_u32 v156, v15, 3, 16                                 // 00000045A66C: D610009C 0241070F
	v_and_b32_e32 v15, 0xffff, v15                             // 00000045A674: 361E1EFF 0000FFFF
	v_bfe_u32 v157, v154, 9, 16                                // 00000045A67C: D610009D 0241139A
	.long 0xd72c0010                                           // 00000045A684: D72C0010
	v_cndmask_b32_e32 v1, 0x83dcd12d, v16, vcc_lo              // 00000045A688: 020220FF 83DCD12D
	.long 0xd72c009b                                           // 00000045A690: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 00000045A694: 020336FF 83DCD12D
	.long 0xd72c009c                                           // 00000045A69C: D72C009C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v156, vcc_lo             // 00000045A6A0: 020338FF 83DCD12D
	.long 0xd72c000f                                           // 00000045A6A8: D72C000F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v15, vcc_lo              // 00000045A6AC: 02021EFF 83DCD12D
	v_bfe_u32 v158, v154, 6, 16                                // 00000045A6B4: D610009E 02410D9A
	v_bfe_u32 v159, v154, 3, 16                                // 00000045A6BC: D610009F 0241079A
	.long 0xd72c009d                                           // 00000045A6C4: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 00000045A6C8: 02033AFF 83DCD12D
	v_bfe_u32 v161, v46, 9, 16                                 // 00000045A6D0: D61000A1 0241132E
	v_sad_u8 v16, v16, 0, 0x6400                               // 00000045A6D8: D6220010 03FD0110 00006400
	v_sad_u8 v155, v155, 0, 0x6400                             // 00000045A6E4: D622009B 03FD019B 00006400
	v_sad_u8 v156, v156, 0, 0x6400                             // 00000045A6F0: D622009C 03FD019C 00006400
	v_sad_u8 v15, v15, 0, 0x6400                               // 00000045A6FC: D622000F 03FD010F 00006400
	.long 0xd72c009e                                           // 00000045A708: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 00000045A70C: 02033CFF 83DCD12D
	v_and_b32_e32 v16, 0xffff, v16                             // 00000045A714: 362020FF 0000FFFF
	.long 0xd72c009f                                           // 00000045A71C: D72C009F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 00000045A720: 02033EFF 83DCD12D
	v_sad_u8 v157, v157, 0, 0x6400                             // 00000045A728: D622009D 03FD019D 00006400
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000045A734: 301E1E90
	v_bfe_u32 v162, v46, 6, 16                                 // 00000045A738: D61000A2 02410D2E
	v_lshl_or_b32 v16, v155, 16, v16                           // 00000045A740: D6560010 0441219B
	.long 0xd72c00a1                                           // 00000045A748: D72C00A1
	v_cndmask_b32_e32 v1, 0x83dcd12d, v161, vcc_lo             // 00000045A74C: 020342FF 83DCD12D
	v_sad_u8 v155, v158, 0, 0x6400                             // 00000045A754: D622009B 03FD019E 00006400
	v_and_or_b32 v15, 0xffff, v156, v15                        // 00000045A760: D657000F 043F38FF 0000FFFF
	.long 0xd72c00a2                                           // 00000045A76C: D72C00A2
	v_cndmask_b32_e32 v1, 0x83dcd12d, v162, vcc_lo             // 00000045A770: 020344FF 83DCD12D
	v_pk_fma_f16 v156, v16, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000045A778: CC0E009C 0BFC0D10 0000C931
	v_and_b32_e32 v154, 0xffff, v154                           // 00000045A784: 373534FF 0000FFFF
	v_sad_u8 v16, v159, 0, 0x6400                              // 00000045A78C: D6220010 03FD019F 00006400
	v_pk_fma_f16 v159, v15, s6, 0xc931 op_sel_hi:[1,0,0]       // 00000045A798: CC0E009F 0BFC0D0F 0000C931
	v_and_b32_e32 v157, 0xffff, v157                           // 00000045A7A4: 373B3AFF 0000FFFF
	s_waitcnt lgkmcnt(1)                                       // 00000045A7AC: BF89FC17
	v_dot2acc_f32_f16 v111, v156, v1                           // 00000045A7B0: 04DE039C
	.long 0xd72c009a                                           // 00000045A7B4: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 00000045A7B8: 020334FF 83DCD12D
	v_dot2acc_f32_f16 v114, v156, v5                           // 00000045A7C0: 04E40B9C
	v_sad_u8 v161, v161, 0, 0x6400                             // 00000045A7C4: D62200A1 03FD01A1 00006400
	v_lshl_or_b32 v157, v155, 16, v157                         // 00000045A7D0: D656009D 0675219B
	v_dot2acc_f32_f16 v111, v159, v2                           // 00000045A7D8: 04DE059F
	v_bfe_u32 v163, v46, 3, 16                                 // 00000045A7DC: D61000A3 0241072E
	v_dot2acc_f32_f16 v114, v159, v6                           // 00000045A7E4: 04E40D9F
	.long 0xd73d002b                                           // 00000045A7E8: D73D002B
	v_cndmask_b32_e32 v1, v119, v44, vcc_lo                    // 00000045A7EC: 02025977
	v_sad_u8 v154, v154, 0, 0x6400                             // 00000045A7F0: D622009A 03FD019A 00006400
	v_pk_fma_f16 v157, v157, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000045A7FC: CC0E009D 0BFC0D9D 0000C931
	v_bfe_u32 v45, v42, 6, 16                                  // 00000045A808: D610002D 02410D2A
	.long 0xd73d0026                                           // 00000045A810: D73D0026
	v_cndmask_b32_e32 v1, v117, v38, vcc_lo                    // 00000045A814: 02024D75
	.long 0xd73d0027                                           // 00000045A818: D73D0027
	v_cndmask_b32_e32 v1, v119, v40, vcc_lo                    // 00000045A81C: 02025177
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045A820: BF870244
	v_dual_dot2acc_f32_f16 v111, v157, v3 :: v_dual_lshlrev_b32 v158, 16, v154// 00000045A824: CB22079D 6F9F3490
	.long 0xd73d009a                                           // 00000045A82C: D73D009A
	v_cndmask_b32_e32 v1, v117, v13, vcc_lo                    // 00000045A830: 02021B75
	.long 0xd72c002d                                           // 00000045A834: D72C002D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v45, vcc_lo              // 00000045A838: 02025AFF 83DCD12D
	.long 0xd73d0022                                           // 00000045A840: D73D0022
	v_cndmask_b32_e32 v1, v117, v34, vcc_lo                    // 00000045A844: 02024575
	v_and_or_b32 v155, 0xffff, v16, v158                       // 00000045A848: D657009B 067A20FF 0000FFFF
	ds_load_b128 v[13:16], v118 offset:15360                   // 00000045A854: DBFC3C00 0D000076
	v_dot2acc_f32_f16 v114, v157, v7                           // 00000045A85C: 04E40F9D
	v_bfe_u32 v158, v154, 9, 16                                // 00000045A860: D610009E 0241139A
	.long 0xd73d0023                                           // 00000045A868: D73D0023
	v_cndmask_b32_e32 v1, v119, v36, vcc_lo                    // 00000045A86C: 02024977
	v_pk_fma_f16 v155, v155, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000045A870: CC0E009B 0BFC0D9B 0000C931
	s_waitcnt lgkmcnt(1)                                       // 00000045A87C: BF89FC17
	v_dot2acc_f32_f16 v110, v156, v9                           // 00000045A880: 04DC139C
	v_sad_u8 v45, v45, 0, 0x6400                               // 00000045A884: D622002D 03FD012D 00006400
	.long 0xd72c002f                                           // 00000045A890: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 00000045A894: 02033CFF 83DCD12D
	v_bfe_u32 v158, v154, 6, 16                                // 00000045A89C: D610009E 02410D9A
	v_dot2acc_f32_f16 v111, v155, v4                           // 00000045A8A4: 04DE099B
	v_dot2acc_f32_f16 v110, v159, v10                          // 00000045A8A8: 04DC159F
	v_bfe_u32 v37, v34, 6, 16                                  // 00000045A8AC: D6100025 02410D22
	.long 0xd73d001e                                           // 00000045A8B4: D73D001E
	v_cndmask_b32_e32 v1, v117, v30, vcc_lo                    // 00000045A8B8: 02023D75
	.long 0xd72c009e                                           // 00000045A8BC: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 00000045A8C0: 02033CFF 83DCD12D
	.long 0xd73d001f                                           // 00000045A8C8: D73D001F
	v_cndmask_b32_e32 v1, v119, v32, vcc_lo                    // 00000045A8CC: 02024177
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000045A8D0: D622002F 03FD012F 00006400
	.long 0xd72c0025                                           // 00000045A8DC: D72C0025
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000045A8E0: 02024AFF 83DCD12D
	.long 0xd73d001a                                           // 00000045A8E8: D73D001A
	v_cndmask_b32_e32 v1, v117, v26, vcc_lo                    // 00000045A8EC: 02023575
	v_bfe_u32 v33, v30, 6, 16                                  // 00000045A8F0: D6100021 02410D1E
	.long 0xd73d001b                                           // 00000045A8F8: D73D001B
	v_cndmask_b32_e32 v1, v119, v28, vcc_lo                    // 00000045A8FC: 02023977
	v_and_b32_e32 v47, 0xffff, v47                             // 00000045A900: 365E5EFF 0000FFFF
	v_sad_u8 v158, v158, 0, 0x6400                             // 00000045A908: D622009E 03FD019E 00006400
	s_waitcnt lgkmcnt(0)                                       // 00000045A914: BF89FC07
	v_dual_dot2acc_f32_f16 v101, v156, v13 :: v_dual_dot2acc_f32_f16 v114, v155, v8// 00000045A918: CB181B9C 6572119B
	v_sad_u8 v37, v37, 0, 0x6400                               // 00000045A920: D6220025 03FD0125 00006400
	.long 0xd72c0021                                           // 00000045A92C: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000045A930: 020242FF 83DCD12D
	v_lshl_or_b32 v47, v158, 16, v47                           // 00000045A938: D656002F 04BD219E
	.long 0xd72c009e                                           // 00000045A940: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v163, vcc_lo             // 00000045A944: 020346FF 83DCD12D
	v_bfe_u32 v29, v26, 6, 16                                  // 00000045A94C: D610001D 02410D1A
	.long 0xd73d0016                                           // 00000045A954: D73D0016
	v_cndmask_b32_e32 v1, v117, v22, vcc_lo                    // 00000045A958: 02022D75
	.long 0xd73d0017                                           // 00000045A95C: D73D0017
	v_cndmask_b32_e32 v1, v119, v24, vcc_lo                    // 00000045A960: 02023177
	v_pk_fma_f16 v47, v47, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045A964: CC0E002F 0BFC0D2F 0000C931
	v_and_b32_e32 v160, 0xffff, v154                           // 00000045A970: 374134FF 0000FFFF
	v_bfe_u32 v154, v154, 3, 16                                // 00000045A978: D610009A 0241079A
	v_dot2acc_f32_f16 v110, v157, v11                          // 00000045A980: 04DC179D
	v_sad_u8 v158, v158, 0, 0x6400                             // 00000045A984: D622009E 03FD019E 00006400
	v_dot2acc_f32_f16 v107, v47, v5                            // 00000045A990: 04D60B2F
	.long 0xd72c00a0                                           // 00000045A994: D72C00A0
	v_cndmask_b32_e32 v1, 0x83dcd12d, v160, vcc_lo             // 00000045A998: 020340FF 83DCD12D
	.long 0xd72c009a                                           // 00000045A9A0: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 00000045A9A4: 020334FF 83DCD12D
	v_dot2acc_f32_f16 v113, v47, v1                            // 00000045A9AC: 04E2032F
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000045A9B0: D6220021 03FD0121 00006400
	.long 0xd72c001d                                           // 00000045A9BC: D72C001D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v29, vcc_lo              // 00000045A9C0: 02023AFF 83DCD12D
	v_bfe_u32 v25, v22, 6, 16                                  // 00000045A9C8: D6100019 02410D16
	v_dot2acc_f32_f16 v101, v159, v14                          // 00000045A9D0: 04CA1D9F
	v_and_b32_e32 v46, 0xffff, v46                             // 00000045A9D4: 365C5CFF 0000FFFF
	v_sad_u8 v160, v160, 0, 0x6400                             // 00000045A9DC: D62200A0 03FD01A0 00006400
	v_sad_u8 v154, v154, 0, 0x6400                             // 00000045A9E8: D622009A 03FD019A 00006400
	v_bfe_u32 v159, v43, 3, 16                                 // 00000045A9F4: D610009F 0241072B
	.long 0xd72c0019                                           // 00000045A9FC: D72C0019
	v_cndmask_b32_e32 v1, 0x83dcd12d, v25, vcc_lo              // 00000045AA00: 020232FF 83DCD12D
	v_sad_u8 v29, v29, 0, 0x6400                               // 00000045AA08: D622001D 03FD011D 00006400
	v_dual_dot2acc_f32_f16 v101, v157, v15 :: v_dual_lshlrev_b32 v160, 16, v160// 00000045AA14: CB221F9D 65A14090
	.long 0xd72c002e                                           // 00000045AA1C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000045AA20: 02025CFF 83DCD12D
	v_bfe_u32 v157, v43, 9, 16                                 // 00000045AA28: D610009D 0241132B
	v_dot2acc_f32_f16 v112, v47, v9                            // 00000045AA30: 04E0132F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045AA34: BF870004
	v_and_or_b32 v154, 0xffff, v154, v160                      // 00000045AA38: D657009A 068334FF 0000FFFF
	v_sad_u8 v25, v25, 0, 0x6400                               // 00000045AA44: D6220019 03FD0119 00006400
	v_dot2acc_f32_f16 v109, v47, v13                           // 00000045AA50: 04DA1B2F
	.long 0xd72c009d                                           // 00000045AA54: D72C009D
	v_cndmask_b32_e32 v1, 0x83dcd12d, v157, vcc_lo             // 00000045AA58: 02033AFF 83DCD12D
	v_add_nc_u32_e32 v116, 1, v116                             // 00000045AA60: 4AE8E881
	v_pk_fma_f16 v154, v154, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000045AA64: CC0E009A 0BFC0D9A 0000C931
	v_and_b32_e32 v160, 0xffff, v161                           // 00000045AA70: 374142FF 0000FFFF
	v_sad_u8 v161, v162, 0, 0x6400                             // 00000045AA78: D62200A1 03FD01A2 00006400
	v_dot2acc_f32_f16 v110, v155, v12                          // 00000045AA84: 04DC199B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000045AA88: BF870224
	v_dual_dot2acc_f32_f16 v101, v155, v16 :: v_dual_dot2acc_f32_f16 v112, v154, v10// 00000045AA8C: CB18219B 6570159A
	v_dot2acc_f32_f16 v113, v154, v2                           // 00000045AA94: 04E2059A
	v_lshl_or_b32 v156, v161, 16, v160                         // 00000045AA98: D656009C 068121A1
	v_bfe_u32 v155, v42, 9, 16                                 // 00000045AAA0: D610009B 0241132A
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000045AAA8: D622002E 03FD012E 00006400
	v_dot2acc_f32_f16 v107, v154, v6                           // 00000045AAB4: 04D60D9A
	v_sad_u8 v157, v157, 0, 0x6400                             // 00000045AAB8: D622009D 03FD019D 00006400
	v_pk_fma_f16 v156, v156, s6, 0xc931 op_sel_hi:[1,0,0]      // 00000045AAC4: CC0E009C 0BFC0D9C 0000C931
	.long 0xd72c002c                                           // 00000045AAD0: D72C002C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 00000045AAD4: 020336FF 83DCD12D
	v_and_b32_e32 v155, 0xffff, v42                            // 00000045AADC: 373654FF 0000FFFF
	v_lshlrev_b32_e32 v46, 16, v46                             // 00000045AAE4: 305C5C90
	v_bfe_u32 v42, v42, 3, 16                                  // 00000045AAE8: D610002A 0241072A
	v_dot2acc_f32_f16 v113, v156, v3                           // 00000045AAF0: 04E2079C
	v_dot2acc_f32_f16 v112, v156, v11                          // 00000045AAF4: 04E0179C
	.long 0xd72c009b                                           // 00000045AAF8: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 00000045AAFC: 020336FF 83DCD12D
	v_dot2acc_f32_f16 v107, v156, v7                           // 00000045AB04: 04D60F9C
	v_sad_u8 v44, v44, 0, 0x6400                               // 00000045AB08: D622002C 03FD012C 00006400
	v_and_or_b32 v46, 0xffff, v158, v46                        // 00000045AB14: D657002E 04BB3CFF 0000FFFF
	.long 0xd72c002a                                           // 00000045AB20: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000045AB24: 020254FF 83DCD12D
	v_bfe_u32 v158, v43, 6, 16                                 // 00000045AB2C: D610009E 02410D2B
	v_add_nc_u32_e32 v118, 32, v118                            // 00000045AB34: 4AECECA0
	v_and_b32_e32 v44, 0xffff, v44                             // 00000045AB38: 365858FF 0000FFFF
	v_pk_fma_f16 v46, v46, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AB40: CC0E002E 0BFC0D2E 0000C931
	v_sad_u8 v155, v155, 0, 0x6400                             // 00000045AB4C: D622009B 03FD019B 00006400
	.long 0xd72c009e                                           // 00000045AB58: D72C009E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v158, vcc_lo             // 00000045AB5C: 02033CFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000045AB64: BF8701B4
	v_lshl_or_b32 v44, v45, 16, v44                            // 00000045AB68: D656002C 04B1212D
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000045AB70: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v112, v46, v12                           // 00000045AB7C: 04E0192E
	v_pk_fma_f16 v44, v44, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AB80: CC0E002C 0BFC0D2C 0000C931
	v_dot2acc_f32_f16 v113, v46, v4                            // 00000045AB8C: 04E2092E
	v_dot2acc_f32_f16 v107, v46, v8                            // 00000045AB90: 04D6112E
	v_sad_u8 v158, v158, 0, 0x6400                             // 00000045AB94: D622009E 03FD019E 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045ABA0: BF870004
	v_dual_dot2acc_f32_f16 v108, v44, v1 :: v_dual_lshlrev_b32 v45, 16, v155// 00000045ABA4: CB22032C 6C2D3690
	v_dot2acc_f32_f16 v92, v44, v5                             // 00000045ABAC: 04B80B2C
	.long 0xd72c009b                                           // 00000045ABB0: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v159, vcc_lo             // 00000045ABB4: 02033EFF 83DCD12D
	v_dot2acc_f32_f16 v106, v44, v9                            // 00000045ABBC: 04D4132C
	v_dot2acc_f32_f16 v105, v44, v13                           // 00000045ABC0: 04D21B2C
	v_and_or_b32 v42, 0xffff, v42, v45                         // 00000045ABC4: D657002A 04B654FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045ABD0: BF870241
	v_pk_fma_f16 v42, v42, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045ABD4: CC0E002A 0BFC0D2A 0000C931
	v_and_b32_e32 v43, 0xffff, v43                             // 00000045ABE0: 365656FF 0000FFFF
	v_sad_u8 v47, v155, 0, 0x6400                              // 00000045ABE8: D622002F 03FD019B 00006400
	v_bfe_u32 v155, v39, 3, 16                                 // 00000045ABF4: D610009B 02410727
	v_dual_dot2acc_f32_f16 v92, v42, v6 :: v_dual_and_b32 v157, 0xffff, v157// 00000045ABFC: CB240D2A 5C9D3AFF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045AC08: BF870004
	.long 0xd72c002b                                           // 00000045AC0C: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000045AC10: 020256FF 83DCD12D
	v_dot2acc_f32_f16 v108, v42, v2                            // 00000045AC18: 04D8052A
	v_dot2acc_f32_f16 v106, v42, v10                           // 00000045AC1C: 04D4152A
	v_dot2acc_f32_f16 v105, v42, v14                           // 00000045AC20: 04D21D2A
	v_lshl_or_b32 v45, v158, 16, v157                          // 00000045AC24: D656002D 0675219E
	.long 0xd72c009b                                           // 00000045AC2C: D72C009B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v155, vcc_lo             // 00000045AC30: 020336FF 83DCD12D
	v_bfe_u32 v42, v34, 9, 16                                  // 00000045AC38: D610002A 02411322
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000045AC40: D622002B 03FD012B 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045AC4C: BF870004
	v_pk_fma_f16 v45, v45, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AC50: CC0E002D 0BFC0D2D 0000C931
	v_dot2acc_f32_f16 v109, v154, v14                          // 00000045AC5C: 04DA1D9A
	v_bfe_u32 v154, v39, 6, 16                                 // 00000045AC60: D610009A 02410D27
	.long 0xd72c0024                                           // 00000045AC68: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000045AC6C: 020254FF 83DCD12D
	v_lshlrev_b32_e32 v43, 16, v43                             // 00000045AC74: 30565690
	v_dot2acc_f32_f16 v108, v45, v3                            // 00000045AC78: 04D8072D
	v_dot2acc_f32_f16 v109, v156, v15                          // 00000045AC7C: 04DA1F9C
	v_dot2acc_f32_f16 v92, v45, v7                             // 00000045AC80: 04B80F2D
	.long 0xd72c009a                                           // 00000045AC84: D72C009A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v154, vcc_lo             // 00000045AC88: 020334FF 83DCD12D
	v_and_or_b32 v43, 0xffff, v47, v43                         // 00000045AC90: D657002B 04AE5EFF 0000FFFF
	v_bfe_u32 v47, v39, 9, 16                                  // 00000045AC9C: D610002F 02411327
	v_and_b32_e32 v39, 0xffff, v39                             // 00000045ACA4: 364E4EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v109, v46, v16 :: v_dual_dot2acc_f32_f16 v106, v45, v11// 00000045ACAC: CB18212E 6D6A172D
	v_bfe_u32 v46, v38, 9, 16                                  // 00000045ACB4: D610002E 02411326
	v_pk_fma_f16 v43, v43, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045ACBC: CC0E002B 0BFC0D2B 0000C931
	.long 0xd72c002f                                           // 00000045ACC8: D72C002F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v47, vcc_lo              // 00000045ACCC: 02025EFF 83DCD12D
	.long 0xd72c0027                                           // 00000045ACD4: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000045ACD8: 02024EFF 83DCD12D
	v_sad_u8 v44, v154, 0, 0x6400                              // 00000045ACE0: D622002C 03FD019A 00006400
	.long 0xd72c0029                                           // 00000045ACEC: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000045ACF0: 02025CFF 83DCD12D
	v_bfe_u32 v46, v38, 6, 16                                  // 00000045ACF8: D610002E 02410D26
	v_dual_dot2acc_f32_f16 v108, v43, v4 :: v_dual_dot2acc_f32_f16 v105, v45, v15// 00000045AD00: CB18092B 6C681F2D
	v_dot2acc_f32_f16 v106, v43, v12                           // 00000045AD08: 04D4192B
	v_sad_u8 v47, v47, 0, 0x6400                               // 00000045AD0C: D622002F 03FD012F 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045AD18: BF870004
	.long 0xd72c002e                                           // 00000045AD1C: D72C002E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v46, vcc_lo              // 00000045AD20: 02025CFF 83DCD12D
	v_sad_u8 v39, v39, 0, 0x6400                               // 00000045AD28: D6220027 03FD0127 00006400
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000045AD34: D6220029 03FD0129 00006400
	v_dot2acc_f32_f16 v92, v43, v8                             // 00000045AD40: 04B8112B
	v_dot2acc_f32_f16 v105, v43, v16                           // 00000045AD44: 04D2212B
	v_bfe_u32 v42, v35, 9, 16                                  // 00000045AD48: D610002A 02411323
	v_bfe_u32 v43, v35, 6, 16                                  // 00000045AD50: D610002B 02410D23
	v_and_b32_e32 v41, 0xffff, v41                             // 00000045AD58: 365252FF 0000FFFF
	v_sad_u8 v46, v46, 0, 0x6400                               // 00000045AD60: D622002E 03FD012E 00006400
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000045AD6C: D6220024 03FD0124 00006400
	.long 0xd72c002a                                           // 00000045AD78: D72C002A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v42, vcc_lo              // 00000045AD7C: 020254FF 83DCD12D
	.long 0xd72c002b                                           // 00000045AD84: D72C002B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v43, vcc_lo              // 00000045AD88: 020256FF 83DCD12D
	v_mov_b32_e32 v45, v65                                     // 00000045AD90: 7E5A0341
	v_lshl_or_b32 v41, v46, 16, v41                            // 00000045AD94: D6560029 04A5212E
	v_sad_u8 v46, v155, 0, 0x6400                              // 00000045AD9C: D622002E 03FD019B 00006400
	s_waitcnt vmcnt(13)                                        // 00000045ADA8: BF8937F7
	v_dual_mov_b32 v65, v131 :: v_dual_and_b32 v36, 0xffff, v36// 00000045ADAC: CA240183 412448FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000045ADB8: BF870003
	v_pk_fma_f16 v41, v41, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045ADBC: CC0E0029 0BFC0D29 0000C931
	v_and_b32_e32 v40, 0xffff, v38                             // 00000045ADC8: 36504CFF 0000FFFF
	v_bfe_u32 v38, v38, 3, 16                                  // 00000045ADD0: D6100026 02410726
	v_lshlrev_b32_e32 v39, 16, v39                             // 00000045ADD8: 304E4E90
	v_sad_u8 v42, v42, 0, 0x6400                               // 00000045ADDC: D622002A 03FD012A 00006400
	v_dot2acc_f32_f16 v103, v41, v1                            // 00000045ADE8: 04CE0329
	.long 0xd72c0028                                           // 00000045ADEC: D72C0028
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000045ADF0: 020250FF 83DCD12D
	.long 0xd72c0026                                           // 00000045ADF8: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000045ADFC: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v104, v41, v5                            // 00000045AE04: 04D00B29
	v_and_or_b32 v39, 0xffff, v46, v39                         // 00000045AE08: D6570027 049E5CFF 0000FFFF
	v_lshl_or_b32 v36, v37, 16, v36                            // 00000045AE14: D6560024 04912125
	v_sad_u8 v43, v43, 0, 0x6400                               // 00000045AE1C: D622002B 03FD012B 00006400
	v_mov_b32_e32 v46, v74                                     // 00000045AE28: 7E5C034A
	s_waitcnt vmcnt(6)                                         // 00000045AE2C: BF891BF7
	v_mov_b32_e32 v74, v136                                    // 00000045AE30: 7E940388
	v_sad_u8 v40, v40, 0, 0x6400                               // 00000045AE34: D6220028 03FD0128 00006400
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000045AE40: D6220026 03FD0126 00006400
	v_pk_fma_f16 v39, v39, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AE4C: CC0E0027 0BFC0D27 0000C931
	v_pk_fma_f16 v36, v36, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AE58: CC0E0024 0BFC0D24 0000C931
	v_and_b32_e32 v42, 0xffff, v42                             // 00000045AE64: 365454FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000045AE6C: BF870122
	v_dual_dot2acc_f32_f16 v99, v36, v5 :: v_dual_lshlrev_b32 v40, 16, v40// 00000045AE70: CB220B24 63285090
	v_dot2acc_f32_f16 v97, v36, v9                             // 00000045AE78: 04C21324
	v_and_or_b32 v38, 0xffff, v38, v40                         // 00000045AE7C: D6570026 04A24CFF 0000FFFF
	v_dot2acc_f32_f16 v96, v36, v13                            // 00000045AE88: 04C01B24
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000045AE8C: BF8701B2
	v_pk_fma_f16 v38, v38, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AE90: CC0E0026 0BFC0D26 0000C931
	v_dual_mov_b32 v47, v67 :: v_dual_and_b32 v40, 0xffff, v47 // 00000045AE9C: CA240143 2F285EFF 0000FFFF
	v_mov_b32_e32 v67, v132                                    // 00000045AEA8: 7E860384
	v_dot2acc_f32_f16 v103, v38, v2                            // 00000045AEAC: 04CE0526
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045AEB0: BF870243
	v_lshl_or_b32 v40, v44, 16, v40                            // 00000045AEB4: D6560028 04A1212C
	v_dot2acc_f32_f16 v104, v38, v6                            // 00000045AEBC: 04D00D26
	v_bfe_u32 v44, v35, 3, 16                                  // 00000045AEC0: D610002C 02410723
	v_and_b32_e32 v35, 0xffff, v35                             // 00000045AEC8: 364646FF 0000FFFF
	v_pk_fma_f16 v40, v40, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AED0: CC0E0028 0BFC0D28 0000C931
	v_dot2acc_f32_f16 v102, v41, v9                            // 00000045AEDC: 04CC1329
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045AEE0: BF870193
	.long 0xd72c0023                                           // 00000045AEE4: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000045AEE8: 020246FF 83DCD12D
	v_dot2acc_f32_f16 v104, v40, v7                            // 00000045AEF0: 04D00F28
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045AEF4: BF870113
	v_dual_dot2acc_f32_f16 v103, v40, v3 :: v_dual_dot2acc_f32_f16 v102, v38, v10// 00000045AEF8: CB180728 67661526
	v_dot2acc_f32_f16 v104, v39, v8                            // 00000045AF00: 04D01127
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000045AF04: BF8701C4
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000045AF08: D6220023 03FD0123 00006400
	v_dual_dot2acc_f32_f16 v100, v41, v13 :: v_dual_and_b32 v41, 0xffff, v34// 00000045AF14: CB241B29 642844FF 0000FFFF
	v_bfe_u32 v34, v34, 3, 16                                  // 00000045AF20: D6100022 02410722
	v_dot2acc_f32_f16 v103, v39, v4                            // 00000045AF28: 04CE0927
	v_dual_dot2acc_f32_f16 v100, v38, v14 :: v_dual_lshlrev_b32 v35, 16, v35// 00000045AF2C: CB221D26 64224690
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045AF34: BF870214
	.long 0xd72c0029                                           // 00000045AF38: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v41, vcc_lo              // 00000045AF3C: 020252FF 83DCD12D
	.long 0xd72c0022                                           // 00000045AF44: D72C0022
	v_cndmask_b32_e32 v1, 0x83dcd12d, v34, vcc_lo              // 00000045AF48: 020244FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045AF50: BF8701A2
	v_sad_u8 v41, v41, 0, 0x6400                               // 00000045AF54: D6220029 03FD0129 00006400
	v_dot2acc_f32_f16 v102, v40, v11                           // 00000045AF60: 04CC1728
	v_sad_u8 v34, v34, 0, 0x6400                               // 00000045AF64: D6220022 03FD0122 00006400
	s_delay_alu instid0(VALU_DEP_3)                            // 00000045AF70: BF870003
	v_lshlrev_b32_e32 v37, 16, v41                             // 00000045AF74: 304A5290
	.long 0xd72c0029                                           // 00000045AF78: D72C0029
	v_cndmask_b32_e32 v1, 0x83dcd12d, v44, vcc_lo              // 00000045AF7C: 020258FF 83DCD12D
	v_mov_b32_e32 v44, v72                                     // 00000045AF84: 7E580348
	s_waitcnt vmcnt(5)                                         // 00000045AF88: BF8917F7
	v_mov_b32_e32 v72, v135                                    // 00000045AF8C: 7E900387
	v_and_or_b32 v34, 0xffff, v34, v37                         // 00000045AF90: D6570022 049644FF 0000FFFF
	v_lshl_or_b32 v37, v43, 16, v42                            // 00000045AF9C: D6560025 04A9212B
	v_mov_b32_e32 v42, v61                                     // 00000045AFA4: 7E54033D
	v_mov_b32_e32 v43, v53                                     // 00000045AFA8: 7E560335
	v_sad_u8 v38, v41, 0, 0x6400                               // 00000045AFAC: D6220026 03FD0129 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AFB8: CC0E0022 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v98, v36, v1                             // 00000045AFC4: 04C40324
	v_pk_fma_f16 v37, v37, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AFC8: CC0E0025 0BFC0D25 0000C931
	v_mov_b32_e32 v41, v63                                     // 00000045AFD4: 7E52033F
	v_and_or_b32 v35, 0xffff, v38, v35                         // 00000045AFD8: D6570023 048E4CFF 0000FFFF
	v_dot2acc_f32_f16 v99, v34, v6                             // 00000045AFE4: 04C60D22
	v_dot2acc_f32_f16 v97, v34, v10                            // 00000045AFE8: 04C21522
	v_dot2acc_f32_f16 v98, v34, v2                             // 00000045AFEC: 04C40522
	v_dot2acc_f32_f16 v102, v39, v12                           // 00000045AFF0: 04CC1927
	v_pk_fma_f16 v35, v35, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045AFF4: CC0E0023 0BFC0D23 0000C931
	v_dot2acc_f32_f16 v99, v37, v7                             // 00000045B000: 04C60F25
	v_dot2acc_f32_f16 v100, v40, v15                           // 00000045B004: 04C81F28
	v_bfe_u32 v38, v30, 9, 16                                  // 00000045B008: D6100026 0241131E
	v_dot2acc_f32_f16 v97, v37, v11                            // 00000045B010: 04C21725
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045B014: BF870214
	v_dual_dot2acc_f32_f16 v98, v37, v3 :: v_dual_dot2acc_f32_f16 v99, v35, v8// 00000045B018: CB180725 62621123
	v_dual_dot2acc_f32_f16 v100, v39, v16 :: v_dual_and_b32 v39, 0xffff, v30// 00000045B020: CB242127 64263CFF 0000FFFF
	v_bfe_u32 v30, v30, 3, 16                                  // 00000045B02C: D610001E 0241071E
	.long 0xd72c0020                                           // 00000045B034: D72C0020
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000045B038: 02024CFF 83DCD12D
	v_dot2acc_f32_f16 v97, v35, v12                            // 00000045B040: 04C21923
	v_dot2acc_f32_f16 v98, v35, v4                             // 00000045B044: 04C40923
	.long 0xd72c0024                                           // 00000045B048: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000045B04C: 02024EFF 83DCD12D
	.long 0xd72c001e                                           // 00000045B054: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000045B058: 02023CFF 83DCD12D
	v_bfe_u32 v38, v31, 9, 16                                  // 00000045B060: D6100026 0241131F
	v_bfe_u32 v39, v31, 6, 16                                  // 00000045B068: D6100027 02410D1F
	v_bfe_u32 v40, v31, 3, 16                                  // 00000045B070: D6100028 0241071F
	v_sad_u8 v32, v32, 0, 0x6400                               // 00000045B078: D6220020 03FD0120 00006400
	v_and_b32_e32 v31, 0xffff, v31                             // 00000045B084: 363E3EFF 0000FFFF
	.long 0xd72c0026                                           // 00000045B08C: D72C0026
	v_cndmask_b32_e32 v1, 0x83dcd12d, v38, vcc_lo              // 00000045B090: 02024CFF 83DCD12D
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000045B098: D6220024 03FD0124 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000045B0A4: D622001E 03FD011E 00006400
	.long 0xd72c0027                                           // 00000045B0B0: D72C0027
	v_cndmask_b32_e32 v1, 0x83dcd12d, v39, vcc_lo              // 00000045B0B4: 02024EFF 83DCD12D
	.long 0xd72c001f                                           // 00000045B0BC: D72C001F
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000045B0C0: 02023EFF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045B0C8: BF870244
	v_dual_mov_b32 v63, v129 :: v_dual_lshlrev_b32 v36, 16, v36// 00000045B0CC: CA220181 3F244890
	v_mov_b32_e32 v61, v127                                    // 00000045B0D4: 7E7A037F
	v_sad_u8 v38, v38, 0, 0x6400                               // 00000045B0D8: D6220026 03FD0126 00006400
	v_mov_b32_e32 v53, v123                                    // 00000045B0E4: 7E6A037B
	v_and_or_b32 v30, 0xffff, v30, v36                         // 00000045B0E8: D657001E 04923CFF 0000FFFF
	v_sad_u8 v31, v31, 0, 0x6400                               // 00000045B0F4: D622001F 03FD011F 00006400
	v_sad_u8 v36, v39, 0, 0x6400                               // 00000045B100: D6220024 03FD0127 00006400
	v_dual_mov_b32 v39, v52 :: v_dual_mov_b32 v52, v122        // 00000045B10C: CA100134 2734017A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000045B114: BF870134
	v_pk_fma_f16 v30, v30, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B118: CC0E001E 0BFC0D1E 0000C931
	v_and_b32_e32 v32, 0xffff, v32                             // 00000045B124: 364040FF 0000FFFF
	v_lshlrev_b32_e32 v31, 16, v31                             // 00000045B12C: 303E3E90
	v_lshl_or_b32 v32, v33, 16, v32                            // 00000045B130: D6560020 04812121
	.long 0xd72c0021                                           // 00000045B138: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v40, vcc_lo              // 00000045B13C: 020250FF 83DCD12D
	v_mov_b32_e32 v40, v69                                     // 00000045B144: 7E500345
	s_waitcnt vmcnt(4)                                         // 00000045B148: BF8913F7
	v_mov_b32_e32 v69, v133                                    // 00000045B14C: 7E8A0385
	v_pk_fma_f16 v32, v32, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B150: CC0E0020 0BFC0D20 0000C931
	v_dot2acc_f32_f16 v96, v34, v14                            // 00000045B15C: 04C01D22
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000045B160: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045B16C: BF870193
	v_dot2acc_f32_f16 v95, v32, v5                             // 00000045B170: 04BE0B20
	v_dual_dot2acc_f32_f16 v93, v32, v9 :: v_dual_dot2acc_f32_f16 v96, v37, v15// 00000045B174: CB181320 5D601F25
	v_dot2acc_f32_f16 v91, v32, v13                            // 00000045B17C: 04B61B20
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045B180: BF870004
	v_and_or_b32 v31, 0xffff, v33, v31                         // 00000045B184: D657001F 047E42FF 0000FFFF
	v_bfe_u32 v33, v26, 9, 16                                  // 00000045B190: D6100021 0241131A
	v_dot2acc_f32_f16 v95, v30, v6                             // 00000045B198: 04BE0D1E
	v_dot2acc_f32_f16 v93, v30, v10                            // 00000045B19C: 04BA151E
	v_bfe_u32 v37, v27, 3, 16                                  // 00000045B1A0: D6100025 0241071B
	v_pk_fma_f16 v31, v31, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B1A8: CC0E001F 0BFC0D1F 0000C931
	v_and_b32_e32 v34, 0xffff, v38                             // 00000045B1B4: 36444CFF 0000FFFF
	.long 0xd72c001c                                           // 00000045B1BC: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000045B1C0: 020242FF 83DCD12D
	v_and_b32_e32 v33, 0xffff, v26                             // 00000045B1C8: 364234FF 0000FFFF
	v_bfe_u32 v26, v26, 3, 16                                  // 00000045B1D0: D610001A 0241071A
	v_mov_b32_e32 v38, v60                                     // 00000045B1D8: 7E4C033C
	v_lshl_or_b32 v34, v36, 16, v34                            // 00000045B1DC: D6560022 04892124
	v_bfe_u32 v36, v27, 6, 16                                  // 00000045B1E4: D6100024 02410D1B
	.long 0xd72c0021                                           // 00000045B1EC: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v33, vcc_lo              // 00000045B1F0: 020242FF 83DCD12D
	.long 0xd72c001a                                           // 00000045B1F8: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000045B1FC: 020234FF 83DCD12D
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000045B204: D622001C 03FD011C 00006400
	v_pk_fma_f16 v34, v34, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B210: CC0E0022 0BFC0D22 0000C931
	v_dot2acc_f32_f16 v94, v32, v1                             // 00000045B21C: 04BC0320
	v_dot2acc_f32_f16 v96, v35, v16                            // 00000045B220: 04C02123
	v_bfe_u32 v35, v27, 9, 16                                  // 00000045B224: D6100023 0241131B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000045B22C: BF870234
	v_dual_dot2acc_f32_f16 v95, v34, v7 :: v_dual_and_b32 v28, 0xffff, v28// 00000045B230: CB240F22 5F1C38FF 0000FFFF
	v_dot2acc_f32_f16 v93, v34, v11                            // 00000045B23C: 04BA1722
	v_dot2acc_f32_f16 v94, v30, v2                             // 00000045B240: 04BC051E
	.long 0xd72c0023                                           // 00000045B244: D72C0023
	v_cndmask_b32_e32 v1, 0x83dcd12d, v35, vcc_lo              // 00000045B248: 020246FF 83DCD12D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000045B250: BF870224
	v_lshl_or_b32 v28, v29, 16, v28                            // 00000045B254: D656001C 0471211D
	v_and_b32_e32 v27, 0xffff, v27                             // 00000045B25C: 363636FF 0000FFFF
	v_dual_dot2acc_f32_f16 v93, v31, v12 :: v_dual_dot2acc_f32_f16 v94, v34, v3// 00000045B264: CB18191F 5D5E0722
	v_sad_u8 v33, v33, 0, 0x6400                               // 00000045B26C: D6220021 03FD0121 00006400
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045B278: BF870214
	v_pk_fma_f16 v28, v28, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B27C: CC0E001C 0BFC0D1C 0000C931
	.long 0xd72c001b                                           // 00000045B288: D72C001B
	v_cndmask_b32_e32 v1, 0x83dcd12d, v27, vcc_lo              // 00000045B28C: 020236FF 83DCD12D
	v_sad_u8 v35, v35, 0, 0x6400                               // 00000045B294: D6220023 03FD0123 00006400
	v_dot2acc_f32_f16 v94, v31, v4                             // 00000045B2A0: 04BC091F
	.long 0xd72c0024                                           // 00000045B2A4: D72C0024
	v_cndmask_b32_e32 v1, 0x83dcd12d, v36, vcc_lo              // 00000045B2A8: 020248FF 83DCD12D
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000045B2B0: D622001A 03FD011A 00006400
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045B2BC: BF870004
	v_dual_dot2acc_f32_f16 v90, v28, v5 :: v_dual_and_b32 v35, 0xffff, v35// 00000045B2C0: CB240B1C 5A2246FF 0000FFFF
	v_lshlrev_b32_e32 v29, 16, v33                             // 00000045B2CC: 303A4290
	.long 0xd72c0021                                           // 00000045B2D0: D72C0021
	v_cndmask_b32_e32 v1, 0x83dcd12d, v37, vcc_lo              // 00000045B2D4: 02024AFF 83DCD12D
	v_sad_u8 v27, v27, 0, 0x6400                               // 00000045B2DC: D622001B 03FD011B 00006400
	v_dot2acc_f32_f16 v88, v28, v9                             // 00000045B2E8: 04B0131C
	v_sad_u8 v36, v36, 0, 0x6400                               // 00000045B2EC: D6220024 03FD0124 00006400
	v_and_or_b32 v26, 0xffff, v26, v29                         // 00000045B2F8: D657001A 047634FF 0000FFFF
	v_dot2acc_f32_f16 v87, v28, v13                            // 00000045B304: 04AE1B1C
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000045B308: 30363690
	v_dot2acc_f32_f16 v95, v31, v8                             // 00000045B30C: 04BE111F
	v_lshl_or_b32 v29, v36, 16, v35                            // 00000045B310: D656001D 048D2124
	v_pk_fma_f16 v26, v26, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B318: CC0E001A 0BFC0D1A 0000C931
	v_dot2acc_f32_f16 v89, v28, v1                             // 00000045B324: 04B2031C
	v_bfe_u32 v28, v22, 9, 16                                  // 00000045B328: D610001C 02411316
	v_sad_u8 v32, v33, 0, 0x6400                               // 00000045B330: D6220020 03FD0121 00006400
	v_pk_fma_f16 v29, v29, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B33C: CC0E001D 0BFC0D1D 0000C931
	v_dot2acc_f32_f16 v90, v26, v6                             // 00000045B348: 04B40D1A
	v_dot2acc_f32_f16 v91, v30, v14                            // 00000045B34C: 04B61D1E
	.long 0xd72c0018                                           // 00000045B350: D72C0018
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000045B354: 020238FF 83DCD12D
	v_bfe_u32 v28, v23, 9, 16                                  // 00000045B35C: D610001C 02411317
	v_and_or_b32 v27, 0xffff, v32, v27                         // 00000045B364: D657001B 046E40FF 0000FFFF
	v_dot2acc_f32_f16 v90, v29, v7                             // 00000045B370: 04B40F1D
	v_dot2acc_f32_f16 v88, v26, v10                            // 00000045B374: 04B0151A
	v_dot2acc_f32_f16 v89, v26, v2                             // 00000045B378: 04B2051A
	.long 0xd72c001c                                           // 00000045B37C: D72C001C
	v_cndmask_b32_e32 v1, 0x83dcd12d, v28, vcc_lo              // 00000045B380: 020238FF 83DCD12D
	v_pk_fma_f16 v27, v27, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B388: CC0E001B 0BFC0D1B 0000C931
	v_dot2acc_f32_f16 v91, v34, v15                            // 00000045B394: 04B61F22
	v_sad_u8 v24, v24, 0, 0x6400                               // 00000045B398: D6220018 03FD0118 00006400
	v_bfe_u32 v30, v23, 6, 16                                  // 00000045B3A4: D610001E 02410D17
	v_dot2acc_f32_f16 v88, v29, v11                            // 00000045B3AC: 04B0171D
	v_dot2acc_f32_f16 v90, v27, v8                             // 00000045B3B0: 04B4111B
	v_dot2acc_f32_f16 v91, v31, v16                            // 00000045B3B4: 04B6211F
	v_and_b32_e32 v24, 0xffff, v24                             // 00000045B3B8: 363030FF 0000FFFF
	v_sad_u8 v28, v28, 0, 0x6400                               // 00000045B3C0: D622001C 03FD011C 00006400
	v_dot2acc_f32_f16 v87, v26, v14                            // 00000045B3CC: 04AE1D1A
	v_and_b32_e32 v26, 0xffff, v22                             // 00000045B3D0: 36342CFF 0000FFFF
	v_bfe_u32 v22, v22, 3, 16                                  // 00000045B3D8: D6100016 02410716
	v_lshl_or_b32 v24, v25, 16, v24                            // 00000045B3E0: D6560018 04612119
	v_bfe_u32 v31, v23, 3, 16                                  // 00000045B3E8: D610001F 02410717
	.long 0xd72c001e                                           // 00000045B3F0: D72C001E
	v_cndmask_b32_e32 v1, 0x83dcd12d, v30, vcc_lo              // 00000045B3F4: 02023CFF 83DCD12D
	.long 0xd72c001a                                           // 00000045B3FC: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v26, vcc_lo              // 00000045B400: 020234FF 83DCD12D
	.long 0xd72c0016                                           // 00000045B408: D72C0016
	v_cndmask_b32_e32 v1, 0x83dcd12d, v22, vcc_lo              // 00000045B40C: 02022CFF 83DCD12D
	v_pk_fma_f16 v24, v24, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B414: CC0E0018 0BFC0D18 0000C931
	v_and_b32_e32 v23, 0xffff, v23                             // 00000045B420: 362E2EFF 0000FFFF
	v_dual_dot2acc_f32_f16 v89, v29, v3 :: v_dual_and_b32 v28, 0xffff, v28// 00000045B428: CB24071D 591C38FF 0000FFFF
	v_dot2acc_f32_f16 v88, v27, v12                            // 00000045B434: 04B0191B
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045B438: BF870004
	v_dot2acc_f32_f16 v84, v24, v9                             // 00000045B43C: 04A81318
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000045B440: D622001A 03FD011A 00006400
	.long 0xd72c0017                                           // 00000045B44C: D72C0017
	v_cndmask_b32_e32 v1, 0x83dcd12d, v23, vcc_lo              // 00000045B450: 02022EFF 83DCD12D
	v_sad_u8 v22, v22, 0, 0x6400                               // 00000045B458: D6220016 03FD0116 00006400
	v_sad_u8 v30, v30, 0, 0x6400                               // 00000045B464: D622001E 03FD011E 00006400
	v_dual_dot2acc_f32_f16 v89, v27, v4 :: v_dual_dot2acc_f32_f16 v86, v24, v5// 00000045B470: CB18091B 59560B18
	v_lshlrev_b32_e32 v25, 16, v26                             // 00000045B478: 30323490
	.long 0xd72c001a                                           // 00000045B47C: D72C001A
	v_cndmask_b32_e32 v1, 0x83dcd12d, v31, vcc_lo              // 00000045B480: 02023EFF 83DCD12D
	v_dot2acc_f32_f16 v85, v24, v1                             // 00000045B488: 04AA0318
	v_sad_u8 v23, v23, 0, 0x6400                               // 00000045B48C: D6220017 03FD0117 00006400
	v_mov_b32_e32 v9, v75                                      // 00000045B498: 7E12034B
	v_and_or_b32 v22, 0xffff, v22, v25                         // 00000045B49C: D6570016 04662CFF 0000FFFF
	v_lshl_or_b32 v25, v30, 16, v28                            // 00000045B4A8: D6560019 0471211E
	v_dual_mov_b32 v60, v126 :: v_dual_mov_b32 v75, v137       // 00000045B4B0: CA10017E 3C4A0189
	v_mov_b32_e32 v30, v148                                    // 00000045B4B8: 7E3C0394
	v_sad_u8 v26, v26, 0, 0x6400                               // 00000045B4BC: D622001A 03FD011A 00006400
	v_pk_fma_f16 v22, v22, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B4C8: CC0E0016 0BFC0D16 0000C931
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000045B4D4: 302E2E90
	v_pk_fma_f16 v25, v25, s6, 0xc931 op_sel_hi:[1,0,0]        // 00000045B4D8: CC0E0019 0BFC0D19 0000C931
	v_dot2acc_f32_f16 v87, v29, v15                            // 00000045B4E4: 04AE1F1D
	v_dual_mov_b32 v35, v153 :: v_dual_mov_b32 v28, v142       // 00000045B4E8: CA100199 231C018E
	v_dot2acc_f32_f16 v84, v22, v10                            // 00000045B4F0: 04A81516
	v_and_or_b32 v5, 0xffff, v26, v23                          // 00000045B4F4: D6570005 045E34FF 0000FFFF
	v_dual_dot2acc_f32_f16 v17, v24, v13 :: v_dual_dot2acc_f32_f16 v86, v22, v6// 00000045B500: CB181B18 11560D16
	v_dual_dot2acc_f32_f16 v85, v22, v2 :: v_dual_add_nc_u32 v2, v115, v116// 00000045B508: CB200516 5502E973
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045B510: BF870193
	v_pk_fma_f16 v1, v5, s6, 0xc931 op_sel_hi:[1,0,0]          // 00000045B514: CC0E0001 0BFC0D05 0000C931
	v_dual_dot2acc_f32_f16 v84, v25, v11 :: v_dual_dot2acc_f32_f16 v17, v22, v14// 00000045B520: CB181719 54101D16
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045B528: BF870214
	v_dual_dot2acc_f32_f16 v87, v27, v16 :: v_dual_dot2acc_f32_f16 v86, v25, v7// 00000045B52C: CB18211B 57560F19
	v_dot2acc_f32_f16 v85, v25, v3                             // 00000045B534: 04AA0719
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045B538: BF870213
	v_dot2acc_f32_f16 v84, v1, v12                             // 00000045B53C: 04A81901
	v_dot2acc_f32_f16 v17, v25, v15                            // 00000045B540: 04221F19
	v_cmp_eq_u32_e32 vcc_lo, 2, v2                             // 00000045B544: 7C940482
	v_dot2acc_f32_f16 v86, v1, v8                              // 00000045B548: 04AC1101
	v_dot2acc_f32_f16 v85, v1, v4                              // 00000045B54C: 04AA0901
	v_dual_mov_b32 v13, v62 :: v_dual_mov_b32 v2, v55          // 00000045B550: CA10013E 0D020137
	v_dual_dot2acc_f32_f16 v17, v1, v16 :: v_dual_mov_b32 v14, v54// 00000045B558: CB102101 110E0136
	v_dual_mov_b32 v10, v71 :: v_dual_mov_b32 v1, v64          // 00000045B560: CA100147 0A000140
	v_mov_b32_e32 v62, v128                                    // 00000045B568: 7E7C0380
	v_dual_mov_b32 v54, v124 :: v_dual_mov_b32 v71, v134       // 00000045B56C: CA10017C 36460186
	v_mov_b32_e32 v26, v144                                    // 00000045B574: 7E340390
	v_dual_mov_b32 v64, v130 :: v_dual_mov_b32 v55, v125       // 00000045B578: CA100182 4036017D
	v_mov_b32_e32 v32, v146                                    // 00000045B580: 7E400392
	v_dual_mov_b32 v34, v152 :: v_dual_mov_b32 v37, v151       // 00000045B584: CA100198 22240197
	v_mov_b32_e32 v22, v140                                    // 00000045B58C: 7E2C038C
	v_dual_mov_b32 v36, v150 :: v_dual_mov_b32 v31, v149       // 00000045B590: CA100196 241E0195
	v_dual_mov_b32 v24, v138 :: v_dual_mov_b32 v33, v147       // 00000045B598: CA10018A 18200193
	v_mov_b32_e32 v27, v145                                    // 00000045B5A0: 7E360391
	v_mov_b32_e32 v29, v143                                    // 00000045B5A4: 7E3A038F
	v_mov_b32_e32 v23, v141                                    // 00000045B5A8: 7E2E038D
	v_mov_b32_e32 v25, v139                                    // 00000045B5AC: 7E32038B
	s_or_b32 s0, vcc_lo, s0                                    // 00000045B5B0: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045B5B4: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000045B5B8: 917E007E
	s_cbranch_execz 114                                        // 00000045B5BC: BFA50072 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2088>
	s_waitcnt vmcnt(19)                                        // 00000045B5C0: BF894FF7
	v_dual_mov_b32 v153, v56 :: v_dual_mov_b32 v152, v73       // 00000045B5C4: CA100138 99980149
	s_waitcnt vmcnt(11)                                        // 00000045B5CC: BF892FF7
	v_dual_mov_b32 v151, v79 :: v_dual_mov_b32 v148, v70       // 00000045B5D0: CA10014F 97940146
	s_waitcnt vmcnt(3)                                         // 00000045B5D8: BF890FF7
	v_dual_mov_b32 v150, v83 :: v_dual_mov_b32 v149, v57       // 00000045B5DC: CA100153 96940139
	v_dual_mov_b32 v147, v78 :: v_dual_mov_b32 v144, v68       // 00000045B5E4: CA10014E 93900144
	s_waitcnt vmcnt(2)                                         // 00000045B5EC: BF890BF7
	v_dual_mov_b32 v146, v82 :: v_dual_mov_b32 v143, v77       // 00000045B5F0: CA100152 928E014D
	s_waitcnt vmcnt(1)                                         // 00000045B5F8: BF8907F7
	v_dual_mov_b32 v145, v58 :: v_dual_mov_b32 v142, v81       // 00000045B5FC: CA10013A 918E0151
	v_dual_mov_b32 v141, v59 :: v_dual_mov_b32 v140, v66       // 00000045B604: CA10013B 8D8C0142
	v_mov_b32_e32 v139, v76                                    // 00000045B60C: 7F16034C
	s_waitcnt vmcnt(0)                                         // 00000045B610: BF8903F7
	v_mov_b32_e32 v138, v80                                    // 00000045B614: 7F140350
	s_mov_b32 s7, exec_lo                                      // 00000045B618: BE87007E
	.long 0xd4c1007e                                           // 00000045B61C: D4C1007E
	v_cndmask_b32_e32 v1, v116, v51, vcc_lo                    // 00000045B620: 02026774
	s_cbranch_execz 64510                                      // 00000045B624: BFA5FBFE <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xf20>
	v_mad_i64_i32 v[3:4], null, 0x300, v116, s[4:5]            // 00000045B628: D6FF7C03 0012E8FF 00000300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045B634: BF870091
	.long 0xd7006a05                                           // 00000045B638: D7006A05
	v_cndmask_b32_e32 v1, v3, v18, vcc_lo                      // 00000045B63C: 02022503
	v_add_co_ci_u32_e64 v6, null, v4, v19, vcc_lo              // 00000045B640: D5207C06 01AA2704
	.long 0xd7006a07                                           // 00000045B648: D7006A07
	v_cndmask_b32_e32 v1, v3, v120, vcc_lo                     // 00000045B64C: 0202F103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045B650: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 00000045B654: D5207C08 01AA0880
	.long 0xd7006a0b                                           // 00000045B65C: D7006A0B
	v_cndmask_b32_e32 v1, v3, v20, vcc_lo                      // 00000045B660: 02022903
	v_add_co_ci_u32_e64 v12, null, v4, v21, vcc_lo             // 00000045B664: D5207C0C 01AA2B04
	.long 0xd7006a03                                           // 00000045B66C: D7006A03
	v_cndmask_b32_e32 v1, v3, v121, vcc_lo                     // 00000045B670: 0202F303
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045B674: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000045B678: D5207C04 01AA0880
	s_clause 0x1f                                              // 00000045B680: BF85001F
	global_load_b32 v125, v[5:6], off                          // 00000045B684: DC520000 7D7C0005
	global_load_b32 v124, v[5:6], off offset:96                // 00000045B68C: DC520060 7C7C0005
	global_load_b32 v123, v[5:6], off offset:192               // 00000045B694: DC5200C0 7B7C0005
	global_load_b32 v122, v[5:6], off offset:288               // 00000045B69C: DC520120 7A7C0005
	global_load_b32 v56, v[5:6], off offset:384                // 00000045B6A4: DC520180 387C0005
	global_load_b32 v57, v[5:6], off offset:480                // 00000045B6AC: DC5201E0 397C0005
	global_load_b32 v58, v[5:6], off offset:576                // 00000045B6B4: DC520240 3A7C0005
	global_load_b32 v59, v[5:6], off offset:672                // 00000045B6BC: DC5202A0 3B7C0005
	global_load_b32 v130, v[7:8], off                          // 00000045B6C4: DC520000 827C0007
	global_load_b32 v128, v[7:8], off offset:96                // 00000045B6CC: DC520060 807C0007
	global_load_b32 v127, v[7:8], off offset:192               // 00000045B6D4: DC5200C0 7F7C0007
	global_load_b32 v126, v[7:8], off offset:288               // 00000045B6DC: DC520120 7E7C0007
	global_load_b32 v73, v[7:8], off offset:384                // 00000045B6E4: DC520180 497C0007
	global_load_b32 v70, v[7:8], off offset:480                // 00000045B6EC: DC5201E0 467C0007
	global_load_b32 v68, v[7:8], off offset:576                // 00000045B6F4: DC520240 447C0007
	global_load_b32 v66, v[7:8], off offset:672                // 00000045B6FC: DC5202A0 427C0007
	global_load_b32 v134, v[11:12], off                        // 00000045B704: DC520000 867C000B
	global_load_b32 v132, v[11:12], off offset:96              // 00000045B70C: DC520060 847C000B
	global_load_b32 v131, v[11:12], off offset:192             // 00000045B714: DC5200C0 837C000B
	global_load_b32 v129, v[11:12], off offset:288             // 00000045B71C: DC520120 817C000B
	global_load_b32 v79, v[11:12], off offset:384              // 00000045B724: DC520180 4F7C000B
	global_load_b32 v78, v[11:12], off offset:480              // 00000045B72C: DC5201E0 4E7C000B
	global_load_b32 v77, v[11:12], off offset:576              // 00000045B734: DC520240 4D7C000B
	global_load_b32 v76, v[11:12], off offset:672              // 00000045B73C: DC5202A0 4C7C000B
	global_load_b32 v137, v[3:4], off                          // 00000045B744: DC520000 897C0003
	global_load_b32 v136, v[3:4], off offset:96                // 00000045B74C: DC520060 887C0003
	global_load_b32 v135, v[3:4], off offset:192               // 00000045B754: DC5200C0 877C0003
	global_load_b32 v133, v[3:4], off offset:288               // 00000045B75C: DC520120 857C0003
	global_load_b32 v83, v[3:4], off offset:384                // 00000045B764: DC520180 537C0003
	global_load_b32 v82, v[3:4], off offset:480                // 00000045B76C: DC5201E0 527C0003
	global_load_b32 v81, v[3:4], off offset:576                // 00000045B774: DC520240 517C0003
	global_load_b32 v80, v[3:4], off offset:672                // 00000045B77C: DC5202A0 507C0003
	s_branch 64422                                             // 00000045B784: BFA0FBA6 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0xf20>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000045B788: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045B78C: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000045B790: 8C7E017E
	s_waitcnt vmcnt(23)                                        // 00000045B794: BF895FF7
	v_dual_mov_b32 v1, v114 :: v_dual_mov_b32 v2, v111         // 00000045B798: CA100172 0102016F
	v_dual_mov_b32 v4, v110 :: v_dual_mov_b32 v3, v101         // 00000045B7A0: CA10016E 04020165
	v_dual_mov_b32 v5, v107 :: v_dual_mov_b32 v8, v112         // 00000045B7A8: CA10016B 05080170
	v_dual_mov_b32 v7, v113 :: v_dual_mov_b32 v6, v92          // 00000045B7B0: CA100171 0706015C
	s_waitcnt vmcnt(7)                                         // 00000045B7B8: BF891FF7
	v_dual_mov_b32 v9, v109 :: v_dual_mov_b32 v10, v108        // 00000045B7BC: CA10016D 090A016C
	v_dual_mov_b32 v11, v106 :: v_dual_mov_b32 v12, v105       // 00000045B7C4: CA10016A 0B0C0169
	v_dual_mov_b32 v13, v104 :: v_dual_mov_b32 v14, v103       // 00000045B7CC: CA100168 0D0E0167
	v_dual_mov_b32 v15, v102 :: v_dual_mov_b32 v16, v100       // 00000045B7D4: CA100166 0F100164
	v_dual_mov_b32 v18, v99 :: v_dual_mov_b32 v19, v98         // 00000045B7DC: CA100163 12120162
	v_dual_mov_b32 v20, v97 :: v_dual_mov_b32 v21, v96         // 00000045B7E4: CA100161 14140160
	v_dual_mov_b32 v22, v95 :: v_dual_mov_b32 v23, v94         // 00000045B7EC: CA10015F 1616015E
	s_waitcnt vmcnt(0)                                         // 00000045B7F4: BF8903F7
	v_dual_mov_b32 v24, v93 :: v_dual_mov_b32 v25, v91         // 00000045B7F8: CA10015D 1818015B
	v_dual_mov_b32 v26, v90 :: v_dual_mov_b32 v27, v89         // 00000045B800: CA10015A 1A1A0159
	v_dual_mov_b32 v28, v88 :: v_dual_mov_b32 v29, v87         // 00000045B808: CA100158 1C1C0157
	v_dual_mov_b32 v30, v86 :: v_dual_mov_b32 v31, v85         // 00000045B810: CA100156 1E1E0155
	v_dual_mov_b32 v32, v84 :: v_dual_mov_b32 v33, v17         // 00000045B818: CA100154 20200111
	s_mov_b32 s0, 0x76543210                                   // 00000045B820: BE8000FF 76543210
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045B828: BF870009
	v_permlanex16_b32 v1, v1, s0, 0xfedcba98                   // 00000045B82C: D65C0001 03FC0101 FEDCBA98
	v_permlanex16_b32 v2, v2, s0, 0xfedcba98                   // 00000045B838: D65C0002 03FC0102 FEDCBA98
	v_permlanex16_b32 v4, v4, s0, 0xfedcba98                   // 00000045B844: D65C0004 03FC0104 FEDCBA98
	v_permlanex16_b32 v3, v3, s0, 0xfedcba98                   // 00000045B850: D65C0003 03FC0103 FEDCBA98
	v_permlanex16_b32 v5, v5, s0, 0xfedcba98                   // 00000045B85C: D65C0005 03FC0105 FEDCBA98
	v_permlanex16_b32 v7, v7, s0, 0xfedcba98                   // 00000045B868: D65C0007 03FC0107 FEDCBA98
	v_permlanex16_b32 v8, v8, s0, 0xfedcba98                   // 00000045B874: D65C0008 03FC0108 FEDCBA98
	v_permlanex16_b32 v9, v9, s0, 0xfedcba98                   // 00000045B880: D65C0009 03FC0109 FEDCBA98
	v_permlanex16_b32 v6, v6, s0, 0xfedcba98                   // 00000045B88C: D65C0006 03FC0106 FEDCBA98
	v_permlanex16_b32 v10, v10, s0, 0xfedcba98                 // 00000045B898: D65C000A 03FC010A FEDCBA98
	v_permlanex16_b32 v11, v11, s0, 0xfedcba98                 // 00000045B8A4: D65C000B 03FC010B FEDCBA98
	v_permlanex16_b32 v12, v12, s0, 0xfedcba98                 // 00000045B8B0: D65C000C 03FC010C FEDCBA98
	v_permlanex16_b32 v13, v13, s0, 0xfedcba98                 // 00000045B8BC: D65C000D 03FC010D FEDCBA98
	v_permlanex16_b32 v14, v14, s0, 0xfedcba98                 // 00000045B8C8: D65C000E 03FC010E FEDCBA98
	v_permlanex16_b32 v15, v15, s0, 0xfedcba98                 // 00000045B8D4: D65C000F 03FC010F FEDCBA98
	v_permlanex16_b32 v16, v16, s0, 0xfedcba98                 // 00000045B8E0: D65C0010 03FC0110 FEDCBA98
	v_permlanex16_b32 v18, v18, s0, 0xfedcba98                 // 00000045B8EC: D65C0012 03FC0112 FEDCBA98
	v_permlanex16_b32 v19, v19, s0, 0xfedcba98                 // 00000045B8F8: D65C0013 03FC0113 FEDCBA98
	v_permlanex16_b32 v20, v20, s0, 0xfedcba98                 // 00000045B904: D65C0014 03FC0114 FEDCBA98
	v_permlanex16_b32 v21, v21, s0, 0xfedcba98                 // 00000045B910: D65C0015 03FC0115 FEDCBA98
	v_permlanex16_b32 v22, v22, s0, 0xfedcba98                 // 00000045B91C: D65C0016 03FC0116 FEDCBA98
	v_permlanex16_b32 v23, v23, s0, 0xfedcba98                 // 00000045B928: D65C0017 03FC0117 FEDCBA98
	v_permlanex16_b32 v24, v24, s0, 0xfedcba98                 // 00000045B934: D65C0018 03FC0118 FEDCBA98
	v_permlanex16_b32 v25, v25, s0, 0xfedcba98                 // 00000045B940: D65C0019 03FC0119 FEDCBA98
	v_permlanex16_b32 v26, v26, s0, 0xfedcba98                 // 00000045B94C: D65C001A 03FC011A FEDCBA98
	v_permlanex16_b32 v27, v27, s0, 0xfedcba98                 // 00000045B958: D65C001B 03FC011B FEDCBA98
	v_permlanex16_b32 v28, v28, s0, 0xfedcba98                 // 00000045B964: D65C001C 03FC011C FEDCBA98
	v_permlanex16_b32 v29, v29, s0, 0xfedcba98                 // 00000045B970: D65C001D 03FC011D FEDCBA98
	v_permlanex16_b32 v30, v30, s0, 0xfedcba98                 // 00000045B97C: D65C001E 03FC011E FEDCBA98
	v_permlanex16_b32 v31, v31, s0, 0xfedcba98                 // 00000045B988: D65C001F 03FC011F FEDCBA98
	v_permlanex16_b32 v32, v32, s0, 0xfedcba98                 // 00000045B994: D65C0020 03FC0120 FEDCBA98
	v_permlanex16_b32 v33, v33, s0, 0xfedcba98                 // 00000045B9A0: D65C0021 03FC0121 FEDCBA98
	.long 0xd44c0000                                           // 00000045B9AC: D44C0000
	v_cndmask_b32_e32 v1, 16, v50, vcc_lo                      // 00000045B9B0: 02026490
	s_barrier                                                  // 00000045B9B4: BFBD0000
	buffer_gl0_inv                                             // 00000045B9B8: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000045B9C0: BE812000
	s_cbranch_execz 69                                         // 00000045B9C4: BFA50045 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x23dc>
	v_dual_add_f32 v17, v17, v33 :: v_dual_add_f32 v32, v84, v32// 00000045B9C8: C9084311 11204154
	v_lshl_or_b32 v33, v48, 11, v49                            // 00000045B9D0: D6560021 04C51730
	v_dual_add_f32 v5, v107, v5 :: v_dual_add_f32 v4, v110, v4 // 00000045B9D8: C9080B6B 0504096E
	v_dual_add_f32 v1, v114, v1 :: v_dual_add_f32 v2, v111, v2 // 00000045B9E0: C9080372 0102056F
	v_dual_add_f32 v8, v112, v8 :: v_dual_add_f32 v7, v113, v7 // 00000045B9E8: C9081170 08060F71
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045B9F0: BF870004
	v_dual_add_f32 v3, v101, v3 :: v_dual_add_nc_u32 v34, 0x400, v33// 00000045B9F4: C9200765 032242FF 00000400
	v_dual_add_f32 v10, v108, v10 :: v_dual_add_f32 v9, v109, v9// 00000045BA00: C908156C 0A08136D
	v_dual_add_f32 v14, v103, v14 :: v_dual_add_f32 v13, v104, v13// 00000045BA08: C9081D67 0E0C1B68
	v_dual_add_f32 v6, v92, v6 :: v_dual_add_f32 v31, v85, v31 // 00000045BA10: C9080D5C 061E3F55
	v_dual_add_f32 v30, v86, v30 :: v_dual_add_f32 v29, v87, v29// 00000045BA18: C9083D56 1E1C3B57
	v_dual_add_f32 v28, v88, v28 :: v_dual_add_f32 v27, v89, v27// 00000045BA20: C9083958 1C1A3759
	v_dual_add_f32 v26, v90, v26 :: v_dual_add_f32 v25, v91, v25// 00000045BA28: C908355A 1A18335B
	v_dual_add_f32 v24, v93, v24 :: v_dual_add_f32 v23, v94, v23// 00000045BA30: C908315D 18162F5E
	v_dual_add_f32 v22, v95, v22 :: v_dual_add_f32 v21, v96, v21// 00000045BA38: C9082D5F 16142B60
	v_dual_add_f32 v20, v97, v20 :: v_dual_add_f32 v19, v98, v19// 00000045BA40: C9082961 14122762
	v_add_f32_e32 v18, v99, v18                                // 00000045BA48: 06242563
	v_dual_add_f32 v16, v100, v16 :: v_dual_add_f32 v15, v102, v15// 00000045BA4C: C9082164 100E1F66
	v_dual_add_f32 v12, v105, v12 :: v_dual_add_f32 v11, v106, v11// 00000045BA54: C9081969 0C0A176A
	ds_store_2addr_b32 v33, v1, v5 offset1:16                  // 00000045BA5C: D8381000 00050121
	ds_store_2addr_b32 v33, v2, v7 offset0:128 offset1:144     // 00000045BA64: D8389080 00070221
	ds_store_2addr_b32 v34, v4, v8 offset1:16                  // 00000045BA6C: D8381000 00080422
	ds_store_2addr_b32 v34, v3, v9 offset0:128 offset1:144     // 00000045BA74: D8389080 00090322
	ds_store_2addr_b32 v33, v6, v13 offset0:32 offset1:48      // 00000045BA7C: D8383020 000D0621
	ds_store_2addr_b32 v33, v10, v14 offset0:160 offset1:176   // 00000045BA84: D838B0A0 000E0A21
	ds_store_2addr_b32 v34, v11, v15 offset0:32 offset1:48     // 00000045BA8C: D8383020 000F0B22
	ds_store_2addr_b32 v34, v12, v16 offset0:160 offset1:176   // 00000045BA94: D838B0A0 00100C22
	ds_store_2addr_b32 v33, v18, v22 offset0:64 offset1:80     // 00000045BA9C: D8385040 00161221
	ds_store_2addr_b32 v33, v19, v23 offset0:192 offset1:208   // 00000045BAA4: D838D0C0 00171321
	ds_store_2addr_b32 v34, v20, v24 offset0:64 offset1:80     // 00000045BAAC: D8385040 00181422
	ds_store_2addr_b32 v34, v21, v25 offset0:192 offset1:208   // 00000045BAB4: D838D0C0 00191522
	ds_store_2addr_b32 v33, v26, v30 offset0:96 offset1:112    // 00000045BABC: D8387060 001E1A21
	ds_store_2addr_b32 v33, v27, v31 offset0:224 offset1:240   // 00000045BAC4: D838F0E0 001F1B21
	ds_store_2addr_b32 v34, v28, v32 offset0:96 offset1:112    // 00000045BACC: D8387060 00201C22
	ds_store_2addr_b32 v34, v29, v17 offset0:224 offset1:240   // 00000045BAD4: D838F0E0 00111D22
	s_or_b32 exec_lo, exec_lo, s1                              // 00000045BADC: 8C7E017E
	.long 0xd44c0001                                           // 00000045BAE0: D44C0001
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000045BAE4: 020200FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000045BAEC: BF89FC07
	s_barrier                                                  // 00000045BAF0: BFBD0000
	buffer_gl0_inv                                             // 00000045BAF4: E0AC0000 00000000
	s_and_saveexec_b32 s4, s1                                  // 00000045BAFC: BE842001
	s_cbranch_execz 50                                         // 00000045BB00: BFA50032 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x24cc>
	v_mov_b32_e32 v1, v0                                       // 00000045BB04: 7E020300
	s_mov_b32 s5, 0                                            // 00000045BB08: BE850080
	s_nop 0                                                    // 00000045BB0C: BF800000
	s_nop 0                                                    // 00000045BB10: BF800000
	s_nop 0                                                    // 00000045BB14: BF800000
	s_nop 0                                                    // 00000045BB18: BF800000
	s_nop 0                                                    // 00000045BB1C: BF800000
	s_nop 0                                                    // 00000045BB20: BF800000
	s_nop 0                                                    // 00000045BB24: BF800000
	s_nop 0                                                    // 00000045BB28: BF800000
	s_nop 0                                                    // 00000045BB2C: BF800000
	s_nop 0                                                    // 00000045BB30: BF800000
	s_nop 0                                                    // 00000045BB34: BF800000
	s_nop 0                                                    // 00000045BB38: BF800000
	s_nop 0                                                    // 00000045BB3C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BB40: BF870001
	v_lshlrev_b32_e32 v8, 2, v1                                // 00000045BB44: 30100282
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v1                          // 00000045BB48: 7C9202FF 000000FF
	ds_load_2addr_stride64_b32 v[2:3], v8 offset1:8            // 00000045BB50: D8E00800 02000008
	ds_load_2addr_stride64_b32 v[4:5], v8 offset0:16 offset1:24// 00000045BB58: D8E01810 04000008
	ds_load_2addr_stride64_b32 v[6:7], v8 offset0:32 offset1:40// 00000045BB60: D8E02820 06000008
	s_or_b32 s5, vcc_lo, s5                                    // 00000045BB68: 8C05056A
	s_waitcnt lgkmcnt(2)                                       // 00000045BB6C: BF89FC27
	v_add_f32_e32 v2, 0, v2                                    // 00000045BB70: 06040480
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000045BB74: BF8700C1
	v_add_f32_e32 v9, v2, v3                                   // 00000045BB78: 06120702
	ds_load_2addr_stride64_b32 v[2:3], v8 offset0:48 offset1:56// 00000045BB7C: D8E03830 02000008
	s_waitcnt lgkmcnt(2)                                       // 00000045BB84: BF89FC27
	v_add_f32_e32 v4, v9, v4                                   // 00000045BB88: 06080909
	v_add_f32_e32 v4, v4, v5                                   // 00000045BB8C: 06080B04
	s_waitcnt lgkmcnt(1)                                       // 00000045BB90: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045BB94: BF870091
	v_add_f32_e32 v4, v4, v6                                   // 00000045BB98: 06080D04
	v_add_f32_e32 v4, v4, v7                                   // 00000045BB9C: 06080F04
	s_waitcnt lgkmcnt(0)                                       // 00000045BBA0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045BBA4: BF8700A1
	v_add_f32_e32 v2, v4, v2                                   // 00000045BBA8: 06040504
	v_add_nc_u32_e32 v4, 0x100, v1                             // 00000045BBAC: 4A0802FF 00000100
	v_dual_add_f32 v2, v2, v3 :: v_dual_mov_b32 v1, v4         // 00000045BBB4: C9100702 02000104
	ds_store_b32 v8, v2 offset:16384                           // 00000045BBBC: D8344000 00000208
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000045BBC4: 917E057E
	s_cbranch_execnz 65501                                     // 00000045BBC8: BFA6FFDD <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2440>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000045BBCC: 8C7E047E
	s_cmp_lt_i32 s33, 2                                        // 00000045BBD0: BF048221
	s_mov_b32 s4, -1                                           // 00000045BBD4: BE8400C1
	s_cbranch_scc1 212                                         // 00000045BBD8: BFA200D4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x282c>
	s_waitcnt lgkmcnt(0)                                       // 00000045BBDC: BF89FC07
	s_barrier                                                  // 00000045BBE0: BFBD0000
	buffer_gl0_inv                                             // 00000045BBE4: E0AC0000 00000000
	s_and_saveexec_b32 s6, s1                                  // 00000045BBEC: BE862001
	s_cbranch_execz 71                                         // 00000045BBF0: BFA50047 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2610>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000045BBF4: 32020087
	s_ashr_i32 s11, s10, 31                                    // 00000045BBF8: 860B9F0A
	s_ashr_i32 s27, s26, 31                                    // 00000045BBFC: 861B9F1A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 00000045BC00: 8484820A
	s_mov_b32 s7, 0                                            // 00000045BC04: BE870080
	v_or_b32_e32 v1, s4, v1                                    // 00000045BC08: 38020204
	s_mul_i32 s4, s5, s26                                      // 00000045BC0C: 96041A05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045BC10: BF8700A1
	.long 0xd72c0003                                           // 00000045BC14: D72C0003
	v_cndmask_b32_e32 v0, v1, v27, vcc_lo                      // 00000045BC18: 02003701
	v_mad_u64_u32 v[1:2], null, v1, s26, 0                     // 00000045BC1C: D6FE7C01 02003501
	v_add3_u32 v2, v2, v3, s4                                  // 00000045BC24: D6550002 00120702
	s_lshl_b32 s4, s2, 7                                       // 00000045BC2C: 84048702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000045BC30: 360600FF 0000007F
	s_ashr_i32 s5, s4, 31                                      // 00000045BC38: 86059F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000045BC3C: BF870122
	.long 0xd73c0001                                           // 00000045BC40: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000045BC44: 02020282
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000045BC48: 84848204
	v_lshlrev_b32_e32 v4, 2, v3                                // 00000045BC4C: 30080682
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000045BC50: 30060082
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045BC54: BF870093
	.long 0xd7006a01                                           // 00000045BC58: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000045BC5C: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000045BC60: D5207C02 01AA0405
	s_lshl_b64 s[4:5], s[26:27], 3                             // 00000045BC68: 8484831A
	.long 0xd7006a01                                           // 00000045BC6C: D7006A01
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000045BC70: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045BC74: BF8701A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000045BC78: D5207C02 01AA0480
	v_or_b32_e32 v4, 0xffffff00, v0                            // 00000045BC80: 380800FF FFFFFF00
	.long 0xd7006a01                                           // 00000045BC88: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000045BC8C: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BC90: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 00000045BC94: D5207C02 01AA0411
	s_nop 0                                                    // 00000045BC9C: BF800000
	s_nop 0                                                    // 00000045BCA0: BF800000
	s_nop 0                                                    // 00000045BCA4: BF800000
	s_nop 0                                                    // 00000045BCA8: BF800000
	s_nop 0                                                    // 00000045BCAC: BF800000
	s_nop 0                                                    // 00000045BCB0: BF800000
	s_nop 0                                                    // 00000045BCB4: BF800000
	s_nop 0                                                    // 00000045BCB8: BF800000
	s_nop 0                                                    // 00000045BCBC: BF800000
	ds_load_b32 v5, v3 offset:16384                            // 00000045BCC0: D8D84000 05000003
	.long 0xd7000804                                           // 00000045BCC8: D7000804
	v_cndmask_b32_e32 v1, 0x100, v4, vcc_lo                    // 00000045BCCC: 020208FF 00000100
	s_xor_b32 s8, s8, -1                                       // 00000045BCD4: 8D08C108
	v_add_nc_u32_e32 v3, 0x400, v3                             // 00000045BCD8: 4A0606FF 00000400
	s_and_b32 s8, exec_lo, s8                                  // 00000045BCE0: 8B08087E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000045BCE4: BF8700C9
	s_or_b32 s7, s8, s7                                        // 00000045BCE8: 8C070708
	s_waitcnt lgkmcnt(0)                                       // 00000045BCEC: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 00000045BCF0: DC6A0000 007C0501
	.long 0xd7006a01                                           // 00000045BCF8: D7006A01
	v_cndmask_b32_e32 v0, v1, v4, vcc_lo                       // 00000045BCFC: 02000901
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000045BD00: D5207C02 01AA0405
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000045BD08: 917E077E
	s_cbranch_execnz 65516                                     // 00000045BD0C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x25c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000045BD10: 8C7E067E
	.long 0xd44a0004                                           // 00000045BD14: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000045BD18: 02020080
	s_waitcnt_vscnt null, 0x0                                  // 00000045BD1C: BC7C0000
	buffer_gl1_inv                                             // 00000045BD20: E0B00000 00000000
	buffer_gl0_inv                                             // 00000045BD28: E0AC0000 00000000
	s_barrier                                                  // 00000045BD30: BFBD0000
	buffer_gl0_inv                                             // 00000045BD34: E0AC0000 00000000
	s_and_saveexec_b32 s5, s4                                  // 00000045BD3C: BE852004
	s_cbranch_execz 29                                         // 00000045BD40: BFA5001D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x26b8>
	s_mov_b32 s7, exec_lo                                      // 00000045BD44: BE87007E
	s_mov_b32 s6, exec_lo                                      // 00000045BD48: BE86007E
	.long 0xd71f0001                                           // 00000045BD4C: D71F0001
	v_cndmask_b32_e32 v0, s7, v128, vcc_lo                     // 00000045BD50: 02010007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BD54: BF870001
	v_cmpx_eq_u32_e32 0, v1                                    // 00000045BD58: 7D940280
	s_cbranch_execz 9                                          // 00000045BD5C: BFA50009 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2684>
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000045BD60: 84888202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000045BD64: BF8704B9
	s_add_u32 s8, s18, s8                                      // 00000045BD68: 80080812
	s_addc_u32 s9, s19, s9                                     // 00000045BD6C: 82090913
	s_bcnt1_i32_b32 s7, s7                                     // 00000045BD70: BE871807
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, s7              // 00000045BD74: CA100080 02020007
	global_atomic_add_u32 v2, v2, v3, s[8:9] glc               // 00000045BD7C: DCD64000 02080302
	s_or_b32 exec_lo, exec_lo, s6                              // 00000045BD84: 8C7E067E
	s_waitcnt vmcnt(0)                                         // 00000045BD88: BF8903F7
	v_readfirstlane_b32 s6, v2                                 // 00000045BD8C: 7E0C0502
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BD90: BF870001
	v_dual_mov_b32 v2, 0 :: v_dual_add_nc_u32 v1, s6, v1       // 00000045BD94: CA200080 02000206
	s_add_i32 s6, s33, -1                                      // 00000045BD9C: 8106C121
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000045BDA0: BF870481
	v_cmp_eq_u32_e32 vcc_lo, s6, v1                            // 00000045BDA4: 7C940206
	v_cndmask_b32_e64 v1, 0, 1, vcc_lo                         // 00000045BDA8: D5010001 01A90280
	ds_store_b32 v2, v1 offset:20480                           // 00000045BDB0: D8345000 00000102
	s_or_b32 exec_lo, exec_lo, s5                              // 00000045BDB8: 8C7E057E
	v_mov_b32_e32 v1, 0                                        // 00000045BDBC: 7E020280
	s_waitcnt lgkmcnt(0)                                       // 00000045BDC0: BF89FC07
	s_barrier                                                  // 00000045BDC4: BFBD0000
	buffer_gl0_inv                                             // 00000045BDC8: E0AC0000 00000000
	ds_load_b32 v1, v1 offset:20480                            // 00000045BDD0: D8D85000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000045BDD8: BF89FC07
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000045BDDC: 7C940280
	s_cbranch_vccnz 466                                        // 00000045BDE0: BFA401D2 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e2c>
	buffer_gl1_inv                                             // 00000045BDE4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000045BDEC: E0AC0000 00000000
	s_and_saveexec_b32 s5, s1                                  // 00000045BDF4: BE852001
	s_cbranch_execz 65                                         // 00000045BDF8: BFA50041 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2800>
	v_lshrrev_b32_e32 v1, 7, v0                                // 00000045BDFC: 32020087
	s_lshl_b32 s6, s2, 7                                       // 00000045BE00: 84068702
	v_and_b32_e32 v3, 0x7f, v0                                 // 00000045BE04: 360600FF 0000007F
	s_ashr_i32 s7, s6, 31                                      // 00000045BE0C: 86079F06
	v_mov_b32_e32 v5, v0                                       // 00000045BE10: 7E0A0300
	v_mad_i64_i32 v[1:2], null, v1, s26, 0                     // 00000045BE14: D6FF7C01 02003501
	s_lshl_b64 s[6:7], s[6:7], 2                               // 00000045BE1C: 84868206
	v_lshlrev_b32_e32 v3, 2, v3                                // 00000045BE20: 30060682
	s_ashr_i32 s27, s26, 31                                    // 00000045BE24: 861B9F1A
	s_mov_b32 s10, 0                                           // 00000045BE28: BE8A0080
	s_lshl_b64 s[8:9], s[26:27], 4                             // 00000045BE2C: 8488841A
	.long 0xd73c0001                                           // 00000045BE30: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000045BE34: 02020282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045BE38: BF870091
	.long 0xd7006a01                                           // 00000045BE3C: D7006A01
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000045BE40: 02000D01
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000045BE44: D5207C02 01AA0407
	s_lshl_b64 s[6:7], s[26:27], 3                             // 00000045BE4C: 8486831A
	.long 0xd7006a01                                           // 00000045BE50: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000045BE54: 02020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045BE58: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000045BE5C: D5207C02 01AA0480
	.long 0xd7006a01                                           // 00000045BE64: D7006A01
	v_cndmask_b32_e32 v1, s16, v1, vcc_lo                      // 00000045BE68: 02020210
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BE6C: BF870001
	v_add_co_ci_u32_e64 v2, null, s17, v2, vcc_lo              // 00000045BE70: D5207C02 01AA0411
	s_nop 0                                                    // 00000045BE78: BF800000
	s_nop 0                                                    // 00000045BE7C: BF800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BE80: BF870001
	v_dual_mov_b32 v4, v2 :: v_dual_mov_b32 v3, v1             // 00000045BE84: CA100102 04020101
	v_mov_b32_e32 v6, 0                                        // 00000045BE8C: 7E0C0280
	s_mov_b32 s1, s33                                          // 00000045BE90: BE810021
	global_load_b32 v7, v[3:4], off glc                        // 00000045BE94: DC524000 077C0003
	.long 0xd7006a03                                           // 00000045BE9C: D7006A03
	v_cndmask_b32_e32 v0, v3, v8, vcc_lo                       // 00000045BEA0: 02001103
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000045BEA4: BF8704A1
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 00000045BEA8: D5207C04 01AA0809
	s_add_i32 s1, s1, -1                                       // 00000045BEB0: 8101C101
	s_cmp_eq_u32 s1, 0                                         // 00000045BEB4: BF068001
	s_waitcnt vmcnt(0)                                         // 00000045BEB8: BF8903F7
	v_add_f32_e32 v6, v6, v7                                   // 00000045BEBC: 060C0F06
	s_cbranch_scc0 65524                                       // 00000045BEC0: BFA1FFF4 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2794>
	v_add_nc_u32_e32 v4, 0x100, v5                             // 00000045BEC4: 4A080AFF 00000100
	v_cmp_lt_u32_e32 vcc_lo, 0xff, v5                          // 00000045BECC: 7C920AFF 000000FF
	.long 0xd7000101                                           // 00000045BED4: D7000101
	v_cndmask_b32_e32 v0, v1, v6, vcc_lo                       // 00000045BED8: 02000D01
	v_lshlrev_b32_e32 v3, 2, v5                                // 00000045BEDC: 30060A82
	v_add_co_ci_u32_e64 v2, null, s7, v2, s1                   // 00000045BEE0: D5207C02 00060407
	v_mov_b32_e32 v5, v4                                       // 00000045BEE8: 7E0A0304
	s_or_b32 s10, vcc_lo, s10                                  // 00000045BEEC: 8C0A0A6A
	ds_store_b32 v3, v6 offset:16384                           // 00000045BEF0: D8344000 00000603
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000045BEF8: 917E0A7E
	s_cbranch_execnz 65504                                     // 00000045BEFC: BFA6FFE0 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2780>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000045BF00: 8C7E057E
	s_and_saveexec_b32 s1, s4                                  // 00000045BF04: BE812004
	s_cbranch_execz 6                                          // 00000045BF08: BFA50006 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2824>
	s_lshl_b64 s[4:5], s[2:3], 2                               // 00000045BF0C: 84848202
	v_mov_b32_e32 v1, 0                                        // 00000045BF10: 7E020280
	s_add_u32 s4, s18, s4                                      // 00000045BF14: 80040412
	s_addc_u32 s5, s19, s5                                     // 00000045BF18: 82050513
	global_store_b32 v1, v1, s[4:5]                            // 00000045BF1C: DC6A0000 00040101
	s_or_b32 exec_lo, exec_lo, s1                              // 00000045BF24: 8C7E017E
	s_mov_b32 s4, -1                                           // 00000045BF28: BE8400C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045BF2C: BF870009
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000045BF30: 8B6A047E
	s_cbranch_vccz 381                                         // 00000045BF34: BFA3017D <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e2c>
	v_cmp_gt_i32_e32 vcc_lo, s24, v48                          // 00000045BF38: 7C886018
	.long 0xd44c0001                                           // 00000045BF3C: D44C0001
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000045BF40: 020200FF 00000080
	s_waitcnt lgkmcnt(0)                                       // 00000045BF48: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000045BF4C: BC7C0000
	s_barrier                                                  // 00000045BF50: BFBD0000
	buffer_gl0_inv                                             // 00000045BF54: E0AC0000 00000000
	s_and_b32 s1, vcc_lo, s1                                   // 00000045BF5C: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000045BF60: BF870009
	s_and_saveexec_b32 s3, s1                                  // 00000045BF64: BE832001
	s_cbranch_execz 368                                        // 00000045BF68: BFA50170 <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e2c>
	v_and_b32_e32 v1, 15, v0                                   // 00000045BF6C: 3602008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045BF70: BF870091
	v_lshlrev_b32_e32 v2, 2, v1                                // 00000045BF74: 30040282
	v_lshl_or_b32 v2, v48, 9, v2                               // 00000045BF78: D6560002 04091330
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045BF80: BF870001
	v_add_nc_u32_e32 v8, 0x4000, v2                            // 00000045BF84: 4A1004FF 00004000
	ds_load_2addr_b32 v[2:3], v8 offset1:16                    // 00000045BF8C: D8DC1000 02000008
	ds_load_2addr_b32 v[4:5], v8 offset0:32 offset1:48         // 00000045BF94: D8DC3020 04000008
	ds_load_2addr_b32 v[6:7], v8 offset0:64 offset1:80         // 00000045BF9C: D8DC5040 06000008
	ds_load_2addr_b32 v[8:9], v8 offset0:96 offset1:112        // 00000045BFA4: D8DC7060 08000008
	v_and_b32_e32 v10, 1, v0                                   // 00000045BFAC: 36140081
	v_and_b32_e32 v11, 2, v0                                   // 00000045BFB0: 36160082
	s_waitcnt lgkmcnt(3)                                       // 00000045BFB4: BF89FC37
	v_dual_add_f32 v13, v2, v3 :: v_dual_and_b32 v12, 4, v0    // 00000045BFB8: C9240702 0D0C0084
	s_waitcnt lgkmcnt(2)                                       // 00000045BFC0: BF89FC27
	v_dual_sub_f32 v2, v2, v3 :: v_dual_add_f32 v3, v4, v5     // 00000045BFC4: C9480702 02020B04
	s_waitcnt lgkmcnt(1)                                       // 00000045BFCC: BF89FC17
	v_dual_sub_f32 v4, v4, v5 :: v_dual_add_f32 v5, v6, v7     // 00000045BFD0: C9480B04 04040F06
	s_waitcnt lgkmcnt(0)                                       // 00000045BFD8: BF89FC07
	v_dual_sub_f32 v6, v6, v7 :: v_dual_add_f32 v7, v8, v9     // 00000045BFDC: C9480F06 06061308
	v_dual_sub_f32 v8, v8, v9 :: v_dual_add_f32 v9, v13, v3    // 00000045BFE4: C9481308 0808070D
	v_sub_f32_e32 v3, v13, v3                                  // 00000045BFEC: 0806070D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000045BFF0: BF870243
	v_dual_add_f32 v13, v2, v4 :: v_dual_add_f32 v14, v5, v7   // 00000045BFF4: C9080902 0D0E0F05
	v_dual_sub_f32 v2, v2, v4 :: v_dual_sub_f32 v5, v5, v7     // 00000045BFFC: C94A0902 02040F05
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000045C004: 7C941480
	.long 0xd44a0001                                           // 00000045C008: D44A0001
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000045C00C: 02021880
	v_dual_add_f32 v7, v9, v14 :: v_dual_add_f32 v4, v6, v8    // 00000045C010: C9081D09 07041106
	v_sub_f32_e32 v6, v6, v8                                   // 00000045C018: 080C1106
	v_sub_f32_e32 v8, v9, v14                                  // 00000045C01C: 08101D09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000045C020: BF870003
	v_add_f32_e32 v9, v13, v4                                  // 00000045C024: 0612090D
	v_dual_sub_f32 v4, v13, v4 :: v_dual_add_f32 v13, v3, v5   // 00000045C028: C948090D 040C0B03
	v_sub_f32_e32 v3, v3, v5                                   // 00000045C030: 08060B03
	v_add_f32_e32 v5, v2, v6                                   // 00000045C034: 060A0D02
	v_sub_f32_e32 v2, v2, v6                                   // 00000045C038: 08040D02
	v_mov_b32_dpp v6, v7 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C03C: 7E0C02FA FF016107
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000045C044: D5010007 21AA0F07
	v_mov_b32_dpp v10, v9 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C04C: 7E1402FA FF016109
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000045C054: D5010009 21AA1309
	v_mov_b32_dpp v14, v13 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C05C: 7E1C02FA FF01610D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000045C064: D501000D 21AA1B0D
	v_mov_b32_dpp v15, v5 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C06C: 7E1E02FA FF016105
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000045C074: D5010005 21AA0B05
	v_mov_b32_dpp v16, v8 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C07C: 7E2002FA FF016108
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000045C084: D5010008 21AA1108
	v_mov_b32_dpp v17, v4 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C08C: 7E2202FA FF016104
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000045C094: D5010004 21AA0904
	v_mov_b32_dpp v18, v3 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C09C: 7E2402FA FF016103
	v_cndmask_b32_e64 v19, -v3, v3, vcc_lo                     // 00000045C0A4: D5010013 21AA0703
	v_cndmask_b32_e64 v21, -v2, v2, vcc_lo                     // 00000045C0AC: D5010015 21AA0502
	v_cmp_eq_u32_e32 vcc_lo, 0, v11                            // 00000045C0B4: 7C941680
	v_dual_add_f32 v3, v7, v6 :: v_dual_add_f32 v8, v8, v16    // 00000045C0B8: C9080D07 03082108
	v_mov_b32_dpp v20, v2 row_xmask:1 row_mask:0xf bank_mask:0xf// 00000045C0C0: 7E2802FA FF016102
	v_dual_add_f32 v2, v9, v10 :: v_dual_add_f32 v9, v4, v17   // 00000045C0C8: C9081509 02082304
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000045C0D0: BF870233
	v_mov_b32_dpp v4, v3 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C0D4: 7E0802FA FF016203
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000045C0DC: D5010003 21AA0703
	v_add_f32_e32 v6, v13, v14                                 // 00000045C0E4: 060C1D0D
	v_mov_b32_dpp v7, v2 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C0E8: 7E0E02FA FF016202
	v_cndmask_b32_e64 v2, -v2, v2, vcc_lo                      // 00000045C0F0: D5010002 21AA0502
	v_mov_b32_dpp v12, v8 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C0F8: 7E1802FA FF016208
	v_add_f32_e32 v3, v3, v4                                   // 00000045C100: 06060903
	v_mov_b32_dpp v10, v6 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C104: 7E1402FA FF016206
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000045C10C: D5010006 21AA0D06
	v_add_f32_e32 v5, v5, v15                                  // 00000045C114: 060A1F05
	v_cndmask_b32_e64 v8, -v8, v8, vcc_lo                      // 00000045C118: D5010008 21AA1108
	v_add_f32_e32 v13, v21, v20                                // 00000045C120: 061A2915
	v_mov_b32_dpp v14, v9 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C124: 7E1C02FA FF016209
	v_add_f32_e32 v6, v6, v10                                  // 00000045C12C: 060C1506
	v_mov_b32_dpp v11, v5 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C130: 7E1602FA FF016205
	v_cndmask_b32_e64 v5, -v5, v5, vcc_lo                      // 00000045C138: D5010005 21AA0B05
	v_cndmask_b32_e64 v9, -v9, v9, vcc_lo                      // 00000045C140: D5010009 21AA1309
	v_add_f32_e32 v8, v8, v12                                  // 00000045C148: 06101908
	v_mov_b32_dpp v15, v13 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C14C: 7E1E02FA FF01620D
	v_cndmask_b32_e64 v13, -v13, v13, vcc_lo                   // 00000045C154: D501000D 21AA1B0D
	v_add_f32_e32 v4, v5, v11                                  // 00000045C15C: 06081705
	v_mov_b32_dpp v5, v3 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C160: 7E0A02FA FF016403
	v_cndmask_b32_e64 v3, -v3, v3, s1                          // 00000045C168: D5010003 20060703
	v_add_f32_e32 v2, v2, v7                                   // 00000045C170: 06040F02
	v_mov_b32_dpp v11, v6 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C174: 7E1602FA FF016406
	v_cndmask_b32_e64 v6, -v6, v6, s1                          // 00000045C17C: D5010006 20060D06
	v_add_f32_e32 v9, v9, v14                                  // 00000045C184: 06121D09
	v_add_f32_e32 v3, v3, v5                                   // 00000045C188: 06060B03
	v_cndmask_b32_e64 v7, -v2, v2, s1                          // 00000045C18C: D5010007 20060502
	v_mov_b32_dpp v2, v2 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C194: 7E0402FA FF016402
	v_add_f32_e32 v6, v6, v11                                  // 00000045C19C: 060C1706
	v_mov_b32_dpp v11, v8 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C1A0: 7E1602FA FF016408
	v_cndmask_b32_e64 v14, -v8, v8, s1                         // 00000045C1A8: D501000E 20061108
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000045C1B0: BF870234
	v_add_f32_e32 v7, v7, v2                                   // 00000045C1B4: 060E0507
	v_mov_b32_dpp v10, v4 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C1B8: 7E1402FA FF016404
	v_cndmask_b32_e64 v4, -v4, v4, s1                          // 00000045C1C0: D5010004 20060904
	v_add_f32_e32 v14, v14, v11                                // 00000045C1C8: 061C170E
	v_mov_b32_dpp v2, v3 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C1CC: 7E0402FA FF016803
	v_mov_b32_dpp v5, v7 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C1D4: 7E0A02FA FF016807
	v_mov_b32_dpp v8, v6 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C1DC: 7E1002FA FF016806
	v_add_f32_e32 v4, v4, v10                                  // 00000045C1E4: 06081504
	v_add_f32_e32 v10, v19, v18                                // 00000045C1E8: 06142513
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000045C1EC: BF8700A1
	v_mov_b32_dpp v12, v10 row_xmask:2 row_mask:0xf bank_mask:0xf// 00000045C1F0: 7E1802FA FF01620A
	v_cndmask_b32_e64 v10, -v10, v10, vcc_lo                   // 00000045C1F8: D501000A 21AA150A
	v_add_f32_e32 v10, v10, v12                                // 00000045C200: 0614190A
	v_add_f32_e32 v12, v13, v15                                // 00000045C204: 06181F0D
	v_mov_b32_dpp v13, v9 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C208: 7E1A02FA FF016409
	v_cndmask_b32_e64 v9, -v9, v9, s1                          // 00000045C210: D5010009 20061309
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045C218: BF870214
	v_mov_b32_dpp v15, v10 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C21C: 7E1E02FA FF01640A
	v_mov_b32_dpp v17, v12 row_xmask:4 row_mask:0xf bank_mask:0xf// 00000045C224: 7E2202FA FF01640C
	v_cndmask_b32_e64 v10, -v10, v10, s1                       // 00000045C22C: D501000A 2006150A
	v_cndmask_b32_e64 v12, -v12, v12, s1                       // 00000045C234: D501000C 2006190C
	v_add_f32_e32 v16, v9, v13                                 // 00000045C23C: 06201B09
	v_mov_b32_dpp v9, v4 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C240: 7E1202FA FF016804
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045C248: BF870214
	v_add_f32_e32 v15, v10, v15                                // 00000045C24C: 061E1F0A
	v_add_f32_e32 v17, v12, v17                                // 00000045C250: 0622230C
	v_mov_b32_dpp v10, v14 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C254: 7E1402FA FF01680E
	v_mov_b32_dpp v11, v16 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C25C: 7E1602FA FF016810
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000045C264: BF870214
	v_mov_b32_dpp v12, v15 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C268: 7E1802FA FF01680F
	v_mov_b32_dpp v13, v17 row_xmask:8 row_mask:0xf bank_mask:0xf// 00000045C270: 7E1A02FA FF016811
	s_and_b32 exec_lo, exec_lo, s0                             // 00000045C278: 8B7E007E
	s_cbranch_execz 171                                        // 00000045C27C: BFA500AB <_ZN7halogen12_GLOBAL__N_18k_ht_linILi3ELi4ELb0ELb1ELb0ELb1EEEvPKjPKtiiiiPKDF16_S7_PfPjPvS5_+0x2e2c>
	v_lshl_or_b32 v18, s2, 7, v1                               // 00000045C280: D6560012 04050E02
	.long 0x7f2c3880                                           // 00000045C288: 7F2C3880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000045C28C: BF870112
	v_ashrrev_i32_e32 v19, 31, v18                             // 00000045C290: 3426249F
	.long 0x7f2e3996                                           // 00000045C294: 7F2E3996
	.long 0x7f303996                                           // 00000045C298: 7F303996
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000045C29C: BF870093
	.long 0xd73c0012                                           // 00000045C2A0: D73C0012
	v_cndmask_b32_e32 v1, 1, v18, vcc_lo                       // 00000045C2A4: 02022481
	.long 0xd7006a14                                           // 00000045C2A8: D7006A14
	v_cndmask_b32_e32 v1, s14, v18, vcc_lo                     // 00000045C2AC: 0202240E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045C2B0: BF870001
	v_add_co_ci_u32_e64 v21, null, s15, v19, vcc_lo            // 00000045C2B4: D5207C15 01AA260F
	s_clause 0x7                                               // 00000045C2BC: BF850007
	global_load_d16_b16 v22, v[20:21], off offset:32           // 00000045C2C0: DC820020 167C0014
	global_load_d16_b16 v23, v[20:21], off                     // 00000045C2C8: DC820000 177C0014
	global_load_d16_b16 v24, v[20:21], off offset:64           // 00000045C2D0: DC820040 187C0014
	global_load_d16_b16 v25, v[20:21], off offset:96           // 00000045C2D8: DC820060 197C0014
	global_load_d16_b16 v26, v[20:21], off offset:128          // 00000045C2E0: DC820080 1A7C0014
	global_load_d16_b16 v27, v[20:21], off offset:160          // 00000045C2E8: DC8200A0 1B7C0014
	global_load_d16_b16 v28, v[20:21], off offset:192          // 00000045C2F0: DC8200C0 1C7C0014
	global_load_d16_b16 v20, v[20:21], off offset:224          // 00000045C2F8: DC8200E0 147C0014
	v_and_b32_e32 v21, 8, v0                                   // 00000045C300: 362A0088
	v_mad_i64_i32 v[0:1], null, s26, v48, 0                    // 00000045C304: D6FF7C00 0202601A
	s_waitcnt vmcnt(0)                                         // 00000045C30C: BF8903F7
	.long 0x7f283996                                           // 00000045C310: 7F283996
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000045C314: BF870223
	v_cmp_eq_u32_e32 vcc_lo, 0, v21                            // 00000045C318: 7C942A80
	.long 0x7f2a3996                                           // 00000045C31C: 7F2A3996
	.long 0xd73c0000                                           // 00000045C320: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000045C324: 02020081
	v_cndmask_b32_e64 v7, -v7, v7, vcc_lo                      // 00000045C328: D5010007 21AA0F07
	v_cndmask_b32_e64 v3, -v3, v3, vcc_lo                      // 00000045C330: D5010003 21AA0703
	v_cndmask_b32_e64 v4, -v4, v4, vcc_lo                      // 00000045C338: D5010004 21AA0904
	v_cndmask_b32_e64 v6, -v6, v6, vcc_lo                      // 00000045C340: D5010006 21AA0D06
	v_cndmask_b32_e64 v14, -v14, v14, vcc_lo                   // 00000045C348: D501000E 21AA1D0E
	v_add_f32_e32 v5, v7, v5                                   // 00000045C350: 060A0B07
	v_cndmask_b32_e64 v7, -v16, v16, vcc_lo                    // 00000045C354: D5010007 21AA2110
	v_cndmask_b32_e64 v16, -v17, v17, vcc_lo                   // 00000045C35C: D5010010 21AA2311
	v_cndmask_b32_e64 v15, -v15, v15, vcc_lo                   // 00000045C364: D501000F 21AA1F0F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000045C36C: BF870124
	v_dual_add_f32 v2, v3, v2 :: v_dual_mul_f32 v3, 0x3db504f3, v5// 00000045C370: C9060503 02020AFF 3DB504F3
	v_dual_add_f32 v5, v6, v8 :: v_dual_add_f32 v4, v4, v9     // 00000045C37C: C9081106 05041304
	v_dual_add_f32 v7, v7, v11 :: v_dual_mul_f32 v2, 0x3db504f3, v2// 00000045C384: C9061707 070204FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045C390: BF870194
	v_dual_add_f32 v8, v15, v12 :: v_dual_add_f32 v9, v16, v13 // 00000045C394: C908190F 08081B10
	v_mul_f32_e32 v4, 0x3db504f3, v4                           // 00000045C39C: 100808FF 3DB504F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000045C3A4: BF870193
	v_dual_add_f32 v6, v14, v10 :: v_dual_mul_f32 v7, 0x3db504f3, v7// 00000045C3A8: C906150E 06060EFF 3DB504F3
	v_dual_mul_f32 v8, 0x3db504f3, v8 :: v_dual_mul_f32 v5, 0x3db504f3, v5// 00000045C3B4: C8C610FF 08040AFF 3DB504F3
	.long 0xd7006a00                                           // 00000045C3C0: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000045C3C4: 02020014
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000045C3C8: BF8701A3
	v_mul_f32_e32 v6, 0x3db504f3, v6                           // 00000045C3CC: 100C0CFF 3DB504F3
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000045C3D4: D5207C01 01AA0215
	.long 0xd7006a00                                           // 00000045C3DC: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 00000045C3E0: 02022500
	s_delay_alu instid0(VALU_DEP_1)                            // 00000045C3E4: BF870001
	v_add_co_ci_u32_e64 v1, null, v1, v19, vcc_lo              // 00000045C3E8: D5207C01 01AA2701
	v_fma_mix_f32 v3, v22, v3, neg(0) op_sel_hi:[1,0,0]        // 00000045C3F0: CC200003 8A020716
	v_fma_mix_f32 v2, v23, v2, neg(0) op_sel_hi:[1,0,0]        // 00000045C3F8: CC200002 8A020517
	v_fma_mix_f32 v5, v24, v5, neg(0) op_sel_hi:[1,0,0]        // 00000045C400: CC200005 8A020B18
	v_fma_mix_f32 v4, v25, v4, neg(0) op_sel_hi:[1,0,0]        // 00000045C408: CC200004 8A020919
	v_fma_mix_f32 v6, v26, v6, neg(0) op_sel_hi:[1,0,0]        // 00000045C410: CC200006 8A020D1A
	.long 0x7e2c3983                                           // 00000045C418: 7E2C3983
	v_mul_f32_e32 v9, 0x3db504f3, v9                           // 00000045C41C: 101212FF 3DB504F3
	v_fma_mix_f32 v7, v27, v7, neg(0) op_sel_hi:[1,0,0]        // 00000045C424: CC200007 8A020F1B
	v_fma_mix_f32 v8, v28, v8, neg(0) op_sel_hi:[1,0,0]        // 00000045C42C: CC200008 8A02111C
	.long 0x7e2a3985                                           // 00000045C434: 7E2A3985
	v_and_b32_e32 v10, 1, v22                                  // 00000045C438: 36142C81
	.long 0x7e2c3984                                           // 00000045C43C: 7E2C3984
	v_fma_mix_f32 v9, v20, v9, neg(0) op_sel_hi:[1,0,0]        // 00000045C440: CC200009 8A021314
	.long 0x7e283982                                           // 00000045C448: 7E283982
	.long 0x7e2e3986                                           // 00000045C44C: 7E2E3986
	.long 0x7e303988                                           // 00000045C450: 7E303988
	v_and_b32_e32 v11, 1, v22                                  // 00000045C454: 36162C81
	.long 0x7e2c3987                                           // 00000045C458: 7E2C3987
	v_and_b32_e32 v12, 1, v20                                  // 00000045C45C: 36182881
	v_and_b32_e32 v13, 1, v21                                  // 00000045C460: 361A2A81
	v_and_b32_e32 v14, 1, v23                                  // 00000045C464: 361C2E81
	v_and_b32_e32 v16, 1, v24                                  // 00000045C468: 36203081
	v_and_b32_e32 v15, 1, v22                                  // 00000045C46C: 361E2C81
	.long 0x7e2c3989                                           // 00000045C470: 7E2C3989
	v_add3_u32 v3, v3, v10, 0x7fff                             // 00000045C474: D6550003 03FE1503 00007FFF
	v_add3_u32 v2, v2, v12, 0x7fff                             // 00000045C480: D6550002 03FE1902 00007FFF
	v_add3_u32 v5, v5, v13, 0x7fff                             // 00000045C48C: D6550005 03FE1B05 00007FFF
	v_add3_u32 v4, v4, v11, 0x7fff                             // 00000045C498: D6550004 03FE1704 00007FFF
	v_and_b32_e32 v10, 1, v22                                  // 00000045C4A4: 36142C81
	v_add3_u32 v6, v6, v14, 0x7fff                             // 00000045C4A8: D6550006 03FE1D06 00007FFF
	v_add3_u32 v8, v8, v16, 0x7fff                             // 00000045C4B4: D6550008 03FE2108 00007FFF
	v_add3_u32 v7, v7, v15, 0x7fff                             // 00000045C4C0: D6550007 03FE1F07 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000045C4CC: BF870004
	v_add3_u32 v9, v9, v10, 0x7fff                             // 00000045C4D0: D6550009 03FE1509 00007FFF
	s_clause 0x7                                               // 00000045C4DC: BF850007
	global_store_d16_hi_b16 v[0:1], v2, off                    // 00000045C4E0: DC960000 007C0200
	global_store_d16_hi_b16 v[0:1], v3, off offset:32          // 00000045C4E8: DC960020 007C0300
	global_store_d16_hi_b16 v[0:1], v5, off offset:64          // 00000045C4F0: DC960040 007C0500
	global_store_d16_hi_b16 v[0:1], v4, off offset:96          // 00000045C4F8: DC960060 007C0400
	global_store_d16_hi_b16 v[0:1], v6, off offset:128         // 00000045C500: DC960080 007C0600
	global_store_d16_hi_b16 v[0:1], v7, off offset:160         // 00000045C508: DC9600A0 007C0700
	global_store_d16_hi_b16 v[0:1], v8, off offset:192         // 00000045C510: DC9600C0 007C0800
	global_store_d16_hi_b16 v[0:1], v9, off offset:224         // 00000045C518: DC9600E0 007C0900
	s_nop 0                                                    // 00000045C520: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000045C524: BFB60003
	s_endpgm                                                   // 00000045C528: BFB00000
	s_nop 0                                                    // 00000045C52C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000045C530: BFB60003
	s_endpgm                                                   // 00000045C534: BFB00000
		...

