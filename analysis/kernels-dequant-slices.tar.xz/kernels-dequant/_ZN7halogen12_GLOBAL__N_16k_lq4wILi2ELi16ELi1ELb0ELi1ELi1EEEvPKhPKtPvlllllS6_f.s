00000000007bf300 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007BF300: F4100200 F8000000
	v_and_b32_e32 v23, 15, v0                                  // 0000007BF308: 362E008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000007BF30C: 32020084
	s_ashr_i32 s3, s2, 31                                      // 0000007BF310: 86039F02
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000007BF314: 30000082
	s_lshl_b64 s[2:3], s[2:3], 4                               // 0000007BF318: 84828402
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BF31C: BF870009
	v_dual_mov_b32 v17, s3 :: v_dual_lshlrev_b32 v2, 2, v23    // 0000007BF320: CA220003 11022E82
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000007BF328: 30060282
	v_or_b32_e32 v16, s2, v1                                   // 0000007BF32C: 38200202
	.long 0x7f023880                                           // 0000007BF330: 7F023880
	s_waitcnt lgkmcnt(0)                                       // 0000007BF334: BF89FC07
	s_clause 0x1                                               // 0000007BF338: BF850001
	global_load_b32 v2, v2, s[8:9]                             // 0000007BF33C: DC520000 02080002
	global_load_b32 v3, v3, s[8:9]                             // 0000007BF344: DC520000 03080003
	.long 0xd4540002                                           // 0000007BF34C: D4540002
	v_cndmask_b32_e32 v1, s16, v16, vcc_lo                     // 0000007BF350: 02022010
	s_add_u32 s24, s8, s20                                     // 0000007BF354: 80181408
	s_addc_u32 s25, s9, s21                                    // 0000007BF358: 82191509
	s_ashr_i32 s4, s15, 31                                     // 0000007BF35C: 86049F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BF360: BF870159
	s_lshr_b32 s4, s4, 27                                      // 0000007BF364: 85049B04
	v_cndmask_b32_e64 v8, 0, v16, s2                           // 0000007BF368: D5010008 000A2080
	v_cndmask_b32_e64 v9, 0, s3, s2                            // 0000007BF370: D5010009 00080680
	s_add_u32 s4, s14, s4                                      // 0000007BF378: 8004040E
	s_addc_u32 s5, s15, 0                                      // 0000007BF37C: 8205800F
	.long 0xd72c0004                                           // 0000007BF380: D72C0004
	v_cndmask_b32_e32 v1, s23, v8, vcc_lo                      // 0000007BF384: 02021017
	v_mad_u64_u32 v[12:13], null, s22, v8, 0                   // 0000007BF388: D6FE7C0C 02021016
	s_lshr_b64 s[6:7], s[4:5], 5                               // 0000007BF390: 85868504
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BF394: BF870009
	s_cmpk_lt_i32 s6, 0x81                                     // 0000007BF398: B3860081
	.long 0xd4440004                                           // 0000007BF39C: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007BF3A0: 02022E06
	s_cselect_b32 s3, -1, 0                                    // 0000007BF3A4: 980380C1
	s_cmpk_gt_i32 s6, 0x80                                     // 0000007BF3A8: B2860080
	.long 0xd700050e                                           // 0000007BF3AC: D700050E
	v_cndmask_b32_e32 v1, s24, v12, vcc_lo                     // 0000007BF3B0: 02021818
	s_cselect_b32 s7, -1, 0                                    // 0000007BF3B4: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007BF3B8: BF870159
	s_and_b32 vcc_lo, exec_lo, s7                              // 0000007BF3BC: 8B6A077E
	s_waitcnt vmcnt(1)                                         // 0000007BF3C0: BF8907F7
	v_bfe_u32 v5, v2, 16, 1                                    // 0000007BF3C4: D6100005 02052102
	s_waitcnt vmcnt(0)                                         // 0000007BF3CC: BF8903F7
	v_bfe_u32 v6, v3, 16, 1                                    // 0000007BF3D0: D6100006 02052103
	v_add3_u32 v2, v2, v5, 0x7fff                              // 0000007BF3D8: D6550002 03FE0B02 00007FFF
	.long 0xd72c0005                                           // 0000007BF3E4: D72C0005
	v_cndmask_b32_e32 v1, s22, v9, vcc_lo                      // 0000007BF3E8: 02021216
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BF3EC: BF870193
	v_add3_u32 v3, v3, v6, 0x7fff                              // 0000007BF3F0: D6550003 03FE0D03 00007FFF
	.long 0x7e023982                                           // 0000007BF3FC: 7E023982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BF400: BF870113
	v_add3_u32 v13, v13, v5, v4                                // 0000007BF404: D655000D 04120B0D
	v_and_or_b32 v1, 0xffff0000, v3, v1                        // 0000007BF40C: D6570001 040606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF418: BF870002
	v_add_co_ci_u32_e64 v15, null, s25, v13, s5                // 0000007BF41C: D5207C0F 00161A19
	ds_store_b32 v0, v1                                        // 0000007BF424: D8340000 00000100
	s_waitcnt lgkmcnt(0)                                       // 0000007BF42C: BF89FC07
	s_barrier                                                  // 0000007BF430: BFBD0000
	buffer_gl0_inv                                             // 0000007BF434: E0AC0000 00000000
	s_cbranch_vccnz 144                                        // 0000007BF43C: BFA40090 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x380>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, 0               // 0000007BF440: CA100080 01000080
	s_and_saveexec_b32 s5, s4                                  // 0000007BF448: BE852004
	s_cbranch_execz 10                                         // 0000007BF44C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x178>
	v_lshlrev_b32_e32 v0, 1, v23                               // 0000007BF450: 30002E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF454: BF870091
	.long 0xd7006a02                                           // 0000007BF458: D7006A02
	v_cndmask_b32_e32 v1, v14, v0, vcc_lo                      // 0000007BF45C: 0202010E
	v_add_co_ci_u32_e64 v3, null, 0, v15, vcc_lo               // 0000007BF460: D5207C03 01AA1E80
	global_load_d16_b16 v0, v[2:3], off                        // 0000007BF468: DC820000 007C0002
	s_waitcnt vmcnt(0)                                         // 0000007BF470: BF8903F7
	v_cvt_f32_f16_e32 v0, v0                                   // 0000007BF474: 7E001700
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BF478: 8C7E057E
	v_or_b32_e32 v2, 16, v23                                   // 0000007BF47C: 38042E90
	s_mov_b32 s4, exec_lo                                      // 0000007BF480: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF484: BF870001
	.long 0xd4c4007e                                           // 0000007BF488: D4C4007E
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000007BF48C: 02020406
	s_cbranch_execz 10                                         // 0000007BF490: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1bc>
	v_lshlrev_b32_e32 v1, 1, v2                                // 0000007BF494: 30020481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF498: BF870091
	.long 0xd7006a01                                           // 0000007BF49C: D7006A01
	v_cndmask_b32_e32 v1, v14, v1, vcc_lo                      // 0000007BF4A0: 0202030E
	v_add_co_ci_u32_e64 v2, null, 0, v15, vcc_lo               // 0000007BF4A4: D5207C02 01AA1E80
	global_load_d16_b16 v1, v[1:2], off                        // 0000007BF4AC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000007BF4B4: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007BF4B8: 7E021701
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF4BC: 8C7E047E
	v_or_b32_e32 v4, 32, v23                                   // 0000007BF4C0: 38082EA0
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v2, 0               // 0000007BF4C4: CA100080 03020080
	s_mov_b32 s4, exec_lo                                      // 0000007BF4CC: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF4D0: BF870002
	.long 0xd4c4007e                                           // 0000007BF4D4: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007BF4D8: 02020806
	s_cbranch_execz 10                                         // 0000007BF4DC: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x208>
	v_lshlrev_b32_e32 v2, 1, v4                                // 0000007BF4E0: 30040881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF4E4: BF870091
	.long 0xd7006a04                                           // 0000007BF4E8: D7006A04
	v_cndmask_b32_e32 v1, v14, v2, vcc_lo                      // 0000007BF4EC: 0202050E
	v_add_co_ci_u32_e64 v5, null, 0, v15, vcc_lo               // 0000007BF4F0: D5207C05 01AA1E80
	global_load_d16_b16 v2, v[4:5], off                        // 0000007BF4F8: DC820000 027C0004
	s_waitcnt vmcnt(0)                                         // 0000007BF500: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007BF504: 7E041702
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF508: 8C7E047E
	v_or_b32_e32 v4, 48, v23                                   // 0000007BF50C: 38082EB0
	s_mov_b32 s4, exec_lo                                      // 0000007BF510: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF514: BF870001
	.long 0xd4c4007e                                           // 0000007BF518: D4C4007E
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000007BF51C: 02020806
	s_cbranch_execz 10                                         // 0000007BF520: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x24c>
	v_lshlrev_b32_e32 v3, 1, v4                                // 0000007BF524: 30060881
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF528: BF870091
	.long 0xd7006a03                                           // 0000007BF52C: D7006A03
	v_cndmask_b32_e32 v1, v14, v3, vcc_lo                      // 0000007BF530: 0202070E
	v_add_co_ci_u32_e64 v4, null, 0, v15, vcc_lo               // 0000007BF534: D5207C04 01AA1E80
	global_load_d16_b16 v3, v[3:4], off                        // 0000007BF53C: DC820000 037C0003
	s_waitcnt vmcnt(0)                                         // 0000007BF544: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007BF548: 7E061703
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF54C: 8C7E047E
	v_or_b32_e32 v6, 64, v23                                   // 0000007BF550: 380C2EC0
	v_dual_mov_b32 v5, 0 :: v_dual_mov_b32 v4, 0               // 0000007BF554: CA100080 05040080
	s_mov_b32 s4, exec_lo                                      // 0000007BF55C: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF560: BF870002
	.long 0xd4c4007e                                           // 0000007BF564: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007BF568: 02020C06
	s_cbranch_execz 10                                         // 0000007BF56C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x298>
	v_lshlrev_b32_e32 v4, 1, v6                                // 0000007BF570: 30080C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF574: BF870091
	.long 0xd7006a06                                           // 0000007BF578: D7006A06
	v_cndmask_b32_e32 v1, v14, v4, vcc_lo                      // 0000007BF57C: 0202090E
	v_add_co_ci_u32_e64 v7, null, 0, v15, vcc_lo               // 0000007BF580: D5207C07 01AA1E80
	global_load_d16_b16 v4, v[6:7], off                        // 0000007BF588: DC820000 047C0006
	s_waitcnt vmcnt(0)                                         // 0000007BF590: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007BF594: 7E081704
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF598: 8C7E047E
	v_or_b32_e32 v6, 0x50, v23                                 // 0000007BF59C: 380C2EFF 00000050
	s_mov_b32 s4, exec_lo                                      // 0000007BF5A4: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF5A8: BF870001
	.long 0xd4c4007e                                           // 0000007BF5AC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 0000007BF5B0: 02020C06
	s_cbranch_execz 10                                         // 0000007BF5B4: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2e0>
	v_lshlrev_b32_e32 v5, 1, v6                                // 0000007BF5B8: 300A0C81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF5BC: BF870091
	.long 0xd7006a05                                           // 0000007BF5C0: D7006A05
	v_cndmask_b32_e32 v1, v14, v5, vcc_lo                      // 0000007BF5C4: 02020B0E
	v_add_co_ci_u32_e64 v6, null, 0, v15, vcc_lo               // 0000007BF5C8: D5207C06 01AA1E80
	global_load_d16_b16 v5, v[5:6], off                        // 0000007BF5D0: DC820000 057C0005
	s_waitcnt vmcnt(0)                                         // 0000007BF5D8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007BF5DC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF5E0: 8C7E047E
	v_or_b32_e32 v10, 0x60, v23                                // 0000007BF5E4: 38142EFF 00000060
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000007BF5EC: CA100080 07060080
	s_mov_b32 s4, exec_lo                                      // 0000007BF5F4: BE84007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BF5F8: BF870002
	.long 0xd4c4007e                                           // 0000007BF5FC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007BF600: 02021406
	s_cbranch_execz 10                                         // 0000007BF604: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x330>
	v_lshlrev_b32_e32 v6, 1, v10                               // 0000007BF608: 300C1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF60C: BF870091
	.long 0xd7006a0a                                           // 0000007BF610: D7006A0A
	v_cndmask_b32_e32 v1, v14, v6, vcc_lo                      // 0000007BF614: 02020D0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007BF618: D5207C0B 01AA1E80
	global_load_d16_b16 v6, v[10:11], off                      // 0000007BF620: DC820000 067C000A
	s_waitcnt vmcnt(0)                                         // 0000007BF628: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007BF62C: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF630: 8C7E047E
	v_or_b32_e32 v10, 0x70, v23                                // 0000007BF634: 38142EFF 00000070
	s_mov_b32 s4, exec_lo                                      // 0000007BF63C: BE84007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF640: BF870001
	.long 0xd4c4007e                                           // 0000007BF644: D4C4007E
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 0000007BF648: 02021406
	s_cbranch_execz 10                                         // 0000007BF64C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x378>
	v_lshlrev_b32_e32 v7, 1, v10                               // 0000007BF650: 300E1481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF654: BF870091
	.long 0xd7006a0a                                           // 0000007BF658: D7006A0A
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 0000007BF65C: 02020F0E
	v_add_co_ci_u32_e64 v11, null, 0, v15, vcc_lo              // 0000007BF660: D5207C0B 01AA1E80
	global_load_d16_b16 v7, v[10:11], off                      // 0000007BF668: DC820000 077C000A
	s_waitcnt vmcnt(0)                                         // 0000007BF670: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007BF674: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007BF678: 8C7E047E
	s_branch 9                                                 // 0000007BF67C: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3a4>
	v_mov_b32_e32 v0, 0                                        // 0000007BF680: 7E000280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF684: BF870001
	v_mov_b32_e32 v1, v0                                       // 0000007BF688: 7E020300
	v_mov_b32_e32 v2, v0                                       // 0000007BF68C: 7E040300
	v_mov_b32_e32 v3, v0                                       // 0000007BF690: 7E060300
	v_mov_b32_e32 v4, v0                                       // 0000007BF694: 7E080300
	v_mov_b32_e32 v5, v0                                       // 0000007BF698: 7E0A0300
	v_mov_b32_e32 v6, v0                                       // 0000007BF69C: 7E0C0300
	v_mov_b32_e32 v7, v0                                       // 0000007BF6A0: 7E0E0300
	s_add_u32 s4, s8, s18                                      // 0000007BF6A4: 80041208
	s_addc_u32 s5, s9, s19                                     // 0000007BF6A8: 82051309
	s_lshr_b32 s18, s15, 31                                    // 0000007BF6AC: 85129F0F
	v_mov_b32_e32 v26, 0                                       // 0000007BF6B0: 7E340280
	s_add_u32 s18, s14, s18                                    // 0000007BF6B4: 8012120E
	s_addc_u32 s19, s15, 0                                     // 0000007BF6B8: 8213800F
	v_cndmask_b32_e64 v24, 0, 1, s7                            // 0000007BF6BC: D5010018 001D0280
	s_ashr_i64 s[18:19], s[18:19], 1                           // 0000007BF6C4: 86928112
	v_mov_b32_e32 v27, 0                                       // 0000007BF6C8: 7E360280
	v_mad_u64_u32 v[18:19], null, v8, s18, s[4:5]              // 0000007BF6CC: D6FE7C12 00102508
	.long 0xd72c000b                                           // 0000007BF6D4: D72C000B
	v_cndmask_b32_e32 v0, v8, v19, vcc_lo                      // 0000007BF6D8: 02002708
	.long 0xd72c0014                                           // 0000007BF6DC: D72C0014
	v_cndmask_b32_e32 v0, v9, v18, vcc_lo                      // 0000007BF6E0: 02002509
	.long 0xd4440004                                           // 0000007BF6E4: D4440004
	v_cndmask_b32_e32 v1, s6, v23, vcc_lo                      // 0000007BF6E8: 02022E06
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000007BF6EC: CA100080 08080080
	v_mov_b32_e32 v10, 0                                       // 0000007BF6F4: 7E140280
	s_delay_alu instid0(VALU_DEP_4)                            // 0000007BF6F8: BF870004
	v_add3_u32 v25, v20, v19, v11                              // 0000007BF6FC: D6550019 042E2714
	v_mov_b32_e32 v11, 0                                       // 0000007BF704: 7E160280
	s_and_saveexec_b32 s5, s4                                  // 0000007BF708: BE852004
	s_cbranch_execz 21                                         // 0000007BF70C: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_dual_mov_b32 v27, 0 :: v_dual_lshlrev_b32 v8, 4, v23     // 0000007BF710: CA220080 1B082E84
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF718: BF870091
	.long 0xd7006a08                                           // 0000007BF71C: D7006A08
	v_cndmask_b32_e32 v1, v18, v8, vcc_lo                      // 0000007BF720: 02021112
	v_add_co_ci_u32_e64 v9, null, 0, v25, vcc_lo               // 0000007BF724: D5207C09 01AA3280
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 0000007BF72C: 916A077E
	global_load_b128 v[8:11], v[8:9], off                      // 0000007BF730: DC5E0000 087C0008
	s_cbranch_vccnz 10                                         // 0000007BF738: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x464>
	v_lshlrev_b32_e32 v19, 1, v23                              // 0000007BF73C: 30262E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BF740: BF870091
	.long 0xd7006a0e                                           // 0000007BF744: D7006A0E
	v_cndmask_b32_e32 v1, v14, v19, vcc_lo                     // 0000007BF748: 0202270E
	v_add_co_ci_u32_e64 v15, null, 0, v15, vcc_lo              // 0000007BF74C: D5207C0F 01AA1E80
	global_load_d16_b16 v14, v[14:15], off                     // 0000007BF754: DC820000 0E7C000E
	s_waitcnt vmcnt(0)                                         // 0000007BF75C: BF8903F7
	v_cvt_f32_f16_e32 v27, v14                                 // 0000007BF760: 7E36170E
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BF764: 8C7E057E
	v_mov_b32_e32 v28, 0                                       // 0000007BF768: 7E380280
	s_and_saveexec_b32 s5, s4                                  // 0000007BF76C: BE852004
	s_cbranch_execz 305                                        // 0000007BF770: BFA50131 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x938>
	v_dual_mov_b32 v31, v27 :: v_dual_lshlrev_b32 v14, 1, v23  // 0000007BF774: CA22011B 1F0E2E81
	.long 0xd7006a0c                                           // 0000007BF77C: D7006A0C
	v_cndmask_b32_e32 v1, s20, v12, vcc_lo                     // 0000007BF780: 02021814
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BF784: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s21, v13, vcc_lo            // 0000007BF788: D5207C0D 01AA1A15
	v_dual_mov_b32 v20, 0 :: v_dual_lshlrev_b32 v19, 5, v23    // 0000007BF790: CA220080 14122E85
	.long 0xd7006a0c                                           // 0000007BF798: D7006A0C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 0000007BF79C: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BF7A0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, vcc_lo              // 0000007BF7A4: D5207C0D 01AA1A80
	v_lshl_or_b32 v29, v23, 4, 0x100                           // 0000007BF7AC: D656001D 03FD0917 00000100
	.long 0xd7006a0c                                           // 0000007BF7B8: D7006A0C
	v_cndmask_b32_e32 v1, s8, v12, vcc_lo                      // 0000007BF7BC: 02021808
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BF7C0: BF8701A1
	v_add_co_ci_u32_e64 v13, null, s9, v13, vcc_lo             // 0000007BF7C4: D5207C0D 01AA1A09
	v_mov_b32_e32 v30, v23                                     // 0000007BF7CC: 7E3C0317
	.long 0xd7006a15                                           // 0000007BF7D0: D7006A15
	v_cndmask_b32_e32 v0, v12, v160, vcc_lo                    // 0000007BF7D4: 0201410C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF7D8: BF870001
	v_add_co_ci_u32_e64 v22, null, 0, v13, vcc_lo              // 0000007BF7DC: D5207C16 01AA1A80
	v_mov_b32_e32 v28, v20                                     // 0000007BF7E4: 7E380314
	v_mov_b32_e32 v26, v20                                     // 0000007BF7E8: 7E340314
	s_mov_b32 s7, 0                                            // 0000007BF7EC: BE870080
	s_lshl_b64 s[8:9], s[14:15], 1                             // 0000007BF7F0: 8488810E
	s_branch 243                                               // 0000007BF7F4: BFA000F3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x8c4>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000007BF7F8: 8C7E0E7E
	.long 0xd73c0020                                           // 0000007BF7FC: D73C0020
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007BF800: 02022681
	v_and_b32_e32 v64, 0xff, v8                                // 0000007BF804: 368010FF 000000FF
	v_lshrrev_b32_e32 v65, 6, v8                               // 0000007BF80C: 32821086
	v_lshrrev_b32_e32 v66, 14, v8                              // 0000007BF810: 3284108E
	v_lshrrev_b32_e32 v8, 22, v8                               // 0000007BF814: 32101096
	v_and_b32_e32 v67, 0xff, v9                                // 0000007BF818: 368612FF 000000FF
	.long 0xd7006a38                                           // 0000007BF820: D7006A38
	v_cndmask_b32_e32 v1, s10, v32, vcc_lo                     // 0000007BF824: 0202400A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BF828: BF8701A1
	v_add_co_ci_u32_e64 v57, null, s11, v33, vcc_lo            // 0000007BF82C: D5207C39 01AA420B
	v_lshlrev_b32_e32 v64, 2, v64                              // 0000007BF834: 30808082
	.long 0xd7006a3c                                           // 0000007BF838: D7006A3C
	v_cndmask_b32_e32 v0, v56, v8, vcc_lo                      // 0000007BF83C: 02001138
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BF840: BF870001
	v_add_co_ci_u32_e64 v61, null, s9, v57, vcc_lo             // 0000007BF844: D5207C3D 01AA7209
	v_and_b32_e32 v65, 0x3fc, v65                              // 0000007BF84C: 368282FF 000003FC
	ds_load_b32 v64, v64                                       // 0000007BF854: D8D80000 40000040
	s_clause 0x7                                               // 0000007BF85C: BF850007
	global_load_b128 v[32:35], v[56:57], off                   // 0000007BF860: DC5E0000 207C0038
	global_load_b128 v[36:39], v[60:61], off                   // 0000007BF868: DC5E0000 247C003C
	global_load_b128 v[40:43], v[56:57], off offset:16         // 0000007BF870: DC5E0010 287C0038
	global_load_b128 v[44:47], v[60:61], off offset:16         // 0000007BF878: DC5E0010 2C7C003C
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000007BF880: DC5E0020 307C0038
	global_load_b128 v[52:55], v[60:61], off offset:32         // 0000007BF888: DC5E0020 347C003C
	global_load_b128 v[56:59], v[56:57], off offset:48         // 0000007BF890: DC5E0030 387C0038
	global_load_b128 v[60:63], v[60:61], off offset:48         // 0000007BF898: DC5E0030 3C7C003C
	v_and_b32_e32 v66, 0x3fc, v66                              // 0000007BF8A0: 368484FF 000003FC
	v_lshrrev_b32_e32 v68, 6, v9                               // 0000007BF8A8: 32881286
	ds_load_b32 v65, v65                                       // 0000007BF8AC: D8D80000 41000041
	v_lshrrev_b32_e32 v69, 14, v9                              // 0000007BF8B4: 328A128E
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007BF8B8: 32121296
	ds_load_b32 v66, v66                                       // 0000007BF8BC: D8D80000 42000042
	v_and_b32_e32 v8, 0x3fc, v8                                // 0000007BF8C4: 361010FF 000003FC
	v_lshlrev_b32_e32 v67, 2, v67                              // 0000007BF8CC: 30868682
	v_and_b32_e32 v68, 0x3fc, v68                              // 0000007BF8D0: 368888FF 000003FC
	v_and_b32_e32 v69, 0x3fc, v69                              // 0000007BF8D8: 368A8AFF 000003FC
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007BF8E0: 361212FF 000003FC
	ds_load_b32 v8, v8                                         // 0000007BF8E8: D8D80000 08000008
	ds_load_b32 v67, v67                                       // 0000007BF8F0: D8D80000 43000043
	ds_load_b32 v68, v68                                       // 0000007BF8F8: D8D80000 44000044
	ds_load_b32 v69, v69                                       // 0000007BF900: D8D80000 45000045
	ds_load_b32 v9, v9                                         // 0000007BF908: D8D80000 09000009
	.long 0xd7006a15                                           // 0000007BF910: D7006A15
	v_cndmask_b32_e32 v0, v21, v160, vcc_lo                    // 0000007BF914: 02014115
	v_add_nc_u32_e32 v29, 0x100, v29                           // 0000007BF918: 4A3A3AFF 00000100
	v_add_co_ci_u32_e64 v22, null, 0, v22, vcc_lo              // 0000007BF920: D5207C16 01AA2C80
	s_and_b32 s4, exec_lo, s4                                  // 0000007BF928: 8B04047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007BF92C: BF870009
	s_or_b32 s7, s4, s7                                        // 0000007BF930: 8C070704
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 0000007BF934: BF891C77
	v_dot2_f32_bf16 v32, v32, v64, 0                           // 0000007BF938: CC1A4020 1A028120
	s_waitcnt vmcnt(6)                                         // 0000007BF940: BF891BF7
	v_dot2_f32_bf16 v36, v36, v64, 0                           // 0000007BF944: CC1A4024 1A028124
	v_and_b32_e32 v64, 0xff, v10                               // 0000007BF94C: 368014FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 0000007BF954: BF89FC67
	v_dot2_f32_bf16 v32, v33, v65, v32                         // 0000007BF958: CC1A4020 1C828321
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BF960: BF870003
	v_dot2_f32_bf16 v33, v37, v65, v36                         // 0000007BF964: CC1A4021 1C928325
	v_lshrrev_b32_e32 v36, 6, v10                              // 0000007BF96C: 32481486
	v_lshrrev_b32_e32 v37, 14, v10                             // 0000007BF970: 324A148E
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007BF974: 32141496
	s_waitcnt lgkmcnt(5)                                       // 0000007BF978: BF89FC57
	v_dot2_f32_bf16 v32, v34, v66, v32                         // 0000007BF97C: CC1A4020 1C828522
	v_dot2_f32_bf16 v33, v38, v66, v33                         // 0000007BF984: CC1A4021 1C868526
	v_and_b32_e32 v34, 0xff, v11                               // 0000007BF98C: 364416FF 000000FF
	v_lshrrev_b32_e32 v38, 6, v11                              // 0000007BF994: 324C1686
	v_lshrrev_b32_e32 v65, 14, v11                             // 0000007BF998: 3282168E
	s_waitcnt lgkmcnt(4)                                       // 0000007BF99C: BF89FC47
	v_dot2_f32_bf16 v32, v35, v8, v32                          // 0000007BF9A0: CC1A4020 1C821123
	v_dot2_f32_bf16 v8, v39, v8, v33                           // 0000007BF9A8: CC1A4008 1C861127
	v_and_b32_e32 v35, 0x3fc, v36                              // 0000007BF9B0: 364648FF 000003FC
	v_and_b32_e32 v36, 0x3fc, v37                              // 0000007BF9B8: 36484AFF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007BF9C0: 32161696
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000007BF9C4: BF891437
	v_dot2_f32_bf16 v32, v40, v67, v32                         // 0000007BF9C8: CC1A4020 1C828728
	s_waitcnt vmcnt(4)                                         // 0000007BF9D0: BF8913F7
	v_dot2_f32_bf16 v8, v44, v67, v8                           // 0000007BF9D4: CC1A4008 1C22872C
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007BF9DC: 361414FF 000003FC
	v_lshlrev_b32_e32 v34, 2, v34                              // 0000007BF9E4: 30444482
	v_and_b32_e32 v37, 0x3fc, v38                              // 0000007BF9E8: 364A4CFF 000003FC
	s_waitcnt lgkmcnt(2)                                       // 0000007BF9F0: BF89FC27
	v_dot2_f32_bf16 v32, v41, v68, v32                         // 0000007BF9F4: CC1A4020 1C828929
	v_dot2_f32_bf16 v8, v45, v68, v8                           // 0000007BF9FC: CC1A4008 1C22892D
	v_and_b32_e32 v38, 0x3fc, v65                              // 0000007BFA04: 364C82FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007BFA0C: 361616FF 000003FC
	ds_load_b32 v35, v35                                       // 0000007BFA14: D8D80000 23000023
	ds_load_b32 v36, v36                                       // 0000007BFA1C: D8D80000 24000024
	s_waitcnt lgkmcnt(3)                                       // 0000007BFA24: BF89FC37
	v_dot2_f32_bf16 v32, v42, v69, v32                         // 0000007BFA28: CC1A4020 1C828B2A
	v_cndmask_b32_e64 v42, v27, v0, s3                         // 0000007BFA30: D501002A 000E011B
	v_lshlrev_b32_e32 v33, 2, v64                              // 0000007BFA38: 30428082
	v_dot2_f32_bf16 v8, v46, v69, v8                           // 0000007BFA3C: CC1A4008 1C228B2E
	v_mov_b32_e32 v27, v31                                     // 0000007BFA44: 7E36031F
	s_waitcnt lgkmcnt(2)                                       // 0000007BFA48: BF89FC27
	v_dot2_f32_bf16 v32, v43, v9, v32                          // 0000007BFA4C: CC1A4020 1C82132B
	ds_load_b32 v33, v33                                       // 0000007BFA54: D8D80000 21000021
	v_dot2_f32_bf16 v8, v47, v9, v8                            // 0000007BFA5C: CC1A4008 1C22132F
	ds_load_b32 v9, v10                                        // 0000007BFA64: D8D80000 0900000A
	ds_load_b32 v10, v34                                       // 0000007BFA6C: D8D80000 0A000022
	ds_load_b32 v39, v37                                       // 0000007BFA74: D8D80000 27000025
	ds_load_b32 v40, v38                                       // 0000007BFA7C: D8D80000 28000026
	ds_load_b32 v41, v11                                       // 0000007BFA84: D8D80000 2900000B
	v_cndmask_b32_e64 v37, v5, v6, s3                          // 0000007BFA8C: D5010025 000E0D05
	v_cndmask_b32_e64 v38, v6, v7, s3                          // 0000007BFA94: D5010026 000E0F06
	v_cndmask_b32_e64 v34, v2, v3, s3                          // 0000007BFA9C: D5010022 000E0702
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007BFAA4: BF890C57
	v_dot2_f32_bf16 v11, v48, v33, v32                         // 0000007BFAA8: CC1A400B 1C824330
	s_waitcnt vmcnt(2)                                         // 0000007BFAB0: BF890BF7
	v_dot2_f32_bf16 v8, v52, v33, v8                           // 0000007BFAB4: CC1A4008 1C224334
	v_cndmask_b32_e64 v33, v1, v2, s3                          // 0000007BFABC: D5010021 000E0501
	v_cndmask_b32_e64 v32, v0, v1, s3                          // 0000007BFAC4: D5010020 000E0300
	v_dot2_f32_bf16 v11, v49, v35, v11                         // 0000007BFACC: CC1A400B 1C2E4731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007BFAD4: BF8701A4
	v_dot2_f32_bf16 v8, v53, v35, v8                           // 0000007BFAD8: CC1A4008 1C224735
	v_cndmask_b32_e64 v35, v3, v4, s3                          // 0000007BFAE0: D5010023 000E0903
	v_dot2_f32_bf16 v11, v50, v36, v11                         // 0000007BFAE8: CC1A400B 1C2E4932
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007BFAF0: BF8701B3
	v_dot2_f32_bf16 v8, v54, v36, v8                           // 0000007BFAF4: CC1A4008 1C224936
	v_cndmask_b32_e64 v36, v4, v5, s3                          // 0000007BFAFC: D5010024 000E0B04
	s_waitcnt lgkmcnt(4)                                       // 0000007BFB04: BF89FC47
	v_dot2_f32_bf16 v11, v51, v9, v11                          // 0000007BFB08: CC1A400B 1C2E1333
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000007BFB10: BF8701B3
	v_dot2_f32_bf16 v8, v55, v9, v8                            // 0000007BFB14: CC1A4008 1C221337
	v_mov_b32_e32 v9, v13                                      // 0000007BFB1C: 7E12030D
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000007BFB20: BF890437
	v_dot2_f32_bf16 v4, v56, v10, v11                          // 0000007BFB24: CC1A4004 1C2E1538
	s_waitcnt vmcnt(0)                                         // 0000007BFB2C: BF8903F7
	v_dot2_f32_bf16 v5, v60, v10, v8                           // 0000007BFB30: CC1A4005 1C22153C
	v_dual_mov_b32 v11, v15 :: v_dual_mov_b32 v10, v14         // 0000007BFB38: CA10010F 0B0A010E
	v_mov_b32_e32 v8, v12                                      // 0000007BFB40: 7E10030C
	s_waitcnt lgkmcnt(2)                                       // 0000007BFB44: BF89FC27
	v_dot2_f32_bf16 v0, v57, v39, v4                           // 0000007BFB48: CC1A4000 1C124F39
	v_dot2_f32_bf16 v1, v61, v39, v5                           // 0000007BFB50: CC1A4001 1C164F3D
	v_mov_b32_e32 v39, v7                                      // 0000007BFB58: 7E4E0307
	v_add_nc_u32_e32 v19, 0x200, v19                           // 0000007BFB5C: 4A2626FF 00000200
	s_waitcnt lgkmcnt(1)                                       // 0000007BFB64: BF89FC17
	v_dot2_f32_bf16 v0, v58, v40, v0                           // 0000007BFB68: CC1A4000 1C02513A
	v_dot2_f32_bf16 v1, v62, v40, v1                           // 0000007BFB70: CC1A4001 1C06513E
	s_waitcnt lgkmcnt(0)                                       // 0000007BFB78: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFB7C: BF870112
	v_dot2_f32_bf16 v0, v59, v41, v0                           // 0000007BFB80: CC1A4000 1C02533B
	v_dot2_f32_bf16 v1, v63, v41, v1                           // 0000007BFB88: CC1A4001 1C06533F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFB90: BF870112
	v_fmac_f32_e32 v28, v42, v0                                // 0000007BFB94: 5638012A
	v_fmac_f32_e32 v26, v42, v1                                // 0000007BFB98: 5634032A
	v_dual_mov_b32 v0, v32 :: v_dual_mov_b32 v1, v33           // 0000007BFB9C: CA100120 00000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007BFBA4: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007BFBAC: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007BFBB4: CA100126 06060127
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000007BFBBC: 917E077E
	s_cbranch_execz 28                                         // 0000007BFBC0: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x934>
	s_waitcnt vmcnt(0)                                         // 0000007BFBC4: BF8903F7
	v_dual_mov_b32 v13, v9 :: v_dual_add_nc_u32 v30, 16, v30   // 0000007BFBC8: CA200109 0D1E3C90
	v_dual_mov_b32 v12, v8 :: v_dual_mov_b32 v15, v11          // 0000007BFBD0: CA100108 0C0E010B
	v_mov_b32_e32 v14, v10                                     // 0000007BFBD8: 7E1C030A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007BFBDC: BF870003
	.long 0xd4430004                                           // 0000007BFBE0: D4430004
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007BFBE4: 02023C06
	s_mov_b32 s14, exec_lo                                     // 0000007BFBE8: BE8E007E
	.long 0xd4c4007e                                           // 0000007BFBEC: D4C4007E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 0000007BFBF0: 02023C06
	s_cbranch_execz 65280                                      // 0000007BFBF4: BFA5FF00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	.long 0xd7006a0c                                           // 0000007BFBF8: D7006A0C
	v_cndmask_b32_e32 v1, v18, v29, vcc_lo                     // 0000007BFBFC: 02023B12
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BFC00: BF870001
	v_add_co_ci_u32_e64 v13, null, 0, v25, vcc_lo              // 0000007BFC04: D5207C0D 01AA3280
	v_cmp_ne_u32_e32 vcc_lo, 1, v24                            // 0000007BFC0C: 7C9A3081
	v_mov_b32_e32 v31, v27                                     // 0000007BFC10: 7E3E031B
	global_load_b128 v[12:15], v[12:13], off                   // 0000007BFC14: DC5E0000 0C7C000C
	s_cbranch_vccnz 65270                                      // 0000007BFC1C: BFA4FEF6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	global_load_d16_b16 v31, v[21:22], off                     // 0000007BFC20: DC820000 1F7C0015
	s_waitcnt vmcnt(0)                                         // 0000007BFC28: BF8903F7
	v_cvt_f32_f16_e32 v31, v31                                 // 0000007BFC2C: 7E3E171F
	s_branch 65265                                             // 0000007BFC30: BFA0FEF1 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4f8>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000007BFC34: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BFC38: BF8700A9
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007BFC3C: 8C7E057E
	.long 0xd71f0000                                           // 0000007BFC40: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007BFC44: 020100C1
	v_xor_b32_e32 v1, 8, v0                                    // 0000007BFC48: 3A020088
	v_xor_b32_e32 v3, 4, v0                                    // 0000007BFC4C: 3A060084
	v_xor_b32_e32 v5, 2, v0                                    // 0000007BFC50: 3A0A0082
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BFC54: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v1                            // 0000007BFC58: 7C9802A0
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 0000007BFC5C: 02020300
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007BFC60: 7C9806A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007BFC64: BF870002
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007BFC68: 30020282
	v_cndmask_b32_e32 v3, v0, v3, vcc_lo                       // 0000007BFC6C: 02060700
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007BFC70: 7C980AA0
	ds_bpermute_b32 v2, v1, v28                                // 0000007BFC74: DACC0000 02001C01
	s_waitcnt lgkmcnt(0)                                       // 0000007BFC7C: BF89FC07
	v_dual_add_f32 v2, v28, v2 :: v_dual_lshlrev_b32 v3, 2, v3 // 0000007BFC80: C922051C 02020682
	ds_bpermute_b32 v1, v1, v26                                // 0000007BFC88: DACC0000 01001A01
	ds_bpermute_b32 v4, v3, v2                                 // 0000007BFC90: DACC0000 04000203
	s_waitcnt lgkmcnt(1)                                       // 0000007BFC98: BF89FC17
	v_add_f32_e32 v1, v26, v1                                  // 0000007BFC9C: 0602031A
	s_waitcnt lgkmcnt(0)                                       // 0000007BFCA0: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 0000007BFCA4: 06040902
	ds_bpermute_b32 v3, v3, v1                                 // 0000007BFCA8: DACC0000 03000103
	v_cndmask_b32_e32 v5, v0, v5, vcc_lo                       // 0000007BFCB0: 020A0B00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007BFCB4: BF870001
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000007BFCB8: 300A0A82
	s_waitcnt lgkmcnt(0)                                       // 0000007BFCBC: BF89FC07
	v_add_f32_e32 v1, v1, v3                                   // 0000007BFCC0: 06020701
	ds_bpermute_b32 v3, v5, v2                                 // 0000007BFCC4: DACC0000 03000205
	ds_bpermute_b32 v4, v5, v1                                 // 0000007BFCCC: DACC0000 04000105
	v_xor_b32_e32 v5, 1, v0                                    // 0000007BFCD4: 3A0A0081
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007BFCD8: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v5                            // 0000007BFCDC: 7C980AA0
	v_cndmask_b32_e32 v0, v0, v5, vcc_lo                       // 0000007BFCE0: 02000B00
	v_cmp_eq_u32_e32 vcc_lo, 0, v23                            // 0000007BFCE4: 7C942E80
	s_waitcnt lgkmcnt(1)                                       // 0000007BFCE8: BF89FC17
	v_dual_add_f32 v2, v2, v3 :: v_dual_lshlrev_b32 v5, 2, v0  // 0000007BFCEC: C9220702 02040082
	s_and_b32 s2, vcc_lo, s2                                   // 0000007BFCF4: 8B02026A
	s_waitcnt lgkmcnt(0)                                       // 0000007BFCF8: BF89FC07
	v_add_f32_e32 v0, v1, v4                                   // 0000007BFCFC: 06000901
	ds_bpermute_b32 v3, v5, v2                                 // 0000007BFD00: DACC0000 03000205
	ds_bpermute_b32 v1, v5, v0                                 // 0000007BFD08: DACC0000 01000005
	s_and_saveexec_b32 s3, s2                                  // 0000007BFD10: BE832002
	s_cbranch_execz 119                                        // 0000007BFD14: BFA50077 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi16ELi1ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xbf4>
	s_waitcnt lgkmcnt(1)                                       // 0000007BFD18: BF89FC17
	v_add_f32_e32 v2, v2, v3                                   // 0000007BFD1C: 06040702
	.long 0x7f063880                                           // 0000007BFD20: 7F063880
	s_waitcnt lgkmcnt(0)                                       // 0000007BFD24: BF89FC07
	v_add_f32_e32 v0, v0, v1                                   // 0000007BFD28: 06000300
	s_load_b32 s0, s[0:1], 0x48                                // 0000007BFD2C: F4000000 F8000048
	.long 0x7e023982                                           // 0000007BFD34: 7E023982
	.long 0x7f023983                                           // 0000007BFD38: 7F023983
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFD3C: BF870091
	v_and_b32_e32 v1, 1, v1                                    // 0000007BFD40: 36020281
	v_add3_u32 v1, v2, v1, 0x7fff                              // 0000007BFD44: D6550001 03FE0302 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BFD50: BF8700A1
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000007BFD54: 360202FF FFFF0000
	s_waitcnt lgkmcnt(0)                                       // 0000007BFD5C: BF89FC07
	v_mul_f32_e32 v1, s0, v1                                   // 0000007BFD60: 10020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFD64: BF870091
	v_mul_f32_e32 v2, 0xbfb8aa3b, v1                           // 0000007BFD68: 100402FF BFB8AA3B
	v_exp_f32_e32 v2, v2                                       // 0000007BFD70: 7E044B02
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFD74: BF870095
	v_add_f32_e32 v2, 1.0, v2                                  // 0000007BFD78: 060404F2
	v_div_scale_f32 v5, null, v2, v2, v1                       // 0000007BFD7C: D6FC7C05 04060502
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000007BFD84: BF8702A1
	v_rcp_f32_e32 v7, v5                                       // 0000007BFD88: 7E0E5505
	s_waitcnt vmcnt(0)                                         // 0000007BFD8C: BF8903F7
	v_fma_f32 v9, -v5, v7, 1.0                                 // 0000007BFD90: D6130009 23CA0F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007BFD98: BF8700A1
	v_fmac_f32_e32 v7, v9, v7                                  // 0000007BFD9C: 560E0F09
	.long 0x7e063980                                           // 0000007BFDA0: 7E063980
	v_and_b32_e32 v4, 1, v3                                    // 0000007BFDA4: 36080681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFDA8: BF870091
	v_add3_u32 v0, v0, v4, 0x7fff                              // 0000007BFDAC: D6550000 03FE0900 00007FFF
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007BFDB8: 360000FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFDC0: BF870091
	v_mul_f32_e32 v0, s0, v0                                   // 0000007BFDC4: 10000000
	v_mul_f32_e32 v4, 0xbfb8aa3b, v0                           // 0000007BFDC8: 100800FF BFB8AA3B
	v_div_scale_f32 v11, vcc_lo, v1, v2, v1                    // 0000007BFDD0: D6FC6A0B 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007BFDD8: BF870292
	v_exp_f32_e32 v4, v4                                       // 0000007BFDDC: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 0000007BFDE0: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007BFDE4: BF870121
	v_div_scale_f32 v6, null, v4, v4, v0                       // 0000007BFDE8: D6FC7C06 04020904
	v_div_scale_f32 v9, s0, v0, v4, v0                         // 0000007BFDF0: D6FC0009 04020900
	v_rcp_f32_e32 v8, v6                                       // 0000007BFDF8: 7E105506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007BFDFC: BF870095
	v_fma_f32 v10, -v6, v8, 1.0                                // 0000007BFE00: D613000A 23CA1106
	v_fmac_f32_e32 v8, v10, v8                                 // 0000007BFE08: 5610110A
	v_mul_f32_e32 v10, v11, v7                                 // 0000007BFE0C: 10140F0B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE10: BF870112
	v_mul_f32_e32 v12, v9, v8                                  // 0000007BFE14: 10181109
	v_fma_f32 v13, -v5, v10, v11                               // 0000007BFE18: D613000D 242E1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE20: BF870112
	v_fma_f32 v14, -v6, v12, v9                                // 0000007BFE24: D613000E 24261906
	v_fmac_f32_e32 v10, v13, v7                                // 0000007BFE2C: 56140F0D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE30: BF870112
	v_fmac_f32_e32 v12, v14, v8                                // 0000007BFE34: 5618110E
	v_fma_f32 v5, -v5, v10, v11                                // 0000007BFE38: D6130005 242E1505
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE40: BF870112
	v_fma_f32 v6, -v6, v12, v9                                 // 0000007BFE44: D6130006 24261906
	v_div_fmas_f32 v5, v5, v7, v10                             // 0000007BFE4C: D6370005 042A0F05
	s_mov_b32 vcc_lo, s0                                       // 0000007BFE54: BEEA0000
	s_lshl_b64 s[0:1], s[16:17], 1                             // 0000007BFE58: 84808110
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE5C: BF870112
	v_div_fmas_f32 v6, v6, v8, v12                             // 0000007BFE60: D6370006 04321106
	v_div_fixup_f32 v2, v5, v2, v1                             // 0000007BFE68: D6270002 04060505
	.long 0x7f0a3983                                           // 0000007BFE70: 7F0A3983
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007BFE74: BF870223
	v_div_fixup_f32 v4, v6, v4, v0                             // 0000007BFE78: D6270004 04020906
	.long 0xd73c0000                                           // 0000007BFE80: D73C0000
	v_cndmask_b32_e32 v1, 1, v16, vcc_lo                       // 0000007BFE84: 02022081
	.long 0x7e0a3982                                           // 0000007BFE88: 7E0A3982
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007BFE8C: BF870113
	.long 0x7e063984                                           // 0000007BFE90: 7E063984
	v_and_b32_e32 v5, 1, v5                                    // 0000007BFE94: 360A0A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000007BFE98: BF870194
	.long 0xd7006a00                                           // 0000007BFE9C: D7006A00
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 0000007BFEA0: 0202000C
	v_and_b32_e32 v3, 1, v3                                    // 0000007BFEA4: 36060681
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 0000007BFEA8: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007BFEB0: BF870214
	v_add3_u32 v5, v2, v5, 0x7fff                              // 0000007BFEB4: D6550005 03FE0B02 00007FFF
	.long 0xd7006a02                                           // 0000007BFEC0: D7006A02
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000007BFEC4: 02000100
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000007BFEC8: BF870214
	v_add3_u32 v4, v4, v3, 0x7fff                              // 0000007BFECC: D6550004 03FE0704 00007FFF
	v_add_co_ci_u32_e64 v3, null, s1, v1, vcc_lo               // 0000007BFED8: D5207C03 01AA0201
	s_clause 0x1                                               // 0000007BFEE0: BF850001
	global_store_d16_hi_b16 v[0:1], v5, off                    // 0000007BFEE4: DC960000 007C0500
	global_store_d16_hi_b16 v[2:3], v4, off                    // 0000007BFEEC: DC960000 007C0402
	s_endpgm                                                   // 0000007BFEF4: BFB00000
		...

