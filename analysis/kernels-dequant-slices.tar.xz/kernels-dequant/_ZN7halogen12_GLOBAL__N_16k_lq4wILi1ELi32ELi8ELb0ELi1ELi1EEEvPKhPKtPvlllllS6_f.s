00000000007b7d00 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[8:23], s[0:1], null                          // 0000007B7D00: F4100200 F8000000
	s_ashr_i32 s3, s2, 31                                      // 0000007B7D08: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 0000007B7D0C: 32040082
	v_lshrrev_b32_e32 v21, 5, v0                               // 0000007B7D10: 322A0085
	v_and_b32_e32 v22, 31, v0                                  // 0000007B7D14: 362C009F
	.long 0x7f0a3880                                           // 0000007B7D18: 7F0A3880
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000007B7D1C: 300C0082
	s_waitcnt lgkmcnt(0)                                       // 0000007B7D20: BF89FC07
	.long 0xd4510004                                           // 0000007B7D24: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007B7D28: 02002002
	s_and_b32 s4, s4, exec_lo                                  // 0000007B7D2C: 8B047E04
	s_cselect_b32 s6, s3, 0                                    // 0000007B7D30: 98068003
	s_cselect_b32 s7, s2, 0                                    // 0000007B7D34: 98078002
	s_add_u32 s4, s8, s20                                      // 0000007B7D38: 80041408
	s_addc_u32 s5, s9, s21                                     // 0000007B7D3C: 82051509
	v_and_b32_e32 v1, 15, v0                                   // 0000007B7D40: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 0000007B7D44: 360404BC
	s_ashr_i32 s20, s15, 31                                    // 0000007B7D48: 86149F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007B7D4C: BF870119
	s_lshr_b32 s20, s20, 27                                    // 0000007B7D50: 85149B14
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000007B7D54: 30020282
	s_add_u32 s20, s14, s20                                    // 0000007B7D58: 8014140E
	s_clause 0x1                                               // 0000007B7D5C: BF850001
	global_load_b32 v3, v1, s[8:9]                             // 0000007B7D60: DC520000 03080001
	global_load_b32 v4, v2, s[8:9]                             // 0000007B7D68: DC520000 04080002
	s_addc_u32 s21, s15, 0                                     // 0000007B7D70: 8215800F
	v_mov_b32_e32 v1, s4                                       // 0000007B7D74: 7E020204
	s_lshr_b64 s[20:21], s[20:21], 5                           // 0000007B7D78: 85948514
	v_mov_b32_e32 v2, s5                                       // 0000007B7D7C: 7E040205
	s_add_i32 s21, s20, 7                                      // 0000007B7D80: 81158714
	s_mul_i32 s5, s23, s7                                      // 0000007B7D84: 96050717
	s_ashr_i32 s24, s21, 31                                    // 0000007B7D88: 86189F15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000007B7D8C: BF8704B9
	s_lshr_b32 s4, s24, 29                                     // 0000007B7D90: 85049D18
	v_mad_u64_u32 v[17:18], null, s22, s7, v[1:2]              // 0000007B7D94: D6FE7C11 04040E16
	s_add_i32 s21, s21, s4                                     // 0000007B7D9C: 81150415
	s_ashr_i32 s4, s21, 3                                      // 0000007B7DA0: 86048315
	s_cmpk_lt_i32 s20, 0x801                                   // 0000007B7DA4: B3940801
	.long 0xd72c0001                                           // 0000007B7DA8: D72C0001
	v_cndmask_b32_e32 v1, s4, v21, vcc_lo                      // 0000007B7DAC: 02022A04
	s_mul_i32 s21, s22, s6                                     // 0000007B7DB0: 96150616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007B7DB4: BF870141
	v_add_nc_u32_e32 v8, s4, v1                                // 0000007B7DB8: 4A100204
	v_add_nc_u32_e32 v23, v1, v22                              // 0000007B7DBC: 4A2E2D01
	s_cselect_b32 s4, -1, 0                                    // 0000007B7DC0: 980480C1
	s_cmpk_gt_i32 s20, 0x800                                   // 0000007B7DC4: B2940800
	v_min_i32_e32 v24, s20, v8                                 // 0000007B7DC8: 22301014
	s_cselect_b32 s20, -1, 0                                   // 0000007B7DCC: 981480C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000007B7DD0: BF870159
	s_and_b32 vcc_lo, exec_lo, s20                             // 0000007B7DD4: 8B6A147E
	s_waitcnt vmcnt(1)                                         // 0000007B7DD8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000007B7DDC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000007B7DE4: BF8903F7
	v_bfe_u32 v7, v4, 16, 1                                    // 0000007B7DE8: D6100007 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000007B7DF0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s5, v18                               // 0000007B7DFC: 4A062405
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007B7E00: BF870223
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000007B7E04: D6550004 03FE0F04 00007FFF
	.long 0xd4410005                                           // 0000007B7E10: D4410005
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007B7E14: 02023117
	.long 0x7e0a3982                                           // 0000007B7E18: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000007B7E1C: BF870114
	v_add_nc_u32_e32 v25, s21, v3                              // 0000007B7E20: 4A320615
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 0000007B7E24: D6570001 041608FF FFFF0000
	ds_store_b32 v6, v1 offset:32                              // 0000007B7E30: D8340020 00000106
	s_waitcnt lgkmcnt(0)                                       // 0000007B7E38: BF89FC07
	s_barrier                                                  // 0000007B7E3C: BFBD0000
	buffer_gl0_inv                                             // 0000007B7E40: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 0000007B7E48: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 0000007B7E4C: CA100080 02000080
	s_and_saveexec_b32 s21, s5                                 // 0000007B7E54: BE952005
	s_cbranch_execz 11                                         // 0000007B7E58: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v23                               // 0000007B7E5C: 30022E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7E60: BF8700A1
	v_ashrrev_i32_e32 v4, 31, v1                               // 0000007B7E64: 3408029F
	.long 0xd7006a03                                           // 0000007B7E68: D7006A03
	v_cndmask_b32_e32 v1, v17, v1, vcc_lo                      // 0000007B7E6C: 02020311
	v_add_co_ci_u32_e64 v4, null, v25, v4, vcc_lo              // 0000007B7E70: D5207C04 01AA0919
	global_load_d16_b16 v1, v[3:4], off                        // 0000007B7E78: DC820000 017C0003
	s_waitcnt vmcnt(0)                                         // 0000007B7E80: BF8903F7
	v_cvt_f32_f16_e32 v1, v1                                   // 0000007B7E84: 7E021701
	s_or_b32 exec_lo, exec_lo, s21                             // 0000007B7E88: 8C7E157E
	v_add_nc_u32_e32 v3, 32, v23                               // 0000007B7E8C: 4A062EA0
	s_mov_b32 s5, exec_lo                                      // 0000007B7E90: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B7E94: BF870001
	.long 0xd4c1007e                                           // 0000007B7E98: D4C1007E
	v_cndmask_b32_e32 v1, v3, v24, vcc_lo                      // 0000007B7E9C: 02023103
	s_cbranch_execz 11                                         // 0000007B7EA0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v2, 1, v3                                // 0000007B7EA4: 30040681
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7EA8: BF8700A1
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000007B7EAC: 3406049F
	.long 0xd7006a02                                           // 0000007B7EB0: D7006A02
	v_cndmask_b32_e32 v1, v17, v2, vcc_lo                      // 0000007B7EB4: 02020511
	v_add_co_ci_u32_e64 v3, null, v25, v3, vcc_lo              // 0000007B7EB8: D5207C03 01AA0719
	global_load_d16_b16 v2, v[2:3], off                        // 0000007B7EC0: DC820000 027C0002
	s_waitcnt vmcnt(0)                                         // 0000007B7EC8: BF8903F7
	v_cvt_f32_f16_e32 v2, v2                                   // 0000007B7ECC: 7E041702
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B7ED0: 8C7E057E
	v_dual_mov_b32 v4, 0 :: v_dual_add_nc_u32 v5, 64, v23      // 0000007B7ED4: CA200080 04042EC0
	v_mov_b32_e32 v3, 0                                        // 0000007B7EDC: 7E060280
	s_mov_b32 s5, exec_lo                                      // 0000007B7EE0: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B7EE4: BF870002
	.long 0xd4c1007e                                           // 0000007B7EE8: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 0000007B7EEC: 02023105
	s_cbranch_execz 11                                         // 0000007B7EF0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v3, 1, v5                                // 0000007B7EF4: 30060A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7EF8: BF8700A1
	v_ashrrev_i32_e32 v6, 31, v3                               // 0000007B7EFC: 340C069F
	.long 0xd7006a05                                           // 0000007B7F00: D7006A05
	v_cndmask_b32_e32 v1, v17, v3, vcc_lo                      // 0000007B7F04: 02020711
	v_add_co_ci_u32_e64 v6, null, v25, v6, vcc_lo              // 0000007B7F08: D5207C06 01AA0D19
	global_load_d16_b16 v3, v[5:6], off                        // 0000007B7F10: DC820000 037C0005
	s_waitcnt vmcnt(0)                                         // 0000007B7F18: BF8903F7
	v_cvt_f32_f16_e32 v3, v3                                   // 0000007B7F1C: 7E061703
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B7F20: 8C7E057E
	v_add_nc_u32_e32 v5, 0x60, v23                             // 0000007B7F24: 4A0A2EFF 00000060
	s_mov_b32 s5, exec_lo                                      // 0000007B7F2C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B7F30: BF870001
	.long 0xd4c1007e                                           // 0000007B7F34: D4C1007E
	v_cndmask_b32_e32 v1, v5, v24, vcc_lo                      // 0000007B7F38: 02023105
	s_cbranch_execz 11                                         // 0000007B7F3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v4, 1, v5                                // 0000007B7F40: 30080A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7F44: BF8700A1
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000007B7F48: 340A089F
	.long 0xd7006a04                                           // 0000007B7F4C: D7006A04
	v_cndmask_b32_e32 v1, v17, v4, vcc_lo                      // 0000007B7F50: 02020911
	v_add_co_ci_u32_e64 v5, null, v25, v5, vcc_lo              // 0000007B7F54: D5207C05 01AA0B19
	global_load_d16_b16 v4, v[4:5], off                        // 0000007B7F5C: DC820000 047C0004
	s_waitcnt vmcnt(0)                                         // 0000007B7F64: BF8903F7
	v_cvt_f32_f16_e32 v4, v4                                   // 0000007B7F68: 7E081704
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B7F6C: 8C7E057E
	v_dual_mov_b32 v6, 0 :: v_dual_add_nc_u32 v7, 0x80, v23    // 0000007B7F70: CA200080 06062EFF 00000080
	v_mov_b32_e32 v5, 0                                        // 0000007B7F7C: 7E0A0280
	s_mov_b32 s5, exec_lo                                      // 0000007B7F80: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B7F84: BF870002
	.long 0xd4c1007e                                           // 0000007B7F88: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 0000007B7F8C: 02023107
	s_cbranch_execz 11                                         // 0000007B7F90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v5, 1, v7                                // 0000007B7F94: 300A0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7F98: BF8700A1
	v_ashrrev_i32_e32 v8, 31, v5                               // 0000007B7F9C: 34100A9F
	.long 0xd7006a07                                           // 0000007B7FA0: D7006A07
	v_cndmask_b32_e32 v1, v17, v5, vcc_lo                      // 0000007B7FA4: 02020B11
	v_add_co_ci_u32_e64 v8, null, v25, v8, vcc_lo              // 0000007B7FA8: D5207C08 01AA1119
	global_load_d16_b16 v5, v[7:8], off                        // 0000007B7FB0: DC820000 057C0007
	s_waitcnt vmcnt(0)                                         // 0000007B7FB8: BF8903F7
	v_cvt_f32_f16_e32 v5, v5                                   // 0000007B7FBC: 7E0A1705
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B7FC0: 8C7E057E
	v_add_nc_u32_e32 v7, 0xa0, v23                             // 0000007B7FC4: 4A0E2EFF 000000A0
	s_mov_b32 s5, exec_lo                                      // 0000007B7FCC: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B7FD0: BF870001
	.long 0xd4c1007e                                           // 0000007B7FD4: D4C1007E
	v_cndmask_b32_e32 v1, v7, v24, vcc_lo                      // 0000007B7FD8: 02023107
	s_cbranch_execz 11                                         // 0000007B7FDC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v6, 1, v7                                // 0000007B7FE0: 300C0E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B7FE4: BF8700A1
	v_ashrrev_i32_e32 v7, 31, v6                               // 0000007B7FE8: 340E0C9F
	.long 0xd7006a06                                           // 0000007B7FEC: D7006A06
	v_cndmask_b32_e32 v1, v17, v6, vcc_lo                      // 0000007B7FF0: 02020D11
	v_add_co_ci_u32_e64 v7, null, v25, v7, vcc_lo              // 0000007B7FF4: D5207C07 01AA0F19
	global_load_d16_b16 v6, v[6:7], off                        // 0000007B7FFC: DC820000 067C0006
	s_waitcnt vmcnt(0)                                         // 0000007B8004: BF8903F7
	v_cvt_f32_f16_e32 v6, v6                                   // 0000007B8008: 7E0C1706
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B800C: 8C7E057E
	v_dual_mov_b32 v8, 0 :: v_dual_add_nc_u32 v9, 0xc0, v23    // 0000007B8010: CA200080 08082EFF 000000C0
	v_mov_b32_e32 v7, 0                                        // 0000007B801C: 7E0E0280
	s_mov_b32 s5, exec_lo                                      // 0000007B8020: BE85007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B8024: BF870002
	.long 0xd4c1007e                                           // 0000007B8028: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007B802C: 02023109
	s_cbranch_execz 11                                         // 0000007B8030: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v7, 1, v9                                // 0000007B8034: 300E1281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B8038: BF8700A1
	v_ashrrev_i32_e32 v10, 31, v7                              // 0000007B803C: 34140E9F
	.long 0xd7006a09                                           // 0000007B8040: D7006A09
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 0000007B8044: 02020F11
	v_add_co_ci_u32_e64 v10, null, v25, v10, vcc_lo            // 0000007B8048: D5207C0A 01AA1519
	global_load_d16_b16 v7, v[9:10], off                       // 0000007B8050: DC820000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000007B8058: BF8903F7
	v_cvt_f32_f16_e32 v7, v7                                   // 0000007B805C: 7E0E1707
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B8060: 8C7E057E
	v_add_nc_u32_e32 v9, 0xe0, v23                             // 0000007B8064: 4A122EFF 000000E0
	s_mov_b32 s5, exec_lo                                      // 0000007B806C: BE85007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B8070: BF870001
	.long 0xd4c1007e                                           // 0000007B8074: D4C1007E
	v_cndmask_b32_e32 v1, v9, v24, vcc_lo                      // 0000007B8078: 02023109
	s_cbranch_execz 11                                         // 0000007B807C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v8, 1, v9                                // 0000007B8080: 30101281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B8084: BF8700A1
	v_ashrrev_i32_e32 v9, 31, v8                               // 0000007B8088: 3412109F
	.long 0xd7006a08                                           // 0000007B808C: D7006A08
	v_cndmask_b32_e32 v1, v17, v8, vcc_lo                      // 0000007B8090: 02021111
	v_add_co_ci_u32_e64 v9, null, v25, v9, vcc_lo              // 0000007B8094: D5207C09 01AA1319
	global_load_d16_b16 v8, v[8:9], off                        // 0000007B809C: DC820000 087C0008
	s_waitcnt vmcnt(0)                                         // 0000007B80A4: BF8903F7
	v_cvt_f32_f16_e32 v8, v8                                   // 0000007B80A8: 7E101708
	s_or_b32 exec_lo, exec_lo, s5                              // 0000007B80AC: 8C7E057E
	s_branch 9                                                 // 0000007B80B0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v1, 0                                        // 0000007B80B4: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B80B8: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000007B80BC: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000007B80C0: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000007B80C4: 7E080301
	v_mov_b32_e32 v5, v1                                       // 0000007B80C8: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000007B80CC: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000007B80D0: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000007B80D4: 7E100301
	s_add_u32 s8, s8, s18                                      // 0000007B80D8: 80081208
	s_addc_u32 s9, s9, s19                                     // 0000007B80DC: 82091309
	s_lshr_b32 s5, s15, 31                                     // 0000007B80E0: 85059F0F
	v_dual_mov_b32 v9, s7 :: v_dual_mov_b32 v26, 0             // 0000007B80E4: CA100007 091A0080
	s_add_u32 s14, s14, s5                                     // 0000007B80EC: 800E050E
	s_addc_u32 s15, s15, 0                                     // 0000007B80F0: 820F800F
	.long 0xd4410005                                           // 0000007B80F4: D4410005
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007B80F8: 02023117
	s_ashr_i64 s[14:15], s[14:15], 1                           // 0000007B80FC: 868E810E
	v_cndmask_b32_e64 v27, 0, 1, s20                           // 0000007B8100: D501001B 00510280
	v_mad_u64_u32 v[18:19], null, v9, s14, s[8:9]              // 0000007B8108: D6FE7C12 00201D09
	.long 0xd72c000b                                           // 0000007B8110: D72C000B
	v_cndmask_b32_e32 v0, s7, v15, vcc_lo                      // 0000007B8114: 02001E07
	.long 0xd72c000c                                           // 0000007B8118: D72C000C
	v_cndmask_b32_e32 v0, s6, v14, vcc_lo                      // 0000007B811C: 02001C06
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000007B8120: CA100080 090A0080
	v_mov_b32_e32 v29, 0                                       // 0000007B8128: 7E3A0280
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B812C: BF870003
	v_add3_u32 v28, v12, v19, v11                              // 0000007B8130: D655001C 042E270C
	v_dual_mov_b32 v11, 0 :: v_dual_mov_b32 v12, 0             // 0000007B8138: CA100080 0B0C0080
	s_and_saveexec_b32 s6, s5                                  // 0000007B8140: BE862005
	s_cbranch_execz 22                                         // 0000007B8144: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v9, 4, v23                               // 0000007B8148: 30122E84
	v_mov_b32_e32 v29, 0                                       // 0000007B814C: 7E3A0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B8150: BF8700A2
	v_ashrrev_i32_e32 v10, 31, v9                              // 0000007B8154: 3414129F
	.long 0xd7006a09                                           // 0000007B8158: D7006A09
	v_cndmask_b32_e32 v1, v18, v9, vcc_lo                      // 0000007B815C: 02021312
	v_add_co_ci_u32_e64 v10, null, v28, v10, vcc_lo            // 0000007B8160: D5207C0A 01AA151C
	s_and_not1_b32 vcc_lo, exec_lo, s20                        // 0000007B8168: 916A147E
	global_load_b128 v[9:12], v[9:10], off                     // 0000007B816C: DC5E0000 097C0009
	s_cbranch_vccnz 10                                         // 0000007B8174: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v13, 1, v23                              // 0000007B8178: 301A2E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B817C: BF870091
	.long 0xd7006a0d                                           // 0000007B8180: D7006A0D
	v_cndmask_b32_e32 v1, v17, v13, vcc_lo                     // 0000007B8184: 02021B11
	v_add_co_ci_u32_e64 v14, null, 0, v25, vcc_lo              // 0000007B8188: D5207C0E 01AA3280
	global_load_d16_b16 v13, v[13:14], off                     // 0000007B8190: DC820000 0D7C000D
	s_waitcnt vmcnt(0)                                         // 0000007B8198: BF8903F7
	v_cvt_f32_f16_e32 v29, v13                                 // 0000007B819C: 7E3A170D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007B81A0: 8C7E067E
	s_and_saveexec_b32 s6, s5                                  // 0000007B81A4: BE862005
	s_cbranch_execz 233                                        // 0000007B81A8: BFA500E9 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x850>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v13, 32, v23    // 0000007B81AC: CA200080 1A0C2EA0
	v_dual_mov_b32 v32, v29 :: v_dual_lshlrev_b32 v19, 5, v23  // 0000007B81B4: CA22011D 20122E85
	s_mov_b32 s7, 0                                            // 0000007B81BC: BE870080
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B81C0: BF870002
	v_lshlrev_b32_e32 v30, 4, v13                              // 0000007B81C4: 303C1A84
	v_lshlrev_b32_e32 v31, 1, v13                              // 0000007B81C8: 303E1A81
	s_branch 188                                               // 0000007B81CC: BFA000BC <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x7c0>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000007B81D0: 8C7E087E
	v_ashrrev_i32_e32 v20, 31, v19                             // 0000007B81D4: 3428269F
	v_lshrrev_b32_e32 v49, 6, v9                               // 0000007B81D8: 32621286
	v_lshrrev_b32_e32 v50, 14, v9                              // 0000007B81DC: 3264128E
	v_and_b32_e32 v51, 0xff, v10                               // 0000007B81E0: 366614FF 000000FF
	v_lshrrev_b32_e32 v52, 6, v10                              // 0000007B81E8: 32681486
	.long 0xd73c0021                                           // 0000007B81EC: D73C0021
	v_cndmask_b32_e32 v1, 1, v19, vcc_lo                       // 0000007B81F0: 02022681
	v_and_b32_e32 v20, 0xff, v9                                // 0000007B81F4: 362812FF 000000FF
	v_and_b32_e32 v49, 0x3fc, v49                              // 0000007B81FC: 366262FF 000003FC
	v_and_b32_e32 v50, 0x3fc, v50                              // 0000007B8204: 366464FF 000003FC
	v_lshrrev_b32_e32 v9, 22, v9                               // 0000007B820C: 32121296
	v_lshrrev_b32_e32 v53, 14, v10                             // 0000007B8210: 326A148E
	.long 0xd7006a2d                                           // 0000007B8214: D7006A2D
	v_cndmask_b32_e32 v1, s10, v33, vcc_lo                     // 0000007B8218: 0202420A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B821C: BF870001
	v_add_co_ci_u32_e64 v46, null, s11, v34, vcc_lo            // 0000007B8220: D5207C2E 01AA440B
	v_lshlrev_b32_e32 v20, 2, v20                              // 0000007B8228: 30282882
	ds_load_b32 v49, v49 offset:32                             // 0000007B822C: D8D80020 31000031
	ds_load_b32 v50, v50 offset:32                             // 0000007B8234: D8D80020 32000032
	s_clause 0x3                                               // 0000007B823C: BF850003
	global_load_b128 v[33:36], v[45:46], off                   // 0000007B8240: DC5E0000 217C002D
	global_load_b128 v[37:40], v[45:46], off offset:16         // 0000007B8248: DC5E0010 257C002D
	global_load_b128 v[41:44], v[45:46], off offset:32         // 0000007B8250: DC5E0020 297C002D
	global_load_b128 v[45:48], v[45:46], off offset:48         // 0000007B8258: DC5E0030 2D7C002D
	v_lshrrev_b32_e32 v10, 22, v10                             // 0000007B8260: 32141496
	ds_load_b32 v20, v20 offset:32                             // 0000007B8264: D8D80020 14000014
	v_and_b32_e32 v9, 0x3fc, v9                                // 0000007B826C: 361212FF 000003FC
	v_lshlrev_b32_e32 v51, 2, v51                              // 0000007B8274: 30666682
	v_and_b32_e32 v52, 0x3fc, v52                              // 0000007B8278: 366868FF 000003FC
	v_and_b32_e32 v53, 0x3fc, v53                              // 0000007B8280: 366A6AFF 000003FC
	v_and_b32_e32 v10, 0x3fc, v10                              // 0000007B8288: 361414FF 000003FC
	ds_load_b32 v9, v9 offset:32                               // 0000007B8290: D8D80020 09000009
	ds_load_b32 v51, v51 offset:32                             // 0000007B8298: D8D80020 33000033
	ds_load_b32 v52, v52 offset:32                             // 0000007B82A0: D8D80020 34000034
	ds_load_b32 v53, v53 offset:32                             // 0000007B82A8: D8D80020 35000035
	ds_load_b32 v10, v10 offset:32                             // 0000007B82B0: D8D80020 0A00000A
	v_add_nc_u32_e32 v30, 0x200, v30                           // 0000007B82B8: 4A3C3CFF 00000200
	s_and_b32 s5, exec_lo, s5                                  // 0000007B82C0: 8B05057E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000007B82C4: BF870149
	s_or_b32 s7, s5, s7                                        // 0000007B82C8: 8C070705
	s_waitcnt vmcnt(3) lgkmcnt(5)                              // 0000007B82CC: BF890C57
	v_dot2_f32_bf16 v20, v33, v20, 0                           // 0000007B82D0: CC1A4014 1A022921
	v_and_b32_e32 v33, 0xff, v11                               // 0000007B82D8: 364216FF 000000FF
	v_dot2_f32_bf16 v20, v34, v49, v20                         // 0000007B82E0: CC1A4014 1C526322
	v_lshrrev_b32_e32 v34, 6, v11                              // 0000007B82E8: 32441686
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000007B82EC: BF8701A2
	v_dot2_f32_bf16 v20, v35, v50, v20                         // 0000007B82F0: CC1A4014 1C526523
	v_lshrrev_b32_e32 v35, 14, v11                             // 0000007B82F8: 3246168E
	v_and_b32_e32 v34, 0x3fc, v34                              // 0000007B82FC: 364444FF 000003FC
	v_lshrrev_b32_e32 v11, 22, v11                             // 0000007B8304: 32161696
	s_waitcnt lgkmcnt(4)                                       // 0000007B8308: BF89FC47
	v_dot2_f32_bf16 v9, v36, v9, v20                           // 0000007B830C: CC1A4009 1C521324
	v_and_b32_e32 v35, 0x3fc, v35                              // 0000007B8314: 364646FF 000003FC
	v_lshrrev_b32_e32 v36, 6, v12                              // 0000007B831C: 32481886
	ds_load_b32 v34, v34 offset:32                             // 0000007B8320: D8D80020 22000022
	s_waitcnt vmcnt(2) lgkmcnt(4)                              // 0000007B8328: BF890847
	v_dot2_f32_bf16 v9, v37, v51, v9                           // 0000007B832C: CC1A4009 1C266725
	ds_load_b32 v35, v35 offset:32                             // 0000007B8334: D8D80020 23000023
	v_lshrrev_b32_e32 v37, 14, v12                             // 0000007B833C: 324A188E
	v_and_b32_e32 v36, 0x3fc, v36                              // 0000007B8340: 364848FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000007B8348: BF89FC47
	v_dot2_f32_bf16 v9, v38, v52, v9                           // 0000007B834C: CC1A4009 1C266926
	v_cndmask_b32_e64 v38, v6, v7, s4                          // 0000007B8354: D5010026 00120F06
	v_and_b32_e32 v37, 0x3fc, v37                              // 0000007B835C: 364A4AFF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 0000007B8364: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B8368: BF870133
	v_dot2_f32_bf16 v9, v39, v53, v9                           // 0000007B836C: CC1A4009 1C266B27
	v_cndmask_b32_e64 v39, v7, v8, s4                          // 0000007B8374: D5010027 00121107
	s_waitcnt lgkmcnt(2)                                       // 0000007B837C: BF89FC27
	v_dot2_f32_bf16 v9, v40, v10, v9                           // 0000007B8380: CC1A4009 1C261528
	v_mov_b32_e32 v40, v8                                      // 0000007B8388: 7E500308
	v_lshlrev_b32_e32 v20, 2, v33                              // 0000007B838C: 30284282
	v_and_b32_e32 v33, 0xff, v12                               // 0000007B8390: 364218FF 000000FF
	v_lshrrev_b32_e32 v12, 22, v12                             // 0000007B8398: 32181896
	ds_load_b32 v20, v20 offset:32                             // 0000007B839C: D8D80020 14000014
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000007B83A4: 30424282
	s_waitcnt vmcnt(1) lgkmcnt(0)                              // 0000007B83A8: BF890407
	v_dot2_f32_bf16 v9, v41, v20, v9                           // 0000007B83AC: CC1A4009 1C262929
	v_cndmask_b32_e64 v20, v29, v1, s4                         // 0000007B83B4: D5010014 0012031D
	v_mov_b32_e32 v29, v32                                     // 0000007B83BC: 7E3A0320
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007B83C0: BF870123
	v_dot2_f32_bf16 v9, v42, v34, v9                           // 0000007B83C4: CC1A4009 1C26452A
	v_cndmask_b32_e64 v34, v2, v3, s4                          // 0000007B83CC: D5010022 00120702
	v_dot2_f32_bf16 v9, v43, v35, v9                           // 0000007B83D4: CC1A4009 1C26472B
	v_cndmask_b32_e64 v35, v3, v4, s4                          // 0000007B83DC: D5010023 00120903
	v_and_b32_e32 v11, 0x3fc, v11                              // 0000007B83E4: 361616FF 000003FC
	v_and_b32_e32 v12, 0x3fc, v12                              // 0000007B83EC: 361818FF 000003FC
	ds_load_b32 v10, v11 offset:32                             // 0000007B83F4: D8D80020 0A00000B
	ds_load_b32 v11, v33 offset:32                             // 0000007B83FC: D8D80020 0B000021
	ds_load_b32 v33, v36 offset:32                             // 0000007B8404: D8D80020 21000024
	ds_load_b32 v49, v37 offset:32                             // 0000007B840C: D8D80020 31000025
	ds_load_b32 v50, v12 offset:32                             // 0000007B8414: D8D80020 3200000C
	v_cndmask_b32_e64 v37, v5, v6, s4                          // 0000007B841C: D5010025 00120D05
	v_cndmask_b32_e64 v36, v4, v5, s4                          // 0000007B8424: D5010024 00120B04
	v_mov_b32_e32 v12, v16                                     // 0000007B842C: 7E180310
	s_waitcnt lgkmcnt(4)                                       // 0000007B8430: BF89FC47
	v_dot2_f32_bf16 v9, v44, v10, v9                           // 0000007B8434: CC1A4009 1C26152C
	v_mov_b32_e32 v10, v14                                     // 0000007B843C: 7E14030E
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 0000007B8440: BF890037
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000007B8444: BF870132
	v_dot2_f32_bf16 v9, v45, v11, v9                           // 0000007B8448: CC1A4009 1C26172D
	v_mov_b32_e32 v11, v15                                     // 0000007B8450: 7E16030F
	s_waitcnt lgkmcnt(2)                                       // 0000007B8454: BF89FC27
	v_dot2_f32_bf16 v5, v46, v33, v9                           // 0000007B8458: CC1A4005 1C26432E
	v_cndmask_b32_e64 v33, v1, v2, s4                          // 0000007B8460: D5010021 00120501
	v_add_nc_u32_e32 v31, 64, v31                              // 0000007B8468: 4A3E3EC0
	v_mov_b32_e32 v9, v13                                      // 0000007B846C: 7E12030D
	v_add_nc_u32_e32 v19, 0x400, v19                           // 0000007B8470: 4A2626FF 00000400
	s_waitcnt lgkmcnt(1)                                       // 0000007B8478: BF89FC17
	v_dot2_f32_bf16 v1, v47, v49, v5                           // 0000007B847C: CC1A4001 1C16632F
	s_waitcnt lgkmcnt(0)                                       // 0000007B8484: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B8488: BF870091
	v_dot2_f32_bf16 v1, v48, v50, v1                           // 0000007B848C: CC1A4001 1C066530
	v_dual_fmac_f32 v26, v20, v1 :: v_dual_mov_b32 v1, v33     // 0000007B8494: C8100314 1A000121
	v_dual_mov_b32 v2, v34 :: v_dual_mov_b32 v3, v35           // 0000007B849C: CA100122 02020123
	v_dual_mov_b32 v4, v36 :: v_dual_mov_b32 v5, v37           // 0000007B84A4: CA100124 04040125
	v_dual_mov_b32 v6, v38 :: v_dual_mov_b32 v7, v39           // 0000007B84AC: CA100126 06060127
	v_mov_b32_e32 v8, v40                                      // 0000007B84B4: 7E100328
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 0000007B84B8: 917E077E
	s_cbranch_execz 35                                         // 0000007B84BC: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x84c>
	s_waitcnt vmcnt(0)                                         // 0000007B84C0: BF8903F7
	v_dual_mov_b32 v14, v10 :: v_dual_add_nc_u32 v23, 32, v23  // 0000007B84C4: CA20010A 0E162EA0
	v_dual_mov_b32 v13, v9 :: v_dual_mov_b32 v16, v12          // 0000007B84CC: CA100109 0D10010C
	v_mov_b32_e32 v15, v11                                     // 0000007B84D4: 7E1E030B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B84D8: BF870003
	.long 0xd4460005                                           // 0000007B84DC: D4460005
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007B84E0: 02023117
	s_mov_b32 s8, exec_lo                                      // 0000007B84E4: BE88007E
	.long 0xd4c1007e                                           // 0000007B84E8: D4C1007E
	v_cndmask_b32_e32 v1, v23, v24, vcc_lo                     // 0000007B84EC: 02023117
	s_cbranch_execz 65335                                      // 0000007B84F0: BFA5FF37 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v14, 31, v30                             // 0000007B84F4: 341C3C9F
	.long 0xd7006a0d                                           // 0000007B84F8: D7006A0D
	v_cndmask_b32_e32 v1, v18, v30, vcc_lo                     // 0000007B84FC: 02023D12
	v_mov_b32_e32 v32, v29                                     // 0000007B8500: 7E40031D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000007B8504: BF870003
	v_add_co_ci_u32_e64 v14, null, v28, v14, vcc_lo            // 0000007B8508: D5207C0E 01AA1D1C
	v_cmp_ne_u32_e32 vcc_lo, 1, v27                            // 0000007B8510: 7C9A3681
	global_load_b128 v[13:16], v[13:14], off                   // 0000007B8514: DC5E0000 0D7C000D
	s_cbranch_vccnz 65324                                      // 0000007B851C: BFA4FF2C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	v_ashrrev_i32_e32 v20, 31, v31                             // 0000007B8520: 34283E9F
	.long 0xd7006a20                                           // 0000007B8524: D7006A20
	v_cndmask_b32_e32 v1, v17, v31, vcc_lo                     // 0000007B8528: 02023F11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000007B852C: BF870001
	v_add_co_ci_u32_e64 v33, null, v25, v20, vcc_lo            // 0000007B8530: D5207C21 01AA2919
	global_load_d16_b16 v20, v[32:33], off                     // 0000007B8538: DC820000 147C0020
	s_waitcnt vmcnt(0)                                         // 0000007B8540: BF8903F7
	v_cvt_f32_f16_e32 v32, v20                                 // 0000007B8544: 7E401714
	s_branch 65313                                             // 0000007B8548: BFA0FF21 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x4d0>
	s_or_b32 exec_lo, exec_lo, s7                              // 0000007B854C: 8C7E077E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007B8550: BF8700B9
	s_or_b32 exec_lo, exec_lo, s6                              // 0000007B8554: 8C7E067E
	.long 0xd71f0001                                           // 0000007B8558: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000007B855C: 020100C1
	s_mov_b32 s4, exec_lo                                      // 0000007B8560: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 0000007B8564: 3A040290
	v_xor_b32_e32 v3, 8, v1                                    // 0000007B8568: 3A060288
	v_xor_b32_e32 v4, 4, v1                                    // 0000007B856C: 3A080284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000007B8570: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 0000007B8574: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 0000007B8578: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v3                            // 0000007B857C: 7C9806A0
	v_cndmask_b32_e32 v3, v1, v3, vcc_lo                       // 0000007B8580: 02060701
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B8584: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 0000007B8588: BF870002
	v_lshlrev_b32_e32 v3, 2, v3                                // 0000007B858C: 30060682
	v_lshlrev_b32_e32 v2, 2, v2                                // 0000007B8590: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007B8594: 02080901
	ds_bpermute_b32 v2, v2, v26                                // 0000007B8598: DACC0000 02001A02
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007B85A0: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007B85A4: BF89FC07
	v_add_f32_e32 v2, v26, v2                                  // 0000007B85A8: 0604051A
	ds_bpermute_b32 v3, v3, v2                                 // 0000007B85AC: DACC0000 03000203
	s_waitcnt lgkmcnt(0)                                       // 0000007B85B4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007B85B8: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007B85BC: DACC0000 03000204
	v_xor_b32_e32 v4, 2, v1                                    // 0000007B85C4: 3A080282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B85C8: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B85CC: 7C9808A0
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 0000007B85D0: 02080901
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000007B85D4: 30080882
	s_waitcnt lgkmcnt(0)                                       // 0000007B85D8: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 0000007B85DC: 06040702
	ds_bpermute_b32 v3, v4, v2                                 // 0000007B85E0: DACC0000 03000204
	v_xor_b32_e32 v4, 1, v1                                    // 0000007B85E8: 3A080281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000007B85EC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000007B85F0: 7C9808A0
	s_waitcnt lgkmcnt(0)                                       // 0000007B85F4: BF89FC07
	v_dual_cndmask_b32 v4, v1, v4 :: v_dual_add_f32 v1, v2, v3 // 0000007B85F8: CA480901 04000702
	v_lshlrev_b32_e32 v2, 2, v4                                // 0000007B8600: 30040882
	ds_bpermute_b32 v2, v2, v1                                 // 0000007B8604: DACC0000 02000102
	v_cmpx_eq_u32_e32 0, v22                                   // 0000007B860C: 7D942C80
	s_cbranch_execz 5                                          // 0000007B8610: BFA50005 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0x928>
	v_lshlrev_b32_e32 v3, 2, v21                               // 0000007B8614: 30062A82
	s_waitcnt lgkmcnt(0)                                       // 0000007B8618: BF89FC07
	v_add_f32_e32 v1, v1, v2                                   // 0000007B861C: 06020501
	ds_store_b32 v3, v1                                        // 0000007B8620: D8340000 00000103
	s_or_b32 exec_lo, exec_lo, s4                              // 0000007B8628: 8C7E047E
	.long 0xd4510004                                           // 0000007B862C: D4510004
	v_cndmask_b32_e32 v0, s2, v16, vcc_lo                      // 0000007B8630: 02002002
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000007B8634: 7C940080
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000007B8638: BF890007
	s_barrier                                                  // 0000007B863C: BFBD0000
	buffer_gl0_inv                                             // 0000007B8640: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 0000007B8648: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000007B864C: BF870009
	s_and_saveexec_b32 s5, s4                                  // 0000007B8650: BE852004
	s_cbranch_execz 72                                         // 0000007B8654: BFA50048 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi1ELi32ELi8ELb0ELi1ELi1EEEvPKhPKtPvlllllS6_f+0xa78>
	v_mov_b32_e32 v8, 0                                        // 0000007B8658: 7E100280
	s_load_b32 s0, s[0:1], 0x48                                // 0000007B865C: F4000000 F8000048
	ds_load_b128 v[0:3], v8                                    // 0000007B8664: DBFC0000 00000008
	ds_load_b128 v[4:7], v8 offset:16                          // 0000007B866C: DBFC0010 04000008
	s_waitcnt lgkmcnt(0)                                       // 0000007B8674: BF89FC07
	v_add_f32_e32 v0, 0, v0                                    // 0000007B8678: 06000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B867C: BF870091
	v_add_f32_e32 v0, v0, v1                                   // 0000007B8680: 06000300
	v_add_f32_e32 v0, v0, v2                                   // 0000007B8684: 06000500
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B8688: BF870091
	v_add_f32_e32 v0, v0, v3                                   // 0000007B868C: 06000700
	v_add_f32_e32 v0, v0, v4                                   // 0000007B8690: 06000900
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B8694: BF870091
	v_add_f32_e32 v0, v0, v5                                   // 0000007B8698: 06000B00
	v_add_f32_e32 v0, v0, v6                                   // 0000007B869C: 06000D00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B86A0: BF870091
	v_add_f32_e32 v0, v0, v7                                   // 0000007B86A4: 06000F00
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007B86A8: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B86B0: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000007B86B4: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000007B86B8: 4A0000FF 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B86C0: BF870091
	v_and_b32_e32 v0, 0xffff0000, v0                           // 0000007B86C4: 360000FF FFFF0000
	v_mul_f32_e32 v0, s0, v0                                   // 0000007B86CC: 10000000
	s_lshl_b64 s[0:1], s[2:3], 1                               // 0000007B86D0: 84808102
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000007B86D4: BF8700A9
	s_add_u32 s0, s12, s0                                      // 0000007B86D8: 8000000C
	s_addc_u32 s1, s13, s1                                     // 0000007B86DC: 8201010D
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000007B86E0: 100200FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000007B86E8: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000007B86EC: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000007B86F0: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000007B86F4: BF870121
	v_div_scale_f32 v2, null, v1, v1, v0                       // 0000007B86F8: D6FC7C02 04020301
	v_div_scale_f32 v5, vcc_lo, v0, v1, v0                     // 0000007B8700: D6FC6A05 04020300
	v_rcp_f32_e32 v3, v2                                       // 0000007B8708: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 0000007B870C: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000007B8714: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 0000007B8718: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B8720: BF870091
	v_fmac_f32_e32 v3, v4, v3                                  // 0000007B8724: 56060704
	v_mul_f32_e32 v4, v5, v3                                   // 0000007B8728: 10080705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B872C: BF870091
	v_fma_f32 v6, v2, v4, v5                                   // 0000007B8730: D6130006 04160902
	v_fmac_f32_e32 v4, v6, v3                                  // 0000007B8738: 56080706
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B873C: BF870091
	v_fmac_f32_e32 v5, v2, v4                                  // 0000007B8740: 560A0902
	v_div_fmas_f32 v2, v5, v3, v4                              // 0000007B8744: D6370002 04120705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B874C: BF870091
	v_div_fixup_f32 v0, v2, v1, v0                             // 0000007B8750: D6270000 04020302
	v_bfe_u32 v1, v0, 16, 1                                    // 0000007B8758: D6100001 02052100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000007B8760: BF870091
	v_add_nc_u32_e32 v0, v0, v1                                // 0000007B8764: 4A000300
	v_add_nc_u32_e32 v0, 0x7fff, v0                            // 0000007B8768: 4A0000FF 00007FFF
	global_store_d16_hi_b16 v8, v0, s[0:1]                     // 0000007B8770: DC960000 00000008
	s_endpgm                                                   // 0000007B8778: BFB00000
		...

