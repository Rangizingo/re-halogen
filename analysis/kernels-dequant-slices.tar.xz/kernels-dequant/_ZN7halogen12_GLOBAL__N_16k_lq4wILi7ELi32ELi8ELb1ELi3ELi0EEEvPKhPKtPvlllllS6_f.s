0000000000859900 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000859900: F4100100 F8000000
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v1, 15, v0          // 000000859908: CA240080 0600008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000859910: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000859914: 86039F02
	v_mov_b32_e32 v5, 0                                        // 000000859918: 7E0A0280
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085991C: BF870193
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v1, 2, v1       // 000000859920: CA220080 08000282
	v_and_b32_e32 v2, 60, v2                                   // 000000859928: 360404BC
	v_lshrrev_b32_e32 v15, 5, v0                               // 00000085992C: 321E0085
	v_dual_mov_b32 v29, 0 :: v_dual_and_b32 v16, 31, v0        // 000000859930: CA240080 1D10009F
	.long 0x7f263880                                           // 000000859938: 7F263880
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v14, 2, v0     // 00000085993C: CA220080 110E0082
	s_waitcnt lgkmcnt(0)                                       // 000000859944: BF89FC07
	s_clause 0x1                                               // 000000859948: BF850001
	global_load_b32 v11, v1, s[4:5]                            // 00000085994C: DC520000 0B040001
	global_load_b32 v13, v2, s[4:5]                            // 000000859954: DC520000 0D040002
	.long 0xd4510014                                           // 00000085995C: D4510014
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000859960: 02001802
	s_and_b32 s20, s20, exec_lo                                // 000000859964: 8B147E14
	s_cselect_b32 s24, s3, 0                                   // 000000859968: 98188003
	s_cselect_b32 s25, s2, 0                                   // 00000085996C: 98198002
	s_add_u32 s14, s4, s14                                     // 000000859970: 800E0E04
	s_addc_u32 s15, s5, s15                                    // 000000859974: 820F0F05
	s_lshr_b32 s20, s11, 31                                    // 000000859978: 85149F0B
	v_mov_b32_e32 v1, s14                                      // 00000085997C: 7E02020E
	s_add_u32 s20, s10, s20                                    // 000000859980: 8014140A
	s_addc_u32 s21, s11, 0                                     // 000000859984: 8215800B
	s_ashr_i32 s22, s11, 31                                    // 000000859988: 86169F0B
	s_ashr_i64 s[20:21], s[20:21], 1                           // 00000085998C: 86948114
	s_lshr_b32 s22, s22, 27                                    // 000000859990: 85169B16
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v2, s15             // 000000859994: CA100080 0702000F
	s_add_u32 s22, s10, s22                                    // 00000085999C: 8016160A
	s_addc_u32 s23, s11, 0                                     // 0000008599A0: 8217800B
	s_mul_i32 s19, s19, s25                                    // 0000008599A4: 96131913
	s_lshr_b64 s[22:23], s[22:23], 5                           // 0000008599A8: 85968516
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008599AC: BF870499
	s_add_i32 s23, s22, 7                                      // 0000008599B0: 81178716
	s_ashr_i32 s26, s23, 31                                    // 0000008599B4: 861A9F17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000008599B8: BF870499
	s_lshr_b32 s26, s26, 29                                    // 0000008599BC: 851A9D1A
	s_add_i32 s23, s23, s26                                    // 0000008599C0: 81171A17
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000008599C4: BF8704B9
	s_ashr_i32 s14, s23, 3                                     // 0000008599C8: 860E8317
	s_add_u32 s4, s4, s16                                      // 0000008599CC: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000008599D0: 82051105
	v_dual_mov_b32 v3, s4 :: v_dual_mov_b32 v4, s5             // 0000008599D4: CA100004 03040005
	v_mad_u64_u32 v[9:10], null, s25, s20, v[1:2]              // 0000008599DC: D6FE7C09 04042819
	.long 0xd72c0012                                           // 0000008599E4: D72C0012
	v_cndmask_b32_e32 v1, s14, v15, vcc_lo                     // 0000008599E8: 02021E0E
	s_mul_i32 s4, s24, s20                                     // 0000008599EC: 96041418
	s_waitcnt vmcnt(1)                                         // 0000008599F0: BF8907F7
	v_bfe_u32 v12, v11, 16, 1                                  // 0000008599F4: D610000C 0205210B
	s_waitcnt vmcnt(0)                                         // 0000008599FC: BF8903F7
	v_bfe_u32 v1, v13, 16, 1                                   // 000000859A00: D6100001 0205210D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000859A08: BF870112
	v_add3_u32 v2, v11, v12, 0x7fff                            // 000000859A0C: D6550002 03FE190B 00007FFF
	v_add3_u32 v1, v13, v1, 0x7fff                             // 000000859A18: D6550001 03FE030D 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 000000859A24: BF870002
	.long 0x7e263982                                           // 000000859A28: 7E263982
	v_add_nc_u32_e32 v2, s4, v10                               // 000000859A2C: 4A041404
	v_mad_u64_u32 v[11:12], null, s18, s25, v[3:4]             // 000000859A30: D6FE7C0B 040C3212
	v_add_nc_u32_e32 v3, s14, v18                              // 000000859A38: 4A06240E
	v_add_nc_u32_e32 v10, v18, v16                             // 000000859A3C: 4A142112
	s_mul_i32 s25, s25, s21                                    // 000000859A40: 96191519
	s_mul_i32 s4, s18, s24                                     // 000000859A44: 96041812
	v_and_or_b32 v1, 0xffff0000, v1, v19                       // 000000859A48: D6570001 044E02FF FFFF0000
	v_min_i32_e32 v18, s22, v3                                 // 000000859A54: 22240616
	v_add_nc_u32_e32 v19, s25, v2                              // 000000859A58: 4A260419
	v_add_nc_u32_e32 v3, s19, v12                              // 000000859A5C: 4A061813
	ds_store_b32 v14, v1                                       // 000000859A60: D8340000 0000010E
	v_cmp_lt_i32_e32 vcc_lo, v10, v18                          // 000000859A68: 7C82250A
	v_add_nc_u32_e32 v20, s4, v3                               // 000000859A6C: 4A280604
	s_waitcnt lgkmcnt(0)                                       // 000000859A70: BF89FC07
	s_barrier                                                  // 000000859A74: BFBD0000
	buffer_gl0_inv                                             // 000000859A78: E0AC0000 00000000
	s_and_saveexec_b32 s5, vcc_lo                              // 000000859A80: BE85206A
	s_cbranch_execz 21                                         // 000000859A84: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1dc>
	v_lshlrev_b32_e32 v1, 1, v10                               // 000000859A88: 30021481
	v_lshlrev_b32_e32 v3, 4, v10                               // 000000859A8C: 30061484
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000859A90: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000859A94: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 000000859A98: 3408069F
	.long 0xd7000401                                           // 000000859A9C: D7000401
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 000000859AA0: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859AA4: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 000000859AA8: D5207C02 00120514
	.long 0xd7000403                                           // 000000859AB0: D7000403
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 000000859AB4: 02020709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 000000859AB8: D5207C04 00120913
	s_clause 0x1                                               // 000000859AC0: BF850001
	global_load_d16_b16 v1, v[1:2], off                        // 000000859AC4: DC820000 017C0001
	global_load_b128 v[5:8], v[3:4], off                       // 000000859ACC: DC5E0000 057C0003
	s_waitcnt vmcnt(1)                                         // 000000859AD4: BF8907F7
	v_cvt_f32_f16_e32 v29, v1                                  // 000000859AD8: 7E3A1701
	s_or_b32 exec_lo, exec_lo, s5                              // 000000859ADC: 8C7E057E
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v23, 0             // 000000859AE0: CA100080 16160080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 000000859AE8: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v21, 0             // 000000859AF0: CA100080 1A140080
	s_and_saveexec_b32 s5, vcc_lo                              // 000000859AF8: BE85206A
	s_cbranch_execz 579                                        // 000000859AFC: BFA50243 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb0c>
	v_dual_mov_b32 v26, 0 :: v_dual_add_nc_u32 v1, 32, v10     // 000000859B00: CA200080 1A0014A0
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v12, 5, v10    // 000000859B08: CA220080 150C1485
	v_dual_mov_b32 v23, 0 :: v_dual_mov_b32 v22, 0             // 000000859B10: CA100080 17160080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000859B18: BF870003
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v27, 4, v1     // 000000859B1C: CA220080 181A0284
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v28, 1, v1     // 000000859B24: CA220080 191C0281
	v_dual_mov_b32 v17, 0 :: v_dual_mov_b32 v30, v29           // 000000859B2C: CA100080 111E011D
	s_mul_i32 s4, s11, 6                                       // 000000859B34: 9604860B
	s_mul_hi_u32 s16, s10, 6                                   // 000000859B38: 9690860A
	s_lshl_b64 s[14:15], s[10:11], 2                           // 000000859B3C: 848E820A
	s_add_i32 s16, s16, s4                                     // 000000859B40: 81100410
	s_mul_i32 s18, s10, 6                                      // 000000859B44: 9612860A
	s_mov_b32 s17, 0                                           // 000000859B48: BE910080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000859B4C: 848A810A
	s_branch 526                                               // 000000859B50: BFA0020E <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xa8c>
	s_or_b32 exec_lo, exec_lo, s19                             // 000000859B54: 8C7E137E
	v_and_b32_e32 v13, 0xff, v5                                // 000000859B58: 361A0AFF 000000FF
	s_and_b32 s4, exec_lo, vcc_lo                              // 000000859B60: 8B046A7E
	v_add_nc_u32_e32 v27, 0x200, v27                           // 000000859B64: 4A3636FF 00000200
	s_or_b32 s17, s4, s17                                      // 000000859B6C: 8C111104
	v_add_nc_u32_e32 v28, 64, v28                              // 000000859B70: 4A3838C0
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000859B74: 301A1A82
	ds_load_b32 v47, v13                                       // 000000859B78: D8D80000 2F00000D
	v_lshrrev_b32_e32 v13, 6, v5                               // 000000859B80: 321A0A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000859B84: BF870141
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000859B88: 361A1AFF 000003FC
	ds_load_b32 v48, v13                                       // 000000859B90: D8D80000 3000000D
	v_lshrrev_b32_e32 v13, 14, v5                              // 000000859B98: 321A0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 000000859B9C: 320A0A96
	v_and_b32_e32 v13, 0x3fc, v13                              // 000000859BA0: 361A1AFF 000003FC
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000859BA8: BF870152
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859BAC: 360A0AFF 000003FC
	ds_load_b32 v49, v13                                       // 000000859BB4: D8D80000 3100000D
	ds_load_b32 v50, v5                                        // 000000859BBC: D8D80000 32000005
	v_and_b32_e32 v5, 0xff, v6                                 // 000000859BC4: 360A0CFF 000000FF
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000859BCC: 341A189F
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000859BD0: 300A0A82
	ds_load_b32 v51, v5                                        // 000000859BD4: D8D80000 33000005
	v_lshrrev_b32_e32 v5, 6, v6                                // 000000859BDC: 320A0C86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859BE0: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859BE4: 360A0AFF 000003FC
	ds_load_b32 v52, v5                                        // 000000859BEC: D8D80000 34000005
	v_lshrrev_b32_e32 v5, 14, v6                               // 000000859BF4: 320A0C8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859BF8: 360A0AFF 000003FC
	ds_load_b32 v53, v5                                        // 000000859C00: D8D80000 35000005
	v_lshrrev_b32_e32 v5, 22, v6                               // 000000859C08: 320A0C96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859C0C: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859C10: 360A0AFF 000003FC
	ds_load_b32 v54, v5                                        // 000000859C18: D8D80000 36000005
	v_and_b32_e32 v5, 0xff, v7                                 // 000000859C20: 360A0EFF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000859C28: 300A0A82
	ds_load_b32 v55, v5                                        // 000000859C2C: D8D80000 37000005
	v_lshrrev_b32_e32 v5, 6, v7                                // 000000859C34: 320A0E86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859C38: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859C3C: 360A0AFF 000003FC
	ds_load_b32 v56, v5                                        // 000000859C44: D8D80000 38000005
	v_lshrrev_b32_e32 v5, 14, v7                               // 000000859C4C: 320A0E8E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859C50: 360A0AFF 000003FC
	ds_load_b32 v57, v5                                        // 000000859C58: D8D80000 39000005
	v_lshrrev_b32_e32 v5, 22, v7                               // 000000859C60: 320A0E96
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859C64: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859C68: 360A0AFF 000003FC
	ds_load_b32 v58, v5                                        // 000000859C70: D8D80000 3A000005
	v_and_b32_e32 v5, 0xff, v8                                 // 000000859C78: 360A10FF 000000FF
	v_lshlrev_b32_e32 v5, 2, v5                                // 000000859C80: 300A0A82
	ds_load_b32 v59, v5                                        // 000000859C84: D8D80000 3B000005
	v_lshrrev_b32_e32 v5, 6, v8                                // 000000859C8C: 320A1086
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859C90: BF8700B1
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859C94: 360A0AFF 000003FC
	ds_load_b32 v60, v5                                        // 000000859C9C: D8D80000 3C000005
	v_lshrrev_b32_e32 v5, 14, v8                               // 000000859CA4: 320A108E
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859CA8: 360A0AFF 000003FC
	ds_load_b32 v61, v5                                        // 000000859CB0: D8D80000 3D000005
	v_lshrrev_b32_e32 v5, 22, v8                               // 000000859CB8: 320A1096
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000859CBC: BF870141
	v_and_b32_e32 v5, 0x3fc, v5                                // 000000859CC0: 360A0AFF 000003FC
	ds_load_b32 v62, v5                                        // 000000859CC8: D8D80000 3E000005
	.long 0xd73c0005                                           // 000000859CD0: D73C0005
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 000000859CD4: 02021881
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000859CD8: 4A1818FF 00000400
	.long 0xd7006a2b                                           // 000000859CE0: D7006A2B
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000859CE4: 02020A06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000859CE8: BF870001
	v_add_co_ci_u32_e64 v44, null, s7, v6, vcc_lo              // 000000859CEC: D5207C2C 01AA0C07
	s_clause 0x3                                               // 000000859CF4: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000859CF8: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000859D00: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 000000859D08: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 000000859D10: DC5E0030 277C002B
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000859D18: BF890CF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000859D1C: CC1A4005 1A025F05
	s_waitcnt lgkmcnt(14)                                      // 000000859D24: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859D28: BF8700A1
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000859D2C: CC1A4005 1C166106
	s_waitcnt lgkmcnt(13)                                      // 000000859D34: BF89FCD7
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000859D38: CC1A4005 1C166307
	s_waitcnt lgkmcnt(12)                                      // 000000859D40: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859D44: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000859D48: CC1A4005 1C166508
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000859D50: BF8908B7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000859D54: CC1A4005 1C16671F
	s_waitcnt lgkmcnt(10)                                      // 000000859D5C: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859D60: BF8700A1
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000859D64: CC1A4005 1C166920
	s_waitcnt lgkmcnt(9)                                       // 000000859D6C: BF89FC97
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000859D70: CC1A4005 1C166B21
	s_waitcnt lgkmcnt(8)                                       // 000000859D78: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859D7C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000859D80: CC1A4005 1C166D22
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000859D88: BF890477
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000859D8C: CC1A4005 1C166F23
	s_waitcnt lgkmcnt(6)                                       // 000000859D94: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859D98: BF8700A1
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000859D9C: CC1A4005 1C167124
	s_waitcnt lgkmcnt(5)                                       // 000000859DA4: BF89FC57
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000859DA8: CC1A4005 1C167325
	s_waitcnt lgkmcnt(4)                                       // 000000859DB0: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859DB4: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000859DB8: CC1A4005 1C167526
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000859DC0: BF890037
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000859DC4: CC1A4005 1C167727
	.long 0xd7006a27                                           // 000000859DCC: D7006A27
	v_cndmask_b32_e32 v0, v43, v10, vcc_lo                     // 000000859DD0: 0200152B
	s_waitcnt lgkmcnt(2)                                       // 000000859DD4: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000859DD8: BF8701C2
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000859DDC: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s11, v44, vcc_lo            // 000000859DE4: D5207C28 01AA580B
	.long 0xd7006a2d                                           // 000000859DEC: D7006A2D
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 000000859DF0: 02001D2B
	s_waitcnt lgkmcnt(1)                                       // 000000859DF4: BF89FC17
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000859DF8: CC1A4005 1C167B29
	v_add_co_ci_u32_e64 v46, null, s15, v44, vcc_lo            // 000000859E00: D5207C2E 01AA580F
	.long 0xd7006a2b                                           // 000000859E08: D7006A2B
	v_cndmask_b32_e32 v0, v43, v18, vcc_lo                     // 000000859E0C: 0200252B
	s_waitcnt lgkmcnt(0)                                       // 000000859E10: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000859E14: BF870123
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000859E18: CC1A4005 1C167D2A
	v_add_co_ci_u32_e64 v44, null, s16, v44, vcc_lo            // 000000859E20: D5207C2C 01AA5810
	v_fmac_f32_e32 v21, v29, v5                                // 000000859E28: 562A0B1D
	s_clause 0x3                                               // 000000859E2C: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 000000859E30: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 000000859E38: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 000000859E40: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 000000859E48: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 000000859E50: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000859E54: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859E5C: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000859E60: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000859E68: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859E70: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000859E74: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000859E7C: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000859E80: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859E88: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000859E8C: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000859E94: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859E9C: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000859EA0: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000859EA8: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000859EAC: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859EB4: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000859EB8: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000859EC0: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000859EC8: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000859ECC: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000859ED4: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000859ED8: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859EE0: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000859EE4: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000859EEC: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859EF4: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000859EF8: CC1A4005 1C167D2A
	v_fmac_f32_e32 v26, v29, v5                                // 000000859F00: 56340B1D
	s_clause 0x3                                               // 000000859F04: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 000000859F08: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 000000859F10: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 000000859F18: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 000000859F20: DC5E0030 277C002D
	.long 0xd7006a2d                                           // 000000859F28: D7006A2D
	v_cndmask_b32_e32 v0, v45, v14, vcc_lo                     // 000000859F2C: 02001D2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000859F30: BF8700B1
	v_add_co_ci_u32_e64 v46, null, s15, v46, vcc_lo            // 000000859F34: D5207C2E 01AA5C0F
	s_waitcnt vmcnt(3)                                         // 000000859F3C: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 000000859F40: CC1A4005 1A025F05
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 000000859F48: CC1A4005 1C166106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859F50: BF870091
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 000000859F54: CC1A4005 1C166307
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 000000859F5C: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 000000859F64: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859F68: BF870091
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 000000859F6C: CC1A4005 1C16671F
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 000000859F74: CC1A4005 1C166920
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859F7C: BF870091
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 000000859F80: CC1A4005 1C166B21
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 000000859F88: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 000000859F90: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859F94: BF870091
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 000000859F98: CC1A4005 1C166F23
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 000000859FA0: CC1A4005 1C167124
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859FA8: BF870091
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 000000859FAC: CC1A4005 1C167325
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 000000859FB4: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 000000859FBC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859FC0: BF870091
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 000000859FC4: CC1A4005 1C167727
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 000000859FCC: CC1A4005 1C167928
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000859FD4: BF870091
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 000000859FD8: CC1A4005 1C167B29
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 000000859FE0: CC1A4005 1C167D2A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000859FE8: BF870001
	v_fmac_f32_e32 v25, v29, v5                                // 000000859FEC: 56320B1D
	s_clause 0x3                                               // 000000859FF0: BF850003
	global_load_b128 v[5:8], v[43:44], off                     // 000000859FF4: DC5E0000 057C002B
	global_load_b128 v[31:34], v[43:44], off offset:16         // 000000859FFC: DC5E0010 1F7C002B
	global_load_b128 v[35:38], v[43:44], off offset:32         // 00000085A004: DC5E0020 237C002B
	global_load_b128 v[39:42], v[43:44], off offset:48         // 00000085A00C: DC5E0030 277C002B
	s_waitcnt vmcnt(3)                                         // 00000085A014: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000085A018: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A020: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000085A024: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000085A02C: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A034: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000085A038: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000085A040: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000085A044: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A04C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000085A050: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000085A058: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A060: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000085A064: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000085A06C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000085A070: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A078: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000085A07C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000085A084: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A08C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000085A090: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000085A098: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000085A09C: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A0A4: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000085A0A8: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000085A0B0: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A0B8: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000085A0BC: CC1A4005 1C167D2A
	v_fmac_f32_e32 v24, v29, v5                                // 00000085A0C4: 56300B1D
	s_clause 0x3                                               // 00000085A0C8: BF850003
	global_load_b128 v[5:8], v[45:46], off                     // 00000085A0CC: DC5E0000 057C002D
	global_load_b128 v[31:34], v[45:46], off offset:16         // 00000085A0D4: DC5E0010 1F7C002D
	global_load_b128 v[35:38], v[45:46], off offset:32         // 00000085A0DC: DC5E0020 237C002D
	global_load_b128 v[39:42], v[45:46], off offset:48         // 00000085A0E4: DC5E0030 277C002D
	s_waitcnt vmcnt(3)                                         // 00000085A0EC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000085A0F0: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A0F8: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000085A0FC: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000085A104: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A10C: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000085A110: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000085A118: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000085A11C: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A124: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000085A128: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000085A130: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A138: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000085A13C: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000085A144: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000085A148: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A150: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000085A154: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000085A15C: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A164: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000085A168: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000085A170: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000085A174: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000085A17C: D7006A27
	v_cndmask_b32_e32 v0, v43, v14, vcc_lo                     // 00000085A180: 02001D2B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085A184: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000085A188: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s15, v44, vcc_lo            // 00000085A190: D5207C28 01AA580F
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000085A198: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A1A0: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000085A1A4: CC1A4005 1C167D2A
	v_fmac_f32_e32 v23, v29, v5                                // 00000085A1AC: 562E0B1D
	s_clause 0x3                                               // 00000085A1B0: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000085A1B4: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 00000085A1BC: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000085A1C4: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 00000085A1CC: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000085A1D4: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000085A1D8: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A1E0: BF870091
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000085A1E4: CC1A4005 1C166106
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000085A1EC: CC1A4005 1C166307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A1F4: BF8700A1
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000085A1F8: CC1A4005 1C166508
	s_waitcnt vmcnt(2)                                         // 00000085A200: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000085A204: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A20C: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000085A210: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000085A218: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A220: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000085A224: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000085A22C: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000085A230: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A238: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000085A23C: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000085A244: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A24C: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000085A250: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000085A258: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000085A25C: CC1A4005 1C167727
	.long 0xd7006a27                                           // 00000085A264: D7006A27
	v_cndmask_b32_e32 v0, v45, v14, vcc_lo                     // 00000085A268: 02001D2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085A26C: BF870122
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000085A270: CC1A4005 1C167928
	v_add_co_ci_u32_e64 v40, null, s15, v46, vcc_lo            // 00000085A278: D5207C28 01AA5C0F
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000085A280: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A288: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000085A28C: CC1A4005 1C167D2A
	v_fmac_f32_e32 v22, v29, v5                                // 00000085A294: 562C0B1D
	s_clause 0x3                                               // 00000085A298: BF850003
	global_load_b128 v[5:8], v[39:40], off                     // 00000085A29C: DC5E0000 057C0027
	global_load_b128 v[31:34], v[39:40], off offset:16         // 00000085A2A4: DC5E0010 1F7C0027
	global_load_b128 v[35:38], v[39:40], off offset:32         // 00000085A2AC: DC5E0020 237C0027
	global_load_b128 v[39:42], v[39:40], off offset:48         // 00000085A2B4: DC5E0030 277C0027
	s_waitcnt vmcnt(3)                                         // 00000085A2BC: BF890FF7
	v_dot2_f32_bf16 v5, v5, v47, 0                             // 00000085A2C0: CC1A4005 1A025F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085A2C8: BF870121
	v_dot2_f32_bf16 v5, v6, v48, v5                            // 00000085A2CC: CC1A4005 1C166106
	v_mov_b32_e32 v6, v2                                       // 00000085A2D4: 7E0C0302
	v_dot2_f32_bf16 v5, v7, v49, v5                            // 00000085A2D8: CC1A4005 1C166307
	v_mov_b32_e32 v7, v3                                       // 00000085A2E0: 7E0E0303
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000085A2E4: BF870132
	v_dot2_f32_bf16 v5, v8, v50, v5                            // 00000085A2E8: CC1A4005 1C166508
	v_mov_b32_e32 v8, v4                                       // 00000085A2F0: 7E100304
	s_waitcnt vmcnt(2)                                         // 00000085A2F4: BF890BF7
	v_dot2_f32_bf16 v5, v31, v51, v5                           // 00000085A2F8: CC1A4005 1C16671F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A300: BF870091
	v_dot2_f32_bf16 v5, v32, v52, v5                           // 00000085A304: CC1A4005 1C166920
	v_dot2_f32_bf16 v5, v33, v53, v5                           // 00000085A30C: CC1A4005 1C166B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A314: BF8700A1
	v_dot2_f32_bf16 v5, v34, v54, v5                           // 00000085A318: CC1A4005 1C166D22
	s_waitcnt vmcnt(1)                                         // 00000085A320: BF8907F7
	v_dot2_f32_bf16 v5, v35, v55, v5                           // 00000085A324: CC1A4005 1C166F23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A32C: BF870091
	v_dot2_f32_bf16 v5, v36, v56, v5                           // 00000085A330: CC1A4005 1C167124
	v_dot2_f32_bf16 v5, v37, v57, v5                           // 00000085A338: CC1A4005 1C167325
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A340: BF8700A1
	v_dot2_f32_bf16 v5, v38, v58, v5                           // 00000085A344: CC1A4005 1C167526
	s_waitcnt vmcnt(0)                                         // 00000085A34C: BF8903F7
	v_dot2_f32_bf16 v5, v39, v59, v5                           // 00000085A350: CC1A4005 1C167727
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A358: BF870091
	v_dot2_f32_bf16 v5, v40, v60, v5                           // 00000085A35C: CC1A4005 1C167928
	v_dot2_f32_bf16 v5, v41, v61, v5                           // 00000085A364: CC1A4005 1C167B29
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A36C: BF870091
	v_dot2_f32_bf16 v5, v42, v62, v5                           // 00000085A370: CC1A4005 1C167D2A
	v_fmac_f32_e32 v17, v29, v5                                // 00000085A378: 56220B1D
	v_mov_b32_e32 v5, v1                                       // 00000085A37C: 7E0A0301
	v_mov_b32_e32 v29, v30                                     // 00000085A380: 7E3A031E
	s_and_not1_b32 exec_lo, exec_lo, s17                       // 00000085A384: 917E117E
	s_cbranch_execz 31                                         // 00000085A388: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xb08>
	s_waitcnt vmcnt(0)                                         // 00000085A38C: BF8903F7
	v_dual_mov_b32 v1, v5 :: v_dual_add_nc_u32 v10, 32, v10    // 00000085A390: CA200105 010A14A0
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v3, v7             // 00000085A398: CA100106 02020107
	v_mov_b32_e32 v4, v8                                       // 00000085A3A0: 7E080308
	s_mov_b32 s19, exec_lo                                     // 00000085A3A4: BE93007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000085A3A8: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v10, v18                          // 00000085A3AC: 7C8C250A
	.long 0xd4c1007e                                           // 00000085A3B0: D4C1007E
	v_cndmask_b32_e32 v1, v10, v18, vcc_lo                     // 00000085A3B4: 0202250A
	s_cbranch_execz 64998                                      // 00000085A3B8: BFA5FDE6 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	v_ashrrev_i32_e32 v2, 31, v28                              // 00000085A3BC: 3404389F
	v_ashrrev_i32_e32 v4, 31, v27                              // 00000085A3C0: 3408369F
	.long 0xd7000401                                           // 00000085A3C4: D7000401
	v_cndmask_b32_e32 v1, v11, v28, vcc_lo                     // 00000085A3C8: 0202390B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A3CC: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v20, v2, s4                  // 00000085A3D0: D5207C02 00120514
	.long 0xd7000403                                           // 00000085A3D8: D7000403
	v_cndmask_b32_e32 v1, v9, v27, vcc_lo                      // 00000085A3DC: 02023709
	v_add_co_ci_u32_e64 v4, null, v19, v4, s4                  // 00000085A3E0: D5207C04 00120913
	s_clause 0x1                                               // 00000085A3E8: BF850001
	global_load_d16_b16 v13, v[1:2], off                       // 00000085A3EC: DC820000 0D7C0001
	global_load_b128 v[1:4], v[3:4], off                       // 00000085A3F4: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 00000085A3FC: BF8907F7
	v_cvt_f32_f16_e32 v30, v13                                 // 00000085A400: 7E3C170D
	s_branch 64979                                             // 00000085A404: BFA0FDD3 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x254>
	s_or_b32 exec_lo, exec_lo, s17                             // 00000085A408: 8C7E117E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085A40C: BF8700B9
	s_or_b32 exec_lo, exec_lo, s5                              // 00000085A410: 8C7E057E
	.long 0xd71f0001                                           // 00000085A414: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000085A418: 020100C1
	s_mov_b32 s4, exec_lo                                      // 00000085A41C: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000085A420: 3A040290
	v_xor_b32_e32 v9, 8, v1                                    // 00000085A424: 3A120288
	v_xor_b32_e32 v19, 4, v1                                   // 00000085A428: 3A260284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000085A42C: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000085A430: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000085A434: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 00000085A438: 7C9812A0
	v_cndmask_b32_e32 v9, v1, v9, vcc_lo                       // 00000085A43C: 02121301
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000085A440: 7C9826A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000085A444: BF870002
	v_lshlrev_b32_e32 v9, 2, v9                                // 00000085A448: 30121282
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000085A44C: 30040482
	ds_bpermute_b32 v3, v2, v21                                // 00000085A450: DACC0000 03001502
	s_waitcnt lgkmcnt(0)                                       // 00000085A458: BF89FC07
	v_add_f32_e32 v3, v21, v3                                  // 00000085A45C: 06060715
	s_waitcnt vmcnt(0)                                         // 00000085A460: BF8903F7
	ds_bpermute_b32 v5, v2, v25                                // 00000085A464: DACC0000 05001902
	ds_bpermute_b32 v6, v2, v24                                // 00000085A46C: DACC0000 06001802
	ds_bpermute_b32 v4, v2, v26                                // 00000085A474: DACC0000 04001A02
	ds_bpermute_b32 v7, v2, v23                                // 00000085A47C: DACC0000 07001702
	ds_bpermute_b32 v8, v2, v22                                // 00000085A484: DACC0000 08001602
	ds_bpermute_b32 v2, v2, v17                                // 00000085A48C: DACC0000 02001102
	ds_bpermute_b32 v10, v9, v3                                // 00000085A494: DACC0000 0A000309
	s_waitcnt lgkmcnt(5)                                       // 00000085A49C: BF89FC57
	v_dual_add_f32 v5, v25, v5 :: v_dual_add_f32 v6, v24, v6   // 00000085A4A0: C9080B19 05060D18
	s_waitcnt lgkmcnt(3)                                       // 00000085A4A8: BF89FC37
	v_dual_add_f32 v4, v26, v4 :: v_dual_add_f32 v7, v23, v7   // 00000085A4AC: C908091A 04060F17
	s_waitcnt lgkmcnt(2)                                       // 00000085A4B4: BF89FC27
	v_add_f32_e32 v8, v22, v8                                  // 00000085A4B8: 06101116
	ds_bpermute_b32 v12, v9, v5                                // 00000085A4BC: DACC0000 0C000509
	ds_bpermute_b32 v13, v9, v6                                // 00000085A4C4: DACC0000 0D000609
	ds_bpermute_b32 v11, v9, v4                                // 00000085A4CC: DACC0000 0B000409
	v_cndmask_b32_e32 v19, v1, v19, vcc_lo                     // 00000085A4D4: 02262701
	ds_bpermute_b32 v18, v9, v8                                // 00000085A4D8: DACC0000 12000809
	s_waitcnt lgkmcnt(4)                                       // 00000085A4E0: BF89FC47
	v_add_f32_e32 v3, v3, v10                                  // 00000085A4E4: 06061503
	s_waitcnt lgkmcnt(2)                                       // 00000085A4E8: BF89FC27
	v_dual_add_f32 v5, v5, v12 :: v_dual_add_f32 v6, v6, v13   // 00000085A4EC: C9081905 05061B06
	v_dual_add_f32 v2, v17, v2 :: v_dual_lshlrev_b32 v19, 2, v19// 00000085A4F4: C9220511 02122682
	ds_bpermute_b32 v17, v9, v7                                // 00000085A4FC: DACC0000 11000709
	s_waitcnt lgkmcnt(2)                                       // 00000085A504: BF89FC27
	v_add_f32_e32 v4, v4, v11                                  // 00000085A508: 06081704
	s_waitcnt lgkmcnt(1)                                       // 00000085A50C: BF89FC17
	v_add_f32_e32 v8, v8, v18                                  // 00000085A510: 06102508
	ds_bpermute_b32 v9, v9, v2                                 // 00000085A514: DACC0000 09000209
	ds_bpermute_b32 v11, v19, v5                               // 00000085A51C: DACC0000 0B000513
	ds_bpermute_b32 v12, v19, v6                               // 00000085A524: DACC0000 0C000613
	ds_bpermute_b32 v10, v19, v4                               // 00000085A52C: DACC0000 0A000413
	s_waitcnt lgkmcnt(4)                                       // 00000085A534: BF89FC47
	v_add_f32_e32 v7, v7, v17                                  // 00000085A538: 060E2307
	ds_bpermute_b32 v17, v19, v8                               // 00000085A53C: DACC0000 11000813
	s_waitcnt lgkmcnt(4)                                       // 00000085A544: BF89FC47
	v_add_f32_e32 v2, v2, v9                                   // 00000085A548: 06041302
	ds_bpermute_b32 v9, v19, v3                                // 00000085A54C: DACC0000 09000313
	s_waitcnt lgkmcnt(2)                                       // 00000085A554: BF89FC27
	v_dual_add_f32 v5, v5, v11 :: v_dual_add_f32 v4, v4, v10   // 00000085A558: C9081705 05041504
	ds_bpermute_b32 v13, v19, v7                               // 00000085A560: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 00000085A568: DACC0000 12000213
	v_xor_b32_e32 v19, 2, v1                                   // 00000085A570: 3A260282
	v_add_f32_e32 v6, v6, v12                                  // 00000085A574: 060C1906
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085A578: BF8700B2
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000085A57C: 7C9826A0
	s_waitcnt lgkmcnt(3)                                       // 00000085A580: BF89FC37
	v_dual_cndmask_b32 v19, v1, v19 :: v_dual_add_f32 v8, v8, v17// 00000085A584: CA482701 13082308
	v_lshlrev_b32_e32 v19, 2, v19                              // 00000085A58C: 30262682
	s_waitcnt lgkmcnt(0)                                       // 00000085A590: BF89FC07
	v_dual_add_f32 v3, v3, v9 :: v_dual_add_f32 v2, v2, v18    // 00000085A594: C9081303 03022502
	ds_bpermute_b32 v11, v19, v5                               // 00000085A59C: DACC0000 0B000513
	v_add_f32_e32 v7, v7, v13                                  // 00000085A5A4: 060E1B07
	ds_bpermute_b32 v9, v19, v3                                // 00000085A5A8: DACC0000 09000313
	ds_bpermute_b32 v10, v19, v4                               // 00000085A5B0: DACC0000 0A000413
	ds_bpermute_b32 v12, v19, v6                               // 00000085A5B8: DACC0000 0C000613
	ds_bpermute_b32 v17, v19, v8                               // 00000085A5C0: DACC0000 11000813
	ds_bpermute_b32 v13, v19, v7                               // 00000085A5C8: DACC0000 0D000713
	ds_bpermute_b32 v18, v19, v2                               // 00000085A5D0: DACC0000 12000213
	v_xor_b32_e32 v19, 1, v1                                   // 00000085A5D8: 3A260281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000085A5DC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v19                           // 00000085A5E0: 7C9826A0
	v_cndmask_b32_e32 v1, v1, v19, vcc_lo                      // 00000085A5E4: 02022701
	v_lshlrev_b32_e32 v19, 2, v1                               // 00000085A5E8: 30260282
	s_waitcnt lgkmcnt(5)                                       // 00000085A5EC: BF89FC57
	v_add_f32_e32 v1, v3, v9                                   // 00000085A5F0: 06021303
	s_waitcnt lgkmcnt(4)                                       // 00000085A5F4: BF89FC47
	v_dual_add_f32 v3, v4, v10 :: v_dual_add_f32 v4, v5, v11   // 00000085A5F8: C9081504 03041705
	s_waitcnt lgkmcnt(2)                                       // 00000085A600: BF89FC27
	v_dual_add_f32 v5, v6, v12 :: v_dual_add_f32 v12, v8, v17  // 00000085A604: C9081906 050C2308
	s_waitcnt lgkmcnt(1)                                       // 00000085A60C: BF89FC17
	v_add_f32_e32 v10, v7, v13                                 // 00000085A610: 06141B07
	s_waitcnt lgkmcnt(0)                                       // 00000085A614: BF89FC07
	v_add_f32_e32 v2, v2, v18                                  // 00000085A618: 06042502
	ds_bpermute_b32 v6, v19, v1                                // 00000085A61C: DACC0000 06000113
	ds_bpermute_b32 v8, v19, v3                                // 00000085A624: DACC0000 08000313
	ds_bpermute_b32 v9, v19, v4                                // 00000085A62C: DACC0000 09000413
	ds_bpermute_b32 v11, v19, v5                               // 00000085A634: DACC0000 0B000513
	ds_bpermute_b32 v13, v19, v10                              // 00000085A63C: DACC0000 0D000A13
	ds_bpermute_b32 v17, v19, v12                              // 00000085A644: DACC0000 11000C13
	ds_bpermute_b32 v7, v19, v2                                // 00000085A64C: DACC0000 07000213
	v_cmpx_eq_u32_e32 0, v16                                   // 00000085A654: 7D942080
	s_cbranch_execz 28                                         // 00000085A658: BFA5001C <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xdcc>
	s_waitcnt lgkmcnt(2)                                       // 00000085A65C: BF89FC27
	v_dual_add_f32 v10, v10, v13 :: v_dual_add_f32 v3, v3, v8  // 00000085A660: C9081B0A 0A021103
	v_mul_u32_u24_e32 v13, 28, v15                             // 00000085A668: 161A1E9C
	v_dual_add_f32 v4, v4, v9 :: v_dual_add_f32 v1, v1, v6     // 00000085A66C: C9081304 04000D01
	s_waitcnt lgkmcnt(1)                                       // 00000085A674: BF89FC17
	v_dual_add_f32 v12, v12, v17 :: v_dual_add_f32 v5, v5, v11 // 00000085A678: C908230C 0C041705
	s_delay_alu instid0(VALU_DEP_3)                            // 00000085A680: BF870003
	v_or_b32_e32 v6, 0x400, v13                                // 00000085A684: 380C1AFF 00000400
	v_mad_u32_u24 v8, v15, 28, 0x408                           // 00000085A68C: D60B0008 03FD390F 00000408
	v_mad_u32_u24 v9, v15, 28, 0x410                           // 00000085A698: D60B0009 03FD390F 00000410
	s_waitcnt lgkmcnt(0)                                       // 00000085A6A4: BF89FC07
	v_add_f32_e32 v2, v2, v7                                   // 00000085A6A8: 06040F02
	ds_store_2addr_b32 v6, v1, v3 offset1:1                    // 00000085A6AC: D8380100 00030106
	ds_store_2addr_b32 v8, v4, v5 offset1:1                    // 00000085A6B4: D8380100 00050408
	ds_store_2addr_b32 v9, v10, v12 offset1:1                  // 00000085A6BC: D8380100 000C0A09
	ds_store_b32 v13, v2 offset:1048                           // 00000085A6C4: D8340418 0000020D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000085A6CC: 8C7E047E
	.long 0xd4510004                                           // 00000085A6D0: D4510004
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 00000085A6D4: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 7, v0                             // 00000085A6D8: 7C980087
	s_waitcnt lgkmcnt(0)                                       // 00000085A6DC: BF89FC07
	s_barrier                                                  // 00000085A6E0: BFBD0000
	buffer_gl0_inv                                             // 00000085A6E4: E0AC0000 00000000
	s_and_b32 s4, vcc_lo, s4                                   // 00000085A6EC: 8B04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000085A6F0: BF870009
	s_and_saveexec_b32 s5, s4                                  // 00000085A6F4: BE852004
	s_cbranch_execz 85                                         // 00000085A6F8: BFA50055 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi7ELi32ELi8ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0xf50>
	v_add_nc_u32_e32 v7, 0x400, v14                            // 00000085A6FC: 4A0E1CFF 00000400
	s_load_b32 s0, s[0:1], 0x48                                // 00000085A704: F4000000 F8000048
	ds_load_2addr_b32 v[1:2], v7 offset1:7                     // 00000085A70C: D8DC0700 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:14 offset1:21         // 00000085A714: D8DC150E 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:28 offset1:35         // 00000085A71C: D8DC231C 05000007
	s_waitcnt lgkmcnt(0)                                       // 00000085A724: BF89FC07
	v_add_f32_e32 v1, 0, v1                                    // 00000085A728: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000085A72C: BF8700B1
	v_add_f32_e32 v8, v1, v2                                   // 00000085A730: 06100501
	ds_load_2addr_b32 v[1:2], v7 offset0:42 offset1:49         // 00000085A734: D8DC312A 01000007
	v_add_f32_e32 v3, v8, v3                                   // 00000085A73C: 06060708
	v_add_f32_e32 v3, v3, v4                                   // 00000085A740: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A744: BF870091
	v_add_f32_e32 v3, v3, v5                                   // 00000085A748: 06060B03
	v_add_f32_e32 v3, v3, v6                                   // 00000085A74C: 06060D03
	s_waitcnt lgkmcnt(0)                                       // 00000085A750: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A754: BF870091
	v_add_f32_e32 v1, v3, v1                                   // 00000085A758: 06020303
	v_add_f32_e32 v1, v1, v2                                   // 00000085A75C: 06020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A760: BF870091
	v_bfe_u32 v2, v1, 16, 1                                    // 00000085A764: D6100002 02052101
	v_add3_u32 v1, v1, v2, 0x7fff                              // 00000085A76C: D6550001 03FE0501 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A778: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 00000085A77C: 360202FF FFFF0000
	v_mul_f32_e32 v1, s0, v1                                   // 00000085A784: 10020200
	s_lshl_b64 s[0:1], s[2:3], 2                               // 00000085A788: 84808202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A78C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 00000085A790: 100202FF BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 00000085A798: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A79C: BF870095
	v_add_f32_e32 v4, 1.0, v1                                  // 00000085A7A0: 060802F2
	v_div_scale_f32 v5, null, v4, v4, 1.0                      // 00000085A7A4: D6FC7C05 03CA0904
	v_div_scale_f32 v7, vcc_lo, 1.0, v4, 1.0                   // 00000085A7AC: D6FC6A07 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000085A7B4: BF870292
	v_rcp_f32_e32 v6, v5                                       // 00000085A7B8: 7E0C5505
	v_fma_f32 v1, -v5, v6, 1.0                                 // 00000085A7BC: D6130001 23CA0D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000085A7C4: BF870121
	v_fmac_f32_e32 v6, v1, v6                                  // 00000085A7C8: 560C0D01
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 00000085A7CC: D6FE7C01 0202000C
	v_mul_f32_e32 v8, v7, v6                                   // 00000085A7D4: 10100D07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A7D8: BF870091
	v_fma_f32 v3, -v5, v8, v7                                  // 00000085A7DC: D6130003 241E1105
	v_fmac_f32_e32 v8, v3, v6                                  // 00000085A7E4: 56100D03
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085A7E8: BF870114
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 00000085A7EC: D6FE7C02 040A000D
	v_fma_f32 v0, -v5, v8, v7                                  // 00000085A7F4: D6130000 241E1105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085A7FC: BF870191
	v_div_fmas_f32 v3, v0, v6, v8                              // 00000085A800: D6370003 04220D00
	.long 0xd73c0000                                           // 00000085A808: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000085A80C: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000085A810: BF870112
	v_div_fixup_f32 v2, v3, v4, 1.0                            // 00000085A814: D6270002 03CA0903
	.long 0xd7006a00                                           // 00000085A81C: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000085A820: 02020008
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000085A824: BF870191
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 00000085A828: D5207C01 01AA0209
	v_add_f32_e32 v2, v2, v2                                   // 00000085A830: 06040502
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000085A834: BF870093
	.long 0xd7006a00                                           // 00000085A838: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 00000085A83C: 02000100
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000085A840: D5207C01 01AA0201
	global_store_b32 v[0:1], v2, off                           // 00000085A848: DC6A0000 007C0200
	s_endpgm                                                   // 00000085A850: BFB00000
		...

