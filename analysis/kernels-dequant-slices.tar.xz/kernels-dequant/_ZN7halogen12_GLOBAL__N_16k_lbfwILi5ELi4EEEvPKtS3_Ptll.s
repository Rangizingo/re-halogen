00000000002da000 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll>:
; _ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll():
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000002DA000: F4040200 F8000020
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000002DA008: 32020085
	s_mov_b32 s3, 0                                            // 0000002DA00C: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002DA010: BF870009
	s_lshl_b64 s[2:3], s[2:3], 3                               // 0000002DA014: 84828302
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000002DA018: BF870481
	v_or_b32_e32 v1, s2, v1                                    // 0000002DA01C: 38020202
	v_mov_b32_e32 v2, s3                                       // 0000002DA020: 7E040203
	s_mov_b32 s2, exec_lo                                      // 0000002DA024: BE82007E
	s_waitcnt lgkmcnt(0)                                       // 0000002DA028: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DA02C: BF870001
	.long 0xd4d4007e                                           // 0000002DA030: D4D4007E
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000002DA034: 02020208
	s_cbranch_execz 525                                        // 0000002DA038: BFA5020D <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll+0x870>
	s_load_b256 s[0:7], s[0:1], null                           // 0000002DA03C: F40C0000 F8000000
	v_and_b32_e32 v0, 31, v0                                   // 0000002DA044: 3600009F
	s_waitcnt lgkmcnt(0)                                       // 0000002DA048: BF89FC07
	.long 0xd451000a                                           // 0000002DA04C: D451000A
	v_cndmask_b32_e32 v0, s6, v129, vcc_lo                     // 0000002DA050: 02010206
	s_and_b32 vcc_lo, exec_lo, s10                             // 0000002DA054: 8B6A0A7E
	s_cbranch_vccnz 325                                        // 0000002DA058: BFA40145 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll+0x570>
	.long 0xd72c0006                                           // 0000002DA05C: D72C0006
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 0000002DA060: 02020207
	.long 0xd72c0007                                           // 0000002DA064: D72C0007
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 0000002DA068: 02020406
	v_mad_u64_u32 v[4:5], null, s6, v1, 0                      // 0000002DA06C: D6FE7C04 02020206
	s_lshl_b64 s[10:11], s[6:7], 1                             // 0000002DA074: 848A8106
	s_mul_i32 s14, s7, 6                                       // 0000002DA078: 960E8607
	s_add_u32 s10, s2, s10                                     // 0000002DA07C: 800A0A02
	s_addc_u32 s11, s3, s11                                    // 0000002DA080: 820B0B03
	s_lshl_b64 s[12:13], s[6:7], 3                             // 0000002DA084: 848C8306
	s_mul_hi_u32 s15, s6, 6                                    // 0000002DA088: 968F8606
	s_mul_i32 s16, s6, 6                                       // 0000002DA08C: 96108606
	v_add3_u32 v5, v5, v7, v6                                  // 0000002DA090: D6550005 041A0F05
	s_add_u32 s12, s2, s12                                     // 0000002DA098: 800C0C02
	s_addc_u32 s13, s3, s13                                    // 0000002DA09C: 820D0D03
	s_add_i32 s15, s15, s14                                    // 0000002DA0A0: 810F0E0F
	s_add_u32 s14, s2, s16                                     // 0000002DA0A4: 800E1002
	.long 0xd73c0004                                           // 0000002DA0A8: D73C0004
	v_cndmask_b32_e32 v1, 1, v4, vcc_lo                        // 0000002DA0AC: 02020881
	v_dual_mov_b32 v8, 0 :: v_dual_lshlrev_b32 v3, 4, v0       // 0000002DA0B0: CA220080 08020084
	s_addc_u32 s15, s3, s15                                    // 0000002DA0B8: 820F0F03
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 0000002DA0BC: CA100080 0A080080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DA0C4: BF870093
	.long 0xd7006a04                                           // 0000002DA0C8: D7006A04
	v_cndmask_b32_e32 v1, s0, v4, vcc_lo                       // 0000002DA0CC: 02020800
	v_add_co_ci_u32_e64 v5, null, s1, v5, vcc_lo               // 0000002DA0D0: D5207C05 01AA0A01
	s_lshl_b64 s[0:1], s[6:7], 2                               // 0000002DA0D8: 84808206
	v_dual_mov_b32 v7, 0 :: v_dual_mov_b32 v6, 0               // 0000002DA0DC: CA100080 07060080
	s_add_u32 s16, s2, s0                                      // 0000002DA0E4: 80100002
	s_addc_u32 s17, s3, s1                                     // 0000002DA0E8: 82110103
	s_mov_b64 s[0:1], 0                                        // 0000002DA0EC: BE800180
	.long 0xd7006a4b                                           // 0000002DA0F0: D7006A4B
	v_cndmask_b32_e32 v1, v4, v3, vcc_lo                       // 0000002DA0F4: 02020704
	.long 0xd700124d                                           // 0000002DA0F8: D700124D
	v_cndmask_b32_e32 v1, s2, v3, vcc_lo                       // 0000002DA0FC: 02020602
	.long 0xd700134f                                           // 0000002DA100: D700134F
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 0000002DA104: 0202060A
	v_add_co_ci_u32_e64 v76, null, 0, v5, vcc_lo               // 0000002DA108: D5207C4C 01AA0A80
	.long 0xd7001451                                           // 0000002DA110: D7001451
	v_cndmask_b32_e32 v1, s16, v3, vcc_lo                      // 0000002DA114: 02020610
	v_add_co_ci_u32_e64 v78, null, s3, 0, s18                  // 0000002DA118: D5207C4E 00490003
	.long 0xd7001553                                           // 0000002DA120: D7001553
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 0000002DA124: 0202060E
	v_add_co_ci_u32_e64 v80, null, s11, 0, s19                 // 0000002DA128: D5207C50 004D000B
	.long 0xd7001655                                           // 0000002DA130: D7001655
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 0000002DA134: 0202060C
	v_add_co_ci_u32_e64 v82, null, s17, 0, s20                 // 0000002DA138: D5207C52 00510011
	v_add_co_ci_u32_e64 v84, null, s15, 0, s21                 // 0000002DA140: D5207C54 0055000F
	v_add_co_ci_u32_e64 v86, null, s13, 0, s22                 // 0000002DA148: D5207C56 0059000D
	global_load_b128 v[11:14], v[75:76], off                   // 0000002DA150: DC5E0000 0B7C004B
	global_load_b128 v[15:18], v[77:78], off                   // 0000002DA158: DC5E0000 0F7C004D
	global_load_b128 v[19:22], v[79:80], off                   // 0000002DA160: DC5E0000 137C004F
	global_load_b128 v[23:26], v[81:82], off                   // 0000002DA168: DC5E0000 177C0051
	global_load_b128 v[27:30], v[83:84], off                   // 0000002DA170: DC5E0000 1B7C0053
	global_load_b128 v[31:34], v[85:86], off                   // 0000002DA178: DC5E0000 1F7C0055
	global_load_b128 v[35:38], v[75:76], off offset:512        // 0000002DA180: DC5E0200 237C004B
	global_load_b128 v[39:42], v[77:78], off offset:512        // 0000002DA188: DC5E0200 277C004D
	global_load_b128 v[43:46], v[79:80], off offset:512        // 0000002DA190: DC5E0200 2B7C004F
	global_load_b128 v[47:50], v[81:82], off offset:512        // 0000002DA198: DC5E0200 2F7C0051
	global_load_b128 v[51:54], v[83:84], off offset:512        // 0000002DA1A0: DC5E0200 337C0053
	global_load_b128 v[55:58], v[85:86], off offset:512        // 0000002DA1A8: DC5E0200 377C0055
	global_load_b128 v[59:62], v[79:80], off offset:1024       // 0000002DA1B0: DC5E0400 3B7C004F
	global_load_b128 v[63:66], v[81:82], off offset:1024       // 0000002DA1B8: DC5E0400 3F7C0051
	global_load_b128 v[67:70], v[83:84], off offset:1024       // 0000002DA1C0: DC5E0400 437C0053
	global_load_b128 v[71:74], v[85:86], off offset:1024       // 0000002DA1C8: DC5E0400 477C0055
	s_add_u32 s0, s0, 0x400                                    // 0000002DA1D0: 8000FF00 00000400
	s_addc_u32 s1, s1, 0                                       // 0000002DA1D8: 82018001
	s_add_u32 s10, s10, 0x800                                  // 0000002DA1DC: 800AFF0A 00000800
	s_addc_u32 s11, s11, 0                                     // 0000002DA1E4: 820B800B
	s_add_u32 s12, s12, 0x800                                  // 0000002DA1E8: 800CFF0C 00000800
	.long 0xd4560012                                           // 0000002DA1F0: D4560012
	v_cndmask_b32_e32 v0, s0, v6, vcc_lo                       // 0000002DA1F4: 02000C00
	s_addc_u32 s13, s13, 0                                     // 0000002DA1F8: 820D800D
	.long 0xd7006a04                                           // 0000002DA1FC: D7006A04
	v_cndmask_b32_e32 v1, 0x800, v4, vcc_lo                    // 0000002DA200: 020208FF 00000800
	s_add_u32 s2, s2, 0x800                                    // 0000002DA208: 8002FF02 00000800
	s_addc_u32 s3, s3, 0                                       // 0000002DA210: 82038003
	v_add_co_ci_u32_e64 v5, null, 0, v5, vcc_lo                // 0000002DA214: D5207C05 01AA0A80
	s_add_u32 s14, s14, 0x800                                  // 0000002DA21C: 800EFF0E 00000800
	s_addc_u32 s15, s15, 0                                     // 0000002DA224: 820F800F
	s_add_u32 s16, s16, 0x800                                  // 0000002DA228: 8010FF10 00000800
	s_addc_u32 s17, s17, 0                                     // 0000002DA230: 82118011
	s_and_b32 vcc_lo, exec_lo, s18                             // 0000002DA234: 8B6A127E
	s_waitcnt vmcnt(14)                                        // 0000002DA238: BF893BF7
	v_dot2_f32_bf16 v8, v15, v11, v8                           // 0000002DA23C: CC1A4008 1C22170F
	s_waitcnt vmcnt(11)                                        // 0000002DA244: BF892FF7
	v_dot2_f32_bf16 v7, v27, v11, v7                           // 0000002DA248: CC1A4007 1C1E171B
	s_waitcnt vmcnt(10)                                        // 0000002DA250: BF892BF7
	v_dot2_f32_bf16 v6, v31, v11, v6                           // 0000002DA254: CC1A4006 1C1A171F
	v_dot2_f32_bf16 v8, v16, v12, v8                           // 0000002DA25C: CC1A4008 1C221910
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DA264: BF870193
	v_dot2_f32_bf16 v7, v28, v12, v7                           // 0000002DA268: CC1A4007 1C1E191C
	v_dot2_f32_bf16 v6, v32, v12, v6                           // 0000002DA270: CC1A4006 1C1A1920
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DA278: BF870193
	v_dot2_f32_bf16 v8, v17, v13, v8                           // 0000002DA27C: CC1A4008 1C221B11
	v_dot2_f32_bf16 v7, v29, v13, v7                           // 0000002DA284: CC1A4007 1C1E1B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DA28C: BF870193
	v_dot2_f32_bf16 v6, v33, v13, v6                           // 0000002DA290: CC1A4006 1C1A1B21
	v_dot2_f32_bf16 v87, v18, v14, v8                          // 0000002DA298: CC1A4057 1C221D12
	v_dot2_f32_bf16 v8, v19, v11, v10                          // 0000002DA2A0: CC1A4008 1C2A1713
	global_load_b128 v[15:18], v[75:76], off offset:1024       // 0000002DA2A8: DC5E0400 0F7C004B
	v_dot2_f32_bf16 v90, v30, v14, v7                          // 0000002DA2B0: CC1A405A 1C1E1D1E
	v_dot2_f32_bf16 v6, v34, v14, v6                           // 0000002DA2B8: CC1A4006 1C1A1D22
	s_waitcnt vmcnt(9)                                         // 0000002DA2C0: BF8927F7
	v_dot2_f32_bf16 v39, v39, v35, v87                         // 0000002DA2C4: CC1A4027 1D5E4727
	v_dot2_f32_bf16 v8, v20, v12, v8                           // 0000002DA2CC: CC1A4008 1C221914
	s_waitcnt vmcnt(6)                                         // 0000002DA2D4: BF891BF7
	v_dot2_f32_bf16 v51, v51, v35, v90                         // 0000002DA2D8: CC1A4033 1D6A4733
	s_waitcnt vmcnt(5)                                         // 0000002DA2E0: BF8917F7
	v_dot2_f32_bf16 v6, v55, v35, v6                           // 0000002DA2E4: CC1A4006 1C1A4737
	v_dot2_f32_bf16 v8, v21, v13, v8                           // 0000002DA2EC: CC1A4008 1C221B15
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DA2F4: BF870112
	v_dot2_f32_bf16 v6, v56, v36, v6                           // 0000002DA2F8: CC1A4006 1C1A4938
	v_dot2_f32_bf16 v88, v22, v14, v8                          // 0000002DA300: CC1A4058 1C221D16
	v_dot2_f32_bf16 v8, v23, v11, v9                           // 0000002DA308: CC1A4008 1C261717
	global_load_b128 v[19:22], v[75:76], off offset:1536       // 0000002DA310: DC5E0600 137C004B
	v_dot2_f32_bf16 v6, v57, v37, v6                           // 0000002DA318: CC1A4006 1C1A4B39
	v_dot2_f32_bf16 v43, v43, v35, v88                         // 0000002DA320: CC1A402B 1D62472B
	v_dot2_f32_bf16 v8, v24, v12, v8                           // 0000002DA328: CC1A4008 1C221918
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DA330: BF870113
	v_dot2_f32_bf16 v6, v58, v38, v6                           // 0000002DA334: CC1A4006 1C1A4D3A
	v_dot2_f32_bf16 v8, v25, v13, v8                           // 0000002DA33C: CC1A4008 1C221B19
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DA344: BF870001
	v_dot2_f32_bf16 v89, v26, v14, v8                          // 0000002DA348: CC1A4059 1C221D1A
	s_clause 0x1                                               // 0000002DA350: BF850001
	global_load_b128 v[23:26], v[77:78], off offset:1024       // 0000002DA354: DC5E0400 177C004D
	global_load_b128 v[75:78], v[77:78], off offset:1536       // 0000002DA35C: DC5E0600 4B7C004D
	global_load_b128 v[7:10], v[79:80], off offset:1536        // 0000002DA364: DC5E0600 077C004F
	global_load_b128 v[27:30], v[81:82], off offset:1536       // 0000002DA36C: DC5E0600 1B7C0051
	global_load_b128 v[11:14], v[83:84], off offset:1536       // 0000002DA374: DC5E0600 0B7C0053
	global_load_b128 v[31:34], v[85:86], off offset:1536       // 0000002DA37C: DC5E0600 1F7C0055
	v_dot2_f32_bf16 v47, v47, v35, v89                         // 0000002DA384: CC1A402F 1D66472F
	v_dot2_f32_bf16 v35, v40, v36, v39                         // 0000002DA38C: CC1A4023 1C9E4928
	v_dot2_f32_bf16 v39, v44, v36, v43                         // 0000002DA394: CC1A4027 1CAE492C
	v_dot2_f32_bf16 v43, v52, v36, v51                         // 0000002DA39C: CC1A402B 1CCE4934
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA3A4: BF870214
	v_dot2_f32_bf16 v40, v48, v36, v47                         // 0000002DA3A8: CC1A4028 1CBE4930
	v_dot2_f32_bf16 v35, v41, v37, v35                         // 0000002DA3B0: CC1A4023 1C8E4B29
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002DA3B8: BF870194
	v_dot2_f32_bf16 v36, v45, v37, v39                         // 0000002DA3BC: CC1A4024 1C9E4B2D
	v_dot2_f32_bf16 v39, v49, v37, v40                         // 0000002DA3C4: CC1A4027 1CA24B31
	v_dot2_f32_bf16 v40, v53, v37, v43                         // 0000002DA3CC: CC1A4028 1CAE4B35
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA3D4: BF870214
	v_dot2_f32_bf16 v35, v42, v38, v35                         // 0000002DA3D8: CC1A4023 1C8E4D2A
	v_dot2_f32_bf16 v36, v46, v38, v36                         // 0000002DA3E0: CC1A4024 1C924D2E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA3E8: BF870214
	v_dot2_f32_bf16 v37, v50, v38, v39                         // 0000002DA3EC: CC1A4025 1C9E4D32
	v_dot2_f32_bf16 v39, v54, v38, v40                         // 0000002DA3F4: CC1A4027 1CA24D36
	s_waitcnt vmcnt(7)                                         // 0000002DA3FC: BF891FF7
	v_dot2_f32_bf16 v6, v71, v15, v6                           // 0000002DA400: CC1A4006 1C1A1F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002DA408: BF870091
	v_dot2_f32_bf16 v6, v72, v16, v6                           // 0000002DA40C: CC1A4006 1C1A2148
	v_dot2_f32_bf16 v6, v73, v17, v6                           // 0000002DA414: CC1A4006 1C1A2349
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002DA41C: BF870001
	v_dot2_f32_bf16 v6, v74, v18, v6                           // 0000002DA420: CC1A4006 1C1A254A
	s_waitcnt vmcnt(5)                                         // 0000002DA428: BF8917F7
	v_dot2_f32_bf16 v23, v23, v15, v35                         // 0000002DA42C: CC1A4017 1C8E1F17
	v_dot2_f32_bf16 v35, v59, v15, v36                         // 0000002DA434: CC1A4023 1C921F3B
	v_dot2_f32_bf16 v36, v63, v15, v37                         // 0000002DA43C: CC1A4024 1C961F3F
	v_dot2_f32_bf16 v37, v67, v15, v39                         // 0000002DA444: CC1A4025 1C9E1F43
	s_waitcnt vmcnt(0)                                         // 0000002DA44C: BF8903F7
	v_dot2_f32_bf16 v6, v31, v19, v6                           // 0000002DA450: CC1A4006 1C1A271F
	v_dot2_f32_bf16 v15, v24, v16, v23                         // 0000002DA458: CC1A400F 1C5E2118
	v_dot2_f32_bf16 v23, v60, v16, v35                         // 0000002DA460: CC1A4017 1C8E213C
	v_dot2_f32_bf16 v24, v64, v16, v36                         // 0000002DA468: CC1A4018 1C922140
	v_dot2_f32_bf16 v35, v68, v16, v37                         // 0000002DA470: CC1A4023 1C962144
	v_dot2_f32_bf16 v6, v32, v20, v6                           // 0000002DA478: CC1A4006 1C1A2920
	v_dot2_f32_bf16 v15, v25, v17, v15                         // 0000002DA480: CC1A400F 1C3E2319
	v_dot2_f32_bf16 v16, v61, v17, v23                         // 0000002DA488: CC1A4010 1C5E233D
	v_dot2_f32_bf16 v23, v65, v17, v24                         // 0000002DA490: CC1A4017 1C622341
	v_dot2_f32_bf16 v24, v69, v17, v35                         // 0000002DA498: CC1A4018 1C8E2345
	v_dot2_f32_bf16 v6, v33, v21, v6                           // 0000002DA4A0: CC1A4006 1C1A2B21
	v_dot2_f32_bf16 v15, v26, v18, v15                         // 0000002DA4A8: CC1A400F 1C3E251A
	v_dot2_f32_bf16 v16, v62, v18, v16                         // 0000002DA4B0: CC1A4010 1C42253E
	v_dot2_f32_bf16 v17, v66, v18, v23                         // 0000002DA4B8: CC1A4011 1C5E2542
	v_dot2_f32_bf16 v23, v70, v18, v24                         // 0000002DA4C0: CC1A4017 1C622546
	v_dot2_f32_bf16 v6, v34, v22, v6                           // 0000002DA4C8: CC1A4006 1C1A2D22
	v_dot2_f32_bf16 v15, v75, v19, v15                         // 0000002DA4D0: CC1A400F 1C3E274B
	v_dot2_f32_bf16 v7, v7, v19, v16                           // 0000002DA4D8: CC1A4007 1C422707
	v_dot2_f32_bf16 v16, v27, v19, v17                         // 0000002DA4E0: CC1A4010 1C46271B
	v_dot2_f32_bf16 v11, v11, v19, v23                         // 0000002DA4E8: CC1A400B 1C5E270B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA4F0: BF870214
	v_dot2_f32_bf16 v15, v76, v20, v15                         // 0000002DA4F4: CC1A400F 1C3E294C
	v_dot2_f32_bf16 v7, v8, v20, v7                            // 0000002DA4FC: CC1A4007 1C1E2908
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA504: BF870214
	v_dot2_f32_bf16 v8, v28, v20, v16                          // 0000002DA508: CC1A4008 1C42291C
	v_dot2_f32_bf16 v11, v12, v20, v11                         // 0000002DA510: CC1A400B 1C2E290C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA518: BF870214
	v_dot2_f32_bf16 v12, v77, v21, v15                         // 0000002DA51C: CC1A400C 1C3E2B4D
	v_dot2_f32_bf16 v7, v9, v21, v7                            // 0000002DA524: CC1A4007 1C1E2B09
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA52C: BF870214
	v_dot2_f32_bf16 v9, v29, v21, v8                           // 0000002DA530: CC1A4009 1C222B1D
	v_dot2_f32_bf16 v11, v13, v21, v11                         // 0000002DA538: CC1A400B 1C2E2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA540: BF870214
	v_dot2_f32_bf16 v8, v78, v22, v12                          // 0000002DA544: CC1A4008 1C322D4E
	v_dot2_f32_bf16 v10, v10, v22, v7                          // 0000002DA54C: CC1A400A 1C1E2D0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002DA554: BF870214
	v_dot2_f32_bf16 v9, v30, v22, v9                           // 0000002DA558: CC1A4009 1C262D1E
	v_dot2_f32_bf16 v7, v14, v22, v11                          // 0000002DA560: CC1A4007 1C2E2D0E
	s_cbranch_vccz 65249                                       // 0000002DA568: BFA3FEE1 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll+0xf0>
	s_branch 5                                                 // 0000002DA56C: BFA00005 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll+0x584>
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v7, 0               // 0000002DA570: CA100080 06060080
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v10, 0              // 0000002DA578: CA100080 090A0080
	v_mov_b32_e32 v8, 0                                        // 0000002DA580: 7E100280
	.long 0xd71f0003                                           // 0000002DA584: D71F0003
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002DA588: 020100C1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002DA58C: BF870121
	v_xor_b32_e32 v4, 16, v3                                   // 0000002DA590: 3A080690
	v_xor_b32_e32 v14, 8, v3                                   // 0000002DA594: 3A1C0688
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 0000002DA598: 7C9808A0
	v_cndmask_b32_e32 v4, v3, v4, vcc_lo                       // 0000002DA59C: 02080903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002DA5A0: BF870113
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DA5A4: 7C981CA0
	v_lshlrev_b32_e32 v4, 2, v4                                // 0000002DA5A8: 30080882
	ds_bpermute_b32 v13, v4, v7                                // 0000002DA5AC: DACC0000 0D000704
	s_waitcnt lgkmcnt(0)                                       // 0000002DA5B4: BF89FC07
	v_add_f32_e32 v7, v7, v13                                  // 0000002DA5B8: 060E1B07
	ds_bpermute_b32 v12, v4, v9                                // 0000002DA5BC: DACC0000 0C000904
	v_cndmask_b32_e32 v14, v3, v14, vcc_lo                     // 0000002DA5C4: 021C1D03
	ds_bpermute_b32 v5, v4, v8                                 // 0000002DA5C8: DACC0000 05000804
	ds_bpermute_b32 v11, v4, v10                               // 0000002DA5D0: DACC0000 0B000A04
	ds_bpermute_b32 v4, v4, v6                                 // 0000002DA5D8: DACC0000 04000604
	s_waitcnt lgkmcnt(3)                                       // 0000002DA5E0: BF89FC37
	v_dual_add_f32 v9, v9, v12 :: v_dual_lshlrev_b32 v14, 2, v14// 0000002DA5E4: C9221909 090E1C82
	s_waitcnt lgkmcnt(0)                                       // 0000002DA5EC: BF89FC07
	v_dual_add_f32 v5, v8, v5 :: v_dual_add_f32 v4, v6, v4     // 0000002DA5F0: C9080B08 05040906
	ds_bpermute_b32 v12, v14, v7                               // 0000002DA5F8: DACC0000 0C00070E
	s_waitcnt lgkmcnt(0)                                       // 0000002DA600: BF89FC07
	v_add_f32_e32 v7, v7, v12                                  // 0000002DA604: 060E1907
	ds_bpermute_b32 v6, v14, v5                                // 0000002DA608: DACC0000 0600050E
	v_add_f32_e32 v8, v10, v11                                 // 0000002DA610: 0610170A
	ds_bpermute_b32 v11, v14, v9                               // 0000002DA614: DACC0000 0B00090E
	ds_bpermute_b32 v13, v14, v4                               // 0000002DA61C: DACC0000 0D00040E
	s_waitcnt lgkmcnt(2)                                       // 0000002DA624: BF89FC27
	v_add_f32_e32 v5, v5, v6                                   // 0000002DA628: 060A0D05
	ds_bpermute_b32 v10, v14, v8                               // 0000002DA62C: DACC0000 0A00080E
	v_xor_b32_e32 v14, 4, v3                                   // 0000002DA634: 3A1C0684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002DA638: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DA63C: 7C981CA0
	v_cndmask_b32_e32 v14, v3, v14, vcc_lo                     // 0000002DA640: 021C1D03
	v_lshlrev_b32_e32 v14, 2, v14                              // 0000002DA644: 301C1C82
	s_waitcnt lgkmcnt(0)                                       // 0000002DA648: BF89FC07
	v_add_f32_e32 v6, v8, v10                                  // 0000002DA64C: 060C1508
	ds_bpermute_b32 v12, v14, v7                               // 0000002DA650: DACC0000 0C00070E
	s_waitcnt lgkmcnt(0)                                       // 0000002DA658: BF89FC07
	v_dual_add_f32 v8, v9, v11 :: v_dual_add_f32 v7, v7, v12   // 0000002DA65C: C9081709 08061907
	ds_bpermute_b32 v9, v14, v5                                // 0000002DA664: DACC0000 0900050E
	ds_bpermute_b32 v11, v14, v8                               // 0000002DA66C: DACC0000 0B00080E
	ds_bpermute_b32 v10, v14, v6                               // 0000002DA674: DACC0000 0A00060E
	s_waitcnt lgkmcnt(2)                                       // 0000002DA67C: BF89FC27
	v_add_f32_e32 v5, v5, v9                                   // 0000002DA680: 060A1305
	v_add_f32_e32 v4, v4, v13                                  // 0000002DA684: 06081B04
	s_waitcnt lgkmcnt(1)                                       // 0000002DA688: BF89FC17
	v_add_f32_e32 v8, v8, v11                                  // 0000002DA68C: 06101708
	v_xor_b32_e32 v9, 1, v3                                    // 0000002DA690: 3A120681
	ds_bpermute_b32 v13, v14, v4                               // 0000002DA694: DACC0000 0D00040E
	v_xor_b32_e32 v14, 2, v3                                   // 0000002DA69C: 3A1C0682
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000002DA6A0: BF870131
	v_cmp_gt_u32_e32 vcc_lo, 32, v14                           // 0000002DA6A4: 7C981CA0
	v_cndmask_b32_e32 v14, v3, v14, vcc_lo                     // 0000002DA6A8: 021C1D03
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002DA6AC: 7C9812A0
	v_dual_cndmask_b32 v3, v3, v9 :: v_dual_lshlrev_b32 v14, 2, v14// 0000002DA6B0: CA621303 030E1C82
	s_waitcnt lgkmcnt(1)                                       // 0000002DA6B8: BF89FC17
	v_add_f32_e32 v6, v6, v10                                  // 0000002DA6BC: 060C1506
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 0000002DA6C0: 7C940080
	ds_bpermute_b32 v12, v14, v8                               // 0000002DA6C4: DACC0000 0C00080E
	v_lshlrev_b32_e32 v15, 2, v3                               // 0000002DA6CC: 301E0682
	s_waitcnt lgkmcnt(1)                                       // 0000002DA6D0: BF89FC17
	v_add_f32_e32 v11, v4, v13                                 // 0000002DA6D4: 06161B04
	s_waitcnt lgkmcnt(0)                                       // 0000002DA6D8: BF89FC07
	v_add_f32_e32 v3, v8, v12                                  // 0000002DA6DC: 06061908
	ds_bpermute_b32 v4, v14, v5                                // 0000002DA6E0: DACC0000 0400050E
	ds_bpermute_b32 v10, v14, v6                               // 0000002DA6E8: DACC0000 0A00060E
	ds_bpermute_b32 v13, v14, v7                               // 0000002DA6F0: DACC0000 0D00070E
	ds_bpermute_b32 v14, v14, v11                              // 0000002DA6F8: DACC0000 0E000B0E
	s_waitcnt lgkmcnt(2)                                       // 0000002DA700: BF89FC27
	v_dual_add_f32 v9, v5, v4 :: v_dual_add_f32 v10, v6, v10   // 0000002DA704: C9080905 090A1506
	s_waitcnt lgkmcnt(1)                                       // 0000002DA70C: BF89FC17
	v_add_f32_e32 v4, v7, v13                                  // 0000002DA710: 06081B07
	s_waitcnt lgkmcnt(0)                                       // 0000002DA714: BF89FC07
	v_add_f32_e32 v7, v11, v14                                 // 0000002DA718: 060E1D0B
	ds_bpermute_b32 v5, v15, v3                                // 0000002DA71C: DACC0000 0500030F
	ds_bpermute_b32 v11, v15, v9                               // 0000002DA724: DACC0000 0B00090F
	ds_bpermute_b32 v12, v15, v10                              // 0000002DA72C: DACC0000 0C000A0F
	ds_bpermute_b32 v6, v15, v4                                // 0000002DA734: DACC0000 0600040F
	ds_bpermute_b32 v8, v15, v7                                // 0000002DA73C: DACC0000 0800070F
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 0000002DA744: 8B7E6A7E
	s_cbranch_execz 73                                         // 0000002DA748: BFA50049 <_ZN7halogen12_GLOBAL__N_16k_lbfwILi5ELi4EEEvPKtS3_Ptll+0x870>
	s_waitcnt lgkmcnt(2)                                       // 0000002DA74C: BF89FC27
	v_dual_add_f32 v10, v10, v12 :: v_dual_add_f32 v9, v9, v11 // 0000002DA750: C908190A 0A081709
	.long 0x7f163880                                           // 0000002DA758: 7F163880
	.long 0xd73c0000                                           // 0000002DA75C: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000002DA760: 02020281
	s_lshl_b64 s[0:1], s[8:9], 1                               // 0000002DA764: 84808108
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002DA768: BF870003
	.long 0x7e16398a                                           // 0000002DA76C: 7E16398A
	.long 0x7e183989                                           // 0000002DA770: 7E183989
	.long 0x7f18398b                                           // 0000002DA774: 7F18398B
	s_waitcnt lgkmcnt(0)                                       // 0000002DA778: BF89FC07
	v_add_f32_e32 v13, v7, v8                                  // 0000002DA77C: 061A1107
	.long 0xd7006a07                                           // 0000002DA780: D7006A07
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000002DA784: 02020004
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000002DA788: BF8701B3
	v_dual_add_f32 v15, v3, v5 :: v_dual_and_b32 v12, 1, v12   // 0000002DA78C: C9240B03 0F0C1881
	.long 0x7f00398b                                           // 0000002DA794: 7F00398B
	v_add_co_ci_u32_e64 v8, null, s5, v1, vcc_lo               // 0000002DA798: D5207C08 01AA0205
	.long 0x7e00398f                                           // 0000002DA7A0: 7E00398F
	v_add_f32_e32 v14, v4, v6                                  // 0000002DA7A4: 061C0D04
	v_and_b32_e32 v2, 1, v11                                   // 0000002DA7A8: 36041681
	v_add3_u32 v12, v9, v12, 0x7fff                            // 0000002DA7AC: D655000C 03FE1909 00007FFF
	.long 0xd7006a03                                           // 0000002DA7B8: D7006A03
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DA7BC: 02000107
	v_and_b32_e32 v9, 1, v0                                    // 0000002DA7C0: 36120081
	.long 0x7e16398e                                           // 0000002DA7C4: 7E16398E
	v_mad_u64_u32 v[0:1], null, s8, 6, v[7:8]                  // 0000002DA7C8: D6FE7C00 041D0C08
	v_add3_u32 v16, v10, v2, 0x7fff                            // 0000002DA7D0: D6550010 03FE050A 00007FFF
	v_add_co_ci_u32_e64 v4, null, s1, v8, vcc_lo               // 0000002DA7DC: D5207C04 01AA1001
	s_lshl_b64 s[0:1], s[8:9], 2                               // 0000002DA7E4: 84808208
	v_and_b32_e32 v2, 1, v11                                   // 0000002DA7E8: 36041681
	.long 0xd7006a05                                           // 0000002DA7EC: D7006A05
	v_cndmask_b32_e32 v0, v7, v0, vcc_lo                       // 0000002DA7F0: 02000107
	v_bfe_u32 v10, v13, 16, 1                                  // 0000002DA7F4: D610000A 0205210D
	v_add_co_ci_u32_e64 v6, null, s1, v8, vcc_lo               // 0000002DA7FC: D5207C06 01AA1001
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002DA804: BF870004
	v_add3_u32 v11, v14, v2, 0x7fff                            // 0000002DA808: D655000B 03FE050E 00007FFF
	v_mad_u64_u32 v[1:2], null, s9, 6, v[1:2]                  // 0000002DA814: D6FE7C01 04050C09
	v_add3_u32 v14, v15, v9, 0x7fff                            // 0000002DA81C: D655000E 03FE130F 00007FFF
	.long 0xd7006a09                                           // 0000002DA828: D7006A09
	v_cndmask_b32_e32 v0, v5, v0, vcc_lo                       // 0000002DA82C: 02000105
	v_add3_u32 v2, v13, v10, 0x7fff                            // 0000002DA830: D6550002 03FE150D 00007FFF
	v_add_co_ci_u32_e64 v10, null, s1, v6, vcc_lo              // 0000002DA83C: D5207C0A 01AA0C01
	s_clause 0x4                                               // 0000002DA844: BF850004
	global_store_d16_hi_b16 v[7:8], v12, off                   // 0000002DA848: DC960000 007C0C07
	global_store_d16_hi_b16 v[3:4], v16, off                   // 0000002DA850: DC960000 007C1003
	global_store_d16_hi_b16 v[5:6], v14, off                   // 0000002DA858: DC960000 007C0E05
	global_store_d16_hi_b16 v[0:1], v11, off                   // 0000002DA860: DC960000 007C0B00
	global_store_d16_hi_b16 v[9:10], v2, off                   // 0000002DA868: DC960000 007C0209
	s_endpgm                                                   // 0000002DA870: BFB00000
		...

