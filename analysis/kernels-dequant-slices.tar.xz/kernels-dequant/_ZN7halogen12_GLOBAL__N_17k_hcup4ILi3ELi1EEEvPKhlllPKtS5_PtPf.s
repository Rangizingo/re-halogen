00000000002cf700 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf>:
; _ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf():
	s_load_b128 s[12:15], s[0:1], null                         // 0000002CF700: F4080300 F8000000
	v_and_b32_e32 v2, 15, v0                                   // 0000002CF708: 3604008F
	v_lshrrev_b32_e32 v1, 4, v0                                // 0000002CF70C: 32020084
	s_load_b256 s[4:11], s[0:1], 0x20                          // 0000002CF710: F40C0100 F8000020
	s_mov_b32 s3, exec_lo                                      // 0000002CF718: BE83007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CF71C: BF870112
	v_lshlrev_b32_e32 v3, 2, v2                                // 0000002CF720: 30060482
	v_lshlrev_b32_e32 v4, 2, v1                                // 0000002CF724: 30080282
	s_waitcnt lgkmcnt(0)                                       // 0000002CF728: BF89FC07
	s_clause 0x1                                               // 0000002CF72C: BF850001
	global_load_b32 v3, v3, s[12:13]                           // 0000002CF730: DC520000 030C0003
	global_load_b32 v4, v4, s[12:13]                           // 0000002CF738: DC520000 040C0004
	s_waitcnt vmcnt(1)                                         // 0000002CF740: BF8907F7
	v_bfe_u32 v5, v3, 16, 1                                    // 0000002CF744: D6100005 02052103
	s_waitcnt vmcnt(0)                                         // 0000002CF74C: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000002CF750: D6100006 02052104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CF758: BF8701A2
	v_add3_u32 v3, v3, v5, 0x7fff                              // 0000002CF75C: D6550003 03FE0B03 00007FFF
	.long 0x7f0a3880                                           // 0000002CF768: 7F0A3880
	v_add3_u32 v4, v4, v6, 0x7fff                              // 0000002CF76C: D6550004 03FE0D04 00007FFF
	v_lshlrev_b32_e32 v6, 2, v0                                // 0000002CF778: 300C0082
	v_mov_b32_e32 v0, 0                                        // 0000002CF77C: 7E000280
	.long 0x7e0a3983                                           // 0000002CF780: 7E0A3983
	v_mov_b32_e32 v3, 0                                        // 0000002CF784: 7E060280
	s_delay_alu instid0(VALU_DEP_2)                            // 0000002CF788: BF870002
	v_and_or_b32 v5, 0xffff0000, v4, v5                        // 0000002CF78C: D6570005 041608FF FFFF0000
	v_mov_b32_e32 v4, 0                                        // 0000002CF798: 7E080280
	ds_store_b32 v6, v5                                        // 0000002CF79C: D8340000 00000506
	s_waitcnt lgkmcnt(0)                                       // 0000002CF7A4: BF89FC07
	s_barrier                                                  // 0000002CF7A8: BFBD0000
	buffer_gl0_inv                                             // 0000002CF7AC: E0AC0000 00000000
	v_cmpx_gt_u32_e32 10, v2                                   // 0000002CF7B4: 7D98048A
	s_cbranch_execz 257                                        // 0000002CF7B8: BFA50101 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf+0x4c0>
	v_lshlrev_b32_e32 v0, 4, v2                                // 0000002CF7BC: 30000484
	s_add_u32 s14, s12, s14                                    // 0000002CF7C0: 800E0E0C
	s_addc_u32 s15, s13, s15                                   // 0000002CF7C4: 820F0F0D
	s_load_b64 s[0:1], s[0:1], 0x10                            // 0000002CF7C8: F4040000 F8000010
	global_load_b128 v[3:6], v0, s[14:15]                      // 0000002CF7D0: DC5E0000 030E0000
	v_lshlrev_b32_e32 v0, 6, v2                                // 0000002CF7D8: 30000486
	s_clause 0xb                                               // 0000002CF7DC: BF85000B
	global_load_b128 v[7:10], v0, s[4:5]                       // 0000002CF7E0: DC5E0000 07040000
	global_load_b128 v[11:14], v0, s[4:5] offset:640           // 0000002CF7E8: DC5E0280 0B040000
	global_load_b128 v[15:18], v0, s[4:5] offset:1280          // 0000002CF7F0: DC5E0500 0F040000
	global_load_b128 v[19:22], v0, s[4:5] offset:16            // 0000002CF7F8: DC5E0010 13040000
	global_load_b128 v[23:26], v0, s[4:5] offset:656           // 0000002CF800: DC5E0290 17040000
	global_load_b128 v[27:30], v0, s[4:5] offset:1296          // 0000002CF808: DC5E0510 1B040000
	global_load_b128 v[31:34], v0, s[4:5] offset:32            // 0000002CF810: DC5E0020 1F040000
	global_load_b128 v[35:38], v0, s[4:5] offset:672           // 0000002CF818: DC5E02A0 23040000
	global_load_b128 v[39:42], v0, s[4:5] offset:1312          // 0000002CF820: DC5E0520 27040000
	global_load_b128 v[43:46], v0, s[4:5] offset:48            // 0000002CF828: DC5E0030 2B040000
	global_load_b128 v[47:50], v0, s[4:5] offset:688           // 0000002CF830: DC5E02B0 2F040000
	global_load_b128 v[51:54], v0, s[4:5] offset:1328          // 0000002CF838: DC5E0530 33040000
	v_lshlrev_b32_e32 v0, 1, v2                                // 0000002CF840: 30000481
	s_waitcnt lgkmcnt(0)                                       // 0000002CF844: BF89FC07
	s_add_u32 s0, s12, s0                                      // 0000002CF848: 8000000C
	s_addc_u32 s1, s13, s1                                     // 0000002CF84C: 8201010D
	global_load_d16_b16 v55, v0, s[0:1]                        // 0000002CF850: DC820000 37000000
	s_waitcnt vmcnt(13)                                        // 0000002CF858: BF8937F7
	v_and_b32_e32 v0, 0xff, v3                                 // 0000002CF85C: 360006FF 000000FF
	v_lshrrev_b32_e32 v56, 6, v3                               // 0000002CF864: 32700686
	v_lshrrev_b32_e32 v57, 14, v3                              // 0000002CF868: 3272068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 0000002CF86C: 32060696
	v_and_b32_e32 v58, 0xff, v4                                // 0000002CF870: 367408FF 000000FF
	v_lshlrev_b32_e32 v0, 2, v0                                // 0000002CF878: 30000082
	v_and_b32_e32 v56, 0x3fc, v56                              // 0000002CF87C: 367070FF 000003FC
	v_and_b32_e32 v57, 0x3fc, v57                              // 0000002CF884: 367272FF 000003FC
	v_lshrrev_b32_e32 v59, 6, v4                               // 0000002CF88C: 32760886
	v_lshrrev_b32_e32 v60, 14, v4                              // 0000002CF890: 3278088E
	ds_load_b32 v0, v0                                         // 0000002CF894: D8D80000 00000000
	ds_load_b32 v56, v56                                       // 0000002CF89C: D8D80000 38000038
	ds_load_b32 v57, v57                                       // 0000002CF8A4: D8D80000 39000039
	v_lshrrev_b32_e32 v4, 22, v4                               // 0000002CF8AC: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 0000002CF8B0: 360606FF 000003FC
	v_lshlrev_b32_e32 v58, 2, v58                              // 0000002CF8B8: 30747482
	v_and_b32_e32 v59, 0x3fc, v59                              // 0000002CF8BC: 367676FF 000003FC
	v_and_b32_e32 v60, 0x3fc, v60                              // 0000002CF8C4: 367878FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 0000002CF8CC: 360808FF 000003FC
	ds_load_b32 v3, v3                                         // 0000002CF8D4: D8D80000 03000003
	ds_load_b32 v58, v58                                       // 0000002CF8DC: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 0000002CF8E4: D8D80000 3B00003B
	ds_load_b32 v60, v60                                       // 0000002CF8EC: D8D80000 3C00003C
	ds_load_b32 v4, v4                                         // 0000002CF8F4: D8D80000 04000004
	v_and_b32_e32 v61, 0xff, v5                                // 0000002CF8FC: 367A0AFF 000000FF
	v_lshrrev_b32_e32 v62, 6, v5                               // 0000002CF904: 327C0A86
	v_lshrrev_b32_e32 v63, 14, v5                              // 0000002CF908: 327E0A8E
	v_lshrrev_b32_e32 v5, 22, v5                               // 0000002CF90C: 320A0A96
	v_and_b32_e32 v64, 0xff, v6                                // 0000002CF910: 36800CFF 000000FF
	v_lshrrev_b32_e32 v65, 14, v6                              // 0000002CF918: 32820C8E
	s_waitcnt vmcnt(12) lgkmcnt(7)                             // 0000002CF91C: BF893077
	v_dot2_f32_bf16 v7, v7, v0, 0                              // 0000002CF920: CC1A4007 1A020107
	s_waitcnt vmcnt(11)                                        // 0000002CF928: BF892FF7
	v_dot2_f32_bf16 v11, v11, v0, 0                            // 0000002CF92C: CC1A400B 1A02010B
	s_waitcnt vmcnt(10)                                        // 0000002CF934: BF892BF7
	v_dot2_f32_bf16 v0, v15, v0, 0                             // 0000002CF938: CC1A4000 1A02010F
	v_lshrrev_b32_e32 v15, 6, v6                               // 0000002CF940: 321E0C86
	v_lshrrev_b32_e32 v6, 22, v6                               // 0000002CF944: 320C0C96
	s_waitcnt lgkmcnt(6)                                       // 0000002CF948: BF89FC67
	v_dot2_f32_bf16 v7, v8, v56, v7                            // 0000002CF94C: CC1A4007 1C1E7108
	v_dot2_f32_bf16 v8, v12, v56, v11                          // 0000002CF954: CC1A4008 1C2E710C
	v_dot2_f32_bf16 v0, v16, v56, v0                           // 0000002CF95C: CC1A4000 1C027110
	v_lshlrev_b32_e32 v11, 2, v61                              // 0000002CF964: 30167A82
	v_and_b32_e32 v12, 0x3fc, v63                              // 0000002CF968: 36187EFF 000003FC
	s_waitcnt lgkmcnt(5)                                       // 0000002CF970: BF89FC57
	v_dot2_f32_bf16 v7, v9, v57, v7                            // 0000002CF974: CC1A4007 1C1E7309
	v_dot2_f32_bf16 v8, v13, v57, v8                           // 0000002CF97C: CC1A4008 1C22730D
	v_dot2_f32_bf16 v0, v17, v57, v0                           // 0000002CF984: CC1A4000 1C027311
	v_and_b32_e32 v9, 0x3fc, v62                               // 0000002CF98C: 36127CFF 000003FC
	v_and_b32_e32 v13, 0x3fc, v65                              // 0000002CF994: 361A82FF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000002CF99C: BF89FC47
	v_dot2_f32_bf16 v7, v10, v3, v7                            // 0000002CF9A0: CC1A4007 1C1E070A
	v_dot2_f32_bf16 v8, v14, v3, v8                            // 0000002CF9A8: CC1A4008 1C22070E
	v_dot2_f32_bf16 v0, v18, v3, v0                            // 0000002CF9B0: CC1A4000 1C020712
	ds_load_b32 v10, v11                                       // 0000002CF9B8: D8D80000 0A00000B
	ds_load_b32 v12, v12                                       // 0000002CF9C0: D8D80000 0C00000C
	ds_load_b32 v9, v9                                         // 0000002CF9C8: D8D80000 09000009
	s_waitcnt vmcnt(9) lgkmcnt(6)                              // 0000002CF9D0: BF892467
	v_dot2_f32_bf16 v7, v19, v58, v7                           // 0000002CF9D4: CC1A4007 1C1E7513
	s_waitcnt vmcnt(8)                                         // 0000002CF9DC: BF8923F7
	v_dot2_f32_bf16 v8, v23, v58, v8                           // 0000002CF9E0: CC1A4008 1C227517
	s_waitcnt vmcnt(7)                                         // 0000002CF9E8: BF891FF7
	v_dot2_f32_bf16 v0, v27, v58, v0                           // 0000002CF9EC: CC1A4000 1C02751B
	v_and_b32_e32 v3, 0x3fc, v5                                // 0000002CF9F4: 36060AFF 000003FC
	v_lshlrev_b32_e32 v5, 2, v64                               // 0000002CF9FC: 300A8082
	s_waitcnt lgkmcnt(5)                                       // 0000002CFA00: BF89FC57
	v_dot2_f32_bf16 v7, v20, v59, v7                           // 0000002CFA04: CC1A4007 1C1E7714
	v_dot2_f32_bf16 v8, v24, v59, v8                           // 0000002CFA0C: CC1A4008 1C227718
	v_dot2_f32_bf16 v0, v28, v59, v0                           // 0000002CFA14: CC1A4000 1C02771C
	v_and_b32_e32 v11, 0x3fc, v15                              // 0000002CFA1C: 36161EFF 000003FC
	v_and_b32_e32 v6, 0x3fc, v6                                // 0000002CFA24: 360C0CFF 000003FC
	s_waitcnt lgkmcnt(4)                                       // 0000002CFA2C: BF89FC47
	v_dot2_f32_bf16 v7, v21, v60, v7                           // 0000002CFA30: CC1A4007 1C1E7915
	v_dot2_f32_bf16 v8, v25, v60, v8                           // 0000002CFA38: CC1A4008 1C227919
	v_dot2_f32_bf16 v0, v29, v60, v0                           // 0000002CFA40: CC1A4000 1C02791D
	s_waitcnt lgkmcnt(3)                                       // 0000002CFA48: BF89FC37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFA4C: BF870193
	v_dot2_f32_bf16 v7, v22, v4, v7                            // 0000002CFA50: CC1A4007 1C1E0916
	v_dot2_f32_bf16 v8, v26, v4, v8                            // 0000002CFA58: CC1A4008 1C22091A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000002CFA60: BF870003
	v_dot2_f32_bf16 v0, v30, v4, v0                            // 0000002CFA64: CC1A4000 1C02091E
	ds_load_b32 v3, v3                                         // 0000002CFA6C: D8D80000 03000003
	ds_load_b32 v4, v5                                         // 0000002CFA74: D8D80000 04000005
	ds_load_b32 v5, v11                                        // 0000002CFA7C: D8D80000 0500000B
	ds_load_b32 v11, v13                                       // 0000002CFA84: D8D80000 0B00000D
	ds_load_b32 v6, v6                                         // 0000002CFA8C: D8D80000 06000006
	s_waitcnt vmcnt(6) lgkmcnt(7)                              // 0000002CFA94: BF891877
	v_dot2_f32_bf16 v7, v31, v10, v7                           // 0000002CFA98: CC1A4007 1C1E151F
	s_waitcnt vmcnt(5)                                         // 0000002CFAA0: BF8917F7
	v_dot2_f32_bf16 v8, v35, v10, v8                           // 0000002CFAA4: CC1A4008 1C221523
	s_waitcnt vmcnt(4)                                         // 0000002CFAAC: BF8913F7
	v_dot2_f32_bf16 v0, v39, v10, v0                           // 0000002CFAB0: CC1A4000 1C021527
	s_waitcnt lgkmcnt(5)                                       // 0000002CFAB8: BF89FC57
	v_dot2_f32_bf16 v7, v32, v9, v7                            // 0000002CFABC: CC1A4007 1C1E1320
	v_dot2_f32_bf16 v8, v36, v9, v8                            // 0000002CFAC4: CC1A4008 1C221324
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFACC: BF870193
	v_dot2_f32_bf16 v0, v40, v9, v0                            // 0000002CFAD0: CC1A4000 1C021328
	v_dot2_f32_bf16 v7, v33, v12, v7                           // 0000002CFAD8: CC1A4007 1C1E1921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFAE0: BF870193
	v_dot2_f32_bf16 v8, v37, v12, v8                           // 0000002CFAE4: CC1A4008 1C221925
	v_dot2_f32_bf16 v0, v41, v12, v0                           // 0000002CFAEC: CC1A4000 1C021929
	s_waitcnt lgkmcnt(4)                                       // 0000002CFAF4: BF89FC47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFAF8: BF870193
	v_dot2_f32_bf16 v7, v34, v3, v7                            // 0000002CFAFC: CC1A4007 1C1E0722
	v_dot2_f32_bf16 v8, v38, v3, v8                            // 0000002CFB04: CC1A4008 1C220726
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CFB0C: BF8701A3
	v_dot2_f32_bf16 v0, v42, v3, v0                            // 0000002CFB10: CC1A4000 1C02072A
	s_waitcnt vmcnt(3) lgkmcnt(3)                              // 0000002CFB18: BF890C37
	v_dot2_f32_bf16 v3, v43, v4, v7                            // 0000002CFB1C: CC1A4003 1C1E092B
	s_waitcnt vmcnt(2)                                         // 0000002CFB24: BF890BF7
	v_dot2_f32_bf16 v7, v47, v4, v8                            // 0000002CFB28: CC1A4007 1C22092F
	s_waitcnt vmcnt(1)                                         // 0000002CFB30: BF8907F7
	v_dot2_f32_bf16 v0, v51, v4, v0                            // 0000002CFB34: CC1A4000 1C020933
	s_waitcnt lgkmcnt(2)                                       // 0000002CFB3C: BF89FC27
	v_dot2_f32_bf16 v3, v44, v5, v3                            // 0000002CFB40: CC1A4003 1C0E0B2C
	v_dot2_f32_bf16 v4, v48, v5, v7                            // 0000002CFB48: CC1A4004 1C1E0B30
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CFB50: BF8701A3
	v_dot2_f32_bf16 v0, v52, v5, v0                            // 0000002CFB54: CC1A4000 1C020B34
	s_waitcnt lgkmcnt(1)                                       // 0000002CFB5C: BF89FC17
	v_dot2_f32_bf16 v3, v45, v11, v3                           // 0000002CFB60: CC1A4003 1C0E172D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFB68: BF870193
	v_dot2_f32_bf16 v4, v49, v11, v4                           // 0000002CFB6C: CC1A4004 1C121731
	v_dot2_f32_bf16 v0, v53, v11, v0                           // 0000002CFB74: CC1A4000 1C021735
	s_waitcnt lgkmcnt(0)                                       // 0000002CFB7C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFB80: BF870193
	v_dot2_f32_bf16 v3, v46, v6, v3                            // 0000002CFB84: CC1A4003 1C0E0D2E
	v_dot2_f32_bf16 v4, v50, v6, v4                            // 0000002CFB8C: CC1A4004 1C120D32
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002CFB94: BF8701A3
	v_dot2_f32_bf16 v5, v54, v6, v0                            // 0000002CFB98: CC1A4005 1C020D36
	s_waitcnt vmcnt(0)                                         // 0000002CFBA0: BF8903F7
	v_fma_mix_f32 v0, v55, v3, 0 op_sel_hi:[1,0,0]             // 0000002CFBA4: CC200000 0A020737
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002CFBAC: BF870193
	v_fma_mix_f32 v3, v55, v4, 0 op_sel_hi:[1,0,0]             // 0000002CFBB0: CC200003 0A020937
	v_fma_mix_f32 v4, v55, v5, 0 op_sel_hi:[1,0,0]             // 0000002CFBB8: CC200004 0A020B37
	s_or_b32 exec_lo, exec_lo, s3                              // 0000002CFBC0: 8C7E037E
	.long 0xd71f0005                                           // 0000002CFBC4: D71F0005
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 0000002CFBC8: 020100C1
	s_mov_b32 s0, exec_lo                                      // 0000002CFBCC: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CFBD0: BF870121
	v_xor_b32_e32 v6, 8, v5                                    // 0000002CFBD4: 3A0C0A88
	v_xor_b32_e32 v9, 4, v5                                    // 0000002CFBD8: 3A120A84
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 0000002CFBDC: 7C980CA0
	v_cndmask_b32_e32 v6, v5, v6, vcc_lo                       // 0000002CFBE0: 020C0D05
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CFBE4: BF8700A3
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002CFBE8: 7C9812A0
	v_cndmask_b32_e32 v9, v5, v9, vcc_lo                       // 0000002CFBEC: 02121305
	v_lshlrev_b32_e32 v9, 2, v9                                // 0000002CFBF0: 30121282
	s_delay_alu instid0(VALU_DEP_4)                            // 0000002CFBF4: BF870004
	v_lshlrev_b32_e32 v6, 2, v6                                // 0000002CFBF8: 300C0C82
	ds_bpermute_b32 v8, v6, v3                                 // 0000002CFBFC: DACC0000 08000306
	s_waitcnt lgkmcnt(0)                                       // 0000002CFC04: BF89FC07
	v_add_f32_e32 v3, v3, v8                                   // 0000002CFC08: 06061103
	ds_bpermute_b32 v7, v6, v0                                 // 0000002CFC0C: DACC0000 07000006
	ds_bpermute_b32 v6, v6, v4                                 // 0000002CFC14: DACC0000 06000406
	s_waitcnt lgkmcnt(1)                                       // 0000002CFC1C: BF89FC17
	v_add_f32_e32 v0, v0, v7                                   // 0000002CFC20: 06000F00
	s_waitcnt lgkmcnt(0)                                       // 0000002CFC24: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 0000002CFC28: 06080D04
	ds_bpermute_b32 v7, v9, v3                                 // 0000002CFC2C: DACC0000 07000309
	ds_bpermute_b32 v6, v9, v0                                 // 0000002CFC34: DACC0000 06000009
	ds_bpermute_b32 v8, v9, v4                                 // 0000002CFC3C: DACC0000 08000409
	v_xor_b32_e32 v9, 2, v5                                    // 0000002CFC44: 3A120A82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002CFC48: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v9                            // 0000002CFC4C: 7C9812A0
	v_cndmask_b32_e32 v9, v5, v9, vcc_lo                       // 0000002CFC50: 02121305
	s_waitcnt lgkmcnt(1)                                       // 0000002CFC54: BF89FC17
	v_dual_add_f32 v0, v0, v6 :: v_dual_lshlrev_b32 v9, 2, v9  // 0000002CFC58: C9220D00 00081282
	s_waitcnt lgkmcnt(0)                                       // 0000002CFC60: BF89FC07
	v_add_f32_e32 v4, v4, v8                                   // 0000002CFC64: 06081104
	v_xor_b32_e32 v8, 1, v5                                    // 0000002CFC68: 3A100A81
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CFC6C: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v8                            // 0000002CFC70: 7C9810A0
	v_add_f32_e32 v6, v3, v7                                   // 0000002CFC74: 060C0F03
	ds_bpermute_b32 v3, v9, v0                                 // 0000002CFC78: DACC0000 03000009
	v_cndmask_b32_e32 v5, v5, v8, vcc_lo                       // 0000002CFC80: 020A1105
	ds_bpermute_b32 v7, v9, v6                                 // 0000002CFC84: DACC0000 07000609
	v_lshlrev_b32_e32 v5, 2, v5                                // 0000002CFC8C: 300A0A82
	ds_bpermute_b32 v9, v9, v4                                 // 0000002CFC90: DACC0000 09000409
	s_waitcnt lgkmcnt(2)                                       // 0000002CFC98: BF89FC27
	v_add_f32_e32 v3, v0, v3                                   // 0000002CFC9C: 06060700
	s_waitcnt lgkmcnt(1)                                       // 0000002CFCA0: BF89FC17
	v_add_f32_e32 v8, v6, v7                                   // 0000002CFCA4: 06100F06
	s_waitcnt lgkmcnt(0)                                       // 0000002CFCA8: BF89FC07
	v_add_f32_e32 v6, v4, v9                                   // 0000002CFCAC: 060C1304
	ds_bpermute_b32 v4, v5, v3                                 // 0000002CFCB0: DACC0000 04000305
	ds_bpermute_b32 v9, v5, v8                                 // 0000002CFCB8: DACC0000 09000805
	ds_bpermute_b32 v7, v5, v6                                 // 0000002CFCC0: DACC0000 07000605
	v_cmpx_eq_u32_e32 0, v2                                    // 0000002CFCC8: 7D940480
	s_cbranch_execz 405                                        // 0000002CFCCC: BFA50195 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf+0xc24>
	s_waitcnt lgkmcnt(2)                                       // 0000002CFCD0: BF89FC27
	v_dual_add_f32 v3, v3, v4 :: v_dual_and_b32 v0, 14, v1     // 0000002CFCD4: C9240903 0300028E
	v_and_b32_e32 v1, 1, v1                                    // 0000002CFCDC: 36020281
	s_lshl_b32 s0, s2, 4                                       // 0000002CFCE0: 84008402
	s_cmp_lg_u64 s[10:11], 0                                   // 0000002CFCE4: BF11800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CFCE8: BF870112
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002CFCEC: D6100004 02052103
	v_or3_b32 v11, v0, s0, v1                                  // 0000002CFCF4: D658000B 04040100
	s_cselect_b32 s0, -1, 0                                    // 0000002CFCFC: 980080C1
	s_cmp_eq_u64 s[10:11], 0                                   // 0000002CFD00: BF10800A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CFD04: BF870112
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002CFD08: D6550003 03FE0903 00007FFF
	v_ashrrev_i32_e32 v12, 31, v11                             // 0000002CFD14: 3418169F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002CFD18: BF870112
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002CFD1C: 360606FF FFFF0000
	.long 0xd73c000d                                           // 0000002CFD24: D73C000D
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 0000002CFD28: 02021681
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFD2C: BF870091
	.long 0xd7006a00                                           // 0000002CFD30: D7006A00
	v_cndmask_b32_e32 v1, s6, v13, vcc_lo                      // 0000002CFD34: 02021A06
	v_add_co_ci_u32_e64 v1, null, s7, v14, vcc_lo              // 0000002CFD38: D5207C01 01AA1C07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFD40: BF870092
	.long 0xd7006a0f                                           // 0000002CFD44: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v0, vcc_lo                   // 0000002CFD48: 020200FF 00002000
	v_add_co_ci_u32_e64 v16, null, 0, v1, vcc_lo               // 0000002CFD50: D5207C10 01AA0280
	.long 0xd7006a11                                           // 0000002CFD58: D7006A11
	v_cndmask_b32_e32 v1, 0x3000, v0, vcc_lo                   // 0000002CFD5C: 020200FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CFD64: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v1, vcc_lo               // 0000002CFD68: D5207C12 01AA0280
	.long 0xd7006a13                                           // 0000002CFD70: D7006A13
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000002CFD74: 020200FF 00001000
	v_add_co_ci_u32_e64 v20, null, 0, v1, vcc_lo               // 0000002CFD7C: D5207C14 01AA0280
	s_clause 0x3                                               // 0000002CFD84: BF850003
	global_load_u16 v2, v[15:16], off offset:2048              // 0000002CFD88: DC4A0800 027C000F
	global_load_u16 v5, v[17:18], off offset:3072              // 0000002CFD90: DC4A0C00 057C0011
	global_load_u16 v10, v[0:1], off                           // 0000002CFD98: DC4A0000 0A7C0000
	global_load_u16 v15, v[19:20], off offset:1024             // 0000002CFDA0: DC4A0400 0F7C0013
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 0000002CFDA8: 100606FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002CFDB0: BF8702A1
	v_exp_f32_e32 v3, v3                                       // 0000002CFDB4: 7E064B03
	s_waitcnt vmcnt(3)                                         // 0000002CFDB8: BF890FF7
	v_dual_add_f32 v3, 1.0, v3 :: v_dual_lshlrev_b32 v2, 16, v2// 0000002CFDBC: C92206F2 03020490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CFDC4: BF870121
	v_div_scale_f32 v4, null, v3, v3, 1.0                      // 0000002CFDC8: D6FC7C04 03CA0703
	v_div_scale_f32 v18, vcc_lo, 1.0, v3, 1.0                  // 0000002CFDD0: D6FC6A12 03CA06F2
	v_rcp_f32_e32 v16, v4                                      // 0000002CFDD8: 7E205504
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFDDC: BF870095
	v_fma_f32 v17, -v4, v16, 1.0                               // 0000002CFDE0: D6130011 23CA2104
	v_fmac_f32_e32 v16, v17, v16                               // 0000002CFDE8: 56202111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFDEC: BF870091
	v_mul_f32_e32 v17, v18, v16                                // 0000002CFDF0: 10222112
	v_fma_f32 v19, -v4, v17, v18                               // 0000002CFDF4: D6130013 244A2304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFDFC: BF870091
	v_fmac_f32_e32 v17, v19, v16                               // 0000002CFE00: 56222113
	v_fma_f32 v4, -v4, v17, v18                                // 0000002CFE04: D6130004 244A2304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFE0C: BF870091
	v_div_fmas_f32 v4, v4, v16, v17                            // 0000002CFE10: D6370004 04462104
	v_div_fixup_f32 v3, v4, v3, 1.0                            // 0000002CFE18: D6270003 03CA0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFE20: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 0000002CFE24: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000002CFE2C: D6550003 03FE0903 00007FFF
	s_waitcnt vmcnt(1)                                         // 0000002CFE38: BF8907F7
	v_lshlrev_b32_e32 v4, 16, v10                              // 0000002CFE3C: 30081490
	s_waitcnt vmcnt(0)                                         // 0000002CFE40: BF8903F7
	v_lshlrev_b32_e32 v10, 16, v15                             // 0000002CFE44: 30141E90
	v_and_b32_e32 v3, 0xffff0000, v3                           // 0000002CFE48: 360606FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFE50: BF870091
	v_fma_f32 v4, v4, v3, 0                                    // 0000002CFE54: D6130004 02020704
	v_dual_fmac_f32 v4, v10, v3 :: v_dual_lshlrev_b32 v5, 16, v5// 0000002CFE5C: C822070A 04040A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CFE64: BF870121
	v_fmac_f32_e32 v4, v2, v3                                  // 0000002CFE68: 56080702
	.long 0xd7006a02                                           // 0000002CFE6C: D7006A02
	v_cndmask_b32_e32 v1, s8, v13, vcc_lo                      // 0000002CFE70: 02021A08
	v_fmac_f32_e32 v4, v5, v3                                  // 0000002CFE74: 56080705
	v_add_co_ci_u32_e64 v3, null, s9, v14, vcc_lo              // 0000002CFE78: D5207C03 01AA1C09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFE80: BF870092
	v_mul_f32_e32 v10, 0x3e800000, v4                          // 0000002CFE84: 101408FF 3E800000
	v_bfe_u32 v4, v10, 16, 1                                   // 0000002CFE8C: D6100004 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CFE94: BF870001
	v_add3_u32 v13, v10, v4, 0x7fff                            // 0000002CFE98: D655000D 03FE090A 00007FFF
	.long 0xd73c0004                                           // 0000002CFEA4: D73C0004
	v_cndmask_b32_e32 v1, 2, v11, vcc_lo                       // 0000002CFEA8: 02021682
	global_store_d16_hi_b16 v[2:3], v13, off                   // 0000002CFEAC: DC960000 007C0D02
	s_cbranch_scc1 7                                           // 0000002CFEB4: BFA20007 <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf+0x7d4>
	.long 0xd7006a0b                                           // 0000002CFEB8: D7006A0B
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002CFEBC: 0202080A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002CFEC0: BF870001
	v_add_co_ci_u32_e64 v12, null, s11, v5, vcc_lo             // 0000002CFEC4: D5207C0C 01AA0A0B
	global_store_b32 v[11:12], v10, off                        // 0000002CFECC: DC6A0000 007C0A0B
	.long 0xd7006a0a                                           // 0000002CFED4: D7006A0A
	v_cndmask_b32_e32 v1, 0x5000, v0, vcc_lo                   // 0000002CFED8: 020200FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CFEE0: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v1, vcc_lo               // 0000002CFEE4: D5207C0B 01AA0280
	.long 0xd7006a0c                                           // 0000002CFEEC: D7006A0C
	v_cndmask_b32_e32 v1, 0x6000, v0, vcc_lo                   // 0000002CFEF0: 020200FF 00006000
	v_add_co_ci_u32_e64 v13, null, 0, v1, vcc_lo               // 0000002CFEF8: D5207C0D 01AA0280
	s_clause 0x1                                               // 0000002CFF00: BF850001
	global_load_u16 v14, v[10:11], off                         // 0000002CFF04: DC4A0000 0E7C000A
	global_load_u16 v15, v[12:13], off offset:1024             // 0000002CFF0C: DC4A0400 0F7C000C
	.long 0xd7006a0a                                           // 0000002CFF14: D7006A0A
	v_cndmask_b32_e32 v1, 0x7000, v0, vcc_lo                   // 0000002CFF18: 020200FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002CFF20: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v1, vcc_lo               // 0000002CFF24: D5207C0B 01AA0280
	.long 0xd7006a0c                                           // 0000002CFF2C: D7006A0C
	v_cndmask_b32_e32 v1, 0x8000, v0, vcc_lo                   // 0000002CFF30: 020200FF 00008000
	v_add_co_ci_u32_e64 v13, null, 0, v1, vcc_lo               // 0000002CFF38: D5207C0D 01AA0280
	s_clause 0x1                                               // 0000002CFF40: BF850001
	global_load_u16 v10, v[10:11], off offset:2048             // 0000002CFF44: DC4A0800 0A7C000A
	global_load_u16 v11, v[12:13], off offset:3072             // 0000002CFF4C: DC4A0C00 0B7C000C
	s_waitcnt lgkmcnt(1)                                       // 0000002CFF54: BF89FC17
	v_add_f32_e32 v8, v8, v9                                   // 0000002CFF58: 06101308
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFF5C: BF870091
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002CFF60: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000002CFF68: D6550008 03FE1308 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFF74: BF870091
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002CFF78: 361010FF FFFF0000
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 0000002CFF80: 101010FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000002CFF88: BF8702A1
	v_exp_f32_e32 v8, v8                                       // 0000002CFF8C: 7E104B08
	s_waitcnt vmcnt(0)                                         // 0000002CFF90: BF8903F7
	v_dual_add_f32 v8, 1.0, v8 :: v_dual_lshlrev_b32 v11, 16, v11// 0000002CFF94: C92210F2 080A1690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CFF9C: BF870121
	v_div_scale_f32 v9, null, v8, v8, 1.0                      // 0000002CFFA0: D6FC7C09 03CA1108
	v_div_scale_f32 v16, vcc_lo, 1.0, v8, 1.0                  // 0000002CFFA8: D6FC6A10 03CA10F2
	v_rcp_f32_e32 v12, v9                                      // 0000002CFFB0: 7E185509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFFB4: BF870095
	v_fma_f32 v13, -v9, v12, 1.0                               // 0000002CFFB8: D613000D 23CA1909
	v_fmac_f32_e32 v12, v13, v12                               // 0000002CFFC0: 5618190D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFFC4: BF870091
	v_mul_f32_e32 v13, v16, v12                                // 0000002CFFC8: 101A1910
	v_fma_f32 v17, -v9, v13, v16                               // 0000002CFFCC: D6130011 24421B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFFD4: BF870091
	v_fmac_f32_e32 v13, v17, v12                               // 0000002CFFD8: 561A1911
	v_fma_f32 v9, -v9, v13, v16                                // 0000002CFFDC: D6130009 24421B09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002CFFE4: BF870121
	v_div_fmas_f32 v9, v9, v12, v13                            // 0000002CFFE8: D6370009 04361909
	v_lshlrev_b32_e32 v12, 16, v15                             // 0000002CFFF0: 30181E90
	v_div_fixup_f32 v8, v9, v8, 1.0                            // 0000002CFFF4: D6270008 03CA1109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002CFFFC: BF870091
	v_bfe_u32 v9, v8, 16, 1                                    // 0000002D0000: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 0000002D0008: D6550008 03FE1308 00007FFF
	v_lshlrev_b32_e32 v9, 16, v14                              // 0000002D0014: 30121C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D0018: BF870092
	v_and_b32_e32 v8, 0xffff0000, v8                           // 0000002D001C: 361010FF FFFF0000
	v_fma_f32 v9, v9, v8, 0                                    // 0000002D0024: D6130009 02021109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D002C: BF870091
	v_dual_fmac_f32 v9, v12, v8 :: v_dual_lshlrev_b32 v10, 16, v10// 0000002D0030: C822110C 090A1490
	v_fmac_f32_e32 v9, v10, v8                                 // 0000002D0038: 5612110A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D003C: BF870121
	v_fmac_f32_e32 v9, v11, v8                                 // 0000002D0040: 5612110B
	v_cndmask_b32_e64 v8, 0, 1, s0                             // 0000002D0044: D5010008 00010280
	v_mul_f32_e32 v9, 0x3e800000, v9                           // 0000002D004C: 101212FF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D0054: BF870091
	v_bfe_u32 v10, v9, 16, 1                                   // 0000002D0058: D610000A 02052109
	v_add3_u32 v12, v9, v10, 0x7fff                            // 0000002D0060: D655000C 03FE1509 00007FFF
	.long 0xd7006a0a                                           // 0000002D006C: D7006A0A
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 0000002D0070: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D0078: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v3, vcc_lo               // 0000002D007C: D5207C0B 01AA0680
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000002D0084: 916A007E
	global_store_d16_hi_b16 v[10:11], v12, off offset:1024     // 0000002D0088: DC960400 007C0C0A
	s_cbranch_vccnz 13                                         // 0000002D0090: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf+0x9c8>
	.long 0xd7006a0a                                           // 0000002D0094: D7006A0A
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D0098: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D009C: BF870111
	v_add_co_ci_u32_e64 v11, null, s11, v5, vcc_lo             // 0000002D00A0: D5207C0B 01AA0A0B
	.long 0xd7006a0a                                           // 0000002D00A8: D7006A0A
	v_cndmask_b32_e32 v1, 0x2000, v10, vcc_lo                  // 0000002D00AC: 020214FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D00B4: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v11, vcc_lo              // 0000002D00B8: D5207C0B 01AA1680
	global_store_b32 v[10:11], v9, off offset:2048             // 0000002D00C0: DC6A0800 007C090A
	.long 0xd7006a09                                           // 0000002D00C8: D7006A09
	v_cndmask_b32_e32 v1, 0xa000, v0, vcc_lo                   // 0000002D00CC: 020200FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D00D4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 0000002D00D8: D5207C0A 01AA0280
	.long 0xd7006a0b                                           // 0000002D00E0: D7006A0B
	v_cndmask_b32_e32 v1, 0xb000, v0, vcc_lo                   // 0000002D00E4: 020200FF 0000B000
	v_add_co_ci_u32_e64 v12, null, 0, v1, vcc_lo               // 0000002D00EC: D5207C0C 01AA0280
	s_clause 0x1                                               // 0000002D00F4: BF850001
	global_load_u16 v13, v[9:10], off                          // 0000002D00F8: DC4A0000 0D7C0009
	global_load_u16 v11, v[11:12], off offset:1024             // 0000002D0100: DC4A0400 0B7C000B
	.long 0xd7006a09                                           // 0000002D0108: D7006A09
	v_cndmask_b32_e32 v1, 0xc000, v0, vcc_lo                   // 0000002D010C: 020200FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002D0114: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v1, vcc_lo               // 0000002D0118: D5207C0A 01AA0280
	.long 0xd7006a00                                           // 0000002D0120: D7006A00
	v_cndmask_b32_e32 v1, 0xd000, v0, vcc_lo                   // 0000002D0124: 020200FF 0000D000
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000002D012C: D5207C01 01AA0280
	s_clause 0x1                                               // 0000002D0134: BF850001
	global_load_u16 v9, v[9:10], off offset:2048               // 0000002D0138: DC4A0800 097C0009
	global_load_u16 v0, v[0:1], off offset:3072                // 0000002D0140: DC4A0C00 007C0000
	s_waitcnt lgkmcnt(0)                                       // 0000002D0148: BF89FC07
	v_add_f32_e32 v1, v6, v7                                   // 0000002D014C: 06020F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D0150: BF870091
	v_bfe_u32 v6, v1, 16, 1                                    // 0000002D0154: D6100006 02052101
	v_add3_u32 v1, v1, v6, 0x7fff                              // 0000002D015C: D6550001 03FE0D01 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D0168: BF870091
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002D016C: 360202FF FFFF0000
	v_mul_f32_e32 v1, 0xbfb8aa3b, v1                           // 0000002D0174: 100202FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000002D017C: BF870291
	v_exp_f32_e32 v1, v1                                       // 0000002D0180: 7E024B01
	v_add_f32_e32 v1, 1.0, v1                                  // 0000002D0184: 060202F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000002D0188: BF870121
	v_div_scale_f32 v6, null, v1, v1, 1.0                      // 0000002D018C: D6FC7C06 03CA0301
	v_div_scale_f32 v12, vcc_lo, 1.0, v1, 1.0                  // 0000002D0194: D6FC6A0C 03CA02F2
	v_rcp_f32_e32 v7, v6                                       // 0000002D019C: 7E0E5506
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D01A0: BF870095
	v_fma_f32 v10, -v6, v7, 1.0                                // 0000002D01A4: D613000A 23CA0F06
	v_fmac_f32_e32 v7, v10, v7                                 // 0000002D01AC: 560E0F0A
	s_waitcnt vmcnt(2)                                         // 0000002D01B0: BF890BF7
	v_lshlrev_b32_e32 v11, 16, v11                             // 0000002D01B4: 30161690
	s_waitcnt vmcnt(1)                                         // 0000002D01B8: BF8907F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000002D01BC: 30121290
	s_waitcnt vmcnt(0)                                         // 0000002D01C0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000002D01C4: 30000090
	v_mul_f32_e32 v10, v12, v7                                 // 0000002D01C8: 10140F0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D01CC: BF870091
	v_fma_f32 v14, -v6, v10, v12                               // 0000002D01D0: D613000E 24321506
	v_fmac_f32_e32 v10, v14, v7                                // 0000002D01D8: 56140F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D01DC: BF870091
	v_fma_f32 v6, -v6, v10, v12                                // 0000002D01E0: D6130006 24321506
	v_div_fmas_f32 v12, v6, v7, v10                            // 0000002D01E8: D637000C 042A0F06
	v_div_fmas_f32 v14, v6, v7, v10                            // 0000002D01F0: D637000E 042A0F06
	v_div_fmas_f32 v6, v6, v7, v10                             // 0000002D01F8: D6370006 042A0F06
	v_cmp_ne_u32_e32 vcc_lo, 1, v8                             // 0000002D0200: 7C9A1081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D0204: BF870214
	v_div_fixup_f32 v12, v12, v1, 1.0                          // 0000002D0208: D627000C 03CA030C
	v_div_fixup_f32 v7, v14, v1, 1.0                           // 0000002D0210: D6270007 03CA030E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000002D0218: BF8701A4
	v_div_fixup_f32 v1, v6, v1, 1.0                            // 0000002D021C: D6270001 03CA0306
	s_and_b32 vcc_lo, exec_lo, vcc_lo                          // 0000002D0224: 8B6A6A7E
	v_bfe_u32 v10, v12, 16, 1                                  // 0000002D0228: D610000A 0205210C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D0230: BF870113
	v_bfe_u32 v6, v7, 16, 1                                    // 0000002D0234: D6100006 02052107
	v_add3_u32 v10, v12, v10, 0x7fff                           // 0000002D023C: D655000A 03FE150C 00007FFF
	v_bfe_u32 v12, v1, 16, 1                                   // 0000002D0248: D610000C 02052101
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D0250: BF870193
	v_add3_u32 v6, v7, v6, 0x7fff                              // 0000002D0254: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v10                          // 0000002D0260: 360E14FF FFFF0000
	v_lshlrev_b32_e32 v10, 16, v13                             // 0000002D0268: 30141A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000002D026C: BF870214
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000002D0270: D6550001 03FE1901 00007FFF
	v_and_b32_e32 v6, 0xffff0000, v6                           // 0000002D027C: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000002D0284: BF870193
	v_fma_f32 v7, v10, v7, 0                                   // 0000002D0288: D6130007 02020F0A
	v_and_b32_e32 v1, 0xffff0000, v1                           // 0000002D0290: 360202FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D0298: BF870092
	v_fmac_f32_e32 v7, v11, v6                                 // 0000002D029C: 560E0D0B
	v_fmac_f32_e32 v7, v9, v1                                  // 0000002D02A0: 560E0309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D02A4: BF870091
	v_fmac_f32_e32 v7, v0, v1                                  // 0000002D02A8: 560E0300
	v_mul_f32_e32 v0, 0x3e800000, v7                           // 0000002D02AC: 10000EFF 3E800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002D02B4: BF870091
	v_bfe_u32 v1, v0, 16, 1                                    // 0000002D02B8: D6100001 02052100
	v_add3_u32 v6, v0, v1, 0x7fff                              // 0000002D02C0: D6550006 03FE0300 00007FFF
	.long 0xd7000001                                           // 0000002D02CC: D7000001
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000002D02D0: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D02D8: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v3, s0                    // 0000002D02DC: D5207C02 00020680
	global_store_d16_hi_b16 v[1:2], v6, off offset:2048        // 0000002D02E4: DC960800 007C0601
	s_cbranch_vccnz 13                                         // 0000002D02EC: BFA4000D <_ZN7halogen12_GLOBAL__N_17k_hcup4ILi3ELi1EEEvPKhlllPKtS5_PtPf+0xc24>
	.long 0xd7006a01                                           // 0000002D02F0: D7006A01
	v_cndmask_b32_e32 v1, s10, v4, vcc_lo                      // 0000002D02F4: 0202080A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000002D02F8: BF870111
	v_add_co_ci_u32_e64 v2, null, s11, v5, vcc_lo              // 0000002D02FC: D5207C02 01AA0A0B
	.long 0xd7006a01                                           // 0000002D0304: D7006A01
	v_cndmask_b32_e32 v1, 0x5000, v1, vcc_lo                   // 0000002D0308: 020202FF 00005000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000002D0310: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000002D0314: D5207C02 01AA0480
	global_store_b32 v[1:2], v0, off                           // 0000002D031C: DC6A0000 007C0001
	s_endpgm                                                   // 0000002D0324: BFB00000
		...

