0000000000317c00 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y>:
; _ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y():
	s_clause 0x2                                               // 000000317C00: BF850002
	s_load_b32 s24, s[0:1], 0x20                               // 000000317C04: F4000600 F8000020
	s_load_b128 s[20:23], s[0:1], 0x150                        // 000000317C0C: F4080500 F8000150
	s_load_b512 s[4:19], s[0:1], 0x168                         // 000000317C14: F4100100 F8000168
	s_mov_b32 s3, -1                                           // 000000317C1C: BE8300C1
	s_waitcnt lgkmcnt(0)                                       // 000000317C20: BF89FC07
	s_cmp_ge_i32 s2, s24                                       // 000000317C24: BF031802
	s_cbranch_scc0 2922                                        // 000000317C28: BFA10B6A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2dd4>
	s_load_b32 s3, s[0:1], 0x160                               // 000000317C2C: F40000C0 F8000160
	s_mov_b32 s25, -1                                          // 000000317C34: BE9900C1
	s_waitcnt lgkmcnt(0)                                       // 000000317C38: BF89FC07
	s_add_i32 s3, s3, s24                                      // 000000317C3C: 81031803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000317C40: BF870009
	s_cmp_ge_i32 s2, s3                                        // 000000317C44: BF030302
	s_cbranch_scc0 2425                                        // 000000317C48: BFA10979 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2630>
	v_lshrrev_b32_e32 v1, 4, v0                                // 000000317C4C: 32020084
	v_bfe_u32 v2, v0, 4, 1                                     // 000000317C50: D6100002 02050900
	s_sub_i32 s3, s2, s3                                       // 000000317C58: 81830302
	v_and_b32_e32 v50, 15, v0                                  // 000000317C5C: 3664008F
	s_lshl_b32 s3, s3, 4                                       // 000000317C60: 84038403
	v_and_b32_e32 v1, 14, v1                                   // 000000317C64: 3602028E
	v_and_b32_e32 v3, 12, v0                                   // 000000317C68: 3606008C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000317C6C: BF870223
	v_lshlrev_b32_e32 v25, 4, v50                              // 000000317C70: 30326484
	v_or_b32_e32 v56, 16, v50                                  // 000000317C74: 38706490
	v_or3_b32 v49, s3, v1, v2                                  // 000000317C78: D6580031 040A0203
	s_mov_b32 s3, exec_lo                                      // 000000317C80: BE83007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000317C84: BF870091
	v_mad_i64_i32 v[1:2], null, 0x154, v49, s[4:5]             // 000000317C88: D6FF7C01 001262FF 00000154
	.long 0xd7006a09                                           // 000000317C94: D7006A09
	v_cndmask_b32_e32 v1, v1, v25, vcc_lo                      // 000000317C98: 02023301
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000317C9C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 000000317CA0: D5207C0A 01AA0480
	.long 0xd7006a03                                           // 000000317CA8: D7006A03
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 000000317CAC: 02020701
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 000000317CB0: D5207C04 01AA0480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000317CB8: BF870094
	.long 0xd7006a05                                           // 000000317CBC: D7006A05
	v_cndmask_b32_e32 v1, 0xd4000, v9, vcc_lo                  // 000000317CC0: 020212FF 000D4000
	v_add_co_ci_u32_e64 v6, null, 0, v10, vcc_lo               // 000000317CC8: D5207C06 01AA1480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000317CD0: BF870094
	.long 0xd7006a07                                           // 000000317CD4: D7006A07
	v_cndmask_b32_e32 v1, 0xd4000, v3, vcc_lo                  // 000000317CD8: 020206FF 000D4000
	v_add_co_ci_u32_e64 v8, null, 0, v4, vcc_lo                // 000000317CE0: D5207C08 01AA0880
	.long 0xd7006a15                                           // 000000317CE8: D7006A15
	v_cndmask_b32_e32 v1, 0x1a9000, v9, vcc_lo                 // 000000317CEC: 020212FF 001A9000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000317CF4: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v10, vcc_lo              // 000000317CF8: D5207C16 01AA1480
	.long 0xd7006a0b                                           // 000000317D00: D7006A0B
	v_cndmask_b32_e32 v1, 0x1a9000, v3, vcc_lo                 // 000000317D04: 020206FF 001A9000
	v_add_co_ci_u32_e64 v12, null, 0, v4, vcc_lo               // 000000317D0C: D5207C0C 01AA0880
	.long 0xd7006a17                                           // 000000317D14: D7006A17
	v_cndmask_b32_e32 v1, 0x27d000, v9, vcc_lo                 // 000000317D18: 020212FF 0027D000
	s_clause 0x1                                               // 000000317D20: BF850001
	global_load_b128 v[45:48], v[9:10], off                    // 000000317D24: DC5E0000 2D7C0009
	global_load_b32 v60, v[3:4], off offset:320                // 000000317D2C: DC520140 3C7C0003
	v_add_co_ci_u32_e64 v24, null, 0, v10, vcc_lo              // 000000317D34: D5207C18 01AA1480
	.long 0xd7006a03                                           // 000000317D3C: D7006A03
	v_cndmask_b32_e32 v1, 0x27d000, v3, vcc_lo                 // 000000317D40: 020206FF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000317D48: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000317D4C: D5207C04 01AA0880
	s_clause 0x5                                               // 000000317D54: BF850005
	global_load_b128 v[41:44], v[5:6], off offset:2048         // 000000317D58: DC5E0800 297C0005
	global_load_b32 v61, v[7:8], off offset:2368               // 000000317D60: DC520940 3D7C0007
	global_load_b128 v[37:40], v[21:22], off                   // 000000317D68: DC5E0000 257C0015
	global_load_b32 v59, v[11:12], off offset:320              // 000000317D70: DC520140 3B7C000B
	global_load_b128 v[17:20], v[23:24], off offset:2048       // 000000317D78: DC5E0800 117C0017
	global_load_b32 v57, v[3:4], off offset:2368               // 000000317D80: DC520940 397C0003
	v_cmpx_gt_u32_e32 20, v56                                  // 000000317D88: 7D987094
	s_cbranch_execz 35                                         // 000000317D8C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x21c>
	.long 0xd7006a03                                           // 000000317D90: D7006A03
	v_cndmask_b32_e32 v1, 0xd4000, v1, vcc_lo                  // 000000317D94: 020202FF 000D4000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000317D9C: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 000000317DA0: D5207C04 01AA0480
	.long 0xd7006a1a                                           // 000000317DA8: D7006A1A
	v_cndmask_b32_e32 v1, 0x1a9000, v1, vcc_lo                 // 000000317DAC: 020202FF 001A9000
	s_clause 0x1                                               // 000000317DB4: BF850001
	global_load_b128 v[13:16], v[9:10], off offset:256         // 000000317DB8: DC5E0100 0D7C0009
	global_load_b32 v54, v[1:2], off offset:336                // 000000317DC0: DC520150 367C0001
	v_add_co_ci_u32_e64 v27, null, 0, v2, vcc_lo               // 000000317DC8: D5207C1B 01AA0480
	.long 0xd7006a01                                           // 000000317DD0: D7006A01
	v_cndmask_b32_e32 v1, 0x27d000, v1, vcc_lo                 // 000000317DD4: 020202FF 0027D000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000317DDC: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000317DE0: D5207C02 01AA0480
	s_clause 0x5                                               // 000000317DE8: BF850005
	global_load_b128 v[9:12], v[5:6], off offset:2304          // 000000317DEC: DC5E0900 097C0005
	global_load_b128 v[5:8], v[21:22], off offset:256          // 000000317DF4: DC5E0100 057C0015
	global_load_b32 v55, v[3:4], off offset:2384               // 000000317DFC: DC520950 377C0003
	global_load_b32 v53, v[26:27], off offset:336              // 000000317E04: DC520150 357C001A
	global_load_b32 v51, v[1:2], off offset:2384               // 000000317E0C: DC520950 337C0001
	global_load_b128 v[1:4], v[23:24], off offset:2304         // 000000317E14: DC5E0900 017C0017
	s_or_b32 exec_lo, exec_lo, s3                              // 000000317E1C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000317E20: BF870009
	s_mov_b32 s3, exec_lo                                      // 000000317E24: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000317E28: 7D940080
	s_xor_b32 s3, exec_lo, s3                                  // 000000317E2C: 8D03037E
	s_cbranch_execz 20                                         // 000000317E30: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x284>
	v_mov_b32_e32 v21, 0                                       // 000000317E34: 7E2A0280
	global_load_b64 v[22:23], v21, s[16:17] glc                // 000000317E38: DC564000 16100015
	s_waitcnt vmcnt(0)                                         // 000000317E40: BF8903F7
	buffer_gl1_inv                                             // 000000317E44: E0B00000 00000000
	buffer_gl0_inv                                             // 000000317E4C: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[18:19], v[22:23]                // 000000317E54: 7CB62C12
	s_cbranch_vccnz 10                                         // 000000317E58: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x284>
	s_sleep 1                                                  // 000000317E5C: BF830001
	global_load_b64 v[22:23], v21, s[16:17] glc                // 000000317E60: DC564000 16100015
	s_waitcnt vmcnt(0)                                         // 000000317E68: BF8903F7
	buffer_gl1_inv                                             // 000000317E6C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000317E74: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[18:19], v[22:23]                // 000000317E7C: 7CB82C12
	s_cbranch_vccnz 65526                                      // 000000317E80: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x25c>
	s_or_b32 exec_lo, exec_lo, s3                              // 000000317E84: 8C7E037E
	v_lshlrev_b32_e32 v58, 1, v25                              // 000000317E88: 30743281
	s_waitcnt vmcnt(0)                                         // 000000317E8C: BF8903F7
	s_barrier                                                  // 000000317E90: BFBD0000
	buffer_gl0_inv                                             // 000000317E94: E0AC0000 00000000
	buffer_gl1_inv                                             // 000000317E9C: E0B00000 00000000
	buffer_gl0_inv                                             // 000000317EA4: E0AC0000 00000000
	s_clause 0x3                                               // 000000317EAC: BF850003
	global_load_b128 v[21:24], v58, s[6:7]                     // 000000317EB0: DC5E0000 1506003A
	global_load_b128 v[33:36], v58, s[6:7] offset:640          // 000000317EB8: DC5E0280 2106003A
	global_load_b128 v[25:28], v58, s[6:7] offset:16           // 000000317EC0: DC5E0010 1906003A
	global_load_b128 v[29:32], v58, s[6:7] offset:656          // 000000317EC8: DC5E0290 1D06003A
	v_cvt_f32_ubyte0_e32 v62, v45                              // 000000317ED0: 7E7C232D
	v_cvt_f32_ubyte1_e32 v63, v45                              // 000000317ED4: 7E7E252D
	v_cvt_f32_ubyte0_e32 v65, v46                              // 000000317ED8: 7E82232E
	v_cvt_f32_ubyte1_e32 v66, v46                              // 000000317EDC: 7E84252E
	v_cvt_f32_ubyte0_e32 v68, v47                              // 000000317EE0: 7E88232F
	v_fma_mix_f32 v62, v62, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317EE4: CC20603E 14F2793E
	v_fma_mix_f32 v63, v63, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317EEC: CC20603F 14F2793F
	v_fma_mix_f32 v65, v65, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317EF4: CC206041 14F27941
	v_cvt_f32_ubyte1_e32 v69, v47                              // 000000317EFC: 7E8A252F
	v_cvt_f32_ubyte0_e32 v71, v48                              // 000000317F00: 7E8E2330
	v_bfe_u32 v119, v62, 16, 1                                 // 000000317F04: D6100077 0205213E
	v_fma_mix_f32 v66, v66, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317F0C: CC206042 14F27942
	v_fma_mix_f32 v68, v68, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317F14: CC206044 14F27944
	v_bfe_u32 v120, v63, 16, 1                                 // 000000317F1C: D6100078 0205213F
	v_bfe_u32 v123, v65, 16, 1                                 // 000000317F24: D610007B 02052141
	v_add3_u32 v62, v62, v119, 0x7fff                          // 000000317F2C: D655003E 03FEEF3E 00007FFF
	.long 0x7f683880                                           // 000000317F38: 7F683880
	v_cvt_f32_ubyte2_e32 v64, v45                              // 000000317F3C: 7E80272D
	v_cvt_f32_ubyte3_e32 v45, v45                              // 000000317F40: 7E5A292D
	v_cvt_f32_ubyte2_e32 v67, v46                              // 000000317F44: 7E86272E
	v_cvt_f32_ubyte3_e32 v46, v46                              // 000000317F48: 7E5C292E
	v_cvt_f32_ubyte2_e32 v70, v47                              // 000000317F4C: 7E8C272F
	v_cvt_f32_ubyte3_e32 v47, v47                              // 000000317F50: 7E5E292F
	v_cvt_f32_ubyte1_e32 v72, v48                              // 000000317F54: 7E902530
	v_cvt_f32_ubyte2_e32 v73, v48                              // 000000317F58: 7E922730
	v_cvt_f32_ubyte3_e32 v48, v48                              // 000000317F5C: 7E602930
	v_cvt_f32_ubyte0_e32 v74, v41                              // 000000317F60: 7E942329
	v_fma_mix_f32 v69, v69, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317F64: CC206045 14F27945
	v_fma_mix_f32 v71, v71, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317F6C: CC206047 14F27947
	v_bfe_u32 v124, v66, 16, 1                                 // 000000317F74: D610007C 02052142
	v_bfe_u32 v127, v68, 16, 1                                 // 000000317F7C: D610007F 02052144
	v_add3_u32 v63, v63, v120, 0x7fff                          // 000000317F84: D655003F 03FEF13F 00007FFF
	v_add3_u32 v65, v65, v123, 0x7fff                          // 000000317F90: D6550041 03FEF741 00007FFF
	.long 0x7e6839be                                           // 000000317F9C: 7E6839BE
	v_cvt_f32_ubyte1_e32 v75, v41                              // 000000317FA0: 7E962529
	v_cvt_f32_ubyte2_e32 v76, v41                              // 000000317FA4: 7E982729
	v_cvt_f32_ubyte0_e32 v77, v42                              // 000000317FA8: 7E9A232A
	v_fma_mix_f32 v64, v64, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FAC: CC206040 14F27940
	v_fma_mix_f32 v45, v45, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FB4: CC20602D 14F2792D
	v_fma_mix_f32 v67, v67, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FBC: CC206043 14F27943
	v_fma_mix_f32 v46, v46, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FC4: CC20602E 14F2792E
	v_fma_mix_f32 v70, v70, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FCC: CC206046 14F27946
	v_fma_mix_f32 v47, v47, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FD4: CC20602F 14F2792F
	v_fma_mix_f32 v72, v72, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FDC: CC206048 14F27948
	v_fma_mix_f32 v73, v73, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FE4: CC206049 14F27949
	v_fma_mix_f32 v48, v48, v60, v60 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FEC: CC206030 14F27930
	v_fma_mix_f32 v60, v74, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000317FF4: CC20603C 14F67B4A
	v_bfe_u32 v128, v69, 16, 1                                 // 000000317FFC: D6100080 02052145
	v_bfe_u32 v131, v71, 16, 1                                 // 000000318004: D6100083 02052147
	v_add3_u32 v66, v66, v124, 0x7fff                          // 00000031800C: D6550042 03FEF942 00007FFF
	v_add3_u32 v68, v68, v127, 0x7fff                          // 000000318018: D6550044 03FEFF44 00007FFF
	v_and_or_b32 v63, 0xffff0000, v63, v52                     // 000000318024: D657003F 04D27EFF FFFF0000
	.long 0x7e6839c1                                           // 000000318030: 7E6839C1
	v_cvt_f32_ubyte1_e32 v78, v42                              // 000000318034: 7E9C252A
	v_cvt_f32_ubyte2_e32 v79, v42                              // 000000318038: 7E9E272A
	v_cvt_f32_ubyte0_e32 v80, v43                              // 00000031803C: 7EA0232B
	v_fma_mix_f32 v74, v75, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318040: CC20604A 14F67B4B
	v_fma_mix_f32 v75, v76, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318048: CC20604B 14F67B4C
	v_fma_mix_f32 v76, v77, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318050: CC20604C 14F67B4D
	v_bfe_u32 v122, v45, 16, 1                                 // 000000318058: D610007A 0205212D
	v_bfe_u32 v132, v72, 16, 1                                 // 000000318060: D6100084 02052148
	v_bfe_u32 v135, v60, 16, 1                                 // 000000318068: D6100087 0205213C
	v_add3_u32 v69, v69, v128, 0x7fff                          // 000000318070: D6550045 03FF0145 00007FFF
	v_add3_u32 v71, v71, v131, 0x7fff                          // 00000031807C: D6550047 03FF0747 00007FFF
	v_and_or_b32 v66, 0xffff0000, v66, v52                     // 000000318088: D6570042 04D284FF FFFF0000
	.long 0x7e6839c4                                           // 000000318094: 7E6839C4
	v_cvt_f32_ubyte1_e32 v81, v43                              // 000000318098: 7EA2252B
	v_cvt_f32_ubyte2_e32 v82, v43                              // 00000031809C: 7EA4272B
	v_cvt_f32_ubyte0_e32 v83, v44                              // 0000003180A0: 7EA6232C
	v_fma_mix_f32 v77, v78, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003180A4: CC20604D 14F67B4E
	v_fma_mix_f32 v78, v79, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003180AC: CC20604E 14F67B4F
	v_fma_mix_f32 v79, v80, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003180B4: CC20604F 14F67B50
	v_bfe_u32 v126, v46, 16, 1                                 // 0000003180BC: D610007E 0205212E
	v_bfe_u32 v119, v74, 16, 1                                 // 0000003180C4: D6100077 0205214A
	v_add3_u32 v45, v45, v122, 0x7fff                          // 0000003180CC: D655002D 03FEF52D 00007FFF
	v_bfe_u32 v122, v76, 16, 1                                 // 0000003180D8: D610007A 0205214C
	v_add3_u32 v72, v72, v132, 0x7fff                          // 0000003180E0: D6550048 03FF0948 00007FFF
	v_add3_u32 v60, v60, v135, 0x7fff                          // 0000003180EC: D655003C 03FF0F3C 00007FFF
	v_and_or_b32 v69, 0xffff0000, v69, v52                     // 0000003180F8: D6570045 04D28AFF FFFF0000
	.long 0x7e6839c7                                           // 000000318104: 7E6839C7
	v_cvt_f32_ubyte3_e32 v41, v41                              // 000000318108: 7E522929
	v_cvt_f32_ubyte3_e32 v42, v42                              // 00000031810C: 7E54292A
	v_cvt_f32_ubyte3_e32 v43, v43                              // 000000318110: 7E56292B
	v_cvt_f32_ubyte1_e32 v84, v44                              // 000000318114: 7EA8252C
	v_cvt_f32_ubyte2_e32 v85, v44                              // 000000318118: 7EAA272C
	v_cvt_f32_ubyte3_e32 v44, v44                              // 00000031811C: 7E58292C
	v_cvt_f32_ubyte0_e32 v86, v37                              // 000000318120: 7EAC2325
	v_fma_mix_f32 v80, v81, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318124: CC206050 14F67B51
	v_fma_mix_f32 v81, v82, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031812C: CC206051 14F67B52
	v_fma_mix_f32 v82, v83, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318134: CC206052 14F67B53
	v_bfe_u32 v130, v47, 16, 1                                 // 00000031813C: D6100082 0205212F
	v_bfe_u32 v123, v77, 16, 1                                 // 000000318144: D610007B 0205214D
	v_add3_u32 v46, v46, v126, 0x7fff                          // 00000031814C: D655002E 03FEFD2E 00007FFF
	v_bfe_u32 v126, v79, 16, 1                                 // 000000318158: D610007E 0205214F
	v_add3_u32 v74, v74, v119, 0x7fff                          // 000000318160: D655004A 03FEEF4A 00007FFF
	v_add3_u32 v76, v76, v122, 0x7fff                          // 00000031816C: D655004C 03FEF54C 00007FFF
	v_and_or_b32 v72, 0xffff0000, v72, v52                     // 000000318178: D6570048 04D290FF FFFF0000
	.long 0x7e6839bc                                           // 000000318184: 7E6839BC
	v_cvt_f32_ubyte1_e32 v87, v37                              // 000000318188: 7EAE2525
	v_cvt_f32_ubyte0_e32 v89, v38                              // 00000031818C: 7EB22326
	v_fma_mix_f32 v41, v41, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318190: CC206029 14F67B29
	v_fma_mix_f32 v42, v42, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318198: CC20602A 14F67B2A
	v_fma_mix_f32 v43, v43, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003181A0: CC20602B 14F67B2B
	v_fma_mix_f32 v83, v84, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003181A8: CC206053 14F67B54
	v_fma_mix_f32 v84, v85, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003181B0: CC206054 14F67B55
	v_fma_mix_f32 v44, v44, v61, v61 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003181B8: CC20602C 14F67B2C
	v_fma_mix_f32 v61, v86, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003181C0: CC20603D 14EE7756
	v_bfe_u32 v121, v64, 16, 1                                 // 0000003181C8: D6100079 02052140
	v_bfe_u32 v134, v48, 16, 1                                 // 0000003181D0: D6100086 02052130
	v_bfe_u32 v127, v80, 16, 1                                 // 0000003181D8: D610007F 02052150
	v_add3_u32 v47, v47, v130, 0x7fff                          // 0000003181E0: D655002F 03FF052F 00007FFF
	v_bfe_u32 v130, v82, 16, 1                                 // 0000003181EC: D6100082 02052152
	v_add3_u32 v77, v77, v123, 0x7fff                          // 0000003181F4: D655004D 03FEF74D 00007FFF
	v_add3_u32 v79, v79, v126, 0x7fff                          // 000000318200: D655004F 03FEFD4F 00007FFF
	v_and_or_b32 v74, 0xffff0000, v74, v52                     // 00000031820C: D657004A 04D294FF FFFF0000
	.long 0x7e6839cc                                           // 000000318218: 7E6839CC
	v_cvt_f32_ubyte2_e32 v88, v37                              // 00000031821C: 7EB02725
	v_cvt_f32_ubyte1_e32 v90, v38                              // 000000318220: 7EB42526
	v_cvt_f32_ubyte0_e32 v92, v39                              // 000000318224: 7EB82327
	v_fma_mix_f32 v85, v87, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318228: CC206055 14EE7757
	v_fma_mix_f32 v87, v89, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318230: CC206057 14EE7759
	v_bfe_u32 v125, v67, 16, 1                                 // 000000318238: D610007D 02052143
	v_add3_u32 v64, v64, v121, 0x7fff                          // 000000318240: D6550040 03FEF340 00007FFF
	v_bfe_u32 v121, v41, 16, 1                                 // 00000031824C: D6100079 02052129
	v_bfe_u32 v131, v83, 16, 1                                 // 000000318254: D6100083 02052153
	v_add3_u32 v48, v48, v134, 0x7fff                          // 00000031825C: D6550030 03FF0D30 00007FFF
	v_bfe_u32 v134, v61, 16, 1                                 // 000000318268: D6100086 0205213D
	v_add3_u32 v80, v80, v127, 0x7fff                          // 000000318270: D6550050 03FEFF50 00007FFF
	v_add3_u32 v82, v82, v130, 0x7fff                          // 00000031827C: D6550052 03FF0552 00007FFF
	v_and_or_b32 v77, 0xffff0000, v77, v52                     // 000000318288: D657004D 04D29AFF FFFF0000
	.long 0x7e6839cf                                           // 000000318294: 7E6839CF
	v_cvt_f32_ubyte2_e32 v91, v38                              // 000000318298: 7EB62726
	v_cvt_f32_ubyte1_e32 v93, v39                              // 00000031829C: 7EBA2527
	v_cvt_f32_ubyte2_e32 v94, v39                              // 0000003182A0: 7EBC2727
	v_cvt_f32_ubyte0_e32 v95, v40                              // 0000003182A4: 7EBE2328
	v_cvt_f32_ubyte1_e32 v96, v40                              // 0000003182A8: 7EC02528
	v_cvt_f32_ubyte1_e32 v99, v17                              // 0000003182AC: 7EC62511
	v_fma_mix_f32 v86, v88, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003182B0: CC206056 14EE7758
	v_fma_mix_f32 v88, v90, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003182B8: CC206058 14EE775A
	v_fma_mix_f32 v90, v92, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003182C0: CC20605A 14EE775C
	v_bfe_u32 v129, v70, 16, 1                                 // 0000003182C8: D6100081 02052146
	v_add3_u32 v67, v67, v125, 0x7fff                          // 0000003182D0: D6550043 03FEFB43 00007FFF
	v_bfe_u32 v125, v42, 16, 1                                 // 0000003182DC: D610007D 0205212A
	v_bfe_u32 v135, v85, 16, 1                                 // 0000003182E4: D6100087 02052155
	v_add3_u32 v41, v41, v121, 0x7fff                          // 0000003182EC: D6550029 03FEF329 00007FFF
	v_bfe_u32 v121, v87, 16, 1                                 // 0000003182F8: D6100079 02052157
	v_add3_u32 v83, v83, v131, 0x7fff                          // 000000318300: D6550053 03FF0753 00007FFF
	v_add3_u32 v61, v61, v134, 0x7fff                          // 00000031830C: D655003D 03FF0D3D 00007FFF
	v_and_or_b32 v80, 0xffff0000, v80, v52                     // 000000318318: D6570050 04D2A0FF FFFF0000
	.long 0x7e6839d2                                           // 000000318324: 7E6839D2
	v_cvt_f32_ubyte3_e32 v37, v37                              // 000000318328: 7E4A2925
	v_cvt_f32_ubyte3_e32 v38, v38                              // 00000031832C: 7E4C2926
	v_cvt_f32_ubyte3_e32 v39, v39                              // 000000318330: 7E4E2927
	v_cvt_f32_ubyte2_e32 v97, v40                              // 000000318334: 7EC22728
	v_cvt_f32_ubyte3_e32 v40, v40                              // 000000318338: 7E502928
	v_cvt_f32_ubyte0_e32 v98, v17                              // 00000031833C: 7EC42311
	v_fma_mix_f32 v89, v91, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318340: CC206059 14EE775B
	v_fma_mix_f32 v91, v93, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318348: CC20605B 14EE775D
	v_fma_mix_f32 v92, v94, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318350: CC20605C 14EE775E
	v_fma_mix_f32 v93, v95, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318358: CC20605D 14EE775F
	v_fma_mix_f32 v94, v96, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318360: CC20605E 14EE7760
	v_fma_mix_f32 v96, v99, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318368: CC206060 14E67363
	v_bfe_u32 v133, v73, 16, 1                                 // 000000318370: D6100085 02052149
	v_add3_u32 v70, v70, v129, 0x7fff                          // 000000318378: D6550046 03FF0346 00007FFF
	v_bfe_u32 v129, v43, 16, 1                                 // 000000318384: D6100081 0205212B
	v_bfe_u32 v122, v88, 16, 1                                 // 00000031838C: D610007A 02052158
	v_add3_u32 v42, v42, v125, 0x7fff                          // 000000318394: D655002A 03FEFB2A 00007FFF
	v_bfe_u32 v125, v90, 16, 1                                 // 0000003183A0: D610007D 0205215A
	v_add3_u32 v85, v85, v135, 0x7fff                          // 0000003183A8: D6550055 03FF0F55 00007FFF
	v_add3_u32 v87, v87, v121, 0x7fff                          // 0000003183B4: D6550057 03FEF357 00007FFF
	.long 0x7ec639c0                                           // 0000003183C0: 7EC639C0
	v_and_or_b32 v64, 0xffff0000, v83, v52                     // 0000003183C4: D6570040 04D2A6FF FFFF0000
	.long 0x7e6839bd                                           // 0000003183D0: 7E6839BD
	v_cvt_f32_ubyte0_e32 v101, v18                             // 0000003183D4: 7ECA2312
	v_cvt_f32_ubyte2_e32 v103, v18                             // 0000003183D8: 7ECE2712
	v_cvt_f32_ubyte1_e32 v105, v19                             // 0000003183DC: 7ED22513
	v_fma_mix_f32 v37, v37, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003183E0: CC206025 14EE7725
	v_fma_mix_f32 v38, v38, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003183E8: CC206026 14EE7726
	v_fma_mix_f32 v39, v39, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003183F0: CC206027 14EE7727
	v_fma_mix_f32 v95, v97, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003183F8: CC20605F 14EE7761
	v_fma_mix_f32 v40, v40, v59, v59 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318400: CC206028 14EE7728
	v_fma_mix_f32 v59, v98, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318408: CC20603B 14E67362
	v_add3_u32 v73, v73, v133, 0x7fff                          // 000000318410: D6550049 03FF0B49 00007FFF
	v_bfe_u32 v133, v44, 16, 1                                 // 00000031841C: D6100085 0205212C
	v_bfe_u32 v126, v91, 16, 1                                 // 000000318424: D610007E 0205215B
	v_bfe_u32 v127, v92, 16, 1                                 // 00000031842C: D610007F 0205215C
	v_add3_u32 v43, v43, v129, 0x7fff                          // 000000318434: D655002B 03FF032B 00007FFF
	v_bfe_u32 v129, v93, 16, 1                                 // 000000318440: D6100081 0205215D
	v_add3_u32 v88, v88, v122, 0x7fff                          // 000000318448: D6550058 03FEF558 00007FFF
	v_add3_u32 v90, v90, v125, 0x7fff                          // 000000318454: D655005A 03FEFB5A 00007FFF
	v_and_or_b32 v61, 0xffff0000, v85, v52                     // 000000318460: D657003D 04D2AAFF FFFF0000
	.long 0x7e6839d7                                           // 00000031846C: 7E6839D7
	v_cvt_f32_ubyte2_e32 v100, v17                             // 000000318470: 7EC82711
	v_cvt_f32_ubyte1_e32 v102, v18                             // 000000318474: 7ECC2512
	v_cvt_f32_ubyte3_e32 v18, v18                              // 000000318478: 7E242912
	v_cvt_f32_ubyte0_e32 v104, v19                             // 00000031847C: 7ED02313
	v_cvt_f32_ubyte2_e32 v106, v19                             // 000000318480: 7ED42713
	v_fma_mix_f32 v98, v101, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318484: CC206062 14E67365
	v_fma_mix_f32 v101, v103, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031848C: CC206065 14E67367
	v_fma_mix_f32 v103, v105, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318494: CC206067 14E67369
	v_bfe_u32 v120, v75, 16, 1                                 // 00000031849C: D6100078 0205214B
	v_bfe_u32 v130, v94, 16, 1                                 // 0000003184A4: D6100082 0205215E
	v_add3_u32 v44, v44, v133, 0x7fff                          // 0000003184AC: D655002C 03FF0B2C 00007FFF
	v_bfe_u32 v133, v59, 16, 1                                 // 0000003184B8: D6100085 0205213B
	v_add3_u32 v71, v91, v126, 0x7fff                          // 0000003184C0: D6550047 03FEFD5B 00007FFF
	v_add3_u32 v91, v92, v127, 0x7fff                          // 0000003184CC: D655005B 03FEFF5C 00007FFF
	v_add3_u32 v92, v93, v129, 0x7fff                          // 0000003184D8: D655005C 03FF035D 00007FFF
	.long 0x7ed239c3                                           // 0000003184E4: 7ED239C3
	v_and_or_b32 v67, 0xffff0000, v88, v52                     // 0000003184E8: D6570043 04D2B0FF FFFF0000
	.long 0x7e6839da                                           // 0000003184F4: 7E6839DA
	v_fma_mix_f32 v97, v100, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003184F8: CC206061 14E67364
	v_fma_mix_f32 v100, v102, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318500: CC206064 14E67366
	v_fma_mix_f32 v18, v18, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318508: CC206012 14E67312
	v_fma_mix_f32 v102, v104, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318510: CC206066 14E67368
	v_fma_mix_f32 v104, v106, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318518: CC206068 14E6736A
	v_add3_u32 v75, v75, v120, 0x7fff                          // 000000318520: D655004B 03FEF14B 00007FFF
	v_bfe_u32 v120, v37, 16, 1                                 // 00000031852C: D6100078 02052125
	v_bfe_u32 v134, v96, 16, 1                                 // 000000318534: D6100086 02052160
	v_bfe_u32 v62, v98, 16, 1                                  // 00000031853C: D610003E 02052162
	v_add3_u32 v60, v94, v130, 0x7fff                          // 000000318544: D655003C 03FF055E 00007FFF
	v_add3_u32 v59, v59, v133, 0x7fff                          // 000000318550: D655003B 03FF0B3B 00007FFF
	.long 0x7ed439c6                                           // 00000031855C: 7ED439C6
	v_and_or_b32 v70, 0xffff0000, v71, v52                     // 000000318560: D6570046 04D28EFF FFFF0000
	.long 0x7e6839dc                                           // 00000031856C: 7E6839DC
	v_bfe_u32 v119, v86, 16, 1                                 // 000000318570: D6100077 02052156
	v_add3_u32 v37, v37, v120, 0x7fff                          // 000000318578: D6550025 03FEF125 00007FFF
	v_bfe_u32 v120, v100, 16, 1                                // 000000318584: D6100078 02052164
	v_bfe_u32 v65, v18, 16, 1                                  // 00000031858C: D6100041 02052112
	v_bfe_u32 v122, v102, 16, 1                                // 000000318594: D610007A 02052166
	v_add3_u32 v76, v96, v134, 0x7fff                          // 00000031859C: D655004C 03FF0D60 00007FFF
	v_add3_u32 v62, v98, v62, 0x7fff                           // 0000003185A8: D655003E 03FE7D62 00007FFF
	v_and_or_b32 v60, 0xffff0000, v60, v52                     // 0000003185B4: D657003C 04D278FF FFFF0000
	.long 0x7e6839bb                                           // 0000003185C0: 7E6839BB
	.long 0x7fc639b4                                           // 0000003185C4: 7FC639B4
	v_add3_u32 v86, v86, v119, 0x7fff                          // 0000003185C8: D6550056 03FEEF56 00007FFF
	v_add3_u32 v79, v100, v120, 0x7fff                         // 0000003185D4: D655004F 03FEF164 00007FFF
	v_add3_u32 v18, v18, v65, 0x7fff                           // 0000003185E0: D6550012 03FE8312 00007FFF
	v_add3_u32 v65, v102, v122, 0x7fff                         // 0000003185EC: D6550041 03FEF566 00007FFF
	v_and_or_b32 v59, 0xffff0000, v76, v52                     // 0000003185F8: D657003B 04D298FF FFFF0000
	.long 0x7e6839be                                           // 000000318604: 7E6839BE
	.long 0x7fda39b4                                           // 000000318608: 7FDA39B4
	.long 0x7fe239b4                                           // 00000031860C: 7FE239B4
	v_bfe_u32 v124, v78, 16, 1                                 // 000000318610: D610007C 0205214E
	.long 0x7eda39cb                                           // 000000318618: 7EDA39CB
	.long 0x7ee239d6                                           // 00000031861C: 7EE239D6
	v_and_or_b32 v45, 0xffff0000, v45, v99                     // 000000318620: D657002D 058E5AFF FFFF0000
	v_and_or_b32 v62, 0xffff0000, v79, v52                     // 00000031862C: D657003E 04D29EFF FFFF0000
	.long 0x7e6839c1                                           // 000000318638: 7E6839C1
	.long 0x7fd239b4                                           // 00000031863C: 7FD239B4
	v_bfe_u32 v123, v89, 16, 1                                 // 000000318640: D610007B 02052159
	v_add3_u32 v78, v78, v124, 0x7fff                          // 000000318648: D655004E 03FEF94E 00007FFF
	.long 0x7ed839c9                                           // 000000318654: 7ED839C9
	v_and_or_b32 v41, 0xffff0000, v41, v109                    // 000000318658: D6570029 05B652FF FFFF0000
	v_and_or_b32 v37, 0xffff0000, v37, v113                    // 000000318664: D6570025 05C64AFF FFFF0000
	.long 0x7fdc39b4                                           // 000000318670: 7FDC39B4
	v_bfe_u32 v128, v81, 16, 1                                 // 000000318674: D6100080 02052151
	v_bfe_u32 v124, v38, 16, 1                                 // 00000031867C: D610007C 02052126
	v_add3_u32 v89, v89, v123, 0x7fff                          // 000000318684: D6550059 03FEF759 00007FFF
	.long 0x7edc39ce                                           // 000000318690: 7EDC39CE
	v_and_or_b32 v46, 0xffff0000, v46, v105                    // 000000318694: D657002E 05A65CFF FFFF0000
	.long 0x7fd439b4                                           // 0000003186A0: 7FD439B4
	.long 0x7fe439b4                                           // 0000003186A4: 7FE439B4
	v_add3_u32 v81, v81, v128, 0x7fff                          // 0000003186A8: D6550051 03FF0151 00007FFF
	v_add3_u32 v38, v38, v124, 0x7fff                          // 0000003186B4: D6550026 03FEF926 00007FFF
	.long 0x7ee439d9                                           // 0000003186C0: 7EE439D9
	v_and_or_b32 v42, 0xffff0000, v42, v110                    // 0000003186C4: D657002A 05BA54FF FFFF0000
	v_cvt_f32_ubyte3_e32 v17, v17                              // 0000003186D0: 7E222911
	.long 0x7fde39b4                                           // 0000003186D4: 7FDE39B4
	v_bfe_u32 v132, v84, 16, 1                                 // 0000003186D8: D6100084 02052154
	.long 0x7ede39d1                                           // 0000003186E0: 7EDE39D1
	v_and_or_b32 v47, 0xffff0000, v47, v106                    // 0000003186E4: D657002F 05AA5EFF FFFF0000
	v_and_or_b32 v38, 0xffff0000, v38, v114                    // 0000003186F0: D6570026 05CA4CFF FFFF0000
	v_cvt_f32_ubyte3_e32 v19, v19                              // 0000003186FC: 7E262913
	v_fma_mix_f32 v17, v17, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318700: CC206011 14E67311
	.long 0x7fd839b4                                           // 000000318708: 7FD839B4
	v_bfe_u32 v128, v39, 16, 1                                 // 00000031870C: D6100080 02052127
	v_add3_u32 v84, v84, v132, 0x7fff                          // 000000318714: D6550054 03FF0954 00007FFF
	v_bfe_u32 v135, v97, 16, 1                                 // 000000318720: D6100087 02052161
	v_and_or_b32 v43, 0xffff0000, v43, v111                    // 000000318728: D657002B 05BE56FF FFFF0000
	v_cvt_f32_ubyte0_e32 v107, v20                             // 000000318734: 7ED62314
	.long 0x7fe039b4                                           // 000000318738: 7FE039B4
	.long 0x7fe639b4                                           // 00000031873C: 7FE639B4
	v_fma_mix_f32 v19, v19, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318740: CC206013 14E67313
	v_bfe_u32 v119, v17, 16, 1                                 // 000000318748: D6100077 02052111
	v_bfe_u32 v68, v104, 16, 1                                 // 000000318750: D6100044 02052168
	v_add3_u32 v39, v39, v128, 0x7fff                          // 000000318758: D6550027 03FF0127 00007FFF
	v_add3_u32 v94, v97, v135, 0x7fff                          // 000000318764: D655005E 03FF0F61 00007FFF
	.long 0x7ee039d4                                           // 000000318770: 7EE039D4
	.long 0x7ee639db                                           // 000000318774: 7EE639DB
	v_and_or_b32 v48, 0xffff0000, v48, v108                    // 000000318778: D6570030 05B260FF FFFF0000
	.long 0x7fea39b4                                           // 000000318784: 7FEA39B4
	v_fma_mix_f32 v107, v107, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318788: CC20606B 14E6736B
	v_bfe_u32 v131, v95, 16, 1                                 // 000000318790: D6100083 0205215F
	v_bfe_u32 v121, v101, 16, 1                                // 000000318798: D6100079 02052165
	v_bfe_u32 v124, v19, 16, 1                                 // 0000003187A0: D610007C 02052113
	v_add3_u32 v17, v17, v119, 0x7fff                          // 0000003187A8: D6550011 03FEEF11 00007FFF
	v_add3_u32 v68, v104, v68, 0x7fff                          // 0000003187B4: D6550044 03FE8968 00007FFF
	.long 0x7eea39de                                           // 0000003187C0: 7EEA39DE
	v_and_or_b32 v44, 0xffff0000, v44, v112                    // 0000003187C4: D657002C 05C258FF FFFF0000
	v_and_or_b32 v39, 0xffff0000, v39, v115                    // 0000003187D0: D6570027 05CE4EFF FFFF0000
	v_bfe_u32 v123, v103, 16, 1                                // 0000003187DC: D610007B 02052167
	v_add3_u32 v93, v95, v131, 0x7fff                          // 0000003187E4: D655005D 03FF075F 00007FFF
	v_add3_u32 v95, v101, v121, 0x7fff                         // 0000003187F0: D655005F 03FEF365 00007FFF
	v_add3_u32 v19, v19, v124, 0x7fff                          // 0000003187FC: D6550013 03FEF913 00007FFF
	v_and_or_b32 v17, 0xffff0000, v17, v117                    // 000000318808: D6570011 05D622FF FFFF0000
	.long 0x7fec39b4                                           // 000000318814: 7FEC39B4
	v_add3_u32 v82, v103, v123, 0x7fff                         // 000000318818: D6550052 03FEF767 00007FFF
	.long 0x7eec39df                                           // 000000318824: 7EEC39DF
	v_bfe_u32 v132, v40, 16, 1                                 // 000000318828: D6100084 02052128
	.long 0x7fe839b4                                           // 000000318830: 7FE839B4
	.long 0x7ee839dd                                           // 000000318834: 7EE839DD
	s_mov_b32 s3, exec_lo                                      // 000000318838: BE83007E
	v_and_or_b32 v18, 0xffff0000, v18, v118                    // 00000031883C: D6570012 05DA24FF FFFF0000
	v_add3_u32 v40, v40, v132, 0x7fff                          // 000000318848: D6550028 03FF0928 00007FFF
	s_waitcnt vmcnt(3)                                         // 000000318854: BF890FF7
	v_dot2_f32_bf16 v65, v21, v63, 0                           // 000000318858: CC1A4041 1A027F15
	s_waitcnt vmcnt(2)                                         // 000000318860: BF890BF7
	v_dot2_f32_bf16 v63, v33, v63, 0                           // 000000318864: CC1A403F 1A027F21
	v_dot2_f32_bf16 v71, v21, v74, 0                           // 00000031886C: CC1A4047 1A029515
	v_dot2_f32_bf16 v73, v33, v74, 0                           // 000000318874: CC1A4049 1A029521
	v_dot2_f32_bf16 v74, v21, v61, 0                           // 00000031887C: CC1A404A 1A027B15
	v_dot2_f32_bf16 v61, v33, v61, 0                           // 000000318884: CC1A403D 1A027B21
	v_dot2_f32_bf16 v65, v22, v45, v65                         // 00000031888C: CC1A4041 1D065B16
	v_dot2_f32_bf16 v45, v34, v45, v63                         // 000000318894: CC1A402D 1CFE5B22
	v_dot2_f32_bf16 v63, v22, v41, v71                         // 00000031889C: CC1A403F 1D1E5316
	v_dot2_f32_bf16 v41, v34, v41, v73                         // 0000003188A4: CC1A4029 1D265322
	v_dot2_f32_bf16 v71, v22, v37, v74                         // 0000003188AC: CC1A4047 1D2A4B16
	v_dot2_f32_bf16 v37, v34, v37, v61                         // 0000003188B4: CC1A4025 1CF64B22
	v_dot2_f32_bf16 v61, v23, v66, v65                         // 0000003188BC: CC1A403D 1D068517
	v_dot2_f32_bf16 v45, v35, v66, v45                         // 0000003188C4: CC1A402D 1CB68523
	v_dot2_f32_bf16 v63, v23, v77, v63                         // 0000003188CC: CC1A403F 1CFE9B17
	v_dot2_f32_bf16 v41, v35, v77, v41                         // 0000003188D4: CC1A4029 1CA69B23
	v_dot2_f32_bf16 v65, v23, v67, v71                         // 0000003188DC: CC1A4041 1D1E8717
	v_dot2_f32_bf16 v61, v24, v46, v61                         // 0000003188E4: CC1A403D 1CF65D18
	v_dot2_f32_bf16 v45, v36, v46, v45                         // 0000003188EC: CC1A402D 1CB65D24
	v_dot2_f32_bf16 v37, v35, v67, v37                         // 0000003188F4: CC1A4025 1C968723
	v_dot2_f32_bf16 v46, v24, v42, v63                         // 0000003188FC: CC1A402E 1CFE5518
	v_dot2_f32_bf16 v41, v36, v42, v41                         // 000000318904: CC1A4029 1CA65524
	s_waitcnt vmcnt(1)                                         // 00000031890C: BF8907F7
	v_dot2_f32_bf16 v61, v25, v69, v61                         // 000000318910: CC1A403D 1CF68B19
	s_waitcnt vmcnt(0)                                         // 000000318918: BF8903F7
	v_dot2_f32_bf16 v45, v29, v69, v45                         // 00000031891C: CC1A402D 1CB68B1D
	v_dot2_f32_bf16 v42, v24, v38, v65                         // 000000318924: CC1A402A 1D064D18
	v_dot2_f32_bf16 v46, v25, v80, v46                         // 00000031892C: CC1A402E 1CBAA119
	v_dot2_f32_bf16 v37, v36, v38, v37                         // 000000318934: CC1A4025 1C964D24
	v_dot2_f32_bf16 v38, v29, v80, v41                         // 00000031893C: CC1A4026 1CA6A11D
	v_dot2_f32_bf16 v41, v26, v47, v61                         // 000000318944: CC1A4029 1CF65F1A
	v_dot2_f32_bf16 v45, v30, v47, v45                         // 00000031894C: CC1A402D 1CB65F1E
	v_dot2_f32_bf16 v46, v26, v43, v46                         // 000000318954: CC1A402E 1CBA571A
	v_dot2_f32_bf16 v42, v25, v70, v42                         // 00000031895C: CC1A402A 1CAA8D19
	v_dot2_f32_bf16 v37, v29, v70, v37                         // 000000318964: CC1A4025 1C968D1D
	v_dot2_f32_bf16 v41, v27, v72, v41                         // 00000031896C: CC1A4029 1CA6911B
	v_dot2_f32_bf16 v45, v31, v72, v45                         // 000000318974: CC1A402D 1CB6911F
	v_dot2_f32_bf16 v46, v27, v64, v46                         // 00000031897C: CC1A402E 1CBA811B
	v_dot2_f32_bf16 v38, v30, v43, v38                         // 000000318984: CC1A4026 1C9A571E
	v_dot2_f32_bf16 v42, v26, v39, v42                         // 00000031898C: CC1A402A 1CAA4F1A
	v_dot2_f32_bf16 v41, v28, v48, v41                         // 000000318994: CC1A4029 1CA6611C
	v_dot2_f32_bf16 v43, v32, v48, v45                         // 00000031899C: CC1A402B 1CB66120
	v_dot2_f32_bf16 v45, v28, v44, v46                         // 0000003189A4: CC1A402D 1CBA591C
	v_dot2_f32_bf16 v46, v30, v39, v37                         // 0000003189AC: CC1A402E 1C964F1E
	v_dot2_f32_bf16 v47, v31, v64, v38                         // 0000003189B4: CC1A402F 1C9A811F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000003189BC: BF870004
	v_dual_add_f32 v39, 0, v41 :: v_dual_add_f32 v38, 0, v43   // 0000003189C0: C9085280 27265680
	.long 0x7e5239c4                                           // 0000003189C8: 7E5239C4
	.long 0x7f5239b4                                           // 0000003189CC: 7F5239B4
	v_bfe_u32 v43, v107, 16, 1                                 // 0000003189D0: D610002B 0205216B
	v_dot2_f32_bf16 v21, v21, v59, 0                           // 0000003189D8: CC1A4015 1A027715
	v_dot2_f32_bf16 v33, v33, v59, 0                           // 0000003189E0: CC1A4021 1A027721
	v_cvt_f32_ubyte1_e32 v48, v20                              // 0000003189E8: 7E602514
	v_and_or_b32 v19, 0xffff0000, v19, v41                     // 0000003189EC: D6570013 04A626FF FFFF0000
	v_add3_u32 v41, v107, v43, 0x7fff                          // 0000003189F8: D6550029 03FE576B 00007FFF
	v_cvt_f32_ubyte2_e32 v43, v20                              // 000000318A04: 7E562714
	v_dot2_f32_bf16 v21, v22, v17, v21                         // 000000318A08: CC1A4015 1C562316
	v_dot2_f32_bf16 v17, v34, v17, v33                         // 000000318A10: CC1A4011 1C862322
	v_add_f32_e32 v37, 0, v45                                  // 000000318A18: 064A5A80
	v_and_or_b32 v45, 0xffff0000, v82, v52                     // 000000318A1C: D657002D 04D2A4FF FFFF0000
	.long 0x7e6839a9                                           // 000000318A28: 7E6839A9
	v_fma_mix_f32 v41, v43, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318A2C: CC206029 14E6732B
	v_fma_mix_f32 v22, v48, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318A34: CC206016 14E67330
	v_cvt_f32_ubyte3_e32 v20, v20                              // 000000318A3C: 7E282914
	v_dot2_f32_bf16 v21, v23, v62, v21                         // 000000318A40: CC1A4015 1C567D17
	v_dot2_f32_bf16 v17, v35, v62, v17                         // 000000318A48: CC1A4011 1C467D23
	v_bfe_u32 v33, v41, 16, 1                                  // 000000318A50: D6100021 02052129
	v_bfe_u32 v23, v22, 16, 1                                  // 000000318A58: D6100017 02052116
	v_fma_mix_f32 v20, v20, v57, v57 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318A60: CC206014 14E67314
	v_dot2_f32_bf16 v21, v24, v18, v21                         // 000000318A68: CC1A4015 1C562518
	v_dot2_f32_bf16 v17, v36, v18, v17                         // 000000318A70: CC1A4011 1C462524
	v_add3_u32 v33, v41, v33, 0x7fff                           // 000000318A78: D6550021 03FE4329 00007FFF
	v_add3_u32 v18, v22, v23, 0x7fff                           // 000000318A84: D6550012 03FE2F16 00007FFF
	v_bfe_u32 v22, v20, 16, 1                                  // 000000318A90: D6100016 02052114
	v_dot2_f32_bf16 v21, v25, v45, v21                         // 000000318A98: CC1A4015 1C565B19
	v_dot2_f32_bf16 v17, v29, v45, v17                         // 000000318AA0: CC1A4011 1C465B1D
	.long 0x7e2e39a1                                           // 000000318AA8: 7E2E39A1
	.long 0x7f2e39b4                                           // 000000318AAC: 7F2E39B4
	v_add3_u32 v20, v20, v22, 0x7fff                           // 000000318AB0: D6550014 03FE2D14 00007FFF
	v_and_or_b32 v18, 0xffff0000, v18, v52                     // 000000318ABC: D6570012 04D224FF FFFF0000
	v_dot2_f32_bf16 v21, v26, v19, v21                         // 000000318AC8: CC1A4015 1C56271A
	v_dot2_f32_bf16 v17, v30, v19, v17                         // 000000318AD0: CC1A4011 1C46271E
	v_and_or_b32 v40, 0xffff0000, v40, v116                    // 000000318AD8: D6570028 05D250FF FFFF0000
	v_dot2_f32_bf16 v19, v27, v60, v42                         // 000000318AE4: CC1A4013 1CAA791B
	v_dot2_f32_bf16 v22, v31, v60, v46                         // 000000318AEC: CC1A4016 1CBA791F
	v_and_or_b32 v20, 0xffff0000, v20, v23                     // 000000318AF4: D6570014 045E28FF FFFF0000
	v_dot2_f32_bf16 v21, v27, v18, v21                         // 000000318B00: CC1A4015 1C56251B
	v_dot2_f32_bf16 v17, v31, v18, v17                         // 000000318B08: CC1A4011 1C46251F
	v_dot2_f32_bf16 v18, v32, v44, v47                         // 000000318B10: CC1A4012 1CBE5920
	v_dot2_f32_bf16 v19, v28, v40, v19                         // 000000318B18: CC1A4013 1C4E511C
	v_dot2_f32_bf16 v22, v32, v40, v22                         // 000000318B20: CC1A4016 1C5A5120
	v_dot2_f32_bf16 v21, v28, v20, v21                         // 000000318B28: CC1A4015 1C56291C
	v_dot2_f32_bf16 v17, v32, v20, v17                         // 000000318B30: CC1A4011 1C462920
	v_add_f32_e32 v40, 0, v18                                  // 000000318B38: 06502480
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000318B3C: BF870214
	v_dual_add_f32 v36, 0, v19 :: v_dual_add_f32 v35, 0, v22   // 000000318B40: C9082680 24222C80
	v_add_f32_e32 v34, 0, v21                                  // 000000318B48: 06442A80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000318B4C: BF870004
	v_add_f32_e32 v33, 0, v17                                  // 000000318B50: 06422280
	v_cmpx_gt_u32_e32 20, v56                                  // 000000318B54: 7D987094
	s_cbranch_execz 813                                        // 000000318B58: BFA5032D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x1c10>
	.long 0xd7000419                                           // 000000318B5C: D7000419
	v_cndmask_b32_e32 v1, s6, v58, vcc_lo                      // 000000318B60: 02027406
	s_delay_alu instid0(VALU_DEP_1)                            // 000000318B64: BF870001
	v_add_co_ci_u32_e64 v26, null, s7, 0, s4                   // 000000318B68: D5207C1A 00110007
	v_cvt_f32_ubyte0_e32 v42, v13                              // 000000318B70: 7E54230D
	v_cvt_f32_ubyte1_e32 v43, v13                              // 000000318B74: 7E56250D
	v_cvt_f32_ubyte2_e32 v44, v13                              // 000000318B78: 7E58270D
	s_clause 0x3                                               // 000000318B7C: BF850003
	global_load_b128 v[17:20], v[25:26], off offset:512        // 000000318B80: DC5E0200 117C0019
	global_load_b128 v[29:32], v[25:26], off offset:1152       // 000000318B88: DC5E0480 1D7C0019
	global_load_b128 v[21:24], v[25:26], off offset:528        // 000000318B90: DC5E0210 157C0019
	global_load_b128 v[25:28], v[25:26], off offset:1168       // 000000318B98: DC5E0490 197C0019
	v_cvt_f32_ubyte3_e32 v45, v13                              // 000000318BA0: 7E5A290D
	v_cvt_f32_ubyte0_e32 v46, v14                              // 000000318BA4: 7E5C230E
	v_cvt_f32_ubyte1_e32 v47, v14                              // 000000318BA8: 7E5E250E
	v_cvt_f32_ubyte2_e32 v48, v14                              // 000000318BAC: 7E60270E
	v_cvt_f32_ubyte3_e32 v56, v14                              // 000000318BB0: 7E70290E
	v_cvt_f32_ubyte0_e32 v57, v15                              // 000000318BB4: 7E72230F
	v_cvt_f32_ubyte1_e32 v58, v15                              // 000000318BB8: 7E74250F
	v_cvt_f32_ubyte2_e32 v59, v15                              // 000000318BBC: 7E76270F
	v_cvt_f32_ubyte3_e32 v60, v15                              // 000000318BC0: 7E78290F
	v_cvt_f32_ubyte0_e32 v61, v16                              // 000000318BC4: 7E7A2310
	v_cvt_f32_ubyte1_e32 v62, v16                              // 000000318BC8: 7E7C2510
	v_cvt_f32_ubyte2_e32 v63, v16                              // 000000318BCC: 7E7E2710
	v_cvt_f32_ubyte3_e32 v64, v16                              // 000000318BD0: 7E802910
	v_cvt_f32_ubyte0_e32 v65, v9                               // 000000318BD4: 7E822309
	v_cvt_f32_ubyte1_e32 v66, v9                               // 000000318BD8: 7E842509
	v_cvt_f32_ubyte2_e32 v67, v9                               // 000000318BDC: 7E862709
	v_cvt_f32_ubyte3_e32 v68, v9                               // 000000318BE0: 7E882909
	v_cvt_f32_ubyte0_e32 v69, v10                              // 000000318BE4: 7E8A230A
	v_cvt_f32_ubyte1_e32 v70, v10                              // 000000318BE8: 7E8C250A
	v_cvt_f32_ubyte2_e32 v71, v10                              // 000000318BEC: 7E8E270A
	v_cvt_f32_ubyte3_e32 v72, v10                              // 000000318BF0: 7E90290A
	v_cvt_f32_ubyte0_e32 v73, v11                              // 000000318BF4: 7E92230B
	v_cvt_f32_ubyte1_e32 v74, v11                              // 000000318BF8: 7E94250B
	v_cvt_f32_ubyte2_e32 v75, v11                              // 000000318BFC: 7E96270B
	v_cvt_f32_ubyte3_e32 v11, v11                              // 000000318C00: 7E16290B
	v_cvt_f32_ubyte0_e32 v76, v12                              // 000000318C04: 7E98230C
	v_cvt_f32_ubyte1_e32 v77, v12                              // 000000318C08: 7E9A250C
	v_cvt_f32_ubyte2_e32 v78, v12                              // 000000318C0C: 7E9C270C
	v_cvt_f32_ubyte3_e32 v12, v12                              // 000000318C10: 7E18290C
	v_cvt_f32_ubyte0_e32 v80, v5                               // 000000318C14: 7EA02305
	v_cvt_f32_ubyte2_e32 v82, v5                               // 000000318C18: 7EA42705
	v_cvt_f32_ubyte1_e32 v85, v6                               // 000000318C1C: 7EAA2506
	v_cvt_f32_ubyte0_e32 v88, v7                               // 000000318C20: 7EB02307
	v_cvt_f32_ubyte2_e32 v90, v7                               // 000000318C24: 7EB42707
	v_cvt_f32_ubyte1_e32 v93, v8                               // 000000318C28: 7EBA2508
	v_cvt_f32_ubyte1_e32 v97, v1                               // 000000318C2C: 7EC22501
	v_cvt_f32_ubyte1_e32 v101, v2                              // 000000318C30: 7ECA2502
	v_cvt_f32_ubyte1_e32 v105, v3                              // 000000318C34: 7ED22503
	v_fma_mix_f32 v42, v42, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C38: CC20602A 14DA6D2A
	v_cvt_f32_ubyte1_e32 v81, v5                               // 000000318C40: 7EA22505
	v_cvt_f32_ubyte0_e32 v84, v6                               // 000000318C44: 7EA82306
	v_cvt_f32_ubyte2_e32 v86, v6                               // 000000318C48: 7EAC2706
	v_cvt_f32_ubyte1_e32 v89, v7                               // 000000318C4C: 7EB22507
	v_cvt_f32_ubyte0_e32 v92, v8                               // 000000318C50: 7EB82308
	v_cvt_f32_ubyte2_e32 v94, v8                               // 000000318C54: 7EBC2708
	v_cvt_f32_ubyte2_e32 v98, v1                               // 000000318C58: 7EC42701
	v_cvt_f32_ubyte2_e32 v102, v2                              // 000000318C5C: 7ECC2702
	v_cvt_f32_ubyte2_e32 v106, v3                              // 000000318C60: 7ED42703
	v_fma_mix_f32 v43, v43, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C64: CC20602B 14DA6D2B
	v_fma_mix_f32 v44, v44, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C6C: CC20602C 14DA6D2C
	v_fma_mix_f32 v45, v45, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C74: CC20602D 14DA6D2D
	v_fma_mix_f32 v46, v46, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C7C: CC20602E 14DA6D2E
	v_fma_mix_f32 v47, v47, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C84: CC20602F 14DA6D2F
	v_fma_mix_f32 v48, v48, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C8C: CC206030 14DA6D30
	v_fma_mix_f32 v56, v56, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C94: CC206038 14DA6D38
	v_fma_mix_f32 v57, v57, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318C9C: CC206039 14DA6D39
	v_fma_mix_f32 v58, v58, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CA4: CC20603A 14DA6D3A
	v_fma_mix_f32 v59, v59, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CAC: CC20603B 14DA6D3B
	v_fma_mix_f32 v60, v60, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CB4: CC20603C 14DA6D3C
	v_fma_mix_f32 v61, v61, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CBC: CC20603D 14DA6D3D
	v_fma_mix_f32 v62, v62, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CC4: CC20603E 14DA6D3E
	v_fma_mix_f32 v63, v63, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CCC: CC20603F 14DA6D3F
	v_fma_mix_f32 v54, v64, v54, v54 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CD4: CC206036 14DA6D40
	v_fma_mix_f32 v64, v65, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CDC: CC206040 14DE6F41
	v_fma_mix_f32 v65, v66, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CE4: CC206041 14DE6F42
	v_fma_mix_f32 v66, v67, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CEC: CC206042 14DE6F43
	v_fma_mix_f32 v67, v68, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CF4: CC206043 14DE6F44
	v_fma_mix_f32 v68, v69, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318CFC: CC206044 14DE6F45
	v_fma_mix_f32 v69, v70, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D04: CC206045 14DE6F46
	v_fma_mix_f32 v70, v71, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D0C: CC206046 14DE6F47
	v_fma_mix_f32 v71, v72, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D14: CC206047 14DE6F48
	v_fma_mix_f32 v72, v73, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D1C: CC206048 14DE6F49
	v_fma_mix_f32 v73, v74, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D24: CC206049 14DE6F4A
	v_fma_mix_f32 v74, v75, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D2C: CC20604A 14DE6F4B
	v_fma_mix_f32 v11, v11, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D34: CC20600B 14DE6F0B
	v_fma_mix_f32 v75, v76, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D3C: CC20604B 14DE6F4C
	v_fma_mix_f32 v76, v77, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D44: CC20604C 14DE6F4D
	v_fma_mix_f32 v77, v78, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D4C: CC20604D 14DE6F4E
	v_fma_mix_f32 v12, v12, v55, v55 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D54: CC20600C 14DE6F0C
	v_fma_mix_f32 v55, v80, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D5C: CC206037 14D66B50
	v_fma_mix_f32 v80, v82, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D64: CC206050 14D66B52
	v_fma_mix_f32 v82, v85, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D6C: CC206052 14D66B55
	v_fma_mix_f32 v85, v88, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D74: CC206055 14D66B58
	v_fma_mix_f32 v88, v90, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D7C: CC206058 14D66B5A
	v_fma_mix_f32 v90, v93, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D84: CC20605A 14D66B5D
	v_fma_mix_f32 v93, v97, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D8C: CC20605D 14CE6761
	v_fma_mix_f32 v97, v101, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D94: CC206061 14CE6765
	v_fma_mix_f32 v101, v105, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318D9C: CC206065 14CE6769
	v_bfe_u32 v105, v42, 16, 1                                 // 000000318DA4: D6100069 0205212A
	v_fma_mix_f32 v78, v81, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DAC: CC20604E 14D66B51
	v_fma_mix_f32 v81, v84, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DB4: CC206051 14D66B54
	v_fma_mix_f32 v84, v86, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DBC: CC206054 14D66B56
	v_fma_mix_f32 v86, v89, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DC4: CC206056 14D66B59
	v_fma_mix_f32 v89, v92, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DCC: CC206059 14D66B5C
	v_fma_mix_f32 v92, v94, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DD4: CC20605C 14D66B5E
	v_fma_mix_f32 v94, v98, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DDC: CC20605E 14CE6762
	v_fma_mix_f32 v98, v102, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DE4: CC206062 14CE6766
	v_fma_mix_f32 v102, v106, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318DEC: CC206066 14CE676A
	v_bfe_u32 v106, v43, 16, 1                                 // 000000318DF4: D610006A 0205212B
	v_bfe_u32 v110, v46, 16, 1                                 // 000000318DFC: D610006E 0205212E
	v_add3_u32 v42, v42, v105, 0x7fff                          // 000000318E04: D655002A 03FED32A 00007FFF
	v_bfe_u32 v111, v47, 16, 1                                 // 000000318E10: D610006F 0205212F
	v_bfe_u32 v114, v57, 16, 1                                 // 000000318E18: D6100072 02052139
	v_add3_u32 v43, v43, v106, 0x7fff                          // 000000318E20: D655002B 03FED52B 00007FFF
	v_add3_u32 v46, v46, v110, 0x7fff                          // 000000318E2C: D655002E 03FEDD2E 00007FFF
	.long 0x7e6839aa                                           // 000000318E38: 7E6839AA
	v_bfe_u32 v115, v58, 16, 1                                 // 000000318E3C: D6100073 0205213A
	v_bfe_u32 v118, v61, 16, 1                                 // 000000318E44: D6100076 0205213D
	v_add3_u32 v47, v47, v111, 0x7fff                          // 000000318E4C: D655002F 03FEDF2F 00007FFF
	v_add3_u32 v57, v57, v114, 0x7fff                          // 000000318E58: D6550039 03FEE539 00007FFF
	v_and_or_b32 v43, 0xffff0000, v43, v52                     // 000000318E64: D657002B 04D256FF FFFF0000
	.long 0x7e6839ae                                           // 000000318E70: 7E6839AE
	v_bfe_u32 v119, v62, 16, 1                                 // 000000318E74: D6100077 0205213E
	v_bfe_u32 v122, v64, 16, 1                                 // 000000318E7C: D610007A 02052140
	v_add3_u32 v58, v58, v115, 0x7fff                          // 000000318E84: D655003A 03FEE73A 00007FFF
	v_add3_u32 v61, v61, v118, 0x7fff                          // 000000318E90: D655003D 03FEED3D 00007FFF
	v_and_or_b32 v47, 0xffff0000, v47, v52                     // 000000318E9C: D657002F 04D25EFF FFFF0000
	.long 0x7e6839b9                                           // 000000318EA8: 7E6839B9
	v_bfe_u32 v123, v65, 16, 1                                 // 000000318EAC: D610007B 02052141
	v_bfe_u32 v126, v68, 16, 1                                 // 000000318EB4: D610007E 02052144
	v_add3_u32 v62, v62, v119, 0x7fff                          // 000000318EBC: D655003E 03FEEF3E 00007FFF
	v_add3_u32 v64, v64, v122, 0x7fff                          // 000000318EC8: D6550040 03FEF540 00007FFF
	v_and_or_b32 v58, 0xffff0000, v58, v52                     // 000000318ED4: D657003A 04D274FF FFFF0000
	.long 0x7e6839bd                                           // 000000318EE0: 7E6839BD
	v_bfe_u32 v127, v69, 16, 1                                 // 000000318EE4: D610007F 02052145
	v_bfe_u32 v130, v72, 16, 1                                 // 000000318EEC: D6100082 02052148
	v_add3_u32 v65, v65, v123, 0x7fff                          // 000000318EF4: D6550041 03FEF741 00007FFF
	v_add3_u32 v68, v68, v126, 0x7fff                          // 000000318F00: D6550044 03FEFD44 00007FFF
	v_and_or_b32 v62, 0xffff0000, v62, v52                     // 000000318F0C: D657003E 04D27CFF FFFF0000
	.long 0x7e6839c0                                           // 000000318F18: 7E6839C0
	v_cvt_f32_ubyte3_e32 v5, v5                                // 000000318F1C: 7E0A2905
	v_cvt_f32_ubyte3_e32 v6, v6                                // 000000318F20: 7E0C2906
	v_cvt_f32_ubyte3_e32 v7, v7                                // 000000318F24: 7E0E2907
	v_cvt_f32_ubyte3_e32 v8, v8                                // 000000318F28: 7E102908
	v_cvt_f32_ubyte0_e32 v96, v1                               // 000000318F2C: 7EC02301
	v_cvt_f32_ubyte0_e32 v100, v2                              // 000000318F30: 7EC82302
	v_cvt_f32_ubyte0_e32 v104, v3                              // 000000318F34: 7ED02303
	v_cvt_f32_ubyte0_e32 v108, v4                              // 000000318F38: 7ED82304
	v_bfe_u32 v131, v73, 16, 1                                 // 000000318F3C: D6100083 02052149
	v_bfe_u32 v134, v75, 16, 1                                 // 000000318F44: D6100086 0205214B
	v_add3_u32 v69, v69, v127, 0x7fff                          // 000000318F4C: D6550045 03FEFF45 00007FFF
	v_add3_u32 v72, v72, v130, 0x7fff                          // 000000318F58: D6550048 03FF0548 00007FFF
	v_and_or_b32 v65, 0xffff0000, v65, v52                     // 000000318F64: D6570041 04D282FF FFFF0000
	.long 0x7e6839c4                                           // 000000318F70: 7E6839C4
	v_fma_mix_f32 v5, v5, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F74: CC206005 14D66B05
	v_fma_mix_f32 v6, v6, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F7C: CC206006 14D66B06
	v_fma_mix_f32 v7, v7, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F84: CC206007 14D66B07
	v_fma_mix_f32 v8, v8, v53, v53 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F8C: CC206008 14D66B08
	v_fma_mix_f32 v53, v96, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F94: CC206035 14CE6760
	v_fma_mix_f32 v96, v100, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318F9C: CC206060 14CE6764
	v_fma_mix_f32 v100, v104, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318FA4: CC206064 14CE6768
	v_fma_mix_f32 v104, v108, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000318FAC: CC206068 14CE676C
	v_bfe_u32 v108, v44, 16, 1                                 // 000000318FB4: D610006C 0205212C
	v_bfe_u32 v120, v63, 16, 1                                 // 000000318FBC: D6100078 0205213F
	v_bfe_u32 v124, v66, 16, 1                                 // 000000318FC4: D610007C 02052142
	v_bfe_u32 v135, v76, 16, 1                                 // 000000318FCC: D6100087 0205214C
	v_bfe_u32 v138, v55, 16, 1                                 // 000000318FD4: D610008A 02052137
	v_add3_u32 v73, v73, v131, 0x7fff                          // 000000318FDC: D6550049 03FF0749 00007FFF
	v_add3_u32 v75, v75, v134, 0x7fff                          // 000000318FE8: D655004B 03FF0D4B 00007FFF
	v_and_or_b32 v69, 0xffff0000, v69, v52                     // 000000318FF4: D6570045 04D28AFF FFFF0000
	.long 0x7e6839c8                                           // 000000319000: 7E6839C8
	v_bfe_u32 v109, v45, 16, 1                                 // 000000319004: D610006D 0205212D
	v_bfe_u32 v112, v48, 16, 1                                 // 00000031900C: D6100070 02052130
	v_bfe_u32 v121, v54, 16, 1                                 // 000000319014: D6100079 02052136
	v_bfe_u32 v125, v67, 16, 1                                 // 00000031901C: D610007D 02052143
	v_bfe_u32 v136, v77, 16, 1                                 // 000000319024: D6100088 0205214D
	v_bfe_u32 v139, v78, 16, 1                                 // 00000031902C: D610008B 0205214E
	v_bfe_u32 v105, v80, 16, 1                                 // 000000319034: D6100069 02052150
	v_add3_u32 v44, v44, v108, 0x7fff                          // 00000031903C: D655002C 03FED92C 00007FFF
	v_add3_u32 v63, v63, v120, 0x7fff                          // 000000319048: D655003F 03FEF13F 00007FFF
	v_add3_u32 v66, v66, v124, 0x7fff                          // 000000319054: D6550042 03FEF942 00007FFF
	v_add3_u32 v76, v76, v135, 0x7fff                          // 000000319060: D655004C 03FF0F4C 00007FFF
	v_add3_u32 v55, v55, v138, 0x7fff                          // 00000031906C: D6550037 03FF1537 00007FFF
	v_and_or_b32 v73, 0xffff0000, v73, v52                     // 000000319078: D6570049 04D292FF FFFF0000
	.long 0x7e6839cb                                           // 000000319084: 7E6839CB
	.long 0x7f5239b4                                           // 000000319088: 7F5239B4
	.long 0x7f1e39b4                                           // 00000031908C: 7F1E39B4
	.long 0x7f2039b4                                           // 000000319090: 7F2039B4
	v_bfe_u32 v113, v56, 16, 1                                 // 000000319094: D6100071 02052138
	v_bfe_u32 v128, v70, 16, 1                                 // 00000031909C: D6100080 02052146
	v_bfe_u32 v106, v5, 16, 1                                  // 0000003190A4: D610006A 02052105
	v_bfe_u32 v108, v81, 16, 1                                 // 0000003190AC: D610006C 02052151
	v_add3_u32 v45, v45, v109, 0x7fff                          // 0000003190B4: D655002D 03FEDB2D 00007FFF
	v_bfe_u32 v110, v84, 16, 1                                 // 0000003190C0: D610006E 02052154
	v_add3_u32 v48, v48, v112, 0x7fff                          // 0000003190C8: D6550030 03FEE130 00007FFF
	v_add3_u32 v54, v54, v121, 0x7fff                          // 0000003190D4: D6550036 03FEF336 00007FFF
	v_add3_u32 v67, v67, v125, 0x7fff                          // 0000003190E0: D6550043 03FEFB43 00007FFF
	v_add3_u32 v42, v77, v136, 0x7fff                          // 0000003190EC: D655002A 03FF114D 00007FFF
	v_add3_u32 v77, v78, v139, 0x7fff                          // 0000003190F8: D655004D 03FF174E 00007FFF
	v_add3_u32 v46, v80, v105, 0x7fff                          // 000000319104: D655002E 03FED350 00007FFF
	.long 0x7e5239ac                                           // 000000319110: 7E5239AC
	v_and_or_b32 v44, 0xffff0000, v76, v52                     // 000000319114: D657002C 04D298FF FFFF0000
	.long 0x7e6839b7                                           // 000000319120: 7E6839B7
	.long 0x7e1e39bf                                           // 000000319124: 7E1E39BF
	.long 0x7e2039c2                                           // 000000319128: 7E2039C2
	.long 0x7f1a39b4                                           // 00000031912C: 7F1A39B4
	.long 0x7fa639b4                                           // 000000319130: 7FA639B4
	v_bfe_u32 v129, v71, 16, 1                                 // 000000319134: D6100081 02052147
	v_bfe_u32 v109, v82, 16, 1                                 // 00000031913C: D610006D 02052152
	v_add3_u32 v56, v56, v113, 0x7fff                          // 000000319144: D6550038 03FEE338 00007FFF
	v_add3_u32 v70, v70, v128, 0x7fff                          // 000000319150: D6550046 03FF0146 00007FFF
	v_add3_u32 v5, v5, v106, 0x7fff                            // 00000031915C: D6550005 03FED505 00007FFF
	v_add3_u32 v78, v81, v108, 0x7fff                          // 000000319168: D655004E 03FED951 00007FFF
	v_add3_u32 v57, v84, v110, 0x7fff                          // 000000319174: D6550039 03FEDD54 00007FFF
	.long 0x7e1a39b0                                           // 000000319180: 7E1A39B0
	v_and_or_b32 v48, 0xffff0000, v77, v52                     // 000000319184: D6570030 04D29AFF FFFF0000
	.long 0x7ea639ae                                           // 000000319190: 7EA639AE
	v_and_or_b32 v41, 0xffff0000, v45, v41                     // 000000319194: D6570029 04A65AFF FFFF0000
	v_and_or_b32 v15, 0xffff0000, v54, v15                     // 0000003191A0: D657000F 043E6CFF FFFF0000
	v_and_or_b32 v16, 0xffff0000, v67, v16                     // 0000003191AC: D6570010 044286FF FFFF0000
	.long 0x7f1239b4                                           // 0000003191B8: 7F1239B4
	v_bfe_u32 v116, v59, 16, 1                                 // 0000003191BC: D6100074 0205213B
	v_bfe_u32 v132, v74, 16, 1                                 // 0000003191C4: D6100084 0205214A
	v_add3_u32 v71, v71, v129, 0x7fff                          // 0000003191CC: D6550047 03FF0347 00007FFF
	v_add3_u32 v80, v82, v109, 0x7fff                          // 0000003191D8: D6550050 03FEDB52 00007FFF
	.long 0x7e1239c6                                           // 0000003191E4: 7E1239C6
	.long 0x7e6839ce                                           // 0000003191E8: 7E6839CE
	.long 0x7eae39b9                                           // 0000003191EC: 7EAE39B9
	v_and_or_b32 v13, 0xffff0000, v56, v13                     // 0000003191F0: D657000D 043670FF FFFF0000
	v_and_or_b32 v5, 0xffff0000, v5, v83                       // 0000003191FC: D6570005 054E0AFF FFFF0000
	v_bfe_u32 v117, v60, 16, 1                                 // 000000319208: D6100075 0205213C
	v_bfe_u32 v133, v11, 16, 1                                 // 000000319210: D6100085 0205210B
	v_bfe_u32 v111, v6, 16, 1                                  // 000000319218: D610006F 02052106
	v_bfe_u32 v112, v85, 16, 1                                 // 000000319220: D6100070 02052155
	v_add3_u32 v59, v59, v116, 0x7fff                          // 000000319228: D655003B 03FEE93B 00007FFF
	v_add3_u32 v74, v74, v132, 0x7fff                          // 000000319234: D655004A 03FF094A 00007FFF
	.long 0x7e9e39aa                                           // 000000319240: 7E9E39AA
	v_and_or_b32 v42, 0xffff0000, v80, v52                     // 000000319244: D657002A 04D2A0FF FFFF0000
	v_and_or_b32 v9, 0xffff0000, v71, v9                       // 000000319250: D6570009 04268EFF FFFF0000
	.long 0x7f1c39b4                                           // 00000031925C: 7F1C39B4
	.long 0x7f1439b4                                           // 000000319260: 7F1439B4
	.long 0x7fae39b4                                           // 000000319264: 7FAE39B4
	v_bfe_u32 v113, v86, 16, 1                                 // 000000319268: D6100071 02052156
	v_bfe_u32 v114, v88, 16, 1                                 // 000000319270: D6100072 02052158
	v_bfe_u32 v116, v89, 16, 1                                 // 000000319278: D6100074 02052159
	v_add3_u32 v60, v60, v117, 0x7fff                          // 000000319280: D655003C 03FEEB3C 00007FFF
	v_add3_u32 v11, v11, v133, 0x7fff                          // 00000031928C: D655000B 03FF0B0B 00007FFF
	v_add3_u32 v6, v6, v111, 0x7fff                            // 000000319298: D6550006 03FEDF06 00007FFF
	v_add3_u32 v81, v85, v112, 0x7fff                          // 0000003192A4: D6550051 03FEE155 00007FFF
	.long 0x7e1c39bb                                           // 0000003192B0: 7E1C39BB
	.long 0x7e1439ca                                           // 0000003192B4: 7E1439CA
	v_cvt_f32_ubyte3_e32 v1, v1                                // 0000003192B8: 7E022901
	v_bfe_u32 v137, v12, 16, 1                                 // 0000003192BC: D6100089 0205210C
	v_bfe_u32 v115, v7, 16, 1                                  // 0000003192C4: D6100073 02052107
	v_bfe_u32 v117, v90, 16, 1                                 // 0000003192CC: D6100075 0205215A
	v_bfe_u32 v120, v53, 16, 1                                 // 0000003192D4: D6100078 02052135
	v_add3_u32 v82, v86, v113, 0x7fff                          // 0000003192DC: D6550052 03FEE356 00007FFF
	v_add3_u32 v61, v88, v114, 0x7fff                          // 0000003192E8: D655003D 03FEE558 00007FFF
	v_add3_u32 v84, v89, v116, 0x7fff                          // 0000003192F4: D6550054 03FEE959 00007FFF
	.long 0x7e6839d1                                           // 000000319300: 7E6839D1
	v_and_or_b32 v14, 0xffff0000, v60, v14                     // 000000319304: D657000E 043A78FF FFFF0000
	v_and_or_b32 v10, 0xffff0000, v11, v10                     // 000000319310: D657000A 042A16FF FFFF0000
	v_and_or_b32 v6, 0xffff0000, v6, v87                       // 00000031931C: D6570006 055E0CFF FFFF0000
	.long 0x7f9e39b4                                           // 000000319328: 7F9E39B4
	.long 0x7fb639b4                                           // 00000031932C: 7FB639B4
	v_fma_mix_f32 v1, v1, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000319330: CC206001 14CE6701
	v_bfe_u32 v121, v93, 16, 1                                 // 000000319338: D6100079 0205215D
	v_bfe_u32 v122, v94, 16, 1                                 // 000000319340: D610007A 0205215E
	v_bfe_u32 v124, v96, 16, 1                                 // 000000319348: D610007C 02052160
	v_add3_u32 v12, v12, v137, 0x7fff                          // 000000319350: D655000C 03FF130C 00007FFF
	v_add3_u32 v7, v7, v115, 0x7fff                            // 00000031935C: D6550007 03FEE707 00007FFF
	v_add3_u32 v85, v90, v117, 0x7fff                          // 000000319368: D6550055 03FEEB5A 00007FFF
	v_add3_u32 v53, v53, v120, 0x7fff                          // 000000319374: D6550035 03FEF135 00007FFF
	.long 0x7eb639bd                                           // 000000319380: 7EB639BD
	v_and_or_b32 v46, 0xffff0000, v82, v52                     // 000000319384: D657002E 04D2A4FF FFFF0000
	.long 0x7e6839d4                                           // 000000319390: 7E6839D4
	v_cvt_f32_ubyte3_e32 v2, v2                                // 000000319394: 7E042902
	v_bfe_u32 v123, v1, 16, 1                                  // 000000319398: D610007B 02052101
	v_bfe_u32 v125, v97, 16, 1                                 // 0000003193A0: D610007D 02052161
	v_bfe_u32 v128, v100, 16, 1                                // 0000003193A8: D6100080 02052164
	v_add3_u32 v86, v93, v121, 0x7fff                          // 0000003193B0: D6550056 03FEF35D 00007FFF
	v_add3_u32 v68, v94, v122, 0x7fff                          // 0000003193BC: D6550044 03FEF55E 00007FFF
	v_add3_u32 v88, v96, v124, 0x7fff                          // 0000003193C8: D6550058 03FEF960 00007FFF
	v_and_or_b32 v45, 0xffff0000, v85, v52                     // 0000003193D4: D657002D 04D2AAFF FFFF0000
	.long 0x7e6839b5                                           // 0000003193E0: 7E6839B5
	v_and_or_b32 v11, 0xffff0000, v12, v79                     // 0000003193E4: D657000B 053E18FF FFFF0000
	v_and_or_b32 v7, 0xffff0000, v7, v91                       // 0000003193F0: D6570007 056E0EFF FFFF0000
	.long 0x7fc639b4                                           // 0000003193FC: 7FC639B4
	v_fma_mix_f32 v2, v2, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000319400: CC206002 14CE6702
	v_bfe_u32 v118, v92, 16, 1                                 // 000000319408: D6100076 0205215C
	v_bfe_u32 v126, v98, 16, 1                                 // 000000319410: D610007E 02052162
	v_bfe_u32 v129, v101, 16, 1                                // 000000319418: D6100081 02052165
	v_add3_u32 v1, v1, v123, 0x7fff                            // 000000319420: D6550001 03FEF701 00007FFF
	v_add3_u32 v89, v97, v125, 0x7fff                          // 00000031942C: D6550059 03FEFB61 00007FFF
	v_add3_u32 v90, v100, v128, 0x7fff                         // 000000319438: D655005A 03FF0164 00007FFF
	.long 0x7ec639c4                                           // 000000319444: 7EC639C4
	v_and_or_b32 v12, 0xffff0000, v86, v52                     // 000000319448: D657000C 04D2ACFF FFFF0000
	.long 0x7e6839d8                                           // 000000319454: 7E6839D8
	v_cvt_f32_ubyte3_e32 v3, v3                                // 000000319458: 7E062903
	v_bfe_u32 v127, v2, 16, 1                                  // 00000031945C: D610007F 02052102
	v_add3_u32 v64, v92, v118, 0x7fff                          // 000000319464: D6550040 03FEED5C 00007FFF
	v_add3_u32 v72, v98, v126, 0x7fff                          // 000000319470: D6550048 03FEFD62 00007FFF
	v_add3_u32 v92, v101, v129, 0x7fff                         // 00000031947C: D655005C 03FF0365 00007FFF
	v_and_or_b32 v53, 0xffff0000, v89, v52                     // 000000319488: D6570035 04D2B2FF FFFF0000
	.long 0x7e6839da                                           // 000000319494: 7E6839DA
	v_and_or_b32 v1, 0xffff0000, v1, v99                       // 000000319498: D6570001 058E02FF FFFF0000
	.long 0x7fce39b4                                           // 0000003194A4: 7FCE39B4
	v_fma_mix_f32 v3, v3, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003194A8: CC206003 14CE6703
	v_bfe_u32 v130, v102, 16, 1                                // 0000003194B0: D6100082 02052166
	v_add3_u32 v2, v2, v127, 0x7fff                            // 0000003194B8: D6550002 03FEFF02 00007FFF
	.long 0x7ece39c8                                           // 0000003194C4: 7ECE39C8
	.long 0x7fd639b4                                           // 0000003194C8: 7FD639B4
	v_bfe_u32 v131, v3, 16, 1                                  // 0000003194CC: D6100083 02052103
	v_add3_u32 v75, v102, v130, 0x7fff                         // 0000003194D4: D655004B 03FF0566 00007FFF
	v_bfe_u32 v119, v8, 16, 1                                  // 0000003194E0: D6100077 02052108
	v_and_or_b32 v2, 0xffff0000, v2, v103                      // 0000003194E8: D6570002 059E04FF FFFF0000
	.long 0x7fbe39b4                                           // 0000003194F4: 7FBE39B4
	v_add3_u32 v3, v3, v131, 0x7fff                            // 0000003194F8: D6550003 03FF0703 00007FFF
	.long 0x7ed639cb                                           // 000000319504: 7ED639CB
	v_add3_u32 v8, v8, v119, 0x7fff                            // 000000319508: D6550008 03FEEF08 00007FFF
	.long 0x7ebe39c0                                           // 000000319514: 7EBE39C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319518: BF870113
	v_and_or_b32 v3, 0xffff0000, v3, v107                      // 00000031951C: D6570003 05AE06FF FFFF0000
	v_and_or_b32 v8, 0xffff0000, v8, v95                       // 000000319528: D6570008 057E10FF FFFF0000
	s_waitcnt vmcnt(3)                                         // 000000319534: BF890FF7
	v_dot2_f32_bf16 v54, v17, v43, 0                           // 000000319538: CC1A4036 1A025711
	s_waitcnt vmcnt(2)                                         // 000000319540: BF890BF7
	v_dot2_f32_bf16 v43, v29, v43, 0                           // 000000319544: CC1A402B 1A02571D
	v_dot2_f32_bf16 v55, v17, v65, 0                           // 00000031954C: CC1A4037 1A028311
	v_dot2_f32_bf16 v56, v29, v65, 0                           // 000000319554: CC1A4038 1A02831D
	v_dot2_f32_bf16 v57, v17, v48, 0                           // 00000031955C: CC1A4039 1A026111
	v_dot2_f32_bf16 v48, v29, v48, 0                           // 000000319564: CC1A4030 1A02611D
	v_dot2_f32_bf16 v54, v18, v41, v54                         // 00000031956C: CC1A4036 1CDA5312
	v_dot2_f32_bf16 v41, v30, v41, v43                         // 000000319574: CC1A4029 1CAE531E
	v_dot2_f32_bf16 v43, v18, v16, v55                         // 00000031957C: CC1A402B 1CDE2112
	v_dot2_f32_bf16 v16, v30, v16, v56                         // 000000319584: CC1A4010 1CE2211E
	v_dot2_f32_bf16 v55, v18, v5, v57                          // 00000031958C: CC1A4037 1CE60B12
	v_dot2_f32_bf16 v5, v30, v5, v48                           // 000000319594: CC1A4005 1CC20B1E
	v_dot2_f32_bf16 v48, v19, v47, v54                         // 00000031959C: CC1A4030 1CDA5F13
	v_dot2_f32_bf16 v41, v31, v47, v41                         // 0000003195A4: CC1A4029 1CA65F1F
	v_dot2_f32_bf16 v43, v19, v69, v43                         // 0000003195AC: CC1A402B 1CAE8B13
	v_dot2_f32_bf16 v16, v31, v69, v16                         // 0000003195B4: CC1A4010 1C428B1F
	v_dot2_f32_bf16 v47, v19, v42, v55                         // 0000003195BC: CC1A402F 1CDE5513
	v_dot2_f32_bf16 v5, v31, v42, v5                           // 0000003195C4: CC1A4005 1C16551F
	v_dot2_f32_bf16 v42, v20, v13, v48                         // 0000003195CC: CC1A402A 1CC21B14
	v_dot2_f32_bf16 v13, v32, v13, v41                         // 0000003195D4: CC1A400D 1CA61B20
	v_dot2_f32_bf16 v41, v20, v9, v43                          // 0000003195DC: CC1A4029 1CAE1314
	v_dot2_f32_bf16 v9, v32, v9, v16                           // 0000003195E4: CC1A4009 1C421320
	v_dot2_f32_bf16 v16, v20, v6, v47                          // 0000003195EC: CC1A4010 1CBE0D14
	s_waitcnt vmcnt(1)                                         // 0000003195F4: BF8907F7
	v_dot2_f32_bf16 v42, v21, v58, v42                         // 0000003195F8: CC1A402A 1CAA7515
	s_waitcnt vmcnt(0)                                         // 000000319600: BF8903F7
	v_dot2_f32_bf16 v13, v25, v58, v13                         // 000000319604: CC1A400D 1C367519
	v_dot2_f32_bf16 v41, v21, v73, v41                         // 00000031960C: CC1A4029 1CA69315
	v_dot2_f32_bf16 v5, v32, v6, v5                            // 000000319614: CC1A4005 1C160D20
	v_dot2_f32_bf16 v6, v25, v73, v9                           // 00000031961C: CC1A4006 1C269319
	v_dot2_f32_bf16 v9, v22, v14, v42                          // 000000319624: CC1A4009 1CAA1D16
	v_dot2_f32_bf16 v13, v26, v14, v13                         // 00000031962C: CC1A400D 1C361D1A
	v_dot2_f32_bf16 v14, v22, v10, v41                         // 000000319634: CC1A400E 1CA61516
	v_dot2_f32_bf16 v16, v21, v46, v16                         // 00000031963C: CC1A4010 1C425D15
	v_dot2_f32_bf16 v5, v25, v46, v5                           // 000000319644: CC1A4005 1C165D19
	v_dot2_f32_bf16 v9, v23, v62, v9                           // 00000031964C: CC1A4009 1C267D17
	v_dot2_f32_bf16 v13, v27, v62, v13                         // 000000319654: CC1A400D 1C367D1B
	v_dot2_f32_bf16 v14, v23, v44, v14                         // 00000031965C: CC1A400E 1C3A5917
	v_dot2_f32_bf16 v6, v26, v10, v6                           // 000000319664: CC1A4006 1C1A151A
	v_dot2_f32_bf16 v10, v22, v7, v16                          // 00000031966C: CC1A400A 1C420F16
	v_dot2_f32_bf16 v5, v26, v7, v5                            // 000000319674: CC1A4005 1C160F1A
	v_dot2_f32_bf16 v13, v28, v15, v13                         // 00000031967C: CC1A400D 1C361F1C
	v_dot2_f32_bf16 v14, v24, v11, v14                         // 000000319684: CC1A400E 1C3A1718
	v_bfe_u32 v7, v104, 16, 1                                  // 00000031968C: D6100007 02052168
	v_dot2_f32_bf16 v9, v24, v15, v9                           // 000000319694: CC1A4009 1C261F18
	v_cvt_f32_ubyte1_e32 v15, v4                               // 00000031969C: 7E1E2504
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000003196A0: BF870214
	v_dual_add_f32 v38, v38, v13 :: v_dual_add_f32 v37, v37, v14// 0000003196A4: C9081B26 26241D25
	v_add3_u32 v7, v104, v7, 0x7fff                            // 0000003196AC: D6550007 03FE0F68 00007FFF
	v_cvt_f32_ubyte2_e32 v13, v4                               // 0000003196B8: 7E1A2704
	v_dot2_f32_bf16 v14, v17, v12, 0                           // 0000003196BC: CC1A400E 1A021911
	v_dot2_f32_bf16 v12, v29, v12, 0                           // 0000003196C4: CC1A400C 1A02191D
	v_add_f32_e32 v39, v39, v9                                 // 0000003196CC: 064E1327
	v_and_or_b32 v9, 0xffff0000, v92, v52                      // 0000003196D0: D6570009 04D2B8FF FFFF0000
	.long 0x7e683987                                           // 0000003196DC: 7E683987
	v_fma_mix_f32 v7, v13, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003196E0: CC206007 14CE670D
	v_dot2_f32_bf16 v13, v18, v1, v14                          // 0000003196E8: CC1A400D 1C3A0312
	v_dot2_f32_bf16 v1, v30, v1, v12                           // 0000003196F0: CC1A4001 1C32031E
	v_fma_mix_f32 v12, v15, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 0000003196F8: CC20600C 14CE670F
	v_cvt_f32_ubyte3_e32 v4, v4                                // 000000319700: 7E082904
	v_bfe_u32 v14, v7, 16, 1                                   // 000000319704: D610000E 02052107
	v_dot2_f32_bf16 v13, v19, v53, v13                         // 00000031970C: CC1A400D 1C366B13
	v_dot2_f32_bf16 v1, v31, v53, v1                           // 000000319714: CC1A4001 1C066B1F
	v_bfe_u32 v15, v12, 16, 1                                  // 00000031971C: D610000F 0205210C
	v_fma_mix_f32 v4, v4, v51, v51 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 000000319724: CC206004 14CE6704
	v_add3_u32 v7, v7, v14, 0x7fff                             // 00000031972C: D6550007 03FE1D07 00007FFF
	v_dot2_f32_bf16 v13, v20, v2, v13                          // 000000319738: CC1A400D 1C360514
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 000000319740: CC1A4001 1C060520
	v_add3_u32 v2, v12, v15, 0x7fff                            // 000000319748: D6550002 03FE1F0C 00007FFF
	v_bfe_u32 v12, v4, 16, 1                                   // 000000319754: D610000C 02052104
	.long 0x7e0e3987                                           // 00000031975C: 7E0E3987
	v_dot2_f32_bf16 v13, v21, v9, v13                          // 000000319760: CC1A400D 1C361315
	v_dot2_f32_bf16 v1, v25, v9, v1                            // 000000319768: CC1A4001 1C061319
	.long 0x7f0e39b4                                           // 000000319770: 7F0E39B4
	v_add3_u32 v4, v4, v12, 0x7fff                             // 000000319774: D6550004 03FE1904 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v52                       // 000000319780: D6570002 04D204FF FFFF0000
	v_dot2_f32_bf16 v9, v22, v3, v13                           // 00000031978C: CC1A4009 1C360716
	v_dot2_f32_bf16 v1, v26, v3, v1                            // 000000319794: CC1A4001 1C06071A
	v_dot2_f32_bf16 v6, v27, v44, v6                           // 00000031979C: CC1A4006 1C1A591B
	v_dot2_f32_bf16 v3, v23, v45, v10                          // 0000003197A4: CC1A4003 1C2A5B17
	v_dot2_f32_bf16 v5, v27, v45, v5                           // 0000003197AC: CC1A4005 1C165B1B
	v_and_or_b32 v4, 0xffff0000, v4, v7                        // 0000003197B4: D6570004 041E08FF FFFF0000
	v_dot2_f32_bf16 v7, v23, v2, v9                            // 0000003197C0: CC1A4007 1C260517
	v_dot2_f32_bf16 v1, v27, v2, v1                            // 0000003197C8: CC1A4001 1C06051B
	v_dot2_f32_bf16 v2, v28, v11, v6                           // 0000003197D0: CC1A4002 1C1A171C
	v_dot2_f32_bf16 v3, v24, v8, v3                            // 0000003197D8: CC1A4003 1C0E1118
	v_dot2_f32_bf16 v5, v28, v8, v5                            // 0000003197E0: CC1A4005 1C16111C
	v_dot2_f32_bf16 v6, v24, v4, v7                            // 0000003197E8: CC1A4006 1C1E0918
	v_dot2_f32_bf16 v1, v28, v4, v1                            // 0000003197F0: CC1A4001 1C06091C
	v_add_f32_e32 v40, v40, v2                                 // 0000003197F8: 06500528
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000003197FC: BF870194
	v_dual_add_f32 v36, v36, v3 :: v_dual_add_f32 v35, v35, v5 // 000000319800: C9080724 24220B23
	v_dual_add_f32 v34, v34, v6 :: v_dual_add_f32 v33, v33, v1 // 000000319808: C9080D22 22200321
	s_or_b32 exec_lo, exec_lo, s3                              // 000000319810: 8C7E037E
	.long 0xd71f0001                                           // 000000319814: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000319818: 020100C1
	s_mov_b32 s6, exec_lo                                      // 00000031981C: BE86007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000319820: BF8701B1
	v_xor_b32_e32 v2, 8, v1                                    // 000000319824: 3A040288
	v_xor_b32_e32 v10, 4, v1                                   // 000000319828: 3A140284
	v_xor_b32_e32 v18, 2, v1                                   // 00000031982C: 3A240282
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000319830: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000319834: 02040501
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319838: BF870114
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000031983C: 7C9814A0
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000319840: 30040482
	ds_bpermute_b32 v5, v2, v37                                // 000000319844: DACC0000 05002502
	s_waitcnt lgkmcnt(0)                                       // 00000031984C: BF89FC07
	v_add_f32_e32 v5, v37, v5                                  // 000000319850: 060A0B25
	ds_bpermute_b32 v3, v2, v39                                // 000000319854: DACC0000 03002702
	ds_bpermute_b32 v7, v2, v36                                // 00000031985C: DACC0000 07002402
	ds_bpermute_b32 v9, v2, v34                                // 000000319864: DACC0000 09002202
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 00000031986C: 02141501
	ds_bpermute_b32 v4, v2, v38                                // 000000319870: DACC0000 04002602
	ds_bpermute_b32 v8, v2, v35                                // 000000319878: DACC0000 08002302
	ds_bpermute_b32 v6, v2, v40                                // 000000319880: DACC0000 06002802
	ds_bpermute_b32 v2, v2, v33                                // 000000319888: DACC0000 02002102
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000319890: 7C9824A0
	s_waitcnt lgkmcnt(6)                                       // 000000319894: BF89FC67
	v_dual_cndmask_b32 v18, v1, v18 :: v_dual_add_f32 v3, v39, v3// 000000319898: CA482501 12020727
	s_waitcnt lgkmcnt(5)                                       // 0000003198A0: BF89FC57
	v_dual_add_f32 v7, v36, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000003198A4: C9220F24 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000003198AC: BF89FC47
	v_add_f32_e32 v9, v34, v9                                  // 0000003198B0: 06121322
	ds_bpermute_b32 v11, v10, v3                               // 0000003198B4: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 0000003198BC: DACC0000 0D00050A
	ds_bpermute_b32 v17, v10, v9                               // 0000003198C4: DACC0000 1100090A
	ds_bpermute_b32 v15, v10, v7                               // 0000003198CC: DACC0000 0F00070A
	s_waitcnt lgkmcnt(7)                                       // 0000003198D4: BF89FC77
	v_add_f32_e32 v4, v38, v4                                  // 0000003198D8: 06080926
	s_waitcnt lgkmcnt(6)                                       // 0000003198DC: BF89FC67
	v_add_f32_e32 v8, v35, v8                                  // 0000003198E0: 06101123
	s_waitcnt lgkmcnt(5)                                       // 0000003198E4: BF89FC57
	v_add_f32_e32 v6, v40, v6                                  // 0000003198E8: 060C0D28
	s_waitcnt lgkmcnt(3)                                       // 0000003198EC: BF89FC37
	v_dual_add_f32 v2, v33, v2 :: v_dual_add_f32 v3, v3, v11   // 0000003198F0: C9080521 02021703
	ds_bpermute_b32 v12, v10, v4                               // 0000003198F8: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000319900: BF89FC37
	v_dual_add_f32 v5, v5, v13 :: v_dual_lshlrev_b32 v18, 2, v18// 000000319904: C9221B05 05122482
	s_waitcnt lgkmcnt(2)                                       // 00000031990C: BF89FC27
	v_add_f32_e32 v13, v9, v17                                 // 000000319910: 061A2309
	ds_bpermute_b32 v16, v10, v8                               // 000000319914: DACC0000 1000080A
	ds_bpermute_b32 v14, v10, v6                               // 00000031991C: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 000000319924: BF89FC37
	v_add_f32_e32 v11, v7, v15                                 // 000000319928: 06161F07
	ds_bpermute_b32 v10, v10, v2                               // 00000031992C: DACC0000 0A00020A
	ds_bpermute_b32 v7, v18, v3                                // 000000319934: DACC0000 07000312
	s_waitcnt lgkmcnt(4)                                       // 00000031993C: BF89FC47
	v_add_f32_e32 v4, v4, v12                                  // 000000319940: 06081904
	s_waitcnt lgkmcnt(0)                                       // 000000319944: BF89FC07
	v_dual_add_f32 v12, v8, v16 :: v_dual_add_f32 v3, v3, v7   // 000000319948: C9082108 0C020F03
	ds_bpermute_b32 v8, v18, v4                                // 000000319950: DACC0000 08000412
	v_add_f32_e32 v6, v6, v14                                  // 000000319958: 060C1D06
	ds_bpermute_b32 v15, v18, v12                              // 00000031995C: DACC0000 0F000C12
	v_add_f32_e32 v2, v2, v10                                  // 000000319964: 06041502
	ds_bpermute_b32 v9, v18, v5                                // 000000319968: DACC0000 09000512
	ds_bpermute_b32 v14, v18, v11                              // 000000319970: DACC0000 0E000B12
	ds_bpermute_b32 v10, v18, v6                               // 000000319978: DACC0000 0A000612
	ds_bpermute_b32 v16, v18, v13                              // 000000319980: DACC0000 10000D12
	ds_bpermute_b32 v17, v18, v2                               // 000000319988: DACC0000 11000212
	v_xor_b32_e32 v18, 1, v1                                   // 000000319990: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000319994: BF870141
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000319998: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 00000031999C: 02022501
	s_waitcnt lgkmcnt(6)                                       // 0000003199A0: BF89FC67
	v_add_f32_e32 v7, v4, v8                                   // 0000003199A4: 060E1104
	v_lshlrev_b32_e32 v1, 2, v1                                // 0000003199A8: 30020282
	s_waitcnt lgkmcnt(4)                                       // 0000003199AC: BF89FC47
	v_add_f32_e32 v4, v5, v9                                   // 0000003199B0: 06081305
	s_waitcnt lgkmcnt(2)                                       // 0000003199B4: BF89FC27
	v_add_f32_e32 v8, v6, v10                                  // 0000003199B8: 06101506
	v_add_f32_e32 v5, v11, v14                                 // 0000003199BC: 060A1D0B
	s_waitcnt lgkmcnt(1)                                       // 0000003199C0: BF89FC17
	v_dual_add_f32 v9, v12, v15 :: v_dual_add_f32 v6, v13, v16 // 0000003199C4: C9081F0C 0906210D
	s_waitcnt lgkmcnt(0)                                       // 0000003199CC: BF89FC07
	v_add_f32_e32 v10, v2, v17                                 // 0000003199D0: 06142302
	ds_bpermute_b32 v15, v1, v3                                // 0000003199D4: DACC0000 0F000301
	ds_bpermute_b32 v11, v1, v7                                // 0000003199DC: DACC0000 0B000701
	ds_bpermute_b32 v16, v1, v4                                // 0000003199E4: DACC0000 10000401
	ds_bpermute_b32 v12, v1, v8                                // 0000003199EC: DACC0000 0C000801
	ds_bpermute_b32 v17, v1, v5                                // 0000003199F4: DACC0000 11000501
	ds_bpermute_b32 v13, v1, v9                                // 0000003199FC: DACC0000 0D000901
	ds_bpermute_b32 v18, v1, v6                                // 000000319A04: DACC0000 12000601
	ds_bpermute_b32 v14, v1, v10                               // 000000319A0C: DACC0000 0E000A01
	v_cmpx_eq_u32_e32 0, v50                                   // 000000319A14: 7D946480
	s_cbranch_execz 515                                        // 000000319A18: BFA50203 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2628>
	v_ashrrev_i32_e32 v50, 31, v49                             // 000000319A1C: 3464629F
	s_waitcnt lgkmcnt(5)                                       // 000000319A20: BF89FC57
	v_dual_add_f32 v3, v3, v15 :: v_dual_add_f32 v4, v4, v16   // 000000319A24: C9081F03 03042104
	s_waitcnt lgkmcnt(1)                                       // 000000319A2C: BF89FC17
	v_dual_add_f32 v5, v5, v17 :: v_dual_add_f32 v6, v6, v18   // 000000319A30: C9082305 05062506
	.long 0xd73c0013                                           // 000000319A38: D73C0013
	v_cndmask_b32_e32 v1, 1, v49, vcc_lo                       // 000000319A3C: 02026281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000319A40: BF870223
	v_bfe_u32 v15, v3, 16, 1                                   // 000000319A44: D610000F 02052103
	v_bfe_u32 v16, v4, 16, 1                                   // 000000319A4C: D6100010 02052104
	v_bfe_u32 v17, v5, 16, 1                                   // 000000319A54: D6100011 02052105
	v_bfe_u32 v18, v6, 16, 1                                   // 000000319A5C: D6100012 02052106
	s_cmp_lg_u64 s[10:11], 0                                   // 000000319A64: BF11800A
	.long 0xd7006a01                                           // 000000319A68: D7006A01
	v_cndmask_b32_e32 v1, s20, v19, vcc_lo                     // 000000319A6C: 02022614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000319A70: BF8701A1
	v_add_co_ci_u32_e64 v2, null, s21, v20, vcc_lo             // 000000319A74: D5207C02 01AA2815
	v_add3_u32 v4, v4, v16, 0x7fff                             // 000000319A7C: D6550004 03FE2104 00007FFF
	.long 0xd7006a15                                           // 000000319A88: D7006A15
	v_cndmask_b32_e32 v1, 0x2000, v1, vcc_lo                   // 000000319A8C: 020202FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000319A94: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v2, vcc_lo               // 000000319A98: D5207C16 01AA0480
	.long 0xd7006a17                                           // 000000319AA0: D7006A17
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 000000319AA4: 020202FF 00003000
	v_add_co_ci_u32_e64 v24, null, 0, v2, vcc_lo               // 000000319AAC: D5207C18 01AA0480
	.long 0xd7006a19                                           // 000000319AB4: D7006A19
	v_cndmask_b32_e32 v1, 0x1000, v1, vcc_lo                   // 000000319AB8: 020202FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000319AC0: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 000000319AC4: D5207C1A 01AA0480
	s_clause 0x3                                               // 000000319ACC: BF850003
	global_load_u16 v21, v[21:22], off offset:2048             // 000000319AD0: DC4A0800 157C0015
	global_load_u16 v22, v[23:24], off offset:3072             // 000000319AD8: DC4A0C00 167C0017
	global_load_u16 v23, v[1:2], off                           // 000000319AE0: DC4A0000 177C0001
	global_load_u16 v24, v[25:26], off offset:1024             // 000000319AE8: DC4A0400 187C0019
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000319AF0: 360808FF FFFF0000
	v_add3_u32 v3, v3, v15, 0x7fff                             // 000000319AF8: D6550003 03FE1F03 00007FFF
	v_add3_u32 v6, v6, v18, 0x7fff                             // 000000319B04: D6550006 03FE2506 00007FFF
	v_add3_u32 v5, v5, v17, 0x7fff                             // 000000319B10: D6550005 03FE2305 00007FFF
	s_cselect_b32 s7, -1, 0                                    // 000000319B1C: 980780C1
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 000000319B20: 100808FF BFB8AA3B
	s_cmp_eq_u64 s[10:11], 0                                   // 000000319B28: BF10800A
	v_and_b32_e32 v6, 0xffff0000, v6                           // 000000319B2C: 360C0CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000319B34: BF870122
	v_exp_f32_e32 v4, v4                                       // 000000319B38: 7E084B04
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000319B3C: 360606FF FFFF0000
	v_mul_f32_e32 v6, 0xbfb8aa3b, v6                           // 000000319B44: 100C0CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000319B4C: BF870311
	v_exp_f32_e32 v6, v6                                       // 000000319B50: 7E0C4B06
	v_dual_add_f32 v4, 1.0, v4 :: v_dual_and_b32 v5, 0xffff0000, v5// 000000319B54: C92408F2 04040AFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319B60: BF870113
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000319B64: 100606FF BFB8AA3B
	v_div_scale_f32 v16, null, v4, v4, 1.0                     // 000000319B6C: D6FC7C10 03CA0904
	s_delay_alu instid0(VALU_DEP_2)                            // 000000319B74: BF870002
	v_exp_f32_e32 v3, v3                                       // 000000319B78: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000319B7C: BF870186
	v_dual_add_f32 v6, 1.0, v6 :: v_dual_mul_f32 v5, 0xbfb8aa3b, v5// 000000319B80: C9060CF2 06040AFF BFB8AA3B
	v_div_scale_f32 v30, s3, 1.0, v4, 1.0                      // 000000319B8C: D6FC031E 03CA08F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319B94: BF870113
	v_rcp_f32_e32 v26, v16                                     // 000000319B98: 7E345510
	v_div_scale_f32 v18, null, v6, v6, 1.0                     // 000000319B9C: D6FC7C12 03CA0D06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000319BA4: BF870393
	v_exp_f32_e32 v5, v5                                       // 000000319BA8: 7E0A4B05
	v_add_f32_e32 v3, 1.0, v3                                  // 000000319BAC: 060606F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 000000319BB0: BF870392
	v_rcp_f32_e32 v28, v18                                     // 000000319BB4: 7E385512
	v_fma_f32 v32, -v16, v26, 1.0                              // 000000319BB8: D6130020 23CA3510
	s_delay_alu instid0(VALU_DEP_2)                            // 000000319BC0: BF870002
	v_div_scale_f32 v15, null, v3, v3, 1.0                     // 000000319BC4: D6FC7C0F 03CA0703
	v_div_scale_f32 v29, vcc_lo, 1.0, v3, 1.0                  // 000000319BCC: D6FC6A1D 03CA06F2
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_3)   // 000000319BD4: BF870186
	v_dual_add_f32 v5, 1.0, v5 :: v_dual_fmac_f32 v26, v32, v26// 000000319BD8: C9000AF2 051A3520
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000319BE0: BF870313
	v_rcp_f32_e32 v25, v15                                     // 000000319BE4: 7E32550F
	v_fma_f32 v35, -v18, v28, 1.0                              // 000000319BE8: D6130023 23CA3912
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000319BF0: BF8701A2
	v_div_scale_f32 v17, null, v5, v5, 1.0                     // 000000319BF4: D6FC7C11 03CA0B05
	v_div_scale_f32 v34, s4, 1.0, v5, 1.0                      // 000000319BFC: D6FC0422 03CA0AF2
	v_fmac_f32_e32 v28, v35, v28                               // 000000319C04: 56383923
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000319C08: BF870313
	v_rcp_f32_e32 v27, v17                                     // 000000319C0C: 7E365511
	v_fma_f32 v31, -v15, v25, 1.0                              // 000000319C10: D613001F 23CA330F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000319C18: BF8702A1
	v_fmac_f32_e32 v25, v31, v25                               // 000000319C1C: 5632331F
	v_div_scale_f32 v31, s5, 1.0, v6, 1.0                      // 000000319C20: D6FC051F 03CA0CF2
	v_fma_f32 v33, -v17, v27, 1.0                              // 000000319C28: D6130021 23CA3711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319C30: BF870113
	v_mul_f32_e32 v32, v29, v25                                // 000000319C34: 1040331D
	v_dual_mul_f32 v36, v31, v28 :: v_dual_fmac_f32 v27, v33, v27// 000000319C38: C8C0391F 241A3721
	v_mul_f32_e32 v33, v30, v26                                // 000000319C40: 1042351E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000319C44: BF870193
	v_fma_f32 v37, -v15, v32, v29                              // 000000319C48: D6130025 2476410F
	v_fma_f32 v40, -v18, v36, v31                              // 000000319C50: D6130028 247E4912
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319C58: BF870214
	v_mul_f32_e32 v35, v34, v27                                // 000000319C5C: 10463722
	v_fma_f32 v38, -v16, v33, v30                              // 000000319C60: D6130026 247A4310
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319C68: BF870214
	v_fmac_f32_e32 v32, v37, v25                               // 000000319C6C: 56403325
	v_fmac_f32_e32 v36, v40, v28                               // 000000319C70: 56483928
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319C74: BF870214
	v_fma_f32 v39, -v17, v35, v34                              // 000000319C78: D6130027 248A4711
	v_fmac_f32_e32 v33, v38, v26                               // 000000319C80: 56423526
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319C84: BF870214
	v_fma_f32 v15, -v15, v32, v29                              // 000000319C88: D613000F 2476410F
	v_fma_f32 v18, -v18, v36, v31                              // 000000319C90: D6130012 247E4912
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319C98: BF870214
	v_fmac_f32_e32 v35, v39, v27                               // 000000319C9C: 56463727
	v_fma_f32 v16, -v16, v33, v30                              // 000000319CA0: D6130010 247A4310
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000319CA8: BF8701A4
	v_div_fmas_f32 v15, v15, v25, v32                          // 000000319CAC: D637000F 0482330F
	s_mov_b32 vcc_lo, s3                                       // 000000319CB4: BEEA0003
	v_fma_f32 v17, -v17, v35, v34                              // 000000319CB8: D6130011 248A4711
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000319CC0: BF8701B3
	v_div_fmas_f32 v16, v16, v26, v33                          // 000000319CC4: D6370010 04863510
	s_mov_b32 vcc_lo, s4                                       // 000000319CCC: BEEA0004
	v_div_fixup_f32 v3, v15, v3, 1.0                           // 000000319CD0: D6270003 03CA070F
	v_div_fmas_f32 v15, v17, v27, v35                          // 000000319CD8: D637000F 048E3711
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000319CE0: BF8701A3
	v_div_fixup_f32 v4, v16, v4, 1.0                           // 000000319CE4: D6270004 03CA0910
	s_mov_b32 vcc_lo, s5                                       // 000000319CEC: BEEA0005
	v_bfe_u32 v16, v3, 16, 1                                   // 000000319CF0: D6100010 02052103
	v_div_fmas_f32 v17, v18, v28, v36                          // 000000319CF8: D6370011 04923912
	v_div_fixup_f32 v5, v15, v5, 1.0                           // 000000319D00: D6270005 03CA0B0F
	v_bfe_u32 v15, v4, 16, 1                                   // 000000319D08: D610000F 02052104
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319D10: BF870214
	v_add3_u32 v3, v3, v16, 0x7fff                             // 000000319D14: D6550003 03FE2103 00007FFF
	v_div_fixup_f32 v6, v17, v6, 1.0                           // 000000319D20: D6270006 03CA0D11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319D28: BF870214
	v_bfe_u32 v16, v5, 16, 1                                   // 000000319D2C: D6100010 02052105
	v_add3_u32 v4, v4, v15, 0x7fff                             // 000000319D34: D6550004 03FE1F04 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319D40: BF870214
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000319D44: 360606FF FFFF0000
	v_bfe_u32 v17, v6, 16, 1                                   // 000000319D4C: D6100011 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319D54: BF870114
	v_add3_u32 v5, v5, v16, 0x7fff                             // 000000319D58: D6550005 03FE2105 00007FFF
	v_add3_u32 v6, v6, v17, 0x7fff                             // 000000319D64: D6550006 03FE2306 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000319D70: BF870152
	v_and_b32_e32 v5, 0xffff0000, v5                           // 000000319D74: 360A0AFF FFFF0000
	s_waitcnt vmcnt(1)                                         // 000000319D7C: BF8907F7
	v_lshlrev_b32_e32 v15, 16, v23                             // 000000319D80: 301E2E90
	s_waitcnt vmcnt(0)                                         // 000000319D84: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v24                             // 000000319D88: 30203090
	v_fma_f32 v3, v3, v15, 0                                   // 000000319D8C: D6130003 02021F03
	v_lshlrev_b32_e32 v15, 16, v21                             // 000000319D94: 301E2A90
	v_and_b32_e32 v4, 0xffff0000, v4                           // 000000319D98: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000319DA0: BF870091
	v_dual_fmac_f32 v3, v4, v16 :: v_dual_and_b32 v4, 0xffff0000, v6// 000000319DA4: C8242104 03040CFF FFFF0000
	v_dual_fmac_f32 v3, v5, v15 :: v_dual_lshlrev_b32 v6, 16, v22// 000000319DB0: C8221F05 03062C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000319DB8: BF870091
	v_fmac_f32_e32 v3, v4, v6                                  // 000000319DBC: 56060D04
	v_mul_f32_e32 v15, 0x3e800000, v3                          // 000000319DC0: 101E06FF 3E800000
	.long 0xd7006a03                                           // 000000319DC8: D7006A03
	v_cndmask_b32_e32 v1, s8, v19, vcc_lo                      // 000000319DCC: 02022608
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000319DD0: BF870191
	v_add_co_ci_u32_e64 v4, null, s9, v20, vcc_lo              // 000000319DD4: D5207C04 01AA2809
	v_bfe_u32 v5, v15, 16, 1                                   // 000000319DDC: D6100005 0205210F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000319DE4: BF870001
	v_add3_u32 v16, v15, v5, 0x7fff                            // 000000319DE8: D6550010 03FE0B0F 00007FFF
	.long 0xd73c0005                                           // 000000319DF4: D73C0005
	v_cndmask_b32_e32 v1, 2, v49, vcc_lo                       // 000000319DF8: 02026282
	global_store_d16_hi_b16 v[3:4], v16, off                   // 000000319DFC: DC960000 007C1003
	s_cbranch_scc1 7                                           // 000000319E04: BFA20007 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2224>
	.long 0xd7006a10                                           // 000000319E08: D7006A10
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000319E0C: 02020A0A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000319E10: BF870001
	v_add_co_ci_u32_e64 v17, null, s11, v6, vcc_lo             // 000000319E14: D5207C11 01AA0C0B
	global_store_b32 v[16:17], v15, off                        // 000000319E1C: DC6A0000 007C0F10
	.long 0xd7006a0f                                           // 000000319E24: D7006A0F
	v_cndmask_b32_e32 v1, 0x5000, v1, vcc_lo                   // 000000319E28: 020202FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000319E30: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 000000319E34: D5207C10 01AA0480
	.long 0xd7006a11                                           // 000000319E3C: D7006A11
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 000000319E40: 020202FF 00006000
	v_add_co_ci_u32_e64 v18, null, 0, v2, vcc_lo               // 000000319E48: D5207C12 01AA0480
	s_clause 0x1                                               // 000000319E50: BF850001
	global_load_u16 v19, v[15:16], off                         // 000000319E54: DC4A0000 137C000F
	global_load_u16 v17, v[17:18], off offset:1024             // 000000319E5C: DC4A0400 117C0011
	.long 0xd7006a0f                                           // 000000319E64: D7006A0F
	v_cndmask_b32_e32 v1, 0x7000, v1, vcc_lo                   // 000000319E68: 020202FF 00007000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000319E70: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v2, vcc_lo               // 000000319E74: D5207C10 01AA0480
	.long 0xd7006a01                                           // 000000319E7C: D7006A01
	v_cndmask_b32_e32 v1, 0x8000, v1, vcc_lo                   // 000000319E80: 020202FF 00008000
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000319E88: D5207C02 01AA0480
	s_clause 0x1                                               // 000000319E90: BF850001
	global_load_u16 v15, v[15:16], off offset:2048             // 000000319E94: DC4A0800 0F7C000F
	global_load_u16 v1, v[1:2], off offset:3072                // 000000319E9C: DC4A0C00 017C0001
	v_dual_add_f32 v2, v7, v11 :: v_dual_add_f32 v7, v8, v12   // 000000319EA4: C9081707 02061908
	s_waitcnt lgkmcnt(0)                                       // 000000319EAC: BF89FC07
	v_dual_add_f32 v8, v9, v13 :: v_dual_add_f32 v9, v10, v14  // 000000319EB0: C9081B09 08081D0A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000319EB8: BF870192
	v_bfe_u32 v10, v2, 16, 1                                   // 000000319EBC: D610000A 02052102
	v_bfe_u32 v11, v7, 16, 1                                   // 000000319EC4: D610000B 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319ECC: BF870213
	v_bfe_u32 v12, v8, 16, 1                                   // 000000319ED0: D610000C 02052108
	v_bfe_u32 v13, v9, 16, 1                                   // 000000319ED8: D610000D 02052109
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319EE0: BF870214
	v_add3_u32 v2, v2, v10, 0x7fff                             // 000000319EE4: D6550002 03FE1502 00007FFF
	v_add3_u32 v7, v7, v11, 0x7fff                             // 000000319EF0: D6550007 03FE1707 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000319EFC: BF870214
	v_add3_u32 v8, v8, v12, 0x7fff                             // 000000319F00: D6550008 03FE1908 00007FFF
	v_add3_u32 v9, v9, v13, 0x7fff                             // 000000319F0C: D6550009 03FE1B09 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319F18: BF870113
	v_and_b32_e32 v7, 0xffff0000, v7                           // 000000319F1C: 360E0EFF FFFF0000
	v_and_b32_e32 v9, 0xffff0000, v9                           // 000000319F24: 361212FF FFFF0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000319F2C: BF870112
	v_mul_f32_e32 v7, 0xbfb8aa3b, v7                           // 000000319F30: 100E0EFF BFB8AA3B
	v_mul_f32_e32 v9, 0xbfb8aa3b, v9                           // 000000319F38: 101212FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000319F40: BF870122
	v_exp_f32_e32 v7, v7                                       // 000000319F44: 7E0E4B07
	v_and_b32_e32 v2, 0xffff0000, v2                           // 000000319F48: 360404FF FFFF0000
	v_exp_f32_e32 v9, v9                                       // 000000319F50: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000319F54: BF870296
	v_dual_add_f32 v7, 1.0, v7 :: v_dual_and_b32 v8, 0xffff0000, v8// 000000319F58: C9240EF2 070810FF FFFF0000
	v_dual_mul_f32 v2, 0xbfb8aa3b, v2 :: v_dual_add_f32 v9, 1.0, v9// 000000319F64: C8C804FF 020812F2 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000319F70: BF870192
	v_mul_f32_e32 v8, 0xbfb8aa3b, v8                           // 000000319F74: 101010FF BFB8AA3B
	v_div_scale_f32 v11, null, v7, v7, 1.0                     // 000000319F7C: D6FC7C0B 03CA0F07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000319F84: BF8701A3
	v_exp_f32_e32 v2, v2                                       // 000000319F88: 7E044B02
	v_div_scale_f32 v22, s3, 1.0, v7, 1.0                      // 000000319F8C: D6FC0316 03CA0EF2
	v_exp_f32_e32 v8, v8                                       // 000000319F94: 7E104B08
	v_div_scale_f32 v13, null, v9, v9, 1.0                     // 000000319F98: D6FC7C0D 03CA1309
	v_rcp_f32_e32 v16, v11                                     // 000000319FA0: 7E20550B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 000000319FA4: BF8703A1
	v_rcp_f32_e32 v20, v13                                     // 000000319FA8: 7E28550D
	v_add_f32_e32 v2, 1.0, v2                                  // 000000319FAC: 060404F2
	v_add_f32_e32 v8, 1.0, v8                                  // 000000319FB0: 061010F2
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000319FB4: BF870196
	v_fma_f32 v24, -v11, v16, 1.0                              // 000000319FB8: D6130018 23CA210B
	v_div_scale_f32 v10, null, v2, v2, 1.0                     // 000000319FC0: D6FC7C0A 03CA0502
	v_div_scale_f32 v21, vcc_lo, 1.0, v2, 1.0                  // 000000319FC8: D6FC6A15 03CA04F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000319FD0: BF8702A4
	v_div_scale_f32 v12, null, v8, v8, 1.0                     // 000000319FD4: D6FC7C0C 03CA1108
	v_div_scale_f32 v26, s4, 1.0, v8, 1.0                      // 000000319FDC: D6FC041A 03CA10F2
	v_fma_f32 v27, -v13, v20, 1.0                              // 000000319FE4: D613001B 23CA290D
	v_rcp_f32_e32 v14, v10                                     // 000000319FEC: 7E1C550A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000319FF0: BF870093
	v_rcp_f32_e32 v18, v12                                     // 000000319FF4: 7E24550C
	v_fmac_f32_e32 v20, v27, v20                               // 000000319FF8: 5628291B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000319FFC: BF870296
	v_fma_f32 v23, -v10, v14, 1.0                              // 00000031A000: D6130017 23CA1D0A
	v_fma_f32 v25, -v12, v18, 1.0                              // 00000031A008: D6130019 23CA250C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A010: BF870091
	v_fmac_f32_e32 v18, v25, v18                               // 00000031A014: 56242519
	v_dual_fmac_f32 v16, v24, v16 :: v_dual_mul_f32 v27, v26, v18// 00000031A018: C8062118 101A251A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000031A020: BF8701A1
	v_dual_fmac_f32 v14, v23, v14 :: v_dual_mul_f32 v25, v22, v16// 00000031A024: C8061D17 0E182116
	v_div_scale_f32 v23, s5, 1.0, v9, 1.0                      // 00000031A02C: D6FC0517 03CA12F2
	v_fma_f32 v31, -v12, v27, v26                              // 00000031A034: D613001F 246A370C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A03C: BF870213
	v_mul_f32_e32 v24, v21, v14                                // 00000031A040: 10301D15
	v_fma_f32 v30, -v11, v25, v22                              // 00000031A044: D613001E 245A330B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A04C: BF870112
	v_fma_f32 v29, -v10, v24, v21                              // 00000031A050: D613001D 2456310A
	v_fmac_f32_e32 v25, v30, v16                               // 00000031A058: 5632211E
	v_fmac_f32_e32 v27, v31, v18                               // 00000031A05C: 5636251F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A060: BF870193
	v_fmac_f32_e32 v24, v29, v14                               // 00000031A064: 56301D1D
	v_fma_f32 v11, -v11, v25, v22                              // 00000031A068: D613000B 245A330B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000031A070: BF8700C3
	v_fma_f32 v12, -v12, v27, v26                              // 00000031A074: D613000C 246A370C
	s_waitcnt vmcnt(0)                                         // 00000031A07C: BF8903F7
	v_lshlrev_b32_e32 v1, 16, v1                               // 00000031A080: 30020290
	v_fma_f32 v10, -v10, v24, v21                              // 00000031A084: D613000A 2456310A
	v_div_fmas_f32 v10, v10, v14, v24                          // 00000031A08C: D637000A 04621D0A
	s_mov_b32 vcc_lo, s3                                       // 00000031A094: BEEA0003
	v_div_fmas_f32 v11, v11, v16, v25                          // 00000031A098: D637000B 0466210B
	s_mov_b32 vcc_lo, s4                                       // 00000031A0A0: BEEA0004
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000031A0A4: BF8701C2
	v_div_fixup_f32 v2, v10, v2, 1.0                           // 00000031A0A8: D6270002 03CA050A
	v_div_fmas_f32 v10, v12, v18, v27                          // 00000031A0B0: D637000A 046E250C
	s_mov_b32 vcc_lo, s5                                       // 00000031A0B8: BEEA0005
	v_div_fixup_f32 v7, v11, v7, 1.0                           // 00000031A0BC: D6270007 03CA0F0B
	v_bfe_u32 v11, v2, 16, 1                                   // 00000031A0C4: D610000B 02052102
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A0CC: BF870193
	v_div_fixup_f32 v8, v10, v8, 1.0                           // 00000031A0D0: D6270008 03CA110A
	v_bfe_u32 v10, v7, 16, 1                                   // 00000031A0D8: D610000A 02052107
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A0E0: BF870193
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000031A0E4: D6550002 03FE1702 00007FFF
	v_bfe_u32 v11, v8, 16, 1                                   // 00000031A0F0: D610000B 02052108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000031A0F8: BF870223
	v_add3_u32 v7, v7, v10, 0x7fff                             // 00000031A0FC: D6550007 03FE1507 00007FFF
	v_lshlrev_b32_e32 v10, 16, v19                             // 00000031A108: 30142690
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000031A10C: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000031A114: BF870234
	v_add3_u32 v8, v8, v11, 0x7fff                             // 00000031A118: D6550008 03FE1708 00007FFF
	v_lshlrev_b32_e32 v11, 16, v17                             // 00000031A124: 30162290
	v_dual_mul_f32 v28, v23, v20 :: v_dual_and_b32 v7, 0xffff0000, v7// 00000031A128: C8E42917 1C060EFF FFFF0000
	v_fma_f32 v2, v2, v10, 0                                   // 00000031A134: D6130002 02021502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000031A13C: BF870224
	v_and_b32_e32 v8, 0xffff0000, v8                           // 00000031A140: 361010FF FFFF0000
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000031A148: 30141E90
	v_fma_f32 v32, -v13, v28, v23                              // 00000031A14C: D6130020 245E390D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A154: BF870114
	v_fmac_f32_e32 v2, v7, v11                                 // 00000031A158: 56041707
	v_fmac_f32_e32 v28, v32, v20                               // 00000031A15C: 56382920
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A160: BF870112
	v_fmac_f32_e32 v2, v8, v10                                 // 00000031A164: 56041508
	v_fma_f32 v13, -v13, v28, v23                              // 00000031A168: D613000D 245E390D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A170: BF870091
	v_div_fmas_f32 v12, v13, v20, v28                          // 00000031A174: D637000C 0472290D
	v_div_fixup_f32 v9, v12, v9, 1.0                           // 00000031A17C: D6270009 03CA130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A184: BF870091
	v_bfe_u32 v12, v9, 16, 1                                   // 00000031A188: D610000C 02052109
	v_add3_u32 v9, v9, v12, 0x7fff                             // 00000031A190: D6550009 03FE1909 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A19C: BF870091
	v_and_b32_e32 v7, 0xffff0000, v9                           // 00000031A1A0: 360E12FF FFFF0000
	v_fmac_f32_e32 v2, v7, v1                                  // 00000031A1A8: 56040307
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A1AC: BF870091
	v_mul_f32_e32 v1, 0x3e800000, v2                           // 00000031A1B0: 100204FF 3E800000
	v_bfe_u32 v2, v1, 16, 1                                    // 00000031A1B8: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031A1C0: BF8700A1
	v_add3_u32 v7, v1, v2, 0x7fff                              // 00000031A1C4: D6550007 03FE0501 00007FFF
	.long 0xd7006a02                                           // 00000031A1D0: D7006A02
	v_cndmask_b32_e32 v1, 0x1000, v3, vcc_lo                   // 00000031A1D4: 020206FF 00001000
	v_add_co_ci_u32_e64 v3, null, 0, v4, vcc_lo                // 00000031A1DC: D5207C03 01AA0880
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000031A1E4: 916A077E
	global_store_d16_hi_b16 v[2:3], v7, off offset:1024        // 00000031A1E8: DC960400 007C0702
	s_cbranch_vccnz 13                                         // 00000031A1F0: BFA4000D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2628>
	.long 0xd7006a02                                           // 00000031A1F4: D7006A02
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000031A1F8: 02020A0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A1FC: BF870111
	v_add_co_ci_u32_e64 v3, null, s11, v6, vcc_lo              // 00000031A200: D5207C03 01AA0C0B
	.long 0xd7006a02                                           // 00000031A208: D7006A02
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 00000031A20C: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031A214: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000031A218: D5207C03 01AA0680
	global_store_b32 v[2:3], v1, off offset:2048               // 00000031A220: DC6A0800 007C0102
	s_or_b32 exec_lo, exec_lo, s6                              // 00000031A228: 8C7E067E
	s_mov_b32 s25, 0                                           // 00000031A22C: BE990080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A230: BF870009
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000031A234: 8B6A197E
	s_cbranch_vccz 485                                         // 00000031A238: BFA301E5 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2dd0>
	s_clause 0x3                                               // 00000031A23C: BF850003
	s_load_b32 s3, s[0:1], 0x148                               // 00000031A240: F40000C0 F8000148
	s_load_b32 s4, s[0:1], 0xb0                                // 00000031A248: F4000100 F80000B0
	s_load_b32 s6, s[0:1], 0xf8                                // 00000031A250: F4000180 F80000F8
	s_load_b32 s7, s[0:1], 0x140                               // 00000031A258: F40001C0 F8000140
	s_sub_i32 s5, s2, s24                                      // 00000031A260: 81851802
	v_lshrrev_b32_e32 v3, 5, v0                                // 00000031A264: 32060085
	s_waitcnt lgkmcnt(0)                                       // 00000031A268: BF89FC07
	v_dual_mov_b32 v22, 0 :: v_dual_and_b32 v15, 31, v0        // 00000031A26C: CA240080 160E009F
	s_cmp_gt_i32 s3, 1                                         // 00000031A274: BF028103
	s_cselect_b32 s8, -1, 0                                    // 00000031A278: 980880C1
	s_cmp_ge_i32 s5, s4                                        // 00000031A27C: BF030405
	s_cselect_b32 s4, -1, 0                                    // 00000031A280: 980480C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A284: BF870009
	s_and_b32 s4, s8, s4                                       // 00000031A288: 8B040408
	s_cmp_gt_i32 s3, 2                                         // 00000031A28C: BF028203
	v_cndmask_b32_e64 v1, 0, 1, s4                             // 00000031A290: D5010001 00110280
	s_cselect_b32 s8, -1, 0                                    // 00000031A298: 980880C1
	s_cmp_ge_i32 s5, s6                                        // 00000031A29C: BF030605
	s_cselect_b32 s6, -1, 0                                    // 00000031A2A0: 980680C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A2A4: BF870009
	s_and_b32 s4, s8, s6                                       // 00000031A2A8: 8B040608
	s_cmp_gt_i32 s3, 3                                         // 00000031A2AC: BF028303
	v_readfirstlane_b32 s6, v1                                 // 00000031A2B0: 7E0C0501
	s_cselect_b32 s3, -1, 0                                    // 00000031A2B4: 980380C1
	s_cmp_ge_i32 s5, s7                                        // 00000031A2B8: BF030705
	s_cselect_b32 s7, -1, 0                                    // 00000031A2BC: 980780C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000031A2C0: BF8704D9
	s_and_b32 s3, s3, s7                                       // 00000031A2C4: 8B030703
	s_and_b32 s4, s4, exec_lo                                  // 00000031A2C8: 8B047E04
	s_cselect_b32 s4, 2, s6                                    // 00000031A2CC: 98040682
	s_and_b32 s3, s3, exec_lo                                  // 00000031A2D0: 8B037E03
	s_cselect_b32 s3, 3, s4                                    // 00000031A2D4: 98030483
	s_mulk_i32 s3, 0x48                                        // 00000031A2D8: B8030048
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A2DC: BF870009
	s_add_u32 s10, s0, s3                                      // 00000031A2E0: 800A0300
	s_addc_u32 s11, s1, 0                                      // 00000031A2E4: 820B8001
	s_clause 0x1                                               // 00000031A2E8: BF850001
	s_load_b64 s[6:7], s[10:11], 0x58                          // 00000031A2EC: F4040185 F8000058
	s_load_b32 s3, s[10:11], 0x68                              // 00000031A2F4: F40000C5 F8000068
	s_add_u32 s8, s10, 40                                      // 00000031A2FC: 8008A80A
	s_addc_u32 s9, s11, 0                                      // 00000031A300: 8209800B
	s_load_b64 s[10:11], s[10:11], 0x28                        // 00000031A304: F4040285 F8000028
	s_waitcnt lgkmcnt(0)                                       // 00000031A30C: BF89FC07
	.long 0xd4510013                                           // 00000031A310: D4510013
	v_cndmask_b32_e32 v0, s6, v137, vcc_lo                     // 00000031A314: 02011206
	s_and_b32 s4, s19, exec_lo                                 // 00000031A318: 8B047E13
	s_cselect_b32 s18, 8, 2                                    // 00000031A31C: 98128288
	s_cselect_b32 s24, 3, 1                                    // 00000031A320: 98188183
	v_cvt_f32_ubyte0_e32 v1, s18                               // 00000031A324: 7E022212
	s_sub_i32 s26, s5, s3                                      // 00000031A328: 819A0305
	s_add_i32 s3, s18, -1                                      // 00000031A32C: 8103C112
	s_ashr_i32 s27, s26, 31                                    // 00000031A330: 861B9F1A
	s_and_b32 s4, s19, exec_lo                                 // 00000031A334: 8B047E13
	v_rcp_iflag_f32_e32 v1, v1                                 // 00000031A338: 7E025701
	s_cselect_b32 s25, 0, 2                                    // 00000031A33C: 98198280
	s_ashr_i32 s4, s23, 31                                     // 00000031A340: 86049F17
	s_lshl_b64 s[26:27], s[26:27], s25                         // 00000031A344: 849A191A
	s_lshr_b32 s4, s4, 28                                      // 00000031A348: 85049C04
	v_lshrrev_b32_e32 v13, s24, v3                             // 00000031A34C: 321A0618
	s_add_u32 s28, s22, s4                                     // 00000031A350: 801C0416
	s_addc_u32 s29, s23, 0                                     // 00000031A354: 821D8017
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031A358: BF870299
	s_ashr_i64 s[28:29], s[28:29], 4                           // 00000031A35C: 869C841C
	v_readfirstlane_b32 s30, v1                                // 00000031A360: 7E3C0501
	.long 0xd7001a01                                           // 00000031A364: D7001A01
	v_cndmask_b32_e32 v1, s26, v13, vcc_lo                     // 00000031A368: 02021A1A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031A36C: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, 0, s26                  // 00000031A370: D5207C02 0069001B
	s_mul_f32 s4, s30, 0x4f7ffffe                              // 00000031A378: A204FF1E 4F7FFFFE
	s_add_u32 s30, s28, s22                                    // 00000031A380: 801E161C
	s_addc_u32 s29, s29, s23                                   // 00000031A384: 821D171D
	s_sub_i32 s31, 0, s18                                      // 00000031A388: 819F1280
	s_cvt_u32_f32 s4, s4                                       // 00000031A38C: BE846704
	s_add_i32 s33, s3, s28                                     // 00000031A390: 81211C03
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 00000031A394: 7CA80206
	s_abs_i32 s34, s33                                         // 00000031A398: BEA21521
	s_mul_i32 s31, s31, s4                                     // 00000031A39C: 961F041F
	s_ashr_i32 s27, s33, 31                                    // 00000031A3A0: 861B9F21
	s_mul_hi_u32 s31, s4, s31                                  // 00000031A3A4: 969F1F04
	v_dual_cndmask_b32 v1, 0, v1 :: v_dual_and_b32 v14, s3, v3 // 00000031A3A8: CA640280 010E0603
	s_add_i32 s4, s4, s31                                      // 00000031A3B0: 81041F04
	v_cndmask_b32_e32 v2, 0, v2, vcc_lo                        // 00000031A3B4: 02040480
	s_mul_hi_u32 s4, s34, s4                                   // 00000031A3B8: 96840422
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A3BC: BF870009
	s_mul_i32 s26, s4, s18                                     // 00000031A3C0: 961A1204
	s_add_i32 s31, s4, 1                                       // 00000031A3C4: 811F8104
	s_sub_i32 s26, s34, s26                                    // 00000031A3C8: 819A1A22
	.long 0xd72c0004                                           // 00000031A3CC: D72C0004
	v_cndmask_b32_e32 v0, v2, v30, vcc_lo                      // 00000031A3D0: 02003D02
	s_sub_i32 s33, s26, s18                                    // 00000031A3D4: 81A1121A
	s_cmp_ge_u32 s26, s18                                      // 00000031A3D8: BF09121A
	.long 0xd72c0006                                           // 00000031A3DC: D72C0006
	v_cndmask_b32_e32 v0, v1, v29, vcc_lo                      // 00000031A3E0: 02003B01
	s_cselect_b32 s4, s31, s4                                  // 00000031A3E4: 9804041F
	s_cselect_b32 s26, s33, s26                                // 00000031A3E8: 981A1A21
	s_add_i32 s31, s4, 1                                       // 00000031A3EC: 811F8104
	s_cmp_ge_u32 s26, s18                                      // 00000031A3F0: BF09121A
	v_mad_u64_u32 v[9:10], null, v1, s30, s[10:11]             // 00000031A3F4: D6FE7C09 00283D01
	s_cselect_b32 s3, s31, s4                                  // 00000031A3FC: 9803041F
	v_mov_b32_e32 v1, 0                                        // 00000031A400: 7E020280
	s_xor_b32 s3, s3, s27                                      // 00000031A404: 8D031B03
	v_mov_b32_e32 v2, 0                                        // 00000031A408: 7E040280
	s_sub_i32 s3, s3, s27                                      // 00000031A40C: 81831B03
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000031A410: BF8701D9
	.long 0xd72c0005                                           // 00000031A414: D72C0005
	v_cndmask_b32_e32 v0, v14, v3, vcc_lo                      // 00000031A418: 0200070E
	v_mov_b32_e32 v3, 0                                        // 00000031A41C: 7E060280
	v_add3_u32 v10, v4, v10, v6                                // 00000031A420: D655000A 041A1504
	.long 0xd7006a12                                           // 00000031A428: D7006A12
	v_cndmask_b32_e32 v0, v9, v22, vcc_lo                      // 00000031A42C: 02002D09
	v_mov_b32_e32 v4, 0                                        // 00000031A430: 7E080280
	v_add_co_ci_u32_e64 v19, null, s23, v10, vcc_lo            // 00000031A434: D5207C13 01AA1417
	v_add_nc_u32_e32 v7, s3, v5                                // 00000031A43C: 4A0E0A03
	v_add_nc_u32_e32 v16, v5, v15                              // 00000031A440: 4A201F05
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031A444: BF870092
	v_min_i32_e32 v17, s28, v7                                 // 00000031A448: 22220E1C
	.long 0xd4410004                                           // 00000031A44C: D4410004
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 00000031A450: 02022310
	s_and_saveexec_b32 s3, s4                                  // 00000031A454: BE832004
	s_cbranch_execz 19                                         // 00000031A458: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x28a8>
	v_lshlrev_b32_e32 v1, 4, v16                               // 00000031A45C: 30022084
	v_and_b32_e32 v3, -4, v16                                  // 00000031A460: 360620C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A464: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000031A468: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000031A46C: 3408069F
	.long 0xd7006a01                                           // 00000031A470: D7006A01
	v_cndmask_b32_e32 v1, v9, v1, vcc_lo                       // 00000031A474: 02020309
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031A478: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v10, v2, vcc_lo              // 00000031A47C: D5207C02 01AA050A
	.long 0xd7006a06                                           // 00000031A484: D7006A06
	v_cndmask_b32_e32 v1, v18, v3, vcc_lo                      // 00000031A488: 02020712
	v_add_co_ci_u32_e64 v7, null, v19, v4, vcc_lo              // 00000031A48C: D5207C07 01AA0913
	s_clause 0x1                                               // 00000031A494: BF850001
	global_load_b128 v[1:4], v[1:2], off                       // 00000031A498: DC5E0000 017C0001
	global_load_b32 v22, v[6:7], off                           // 00000031A4A0: DC520000 167C0006
	s_or_b32 exec_lo, exec_lo, s3                              // 00000031A4A8: 8C7E037E
	.long 0xd44a0003                                           // 00000031A4AC: D44A0003
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000031A4B0: 02020080
	s_and_saveexec_b32 s10, s3                                 // 00000031A4B4: BE8A2003
	s_cbranch_execz 20                                         // 00000031A4B8: BFA50014 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x290c>
	v_mov_b32_e32 v6, 0                                        // 00000031A4BC: 7E0C0280
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 00000031A4C0: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 00000031A4C8: BF8903F7
	buffer_gl1_inv                                             // 00000031A4CC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000031A4D4: E0AC0000 00000000
	v_cmp_le_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 00000031A4DC: 7CB60E0E
	s_cbranch_vccnz 10                                         // 00000031A4E0: BFA4000A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x290c>
	s_sleep 1                                                  // 00000031A4E4: BF830001
	global_load_b64 v[7:8], v6, s[12:13] glc                   // 00000031A4E8: DC564000 070C0006
	s_waitcnt vmcnt(0)                                         // 00000031A4F0: BF8903F7
	buffer_gl1_inv                                             // 00000031A4F4: E0B00000 00000000
	buffer_gl0_inv                                             // 00000031A4FC: E0AC0000 00000000
	v_cmp_gt_u64_e32 vcc_lo, s[14:15], v[7:8]                  // 00000031A504: 7CB80E0E
	s_cbranch_vccnz 65526                                      // 00000031A508: BFA4FFF6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x28e4>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000031A50C: 8C7E0A7E
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v20, 0             // 00000031A510: CA100080 15140080
	s_waitcnt vmcnt(0)                                         // 00000031A518: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 00000031A51C: BC7C0000
	s_barrier                                                  // 00000031A520: BFBD0000
	buffer_gl0_inv                                             // 00000031A524: E0AC0000 00000000
	buffer_gl1_inv                                             // 00000031A52C: E0B00000 00000000
	buffer_gl0_inv                                             // 00000031A534: E0AC0000 00000000
	s_and_saveexec_b32 s14, s4                                 // 00000031A53C: BE8E2004
	s_cbranch_execz 684                                        // 00000031A540: BFA502AC <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x33f4>
	v_dual_mov_b32 v21, 0 :: v_dual_lshlrev_b32 v6, 4, v15     // 00000031A544: CA220080 15061E84
	v_mov_b32_e32 v20, 0                                       // 00000031A54C: 7E280280
	s_mov_b32 s15, 0                                           // 00000031A550: BE8F0080
	s_lshl_b64 s[10:11], s[22:23], 1                           // 00000031A554: 848A8116
	s_delay_alu instid0(VALU_DEP_2)                            // 00000031A558: BF870002
	v_lshl_add_u32 v11, v5, 4, v6                              // 00000031A55C: D646000B 04190905
	s_branch 245                                               // 00000031A564: BFA000F5 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2d3c>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000031A568: 8C7E167E
	v_ashrrev_i32_e32 v12, 31, v11                             // 00000031A56C: 3418169F
	v_cvt_f32_ubyte1_e32 v41, v1                               // 00000031A570: 7E522501
	v_cvt_f32_ubyte2_e32 v42, v1                               // 00000031A574: 7E542701
	v_cvt_f32_ubyte0_e32 v43, v2                               // 00000031A578: 7E562302
	v_cvt_f32_ubyte1_e32 v44, v2                               // 00000031A57C: 7E582502
	.long 0xd73c000b                                           // 00000031A580: D73C000B
	v_cndmask_b32_e32 v1, 1, v11, vcc_lo                       // 00000031A584: 02021681
	v_cvt_f32_ubyte2_e32 v45, v2                               // 00000031A588: 7E5A2702
	v_cvt_f32_ubyte3_e32 v2, v2                                // 00000031A58C: 7E042902
	v_cvt_f32_ubyte0_e32 v46, v3                               // 00000031A590: 7E5C2303
	v_cvt_f32_ubyte1_e32 v47, v3                               // 00000031A594: 7E5E2503
	v_cvt_f32_ubyte2_e32 v48, v3                               // 00000031A598: 7E602703
	.long 0xd700040b                                           // 00000031A59C: D700040B
	v_cndmask_b32_e32 v1, s20, v11, vcc_lo                     // 00000031A5A0: 02021614
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000031A5A4: BF8701A1
	v_add_co_ci_u32_e64 v12, null, s21, v12, s4                // 00000031A5A8: D5207C0C 00121815
	v_cvt_f32_ubyte3_e32 v3, v3                                // 00000031A5B0: 7E062903
	.long 0xd7000425                                           // 00000031A5B4: D7000425
	v_cndmask_b32_e32 v0, v11, v10, vcc_lo                     // 00000031A5B8: 0200150B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031A5BC: BF870001
	v_add_co_ci_u32_e64 v38, null, s11, v12, s4                // 00000031A5C0: D5207C26 0012180B
	v_cvt_f32_ubyte0_e32 v49, v4                               // 00000031A5C8: 7E622304
	v_cvt_f32_ubyte1_e32 v50, v4                               // 00000031A5CC: 7E642504
	s_clause 0x3                                               // 00000031A5D0: BF850003
	global_load_b128 v[25:28], v[11:12], off                   // 00000031A5D4: DC5E0000 197C000B
	global_load_b128 v[29:32], v[37:38], off                   // 00000031A5DC: DC5E0000 1D7C0025
	global_load_b128 v[33:36], v[11:12], off offset:16         // 00000031A5E4: DC5E0010 217C000B
	global_load_b128 v[37:40], v[37:38], off offset:16         // 00000031A5EC: DC5E0010 257C0025
	v_cvt_f32_ubyte0_e32 v11, v1                               // 00000031A5F4: 7E162301
	v_cvt_f32_ubyte3_e32 v1, v1                                // 00000031A5F8: 7E022901
	v_cvt_f32_ubyte2_e32 v51, v4                               // 00000031A5FC: 7E662704
	v_cvt_f32_ubyte3_e32 v4, v4                                // 00000031A600: 7E082904
	v_fma_mix_f32 v41, v41, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A604: CC206029 145A2D29
	v_fma_mix_f32 v11, v11, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A60C: CC20600B 145A2D0B
	v_fma_mix_f32 v42, v42, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A614: CC20602A 145A2D2A
	v_fma_mix_f32 v1, v1, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A61C: CC206001 145A2D01
	v_fma_mix_f32 v43, v43, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A624: CC20602B 145A2D2B
	v_fma_mix_f32 v44, v44, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A62C: CC20602C 145A2D2C
	v_fma_mix_f32 v45, v45, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A634: CC20602D 145A2D2D
	v_fma_mix_f32 v2, v2, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A63C: CC206002 145A2D02
	v_fma_mix_f32 v46, v46, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A644: CC20602E 145A2D2E
	v_fma_mix_f32 v47, v47, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A64C: CC20602F 145A2D2F
	v_fma_mix_f32 v48, v48, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A654: CC206030 145A2D30
	v_fma_mix_f32 v3, v3, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A65C: CC206003 145A2D03
	v_fma_mix_f32 v49, v49, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A664: CC206031 145A2D31
	v_fma_mix_f32 v50, v50, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A66C: CC206032 145A2D32
	v_fma_mix_f32 v51, v51, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A674: CC206033 145A2D33
	v_fma_mix_f32 v4, v4, v22, v22 op_sel:[0,0,1] op_sel_hi:[0,1,1]// 00000031A67C: CC206004 145A2D04
	v_bfe_u32 v22, v11, 16, 1                                  // 00000031A684: D6100016 0205210B
	v_bfe_u32 v56, v41, 16, 1                                  // 00000031A68C: D6100038 02052129
	v_bfe_u32 v57, v42, 16, 1                                  // 00000031A694: D6100039 0205212A
	.long 0x7f183880                                           // 00000031A69C: 7F183880
	v_bfe_u32 v58, v1, 16, 1                                   // 00000031A6A0: D610003A 02052101
	v_add3_u32 v11, v11, v22, 0x7fff                           // 00000031A6A8: D655000B 03FE2D0B 00007FFF
	v_bfe_u32 v59, v43, 16, 1                                  // 00000031A6B4: D610003B 0205212B
	v_add3_u32 v22, v41, v56, 0x7fff                           // 00000031A6BC: D6550016 03FE7129 00007FFF
	v_add3_u32 v41, v42, v57, 0x7fff                           // 00000031A6C8: D6550029 03FE732A 00007FFF
	.long 0x7f68398c                                           // 00000031A6D4: 7F68398C
	.long 0x7e18398b                                           // 00000031A6D8: 7E18398B
	v_bfe_u32 v60, v44, 16, 1                                  // 00000031A6DC: D610003C 0205212C
	v_bfe_u32 v61, v45, 16, 1                                  // 00000031A6E4: D610003D 0205212D
	v_add3_u32 v1, v1, v58, 0x7fff                             // 00000031A6EC: D6550001 03FE7501 00007FFF
	v_add3_u32 v42, v43, v59, 0x7fff                           // 00000031A6F8: D655002A 03FE772B 00007FFF
	.long 0x7e6839a9                                           // 00000031A704: 7E6839A9
	v_and_or_b32 v22, 0xffff0000, v22, v12                     // 00000031A708: D6570016 04322CFF FFFF0000
	v_bfe_u32 v62, v2, 16, 1                                   // 00000031A714: D610003E 02052102
	v_bfe_u32 v63, v46, 16, 1                                  // 00000031A71C: D610003F 0205212E
	v_add3_u32 v43, v44, v60, 0x7fff                           // 00000031A724: D655002B 03FE792C 00007FFF
	v_add3_u32 v11, v45, v61, 0x7fff                           // 00000031A730: D655000B 03FE7B2D 00007FFF
	v_and_or_b32 v1, 0xffff0000, v1, v52                       // 00000031A73C: D6570001 04D202FF FFFF0000
	.long 0x7e1839aa                                           // 00000031A748: 7E1839AA
	.long 0x7f6a398c                                           // 00000031A74C: 7F6A398C
	v_bfe_u32 v64, v47, 16, 1                                  // 00000031A750: D6100040 0205212F
	v_bfe_u32 v65, v48, 16, 1                                  // 00000031A758: D6100041 02052130
	v_add3_u32 v2, v2, v62, 0x7fff                             // 00000031A760: D6550002 03FE7D02 00007FFF
	v_add3_u32 v41, v46, v63, 0x7fff                           // 00000031A76C: D6550029 03FE7F2E 00007FFF
	.long 0x7e6a398b                                           // 00000031A778: 7E6A398B
	v_and_or_b32 v11, 0xffff0000, v43, v12                     // 00000031A77C: D657000B 043256FF FFFF0000
	v_bfe_u32 v66, v3, 16, 1                                   // 00000031A788: D6100042 02052103
	v_bfe_u32 v67, v49, 16, 1                                  // 00000031A790: D6100043 02052131
	v_add3_u32 v44, v47, v64, 0x7fff                           // 00000031A798: D655002C 03FE812F 00007FFF
	v_add3_u32 v45, v48, v65, 0x7fff                           // 00000031A7A4: D655002D 03FE8330 00007FFF
	v_and_or_b32 v2, 0xffff0000, v2, v53                       // 00000031A7B0: D6570002 04D604FF FFFF0000
	.long 0x7e1839a9                                           // 00000031A7BC: 7E1839A9
	.long 0x7f6c398c                                           // 00000031A7C0: 7F6C398C
	v_bfe_u32 v68, v50, 16, 1                                  // 00000031A7C4: D6100044 02052132
	v_bfe_u32 v69, v51, 16, 1                                  // 00000031A7CC: D6100045 02052133
	v_add3_u32 v3, v3, v66, 0x7fff                             // 00000031A7D4: D6550003 03FE8503 00007FFF
	.long 0x7e6c39ad                                           // 00000031A7E0: 7E6C39AD
	v_bfe_u32 v70, v4, 16, 1                                   // 00000031A7E4: D6100046 02052104
	.long 0x7f6e398c                                           // 00000031A7EC: 7F6E398C
	s_and_b32 s4, exec_lo, vcc_lo                              // 00000031A7F0: 8B046A7E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A7F4: BF870193
	v_and_or_b32 v3, 0xffff0000, v3, v54                       // 00000031A7F8: D6570003 04DA06FF FFFF0000
	v_add3_u32 v4, v4, v70, 0x7fff                             // 00000031A804: D6550004 03FE8D04 00007FFF
	s_or_b32 s15, s4, s15                                      // 00000031A810: 8C0F0F04
	s_waitcnt vmcnt(3)                                         // 00000031A814: BF890FF7
	v_dot2_f32_bf16 v25, v25, v22, 0                           // 00000031A818: CC1A4019 1A022D19
	s_waitcnt vmcnt(2)                                         // 00000031A820: BF890BF7
	v_dot2_f32_bf16 v22, v29, v22, 0                           // 00000031A824: CC1A4016 1A022D1D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A82C: BF870112
	v_dot2_f32_bf16 v25, v26, v1, v25                          // 00000031A830: CC1A4019 1C66031A
	v_dot2_f32_bf16 v1, v30, v1, v22                           // 00000031A838: CC1A4001 1C5A031E
	v_add3_u32 v22, v49, v67, 0x7fff                           // 00000031A840: D6550016 03FE8731 00007FFF
	v_and_or_b32 v26, 0xffff0000, v44, v12                     // 00000031A84C: D657001A 043258FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A858: BF870214
	v_dot2_f32_bf16 v25, v27, v11, v25                         // 00000031A85C: CC1A4019 1C66171B
	v_dot2_f32_bf16 v1, v31, v11, v1                           // 00000031A864: CC1A4001 1C06171F
	v_add3_u32 v11, v50, v68, 0x7fff                           // 00000031A86C: D655000B 03FE8932 00007FFF
	.long 0x7e183996                                           // 00000031A878: 7E183996
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A87C: BF870214
	v_dot2_f32_bf16 v25, v28, v2, v25                          // 00000031A880: CC1A4019 1C66051C
	v_dot2_f32_bf16 v1, v32, v2, v1                            // 00000031A888: CC1A4001 1C060520
	v_add3_u32 v2, v51, v69, 0x7fff                            // 00000031A890: D6550002 03FE8B33 00007FFF
	s_waitcnt vmcnt(1)                                         // 00000031A89C: BF8907F7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000031A8A0: BF870003
	v_dot2_f32_bf16 v22, v33, v26, v25                         // 00000031A8A4: CC1A4016 1C663521
	s_waitcnt vmcnt(0)                                         // 00000031A8AC: BF8903F7
	v_dot2_f32_bf16 v1, v37, v26, v1                           // 00000031A8B0: CC1A4001 1C063525
	.long 0x7e6e3982                                           // 00000031A8B8: 7E6E3982
	v_and_or_b32 v2, 0xffff0000, v11, v12                      // 00000031A8BC: D6570002 043216FF FFFF0000
	v_dot2_f32_bf16 v11, v34, v3, v22                          // 00000031A8C8: CC1A400B 1C5A0722
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A8D0: BF870214
	v_dot2_f32_bf16 v1, v38, v3, v1                            // 00000031A8D4: CC1A4001 1C060726
	v_and_or_b32 v12, 0xffff0000, v4, v55                      // 00000031A8DC: D657000C 04DE08FF FFFF0000
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 00000031A8E8: CA100108 04020107
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A8F0: BF870214
	v_dot2_f32_bf16 v11, v35, v2, v11                          // 00000031A8F4: CC1A400B 1C2E0523
	v_dot2_f32_bf16 v1, v39, v2, v1                            // 00000031A8FC: CC1A4001 1C060527
	v_mov_b32_e32 v2, v6                                       // 00000031A904: 7E040306
	v_mov_b32_e32 v22, v24                                     // 00000031A908: 7E2C0318
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000031A90C: BF870214
	v_dot2_f32_bf16 v7, v36, v12, v11                          // 00000031A910: CC1A4007 1C2E1924
	v_dot2_f32_bf16 v8, v40, v12, v1                           // 00000031A918: CC1A4008 1C061928
	v_mov_b32_e32 v1, v5                                       // 00000031A920: 7E020305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A924: BF870193
	v_dual_mov_b32 v11, v23 :: v_dual_add_f32 v20, v20, v7     // 00000031A928: CA080117 0B140F14
	v_add_f32_e32 v21, v21, v8                                 // 00000031A930: 062A1115
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000031A934: 917E0F7E
	s_cbranch_execz 429                                        // 00000031A938: BFA501AD <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x33f0>
	v_add_nc_u32_e32 v16, 32, v16                              // 00000031A93C: 4A2020A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031A940: BF870112
	v_add_nc_u32_e32 v23, 0x200, v11                           // 00000031A944: 4A2E16FF 00000200
	v_cmp_ge_i32_e32 vcc_lo, v16, v17                          // 00000031A94C: 7C8C2310
	s_and_saveexec_b32 s4, vcc_lo                              // 00000031A950: BE84206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A954: BF870009
	s_xor_b32 s4, exec_lo, s4                                  // 00000031A958: 8D04047E
	v_add_nc_u32_e32 v23, 0x200, v11                           // 00000031A95C: 4A2E16FF 00000200
	s_or_saveexec_b32 s22, s4                                  // 00000031A964: BE962204
	v_dual_mov_b32 v24, v22 :: v_dual_mov_b32 v5, v1           // 00000031A968: CA100116 18040101
	v_dual_mov_b32 v6, v2 :: v_dual_mov_b32 v7, v3             // 00000031A970: CA100102 06060103
	v_mov_b32_e32 v8, v4                                       // 00000031A978: 7E100304
	s_xor_b32 exec_lo, exec_lo, s22                            // 00000031A97C: 8D7E167E
	s_cbranch_execz 65273                                      // 00000031A980: BFA5FEF9 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2968>
	v_and_b32_e32 v7, -4, v16                                  // 00000031A984: 360E20C4
	v_ashrrev_i32_e32 v6, 31, v23                              // 00000031A988: 340C2E9F
	.long 0xd7000405                                           // 00000031A98C: D7000405
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 00000031A990: 02022F09
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031A994: BF870193
	v_ashrrev_i32_e32 v8, 31, v7                               // 00000031A998: 34100E9F
	v_add_co_ci_u32_e64 v6, null, v10, v6, s4                  // 00000031A99C: D5207C06 00120D0A
	.long 0xd7000418                                           // 00000031A9A4: D7000418
	v_cndmask_b32_e32 v1, v18, v7, vcc_lo                      // 00000031A9A8: 02020F12
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031A9AC: BF870001
	v_add_co_ci_u32_e64 v25, null, v19, v8, s4                 // 00000031A9B0: D5207C19 00121113
	s_clause 0x1                                               // 00000031A9B8: BF850001
	global_load_b128 v[5:8], v[5:6], off                       // 00000031A9BC: DC5E0000 057C0005
	global_load_b32 v24, v[24:25], off                         // 00000031A9C4: DC520000 187C0018
	s_branch 65254                                             // 00000031A9CC: BFA0FEE6 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2968>
	s_mov_b32 s3, 0                                            // 00000031A9D0: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031A9D4: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000031A9D8: 916A037E
	s_cbranch_vccnz 902                                        // 00000031A9DC: BFA40386 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3bf8>
	s_load_b256 s[4:11], s[0:1], null                          // 00000031A9E0: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000031A9E8: 86039F02
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v5, v0              // 00000031A9EC: CA100080 02040100
	s_lshr_b32 s14, s3, 30                                     // 00000031A9F4: 850E9E03
	s_load_b32 s1, s[0:1], 0x1b4                               // 00000031A9F8: F4000040 F80001B4
	s_add_i32 s16, s2, s14                                     // 00000031AA00: 81100E02
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000031AA04: 848E8202
	s_ashr_i32 s3, s16, 2                                      // 00000031AA08: 86038210
	s_mul_i32 s0, s2, 0x1400                                   // 00000031AA0C: 9600FF02 00001400
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, v0              // 00000031AA14: CA100080 04000100
	s_waitcnt lgkmcnt(0)                                       // 00000031AA1C: BF89FC07
	s_add_u32 s8, s8, s14                                      // 00000031AA20: 80080E08
	s_addc_u32 s9, s9, s15                                     // 00000031AA24: 82090F09
	s_add_u32 s0, s4, s0                                       // 00000031AA28: 80000004
	global_load_b32 v3, v2, s[8:9]                             // 00000031AA2C: DC520000 03080002
	s_mul_hi_i32 s8, s2, 0x1400                                // 00000031AA34: 9708FF02 00001400
	s_mul_i32 s9, s3, 0x1400                                   // 00000031AA3C: 9609FF03 00001400
	s_addc_u32 s8, s5, s8                                      // 00000031AA44: 82080805
	s_mul_hi_i32 s14, s3, 0x1400                               // 00000031AA48: 970EFF03 00001400
	s_add_u32 s6, s6, s9                                       // 00000031AA50: 80060906
	s_addc_u32 s7, s7, s14                                     // 00000031AA54: 82070E07
	s_and_b32 s1, s1, 0xffff                                   // 00000031AA58: 8B01FF01 0000FFFF
	s_mov_b32 s9, 0                                            // 00000031AA60: BE890080
	s_set_inst_prefetch_distance 0x1                           // 00000031AA64: BF840001
	s_nop 0                                                    // 00000031AA68: BF800000
	s_nop 0                                                    // 00000031AA6C: BF800000
	s_nop 0                                                    // 00000031AA70: BF800000
	s_nop 0                                                    // 00000031AA74: BF800000
	s_nop 0                                                    // 00000031AA78: BF800000
	s_nop 0                                                    // 00000031AA7C: BF800000
	.long 0xd73c0006                                           // 00000031AA80: D73C0006
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000031AA84: 02020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AA88: BF870091
	.long 0xd7006a08                                           // 00000031AA8C: D7006A08
	v_cndmask_b32_e32 v1, s0, v6, vcc_lo                       // 00000031AA90: 02020C00
	v_add_co_ci_u32_e64 v9, null, s8, v7, vcc_lo               // 00000031AA94: D5207C09 01AA0E08
	.long 0xd7006a06                                           // 00000031AA9C: D7006A06
	v_cndmask_b32_e32 v1, s6, v6, vcc_lo                       // 00000031AAA0: 02020C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031AAA4: BF870001
	v_add_co_ci_u32_e64 v7, null, s7, v7, vcc_lo               // 00000031AAA8: D5207C07 01AA0E07
	global_load_u16 v10, v[8:9], off                           // 00000031AAB0: DC4A0000 0A7C0008
	global_load_u16 v6, v[6:7], off                            // 00000031AAB8: DC4A0000 067C0006
	s_waitcnt vmcnt(1)                                         // 00000031AAC0: BF8907F7
	v_lshlrev_b32_e32 v7, 16, v10                              // 00000031AAC4: 300E1490
	s_waitcnt vmcnt(0)                                         // 00000031AAC8: BF8903F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000031AACC: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AAD0: BF870091
	v_fmac_f32_e32 v7, v3, v6                                  // 00000031AAD4: 560E0D03
	v_bfe_u32 v6, v7, 16, 1                                    // 00000031AAD8: D6100006 02052107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AAE0: BF870091
	v_add3_u32 v6, v7, v6, 0x7fff                              // 00000031AAE4: D6550006 03FE0D07 00007FFF
	v_and_b32_e32 v7, 0xffff0000, v6                           // 00000031AAF0: 360E0CFF FFFF0000
	v_add_nc_u32_e32 v1, s1, v1                                // 00000031AAF8: 4A020201
	global_store_d16_hi_b16 v[8:9], v6, off                    // 00000031AAFC: DC960000 007C0608
	v_fmac_f32_e32 v4, v7, v7                                  // 00000031AB04: 56080F07
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v1                         // 00000031AB08: 7C9202FF 000009FF
	s_or_b32 s9, vcc_lo, s9                                    // 00000031AB10: 8C09096A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031AB14: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000031AB18: 917E097E
	s_cbranch_execnz 65496                                     // 00000031AB1C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2e80>
	s_set_inst_prefetch_distance 0x2                           // 00000031AB20: BF840002
	s_or_b32 exec_lo, exec_lo, s9                              // 00000031AB24: 8C7E097E
	v_lshlrev_b32_e32 v1, 2, v0                                // 00000031AB28: 30020082
	s_lshr_b32 s6, s1, 1                                       // 00000031AB2C: 85068101
	s_mov_b32 s0, 0                                            // 00000031AB30: BE800080
	ds_store_b32 v1, v4                                        // 00000031AB34: D8340000 00000401
	s_waitcnt lgkmcnt(0)                                       // 00000031AB3C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000031AB40: BC7C0000
	s_barrier                                                  // 00000031AB44: BFBD0000
	s_branch 17                                                // 00000031AB48: BFA00011 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f90>
	s_nop 0                                                    // 00000031AB4C: BF800000
	s_nop 0                                                    // 00000031AB50: BF800000
	s_nop 0                                                    // 00000031AB54: BF800000
	s_nop 0                                                    // 00000031AB58: BF800000
	s_nop 0                                                    // 00000031AB5C: BF800000
	s_nop 0                                                    // 00000031AB60: BF800000
	s_nop 0                                                    // 00000031AB64: BF800000
	s_nop 0                                                    // 00000031AB68: BF800000
	s_nop 0                                                    // 00000031AB6C: BF800000
	s_nop 0                                                    // 00000031AB70: BF800000
	s_nop 0                                                    // 00000031AB74: BF800000
	s_nop 0                                                    // 00000031AB78: BF800000
	s_nop 0                                                    // 00000031AB7C: BF800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000031AB80: 8C7E077E
	s_waitcnt lgkmcnt(0)                                       // 00000031AB84: BF89FC07
	s_barrier                                                  // 00000031AB88: BFBD0000
	s_lshr_b32 s6, s6, 1                                       // 00000031AB8C: 85068106
	buffer_gl0_inv                                             // 00000031AB90: E0AC0000 00000000
	s_cbranch_scc0 15                                          // 00000031AB98: BFA1000F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2fd8>
	s_mov_b32 s7, exec_lo                                      // 00000031AB9C: BE87007E
	.long 0xd4cc007e                                           // 00000031ABA0: D4CC007E
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 00000031ABA4: 02020006
	s_cbranch_execz 65525                                      // 00000031ABA8: BFA5FFF5 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f80>
	v_lshl_add_u32 v2, s6, 2, v1                               // 00000031ABAC: D6460002 04050406
	ds_load_b32 v2, v2                                         // 00000031ABB4: D8D80000 02000002
	ds_load_b32 v3, v1                                         // 00000031ABBC: D8D80000 03000001
	s_waitcnt lgkmcnt(0)                                       // 00000031ABC4: BF89FC07
	v_add_f32_e32 v2, v2, v3                                   // 00000031ABC8: 06040702
	ds_store_b32 v1, v2                                        // 00000031ABCC: D8340000 00000201
	s_branch 65514                                             // 00000031ABD4: BFA0FFEA <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2f80>
	v_mov_b32_e32 v1, 0                                        // 00000031ABD8: 7E020280
	s_cmp_eq_u32 s1, 1                                         // 00000031ABDC: BF068101
	s_mul_hi_i32 s6, s2, 0x1400                                // 00000031ABE0: 9706FF02 00001400
	s_mul_i32 s7, s2, 0x1400                                   // 00000031ABE8: 9607FF02 00001400
	ds_load_b32 v1, v1                                         // 00000031ABF0: D8D80000 01000001
	s_waitcnt lgkmcnt(0)                                       // 00000031ABF8: BF89FC07
	v_div_scale_f32 v2, null, 0x45200000, 0x45200000, v1       // 00000031ABFC: D6FC7C02 0405FEFF 45200000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031AC08: BF870001
	v_rcp_f32_e32 v3, v2                                       // 00000031AC0C: 7E065502
	v_xor_b32_e32 v2, 0x80000000, v2                           // 00000031AC10: 3A0404FF 80000000
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 00000031AC18: BF870085
	v_fma_f32 v4, v2, v3, 1.0                                  // 00000031AC1C: D6130004 03CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031AC24: BF8700A1
	v_fmac_f32_e32 v3, v4, v3                                  // 00000031AC28: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, 0x45200000, v1             // 00000031AC2C: D6FC6A04 0405FF01 45200000
	v_mul_f32_e32 v6, v4, v3                                   // 00000031AC38: 100C0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AC3C: BF870091
	v_fma_f32 v7, v2, v6, v4                                   // 00000031AC40: D6130007 04120D02
	v_fmac_f32_e32 v6, v7, v3                                  // 00000031AC48: 560C0707
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AC4C: BF870091
	v_fmac_f32_e32 v4, v2, v6                                  // 00000031AC50: 56080D02
	v_div_fmas_f32 v2, v4, v3, v6                              // 00000031AC54: D6370002 041A0704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AC5C: BF870091
	v_div_fixup_f32 v1, v2, 0x45200000, v1                     // 00000031AC60: D6270001 0405FF02 45200000
	v_add_f32_e32 v1, 0x358637bd, v1                           // 00000031AC6C: 060202FF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031AC74: BF870121
	v_mul_f32_e32 v2, 0x4b800000, v1                           // 00000031AC78: 100402FF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v1                      // 00000031AC80: 7C2802FF 00800000
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000031AC88: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031AC8C: BF870291
	v_rsq_f32_e32 v1, v1                                       // 00000031AC90: 7E025D01
	v_mul_f32_e32 v2, 0x45800000, v1                           // 00000031AC94: 100402FF 45800000
	s_cbranch_scc1 5                                           // 00000031AC9C: BFA20005 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x30b4>
	s_mov_b32 s0, -1                                           // 00000031ACA0: BE8000C1
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031ACA4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 00000031ACA8: 020E0501
	s_cbranch_execz 3                                          // 00000031ACAC: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x30bc>
	s_branch 95                                                // 00000031ACB0: BFA0005F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3230>
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031ACB4: BF870001
	v_cndmask_b32_e32 v7, v1, v2, vcc_lo                       // 00000031ACB8: 020E0501
	v_sub_nc_u32_e32 v8, 0xa00, v0                             // 00000031ACBC: 4C1000FF 00000A00
	v_lshl_or_b32 v2, v0, 1, s7                                // 00000031ACC4: D6560002 001D0300
	s_mul_i32 s0, s2, 0xa00                                    // 00000031ACCC: 9600FF02 00000A00
	v_mov_b32_e32 v6, s6                                       // 00000031ACD4: 7E0C0206
	v_or_b32_e32 v1, s0, v0                                    // 00000031ACD8: 38020000
	v_and_b32_e32 v9, 0xbfe, v8                                // 00000031ACDC: 361210FF 00000BFE
	.long 0xd7006a03                                           // 00000031ACE4: D7006A03
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000031ACE8: 02020404
	s_mul_i32 s0, s3, 0x2800                                   // 00000031ACEC: 9600FF03 00002800
	v_add_co_ci_u32_e64 v4, null, s5, v6, vcc_lo               // 00000031ACF4: D5207C04 01AA0C05
	.long 0xd7006a05                                           // 00000031ACFC: D7006A05
	v_cndmask_b32_e32 v1, s20, v2, vcc_lo                      // 00000031AD00: 02020414
	v_subrev_nc_u32_e32 v1, s0, v1                             // 00000031AD04: 4E020200
	v_add_co_ci_u32_e64 v6, null, s21, v6, vcc_lo              // 00000031AD08: D5207C06 01AA0C15
	v_mov_b32_e32 v10, v9                                      // 00000031AD10: 7E140309
	s_mov_b32 s8, 0                                            // 00000031AD14: BE880080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031AD18: BF8700B3
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000031AD1C: 3404029F
	global_load_b32 v13, v[3:4], off                           // 00000031AD20: DC520000 0D7C0003
	.long 0xd73c000b                                           // 00000031AD28: D73C000B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000031AD2C: 02020281
	.long 0xd7006a0b                                           // 00000031AD30: D7006A0B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 00000031AD34: 0202160A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031AD38: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s11, v12, vcc_lo            // 00000031AD3C: D5207C0C 01AA180B
	.long 0xd7006a03                                           // 00000031AD44: D7006A03
	v_cndmask_b32_e32 v0, v3, v132, vcc_lo                     // 00000031AD48: 02010903
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000031AD4C: D5207C04 01AA0880
	global_load_b32 v2, v[11:12], off                          // 00000031AD54: DC520000 027C000B
	.long 0x7f163880                                           // 00000031AD5C: 7F163880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000031AD60: BF8700D1
	.long 0x7f18398b                                           // 00000031AD64: 7F18398B
	s_waitcnt vmcnt(1)                                         // 00000031AD68: BF8907F7
	.long 0x7e1c390d                                           // 00000031AD6C: 7E1C390D
	s_waitcnt vmcnt(0)                                         // 00000031AD70: BF8903F7
	.long 0x7e1e3902                                           // 00000031AD74: 7E1E3902
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000031AD78: 301E1E90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AD7C: BF870091
	v_dual_add_f32 v15, 1.0, v15 :: v_dual_lshlrev_b32 v14, 16, v14// 00000031AD80: C9221EF2 0F0E1C90
	v_dual_mul_f32 v14, v7, v14 :: v_dual_add_nc_u32 v1, 2, v1 // 00000031AD88: C8E01D07 0E000282
	v_and_b32_e32 v2, 0xffff0000, v2                           // 00000031AD90: 360404FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AD98: BF870091
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_and_b32 v13, 0xffff0000, v13// 00000031AD9C: C92404F2 020C1AFF FFFF0000
	v_dual_mul_f32 v13, v7, v13 :: v_dual_add_nc_u32 v10, -2, v10// 00000031ADA8: C8E01B07 0D0A14C2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031ADB0: BF870111
	v_cmp_eq_u32_e32 vcc_lo, 0, v10                            // 00000031ADB4: 7C941480
	v_dual_mul_f32 v2, v13, v2 :: v_dual_mul_f32 v13, v14, v15 // 00000031ADB8: C8C6050D 020C1F0E
	s_or_b32 s8, vcc_lo, s8                                    // 00000031ADC0: 8C08086A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031ADC4: BF870111
	.long 0x7e163982                                           // 00000031ADC8: 7E163982
	.long 0x7e18398d                                           // 00000031ADCC: 7E18398D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031ADD0: BF870112
	v_and_b32_e32 v11, 1, v11                                  // 00000031ADD4: 36161681
	v_and_b32_e32 v12, 1, v12                                  // 00000031ADD8: 36181881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031ADDC: BF870112
	v_add3_u32 v2, v2, v11, 0x7fff                             // 00000031ADE0: D6550002 03FE1702 00007FFF
	v_add3_u32 v11, v13, v12, 0x7fff                           // 00000031ADEC: D655000B 03FE190D 00007FFF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031ADF8: BF8700B1
	.long 0x7e04398b                                           // 00000031ADFC: 7E04398B
	global_store_b32 v[5:6], v2, off                           // 00000031AE00: DC6A0000 007C0205
	.long 0xd7000005                                           // 00000031AE08: D7000005
	v_cndmask_b32_e32 v0, v5, v132, vcc_lo                     // 00000031AE0C: 02010905
	v_add_co_ci_u32_e64 v6, null, 0, v6, s0                    // 00000031AE10: D5207C06 00020C80
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 00000031AE18: 917E087E
	s_cbranch_execnz 65470                                     // 00000031AE1C: BFA6FFBE <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3118>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000031AE20: 8C7E087E
	v_add_nc_u32_e32 v5, v0, v9                                // 00000031AE24: 4A0A1300
	.long 0xd44d0000                                           // 00000031AE28: D44D0000
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000031AE2C: 02021308
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031AE30: BF870001
	s_and_saveexec_b32 s8, s0                                  // 00000031AE34: BE882000
	s_cbranch_execz 79                                         // 00000031AE38: BFA5004F <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3378>
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000031AE3C: BF8704A2
	v_lshlrev_b32_e32 v1, 1, v5                                // 00000031AE40: 30020A81
	s_lshl_b32 s0, s3, 2                                       // 00000031AE44: 84008203
	s_sub_i32 s2, s2, s0                                       // 00000031AE48: 81820002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AE4C: BF870099
	s_mulk_i32 s2, 0xa00                                       // 00000031AE50: B8020A00
	.long 0xd7000303                                           // 00000031AE54: D7000303
	v_cndmask_b32_e32 v1, s7, v1, vcc_lo                       // 00000031AE58: 02020207
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031AE5C: BF8700B1
	v_add_co_ci_u32_e64 v4, null, s6, 0, s3                    // 00000031AE60: D5207C04 000D0006
	s_lshl_b32 s3, s1, 1                                       // 00000031AE68: 84038101
	.long 0xd7006a01                                           // 00000031AE6C: D7006A01
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 00000031AE70: 02020604
	v_add_co_ci_u32_e64 v2, null, s5, v4, vcc_lo               // 00000031AE74: D5207C02 01AA0805
	.long 0xd7006a03                                           // 00000031AE7C: D7006A03
	v_cndmask_b32_e32 v1, s20, v3, vcc_lo                      // 00000031AE80: 02020614
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031AE84: BF870001
	v_add_co_ci_u32_e64 v4, null, s21, v4, vcc_lo              // 00000031AE88: D5207C04 01AA0815
	s_mov_b32 s4, 0                                            // 00000031AE90: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000031AE94: BF840001
	s_nop 0                                                    // 00000031AE98: BF800000
	s_nop 0                                                    // 00000031AE9C: BF800000
	s_nop 0                                                    // 00000031AEA0: BF800000
	s_nop 0                                                    // 00000031AEA4: BF800000
	s_nop 0                                                    // 00000031AEA8: BF800000
	s_nop 0                                                    // 00000031AEAC: BF800000
	s_nop 0                                                    // 00000031AEB0: BF800000
	s_nop 0                                                    // 00000031AEB4: BF800000
	s_nop 0                                                    // 00000031AEB8: BF800000
	s_nop 0                                                    // 00000031AEBC: BF800000
	v_add_nc_u32_e32 v8, s2, v5                                // 00000031AEC0: 4A100A02
	global_load_u16 v6, v[1:2], off                            // 00000031AEC4: DC4A0000 067C0001
	v_ashrrev_i32_e32 v9, 31, v8                               // 00000031AECC: 3412109F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AED0: BF870091
	.long 0xd73c0008                                           // 00000031AED4: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000031AED8: 02021081
	.long 0xd7006a08                                           // 00000031AEDC: D7006A08
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000031AEE0: 0202100A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031AEE4: BF8700A1
	v_add_co_ci_u32_e64 v9, null, s11, v9, vcc_lo              // 00000031AEE8: D5207C09 01AA120B
	.long 0xd7006a01                                           // 00000031AEF0: D7006A01
	v_cndmask_b32_e32 v0, v1, v3, vcc_lo                       // 00000031AEF4: 02000701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000031AEF8: D5207C02 01AA0480
	global_load_u16 v8, v[8:9], off                            // 00000031AF00: DC4A0000 087C0008
	s_waitcnt vmcnt(1)                                         // 00000031AF08: BF8907F7
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000031AF0C: 300C0C90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AF10: BF870091
	v_dual_mul_f32 v6, v7, v6 :: v_dual_add_nc_u32 v5, s1, v5  // 00000031AF14: C8E00D07 06040A01
	v_cmp_lt_u32_e32 vcc_lo, 0x9ff, v5                         // 00000031AF1C: 7C920AFF 000009FF
	s_or_b32 s4, vcc_lo, s4                                    // 00000031AF24: 8C04046A
	s_waitcnt vmcnt(0)                                         // 00000031AF28: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000031AF2C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AF30: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 00000031AF34: 061010F2
	v_mul_f32_e32 v6, v6, v8                                   // 00000031AF38: 100C1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031AF3C: BF870091
	v_bfe_u32 v8, v6, 16, 1                                    // 00000031AF40: D6100008 02052106
	v_add3_u32 v6, v6, v8, 0x7fff                              // 00000031AF48: D6550006 03FE1106 00007FFF
	global_store_d16_hi_b16 v[3:4], v6, off                    // 00000031AF54: DC960000 007C0603
	.long 0xd7000003                                           // 00000031AF5C: D7000003
	v_cndmask_b32_e32 v0, v3, v3, vcc_lo                       // 00000031AF60: 02000703
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031AF64: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v4, s0                    // 00000031AF68: D5207C04 00020880
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000031AF70: 917E047E
	s_cbranch_execnz 65490                                     // 00000031AF74: BFA6FFD2 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x32c0>
	s_set_inst_prefetch_distance 0x2                           // 00000031AF78: BF840002
	s_or_b32 exec_lo, exec_lo, s8                              // 00000031AF7C: 8C7E087E
	s_waitcnt_vscnt null, 0x0                                  // 00000031AF80: BC7C0000
	s_barrier                                                  // 00000031AF84: BFBD0000
	buffer_gl0_inv                                             // 00000031AF88: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000031AF90: BE80007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000031AF94: 7D940080
	s_cbranch_execz 535                                        // 00000031AF98: BFA50217 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3bf8>
	s_mov_b32 s0, exec_lo                                      // 00000031AF9C: BE80007E
	buffer_gl1_inv                                             // 00000031AFA0: E0B00000 00000000
	buffer_gl0_inv                                             // 00000031AFA8: E0AC0000 00000000
	.long 0xd71f0000                                           // 00000031AFB0: D71F0000
	v_cndmask_b32_e32 v0, s0, v128, vcc_lo                     // 00000031AFB4: 02010000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000031AFB8: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v0                             // 00000031AFBC: 7C940080
	s_and_b32 s1, exec_lo, vcc_lo                              // 00000031AFC0: 8B016A7E
	s_mov_b32 exec_lo, s1                                      // 00000031AFC4: BEFE0001
	s_cbranch_execz 523                                        // 00000031AFC8: BFA5020B <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3bf8>
	s_bcnt1_i32_b32 s0, s0                                     // 00000031AFCC: BE801800
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031AFD0: BF870009
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v0, s0              // 00000031AFD4: CA100080 01000000
	global_atomic_add_u64 v1, v[0:1], s[12:13]                 // 00000031AFDC: DD0E0000 000C0001
	s_nop 0                                                    // 00000031AFE4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000031AFE8: BFB60003
	s_endpgm                                                   // 00000031AFEC: BFB00000
	s_or_b32 exec_lo, exec_lo, s15                             // 00000031AFF0: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031AFF4: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 00000031AFF8: 8C7E0E7E
	.long 0xd71f0001                                           // 00000031AFFC: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000031B000: 020100C1
	s_mov_b32 s4, exec_lo                                      // 00000031B004: BE84007E
	v_xor_b32_e32 v2, 16, v1                                   // 00000031B008: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 00000031B00C: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 00000031B010: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000031B014: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 00000031B018: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 00000031B01C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 00000031B020: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000031B024: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 00000031B028: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 00000031B02C: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000031B030: 7C980CA0
	ds_bpermute_b32 v3, v2, v20                                // 00000031B034: DACC0000 03001402
	v_lshlrev_b32_e32 v4, 2, v4                                // 00000031B03C: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000031B040: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 00000031B044: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031B048: BF870001
	v_dual_add_f32 v3, v20, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 00000031B04C: C9220714 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 00000031B054: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 00000031B05C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000031B060: 06060B03
	ds_bpermute_b32 v2, v2, v21                                // 00000031B064: DACC0000 02001502
	s_waitcnt lgkmcnt(0)                                       // 00000031B06C: BF89FC07
	v_add_f32_e32 v2, v21, v2                                  // 00000031B070: 06040515
	ds_bpermute_b32 v4, v4, v2                                 // 00000031B074: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 00000031B07C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 00000031B080: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 00000031B084: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000031B08C: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 00000031B094: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031B098: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000031B09C: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 00000031B0A0: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 00000031B0A4: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 00000031B0A8: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 00000031B0B0: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000031B0B4: 06040B02
	ds_bpermute_b32 v4, v6, v3                                 // 00000031B0B8: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 00000031B0C0: DACC0000 05000206
	v_xor_b32_e32 v6, 1, v1                                    // 00000031B0C8: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000031B0CC: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 00000031B0D0: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 00000031B0D4: 02020D01
	s_waitcnt lgkmcnt(1)                                       // 00000031B0D8: BF89FC17
	v_dual_add_f32 v1, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v1  // 00000031B0DC: C9220903 01060282
	s_waitcnt lgkmcnt(0)                                       // 00000031B0E4: BF89FC07
	v_add_f32_e32 v2, v2, v5                                   // 00000031B0E8: 06040B02
	ds_bpermute_b32 v3, v6, v1                                 // 00000031B0EC: DACC0000 03000106
	ds_bpermute_b32 v4, v6, v2                                 // 00000031B0F4: DACC0000 04000206
	v_cmpx_eq_u32_e32 0, v15                                   // 00000031B0FC: 7D941E80
	s_cbranch_execz 9                                          // 00000031B100: BFA50009 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3528>
	s_waitcnt lgkmcnt(0)                                       // 00000031B104: BF89FC07
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, s24, v13// 00000031B108: C9220902 02041A18
	v_add_f32_e32 v1, v1, v3                                   // 00000031B110: 06020701
	s_delay_alu instid0(VALU_DEP_2)                            // 00000031B114: BF870002
	v_add_lshl_u32 v3, v5, v14, 3                              // 00000031B118: D6470003 020E1D05
	ds_store_b64 v3, v[1:2] offset:1024                        // 00000031B120: D9340400 00000103
	s_or_b32 exec_lo, exec_lo, s4                              // 00000031B128: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B12C: BF870009
	s_and_b32 s4, s19, exec_lo                                 // 00000031B130: 8B047E13
	s_cselect_b32 s4, 2, 8                                     // 00000031B134: 98048882
	s_mov_b32 s19, exec_lo                                     // 00000031B138: BE93007E
	s_waitcnt lgkmcnt(0)                                       // 00000031B13C: BF89FC07
	s_barrier                                                  // 00000031B140: BFBD0000
	buffer_gl0_inv                                             // 00000031B144: E0AC0000 00000000
	.long 0xd4cc007e                                           // 00000031B14C: D4CC007E
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000031B150: 02020004
	s_cbranch_execz 397                                        // 00000031B154: BFA5018D <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3b8c>
	s_load_b32 s4, s[8:9], 0x40                                // 00000031B158: F4000104 F8000040
	v_lshrrev_b32_e32 v4, 1, v0                                // 00000031B160: 32080081
	v_mov_b32_e32 v5, 0                                        // 00000031B164: 7E0A0280
	s_waitcnt lgkmcnt(0)                                       // 00000031B168: BF89FC07
	s_sub_i32 s4, s5, s4                                       // 00000031B16C: 81840405
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000031B170: BF870499
	s_ashr_i32 s5, s4, 31                                      // 00000031B174: 86059F04
	s_lshl_b64 s[4:5], s[4:5], s25                             // 00000031B178: 84841904
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B17C: BF870099
	.long 0xd7000401                                           // 00000031B180: D7000401
	v_cndmask_b32_e32 v1, s4, v4, vcc_lo                       // 00000031B184: 02020804
	v_add_co_ci_u32_e64 v2, null, s5, 0, s4                    // 00000031B188: D5207C02 00110005
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031B190: BF870001
	v_cmp_gt_i64_e32 vcc_lo, s[6:7], v[1:2]                    // 00000031B194: 7CA80206
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000031B198: 8B7E6A7E
	s_cbranch_execz 379                                        // 00000031B19C: BFA5017B <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3b8c>
	v_and_b32_e32 v3, 1, v0                                    // 00000031B1A0: 36060081
	v_lshlrev_b32_e32 v4, s24, v4                              // 00000031B1A4: 30080818
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B1A8: BF870092
	v_lshlrev_b32_e32 v6, 2, v3                                // 00000031B1AC: 300C0682
	v_lshl_or_b32 v4, v4, 3, v6                                // 00000031B1B0: D6560004 04190704
	ds_load_b32 v6, v4 offset:1024                             // 00000031B1B8: D8D80400 06000004
	v_add_nc_u32_e32 v4, 8, v4                                 // 00000031B1C0: 4A080888
	s_add_i32 s18, s18, -1                                     // 00000031B1C4: 8112C112
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B1C8: BF870009
	s_cmp_eq_u32 s18, 0                                        // 00000031B1CC: BF068012
	s_waitcnt lgkmcnt(0)                                       // 00000031B1D0: BF89FC07
	v_add_f32_e32 v5, v5, v6                                   // 00000031B1D4: 060A0D05
	s_cbranch_scc0 65527                                       // 00000031B1D8: BFA1FFF7 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x35b8>
	s_clause 0x1                                               // 00000031B1DC: BF850001
	s_load_b64 s[14:15], s[8:9], 0x38                          // 00000031B1E0: F4040384 F8000038
	s_load_b64 s[10:11], s[8:9], 0x8                           // 00000031B1E8: F4040284 F8000008
	s_mov_b32 s18, -1                                          // 00000031B1F0: BE9200C1
	s_mov_b32 s5, 0                                            // 00000031B1F4: BE850080
	s_mov_b32 s4, 0                                            // 00000031B1F8: BE840080
	s_waitcnt lgkmcnt(0)                                       // 00000031B1FC: BF89FC07
	s_cmp_lt_i32 s15, 3                                        // 00000031B200: BF04830F
	s_cbranch_scc1 194                                         // 00000031B204: BFA200C2 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3910>
	s_cmp_gt_i32 s15, 3                                        // 00000031B208: BF02830F
	s_cbranch_scc0 73                                          // 00000031B20C: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3734>
	s_cmp_gt_i32 s15, 4                                        // 00000031B210: BF02840F
	s_cbranch_scc0 73                                          // 00000031B214: BFA10049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x373c>
	s_cmp_eq_u32 s15, 5                                        // 00000031B218: BF06850F
	s_mov_b32 s4, -1                                           // 00000031B21C: BE8400C1
	s_cbranch_scc0 66                                          // 00000031B220: BFA10042 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x372c>
	v_lshrrev_b32_e32 v4, 23, v2                               // 00000031B224: 32080497
	s_load_b64 s[8:9], s[8:9], 0x10                            // 00000031B228: F4040204 F8000010
	s_lshr_b32 s4, s7, 31                                      // 00000031B230: 85049F07
	v_bfe_u32 v15, v5, 16, 1                                   // 00000031B234: D610000F 02052105
	s_add_u32 s22, s6, s4                                      // 00000031B23C: 80160406
	.long 0xd7006a04                                           // 00000031B240: D7006A04
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000031B244: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000031B248: BF8704C1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 00000031B24C: D5207C0A 01AA0480
	s_addc_u32 s23, s7, 0                                      // 00000031B254: 82178007
	v_dual_mov_b32 v11, s11 :: v_dual_and_b32 v4, 0xfffffe00, v4// 00000031B258: CA24000B 0B0408FF FFFFFE00
	s_ashr_i64 s[22:23], s[22:23], 1                           // 00000031B264: 86968116
	.long 0xd72c0009                                           // 00000031B268: D72C0009
	v_cndmask_b32_e32 v1, s23, v3, vcc_lo                      // 00000031B26C: 02020617
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B270: BF870092
	.long 0xd7016a06                                           // 00000031B274: D7016A06
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000031B278: 02020901
	v_sub_co_ci_u32_e64 v7, null, v2, v10, vcc_lo              // 00000031B27C: D5217C07 01AA1502
	.long 0xd72c0008                                           // 00000031B284: D72C0008
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 00000031B288: 02020616
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B28C: BF870193
	.long 0xd700040d                                           // 00000031B290: D700040D
	v_cndmask_b32_e32 v1, 0xffffff00, v6, vcc_lo               // 00000031B294: 02020CFF FFFFFF00
	v_cmp_gt_i64_e32 vcc_lo, 0x100, v[6:7]                     // 00000031B29C: 7CA80CFF 00000100
	v_add_co_ci_u32_e64 v14, null, -1, v7, s4                  // 00000031B2A4: D5207C0E 00120EC1
	v_mov_b32_e32 v12, s10                                     // 00000031B2AC: 7E18020A
	s_mov_b32 s4, 0                                            // 00000031B2B0: BE840080
	.long 0xd73c0008                                           // 00000031B2B4: D73C0008
	v_cndmask_b32_e32 v1, 1, v8, vcc_lo                        // 00000031B2B8: 02021081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000031B2BC: BF870143
	v_cndmask_b32_e32 v7, v14, v7, vcc_lo                      // 00000031B2C0: 020E0F0E
	s_waitcnt lgkmcnt(0)                                       // 00000031B2C4: BF89FC07
	v_dual_cndmask_b32 v11, s9, v11 :: v_dual_cndmask_b32 v6, v13, v6// 00000031B2C8: CA521609 0B060D0D
	v_cndmask_b32_e32 v12, s8, v12, vcc_lo                     // 00000031B2D0: 02181808
	.long 0xd73c0006                                           // 00000031B2D4: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000031B2D8: 02020C81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B2DC: BF870092
	.long 0xd7006a08                                           // 00000031B2E0: D7006A08
	v_cndmask_b32_e32 v1, v12, v8, vcc_lo                      // 00000031B2E4: 0202110C
	v_add_co_ci_u32_e64 v9, null, v11, v9, vcc_lo              // 00000031B2E8: D5207C09 01AA130B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B2F0: BF870092
	.long 0xd7006a04                                           // 00000031B2F4: D7006A04
	v_cndmask_b32_e32 v1, v8, v4, vcc_lo                       // 00000031B2F8: 02020908
	v_add_co_ci_u32_e64 v8, null, v9, v10, vcc_lo              // 00000031B2FC: D5207C08 01AA1509
	v_add3_u32 v9, v5, v15, 0x7fff                             // 00000031B304: D6550009 03FE1F05 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B310: BF870093
	.long 0xd7006a06                                           // 00000031B314: D7006A06
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 00000031B318: 02020D04
	v_add_co_ci_u32_e64 v7, null, v8, v7, vcc_lo               // 00000031B31C: D5207C07 01AA0F08
	global_store_d16_hi_b16 v[6:7], v9, off                    // 00000031B324: DC960000 007C0906
	s_mov_b32 s8, 0                                            // 00000031B32C: BE880080
	s_branch 3                                                 // 00000031B330: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3740>
	s_mov_b32 s8, -1                                           // 00000031B334: BE8800C1
	s_branch 53                                                // 00000031B338: BFA00035 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3810>
	s_mov_b32 s8, -1                                           // 00000031B33C: BE8800C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B340: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 00000031B344: 8B6A087E
	s_cbranch_vccz 48                                          // 00000031B348: BFA30030 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x380c>
	v_mul_f32_e32 v4, 0xbfb8aa3b, v5                           // 00000031B34C: 10080AFF BFB8AA3B
	.long 0xd72c0007                                           // 00000031B354: D72C0007
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 00000031B358: 02020607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031B35C: BF870292
	v_exp_f32_e32 v4, v4                                       // 00000031B360: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000031B364: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B368: BF870121
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 00000031B36C: D6FC7C08 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000031B374: D6FC6A09 03CA08F2
	v_rcp_f32_e32 v10, v8                                      // 00000031B37C: 7E145508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B380: BF870095
	v_fma_f32 v6, -v8, v10, 1.0                                // 00000031B384: D6130006 23CA1508
	v_fmac_f32_e32 v10, v6, v10                                // 00000031B38C: 56141506
	.long 0xd72c0006                                           // 00000031B390: D72C0006
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000031B394: 02020606
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031B398: BF870112
	v_mul_f32_e32 v11, v9, v10                                 // 00000031B39C: 10161509
	.long 0xd73c0006                                           // 00000031B3A0: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 00000031B3A4: 02020C82
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B3A8: BF870092
	v_fma_f32 v12, -v8, v11, v9                                // 00000031B3AC: D613000C 24261708
	v_fmac_f32_e32 v11, v12, v10                               // 00000031B3B4: 5616150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B3B8: BF870121
	v_fma_f32 v12, -v8, v11, v9                                // 00000031B3BC: D613000C 24261708
	.long 0xd73c0008                                           // 00000031B3C4: D73C0008
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000031B3C8: 02020282
	v_div_fmas_f32 v10, v12, v10, v11                          // 00000031B3CC: D637000A 042E150C
	.long 0xd7006a06                                           // 00000031B3D4: D7006A06
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 00000031B3D8: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B3DC: BF870191
	v_add_co_ci_u32_e64 v7, null, s11, v7, vcc_lo              // 00000031B3E0: D5207C07 01AA0E0B
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 00000031B3E8: D6270004 03CA090A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B3F0: BF870093
	.long 0xd7006a06                                           // 00000031B3F4: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000031B3F8: 02021106
	v_add_co_ci_u32_e64 v7, null, v7, v9, vcc_lo               // 00000031B3FC: D5207C07 01AA1307
	global_store_b32 v[6:7], v4, off                           // 00000031B404: DC6A0000 007C0406
	s_mov_b32 s8, 0                                            // 00000031B40C: BE880080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B410: BF870009
	s_and_b32 vcc_lo, exec_lo, s8                              // 00000031B414: 8B6A087E
	s_cbranch_vccz 60                                          // 00000031B418: BFA3003C <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x390c>
	v_bfe_u32 v4, v5, 16, 1                                    // 00000031B41C: D6100004 02052105
	.long 0xd72c0007                                           // 00000031B424: D72C0007
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 00000031B428: 02020607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B42C: BF870092
	v_add3_u32 v4, v5, v4, 0x7fff                              // 00000031B430: D6550004 03FE0905 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000031B43C: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B444: BF870091
	v_mul_f32_e32 v4, s14, v4                                  // 00000031B448: 1008080E
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000031B44C: 100808FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031B454: BF870291
	v_exp_f32_e32 v4, v4                                       // 00000031B458: 7E084B04
	v_add_f32_e32 v4, 1.0, v4                                  // 00000031B45C: 060808F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B460: BF870121
	v_div_scale_f32 v8, null, v4, v4, 1.0                      // 00000031B464: D6FC7C08 03CA0904
	v_div_scale_f32 v10, vcc_lo, 1.0, v4, 1.0                  // 00000031B46C: D6FC6A0A 03CA08F2
	v_rcp_f32_e32 v9, v8                                       // 00000031B474: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B478: BF870095
	v_fma_f32 v6, -v8, v9, 1.0                                 // 00000031B47C: D6130006 23CA1308
	v_fmac_f32_e32 v9, v6, v9                                  // 00000031B484: 56121306
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B488: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000031B48C: 1016130A
	v_fma_f32 v6, -v8, v11, v10                                // 00000031B490: D6130006 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B498: BF870121
	v_fmac_f32_e32 v11, v6, v9                                 // 00000031B49C: 56161306
	.long 0xd72c0006                                           // 00000031B4A0: D72C0006
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000031B4A4: 02020606
	v_fma_f32 v8, -v8, v11, v10                                // 00000031B4A8: D6130008 242A1708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031B4B0: BF870112
	.long 0xd73c0006                                           // 00000031B4B4: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 00000031B4B8: 02020C82
	v_div_fmas_f32 v10, v8, v9, v11                            // 00000031B4BC: D637000A 042E1308
	.long 0xd73c0008                                           // 00000031B4C4: D73C0008
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000031B4C8: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B4CC: BF870193
	.long 0xd7006a06                                           // 00000031B4D0: D7006A06
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 00000031B4D4: 02020C0A
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 00000031B4D8: D6270004 03CA090A
	v_add_co_ci_u32_e64 v7, null, s11, v7, vcc_lo              // 00000031B4E0: D5207C07 01AA0E0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B4E8: BF870193
	.long 0xd7006a06                                           // 00000031B4EC: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000031B4F0: 02021106
	v_add_f32_e32 v4, v4, v4                                   // 00000031B4F4: 06080904
	s_delay_alu instid0(VALU_DEP_3)                            // 00000031B4F8: BF870003
	v_add_co_ci_u32_e64 v7, null, v7, v9, vcc_lo               // 00000031B4FC: D5207C07 01AA1307
	global_store_b32 v[6:7], v4, off                           // 00000031B504: DC6A0000 007C0406
	s_mov_b32 s18, 0                                           // 00000031B50C: BE920080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B510: BF870009
	s_and_b32 vcc_lo, exec_lo, s18                             // 00000031B514: 8B6A127E
	s_cbranch_vccz 73                                          // 00000031B518: BFA30049 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a40>
	s_cmp_gt_i32 s15, 1                                        // 00000031B51C: BF02810F
	s_mov_b32 s5, -1                                           // 00000031B520: BE8500C1
	s_cbranch_scc0 64                                          // 00000031B524: BFA10040 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a28>
	v_bfe_u32 v4, v5, 16, 1                                    // 00000031B528: D6100004 02052105
	s_mov_b32 s5, 0                                            // 00000031B530: BE850080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B534: BF870091
	v_add3_u32 v4, v5, v4, 0x7fff                              // 00000031B538: D6550004 03FE0905 00007FFF
	v_and_b32_e32 v4, 0xffff0000, v4                           // 00000031B544: 360808FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B54C: BF870091
	v_mul_f32_e32 v4, 0xbfb8aa3b, v4                           // 00000031B550: 100808FF BFB8AA3B
	v_exp_f32_e32 v4, v4                                       // 00000031B558: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B55C: BF870095
	v_add_f32_e32 v4, 1.0, v4                                  // 00000031B560: 060808F2
	v_div_scale_f32 v6, null, v4, v4, 1.0                      // 00000031B564: D6FC7C06 03CA0904
	v_div_scale_f32 v9, vcc_lo, 1.0, v4, 1.0                   // 00000031B56C: D6FC6A09 03CA08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031B574: BF870292
	v_rcp_f32_e32 v8, v6                                       // 00000031B578: 7E105506
	v_fma_f32 v7, -v6, v8, 1.0                                 // 00000031B57C: D6130007 23CA1106
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B584: BF870091
	v_fmac_f32_e32 v8, v7, v8                                  // 00000031B588: 56101107
	v_mul_f32_e32 v10, v9, v8                                  // 00000031B58C: 10141109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B590: BF870091
	v_fma_f32 v7, -v6, v10, v9                                 // 00000031B594: D6130007 24261506
	v_fmac_f32_e32 v10, v7, v8                                 // 00000031B59C: 56141107
	.long 0xd72c0007                                           // 00000031B5A0: D72C0007
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 00000031B5A4: 02020607
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B5A8: BF870122
	v_fma_f32 v9, -v6, v10, v9                                 // 00000031B5AC: D6130009 24261506
	.long 0xd72c0006                                           // 00000031B5B4: D72C0006
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000031B5B8: 02020606
	v_div_fmas_f32 v8, v9, v8, v10                             // 00000031B5BC: D6370008 042A1109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031B5C4: BF870112
	.long 0xd73c0006                                           // 00000031B5C8: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 00000031B5CC: 02020C81
	v_div_fixup_f32 v4, v8, v4, 1.0                            // 00000031B5D0: D6270004 03CA0908
	.long 0xd73c0008                                           // 00000031B5D8: D73C0008
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000031B5DC: 02020281
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B5E0: BF870193
	.long 0xd7006a06                                           // 00000031B5E4: D7006A06
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 00000031B5E8: 02020C0A
	v_bfe_u32 v10, v4, 16, 1                                   // 00000031B5EC: D610000A 02052104
	v_add_co_ci_u32_e64 v7, null, s11, v7, vcc_lo              // 00000031B5F4: D5207C07 01AA0E0B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B5FC: BF870193
	.long 0xd7006a06                                           // 00000031B600: D7006A06
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 00000031B604: 02021106
	v_add3_u32 v4, v4, v10, 0x7fff                             // 00000031B608: D6550004 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 00000031B614: BF870003
	v_add_co_ci_u32_e64 v7, null, v7, v9, vcc_lo               // 00000031B618: D5207C07 01AA1307
	global_store_d16_hi_b16 v[6:7], v4, off                    // 00000031B620: DC960000 007C0406
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 00000031B628: 916A057E
	s_mov_b32 s5, 0                                            // 00000031B62C: BE850080
	s_cbranch_vccnz 3                                          // 00000031B630: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3a40>
	s_cmp_lg_u32 s15, 1                                        // 00000031B634: BF07810F
	s_mov_b32 s5, -1                                           // 00000031B638: BE8500C1
	s_cselect_b32 s4, -1, 0                                    // 00000031B63C: 980480C1
	v_bfe_u32 v6, v5, 16, 1                                    // 00000031B640: D6100006 02052105
	.long 0xd72c0004                                           // 00000031B648: D72C0004
	v_cndmask_b32_e32 v1, s7, v3, vcc_lo                       // 00000031B64C: 02020607
	.long 0xd72c0003                                           // 00000031B650: D72C0003
	v_cndmask_b32_e32 v1, s6, v3, vcc_lo                       // 00000031B654: 02020606
	.long 0xd73c0001                                           // 00000031B658: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000031B65C: 02020281
	s_and_b32 vcc_lo, exec_lo, s4                              // 00000031B660: 8B6A047E
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000031B664: D6550005 03FE0D05 00007FFF
	s_cbranch_vccz 16                                          // 00000031B670: BFA30010 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3ab4>
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031B674: BF8700A3
	.long 0xd73c0006                                           // 00000031B678: D73C0006
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000031B67C: 02020681
	s_mov_b32 s5, 0                                            // 00000031B680: BE850080
	.long 0xd7006a06                                           // 00000031B684: D7006A06
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 00000031B688: 02020C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000031B68C: BF870111
	v_add_co_ci_u32_e64 v7, null, s11, v7, vcc_lo              // 00000031B690: D5207C07 01AA0E0B
	.long 0xd7006a06                                           // 00000031B698: D7006A06
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 00000031B69C: 02020306
	s_delay_alu instid0(VALU_DEP_1)                            // 00000031B6A0: BF870001
	v_add_co_ci_u32_e64 v7, null, v7, v2, vcc_lo               // 00000031B6A4: D5207C07 01AA0507
	global_store_d16_hi_b16 v[6:7], v5, off                    // 00000031B6AC: DC960000 007C0506
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 00000031B6B4: 916A057E
	s_cbranch_vccnz 52                                         // 00000031B6B8: BFA40034 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3b8c>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000031B6BC: BF870121
	v_and_b32_e32 v5, 0xffff0000, v5                           // 00000031B6C0: 360A0AFF FFFF0000
	.long 0xd73c0003                                           // 00000031B6C8: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 00000031B6CC: 02020681
	v_mul_f32_e32 v5, s14, v5                                  // 00000031B6D0: 100A0A0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B6D4: BF870091
	v_mul_f32_e32 v6, 0xbfb8aa3b, v5                           // 00000031B6D8: 100C0AFF BFB8AA3B
	v_exp_f32_e32 v6, v6                                       // 00000031B6E0: 7E0C4B06
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B6E4: BF870095
	v_add_f32_e32 v6, 1.0, v6                                  // 00000031B6E8: 060C0CF2
	v_div_scale_f32 v7, null, v6, v6, v5                       // 00000031B6EC: D6FC7C07 04160D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000031B6F4: BF870291
	v_rcp_f32_e32 v8, v7                                       // 00000031B6F8: 7E105507
	v_fma_f32 v9, -v7, v8, 1.0                                 // 00000031B6FC: D6130009 23CA1107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000031B704: BF8700A1
	v_fmac_f32_e32 v8, v9, v8                                  // 00000031B708: 56101109
	v_div_scale_f32 v10, vcc_lo, v5, v6, v5                    // 00000031B70C: D6FC6A0A 04160D05
	v_mul_f32_e32 v9, v10, v8                                  // 00000031B714: 1012110A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B718: BF870091
	v_fma_f32 v11, -v7, v9, v10                                // 00000031B71C: D613000B 242A1307
	v_fmac_f32_e32 v9, v11, v8                                 // 00000031B724: 5612110B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B728: BF870091
	v_fma_f32 v7, -v7, v9, v10                                 // 00000031B72C: D6130007 242A1307
	v_div_fmas_f32 v7, v7, v8, v9                              // 00000031B734: D6370007 04261107
	.long 0xd7006a03                                           // 00000031B73C: D7006A03
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000031B740: 0202060A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000031B744: BF870191
	v_add_co_ci_u32_e64 v4, null, s11, v4, vcc_lo              // 00000031B748: D5207C04 01AA080B
	v_div_fixup_f32 v5, v7, v6, v5                             // 00000031B750: D6270005 04160D07
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B758: BF870093
	.long 0xd7006a01                                           // 00000031B75C: D7006A01
	v_cndmask_b32_e32 v1, v3, v1, vcc_lo                       // 00000031B760: 02020303
	v_add_co_ci_u32_e64 v2, null, v4, v2, vcc_lo               // 00000031B764: D5207C02 01AA0504
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000031B76C: BF870093
	v_bfe_u32 v6, v5, 16, 1                                    // 00000031B770: D6100006 02052105
	v_add3_u32 v5, v5, v6, 0x7fff                              // 00000031B778: D6550005 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[1:2], v5, off                    // 00000031B784: DC960000 007C0501
	s_or_b32 exec_lo, exec_lo, s19                             // 00000031B78C: 8C7E137E
	s_waitcnt_vscnt null, 0x0                                  // 00000031B790: BC7C0000
	s_barrier                                                  // 00000031B794: BFBD0000
	buffer_gl0_inv                                             // 00000031B798: E0AC0000 00000000
	s_and_saveexec_b32 s4, s3                                  // 00000031B7A0: BE842003
	s_cbranch_execz 18                                         // 00000031B7A4: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3bf0>
	s_mov_b32 s3, exec_lo                                      // 00000031B7A8: BE83007E
	buffer_gl1_inv                                             // 00000031B7AC: E0B00000 00000000
	buffer_gl0_inv                                             // 00000031B7B4: E0AC0000 00000000
	.long 0xd71f0001                                           // 00000031B7BC: D71F0001
	v_cndmask_b32_e32 v0, s3, v128, vcc_lo                     // 00000031B7C0: 02010003
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000031B7C4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, 0, v1                             // 00000031B7C8: 7C940280
	s_and_b32 s5, exec_lo, vcc_lo                              // 00000031B7CC: 8B056A7E
	s_mov_b32 exec_lo, s5                                      // 00000031B7D0: BEFE0005
	s_cbranch_execz 6                                          // 00000031B7D4: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x3bf0>
	s_bcnt1_i32_b32 s3, s3                                     // 00000031B7D8: BE831803
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000031B7DC: BF870009
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s3              // 00000031B7E0: CA100080 02000003
	global_atomic_add_u64 v2, v[1:2], s[16:17]                 // 00000031B7E8: DD0E0000 00100102
	s_or_b32 exec_lo, exec_lo, s4                              // 00000031B7F0: 8C7E047E
	s_cbranch_execz 64634                                      // 00000031B7F4: BFA5FC7A <_ZN7halogen12_GLOBAL__N_112k_hc8_fused3ILi2EEEvPtPKtPKfS4_iNS0_5LqGrpES2_liPKhS4_S2_PfPyySB_y+0x2de0>
	s_nop 0                                                    // 00000031B7F8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000031B7FC: BFB60003
	s_endpgm                                                   // 00000031B800: BFB00000
		...

