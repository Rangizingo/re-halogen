0000000000576800 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000576800: F4100100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 000000576808: 86039F02
	v_lshrrev_b32_e32 v2, 2, v0                                // 00000057680C: 32040082
	v_lshrrev_b32_e32 v29, 5, v0                               // 000000576810: 323A0085
	v_and_b32_e32 v30, 31, v0                                  // 000000576814: 363C009F
	.long 0x7f0a3880                                           // 000000576818: 7F0A3880
	v_lshlrev_b32_e32 v28, 2, v0                               // 00000057681C: 30380082
	s_waitcnt lgkmcnt(0)                                       // 000000576820: BF89FC07
	.long 0xd4510000                                           // 000000576824: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000576828: 02001802
	s_and_b32 s0, s0, exec_lo                                  // 00000057682C: 8B007E00
	s_cselect_b32 s20, s3, 0                                   // 000000576830: 98148003
	s_cselect_b32 s21, s2, 0                                   // 000000576834: 98158002
	s_add_u32 s0, s4, s16                                      // 000000576838: 80001004
	s_addc_u32 s1, s5, s17                                     // 00000057683C: 82011105
	v_and_b32_e32 v1, 15, v0                                   // 000000576840: 3602008F
	v_and_b32_e32 v2, 60, v2                                   // 000000576844: 360404BC
	s_ashr_i32 s16, s11, 31                                    // 000000576848: 86109F0B
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057684C: BF870119
	s_lshr_b32 s16, s16, 27                                    // 000000576850: 85109B10
	v_lshlrev_b32_e32 v1, 2, v1                                // 000000576854: 30020282
	s_add_u32 s16, s10, s16                                    // 000000576858: 8010100A
	s_clause 0x1                                               // 00000057685C: BF850001
	global_load_b32 v3, v1, s[4:5]                             // 000000576860: DC520000 03040001
	global_load_b32 v4, v2, s[4:5]                             // 000000576868: DC520000 04040002
	s_addc_u32 s17, s11, 0                                     // 000000576870: 8211800B
	v_mov_b32_e32 v2, s1                                       // 000000576874: 7E040201
	s_lshr_b64 s[16:17], s[16:17], 5                           // 000000576878: 85908510
	v_mov_b32_e32 v1, s0                                       // 00000057687C: 7E020200
	s_add_i32 s17, s16, 7                                      // 000000576880: 81118710
	s_mul_i32 s1, s19, s21                                     // 000000576884: 96011513
	s_ashr_i32 s22, s17, 31                                    // 000000576888: 86169F11
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000057688C: BF8704B9
	s_lshr_b32 s0, s22, 29                                     // 000000576890: 85009D16
	v_mad_u64_u32 v[24:25], null, s18, s21, v[1:2]             // 000000576894: D6FE7C18 04042A12
	s_add_i32 s17, s17, s0                                     // 00000057689C: 81110011
	s_ashr_i32 s0, s17, 3                                      // 0000005768A0: 86008311
	s_cmpk_lt_i32 s16, 0x801                                   // 0000005768A4: B3900801
	.long 0xd72c0001                                           // 0000005768A8: D72C0001
	v_cndmask_b32_e32 v1, s0, v29, vcc_lo                      // 0000005768AC: 02023A00
	s_mul_i32 s17, s18, s20                                    // 0000005768B0: 96111412
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000005768B4: BF870141
	v_add_nc_u32_e32 v7, s0, v1                                // 0000005768B8: 4A0E0200
	v_add_nc_u32_e32 v31, v1, v30                              // 0000005768BC: 4A3E3D01
	s_cselect_b32 s0, -1, 0                                    // 0000005768C0: 980080C1
	s_cmpk_gt_i32 s16, 0x800                                   // 0000005768C4: B2900800
	v_min_i32_e32 v32, s16, v7                                 // 0000005768C8: 22400E10
	s_cselect_b32 s16, -1, 0                                   // 0000005768CC: 981080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000005768D0: BF870159
	s_and_b32 vcc_lo, exec_lo, s16                             // 0000005768D4: 8B6A107E
	s_waitcnt vmcnt(1)                                         // 0000005768D8: BF8907F7
	v_bfe_u32 v2, v3, 16, 1                                    // 0000005768DC: D6100002 02052103
	s_waitcnt vmcnt(0)                                         // 0000005768E4: BF8903F7
	v_bfe_u32 v6, v4, 16, 1                                    // 0000005768E8: D6100006 02052104
	v_add3_u32 v2, v3, v2, 0x7fff                              // 0000005768F0: D6550002 03FE0503 00007FFF
	v_add_nc_u32_e32 v3, s1, v25                               // 0000005768FC: 4A063201
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000576900: BF870223
	v_add3_u32 v4, v4, v6, 0x7fff                              // 000000576904: D6550004 03FE0D04 00007FFF
	.long 0xd4410001                                           // 000000576910: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000576914: 0202411F
	.long 0x7e0a3982                                           // 000000576918: 7E0A3982
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000057691C: BF870114
	v_add_nc_u32_e32 v33, s17, v3                              // 000000576920: 4A420611
	v_and_or_b32 v1, 0xffff0000, v4, v5                        // 000000576924: D6570001 041608FF FFFF0000
	ds_store_b32 v28, v1                                       // 000000576930: D8340000 0000011C
	s_waitcnt lgkmcnt(0)                                       // 000000576938: BF89FC07
	s_barrier                                                  // 00000057693C: BFBD0000
	buffer_gl0_inv                                             // 000000576940: E0AC0000 00000000
	s_cbranch_vccnz 154                                        // 000000576948: BFA4009A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3b4>
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v8, 0               // 00000057694C: CA100080 09080080
	s_and_saveexec_b32 s17, s1                                 // 000000576954: BE912001
	s_cbranch_execz 11                                         // 000000576958: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x188>
	v_lshlrev_b32_e32 v1, 1, v31                               // 00000057695C: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576960: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576964: 3404029F
	.long 0xd7006a01                                           // 000000576968: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 00000057696C: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576970: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576978: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576980: BF8903F7
	v_cvt_f32_f16_e32 v8, v1                                   // 000000576984: 7E101701
	s_or_b32 exec_lo, exec_lo, s17                             // 000000576988: 8C7E117E
	v_add_nc_u32_e32 v1, 32, v31                               // 00000057698C: 4A023EA0
	s_mov_b32 s1, exec_lo                                      // 000000576990: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000576994: BF870001
	.long 0xd4c1007e                                           // 000000576998: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 00000057699C: 02024101
	s_cbranch_execz 11                                         // 0000005769A0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1d0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000005769A4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005769A8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005769AC: 3404029F
	.long 0xd7006a01                                           // 0000005769B0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 0000005769B4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 0000005769B8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 0000005769C0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000005769C8: BF8903F7
	v_cvt_f32_f16_e32 v9, v1                                   // 0000005769CC: 7E121701
	s_or_b32 exec_lo, exec_lo, s1                              // 0000005769D0: 8C7E017E
	v_dual_mov_b32 v10, 0 :: v_dual_add_nc_u32 v1, 64, v31     // 0000005769D4: CA200080 0A003EC0
	v_mov_b32_e32 v11, 0                                       // 0000005769DC: 7E160280
	s_mov_b32 s1, exec_lo                                      // 0000005769E0: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005769E4: BF870002
	.long 0xd4c1007e                                           // 0000005769E8: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 0000005769EC: 02024101
	s_cbranch_execz 11                                         // 0000005769F0: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x220>
	v_lshlrev_b32_e32 v1, 1, v1                                // 0000005769F4: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005769F8: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000005769FC: 3404029F
	.long 0xd7006a01                                           // 000000576A00: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576A04: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576A08: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576A10: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576A18: BF8903F7
	v_cvt_f32_f16_e32 v10, v1                                  // 000000576A1C: 7E141701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576A20: 8C7E017E
	v_add_nc_u32_e32 v1, 0x60, v31                             // 000000576A24: 4A023EFF 00000060
	s_mov_b32 s1, exec_lo                                      // 000000576A2C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000576A30: BF870001
	.long 0xd4c1007e                                           // 000000576A34: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000576A38: 02024101
	s_cbranch_execz 11                                         // 000000576A3C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x26c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000576A40: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576A44: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576A48: 3404029F
	.long 0xd7006a01                                           // 000000576A4C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576A50: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576A54: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576A5C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576A64: BF8903F7
	v_cvt_f32_f16_e32 v11, v1                                  // 000000576A68: 7E161701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576A6C: 8C7E017E
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v1, 0x80, v31   // 000000576A70: CA200080 0C003EFF 00000080
	v_mov_b32_e32 v13, 0                                       // 000000576A7C: 7E1A0280
	s_mov_b32 s1, exec_lo                                      // 000000576A80: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000576A84: BF870002
	.long 0xd4c1007e                                           // 000000576A88: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000576A8C: 02024101
	s_cbranch_execz 11                                         // 000000576A90: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x2c0>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000576A94: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576A98: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576A9C: 3404029F
	.long 0xd7006a01                                           // 000000576AA0: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576AA4: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576AA8: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576AB0: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576AB8: BF8903F7
	v_cvt_f32_f16_e32 v12, v1                                  // 000000576ABC: 7E181701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576AC0: 8C7E017E
	v_add_nc_u32_e32 v1, 0xa0, v31                             // 000000576AC4: 4A023EFF 000000A0
	s_mov_b32 s1, exec_lo                                      // 000000576ACC: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000576AD0: BF870001
	.long 0xd4c1007e                                           // 000000576AD4: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000576AD8: 02024101
	s_cbranch_execz 11                                         // 000000576ADC: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x30c>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000576AE0: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576AE4: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576AE8: 3404029F
	.long 0xd7006a01                                           // 000000576AEC: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576AF0: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576AF4: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576AFC: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576B04: BF8903F7
	v_cvt_f32_f16_e32 v13, v1                                  // 000000576B08: 7E1A1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576B0C: 8C7E017E
	v_dual_mov_b32 v14, 0 :: v_dual_add_nc_u32 v1, 0xc0, v31   // 000000576B10: CA200080 0E003EFF 000000C0
	v_mov_b32_e32 v15, 0                                       // 000000576B1C: 7E1E0280
	s_mov_b32 s1, exec_lo                                      // 000000576B20: BE81007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000576B24: BF870002
	.long 0xd4c1007e                                           // 000000576B28: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000576B2C: 02024101
	s_cbranch_execz 11                                         // 000000576B30: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x360>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000576B34: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576B38: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576B3C: 3404029F
	.long 0xd7006a01                                           // 000000576B40: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576B44: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576B48: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576B50: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576B58: BF8903F7
	v_cvt_f32_f16_e32 v14, v1                                  // 000000576B5C: 7E1C1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576B60: 8C7E017E
	v_add_nc_u32_e32 v1, 0xe0, v31                             // 000000576B64: 4A023EFF 000000E0
	s_mov_b32 s1, exec_lo                                      // 000000576B6C: BE81007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000576B70: BF870001
	.long 0xd4c1007e                                           // 000000576B74: D4C1007E
	v_cndmask_b32_e32 v1, v1, v32, vcc_lo                      // 000000576B78: 02024101
	s_cbranch_execz 11                                         // 000000576B7C: BFA5000B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3ac>
	v_lshlrev_b32_e32 v1, 1, v1                                // 000000576B80: 30020281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576B84: BF8700A1
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576B88: 3404029F
	.long 0xd7006a01                                           // 000000576B8C: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576B90: 02020318
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000576B94: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000576B9C: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576BA4: BF8903F7
	v_cvt_f32_f16_e32 v15, v1                                  // 000000576BA8: 7E1E1701
	s_or_b32 exec_lo, exec_lo, s1                              // 000000576BAC: 8C7E017E
	s_branch 9                                                 // 000000576BB0: BFA00009 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x3d8>
	v_mov_b32_e32 v8, 0                                        // 000000576BB4: 7E100280
	s_delay_alu instid0(VALU_DEP_1)                            // 000000576BB8: BF870001
	v_mov_b32_e32 v9, v8                                       // 000000576BBC: 7E120308
	v_mov_b32_e32 v10, v8                                      // 000000576BC0: 7E140308
	v_mov_b32_e32 v11, v8                                      // 000000576BC4: 7E160308
	v_mov_b32_e32 v12, v8                                      // 000000576BC8: 7E180308
	v_mov_b32_e32 v13, v8                                      // 000000576BCC: 7E1A0308
	v_mov_b32_e32 v14, v8                                      // 000000576BD0: 7E1C0308
	v_mov_b32_e32 v15, v8                                      // 000000576BD4: 7E1E0308
	s_add_u32 s4, s4, s14                                      // 000000576BD8: 80040E04
	s_addc_u32 s5, s5, s15                                     // 000000576BDC: 82050F05
	s_lshr_b32 s1, s11, 31                                     // 000000576BE0: 85019F0B
	v_dual_mov_b32 v1, s21 :: v_dual_mov_b32 v20, 0            // 000000576BE4: CA100015 01140080
	s_add_u32 s14, s10, s1                                     // 000000576BEC: 800E010A
	s_addc_u32 s15, s11, 0                                     // 000000576BF0: 820F800B
	.long 0xd4410001                                           // 000000576BF4: D4410001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000576BF8: 0202411F
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000576BFC: 868E810E
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v27, 0             // 000000576C00: CA100080 221A0080
	v_mad_u64_u32 v[25:26], null, v1, s14, s[4:5]              // 000000576C08: D6FE7C19 00101D01
	.long 0xd72c0001                                           // 000000576C10: D72C0001
	v_cndmask_b32_e32 v0, s21, v15, vcc_lo                     // 000000576C14: 02001E15
	.long 0xd72c0002                                           // 000000576C18: D72C0002
	v_cndmask_b32_e32 v0, s20, v14, vcc_lo                     // 000000576C1C: 02001C14
	v_cndmask_b32_e64 v35, 0, 1, s16                           // 000000576C20: D5010023 00410280
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0             // 000000576C28: CA100080 15160080
	v_mov_b32_e32 v23, 0                                       // 000000576C30: 7E2E0280
	s_delay_alu instid0(VALU_DEP_4)                            // 000000576C34: BF870004
	v_add3_u32 v36, v2, v26, v1                                // 000000576C38: D6550024 04063502
	s_and_saveexec_b32 s4, s1                                  // 000000576C40: BE842001
	s_cbranch_execz 22                                         // 000000576C44: BFA50016 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 4, v31                               // 000000576C48: 30023E84
	v_mov_b32_e32 v27, 0                                       // 000000576C4C: 7E360280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576C50: BF8700A2
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000576C54: 3404029F
	.long 0xd7006a01                                           // 000000576C58: D7006A01
	v_cndmask_b32_e32 v1, v25, v1, vcc_lo                      // 000000576C5C: 02020319
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 000000576C60: D5207C02 01AA0524
	s_and_not1_b32 vcc_lo, exec_lo, s16                        // 000000576C68: 916A107E
	global_load_b128 v[20:23], v[1:2], off                     // 000000576C6C: DC5E0000 147C0001
	s_cbranch_vccnz 10                                         // 000000576C74: BFA4000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x4a0>
	v_lshlrev_b32_e32 v1, 1, v31                               // 000000576C78: 30023E81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000576C7C: BF870091
	.long 0xd7006a01                                           // 000000576C80: D7006A01
	v_cndmask_b32_e32 v1, v24, v1, vcc_lo                      // 000000576C84: 02020318
	v_add_co_ci_u32_e64 v2, null, 0, v33, vcc_lo               // 000000576C88: D5207C02 01AA4280
	global_load_d16_b16 v1, v[1:2], off                        // 000000576C90: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000576C98: BF8903F7
	v_cvt_f32_f16_e32 v27, v1                                  // 000000576C9C: 7E361701
	s_or_b32 exec_lo, exec_lo, s4                              // 000000576CA0: 8C7E047E
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v39, 0             // 000000576CA4: CA100080 26260080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v41, 0             // 000000576CAC: CA100080 28280080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v43, 0             // 000000576CB4: CA100080 2A2A0080
	v_mov_b32_e32 v37, 0                                       // 000000576CBC: 7E4A0280
	s_and_saveexec_b32 s14, s1                                 // 000000576CC0: BE8E2001
	s_cbranch_execz 666                                        // 000000576CC4: BFA5029A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf30>
	v_dual_mov_b32 v42, 0 :: v_dual_add_nc_u32 v1, 32, v31     // 000000576CC8: CA200080 2A003EA0
	v_dual_mov_b32 v37, 0 :: v_dual_lshlrev_b32 v26, 5, v31    // 000000576CD0: CA220080 251A3E85
	v_dual_mov_b32 v41, 0 :: v_dual_mov_b32 v38, 0             // 000000576CD8: CA100080 29260080
	s_delay_alu instid0(VALU_DEP_3)                            // 000000576CE0: BF870003
	v_dual_mov_b32 v43, 0 :: v_dual_lshlrev_b32 v44, 4, v1     // 000000576CE4: CA220080 2B2C0284
	v_dual_mov_b32 v40, 0 :: v_dual_lshlrev_b32 v45, 1, v1     // 000000576CEC: CA220080 282C0281
	v_dual_mov_b32 v39, 0 :: v_dual_mov_b32 v34, 0             // 000000576CF4: CA100080 27220080
	v_mov_b32_e32 v46, v27                                     // 000000576CFC: 7E5C031B
	s_mul_i32 s1, s11, 6                                       // 000000576D00: 9601860B
	s_mul_hi_u32 s15, s10, 6                                   // 000000576D04: 968F860A
	s_lshl_b64 s[4:5], s[10:11], 2                             // 000000576D08: 8484820A
	s_add_i32 s15, s15, s1                                     // 000000576D0C: 810F010F
	s_mul_i32 s17, s10, 6                                      // 000000576D10: 9611860A
	s_mov_b32 s16, 0                                           // 000000576D14: BE900080
	s_lshl_b64 s[10:11], s[10:11], 1                           // 000000576D18: 848A810A
	s_branch 608                                               // 000000576D1C: BFA00260 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xea0>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000576D20: 8C7E127E
	v_cndmask_b32_e64 v47, v27, v8, s0                         // 000000576D24: D501002F 0002111B
	v_cndmask_b32_e64 v4, v11, v12, s0                         // 000000576D2C: D5010004 0002190B
	v_cndmask_b32_e64 v3, v10, v11, s0                         // 000000576D34: D5010003 0002170A
	v_cndmask_b32_e64 v2, v9, v10, s0                          // 000000576D3C: D5010002 00021509
	v_cndmask_b32_e64 v1, v8, v9, s0                           // 000000576D44: D5010001 00021308
	v_dual_mov_b32 v8, v15 :: v_dual_and_b32 v9, 0xff, v20     // 000000576D4C: CA24010F 080828FF 000000FF
	v_lshrrev_b32_e32 v10, 6, v20                              // 000000576D58: 32142886
	v_lshrrev_b32_e32 v11, 14, v20                             // 000000576D5C: 3216288E
	v_cndmask_b32_e64 v7, v14, v15, s0                         // 000000576D60: D5010007 00021F0E
	v_cndmask_b32_e64 v6, v13, v14, s0                         // 000000576D68: D5010006 00021D0D
	v_lshlrev_b32_e32 v9, 2, v9                                // 000000576D70: 30121282
	v_and_b32_e32 v10, 0x3fc, v10                              // 000000576D74: 361414FF 000003FC
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576D7C: 361616FF 000003FC
	v_cndmask_b32_e64 v5, v12, v13, s0                         // 000000576D84: D5010005 00021B0C
	v_ashrrev_i32_e32 v27, 31, v26                             // 000000576D8C: 3436349F
	ds_load_b32 v9, v9                                         // 000000576D90: D8D80000 09000009
	ds_load_b32 v10, v10                                       // 000000576D98: D8D80000 0A00000A
	ds_load_b32 v15, v11                                       // 000000576DA0: D8D80000 0F00000B
	v_lshrrev_b32_e32 v11, 22, v20                             // 000000576DA8: 32162896
	s_and_b32 s1, exec_lo, s1                                  // 000000576DAC: 8B01017E
	v_add_nc_u32_e32 v44, 0x200, v44                           // 000000576DB0: 4A5858FF 00000200
	s_or_b32 s16, s1, s16                                      // 000000576DB8: 8C101001
	v_add_nc_u32_e32 v45, 64, v45                              // 000000576DBC: 4A5A5AC0
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576DC0: 361616FF 000003FC
	ds_load_b32 v60, v11                                       // 000000576DC8: D8D80000 3C00000B
	v_and_b32_e32 v11, 0xff, v21                               // 000000576DD0: 36162AFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576DD8: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000576DDC: 30161682
	ds_load_b32 v61, v11                                       // 000000576DE0: D8D80000 3D00000B
	v_lshrrev_b32_e32 v11, 6, v21                              // 000000576DE8: 32162A86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576DEC: 361616FF 000003FC
	ds_load_b32 v62, v11                                       // 000000576DF4: D8D80000 3E00000B
	v_lshrrev_b32_e32 v11, 14, v21                             // 000000576DFC: 32162A8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576E00: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E04: 361616FF 000003FC
	ds_load_b32 v63, v11                                       // 000000576E0C: D8D80000 3F00000B
	v_lshrrev_b32_e32 v11, 22, v21                             // 000000576E14: 32162A96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E18: 361616FF 000003FC
	ds_load_b32 v64, v11                                       // 000000576E20: D8D80000 4000000B
	v_and_b32_e32 v11, 0xff, v22                               // 000000576E28: 36162CFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576E30: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000576E34: 30161682
	ds_load_b32 v65, v11                                       // 000000576E38: D8D80000 4100000B
	v_lshrrev_b32_e32 v11, 6, v22                              // 000000576E40: 32162C86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E44: 361616FF 000003FC
	ds_load_b32 v66, v11                                       // 000000576E4C: D8D80000 4200000B
	v_lshrrev_b32_e32 v11, 14, v22                             // 000000576E54: 32162C8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576E58: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E5C: 361616FF 000003FC
	ds_load_b32 v67, v11                                       // 000000576E64: D8D80000 4300000B
	v_lshrrev_b32_e32 v11, 22, v22                             // 000000576E6C: 32162C96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E70: 361616FF 000003FC
	ds_load_b32 v68, v11                                       // 000000576E78: D8D80000 4400000B
	v_and_b32_e32 v11, 0xff, v23                               // 000000576E80: 36162EFF 000000FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576E88: BF8700B1
	v_lshlrev_b32_e32 v11, 2, v11                              // 000000576E8C: 30161682
	ds_load_b32 v69, v11                                       // 000000576E90: D8D80000 4500000B
	v_lshrrev_b32_e32 v11, 6, v23                              // 000000576E98: 32162E86
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576E9C: 361616FF 000003FC
	ds_load_b32 v70, v11                                       // 000000576EA4: D8D80000 4600000B
	v_lshrrev_b32_e32 v11, 14, v23                             // 000000576EAC: 32162E8E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000576EB0: BF8700B1
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576EB4: 361616FF 000003FC
	ds_load_b32 v71, v11                                       // 000000576EBC: D8D80000 4700000B
	v_lshrrev_b32_e32 v11, 22, v23                             // 000000576EC4: 32162E96
	v_and_b32_e32 v11, 0x3fc, v11                              // 000000576EC8: 361616FF 000003FC
	ds_load_b32 v72, v11                                       // 000000576ED0: D8D80000 4800000B
	.long 0xd73c000b                                           // 000000576ED8: D73C000B
	v_cndmask_b32_e32 v1, 1, v26, vcc_lo                       // 000000576EDC: 02023481
	v_dual_mov_b32 v27, v46 :: v_dual_add_nc_u32 v26, 0x400, v26// 000000576EE0: CA20012E 1B1A34FF 00000400
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000576EEC: BF870092
	.long 0xd7006a38                                           // 000000576EF0: D7006A38
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 000000576EF4: 02021606
	v_add_co_ci_u32_e64 v57, null, s7, v12, vcc_lo             // 000000576EF8: D5207C39 01AA1807
	s_clause 0x3                                               // 000000576F00: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000576F04: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000576F0C: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000576F14: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000576F1C: DC5E0030 347C0038
	s_waitcnt vmcnt(3) lgkmcnt(15)                             // 000000576F24: BF890CF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000576F28: CC1A400B 1A02130B
	s_waitcnt lgkmcnt(14)                                      // 000000576F30: BF89FCE7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576F34: BF8700A1
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000576F38: CC1A400B 1C2E150C
	s_waitcnt lgkmcnt(13)                                      // 000000576F40: BF89FCD7
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000576F44: CC1A400B 1C2E1F0D
	s_waitcnt lgkmcnt(12)                                      // 000000576F4C: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576F50: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000576F54: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2) lgkmcnt(11)                             // 000000576F5C: BF8908B7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000576F60: CC1A400B 1C2E7B14
	s_waitcnt lgkmcnt(10)                                      // 000000576F68: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576F6C: BF8700A1
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000576F70: CC1A400B 1C2E7D15
	s_waitcnt lgkmcnt(9)                                       // 000000576F78: BF89FC97
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000576F7C: CC1A400B 1C2E7F16
	s_waitcnt lgkmcnt(8)                                       // 000000576F84: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576F88: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000576F8C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1) lgkmcnt(7)                              // 000000576F94: BF890477
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000576F98: CC1A400B 1C2E8330
	s_waitcnt lgkmcnt(6)                                       // 000000576FA0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576FA4: BF8700A1
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000576FA8: CC1A400B 1C2E8531
	s_waitcnt lgkmcnt(5)                                       // 000000576FB0: BF89FC57
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000576FB4: CC1A400B 1C2E8732
	s_waitcnt lgkmcnt(4)                                       // 000000576FBC: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000576FC0: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000576FC4: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0) lgkmcnt(3)                              // 000000576FCC: BF890037
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000576FD0: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000576FD8: D7006A34
	v_cndmask_b32_e32 v0, v56, v10, vcc_lo                     // 000000576FDC: 02001538
	s_waitcnt lgkmcnt(2)                                       // 000000576FE0: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000576FE4: BF8701C2
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000576FE8: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s11, v57, vcc_lo            // 000000576FF0: D5207C35 01AA720B
	.long 0xd7006a3a                                           // 000000576FF8: D7006A3A
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000576FFC: 02000938
	s_waitcnt lgkmcnt(1)                                       // 000000577000: BF89FC17
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000577004: CC1A400B 1C2E8F36
	v_add_co_ci_u32_e64 v59, null, s5, v57, vcc_lo             // 00000057700C: D5207C3B 01AA7205
	.long 0xd7006a38                                           // 000000577014: D7006A38
	v_cndmask_b32_e32 v0, v56, v17, vcc_lo                     // 000000577018: 02002338
	s_waitcnt lgkmcnt(0)                                       // 00000057701C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000577020: BF870123
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000577024: CC1A400B 1C2E9137
	v_add_co_ci_u32_e64 v57, null, s15, v57, vcc_lo            // 00000057702C: D5207C39 01AA720F
	v_fmac_f32_e32 v37, v47, v11                               // 000000577034: 564A172F
	s_clause 0x3                                               // 000000577038: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 00000057703C: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 000000577044: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 00000057704C: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 000000577054: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 00000057705C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000577060: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577068: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 00000057706C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000577074: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057707C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000577080: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000577088: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000057708C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577094: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000577098: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 0000005770A0: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005770A8: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 0000005770AC: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 0000005770B4: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000005770B8: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005770C0: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000005770C4: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000005770CC: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005770D4: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000005770D8: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000005770E0: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000005770E4: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005770EC: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000005770F0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000005770F8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577100: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000577104: CC1A400B 1C2E9137
	v_fmac_f32_e32 v43, v47, v11                               // 00000057710C: 5656172F
	s_clause 0x3                                               // 000000577110: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 000000577114: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 00000057711C: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 000000577124: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 00000057712C: DC5E0030 347C003A
	.long 0xd7006a3a                                           // 000000577134: D7006A3A
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000577138: 0200093A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000057713C: BF8700B1
	v_add_co_ci_u32_e64 v59, null, s5, v59, vcc_lo             // 000000577140: D5207C3B 01AA7605
	s_waitcnt vmcnt(3)                                         // 000000577148: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 00000057714C: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000577154: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057715C: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000577160: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000577168: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000577170: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577174: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000577178: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000577180: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577188: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 00000057718C: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000577194: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000057719C: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005771A0: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 0000005771A4: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 0000005771AC: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005771B4: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000005771B8: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000005771C0: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000005771C8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005771CC: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000005771D0: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000005771D8: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005771E0: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000005771E4: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000005771EC: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005771F4: BF870001
	v_fmac_f32_e32 v42, v47, v11                               // 0000005771F8: 5654172F
	s_clause 0x3                                               // 0000005771FC: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 000000577200: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 000000577208: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 000000577210: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 000000577218: DC5E0030 347C0038
	.long 0xd7006a38                                           // 000000577220: D7006A38
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000577224: 02000938
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000577228: BF8700B1
	v_add_co_ci_u32_e64 v57, null, s5, v57, vcc_lo             // 00000057722C: D5207C39 01AA7205
	s_waitcnt vmcnt(3)                                         // 000000577234: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000577238: CC1A400B 1A02130B
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 000000577240: CC1A400B 1C2E150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577248: BF870091
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 00000057724C: CC1A400B 1C2E1F0D
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000577254: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 00000057725C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577260: BF870091
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000577264: CC1A400B 1C2E7B14
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 00000057726C: CC1A400B 1C2E7D15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577274: BF870091
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000577278: CC1A400B 1C2E7F16
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000577280: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000577288: BF8907F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057728C: BF870091
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000577290: CC1A400B 1C2E8330
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000577298: CC1A400B 1C2E8531
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005772A0: BF870091
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 0000005772A4: CC1A400B 1C2E8732
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 0000005772AC: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 0000005772B4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005772B8: BF870091
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 0000005772BC: CC1A400B 1C2E8B34
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000005772C4: CC1A400B 1C2E8D35
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005772CC: BF870091
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000005772D0: CC1A400B 1C2E8F36
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000005772D8: CC1A400B 1C2E9137
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005772E0: BF870001
	v_fmac_f32_e32 v41, v47, v11                               // 0000005772E4: 5652172F
	s_clause 0x3                                               // 0000005772E8: BF850003
	global_load_b128 v[11:14], v[58:59], off                   // 0000005772EC: DC5E0000 0B7C003A
	global_load_b128 v[20:23], v[58:59], off offset:16         // 0000005772F4: DC5E0010 147C003A
	global_load_b128 v[48:51], v[58:59], off offset:32         // 0000005772FC: DC5E0020 307C003A
	global_load_b128 v[52:55], v[58:59], off offset:48         // 000000577304: DC5E0030 347C003A
	s_waitcnt vmcnt(3)                                         // 00000057730C: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 000000577310: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577318: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 00000057731C: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 000000577324: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057732C: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000577330: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000577338: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 00000057733C: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577344: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000577348: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000577350: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577358: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000057735C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000577364: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000577368: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577370: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000577374: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 00000057737C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577384: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000577388: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000577390: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000577394: CC1A400B 1C2E8B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057739C: BF870091
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 0000005773A0: CC1A400B 1C2E8D35
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 0000005773A8: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005773B0: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 0000005773B4: CC1A400B 1C2E9137
	v_fmac_f32_e32 v40, v47, v11                               // 0000005773BC: 5650172F
	s_clause 0x3                                               // 0000005773C0: BF850003
	global_load_b128 v[11:14], v[56:57], off                   // 0000005773C4: DC5E0000 0B7C0038
	global_load_b128 v[20:23], v[56:57], off offset:16         // 0000005773CC: DC5E0010 147C0038
	global_load_b128 v[48:51], v[56:57], off offset:32         // 0000005773D4: DC5E0020 307C0038
	global_load_b128 v[52:55], v[56:57], off offset:48         // 0000005773DC: DC5E0030 347C0038
	s_waitcnt vmcnt(3)                                         // 0000005773E4: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000005773E8: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005773F0: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000005773F4: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000005773FC: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577404: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 000000577408: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 000000577410: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 000000577414: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000057741C: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000577420: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000577428: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577430: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 000000577434: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 00000057743C: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000577440: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577448: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 00000057744C: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 000000577454: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057745C: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000577460: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000577468: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 00000057746C: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 000000577474: D7006A34
	v_cndmask_b32_e32 v0, v58, v4, vcc_lo                      // 000000577478: 0200093A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000057747C: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000577480: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v59, vcc_lo             // 000000577488: D5207C35 01AA7605
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000577490: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577498: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 00000057749C: CC1A400B 1C2E9137
	v_fmac_f32_e32 v39, v47, v11                               // 0000005774A4: 564E172F
	s_clause 0x3                                               // 0000005774A8: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 0000005774AC: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 0000005774B4: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000005774BC: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000005774C4: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000005774CC: BF890FF7
	v_dot2_f32_bf16 v11, v11, v9, 0                            // 0000005774D0: CC1A400B 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005774D8: BF870091
	v_dot2_f32_bf16 v11, v12, v10, v11                         // 0000005774DC: CC1A400B 1C2E150C
	v_dot2_f32_bf16 v11, v13, v15, v11                         // 0000005774E4: CC1A400B 1C2E1F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005774EC: BF8700A1
	v_dot2_f32_bf16 v11, v14, v60, v11                         // 0000005774F0: CC1A400B 1C2E790E
	s_waitcnt vmcnt(2)                                         // 0000005774F8: BF890BF7
	v_dot2_f32_bf16 v11, v20, v61, v11                         // 0000005774FC: CC1A400B 1C2E7B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577504: BF870091
	v_dot2_f32_bf16 v11, v21, v62, v11                         // 000000577508: CC1A400B 1C2E7D15
	v_dot2_f32_bf16 v11, v22, v63, v11                         // 000000577510: CC1A400B 1C2E7F16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577518: BF8700A1
	v_dot2_f32_bf16 v11, v23, v64, v11                         // 00000057751C: CC1A400B 1C2E8117
	s_waitcnt vmcnt(1)                                         // 000000577524: BF8907F7
	v_dot2_f32_bf16 v11, v48, v65, v11                         // 000000577528: CC1A400B 1C2E8330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577530: BF870091
	v_dot2_f32_bf16 v11, v49, v66, v11                         // 000000577534: CC1A400B 1C2E8531
	v_dot2_f32_bf16 v11, v50, v67, v11                         // 00000057753C: CC1A400B 1C2E8732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577544: BF8700A1
	v_dot2_f32_bf16 v11, v51, v68, v11                         // 000000577548: CC1A400B 1C2E8933
	s_waitcnt vmcnt(0)                                         // 000000577550: BF8903F7
	v_dot2_f32_bf16 v11, v52, v69, v11                         // 000000577554: CC1A400B 1C2E8B34
	.long 0xd7006a34                                           // 00000057755C: D7006A34
	v_cndmask_b32_e32 v0, v56, v4, vcc_lo                      // 000000577560: 02000938
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000577564: BF870122
	v_dot2_f32_bf16 v11, v53, v70, v11                         // 000000577568: CC1A400B 1C2E8D35
	v_add_co_ci_u32_e64 v53, null, s5, v57, vcc_lo             // 000000577570: D5207C35 01AA7205
	v_dot2_f32_bf16 v11, v54, v71, v11                         // 000000577578: CC1A400B 1C2E8F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577580: BF870091
	v_dot2_f32_bf16 v11, v55, v72, v11                         // 000000577584: CC1A400B 1C2E9137
	v_fmac_f32_e32 v38, v47, v11                               // 00000057758C: 564C172F
	s_clause 0x3                                               // 000000577590: BF850003
	global_load_b128 v[11:14], v[52:53], off                   // 000000577594: DC5E0000 0B7C0034
	global_load_b128 v[20:23], v[52:53], off offset:16         // 00000057759C: DC5E0010 147C0034
	global_load_b128 v[48:51], v[52:53], off offset:32         // 0000005775A4: DC5E0020 307C0034
	global_load_b128 v[52:55], v[52:53], off offset:48         // 0000005775AC: DC5E0030 347C0034
	s_waitcnt vmcnt(3)                                         // 0000005775B4: BF890FF7
	v_dot2_f32_bf16 v9, v11, v9, 0                             // 0000005775B8: CC1A4009 1A02130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000005775C0: BF870091
	v_dot2_f32_bf16 v9, v12, v10, v9                           // 0000005775C4: CC1A4009 1C26150C
	v_dot2_f32_bf16 v9, v13, v15, v9                           // 0000005775CC: CC1A4009 1C261F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000005775D4: BF8700A1
	v_dot2_f32_bf16 v9, v14, v60, v9                           // 0000005775D8: CC1A4009 1C26790E
	s_waitcnt vmcnt(2)                                         // 0000005775E0: BF890BF7
	v_dot2_f32_bf16 v9, v20, v61, v9                           // 0000005775E4: CC1A4009 1C267B14
	v_mov_b32_e32 v20, v16                                     // 0000005775EC: 7E280310
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000005775F0: BF870122
	v_dot2_f32_bf16 v9, v21, v62, v9                           // 0000005775F4: CC1A4009 1C267D15
	v_mov_b32_e32 v21, v17                                     // 0000005775FC: 7E2A0311
	v_dot2_f32_bf16 v9, v22, v63, v9                           // 000000577600: CC1A4009 1C267F16
	v_mov_b32_e32 v22, v18                                     // 000000577608: 7E2C0312
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000057760C: BF870132
	v_dot2_f32_bf16 v9, v23, v64, v9                           // 000000577610: CC1A4009 1C268117
	v_mov_b32_e32 v23, v19                                     // 000000577618: 7E2E0313
	s_waitcnt vmcnt(1)                                         // 00000057761C: BF8907F7
	v_dot2_f32_bf16 v9, v48, v65, v9                           // 000000577620: CC1A4009 1C268330
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577628: BF870091
	v_dot2_f32_bf16 v9, v49, v66, v9                           // 00000057762C: CC1A4009 1C268531
	v_dot2_f32_bf16 v9, v50, v67, v9                           // 000000577634: CC1A4009 1C268732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000057763C: BF8700A1
	v_dot2_f32_bf16 v9, v51, v68, v9                           // 000000577640: CC1A4009 1C268933
	s_waitcnt vmcnt(0)                                         // 000000577648: BF8903F7
	v_dot2_f32_bf16 v9, v52, v69, v9                           // 00000057764C: CC1A4009 1C268B34
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577654: BF870091
	v_dot2_f32_bf16 v9, v53, v70, v9                           // 000000577658: CC1A4009 1C268D35
	v_dot2_f32_bf16 v9, v54, v71, v9                           // 000000577660: CC1A4009 1C268F36
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577668: BF870091
	v_dot2_f32_bf16 v9, v55, v72, v9                           // 00000057766C: CC1A4009 1C269137
	v_dual_fmac_f32 v34, v47, v9 :: v_dual_mov_b32 v15, v8     // 000000577674: C810132F 220E0108
	v_dual_mov_b32 v14, v7 :: v_dual_mov_b32 v13, v6           // 00000057767C: CA100107 0E0C0106
	v_dual_mov_b32 v12, v5 :: v_dual_mov_b32 v11, v4           // 000000577684: CA100105 0C0A0104
	v_dual_mov_b32 v10, v3 :: v_dual_mov_b32 v9, v2            // 00000057768C: CA100103 0A080102
	v_mov_b32_e32 v8, v1                                       // 000000577694: 7E100301
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 000000577698: 917E107E
	s_cbranch_execz 35                                         // 00000057769C: BFA50023 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0xf2c>
	s_waitcnt vmcnt(0)                                         // 0000005776A0: BF8903F7
	v_dual_mov_b32 v16, v20 :: v_dual_add_nc_u32 v31, 32, v31  // 0000005776A4: CA200114 101E3EA0
	v_dual_mov_b32 v17, v21 :: v_dual_mov_b32 v18, v22         // 0000005776AC: CA100115 11120116
	v_mov_b32_e32 v19, v23                                     // 0000005776B4: 7E260317
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005776B8: BF870003
	.long 0xd4460001                                           // 0000005776BC: D4460001
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000005776C0: 0202411F
	s_mov_b32 s18, exec_lo                                     // 0000005776C4: BE92007E
	.long 0xd4c1007e                                           // 0000005776C8: D4C1007E
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 0000005776CC: 0202411F
	s_cbranch_execz 64915                                      // 0000005776D0: BFA5FD93 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v44                              // 0000005776D4: 3404589F
	.long 0xd7006a01                                           // 0000005776D8: D7006A01
	v_cndmask_b32_e32 v1, v25, v44, vcc_lo                     // 0000005776DC: 02025919
	v_mov_b32_e32 v46, v27                                     // 0000005776E0: 7E5C031B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000005776E4: BF870003
	v_add_co_ci_u32_e64 v2, null, v36, v2, vcc_lo              // 0000005776E8: D5207C02 01AA0524
	v_cmp_ne_u32_e32 vcc_lo, 1, v35                            // 0000005776F0: 7C9A4681
	global_load_b128 v[16:19], v[1:2], off                     // 0000005776F4: DC5E0000 107C0001
	s_cbranch_vccnz 64904                                      // 0000005776FC: BFA4FD88 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	v_ashrrev_i32_e32 v2, 31, v45                              // 000000577700: 34045A9F
	.long 0xd7006a01                                           // 000000577704: D7006A01
	v_cndmask_b32_e32 v1, v24, v45, vcc_lo                     // 000000577708: 02025B18
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057770C: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 000000577710: D5207C02 01AA0521
	global_load_d16_b16 v1, v[1:2], off                        // 000000577718: DC820000 017C0001
	s_waitcnt vmcnt(0)                                         // 000000577720: BF8903F7
	v_cvt_f32_f16_e32 v46, v1                                  // 000000577724: 7E5C1701
	s_branch 64893                                             // 000000577728: BFA0FD7D <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x520>
	s_or_b32 exec_lo, exec_lo, s16                             // 00000057772C: 8C7E107E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000577730: BF8700B9
	s_or_b32 exec_lo, exec_lo, s14                             // 000000577734: 8C7E0E7E
	.long 0xd71f0001                                           // 000000577738: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000057773C: 020100C1
	s_mov_b32 s0, exec_lo                                      // 000000577740: BE80007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000577744: 3A040290
	v_xor_b32_e32 v10, 8, v1                                   // 000000577748: 3A140288
	v_xor_b32_e32 v18, 4, v1                                   // 00000057774C: 3A240284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000577750: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000577754: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000577758: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v10                           // 00000057775C: 7C9814A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000577760: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000577764: 30040482
	ds_bpermute_b32 v3, v2, v37                                // 000000577768: DACC0000 03002502
	s_waitcnt lgkmcnt(0)                                       // 000000577770: BF89FC07
	v_add_f32_e32 v3, v37, v3                                  // 000000577774: 06060725
	ds_bpermute_b32 v5, v2, v42                                // 000000577778: DACC0000 05002A02
	ds_bpermute_b32 v7, v2, v40                                // 000000577780: DACC0000 07002802
	ds_bpermute_b32 v9, v2, v38                                // 000000577788: DACC0000 09002602
	v_cndmask_b32_e32 v10, v1, v10, vcc_lo                     // 000000577790: 02141501
	ds_bpermute_b32 v4, v2, v43                                // 000000577794: DACC0000 04002B02
	ds_bpermute_b32 v6, v2, v41                                // 00000057779C: DACC0000 06002902
	ds_bpermute_b32 v8, v2, v39                                // 0000005777A4: DACC0000 08002702
	ds_bpermute_b32 v2, v2, v34                                // 0000005777AC: DACC0000 02002202
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005777B4: 7C9824A0
	s_waitcnt lgkmcnt(6)                                       // 0000005777B8: BF89FC67
	v_add_f32_e32 v5, v42, v5                                  // 0000005777BC: 060A0B2A
	s_waitcnt lgkmcnt(5)                                       // 0000005777C0: BF89FC57
	v_dual_add_f32 v7, v40, v7 :: v_dual_lshlrev_b32 v10, 2, v10// 0000005777C4: C9220F28 070A1482
	s_waitcnt lgkmcnt(4)                                       // 0000005777CC: BF89FC47
	v_add_f32_e32 v9, v38, v9                                  // 0000005777D0: 06121326
	ds_bpermute_b32 v11, v10, v3                               // 0000005777D4: DACC0000 0B00030A
	ds_bpermute_b32 v13, v10, v5                               // 0000005777DC: DACC0000 0D00050A
	ds_bpermute_b32 v15, v10, v7                               // 0000005777E4: DACC0000 0F00070A
	ds_bpermute_b32 v17, v10, v9                               // 0000005777EC: DACC0000 1100090A
	s_waitcnt lgkmcnt(7)                                       // 0000005777F4: BF89FC77
	v_add_f32_e32 v4, v43, v4                                  // 0000005777F8: 0608092B
	s_waitcnt lgkmcnt(6)                                       // 0000005777FC: BF89FC67
	v_add_f32_e32 v6, v41, v6                                  // 000000577800: 060C0D29
	s_waitcnt lgkmcnt(5)                                       // 000000577804: BF89FC57
	v_add_f32_e32 v8, v39, v8                                  // 000000577808: 06101127
	s_waitcnt lgkmcnt(3)                                       // 00000057780C: BF89FC37
	v_dual_add_f32 v2, v34, v2 :: v_dual_add_f32 v3, v3, v11   // 000000577810: C9080522 02021703
	ds_bpermute_b32 v14, v10, v6                               // 000000577818: DACC0000 0E00060A
	s_waitcnt lgkmcnt(3)                                       // 000000577820: BF89FC37
	v_add_f32_e32 v5, v5, v13                                  // 000000577824: 060A1B05
	ds_bpermute_b32 v12, v10, v4                               // 000000577828: DACC0000 0C00040A
	s_waitcnt lgkmcnt(3)                                       // 000000577830: BF89FC37
	v_add_f32_e32 v7, v7, v15                                  // 000000577834: 060E1F07
	s_waitcnt lgkmcnt(2)                                       // 000000577838: BF89FC27
	v_add_f32_e32 v9, v9, v17                                  // 00000057783C: 06122309
	ds_bpermute_b32 v16, v10, v8                               // 000000577840: DACC0000 1000080A
	ds_bpermute_b32 v10, v10, v2                               // 000000577848: DACC0000 0A00020A
	s_waitcnt lgkmcnt(2)                                       // 000000577850: BF89FC27
	v_add_f32_e32 v4, v4, v12                                  // 000000577854: 06081904
	s_waitcnt lgkmcnt(1)                                       // 000000577858: BF89FC17
	v_add_f32_e32 v8, v8, v16                                  // 00000057785C: 06102108
	s_waitcnt lgkmcnt(0)                                       // 000000577860: BF89FC07
	v_add_f32_e32 v2, v2, v10                                  // 000000577864: 06041502
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 000000577868: 02242501
	s_delay_alu instid0(VALU_DEP_1)                            // 00000057786C: BF870001
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000577870: 30242482
	ds_bpermute_b32 v12, v18, v5                               // 000000577874: DACC0000 0C000512
	s_waitcnt lgkmcnt(0)                                       // 00000057787C: BF89FC07
	v_add_f32_e32 v5, v5, v12                                  // 000000577880: 060A1905
	ds_bpermute_b32 v16, v18, v9                               // 000000577884: DACC0000 10000912
	v_add_f32_e32 v6, v6, v14                                  // 00000057788C: 060C1D06
	ds_bpermute_b32 v10, v18, v3                               // 000000577890: DACC0000 0A000312
	ds_bpermute_b32 v14, v18, v7                               // 000000577898: DACC0000 0E000712
	ds_bpermute_b32 v17, v18, v2                               // 0000005778A0: DACC0000 11000212
	s_waitcnt lgkmcnt(3)                                       // 0000005778A8: BF89FC37
	v_add_f32_e32 v9, v9, v16                                  // 0000005778AC: 06122109
	ds_bpermute_b32 v13, v18, v6                               // 0000005778B0: DACC0000 0D000612
	s_waitcnt lgkmcnt(3)                                       // 0000005778B8: BF89FC37
	v_add_f32_e32 v3, v3, v10                                  // 0000005778BC: 06061503
	ds_bpermute_b32 v11, v18, v4                               // 0000005778C0: DACC0000 0B000412
	s_waitcnt lgkmcnt(3)                                       // 0000005778C8: BF89FC37
	v_add_f32_e32 v7, v7, v14                                  // 0000005778CC: 060E1D07
	ds_bpermute_b32 v15, v18, v8                               // 0000005778D0: DACC0000 0F000812
	v_xor_b32_e32 v18, 2, v1                                   // 0000005778D8: 3A240282
	s_delay_alu instid0(VALU_DEP_1)                            // 0000005778DC: BF870001
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 0000005778E0: 7C9824A0
	s_waitcnt lgkmcnt(2)                                       // 0000005778E4: BF89FC27
	v_add_f32_e32 v6, v6, v13                                  // 0000005778E8: 060C1B06
	v_cndmask_b32_e32 v18, v1, v18, vcc_lo                     // 0000005778EC: 02242501
	s_waitcnt lgkmcnt(1)                                       // 0000005778F0: BF89FC17
	v_dual_add_f32 v4, v4, v11 :: v_dual_add_f32 v11, v2, v17  // 0000005778F4: C9081704 040A2302
	s_delay_alu instid0(VALU_DEP_2)                            // 0000005778FC: BF870002
	v_lshlrev_b32_e32 v18, 2, v18                              // 000000577900: 30242482
	ds_bpermute_b32 v14, v18, v7                               // 000000577904: DACC0000 0E000712
	s_waitcnt lgkmcnt(1)                                       // 00000057790C: BF89FC17
	v_add_f32_e32 v8, v8, v15                                  // 000000577910: 06101F08
	ds_bpermute_b32 v2, v18, v3                                // 000000577914: DACC0000 02000312
	ds_bpermute_b32 v10, v18, v4                               // 00000057791C: DACC0000 0A000412
	ds_bpermute_b32 v12, v18, v5                               // 000000577924: DACC0000 0C000512
	ds_bpermute_b32 v13, v18, v6                               // 00000057792C: DACC0000 0D000612
	ds_bpermute_b32 v15, v18, v8                               // 000000577934: DACC0000 0F000812
	ds_bpermute_b32 v16, v18, v9                               // 00000057793C: DACC0000 10000912
	ds_bpermute_b32 v17, v18, v11                              // 000000577944: DACC0000 11000B12
	v_xor_b32_e32 v18, 1, v1                                   // 00000057794C: 3A240281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000577950: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v18                           // 000000577954: 7C9824A0
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 000000577958: 02022501
	s_waitcnt lgkmcnt(6)                                       // 00000057795C: BF89FC67
	v_dual_add_f32 v1, v3, v2 :: v_dual_lshlrev_b32 v18, 2, v1 // 000000577960: C9220503 01120282
	s_waitcnt lgkmcnt(5)                                       // 000000577968: BF89FC57
	v_add_f32_e32 v2, v4, v10                                  // 00000057796C: 06041504
	s_waitcnt lgkmcnt(3)                                       // 000000577970: BF89FC37
	v_dual_add_f32 v4, v5, v12 :: v_dual_add_f32 v5, v6, v13   // 000000577974: C9081905 04041B06
	v_add_f32_e32 v3, v7, v14                                  // 00000057797C: 06061D07
	s_waitcnt lgkmcnt(1)                                       // 000000577980: BF89FC17
	v_dual_add_f32 v7, v8, v15 :: v_dual_add_f32 v10, v9, v16  // 000000577984: C9081F08 070A2109
	s_waitcnt lgkmcnt(0)                                       // 00000057798C: BF89FC07
	v_add_f32_e32 v12, v11, v17                                // 000000577990: 0618230B
	ds_bpermute_b32 v6, v18, v1                                // 000000577994: DACC0000 06000112
	ds_bpermute_b32 v8, v18, v2                                // 00000057799C: DACC0000 08000212
	ds_bpermute_b32 v11, v18, v4                               // 0000005779A4: DACC0000 0B000412
	ds_bpermute_b32 v13, v18, v5                               // 0000005779AC: DACC0000 0D000512
	ds_bpermute_b32 v9, v18, v3                                // 0000005779B4: DACC0000 09000312
	ds_bpermute_b32 v14, v18, v7                               // 0000005779BC: DACC0000 0E000712
	ds_bpermute_b32 v15, v18, v10                              // 0000005779C4: DACC0000 0F000A12
	ds_bpermute_b32 v16, v18, v12                              // 0000005779CC: DACC0000 10000C12
	v_cmpx_eq_u32_e32 0, v30                                   // 0000005779D4: 7D943C80
	s_cbranch_execz 16                                         // 0000005779D8: BFA50010 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x121c>
	s_waitcnt lgkmcnt(2)                                       // 0000005779DC: BF89FC27
	v_dual_add_f32 v14, v7, v14 :: v_dual_add_f32 v19, v4, v11 // 0000005779E0: C9081D07 0E121704
	s_waitcnt vmcnt(0)                                         // 0000005779E8: BF8903F7
	v_add_f32_e32 v20, v5, v13                                 // 0000005779EC: 06281B05
	v_dual_add_f32 v18, v2, v8 :: v_dual_add_f32 v17, v1, v6   // 0000005779F0: C9081102 12100D01
	s_waitcnt lgkmcnt(0)                                       // 0000005779F8: BF89FC07
	v_dual_add_f32 v16, v12, v16 :: v_dual_lshlrev_b32 v1, 5, v29// 0000005779FC: C922210C 10003A85
	v_add_f32_e32 v15, v10, v15                                // 000000577A04: 061E1F0A
	v_add_f32_e32 v13, v3, v9                                  // 000000577A08: 061A1303
	ds_store_b128 v1, v[17:20] offset:1024                     // 000000577A0C: DB7C0400 00001101
	ds_store_b128 v1, v[13:16] offset:1040                     // 000000577A14: DB7C0410 00000D01
	s_or_b32 exec_lo, exec_lo, s0                              // 000000577A1C: 8C7E007E
	.long 0xd4510000                                           // 000000577A20: D4510000
	v_cndmask_b32_e32 v0, s2, v12, vcc_lo                      // 000000577A24: 02001802
	v_cmp_gt_u32_e32 vcc_lo, 8, v0                             // 000000577A28: 7C980088
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000577A2C: BF890007
	s_barrier                                                  // 000000577A30: BFBD0000
	buffer_gl0_inv                                             // 000000577A34: E0AC0000 00000000
	s_and_b32 s0, vcc_lo, s0                                   // 000000577A3C: 8B00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000577A40: BF870009
	s_and_saveexec_b32 s1, s0                                  // 000000577A44: BE812000
	s_cbranch_execz 51                                         // 000000577A48: BFA50033 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi8ELi32ELi8ELb0ELi0ELi1EEEvPKhPKtPvlllllS6_f+0x1318>
	v_add_nc_u32_e32 v7, 0x400, v28                            // 000000577A4C: 4A0E38FF 00000400
	s_lshl_b64 s[0:1], s[2:3], 1                               // 000000577A54: 84808102
	ds_load_2addr_b32 v[1:2], v7 offset1:8                     // 000000577A58: D8DC0800 01000007
	ds_load_2addr_b32 v[3:4], v7 offset0:16 offset1:24         // 000000577A60: D8DC1810 03000007
	ds_load_2addr_b32 v[5:6], v7 offset0:32 offset1:40         // 000000577A68: D8DC2820 05000007
	s_waitcnt lgkmcnt(2)                                       // 000000577A70: BF89FC27
	v_add_f32_e32 v1, 0, v1                                    // 000000577A74: 06020280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000577A78: BF8700A1
	v_add_f32_e32 v1, v1, v2                                   // 000000577A7C: 06020501
	s_waitcnt lgkmcnt(1)                                       // 000000577A80: BF89FC17
	v_add_f32_e32 v1, v1, v3                                   // 000000577A84: 06020701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000577A88: BF870131
	v_add_f32_e32 v3, v1, v4                                   // 000000577A8C: 06060901
	v_mad_u64_u32 v[1:2], null, s12, v0, 0                     // 000000577A90: D6FE7C01 0202000C
	s_waitcnt lgkmcnt(0)                                       // 000000577A98: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000577A9C: 06060B03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000577AA0: BF8700D1
	v_add_f32_e32 v4, v3, v6                                   // 000000577AA4: 06080D03
	ds_load_2addr_b32 v[7:8], v7 offset0:48 offset1:56         // 000000577AA8: D8DC3830 07000007
	v_mad_u64_u32 v[2:3], null, s13, v0, v[2:3]                // 000000577AB0: D6FE7C02 040A000D
	s_waitcnt lgkmcnt(0)                                       // 000000577AB8: BF89FC07
	v_add_f32_e32 v0, v4, v7                                   // 000000577ABC: 06000F04
	v_add_f32_e32 v3, v0, v8                                   // 000000577AC0: 06061100
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000577AC4: BF870113
	.long 0xd73c0000                                           // 000000577AC8: D73C0000
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000577ACC: 02020281
	v_bfe_u32 v2, v3, 16, 1                                    // 000000577AD0: D6100002 02052103
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000577AD8: BF870092
	.long 0xd7006a00                                           // 000000577ADC: D7006A00
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 000000577AE0: 02020008
	v_add_co_ci_u32_e64 v1, null, s9, v1, vcc_lo               // 000000577AE4: D5207C01 01AA0209
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000577AEC: BF870193
	v_add3_u32 v2, v3, v2, 0x7fff                              // 000000577AF0: D6550002 03FE0503 00007FFF
	.long 0xd7006a00                                           // 000000577AFC: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 000000577B00: 02000100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000577B04: BF870001
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000577B08: D5207C01 01AA0201
	global_store_d16_hi_b16 v[0:1], v2, off                    // 000000577B10: DC960000 007C0200
	s_endpgm                                                   // 000000577B18: BFB00000
		...

