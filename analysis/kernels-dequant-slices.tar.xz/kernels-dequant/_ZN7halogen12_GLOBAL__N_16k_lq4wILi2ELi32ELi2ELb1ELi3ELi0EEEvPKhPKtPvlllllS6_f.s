0000000000837600 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f>:
; _ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f():
	s_load_b512 s[4:19], s[0:1], null                          // 000000837600: F4100100 F8000000
	v_dual_mov_b32 v18, 0 :: v_dual_and_b32 v1, 15, v0         // 000000837608: CA240080 1200008F
	v_lshrrev_b32_e32 v2, 2, v0                                // 000000837610: 32040082
	s_ashr_i32 s3, s2, 31                                      // 000000837614: 86039F02
	v_lshrrev_b32_e32 v14, 6, v0                               // 000000837618: 321C0086
	s_lshl_b64 s[20:21], s[2:3], 2                             // 00000083761C: 84948202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837620: BF8701A9
	v_dual_mov_b32 v4, s21 :: v_dual_lshlrev_b32 v1, 2, v1     // 000000837624: CA220015 04000282
	v_and_b32_e32 v2, 60, v2                                   // 00000083762C: 360404BC
	v_or_b32_e32 v3, s20, v14                                  // 000000837630: 38061C14
	v_bfe_u32 v15, v0, 5, 1                                    // 000000837634: D610000F 02050B00
	.long 0x7f0e3880                                           // 00000083763C: 7F0E3880
	v_mov_b32_e32 v17, 0                                       // 000000837640: 7E220280
	s_waitcnt lgkmcnt(0)                                       // 000000837644: BF89FC07
	s_clause 0x1                                               // 000000837648: BF850001
	global_load_b32 v5, v1, s[4:5]                             // 00000083764C: DC520000 05040001
	global_load_b32 v6, v2, s[4:5]                             // 000000837654: DC520000 06040002
	s_add_u32 s2, s4, s14                                      // 00000083765C: 80020E04
	s_addc_u32 s3, s5, s15                                     // 000000837660: 82030F05
	s_lshr_b32 s14, s11, 31                                    // 000000837664: 850E9F0B
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[3:4]                  // 000000837668: 7CA8060C
	s_add_u32 s14, s10, s14                                    // 00000083766C: 800E0E0A
	s_addc_u32 s15, s11, 0                                     // 000000837670: 820F800B
	s_ashr_i32 s22, s11, 31                                    // 000000837674: 86169F0B
	s_ashr_i64 s[14:15], s[14:15], 1                           // 000000837678: 868E810E
	s_lshr_b32 s22, s22, 27                                    // 00000083767C: 85169B16
	v_dual_cndmask_b32 v3, 0, v3 :: v_dual_and_b32 v16, 31, v0 // 000000837680: CA640680 0310009F
	s_add_u32 s22, s10, s22                                    // 000000837688: 8016160A
	s_addc_u32 s23, s11, 0                                     // 00000083768C: 8217800B
	v_cndmask_b32_e64 v4, 0, s21, vcc_lo                       // 000000837690: D5010004 01A82A80
	s_lshr_b64 s[22:23], s[22:23], 5                           // 000000837698: 85968516
	.long 0xd72c0008                                           // 00000083769C: D72C0008
	v_cndmask_b32_e32 v1, s19, v3, vcc_lo                      // 0000008376A0: 02020613
	s_add_i32 s23, s22, 1                                      // 0000008376A4: 81178116
	.long 0xd72c000d                                           // 0000008376A8: D72C000D
	v_cndmask_b32_e32 v0, v3, v15, vcc_lo                      // 0000008376AC: 02001F03
	s_lshr_b32 s19, s23, 31                                    // 0000008376B0: 85139F17
	v_mad_u64_u32 v[9:10], null, v3, s14, s[2:3]               // 0000008376B4: D6FE7C09 00081D03
	s_add_i32 s23, s23, s19                                    // 0000008376BC: 81171317
	.long 0xd72c0015                                           // 0000008376C0: D72C0015
	v_cndmask_b32_e32 v0, v4, v14, vcc_lo                      // 0000008376C4: 02001D04
	s_ashr_i32 s15, s23, 1                                     // 0000008376C8: 860F8117
	s_add_u32 s2, s4, s16                                      // 0000008376CC: 80021004
	.long 0xd72c0013                                           // 0000008376D0: D72C0013
	v_cndmask_b32_e32 v1, s15, v15, vcc_lo                     // 0000008376D4: 02021E0F
	s_addc_u32 s3, s5, s17                                     // 0000008376D8: 82031105
	.long 0xd72c0016                                           // 0000008376DC: D72C0016
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000008376E0: 02020812
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 0000008376E4: CA100080 01020080
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000008376EC: BF870214
	v_add3_u32 v10, v21, v10, v13                              // 0000008376F0: D655000A 04361515
	v_add_nc_u32_e32 v4, s15, v19                              // 0000008376F8: 4A08260F
	v_add_nc_u32_e32 v19, v19, v16                             // 0000008376FC: 4A262113
	s_waitcnt vmcnt(1)                                         // 000000837700: BF8907F7
	v_bfe_u32 v11, v5, 16, 1                                   // 000000837704: D610000B 02052105
	s_waitcnt vmcnt(0)                                         // 00000083770C: BF8903F7
	v_bfe_u32 v20, v6, 16, 1                                   // 000000837710: D6100014 02052106
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837718: BF8701A2
	v_add3_u32 v5, v5, v11, 0x7fff                             // 00000083771C: D6550005 03FE1705 00007FFF
	v_mad_u64_u32 v[11:12], null, s18, v3, s[2:3]              // 000000837728: D6FE7C0B 000A0612
	v_add3_u32 v6, v6, v20, 0x7fff                             // 000000837730: D6550006 03FE2906 00007FFF
	v_mov_b32_e32 v3, 0                                        // 00000083773C: 7E060280
	v_min_i32_e32 v20, s22, v4                                 // 000000837740: 22280816
	.long 0x7e0e3985                                           // 000000837744: 7E0E3985
	v_dual_mov_b32 v4, 0 :: v_dual_lshlrev_b32 v5, 2, v0       // 000000837748: CA220080 04040082
	v_add3_u32 v21, v8, v12, v22                               // 000000837750: D6550015 045A1908
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837758: BF870003
	v_and_or_b32 v6, 0xffff0000, v6, v7                        // 00000083775C: D6570006 041E0CFF FFFF0000
	v_cmp_lt_i32_e32 vcc_lo, v19, v20                          // 000000837768: 7C822913
	ds_store_b32 v5, v6                                        // 00000083776C: D8340000 00000605
	s_waitcnt lgkmcnt(0)                                       // 000000837774: BF89FC07
	s_barrier                                                  // 000000837778: BFBD0000
	buffer_gl0_inv                                             // 00000083777C: E0AC0000 00000000
	s_and_saveexec_b32 s3, vcc_lo                              // 000000837784: BE83206A
	s_cbranch_execz 21                                         // 000000837788: BFA50015 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x1e0>
	v_lshlrev_b32_e32 v1, 1, v19                               // 00000083778C: 30022681
	v_lshlrev_b32_e32 v3, 4, v19                               // 000000837790: 30062684
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837794: BF870112
	v_ashrrev_i32_e32 v2, 31, v1                               // 000000837798: 3404029F
	v_ashrrev_i32_e32 v4, 31, v3                               // 00000083779C: 3408069F
	.long 0xd7000201                                           // 0000008377A0: D7000201
	v_cndmask_b32_e32 v1, v11, v1, vcc_lo                      // 0000008377A4: 0202030B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000008377A8: BF8700A1
	v_add_co_ci_u32_e64 v2, null, v21, v2, s2                  // 0000008377AC: D5207C02 000A0515
	.long 0xd7000203                                           // 0000008377B4: D7000203
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 0000008377B8: 02020709
	v_add_co_ci_u32_e64 v4, null, v10, v4, s2                  // 0000008377BC: D5207C04 000A090A
	s_clause 0x1                                               // 0000008377C4: BF850001
	global_load_d16_b16 v5, v[1:2], off                        // 0000008377C8: DC820000 057C0001
	global_load_b128 v[1:4], v[3:4], off                       // 0000008377D0: DC5E0000 017C0003
	s_waitcnt vmcnt(1)                                         // 0000008377D8: BF8907F7
	v_cvt_f32_f16_e32 v18, v5                                  // 0000008377DC: 7E241705
	s_or_b32 exec_lo, exec_lo, s3                              // 0000008377E0: 8C7E037E
	v_mov_b32_e32 v22, 0                                       // 0000008377E4: 7E2C0280
	s_and_saveexec_b32 s3, vcc_lo                              // 0000008377E8: BE83206A
	s_cbranch_execz 264                                        // 0000008377EC: BFA50108 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x610>
	v_dual_mov_b32 v22, 0 :: v_dual_add_nc_u32 v5, 32, v19     // 0000008377F0: CA200080 160426A0
	v_dual_mov_b32 v17, 0 :: v_dual_lshlrev_b32 v12, 5, v19    // 0000008377F8: CA220080 110C2685
	s_mov_b32 s14, 0                                           // 000000837800: BE8E0080
	s_delay_alu instid0(VALU_DEP_2)                            // 000000837804: BF870002
	v_lshlrev_b32_e32 v23, 4, v5                               // 000000837808: 302E0A84
	v_dual_mov_b32 v25, v18 :: v_dual_lshlrev_b32 v24, 1, v5   // 00000083780C: CA220112 19180A81
	s_lshl_b64 s[4:5], s[10:11], 1                             // 000000837814: 8484810A
	s_branch 221                                               // 000000837818: BFA000DD <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x590>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000083781C: 8C7E0A7E
	v_ashrrev_i32_e32 v13, 31, v12                             // 000000837820: 341A189F
	v_lshrrev_b32_e32 v58, 6, v1                               // 000000837824: 32740286
	v_lshrrev_b32_e32 v59, 14, v1                              // 000000837828: 3276028E
	v_and_b32_e32 v60, 0xff, v2                                // 00000083782C: 367804FF 000000FF
	v_lshrrev_b32_e32 v61, 6, v2                               // 000000837834: 327A0486
	.long 0xd73c001a                                           // 000000837838: D73C001A
	v_cndmask_b32_e32 v1, 1, v12, vcc_lo                       // 00000083783C: 02021881
	v_and_b32_e32 v13, 0xff, v1                                // 000000837840: 361A02FF 000000FF
	v_and_b32_e32 v58, 0x3fc, v58                              // 000000837848: 367474FF 000003FC
	v_and_b32_e32 v59, 0x3fc, v59                              // 000000837850: 367676FF 000003FC
	v_lshrrev_b32_e32 v1, 22, v1                               // 000000837858: 32020296
	v_lshrrev_b32_e32 v62, 14, v2                              // 00000083785C: 327C048E
	.long 0xd7000232                                           // 000000837860: D7000232
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 000000837864: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837868: BF8701A1
	v_add_co_ci_u32_e64 v51, null, s7, v27, s2                 // 00000083786C: D5207C33 000A3607
	v_lshlrev_b32_e32 v13, 2, v13                              // 000000837874: 301A1A82
	.long 0xd7000236                                           // 000000837878: D7000236
	v_cndmask_b32_e32 v0, v50, v4, vcc_lo                      // 00000083787C: 02000932
	s_delay_alu instid0(VALU_DEP_1)                            // 000000837880: BF870001
	v_add_co_ci_u32_e64 v55, null, s5, v51, s2                 // 000000837884: D5207C37 000A6605
	ds_load_b32 v13, v13                                       // 00000083788C: D8D80000 0D00000D
	ds_load_b32 v58, v58                                       // 000000837894: D8D80000 3A00003A
	ds_load_b32 v59, v59                                       // 00000083789C: D8D80000 3B00003B
	s_clause 0x7                                               // 0000008378A4: BF850007
	global_load_b128 v[26:29], v[50:51], off                   // 0000008378A8: DC5E0000 1A7C0032
	global_load_b128 v[30:33], v[54:55], off                   // 0000008378B0: DC5E0000 1E7C0036
	global_load_b128 v[34:37], v[50:51], off offset:16         // 0000008378B8: DC5E0010 227C0032
	global_load_b128 v[38:41], v[54:55], off offset:16         // 0000008378C0: DC5E0010 267C0036
	global_load_b128 v[42:45], v[50:51], off offset:32         // 0000008378C8: DC5E0020 2A7C0032
	global_load_b128 v[46:49], v[54:55], off offset:32         // 0000008378D0: DC5E0020 2E7C0036
	global_load_b128 v[50:53], v[50:51], off offset:48         // 0000008378D8: DC5E0030 327C0032
	global_load_b128 v[54:57], v[54:55], off offset:48         // 0000008378E0: DC5E0030 367C0036
	v_lshrrev_b32_e32 v2, 22, v2                               // 0000008378E8: 32040496
	v_and_b32_e32 v1, 0x3fc, v1                                // 0000008378EC: 360202FF 000003FC
	v_lshlrev_b32_e32 v60, 2, v60                              // 0000008378F4: 30787882
	v_and_b32_e32 v61, 0x3fc, v61                              // 0000008378F8: 367A7AFF 000003FC
	v_and_b32_e32 v62, 0x3fc, v62                              // 000000837900: 367C7CFF 000003FC
	v_and_b32_e32 v2, 0x3fc, v2                                // 000000837908: 360404FF 000003FC
	ds_load_b32 v1, v1                                         // 000000837910: D8D80000 01000001
	ds_load_b32 v60, v60                                       // 000000837918: D8D80000 3C00003C
	ds_load_b32 v61, v61                                       // 000000837920: D8D80000 3D00003D
	ds_load_b32 v62, v62                                       // 000000837928: D8D80000 3E00003E
	ds_load_b32 v2, v2                                         // 000000837930: D8D80000 02000002
	v_add_nc_u32_e32 v23, 0x200, v23                           // 000000837938: 4A2E2EFF 00000200
	v_add_nc_u32_e32 v24, 64, v24                              // 000000837940: 4A3030C0
	v_add_nc_u32_e32 v12, 0x400, v12                           // 000000837944: 4A1818FF 00000400
	s_and_b32 s2, exec_lo, vcc_lo                              // 00000083794C: 8B026A7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000837950: BF870009
	s_or_b32 s14, s2, s14                                      // 000000837954: 8C0E0E02
	s_waitcnt vmcnt(7) lgkmcnt(7)                              // 000000837958: BF891C77
	v_dot2_f32_bf16 v26, v26, v13, 0                           // 00000083795C: CC1A401A 1A021B1A
	s_waitcnt vmcnt(6)                                         // 000000837964: BF891BF7
	v_dot2_f32_bf16 v13, v30, v13, 0                           // 000000837968: CC1A400D 1A021B1E
	v_and_b32_e32 v30, 0xff, v3                                // 000000837970: 363C06FF 000000FF
	s_waitcnt lgkmcnt(6)                                       // 000000837978: BF89FC67
	v_dot2_f32_bf16 v26, v27, v58, v26                         // 00000083797C: CC1A401A 1C6A751B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837984: BF870003
	v_dot2_f32_bf16 v13, v31, v58, v13                         // 000000837988: CC1A400D 1C36751F
	v_lshrrev_b32_e32 v27, 6, v3                               // 000000837990: 32360686
	v_lshrrev_b32_e32 v31, 14, v3                              // 000000837994: 323E068E
	v_lshrrev_b32_e32 v3, 22, v3                               // 000000837998: 32060696
	s_waitcnt lgkmcnt(5)                                       // 00000083799C: BF89FC57
	v_dot2_f32_bf16 v26, v28, v59, v26                         // 0000008379A0: CC1A401A 1C6A771C
	v_dot2_f32_bf16 v13, v32, v59, v13                         // 0000008379A8: CC1A400D 1C367720
	v_and_b32_e32 v27, 0x3fc, v27                              // 0000008379B0: 363636FF 000003FC
	v_and_b32_e32 v28, 0xff, v4                                // 0000008379B8: 363808FF 000000FF
	v_lshrrev_b32_e32 v32, 6, v4                               // 0000008379C0: 32400886
	s_waitcnt lgkmcnt(4)                                       // 0000008379C4: BF89FC47
	v_dot2_f32_bf16 v26, v29, v1, v26                          // 0000008379C8: CC1A401A 1C6A031D
	v_dot2_f32_bf16 v1, v33, v1, v13                           // 0000008379D0: CC1A4001 1C360321
	v_lshlrev_b32_e32 v13, 2, v30                              // 0000008379D8: 301A3C82
	v_and_b32_e32 v29, 0x3fc, v31                              // 0000008379DC: 363A3EFF 000003FC
	v_lshrrev_b32_e32 v58, 14, v4                              // 0000008379E4: 3274088E
	s_waitcnt vmcnt(5) lgkmcnt(3)                              // 0000008379E8: BF891437
	v_dot2_f32_bf16 v26, v34, v60, v26                         // 0000008379EC: CC1A401A 1C6A7922
	s_waitcnt vmcnt(4)                                         // 0000008379F4: BF8913F7
	v_dot2_f32_bf16 v1, v38, v60, v1                           // 0000008379F8: CC1A4001 1C067926
	ds_load_b32 v13, v13                                       // 000000837A00: D8D80000 0D00000D
	ds_load_b32 v27, v27                                       // 000000837A08: D8D80000 1B00001B
	ds_load_b32 v29, v29                                       // 000000837A10: D8D80000 1D00001D
	s_waitcnt lgkmcnt(5)                                       // 000000837A18: BF89FC57
	v_dot2_f32_bf16 v26, v35, v61, v26                         // 000000837A1C: CC1A401A 1C6A7B23
	v_dot2_f32_bf16 v1, v39, v61, v1                           // 000000837A24: CC1A4001 1C067B27
	v_lshrrev_b32_e32 v4, 22, v4                               // 000000837A2C: 32080896
	v_and_b32_e32 v3, 0x3fc, v3                                // 000000837A30: 360606FF 000003FC
	v_lshlrev_b32_e32 v28, 2, v28                              // 000000837A38: 30383882
	s_waitcnt lgkmcnt(4)                                       // 000000837A3C: BF89FC47
	v_dot2_f32_bf16 v26, v36, v62, v26                         // 000000837A40: CC1A401A 1C6A7D24
	v_dot2_f32_bf16 v1, v40, v62, v1                           // 000000837A48: CC1A4001 1C067D28
	v_and_b32_e32 v30, 0x3fc, v32                              // 000000837A50: 363C40FF 000003FC
	v_and_b32_e32 v31, 0x3fc, v58                              // 000000837A58: 363E74FF 000003FC
	v_and_b32_e32 v4, 0x3fc, v4                                // 000000837A60: 360808FF 000003FC
	s_waitcnt lgkmcnt(3)                                       // 000000837A68: BF89FC37
	v_dot2_f32_bf16 v26, v37, v2, v26                          // 000000837A6C: CC1A401A 1C6A0525
	v_dot2_f32_bf16 v1, v41, v2, v1                            // 000000837A74: CC1A4001 1C060529
	ds_load_b32 v2, v3                                         // 000000837A7C: D8D80000 02000003
	ds_load_b32 v3, v28                                        // 000000837A84: D8D80000 0300001C
	ds_load_b32 v28, v30                                       // 000000837A8C: D8D80000 1C00001E
	ds_load_b32 v30, v31                                       // 000000837A94: D8D80000 1E00001F
	ds_load_b32 v31, v4                                        // 000000837A9C: D8D80000 1F000004
	s_waitcnt vmcnt(3) lgkmcnt(7)                              // 000000837AA4: BF890C77
	v_dot2_f32_bf16 v4, v42, v13, v26                          // 000000837AA8: CC1A4004 1C6A1B2A
	s_waitcnt vmcnt(2)                                         // 000000837AB0: BF890BF7
	v_dot2_f32_bf16 v1, v46, v13, v1                           // 000000837AB4: CC1A4001 1C061B2E
	s_waitcnt lgkmcnt(6)                                       // 000000837ABC: BF89FC67
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837AC0: BF870112
	v_dot2_f32_bf16 v4, v43, v27, v4                           // 000000837AC4: CC1A4004 1C12372B
	v_dot2_f32_bf16 v1, v47, v27, v1                           // 000000837ACC: CC1A4001 1C06372F
	s_waitcnt lgkmcnt(5)                                       // 000000837AD4: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837AD8: BF870112
	v_dot2_f32_bf16 v4, v44, v29, v4                           // 000000837ADC: CC1A4004 1C123B2C
	v_dot2_f32_bf16 v1, v48, v29, v1                           // 000000837AE4: CC1A4001 1C063B30
	s_waitcnt lgkmcnt(4)                                       // 000000837AEC: BF89FC47
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837AF0: BF870112
	v_dot2_f32_bf16 v4, v45, v2, v4                            // 000000837AF4: CC1A4004 1C12052D
	v_dot2_f32_bf16 v1, v49, v2, v1                            // 000000837AFC: CC1A4001 1C060531
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 000000837B04: BF890437
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000837B08: BF870122
	v_dot2_f32_bf16 v2, v50, v3, v4                            // 000000837B0C: CC1A4002 1C120732
	s_waitcnt vmcnt(0)                                         // 000000837B14: BF8903F7
	v_dot2_f32_bf16 v1, v54, v3, v1                            // 000000837B18: CC1A4001 1C060736
	v_dual_mov_b32 v4, v8 :: v_dual_mov_b32 v3, v7             // 000000837B20: CA100108 04020107
	s_waitcnt lgkmcnt(2)                                       // 000000837B28: BF89FC27
	v_dot2_f32_bf16 v2, v51, v28, v2                           // 000000837B2C: CC1A4002 1C0A3933
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000837B34: BF870123
	v_dot2_f32_bf16 v1, v55, v28, v1                           // 000000837B38: CC1A4001 1C063937
	s_waitcnt lgkmcnt(1)                                       // 000000837B40: BF89FC17
	v_dot2_f32_bf16 v2, v52, v30, v2                           // 000000837B44: CC1A4002 1C0A3D34
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000837B4C: BF870122
	v_dot2_f32_bf16 v1, v56, v30, v1                           // 000000837B50: CC1A4001 1C063D38
	s_waitcnt lgkmcnt(0)                                       // 000000837B58: BF89FC07
	v_dot2_f32_bf16 v7, v53, v31, v2                           // 000000837B5C: CC1A4007 1C0A3F35
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837B64: BF8701A2
	v_dot2_f32_bf16 v8, v57, v31, v1                           // 000000837B68: CC1A4008 1C063F39
	v_dual_mov_b32 v2, v6 :: v_dual_mov_b32 v1, v5             // 000000837B70: CA100106 02000105
	v_fmac_f32_e32 v22, v18, v7                                // 000000837B78: 562C0F12
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837B7C: BF870003
	v_dual_fmac_f32 v17, v18, v8 :: v_dual_mov_b32 v18, v25    // 000000837B80: C8101112 11120119
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 000000837B88: 917E0E7E
	s_cbranch_execz 31                                         // 000000837B8C: BFA5001F <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x60c>
	s_waitcnt vmcnt(0)                                         // 000000837B90: BF8903F7
	v_dual_mov_b32 v6, v2 :: v_dual_add_nc_u32 v19, 32, v19    // 000000837B94: CA200102 061226A0
	v_dual_mov_b32 v5, v1 :: v_dual_mov_b32 v8, v4             // 000000837B9C: CA100101 05080104
	v_mov_b32_e32 v7, v3                                       // 000000837BA4: 7E0E0303
	s_mov_b32 s10, exec_lo                                     // 000000837BA8: BE8A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000837BAC: BF870003
	v_cmp_ge_i32_e32 vcc_lo, v19, v20                          // 000000837BB0: 7C8C2913
	.long 0xd4c1007e                                           // 000000837BB4: D4C1007E
	v_cndmask_b32_e32 v1, v19, v20, vcc_lo                     // 000000837BB8: 02022913
	s_cbranch_execz 65303                                      // 000000837BBC: BFA5FF17 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	v_ashrrev_i32_e32 v6, 31, v24                              // 000000837BC0: 340C309F
	v_ashrrev_i32_e32 v8, 31, v23                              // 000000837BC4: 34102E9F
	.long 0xd7000205                                           // 000000837BC8: D7000205
	v_cndmask_b32_e32 v1, v11, v24, vcc_lo                     // 000000837BCC: 0202310B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000837BD0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, v21, v6, s2                  // 000000837BD4: D5207C06 000A0D15
	.long 0xd7000207                                           // 000000837BDC: D7000207
	v_cndmask_b32_e32 v1, v9, v23, vcc_lo                      // 000000837BE0: 02022F09
	v_add_co_ci_u32_e64 v8, null, v10, v8, s2                  // 000000837BE4: D5207C08 000A110A
	s_clause 0x1                                               // 000000837BEC: BF850001
	global_load_d16_b16 v13, v[5:6], off                       // 000000837BF0: DC820000 0D7C0005
	global_load_b128 v[5:8], v[7:8], off                       // 000000837BF8: DC5E0000 057C0007
	s_waitcnt vmcnt(1)                                         // 000000837C00: BF8907F7
	v_cvt_f32_f16_e32 v25, v13                                 // 000000837C04: 7E32170D
	s_branch 65284                                             // 000000837C08: BFA0FF04 <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x21c>
	s_or_b32 exec_lo, exec_lo, s14                             // 000000837C0C: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000837C10: BF8700C9
	s_or_b32 exec_lo, exec_lo, s3                              // 000000837C14: 8C7E037E
	s_waitcnt vmcnt(0)                                         // 000000837C18: BF8903F7
	.long 0xd71f0001                                           // 000000837C1C: D71F0001
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000837C20: 020100C1
	s_mov_b32 s2, exec_lo                                      // 000000837C24: BE82007E
	v_xor_b32_e32 v2, 16, v1                                   // 000000837C28: 3A040290
	v_xor_b32_e32 v4, 8, v1                                    // 000000837C2C: 3A080288
	v_xor_b32_e32 v6, 4, v1                                    // 000000837C30: 3A0C0284
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000837C34: BF870223
	v_cmp_gt_u32_e32 vcc_lo, 32, v2                            // 000000837C38: 7C9804A0
	v_cndmask_b32_e32 v2, v1, v2, vcc_lo                       // 000000837C3C: 02040501
	v_cmp_gt_u32_e32 vcc_lo, 32, v4                            // 000000837C40: 7C9808A0
	s_delay_alu instid0(VALU_DEP_2)                            // 000000837C44: BF870002
	v_lshlrev_b32_e32 v2, 2, v2                                // 000000837C48: 30040482
	v_cndmask_b32_e32 v4, v1, v4, vcc_lo                       // 000000837C4C: 02080901
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000837C50: 7C980CA0
	ds_bpermute_b32 v3, v2, v22                                // 000000837C54: DACC0000 03001602
	v_lshlrev_b32_e32 v4, 2, v4                                // 000000837C5C: 30080882
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000837C60: 020C0D01
	s_waitcnt lgkmcnt(0)                                       // 000000837C64: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000837C68: BF870001
	v_dual_add_f32 v3, v22, v3 :: v_dual_lshlrev_b32 v6, 2, v6 // 000000837C6C: C9220716 03060C82
	ds_bpermute_b32 v5, v4, v3                                 // 000000837C74: DACC0000 05000304
	s_waitcnt lgkmcnt(0)                                       // 000000837C7C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 000000837C80: 06060B03
	ds_bpermute_b32 v2, v2, v17                                // 000000837C84: DACC0000 02001102
	s_waitcnt lgkmcnt(0)                                       // 000000837C8C: BF89FC07
	v_add_f32_e32 v2, v17, v2                                  // 000000837C90: 06040511
	ds_bpermute_b32 v4, v4, v2                                 // 000000837C94: DACC0000 04000204
	s_waitcnt lgkmcnt(0)                                       // 000000837C9C: BF89FC07
	v_add_f32_e32 v2, v2, v4                                   // 000000837CA0: 06040902
	ds_bpermute_b32 v4, v6, v3                                 // 000000837CA4: DACC0000 04000306
	ds_bpermute_b32 v5, v6, v2                                 // 000000837CAC: DACC0000 05000206
	v_xor_b32_e32 v6, 2, v1                                    // 000000837CB4: 3A0C0282
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000837CB8: BF8700B1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000837CBC: 7C980CA0
	v_cndmask_b32_e32 v6, v1, v6, vcc_lo                       // 000000837CC0: 020C0D01
	s_waitcnt lgkmcnt(1)                                       // 000000837CC4: BF89FC17
	v_dual_add_f32 v3, v3, v4 :: v_dual_lshlrev_b32 v6, 2, v6  // 000000837CC8: C9220903 03060C82
	s_waitcnt lgkmcnt(0)                                       // 000000837CD0: BF89FC07
	v_add_f32_e32 v4, v2, v5                                   // 000000837CD4: 06080B02
	ds_bpermute_b32 v2, v6, v3                                 // 000000837CD8: DACC0000 02000306
	ds_bpermute_b32 v5, v6, v4                                 // 000000837CE0: DACC0000 05000406
	v_xor_b32_e32 v6, 1, v1                                    // 000000837CE8: 3A0C0281
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000837CEC: BF8700A1
	v_cmp_gt_u32_e32 vcc_lo, 32, v6                            // 000000837CF0: 7C980CA0
	v_cndmask_b32_e32 v1, v1, v6, vcc_lo                       // 000000837CF4: 02020D01
	v_lshlrev_b32_e32 v6, 2, v1                                // 000000837CF8: 300C0282
	s_waitcnt lgkmcnt(0)                                       // 000000837CFC: BF89FC07
	v_dual_add_f32 v2, v3, v2 :: v_dual_add_f32 v1, v4, v5     // 000000837D00: C9080503 02000B04
	ds_bpermute_b32 v4, v6, v2                                 // 000000837D08: DACC0000 04000206
	ds_bpermute_b32 v3, v6, v1                                 // 000000837D10: DACC0000 03000106
	v_cmpx_eq_u32_e32 0, v16                                   // 000000837D18: 7D942080
	s_cbranch_execz 10                                         // 000000837D1C: BFA5000A <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x748>
	s_waitcnt lgkmcnt(1)                                       // 000000837D20: BF89FC17
	v_dual_add_f32 v2, v2, v4 :: v_dual_lshlrev_b32 v5, 3, v15 // 000000837D24: C9220902 02041E83
	s_waitcnt lgkmcnt(0)                                       // 000000837D2C: BF89FC07
	v_add_f32_e32 v3, v1, v3                                   // 000000837D30: 06060701
	s_delay_alu instid0(VALU_DEP_2)                            // 000000837D34: BF870002
	v_lshl_or_b32 v4, v14, 4, v5                               // 000000837D38: D6560004 0415090E
	ds_store_b64 v4, v[2:3] offset:1024                        // 000000837D40: D9340400 00000204
	s_or_b32 exec_lo, exec_lo, s2                              // 000000837D48: 8C7E027E
	s_waitcnt lgkmcnt(0)                                       // 000000837D4C: BF89FC07
	v_lshrrev_b32_e32 v3, 1, v0                                // 000000837D50: 32060081
	v_mov_b32_e32 v2, s21                                      // 000000837D54: 7E040215
	.long 0xd44c0002                                           // 000000837D58: D44C0002
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000837D5C: 02020088
	s_barrier                                                  // 000000837D60: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000837D64: BF8704C3
	v_or_b32_e32 v1, s20, v3                                   // 000000837D68: 38020614
	buffer_gl0_inv                                             // 000000837D6C: E0AC0000 00000000
	v_cmp_gt_i64_e32 vcc_lo, s[12:13], v[1:2]                  // 000000837D74: 7CA8020C
	s_and_b32 s2, s2, vcc_lo                                   // 000000837D78: 8B026A02
	s_and_saveexec_b32 s3, s2                                  // 000000837D7C: BE832002
	s_cbranch_execz 75                                         // 000000837D80: BFA5004B <_ZN7halogen12_GLOBAL__N_16k_lq4wILi2ELi32ELi2ELb1ELi3ELi0EEEvPKhPKtPvlllllS6_f+0x8b0>
	v_and_b32_e32 v0, 1, v0                                    // 000000837D84: 36000081
	s_load_b32 s0, s[0:1], 0x48                                // 000000837D88: F4000000 F8000048
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837D90: BF870091
	v_lshlrev_b32_e32 v4, 2, v0                                // 000000837D94: 30080082
	v_lshl_or_b32 v3, v3, 4, v4                                // 000000837D98: D6560003 04110903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000837DA0: BF8700C1
	v_add_nc_u32_e32 v3, 0x400, v3                             // 000000837DA4: 4A0606FF 00000400
	ds_load_2addr_b32 v[3:4], v3 offset1:2                     // 000000837DAC: D8DC0200 03000003
	s_waitcnt lgkmcnt(0)                                       // 000000837DB4: BF89FC07
	v_add_f32_e32 v3, 0, v3                                    // 000000837DB8: 06060680
	v_add_f32_e32 v3, v3, v4                                   // 000000837DBC: 06060903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837DC0: BF870091
	v_bfe_u32 v4, v3, 16, 1                                    // 000000837DC4: D6100004 02052103
	v_add3_u32 v3, v3, v4, 0x7fff                              // 000000837DCC: D6550003 03FE0903 00007FFF
	.long 0xd72c0004                                           // 000000837DD8: D72C0004
	v_cndmask_b32_e32 v1, s13, v0, vcc_lo                      // 000000837DDC: 0202000D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837DE0: BF870092
	v_and_b32_e32 v3, 0xffff0000, v3                           // 000000837DE4: 360606FF FFFF0000
	v_mul_f32_e32 v3, s0, v3                                   // 000000837DEC: 10060600
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837DF0: BF870091
	v_mul_f32_e32 v3, 0xbfb8aa3b, v3                           // 000000837DF4: 100606FF BFB8AA3B
	v_exp_f32_e32 v3, v3                                       // 000000837DFC: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837E00: BF870095
	v_add_f32_e32 v5, 1.0, v3                                  // 000000837E04: 060A06F2
	v_div_scale_f32 v6, null, v5, v5, 1.0                      // 000000837E08: D6FC7C06 03CA0B05
	v_div_scale_f32 v8, vcc_lo, 1.0, v5, 1.0                   // 000000837E10: D6FC6A08 03CA0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000837E18: BF870292
	v_rcp_f32_e32 v7, v6                                       // 000000837E1C: 7E0E5506
	v_fma_f32 v3, -v6, v7, 1.0                                 // 000000837E20: D6130003 23CA0F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837E28: BF870091
	v_fmac_f32_e32 v7, v3, v7                                  // 000000837E2C: 560E0F03
	v_mul_f32_e32 v9, v8, v7                                   // 000000837E30: 10120F08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000837E34: BF870091
	v_fma_f32 v3, -v6, v9, v8                                  // 000000837E38: D6130003 24221306
	v_fmac_f32_e32 v9, v3, v7                                  // 000000837E40: 56120F03
	.long 0xd72c0003                                           // 000000837E44: D72C0003
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 000000837E48: 0202000C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000837E4C: BF870112
	v_fma_f32 v0, -v6, v9, v8                                  // 000000837E50: D6130000 24221306
	.long 0xd73c0003                                           // 000000837E58: D73C0003
	v_cndmask_b32_e32 v1, 2, v3, vcc_lo                        // 000000837E5C: 02020682
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837E60: BF8701A2
	v_div_fmas_f32 v6, v0, v7, v9                              // 000000837E64: D6370006 04260F00
	.long 0xd73c0000                                           // 000000837E6C: D73C0000
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000837E70: 02020282
	.long 0xd7006a03                                           // 000000837E74: D7006A03
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 000000837E78: 02020608
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000837E7C: BF8701A3
	v_div_fixup_f32 v2, v6, v5, 1.0                            // 000000837E80: D6270002 03CA0B06
	v_add_co_ci_u32_e64 v4, null, s9, v4, vcc_lo               // 000000837E88: D5207C04 01AA0809
	.long 0xd7006a00                                           // 000000837E90: D7006A00
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 000000837E94: 02020103
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000837E98: BF870193
	v_add_f32_e32 v2, v2, v2                                   // 000000837E9C: 06040502
	v_add_co_ci_u32_e64 v1, null, v4, v1, vcc_lo               // 000000837EA0: D5207C01 01AA0304
	global_store_b32 v[0:1], v2, off                           // 000000837EA8: DC6A0000 007C0200
	s_endpgm                                                   // 000000837EB0: BFB00000
		...

